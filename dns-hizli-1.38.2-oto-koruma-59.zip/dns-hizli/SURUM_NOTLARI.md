# Sürüm notları

Ayrıntılı geliştirme tarihçesi ve kararlar: [DNS_HIZLI_TARIHCE.txt](DNS_HIZLI_TARIHCE.txt). En yeni sürüm en üstte.

## oto-koruma 57 — mimari: durum makineleri servisten çekirdeğe (`ServiceMachines`)
- **`GwValve` (core):** ağ geçidi vanasının sayaç/karar mantığı (`gwTick` içindeki 4 sayaç: kötü ölçüm, DPI kötü ölçüm, sağlıklı seri, kesinti sayısı) saf sınıfa taşındı. Girdi: gözlem (`Obs`), çıktı: `NONE / TRIP_DPI / TRIP_ALL`. Servis yalnızca kararı uygular (modülleri kapat, geri açma zamanlayıcısı kur).
- **`RetrySchedule` (core):** bağlanma yeniden deneme çizelgesi (7 basamak, kapalı kipte ≤120 sn ve vazgeçmeyen) ve sabitleri servisten çıktı.
- Test (`sizma24`, +31 kontrol): eski sayaç kodunun kelimesi kelimesine kopyası kâhin olarak 20 000 rastgele dizi × 30 ölçümde karar ve kesinti sayacı birebir; tek tek senaryolar (tek kötü ölçüm açmaz, çevrimdışı/DNS cevapsızken açılmaz, ayarlarda DPI kapalıysa DPI vanası açılmaz, 20. sağlıklı ölçümde af, seri kesilirse af baştan). `sizma25` servisin eski sayaçları taşımadığını ve çekirdeğe devrettiğini denetler.
- **Derleme düzeltmesi (GitHub #58):** `DnsVpnService.backupFor` sondaki lambdayı yanlış parametreye (`all`) bağlıyordu ("No value passed for parameter latencies"). `ServicePolicy.backupFor` parametre sırası değişti (lambda en sonda) ve servis adlandırılmış argümanla çağırıyor. Ders: `platform` değişiklikleri GitHub derlemesine kadar doğrulanamıyor; sizma25 yalnızca ön eleme.
- Davranış farkı (yalnızca performans): `gwTick` artık her dakika ayarları bir kez okur (eskiden yalnızca vana anında).
- Dürüst sınırlar: `DnsVpnService` hâlâ çok büyük (bağlan/geçiş/duraklat/kapat akışları ve Android çağrıları içinde); `object` tekilleri (`FilterRuntime` vb.) değişmedi. `platform/*` yerelde DERLENMEDİ.

## oto-koruma 56 — puanlama eleştirilerine yanıt: servis mantığı çekirdeğe, platform için statik denetim, aralıklı test
- **`ServicePolicy` (core, yeni):** `DnsVpnService` içindeki saf kararlar çıkarıldı: doğrulama deneme sayısı/süresi (`triesFor`, `msFor`), gizlilik düşüşü (`isDowngrade`), yedek sunucu (`backupFor`), sunucu halkası (`nextRing`, `nextInRing`), ağ geçidi modülleri (`gwWanted`, `gwLevelFor`), duraklatma süresi (`pauseUntil`, `pauseRemainingMs`: saat geri/ileri sıçrasa da alarm 0..24 sa). Serviste aynı adlı özel işlevler artık yalnızca bu nesneye devreder. Test `sizma24` (12 kontrol): eski gövdelerin birebir kopyası kâhin; 3000 rastgele ayarda yedek/halka eşit; halka döngüsel ve kendine dönmez.
- **Platform için derleyicisiz statik denetim `sizma25` (14 kontrol):** parantez/küme dengesi, her `import app.dnshizli.core.X` çekirdekte var, kullanılan çekirdek türü import edilmiş, platformun çağırdığı çekirdek nesne üyeleri var (204 erişim), `DnsVpnService`'te çift işlev yok, servis `ServicePolicy`'ye devrediyor. Bozulan kopyalarla (import silme, var olmayan üye, çift tanım, yanlış import) denetimin yakaladığı doğrulandı. Derlemenin yerine GEÇMEZ; GitHub derlemesi öncesi ucuz ön eleme.
- Aralıklı test: "kalıcı yedek geçişi" artık toplam sayaç yerine yalnızca ikinci sorgunun artışına bakar (ilk sorgunun yeniden deneme zamanlamasına bağlı değil).
- Dürüst sınırlar: `DnsVpnService` yaklaşık 2740 satırla hâlâ büyük; yalnızca saf kararlar ayrıldı, durum makinesi (bağlan/duraklat/geçiş) ve Android çağrıları servis içinde. Gerçek bölme (ör. gateway yöneticisi, duraklatma denetleyicisi) derleme ve cihaz denemesi gerektirir. `object` tekilleri (`FilterRuntime` vb.) değişmedi. `platform/*` yerelde DERLENMEDİ.

## oto-koruma 55 — büyük bozulmalara karşı sınama (`sizma23`, 85 kontrol) ve 8 sağlamlaştırma
- Yöntem: bozuk/kesik/bit çevrilmiş liste dosyaları, bellek bombası başlıkları, güncellemenin her adımında güç kesintisi, diskte çürüyen önbellek, bozuk manifest/imza, saatin geri sarılması, bellek yetmemesi.
- **Bulunan zayıflıklar ve düzeltmeler:**
  - `FilterTier.read`: 4 baytlık başlık "30 milyon" derse diziler veriden önce ayrılıyordu (~120 MB, düşük bellekli telefonda OOM). Artık diziler okunan veriyle ikiye katlanarak büyür; dev başlık + 10 bayt veri 4 MB'ın altında IOException verir.
  - `FilterRuntime.build`: korunan ad listesi (`protected.txt`) ya da PSL okunurken OutOfMemoryError arka plan işini sessizce öldürüyordu (motor kurulmaz, yeniden deneme yok). Artık `Throwable` yakalanır: yedek motor kurulur, `heal` yeniden dener.
  - `protected.txt` okunamazsa tüm motor düşüyordu (katmanlardaki paket yedeği burada yoktu) → artık paketteki sürüme düşer. `readTier` yedeği yalnızca IOException'da değil her istisnada (depolama/SecurityException) devreye girer.
  - `DnsCache`: saat geri giderse kaydın yaşı bilinemiyordu (süre uzuyordu) → kayıt atılır. (Üretimde saat `nanoTime`, yani tekdüze; savunma amaçlı.)
  - `RollingCounter`: saat geri giderse pencere ilerlemiyor, sayaç kilitleniyordu → baştan kurulur.
  - `ListStore.install`: dosyalar `fsync` ile diske zorlanır (yeniden adlandırma kalıcı olup güç kesilirse sıfır uzunluklu liste kalmasın).
- Doğrulanan, değişiklik gerektirmeyenler: kesik/bit çevrilmiş/çöp liste (3300+ bit çevirme, her önek) yalnızca IOException; 8 bozulma türü × 3 katman paket yedeğiyle aynı kararlar; 200 güç kesintisi senaryosu sürüm karıştırmıyor; 5000+ bozuk manifest/imza istisna atmıyor; Immune geri sarılmada çökmüyor.
- Mutasyon: 9 mutant (büyüme, bomba, istisna türü, protected yedeği, Throwable, 3 saat koruması, RollingCounter); 8 öldü, 1 eşdeğer (`prefetchDue` saat koruması: geri saatte zaten false).
- **Bit çürümesi artık yakalanır:** `ListStore.install` kurulumda her dosyanın SHA-256 + boyunu `ozet.txt` olarak aynı dizine (aynı atomik adımda) yazar; `ListUpdater.open` önbellek dosyasını motora vermeden `ListStore.verified` ile doğrular. Uymazsa (yapısı geçerli kalıp içeriği değişen dosya dahil) paketteki liste kullanılır, günlüğe yazılır ve sürüm sıfırlanıp yeniden indirme tetiklenir. Özet dosyası yoksa/bozuksa/şişirilmişse (>4 KB) güvenli tarafta paket listesi. Sonuç (yol, boy, zaman) aynı kaldıkça bellekte tutulur (yeniden yüklemede tekrar özetlenmez); işlem başına bir kez doğrulanır. Eski sürüm önbelleği (özetsiz) bir kez paket listesine düşer, ardından yeniden indirilir.
- **Disk dolu / izin hatası artık enjekte edilerek sınandı:** `ListStore.Io` (yazma, yeniden adlandırma) ayrılığı; her yazım noktasında ENOSPC istisnası, sessiz kısa yazım, sıfır bayt yazım ve 1./2. yeniden adlandırmada false/istisna: kurulum false döner, eski sürüm sağlam ve doğrulanır, artık dizin kalmaz, sonraki kurulum çalışır. Kurulum artık her yazımdan sonra dosya boyunu denetler (kısa yazımı hata saymayan sistemlerde yarım liste yerine konmaz) ve `Throwable` yakalar.
- Mutasyon (ListStore): 9 mutant; 7 hemen öldü, 2 yaşayan (bellek anahtarı yalnız yol; özet dosyası boyut sınırı) için test eklenip öldürüldü.
- Bilinen sınırlar: özet, indirme sonrası yerel kayıttır; saldırgan aynı anda hem listeyi hem `ozet.txt`'i değiştirebilecek kadar uygulama dizinine yazabiliyorsa (kök) zaten her şey mümkündür. İşlem ömrü içinde doğrulanmış dosyanın sonradan, aynı boy ve aynı değişme zamanıyla bozulması bir sonraki işlem başlangıcına kadar görülmez. Android kodu (`platform/*`, `ListUpdater.open` değişikliği dahil) yerelde DERLENMEDİ.

## oto-koruma 54 — ikinci hata avı: mutasyon ölçümüyle 3 test boşluğu kapatıldı, 1 küçük sağlamlaştırma

Mutasyon ölçümü Immune, Dpi, Format, Settings, CustomDns, ServerList, PlanMemory dosyalarında koşturuldu; yakalanamayan bozmalar incelendi:
- **Immune doğrulama turu** (`streak < CONFIRM_TICKS`): "eşiği aşan ama patlama olmayan sinyal tek turda değil art arda 2 turda önlem açar" sınırı hiç sınanmıyordu → test eklendi (bozma artık yakalanıyor).
- **`Format.share/clock/span/ago`** sınır tabloları sınanmıyordu → eklendi.
- **`ServerList.fastest/recommend/visible`**: "eşit gecikmede katalog sırası" belgelenmişti ama sınanmıyordu → eklendi (bozma yakalanıyor); sinyal çubuğu sınırları eklendi.
- **Sağlamlaştırma:** `LatencyHistory.mean` Int toplamı bozuk/çok büyük kayıtlı değerlerde taşabilirdi → Long toplam.
- Denk (davranışı değiştirmeyen) sayılan hayatta kalanlar: `Immune` quietMul `>1`/`>=1`, `s.base<0`/`<=0`, harmEv `<=`/`<` (tam KEEP_MS ms sınırı), `Dpi.httpEnd` `x<0`/`x<=0` (x=0 üretilemez), `CustomDns.newId` uzunluk sınırı (üretilemez), `sameIp` ayrıştırılamaz yedeği (önce validIp denetlenir).
- Tam paket: 13361 kontrol, 0 başarısız.
- Güvenlik açığı bulunmadı (CnameGuard iş parçacığı yalıtımı, ListUpdate imza/rollback, ListStore atomik değişim, BlockedSites ayrıştırması, TextSafe okundu). `platform/*` bu turda değişmedi.

## oto-koruma 53 — hata avı (1 hata düzeltildi, bir dizi alan referansla temize çıktı)

Yeni grup `sizma22` (7 kontrol), bağımsız referanslarla:
- **Hata — `Format.bytes`:** birim sınırında yuvarlama taşıyordu: 1.048.064 bayt "1024 KB" gösteriyordu ("1 MB" olmalıydı). Artık bir üst birime geçer.
- **Temiz çıkanlar:** `Format.count` sınırları, `PublicSuffix.registrableStart` (psl.txt'nin tamamı, PSL belirtimi algoritmasıyla 150 bin ad), TCP/UDP sağlama toplamları (IPv4+IPv6, bağımsız sözde-başlık referansı; 72 bin tek bit hatasının hiçbiri kabul edilmedi).
- Gözle taranıp sorun bulunmayanlar: `!!` kullanımları (ağdan gelen girdide hepsi try/catch ya da önceden doğrulanmış), `TlsFingerprint`, `LatencyRing`, DailyStats/UsageStats/SessionLog, Immune/PlanMemory/AppAds kod çözücüleri.
- Tam paket: 13343 kontrol, 0 başarısız.
- Güvenlik açığı bu turda bulunmadı. `platform/*` dokunulmadı (bu turda). Android yerelde derlenmedi.

## oto-koruma 52 — CA anahtarı Keystore ile sarıldı, platform karar mantığı core'a alınıp test edildi

- **MITM CA özel anahtarı artık Android Keystore'da tutulan AES-256-GCM anahtarıyla sarılı saklanır** (`ca.key` = "DHK1" + IV + şifreli metin). Anahtar telefondan çıkamaz; özel klasörün kopyası tek başına CA anahtarını vermez. Eski düz dosya ilk açılışta otomatik sarılı biçime çevrilir. Keystore kullanılamazsa eski davranışa (düz dosya) düşer: özellik bozulmaz. Mantık `core/KeyVault.kt` (bilgisayarda sınanır), Android uygulaması `platform/MitmStore.kt` içindeki `KeystoreWrapper`.
- **Platform karar mantığı core'a çıkarıldı** (`core/PlatformPolicy.kt`): `BootPolicy` (açılış/güncelleme/duraklatma kararı, sahte QUICKBOOT koruması) ve `IntentPolicy` (dışarıdan gelen niyetin güveni: sunucu seçemez, duraklatamaz, doğrudan kesemez). `BootReceiver` ve `MainActivity.handleIntent` artık yalnızca bu kararı uygular.
- Yeni test grubu `sizma21` (22 kontrol): KeyVault (300 bit çevirme, yanlış anahtar, kesik dosya, göç, sarma hatası), BootPolicy (eski mantıkla 200 bin rastgele durumda birebir), IntentPolicy (≈ 30 bin girdi birleşiminde güvenlik değişmezleri). Mutasyon: 3 bozma yakalandı, 4.'sü (gereksiz erken dönüş) denk çıktı ve kaldırıldı.
- **UYARI: `platform/MitmStore.kt`, `BootReceiver.kt`, `MainActivity.kt` değişti ve Android'de DERLENMEDİ.** GitHub Actions derlemesi bu sürümde özellikle gerekli.
- Tam paket: 13336 kontrol, 0 başarısız.
- Yapılmadı: `DnsVpnService.kt` (2763 satır) bölünmedi — derlenemeyen kodda büyük taşıma riskli.

## oto-koruma 51 — hata bulma testleri: bağımsız referansla karşılaştırma (2 gerçek hata bulundu ve düzeltildi)

Yeni tür test (`sizma20`, 33 kontrol): aynı rastgele girdi hem uygulamanın koduna hem de JDK'ya / ayrı yazılmış basit bir modele verilir; ayrılan her durum incelenir.
- **Hata 1 — HostsList (içe aktarma):** AdBlock kozmetik/betik kuralları (`site.com##.banner`, `#@#`, `#?#`, `#$#`, `#%#`) "yorum" diye `#`'ten kesilip geriye `site.com` kalıyordu: bir sayfanın öğesini gizleyen kural bütün siteyi ENGELLİYORDU (EasyList benzeri listeleri içe aktarırken). Artık bu kurallar atlanır.
- **Hata 2 — Base64Mini.decode (ayar kodu):** `====`, `A===` ve ortada dolgulu (`AA==AAAA`) girdiler kabul ediliyordu (JDK reddeder). Artık dolgu yalnızca son dörtlünün sonunda ve en çok 2 karakter. Etki küçük (yalnızca ayar içe aktarma), ama yanlıştı.
- Referansla birebir çıkanlar (hata yok): Base64 kodlama, `Ip.parse6` (60 bin yazım, JDK ile), `Ip.format` (RFC 5952), `Ip.parse4`, `Packets.checksum`, `DnsCache` (200 bin işlem, kayıt+bayt sınırı, LRU, bayat, TTL eskitme), `RollingCounter` (240 bin örnek).
- Tam paket: 13314 kontrol, 0 başarısız.
- Uygulama kodu değişen dosyalar: `HostsList.kt`, `Settings.kt` (yalnızca `Base64Mini`). `platform/*` dokunulmadı, Android yerelde derlenmedi.

## oto-koruma 50 — uygulama geneli güvenlik taraması

Taranan: manifest (dışa açık bileşenler, izinler, yedek, şifresiz trafik), PendingIntent bayrakları, gelen niyet/yayın işleme (MainActivity, BootReceiver, ActionReceiver, widget, kutucuk), ağ güvenliği ayarı, TLS/ana makine doğrulaması, rastgelelik kaynakları, dosya/MediaStore dışa aktarımı, görüntü çözme sınırları, özel DNS girdisi doğrulaması, ayar içe aktarma, günlüklerde kişisel veri.
- **Yeni güvenlik açığı bulunmadı.** Önceki turların önlemleri yerinde: yalnızca ana etkinlik ve başlatıcı takma adları dışa açık; "kes" isteği dışarıdan gelirse kullanıcıya sorulur; tüm PendingIntent'ler IMMUTABLE; QUICKBOOT yayını yalnızca açılış penceresinde; tüm güvenlik-duyarlı rastgelelik SecureRandom; içe aktarma yerel/servis alanlarını (onboarded, mitmOn, custom, wasActive…) ezemez ve gevşemeleri işaretler.
- Yeni test grubu (sızma 19, `sizma18` içinde, 8 kontrol; tam paket 13281 kontrol, 0 başarısız): düşmanca ayar kodları — alan enjeksiyonu, CRLF/NUL, çift anahtar, NaN/1e99, 150 KB değer, 3000 çöp kod, ayırıcı enjeksiyonu.
- Bilinen kabul edilmiş riskler: MITM CA özel anahtarı uygulamanın özel klasöründe şifresiz dosyadır (Android Keystore ile sarmak yapılabilir; CA ad kısıtlıdır); `platform/*` yerelde derlenmedi, yalnızca okundu.

## oto-koruma 49 — testlerin sınanması (mutasyon testi) ve güçlendirilmesi

Yöntem: çekirdek koddaki koşulları bilerek bozup (< ↔ <=, == ↔ !=, && ↔ ||, +1/−1) testlerin bunu yakalayıp yakalamadığına bakıldı. Yakalanmayan (hayatta kalan) bozmalar test boşluğu demektir.
- Yeni grup `sizma18` (34 kontrol): DnsCache bayat kayıt sınırı (tam STALE_MAX_MS), barındırma son ekleri (github.io, blogspot.com), 2 harfli ülke uzantısı sezgisi (co.uk, com.tr, listede olmayan ab.fr; PSL kapalı/açık), ZoneQueue şüpheli alan başına sınır, HostsList dışa aktarma/seçenek/sınır, yerel engel cevabı biçimi (QR, SOA, kök sahip, TTL, RCODE).
- TcpDns istemci MSS seçeneği ayrıştırması hiç sınanmıyordu: `tdMss` (MSS 300…5000, 50, 1 için en büyük cevap parçası = sınırlanmış MSS).
- Yeniden denenen 10 hayatta kalan bozmanın 10'u artık yakalanıyor. Kalan ~7 hayatta kalan, denk (davranışı değiştirmeyen) sınır bozmaları olarak değerlendirildi.
- Tam paket: 13273 kontrol; tek hata, 80 eşzamanlı UDP sorgunun testteki yükte tampon taşmasıydı (test düzeni, 4 dalgaya bölündü; uygulama hatası değil).
- Uygulama kodunda değişiklik yok (yalnızca testler). Android kodu (`platform/*`) yerelde derlenmedi.

## oto-koruma 48 — yinelenen yardımcıların birleştirilmesi

- Odoh.u16 artık Packets.u16'yı kullanıyor (birebir aynı kodun kopyasıydı). QuicClient.hex artık QuicInitial.hex'i kullanıyor.
- Tek kullanımlık soyutlama taraması: kullanılmayan tür yok; tek çağrılı küçük private yardımcılar (bladeTip, bladeBase, delayed, checksum20, parse) adlandırma açısından okunurluğu artırdığı için bırakıldı.
- TODO/FIXME yok. Tam paket: 13191 kontrol, 0 başarısız.

## oto-koruma 47 — ölü kod temizliği (1. adım), test düzeneği düzeltmeleri

Ölü kod (kullanılmayan sabit, yardımcı, yerel değişken; uygulamanın hiçbir yerinde ve testlerde başvurusu yok, derleme ve tam test paketiyle doğrulandı):
- Gateway: MAX_UDP, UDP_IDLE_MS, TCP_IDLE_MS, TLS_WAIT_MS, HTTP_WAIT_MS (akış zaman aşımları zaten GwConfig'de).
- SecureForwarder: FIRST_FAMILY_MS (OLD_FIRST_FAMILY_MS kullanılıyor). DnsForwarder: MAX_REPLY_ONE_PACKET, unknownShedCount().
- MobileNet: OLD_SYN_RETRY_MS. Dpi: u24. ArtY2k: winBar. Themes: scaleAlpha, isNightHour. AppAds: modeOf. OdohEngine: targetOf. OdohPaths: anyOkWithin.
- QuicClient: debugStreamCount, lastActivity. AeroArt: aTopStrong, aBotStrong. SoundParts: CONTOUR_NAMES (yerelleştirme Strings üzerinden).
Davranış değişmedi.

Test düzeneği (uygulama değil):
- sizma16/17 honest istemci yeniden iletmiyordu. Geçit gelen kutusu dolunca paketleri kasıtlı atar (istemci yeniden iletir); test istemcisi bunu yapmadığı için sel biter bitmez gönderilen tek veri paketi kayboluyordu ve 15 sn yankı gelmiyordu. Artık gerçek TCP gibi aynı segment yeniden gönderiliyor (echoWithRetx). Teşhis: akış ESTAB, rcvNxt hiç ilerlemedi; geçit tarafında iç hata yok.
- Port sarmalama 60 bin SYN'lik selde dürüst istemcinin portuna geri dönüyordu; pencere 1024–65535 tam aralığa çıkarıldı.

Açık kalan: UDP DNS seli mağdur kaybı (%98 eşiği, ölçümde 1174–1199 arasında). Eşik gevşetilmedi; sınırda bir ölçüm olarak izleniyor.

Tam paket: 13191 kontrol, 0 başarısız. Kaynak sadeleştirme (görev 180) bu sürümde yalnızca ölü kod adımıyla sınırlı; yinelenen yardımcılar ve tek kullanımlık soyutlamalar henüz ele alınmadı.

## oto-koruma 46 — Derin yük turu (sizma17): paket boru hattı, tablo, bellek ve veri düzlemi normal kullanımın ~2000 katı altında

Yeni test grubu: sizma17 (ağ geçidi ve çekirdek yük kampanyası, 36 kontrol). sizma16'daki UDP DNS / SYN / UDP-akış sellerinin DIŞINDAKİ yüzeyler sürüldü.

Bulunan ve kapatılan açık:
- Ortak bellek tavanında (24 MB) adil pay yoktu: penceresini 0 ilan edip okumayan birkaç yüz akış tavanın tamamını kuyruklarında tutup öteki akışları aç bırakabiliyordu. Test: 400 "sıfır pencere" akışı tavanı doldururken dürüst akış, düzeltmeden önce yankısını alamıyor (kırmızı), düzeltmeden sonra alıyor. Artık büyümüş (≥ 16 KB) kuyruklar tavanın yalnızca 3/4'ünü kullanabilir; kalan 1/4 küçük kuyruklara ayrılır.

Saldırıldı, açık çıkmadı (süre, yığın, iş parçacığı, dosya tanıtıcısı, tablo/bellek tavanı ve dürüst trafik ölçülerek):
- 400 bin bozuk/değiştirilmiş paket (rastgele bayt, IHL/sürüm/toplam-uzunluk/parça/protokol/veri-ofseti yalanları, kesik paketler): iç hata sayacı 0, çıkış baytı giriş baytının 2,5 katını aşmadı (yansıtma/amplifikasyon yok).
- Tabloyu 1500 tamamlanmış ve sürekli canlı tutulan bağlantıyla doldurma: tavan aşılmadı, boşta kalanlar tahliye edildi, saldırı bitince dürüst akış ≤ 8 sn'de girdi (15 dk kilitlenme yok).
- 400 istemci hiç ACK vermiyor + sunucu sonsuz veri basıyor: akış başına durağan yeniden iletim hızı ≤ 8 paket/sn (yeniden iletim fırtınası yok), bellek sabit.
- 200 bin IPv4/IPv6 parçası (ilk olmayan parçaya gömülü sahte SYN dahil): hiçbiri akış açmadı, cevap üretilmedi.
- 8 iş parçacıklı süzgeç + önbellek: sürdürülen hız ~800 bin–1 milyon sorgu/sn (normal telefonun ~2000 katı), eşzamanlı yükte süzgeç kararı hiç yanlış çıkmadı.
- Birleşik fırtına (bozuk + UDP + parça aynı anda): ağ geçidi sağlıklı kaldı, iç hata yok, tablolar boşaldı, veri düzlemi toparlandı.

Not: Bu testlerin tümü sandbox'ta yazılım düzeyinde sürülür; gerçek radyo/çekirdek değil. Bazı eşikler (loopback port tükenmesi) sandbox sınırıdır, gerçek telefonu yansıtmaz. Android platform/* kodu bu turda değişmedi; değişiklik GwPackets.kt (bellek tavanı adil payı) çekirdek kodundadır — yerelde derlenemez, GitHub Actions'ta derlenip doğrulanmalı.

## oto-koruma 46 — derin yük turu (sizma16, sizma17): sıfır pencere açlığı düzeltmesi, test düzeneği hataları

Yeni test grubu: sizma17 (7 grup, 38 kontrol): bozuk paket yağmuru, tamamlanmış sessiz bağlantılarla tablo doldurma, bellek tavanı açlığı, sıfır pencereli yeniden iletim fırtınası, parça seli, süzgeç/önbellek verimi (8 iş parçacığı, normalin ~2000 katı), birleşik fırtına.

Uygulama düzeltmesi:
- Ortak bellek tavanı (`ByteQueue.free`): büyüyen kuyruklar tavanın tamamını tutabiliyordu. Sıfır pencere ilan eden birkaç yüz akış tavanı doldurunca, dürüst akışların yazacak yeri kalmıyordu (açlık). Artık büyümüş kuyruklar tavanın en çok 3/4'ünü kullanabilir, kalan 1/4 küçük kuyruklara kalır. Doğrulama: eski formülle sizma17'nin "sıfır pencereli saldırı sürerken dürüst akış çalışır" kontrolü kırılıyor, yenisinde geçiyor.

Test düzeneği düzeltmeleri (uygulama değil):
- sizma16 SYN testi: test sayacı 65535'i geçince paket port alanı taşıyordu, yanıtlar eşleşmeyip düşüyordu ve sonraki gruplar (sizma17) takılıyordu. Port artık 1024–65534 aralığında sarmalanıyor.
- sizma16 fd kontrolü: açık 1500 akış varken tanıtıcı sayısının tabana inmesini bekliyordu (yanlış beklenti). Şimdi açıkken tavanla (2 × akış + pay, sink aynı süreçte olduğu için) sınırlı, sıfırlamadan sonra tabana dönüyor.
- sizma17 sıfır pencere grubu: "loopback tükendi" muafiyeti kaldırıldı. Yerinde düz soket ölçümü (5/5 başarılı) bu açıklamayı çürüttü; kontrol artık gerçek toparlanmayı şart koşuyor.

Açık kalan, bilerek değiştirilmeyen noktalar:
- Fırtına sürerken yeni dürüst bağlantılar reddediliyor (tablo, canlı akışlarla dolu; tasarım gereği). Fırtına bitince toparlanıyor. Kontrol bunu bilgi olarak raporluyor.
- UDP DNS seli, 100 bin sorgu/sn, aynı makinede: mağdur sorguların kaybı %2 sınırında (1175/1199 ≈ %98,0). Eşik gevşetilmedi; ölçüm olarak raporlanıyor. Gerçek telefonda bu hız üretilemez.

Tam paket: 13191 kontrol, 0 başarısız. Android platform kodunda değişiklik yok; ByteQueue çekirdek kodu (JVM testleriyle doğrulandı).

## oto-koruma 45 — Büyük sızma turu (sizma14, sizma15): DNS-over-TCP düşman istemci, CPU/bellek yükseltme saldırıları

Yeni test grupları: sizma14 (TcpDns düşman istemci, 96 kontrol), sizma15 (algoritmik karmaşıklık, 46 kontrol).

Bulunan ve kapatılan açıklar:
- Liste ad temizleyici (`FilterNames.normalize`): baştaki `*.` / `.` öbeklerini her turda dizgiyi kopyalayarak atan döngü karesel süreliydi. 4 MB'a kadar içe aktarılan bir listedeki tek satır (ör. milyon nokta) uygulamayı dakikalarca (saatlere varan) meşgul ederdi (80 bin karakter 0,5 sn; ölçülen: eski kodla sizma15 10 dk içinde bitmedi). Artık tek geçişte atlanıyor: 3 milyon karakterlik üç saldırı satırı 75 ms. Eski davranışla 20 bin rastgele girdide birebir aynı sonuç.
- TcpDns, kör RST: sıra numarası pencere dışı olsa da bağlantıyı siliyordu. RFC 5961'e göre yalnızca tam beklenen sıra numarası RST'si siler; pencere içi ama tam olmayan RST'ye "challenge ACK" verilir.
- TcpDns, sahte SYN: kurulu bağlantıya gelen SYN bağlantıyı sıfırlıyordu; artık challenge ACK verilir, bağlantı sürer.
- TcpDns, FIN sonrası veri: istemci FIN gönderdikten sonra gelen veri arabelleğe işleniyordu; artık yok sayılır.
- Bedeli: eski bağlantıdan kalma kaynak portu yeniden kullanılırsa ilk SYN'e challenge ACK gider, istemci yeniden dener (~1 sn).

Saldırıldı, açık çıkmadı (süre ve doğruluk ölçülerek): 127 etiketli/253 karakterli adlar (süzgeç motoru saf son-ek referansıyla 30 bin adda birebir aynı; 20 bin en-derin sorgu 0,3 sn), 30 adımlı derin-adlı CNAME zinciri ×2000 (63 ms), 40 adımlı zincir kapatılıyor, kendine dönen sıkıştırma işaretçileri, 65000 kayıt iddialı rastgele bozuk cevaplar (60 bin adet, istisna yok), 64 KB cevapta TTL işleme, Public Suffix 127 etiket, hashCode'u çakışan 131 bin önbellek anahtarı (176 ms, bellek/kayıt tavanı tutuyor), TTL uç değerleri, 8 iş parçacıklı önbellek seli, tek satırda 200 bin adlı dnsmasq/hosts satırları (80 MB yığında bile geçiyor), FilterHash dağılımı (600 bin adda çakışma yok, çığ ≈ 24 bit, 1 milyon girişli katmanda yanlış pozitif 0).

Bilinen, kabul edilen sınırlar: FilterHash anahtarsız ve 48 bit; uygulamanın korunan listesi herkese açık olduğundan, saldırgan kendi izleyici adını korunan bir adın özetiyle çakışacak biçimde üretebilir (reklam engelini yalnız kendi alanı için aşar; yeni bir alan adı almak aynı sonucu verir, bu yüzden değiştirilmedi). 254-255 karakterli (RFC dışı) adlar motorca kabul ediliyor, üst sunucu reddeder. TcpDns istemcinin alma penceresini yok sayar, MAX_PENDING üstündeki borulu sorguları sessizce düşürür.

Android `platform/*` kodu bu turda yalnızca DnsVpnService'in `BlockedSites` içe aktarması ve `autoTimer = true` değişti; yerelde derlenemez, GitHub Actions'ta doğrulanmalı.

## oto-koruma 44 — bilinen açıkların kapatılması: TCP yeniden iletimi, şüpheli alan bütçesi, sıfır baytlık UDP yanıtı

- TcpDns (DNS-over-TCP): onaylanmamış cevap ya da FIN için yeniden iletim zamanlayıcısı eklendi. Kayıp segmentte istemci başka paket göndermezse eskiden kurtarma yalnızca istemcinin kendi zaman aşımıyla (saniyeler) oluyordu. Şimdi ilk segment 300 ms'de yeniden gider, süre ikiye katlanır (en çok 4 sn), 6 denemeden sonra RST. Zamanlayıcı iş parçacığı yalnızca bağlantı varken çalışır; yoksa boşta CPU yok. Test: kayıp cevap senaryosu, zaman aşımı/RST, boşta sessizlik (tcp grubu, 10 yeni kontrol). Mutasyonla doğrulandı (yeniden iletim kapatılınca 3 kontrol kırılıyor).
- ZoneQueue (şerit zamanlayıcısı): şüpheli alan sınırı yalnızca alan başına (zoneCap) idi; her biri tek işli çok sayıda şüpheli alan bütün şeritleri doldurabiliyordu. Artık tüm şüpheli alanların toplam eşzamanlı işi de bir bütçeyle (varsayılan zoneCap = 3) sınırlı. Sağlıklı alanlar boşta kalan şeritleri alır. Model karşılaştırması güncellendi. Test: 12 şüpheli alan + 1 sağlıklı alan; bütçe kaldırılınca 11 şüpheli iş verildi, test yakaladı (sizma9).
- Gateway UDP: sunucudan gelen sıfır baytlık datagram düşüyordu (kanal okuması 0/-1 döndürüp boş yanıtla boş kuyruğu ayırt edemiyordu). Artık receive() kullanılıyor. Not: JDK istemci tarafında sıfır baytlık datagram göndermez; bu yön değişmedi. Test: sizma13'e eklendi, eski kodda v4 ve v6 kırılıyor, yenisinde geçiyor.
- Güvenli şerit sınırı 12 ayarlanmadı: gerçek kullanım verisi yok. Bunun yerine sınırın kendisi değil, dağıtılmış sel davranışı (genel bütçe) düzeltildi.
- Sıfır baytlık yanıt veren gerçek sunucular ölçülemedi: sandbox dış DNS'e erişmiyor. Düzeltme sunucudan bağımsız.
- 

## oto-koruma 40 — Daha sofistike sızma turu: IPv6 durum makinesi, yük altında hata yalıtımı, çapraz doğrulama

Yeni test grupları: sizma8 (düşmanca H2 + şerit fırtınası), sizma9 (zamanlayıcı), sizma10/11 (geçit hata yalıtımı, UDP dayanıklılığı), sizma12 (farklı uygulamalarla karşılaştırma), sizma13 (IPv6/IPv4 eşlik).

Düzeltmeler:
- Ağ geçidi: istemcinin FIN'i en son geldiğinde son ACK gönderilmeden akış kapanıyordu (istemci FIN'i yeniden yollayıp RST bekliyordu). Artık kapanıştan önce ACK gider. (sizma13 buldu; mutasyonla doğrulandı.)
- Ağ geçidi: tek paketteki beklenmedik hata artık akışı/geçidi düşürmez (internalError/emit/failSafe, sayaç `internalErrors`).
- DnsForwarder: bölge başına bekleyen sınır (64), alım ve süpürme korumaları. SecureForwarder: bölge farkında zamanlayıcı (ZoneQueue).
- Http2: dolgulu DATA kredisi, CONTINUATION sınırı.

sizma13: bağımsız RFC paket denetçisi (sağlama toplamı, MSS, seçenekler, uzunluklar, durum kuralları; 72 kendi-testi) tüm geçit çıkışını denetler; v4↔v6 aynı davranış (el sıkışma, 300 KB aktarım, yaşam döngüsü, UDP, uzantı başlıkları, DPI planları bayt-bayt, süzgeç bölme noktaları, kaos konuşmaları).

- Ana menü sadeleştirildi: günlük ayarlar (DNS, filtre, bildirim, istatistik, hakkında) üstte; bağlantı ve uygulamalar, sunucu listesi, veri ve deneysel özellikler yalnızca "Gelişmiş ayarları göster" açıkken görünen karta taşındı. Yeni metin anahtarı eklenmedi (dil dosyalarına dokunulmadı).
- DnsVpnService: eksik `BlockedSites` importu eklendi (GitHub APK derlemesi `Unresolved reference` ile düşmüştü; Android kodu burada derlenemediği için CI'da görüldü).

Dürüst sınırlar: Android `platform/*` kodu burada derlenemedi; kum havuzunda gerçek IPv6 yığını yok (v4-eşlemeli adres hileli çerçeve/durum makinesini sınar); TcpDns'de yeniden iletim zamanlayıcısı yok; çok sayıda ayrı bölge seli yine de gecikme yaratır (≤12 güvenli şerit); IPv6/IPv4 karışık uzun-soak henüz yok.

## 1.38.2 oto-koruma 12–16 (ara düzeltmeler, sürüm numarası değişmedi)

- **Reklam engeli (Sıkı):** birinci taraf gibi görünen reklam/izleme alt alan adları ("ads.site.com", "tracking.site.net", "telemetry.", "smetrics." vb.) listelerde olmasa da engellenir. Yalnızca kayıtlı adın önündeki etiketlere bakılır ("ads.com" gibi iki etiketli adlar ve "stats", "click", "push" gibi geniş sözcükler kapsam dışıdır). Kullanıcının izin listesi önce gelir.
- **Süzgeç kendini onarma:** liste dosyaları okunamayıp yedek (listesiz) motor devreye girdiyse engelleme artık sonsuza dek kapalı kalmaz; 3 hızlı denemeden sonra da 5 dakikada bir yeniden denenir.
- **DNS sızıntı kalkanı:** DNS modunda bilinen herkese açık çözümleyici adresleri (8.8.8.8, 1.1.1.1 …) tünele alınır: sabit sunucuya soran uygulamanın düz DNS'i şifreli DNS'e gider, DoH/DoT bağlantıları reddedilir ("DoH koruması" ayarına bağlı).
- **DPI vanası:** DPI atlatma ağdaki TLS el sıkışmalarını bozuyorsa (bağlantılar açılıyor ama hiçbir el sıkışma tamamlanmıyor) yalnızca DPI otomatik kapatılır; Reklam+ ve DNS sürer. 5/15/45/60 dk ile yeniden denenir. Önceki vana yalnızca "hiçbir bağlantı açılmıyor" durumuna bakıyordu.
- **İmzalı yayın APK'sı:** `anahtar-uret.yml` kendi anahtarını üretir, `release.yml` artık imzalı APK da çıkarır (itch.io için). Debug APK herkese açık anahtarla imzalıdır, mağaza dışında dağıtılmamalıdır.
- Güvenlik ve kararlılık: IPv6 uzantılı TCP/53, NAT64/IPv4-eşlenmiş DoH adresleri, TLS saat/sertifika ayrımı, ayar kodu içe aktarma uyarıları, Immune çakışma ve saat geri sarması, HTTP/2 sessiz kopma, QUIC yeniden gönderim, tanılama maskesi, yalnızca-DPI/Reklam+ kipinde kutucuk/widget.

## 1.38.2 (versionCode 59)

**İkinci tur denetim: engelli ağda QUIC beklemesi, akış sınırı, pil, ek sertleştirme**

> Dürüst not: JVM testleriyle (10605 kontrol, 0 başarısız) ve yerel aioquic sunucusuyla sınandı; Android kaynakları ayrıca saplama (stub) kitaplığıyla derlendi. Samsung A34 / Xiaomi 17T'de, gerçek operatörde, gerçek DNS sağlayıcılarında, Gradle ile derlemede DENENMEDİ. Somut bir hata tarifi gelmediği için bu tur da kod taraması: bulunanlar aşağıdadır, bu turda 1.38.1'e göre çok daha az kusur çıktı.

- **UDP'nin engelli olduğu ağda DoQ/DoH3 her bağlanışta ~10 sn bekletiyordu.** QUIC artık yedek yöntem varken tek denemeyle, 2,5 sn'lik yoklamayla denenir; başarısız olursa 10 dk atlanır (ağ değişince sıfırlanır). Yeni sınıf: `QuicBackoff`.
- **QUIC bağlantısında sunucunun akış sınırı dolunca** (yaklaşık 100 sorgu) bağlantı sunucu hatası sayılıyordu; artık bağlantı baştan, sessizce yenilenir.
- **Boşta QUIC bağlantısı saniyede ~66 kez uyanıp pil yiyordu**; boştayken 250 ms'de bir uyanır, havada paket varken eski sıklıkta çalışır (yeniden gönderim zamanlayıcısını bekleyen istek de sürer).
- El sıkışma iletilerinde (TLS) bozuk alan artık beklenmeyen bir istisna değil, kontrollü bağlantı hatasıdır.
- Rastgele girdi (fuzz) testleri: kurulu bağlantıya bozuk TCP segmentleri (ağ geçidi), yetkili ama rastgele QUIC çerçeveleri, rastgele datagramlar, rastgele TLS iletileri.
- Gözden geçirilip değişiklik gerektirmeyenler: manifest ve ağ güvenliği yapılandırması, BootReceiver / ActionReceiver / intent işleme, liste güncelleme ve depolama, DNS önbelleği, CrashLog, CutWatch, UdpDecoy, ağ geçidinin TCP durum makinesi.

*Testler:* 10587 → 10605.

## 1.38.1 (versionCode 58)

**Güvenlik sertleştirmesi (QUIC/TLS, sahte paket, ağ geçidi) ve yeni özelliklerdeki hatalar**

> Dürüst not: JVM testleriyle (10587 kontrol, 0 başarısız) ve yerel aioquic sunucusuyla sınandı. Samsung A34 / Xiaomi 17T'de, gerçek operatörde, gerçek DNS sağlayıcılarında, Gradle ile derlemede DENENMEDİ. "Bozuk" özellikler için somut bir hata tarifi gelmediği için kod baştan okundu; aşağıdakiler bulunanlardır, cihazda görülen bir hata başka olabilir.

*Güvenlik* (ayrıntı: GUVENLIK_INCELEMESI.md, "Ek inceleme 1.38.1")
- **QUIC'te yol üstü saldırgan DoQ/DoH3 cevabını değiştirebilirdi** (herkesçe türetilebilen Initial anahtarıyla sahte STREAM çerçevesi): Initial/Handshake paketlerinde yalnızca izinli çerçeveler kabul edilir, bu anahtarlar zamanında atılır.
- Doğrulanmamış sürüm pazarlığı/Retry bağlantıyı düşüremez (kimlik yansıması, v1 denetimi, Retry bütünlük etiketi).
- Sıra dışı CRYPTO/STREAM tamponları, çerçeve uzunluğu taşması (sonsuz döngü), ACK aralığı CPU yükü sınırlandı; sahte datagram bağlantıyı canlı tutamaz; kısa başlık/sunucu kimliği/eski paket numarası denetimleri.
- Joker sertifika `*.com` eşleşmez; ServerHello sıkıştırma/sürüm denetimi; QUIC sertifika hataları güven hatası sayılır.
- Sahte ClientHello sayfa dosyası tünel kapanınca sıfırlanıp silinir (gerçek SNI'lar diskte kalmaz).

*Hatalar*
- **Ağ geçidi UDP akış sayacı** açılamayan akışlarda eksiye kayıyor, 400 akış sınırını işlevsiz bırakıyordu; TCP akış sayacı çift düşüşe karşı korundu.
- **DoH3**: 126 bayttan uzun yol/yetki değerleri bozuk kodlanıyordu.
- **Bayat QUIC bağlantısı**: sunucunun sessizce attığı boşta bağlantıya yazılan ilk soru cevap süresi dolana dek bekliyordu; 20 sn sessiz ya da kopmuş bağlantı artık yeniden kurulur.
- Zaman aşımına uğrayan QUIC akışı tabloda kalıyordu (sızıntı).

*Testler:* 10565 → 10587 (saldırgan sunucu senaryoları: sahte sürüm pazarlığı/Retry, Initial'da yasak çerçeveler, şişirme ve taşma girdileri; sayaç; bayat bağlantı; uzun QPACK değeri; QUIC güven hatası sayacı).

*Bilinen sınırlar:* 1.38.0'dakiler geçerlidir (Retry/0-RTT/anahtar güncelleme yok; çift paketli Chrome ClientHello'sunda QUIC bölme uygulanmaz). Sahte paket yöntemleri (TCP yöntem 12, UDP/QUIC sahte Initial) düşük TTL'e güvenir.

## 1.38.0 (versionCode 57)

**QUIC: DNS-over-QUIC (DoQ), DNS-over-HTTP/3 (DoH3) ve QUIC Initial paketini DPI'a karşı yeniden kurma**

> Dürüst not: JVM testleriyle (10565 kontrol, 0 başarısız) ve gerçek bir QUIC sunucusuyla (aioquic, yerel döngü) sınandı. Gerçek DNS sağlayıcılarında, Samsung A34 / Xiaomi 17T'de, gerçek operatörde, Gradle ile derlemede DENENMEDİ. Katalogdaki QUIC bayrakları sağlayıcıların belgelerinden alındı, doğrulanmadı.

*Eklenenler*
- **Saf Kotlin QUIC v1 istemcisi** (`QuicClient`, `QuicTls`, `QuicInitial`): TLS 1.3 (x25519, AES-128-GCM; RSA-PSS ve ECDSA imzaları), Initial/Handshake/1-RTT paket ve başlık koruması, ACK, akış birleştirme, akış denetimi, kayıp telafisi (yeniden gönderim), sertifika zinciri + SAN ad denetimi + CertificateVerify + Finished. Yapılmayanlar: Retry, 0-RTT, anahtar güncelleme, bağlantı taşıma.
- **DoQ (RFC 9250)** ve **DoH3** (`Http3Client`, QPACK yalnızca statik tablo): `SecureForwarder` içinde `Proto.DOQ` / `Proto.DOH3`. DNS ayarlarında "QUIC ile DNS'i dene (deneysel)" anahtarı (varsayılan kapalı): açıkken destekleyen sunucuda önce DoQ/DoH3 denenir, UDP engelliyse DoT/DoH'a düşülür. Katalog: AdGuard, Cloudflare, Google, NextDNS, Control D.
- **QUIC Initial yeniden kurma** (Bağlantı ve uygulamalar > "QUIC Initial'ı değiştir"): istemcinin ilk Initial paketi çözülür (anahtarlar yalnızca DCID'den türer), ClientHello CRYPTO çerçeveleri SNI'nın ortasından ikiye bölünüp ters sırada yazılır (paket numarası/boyut aynı), önce düşük TTL'li sahte Initial (SNI iana.org alt alanı) gider. QUIC'i engelleme kapalıyken ve DPI açıkken çalışır.
- **Test düzeneği:** `selftest/quic/` (aioquic sunucusu, sertifika üretici, kayıplı UDP aktarıcı). python3 + aioquic yoksa yalnızca birlikte çalışma testleri atlanır; CI'da sürüm sabitlenerek kurulur. Rastgele paket kaybında (%20) bağlantı ve sorgular sınandı.

*Çapraz doğrulama:* QUIC Initial anahtarları RFC 9001 A.1 değerleriyle, paket biçimi bağımsız bir Python uygulamasıyla (iki yönde) doğrulandı.

*Bilinen sınırlar:* Retry gönderen sunucuya bağlanılamaz (hata ile düşülür); sunucu anahtar güncellemesi yapınca bağlantı yenilenir; DoQ/DoH3 her şerit için ayrı bağlantıdır; Android'de VpnService.protect UDP yuvasında denenmedi; QUIC Initial'da çift paketli (Kyber) ClientHello değiştirilmez (SNI ilk pakette değilse dokunulmaz).

## 1.37.0 (versionCode 56)

**Yeni DPI yöntemi 12: sahte ClientHello (ByeDPI "fake" tekniği, ham yuva olmadan)**

> Dürüst not: yalnızca JVM testleriyle sınandı (10565 kontrol, 0 başarısız). Bu yöntem çekirdeğin davranışına dayanır; gerçek cihazda, gerçek operatörde, Gradle ile derlemede DENENMEDİ. Başarısız olursa planlayıcı yöntemi eler (en son sırada).

*Nasıl çalışır*
- SNI'yı içeren ilk parçanın SNI'sı aynı uzunlukta bir iana.org alt alanıyla değiştirilir (sahte kopya).
- TTL 8'e düşürülür; sahte kopya `Os.sendfile` ile (bir dosya sayfasından, kopyalamadan) yuvaya verilir; DPI görür, sunucuya varmadan ölür. TTL hemen 64'e döner.
- Sayfa GERÇEK baytlarla ezilir. Sunucu hiçbir şey onaylamadığından çekirdek aynı sıra numaralarını yeniden iletir ve bu kez gerçek veri gider; DPI bunu "zaten gördüğüm yeniden iletim" sayabilir.
- Güvenlik: TTL düşürülemezse ya da platform desteklemezse sahte HİÇ gönderilmez, düz bölmeye düşer. Sayfa her durumda (hata dahil) gerçekle ezilir.
- Sayaç: Günlükte "sahte ClientHello N". `platform/FakeSender.kt` (256 sayfalık halka, uygulama önbelleğinde).

*Bilinen riskler (cihazda sınanmadı)*: bazı sürücüler sayfayı kopyalarsa yeniden iletim sahte baytı taşır (bağlantı başarısız olur, yöntem elenir); TTL 8 bazı ağlarda DPI'a ulaşmayabilir ya da sunucuya ulaşabilir; her bağlantıya yeniden iletim süresi (yüzlerce ms) eklenir.

*Testler:* 10431 → 10565 (yöntem 12 bölme, sahte kopya biçimi, kısmi/tam/desteksiz/TTL'siz ağ geçidi senaryoları, plan belleği, rastgele girdi). Rastgele girdi testi başta bir taşma hatası yakaladı, düzeltildi.

## 1.36.0 (versionCode 55)

**Android 17+ için "ECH'ye izin ver" anahtarı (eski Android'de hiç görünmez)**

> Dürüst not: yalnızca JVM testleriyle sınandı (10565 kontrol, 0 başarısız). Android 17 cihazda, Gradle ile derlemede DENENMEDİ.

*Eklenenler*
- **ECH'ye izin ver (☰ > Bağlantı ve uygulamalar):** satır yalnızca cihazın Android sürümü 17 (API 37) ve üstüyse oluşur; 17'den düşükte hiç gösterilmez ve etkisi de yoktur. Açıkken Reklam+ HTTPS/SVCB (ECH yapılandırması) kayıtlarını silmez; Android 17 şifreli SNI'yi kendisi kullanır. Varsayılan kapalı. Bedeli: ECH'li sitede Gateway gerçek SNI'yi göremez, o sitede DPI yöntemleri SNI'ye göre çalışmaz.
- 10 yeni test; 12 dilde yenilikler girişi.

*Yapılmadı (yol haritasında)*: DoQ/DoH3, QUIC Initial bölme, MD5/NDK sahte paket, API 37 sınıflarıyla gerçek ECH erişim sınaması (compileSdk 36; cihaz ve sunucu gerekir).

## 1.35.0 (versionCode 54)

**Araştırmadan çıkan eksiklerin kod karşılığı olanlar: yeni TLS yöntemi, Discord/STUN sahte paketleri, DPI sayaçları günlükte**

> Dürüst not: yalnızca JVM testleriyle sınandı (10565 kontrol, 0 başarısız). Gerçek operatörde, Samsung A34 ve Xiaomi 17T'de, Gradle ile derlemede DENENMEDİ. Araştırma raporu (açık kaynak DPI/DNS/reklam engelleme projeleri) bizim kodu görmeden yazıldığı için önerilerinin bir kısmı zaten vardı; aşağıda hangisi hangisi ayrı yazıldı.

*Eklenenler*
- **TLS yöntemi 11 (kayıt sürüm baytı):** kayıt bölme + ikinci kaydın başlığındaki sürüm baytı (03 01 ↔ 03 03) değişik (ByeDPI `--tlsminor` fikri). Başlık sürümü RFC 8446'ya göre yok sayılır ve el sıkışma özetine girmez. Sıranın EN SONUNDA (katı sunucular reddedebilir; reddederse hedef zaten tükenmiş sayılır). Gerçek bir JSSE sunucusuyla el sıkışma testinden geçti. `Dpi.TLS_PLANS` 12.
- **Discord ses / STUN sahte paketleri (deneysel, varsayılan KAPALI):** ☰ > Bağlantı ve uygulamalar > "Ses/STUN sahte paketi". DPI açıkken Discord "IP keşfi" paketinden (74 bayt, UDP 50000-65535) ve STUN bağlama isteğinden (UDP 3478, 19302-19309) önce 4 rastgele paket, IP TTL=4 ile gider ve sunucuya varmadan ölür (UDP'de TTL gönderim anında okunur, ham soket gerekmez). TTL ayarlanamıyorsa HİÇ gönderilmez. Başka hiçbir UDP paketine dokunulmaz. Hangi TTL'in DPI'a ulaşıp sunucuya ulaşmadığı operatöre göre değişir: ⚠ gerçek ağda doğrulanmadı.
- **DPI sayaçları günlükte:** kesinti, yöntem değişimi, UDP sahte paket, atılan engel sayfası cevabı ve yeniden deneme sayısı değiştikçe günlüğe tek satır ("DPI: kesinti n, ..."). Telefonda "işe yarıyor mu" sorusu için: sayaç hiç artmıyorsa özellik tetiklenmiyor demektir.

*Araştırma önerilerinden ZATEN VAR olanlar (kodda doğrulandı)*
- Ağ türüne/operatöre göre ayrı yöntem belleği (`PlanMemory`, `Gateway.networkChanged`, kalıcı).
- Özel DNS (Private DNS) çakışma denetimi (`strictPrivateDns`, `PrivateDns`).
- İstemci alt ağı (ECS) bilgisi giden sorgularda sıfırlanır (`Packets.kt`).
- İmzalı liste güncellemesi (ECDSA P-256, `ListUpdater`).
- Uygulama bazında kapsam (`AppScope`: hepsi / yalnızca seçilenler / seçilenler hariç).
- HTTPS/SVCB (tür 65) kayıtları: engelli ad ve SVCB hedefi denetimi var; Reklam+ açıkken bilerek verilmez (ECH gerçek adı gizlerdi).
- Yavaş el sıkışma: yeniden deneme süresi ölçülen gecikmeye göre 0,9-3 sn; daha yavaş el sıkışma zaten sıradaki yönteme geçirir. Ayrıca "yavaşlatma" sayacı eklenmedi, çünkü bu yol onu kapsıyor.

*Eklenmeyenler ve nedeni*
- TCP_MD5SIG "sahte paket" (NDK, çekirdek/sandbox izni bilinmiyor): YOLHARITASI.md'de deneysel madde.
- DoQ / DoH3 (saf Kotlin'de QUIC yığını; Türkiye'de DoH'tan az engelli olduğuna kanıt yok), QUIC Initial CRYPTO bölme, yöntem zincirleme (planlayıcı yeniden tasarımı), kendi ECH/DoH erişim testi (Android 17 cihaz gerekir), paralel üst sunucu yarışı (gizlilik bedeli), NRD/DGA/HaGeZi listeleri ve joker biçime geçiş (liste verisi indirme ve lisans doğrulaması gerekir; bu ortamda ağ yok, HaGeZi/OISD lisansı doğrulanmadı, OISD GPL-3.0 olduğu için gömülmemeli).

- Metinler: 12 dilde 2 yeni metin, yeni ilk "Yenilikler" maddesi.
- Testler: 10404 → 10565 kontrol, 0 başarısız (UDP sahte paket: sunucuda 4 sahte + 1 gerçek, TTL 4 sonra 64, ayar kapalı / TTL ayarlanamıyor / parmak izi uymuyor durumları, STUN ayrıştırıcı; yöntem 11 bölme ve kalıcı bellek). Android 35 stub derlemesi temiz (R/BuildConfig zinciri hariç).

## 1.34.0 (versionCode 53)

**Bağlantı kurulduktan sonra kesilen siteleri algılama ve düz DNS'te sahte engel sayfası koruması**

> Dürüst not: Shroudly 2.5.6'nın (açık kaynak, MIT) kaynağını inceledim; aynı yaklaşımları Android'e uyarladım. Bunlar yalnızca JVM testleriyle sınandı (10404 kontrol, 0 başarısız); gerçek operatörde, Samsung A34 ve Xiaomi 17T'de, Gradle ile gerçek derlemede DENENMEDİ. Kesinti algılama sezgiseldir: yanlış alarm ihtimalini azaltmak için tek belirtide yöntem değiştirmez.

*Kesinti algılama (yeni: `core/CutWatch.kt`, `Dpi.Planner.cut`)*
- Bazı filtreler (İran, Rusya'nın 16 KB dondurması) el sıkışmayı geçirip veriyi keser; tarayıcıda boş sayfa olur, el sıkışma denetimi ise "başarı" görürdü. Artık bölme uygulanan TLS bağlantılarında sunucunun TLS kayıtları izlenir (yalnızca 5 baytlık başlıklar; içerik saklanmaz), ilk 64 KB boyunca:
  - **susma:** sunucu bir kaydın ORTASINDA 8 sn susar (puan 2),
  - **sıfırlama:** bekleyen iş varken bağlantı "Connection reset" ile kopar (puan 1); iş bittikten sonraki sıfırlama (canlı tutma kapanışı) sayılmaz,
  - **cevapsız:** en az 300 baytlık gerçek bir istek 15 sn cevapsız kalır (puan 1). Küçük yazmalar (el sıkışmanın istemci bitişi, tarayıcının önceden açtığı boşta bağlantılar) cevap beklemez, yoksa sahte alarm olurdu.
- 10 dk içinde toplam puan 3'e ulaşırsa o hedefin öğrenilmiş yöntemi SIRADAKİNE geçer; sonraki bağlantı onu dener. Sırada yöntem kalmadıysa hiçbir şey değişmez. Bellek 256 hedefle sınırlı. Mevcut bağlantıya dokunulmaz (kesilmez).
- `GwStats.cuts` ve `cutSwitched` sayar.

*Engel sayfası adresleri (yeni: `core/BlockPages.kt`)*
- Düz DNS (UDP/53) cevabının cevap bölümünde bilinen bir engel sayfası/sahte havuz adresi (Türkiye 195.175.254.2 ve 193.192.98.x, Çin'in enjekte havuzu ve toplam 21 ülkenin adresleri, 170 adres) varsa cevap atılır, bekleyen sorgu açık kalır; gerçek cevap (yarışı kaybeden asıl sunucu ya da yeniden deneme) gelirse o kabul edilir. Sahte cevap önbelleğe girmez ve istemciye verilmez. `Stats.blockPages` sayar.
- Bilerek listede YOK: ortak bulut adresleri (yarın gerçek siteye atanabilir; Shroudly'nin listesindeki tek Hetzner adresi de çıkarıldı) ve DNS süzme hizmetlerinin (AdGuard, OpenDNS, CleanBrowsing…) sayfaları: kullanıcı o hizmeti seçtiyse engelli saymak doğrudur.
- Şifreli DNS'te (DoT/DoH/ODoH) bakılmaz: cevabı ağ değiştiremez.
- Liste OONI verisine dayanır ve eskiyebilir; gerçek bir siteye ait bir adres listede kalırsa o site düz DNS'te açılmaz. Kaynak ve lisans: `app/src/main/assets/filter/KAYNAKLAR.txt` (Shroudly, MIT).

*Neden bunlar, neden başka şeyler değil*
- Shroudly'nin Linux'ta TCP_MD5SIG ile "sahte paket" hilesi ve ham paket gerektiren yöntemleri (bozuk sağlama toplamı, sahte RST'yi düşürme, gerçek `split-seqovl`) alınmadı: Android'de uygulama ham paket yazamaz, TCP_MD5SIG için yerel kod (NDK) gerekir ve çekirdek/sandbox izni bilinmiyor.
- Bizde zaten olanlar: TLS kayıt bölme, TTL=1 ile sırasız gönderim, OOB, `hOsT`, QUIC düşürme.

- Metinler: "Yenilikler" listesine 12 dilde yeni ilk madde.
- Testler: 10340 → 10404 kontrol, 0 başarısız (yeni `yeni134` grubu: izleyici, CutWatch, Planner.cut, BlockPages, düz DNS iletici ile yarış; gerçek soketli ağ geçidi testleri: kayıt ortasında susma, sıfırlama, cevapsız istek, sağlıklı bağlantıda alarm yok). Android 35 stub derlemesi: yalnızca üretilen R/BuildConfig zinciri.

## 1.33.0 (versionCode 52)

**Güvenlik sertleştirmesi, hata taraması ve 69 arayüz iyileştirmesi (Kişiselleştirme + diğer sekmeler)**

> Dürüst not: her şey yalnızca JVM testleriyle ve masaüstü önizlemesiyle sınandı (10340 kontrol, 0 başarısız). Gradle ile gerçek APK derlemesi ve gerçek cihaz (Samsung A34, Xiaomi 17T vb.) denemesi YAPILMADI. Düzeltme: sürüm derlemesinde küçültme (`isMinifyEnabled`, `isShrinkResources`, proguard) zaten açık; önceki "küçültme görünmüyor" ve Google Play özelliklerinin MB tahmini yanlış/kabaydı.

*Güvenlik (69'a dahil değil)*
- Yeni `core/TextSafe.kt`: dışarıdan gelen metinlerden (cihaz bilgisi, getprop, tanılama raporu) denetim, çift yönlü (bidi), sıfır genişlikli ve gizli karakterler temizlenir; boşluklar birleştirilir, uzunluk kısıtlanır, vekil çiftleri bölünmez.
- `DeviceProfiler.sanitize`: alan uzunlukları, en çok 64 özellik, sayısal alanlar (SDK, RAM, bellek, Hz) makul aralığa kırpılır. `parseProp` 400 karakterden uzun satırı reddeder, anahtar/değeri temizler.
- `DiagReport` gizli karakter temizliği ortak `TextSafe`'e bağlandı (tek doğru kaynak).
- Yeni `pzClosed` ayarı: bilinmeyen/bozuk değer okunurken temizlenir (`PzFolds.sanitize`), yerel anahtardır, dışa aktarılan dosyaya girmez.
- Ayar dosyası kodlayıcısına rastgele bozuk girdi taraması (`fuzz2`) ve yeni `audit` grubu varsayılan tam takıma eklendi; hata bulunmadı.

*Gerçek hatalar (düzeltildi)*
- Titreşimi olmayan cihazda "Titreşim gücü" satırı gösteriliyordu.
- Kaydırıcının erişilebilirlik adımı kayan noktadan kayıyordu; artık %5 ızgarasına oturur.
- Kişiselleştirme sayfasının koşullu satır imzası Int bit maskesiydi (31'den fazla koşulda taşardı); `Conds` sınıfına geçildi.
- Büyük yazı boyutunda segment, kaydırıcı, anahtar notu, bölüm başlığı ve üst başlık metinleri kesiliyordu.
- Her karede Bildirim izni sorgusu (binder çağrısı) yapılıyordu; önbelleğe alındı.
- İlk karede koşullu satırlar yanlış görünüp sonra zıplıyordu.
- `PzFolds.isClosed` her karede bellek ayırıyordu (kare başı 96 B sınırı).

*69 iyileştirme*

Ortak bileşenler (1–21)
1. Segment seçici dokunma yüksekliği 44 dp.
2. Çok seçenekli segment birden çok satıra bölünür.
3. Segment etiketleri sığacak şekilde küçülür.
4. Kaydırıcı başlığı/değeri sığmazsa kısaltılır.
5. Kaydırıcı erişilebilirlik adımı %5.
6. Kaydırıcı bırakılınca bir "onRelease" kancası çalışır.
7. Segmentte yalnızca seçim değişince çalışan "after" kancası.
8. Anahtar notları büyük yazıda 6 satıra kadar.
9. Bilgi satırına uzun basınca "başlık: değer" kopyalanır.
10. Bilgi satırı erişilebilirlikte ham değerin tamamını okur.
11. Bölüm başlığı 2 satıra kadar sarar.
12. Üst başlık büyük yazıda %62'ye kadar küçülür.
13. Katlanabilir başlık kapalıyken sağda özet gösterir.
14. Katlanabilir başlık 2 satıra sarar.
15. Katlanabilir başlık erişilebilirlikte açık/kapalı değeri ve uzun basma eylemi bildirir.
16. Başlığa uzun basınca tüm bölümler açılır/kapanır (bildirimle).
17. Önizlemeye dokununca hazır görünümler açılır.
18. Önizlemede ok işareti.
19. Önizleme erişilebilirlikte "düğme" olarak okunur.
20. Hareket kapalıyken önizleme küresi durağandır.
21. Düşük güç modunda önizlemede rozet; `Conds` yardımcısı (koşullu görünürlük, bellek ayırmaz).

Kişiselleştirme (22–36)
22. Kapalı/açık bölümler hatırlanır.
23. Kayıt doğrulanır ve dışa aktarılmaz.
24. Açılan bölüm görünür alana kaydırılır.
25. Yeni hazır görünüm: Pil dostu.
26. Yeni hazır görünüm: Okunaklı (yazıyı küçültmez).
27. 5 hazır görünüm adı ve notu 12 dilde.
28. Elle değiştirilmişse "Özel ayar" yazar.
29–35. Yedi bölümün kapalıyken özeti: tema, şekil, arka plan, his, erişilebilirlik (n/4), cihaz, dil.
36. İlk karede doğru satırlar görünür.

Diğer sekmeler (37–69)
37–43. Ana menü: tema adı, ses paketi, uygulama kapsamı, istatistik sayısı, sürüm, bildirim izni durumu; değişince menü kendini günceller.
44. DNS: "Sıkı şifreleme" yalnızca Otomatik şifrelemede.
45. DNS: "Önbelleği temizle" yalnızca önbellek açıkken.
46–48. Filtre: bellek, son, geçen satırları yalnızca filtre açıkken.
49. Bildirimler: izin engelliyse uyarı kartı en üstte.
50. İzin sorgusu önbelleğe alındı.
51. Listeler: "Şifrelemeyi ölç" yalnızca otomatik ölçümde.
52–56. İstatistik: kazanılan süre, oturumlar, sonuçları paylaş, istatistikleri sıfırla, haftalık grafik yalnızca veri varken.
57. Geçmişi temizle onay ister.
58. Ses kapalıyken ayrıntılar gizlenir.
59. Sessiz saat aralığı yalnızca sessiz saat açıkken.
60. Animasyon kapalıyken animasyon satırları gizlenir, yerine açıklama.
61. Titreşimsiz cihazda titreşim gücü yok.
62. Titreşim gücü yalnızca titreşim açıkken.
63. Boş kart oluşmaz.
64. Ses çıkışı değişince önizleme çalar.
65. Titreşim gücü değişince önizleme titrer.
66. Ses seviyesi bırakılınca örnek çalar.
67. Hazır görünüm penceresinde açıklama alt notu.
68. Uygulanan görünümün adı bildirimde yazar.
69. "Geçmişi temizle" yalnızca temizlenecek veri varken.

- Metinler: 12 dilde 6 yeni metin, "Yenilikler" listesine yeni ilk madde.
- Testler: 8161 → 10340 kontrol, 0 başarısız (yeni `yeni69` grubu, yerleşim denetimine 5 durum). Android 35 stub derlemesi: yalnızca üretilen R/BuildConfig çözülemedi, bunların zincirleme hataları dışında yeni hata yok.

## 1.32.0 (versionCode 51)

**Daha güçlü DPI, cihazı tanıyan uyum katmanı ve baştan düzenlenen Kişiselleştirme sayfası**

> Dürüst not: DPI ve cihaz tanıma yalnızca JVM benzetimiyle ve birim testleriyle sınandı. Gerçek operatörde DPI sonucu ve ROM'ların sistem özelliği adları (aşağıda) gerçek cihazda doğrulanmadı; tanıma okunamazsa uygulama üretici bilgisine düşer ve hiçbir şey bozulmaz.

*DPI atlatma*
- **Üç yeni TLS yöntemi (toplam 11):** 8 = alan adının SON noktasında kayıt bölme (".com" ya da tüm adı arayan kurallar ilk kayıtta eşleşmez); 9 = gecikmeli TCP bölme; 10 = gecikmeli kayıt bölme. Gecikmeli yöntemlerde ikinci parça 60 ms sonra gider (kısa ömürlü yeniden birleştirme belleği olan DPI ilk parçayı unutur); yalnızca öbürleri işe yaramazsa denenir. Yeni sıra: 1, 0, 5, 3, 2, 6, 8, 7, 4, 9, 10.
- **Yeni HTTP yöntemi (toplam 8):** Host DEĞERİNİN ortasında gecikmeli bölme.
- **Tükenen hedef belleği:** tüm yöntemleri başarısız olan bir hedef 45 sn boyunca yeniden yöntem gezilmeden doğrudan geçirilir (her bağlantıda 11 yöntem denemek kullanıcıyı bekletiyordu). `GwStats.exhaustSkipped` sayar.
- **Ağ geçidi:** parçalara gecikme eklenebilir (bağlantı kendi zamanlayıcısıyla uyanır, seçici döngüsü bloke olmaz).
- **Benzetim sonucu (kafes modeli, gerçek ağ garantisi DEĞİL):** TLS'te ilk denemede başarı %20 → %94, ortalama gecikme 2211 → 176 ms; HTTP'de %25 → %96, 3321 → 96 ms.

*Cihaz tanıma (yeni: `core/DeviceProfile.kt`, `platform/DeviceProbe.kt`)*
- Telefonu üreticiye göre ve SİSTEMİNE göre tanır: One UI, HyperOS/MIUI, HarmonyOS/EMUI, MagicOS, ColorOS/realme UI/OxygenOS, Funtouch/OriginOS, HiOS/XOS/itel OS, Nothing OS, Hello UX, Xperia, ZTE/nubia/RedMagic, Flyme, ZenUI/ROG UI, Casper, General Mobile, Reeder, Pixel ve düz Android.
- **Özel ROM'lar** (LineageOS, GrapheneOS, CalyxOS, /e/OS, crDroid, PixelExperience, Evolution X, RisingOS ve bilinmeyen test-keys derlemeleri) donanım üreticisinden ÖNCE tanınır: Xiaomi donanımında LineageOS "agresif Xiaomi" sayılmaz, kapatma riski düşük, sıkı pil rehberi gösterilmez.
- Bellek sınıfı (düşük/orta/yüksek; satış adındaki RAM'den ~%10 az bildirilen değere göre), uygulama kapatılma riski (düşük/orta/yüksek) ve cihaza göre öneriler (Samsung "uyuyan uygulamalar", Xiaomi/Honor/Huawei otomatik başlatma, düşük RAM, özel ROM).
- **Kendini ayarlar:** düşük sınıf cihazda "Tam" animasyon etkin olarak "Az"a iner (kullanıcının seçimi DEĞİŞMEZ, kapatılabilir: "Cihaza göre ayarla"). Kabarcık miktarı da buna uyar.
- Xiaomi/HyperOS için uygulamaya özel PowerKeeper pil ekranı eklendi; Huawei güç yöneticisi ekranı eklendi.
- Getprop yalnız izin verilen ro./hw_sc. adlarını okur (seri no, IMEI, MAC yok), arka planda, en düşük öncelikte, bir kez, en çok 3 sn / 512 KB; ağ kullanmaz. Tanılama raporuna "Sistem:" satırı eklendi.

*Kişiselleştirme sayfası (24 iyileştirme)*
1. Canlı önizleme: seçili tema/stil/küre şekliyle dönen küre, tema adı, stil ve hazır görünüm adı.
2. Önizlemede cihaza göre sadeleştirme etiketi.
3. Yedi katlanabilir bölüm (başlığa dokun: açılır/kapanır; ok döner; erişilebilirlikte açık/kapalı okunur).
4. Tema renkleri Özel / Açık / Koyu olarak gruplu.
5. Açık/koyu tema ve zamanlama satırları yalnızca "Otomatik" tema seçiliyken.
6. Gece saatleri satırı yalnızca zamanlama açıkken.
7. Arka plan karartma ve bulanıklık yalnızca fotoğraf varken.
8. Cam şeffaflığı kaydırıcısı yüksek kontrastta gizli (zaten opak).
9. "Hazır görünüm": Sade / Dengeli / Canlı (cam + hareket + hız); geçerli olan satırda yazar.
10. Hazır görünüm uygulanınca "Geri al".
11. "Görünümü sıfırla" satırı yalnızca varsayılandan farklı bir ayar varken, kaçının farklı olduğunu yazar.
12. Sıfırlama yalnızca görünümü etkiler (DNS, filtre, favoriler, fotoğraf, simge korunur) ve geri alınır.
13. Yazı boyutunda seçili yüzde altta yazılır.
14. Animasyon sırası Yok · Az · Tam (her dilde); ayrı kabarcık satırı yok.
15. Hareket satırında düşük güç / cihaza göre sadeleştirme notu.
16. Titreşim motoru olmayan cihazda "Titreşim" satırı gizli.
17. "Bu cihaz" bölümü: cihaz adı, sistem ve sürüm, sınıf, kapatılma riski, uygulanan otomatik ayar, üreticiye özel öneriler.
18. Riskli sistemlerde "Pil ayarlarını aç" düğmesi.
19. "Cihaza göre ayarla" anahtarı.
20. Satır değerleri ekran okuyucuya okunur (NavRow değeri).
21. "Kendi stilim" ve "Temaya göre şekil" satırlarında dolu/toplam sayacı.
22. Dil ve simge nadir değişen ayar olarak sayfa sonuna alındı.
23. Önizleme yazı boyutuna uyar, uzun adlar kısaltılır; kare başına bellek ayırmaz (test).
24. Bölüm durumu sayfa açıkken hatırlanır; yerleşim yalnızca gerçekten değişince yenilenir.

*Genel*
- 12 dilde 30 yeni metin ve yeni "Neler yeni" maddesi.
- Testler: 7970 → 8161 kontrol (cihaz tanıma tabloları, ayar etkileri, Kişiselleştirme sayfası, 12 dil).

## 1.31.0 (versionCode 50)

**Güvenlik katmanları, filtre, DPI, kriptografi ve arayüz iyileştirmeleri**

*Şifreli DNS tüneli*
- **Bayat cevap (RFC 8767, "serve-stale"):** üst sunucu yanıt vermezse ya da son hatası son başarısından yeniyse, süresi dolmuş OLUMLU cevap (en çok 6 saat eski, TTL 30 sn) hemen verilir; gerçek sorgu arkada çalışıp önbelleği tazeler. Düz UDP'de 1,8 sn sonra, DoT/DoH/ODoH'ta üst sunucu "sorunlu" sayılınca. Olumsuz (NXDOMAIN/boş) cevaplar asla bayat verilmez. İstemci artık sunucu kesintisinde saniyelerce zaman aşımı beklemez. `Stats.stale` bayat verilen cevapları sayar.

*Kriptografi*
- **El sıkışma sonrası TLS politikası (`TlsPolicy`):** pazarlık edilen sürüm ve şifre takımı denetlenir (DoT, DoH, ODoH, ODoH yapılandırma alımı, sunucu sınaması). Yalnızca TLS 1.3/1.2; TLS 1.3'te yalnızca AES/ChaCha20; TLS 1.2'de ileri gizlilik (ECDHE/DHE) şart. Statik RSA/DH/ECDH, NULL, anonim, EXPORT, RC4, DES/3DES, RC2, IDEA, SEED, MD5 reddedilir; ret sertifika hatası gibi "güven hatası" sayılır (yedek sunucuya geçilir, `tlsFailures` artar). Gerçek sağlayıcıları etkilemez; savunma derinliğidir.

*DPI atlatma*
- **Yerel adreslere DPI uygulanmaz** (modem, yazıcı, 10.x/192.168.x/100.64/10, IPv6 yerel): eskiden bölme bu hedeflere de uygulanıp yöntem oylarını ve öğrenilen belleği bozuyordu. `GwConfig.dpiOnLocal` ile (yalnız testlerde) açılabilir.
- **Sahte cevap tanıma:** ilk TLS cevabı TLS kaydı (0x16/0x15) değilse (DPI'ın enjekte ettiği düz metin/yönlendirme) bu cevap kabul edilmez, bir sonraki yönteme geçilir ve öğrenilmez; son yöntemde olduğu gibi iletilir. `GwStats.injected` sayar.
- **Güvenli ilk yöntem:** yeniden denenemeyecek uçuşlarda (ilk veri birden çok parça) artık "cesur" yöntem değil, öğrenilmiş ya da en güvenli ilk yöntem seçilir.

*Reklam engelleme ve filtre (kendi liste içe aktarma)*
- **AdBlock istisnaları:** `@@||alan^` (zararsız seçeneklerle) okunur; ad ya da üst alan adı istisnaysa listeden çıkarılır (etiket sınırında: `example.com` istisnası `notexample.com`'u çıkarmaz).
- **Zararsız seçenekler kabul:** `$important`, `$third-party`, `$3p`, `$all` (eskiden bütün `$` kuralları atılıyordu). Kısıtlayıcı seçenekler (`$script`, `$image`…) alan adı düzeyinde anlamlandırılamadığından yine atılır.
- **Yeni biçimler:** dnsmasq (`address=/ad/0.0.0.0`, `server=/ad/`, `local=/ad/`), Unbound (`local-zone: "ad" always_nxdomain|always_null|…`), RPZ (`ad CNAME .`).
- **Ortak son ek koruması:** `com.tr`, `co.uk`, `*.ck` gibi ICANN son ekleri (Public Suffix List; GitHub.io/blogspot gibi özel bölüm adları hariç) ne içe aktarmada ne elle engel/izin listesine alınır: tek kural bütün siteleri kapatırdı.

*Arayüz (18 iyileştirme)*
1. Eylem satırlarında radyo yerine eylem simgesi (izin ver ✓, engelle ⃠, kaldır ✕, ekle +, kopyala).
2. "Son engellenenler"de sağda kaç kez engellendiği (12×).
3. "Son izin verilenler"de aynı sayaç; reklama benzeyenler sıklığa göre sıralı.
4. Erişilebilirlik: eylem satırları artık "seçili değil" demez; sayaç okunur.
5. İzin/engel listeleri aynı sitenin alt alanları yan yana olacak biçimde sıralı.
6. "Ekle…" satırında + simgesi ve doluluk (ör. 12/200).
7. Uzun alan adları baştan kısalır ("…reklam-sunucusu.example.com"): önemli olan sondaki kayıtlı alan adı görünür.
8. Filtre sayfasında "Site neden açılmıyor?" kısayolu (eskiden yalnız DNS sayfasındaydı).
9. Menüde Engelleme satırı düzey + toplam engel ("Orta · 1,2 bin").
10. İstatistiklerde engellenen sayısı toplam sorgudaki payıyla ("300 · %15").
11. Ortak son ek için ayrı ve açıklayıcı uyarı (eskiden "geçerli ad yazın" deniyordu).
12. Engelleme/izin verme tek dokunuşla GERİ ALINIR (iki liste de eski haline döner).
13. Toplu "şüphelilerin hepsini engelle" de geri alınır.
14. Kendi liste içe aktarması geri alınır.
15. İçe aktarma bildirimi istisna yüzünden çıkarılan ad sayısını söyler.
16. İçe aktarma açıklaması yeni biçimleri (AdBlock @@, dnsmasq, Unbound, RPZ) sayar (12 dil).
17. Son engellenen/geçen listelerinde "Kopyala" satırı (adları satır satır panoya).
18. Seçenek satırındaki açıklama sağdaki rozete çarpmaz (genişlik rozete göre ayrılır).
- 12 dilde 3 yeni metin (ortak son ek uyarısı, istisna notu, içe aktarma açıklaması).

*Araçlar*
- Önizleme betiğinde (`UiPreview`) "stylepick" artık Kişiselleştirme sayfasından açılır; `filter` önizlemeleri sayaçları ve geçenler panelini de üretir.
- Testler: 7970 kontrol, 0 başarısız (Kotlin 2.4.21, JDK 25); `core/ui/platform` Android 35 saplamalarıyla da derlendi. Gerçek Gradle/AGP derlemesi ve cihaz davranışı (DPI'ın gerçek operatörde, serve-stale'in gerçek ağda) bu ortamda DOĞRULANAMADI; APK'yı GitHub Actions derlesin.

## 1.30.1 (versionCode 49)

**Eksik ve hata taraması (küçük düzeltmeler + araç güncellemeleri)**
- **Duraklatma bitince bağlantı:** "duraklat" süresi dolup alarm tetiklendiğinde yeniden bağlanma denemeleri tükenirse, ağ geri geldiğinde bağlantı kendiliğinden kurulmuyordu (`userWanted` bayrağı açılmıyordu). Bildirimden "devam et" yolundaki davranışla aynı hâle getirildi.
- **Rastgele kaynak portu aralığı:** TCP DNS için seçilen kaynak portu 1000–65000 aralığının son değerini (65000) hiç üretmiyordu; aralık artık tam (`PORT_SPAN`).
- **Araçlar:** Gradle 9.8.1, Kotlin 2.4.21, `actions/setup-python@v7`, `gitleaks/gitleaks-action@v3`. Üç iş akışı (apk, release, security) aynı Gradle sürümünü kullanıyor.
- **Yeni "Testler" iş akışı:** `selftest/` altındaki JVM testlerini (7793 kontrol) GitHub'da çalıştırır; Kotlin derleyicisini JetBrains'in resmî yayınından indirip SHA-256 ile doğrular. Telefondan Actions → Testler ile görülür; bir kontrol başarısızsa kırmızı olur. APK derlemesi testleri çalıştırmaz, bu iş akışı o boşluğu kapatır.
- **Belgeler:** README, OKUBENI, INCELEME'deki test sayısı, Gradle ve Kotlin sürümleri güncellendi; manifestteki "altı takma ad" yorumu "sekiz" olarak düzeltildi; `RegressionTests.kt` içindeki dört eski "AÇIK" çıktı satırı güncel duruma getirildi.
- **Not (davranış değişmedi):** tünel açıkken tutulan `PARTIAL_WAKE_LOCK`, "ekran kapalıyken hiçbir şey dönmez" anlatımıyla ve düşük arka plan kaynağı hedefiyle çelişir; Play'in "aşırı kısmi wake lock" ölçütüne de takılabilir. Gerçek cihazda pil ölçümüyle ele alınmalı.
- Testler: 7793 kontrol, 0 başarısız. Gerçek Gradle/AGP derlemesi ve cihaz davranışı bu ortamda doğrulanamadı; APK'yı GitHub Actions derlesin.


## 1.30.0 (versionCode 48)

**Geniş güvenlik geçişi: şifreli DNS, ODoH, kriptografi, ağ geçidi (ayrıntı: GUVENLIK_INCELEMESI.md, "Ek inceleme 1.30.0")**
- **HTTP çerçeveleme (DoH, ODoH, yapılandırma alımı):** tek ortak kural kümesi (`HttpRules`). Katlanmış başlık, boşluklu başlık adı, "gzip, chunked" gibi çözülemeyen aktarım kodlamaları, ikinci Transfer-Encoding ve parça sonunda CRLF olmayan cevaplar reddedilir; 100/103 ara cevapları atlanır (en çok 4); durum satırı tam 3 basamak olmalı.
- **ODoH:** her sorgu tek kullanımlık (aynı cevap ikinci kez açılamaz); cevap anahtarı, nonce, ara anahtar, dışa aktarılan sır ve sorgunun düz metni başarıda da hatada da bellekten silinir.
- **HPKE/HKDF:** ara sırlar (paylaşılan sır, anahtar çizelgesi sırrı, KEM ara anahtarı, HKDF blokları) kullanıldıktan hemen sonra silinir. RFC vektörleri ve çapraz doğrulama aynen geçiyor.
- **Düz DNS:** cevap, sorunun gönderildiği soketten (aynı kaynak portundan) gelmek zorunda; sahte cevap gönderen biri artık iki porttan herhangi birini tutturmakla yetinemez.
- **Reklam+:** mutlak biçimli HTTP isteği (`GET http://reklam.example/ …` + izinli görünen Host) ve CONNECT hedefi de denetlenir; "Host: izinli.com" yazarak engel atlatılamaz.
- **Ağ geçidi belleği:** tüm TCP akışlarının kuyruklarına ortak 24 MB tavan. Önceden 1500 bağlantı × 224 KB ≈ 330 MB'a kadar büyüyebiliyordu; okumayan bir uygulama servisi bellek yetersizliğinden öldürebilirdi. Tavan dolunca TCP geri basıncı devreye girer, boşalınca duran akışlar kendiliğinden sürer.
- **Kilitlenme düzeltmesi:** istemci penceresi dolduğunda sunucudan gelen veri istemciye gönderilmeden bekleyebiliyordu (iki yön birbirini bekliyordu). Artık her durumda akıtılır; zamanlayıcı da bekleyen veriyi yoklar.
- **Liste güncelleme:** manifestte ikinci sürüm satırı ve rakam dışı sürüm reddedilir; gömülü anahtar yalnızca P-256 olabilir.

- Testler: 7594 kontrol, 0 başarısız (yeni: HTTP kuralları, ODoH tek kullanım/silme, yanlış soketten cevap, mutlak biçim atlatması uçtan uca, ortak bellek tavanı uçtan uca). Android tarafı bu sürümde değişmedi.

**Reklam engelleme güçlendirmesi**
- **Yeni listeler (Basit):** GoodbyeAds (mobil uygulama reklamları, MIT) ve turk-adlist (Türkçe haber/alışveriş sitelerinin reklam sunucuları, CC BY-SA 3.0). Türkçe sitelerin reklam sunucularında kapsam %81'den %98'e çıktı; Basit katman 360 binden 506 bin ada çıktı. Tüm listeler bugünkü sürümleriyle yeniden derlendi.
- **Yeni liste (Orta):** AdGuard CNAME gizli izleyicileri (MIT): birinci taraf gibi görünen izleyici alt alan adları.
- **Bozulma koruması:** liste derlenirken siteleri/uygulamaları bozan girdiler (AliExpress görselleri, JW Player videoları, TRT oynatıcısının bölge denetimi, giriş servisleri, kısa bağlantılar...) çıkarılır; popüler alan adları ayrıca bağımsız bir listede yoksa yalnızca Sıkı'ya girer.
- **Bildirim düzeltmesi:** eski Basit liste `fcm.googleapis.com` adını engelliyordu (anlık bildirim altyapısı); bazı uygulamaların bildirimleri gecikebilir ya da gelmeyebilirdi. FCM, Firebase kurulum kimliği ve OneSignal artık hiçbir seviyede engellenmez.
- **Son izin verilenler:** Engelleme sayfasında yeni liste. Reklam hâlâ görünüyorsa süzgeçten geçen son 60 adı görüp kaçan reklam sunucusunu tek dokunuşla engelleyebilirsin. Yalnızca bellekte tutulur ("Geçmişi tut" kapalıyken hiç tutulmaz). 12 dilde.
- **Reklam+ ve QUIC:** Reklam+ açıkken QUIC (UDP/443) da düşürülür. QUIC'te site adı şifreli olduğundan QUIC kullanan reklam sunucuları ve uygulamalar Reklam+'ı atlıyordu; artık TCP/TLS'e dönüp adları görünür oluyor.
- **Yabancı siteler, açılır pencere ve yönlendirmeler:** EasyList reklam sunucuları ve EasyList açılır pencere/yönlendirme sunucuları (yalnızca bütün alan adını engelleyen kurallar; CC BY-SA 3.0) Basit'e, EasyPrivacy izleyici sunucuları Orta'ya eklendi. Genel karşılaştırma listesinde (HaGeZi Multi Normal, yalnızca ölçüt, pakete girmez) Basit kapsamı %54'ten %64'e çıktı; bilinen açılır pencere ağlarında %96.
- **Tarayıcının DNS atlatmasını engelle (yeni ayar, varsayılan açık):** tarayıcı ya da uygulama kendi şifreli DNS'ini (Chrome "Güvenli DNS", uygulama içi DoH) kullanırsa sorgular süzgece hiç gelmez, reklamlar ve açılır pencereler geçerdi. Engelleme açıkken bilinen şifreli DNS sağlayıcılarının adları engellenir; tarayıcı sistem DNS'ine döner. Chrome'da "Güvenli DNS" belirli bir sağlayıcıya ayarlıysa sayfa açılmayabilir: o ayar kapatılmalı ya da bu ayar kapatılmalı (notta yazıyor). 12 dilde.
- **Her gün değişen reklam adları:**
  - *Günlük liste güncellemesi:* GitHub her gün listeleri yeniden üretip imzalar; uygulama Wi-Fi'de 12 saatte bir, mobil veride 3 günde bir denetler. Açık anahtar ve yayın adresi artık koddan değil derleme ortamından (GitHub gizli değeri `LIST_PUBLIC_KEY`) gelir; kurulum 2 gizli değer + 1 tıklama (tools/yayin/README.md). Proje zip olarak yüklenmiş depoda da çalışır.
  - *Şüpheli ad işaretleme:* "Son izin verilenler" listesinde reklam/yönlendirme sunucusuna benzeyen adlar (reklam sözcükleri, rastgele onaltılık ya da harf-rakam dizileri, riskli uzantılar) başa alınır ve "Reklama benziyor" diye işaretlenir; "Şüphelilerin hepsini engelle" tek dokunuşla hepsini kendi engel listesine ekler. Yalnızca öne çıkarır, kendiliğinden engellemez (en popüler 10 bin sitenin ~%0,5'i işaretlenir; çoğu zaten reklam/bahis adı).
  - *Sıkı seviyede riskli uzantılar:* yaygın sitelerde neredeyse hiç görülmeyen, dönen reklam adlarında sık kullanılan uzantılar (.cfd, .cyou, .icu, .sbs, .rest, .quest, .buzz…) bütünüyle engellenir. EasyList reklam sunucularının ~%11'i bu uzantılarda. İzin listesi önce gelir. Seviye notu 12 dilde güncellendi.
  - *Kendi adresinden reklam veren siteler:* reklam ayrı bir alt alan adındaysa (ads.site.com) yukarıdaki listeden engellenebilir; sayfa ile aynı adresten geliyorsa DNS ile ayırt edilemez (HTTPS içeriğini açmak gerekir, bu uygulama bunu bilerek yapmaz).
- Testler: 7754 kontrol, 0 başarısız (yeni: Türkçe, mobil ve açılır pencere reklam sunucuları, bozulmaması gereken 33 ad, lisans bildirimleri, son izin verilenler, DNS atlatma koruması, şüpheli ad işaretleme ve toplu engelleme, riskli uzantılar).


## 1.29.1 (versionCode 47)

**Reklam+, DPI ve DNS düzeltmeleri**
- **Sabit DNS sunucusuna soran uygulamalar:** ağ geçidi açıkken, DNS de açıksa, bir uygulama kendi DNS sunucusuna (ör. 8.8.8.8:53) düz DNS ile sorsa bile sorgu artık seçtiğin sunucuya ve süzgece yönlenir (önceden şifresiz olarak doğrudan çıkıyordu). Yerel/özel hedefler (yönlendirici, şirket DNS'i) yönlendirilmez.
- **TCP/53 DNS:** sabit sunucuya TCP ile giden DNS soruları da süzülür (önceden yalnızca UDP süzülüyordu).
- **Gizli izleyici (CNAME):** sabit sunucudan UDP/53 ile gelen cevaplarda da CNAME zinciri denetlenir.
- **ECH:** Reklam+ açıkken HTTPS/SVCB (tür 65/64) sorgularına "kayıt yok" denir. Bu kayıtlar şifreli ClientHello (ECH) anahtarı taşır; tarayıcı ECH kullanınca gerçek site adı ağ geçidinden görünmez, reklam engeli atlanırdı. Kayıt yoksa tarayıcı düz TLS'e döner. Reklam+ kapalıyken davranış değişmedi.
- **Engelli ad asla sızmaz:** sınıfı IN olmayan (CHAOS, ANY...) bir soruyla engelli ad üst sunucuya gidebiliyordu; artık "reddedildi" (RCODE 5) cevabı verilir. Aynı sağlamlaştırma gizli izleyici cevabında da var.
- **Kök ad sorgusu** (".") biçim hatası sayılıyordu; artık normal iletilir.
- **HTTP Host okuma:** gövdedeki "Host:" satırı Host başlığı sayılmaz (yalnızca başlık bölümü okunur).
- Testler: yeni kontroller eklendi (UDP/TCP 53 uçtan uca dahil).

## 1.29.0 (versionCode 46)

**Güvenlik sertleştirmesi (ayrıntı: GUVENLIK_INCELEMESI.md, "Ek inceleme 1.29.0")**
- **Filtre atlatmaları kapatıldı:** 0x80 ve üstü baytlı etiketlerle (ör. `x.doubleclick.net` önüne eklenen sahte bayt) engel atlanabiliyordu; artık ad bayt bayt doğru okunur. Birden çok soru içeren, sıkıştırma işaretçili, ayrılmış etiket türlü ya da kesik sorgular filtre açıkken yönlendirilmez; istemciye hata (FORMERR) döner.
- **Reklam+ / DPI:** ağdan gelen SNI ve Host adları, kullanıcı girişi gibi katı değil, gevşek biçimde temizlenir; alışılmadık yazımlar engel listesini artık aşamaz.
- **Kayıt sızıntısı:** günlüğe yazılan adlardaki denetim ve garip karakterler "?" ile değiştirilir.
- **Liste güncelleme:** liste kümesi tek dizin değişimiyle yerine konur (yarım kalan güncelleme eski ve yeni dosyaları karıştırmaz); uygulama güncellenince eski önbellek yok sayılır; dosya başına 90 sn toplam süre sınırı; aynı anda tek güncelleme.
- Testler: 7457 kontrol, 0 başarısız. Android tarafı (ListUpdater) bu ortamda derlenmedi; GitHub derlemesinde doğrulanır.

**Metinler:** Yenilikler ilk maddesi ve mağaza/gizlilik metinleri Google Play koşullarına göre güncellendi (VPN açıklaması, isteğe bağlı DPI/Reklam+ kipleri, liste güncelleme beyanı).

## 1.28.0 (versionCode 45)

**Engelleme motoru ve liste güncellemesi**
- **Otomatik liste güncellemesi:** engelleme listeleri (basic/medium/strict) uygulamanın içinde değil, imzalı bir yayın adresinde tutulur. Uygulama en çok günde bir kontrol eder, indirir, doğrular ve yerine koyar. Varsayılan açık; gizlilik metninde ayrıntı var.
- **İmza zorunluluğu:** manifest ECDSA P-256 ile imzalanır; imza gömülü açık anahtarla doğrulanmadan hiçbir liste kabul edilmez. Açık anahtar tanımlı değilse güncelleme kapalıdır (güvenli varsayılan).
- **Geri dönüş (rollback) engeli:** sürüm numarası kurulu sürümden büyük olmalı; eski imzalı bir sürüme dönülemez.
- **Boyut ve özet kontrolü:** her dosyanın boyu ve SHA-256 özeti manifestle eşleşmeli; 100 KB altındaki (boş/kırpılmış) listeler reddedilir, böylece bir yayın hatası tüm kullanıcılarda engellemeyi kapatamaz.
- **Katman bazında yedek:** önbellekteki bir liste bozuksa yalnızca o katman paketteki sürümden okunur; eskiden tek bozuk dosya tüm engellemeyi kapatıyordu.
- **Yeniden yükleme:** liste değişince motor, ayarları korunarak senkron ya da arka planda yeniden kurulabilir.
- **Yayın iş akışı:** `.github/workflows/listeleri-yayinla.yml` haftada bir listeleri üretir, imzalar ve "listeler" yayınına koyar. Kurulum adımları: `tools/yayin/README.md`.

**Hazır arka planlar**
- Uygulamayla gelen 8 görsel yerine 28 görsel. Filigranlı iki görsel (onedio ve pngtree damgalı) listeye alınmadı. Hazır görseller ekran oranına kırpılır; küçük çözünürlüklü görseller (genişlik 240–500 px) telefonda yumuşak görünebilir.

**Kendi stilim**
- Kişiselleştirmede "Kendi stilim" sayfası beş bölümden oluşur: Görünüm (gökyüzü, vurgu, sıvı hareketi, dalga yüksekliği kaydırıcısı), Hareket (animasyon türü, biçimi ve büyüklük kaydırıcısı), Ses (tını, dizi ve perde), Kayıtlı stillerim (altı yuva) ve Araçlar (karıştır, sesi dinle, sıfırla).
- Kayıtlı stillerim: Bir yuvaya dokunup mevcut ayarları kaydedebilirsin. Dolu bir yuvada uygula ya da sil seçilir. Kayıtlar telefona özgüdür.
- 24 yeni tema (12 açık, 12 koyu): toplam 48 tema. Her tema WCAG kontrolünden geçer.
- Güvenlik: ağ geçidi açıkken IPv4 tünelinde IPv6 trafiğinin reklam, DoH ve DPI denetimini atladığı sızıntı kapatıldı.
- IPv6 uzantı başlıkları (hop-by-hop, yönlendirme, hedef seçenekleri) artık geçiyor; önceden bu paketler düşüyordu.
- HTTP Host başlığında IPv6 değişmezi doğru okunuyor.
- Yeni dillerde (Almanca, İspanyolca, Fransızca, Endonezyaca, İtalyanca, Lehçe, Portekizce, Rusça, Ukraynaca, Vietnamca) yeni özel stil ve tema adları çevrildi.
- Uzun seçim listelerinde (dil, tema, parça vb.) açılışta seçili seçenek görünür; artık en alttaki seçenekten sonra listenin başına dönülmez.
- 162 animasyon parçası: 18 efekt türü × 9 biçim. Türler birbirinden farklı çizilir: yörünge, taç yaprağı, kabarcık, şimşek, kristal, ateşböceği, sarmal, ışın, kırılma ve piksel türleri eklendi. "Stilin kendi animasyonu" varsayılandır.
- 384 ses parçası: 16 tını × 12 nota dizisi × 2 perde (normal ve yüksek). Dizilere titreşim ve akor eklendi. "Otomatik (paket)" varsayılandır.

**Efekt biçimleri ve ses parçaları**
- Dokunma efekti biçimi 5'ten 9'a çıktı: Eğik, Ayna, Büyüyen, Hızlı (her stil için ayrı seçilir).
- 384 ses parçası (16 tını × 12 nota dizisi × 2 perde): Ayarlar › Ses › "Ses parçası" ile seçilir, tını, dizi ve perde sırayla sorulur; "Otomatik (paket)" varsayılandır ve eski davranış aynıdır. Parça seçiliyken arayüz sesleri parçayla çalar.

**Özel tema**
- Kişiselleştirmede "Gökyüzü" (8 seçenek: 4 açık, 4 koyu) ve "Vurgu" (6 seçenek) ile kendi temanı kur. Metin ve yüzey renkleri seçime göre türetilir; 48 kombinasyonun hepsi WCAG 4,5:1 okunabilirlik testinden geçer.
- Tema seçicide "Özel" örneği, seçilen kombinasyonu gösterir.
- Sıvı rengi önizlemesi artık süs animasyonu olarak 33 ms kare hızında çalışır (eskiden 16 ms istiyordu).

**Yeni temalar**
- 12 yeni tema eklendi (toplam 24): açık olarak Şeftali, Turunç, Gül, Buzul, Kum, Lagün, Kakao, Şeker; koyu olarak Orman, Kor, Erik, Arduvaz. Her biri 12 dilde adlandırıldı; okunabilirlik testleri (WCAG 4,5:1) geçiyor.
- Tema seçicideki örnek önbelleği 24 temaya göre büyütüldü; eskiden her karede yeniden ayrım yapıyordu.

**Küre animasyonları ve sesler**
- **10 sıvı hareketi:** Ayarlar › Görünüm › Küre › "Sıvı hareketi" (tüm stillerde): Sakin (özgün), Gelgit, Halka, Kabarma, İkiz, Üçgen, Yumuşak kare, Kaynama, Sarmal, Durgun. Varsayılan Sakin; görünüm değişmez.
- **Her stil için 4 yeni dokunma/kutlama efekti:** "Dokunma efekti biçimi" seçeneği, aktif stil için ayrı saklanır. Seçenekler: özgün, yoğun, dönen, çift nabız, toplanan. Özgün varsayılandır.
- **3 yeni ses:** kaydırma (sayfa geçişi), uzun basış, uyarı (bağlı değilken duraklatma isteğinde). Ses paketi tınısıyla çalar.
- Sıvı hareketleri yeniden ayarlandı: her hareketin kendi hızı ve genlik çarpanı var; "Durgun" eskiden neredeyse hiç hareket etmiyordu. Sakin (varsayılan) değişmedi. Sıvı yalnızca bağlanırken/bağlıyken görünür; kapalıyken küre boştur.
- Sıvı hareketi tüm tasarım stillerinde çalışır (Duru'nun düz daire küresi dahil). Türkçe dışındaki dillerde yeni etiketler İngilizce gösterilir.

**Arayüz düzeltmeleri**
- "Kabarcıklar" ayrı ayar satırı kaldırıldı. Kabarcık miktarı artık animasyon seviyesinden gelir: Tam → çok, Az → az, Yok → kapalı. Varsayılan (Tam) görünümde kabarcık sayısı önceki "az"dan "çok"a çıktı; geri almak istersen söyle.
- Animasyon seçenekleri Yok · Az · Tam sırasıyla gösterilir (her dilde). Türkçe "Kapalı" etiketi "Yok" oldu. Kayıtlı ayarlar bozulmaz (enum sırası aynı).

**Önceki sürümden düzeltmeler (1.27.x içinde)**
- DNS cevap doğrulama açığı (soru çözülemeyen sorgularda kimlik tutan her cevap kabul ediliyordu) kapatıldı.
- HTTP çerçeveleme sertleştirildi (bozuk ya da çelişen uzunluk ve chunked+Content-Length reddedilir).

**Testler:** liste imzası, manifest biçimi, özet/boy, rollback, minimum boyut ve bozuk önbellekte yedek (57 kontrol, "girdi" grubu).

**Henüz yapılmadı (bilerek):**
- Gerçek yayın adresi ve açık anahtar: `ListUpdater.BASE_URL` ve `PUBLIC_KEY_B64` yayın kurulumunda doldurulmalı; boşken güncelleme kapalıdır.
- Ayarlarda "Listeleri otomatik güncelle" anahtarı: şimdilik yalnızca varsayılan açıktır, arayüz anahtarı sonraki adımda eklenmeli.
- Üç dosyanın yerine taşınması sırasında çökme olursa karışık sürüm kalabilir (her dosya ayrı ayrı doğrulanmış olur).

## 1.27.0 (versionCode 44)

**Güvenlik ve sağlamlık**
- **HPKE çapraz doğrulama:** ODoH'un şifreleme katmanı bağımsız bir referans uygulamayla (pyhpke, RFC 9180) iki yönde doğrulandı. Kodda değişiklik yok; test ve vektörler eklendi.
- **Nonce ve anahtar kuralları:** her kurulumda yeni efemer anahtar, nonce tekrarı olmadığı ve sıra dışı mesajların reddedildiği testlerle korunuyor.
- **Bozuk girdi fuzzing:** şifreli metne 4000 bozuk girdi; istisna ya da kabul yok, alıcı durumu korunuyor.
- **Yayın imzalama koruması:** yayın derlemesinin debug anahtarına düşmediğini ve gizli anahtar dosyalarının depo dışında kaldığını doğrulayan testler.
- **Dependabot:** Gradle bağımlılıkları ve GitHub Actions sürümleri haftalık izleniyor.
- **Ad etiketi dizisi taşması:** filtre, 128'den fazla etiketli adlarda sağdaki sonekleri sessizce atıyordu. Dizi, 255 baytlık DNS adının en çok etiket sayısına (128) göre boyutlandırıldı. Gerçek ağ sorgularında bu durum zaten oluşamıyordu; yine de düzeltildi.
- **HTTP çerçeveleme sertliği:** ODoH ve DoH cevaplarında bozuk içerik uzunluğu, birbirini tutmayan iki içerik uzunluğu ve hem chunked hem içerik uzunluğu birlikte gelen cevaplar artık reddediliyor (önceden sessizce kabul ya da 'kapanana kadar oku' moduna düşüyordu). Testler: 'HTTP çerçeveleme' grubu.
- **DNS cevabı doğrulama açığı (kritik, düzeltildi):** sorgunun sorusu çözülemediğinde (soru yok ya da sıkıştırılmış ad) soru denetimi atlanıyordu; kimlik tutan her cevap önbelleğe giriyordu. Artık yalnızca soru bölümü ve cevabı boş hata cevabı kabul ediliyor. Düz DNS ve şifreli DNS yolları aynı fonksiyonu kullandığı için ikisi de kapandı. Testler: 'Güvenlik' grubu (2 yeni kontrol).
- **Eşleştirme sınır testleri:** DNS sınırında (≤253 bayt) çok etiketli adlarda engel yakalanıyor; 253 bayttan uzun adlar geçersiz sayılıp güvenle reddediliyor.
- **Güvenlik taraması iş akışı:** Lint, mobsfscan, gitleaks ve MobSF (APK) taraması.
- **Eşzamanlılık hatası düzeltildi (kripto):** Aynı şifreleme bağlamı birden çok iş parçacığından kullanılınca nonce çakışabiliyordu (test 4000 şifrelemede 128 çakışma buldu). Artık sayaç ve şifreleme tek kilit altında; sayaç tükenirse bağlam kullanılmaz.
- **Türkçe alan adları:** `örnek.com` gibi IDN adlar artık kabul edilir ve punycode'a çevrilir (`xn--rnek-4qa.com`). Büyük harf eşlemesi (İ/ı) doğru çalışır.
- **Gizlilik politikası:** Tanılama raporunun içeriği, çökme özeti ve bildirim/açılış izinleri politikaya işlendi.
- **Tanılama raporu** (☰ > Sorun giderici > Tanılama raporu): sürüm, Android sürümü, cihaz modeli, ağ türü, ayar kodları ve sorun sayısını gösterir. Önce önizlenir, paylaşımı sen onaylarsın; alan adı, IP ya da kişisel veri içermez.

## 1.26.0 (versionCode 43)

**Yeni**
- **Duru stili** (☰ > Kişiselleştir > Stil): sakin ve sade; nane tonlu zemin, altta saydam su bandı, ince kenarlı düz yüzeyler, az hareket (solarak büyüyen sayfa geçişi, yumuşak yaylar, halka efekti).
- **Duru uygulama simgesi:** suya süzülen iki yaprak, saydam su ve cam rozette "DNS" (uyarlanabilir + tek renkli simge dahil).
- **Duru ses paketi:** yumuşak, kısa, sıcak tınılı 11 olay sesi; Otomatik pakette Duru stiliyle eşleşir, ayrıca kendi paketi olarak seçilebilir.
- **Duru animasyonları:** 10 olay için yaprak süzülmesi ve su halkaları (dokunma, anahtar, bağlanma, kesilme, hata, tamamlanma, panel, geri, seçim, yenileme).
- 12 dilde stil ve simge açıklamaları.

**Bağlantı (aynı sürüm):**
- **Uyanık kalma kilidi:** Tünel açıkken (bağlanıyor, bağlı, yeniden denerken) CPU uyanık tutulur; ekran kapalıyken bağlantı donup sessizce düşmesin diye. Kullanıcı kestiğinde, duraklattığında ya da hata verince bırakılır. Pil tüketimi bu kilidin bedelidir; pil ayarları sayfasındaki muafiyet durumu hâlâ geçerli.
- **Ağ dönünce yeniden bağlanma:** Yeniden denemeler tükendikten sonra bile, kullanıcı bağlantıyı kesmediyse ağ geri geldiğinde bağlantı yeniden kurulur. Kullanıcı kestiyse hiçbir şey kendiliğinden açılmaz.
- **DNS sızıntı kontrolü:** Sorun gidericide, tünel açıkken sistemin DNS sunucusu bizim sanal adresimiz değilse uyarı verir. Uygulamalar kendi DNS'lerini (ör. tarayıcının DoH ayarı) kullanıyorsa bu kontrol görmez; bunu da not olarak belirtiyorum.

- **Ağa göre DPI öğrenmesi (kalıcı):** Hangi DPI yönteminin hangi ağda çalıştığı artık uygulama kapansa da hatırlanır. Anahtar: ağ türü ve mobilde operatör kodu (MCC+MNC); Wi-Fi'de SSID kullanılmaz (konum izni gerekir), yalnızca "Wi-Fi" olarak tutulur. Kayıt yalnızca telefonda durur. Bir yöntem artık çalışmazsa sıradakine geçilir ve yeni çalışan kayda yazılır.

- **"Site neden açılmıyor?" (☰ > Sorun giderici alanında ayrı satır):** Bir alan adı yazılır; uygulama sırayla bakar: bağlantı açık mı, kullanıcı engel listesinde mi, reklam/izleme listesinde mi, şifreli DNS sağlayıcısı mı, izin verilmiş mi. Engelliyorsa "İzin ver" düğmesi çıkar. Engellemiyorsa sorunun büyük olasılıkla sitede ya da tarayıcıda olduğunu söyler.

- **YouTube reklam sunucuları (yalnızca kişisel sürüm, kısmi):** Ayarlarda isteğe bağlı anahtar. Bilinen reklam ve reklam ölçüm alan adlarını DNS'te engeller. İçerik sunucuları (googlevideo.com, youtubei, youtube.com) asla engellenmez; oynatıcı içi reklamları kaldırmaz, bu yüzden kısmidir. Play sürümünde anahtar görünmez ve etkin olmaz. Kişisel APK: `./gradlew assembleRelease -Ppersonal=true`.

**Düzeltme (aynı sürüm):** Duru Aqua çakması gibi duruyordu; bileşenler baştan düz çizildi (cam küre yerine düz daire + sakin su düzeyi, hap yerine yumuşak köşeli düğmeler, gölgesiz kartlar, düz simge kareleri, düz üst çubuk), yeni "süzülme" sayfa geçişi ve ince halka + yaprak efekti eklendi.

**Test:** tüm JVM testleri, 0 hata (stil/paket/tını sayıları 8/14/16'ya güncellendi).

## 1.25.0 (versionCode 42)

**Değişti**
- **Ses varsayılanı (Otomatik):** dokunma ve bağlanma sesleri artık telefon **titreşim** modundayken de çalar (oyun ve klavye sesleri gibi, medya kanalından). Yalnızca **tam sessiz** modda susar. Önceden Otomatik modda telefon titreşimdeyken de susuyordu; "bazı telefonlarda ses gelmiyor" geri bildiriminin başlıca nedeni buydu (çok kullanıcı telefonu sürekli titreşimde tutuyor). Sistem/medya ses seviyesine ve "sessiz başarı" / yedek yol mantığına dokunulmadı. İsteyen eski davranışa Ses çıkışı: Sistem ile dönebilir, tam sessizde de duymak isteyen Medya seçebilir.

**İnceleme**
- Şifreli bağlantı çekirdeği (`SecureForwarder`: DoT / DoH / ODoH) kaynak kodundan yeniden gözden geçirildi: HTTP ayrıştırma (chunked + content-length çakışmasında chunked önceliği), sınır denetimleri, şerit eşzamanlılığı ve TLS 1.2/1.3 sabitlemesi. Yeni bir açık ya da hata bulunmadı; değişiklik yapılmadı.

**Test:** tüm JVM testleri, 0 hata (ses kanalı seçimine titreşim + medya durumları eklendi).

## 1.23.0 (versionCode 40)

**Yeni**
- **Oblivious DoH (ODoH, RFC 9230)**, isteğe bağlı, varsayılan **kapalı** (☰ > DNS ayarları > Oblivious DoH: Kapalı / Yedekli / Sıkı). Sorgu hedef sunucunun anahtarıyla şifrelenip bir **röle** üzerinden gider: röle IP'nizi görür ama soruyu göremez, DNS sunucusu soruyu görür ama sizi göremez.
  - *Yedekli:* önce ODoH; kurulamazsa normal şifreli yöntemler (gizlilik düştü uyarısıyla) ve ODoH'a dönmek için arka planda yeniden deneme. *Sıkı:* yalnızca ODoH; kurulamazsa bağlanmaz, hiçbir yönteme düşmez.
  - ODoH seçili DNS sunucusundan bağımsızdır; uygulamanın kendi röle + hedef çiftlerini kullanır (2 röle × 3 hedef, her çiftte iki ayrı işletmeci; aynı işletmeci ya da alan adı eşleşmez, kurucu bunu reddeder).
- **Kendini onaran, çok katmanlı motor:** (1) yol seçimi: gecikme + hata puanı, devre kesici, üstel geri çekilme (2 sn → 2 dk, ±%20 sapma), yarı açık tek deneme, bayat yolların yoklanması; (2) anahtar yönetimi: tek uçuşlu alım, 6 saat taze, alınamazsa 7 güne kadar bayat anahtarla devam, 401'de hız sınırlı yenileme (anahtar dönmesi arıza sayılmaz); (3) adresler: son çalışan → ipucu → şifreli (DoT) ad çözümü, düz DNS hiç kullanılmaz; (4) bağlantı: aynı sorguda ölü röleden sonra başka röleye geçiş, sahte/bozuk cevap yolu uzun süre keser; (5) ağ değişince yol bilgisi sıfırlanır.
- Gizlilik ayrıntıları: her sorgu için taze HPKE anahtarı, DNS kimliği 0, düz metin 128 baytın katına doldurulur, cevaplar kimlik doğrulamalı; hedefin yapılandırması doğrudan (röleden değil) alınır, bu sırada hedef IP'nizi görür ama soru görmez.
- Kendi X25519 + HPKE (RFC 9180) gerçeklemesi (dış kütüphane yok); RFC 7748 / RFC 9180 vektörleriyle ve JDK ile 300 rastgele çapraz sınamayla doğrulandı.
- Araç: `tools/odoh_check.py` canlı röle/hedef denetimi.

**Dürüst sınırlar**
- ODoH yalnızca **DNS sağlayıcısından IP'nizi** saklar. Operatörünüz, Wi-Fi sahibi ve bağlandığınız siteler IP'nizi yine görür; röle trafik zamanını ve hacmini görür. Gizlilik, rölenin ve hedefin **anlaşmamasına** dayanır.
- Gerçek röle/hedeflerle **canlı uyumluluk bu ortamda denenemedi** (ağ yok); şifreleme RFC vektörleriyle ve bağımsız bir sunucu benzetimiyle sınandı. Röle/hedef IP ipuçları Ekim 2026 tarihlidir. Cihazda denenmedi: VPN servisi entegrasyonu, bildirimler, ağ değişimi.

**Test:** 6153 kontrol, 0 hata (212 yeni: şifreleme, yapılandırma, ileti biçimi, yol tahtası, anahtar önbelleği, katalog, adres defteri, ayarlar, uçtan uca benzetim).

## 1.22.0 (versionCode 39)

**Yeni**
- **Liquid Glass stili:** yarı saydam mavi-indigo cam, parlak beyaz kenar ışığı, cam anahtar damlası. Kendi dokunma efekti, ses paketi (parlak, dalgalanan cam tınısı) ve uygulama simgesi (cam küre içinde kalkan ve güç simgesi).
- **Her stile 4 yeni animasyon:** panel açılması, geri, seçim, yenileme. Sekiz mevcut paket için ayrı çizimler; Liquid Glass'ın 10 animasyonunun hepsi kendine özel. Toplam 10 paket × 10 animasyon.
- **Her ses paketine 2 yeni ses:** seçim ve yenileme. Seçenek, sunucu veya tema seçince seçim sesi; ölçüm ve bağlantı testi başlayınca yenileme sesi çalar.

**Değişti**
- Uygulama **güvenlik / ağ aracı** olarak konumlandırıldı: mağaza metni ve kısa açıklamalar (12 dil) "zararlı, kimlik avı ve izleyici alan adlarına karşı koruma" diline çevrildi.
- Stil, simge ve ses paketi açıklamaları 12 dilde güncellendi.

**Test:** 5941 kontrol, 0 hata. Cihazda doğrulanmadı: görünüm, ses beğenisi, yeni simgenin başlatıcıdaki görünümü.

## 1.21.9
- Gömülü **Public Suffix List**: "aynı site" kararı gerçek eTLD+1'e bakar (co.uk, com.tr, github.io…); sıcak yolda bellek ayırmaz.
- **Filtre belleği** ayarı: Otomatik / Hafif / Tam. Az belleği olan telefonda en büyük liste atlanır, bellek yetmezse çökmeden devam edilir.
- "Yalnızca seçilenler"de seçili uygulama yoksa koruma **başlamaz** (Android boş listeyi "hepsi" sayar); hata gösterilir.
- Play beyan taslağına kontrol listesi eklendi.

## 1.21.8
- Filtre listeleri akışla okunur (tam dosya ayrıca belleğe alınmaz), bellek yetmezse yedek yol.
- Özel son ek listesi, SecureForwarder yarışı, TcpDns port sarması düzeltmeleri, ayar önbelleği.

## 1.21.5 – 1.21.7
- Dış incelemelerden doğrulanan düzeltmeler: içe aktarılan listenin korunan adları geçemesi, tema örnek küresi önbelleği, CNAME sayacının atomik olması, ağ geçidi adres elemesi, regresyon testleri.

## 1.10 – 1.21
- Kendi kullanıcı alanı TCP/UDP aktarıcısı (ağ geçidi), DPI atlatma ve Reklam+ düğmeleri, mobil ağ politikası, ses uyumluluğu (Rahatsız Etmeyin), yeni hareket motoru, ses efektleri, stile özgü efektler, profiller, sessiz saatler.

## 1.9.x
- Dört seviyeli koruma/engelleme, izin ve engel listesi, kendini onarma, kendi TCP katmanımız, bildirim sistemi, gecikme grafiği, kendi liste içe/dışa aktarma, Aurora stili, IPv4 + IPv6.

## 1.1 – 1.8
- Özel DNS sunucuları ve 32'lik katalog, uygulama başına kapsam, stiller ve sayfa geçişleri, arka plan fotoğrafı, uygulama simgeleri, sorun giderici, sunucu arama, ☰ menü ve Hakkında, kişiselleştirme penceresi.

### oto-koruma 18: günlük ayrıntısı, sızıntı denetimi, modül uyumu
- Günlük: kapasite 120 → 400; satırlar `[KATEGORİ]`, `! [KATEGORİ]` (uyarı), `!! [KATEGORİ]` (hata) önekli. Hata satırlarında artık özel durumun sınıfı, nedeni ve kodun dosya:satır konumu var (ileti metni yine yazılmaz: ad/adres sızmasın). Tanılama raporu 40 → 90 olay, 9000 karakter.
- 5 dakikada bir `[ÖZET]` satırı: ağ türü, DNS, ağ geçidi, DPI başarı/başarısızlık, DoH engeli, sızıntı sayaçları, liste durumu, aktif oto-koruma önlemleri.
- Sızıntı: DNS+DPI (Reklam+ kapalı) birleşiminde DoH/DoT atlatması artık ağ geçidinde engellenir (`Coherence.blockDoh`: DNS açık ve Reklam+ ya da DNS sızıntı kalkanı açık). Önceden yalnızca Reklam+ ile engelleniyordu.
- `LeakAudit`: sabit sunucuya giden düz UDP/TCP 53'ün tünele alınma sayıları. `[SIZINTI]` satırları: DoH girişimi engeli, Özel DNS sabitliği, kalkan.
- `Coherence.warnings`: modüller birbiriyle çelişirse `[UYUM]` uyarısı (DPI açık/DNS kapalı, liste yüklenmedi, DoH engeli yok…).
- Not: Android'e özel kod (DnsVpnService) yerelde derlenemedi; JVM testleri 10850 kontrol, 0 başarısız.

### oto-koruma 19: sürekli denetim katmanı, ayrıntılı kategorili günlük, cihaz uyumu
- `Audit` (core/Audit.kt): 30 sn'de bir sayaç ölçümü alır, 5 dk'lık pencerede sızıntı (tünel yok, DNS atlatma, DoH açık), DPI (başarısızlık, kesinti, tükenen hedef), reklam (liste yok, hiç engel yok, ECH), sızma (sahte DNS cevabı, sertifika uyuşmazlığı, saat, yoğun trafik), istikrar (zaman aşımı, bağlantı hatası, yedeğe geçiş, ağ dalgalanması, sık yeniden kurulma) ve kaynak (akış sınırı) bulguları üretir. Her bulgu bir kez bildirilir, sürerse 30 dk'da bir tekrarlanır. Güven puanı: 100 − 30×kritik − 10×uyarı.
- Kritik bulgularda (uyarı bildirimleri açıksa) bildirim; her bulgu günlüğe kategorisiyle yazılır.
- Günlük: kapasite 800 (2 kat), eski satırlar anahtar sözcükle kategorilenir; rapor 18000 karakter, 220 olay; bölümler: Denetim, Uyumluluk, Ayarlar, Olay özeti, Kategoriler, Son sayaçlar, kategori başlıklı olaylar.
- Hata/kopma anında (tünel kapandı, bağlanamadı, bağlantı kesildi) durum özeti anında yazılır.
- `Compat`: cihaz sınıfı/RAM/yığın sınırına göre ağ geçidi akış sınırları (TCP 400–1500, UDP 120–400), agresif sistemlerde 3 dk'da bir özet ve pil/ROM notları (Samsung, özel ROM, GrapheneOS/CalyxOS, eski Android).
- Android'e özel kod (DnsVpnService, Notifier, MainActivity) yerelde derlenemedi; JVM testleri 10890 kontrol, 0 başarısız.

### oto-koruma 20: 12 dilde bulgu metinleri, katmanlı uyum planı
- Denetim bulguları, uyum notları ve modül uyarıları artık KOD + değişken olarak taşınır; metin görüntülenirken seçili dilde üretilir (`AuditText`; TR, EN, DE, ES, FR, PT, RU, IT, ID, VI, PL, UK; 55+ kod). Testler her kodun 12 dilde dolu, değişkenlerinin aynı ve içinde alan adı/IP benzeri değer olmadığını doğrular. Günlüğe yazılan satırlar yazıldığı andaki dilde kalır.
- `Compat` katmanlı hale geldi: cihaz sınıfı/bellek, kapatılma eğilimi (üretici/ROM), pil tasarrufu, ağ türü (ölçülü mobil, yalnızca IPv6), soket yeteneği (TTL), bileşik kısıt (≥2 kısıt: ek daralma + Hafif filtre önerisi), sistem sürümü. Katmanlar yalnızca kısar; test bunu doğrular.
- Plan ağ geçidine uygulanır: TCP/UDP akış sınırı, UDP/TCP boşta süresi, paralel yedek deneme; ayrıca denetim ve özet aralığı. Üretici başına (Xiaomi, Huawei/Honor, OPPO/realme/OnePlus, vivo, Samsung) yönerge notları.
- Android'e özel kod (DnsVpnService) yerelde derlenemedi; JVM testleri 11119 kontrol, 0 başarısız.

### oto-koruma 21
- Derleme düzeltmesi: MainActivity.AndroidHost.networkKind içinde `this` Context değil iç sınıftı (`this@MainActivity` yapıldı); kullanılmayan import silindi.

### oto-koruma 22: uygulama bazlı reklam engelleme, kurtarma, liste sağlık denetimi
- **Uygulama bazlı istatistik** (`core/AppAds.kt`, `platform/AppOwner.kt`): her engellenen istek, bağlantının sahibi uygulamaya yazılır (Android 10+ `getConnectionOwnerUid`; yalnızca VPN uygulaması sorabilir). Engelleme ayarı → Uygulama bazlı reklam engelleme: en çok engelleten uygulamalar ve en sık engellenen adlar. Yalnızca bellekte; cihazdan çıkmaz. Eski Android'de ya da sahip çözülemezse genel ayar uygulanır (asla yanlış uygulamaya muaf davranılmaz).
- **Uygulama başına kip**: Genel / Muaf (o uygulamada hiçbir şey engellenmez, ör. bankacılık) / Sıkı (en sıkı liste, ör. reklamı bol oyun). Düz DNS (UDP/53, TCP/53), SNI/Host, QUIC ve IP-ad eşlemesi yollarının hepsi kipi uygular; DNS-only kipte `FilteringForwarder` da. Sıkı motor yalnızca en az bir uygulama sıkıdayken kurulur (`FilterRuntime.strictEngine/strictGwEngine`). Kurallar ayarlarla (`appAds`) kalıcıdır.
- **Bozulan uygulama kurtarma**: aynı ad bir dakikada ≥40 kez engellenirse (uygulama yeniden deniyor) uygulama "Bozulmuş olabilir" olarak listenin başına çıkar; tek dokunuşla muaf tut / engellenen adlara izin ver / yok say. Denetim katmanına bilgi düzeyinde `app.broken` bulgusu (12 dilde; puanı düşürmez).
- **Liste güncelleme sağlık denetimi** (`ListCanary`): imzası ve özeti doğru indirilen listeler yerine konmadan önce en sıkı seviyede bir motora kurulur; 46 popüler/resmî site (Google, YouTube, WhatsApp, bankalar…) geçmeli, bilinen 10 reklam ağının en az 7'si engellenmeli, boyut paketteki sürümün yarısı ile 4 katı arasında olmalı. Geçemeyen sürüm atlanır, eski liste korunur, aynı sürüm tekrar indirilmez (daha yeni yayın yine denenir).
- Yeni metinler 12 dilde (`AppAdsText`, `app.broken`); testlerle doğrulanır. Ağ geçidi testleri: muaf/sıkı/bilinmeyen sahip, DNS ve SNI yolları, istatistik atfı. JVM testleri 11222+ kontrol, 0 başarısız.
- Android'e özel kod (AppOwner, DnsVpnService, ListUpdater, App) yerelde derlenemedi.
- Düzeltme: kurtarmada izin verilen adlar tek ayar güncellemesiyle eklenir (önceden her ad için motor yeniden kuruluyordu); sahip önbelleği 1 sn (port yeniden kullanımında yanlış atıf riski azaldı).

### oto-koruma 24: DPI puan/hız/site belleği, sızıntı testi, durum özeti
- **DPI yöntem puanı ve hız** (`Dpi.Planner`): her yöntem için kazanç/başarısız sayısı ve bağlantı kurulduktan sonra ilk cevaba kadar süre (üstel ortalama). Ağ önceliği seçerken oyları yakın yöntemler arasında belirgin (%30+) daha hızlı olan tercih edilir.
- **Kalıcı site belleği** (`PlanMemory`): ağ başına en çok 64 site için çalışan TLS yöntemi diske yazılır (en sık dakikada bir); anahtar sitenin 48 bitlik özeti, ad açık yazılmaz. Ağ değişince/uygulama açılınca ilk bağlantı doğru yöntemle başlar. Eski kayıt biçimi okunur.
- **[DPI] günlüğü**: ağ değişimi, yöntem kazanımı (kaç yöntem önce başarısız, ilk cevap süresi; yöntem başına dakikada bir), kesinti nedeniyle yöntem değişimi, tüm yöntemlerin tükenmesi.
- **Rapor**: "DPI yöntemleri (bu ağ)" bölümü (yöntem başına kazanç, başarısız, ort ms, atlanıyor).
- **Etkin DNS sızıntı testi** (`LeakProbe`): bağlıyken 20 dk'da bir var olmayan benzersiz bir ad (.invalid) sistem çözücüsüyle sorulur; sorgu DNS yönlendiricisinden/ağ geçidinden geçmezse `leak.private-dns` bulgusu (Özel DNS/DNS-over-TLS tüneli atlıyor olabilir; 12 dilde, kapatma yönergesiyle). Bağlantıdan 45 sn sonra ilk test.
- **Liste güncelleme**: Wi-Fi'da denetim 12 sa → 3 sa (yalnızca küçük manifest; listeler yeni sürüm varsa), servis bağlıyken de her 3 saatte tetikler. Mobil veride 72 sa korunur.
- **Durum özeti**: Engelleme sayfasında "Durum özeti" (DNS, DPI, Reklam engelleme, Bağlantı ve güvenlik: çalışıyor/uyarı/sorun/kapalı), denetim bulgularından; 12 dilde.
- JVM testleri 11282 kontrol, 0 başarısız. Android'e özel kod (DnsVpnService, MainActivity) yerelde derlenemedi; gerçek telefonda denenmedi.

## oto-koruma 25 — günlük doğruluğu
- Sızıntı sınaması metni "tünelden geçmedi" yerine "DNS yönlendiricisinde görülmedi (kesin değil)" der (12 dil).
- Soket yenileme günlüğü hata iletisini değil sınıf adını yazar (ad/adres sızmaz).
- Günlük kategorisi: "engel" → "engellen"; "ech" yalnız bağımsız sözcük.
- Testler: kod çözücü fuzz, kategori doğruluğu.

## oto-koruma 26 — oto-onarım sertleştirme
- Eski UI testi düzeltildi: filtre kapalıyken "Son engellenenler" satırı gizli (bilinçli davranış), açılınca görünür.
- Immune: aynı sürekli önlem kayıttan iki tehdide yazılmaz; geleceğe dönük zaman damgaları (lastEvent/lastChange/lastRelax/lastGlobal/holdUntil) selfCheck'te şimdiye çekilir (rahatlama sonsuza dek kilitlenmesin).
- Günlük: önlem uygulanamadıysa "uygulandı" satırı yazılmaz; tek satır "uygulanamadı, geri alındı" (uyarı).
- Testler: Immune.decode/decodeAll/tick fuzz, yinelenen önlem.

## oto-koruma 27 — sızma testi, 4x zorlu testler
- Yeni `selftest/PenTests.kt`: HPACK/Huffman, HTTP/3, QUIC, HTTP cevap çerçevelemesi (istek kaçırma), DNS cevapları (CnameGuard/önbellek), hosts/liste/ayar/istatistik içe aktarma, SYN seli; yapıya duyarlı mutasyon, süre sınırı (500 ms) ve çıktı sınırı denetimi. `GatewayTests`: bozuk ClientHello + kötü sunucu akışları.
- Tüm eski fuzz döngüleri `FUZZ_X = 4` ile 4 kat büyütüldü (FuzzTests, HardeningTests, AdBoost, Stage22, Tcp, Odoh, Quic, Secure vb.).
- Bulgu: ayrıştırıcılarda yeni açık çıkmadı; manifest, PendingIntent, alıcı, içe aktarma yolları gözden geçirildi (dışa açık bileşenler korumalı).
- Tam paket: 11303 kontrol, 0 başarısız (~275 sn).

## oto-koruma 28 — Shroudly karşılaştırmasından
- Düz HTTP'de enjekte edilmiş engel yönlendirmesi (302, Location = bilinen engel sayfası IPv4'ü) başarı sayılmaz; sıradaki yöntemle yeniden denenir (`Dpi.looksLikeBlockRedirect`).
- Seçici QUIC düşürme (`GwConfig.quicSelective`, varsayılan açık): TCP'de ilk yöntem engele takılıp başka yöntem çalışan sunucu adresine (30 dk, en çok 256 adres, adres özeti) giden UDP/443 düşürülür.
- Zaten vardı: engel sayfası IP reddi (BlockPages), kesinti tespiti (CutWatch), autoTtl/HopProbe.
- Yapılmadı: sahte RST düşürme (üst bağlantılar işletim sistemi soketi; RST'yi uygulama göremez), OONI tabanlı sunucu listesi (sunucu hattı + imza anahtarı gerekir).

## oto-koruma 29 — OONI engelli site listesi (üretici)
- `tools/ooni_sites.py` + `tools/test_ooni_sites.py` + `.github/workflows/engelli-liste.yml`: haftalık, OONI toplu sayaç API'sinden TR engelli alan adları; 90 gün görülmezse düşer; şema/boyut korumaları; ECDSA imza (LIST_SIGNING_KEY).
- Henüz canlı API'ye karşı ÇALIŞTIRILMADI (ağ erişimi yoktu).
- İstemci: `core/BlockedSites.kt` (ayrıştırma, imza, sürüm satırı, alt alan adı eşleşmesi); `ListUpdater.updateBlocked/loadBlocked` (engelli-TR.txt + .sig indirir, imza+sürüm+boyut denetimi, atomik yazım; Android kodu, yerelde DERLENMEDİ).
- Kullanım: DPI açık + `quicSelective` iken QUIC Initial'ın SNI'si listedeyse UDP/443 düşürülür (tarayıcı TCP'ye döner).

## oto-koruma 31 — DoT/DoH için SNI'siz yedek bağlantı
- `SecureForwarder.openOne`: SNI'li TLS el sıkışması kesilirse (SSLHandshakeException/sıfırlama; zaman aşımı ve sertifika reddi HARİÇ) aynı hedefe bir kez SNI'siz denenir; çalışırsa hedef bu ağda SNI'siz hatırlanır (ağ değişince sıfırlanır). Sertifika yine hedef adına karşı doğrulanır.
- Android'de (Conscrypt) `serverNames = emptyList()` SNI'yi gerçekten kaldırıyor mu DOĞRULANMADI; JVM'de (JSSE) testle doğrulandı.

## oto-koruma 32
- Test: çok segmentli büyük ClientHello (2.6 KB dolgulu, 1200 baytlık TCP parçalar) ağ geçidinden eksiksiz geçer, cevap istemciye ulaşır (kod değişmedi; yalnızca doğrulama).

## oto-koruma 33
- Tanılama raporu "DPI yöntemleri (bu ağ)" bölümüne yan sayaç satırı eklendi: enjekte edilen engel sayfası, düşürülen QUIC, işaretli sunucu adresi, engelli liste boyutu (`Gateway.dpiExtras`). DPI tablosu boşsa eklenmez.

## oto-koruma 34
- DNS: birincil sunucu son sorguda geç kaldıysa sorgu iki sunucuya birden gider (yarış), ilk cevap kazanır; birincil düzelince biter.
- DPI yalnızca listedeki sitelere (ayar, varsayılan kapalı): `dpiListedOnly`. Engelli liste boşsa DPI her zamanki gibi tüm sitelere.
- Autopilot DPI: ağ engeli belirtilerinde DPI kapalıysa otomatik koruma `DPI_ON` önlemini açar (sakin dönemde geri alınır).
- Tarayıcı kipi (deneysel, kapalı, açık onayla): cihaza özgü yerel CA (`MitmCa`, elle DER/ECDSA P-256), yerel TLS vekili (`MitmProxy`),
  kozmetik kurallar (`Cosmetic`, yerleşik: YouTube arayüz reklam alanları). Yalnızca tarayıcı paketlerinin akışları (`getConnectionOwnerUid`),
  yalnızca kural listesindeki adlar. Sunucu tarafı tam doğrulanır (zincir + ad). CA'ya güvenmeyen istemci → ad 10 dk muaf. `mitmOn`
  dışa/içe aktarılmaz. Reklam+ ya da DPI (ağ geçidi) açıkken çalışır. Kurulum: Ayarlar > Tarayıcı kipi sertifikası > Kaydet; sistem ayarlarından CA olarak kur.

## oto-koruma 35 — derin test katmanı, onarım/denetim iyileştirmeleri, Deneysel bölüm
- Yeni "derin" grup (`DEEP_X = 3`, eski ~11,4 bin kontrolün ÜSTÜNE; eski takım baştan yazılmadı, genişletildi): kaos DNS sunucuları (çok iş parçacıklı), aşamalı arıza, CPU doygunken yarış, tohumlu uzun Immune simülasyonları + değişmezler, kalıcılık/bozuk kayıt, Denetim senaryoları, vekil saldırı testleri (bozuk/çelişkili Content-Length, yavaş ve eşzamanlı istemciler, CA/kozmetik fuzz), ağ geçidi DPI × listedOnly × liste × vekil matrisi.
- Bulunan ve düzeltilen hatalar:
  - DNS yarışı: `streak` gönderimden SONRA okunuyordu; hızlı birincil cevap onu sıfırlayınca yarış kaçıyordu (yük altında aralıklı hata buydu). Karar artık gönderimden ÖNCE.
  - Vekil: çelişkili çift Content-Length isteği kaynağa iletiliyordu (request smuggling) → istek düşürülür; bozuk cevap uzunluğunda enjekte edilmez.
  - Vekil: sessizce kapanan bağlantılar adı 10 dk muaf bırakıyordu → yalnızca sertifika reddi (TLS uyarısı / "broken pipe") sayılır.
  - Vekil bağlantı üst sınırı 48 → 128 (eşzamanlı testte reddediliyordu).
- Oto onarım: `DPI_ON` (NET_BLOCK merdiveni), `MITM_OFF` (yeni `PROXY_FAIL` belirtisi: vekil el sıkışma hataları), tick başına en fazla 2 şiddetli eylem (`MAX_SEVERE_PER_TICK`).
- Denetim: yarış oranı (`stab.race`), vekil sertifika reddi (`mitm.cert`), vekil ama ağ geçidi yok (`mitm.nogw`), otomatik DPI (`dpi.auto`), liste boş + listedOnly (`dpi.listed-empty`); 12 dilde.
- Arayüz: menüde yeni "Deneysel özellikler" bölümü; "DPI yalnızca listedeki sitelere", "Tarayıcı kipi" ve "Tarayıcı kipi sertifikası" Bağlantı'dan oraya taşındı.
- Test hatası düzeltildi: boş güven deposu JDK'da `internal_error` üretiyordu; istemci artık başka bir CA'ya güveniyor.
- Doğrulama: tam set 12090 kontrol, 0 hata. Android kodu (`platform/*`) yerelde DERLENMEDİ. Firefox kullanıcı CA'sına güvenmez. Kozmetik filtre yalnızca sayfadaki reklam alanlarını gizler.
- Deneysel bölüme iki anahtar: "DNS yarışı" (`dnsRace`, varsayılan açık; bağlantı kurulurken okunur) ve "Autopilot DPI" (`autoDpi`, varsayılan açık; `DPI_ON` önlemini engeller).
- Yerleşik kozmetik kurallar: mobil YouTube (`ytm-*`), YouTube eşlik reklamları, Reddit (`shreddit-ad-post`). Seçiciler canlı sitelere karşı DOĞRULANMADI.

## oto-koruma 37 — güvenlik taraması, menü sadeleştirme
- Güvenlik (tarayıcı kipi CA'sı): yerel CA artık iki katmanlı. Kök anahtarı üretimde ara CA'yı imzalar imzalamaz ATILIR; cihazda yalnızca Ad Kısıtlı ara CA anahtarı kalır (kritik NameConstraints, yalnızca kural alanları: youtube.com, reddit.com). Anahtar sızsa bile başka site için geçerli sertifika üretilemez. Kısıt bilerek ara sertifikada: PKIX çapa (kök) sertifikadaki kısıtı uygulamıyor (JDK'da doğrulandı, Android'de garanti yok). JVM'de PKIX ile test edildi; Android'in kullanıcı CA'sında uygulamasını DOĞRULAMADIM.
  - Eski (tek katmanlı) CA kaydı yüklenmez, yenisi üretilir: tarayıcı kipi kullananlar sertifikayı BİR KEZ yeniden kurmalı. Kural alanları değişirse de aynısı olur.
- CA dışa aktarma: önceki `dnshizli-ca*.crt` kayıtları silinir (eski dosyayı kurma karışıklığı), yazım hatasında yarım kayıt geri alınır. Android kodu, DERLENMEDİ.
- Vekil `expect` tablosu en çok 1024 kayıt.
- Yeni "tarama" grubu (`SweepTests.kt`): 20 metin çözücüsü (kalıcı kayıtlar, içe aktarma kodu, listeler, kurallar) ve 11 ikili ayrıştırıcı (DNS iletisi, TLS/HTTP, QUIC, HPACK/Huffman, engelli liste, manifest, ODoH) rastgele, bozuk ve aşırı büyük girdilerle sınanır: çökme ve yavaşlama (ikinci dereceden/ReDoS) aranır. Hiçbirinde hata çıkmadı.
- İncelenen ve temiz bulunanlar: manifest (dışa açık bileşenler, izinler), PendingIntent bayrakları (hepsi IMMUTABLE), MainActivity intent güveni, ağ güvenlik yapılandırması, yedekleme kuralları, dosya okuma sınırları.
- Menü: Bağlantı sayfasından QUIC bölme, UDP yem ve ECH izni Deneysel'e taşındı (Bağlantı 15 → 12 satır); DNS sayfasındaki yinelenen "Site neden açılmıyor" satırı kaldırıldı (Süzgeç sayfasında var); Deneysel satırı günlük ayarların arasından Hakkında'nın bulunduğu karta alındı; Deneysel iki karta bölündü (ağ yöntemleri / tarayıcı kipi).
- Test düzeltmeleri: DoT şerit sınırı testi yük altında dalgalanıyordu (boşta kapanma süresi 400 → 1500 ms); ECH satır testi yeni bölüme bakıyor; CA bozma testi "kabul edilen kayıt işlevsel olarak özgün CA" kuralına çevrildi.

## oto-koruma 38 — sızma girişimi (kendi kendine saldırı), ağır testler, "Gelişmiş" katmanı
- Yeni "sizma" grubu (`SizmaTests.kt`) + MITM kırmızı takım testleri + ağ geçidi kaos testi. Saldırgan gözüyle yazıldı; 3 gerçek hata + küçük sorunlar bulundu ve kapatıldı:
  - **Günlük/rapor sahteciliği:** uzaktan gelen metin (ör. alan adı, sunucu mesajı) satır sonu/denetim karakteriyle günlüğe sahte satır uydurabiliyordu → `DiagLog.add` artık denetim ve biçim karakterlerini siler, satırları tek satıra indirir, 500 karakterle keser.
  - **Ad taklidi:** görünmez/yön değiştiren (bidi, sıfır genişlik) karakterli ya da benzer görünen adlar özel DNS adı doğrulamasını geçebiliyordu → `CustomDns` bu adları reddeder.
  - **Cihaz dili/takvimi CA üretimini bozuyordu:** Arapça/Tayca/Japonca gibi yerellerde `String.format`/`Calendar` yüzünden sertifika tarihi bozuluyordu → `Locale.ROOT`, `java.time`, `GregorianCalendar`. Aynı düzeltme DailyStats'a da uygulandı.
  - Küçükler: ODoH deterministik rastgele sayı üreteci yerine `SecureRandom`; DailyStats takvimi cihaz diline bağlıydı. İncelenip temiz çıkanlar: içe aktarma kodu (mitmOn/özel DNS/uygulamalar içe aktarılamaz), bölünmüş engel listesi eşleşmesi (harf, nokta, sonek, sıfır bayt, benzer ad).
- **Mutasyon doğrulaması:** günlük, ad ve yerel-dil düzeltmeleri geçici olarak geri alınınca 5 sızma kontrolü başarısız oldu (testler boş geçmiyor); düzeltmeler geri konuldu.
- **Ağ geçidi kaos testi:** tünele 180 bin bozuk/mutasyonlu paket (rastgele ham baytlar, kesik başlık, IHL seçenekleri, parça bayrakları, IPv6 uzantı zinciri/döngüsü, SYN seli, sahte ClientHello). Beklenen ve doğrulanan: yakalanmamış istisna yok, eşzamanlı akış ≤ 5000, bellek büyümesi < 200 MB, sayaçlar eksiye düşmez, saldırıdan sonra sağlıklı TCP akışı çalışır, `stop()` < 5 sn. Bulunan açık yok.
- **UI ("Gelişmiş" katmanı):** Ayarlar'ın sonunda "Gelişmiş ayarları göster" anahtarı (varsayılan KAPALI, yalnızca bu cihazda; dışa/içe aktarılmaz). Kapalıyken gizlenen teknik satırlar: Modülleri hatırla, ODoH, IP kipi, Sorun giderme, Tanılama, DNS rebind koruması, Sağlık, Otomatik en hızlı, Ağ değişince yenile, QUIC engeli, Durdurma/zaman aşımı/sessiz bildirimleri, Süzgeç listesi ve Deneysel satırları. Gizliyken ayarlar çalışmaya devam eder.
- Dürüst notlar: Android kodu (`platform/*`) yerelde DERLENMEDİ. CA Ad Kısıtı'nın Android'in kullanıcı CA'larında uygulanıp uygulanmadığı doğrulanmadı (JDK'da doğrulandı). Sertifikayı bir kez yeniden kurmak gerekir. Yeni YouTube/Reddit kozmetik seçicileri canlı sitelerde doğrulanmadı. Kişiselleştirme sayfasında zaten katlanır bölümler var, ayrıca sadeleştirilmedi.
- Testler: 12164 → 12232 kontrol, 0 başarısız.

## oto-koruma 39 — 3 kat ağır sızma turu: DPI, DNS, tarayıcı kipi vekili, QUIC; yeni özelliklerin hataları
- Yeni gruplar: `sizma2` (ağ geçidi suistimali: süzgeç atlatma, akış tablosu doldurma, TCP durum makinesi), `sizma3` (DPI özellik/özellik-rastgele testleri), `sizma4` (düşmanca DNS), `sizma5` (vekil + kozmetik), `sizma6` (yeni özellik hataları), `sizma7` (QUIC). Rastgele testler bağımsız "doğruluk kâhini" ile karşılaştırır (kendi koduyla kendini doğrulamaz).
- **DPI (3 katman):** her bölme yöntemi 4500 rastgele ClientHello ve 4500 rastgele HTTP isteğinde akışı bozmuyor (parçalar birleşince bayt bayt aynı, kayıt sınırları, SNI'sız/çok küçük/çok büyük/bozuk girdiler); gizlenmiş Host biçimleri her bölme yönteminden sonra da süzgece görünür; planlayıcı rastgele olay dizilerinde ve eşzamanlı kullanımda değişmezleri korur.
  - **Gerçek hata:** DPI planlayıcının belleği TLS ve HTTP için aynı ad anahtarını paylaşıyordu. HTTP'de öğrenilen yöntem (0–7) aynı sitenin TLS yöntemini (0–13) eziyor, HTTP'deki "tükendi" TLS'i düz aktarmaya düşürüyor, kesinti puanı yanlış türün yöntemini ilerletiyordu → anahtar türe göre ayrıldı (`first/failed/exhaust/isExhausted/cut/worked` + ağ geçidi çağrıları), aralık dışı yöntem numaraları okunmaz/içe aktarılmaz.
- **DNS (düşmanca cevaplar):**
  - **Süzgeç atlatma:** izleyici sahibi CNAME zincirini uzatarak (ya da başa sahte A kayıtları koyarak) engeli atlatabiliyordu → CNAME zinciri 32 adıma kadar tam izlenir, 32'den uzun zincir (gerçek çözücü üretmez) güvenli tarafta engellenir; HTTPS/SVCB TargetName arkasına saklanma da yakalanır. Rebind'de çok sayıda genel adres + sonda yerel adres artık yerel adresi kaçırmaz.
  - `Dns.cacheTtl`: 2^31−1 (geçerli TTL) "kayıt yok" işaretiyle karışıp 0 dönüyordu → ayrı bayrak.
  - 7500 rastgele geçerli cevap bağımsız kâhinle birebir; yapı-bilinçli bozuk cevaplarda (sayaç, uzunluk, işaretçi, etiket türü, kesme) ayrıştırıcılar istisna fırlatmaz.
- **Tarayıcı kipi vekili (MITM):**
  - chunked gövde çözümü ikinci dereceydi: 1 baytlık parçalarla 4 MB, dakikalarca işlemci yakardı → doğrusal. Boyut satırı en çok 256 bayt (satır sonu göndermeyen sunucu bellek şişiremez).
  - Akış sonu tespiti okuma sınırlarından bağımsız: veri içindeki `0\r\n\r\n` akışı erken kesmez; Transfer-Encoding + Content-Length birlikte gelince kısa Content-Length'te kesilmez.
  - Kesik HTML gövdesi (EOF < Content-Length) artık yeniden yazılmış Content-Length'le "tam sayfa" gibi verilmez; hata sayılır.
  - Yuva tutma (slowloris): kural alanı başına en çok 72 eşzamanlı bağlantı, HTML gövdesi için toplam 60 sn süre; başka alan etkilenmez.
  - `<style>` enjeksiyonu: betik, yorum, `<title>`/`<textarea>` içindeki `</head>`'e ve tırnaklı özniteliğin içindeki `>`'e ("`<body data-x="a>b">`") yanılmaz; CSP `style-src` nonce'u doğru başlıktan seçilir.
  - Kozmetik kurallar: dengesiz seçici (açık tırnak, açık `[`/`(`, çapraz kapanış) aynı alanın sonraki kurallarını yutuyordu → reddedilir; 9000 rastgele seçici kümesinde üretilen CSS her zaman iyi biçimli.
- **QUIC:** iki CRYPTO çerçevesi aynı ofsete farklı bayt koyarsa (ilkine gerçek adı, sonuncuya zararsız adı) sunucunun hangisini seçeceği bilinemezdi; biz "son gelen"i alıyorduk → çakışan farklı baytlar artık belirsiz sayılır ve akış düşürülür (özdeş yeniden gönderim ve ters sıra normal çalışır). 1200 yapı-bilinçli rastgele Initial (DCID/SCID/PN uzunluğu, çerçeve bölme/sıra/dolgu, artçı paket) ve 9000 rastgele çerçeve kümesi bağımsız referansla birebir.
- **Yeni özelliklerdeki hatalar:**
  - DNS yarışı anahtarı bağlıyken servise iletilmiyordu (yeniden bağlanmak gerekiyordu) → `connectionChanged` kapsamına alındı.
  - "Otomatik DPI" kapatılsa bile DPI-önlemi etkin kaldıkça açık kalıyordu → `dpiWanted` (kullanıcı DPI'sı açıksa her zaman; yoksa yalnızca Otomatik DPI açık VE önlem etkinse). Otomatik DPI anahtarı değişince modüller çalışan ağ geçidine canlı uygulanır.
- **Mutasyon doğrulaması:** 12 düzeltme (planlayıcı türü, CNAME tarama/zincir sınırı, alan başı sınır, gövde süresi, `tagEnd`, kesik gövde, chunk satır sınırı, `balanced`, QUIC çakışması, `dpiWanted`, DNS yarışı canlı uygulama) geçici geri alınınca ilgili testler başarısız oldu. İlk turda chunk satır sınırı ve gövde süresi yakalanmadı → iki test eklendi (50 MB satır sonsuz akışta ≤ 64 KB okunur; 0,6 sn süreli damla damla gövde ≤ 2,5 sn'de bırakılır), yeniden geri alınınca yakalandı. Hepsi geri konuldu.
- **Bilinen sınırlar / dürüst notlar:**
  - Android kodu (`platform/*`) yerelde DERLENMEDİ (`DnsVpnService.kt` içindeki `dpiWanted` çağrısı dahil). Ad Kısıtlı CA'nın Android'de uygulandığı, kozmetik seçicilerin canlı sitelerde çalıştığı doğrulanmadı; CA bir kez yeniden kurulmalı.
  - Akış tahliyesi (evict), akışlarını taze tutan ya da sunucuyu elinde tutan saldırganı durduramaz; yalnızca sessiz akışları atar.
  - Tarayıcı kipinde ardışık (pipelined) ikinci HTTP isteği ve h2c incelenmez; QUIC SNI yalnızca akışın ilk paketinde okunur (aynı 4'lü yeniden kullanımı/birleşik bağlantılar için doğal sınır).
  - Otomatik DPI yalnızca ağ geçidi çalışırken etkilidir; DPI sağlık vanası otomatik DPI'yı izlemez. CGNAT 100.64/10 bilerek rebind sayılmaz.
  - Kapalı-güvenli (fail-closed) davranışlar artık şunlarda: inceleme açıkken ≥3 sn tamamlanmayan ilk uçuş, >16 KB başlık, >32 adım CNAME, belirsiz QUIC CRYPTO çakışması, alan başı 72'i aşan vekil bağlantısı, kesik/zaman aşımına uğrayan HTML gövdesi (hata verir, sessizce kısa sayfa vermez).
- Eski iki test bilerek değişen davranışa göre güncellendi: CNAME "8 adım ötesine bakılmaz" (artık 9. adımdaki engelli hedef de yakalanır) ve "60 eşzamanlı istemci tek alanda" (alan başı 72 sınırının altında, 68 istemci).
- Testler: 12232 → 12418 kontrol, 0 başarısız (tam paket, 436 sn).
