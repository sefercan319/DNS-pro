package app.dnshizli.ui

import app.dnshizli.core.CustomPalette
import app.dnshizli.core.SavedStyles
import app.dnshizli.core.FxParts
import app.dnshizli.core.SoundParts
import app.dnshizli.core.UsageTotals
import app.dnshizli.core.SoundBlock
import app.dnshizli.core.SoundOutput
import app.dnshizli.core.AppEntry
import app.dnshizli.core.FilterLive
import app.dnshizli.core.lightEffective
import app.dnshizli.core.FxSlot
import app.dnshizli.core.HostsList
import app.dnshizli.core.FilterNames
import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.FilterVerdict
import app.dnshizli.core.SiteCause
import app.dnshizli.core.SiteCheck
import app.dnshizli.core.YouTubeAds
import app.dnshizli.core.NetCheck
import app.dnshizli.core.ResultsText
import app.dnshizli.core.ServerSearch
import app.dnshizli.core.AppScope
import app.dnshizli.core.AppSettings
import app.dnshizli.core.Catalog
import app.dnshizli.core.CustomDns
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Format
import app.dnshizli.core.ImportReview
import app.dnshizli.core.Latency
import app.dnshizli.core.LatencyHistory
import app.dnshizli.core.HapticLevel
import app.dnshizli.core.LiquidColors
import app.dnshizli.core.OrbShape
import app.dnshizli.core.OrbFlow
import app.dnshizli.core.FxVariants
import app.dnshizli.core.OrbShapes
import app.dnshizli.core.OrbState
import app.dnshizli.core.Profiles
import app.dnshizli.core.Sfx
import app.dnshizli.core.Look
import app.dnshizli.core.LookPreset
import app.dnshizli.core.Synth
import app.dnshizli.core.Voice
import app.dnshizli.core.Proto
import app.dnshizli.core.WpBlur
import app.dnshizli.core.UiStyle
import app.dnshizli.core.Pic
import app.dnshizli.core.SelfTestResult
import app.dnshizli.core.ServerList
import app.dnshizli.core.SettingsCodec
import app.dnshizli.core.SortMode
import app.dnshizli.core.Tag
import app.dnshizli.core.Themes

/** Liste süzgeçleri (üstteki çipler). Etiketleri etkin dilden okunur. [id] ayarda saklanır. */
enum class Filter(val tag: Tag?) {
    ALL(null),
    FAVORITES(null),
    RECENT(null),
    FAST(Tag.FAST),
    PRIVACY(Tag.PRIVACY),
    ADS(Tag.ADS),
    FAMILY(Tag.FAMILY),
    SECURITY(Tag.SECURITY),
    ENCRYPTED(null),
    UNFILTERED(null);

    val id: String get() = name.lowercase()

    val label: String get() = when (this) {
        ALL -> Strings.FILTER_ALL
        FAVORITES -> Strings.FILTER_FAV
        RECENT -> Strings.FILTER_RECENT
        ENCRYPTED -> Strings.FILTER_ENCRYPTED
        UNFILTERED -> Strings.FILTER_UNFILTERED
        else -> tag!!.label
    }

    /** Etiket dışı ek koşul (şifreli / filtresiz). */
    val extra: ((DnsServer) -> Boolean)? get() = when (this) {
        ENCRYPTED -> ServerList::encrypted
        UNFILTERED -> ServerList::unfiltered
        else -> null
    }

    companion object {
        fun byId(id: String?): Filter = values().firstOrNull { it.id == id } ?: ALL
    }
}

/** Arayüzün gördüğü VPN durumu. Servis bunu üretir, etkinlik modele iletir. */
data class VpnUi(
    val state: OrbState = OrbState.OFF,
    val serverId: String? = null,
    val sinceMs: Long = 0L,
    val queries: Long = 0L,
    val cacheHits: Long = 0L,
    val avgMs: Int = 0,
    val error: String? = null,
    val onBackup: Boolean = false,
    /** Kullanılan taşıma yöntemi (bağlıyken). */
    val proto: Proto? = null,
    val blocked: Long = 0L,
    /** Kısa süreli duraklatma bitiş zamanı (epoch ms); 0 ise duraklatılmamış. */
    val pausedUntil: Long = 0L,
    /** Otomatik şifrelemede şifreli yöntem kurulamadı, şifresiz DNS kullanılıyor. */
    val downgraded: Boolean = false,
    /** Bağlantı koptu, servis kendiliğinden yeniden deniyor. */
    val retrying: Boolean = false,
    /** Hata olmayan tek seferlik bilgi (ör. "yedek sunucuya bağlanıldı"); arayüz bir kez gösterir. */
    val info: String? = null,
    /** Tünel açık ama DNS bağlı değil: yalnızca ağ geçidi modülleri (DPI atlatma / Reklam+) çalışıyor. */
    val gwOnly: Boolean = false,
    /** Ağ geçidi (kullanıcı alanı aktarıcı) çalışıyor mu, kaç bağlantı engelledi / bölündü. */
    val gwActive: Boolean = false,
    val gwDpi: Boolean = false,
    val gwAds: Boolean = false,
    val gwBlocked: Long = 0L,
    val gwSplit: Long = 0L,
    /** Servis, bağlantı sorunu yüzünden modülleri kendisi kapattı. */
    val gwTripped: Boolean = false,
) {
    val active: Boolean get() = state == OrbState.ON || state == OrbState.CONNECTING
}

/** Geçici kısa mesaj (alt kısımda cam hap). [action] doluysa yanında dokunulabilir bir eylem olur. */
class ToastMsg(val text: String, val action: String? = null, val onAction: (() -> Unit)? = null)

/**
 * Platformun (Android) arayüze sunduğu yetenekler. Testlerde sahte bir uygulaması kullanılır.
 * Tüm çağrılar ve [AppModel]'in tüm metotları ana (arayüz) iş parçacığında çalışır.
 */
interface Host {
    /** [serverId] sunucusuna bağlan; zaten bağlıysa tüneli koparmadan sunucuyu değiştir. Durum [AppModel.onVpn] ile döner. */
    fun connect(serverId: String)
    fun disconnect()

    /**
     * Ağ geçidi modüllerinin (DPI atlatma, Reklam+) istenen durumunu servise ilet. Tünel yoksa yalnızca modüller başlar;
     * sistem VPN izni gerekiyorsa sorulur, verilmezse [onFail] çağrılır. Durum [AppModel.onVpn] ile döner.
     */
    fun applyModules(dpi: Boolean, ads: Boolean, onFail: () -> Unit) {}

    /** Yalnızca DNS bağlantısını durdur; çalışan modüller sürer. */
    fun disconnectDns() { disconnect() }

    /** Bağlantıyı [minutes] dakika duraklat; süre bitince servis kendiliğinden yeniden bağlanır. */
    fun pause(minutes: Int)

    /** Duraklatmayı bitir ve hemen yeniden bağlan. */
    fun resume()

    /** Bağlıyken servisteki DNS önbelleğini boşalt. */
    fun clearCache()

    /** Listedeki sunucuların gecikmesini arka planda ölç; her sonuç [AppModel.onLatency], bitiş [AppModel.onMeasureDone] ile döner. */
    fun measure(serverIds: List<String>)

    fun saveSettings(s: AppSettings)

    /** Başlatıcıda görünen uygulamaları arka planda listele; sonuç (ada göre sıralı) ana iş parçacığında [onDone] ile gelir. */
    fun loadApps(onDone: (List<AppEntry>) -> Unit)

    /** Bağlıyken uygulama seçimini uygulamak için tüneli aynı sunucuyla yeniden kur. */
    fun applyApps()

    /**
     * Özel DNS ekleme penceresini göster. Kullanıcı "Ekle"ye basınca [validate] hata metni döndürürse pencere
     * açık kalıp metni gösterir; null dönerse kapanır ve [onDone] çağrılır.
     */
    fun promptCustomServer(validate: (CustomDns.Draft) -> String?, initial: CustomDns.Draft?, onDone: (CustomDns.Draft) -> Unit)
    fun saveLatencies(m: Map<String, Latency>)
    fun saveHistory(h: Map<String, List<Int?>>)

    /** Servisin yazdığı toplam istatistikleri ve günlük sayıları sıfırla. */
    fun resetTotals()
    fun copyText(text: String)
    fun readClipboard(): String?
    fun shareText(text: String)
    fun shareApp()
    fun rateApp()
    fun haptic(strong: Boolean)

    /**
     * Olaya özgü titreşim deseni: [pulses] kaç vuruş, [gapMs] vuruşlar arası ms, [strong] güçlü mü. İzin gerektirmez
     * (sistemin dokunsal geri bildirimi); sistem dokunmatik titreşimi kapalıysa hiçbir şey olmaz.
     */
    fun hapticPattern(pulses: Int, gapMs: Int, strong: Boolean) { haptic(strong) }

    /** Ses efekti çal. [volume] 0..1 efektin genliğidir. Sistem sessizdeyse ya da kısıksa çalmaz. */
    fun playSound(e: Sfx, voice: Voice, volume: Float) {}

    /**
     * Ses efektini [output] kanalından çal. Ses durumu yüzünden (telefon sessiz, seviye sıfır) çalınmayacaksa nedenini döner;
     * "Sesi dene" bunu kullanıcıya açıklar. Varsayılan: eski [playSound].
     */
    fun playSoundRouted(e: Sfx, voice: Voice, volume: Float, output: SoundOutput): SoundBlock { playSound(e, voice, volume); return SoundBlock.NONE }

    /** Ses parçasıyla çal ([SoundParts]). Varsayılan: parçanın tınısıyla eski yol (platform parça desteklemiyorsa). */
    fun playSoundPart(e: Sfx, part: Int, volume: Float, output: SoundOutput): SoundBlock =
        playSoundRouted(e, SoundParts.voice(part), volume, output)

    /** Ses önbelleğini bırak (tını değişince ya da uygulama kapanırken). */
    fun releaseSounds() {}
    fun openVpnSettings()

    /** Ayardaki dili ("auto" ya da kod) uygula (Android 13+ sistemin uygulama dili ayarıyla eşitlenir). */
    fun applyLanguage(setting: String)
    fun diagnostics(): String
    fun clearDiagnostics()
    fun versionName(): String
    fun now(): Long
    fun requestFrame()

    /** Son sorguların cevap süreleri (ms; -1 = zaman aşımı), eskiden yeniye, [out]'a yazılır; yazılan sayıyı döner. Bağlı değilse 0. */
    fun latencies(out: IntArray): Int = 0

    /** İçe aktarılan engel listesi (cihazda, ayarların dışında): ad sayısı, okuma ve yazma. */
    fun importedCount(): Int = 0
    fun loadImported(): List<String> = emptyList()
    fun saveImported(names: List<String>): Boolean = false

    /** Sistemin dosya seçicisini aç; seçilen metin dosyasının içeriği [onDone] ile gelir (okunamazsa null, vazgeçilirse hiç çağrılmaz). */
    fun pickTextFile(onDone: (String?) -> Unit) {}

    /** Android 13+ bildirim izni verilmiş mi (eskilerde bildirimler açık mı); sistem bildirim ayarlarını aç. */
    fun notificationsAllowed(): Boolean = true
    fun openNotificationSettings() {}

    /** Cihazın yerel saatine göre saat (0..23); "gece temasını saate bağla" kullanır. */
    fun localHour(): Int {
        val c = java.util.Calendar.getInstance()
        c.timeInMillis = now()
        return c.get(java.util.Calendar.HOUR_OF_DAY)
    }

    /** Sistem galerisinden arka plan fotoğrafı seçtir; sonuç [AppModel.onWallpaperPicked] ile döner. */
    fun pickWallpaper()

    /** Uygulamayla gelen hazır görselin [index]'ini arka plan yap; sonuç [AppModel.onWallpaperPicked] ile döner. */
    fun usePresetWallpaper(index: Int)

    /** Kayıtlı arka plan fotoğrafını sil. */
    fun removeWallpaper()

    /**
     * Kayıtlı fotoğrafı [blur] düzeyiyle arka planda yükle; ana iş parçacığında [onDone] ile gelir.
     * Dosya yoksa ya da bozuksa null. Dönen [Pic]'in sahibi çağıran olur (işi bitince [Pic.release]).
     */
    fun loadWallpaper(blur: WpBlur, onDone: (Pic?) -> Unit)

    /** Başlatıcıdaki uygulama simgesini [style] simgesiyle değiştir. Başarılıysa true. */
    fun setAppIcon(style: UiStyle): Boolean

    /** Sorun gidericinin okuduğu telefon durumu (VPN izni, internet, başka VPN, Android Özel DNS). Hızlıdır, ana iş parçacığında çağrılır. */
    fun networkCheck(): NetCheck

    /** Tek satırlık metin girişi penceresi; boş sonuç "temizle" demektir. */
    fun promptText(title: String, hint: String, initial: String, maxLen: Int = app.dnshizli.core.ServerSearch.MAX, okLabel: String? = null, onDone: (String) -> Unit)

    /** Bağlıyken bağlantı testini başlat; sonuç [AppModel.onTestResult] ile döner. */
    fun runTest()

    /** Bağlıyken değişen bağlantı ayarlarını (şifreleme, önbellek, kurallar) hemen uygula. */
    fun reapply()

    /** Uygulama simgesinin kısayollarını favorilerle güncelle (Android 7.1+ dinamik kısayollar). */
    fun updateShortcuts(serverIds: List<String>)

    /** Android 12+ duvar kağıdından gelen vurgu rengi (dinamik tema için); yoksa null. */
    fun systemAccent(): Int?

    /** Sistem pil ayarlarını aç. */
    fun openBatterySettings()

    /** Telefonda titreşim motoru var mı? Yoksa titreşim ayarı gösterilmez. */
    fun hasVibrator(): Boolean = true

    /** Uygulama pil optimizasyonu ile kısıtlanıyor mu? Bilinmiyorsa null. */
    fun batteryRestricted(): Boolean?

    /** Kişisel (kendi kullanımın için) derleme mi? Play sürümünde false: isteğe bağlı kişisel özellikler gizlenir. */
    fun personalBuild(): Boolean = false

    /** Tanılama raporu için cihaz bilgisi (varsayılanlar bilinmeyen değerdir). */
    fun appVersion(): Pair<String, Int> = "?" to 0
    fun deviceModel(): String = "?"
    fun androidSdk(): Int = 0
    fun networkKind(): String = "?"
    /** Kayıtlı çökme özetleri (en yeni başta). Yalnızca tanılama raporu için. */
    fun crashes(): List<String> = emptyList()
}

/**
 * Uygulamanın tüm durumu ve kuralları. Arayüzden bağımsızdır: dokunma eylemleri burada anlam kazanır,
 * sahne yalnızca [version] değişince kendini günceller. Bu sayede her şey JVM'de test edilebilir.
 */
class AppModel(
    val host: Host,
    settings: AppSettings,
    latencies: Map<String, Latency> = emptyMap(),
    history: Map<String, List<Int?>> = emptyMap(),
) {
    var settings: AppSettings = settings
        private set
    var vpn: VpnUi = VpnUi()
        private set
    val latencies: MutableMap<String, Latency> = LinkedHashMap(latencies)
    var history: Map<String, List<Int?>> = history
        private set
    var filter: Filter = Filter.ALL
        private set
    var measuring: Boolean = false
        private set
    var consentOpen: Boolean = false
        private set
    var toast: ToastMsg? = null
        private set
    var testing: Boolean = false
        private set
    var testResult: SelfTestResult? = null
        private set

    /** Yeni bir test sonucu geldiğinde artar: sahne sonucu panelde gösterir. */
    var testSeq: Int = 0
        private set

    /** "Neler yeni" sayfasını açma isteği (sahne izler). */
    var whatsNewSeq: Int = 0
        private set

    /** Duvar kağıdı rengi (dinamik tema için); platform yapılandırma değişince günceller. */
    var accentSeed: Int? = null
        private set

    /** Şu an gösterilen temanın kimliği (otomatik tema çözüldükten sonra). Sahne yazar; şekil seçimi bunu kullanır. */
    var shownThemeId: String = Themes.aqua.id

    /** [themeId] temasının ana düğme şekli (kaydı yoksa küre). */
    fun orbShapeFor(themeId: String): OrbShape = OrbShapes.get(settings.orbShapes, themeId)

    /** [themeId] temasının ana düğme şeklini [shape] yapar. */
    fun setOrbFlow(f: OrbFlow) {
        update { it.copy(orbFlow = f) }
        sfx(Sfx.TAP)
    }

    /** Aktif stil için dokunma efekti varyantı ([FxVariants]). */
    /** Özel temayı ayarlar; tema "custom" olur. [sky] ve [accent] dizinleri [CustomPalette] listeleridir. */
    fun setCustomTheme(sky: Int, accent: Int) {
        val cur = CustomPalette.decode(settings.customTheme) ?: (CustomPalette.DEFAULT_SKY to CustomPalette.DEFAULT_ACCENT)
        val next = CustomPalette.encode(sky.coerceIn(0, CustomPalette.skies.size - 1), accent.coerceIn(0, CustomPalette.accents.size - 1))
        update { it.copy(customTheme = next, theme = Themes.CUSTOM_ID) }
        if (cur.first == sky && cur.second == accent) return
        sfx(Sfx.TAP)
    }

    /** Animasyon parçasını seçer ([FxParts]); geçersiz dizin -1 (stilin kendi animasyonu) olur. */
    fun setFxPart(i: Int) {
        val next = if (FxParts.valid(i)) i else -1
        if (settings.fxPart == next) return
        update { it.copy(fxPart = next) }
        sfx(Sfx.TAP)
    }

    /** Mevcut kendi stilimi [slot] yuvasına kaydeder (0..[SavedStyles.MAX] - 1). */
    fun saveOwnStyle(slot: Int) {
        if (slot !in 0 until SavedStyles.MAX) return
        update { s ->
            val list = MutableList(SavedStyles.MAX) { s.savedStyles.getOrNull(it) ?: "" }
            list[slot] = SavedStyles.snapshot(s)
            s.copy(savedStyles = SavedStyles.canon(list))
        }
        sfx(Sfx.TAP)
    }

    /** Yuvadaki kayıtlı stili uygular. Boş yuvada hiçbir şey olmaz. */
    fun applyOwnStyle(slot: Int) {
        val p = settings.savedStyles.getOrNull(slot)?.let { SavedStyles.parse(it) } ?: return
        update { SavedStyles.apply(it, p) }
        previewSound()
    }

    /** Yuvadaki kaydı siler; yuva boşalır. */
    fun deleteOwnStyle(slot: Int) {
        update { s -> s.copy(savedStyles = SavedStyles.canon(MutableList(SavedStyles.MAX) { s.savedStyles.getOrNull(it) ?: "" }.also { if (slot in 0 until SavedStyles.MAX) it[slot] = "" })) }
    }

    fun setFxVariant(v: Int) {
        update { it.copy(fxVariants = FxVariants.with(it.fxVariants, it.style, v)) }
        sfx(Sfx.TAP)
    }

    fun setOrbShape(themeId: String, shape: OrbShape) {
        update { it.copy(orbShapes = OrbShapes.with(it.orbShapes, themeId, shape)) }
        sfx(Sfx.TAP)
    }

    /** Sıvının çizim rengi (opak ARGB); 0 = temanın kendi rengi. */
    val liquidColorArgb: Int get() = LiquidColors.argb(settings.liquidColor)

    /** Sıvı rengini [hex] yapar ("" = temanın rengi). */
    fun setLiquidColor(hex: String) {
        update { it.copy(liquidColor = LiquidColors.clean(hex)) }
        sfx(Sfx.TAP)
    }

    /** Her görünür değişimde artar; sahne bunu izleyip yeniden kurulur. */
    var version: Int = 0
        private set

    /** Her yeni geçici mesajda artar. */
    var toastSeq: Int = 0
        private set

    /** Dil değişince artar: sahne bütün sayfaları yeni dilde yeniden kurar. */
    var langSeq: Int = 0
        private set

    private var pendingConnect: String? = null
    private var measureRemaining = 0
    private var measureStart = 0L

    /** Bağlıyken istenen ama platformun henüz bildirmediği geçiş hedefi: çift dokunmada ikinci çağrıyı eler. */
    private var switchingTo: String? = null
    private var switchAt = 0L

    private var started = false

    init {
        if (settings.rememberFilter) filter = Filter.byId(settings.lastFilter)
        accentSeed = host.systemAccent()
    }

    private fun bump() { version++; host.requestFrame() }

    // ------------------------------------------------------------------ okuma

    fun selectedId(): String = settings.lastServer ?: Catalog.DEFAULT_ID

    fun server(id: String?): DnsServer? = id?.let { Catalog.byId(it) }

    fun nameOf(id: String?): String = server(id)?.name ?: Catalog.default.name

    /** Şu an bağlı (veya bağlanmakta) sunucunun kimliği; yoksa null. */
    fun connectedId(): String? = if (vpn.active) (vpn.serverId ?: selectedId()) else null

    /** Duraklatma sürüyor mu (süre bitmiş ama servis henüz yeniden bağlanmamış olabilir)? */
    val paused: Boolean get() = !vpn.active && vpn.pausedUntil != 0L

    /** Duraklatma süresi doldu, servisin yeniden bağlanması bekleniyor. */
    val resuming: Boolean get() = paused && vpn.pausedUntil <= host.now()

    /** Seçili şifreleme tercihiyle bu sunucuya bağlanılabilir mi? */
    fun canUse(s: DnsServer): Boolean = settings.plan(s).isNotEmpty()

    /** Sade görünümde süzgeçler gizlidir: liste hep "Tümü"dür. */
    val effectiveFilter: Filter get() = if (settings.minimal) Filter.ALL else filter

    /** Sunucu araması (yalnızca oturum boyunca tutulur, kaydedilmez). Sade görünümde süzgeçler gibi gizlidir. */
    var query: String = ""
        private set

    val effectiveQuery: String get() = if (settings.minimal) "" else query

    fun setQuery(q: String) {
        val c = ServerSearch.clean(q)
        if (c == query) return
        query = c
        bump()
    }

    /** Arama penceresini açar; boş girdi aramayı temizler. */
    fun promptSearch() = host.promptText(Strings.SEARCH, Strings.SEARCH_HINT, query) { setQuery(it) }

    /** Ölçüm sonuçlarını (en hızlıdan) metin olarak paylaşır; ölçüm yoksa uyarır. */
    fun shareResults() {
        val text = ResultsText.build(Strings.SHARE_RESULTS_HEAD, Catalog.all, latencies)
        if (text == null) { toast(Strings.NO_RESULTS); return }
        host.shareText(text)
    }

    fun visibleServers(): List<DnsServer> {
        val filter = effectiveFilter
        val base = when (filter) {
            Filter.FAVORITES -> Catalog.all.filter { it.id in settings.favorites }
            Filter.RECENT -> settings.recent.mapNotNull { Catalog.byId(it) }
            else -> Catalog.all
        }
        val q = effectiveQuery
        if (filter == Filter.RECENT) return ServerSearch.filter(base.filter { it.id !in settings.hidden }, q)   // son kullanım sırası korunur
        return ServerSearch.filter(ServerList.visible(base, filter.tag, settings.favorites, latencies, settings.sortMode, settings.hidden, filter.extra), q)
    }

    // ------------------------------------------------------------------ uzun liste: ilk sunucular + "Tümünü göster"

    /** Liste açık mı (yalnızca bu oturumda; kaydedilmez). */
    var listExpanded: Boolean = false
        private set

    /** Liste, kısaltılacak kadar uzun mu? En az [LIST_MIN_HIDDEN] sunucu gizlenecekse kısaltılır (tek sunucu için düğme gereksiz). */
    fun listCollapsible(): Boolean = visibleServers().size >= LIST_LIMIT + LIST_MIN_HIDDEN

    /** Ekranda gösterilecek sunucular: kısaltılabilir ve kapalıysa ilk [LIST_LIMIT]. */
    fun shownServers(): List<DnsServer> {
        val all = visibleServers()
        return if (!listExpanded && all.size >= LIST_LIMIT + LIST_MIN_HIDDEN) all.subList(0, LIST_LIMIT) else all
    }

    fun toggleList() { listExpanded = !listExpanded; bump() }

    /** Özel sunucu ekleme penceresini açar. */
    fun promptCustom() {
        host.promptCustomServer({ d -> CustomDns.validate(d, Catalog.custom.size)?.let { customErrorText(it) } }, null) { commitCustom(it) }
    }

    fun customErrorText(e: CustomDns.Error): String = when (e) {
        CustomDns.Error.NAME -> Strings.CUSTOM_ERR_NAME
        CustomDns.Error.IP, CustomDns.Error.IP2 -> Strings.CUSTOM_ERR_IP
        CustomDns.Error.DOT -> Strings.CUSTOM_ERR_DOT
        CustomDns.Error.DOH -> Strings.CUSTOM_ERR_DOH
        CustomDns.Error.LIMIT -> Strings.CUSTOM_ERR_LIMIT
    }

    /** Doğrulanmış girdiyi özel sunucu olarak kaydeder (geçersizse hiçbir şey yapmaz). */
    fun commitCustom(d: CustomDns.Draft) {
        if (CustomDns.validate(d, Catalog.custom.size) != null) return
        val s = CustomDns.build(CustomDns.newId(host.now(), Catalog.all.map { it.id }), d)
        val list = Catalog.custom + s
        Catalog.setCustom(list)
        update { it.copy(custom = CustomDns.encode(list)) }
        toast(Strings.customAdded(s.name))
    }

    /** Özel sunucunun bilgilerini düzenleme penceresini açar (bağlıyken düzenlenmez). */
    fun editCustom(id: String) {
        val s = Catalog.custom.firstOrNull { it.id == id } ?: return
        if (connectedId() == id) { toast(Strings.CUSTOM_IN_USE); return }
        val cur = CustomDns.Draft(s.brand, s.primary, s.secondary ?: "", s.dot ?: "", s.doh ?: "")
        host.promptCustomServer({ d -> CustomDns.validate(d, Catalog.custom.size - 1)?.let { customErrorText(it) } }, cur) { commitEdit(id, it) }
    }

    /** Doğrulanmış girdiyi aynı kimlikle kaydeder; adresler değiştiği için eski ölçümler silinir. */
    fun commitEdit(id: String, d: CustomDns.Draft) {
        if (Catalog.custom.none { it.id == id } || connectedId() == id) return
        if (CustomDns.validate(d, Catalog.custom.size - 1) != null) return
        val s = CustomDns.build(id, d)
        val list = Catalog.custom.map { if (it.id == id) s else it }
        Catalog.setCustom(list)
        update { it.copy(custom = CustomDns.encode(list)) }
        latencies.remove(id)
        history = history - id
        host.saveLatencies(latencies)
        host.saveHistory(history)
        toast(Strings.customUpdated(s.name))
    }

    /** Özel sunucuyu siler ve ona bağlı tüm seçimleri (favori, kural, yedek, ölçümler) temizler. Bağlıyken silinmez. */
    fun removeCustom(id: String): Boolean {
        val s = Catalog.custom.firstOrNull { it.id == id } ?: return false
        if (connectedId() == id) { toast(Strings.CUSTOM_IN_USE); return false }
        val list = Catalog.custom.filter { it.id != id }
        Catalog.setCustom(list)
        update {
            it.copy(
                custom = CustomDns.encode(list),
                favorites = it.favorites - id, hidden = it.hidden - id, recent = it.recent.filter { r -> r != id },
                lastServer = it.lastServer.takeIf { l -> l != id },
                wifiServer = it.wifiServer.takeIf { w -> w != id }, mobileServer = it.mobileServer.takeIf { m -> m != id },
                backupServer = it.backupServer.takeIf { b -> b != id },
            )
        }
        latencies.remove(id)
        history = history - id
        host.saveLatencies(latencies)
        host.saveHistory(history)
        host.updateShortcuts(Catalog.all.filter { it.id in settings.favorites }.map { it.id })
        toast(Strings.customDeleted(s.name))
        return true
    }

    fun hiddenServers(): List<DnsServer> = Catalog.all.filter { it.id in settings.hidden }

    fun statusTitle(): String = when {
        paused -> Strings.PAUSED
        else -> when (vpn.state) {
            OrbState.OFF -> Strings.OFF
            OrbState.CONNECTING -> Strings.CONNECTING
            OrbState.ON -> Strings.ON
            OrbState.ERROR -> Strings.ERROR
        }
    }

    fun statusSub(): String {
        if (resuming) return Strings.RESUMING
        if (paused) return Strings.pausedUntil(Format.hm(vpn.pausedUntil))
        return when (vpn.state) {
            OrbState.OFF -> if (vpn.gwOnly) (modulesLine()?.let { Strings.gwOn(it) } ?: Strings.selected(nameOf(selectedId()))) else Strings.selected(nameOf(selectedId()))
            OrbState.CONNECTING -> nameOf(vpn.serverId ?: selectedId())
            OrbState.ON -> Strings.onLine(nameOf(vpn.serverId ?: selectedId()), vpn.proto?.let { Strings.protoName(it) }, vpn.avgMs.takeIf { it > 0 })
            OrbState.ERROR -> vpn.error ?: Strings.ERR_DEFAULT
        }
    }

    fun statusHint(): String {
        if (paused) return Strings.HINT_PAUSED
        return when (vpn.state) {
            OrbState.OFF -> {
                // Bugün sorgu yapıldıysa rehber metni yerine günlük özet; yoksa ilk kullanım ipucu.
                val today = if (settings.minimal) 0L
                else app.dnshizli.core.DailyStats.decode(settings.daily)[app.dnshizli.core.DailyStats.today(host.now())] ?: 0L
                if (today > 0) Strings.todayLine(today) else Strings.HINT_OFF
            }
            OrbState.CONNECTING -> if (vpn.retrying) Strings.NOTIF_RETRYING else Strings.HINT_CONNECTING
            OrbState.ON -> {
                val secs = ((host.now() - vpn.sinceMs) / 1000).coerceAtLeast(0)
                if (settings.minimal) Format.clock(secs)
                else {
                    val pct = if (vpn.queries > 0) (vpn.cacheHits * 100 / vpn.queries).toInt().coerceIn(0, 100) else 0
                    Strings.statsLine(secs, vpn.queries, pct, vpn.blocked)
                }
            }
            OrbState.ERROR -> Strings.HINT_ERROR
        }
    }

    // ------------------------------------------------------------------ ses, titreşim, kutlama (Aşama 24)

    /** Her başarılı bağlanışta artar; kürenin kutlama animasyonu bunu izler. */
    var celebrateSeq = 0
        private set
    private var vpnSeen = false

    /** Ses paketi animasyonu tetikleyicisi: her olayda artar, [packFxSlot] hangisinin çizileceğini söyler (Scene izler). */
    var packFxSeq = 0
        private set
    var packFxSlot = FxSlot.CONNECT
        private set

    /** Olayın paket animasyonu yuvası; animasyonu olmayan olaylar (geri, panel, dokunuş) null. */
    private fun slotOf(e: Sfx): FxSlot? = when (e) {
        Sfx.TOGGLE_ON, Sfx.TOGGLE_OFF -> FxSlot.TOGGLE
        Sfx.CONNECT -> FxSlot.CONNECT
        Sfx.DISCONNECT -> FxSlot.DISCONNECT
        Sfx.ERROR -> FxSlot.ERROR
        Sfx.DONE -> FxSlot.DONE
        Sfx.SHEET -> FxSlot.SHEET
        Sfx.BACK -> FxSlot.BACK
        Sfx.SELECT -> FxSlot.SELECT
        Sfx.REFRESH -> FxSlot.REFRESH
        else -> null
    }

    /** Ses efekti çal (ayarlar, sessiz saatler ve grup anahtarları uygunsa). Animasyon tetikleyicisi sesten bağımsızdır. */
    fun sfx(e: Sfx) {
        val s = settings
        val slot = slotOf(e)
        if (slot != null && s.soundPack.animated) { packFxSlot = slot; packFxSeq++ }
        if (!s.soundAllowed(host.localHour())) return
        if (e.isConnection) { if (!s.soundConn) return } else if (!s.soundUi) return
        lastSoundBlock = if (s.soundPart >= 0) host.playSoundPart(e, s.soundPart, s.soundVolume, s.soundOutput)
            else host.playSoundRouted(e, Synth.voiceFor(s.soundPack, s.style), s.soundVolume, s.soundOutput)
    }

    /** Son çalma denemesinde sesin neden çalınmadığı ([SoundBlock.NONE] = çaldı ya da denenmedi). */
    var lastSoundBlock: SoundBlock = SoundBlock.NONE
        private set

    /** Olaya özgü titreşim: bağlanınca iki vuruş, kesilince tek, hatada üç; şiddet ayarına göre. */
    fun hapticEvent(e: Sfx) {
        val s = settings
        if (!s.haptics || s.quietNow(host.localHour())) return
        val lvl = s.hapticLevel
        val base = when (e) {
            Sfx.CONNECT -> 2
            Sfx.ERROR -> 3
            else -> 1
        }
        val pulses = when (lvl) { HapticLevel.LIGHT -> 1; HapticLevel.NORMAL -> base; HapticLevel.STRONG -> base + 1 }
        host.hapticPattern(pulses, if (e == Sfx.ERROR) 70 else 85, lvl != HapticLevel.LIGHT)
    }

    /** Dokunuş geri bildirimi: titreşim (sessiz saatte yok) ve isteğe bağlı ses. [e] null ise ses çalmaz. */
    fun tapFeedback(strong: Boolean, e: Sfx?) {
        val s = settings
        if (s.haptics && !s.quietNow(host.localHour())) host.haptic(strong && s.hapticLevel != HapticLevel.LIGHT)
        if (e != null) sfx(e)
    }

    /** Ayarlardaki "Dene" düğmeleri: seçili tınıyla bağlanma sesi ve titreşimi. */
    fun previewSound() {
        lastSoundBlock = SoundBlock.NONE
        sfx(Sfx.CONNECT); hapticEvent(Sfx.CONNECT)
        // Ses gelmeyince kullanıcı uygulamayı bozuk sanmasın: nedeni ve çözümü söylenir.
        when (lastSoundBlock) {
            SoundBlock.RINGER -> toast(Strings.SOUND_BLOCK_RINGER)
            SoundBlock.ZERO_VOLUME -> toast(Strings.SOUND_BLOCK_ZERO)
            SoundBlock.NONE -> {}
        }
    }

    /** Durum özetini tek metin olarak panoya kopyala (destek ve paylaşım için; kişisel veri içermez). */
    fun copyStatusSummary() {
        val parts = ArrayList<String>()
        parts.add(Strings.APP + " " + host.versionName())
        parts.add(statusTitle())
        statusSub().takeIf { it.isNotBlank() }?.let { parts.add(it) }
        modulesLine()?.let { parts.add(it) }
        host.copyText(parts.joinToString(" · "))
        toast(Strings.COPIED)
    }

    /** Profili uygula: sunucu, şifreleme, önbellek, süzgeç ve modüller tek dokunuşla; bağlıysa sunucuya geçer, değilse bağlanır. */
    fun applyProfile(id: String) {
        val p = Profiles.byId(id) ?: return
        update { p.applyTo(it) }
        requestModules(p.dpi, p.ads)
        if (vpn.active) tapServer(p.serverId) else requestConnect(p.serverId)
        toast(Strings.profileApplied(Strings.PROFILE_NAMES[Profiles.all.indexOf(p)]))
    }

    // ------------------------------------------------------------------ eylemler (kullanıcı)

    /** Küreye dokunuldu: bağlıysa kes, duraklatılmışsa sürdür, değilse seçili (ya da ayar açıksa en hızlı) sunucuya bağlan. */
    fun tapOrb() {
        when {
            vpn.active && settings.confirmDisconnect -> toast(Strings.CONFIRM_DISCONNECT, Strings.DISCONNECT) { disconnectNow() }
            vpn.active -> disconnectNow()
            paused -> {
                host.resume()
                vpn = vpn.copy(state = OrbState.CONNECTING, pausedUntil = 0L, error = null, sinceMs = host.now())
                bump()
            }
            else -> {
                val target = if (settings.autoFastest) fastestUsable()?.first?.id ?: selectedId() else selectedId()
                requestConnect(target)
            }
        }
    }

    /** Onaysız kesme (onaydan sonra ya da onay kapalıyken). Modül açıksa yalnızca DNS durur, modüller sürer. */
    fun disconnectNow() {
        if (!vpn.active) return
        switchingTo = null
        if (vpn.gwActive) host.disconnectDns() else host.disconnect()
        toast(Strings.DISCONNECTED)
    }

    // ------------------------------------------------------------------ ağ geçidi modülleri (DPI atlatma, Reklam+)

    private var pendingDpi: Boolean? = null
    private var pendingAds: Boolean? = null
    private var pendingAt = 0L
    private var pendingModules: Pair<Boolean, Boolean>? = null

    private fun pendingFresh(): Boolean = host.now() - pendingAt < MODULE_PENDING_MS

    /** DPI atlatma şu an açık mı (istek bekliyorsa isteğe göre; aksi halde servisin gerçek durumuna göre). */
    val dpiOn: Boolean get() = (if (pendingFresh()) pendingDpi else null) ?: vpn.gwDpi
    val adsPlusOn: Boolean get() = (if (pendingFresh()) pendingAds else null) ?: vpn.gwAds

    fun toggleDpi() = requestModules(!dpiOn, adsPlusOn)
    fun toggleAdsPlus() = requestModules(dpiOn, !adsPlusOn)

    private fun requestModules(dpi: Boolean, ads: Boolean) {
        if (!settings.onboarded) {
            pendingModules = dpi to ads
            consentOpen = true
            bump()
            return
        }
        sendModules(dpi, ads)
    }

    private fun sendModules(dpi: Boolean, ads: Boolean) {
        val wasDpi = dpiOn
        val wasAds = adsPlusOn
        pendingDpi = dpi; pendingAds = ads; pendingAt = host.now()
        if (settings.lastDpi != dpi || settings.lastAds != ads) { settings = settings.copy(lastDpi = dpi, lastAds = ads); host.saveSettings(settings) }
        val oldLast = settings.lastDpi to settings.lastAds
        var failed = false
        host.applyModules(dpi, ads) {
            failed = true
            // İzin verilmedi ya da başlatılamadı: istek geri alınır.
            pendingDpi = null; pendingAds = null
            if (settings.lastDpi != oldLast.first || settings.lastAds != oldLast.second) { settings = settings.copy(lastDpi = oldLast.first, lastAds = oldLast.second); host.saveSettings(settings) }
            toast(Strings.MOD_FAILED)
            sfx(Sfx.ERROR)
            bump()
        }
        if (failed) return
        if (dpi != wasDpi || ads != wasAds) sfx(if ((dpi && !wasDpi) || (ads && !wasAds)) Sfx.TOGGLE_ON else Sfx.TOGGLE_OFF)
        if (dpi != wasDpi) toast(if (dpi) Strings.modOn(Strings.MOD_DPI) else Strings.modOff(Strings.MOD_DPI))
        if (ads != wasAds) toast(if (ads) Strings.modOn(Strings.MOD_ADS) else Strings.modOff(Strings.MOD_ADS))
        bump()
    }

    /** Ana ekranda kısa not: modül açıkken hangileri çalışıyor. */
    fun modulesLine(): String? {
        val names = listOfNotNull(if (vpn.gwDpi) Strings.MOD_DPI else null, if (vpn.gwAds) Strings.MOD_ADS else null)
        return if (names.isEmpty()) null else names.joinToString(" + ")
    }

    private fun fastestUsable() =
        ServerList.fastest(Catalog.all, latencies) { it.id !in settings.hidden && canUse(it) }

    /** Listedeki bir sunucuya dokunuldu: ona bağlan (bağlıysa kesintisiz geç). */
    fun tapServer(id: String) {
        val s = Catalog.byId(id) ?: return
        if (vpn.active && vpn.serverId == id) return
        if (vpn.active && switchingTo == id && host.now() - switchAt < SWITCH_GRACE_MS) return
        if (!canUse(s)) {
            toast(Strings.errNoProto(s.name, Strings.OPT_ENCRYPTION[settings.encryption.ordinal]))
            return
        }
        requestConnect(id)
        if (vpn.active && vpn.serverId != id) toast(Strings.switched(nameOf(id)))
    }

    private fun requestConnect(id: String) {
        if (!settings.onboarded) {
            pendingConnect = id
            consentOpen = true
            bump()
            return
        }
        doConnect(id)
    }

    private fun doConnect(id: String) {
        settings = settings.copy(lastServer = id).withRecent(id)
        host.saveSettings(settings)
        if (vpn.active) { switchingTo = id; switchAt = host.now() }
        else {
            switchingTo = null
            vpn = vpn.copy(state = OrbState.CONNECTING, serverId = id, error = null, sinceMs = host.now(), onBackup = false, pausedUntil = 0L)
        }
        host.connect(id)
        bump()
    }

    fun acceptConsent() {
        consentOpen = false
        settings = settings.copy(onboarded = true)
        host.saveSettings(settings)
        val id = pendingConnect
        pendingConnect = null
        val mods = pendingModules
        pendingModules = null
        // İkisi de beklemedeyse (ör. ilk açılışta bir profile dokunuldu) ikisi de uygulanır: önce modüller, sonra bağlantı.
        if (mods != null) sendModules(mods.first, mods.second)
        if (id != null) doConnect(id) else if (mods == null) bump()
    }

    fun dismissConsent() {
        consentOpen = false
        pendingConnect = null
        pendingModules = null
        bump()
    }

    fun setFilter(f: Filter) {
        if (filter == f) return
        filter = f
        if (settings.rememberFilter) {
            settings = settings.copy(lastFilter = f.id)
            host.saveSettings(settings)
        }
        bump()
    }

    fun toggleFavorite(id: String) {
        if (Catalog.byId(id) == null) return
        val fav = settings.favorites
        update { it.copy(favorites = if (id in fav) fav - id else fav + id) }
        host.updateShortcuts(Catalog.all.filter { it.id in settings.favorites }.map { it.id })
    }

    /** Sıralamayı sırayla değiştirir: varsayılan → hız → ad → varsayılan. */
    fun toggleSort() = update {
        val next = SortMode.values()[(it.sortMode.ordinal + 1) % SortMode.values().size]
        it.copy(sortMode = next)
    }

    /** Sunucuyu listeden gizler; mesajdaki "Geri al" ile geri getirilir. */
    fun hide(id: String) {
        val s = Catalog.byId(id) ?: return
        if (id in settings.hidden) return
        update { it.copy(hidden = it.hidden + id) }
        toast(Strings.hiddenToast(s.name), Strings.UNDO) { unhide(id) }
    }

    fun unhide(id: String) = update { it.copy(hidden = it.hidden - id) }

    /** Tüm sunucuların hızını ölç (gizlenenler hariç). Zaten ölçülüyorsa yok sayılır. */
    fun measureAll() = measure(Catalog.all.filter { it.id !in settings.hidden }.map { it.id })

    fun measure(ids: List<String>) {
        if (measuring || ids.isEmpty()) return
        measuring = true
        measureStart = host.now()
        measureRemaining = ids.size
        sfx(Sfx.REFRESH)
        host.measure(ids)
        bump()
    }

    /** Ölçülmüş en hızlı (kullanılabilir) sunucuya bağlan. */
    fun connectFastest() {
        val best = fastestUsable()
        if (best == null) toast(Strings.MEASURE_FIRST) else tapServer(best.first.id)
    }

    /** Bağlıyken bağlantı testini başlat. */
    fun testConnection() {
        if (vpn.state != OrbState.ON) { toast(Strings.ONLY_CONNECTED); return }
        if (testing) return
        testing = true
        testStart = host.now()
        sfx(Sfx.REFRESH)
        host.runTest()
        bump()
    }

    private var testStart = 0L

    fun onTestResult(r: SelfTestResult) {
        testing = false
        testResult = r
        testSeq++
        bump()
    }

    /**
     * Amaca uygun sunucu: [goal] etiketli (null ise hepsi) kullanılabilir sunucular arasında ölçülmüş en hızlısı.
     * Hiç ölçüm yoksa önce ölçmeyi önerir (ölçüm bitince en hızlı mesajı zaten gelir).
     */
    fun recommend(goal: Tag?) {
        val usable: (DnsServer) -> Boolean = { it.id !in settings.hidden && canUse(it) }
        val s = ServerList.recommend(Catalog.all, goal, latencies, usable)
        if (s == null) { toast(Strings.NO_REPLY); return }
        // Hiç ölçüm yoksa katalogdaki ilk uygun sunucu önerilir ve arkadan ölçülür (bir sonraki öneri ölçüme dayanır).
        if (latencies.isEmpty()) measureAll()
        tapServer(s.id)
        toast(Strings.recommended(s.name))
    }

    /** Tüm ölçümleri ve geçmişi siler. */
    fun clearHistory() {
        latencies.clear()
        history = emptyMap()
        host.saveLatencies(latencies)
        host.saveHistory(history)
        toast(Strings.HISTORY_CLEARED)
    }

    /**
     * Uygulama ön plana ilk geldiğinde: açılışta ölçüm (ayar açıksa ve son ölçüm 1 günden eskiyse) ve
     * sürüm yükseldiyse "Neler yeni" duyurusu.
     */
    fun onStart() {
        if (started) return
        started = true
        if (settings.autoMeasure && settings.onboarded) {
            val newest = latencies.values.maxOfOrNull { it.at } ?: 0L
            if (host.now() - newest > DAY_MS) measureAll()
        }
        if (settings.lastSeenVersion < WHATS_NEW_VERSION) {
            val wasUsing = settings.onboarded
            settings = settings.copy(lastSeenVersion = WHATS_NEW_VERSION)
            host.saveSettings(settings)
            if (wasUsing) toast(Strings.WHATS_NEW_TOAST, Strings.SHOW) { openWhatsNew() }
        }
    }

    fun openWhatsNew() { whatsNewSeq++; bump() }

    /** Duvar kağıdı rengi değişti (ya da ilk kez okundu). */
    fun setAccentSeed(v: Int?) { if (v != accentSeed) { accentSeed = v; bump() } }

    /** Bağlantıyı [minutes] dakika duraklat. */
    fun pause(minutes: Int) {
        if (!vpn.active || minutes <= 0) return
        switchingTo = null
        host.pause(minutes)
        vpn = vpn.copy(state = OrbState.OFF, pausedUntil = host.now() + minutes * 60_000L)
        bump()
    }

    fun clearCache() {
        if (vpn.state != OrbState.ON) { toast(Strings.ONLY_CONNECTED); return }
        host.clearCache()
        toast(Strings.CACHE_CLEARED)
    }

    /** Ayarı değiştir ve kaydet. Tüm ayar kontrolleri bunu kullanır. */
    fun update(change: (AppSettings) -> AppSettings) {
        val next = change(settings)
        if (next == settings) return
        val prev = settings
        val langChanged = next.lang != prev.lang
        settings = next
        host.saveSettings(settings)
        if (langChanged) { host.applyLanguage(next.lang); langSeq++ }
        if (prev.filterLevel != next.filterLevel || prev.filterAllow != next.filterAllow || prev.filterBlock != next.filterBlock || prev.youtubeAds != next.youtubeAds) {
            FilterRuntime.setLight(next.lightEffective())
            FilterRuntime.update(next.filterLevel, next.filterAllow, YouTubeAds.blockFor(next, host.personalBuild()))
        }
        if (prev.keepHistory != next.keepHistory) FilterLive.keep(next.keepHistory)
        if (prev.rebindGuard != next.rebindGuard) FilterRuntime.rebind = next.rebindGuard
        if (prev.dohGuard != next.dohGuard) FilterRuntime.setDohGuard(next.dohGuard)
        // Ağ geçidi çalışırken QUIC ayarı değiştiyse servis ayarı canlı alır (kesinti yok).
        if (prev.blockQuic != next.blockQuic && vpn.gwActive) host.applyModules(dpiOn, adsPlusOn) {}
        // Bağlıyken bağlantıyı etkileyen bir ayar değiştiyse servise hemen uygulat (yeniden bağlanmak gerekmesin).
        if ((vpn.state == OrbState.ON || vpn.gwOnly) && (prev.appScope != next.appScope || prev.apps != next.apps)) appsPending = true
        if (vpn.state == OrbState.ON && prev.ipMode != next.ipMode) {
            // Tünelin IPv6 adresi ekleniyor ya da çıkıyor: tünel aynı sunucuyla yeniden kurulur (DNS bir iki saniye kesilir).
            host.applyApps()
            toast(Strings.APPLYING)
        } else if (vpn.state == OrbState.ON && connectionChanged(prev, next)) {
            host.reapply()
            toast(Strings.APPLYING)
        }
        bump()
    }

    // ------------------------------------------------------------------ reklam / izleyici engelleme

    /** Alan adı yazma penceresi; geçerliyse listeye ekler ([allow]: izin listesi, değilse kendi engel listesi). Bitince [done] çağrılır. */
    fun promptFilterName(allow: Boolean, done: () -> Unit = {}) {
        host.promptText(if (allow) Strings.FILTER_ALLOW_ADD else Strings.FILTER_BLOCK_ADD, "ornek.com", "", maxLen = 253, okLabel = Strings.CUSTOM_SAVE) { raw ->
            if (raw.isNotBlank() && addFilterName(allow, raw)) done()
        }
    }

    /** Bir sonuç: bilgi panelinin satırları, varsa düğme metni ve düğmenin izin vereceği alan adı. */
    class SiteView(val paragraphs: List<String>, val button: String?, val allowName: String?)

    /** "Site neden açılmıyor?": alan adını filtre ve bağlantı durumuna göre sınar. Filtre motoru kapalıysa kullanıcı listesine bakılır. */
    fun siteView(raw: String): SiteView {
        val name = FilterNames.normalize(raw)
        val eng = FilterRuntime.engine
        val verdict = when {
            name == null -> -1
            eng != null -> eng.fork().verdictOf(name)
            name in settings.filterBlock -> FilterVerdict.USER
            else -> -1
        }
        // YouTube adları motorda kullanıcı engeli gibi durur; kullanıcının kendi listesinde değillerse "reklam listesi" diye anlatılır.
        val v = if (verdict == FilterVerdict.USER && name != null && name !in settings.filterBlock && name in YouTubeAds.HOSTS) FilterVerdict.LIST else verdict
        val rep = SiteCheck.diagnose(name, vpn.state == OrbState.ON || vpn.gwAds, v, name != null && name in settings.filterAllow, settings.adsPlus && settings.dnsOn)
        val text = when (rep.cause) {
            SiteCause.BAD_NAME -> Strings.SITE_NO_NAME
            SiteCause.VPN_OFF -> Strings.SITE_VPN_OFF
            SiteCause.USER_BLOCK -> Strings.SITE_USER_BLOCK
            SiteCause.LIST_BLOCK -> Strings.SITE_LIST_BLOCK
            SiteCause.CANARY -> Strings.SITE_CANARY
            SiteCause.DOH_BLOCK -> Strings.SITE_DOH
            SiteCause.ALLOWED -> Strings.SITE_ALLOWED
            SiteCause.NOT_OURS -> Strings.SITE_NOT_OURS
        }
        val canAllow = rep.cause == SiteCause.USER_BLOCK || rep.cause == SiteCause.LIST_BLOCK
        return SiteView(listOf(text), if (canAllow) Strings.SITE_ALLOW_BTN else null, if (canAllow) name else null)
    }

    /** Alan adını izin ya da engel listesine ekler; öbür listeden çıkarır. Geçersizse ya da liste doluysa uyarır, false döner. */
    /** Birden çok adı tek seferde kendi engel listesine ekler (izin listesinden çıkarır). Eklenen varsa true. */
    fun addFilterBlocks(raw: List<String>): Boolean {
        val valid = raw.mapNotNull { FilterNames.normalize(it) }
        val names = valid.filter { !FilterNames.isPublicSuffix(it) }.distinct()
        if (names.isEmpty()) { if (valid.isNotEmpty()) toast(Strings.FILTER_ERR_SUFFIX); return false }
        val fresh = names.filter { it !in settings.filterBlock }
        if (settings.filterBlock.size + fresh.size > FilterNames.MAX_LIST) { toast(Strings.FILTER_ERR_LIMIT); return false }
        val prevBlock = settings.filterBlock
        val prevAllow = settings.filterAllow
        update { it.copy(filterBlock = it.filterBlock + fresh, filterAllow = it.filterAllow.filter { n -> n !in names }) }
        toast(Strings.filterBlocked(Strings.mineCount(names.size)), Strings.UNDO) { update { it.copy(filterBlock = prevBlock, filterAllow = prevAllow) } }
        return true
    }

    fun addFilterName(allow: Boolean, raw: String): Boolean {
        val name = FilterNames.normalize(raw)
        // Ortak son ek ("co.uk", "com.tr") bütün siteleri kapsar: ne engel ne izin listesine alınır. Geçerli bir ad olduğu için
        // genel "geçerli ad yazın" uyarısı yanıltırdı: nedeni açıkça söylenir.
        if (name == null) { toast(Strings.FILTER_ERR); return false }
        if (FilterNames.isPublicSuffix(name)) { toast(Strings.FILTER_ERR_SUFFIX); return false }
        val cur = if (allow) settings.filterAllow else settings.filterBlock
        if (name !in cur && cur.size >= FilterNames.MAX_LIST) { toast(Strings.FILTER_ERR_LIMIT); return false }
        val prevBlock = settings.filterBlock
        val prevAllow = settings.filterAllow
        update {
            if (allow) it.copy(filterAllow = (it.filterAllow.filter { n -> n != name } + name), filterBlock = it.filterBlock.filter { n -> n != name })
            else it.copy(filterBlock = (it.filterBlock.filter { n -> n != name } + name), filterAllow = it.filterAllow.filter { n -> n != name })
        }
        // Yanlış dokunuş tek dokunuşla geri alınır (iki liste de eski haline döner).
        toast(if (allow) Strings.filterAllowed(name) else Strings.filterBlocked(name), Strings.UNDO) { update { it.copy(filterBlock = prevBlock, filterAllow = prevAllow) } }
        return true
    }

    /** Alan adlarını (satır satır) panoya kopyalar: yanlış engeli bildirmek ya da başka yere taşımak için. */
    fun copyNames(names: List<String>) {
        if (names.isEmpty()) { toast(Strings.MINE_NOTHING); return }
        host.copyText(names.joinToString("\n"))
        toast(Strings.mineCopied(names.size))
    }

    fun askRemoveFilterName(allow: Boolean, name: String) =
        toast(Strings.filterRemoveAsk(name), Strings.FILTER_REMOVE_BTN) { removeFilterName(allow, name) }

    fun removeFilterName(allow: Boolean, name: String) {
        update { if (allow) it.copy(filterAllow = it.filterAllow.filter { n -> n != name }) else it.copy(filterBlock = it.filterBlock.filter { n -> n != name }) }
        toast(Strings.filterRemoved(name))
    }

    // ------------------------------------------------------------------ kendi liste (içe/dışa aktarma)

    /** İçe aktarılan engel listesindeki ad sayısı (ayarlarda değil, cihazdaki dosyada durur). */
    var importedCount: Int = host.importedCount()
        private set

    /** Panodaki metni (hosts, alan adı listesi ya da ||alan^ kuralları) engel listesine ekler. */
    fun importFromClipboard() {
        val text = host.readClipboard()
        if (text.isNullOrBlank()) { toast(Strings.MINE_CLIP_EMPTY); return }
        applyImport(text)
    }

    /** Sistemin dosya seçicisinden bir metin dosyası alıp engel listesine ekler. */
    fun importFromFile() {
        host.pickTextFile { text ->
            if (text == null) toast(Strings.MINE_FILE_ERR) else applyImport(text)
        }
    }

    private fun applyImport(text: String) {
        val r = HostsList.parse(text)
        if (r.names.isEmpty()) { toast(Strings.MINE_NOTHING); return }
        val before = host.loadImported()
        val merged = HostsList.merge(before, r.names)
        if (!host.saveImported(merged)) { toast(Strings.MINE_FILE_ERR); return }
        importedCount = merged.size
        val added = merged.size - before.size
        val note = (if (r.cut || merged.size >= HostsList.MAX_IMPORTED) ". " + Strings.MINE_CUT else "") +
            (if (r.excepted > 0) ". " + Strings.mineExcepted(r.excepted) else "")
        // Eklenen bir şey varsa içe aktarma geri alınabilir (yanlış dosya ya da pano içeriği).
        if (added > 0) toast(Strings.mineAdded(added) + note, Strings.UNDO) { undoImportedList(before) }
        else toast(Strings.mineAdded(added) + note)
        bump()
    }

    private fun undoImportedList(before: List<String>) {
        if (!host.saveImported(before)) { toast(Strings.MINE_FILE_ERR); return }
        importedCount = before.size
        bump()
    }

    fun askClearImported() {
        if (importedCount == 0) { toast(Strings.MINE_NOTHING); return }
        toast(Strings.MINE_CLEAR_ASK, Strings.FILTER_REMOVE_BTN) { clearImported() }
    }

    fun clearImported() {
        if (!host.saveImported(emptyList())) { toast(Strings.MINE_FILE_ERR); return }
        importedCount = 0
        toast(Strings.MINE_CLEARED)
        bump()
    }

    /** Engel listesini (kendi eklediklerin + içe aktarılanlar) hosts biçiminde panoya kopyalar. */
    fun copyBlockList() {
        val all = (settings.filterBlock + host.loadImported()).distinct()
        if (all.isEmpty()) { toast(Strings.MINE_NOTHING); return }
        host.copyText(HostsList.export(all))
        toast(Strings.mineCopied(minOf(all.size, HostsList.MAX_EXPORT)))
    }

    /** Sorgu başına gecikme grafiğinin örnekleri (kullanılan sayı [latencyCount]); grafik yeniler. */
    val latencySamples = IntArray(app.dnshizli.core.LatencyRing.CAPACITY)
    var latencyCount = 0
        private set

    fun refreshLatencies() {
        latencyCount = if (vpn.state == OrbState.ON) host.latencies(latencySamples).coerceIn(0, latencySamples.size) else 0
    }

    private fun connectionChanged(a: AppSettings, b: AppSettings): Boolean =
        a.encryption != b.encryption || a.strictEncryption != b.strictEncryption || a.odoh != b.odoh || a.cache != b.cache ||
            a.wifiServer != b.wifiServer || a.mobileServer != b.mobileServer ||
            a.hideOnLockscreen != b.hideOnLockscreen || a.quietNotification != b.quietNotification

    // ------------------------------------------------------------------ uygulama seçimi

    /** Yüklü (başlatıcıda görünen) uygulamalar; sayfa açılınca yüklenir, yüklenene kadar null. */
    var apps: List<AppEntry>? = null
        private set

    /** Bağlıyken uygulama seçimi değişti ama tünel henüz yenilenmedi. */
    var appsPending: Boolean = false
        private set

    fun loadApps() {
        host.loadApps { list -> apps = list; bump() }
    }

    fun setAppScope(scope: AppScope) = update { it.copy(appScope = scope) }

    fun toggleApp(pkg: String, on: Boolean) = update { it.copy(apps = if (on) it.apps + pkg else it.apps - pkg) }

    /** Değişikliği şimdi uygula: tünel yeniden kurulur. */
    fun applyAppsNow() {
        if (!appsPending) return
        appsPending = false
        if (vpn.state == OrbState.ON || vpn.gwOnly) { host.applyApps(); toast(Strings.APPLYING) }
        bump()
    }

    fun setLanguage(setting: String) = update { it.copy(lang = setting) }

    /** Dil platformdan değişti (ör. Android'in uygulama dili ayarı): sayfaları yeniden kur. */
    fun onLanguageChanged() { langSeq++; bump() }

    // ------------------------------------------------------------------ arka plan fotoğrafı

    fun pickWallpaper() = host.pickWallpaper()

    fun usePresetWallpaper(index: Int) = host.usePresetWallpaper(index)

    /** Seçici döndü: [ok] ise fotoğraf hazırlanıp kaydedilmiştir. */
    fun onWallpaperPicked(ok: Boolean) {
        if (ok) { update { it.copy(wallpaper = true, wpRev = it.wpRev + 1) }; toast(Strings.WP_SAVED) }
        else toast(Strings.WP_FAILED)
    }

    fun removeWallpaper() {
        host.removeWallpaper()
        update { it.copy(wallpaper = false) }
        toast(Strings.WP_REMOVED)
    }

    /** Ayar "var" diyor ama dosya yok/bozuk: ayarı sessizce kapat (kendini onarır). */
    fun onWallpaperMissing() { update { it.copy(wallpaper = false) } }

    // ------------------------------------------------------------------ uygulama simgesi

    /** Simge değişince ayar yalnızca platform değiştirebildiyse güncellenir (ayar ile gerçek durum ayrışmasın). */
    fun setAppIcon(style: UiStyle) {
        if (style == settings.appIcon) return
        if (host.setAppIcon(style)) { update { it.copy(appIcon = style) }; toast(Strings.ICON_SET) }
        else toast(Strings.ICON_FAILED)
    }

    fun exportSettings() {
        host.copyText(SettingsCodec.export(settings))
        toast(Strings.EXPORTED)
    }

    /**
     * Panodaki ayar kodunu yükler. Güvenliği etkileyen değişiklikler (şifrelemenin zayıflaması, otomatik bağlanma,
     * sunucu kuralları) mesajda ayrıca yazılır; "Geri al" önceki ayarları geri getirir.
     */
    fun importSettings() {
        val code = host.readClipboard()
        val next = if (code == null) null else SettingsCodec.import(code, settings)
        if (next == null) { toast(Strings.IMPORT_BAD); return }
        val before = settings
        update { next.copy(onboarded = it.onboarded, wasActive = it.wasActive, lastSeenVersion = it.lastSeenVersion) }
        val changes = ImportReview.changes(before, settings)
        val text = if (changes.isEmpty()) Strings.IMPORTED else Strings.importedWith(changes.joinToString(", ") { Strings.sensitive(it) })
        toast(text, Strings.UNDO) { undoImport(before) }
    }

    private fun undoImport(before: AppSettings) {
        // Servisin bu arada yazdığı istatistikler korunur; yalnızca kullanıcı ayarları geri alınır.
        val cur = settings
        update {
            before.copy(
                wasActive = cur.wasActive, totals = cur.totals, daily = cur.daily, usage = cur.usage, sessions = cur.sessions,
                lastServer = cur.lastServer, recent = cur.recent,
            )
        }
    }

    /** Hazır görünümü ([LookPreset]) uygular; "Geri al" önceki görünümü getirir. */
    fun applyLookPreset(p: LookPreset) {
        val before = settings
        update { Look.apply(it, p) }
        sfx(Sfx.TAP)
        toast(Strings.PRESET_DONE, Strings.UNDO) { update { cur -> Look.copyLook(before, cur) } }
    }

    /** Yalnızca görünüm ayarlarını varsayılana döndürür (DNS, filtre ve diğerleri değişmez); "Geri al" görünümü geri getirir. */
    fun resetLook() {
        val before = settings
        update { Look.reset(it) }
        toast(Strings.RESET_LOOK_DONE, Strings.UNDO) { update { cur -> Look.copyLook(before, cur) } }
    }

    /** Görünüm/bağlantı ayarlarını varsayılana döndürür; favoriler, onay ve istatistikler korunur. Onay mesajıyla çağrılır. */
    fun askResetSettings() = toast(Strings.CONFIRM, Strings.RESET) { resetSettings() }

    fun resetSettings() {
        val keep = settings
        update {
            AppSettings(
                lang = keep.lang, favorites = keep.favorites, recent = keep.recent, lastServer = keep.lastServer,
                onboarded = keep.onboarded, lastSeenVersion = keep.lastSeenVersion, wasActive = keep.wasActive, totals = keep.totals,
                daily = keep.daily,
                usage = keep.usage, sessions = keep.sessions,
                custom = keep.custom, wallpaper = keep.wallpaper, wpRev = keep.wpRev,   // eklenen sunucular ve fotoğraf silinmesin
            )
        }
        toast(Strings.RESET_DONE)
    }

    fun askResetStats() = toast(Strings.CONFIRM, Strings.RESET) { resetStats() }

    fun resetStats() {
        host.resetTotals()
        settings = settings.copy(
            totals = UsageTotals(), daily = "",
            usage = "", sessions = "",
        )
        bump()
        toast(Strings.RESET_DONE)
    }

    fun copy(text: String) {
        host.copyText(text)
        toast(Strings.COPIED)
    }

    fun toast(text: String, action: String? = null, onAction: (() -> Unit)? = null) {
        if (text.isBlank()) return
        toast = ToastMsg(text, action, onAction)
        toastSeq++
        bump()
    }

    /** Platform ölçümün bittiğini bildirmezse dönen gösterge sonsuza dek sürmesin. Sahne her karede çağırır. */
    fun watchdog() {
        if (measuring && host.now() - measureStart > MEASURE_TIMEOUT_MS) onMeasureDone()
        if (testing && host.now() - testStart > TEST_TIMEOUT_MS) { testing = false; bump() }
        if (vpn.pausedUntil != 0L && !vpn.active && vpn.pausedUntil <= host.now() - PAUSE_GRACE_MS) {
            // Süre çoktan doldu ama servis hiç dönmedi (ör. sistem alarmı ertelendi ve servis yok): takılı kalma.
            vpn = vpn.copy(pausedUntil = 0L)
            bump()
        }
    }

    // ------------------------------------------------------------------ platformdan gelenler

    private val dpiRecent = app.dnshizli.core.RollingCounter()
    private val adsRecent = app.dnshizli.core.RollingCounter()

    /** Son 10 dakikada bölünen bağlantı sayısı (modül kapalıysa ya da veri yoksa 0). */
    fun recentSplit(): Long = if (vpn.gwDpi) dpiRecent.recent() else 0L

    /** Son 10 dakikada engellenen reklam/izleyici sayısı (modül kapalıysa ya da veri yoksa 0). */
    fun recentBlocked(): Long = if (vpn.gwAds) adsRecent.recent() else 0L

    fun onVpn(v: VpnUi) {
        val old = vpn
        vpn = v
        val t = host.now()
        if (v.gwDpi) dpiRecent.record(t, v.gwSplit.toLong()) else dpiRecent.clear()
        if (v.gwAds) adsRecent.record(t, v.gwBlocked.toLong()) else adsRecent.clear()
        if (pendingDpi != null && (v.gwDpi == pendingDpi || v.state == OrbState.ERROR || v.gwTripped)) pendingDpi = null
        if (pendingAds != null && (v.gwAds == pendingAds || v.state == OrbState.ERROR || v.gwTripped)) pendingAds = null
        if (v.state != OrbState.ON && !v.gwOnly) appsPending = false      // yeni bağlantı güncel seçimi zaten kullanır
        if (!v.active || v.serverId == switchingTo) switchingTo = null
        val firstVpn = !vpnSeen
        vpnSeen = true
        if (!firstVpn && v.state != old.state) {
            when {
                v.state == OrbState.ON -> {
                    sfx(Sfx.CONNECT); hapticEvent(Sfx.CONNECT)
                    if (settings.celebrate) celebrateSeq++
                    // "Modülleri hatırla": bağlanınca DPI atlatma ve Reklam+ son istenen durumda açılır.
                    if (settings.rememberModules && (settings.lastDpi || settings.lastAds) && !v.gwDpi && !v.gwAds && pendingDpi == null && pendingAds == null) {
                        sendModules(settings.lastDpi, settings.lastAds)
                    }
                }
                v.state == OrbState.ERROR -> { sfx(Sfx.ERROR); hapticEvent(Sfx.ERROR) }
                v.state == OrbState.OFF && old.state == OrbState.ON -> { sfx(Sfx.DISCONNECT); hapticEvent(Sfx.DISCONNECT) }
            }
        }
        if (v.state == OrbState.ON && v.onBackup && !old.onBackup) toast(Strings.BACKUP)
        // Bağlıyken bir işlem (ör. sunucu değiştirme) başarısız olduysa servis nedenini bir kez bildirir.
        if (v.state == OrbState.ON && v.error != null && v.error != old.error) {
            toast(v.error)
            // İstenen sunucuya geçilemedi, eskisinde kalındı: seçim de eskisine döner (kesip yeniden bağlanınca o kullanılsın).
            val sid = v.serverId
            if (switchingTo != null && sid != null && sid != switchingTo) {
                switchingTo = null
                settings = settings.copy(lastServer = sid)
                host.saveSettings(settings)
            }
        }
        if (v.state == OrbState.ON && v.downgraded && !(old.state == OrbState.ON && old.downgraded)) toast(if (v.proto != null && v.proto != Proto.PLAIN) Strings.DOWNGRADED_ODOH else Strings.DOWNGRADED)
        if (v.state == OrbState.ON && old.state == OrbState.ON && old.downgraded && !v.downgraded) toast(Strings.UPGRADED)
        if (v.info != null && v.info != old.info) toast(v.info)
        // Servis sunucuyu kendisi değiştirdiyse (bildirimdeki "Sonraki", yedek sunucu, ağ kuralı) seçimi izle.
        val sid = v.serverId
        if (v.state == OrbState.ON && sid != null && sid != settings.lastServer && Catalog.byId(sid) != null && switchingTo == null) {
            settings = settings.copy(lastServer = sid).let { if (settings.keepHistory) it.withRecent(sid) else it }
        }
        bump()
    }

    fun onLatency(id: String, ms: Int?, loss: Int = 0) {
        if (Catalog.byId(id) == null) return
        latencies[id] = Latency(ms, host.now(), loss)
        if (settings.keepHistory) history = LatencyHistory.add(history, id, ms)
        if (measureRemaining > 0) measureRemaining--
        bump()
    }

    fun onMeasureDone() {
        if (!measuring) return
        measuring = false
        measureRemaining = 0
        host.saveLatencies(latencies)
        host.saveHistory(history)
        val best = fastestUsable()
        if (best == null) toast(Strings.NO_REPLY)
        else toast(Strings.fastest(best.first.name, best.second), Strings.CONNECT) { tapServer(best.first.id) }
        bump()
    }

    /** Depolamadan okunan ayarları (ör. servisin yazdığı toplamlar) modele al; yeniden kaydetmez. */
    fun replaceSettings(s: AppSettings) {
        if (s == settings) return
        settings = s
        bump()
    }

    // ------------------------------------------------------------------ gösterim yardımcıları

    fun latencyText(id: String): String? {
        val l = latencies[id] ?: return null
        return l.ms?.let { Format.ms(it) } ?: "—"
    }

    fun hitPercentTotal(): Int {
        val q = settings.totalQueries
        return if (q > 0) (settings.totalHits * 100 / q).toInt().coerceIn(0, 100) else 0
    }

    companion object {
        /** Aynı sunucuya art arda dokunmanın ikinci çağrı sayılmayacağı süre. */
        const val SWITCH_GRACE_MS = 2500L

        /** Modül isteği için servis cevabı beklerken gösterilen sürenin üst sınırı (izin penceresi dahil). */
        const val MODULE_PENDING_MS = 12_000L

        /** Tüm sunucuların ölçümü için üst süre. */
        const val MEASURE_TIMEOUT_MS = 60_000L

        /** Duraklatma bitince servisin yeniden bağlanmasını beklerken tanınan pay (sistem alarmı gecikebilir). */
        const val PAUSE_GRACE_MS = 30 * 60_000L

        /** Hızlı seçimdeki duraklatma süreleri (dakika). */
        val PAUSE_OPTIONS = listOf(5, 15, 30, 60, 120)

        /** Bağlantı testi için üst süre. */
        const val TEST_TIMEOUT_MS = 15_000L

        private const val DAY_MS = 24 * 3_600_000L

        /** "Neler yeni" duyurusunun ait olduğu sürüm: yükseldiğinde güncelleyen kullanıcıya bir kez gösterilir. */
        const val WHATS_NEW_VERSION = 26
        const val LIST_LIMIT = 8
        const val LIST_MIN_HIDDEN = 3
    }
}
