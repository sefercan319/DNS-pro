package app.dnshizli.core

/** Русский. */
object TxRu : Tx() {
    override val lang = Lang.RU

    override val decimalSep = ','
    override val thousand = " тыс."
    override val million = " млн"
    override fun percent(n: Int) = "$n%"
    override val dayU = "д"
    override val hourU = "ч"
    override val minU = "мин"
    override val secU = "с"
    override val msU = "мс"
    override val justNow = "только что"
    override fun ago(span: String) = "$span назад"

    override val OFF = "Не подключено"
    override val CONNECTING = "Подключение…"
    override val ON = "Подключено"
    override val ERROR = "Не удалось подключиться"
    override val PAUSED = "Пауза"
    override val HINT_OFF = "Коснитесь сферы, чтобы подключиться"
    override val HINT_CONNECTING = "Это может занять несколько секунд"
    override val HINT_ERROR = "Коснитесь, чтобы повторить"
    override val HINT_PAUSED = "Коснитесь, чтобы продолжить сейчас"
    override val ERR_DEFAULT = "Не удалось установить соединение"
    override fun selected(name: String) = "Выбран $name"
    override fun pausedUntil(time: String) = "Продолжение в $time"
    override fun blockedShort(n: String) = "заблокировано: $n"
    override fun queriesShort(n: String) = "запросов: $n"
    override fun cacheShort(pct: String) = "кэш $pct"

    override val SERVERS = "Серверы"
    override val FILTER_ALL = "Все"
    override val FILTER_FAV = "Избранное"
    override val FILTER_RECENT = "Недавние"
    override val EMPTY_FAV = "Избранного пока нет. Коснитесь звёздочки у сервера."
    override val EMPTY_RECENT = "Вы ещё не подключались ни к одному серверу."
    override val EMPTY_FILTER = "В этой категории нет серверов."
    override val MEASURE = "Измерить скорость"
    override val MEASURING = "Измерение…"
    override val SORT = "Сортировать по скорости"
    override val PULL_TO_MEASURE = "Потяните, чтобы измерить"
    override val RELEASE_TO_MEASURE = "Отпустите для измерения"
    override fun serversCount(n: Int) = "серверов: $n"
    override fun showAllServers(n: Int) = "Показать все ($n)"
    override val SHOW_LESS = "Показать меньше"
    override val TAG_FAST = "Быстрые"
    override val TAG_PRIVACY = "Приватность"
    override val TAG_ADS = "Реклама"
    override val TAG_FAMILY = "Семья"
    override val TAG_SECURITY = "Защита"
    override val VAR_OPEN = "без фильтра"
    override val VAR_ADS = "без рекламы"
    override val VAR_SECURITY = "Защита"
    override val VAR_FAMILY = "Семья"
    override val A11Y_CONNECTED = "подключено"
    override val A11Y_ENCRYPTED = "зашифровано"
    override fun favA11y(name: String) = "$name в избранном"

    override val COPIED = "Скопировано в буфер обмена"
    override val DISCONNECTED = "Отключено"
    override val BACKUP = "Переключено на резервный сервер"
    override val NO_REPLY = "Ни один сервер не ответил"
    override val MEASURE_FIRST = "Сначала измерьте скорость"
    override val CONNECT = "Подключить"
    override val UNDO = "Отменить"
    override fun fastest(name: String, ms: Int) = "Быстрее всех: $name · $ms мс"
    override fun switched(name: String) = "Переключение на $name"
    override fun hiddenToast(name: String) = "$name скрыт"

    override val PRIMARY = "Основной"
    override val SECONDARY = "Дополнительный"
    override val COPY = "Копировать"
    override fun addressA11y(label: String, ip: String) = "$label адрес: $ip"
    override val CONNECT_TO_THIS = "Подключиться к этому серверу"
    override val SWITCH_TO_THIS = "Перейти на этот сервер"
    override val CONNECTED_NOW = "Сейчас подключено"
    override val ADD_FAV = "В избранное"
    override val REMOVE_FAV = "Убрать из избранного"
    override val MEASURE_THIS = "Измерить"
    override val HIDE = "Скрыть из списка"
    override val UNHIDE = "Показать в списке"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Последний замер: нет ответа · $ago" else "Последний замер: $ms мс · $ago"
    override val NEVER_MEASURED = "Ещё не измерялся"
    override val ENC_SUPPORT = "Шифрованный DNS"
    override val ENC_NONE = "Не поддерживается"
    override val ENC_ONLY = "Принимает только шифрованные подключения"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Лучший $best мс · медиана $median мс · потери $lossPct%"
    override val HISTORY = "История замеров"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: замеров $n, нет ответа" else "$HISTORY: замеров $n, медиана $median мс"

    override val QUICK_TITLE = "Быстрый выбор"
    override val QUICK_FAVORITES = "Избранное"
    override val QUICK_RECENT = "Недавние"
    override val PAUSE_FOR = "Пауза"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} ч" else "$n мин"
    override val RESUME = "Продолжить"

    override val SETTINGS = "Настройки"
    override val MENU = "Меню"
    override val PERSONALIZE = "Персонализация"
    override val PZ_BACKGROUND = "Фон"
    override val PZ_AUTO = "Автотема"
    override val PZ_FEEL = "Стекло, текст и движение"
    override val PZ_ACCESS = "Доступность и энергия"
    override val THIS_DEVICE = "Это устройство"
    override val DEVICE_AUTO = "Подстроить под устройство"
    override val DEVICE_AUTO_NOTE = "Определяет телефон и подстраивает движение и подсказки. Если выключено, действуют только ваши настройки."
    override val DEVICE_SYSTEM = "Система"
    override val DEVICE_CLASS = "Класс устройства"
    override val DEVICE_RISK = "Риск закрытия в фоне"
    override val OPT_TIER = listOf(
        "Базовый",
        "Средний",
        "Высокий",
    )
    override val OPT_RISK = listOf(
        "Низкий",
        "Средний",
        "Высокий",
    )
    override val DEVICE_ADVICE = listOf(
        "Эта система жёстко закрывает фоновые приложения. В настройках батареи установите для DNS Hızlı «без ограничений» и разрешите автозапуск, иначе защита может остановиться сама.",
        "One UI может «усыплять» неиспользуемые приложения. В настройках батареи установите для DNS Hızlı «Без ограничений» и уберите его из списка «Спящие приложения».",
        "Устройство с малым объёмом памяти: лёгкий список и более спокойное движение выбраны автоматически; ничего делать не нужно.",
        "Обнаружена кастомная прошивка: ограничений батареи от производителя нет, достаточно стандартной настройки Android.",
        "Система, близкая к чистому Android: дополнительных настроек батареи не требуется.",
        "Мощное устройство: все визуальные эффекты и движение работают плавно.",
    )
    override val DEVICE_APPLIED_MOTION = "Применено: движение упрощено для этого устройства."
    override val DEVICE_UNKNOWN = "Устройство ещё не распознано."
    override val DEVICE_OFF_NOTE = "Подстройка отключена: действуют только ваши настройки."
    override val PZ_ADAPTED = "Спокойное движение для этого устройства"
    override val SEC_THEME_COLOR = "Тема и цвет"
    override val SEC_SHAPE = "Стиль и шар"
    override val SEC_LANG_ICON = "Язык и значок"
    override val GROUP_SPECIAL = "Особые"
    override val GROUP_LIGHT = "Светлые"
    override val GROUP_DARK = "Тёмные"
    override val PRESET = "Готовый вид"
    override val OPT_PRESET = listOf(
        "Спокойный",
        "Сбалансированный",
        "Яркий",
    )
    override val PRESET_NOTES = listOf(
        "Мало движения, лёгкое стекло: бережёт батарею и глаза.",
        "Среднее стекло, лёгкое движение; подходит для большинства.",
        "Полное движение, насыщенное стекло и пузыри.",
    )
    override val PRESET_DONE = "Вид применён"
    override val RESET_LOOK = "Сбросить оформление"
    override val RESET_LOOK_BODY = "Тема, стиль, шар, фон, стекло, размер текста и движение вернутся к значениям по умолчанию. Настройки DNS, фильтра и остальные не изменятся. Можно отменить."
    override val RESET_LOOK_BTN = "Сбросить"
    override val RESET_LOOK_DONE = "Оформление сброшено"
    override val MOTION_NOTE_LOWPOWER = "Включён режим экономии: движение отключено."
    override val MOTION_NOTE_DEVICE = "На этом устройстве движение упрощается автоматически (Подстроить под устройство)."
    override val DNS_SETTINGS = "Настройки DNS"
    override val CONN_APPS = "Подключение и приложения"
    override val STATS_HISTORY = "Статистика и история"
    override val SEC_LOOK = "Внешний вид"
    override val SEC_LIST = "Список серверов"
    override val SEC_DATA = "Данные"
    override val ABOUT = "О приложении"
    override val LANGUAGE = "Язык"
    override val LANG_AUTO = "Автоматически (язык системы)"
    override val THEME = "Тема"
    override val THEME_AUTO = "Авто"
    override val THEME_AUTO_NOTE = "Авто · по светлой/тёмной теме системы"
    override val CUSTOM_STYLE = "Мой стиль"
    override val FX_PART = "Часть анимации"
    override val FX_PART_AUTO = "Собственная анимация стиля"
    override val FX_KIND_NAMES = listOf("Кольцо", "Капля", "Ломтик", "Лист", "Искра", "Смахивание", "Стекло", "Дым", "Орбита", "Лепесток", "Пузырь", "Молния", "Кристалл", "Светлячок", "Спираль", "Луч", "Осколок", "Пиксель")
    override val FX_KIND = "Тип анимации"
    override val FX_FORM = "Форма анимации"
    override val SOUND_PART = "Часть звука"
    override val SOUND_PART_AUTO = "Авто (пакет)"
    override val SOUND_VOICE = "Тембр"
    override val SOUND_CONTOUR = "Мелодия"
    override val SOUND_REGISTER = "Регистр"
    override val VOICE_NAMES = listOf("Пузырь", "Стекло", "Щелчок", "Дерево", "Пиксель", "Воздух", "Капля", "Колокольчик", "Бип", "Калимба", "Хром", "Пэд", "Чип", "Сонар", "Люмен", "Дуру")
    override val SOUND_CONTOUR_NAMES = listOf("Один удар", "Восходящее трезвучие", "Нисходящее", "Двойная точка", "Волна", "Скачок на октаву", "Квинта", "Медленный подъём", "Быстрая гамма", "Завершение", "Тремоло", "Аккорд")
    override val SOUND_REGISTER_NAMES = listOf("Обычный", "Высокий")
    override val CUSTOM_SECTION_LOOK = "Внешний вид"
    override val CUSTOM_SECTION_MOTION = "Движение"
    override val CUSTOM_SECTION_SOUND = "Звук"
    override val CUSTOM_SECTION_TOOLS = "Инструменты"
    override val CUSTOM_SECTION_SAVED = "Сохранённые стили"
    override val CUSTOM_SLOT_EMPTY = "Пусто · нажмите, чтобы сохранить"
    override val STYLE_APPLY = "Применить"
    override val STYLE_DELETE = "Удалить"
    override val ORB_AMOUNT = "Высота жидкой волны"
    override val FX_SIZE = "Размер анимации"
    override fun customSlotName(slot: Int): String = "Стиль ${slot + 1}"
    override val CUSTOM_STYLE_NOTE = "Каждую часть можно выбрать отдельно. Выбранная часть заменяет собственную анимацию или звук стиля; остальная часть стиля не меняется."
    override val CUSTOM_SHUFFLE = "Перемешать части"
    override val CUSTOM_RESET = "Сбросить к значениям стиля"
    override val CUSTOM_LISTEN = "Проиграть текущий звук"
    override val CUSTOM_RANDOM_DONE = "Части перемешаны"
    override val CUSTOM_RESET_DONE = "Сброшено"
    override val CUSTOM_SUMMARY = "Сейчас"
    override val CUSTOM_THEME = "Своя тема"
    override val CUSTOM_SKY = "Небо"
    override val CUSTOM_ACCENT = "Акцент"
    override val CUSTOM_SKY_NAMES = listOf("Утро", "Море", "Зелёный", "Розовый", "Полночь", "Лесная подстилка", "Уголь", "Красный рассвет")
    override val CUSTOM_ACCENT_NAMES = listOf("Бирюзовый", "Синий", "Фиолетовый", "Розовый", "Оранжевый", "Зелёный")
    override val FX_VARIANT = "Стиль эффекта касания"
    override val FX_VARIANT_NAMES = listOf("Исходный", "Плотный", "Вращение", "Двойной импульс", "Сходящийся", "Наклонный", "Зеркальный", "Растущий", "Быстрый")
    override val ORB_FLOW = "Движение жидкости"
    override val ORB_FLOW_NAMES = listOf("Спокойно", "Прилив", "Кольца", "Зыбь", "Близнецы", "Треугольная волна", "Мягкий квадрат", "Кипение", "Спираль", "Неподвижно")
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Аква"
        "meadow" -> "Луг"
        "ocean" -> "Океан"
        "sunset" -> "Закат"
        "lavender" -> "Лаванда"
        "coral" -> "Коралл"
        "mint" -> "Мята"
        "night" -> "Ночь"
        "amoled" -> "Чёрная (AMOLED)"
        "sakura" -> "Sakura"
        "honey" -> "Honey"
        "aurora" -> "Aurora"
        "peach" -> "Персик"
        "citrus" -> "Цитрус"
        "rose" -> "Роза"
        "glacier" -> "Ледник"
        "sand" -> "Песок"
        "lagoon" -> "Лагуна"
        "cocoa" -> "Какао"
        "candy" -> "Конфета"
        "forest" -> "Лес"
        "ember" -> "Жар"
        "plum" -> "Слива"
        "slate" -> "Сланец"
        "fjord" -> "Фьорд"
        "marigold" -> "Бархатцы"
        "lilac" -> "Сирень"
        "pistachio" -> "Фисташка"
        "tangerine" -> "Мандарин"
        "bubblegum" -> "Жвачка"
        "seafoam" -> "Морская пена"
        "dune" -> "Дюна"
        "mist" -> "Туман"
        "matcha" -> "Матча"
        "ivory" -> "Слоновая кость"
        "orchid" -> "Орхидея"
        "twilight" -> "Сумерки"
        "obsidian" -> "Обсидиан"
        "espresso" -> "Эспрессо"
        "neon" -> "Неон"
        "sapphire" -> "Сапфир"
        "pine" -> "Сосна"
        "wine" -> "Вино"
        "graphite" -> "Графит"
        "teal" -> "Ночная бирюза"
        "ink" -> "Чернила"
        "copper" -> "Медь"
        "northern" -> "Северное сияние"
        "custom" -> "Своя"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Тема: $name"
    override val THEME_SCHEDULE = "Ночная тема по расписанию"
    override val THEME_SCHEDULE_NOTE = "В режиме Авто «Ночь» с 22:00 до 07:00"
    override val GLASS = "Прозрачность стекла"
    override val BUBBLES = "Пузырьки"
    override val STYLE = "Стиль"
    override val STYLE_NOTES = listOf(
        "Стекло, глянец и пузырьки: исходный вид.",
        "Небо, зелёная трава, стеклянные капли и гелевые кнопки.",
        "Город, музыка и молодость: небоскрёбы, колонка, кольца, звёзды и лучи.",
        "Природа и технологии: зелёная Земля, ветряки, солнечные панели и листья.",
        "Голографические розовый и фиолетовый, хромовые сердца, пузыри, блёстки и пиксельные окна.",
        "Бирюзовый, зелёный и жёлтый свет, яркий луч и прозрачные сетчатые волны.",
        "Полупрозрачное сине-индиго стекло, яркий белый свет по краям и преломлённые блики.",
        "Спокойно и просто: мятный фон, прозрачная вода внизу, тонкие границы и мягкое движение."
    )
    override val WALLPAPER = "Фото на фоне"
    override val WP_OFF = "Нет"
    override val WP_ON = "Фото"
    override val WP_PICK = "Выбрать фото из галереи"
    override val WP_PICK_NOTE = "Остаётся на телефоне и никуда не отправляется. Затемнение при необходимости усиливается само, чтобы текст читался."
    override val WP_PRESETS = "Встроенные картинки"
    override val WP_PRESETS_NOTE = "28 картинок в приложении. Интернет не нужен."
    override val WP_REMOVE = "Убрать фото"
    override val WP_DIM = "Сила затемнения"
    override val WP_BLUR = "Размытие"
    override val OPT_WP_BLUR = listOf("Нет", "Слабое", "Сильное")
    override val WP_SAVED = "Фон задан"
    override val WP_FAILED = "Не удалось открыть фото"
    override val WP_REMOVED = "Фон убран"
    override val APP_ICON = "Значок приложения"
    override val ICON_NOTES = listOf(
        "Стеклянный шар: исходный значок.",
        "Стеклянная капля над небом и травой.",
        "Лаймово-бирюзовый город, лучи солнца и кнопка питания.",
        "Глянцевая зелёная Земля с проросшим листом.",
        "Глянцевое хромовое сердце на голографическом розовом и фиолетовом.",
        "Стеклянный шар на бирюзово-жёлтом свечении и волнах света.",
        "Матовый стеклянный шар с яркой кромкой на сине-индиго свете.",
        "Листья скользят на воду, стеклянный значок DNS."
    )
    override val ICON_SET = "Значок сменится после выхода"
    override val ICON_NOTE = "Если ярлык на главном экране пропадёт, добавьте приложение снова."
    override val ICON_FAILED = "Не удалось изменить значок"
    override val HELP_WHY_TITLE = "Зачем это приложение?"
    override val HELP_WHY_BODY = "DNS Hızlı небольшое и простое, его сделал один человек, за ним нет большой компании. Без аккаунта и рекламы: вы сами выбираете DNS, шифрование, к каким приложениям он применяется и как всё выглядит."
    override val HELP_WHY_TAIL = "Возможно, оно не лучше конкурентов, но работает, и его стоит попробовать."
    override val TROUBLE = "Диагностика"
    override val TROUBLE_RECHECK = "Проверить снова"
    override val DIAG_ROW = "Диагностический отчёт"
    override val DIAG_TITLE = "Диагностический отчёт"
    override val DIAG_NOTE = "Отчёт содержит только версию, модель устройства и коды настроек. Без доменных имён, IP-адресов и персональных данных. Ничего не отправляется, пока вы не поделитесь."
    override val DIAG_SHARE_BTN = "Поделиться"
    override val TROUBLE_ALL_OK = "Всё выглядит нормально. Если всё равно не подключается, попробуйте другой сервер."
    override val TROUBLE_SOME = "На что стоит обратить внимание:"
    override val T_NET = "Интернет"
    override val NET_OK = "подключён."
    override val NET_BAD = "нет или ограничен. Проверьте Wi-Fi или мобильные данные."
    override val T_PERM = "Разрешение VPN"
    override val PERM_OK = "выдано."
    override val PERM_BAD = "ещё не выдано. Android спросит при подключении; разрешите."
    override val T_VPN = "Другой VPN"
    override val VPN_OK = "нет."
    override val VPN_BAD = "похоже, включён. Android допускает только один VPN; выключите его."
    override val T_DNS = "Частный DNS Android"
    override val T_LEAK = "Утечка DNS"
    override val YT_ADS = "Серверы рекламы YouTube (частично)"
    override val YT_ADS_NOTE = "Только персональная версия. Блокирует на уровне DNS известные рекламные серверы YouTube. Частично: часть рекламы всё равно проходит; видео не затрагивается."
    override val SITE_DIAG = "Почему сайт не открывается?"
    override val SITE_NO_NAME = "Введите корректный домен, например example.ru."
    override val SITE_VPN_OFF = "DNS Hızlı выключен. Сначала подключитесь, затем попробуйте сайт снова."
    override val SITE_USER_BLOCK = "Это имя в вашем списке блокировки."
    override val SITE_LIST_BLOCK = "Это имя есть в списке рекламы и трекеров; из-за него сайт может работать неправильно."
    override val SITE_CANARY = "Браузер использует это имя для проверки зашифрованного DNS. Оно заблокировано намеренно, это не проблема."
    override val SITE_DOH = "Этот провайдер зашифрованного DNS намеренно отключён шлюзом."
    override val SITE_ALLOWED = "Это имя есть в вашем списке разрешённых; блокировка рекламы его не блокирует."
    override val SITE_NOT_OURS = "DNS Hızlı не блокирует это имя. Скорее всего, проблема в самом сайте или браузере. Чтобы проверить: отключите обход DPI или выберите другой сервер."
    override val SITE_ALLOW_BTN = "Разрешить"
    override val LEAK_OK = "Системный DNS направлен через наш туннель."
    override val LEAK_BAD = "Системный DNS идёт мимо туннеля; запросы могут попасть к оператору."
    override val PDNS_OK = "выключен или автоматический, проблем нет."
    override val PDNS_BAD = "закреплён за одним сервером и может обходить DNS этого приложения. В Настройки > Сеть > Частный DNS выберите «Автоматически» или «Выключено»."
    override val SEARCH = "Поиск"
    override val SEARCH_HINT = "Имя или владелец сервера"
    override val SEARCH_CLEAR = "Очистить"
    override val SHARE_RESULTS = "Поделиться результатами замеров"
    override val SHARE_RESULTS_HEAD = "Замеры DNS Hızlı (сначала самые быстрые)"
    override val NO_RESULTS = "Сначала выполните замер"
    override val CUSTOM_EDIT = "Изменить"
    override fun customUpdated(name: String) = "$name обновлён"
    override val KEEP_HISTORY = "Хранить историю"
    override val KEEP_HISTORY_NOTE = "Когда выключено, недавние серверы, история и замеры не записываются. Уже сохранённое остаётся."
    override val MOTION = "Анимации"
    override val TEXT_SIZE = "Размер текста"
    override val HIGH_CONTRAST = "Высокий контраст"
    override val HIGH_CONTRAST_NOTE = "Более плотное стекло и тёмный текст"
    override val MINIMAL = "Простой вид"
    override val MINIMAL_NOTE = "Скрывает фильтры и строку статистики"
    override val LOW_POWER = "Энергосбережение"
    override val LOW_POWER_NOTE = "Отключает всю анимацию, бережёт батарею"
    override val HAPTICS = "Вибрация"
    override val HAPTICS_NOTE = "Лёгкий отклик при касании"
    override val ENCRYPTION = "Шифрованный DNS"
    override val ENCRYPTION_NOTE = "Авто: сначала DoT, затем DoH, в конце обычный DNS"
    override val AUTO_CONNECT = "Подключаться при запуске"
    override val AUTO_CONNECT_NOTE = "При открытии приложения подключается к последнему серверу"
    override val CONNECT_ON_BOOT = "Подключаться при включении"
    override val CONNECT_ON_BOOT_NOTE = "Подключается сам после перезагрузки телефона"
    override val AUTO_FASTEST = "К самому быстрому"
    override val AUTO_FASTEST_NOTE = "Сфера выбирает самый быстрый сервер по последнему замеру"
    override val REFRESH_ON_NET = "Обновлять при смене сети"
    override val REFRESH_ON_NET_NOTE = "DNS обновляется при переходе между Wi-Fi и мобильной сетью"
    override val NOTIFY_DROP = "Сообщать о разрыве"
    override val NOTIFY_DROP_NOTE = "Уведомление с кнопкой переподключения при обрыве"
    override val NOTIFY_CONNECT = "Сообщать о подключении"
    override val NOTIFY_CONNECT_NOTE = "Короткое уведомление, когда соединение установлено"
    override val NOTIFY_STOP = "Сообщать об отключении"
    override val NOTIFY_STOP_NOTE = "Короткое уведомление, когда вы сами отключаетесь"
    override val NOTIFY_TIMEOUT = "Сообщать о тайм-ауте"
    override val NOTIFY_TIMEOUT_NOTE = "Уведомление, если DNS-сервер перестал отвечать"
    override val NOTIF_PERM = "Разрешение на уведомления"
    override val PERM_ALLOWED = "Включено"
    override val PERM_BLOCKED = "Выключено · исправить"
    override val NOTIF_CONNECTED_TITLE = "DNS подключён"
    override val NOTIF_STOPPED_TITLE = "DNS отключён"
    override val NOTIF_STOPPED_TEXT = "Защита выключена"
    override val NOTIF_TIMEOUT_TITLE = "Тайм-аут DNS"
    override val FAIL_CLOSED = "Блокировать DNS при обрыве"
    override val FAIL_CLOSED_NOTE = "При обрыве запросы DNS не утекают оператору; они не выполняются до повторного подключения"
    override val FILTER_MEM = "Память фильтра"
    override val OPT_FILTER_MEM = listOf("Авто", "Лёгкая", "Полная")
    override val FILTER_MEM_NOTE = "Авто: без большого списка при малой памяти. Лёгкая: без. Полная: с ним"
    override val ERR_NO_APPS = "Приложения не выбраны, защита не запущена. Выберите приложения или переключитесь на «Все приложения»."
    override val NOTIF_SEALED = "DNS заблокирован, идёт переподключение"
    override val ERR_SEALED = "Не удалось подключиться. DNS заблокирован, чтобы запросы не утекли. Нажмите «Отключить», чтобы снять блокировку."
    override val SEALED_INFO = "DNS заблокирован до восстановления связи"
    override val LATENCY_TITLE = "Задержка по запросам"
    override val LATENCY_EMPTY = "Появится вживую после подключения и поступления запросов"
    override val FILTER_MINE = "Мой список"
    override val MINE_PASTE = "Импорт из буфера"
    override val MINE_PASTE_NOTE = "Файл hosts или по одному домену в строке"
    override val MINE_FILE = "Импорт из файла"
    override val MINE_FILE_NOTE = "Файл .txt или hosts на телефоне"
    override val MINE_EXPORT = "Копировать мой список"
    override val MINE_EXPORT_NOTE = "В буфер, в формате hosts"
    override val MINE_CLEAR = "Удалить импортированное"
    override val MINE_FOOT = "Читает строки hosts, простые списки доменов, правила AdBlock (||домен^ и исключения @@), dnsmasq, Unbound и RPZ. До 50 000 имён. Список разрешённых всегда главнее."
    override val MINE_NOTHING = "Подходящих доменов не найдено"
    override val MINE_CLIP_EMPTY = "Буфер пуст"
    override val MINE_FILE_ERR = "Не удалось прочитать файл"
    override val MINE_CLEARED = "Импортированный список удалён"
    override val MINE_CLEAR_ASK = "Удалить импортированный список?"
    override val MINE_CUT = "Достигнут предел, остальное пропущено"
    override fun notifTimeout(name: String) = "$name не отвечает. Пробую снова."
    override val MOD_DPI = "Обход DPI"
    override val MOD_ADS = "Реклама+"
    override val MOD_DPI_SUB = "Открывает блокировки"
    override val MOD_ADS_SUB = "Фильтрует вне DNS"
    override val MOD_ON = "Вкл"
    override val MOD_OFF = "Выкл"
    override val BLOCK_QUIC = "Блокировать QUIC"
    override val BLOCK_QUIC_NOTE = "Приложения вернутся к TCP, и Обход DPI и Реклама+ охватят их тоже"
    override val GW_TRIPPED = "Обнаружена проблема с соединением: Обход DPI и Реклама+ выключены"
    override val MOD_FAILED = "Не удалось включить. Нет разрешения VPN или активен другой VPN."
    override fun gwOn(modules: String) = "Шлюз включён: $modules"
    override fun gwOnStats(modules: String, blocked: String) = "Шлюз включён: $modules · заблокировано $blocked"
    override fun modOn(name: String) = "$name включено"
    override fun modOff(name: String) = "$name выключено"
    override fun modAdsCount(n: String) = "Заблокировано: $n"
    override fun modDpiCount(n: String) = "Разделено соединений: $n"
    override fun latencyLine(avg: String, max: String, timeouts: Int) = "средн. $avg · макс. $max" + (if (timeouts > 0) " · тайм-аутов: $timeouts" else "")
    override fun mineCount(n: Int) = "Доменов: $n"
    override fun mineAdded(n: Int) = "Добавлено доменов: $n"
    override fun mineExcepted(n: Int) = "Исключено по правилам-исключениям: $n"
    override fun mineCopied(n: Int) = "Скопировано доменов: $n"
    override val CACHE = "Кэш DNS"
    override val CLEAR_CACHE = "Очистить кэш"
    override val CACHE_CLEARED = "Кэш очищен"
    override val ONLY_CONNECTED = "Доступно при подключении"
    override val RULE_WIFI = "Сервер для Wi-Fi"
    override val RULE_MOBILE = "Сервер для мобильной сети"
    override val RULE_AUTO = "Авто"
    override val RULE_AUTO_NOTE = "Последний использованный сервер"
    override val COMPACT = "Компактный список"
    override val COMPACT_NOTE = "Короткие строки без описания"
    override val HIDDEN = "Скрытые серверы"
    override val HIDDEN_NONE = "Нет"
    override val STAT_QUERIES = "Всего запросов"
    override val STAT_HITS = "Ответов из кэша"
    override val STAT_BLOCKED = "Заблокировано (оценка)"
    override val STAT_TIME = "Всего подключено"
    override val WEEK = "Последние 7 дней"
    override fun weekA11y(total: String) = "Запросов за 7 дней: $total"
    override val WEEKDAYS = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    override val EXPORT = "Экспорт настроек"
    override val IMPORT = "Импорт настроек"
    override val EXPORTED = "Код настроек скопирован"
    override val IMPORTED = "Настройки загружены"
    override val IMPORT_BAD = "В буфере обмена нет корректного кода настроек"
    override val RESET_SETTINGS = "Сбросить настройки"
    override val RESET_STATS = "Сбросить статистику"
    override val CONFIRM = "Вы уверены?"
    override val RESET = "Сбросить"
    override val RESET_DONE = "Сброшено"
    override val LOG = "Журнал диагностики"
    override val HELP = "Как это работает?"
    override val VPN_SETTINGS = "Настройки VPN системы"
    override val SHARE_APP = "Поделиться приложением"
    override val RATE_APP = "Оценить приложение"
    override val FEEDBACK = "Отправить отзыв"
    override fun shareAppText(url: String) = "$APP подключает к популярным DNS одним касанием: $url"
    override val VERSION = "Версия"
    override val OPT_BUBBLES = listOf("Нет", "Мало", "Много")
    override val OPT_MOTION = listOf("Все", "Меньше", "Нет")
    override val OPT_CACHE = listOf("Нет", "Малый", "Обычный", "Большой")
    override val OPT_ENCRYPTION = listOf("Авто", "DoT", "DoH", "Нет")
    override val PLAIN_DNS = "Обычный DNS"

    override val LOG_NOTE = "Хранятся только события подключения. Имена запросов и личные данные не записываются."
    override val LOG_EMPTY = "Записей пока нет."
    override val SHARE = "Поделиться"
    override val CLEAR = "Очистить"
    override val CLEARED = "Очищено"
    override val HELP_SECTIONS = listOf(
        "Что такое DNS?" to
            "DNS — это служба, которая превращает интернет-адреса (например, example.com) в числа, понятные устройствам. " +
            "От выбранного DNS зависят скорость, приватность и то, что будет заблокировано.",
        "Что делает приложение?" to
            "Оно использует выбранный DNS-сервер во всех приложениях. Для этого на телефоне открывается локальный VPN-интерфейс, " +
            "но ваш трафик не идёт на VPN-сервер. На выбранный сервер отправляются только DNS-запросы, " +
            "всё остальное идёт обычным путём.",
        "Шифрованный DNS (DoT / DoH)" to
            "На серверах с поддержкой запросы передаются зашифрованными: никто в сети (владелец Wi-Fi, оператор) не видит, " +
            "какие сайты вы открываете, и не может подменить ответы. В режиме «Авто» сначала пробуется DoT, затем DoH; " +
            "если не работает ни один, используется обычный DNS. Вас об этом предупредят, а приложение будет пытаться вернуться к шифрованию " +
            "при каждой смене сети и каждые 10 минут. При включённом «Строгом шифровании» обычный DNS не используется никогда. " +
            "Главный экран показывает, какой способ сейчас используется.",
        "Проверка подключения" to
            "☰ > Настройки DNS > Проверка подключения отправляет настоящие DNS-запросы через туннель. Она показывает, что " +
            "DNS действительно отвечает с выбранного сервера, как быстро, проверяет ли сервер подписи DNSSEC " +
            "и блокирует ли известный рекламный домен.",
        "Приватность" to
            "Без аккаунта, без сбора данных, без рекламы. Приложение не хранит имена запросов и ничего не отправляет само. " +
            "Ваши запросы идут только выбранному DNS-провайдеру, по его политике конфиденциальности. " +
            "Шифрованный DNS (DoT/DoH) не даёт никому в сети читать или подменять ваши запросы. Перед отправкой приложение убирает лишние данные, которые могли бы выдать устройство (подсеть клиента, cookie, идентификаторы), дополняет сообщения, чтобы скрыть их длину, и сбрасывает билеты сессий TLS при смене сети. " +
            "Честно говоря: без ретранслятора DNS-провайдер всё равно видит ваш публичный IP-адрес (ему же нужно вам ответить), а ошибка сертификата может означать, что кто-то вмешивается в соединение. " +
            "В журнале диагностики только события подключения.",
        "Батарея и ресурсы" to
            "В фоне расходует очень мало. При выключенном экране ничего не крутится в цикле; " +
            "работа идёт только при поступлении DNS-запроса. Шифрованные соединения закрываются сами при простое.",
        "Полезно знать" to
            "Android разрешает только один VPN одновременно; при активном другом VPN это приложение не подключится. " +
            "«Безопасный DNS» в браузерах и «Частный DNS» Android с указанным именем используют свой сервер " +
            "и могут обходить это перенаправление; достаточно оставить их в режиме «Автоматически» или «Отключено». " +
            "Долгое нажатие на сферу: быстрый выбор сервера или пауза подключения.",
    )

    override val NOTIF_CHANNEL = "Состояние подключения"
    override val NOTIF_CHANNEL_NOTE = "Показывается, пока DNS-подключение активно"
    override val NOTIF_ALERT_CHANNEL = "Предупреждения о подключении"
    override val NOTIF_CONNECTING = "Подключение…"
    override val NOTIF_STOP = "Отключить"
    override val NOTIF_NEXT = "Следующий"
    override val NOTIF_DROP_TITLE = "DNS-подключение прервано"
    override val NOTIF_RECONNECT = "Переподключить"
    override fun notifOn(name: String, proto: String) = "Подключено к $name · $proto"
    override fun notifPaused(time: String) = "Пауза · продолжение в $time"
    override val TILE_ON = "Подключено"
    override val TILE_OFF = "Выкл."
    override val WIDGET_TAP = "Касание: подключить / отключить"
    override val ERR_PERMISSION = "Разрешение VPN не выдано"
    override val ERR_ESTABLISH = "Не удалось открыть VPN-интерфейс. Возможно, активен другой VPN."
    override fun errNoReply(name: String) = "$name не ответил"
    override val PHONE_BYPASS = "Телефон не берёт этот DNS (Частный DNS?)"
    override fun errNoProto(name: String, proto: String) = "$name не поддерживает $proto"
    override val ERR_SOCKET = "Сеть недоступна"
    override fun errPrivateDns(host: String) = "Частный DNS Android закреплён за $host и обходит приложение. Установите Настройки > Сеть > Частный DNS: Автоматически или Отключено."
    override val ERR_REVOKED = "Подключение закрыто системой"
    override val ERR_TUNNEL = "Туннель неожиданно закрылся"
    override val ERR_UNKNOWN = "Произошла непредвиденная ошибка"

    override val CONSENT_TITLE = "Перед подключением"
    override val CONSENT_BODY = listOf(
        "$APP использует VPN-интерфейс Android, чтобы направлять ваши DNS-запросы (имена посещаемых сайтов) на выбранный DNS-сервер.",
        "Ваш трафик не отправляется на VPN-сервер; к выбранному провайдеру идут только DNS-запросы. На серверах с поддержкой " +
            "они шифруются (DoT/DoH), на остальных передаются без шифрования. Действует политика конфиденциальности провайдера." +
            " Если включить «$MOD_DPI» или «$MOD_ADS», весь трафик идёт через ретранслятор, работающий только внутри телефона; он по-прежнему никуда не отправляется.",
        "Приложение не собирает личные данные, не хранит имена запросов и ничего никому не передаёт.",
        "Если продолжить, Android покажет запрос на VPN-подключение; нужно нажать «ОК».",
    )
    override val CONSENT_OK = "Понятно, продолжить"
    override val CLOSE = "Закрыть"
    override val BACK = "Назад"

    // ---- 3. sürüm ----
    override val RESUMING = "Возобновление…"
    override val DOWNGRADED = "Шифрование не удалось, обычный DNS"
    override val UPGRADED = "Снова шифрованный DNS"
    override val ODOH = "Oblivious DoH (ODoH)"
    override val OPT_ODOH = listOf("Выкл.", "Запас", "Строго")
    override val ODOH_NOTE = "Ретранслятор видит ваш IP, но не вопрос; сервер — вопрос, но не вас."
    override val DOWNGRADED_ODOH = "ODoH недоступен, используется обычное шифрованное соединение"
    override val NOTIF_ODOH_TITLE = "ODoH не активен"
    override fun notifOdoh(name: String) = "Не удалось связаться с ретрансляторами ODoH. Используется обычное соединение с $name; приложение продолжит попытки вернуться к ODoH."
    override val ERR_NO_ODOH = "Не удалось подключиться через ODoH: ретрансляторы или цели не отвечают"
    override val NOTIF_DOWNGRADE_TITLE = "DNS не зашифрован"
    override fun notifDowngrade(name: String) = "Не удалось установить шифрованное подключение к $name. Используется обычный DNS; приложение попробует вернуться к шифрованию."
    override fun backupUsed(failed: String, used: String) = "$failed не ответил, подключено к $used"
    override val NOTIF_RETRYING = "Подключение прервано, повтор…"
    override fun errNoEncrypted(name: String) = "Не удалось установить шифрованное подключение к $name"
    override fun errUntrusted(name: String) = "Не удалось проверить сертификат $name: сеть или программа, возможно, вмешивается в шифрованные подключения"
    override val APPLYING = "Новая настройка применяется к подключению"
    override val CONFIRM_DISCONNECT = "Отключиться?"
    override val DISCONNECT = "Отключить"

    override val SEC_NOTIF = "Уведомления"
    override val STRICT_ENC = "Строгое шифрование"
    override val STRICT_ENC_NOTE = "Никогда не переходить на обычный DNS"
    override val IP_MODE = "Версия IP"
    override val IP_MODE_NOTE = "Сначала пробуется та, что есть в вашей сети; другая — запасная"
    override val OPT_IP_MODE = listOf("IPv4 + IPv6", "Только IPv4")
    override val FILTER = "Блокировка"
    override val FILTER_LEVEL = "Блокировка рекламы и трекеров"
    override val OPT_FILTER = listOf(
        "Выкл",
        "Базовый",
        "Средний",
        "Строгий",
    )
    override val FILTER_NOTES = listOf(
        "Ничего не фильтруется.",
        "Сторонние списки известных рекламных и вредоносных доменов. Обычно низкий риск сбоев.",
        "Базовый список плюс больше трекеров и аналитики. Некоторые сайты могут работать с ошибками.",
        "Самый широкий: мошенничество, перенаправления и рискованные зоны (.cfd, .icu…). Частые сбои.",
    )
    override val FILTER_INFO = "Фильтрация выполняется на телефоне: при запросе имени из списка возвращается ответ «не найдено», имя не сохраняется. Работает только при подключении. Настройка безопасного DNS в браузере может её обойти. Если сайт перестал работать, разрешите его в разделе «Недавно отфильтрованные». Списки могут быть неполными; ни один фильтр не ловит всё."
    override val FILTER_LAST = "Недавно заблокированные"
    override val FILTER_RECENT_NOTE = "Нажмите: разрешить"
    override val FILTER_RECENT_EMPTY = "В этом сеансе ничего не заблокировано. Имена появятся здесь при подключении и включённом уровне."
    override val FILTER_RECENT_FOOT = "Только в памяти на время сеанса; не сохраняется, удаляется при отключении."
    override val FILTER_PASSED = "Недавно разрешённые"
    override val FILTER_PASSED_NOTE = "Нажмите: заблокировать"
    override val FILTER_PASSED_EMPTY = "В этом сеансе пока ничего не разрешено. Имена появляются здесь при подключении и включённом уровне."
    override val FILTER_PASSED_FOOT = "Если реклама всё ещё видна, найдите здесь похожее на рекламу имя и нажмите, чтобы заблокировать. Хранится только в памяти в этом сеансе; не сохраняется."
    override val FILTER_SUSPECT_NOTE = "Похоже на рекламу · нажмите: заблокировать"
    override val FILTER_BLOCK_SUSPECTS = "Заблокировать все подозрительные"
    override val FILTER_ALLOW = "Разрешённые"
    override val FILTER_BLOCK = "Мой список блокировки"
    override val FILTER_ADD = "Добавить…"
    override val FILTER_REMOVE = "Нажмите: убрать"
    override val FILTER_ALLOW_ADD = "Домен для разрешения"
    override val FILTER_BLOCK_ADD = "Домен для блокировки"
    override val FILTER_ERR = "Введите допустимый домен, например primer.ru"
    override val FILTER_ERR_LIMIT = "Не более 200 доменов"
    override val FILTER_ERR_SUFFIX = "Это общий суффикс (например, co.uk), он охватывает все сайты. Введите конкретный сайт"
    override val FILTER_ALLOW_EMPTY = "Разрешённых доменов нет. Если сайт перестал работать, добавьте его сюда."
    override val FILTER_BLOCK_EMPTY = "Ваш список блокировки пуст."
    override val FILTER_ALLOW_FOOT = "Домен и все его поддомены никогда не блокируются. Разрешение сильнее всех списков и вашего списка блокировки."
    override val FILTER_BLOCK_FOOT = "Домен и все его поддомены блокируются всегда (даже при выключенном уровне)."
    override val FILTER_REMOVE_BTN = "Убрать"
    override fun filterAllowed(name: String) = "$name: разрешено"
    override fun filterBlocked(name: String) = "$name будет заблокирован"
    override fun filterRemoved(name: String) = "$name убран"
    override fun filterRemoveAsk(name: String) = "Убрать $name из списка?"
    override val TEST_IPV6 = "Путь IPv6"
    override val AUTO_RECONNECT = "Автопереподключение"
    override val AUTO_RECONNECT_NOTE = "При разрыве повтор через 5 с, 30 с и 2 мин"
    override val BACKUP_SERVER = "Резервный сервер"
    override val BACKUP_OFF = "Нет"
    override val BACKUP_OFF_NOTE = "Не подключаться, если выбранный сервер не отвечает"
    override val BACKUP_FASTEST = "Самый быстрый"
    override val BACKUP_FASTEST_NOTE = "Самый быстрый из других серверов по последнему замеру"
    override val CONFIRM_OFF = "Спрашивать перед отключением"
    override val CONFIRM_OFF_NOTE = "Случайное касание сферы не отключит"
    override val LOCK_HIDE = "Скрыть на экране блокировки"
    override val LOCK_HIDE_NOTE = "Имя сервера не видно в уведомлении на экране блокировки"
    override val QUIET_NOTIF = "Тихое уведомление"
    override val QUIET_NOTIF_NOTE = "Без значка в строке состояния, без звука"
    override val REMEMBER_FILTER = "Запоминать фильтр"
    override val REMEMBER_FILTER_NOTE = "При открытии приложения вернётся последний выбранный фильтр"
    override val AUTO_MEASURE = "Замер при запуске"
    override val AUTO_MEASURE_NOTE = "Измеряет сам, если последнему замеру больше суток"
    override val MEASURE_ENC = "Шифрованный замер"
    override val MEASURE_ENC_NOTE = "Измеряет скорость через DoT, ближе к реальной работе с шифрованием"
    override val OPT_SORT = listOf("Обычный", "Скорость", "Название")
    override fun sortA11y(mode: String) = "Сортировка: $mode"
    override val AUTO_LIGHT = "Авто: светлая тема"
    override val AUTO_DARK = "Авто: тёмная тема"
    override val NIGHT_HOURS = "Ночные часы"
    override val FILTER_ENCRYPTED = "Шифрованные"
    override val FILTER_UNFILTERED = "Без фильтра"

    override val TEST = "Проверить подключение"
    override val TEST_NOTE = "DNS, DNSSEC и блокировка рекламы"
    override val TESTING = "Проверка…"
    override val TEST_TITLE = "Проверка подключения"
    override val TEST_OK = "DNS работает"
    override val TEST_FAIL = "Нет ответа"
    override val TEST_SERVER = "Сервер"
    override val TEST_METHOD = "Способ"
    override val TEST_LATENCY = "Время ответа"
    override val TEST_DNSSEC = "Проверка DNSSEC"
    override val TEST_ADS = "Блокировка рекламы"
    override val DNSSEC_YES = "Проверяет"
    override val DNSSEC_NO = "Не проверяет"
    override val ADS_YES = "Вкл."
    override val ADS_NO = "Выкл."
    override val UNKNOWN = "Неизвестно"
    override val TEST_EXPLAIN = "Запросы отправлены через туннель так же, как их отправило бы приложение; ответы пришли от выбранного сервера."
    override val TEST_AGAIN = "Проверить снова"

    override val RECOMMEND = "Подобрать сервер"
    override val RECOMMEND_NOTE = "Выберите цель, и мы подключим самый быстрый подходящий"
    override val GOAL_SPEED = "Скорость"
    override val GOAL_SPEED_NOTE = "Самый быстрый сервер по вашим замерам"
    override val GOAL_PRIVACY_NOTE = "Без журналов, упор на приватность"
    override val GOAL_ADS_NOTE = "Фильтрует рекламу и трекеры"
    override val GOAL_FAMILY_NOTE = "Фильтрует контент для взрослых"
    override val GOAL_SECURITY_NOTE = "Фильтрует вредоносные и фишинговые сайты"
    override fun recommended(name: String) = "Рекомендуем: $name"

    override val PRIVATE_DNS = "Имя для частного DNS"
    override val PRIVATE_DNS_NOTE = "Его можно вставить в настройку «Частный DNS» Android. Тогда система будет использовать этот сервер напрямую, в обход приложения."
    override val CLEAR_HISTORY = "Очистить историю замеров"
    override val HISTORY_CLEARED = "Замеры очищены"

    override val GUARD = "Постоянная защита"
    override val GUARD_NOTE = "Постоянная VPN"
    override val GUARD_BODY = listOf(
        "Пока приложение не подключено (выключено, на паузе или после разрыва), ваши DNS-запросы идут на сервер интернет-провайдера.",
        "Чтобы этого избежать, включите для этого приложения «Постоянная VPN» в настройках VPN Android. Если также включено «Блокировать соединения без VPN», интернет совсем не будет работать, пока приложение не подключено: утечек нет, но пауза тоже означает отсутствие интернета.",
        "С постоянной VPN система сама запускает приложение при включении телефона и после его остановки.",
    )
    override val GUARD_BUTTON = "Открыть настройки VPN"
    override val BATTERY = "Настройки батареи"
    override val BATTERY_OK = "Без ограничений"
    override val BATTERY_LIMITED = "Может ограничиваться"
    override val BATTERY_BODY = listOf(
        "Android обычно защищает VPN-приложения. Но некоторые производители (Xiaomi, Huawei, Oppo, Vivo, некоторые версии Samsung) могут закрывать фоновые приложения ради экономии батареи.",
        "Если подключение само обрывается, установите для этого приложения расход батареи «Без ограничений» или «Не оптимизировать»; на некоторых телефонах также разрешите «Автозапуск».",
    )
    override val BATTERY_BUTTON = "Открыть настройки батареи"

    override val BOOT_TAP = "Не удалось подключиться при запуске. Нажмите, чтобы подключиться."
    override val REBIND = "Защита локальной сети"
    override val REBIND_NOTE = "Не даёт сайтам добраться до роутера и домашних устройств через DNS"
    override val DOH_GUARD = "Блокировать собственный DNS браузера"
    override val DOH_GUARD_NOTE = "Браузер не обойдёт фильтр своим DNS. Сбои? Отключите безопасный DNS"
    override val STAT_AVG = "Среднее время ответа"
    override val STAT_SAVED = "Время, сэкономленное кэшем"
    override val STAT_TRAFFIC = "DNS-трафик"
    override val SESSIONS = "История подключений"
    override val SESSIONS_NOTE = "Последние 30 подключений; имена запросов не хранятся"
    override val SESSIONS_EMPTY = "Подключений пока не записано."
    override val MOST_USED = "Чаще всего"
    override val TODAY = "Сегодня"
    override val ORB_SHAPE = "Форма шара"
    override val ORB_SHAPE_EACH = "Форма для темы"
    override val ORB_SHAPE_NAMES = listOf("Шар", "Треугольник", "Квадрат", "Шестиугольник", "Звезда", "Восьмиугольник", "Пятиугольник", "Прямоугольник", "Перевёрнутый треугольник", "Ромб", "Цветок", "Шестиконечная звезда")
    override val SHIELD_WORD = "Щит"
    override val LIQUID_COLOR = "Цвет жидкости"
    override val LIQUID_THEME = "По теме"
    override val COLOR_WORD = "Цвет"
    override val LIQUID_NOTE = "Выбранный цвет заменяет оттенок скорости; скорость волн по-прежнему зависит от скорости сервера."
    override val YESTERDAY = "Вчера"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Вы отключили"
        EndReason.PAUSE -> "Пауза"
        EndReason.SWITCH -> "Смена сервера"
        EndReason.DROP -> "Разрыв"
        EndReason.REVOKED -> "Закрыто системой"
        EndReason.FAILED -> "Нет ответа"
        EndReason.NETWORK -> "Смена сети"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · запросов: $queries"

    override val SOUND_MOTION = "Звук и движение"
    override val SEC_SOUND = "Звук"
    override val SOUND_ON = "Звуковые эффекты"
    override val SOUND_ON_NOTE = "Короткие мягкие звуки при касании и подключении. Не звучат, если телефон в беззвучном режиме."
    override val SOUND_UI = "Звуки касаний"
    override val SOUND_UI_NOTE = "Кнопки, переключатели и смена страниц"
    override val SOUND_CONN = "Звуки подключения"
    override val SOUND_CONN_NOTE = "Отдельные звуки при подключении, отключении и ошибке"
    override val SOUND_VOL = "Громкость"
    override val SOUND_PACK = "Набор звуков"
    override val SOUND_TEST = "Проверить звук подключения"
    override val QUIET_HOURS = "Тихие часы"
    override val QUIET_NOTE = "В это время нет звуков и вибрации"
    override val QUIET_RANGE = "Промежуток тихих часов"
    override val SEC_MOTION_FX = "Движение и эффекты"
    override val ANIM_SPEED = "Скорость анимации"
    override val TAP_FX = "Эффект касания"
    override val TAP_FX_NOTE = "Небольшой эффект в стиле темы там, где ты касаешься"
    override val CELEBRATE = "Праздник при подключении"
    override val CELEBRATE_NOTE = "Шоу в стиле темы вокруг шара после подключения"
    override val HAPTIC_LEVEL = "Сила вибрации"
    override val REMEMBER_MODS = "Помнить модули"
    override val REMEMBER_MODS_NOTE = "При подключении Обход DPI и Реклама+ включаются так, как ты их оставил"
    override val PROFILES = "Профили"
    override val COPY_STATUS = "Копировать сводку состояния"
    override val OPT_PACK = listOf("Авто", "Мягкий", "Стекло", "Классика")
    override val SOUND_PACK_NOTE = "Авто: звук текущего стиля"
    override val SOUND_OUT = "Вывод звука"
    override val OPT_SOUND_OUT = listOf("Авто", "Система", "Медиа")
    override val SOUND_OUT_NOTES = listOf("Если системный звук выключен, играет через медиа", "Тот же канал, что и звуки касаний", "Звучит даже в режиме вибрации")
    override val SOUND_BLOCK_RINGER = "Телефон в беззвучном режиме или на вибрации. Выберите вывод: Медиа."
    override val SOUND_BLOCK_ZERO = "Громкость выключена, звук не воспроизведён."
    override val PACK_SPACE = "Космос"
    override val PACKS_NOTE = "Новые пакеты (и Liquid Glass) имеют свои звуки и по десять анимаций: касание, переключатель, подключение, отключение, ошибка, готово, панель, назад, выбор и обновление."
    override val OPT_HAPTIC = listOf("Слабая", "Обычная", "Сильная")
    override val PROFILE_NAMES = listOf("Скорость", "Приватность", "Семья", "Полная защита")
    override val PROFILE_NOTES = listOf("Самый быстрый сервер, большой кэш, без блокировки", "Строгое шифрование, блокировка трекеров, Реклама+", "Сервер с семейным фильтром, средняя блокировка", "Блокировка рекламы и трекеров, Обход DPI, Реклама+")
    override fun profileApplied(name: String) = "Профиль применён: $name"

    override val WHATS_NEW = "Что нового?"
    override val WHATS_NEW_TOAST = "Приложение обновлено"
    override val SHOW = "Показать"
    override val WHATS_NEW_ITEMS = listOf(
        "Новое: подстройка под телефон (Samsung, Xiaomi, Honor…), более сильный DPI и обновлённая Персонализация. ☰ > Персонализация.",
        "Новое: надёжнее фильтр; искажённые и хитрые DNS-запросы отклоняются, обновление списков устойчиво к сбоям. ☰ > Блокировка.",
        "Новое: стиль Duru; спокойные мятные тона, листья на воде, свои значок, звуки и анимации. ☰ > Персонализация > Стиль.",
        "Новое: звуки теперь играют даже в режиме вибрации (через медиа); молчат только в полностью беззвучном режиме. ☰ > Звук и движение.",
        "Новое: вывод звука для «немых» телефонов (☰ > Звук и движение), защита локальной сети, блокировка в 5 раз быстрее, настройки батареи.",
        "Новое: необязательный Oblivious DoH (ODoH): ретранслятор видит ваш IP, DNS-сервер — запросы, но не оба сразу. ☰ > Настройки DNS.",
        "Новое: звуковые эффекты, новый плавный движок анимации, эффекты касания по стилям, профили, тихие часы. ☰ > Звук и движение.",
        "Новое: кнопки «Обход DPI» и «Реклама+». Работают вместе с DNS или отдельно; по умолчанию выключены.",
        "Новое: импорт своего списка блокировки, уведомления о подключении, обрыве и тайм-ауте, график задержки и блокировка DNS при обрыве.",
        "Новое: список сначала показывает 8 серверов (Показать все / Показать меньше), Добавить свой DNS вверху, тонкая полоса прокрутки.",
        "Новое: блокировка рекламы, трекеров и вредоносных сайтов (Выкл/Базовый/Средний/Строгий), свои списки. ☰ > Блокировка. Всё на телефоне.",
        "Новое: стиль Frutiger Aurora; Y2K стал голографическим, Metro про город и музыку. Выбор: ☰ > Персонализация > Стиль.",
        "Новое: IPv4 и IPv6 вместе, быстрее находим сбои; ради приватности из запросов убираются следы устройства, а длина сообщений скрывается.",
        "Новое: настройки разделены по темам. Меню ☰ открывает Настройки DNS, Подключение и приложения, Уведомления, Список серверов, Статистику и историю, Данные.",
        "Новое: окно «Персонализация» (в меню ☰): язык, тема, стиль, фон, значок, текст и доступность.",
        "Новое: меню ☰ на главном экране и окно «О приложении» (новости, справка, журнал, поделиться, версия).",
        "Исправление: свой снимок и встроенные картинки снова можно ставить фоном (размер фото читался неверно).",
        "Исправление: проверка соединения отличает сбой сервера от телефона, не использующего DNS, и предупреждает.",
        "Исправление: стили Metro, Eco и Y2K перерисованы; смена значка применяется после выхода из приложения.",
        "Новое: 8 встроенных фонов (☰ → Персонализация → Фото фона → Встроенные картинки).",
        "Новое: диагностика, поиск серверов, обмен результатами замеров, правка своих серверов и режим без истории.",
        "Значок приложения: выберите один из пяти значков под пять стилей.",
        "Фото на фоне: свой снимок в качестве фона с настройкой затемнения и размытия; текст всегда читается.",
        "Пять стилей: Aqua (классика), Aero (небо и трава), Metro (плоские плитки), Eco (природа) и розовый Y2K — у каждого свои анимации, а переходы стали плавнее.",
        "Выбор приложений: применяйте DNS только к выбранным приложениям или исключайте некоторые.",
        "Свои DNS-серверы (до 8), 10 новых серверов и раздел сведений у каждого сервера: для чего нужен, владелец, средний пинг.",
        "Более надёжное подключение: дополнительные проверки против поддельных ответов DNS, предупреждение при переходе на обычный DNS, строгое шифрование и автоматический возврат к шифрованию.",
        "Проверка подключения: одним касанием убедитесь, что DNS отвечает от выбранного сервера, а также проверьте DNSSEC и блокировку рекламы.",
        "Резервный сервер и автопереподключение: приложение само восстанавливается, если выбранный сервер не отвечает или подключение обрывается.",
        "История подключений, самые используемые серверы, среднее время ответа и DNS-трафик.",
        "Новые фильтры («Шифрованные», «Без фильтра»), сортировка по названию, «Подобрать сервер» и замер при запуске.",
        "Живые счётчики в уведомлении, кнопка паузы на 15 минут, скрытие на экране блокировки и тихое уведомление.",
        "Три новые темы («Сакура», «Мёд», «Северное сияние»), тема по цвету обоев и выбор светлой/тёмной темы для режима Авто.",
        "Четыре новых языка: индонезийский, вьетнамский, польский и украинский.",
    )
    override fun importedWith(changes: String) = "Настройки загружены · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "шифрование ослаблено"
        SensitiveChange.AUTO_START -> "включено автоподключение"
        SensitiveChange.RULES -> "изменены правила серверов"
        SensitiveChange.PRIVACY -> "ослаблены настройки приватности или уведомлений"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · запросов: $queries · заблокировано: $blocked"
    override val NOTIF_LOCKED = "Защита DNS включена"
    override val NOTIF_QUIET_CHANNEL = "Состояние подключения (тихое)"
    override fun widgetToday(queries: String) = "Сегодня запросов: $queries"
    override fun pauseAction(minutes: Int) = "Пауза ${minutes(minutes)}"


    override val CUSTOM_NOTE = "Добавленный вами сервер"
    override val CUSTOM_ADD = "Добавить свой DNS"
    override val CUSTOM_F_NAME = "Название"
    override val CUSTOM_F_IP1 = "Адрес IPv4 (напр. 1.2.3.4)"
    override val CUSTOM_F_IP2 = "Второй IPv4 (необязательно)"
    override val CUSTOM_F_DOT = "Имя DoT (необязательно)"
    override val CUSTOM_F_DOH = "Адрес DoH, https://… (необязательно)"
    override val CUSTOM_SAVE = "Добавить"
    override val CUSTOM_CANCEL = "Отмена"
    override val CUSTOM_HINT = "Для шифрованного соединения заполните DoT или DoH; иначе используется обычный DNS."
    override val CUSTOM_ERR_NAME = "Название: 1–24 символа (без | ; , =)"
    override val CUSTOM_ERR_IP = "Введите корректный адрес IPv4 (напр. 1.2.3.4)"
    override val CUSTOM_ERR_DOT = "Имя DoT должно быть доменным именем"
    override val CUSTOM_ERR_DOH = "Адрес DoH должен начинаться с https://"
    override val CUSTOM_ERR_LIMIT = "Можно добавить не более 8 своих серверов"
    override fun customAdded(name: String) = "$name добавлен"
    override val CUSTOM_DELETE = "Удалить этот сервер"
    override val CUSTOM_IN_USE = "Нельзя удалить во время подключения"
    override fun customDeleted(name: String) = "$name удалён"
    override val INFO_PURPOSE = "Для чего нужен"
    override val INFO_OWNER = "Владелец"
    override val INFO_AVG = "Средний пинг"
    override fun avgPing(ms: Int, n: Int) = "$ms $msU · измерений: $n"

    override val APPS = "Приложения"
    override val APPS_ALL = "Все"
    override fun appsOnly(n: Int) = "Только выбранные ($n)"
    override fun appsExcept(n: Int) = "Все, кроме выбранных ($n)"
    override val APPS_MODE = "Для каких приложений применять DNS?"
    override val OPT_APPS = listOf("Все", "Выбранные", "Кроме выбр.")
    override val APPS_NOTE = "Остальные приложения используют DNS телефона. Работает один DNS-сервер; выбрать разные для приложений нельзя."
    override val APPS_LOADING = "Загрузка приложений…"
    override val APPS_EMPTY = "Приложения не найдены"
    override val APPS_NONE_SELECTED = "Приложения не выбраны: защита не запустится. Выберите приложения или переключитесь на «Все приложения»."
    override val APPS_APPLY = "Применить сейчас"
    override val APPS_PENDING = "Изменение вступит в силу при обновлении соединения (разрыв на пару секунд)."

    override val NOTES = mapOf(
        "cloudflare" to "Быстрый",
        "google" to "Широко используется",
        "quad9" to "Фильтрует вредоносные домены",
        "adguard" to "Фильтрует рекламу и трекеры",
        "controld" to "Без фильтрации, быстрый",
        "opendns" to "Cisco, фильтрует фишинговые домены",
        "dnssb" to "Бережёт приватность, быстрый",
        "dns4eu" to "DNS ЕС, фильтр вредоносов",
        "uncensored" to "Без фильтров и перенаправлений",
        "quad9-open" to "Без фильтрации",
        "adguard-open" to "Без фильтрации",
        "dns4eu-open" to "DNS ЕС, без фильтрации",
        "controld-ads" to "Фильтр рекламы, трекеров и вредоносов",
        "dns4eu-ads" to "DNS ЕС, фильтр рекламы и вредоносов",
        "cloudflare-security" to "Фильтр вредоносных сайтов",
        "controld-malware" to "Фильтр вредоносных сайтов",
        "cleanbrowsing-security" to "Фильтр фишинга и вредоносных сайтов",
        "cloudflare-family" to "Фильтр вредоносов и 18+",
        "opendns-family" to "Фильтр контента для взрослых",
        "adguard-family" to "Фильтр рекламы и контента для взрослых",
        "cleanbrowsing-family" to "Контент для взрослых, безопасный поиск",
        "dns4eu-child" to "DNS ЕС, защита детей",
        "controld-family" to "Фильтр контента для взрослых",
        "nextdns" to "Настраиваемый фильтр",
        "cira-private" to "Канада, без фильтра, приватность",
        "cira-protected" to "Канада, фильтр вредоносных сайтов",
        "libredns" to "Независимый, без фильтрации",
        "switch" to "Швейцария, фильтр вредоносных сайтов",
        "wikimedia" to "DNS Wikimedia, бережёт приватность",
        "digitale" to "Швейц. НКО, без фильтрации",
        "quad101" to "Тайвань, быстрый",
        "alidns" to "Китай, быстрый",
    )
}
