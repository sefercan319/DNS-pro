package app.dnshizli.core

/** Hazır görünümler: cam, hareket ve hız tek dokunuşla birlikte ayarlanır. */
enum class LookPreset(val glass: Float, val motion: Motion, val speed: Float) {
    CALM(0.30f, Motion.REDUCED, 0.8f),
    BALANCED(0.55f, Motion.REDUCED, 1f),
    VIVID(0.80f, Motion.FULL, 1f),
}

/**
 * Görünüm ayarlarının toplu işlemleri (saf mantık). "Görünüm": tema, stil, küre, arka plan, cam, yazı boyutu, hareket.
 * DNS, filtre, ağ, geçmiş ve kullanım ayarlarına dokunulmaz.
 */
object Look {
    fun apply(s: AppSettings, p: LookPreset): AppSettings = s.copy(glass = p.glass, motion = p.motion, animSpeed = p.speed)

    /** [s] tam olarak hangi hazır görünüme uyuyor (hiçbirine uymuyorsa null)? */
    fun match(s: AppSettings): LookPreset? = LookPreset.values().firstOrNull { it.glass == s.glass && it.motion == s.motion && it.speed == s.animSpeed }

    /** [from]'daki görünüm alanlarını [to]'ya yazar; diğer tüm ayarlar [to]'da kalır. */
    fun copyLook(from: AppSettings, to: AppSettings): AppSettings = to.copy(
        theme = from.theme, autoLight = from.autoLight, autoDark = from.autoDark, themeSchedule = from.themeSchedule, nightHours = from.nightHours,
        customTheme = from.customTheme, style = from.style, orbFlow = from.orbFlow, orbShapes = from.orbShapes, liquidColor = from.liquidColor,
        orbPct = from.orbPct, fxPart = from.fxPart, fxPct = from.fxPct, soundPart = from.soundPart,
        wpDim = from.wpDim, wpBlur = from.wpBlur,
        glass = from.glass, textScale = from.textScale, motion = from.motion, animSpeed = from.animSpeed,
        highContrast = from.highContrast, lowPower = from.lowPower,
    )

    /** Görünüm alanlarını varsayılana döndürür. Fotoğraf, uygulama simgesi ve diğer ayarlar korunur. */
    fun reset(s: AppSettings): AppSettings = copyLook(DEFAULTS, s)

    private val DEFAULTS = AppSettings()

    /** Görünüm alanlarından kaçı varsayılandan farklı? Her karede sorulabilir: bellek ayırmaz. */
    fun changedCount(s: AppSettings): Int {
        val d = DEFAULTS
        var n = 0
        if (s.theme != d.theme) n++
        if (s.autoLight != d.autoLight) n++
        if (s.autoDark != d.autoDark) n++
        if (s.themeSchedule != d.themeSchedule) n++
        if (s.nightHours != d.nightHours) n++
        if (s.customTheme != d.customTheme) n++
        if (s.style != d.style) n++
        if (s.orbFlow != d.orbFlow) n++
        if (s.orbShapes != d.orbShapes) n++
        if (s.liquidColor != d.liquidColor) n++
        if (s.orbPct != d.orbPct) n++
        if (s.fxPart != d.fxPart) n++
        if (s.fxPct != d.fxPct) n++
        if (s.soundPart != d.soundPart) n++
        if (s.wpDim != d.wpDim) n++
        if (s.wpBlur != d.wpBlur) n++
        if (s.glass != d.glass) n++
        if (s.textScale != d.textScale) n++
        if (s.motion != d.motion) n++
        if (s.animSpeed != d.animSpeed) n++
        if (s.highContrast != d.highContrast) n++
        if (s.lowPower != d.lowPower) n++
        return n
    }
}
