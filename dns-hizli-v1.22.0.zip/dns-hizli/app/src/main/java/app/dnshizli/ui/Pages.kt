package app.dnshizli.ui

import app.dnshizli.core.WallpaperPresets
import app.dnshizli.core.FilterMem
import app.dnshizli.core.ALIGN_CENTER
import app.dnshizli.core.Troubleshoot
import app.dnshizli.core.ALIGN_LEFT
import app.dnshizli.core.BubbleLevel
import app.dnshizli.core.CacheLevel
import app.dnshizli.core.Catalog
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Easing
import app.dnshizli.core.Encryption
import app.dnshizli.core.Format
import app.dnshizli.core.FilterLevel
import app.dnshizli.core.FilterLive
import app.dnshizli.core.Gfx
import app.dnshizli.core.Icon
import app.dnshizli.core.Icons
import app.dnshizli.core.IpMode
import app.dnshizli.core.L
import app.dnshizli.core.Lang
import app.dnshizli.core.TextScale
import app.dnshizli.core.HapticLevel
import app.dnshizli.core.Profile
import app.dnshizli.core.Profiles
import app.dnshizli.core.SoundPack
import app.dnshizli.core.Motion
import app.dnshizli.core.NightHours
import app.dnshizli.core.OrbMath
import app.dnshizli.core.OrbShape
import app.dnshizli.core.OrbShapes
import app.dnshizli.core.OrbState
import app.dnshizli.core.AppEntry
import app.dnshizli.core.AppScope
import app.dnshizli.core.AppSettings
import app.dnshizli.core.Rgb
import app.dnshizli.core.Session
import app.dnshizli.core.SessionLog
import app.dnshizli.core.Tag
import app.dnshizli.core.TextFit
import app.dnshizli.core.Themes
import app.dnshizli.core.UiStyle
import app.dnshizli.core.WpBlur
import app.dnshizli.core.WallpaperMath
import app.dnshizli.core.UsageStats
import kotlin.math.roundToInt

/** Seçim panelindeki bir seçenek. */
class Option(val id: String?, val name: String, val note: String = "", val selected: Boolean = false)

/** Sayfaların ve alt sayfaların gezinti istekleri (sahne uygular). */
interface Nav {
    /** ☰ menüsü: ayrı pencerelerin listesi. */
    fun openMenu()
    /** Ayar pencereleri (DNS, bağlantı, bildirimler, sunucu listesi, istatistikler, veriler). */
    fun openSection(section: Section)
    /** Kişiselleştirme penceresi: dil, tema, stil, arka plan, simge, yazı, hareket, erişilebilirlik. */
    fun openPersonalize()
    /** Sıvı rengi: önizleme, "Temaya göre" ve 50 renk. */
    fun openLiquidColor()
    /** Hakkında penceresi: yenilikler, yardım, günlük, paylaş, puanla, geri bildirim, sürüm. */
    fun openAbout()
    fun openLog()
    fun openHelp()
    fun openDetails(server: DnsServer)

    /** "Otomatik" + tüm sunucular arasından seçim (ağ kuralları). */
    fun openChoice(title: String, current: String?, onPick: (String?) -> Unit)

    /** Genel seçim paneli (dil, gizlenen sunucular…). */
    fun openOptions(title: String, options: List<Option>, empty: String = "", footer: String = "", onPick: (String?) -> Unit)

    /** Küreye uzun basınca: favoriler, son kullanılanlar, duraklatma. */
    fun openQuickPick()

    /** Bağlantı testini başlatır ve sonucunu panelde gösterir. */
    fun openTest()

    /** "Bana uygun sunucu": amaç seçimi. */
    fun openRecommend()

    /** Başlık, paragraflar ve isteğe bağlı bir eylem düğmesi olan bilgi paneli. */
    fun openInfo(title: String, paragraphs: List<String>, button: String? = null, action: (() -> Unit)? = null)
    fun openSessions()
    fun openWhatsNew()
    fun openApps()
    fun back()
}

class TopSpacer : Node() {
    override fun layout(env: Env, maxW: Float) { w = maxW; h = M.HEADER_H + env.insetTop + 4f }
}

class BottomSpacer : Node() {
    override fun layout(env: Env, maxW: Float) { w = maxW; h = 28f + env.insetBottom }
}

/** Üstte cam başlık çubuğu, altında dikey kaydırılan içerik olan sayfa iskeleti. */
abstract class ScrollPage(title: String, back: Boolean, protected val nav: Nav) : Node() {
    protected val header = Header(title, back) { nav.back() }
    protected val scroll = ScrollView()
    protected val col = Column(gap = 14f)

    init {
        col.add(TopSpacer())
        scroll.setContent(col)
        add(scroll)
        add(header)
    }

    /** Sayfa açılırken satırların art arda belirmesini başlatır (stilin hareketi izin veriyorsa). */
    fun startReveal(env: Env) = scroll.startReveal(env)

    /** Alt sınır boşluğunu ekler; alt sınıflar içeriği ekledikten sonra çağırır. */
    protected fun finish() { col.add(BottomSpacer()) }

    val scrollOffset: Float get() = scroll.offset

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        h = env.height
        val cw = minOf(maxW, M.MAX_W)
        val l = (maxW - cw) / 2f
        col.padL = l + M.PAD
        col.padR = l + M.PAD
        header.layout(env, maxW)
        scroll.clipInsetTop = header.h
        scroll.setViewport(env, maxW, h)
        onLaidOut(env, l)
    }

    protected open fun onLaidOut(env: Env, left: Float) {}

    /** İçerik değişti (satır sayısı vb.): yeniden yerleştir. */
    fun relayoutContent(env: Env) { scroll.setViewport(env, w, h) }

    override fun tick(dt: Float, env: Env): Boolean {
        header.barAlpha = Easing.clamp01((scroll.offset - 6f) / 40f)
        return tickKids(dt, env)
    }
}

// =============================================================================== ana sayfa

/** Üst çubukta, küre kaydırılıp görünmez olunca beliren küçük bağlantı düğmesi. */
class MiniOrb(private val onTap: () -> Unit) : PressNode() {
    var alpha = 0f
    override val tappable: Boolean get() = alpha > 0.5f
    override val hitSlop: Float get() = 2f
    override fun layout(env: Env, maxW: Float) { w = 40f; h = 40f }
    override fun draw(g: Gfx, env: Env) {
        if (alpha <= 0.01f) return
        val st = env.model.vpn.state
        g.save()
        g.alpha(alpha)
        pressScale(g, w / 2f, h / 2f, 0.1f)
        val glow = if (st == OrbState.ON) 0.7f else 0f
        env.art.orbShape = env.model.orbShapeFor(env.model.shownThemeId)
        env.art.liquidTintAmt = 0f
        env.art.liquidColor = env.model.liquidColorArgb
        env.art.orb(g, w / 2f, h / 2f, 17f, OrbMath.targetLevel(st), env.time * 1.5f, glow, if (st == OrbState.ERROR) 1f else 0f, press.value * 0.6f)
        g.restore()
    }
    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) { super.onUp(lx, ly, tap, env); if (tap) { env.tap(true); onTap() } }
    override fun a11y(): A11y? = null
    fun label(env: Env): String = Strings.APP + ": " + env.model.statusTitle()
}

/** Süzgeç çipleri: sığdığı kadar satıra dizilir. Yatay kaydırma yok: her çip görünür ve erişilebilir. */
class ChipsRow(private val model: AppModel) : Node() {
    private val filters = Filter.values()
    private val chips = filters.map { f -> Chip(f.label) { model.setFilter(f) } }
    /** Son çip: arama. Aramada "Ara", arama varken aranan söz görünür ve seçili olur. */
    private val search = Chip(Strings.SEARCH) { model.promptSearch() }
    private val all = chips + search
    private var seen = -1

    init { for (c in all) add(c) }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        var x = 0f
        var y = PAD_T
        search.text = searchText()
        for (c in all) {
            c.layout(env, maxW)
            if (x > 0f && x + c.w > maxW + 0.5f) { x = 0f; y += M.CHIP_H + GAP }
            c.x = x; c.y = y
            x += c.w + GAP
        }
        h = y + M.CHIP_H + PAD_B
        sync(env, false)
    }

    private fun sync(env: Env, animate: Boolean) {
        for (i in filters.indices) chips[i].setSelected(filters[i] == model.filter, env, animate)
        search.setSelected(model.effectiveQuery.isNotEmpty(), env, animate)
    }

    private fun searchText(): String {
        val q = model.effectiveQuery
        return if (q.isEmpty()) Strings.SEARCH else "“" + (if (q.length > 12) q.take(11) + "…" else q) + "”"
    }

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version) { seen = model.version; sync(env, true) }
        return tickKids(dt, env)
    }

    private companion object {
        const val GAP = 8f
        const val PAD_T = 6f
        const val PAD_B = 10f
    }
}

/** "Sunucular" başlığı, sayısı ve sağda sırala / ölç düğmeleri. */
class ListHeader(private val model: AppModel) : Node() {
    private val title = Label(Strings.SERVERS, 18f, bold = true)
    private val count = Label("", 13f, ink = Ink.SOFT)
    private val sortBtn = IconButton(Icon.SORT, Strings.SORT, 40f) { model.toggleSort() }.also {
        it.labelFn = { Strings.sortA11y(Strings.OPT_SORT[model.settings.sortMode.ordinal]) }
    }
    private val measureBtn = IconButton(Icon.REFRESH, Strings.MEASURE, 40f) { model.measureAll() }
    private val spoken = A11yOnly("", Role.HEADING)
    private var seen = -1

    init { add(spoken); add(measureBtn); add(sortBtn) }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        h = 48f
        measureBtn.layout(env, maxW); sortBtn.layout(env, maxW)
        measureBtn.x = w - measureBtn.w; measureBtn.y = (h - measureBtn.h) / 2f
        sortBtn.x = measureBtn.x - 10f - sortBtn.w; sortBtn.y = measureBtn.y
        syncText()
        title.layout(env, maxW - 120f)
        title.x = 4f; title.y = (h - title.h) / 2f
        count.x = 4f + env.metrics.textWidth(title.text, env.sz(18f), true) + 10f
        count.layout(env, maxOf(40f, sortBtn.x - 8f - count.x))   // büyük yazıda da kısalmaz
        count.y = title.y + (title.h - count.h) / 2f + 1f
        spoken.x = 0f; spoken.y = title.y; spoken.h = title.h
        spoken.w = spokenWidth(env)
    }

    private fun spokenWidth(env: Env): Float = minOf(sortBtn.x - 8f, count.x + env.metrics.textWidth(count.text, env.sz(13f), false))

    /** Modelden gelen metin ve düğme durumları. */
    private fun syncText() {
        seen = model.version
        count.text = Strings.serversCount(model.visibleServers().size)
        spoken.label = Strings.SERVERS + ", " + count.text
        sortBtn.active = model.settings.sortMode != app.dnshizli.core.SortMode.DEFAULT
        measureBtn.active = model.measuring
    }

    private fun refresh(env: Env) {
        if (seen == model.version) return
        syncText()
        spoken.w = spokenWidth(env)
    }

    override fun tick(dt: Float, env: Env): Boolean {
        refresh(env)
        if (model.measuring) measureBtn.spin = (measureBtn.spin + dt * 360f) % 360f else measureBtn.spin = 0f
        return tickKids(dt, env)
    }

    /** Ölçüm dönerken küre gibi süs animasyonudur: 33 ms'lik kareler yeter. */
    override fun ambient(env: Env): Boolean = (env.ambient && model.measuring) || ambientKids(env)

    override fun draw(g: Gfx, env: Env) {
        g.save(); g.translate(title.x, title.y); title.draw(g, env); g.restore()
        g.save(); g.translate(count.x, count.y); count.draw(g, env); g.restore()
        drawKids(g, env)
    }
}

/** Sunucu satırlarını tutar; satır nesneleri kimliğe göre yeniden kullanılır (animasyon durumu korunur). */
class ServerListNode(private val onLong: (DnsServer) -> Unit) : Node() {
    private val rows = HashMap<String, ServerRow>()
    private val empty = Label("", 14f, ink = Ink.SOFT, align = ALIGN_CENTER, maxLines = 0)

    fun sync(env: Env) {
        val m = env.model
        val list = m.shownServers()
        removeAll()
        for (s in list) add(rows.getOrPut(s.id) { ServerRow(s, onLong) })
        empty.text = when {
            list.isNotEmpty() -> ""
            m.effectiveFilter == Filter.FAVORITES -> Strings.EMPTY_FAV
            m.effectiveFilter == Filter.RECENT -> Strings.EMPTY_RECENT
            else -> Strings.EMPTY_FILTER
        }
    }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        var cy = 0f
        for (k in kids) {
            k.layout(env, maxW)
            k.x = 0f
            k.y = cy
            cy += k.h + M.ROW_GAP
        }
        h = if (kids.isEmpty()) 0f else cy - M.ROW_GAP
        if (empty.text.isNotEmpty()) {
            empty.layout(env, maxW - 24f)
            empty.x = 12f
            empty.y = 16f
            h = empty.h + 32f
        }
    }

    override val revealSelf: Boolean get() = true

    override fun draw(g: Gfx, env: Env) {
        if (empty.text.isNotEmpty()) { g.save(); g.translate(empty.x, empty.y); empty.draw(g, env); g.restore() }
        val rv = env.revealT
        if (rv == Reveal.DONE) { drawKids(g, env); return }
        // açılışta satırlar art arda belirir (ilk bölümlerden sonra başlar)
        val stg = env.art.motion.stagger
        var i = 0
        while (i < kids.size) {
            val k = kids[i]
            g.save()
            g.translate(k.x, k.y - scrollY)
            Reveal.apply(g, env, Reveal.progress(rv, i + 3, stg), k.w, k.h)
            k.draw(g, env)
            g.restore()
            i++
        }
    }

    override fun a11y(): A11y? = if (empty.text.isNotEmpty()) A11y(empty.text, Role.TEXT) else null
}

/**
 * Küre altında hızlı profil çipleri (Hız / Gizlilik / Aile / Tam koruma). Dokununca [AppModel.applyProfile] çalışır
 * (menüdeki profil penceresiyle aynı eylem). Seçili çip, ayarların profille birebir örtüştüğü profildir; örtüşen yoksa hiçbiri seçili olmaz.
 */
class ProfileChips(private val model: AppModel) : Node() {
    // "Aile" gibi adlar süzgeç çipleriyle çakışır: ekran okuyucu için "Profiller: Aile" denir.
    private val chips = Profiles.all.mapIndexed { i, p ->
        Chip(Strings.PROFILE_NAMES[i]) { model.applyProfile(p.id) }.also { it.a11yLabel = Strings.PROFILES + ": " + Strings.PROFILE_NAMES[i] }
    }
    private var seen = -1

    init { for (c in chips) add(c) }

    private fun matches(p: Profile): Boolean {
        val s = model.settings
        return s.lastServer == p.serverId && s.strictEncryption == p.encryptionStrict && s.cache == p.cache &&
            s.autoFastest == p.fastest && s.filterLevel == p.filter
    }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        var x = 0f
        var y = 0f
        for (c in chips) {
            c.layout(env, maxW)
            if (x > 0f && x + c.w > maxW + 0.5f) { x = 0f; y += M.CHIP_H + GAP }
            c.x = x; c.y = y
            x += c.w + GAP
        }
        h = y + M.CHIP_H
        sync(env, false)
    }

    private fun sync(env: Env, animate: Boolean) {
        for (i in chips.indices) chips[i].setSelected(matches(Profiles.all[i]), env, animate)
    }

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version) { seen = model.version; sync(env, true) }
        return tickKids(dt, env)
    }

    private companion object { const val GAP = 8f }
}

class HomePage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.APP, false, nav) {
    private val orb = OrbBlock({ model.tapOrb() }, { nav.openQuickPick() })
    private val profileChips = ProfileChips(model)
    private val modules = ModuleCards(model)
    private val chips = ChipsRow(model)
    private val listHead = ListHeader(model)
    private val list = ServerListNode { nav.openDetails(it) }
    private val addCustom = ActionButton(Strings.CUSTOM_ADD, false) { model.promptCustom() }
    private val more = ActionButton("", false) { model.toggleList() }
    private val menu = IconButton(Icon.MENU, Strings.MENU) { nav.openMenu() }
    private val mini = MiniOrb { model.tapOrb() }
    private var seen = -1

    init {
        header.addRight(menu)
        header.addRight(mini)
        col.add(orb)
        col.add(profileChips)
        col.add(modules)
        col.add(chips)
        col.add(listHead)
        col.add(addCustom)
        col.add(list)
        col.add(more)
        finish()
        col.gap = 10f
        chips.visible = !model.settings.minimal
        profileChips.visible = !model.settings.minimal
        // En üstte aşağı çekip bırakınca tüm sunucuların hızı ölçülür.
        scroll.pullable = true
        scroll.onPullRelease = { d -> if (d >= Scroller.PULL_TRIGGER) { model.measureAll() } }
    }

    override fun onLaidOut(env: Env, left: Float) { seen = -1 }

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version) {
            seen = model.version
            chips.visible = !model.settings.minimal
            profileChips.visible = !model.settings.minimal
            list.sync(env)
            more.visible = model.listCollapsible()
            more.text = if (model.listExpanded) Strings.SHOW_LESS else Strings.showAllServers(model.visibleServers().size - AppModel.LIST_LIMIT)
            relayoutContent(env)
        }
        val a = super.tick(dt, env)
        // Küre görünümden çıkınca üst çubukta mini düğme belirir.
        val orbScreenBottom = orb.y + orb.cy + orb.r * 0.55f - scroll.offset
        val limit = M.HEADER_H + env.insetTop
        mini.alpha = Easing.clamp01((limit - orbScreenBottom + 6f) / 36f)
        return a
    }

    override fun draw(g: Gfx, env: Env) {
        val p = scroll.pull
        if (p > 2f) {
            // Çekme ipucu: içeriğin üstünde açılan boşlukta, çekildikçe belirir ve döner.
            val ready = p >= Scroller.PULL_TRIGGER
            val a = Easing.clamp01(p / 48f)
            val cy = header.h + p * 0.5f + 2f
            g.save()
            g.alpha(a)
            val fs = env.sz(13f)
            val text = if (ready) Strings.RELEASE_TO_MEASURE else Strings.PULL_TO_MEASURE
            val tw = env.metrics.textWidth(text, fs, true)
            val x0 = (w - tw - 26f) / 2f
            g.save()
            g.translate(x0 + 9f, cy)
            g.rotate(p * 2.4f)
            Icons.draw(g, Icon.REFRESH, 0f, 0f, 18f, if (ready) env.theme.link else env.theme.textSoft, 2f)
            g.restore()
            g.paint(if (ready) env.theme.link else env.theme.textSoft)
            g.text(text, x0 + 26f, centerBaseline(cy, fs), fs, true, ALIGN_LEFT)
            g.restore()
        }
        super.draw(g, env)
    }
}

// =============================================================================== menü ve hakkında

/** ☰ menüsü: her satır ayrı bir pencere açar. */
class MenuPage(nav: Nav) : ScrollPage(Strings.MENU, true, nav) {
    init {
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.PERSONALIZE, null, Icon.PALETTE) { nav.openPersonalize() })
            c.add(NavRow(Strings.SOUND_MOTION, null, Icon.BELL) { nav.openSection(Section.SOUND) })
        })
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.DNS_SETTINGS, null, Icon.LOCK) { nav.openSection(Section.DNS) })
            c.add(NavRow(Strings.FILTER, { Strings.OPT_FILTER[it.filterLevel.ordinal] }, Icon.BLOCK) { nav.openSection(Section.FILTER) })
            c.add(NavRow(Strings.CONN_APPS, null, Icon.WIFI) { nav.openSection(Section.CONNECTION) })
            c.add(NavRow(Strings.SEC_NOTIF, null, Icon.BELL) { nav.openSection(Section.NOTIFICATIONS) })
            c.add(NavRow(Strings.SEC_LIST, null, Icon.SORT) { nav.openSection(Section.LIST) })
        })
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.STATS_HISTORY, null, Icon.SIGNAL) { nav.openSection(Section.STATS) })
            c.add(NavRow(Strings.SEC_DATA, null, Icon.COPY) { nav.openSection(Section.DATA) })
            c.add(NavRow(Strings.ABOUT, null, Icon.INFO) { nav.openAbout() })
        })
        finish()
    }
}

/** Hakkında: açıklama yazıları, yenilikler, günlük, sistem VPN ayarları, paylaş, puanla, geri bildirim, sürüm. */
class AboutPage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.ABOUT, true, nav) {
    init {
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.HELP_WHY_TITLE, null, Icon.HEART) {
                nav.openInfo(Strings.HELP_WHY_TITLE, listOf(Strings.HELP_WHY_BODY, Strings.HELP_WHY_TAIL))
            })
            c.add(NavRow(Strings.HELP, null, Icon.INFO) { nav.openHelp() })
            c.add(NavRow(Strings.WHATS_NEW, null, Icon.STAR) { nav.openWhatsNew() })
        })
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.LOG, null, Icon.LOG) { nav.openLog() })
            c.add(NavRow(Strings.VPN_SETTINGS, null, Icon.SHIELD) { model.host.openVpnSettings() })
            c.add(NavRow(Strings.FEEDBACK, null, Icon.COPY) { model.host.shareText(model.host.diagnostics()) })
        })
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.SHARE_APP, null, Icon.HEART) { model.host.shareApp() })
            c.add(NavRow(Strings.RATE_APP, null, Icon.STAR) { model.host.rateApp() })
            c.add(InfoRow(Strings.VERSION) { model.host.versionName() })
        })
        finish()
    }
}

// =============================================================================== kişiselleştirme

/** Kişiselleştirme penceresi: dil, tema, stil, arka plan, simge ve erişilebilirlik/güç seçenekleri. */
class PersonalizePage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.PERSONALIZE, true, nav) {
    private var seenVersion = -1

    // Satırların değeri ayar değişince değişir; başlıkla sığmayan değer alta iner, bu yüzden yerleşim yenilenir.
    override fun tick(dt: Float, env: Env): Boolean {
        if (seenVersion != model.version) { seenVersion = model.version; relayoutContent(env) }
        return super.tick(dt, env)
    }

    init {
        col.add(SectionTitle(Strings.SEC_LOOK))
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.LANGUAGE, { langName(it.lang) }, Icon.GLOBE) { openLanguage(nav) })
            c.add(SwatchRow())
            c.add(NavRow(Strings.STYLE, { it.style.label }) { openStyle(nav) })
            c.add(NavRow(Strings.ORB_SHAPE, { Strings.orbShapeName(OrbShapes.get(it.orbShapes, model.shownThemeId)) }) { openOrbShape(nav, model.shownThemeId) })
            c.add(NavRow(Strings.ORB_SHAPE_EACH, null) { openOrbShapeThemes(nav) })
            c.add(NavRow(Strings.LIQUID_COLOR, { if (it.liquidColor.isEmpty()) Strings.LIQUID_THEME else "#" + it.liquidColor }) { nav.openLiquidColor() })
            c.add(NavRow(Strings.APP_ICON, { model.settings.appIcon.label }) { openAppIcon(nav) })
        })

        col.add(SectionTitle(Strings.PZ_BACKGROUND))
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.WALLPAPER, { if (it.wallpaper) Strings.WP_ON else Strings.WP_OFF }) { openWallpaper(nav) })
            c.add(SliderRow(Strings.WP_DIM, { it.wpDim / WallpaperMath.DIM_MAX }, { s, v -> s.copy(wpDim = v * WallpaperMath.DIM_MAX) }, { Strings.percent((it.wpDim * 100).roundToInt()) }))
            c.add(SegmentRow(Strings.WP_BLUR, Strings.OPT_WP_BLUR, { it.wpBlur.ordinal }, { s, i -> s.copy(wpBlur = WpBlur.values()[i]) }))
        })

        col.add(SectionTitle(Strings.PZ_AUTO))
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.AUTO_LIGHT, { themeName(it.autoLight) }) { openAutoTheme(nav, dark = false) })
            c.add(NavRow(Strings.AUTO_DARK, { themeName(it.autoDark) }) { openAutoTheme(nav, dark = true) })
            c.add(ToggleRow(Strings.THEME_SCHEDULE, Strings.THEME_SCHEDULE_NOTE, { it.themeSchedule }, { s, v -> s.copy(themeSchedule = v) }))
            c.add(SegmentRow(Strings.NIGHT_HOURS, NightHours.values().map { it.label }, { it.nightHours.ordinal }, { s, i -> s.copy(nightHours = NightHours.values()[i]) }))
        })

        col.add(SectionTitle(Strings.PZ_FEEL))
        col.add(SettingsCard().also { c ->
            c.add(SliderRow(Strings.GLASS, { it.glass }, { s, v -> s.copy(glass = v) }, { Strings.percent((it.glass * 100).roundToInt()) }))
            c.add(SegmentRow(Strings.TEXT_SIZE, Strings.OPT_TEXT, { it.textScale.ordinal }, { s, i -> s.copy(textScale = TextScale.values()[i]) }))
            c.add(SegmentRow(Strings.BUBBLES, Strings.OPT_BUBBLES, { it.bubbles.ordinal }, { s, i -> s.copy(bubbles = BubbleLevel.values()[i]) }))
            c.add(SegmentRow(Strings.MOTION, Strings.OPT_MOTION, { it.motion.ordinal }, { s, i -> s.copy(motion = Motion.values()[i]) }))
        })

        col.add(SectionTitle(Strings.PZ_ACCESS))
        col.add(SettingsCard().also { c ->
            c.add(ToggleRow(Strings.HIGH_CONTRAST, Strings.HIGH_CONTRAST_NOTE, { it.highContrast }, { s, v -> s.copy(highContrast = v) }))
            c.add(ToggleRow(Strings.MINIMAL, Strings.MINIMAL_NOTE, { it.minimal }, { s, v -> s.copy(minimal = v) }))
            c.add(ToggleRow(Strings.LOW_POWER, Strings.LOW_POWER_NOTE, { it.lowPower }, { s, v -> s.copy(lowPower = v) }))
            c.add(ToggleRow(Strings.HAPTICS, Strings.HAPTICS_NOTE, { it.haptics }, { s, v -> s.copy(haptics = v) }))
        })
        finish()
    }

    private fun themeName(id: String): String = if (id == Themes.DYNAMIC_ID) Strings.themeName(id) else (Themes.byId(id)?.name ?: id)

    /** Satırdaki kısa değer: "Otomatik" ya da dilin kendi adı. */
    private fun langName(setting: String): String = if (setting == L.AUTO) Strings.THEME_AUTO else (Lang.byCode(setting)?.native ?: Strings.THEME_AUTO)

    private fun openLanguage(nav: Nav) {
        val cur = model.settings.lang
        val opts = ArrayList<Option>()
        opts.add(Option(L.AUTO, Strings.LANG_AUTO, L.lang.native, cur == L.AUTO))
        for (l in Lang.values()) opts.add(Option(l.code, l.native, "", cur == l.code))
        nav.openOptions(Strings.LANGUAGE, opts) { id -> if (id != null) model.setLanguage(id) }
    }

    /** "Otomatik" temanın açık ya da koyu modda kullanacağı tema; duvar kağıdı teması varsa o da seçilebilir. */
    private fun openAutoTheme(nav: Nav, dark: Boolean) {
        val cur = if (dark) model.settings.autoDark else model.settings.autoLight
        val opts = ArrayList<Option>()
        if (model.accentSeed != null) opts.add(Option(Themes.DYNAMIC_ID, Strings.themeName(Themes.DYNAMIC_ID), "", cur == Themes.DYNAMIC_ID))
        for (t in Themes.all.filter { it.dark == dark }) opts.add(Option(t.id, t.name, "", cur == t.id))
        nav.openOptions(if (dark) Strings.AUTO_DARK else Strings.AUTO_LIGHT, opts) { id ->
            if (id != null) model.update { if (dark) it.copy(autoDark = id) else it.copy(autoLight = id) }
        }
    }

    private fun openStyle(nav: Nav) {
        val cur = model.settings.style
        val opts = UiStyle.values().mapIndexed { i, st -> Option(st.id, st.label, Strings.STYLE_NOTES[i], cur == st) }
        nav.openOptions(Strings.STYLE, opts) { id -> UiStyle.byId(id)?.let { st -> model.update { it.copy(style = st) } } }
    }

    /** [themeId] teması için ana düğme şeklini seçtirir (küre, üçgen, kare, altıgen, yıldız). */
    private fun openOrbShape(nav: Nav, themeId: String) {
        val cur = model.orbShapeFor(themeId)
        val opts = OrbShape.values().map { Option(it.id, Strings.orbShapeName(it), "", it == cur) }
        nav.openOptions(Strings.ORB_SHAPE + ": " + Strings.themeName(themeId), opts) { id -> OrbShape.byId(id)?.let { model.setOrbShape(themeId, it) } }
    }

    /** Tema başına şekil: 12 temanın her biri ayrı listelenir, seçilen temanın şekil penceresi açılır. */
    private fun openOrbShapeThemes(nav: Nav) {
        val opts = Themes.all.map { t -> Option(t.id, Strings.themeName(t.id), Strings.orbShapeName(model.orbShapeFor(t.id)), t.id == model.shownThemeId) }
        nav.openOptions(Strings.ORB_SHAPE_EACH, opts) { id -> if (id != null) openOrbShape(nav, id) }
    }

    private fun openAppIcon(nav: Nav) {
        val cur = model.settings.appIcon
        val opts = UiStyle.values().mapIndexed { i, st -> Option(st.id, st.label, Strings.ICON_NOTES[i], cur == st) }
        nav.openOptions(Strings.APP_ICON, opts, footer = Strings.ICON_NOTE) { id -> UiStyle.byId(id)?.let { model.setAppIcon(it) } }
    }

    private fun openWallpaper(nav: Nav) {
        val opts = ArrayList<Option>()
        opts.add(Option("pick", Strings.WP_PICK, Strings.WP_PICK_NOTE))
        opts.add(Option("presets", Strings.WP_PRESETS, Strings.WP_PRESETS_NOTE))
        if (model.settings.wallpaper) opts.add(Option("remove", Strings.WP_REMOVE))
        nav.openOptions(Strings.WALLPAPER, opts) { id ->
            when (id) {
                "pick" -> model.pickWallpaper()
                "remove" -> model.removeWallpaper()
                "presets" -> openPresets(nav)
            }
        }
    }

    private fun openPresets(nav: Nav) {
        val opts = WallpaperPresets.NAMES.mapIndexed { i, n -> Option("p$i", n) }
        nav.openOptions(Strings.WP_PRESETS, opts) { id ->
            val i = id?.removePrefix("p")?.toIntOrNull()
            if (i != null && i in WallpaperPresets.NAMES.indices) model.usePresetWallpaper(i)
        }
    }
}

// =============================================================================== ayar pencereleri

/** Ayar pencereleri: ☰ menüsündeki her satır birini açar. */
enum class Section { DNS, FILTER, CONNECTION, NOTIFICATIONS, LIST, STATS, DATA, SOUND }

private fun sectionTitle(s: Section): String = when (s) {
    Section.DNS -> Strings.DNS_SETTINGS
    Section.FILTER -> Strings.FILTER
    Section.CONNECTION -> Strings.CONN_APPS
    Section.NOTIFICATIONS -> Strings.SEC_NOTIF
    Section.LIST -> Strings.SEC_LIST
    Section.STATS -> Strings.STATS_HISTORY
    Section.DATA -> Strings.SEC_DATA
    Section.SOUND -> Strings.SOUND_MOTION
}

class SectionPage(private val model: AppModel, nav: Nav, val section: Section) : ScrollPage(sectionTitle(section), true, nav) {
    private var seenVersion = -1

    // Satırların değeri ayar değişince değişir; başlıkla sığmayan değer alta iner, bu yüzden yerleşim yenilenir.
    override fun tick(dt: Float, env: Env): Boolean {
        if (seenVersion != model.version) { seenVersion = model.version; relayoutContent(env) }
        return super.tick(dt, env)
    }

    init {
        when (section) {
            Section.DNS -> buildDns(nav)
            Section.FILTER -> buildFilter(nav)
            Section.CONNECTION -> buildConnection(nav)
            Section.NOTIFICATIONS -> buildNotifications()
            Section.LIST -> buildList(nav)
            Section.STATS -> buildStats(nav)
            Section.DATA -> buildData()
            Section.SOUND -> buildSound()
        }
        finish()
    }

    private fun card(build: (SettingsCard) -> Unit) { col.add(SettingsCard().also(build)) }

    private fun buildDns(nav: Nav) {
        card { c ->
            c.add(NavRow(Strings.PROFILES, null, Icon.SHIELD) { openProfiles(nav) })
            c.add(ToggleRow(Strings.REMEMBER_MODS, Strings.REMEMBER_MODS_NOTE, { it.rememberModules }, { s, v -> s.copy(rememberModules = v) }))
        }
        card { c ->
            c.add(SegmentRow(Strings.ENCRYPTION, Strings.OPT_ENCRYPTION, { it.encryption.ordinal }, { s, i -> s.copy(encryption = Encryption.values()[i]) }, Strings.ENCRYPTION_NOTE))
            c.add(ToggleRow(Strings.STRICT_ENC, Strings.STRICT_ENC_NOTE, { it.strictEncryption }, { s, v -> s.copy(strictEncryption = v) }))
            c.add(SegmentRow(Strings.IP_MODE, Strings.OPT_IP_MODE, { it.ipMode.ordinal }, { s, i -> s.copy(ipMode = IpMode.values()[i]) }, Strings.IP_MODE_NOTE))
        }
        card { c ->
            c.add(NavRow(Strings.BACKUP_SERVER, { backupName(it.backupServer) }) { openBackup(nav) })
            c.add(NavRow(Strings.RULE_WIFI, { ruleName(it.wifiServer) }) {
                nav.openChoice(Strings.RULE_WIFI, model.settings.wifiServer) { id -> model.update { it.copy(wifiServer = id) } }
            })
            c.add(NavRow(Strings.RULE_MOBILE, { ruleName(it.mobileServer) }) {
                nav.openChoice(Strings.RULE_MOBILE, model.settings.mobileServer) { id -> model.update { it.copy(mobileServer = id) } }
            })
        }
        card { c ->
            c.add(SegmentRow(Strings.CACHE, Strings.OPT_CACHE, { it.cache.ordinal }, { s, i -> s.copy(cache = CacheLevel.values()[i]) }))
            c.add(NavRow(Strings.CLEAR_CACHE, null, Icon.REFRESH) { model.clearCache() })
        }
        card { c ->
            c.add(NavRow(Strings.TEST, { if (model.testing) Strings.TESTING else "" }, Icon.CHECK) { nav.openTest() })
            c.add(NavRow(Strings.TROUBLE, null, Icon.INFO) { openTrouble(nav) })
        }
    }

    private fun buildFilter(nav: Nav) {
        card { c ->
            c.add(SegmentRow(Strings.FILTER_LEVEL, Strings.OPT_FILTER, { it.filterLevel.ordinal }, { s, i -> s.copy(filterLevel = FilterLevel.values()[i]) },
                noteFn = { Strings.FILTER_NOTES[it.filterLevel.ordinal] }))
            c.add(InfoRow(Strings.STAT_BLOCKED) { Format.count(FilterLive.blockedTotal) })
            c.add(SegmentRow(Strings.FILTER_MEM, Strings.OPT_FILTER_MEM, { it.filterMem.ordinal }, { s, i -> s.copy(filterMem = FilterMem.values()[i]) }, noteFn = { Strings.FILTER_MEM_NOTE }))
        }
        card { c ->
            c.add(NavRow(Strings.FILTER_LAST, { FilterLive.recent().size.let { n -> if (n == 0) "" else n.toString() } }, Icon.LOG) { openRecentBlocked(nav) })
            c.add(NavRow(Strings.FILTER_ALLOW, { if (it.filterAllow.isEmpty()) "" else it.filterAllow.size.toString() }, Icon.CHECK) { openFilterList(nav, true) })
            c.add(NavRow(Strings.FILTER_BLOCK, { if (it.filterBlock.isEmpty()) "" else it.filterBlock.size.toString() }, Icon.BLOCK) { openFilterList(nav, false) })
            c.add(NavRow(Strings.FILTER_MINE, { if (model.importedCount == 0) "" else Format.count(model.importedCount.toLong()) }, Icon.COPY) { openMine(nav) })
        }
        col.add(ParagraphCard(Strings.FILTER_INFO))
    }

    /** Bu oturumda engellenenler: dokununca izin listesine eklenir ("site bozuldu" çaresi). */
    private fun openRecentBlocked(nav: Nav) {
        val opts = FilterLive.recent().map { Option(it.name, it.name, if (it.user) Strings.FILTER_BLOCK else Strings.FILTER_RECENT_NOTE) }
        nav.openOptions(Strings.FILTER_LAST, opts, Strings.FILTER_RECENT_EMPTY, Strings.FILTER_RECENT_FOOT) { id -> if (id != null) model.addFilterName(true, id) }
    }

    /** Kendi listem: panodan ya da dosyadan içe aktarma, hosts olarak kopyalama, içe aktarılanları silme. */
    private fun openMine(nav: Nav) {
        val opts = listOf(
            Option(MINE_PASTE, Strings.MINE_PASTE, Strings.MINE_PASTE_NOTE),
            Option(MINE_FILE, Strings.MINE_FILE, Strings.MINE_FILE_NOTE),
            Option(MINE_EXPORT, Strings.MINE_EXPORT, Strings.MINE_EXPORT_NOTE),
            Option(MINE_CLEAR, Strings.MINE_CLEAR, Strings.mineCount(model.importedCount)),
        )
        nav.openOptions(Strings.FILTER_MINE, opts, "", Strings.MINE_FOOT) { id ->
            when (id) {
                MINE_PASTE -> model.importFromClipboard()
                MINE_FILE -> model.importFromFile()
                MINE_EXPORT -> model.copyBlockList()
                MINE_CLEAR -> model.askClearImported()
                else -> {}
            }
        }
    }

    /** İzin ya da kendi engel listesi: "Ekle…" satırı ve kayıtlı alan adları (dokununca kaldırma sorusu). */
    private fun openFilterList(nav: Nav, allow: Boolean) {
        val names = if (allow) model.settings.filterAllow else model.settings.filterBlock
        val opts = ArrayList<Option>()
        opts.add(Option(ADD_ID, Strings.FILTER_ADD, ""))
        for (n in names) opts.add(Option(n, n, Strings.FILTER_REMOVE))
        val title = if (allow) Strings.FILTER_ALLOW else Strings.FILTER_BLOCK
        val foot = if (allow) Strings.FILTER_ALLOW_FOOT else Strings.FILTER_BLOCK_FOOT
        nav.openOptions(title, opts, if (allow) Strings.FILTER_ALLOW_EMPTY else Strings.FILTER_BLOCK_EMPTY, foot) { id ->
            when (id) {
                null -> {}
                ADD_ID -> model.promptFilterName(allow) { openFilterList(nav, allow) }
                else -> model.askRemoveFilterName(allow, id)
            }
        }
    }

    private fun buildConnection(nav: Nav) {
        card { c ->
            c.add(ToggleRow(Strings.AUTO_CONNECT, Strings.AUTO_CONNECT_NOTE, { it.autoConnect }, { s, v -> s.copy(autoConnect = v) }))
            c.add(ToggleRow(Strings.CONNECT_ON_BOOT, Strings.CONNECT_ON_BOOT_NOTE, { it.connectOnBoot }, { s, v -> s.copy(connectOnBoot = v) }))
            c.add(ToggleRow(Strings.AUTO_FASTEST, Strings.AUTO_FASTEST_NOTE, { it.autoFastest }, { s, v -> s.copy(autoFastest = v) }))
            c.add(ToggleRow(Strings.AUTO_RECONNECT, Strings.AUTO_RECONNECT_NOTE, { it.autoReconnect }, { s, v -> s.copy(autoReconnect = v) }))
            c.add(ToggleRow(Strings.FAIL_CLOSED, Strings.FAIL_CLOSED_NOTE, { it.failClosed }, { s, v -> s.copy(failClosed = v) }))
            c.add(ToggleRow(Strings.REFRESH_ON_NET, Strings.REFRESH_ON_NET_NOTE, { it.refreshOnNetwork }, { s, v -> s.copy(refreshOnNetwork = v) }))
            c.add(ToggleRow(Strings.CONFIRM_OFF, Strings.CONFIRM_OFF_NOTE, { it.confirmDisconnect }, { s, v -> s.copy(confirmDisconnect = v) }))
            c.add(ToggleRow(Strings.BLOCK_QUIC, Strings.BLOCK_QUIC_NOTE, { it.blockQuic }, { s, v -> s.copy(blockQuic = v) }))
        }
        card { c ->
            c.add(NavRow(Strings.APPS, { appsSummary(it) }) { nav.openApps() })
            c.add(NavRow(Strings.GUARD, null, Icon.SHIELD) {
                nav.openInfo(Strings.GUARD, Strings.GUARD_BODY, Strings.GUARD_BUTTON) { model.host.openVpnSettings() }
            })
            c.add(NavRow(Strings.BATTERY, { batteryText() }, Icon.BOLT) {
                nav.openInfo(Strings.BATTERY, Strings.BATTERY_BODY, Strings.BATTERY_BUTTON) { model.host.openBatterySettings() }
            })
        }
    }

    private fun buildNotifications() {
        card { c ->
            c.add(ToggleRow(Strings.NOTIFY_CONNECT, Strings.NOTIFY_CONNECT_NOTE, { it.notifyConnect }, { s, v -> s.copy(notifyConnect = v) }))
            c.add(ToggleRow(Strings.NOTIFY_DROP, Strings.NOTIFY_DROP_NOTE, { it.notifyDrop }, { s, v -> s.copy(notifyDrop = v) }))
            c.add(ToggleRow(Strings.NOTIFY_STOP, Strings.NOTIFY_STOP_NOTE, { it.notifyStop }, { s, v -> s.copy(notifyStop = v) }))
            c.add(ToggleRow(Strings.NOTIFY_TIMEOUT, Strings.NOTIFY_TIMEOUT_NOTE, { it.notifyTimeout }, { s, v -> s.copy(notifyTimeout = v) }))
        }
        card { c ->
            c.add(ToggleRow(Strings.LOCK_HIDE, Strings.LOCK_HIDE_NOTE, { it.hideOnLockscreen }, { s, v -> s.copy(hideOnLockscreen = v) }))
            c.add(ToggleRow(Strings.QUIET_NOTIF, Strings.QUIET_NOTIF_NOTE, { it.quietNotification }, { s, v -> s.copy(quietNotification = v) }))
            c.add(NavRow(Strings.NOTIF_PERM, { if (model.host.notificationsAllowed()) Strings.PERM_ALLOWED else Strings.PERM_BLOCKED }, Icon.INFO) {
                model.host.openNotificationSettings()
            })
        }
    }

    private fun buildList(nav: Nav) {
        card { c ->
            c.add(NavRow(Strings.RECOMMEND, null, Icon.STAR) { nav.openRecommend() })
            c.add(ToggleRow(Strings.COMPACT, Strings.COMPACT_NOTE, { it.compact }, { s, v -> s.copy(compact = v) }))
            c.add(ToggleRow(Strings.REMEMBER_FILTER, Strings.REMEMBER_FILTER_NOTE, { it.rememberFilter }, { s, v -> s.copy(rememberFilter = v) }))
            c.add(ToggleRow(Strings.AUTO_MEASURE, Strings.AUTO_MEASURE_NOTE, { it.autoMeasure }, { s, v -> s.copy(autoMeasure = v) }))
            c.add(ToggleRow(Strings.MEASURE_ENC, Strings.MEASURE_ENC_NOTE, { it.measureEncrypted }, { s, v -> s.copy(measureEncrypted = v) }))
            c.add(NavRow(Strings.HIDDEN, { if (it.hidden.isEmpty()) Strings.HIDDEN_NONE else it.hidden.size.toString() }) { openHidden(nav) })
        }
    }

    private fun buildStats(nav: Nav) {
        card { c ->
            c.add(InfoRow(Strings.STAT_QUERIES) { Format.count(it.totalQueries) })
            c.add(InfoRow(Strings.STAT_HITS) { Strings.percent(model.hitPercentTotal()) })
            c.add(InfoRow(Strings.STAT_BLOCKED) { Format.count(it.totalBlocked) })
            c.add(InfoRow(Strings.STAT_TIME) { Format.span(it.totalSeconds) })
            c.add(InfoRow(Strings.STAT_AVG) { s -> s.avgLatencyMs?.let { Format.ms(it) } ?: "—" })
            c.add(InfoRow(Strings.STAT_SAVED) { Format.span(it.savedSeconds) })
            c.add(InfoRow(Strings.STAT_TRAFFIC) { Strings.traffic(Format.bytes(it.bytesUp), Format.bytes(it.bytesDown)) })
            c.add(LatencyChart())
            c.add(WeekChart())
            c.add(NavRow(Strings.SESSIONS, { SessionLog.decode(it.sessions).size.toString() }, Icon.LOG) { nav.openSessions() })
        }
        card { c ->
            c.add(ToggleRow(Strings.KEEP_HISTORY, Strings.KEEP_HISTORY_NOTE, { it.keepHistory }, { s, v -> s.copy(keepHistory = v) }))
            c.add(NavRow(Strings.SHARE_RESULTS, null, Icon.COPY) { model.shareResults() })
            c.add(NavRow(Strings.CLEAR_HISTORY, null, Icon.REFRESH) { model.clearHistory() })
            c.add(NavRow(Strings.RESET_STATS, null, Icon.BLOCK) { model.askResetStats() })
        }
    }

    private fun openProfiles(nav: Nav) {
        val opts = Profiles.all.mapIndexed { i, p -> Option(p.id, Strings.PROFILE_NAMES[i], Strings.PROFILE_NOTES[i]) }
        nav.openOptions(Strings.PROFILES, opts) { id -> if (id != null) model.applyProfile(id) }
    }

    /** Ses paketi listesi: 4 klasik paket ve stile özel 8 animasyonlu paket. */
    private fun openSoundPack(nav: Nav) {
        val cur = model.settings.soundPack
        val opts = SoundPack.values().map { Option(it.id, Strings.packName(it), if (it == SoundPack.AUTO) Strings.SOUND_PACK_NOTE else "", it == cur) }
        nav.openOptions(Strings.SOUND_PACK, opts, footer = Strings.PACKS_NOTE) { id ->
            val p = SoundPack.values().firstOrNull { it.id == id }
            if (p != null) { model.update { it.copy(soundPack = p) }; model.previewSound() }
        }
    }

    private fun buildSound() {
        col.add(SectionTitle(Strings.SEC_SOUND))
        card { c ->
            c.add(ToggleRow(Strings.SOUND_ON, Strings.SOUND_ON_NOTE, { it.soundOn }, { s, v -> s.copy(soundOn = v) }))
            c.add(ToggleRow(Strings.SOUND_UI, Strings.SOUND_UI_NOTE, { it.soundUi }, { s, v -> s.copy(soundUi = v) }))
            c.add(ToggleRow(Strings.SOUND_CONN, Strings.SOUND_CONN_NOTE, { it.soundConn }, { s, v -> s.copy(soundConn = v) }))
            c.add(SliderRow(Strings.SOUND_VOL, { it.soundVolume }, { s, v -> s.copy(soundVolume = v) }, { Strings.percent((it.soundVolume * 100).roundToInt()) }))
            c.add(NavRow(Strings.SOUND_PACK, { Strings.packName(it.soundPack) }) { openSoundPack(nav) })
            c.add(NavRow(Strings.SOUND_TEST, null, Icon.BELL) { model.previewSound() })
        }
        card { c ->
            c.add(ToggleRow(Strings.QUIET_HOURS, Strings.QUIET_NOTE, { it.quietHours }, { s, v -> s.copy(quietHours = v) }))
            c.add(SegmentRow(Strings.QUIET_RANGE, NightHours.values().map { it.label }, { it.quietRange.ordinal }, { s, i -> s.copy(quietRange = NightHours.values()[i]) }))
        }
        col.add(SectionTitle(Strings.SEC_MOTION_FX))
        card { c ->
            c.add(SliderRow(Strings.ANIM_SPEED, { (it.animSpeed - AppSettings.SPEED_MIN) / (AppSettings.SPEED_MAX - AppSettings.SPEED_MIN) },
                { s, v -> s.copy(animSpeed = (Math.round((AppSettings.SPEED_MIN + v * (AppSettings.SPEED_MAX - AppSettings.SPEED_MIN)) * 20f) / 20f).coerceIn(AppSettings.SPEED_MIN, AppSettings.SPEED_MAX)) },
                { Strings.percent((it.animSpeed * 100).roundToInt()) }))
            c.add(ToggleRow(Strings.TAP_FX, Strings.TAP_FX_NOTE, { it.tapFx }, { s, v -> s.copy(tapFx = v) }))
            c.add(ToggleRow(Strings.CELEBRATE, Strings.CELEBRATE_NOTE, { it.celebrate }, { s, v -> s.copy(celebrate = v) }))
            c.add(SegmentRow(Strings.HAPTIC_LEVEL, Strings.OPT_HAPTIC, { it.hapticLevel.ordinal }, { s, i -> s.copy(hapticLevel = HapticLevel.values()[i]) }))
        }
    }

    private fun buildData() {
        card { c ->
            c.add(NavRow(Strings.COPY_STATUS, null, Icon.COPY) { model.copyStatusSummary() })
            c.add(NavRow(Strings.EXPORT, null, Icon.COPY) { model.exportSettings() })
            c.add(NavRow(Strings.IMPORT, null, Icon.LOG) { model.importSettings() })
            c.add(NavRow(Strings.RESET_SETTINGS, null, Icon.REFRESH) { model.askResetSettings() })
        }
    }

    private fun appsSummary(s: AppSettings): String = when (s.appScope) {
        AppScope.ALL -> Strings.APPS_ALL
        AppScope.ONLY -> Strings.appsOnly(s.apps.size)
        AppScope.EXCEPT -> Strings.appsExcept(s.apps.size)
    }

    private fun ruleName(id: String?): String = id?.let { Catalog.byId(it)?.name } ?: Strings.RULE_AUTO

    private fun backupName(id: String?): String = when (id) {
        null -> Strings.BACKUP_OFF
        AppSettings.BACKUP_AUTO -> Strings.BACKUP_FASTEST
        else -> Catalog.byId(id)?.name ?: Strings.BACKUP_OFF
    }

    private fun batteryText(): String = when (model.host.batteryRestricted()) {
        true -> Strings.BATTERY_LIMITED
        false -> Strings.BATTERY_OK
        null -> ""
    }

    /** Sorun giderici: telefon durumunu okuyup bilgi panelinde gösterir; "Yeniden denetle" yeniden okur. */
    private fun openTrouble(nav: Nav) {
        val r = Troubleshoot.report(model.host.networkCheck(), model.vpn.active)
        nav.openInfo(Strings.TROUBLE, r.paragraphs, Strings.TROUBLE_RECHECK) { openTrouble(nav) }
    }

    private fun openBackup(nav: Nav) {
        val cur = model.settings.backupServer
        val opts = ArrayList<Option>()
        opts.add(Option(OFF_ID, Strings.BACKUP_OFF, Strings.BACKUP_OFF_NOTE, cur == null))
        opts.add(Option(AppSettings.BACKUP_AUTO, Strings.BACKUP_FASTEST, Strings.BACKUP_FASTEST_NOTE, cur == AppSettings.BACKUP_AUTO))
        for (s in Catalog.all) opts.add(Option(s.id, s.name, s.note, cur == s.id))
        nav.openOptions(Strings.BACKUP_SERVER, opts) { id -> model.update { it.copy(backupServer = if (id == OFF_ID) null else id) } }
    }

    private fun openHidden(nav: Nav) {
        val opts = model.hiddenServers().map { Option(it.id, it.name, Strings.UNHIDE) }
        nav.openOptions(Strings.HIDDEN, opts, Strings.HIDDEN_NONE) { id -> if (id != null) model.unhide(id) }
    }

    private companion object {
        const val OFF_ID = "off"
        const val ADD_ID = "\u0000add"
        const val MINE_PASTE = "\u0000paste"
        const val MINE_FILE = "\u0000file"
        const val MINE_EXPORT = "\u0000export"
        const val MINE_CLEAR = "\u0000clear"
    }
}

// =============================================================================== bağlantı geçmişi

/** En çok kullanılan sunucular ve son oturumlar (yalnızca sunucu, yöntem, süre, sorgu sayısı; ad tutulmaz). */
class SessionsPage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.SESSIONS, true, nav) {
    init {
        col.add(Label(Strings.SESSIONS_NOTE, 13f, ink = Ink.SOFT, maxLines = 0))
        val top = UsageStats.top(model.settings.usage, 3)
        if (top.isNotEmpty()) {
            col.add(SectionTitle(Strings.MOST_USED))
            col.add(SettingsCard().also { c ->
                for ((id, secs) in top) c.add(InfoRow(Catalog.byId(id)?.name ?: id) { Format.span(secs) })
            })
        }
        val sessions = SessionLog.decode(model.settings.sessions).asReversed()
        col.add(SectionTitle(Strings.SESSIONS))
        if (sessions.isEmpty()) col.add(ParagraphCard(Strings.SESSIONS_EMPTY))
        else col.add(SettingsCard().also { c -> for (x in sessions) c.add(SessionRow(x, model)) })
        finish()
    }
}

/** Bağlantı geçmişinde tek satır: sunucu · yöntem, zaman, süre ve bitiş nedeni. */
class SessionRow(private val s: Session, private val model: AppModel) : Node() {
    private val title = (Catalog.byId(s.serverId)?.name ?: s.serverId) + " · " + Strings.protoName(s.proto)
    private val line1 = whenText() + " · " + Strings.endReason(s.end)
    private val line2 = Strings.sessionLine(Format.span(s.seconds), Format.count(s.queries))
    private var shown = arrayOf(title, line1, line2)
    private var laidW = -1f
    private var laidFs = 0f

    private fun whenText(): String {
        val now = model.host.now()
        val day = app.dnshizli.core.DailyStats.today(s.startMs)
        val today = app.dnshizli.core.DailyStats.today(now)
        val yesterday = app.dnshizli.core.DailyStats.today(now - 86_400_000L)
        val d = when (day) { today -> Strings.TODAY; yesterday -> Strings.YESTERDAY; else -> String.format(java.util.Locale.ROOT, "%02d.%02d", day % 100, (day / 100) % 100) }
        return d + " " + Format.hm(s.startMs)
    }

    override fun layout(env: Env, maxW: Float) { w = maxW; h = 74f; laidW = -1f }

    private fun relay(env: Env) {
        laidW = w; laidFs = env.fs
        shown = arrayOf(
            TextFit.ellipsize(env.metrics, title, w - 32f, env.sz(15f), true),
            TextFit.ellipsize(env.metrics, line1, w - 32f, env.sz(13f), false),
            TextFit.ellipsize(env.metrics, line2, w - 32f, env.sz(13f), false),
        )
    }

    override fun draw(g: Gfx, env: Env) {
        if (laidW != w || laidFs != env.fs) relay(env)
        g.paint(env.theme.text)
        g.text(shown[0], 16f, 24f, env.sz(15f), true, ALIGN_LEFT)
        g.paint(env.theme.textSoft)
        g.text(shown[1], 16f, 44f, env.sz(13f), false, ALIGN_LEFT)
        g.text(shown[2], 16f, 62f, env.sz(13f), false, ALIGN_LEFT)
    }

    override fun a11y(): A11y = A11y("$title. $line1. $line2", Role.TEXT)
}

// =============================================================================== neler yeni

class WhatsNewPage(nav: Nav) : ScrollPage(Strings.WHATS_NEW, true, nav) {
    init {
        for (item in Strings.WHATS_NEW_ITEMS) col.add(ParagraphCard("• $item"))
        finish()
        col.gap = 8f
    }
}

// =============================================================================== uygulama seçimi

/**
 * Uygulama satırları kartı. Yüzlerce uygulama olabilir: yalnızca ekranda görünen satırlar çizilir
 * ([offset]: bu sayfanın kaydırma konumu; kart doğrudan içerik sütununun çocuğudur).
 */
class AppListCard(private val offset: () -> Float) : Node() {
    fun setApps(list: List<AppEntry>) {
        removeAll()
        for (a in list) {
            val pkg = a.pkg
            add(ToggleRow(a.label, null, { pkg in it.apps }, { s, v -> s.copy(apps = if (v) s.apps + pkg else s.apps - pkg) }))
        }
    }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        var cy = 0f
        for (k in kids) { k.layout(env, maxW); k.x = 0f; k.y = cy; cy += k.h }
        h = cy
    }

    override fun draw(g: Gfx, env: Env) {
        env.art.card(g, 0f, 0f, w, h, M.CARD_R)
        val top = offset() - y - 80f
        val bottom = offset() + env.height - y + 80f
        g.paint(Rgb.alpha(Rgb.WHITE, if (env.theme.dark) 0.14f else 0.55f))
        var i = 0
        while (i < kids.size) {
            val k = kids[i++]
            if (k.y + k.h < top || k.y > bottom) continue
            g.save(); g.translate(k.x, k.y); k.draw(g, env); g.restore()
            if (i > 1) g.rect(16f, k.y - 0.5f, w - 16f, k.y + 0.5f)
        }
    }
}

/** "Hangi uygulamalar": DNS'in uygulanacağı uygulamaları seçer. */
class AppsPage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.APPS, true, nav) {
    private val status = Label("", 14f, ink = Ink.SOFT, align = ALIGN_CENTER, maxLines = 0)
    private val list = AppListCard { scroll.offset }
    private val pending = ParagraphCard(Strings.APPS_PENDING)
    private val apply = ActionButton(Strings.APPS_APPLY, true) { model.applyAppsNow() }
    private var seen = -1
    private var shownApps: List<AppEntry>? = null

    init {
        col.add(SettingsCard().also { c ->
            c.add(SegmentRow(Strings.APPS_MODE, Strings.OPT_APPS, { it.appScope.ordinal }, { s, i -> s.copy(appScope = AppScope.values()[i]) }))
        })
        col.add(ParagraphCard(Strings.APPS_NOTE))
        col.add(pending)
        col.add(apply)
        col.add(status)
        col.add(list)
        finish()
        col.gap = 12f
        model.loadApps()
    }

    override fun onLaidOut(env: Env, left: Float) { seen = -1 }

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version) {
            seen = model.version
            val s = model.settings
            val apps = model.apps
            if (apps !== shownApps) { shownApps = apps; list.setApps(apps ?: emptyList()) }
            val picking = s.appScope != AppScope.ALL
            val installed = apps?.map { it.pkg }?.toSet() ?: emptySet()
            status.text = when {
                !picking -> ""
                apps == null -> Strings.APPS_LOADING
                apps.isEmpty() -> Strings.APPS_EMPTY
                s.apps.none { it in installed } -> Strings.APPS_NONE_SELECTED
                else -> ""
            }
            list.visible = picking && !apps.isNullOrEmpty()
            pending.visible = model.appsPending
            apply.visible = model.appsPending
            relayoutContent(env)
        }
        return super.tick(dt, env)
    }
}

// =============================================================================== yardım ve günlük

/** İçinde çok satırlı yazı olan cam kart. [tail] verilirse metnin son cümlesi olarak yeşil renkte, aynı kartta çizilir. */
class ParagraphCard(text: String, tail: String? = null) : Node() {
    private val label = Label(text, 15f, ink = Ink.TEXT, maxLines = 0)
    private val last = tail?.let { Label(it, 15f, ink = Ink.GOOD, maxLines = 0) }
    override fun layout(env: Env, maxW: Float) {
        w = maxW
        label.layout(env, maxW - 32f)
        label.x = 16f; label.y = 14f
        h = label.h + 28f
        if (last != null) {
            last.layout(env, maxW - 32f)
            last.x = 16f; last.y = 14f + label.h + 8f
            h = last.y + last.h + 14f
        }
    }
    override fun draw(g: Gfx, env: Env) {
        env.art.card(g, 0f, 0f, w, h, M.CARD_R)
        g.save(); g.translate(label.x, label.y); label.draw(g, env); g.restore()
        if (last != null) { g.save(); g.translate(last.x, last.y); last.draw(g, env); g.restore() }
    }
    override fun a11y(): A11y = A11y(if (last == null) label.text else label.text + " " + last.text, Role.TEXT)
}

class HelpPage(nav: Nav) : ScrollPage(Strings.HELP, true, nav) {
    init {
        for ((title, body) in Strings.HELP_SECTIONS) {
            col.add(SectionTitle(title))
            col.add(ParagraphCard(body))
        }
        col.add(SectionTitle(Strings.HELP_WHY_TITLE))
        col.add(ParagraphCard(Strings.HELP_WHY_BODY, Strings.HELP_WHY_TAIL))
        finish()
        col.gap = 8f
    }
}

/** Günlük satırlarını gösteren cam kart. */
class LogView(private val host: Host) : Node() {
    private var lines: List<String> = emptyList()
    private var shown: List<String> = emptyList()
    private var empty = true

    /** Kayıtları yeniden okur. Ardından üst sayfa yerleşimi yenilemelidir (satır sayısı değişir). */
    fun refresh() {
        val raw = host.diagnostics().trim()
        empty = raw.isEmpty()
        lines = if (empty) listOf(Strings.LOG_EMPTY) else raw.split('\n').asReversed()   // en yeni üstte
    }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        if (lines.isEmpty()) refresh()
        shown = lines.map { TextFit.ellipsize(env.metrics, it, maxW - 32f, env.sz(12f), false) }
        h = shown.size * env.sz(12f) * 1.5f + 28f
    }

    override fun draw(g: Gfx, env: Env) {
        env.art.card(g, 0f, 0f, w, h, M.CARD_R)
        val s = env.sz(12f)
        g.paint(env.theme.text)
        for (i in 0 until shown.size) g.text(shown[i], 16f, 14f + s + i * s * 1.5f, s, false, ALIGN_LEFT)
    }

    /** Kopyalanacak/paylaşılacak metin (en eski üstte). Kayıt yoksa boş: "Henüz kayıt yok." yer tutucusu kopyalanmaz. */
    fun text(): String = if (empty) "" else lines.asReversed().joinToString("\n")
    override fun a11y(): A11y = A11y(shown.take(8).joinToString(". "), Role.TEXT)
}

/** Eşit genişlikte yan yana düğmeler. */
class ButtonsRow(private val buttons: List<ActionButton>) : Node() {
    init { for (b in buttons) add(b) }
    override fun layout(env: Env, maxW: Float) {
        w = maxW
        val gap = 10f
        val bw = (maxW - gap * (buttons.size - 1)) / buttons.size
        var cx = 0f
        for (b in buttons) { b.layout(env, bw); b.x = cx; b.y = 0f; cx += bw + gap }
        h = buttons.maxOf { it.h }
    }
}

class LogPage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.LOG, true, nav) {
    private val view = LogView(model.host)
    private val note = Label(Strings.LOG_NOTE, 13f, ink = Ink.SOFT, maxLines = 0)
    private var envRef: Env? = null

    init {
        view.refresh()
        col.add(note)
        col.add(ButtonsRow(listOf(
            ActionButton(Strings.COPY, false) { model.copy(view.text()) },
            ActionButton(Strings.SHARE, false) { model.host.shareText(view.text()) },
            ActionButton(Strings.CLEAR, false) { clear() },
        )))
        col.add(view)
        finish()
    }

    override fun onLaidOut(env: Env, left: Float) { envRef = env }

    private fun clear() {
        model.host.clearDiagnostics()
        view.refresh()
        envRef?.let { relayoutContent(it) }
        model.toast(Strings.CLEARED)
    }
}
