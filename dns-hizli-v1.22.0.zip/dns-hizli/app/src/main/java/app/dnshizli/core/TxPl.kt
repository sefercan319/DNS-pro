package app.dnshizli.core

/** Polski. */
object TxPl : Tx() {
    override val lang = Lang.PL

    override val decimalSep = ','
    override val thousand = " tys."
    override val million = " mln"
    override fun percent(n: Int) = "$n%"
    override val dayU = "d"
    override val hourU = "godz."
    override val minU = "min"
    override val secU = "s"
    override val justNow = "przed chwilą"
    override fun ago(span: String) = "$span temu"

    override val OFF = "Brak połączenia"
    override val CONNECTING = "Łączenie…"
    override val ON = "Połączono"
    override val ERROR = "Błąd połączenia"
    override val PAUSED = "Wstrzymano"
    override val HINT_OFF = "Dotknij kuli, aby połączyć"
    override val HINT_CONNECTING = "To może potrwać kilka sekund"
    override val HINT_ERROR = "Dotknij, aby spróbować ponownie"
    override val HINT_PAUSED = "Dotknij, aby wznowić teraz"
    override val ERR_DEFAULT = "Nie udało się połączyć"
    override fun selected(name: String) = "Wybrano: $name"
    override fun pausedUntil(time: String) = "Wznowienie o $time"
    override fun blockedShort(n: String) = "zablokowane: $n"
    override fun queriesShort(n: String) = "zapytania: $n"
    override fun cacheShort(pct: String) = "cache $pct"

    override val SERVERS = "Serwery"
    override val FILTER_ALL = "Wszystkie"
    override val FILTER_FAV = "Ulubione"
    override val FILTER_RECENT = "Ostatnie"
    override val EMPTY_FAV = "Brak ulubionych. Dotknij gwiazdki serwera."
    override val EMPTY_RECENT = "Nie było jeszcze połączeń z żadnym serwerem."
    override val EMPTY_FILTER = "Brak serwerów w tej kategorii."
    override val MEASURE = "Zmierz szybkość"
    override val MEASURING = "Pomiar…"
    override val SORT = "Sortowanie"
    override val PULL_TO_MEASURE = "Pociągnij, aby zmierzyć"
    override val RELEASE_TO_MEASURE = "Puść, aby zmierzyć"
    override fun serversCount(n: Int) = "serwery: $n"
    override fun showAllServers(n: Int) = "Pokaż wszystkie ($n)"
    override val SHOW_LESS = "Pokaż mniej"
    override val TAG_FAST = "Szybkie"
    override val TAG_PRIVACY = "Prywatność"
    override val TAG_ADS = "Bez reklam"
    override val TAG_FAMILY = "Rodzina"
    override val TAG_SECURITY = "Ochrona"
    override val VAR_OPEN = "Bez filtra"
    override val VAR_ADS = "Bez reklam"
    override val VAR_SECURITY = "Ochrona"
    override val VAR_FAMILY = "Rodzina"
    override val A11Y_CONNECTED = "połączono"
    override val A11Y_ENCRYPTED = "szyfrowany"
    override fun favA11y(name: String) = "$name w ulubionych"

    override val COPIED = "Skopiowano do schowka"
    override val DISCONNECTED = "Rozłączono"
    override val BACKUP = "Przełączono na serwer zapasowy"
    override val NO_REPLY = "Żaden serwer nie odpowiedział"
    override val MEASURE_FIRST = "Najpierw zmierz szybkość"
    override val CONNECT = "Połącz"
    override val UNDO = "Cofnij"
    override fun fastest(name: String, ms: Int) = "Najszybszy: $name · $ms ms"
    override fun switched(name: String) = "Przełączanie na $name"
    override fun hiddenToast(name: String) = "Ukryto: $name"

    override val PRIMARY = "Podstawowy"
    override val SECONDARY = "Alternatywny"
    override val COPY = "Kopiuj"
    override fun addressA11y(label: String, ip: String) = "Adres ($label): $ip"
    override val CONNECT_TO_THIS = "Połącz z tym serwerem"
    override val SWITCH_TO_THIS = "Przełącz na ten serwer"
    override val CONNECTED_NOW = "Obecnie połączony"
    override val ADD_FAV = "Dodaj do ulubionych"
    override val REMOVE_FAV = "Usuń z ulubionych"
    override val MEASURE_THIS = "Zmierz szybkość"
    override val HIDE = "Ukryj na liście"
    override val UNHIDE = "Pokaż na liście"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Ostatni pomiar: brak odpowiedzi · $ago" else "Ostatni pomiar: $ms ms · $ago"
    override val NEVER_MEASURED = "Jeszcze nie zmierzono"
    override val ENC_SUPPORT = "Szyfrowany DNS"
    override val ENC_NONE = "Nieobsługiwany"
    override val ENC_ONLY = "Tylko połączenia szyfrowane"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Najlepszy $best ms · mediana $median ms · straty $lossPct%"
    override val HISTORY = "Historia pomiarów"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: liczba pomiarów $n, brak odpowiedzi" else "$HISTORY: liczba pomiarów $n, mediana $median ms"

    override val QUICK_TITLE = "Szybki wybór"
    override val QUICK_FAVORITES = "Ulubione"
    override val QUICK_RECENT = "Ostatnio używane"
    override val PAUSE_FOR = "Wstrzymaj"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} godz." else "$n min"
    override val RESUME = "Wznów"

    override val SETTINGS = "Ustawienia"
    override val MENU = "Menu"
    override val PERSONALIZE = "Personalizacja"
    override val PZ_BACKGROUND = "Tło"
    override val PZ_AUTO = "Motyw automatyczny"
    override val PZ_FEEL = "Szkło, tekst i ruch"
    override val PZ_ACCESS = "Dostępność i energia"
    override val DNS_SETTINGS = "Ustawienia DNS"
    override val CONN_APPS = "Połączenie i aplikacje"
    override val STATS_HISTORY = "Statystyki i historia"
    override val SEC_LOOK = "Wygląd"
    override val SEC_LIST = "Lista serwerów"
    override val SEC_DATA = "Dane"
    override val ABOUT = "Informacje"
    override val LANGUAGE = "Język"
    override val LANG_AUTO = "Automatycznie (język systemu)"
    override val THEME = "Motyw"
    override val THEME_AUTO = "Automatyczny"
    override val THEME_AUTO_NOTE = "Automatyczny · jasny/ciemny jak w systemie"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Łąka"
        "ocean" -> "Ocean"
        "sunset" -> "Zachód słońca"
        "lavender" -> "Lawenda"
        "coral" -> "Koral"
        "mint" -> "Mięta"
        "sakura" -> "Sakura"
        "honey" -> "Miód"
        "night" -> "Noc"
        "amoled" -> "Czarny (AMOLED)"
        "aurora" -> "Zorza"
        "dynamic" -> "Tapeta"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Motyw: $name"
    override val THEME_SCHEDULE = "Motyw nocny według godzin"
    override val THEME_SCHEDULE_NOTE = "W trybie automatycznym ciemny motyw w wybranych godzinach"
    override val GLASS = "Przezroczystość szkła"
    override val BUBBLES = "Bąbelki"
    override val STYLE = "Styl"
    override val STYLE_NOTES = listOf(
        "Szklany, błyszczący, z bąbelkami: oryginalny wygląd.",
        "Niebo, zielona trawa, szklane krople i żelowe przyciski.",
        "Miasto, muzyka i młodość: wieżowce, głośnik, kręgi, gwiazdy i promienie.",
        "Natura i technologia: zielona Ziemia, turbiny wiatrowe, panele słoneczne i liście.",
        "Holograficzny róż i fiolet, chromowane serca, bańki, iskierki i okna z pikseli.",
        "Turkusowe, zielone i żółte światło, jasna smuga i przezroczyste siatkowe fale.",
        "Półprzezroczyste niebiesko-indygo szkło z jasnym białym światłem krawędzi i załamanymi refleksami.",
    )
    override val WALLPAPER = "Zdjęcie w tle"
    override val WP_OFF = "Brak"
    override val WP_ON = "Zdjęcie"
    override val WP_PICK = "Wybierz zdjęcie z galerii"
    override val WP_PICK_NOTE = "Zostaje na telefonie, nigdy nie jest wysyłane. Przysłona wzmacnia się automatycznie, gdy trzeba, by tekst był czytelny."
    override val WP_PRESETS = "Wbudowane obrazy"
    override val WP_PRESETS_NOTE = "8 obrazów w aplikacji. Bez internetu."
    override val WP_REMOVE = "Usuń zdjęcie"
    override val WP_DIM = "Siła przysłony"
    override val WP_BLUR = "Rozmycie"
    override val OPT_WP_BLUR = listOf("Wył.", "Lekkie", "Mocne")
    override val WP_SAVED = "Ustawiono tło"
    override val WP_FAILED = "Nie można otworzyć zdjęcia"
    override val WP_REMOVED = "Usunięto tło"
    override val APP_ICON = "Ikona aplikacji"
    override val ICON_NOTES = listOf(
        "Szklana kula: pierwotna ikona.",
        "Szklana kropla nad niebem i trawą.",
        "Limonkowo-turkusowe miasto z promieniami i przyciskiem zasilania.",
        "Błyszcząca zielona Ziemia z kiełkującym liściem.",
        "Błyszczące chromowe serce na holograficznym różu i fiolecie.",
        "Szklana kula na turkusowo-żółtej poświacie i falach światła.",
        "Matowa szklana kula z jasnym brzegiem na niebiesko-indygo świetle.",
    )
    override val ICON_SET = "Ikona zmieni się po wyjściu"
    override val ICON_NOTE = "Jeśli skrót na ekranie głównym zniknie, dodaj aplikację ponownie."
    override val ICON_FAILED = "Nie udało się zmienić ikony"
    override val HELP_WHY_TITLE = "Dlaczego ta aplikacja?"
    override val HELP_WHY_BODY = "DNS Hızlı jest mała i prosta, stworzona przez jedną osobę, bez dużej firmy za plecami. Bez konta i reklam: sam wybierasz DNS, szyfrowanie, których aplikacji dotyczy i jak wygląda."
    override val HELP_WHY_TAIL = "Może nie jest lepsza od konkurencji, ale działa i warto ją wypróbować."
    override val TROUBLE = "Rozwiązywanie problemów"
    override val TROUBLE_RECHECK = "Sprawdź ponownie"
    override val TROUBLE_ALL_OK = "Wszystko wygląda dobrze. Jeśli nadal się nie łączy, spróbuj innego serwera."
    override val TROUBLE_SOME = "Rzeczy do sprawdzenia:"
    override val T_NET = "Internet"
    override val NET_OK = "połączony."
    override val NET_BAD = "brak lub ograniczony. Sprawdź Wi-Fi lub dane mobilne."
    override val T_PERM = "Zgoda na VPN"
    override val PERM_OK = "udzielona."
    override val PERM_BAD = "jeszcze nie udzielona. Android zapyta przy łączeniu; zezwól."
    override val T_VPN = "Inny VPN"
    override val VPN_OK = "brak."
    override val VPN_BAD = "wygląda na włączony. Android pozwala na jeden VPN naraz; wyłącz go."
    override val T_DNS = "Prywatny DNS Androida"
    override val PDNS_OK = "wyłączony lub automatyczny, bez problemu."
    override val PDNS_BAD = "jest przypięty do jednego serwera i może omijać DNS tej aplikacji. W Ustawienia > Sieć > Prywatny DNS wybierz Automatyczny lub Wyłączony."
    override val SEARCH = "Szukaj"
    override val SEARCH_HINT = "Nazwa lub właściciel serwera"
    override val SEARCH_CLEAR = "Wyczyść"
    override val SHARE_RESULTS = "Udostępnij wyniki pomiarów"
    override val SHARE_RESULTS_HEAD = "Pomiary DNS Hızlı (od najszybszego)"
    override val NO_RESULTS = "Najpierw wykonaj pomiar"
    override val CUSTOM_EDIT = "Edytuj"
    override fun customUpdated(name: String) = "Zaktualizowano: $name"
    override val KEEP_HISTORY = "Zapisuj historię"
    override val KEEP_HISTORY_NOTE = "Gdy wyłączone, ostatnie serwery, historia i pomiary nie są zapisywane. Istniejące dane zostają."
    override val MOTION = "Animacje"
    override val TEXT_SIZE = "Rozmiar tekstu"
    override val HIGH_CONTRAST = "Wysoki kontrast"
    override val HIGH_CONTRAST_NOTE = "Mniej przezroczyste szkło i ciemniejszy tekst"
    override val MINIMAL = "Widok minimalny"
    override val MINIMAL_NOTE = "Ukrywa filtry i wiersz statystyk"
    override val LOW_POWER = "Oszczędzanie energii"
    override val LOW_POWER_NOTE = "Wyłącza wszystkie animacje, oszczędza baterię"
    override val HAPTICS = "Wibracje"
    override val HAPTICS_NOTE = "Delikatna reakcja na dotyk"
    override val ENCRYPTION = "Szyfrowany DNS"
    override val ENCRYPTION_NOTE = "Auto: najpierw DoT, potem DoH, na końcu zwykły DNS"
    override val AUTO_CONNECT = "Łącz po otwarciu aplikacji"
    override val AUTO_CONNECT_NOTE = "Łączy z ostatnim serwerem po otwarciu aplikacji"
    override val CONNECT_ON_BOOT = "Łącz po uruchomieniu"
    override val CONNECT_ON_BOOT_NOTE = "Łączy automatycznie po restarcie telefonu"
    override val AUTO_FASTEST = "Łącz z najszybszym"
    override val AUTO_FASTEST_NOTE = "Kula wybiera najszybszy serwer z ostatniego pomiaru"
    override val REFRESH_ON_NET = "Odświeżaj po zmianie sieci"
    override val REFRESH_ON_NET_NOTE = "DNS odświeża się przy przejściu między Wi-Fi a danymi komórkowymi"
    override val NOTIFY_DROP = "Powiadamiaj o rozłączeniu"
    override val NOTIFY_DROP_NOTE = "Powiadomienie z przyciskiem ponownego połączenia przy zerwaniu"
    override val NOTIFY_CONNECT = "Powiadom o połączeniu"
    override val NOTIFY_CONNECT_NOTE = "Krótkie powiadomienie po nawiązaniu połączenia"
    override val NOTIFY_STOP = "Powiadom o rozłączeniu"
    override val NOTIFY_STOP_NOTE = "Krótkie powiadomienie, gdy sam się rozłączasz"
    override val NOTIFY_TIMEOUT = "Powiadom o przekroczeniu czasu"
    override val NOTIFY_TIMEOUT_NOTE = "Powiadomienie, gdy serwer DNS przestaje odpowiadać"
    override val NOTIF_PERM = "Zgoda na powiadomienia"
    override val PERM_ALLOWED = "Włączona"
    override val PERM_BLOCKED = "Wyłączona · napraw"
    override val NOTIF_CONNECTED_TITLE = "DNS połączony"
    override val NOTIF_STOPPED_TITLE = "DNS rozłączony"
    override val NOTIF_STOPPED_TEXT = "Ochrona wyłączona"
    override val NOTIF_TIMEOUT_TITLE = "Przekroczono czas DNS"
    override val FAIL_CLOSED = "Blokuj DNS po zerwaniu"
    override val FAIL_CLOSED_NOTE = "Gdy połączenie padnie, zapytania DNS nie wyciekną do operatora; nie powiodą się do ponownego połączenia"
    override val FILTER_MEM = "Pamięć filtra"
    override val OPT_FILTER_MEM = listOf("Auto", "Lekka", "Pełna")
    override val FILTER_MEM_NOTE = "Auto: bez dużej listy przy małej pamięci. Lekka: bez. Pełna: z nią"
    override val ERR_NO_APPS = "Nie wybrano aplikacji, ochrona nie została uruchomiona. Wybierz aplikacje lub przełącz na „Wszystkie aplikacje”."
    override val NOTIF_SEALED = "DNS zablokowany podczas łączenia"
    override val ERR_SEALED = "Nie udało się połączyć. DNS jest zablokowany, by zapytania nie wyciekły. Stuknij Zatrzymaj, aby go zwolnić."
    override val SEALED_INFO = "DNS zablokowany do czasu powrotu połączenia"
    override val LATENCY_TITLE = "Opóźnienie zapytań"
    override val LATENCY_EMPTY = "Pojawi się na żywo po połączeniu i napływie zapytań"
    override val FILTER_MINE = "Moja własna lista"
    override val MINE_PASTE = "Importuj ze schowka"
    override val MINE_PASTE_NOTE = "Plik hosts lub jedna domena w wierszu"
    override val MINE_FILE = "Importuj z pliku"
    override val MINE_FILE_NOTE = "Plik .txt lub hosts z telefonu"
    override val MINE_EXPORT = "Kopiuj moją listę blokad"
    override val MINE_EXPORT_NOTE = "Do schowka, w formacie hosts"
    override val MINE_CLEAR = "Usuń zaimportowaną listę"
    override val MINE_FOOT = "Odczytuje wiersze hosts (0.0.0.0 domena), zwykłe listy domen i reguły ||domena^. Do 50 000 nazw. Twoja lista dozwolonych zawsze ma pierwszeństwo."
    override val MINE_NOTHING = "Nie znaleziono poprawnych domen"
    override val MINE_CLIP_EMPTY = "Schowek jest pusty"
    override val MINE_FILE_ERR = "Nie można odczytać pliku"
    override val MINE_CLEARED = "Zaimportowana lista usunięta"
    override val MINE_CLEAR_ASK = "Usunąć zaimportowaną listę?"
    override val MINE_CUT = "Osiągnięto limit, resztę pominięto"
    override fun notifTimeout(name: String) = "$name nie odpowiada. Próbuję ponownie."
    override val MOD_DPI = "Obejście DPI"
    override val MOD_ADS = "Reklamy+"
    override val MOD_DPI_SUB = "Odblokowuje strony"
    override val MOD_ADS_SUB = "Blokuje poza DNS"
    override val MOD_ON = "Wł."
    override val MOD_OFF = "Wył."
    override val BLOCK_QUIC = "Blokuj QUIC"
    override val BLOCK_QUIC_NOTE = "Aplikacje wracają do TCP, więc Obejście DPI i Reklamy+ obejmują i je"
    override val GW_TRIPPED = "Wykryto problem z połączeniem: Obejście DPI i Reklamy+ wyłączono"
    override val MOD_FAILED = "Nie udało się włączyć. Brak zgody VPN lub działa inny VPN."
    override fun gwOn(modules: String) = "Brama włączona: $modules"
    override fun gwOnStats(modules: String, blocked: String) = "Brama włączona: $modules · zablokowano $blocked"
    override fun modOn(name: String) = "Włączono: $name"
    override fun modOff(name: String) = "Wyłączono: $name"
    override fun modAdsCount(n: String) = "$n zablokowanych"
    override fun modDpiCount(n: String) = "$n połączeń podzielonych"
    override fun latencyLine(avg: String, max: String, timeouts: Int) = "śr. $avg · maks. $max" + (if (timeouts > 0) " · przekroczeń czasu: $timeouts" else "")
    override fun mineCount(n: Int) = "Domen: $n"
    override fun mineAdded(n: Int) = "Dodano domen: $n"
    override fun mineCopied(n: Int) = "Skopiowano domen: $n"
    override val CACHE = "Pamięć podręczna DNS"
    override val CLEAR_CACHE = "Wyczyść pamięć podręczną"
    override val CACHE_CLEARED = "Wyczyszczono pamięć podręczną"
    override val ONLY_CONNECTED = "Dostępne po połączeniu"
    override val RULE_WIFI = "Serwer dla Wi-Fi"
    override val RULE_MOBILE = "Serwer dla sieci komórkowej"
    override val RULE_AUTO = "Automatycznie"
    override val RULE_AUTO_NOTE = "Ostatnio używany serwer"
    override val COMPACT = "Kompaktowa lista"
    override val COMPACT_NOTE = "Niższe wiersze bez opisów"
    override val HIDDEN = "Ukryte serwery"
    override val HIDDEN_NONE = "Brak"
    override val STAT_QUERIES = "Zapytania łącznie"
    override val STAT_HITS = "Z pamięci podręcznej"
    override val STAT_BLOCKED = "Zablokowane (szacunkowo)"
    override val STAT_TIME = "Łączny czas połączenia"
    override val WEEK = "Ostatnie 7 dni"
    override fun weekA11y(total: String) = "Zapytania z ostatnich 7 dni: $total"
    override val WEEKDAYS = listOf("Pn", "Wt", "Śr", "Cz", "Pt", "So", "Nd")
    override val EXPORT = "Eksportuj ustawienia"
    override val IMPORT = "Importuj ustawienia"
    override val EXPORTED = "Skopiowano kod ustawień do schowka"
    override val IMPORTED = "Wczytano ustawienia"
    override val IMPORT_BAD = "Brak prawidłowego kodu ustawień w schowku"
    override val RESET_SETTINGS = "Resetuj ustawienia"
    override val RESET_STATS = "Resetuj statystyki"
    override val CONFIRM = "Na pewno?"
    override val RESET = "Resetuj"
    override val RESET_DONE = "Zresetowano"
    override val LOG = "Dziennik diagnostyczny"
    override val HELP = "Jak to działa?"
    override val VPN_SETTINGS = "Systemowe ustawienia VPN"
    override val SHARE_APP = "Udostępnij aplikację"
    override val RATE_APP = "Oceń aplikację"
    override val FEEDBACK = "Wyślij opinię"
    override fun shareAppText(url: String) = "$APP łączy z popularnymi serwerami DNS jednym dotknięciem: $url"
    override val VERSION = "Wersja"
    override val OPT_BUBBLES = listOf("Wył.", "Mało", "Dużo")
    override val OPT_MOTION = listOf("Pełne", "Mniej", "Wył.")
    override val OPT_CACHE = listOf("Wył.", "Mała", "Normalna", "Duża")
    override val OPT_ENCRYPTION = listOf("Auto", "DoT", "DoH", "Wył.")
    override val PLAIN_DNS = "Zwykły DNS"

    override val LOG_NOTE = "Zapisywane są tylko zdarzenia połączenia. Nazwy zapytań i dane osobowe nigdy nie są przechowywane."
    override val LOG_EMPTY = "Brak wpisów."
    override val SHARE = "Udostępnij"
    override val CLEAR = "Wyczyść"
    override val CLEARED = "Wyczyszczono"
    override val HELP_SECTIONS = listOf(
        "Czym jest DNS?" to
            "DNS to usługa, która zamienia adresy internetowe (np. example.com) na liczby zrozumiałe dla urządzeń. " +
            "Używany DNS wpływa na szybkość, prywatność i to, jakie treści są blokowane.",
        "Co robi aplikacja?" to
            "Sprawia, że wybrany serwer DNS jest używany we wszystkich aplikacjach. W tym celu otwiera na telefonie lokalny interfejs VPN, " +
            "ale Twój ruch nie trafia na żaden serwer VPN. Do wybranego serwera wysyłane są tylko zapytania DNS; " +
            "cała reszta płynie zwykłą drogą.",
        "Szyfrowany DNS (DoT / DoH)" to
            "Na serwerach, które to obsługują, zapytania są szyfrowane: nikt w sieci (właściciel Wi-Fi, operator) nie zobaczy, " +
            "jakie strony odwiedzasz, ani nie podmieni odpowiedzi. W trybie Auto najpierw próbowany jest DoT, potem DoH; jeśli żaden nie działa, " +
            "używany jest zwykły DNS. Dostaniesz wtedy ostrzeżenie, a aplikacja spróbuje wrócić do szyfrowania przy każdej " +
            "zmianie sieci i co 10 minut. Gdy włączone jest „Ścisłe szyfrowanie”, zwykły DNS nigdy nie jest używany. " +
            "Ekran główny pokazuje, która metoda jest w użyciu.",
        "Test połączenia" to
            "☰ > Ustawienia DNS > Przetestuj połączenie wysyła prawdziwe zapytania DNS przez tunel. Pokazuje, " +
            "czy DNS rzeczywiście odpowiada z wybranego serwera, jak szybko, czy serwer weryfikuje podpisy DNSSEC " +
            "i czy blokuje znaną domenę reklamową.",
        "Prywatność" to
            "Bez konta, bez zbierania danych, bez reklam. Aplikacja nie zapisuje nazw zapytań i sama niczego nigdzie nie wysyła. " +
            "Twoje zapytania trafiają tylko do wybranego dostawcy DNS, zgodnie z jego polityką prywatności. " +
            "Szyfrowany DNS (DoT/DoH) nie pozwala nikomu w sieci czytać ani zmieniać Twoich zapytań. Przed wysłaniem aplikacja usuwa dodatkowe dane, które mogłyby zdradzić urządzenie (podsieć klienta, ciasteczka, identyfikatory), dopełnia wiadomości, by ukryć ich długość, i porzuca bilety sesji TLS po zmianie sieci. " +
            "Szczerze: bez przekaźnika dostawca DNS nadal widzi Twój publiczny adres IP (musi przecież Ci odpowiedzieć), a błąd certyfikatu może oznaczać, że ktoś ingeruje w połączenie. " +
            "Dziennik diagnostyczny zawiera wyłącznie zdarzenia połączenia.",
        "Bateria i zasoby" to
            "W tle zużywa bardzo mało zasobów. Przy wyłączonym ekranie nic nie działa w pętli; " +
            "aplikacja pracuje tylko wtedy, gdy przychodzi zapytanie DNS. Nieużywane połączenia szyfrowane zamykają się same.",
        "Warto wiedzieć" to
            "Android pozwala na tylko jeden VPN naraz; ta aplikacja nie połączy się, gdy aktywna jest inna aplikacja VPN. " +
            "Ustawienie „bezpieczny DNS” w przeglądarce i „Prywatny DNS” Androida z konkretną nazwą hosta używają własnego serwera " +
            "i mogą omijać to przekierowanie; wystarczy zostawić je na „Automatyczny” lub „Wyłączony”. " +
            "Przytrzymaj kulę, aby szybko przełączyć się na ulubione serwery lub na chwilę wstrzymać połączenie.",
    )

    override val NOTIF_CHANNEL = "Stan połączenia"
    override val NOTIF_CHANNEL_NOTE = "Widoczne, gdy połączenie DNS jest aktywne"
    override val NOTIF_ALERT_CHANNEL = "Alerty połączenia"
    override val NOTIF_CONNECTING = "Łączenie…"
    override val NOTIF_STOP = "Rozłącz"
    override val NOTIF_NEXT = "Następny"
    override val NOTIF_DROP_TITLE = "Utracono połączenie DNS"
    override val NOTIF_RECONNECT = "Połącz ponownie"
    override fun notifOn(name: String, proto: String) = "Połączono z $name · $proto"
    override fun notifPaused(time: String) = "Wstrzymano · wznowienie o $time"
    override val TILE_ON = "Połączono"
    override val TILE_OFF = "Wył."
    override val WIDGET_TAP = "Dotknij: połącz / rozłącz"
    override val ERR_PERMISSION = "Nie przyznano uprawnienia VPN"
    override val ERR_ESTABLISH = "Nie udało się otworzyć interfejsu VPN. Może działać inny VPN."
    override fun errNoReply(name: String) = "$name nie odpowiada"
    override val PHONE_BYPASS = "Telefon nie używa tego DNS (Prywatny DNS?)"
    override fun errNoProto(name: String, proto: String) = "$name nie obsługuje $proto"
    override val ERR_SOCKET = "Brak dostępu do sieci"
    override fun errPrivateDns(host: String) = "Prywatny DNS Androida jest ustawiony na $host i omija tę aplikację. Ustaw Ustawienia > Sieć > Prywatny DNS na Automatyczny lub Wyłączony."
    override val ERR_REVOKED = "System zamknął połączenie"
    override val ERR_TUNNEL = "Tunel został nieoczekiwanie zamknięty"
    override val ERR_UNKNOWN = "Wystąpił nieoczekiwany błąd"

    override val CONSENT_TITLE = "Zanim się połączysz"
    override val CONSENT_BODY = listOf(
        "$APP używa interfejsu VPN Androida, aby kierować Twoje zapytania DNS (nazwy odwiedzanych stron) do wybranego serwera DNS.",
        "Twój ruch nie jest wysyłany na serwer VPN; do wybranego dostawcy trafiają tylko zapytania DNS. Na serwerach, które to obsługują, " +
            "zapytania są szyfrowane (DoT/DoH); na pozostałych są wysyłane bez szyfrowania. Obowiązuje polityka prywatności dostawcy." +
            " Jeśli włączysz „$MOD_DPI” lub „$MOD_ADS”, cały ruch przechodzi przez przekaźnik działający tylko w telefonie; nadal nie jest nigdzie wysyłany.",
        "Aplikacja nie zbiera danych osobowych, nie zapisuje nazw zapytań i niczego nikomu nie udostępnia.",
        "Jeśli przejdziesz dalej, Android wyświetli prośbę o połączenie VPN; musisz dotknąć „OK”.",
    )
    override val CONSENT_OK = "Rozumiem, dalej"
    override val CLOSE = "Zamknij"
    override val BACK = "Wstecz"

    override val RESUMING = "Wznawianie…"
    override val DOWNGRADED = "Brak szyfrowania, używany zwykły DNS"
    override val UPGRADED = "Znów szyfrowany DNS"
    override val NOTIF_DOWNGRADE_TITLE = "DNS nie jest szyfrowany"
    override fun notifDowngrade(name: String) = "Nie udało się nawiązać szyfrowanego połączenia z $name. Używany jest zwykły DNS; aplikacja spróbuje wrócić do szyfrowania."
    override fun backupUsed(failed: String, used: String) = "$failed nie odpowiada, połączono z $used"
    override val NOTIF_RETRYING = "Utracono połączenie, ponawianie…"
    override fun errNoEncrypted(name: String) = "Nie udało się nawiązać szyfrowanego połączenia z $name"
    override fun errUntrusted(name: String) = "Nie udało się zweryfikować certyfikatu $name; sieć lub oprogramowanie może ingerować w szyfrowane połączenia"
    override val APPLYING = "Stosowanie nowego ustawienia do połączenia"
    override val CONFIRM_DISCONNECT = "Rozłączyć?"
    override val DISCONNECT = "Rozłącz"

    override val SEC_NOTIF = "Powiadomienia"
    override val STRICT_ENC = "Ścisłe szyfrowanie"
    override val STRICT_ENC_NOTE = "Nigdy nie przechodź na zwykły DNS"
    override val IP_MODE = "Wersja IP"
    override val IP_MODE_NOTE = "Najpierw próbowana jest ta, którą ma Twoja sieć; druga jest zapasowa"
    override val OPT_IP_MODE = listOf("IPv4 + IPv6", "Tylko IPv4")
    override val FILTER = "Blokowanie"
    override val FILTER_LEVEL = "Blokowanie reklam i śledzenia"
    override val OPT_FILTER = listOf(
        "Wył.",
        "Podst.",
        "Średni",
        "Ścisły",
    )
    override val FILTER_NOTES = listOf(
        "Nic nie jest blokowane.",
        "Znane strony reklamowe, phishingowe i ze złośliwym kodem. Bardzo małe ryzyko usterek.",
        "Podstawowy plus więcej trackerów i analityki. Niektóre strony mogą mieć problemy.",
        "Najszersza lista, także oszustwa, nadużycia i przekierowania. Częste usterki.",
    )
    override val FILTER_INFO = "Blokowanie odbywa się w całości na telefonie: gdy ktoś pyta o stronę z listy, odpowiedzią jest NXDOMAIN, zapytanie nie trafia do żadnego serwera i żadna nazwa nie jest zapisywana. Działa tylko po połączeniu. Własne bezpieczne DNS przeglądarki może to ominąć. Gdy strona przestanie działać, zezwól na nią w Ostatnio zablokowane."
    override val FILTER_LAST = "Ostatnio zablokowane"
    override val FILTER_RECENT_NOTE = "Dotknij: zezwól"
    override val FILTER_RECENT_EMPTY = "W tej sesji nic nie zablokowano. Nazwy pojawią się tu po połączeniu i włączeniu poziomu."
    override val FILTER_RECENT_FOOT = "Tylko w pamięci na czas tej sesji; nigdy nie zapisywane, usuwane po rozłączeniu."
    override val FILTER_ALLOW = "Dozwolone"
    override val FILTER_BLOCK = "Moja lista blokad"
    override val FILTER_ADD = "Dodaj…"
    override val FILTER_REMOVE = "Dotknij: usuń"
    override val FILTER_ALLOW_ADD = "Domena do zezwolenia"
    override val FILTER_BLOCK_ADD = "Domena do zablokowania"
    override val FILTER_ERR = "Wpisz poprawną domenę, np. przyklad.pl"
    override val FILTER_ERR_LIMIT = "Najwyżej 200 domen"
    override val FILTER_ALLOW_EMPTY = "Brak dozwolonych domen. Gdy strona przestanie działać, dodaj ją tutaj."
    override val FILTER_BLOCK_EMPTY = "Twoja lista blokad jest pusta."
    override val FILTER_ALLOW_FOOT = "Domena i wszystkie jej subdomeny nigdy nie są blokowane. Zezwolenie wygrywa z każdą listą i Twoją listą blokad."
    override val FILTER_BLOCK_FOOT = "Domena i wszystkie jej subdomeny są zawsze blokowane (także przy poziomie Wył.)."
    override val FILTER_REMOVE_BTN = "Usuń"
    override fun filterAllowed(name: String) = "$name jest dozwolone"
    override fun filterBlocked(name: String) = "$name będzie blokowane"
    override fun filterRemoved(name: String) = "Usunięto $name"
    override fun filterRemoveAsk(name: String) = "Usunąć $name z listy?"
    override val TEST_IPV6 = "Ścieżka IPv6"
    override val AUTO_RECONNECT = "Łącz ponownie automatycznie"
    override val AUTO_RECONNECT_NOTE = "Po zerwaniu połączenia ponawia po 5 s, 30 s i 2 min"
    override val BACKUP_SERVER = "Serwer zapasowy"
    override val BACKUP_OFF = "Wyłączony"
    override val BACKUP_OFF_NOTE = "Nie łącz, jeśli wybrany serwer nie odpowiada"
    override val BACKUP_FASTEST = "Najszybszy"
    override val BACKUP_FASTEST_NOTE = "Najszybszy inny serwer z ostatniego pomiaru"
    override val CONFIRM_OFF = "Pytaj przed rozłączeniem"
    override val CONFIRM_OFF_NOTE = "Przypadkowe dotknięcie kuli nie rozłączy"
    override val LOCK_HIDE = "Ukryj na ekranie blokady"
    override val LOCK_HIDE_NOTE = "Nazwa serwera nie pojawia się w powiadomieniu na ekranie blokady"
    override val QUIET_NOTIF = "Ciche powiadomienie"
    override val QUIET_NOTIF_NOTE = "Bez ikony na pasku stanu, bez dźwięku"
    override val REMEMBER_FILTER = "Zapamiętaj ostatni filtr"
    override val REMEMBER_FILTER_NOTE = "Po otwarciu aplikacji wraca ostatnio wybrany filtr"
    override val AUTO_MEASURE = "Mierz po uruchomieniu"
    override val AUTO_MEASURE_NOTE = "Mierzy automatycznie, jeśli ostatni pomiar ma ponad dobę"
    override val MEASURE_ENC = "Pomiar szyfrowany"
    override val MEASURE_ENC_NOTE = "Mierzy szybkość przez DoT, bliżej realnego użycia"
    override val OPT_SORT = listOf("Domyślnie", "Szybkość", "Nazwa")
    override fun sortA11y(mode: String) = "Sortowanie: $mode"
    override val AUTO_LIGHT = "Automatyczny: jasny motyw"
    override val AUTO_DARK = "Automatyczny: ciemny motyw"
    override val NIGHT_HOURS = "Godziny nocne"
    override val FILTER_ENCRYPTED = "Szyfrowane"
    override val FILTER_UNFILTERED = "Bez filtra"

    override val TEST = "Przetestuj połączenie"
    override val TEST_NOTE = "DNS, DNSSEC i blokowanie reklam"
    override val TESTING = "Testowanie…"
    override val TEST_TITLE = "Test połączenia"
    override val TEST_OK = "DNS działa"
    override val TEST_FAIL = "Brak odpowiedzi"
    override val TEST_SERVER = "Serwer"
    override val TEST_METHOD = "Metoda"
    override val TEST_LATENCY = "Czas odpowiedzi"
    override val TEST_DNSSEC = "Weryfikacja DNSSEC"
    override val TEST_ADS = "Blokowanie reklam"
    override val DNSSEC_YES = "Weryfikuje"
    override val DNSSEC_NO = "Nie weryfikuje"
    override val ADS_YES = "Włączone"
    override val ADS_NO = "Wyłączone"
    override val UNKNOWN = "Nieznane"
    override val TEST_EXPLAIN = "Zapytania wysłano przez tunel, tak jak zrobiłaby to aplikacja; odpowiedzi przyszły z wybranego serwera."
    override val TEST_AGAIN = "Testuj ponownie"

    override val RECOMMEND = "Dobierz mi serwer"
    override val RECOMMEND_NOTE = "Wybierz cel, a połączymy z najszybszym pasującym"
    override val GOAL_SPEED = "Szybkość"
    override val GOAL_SPEED_NOTE = "Najszybszy serwer według Twoich pomiarów"
    override val GOAL_PRIVACY_NOTE = "Bez logów, nastawiony na prywatność"
    override val GOAL_ADS_NOTE = "Blokuje reklamy i trackery"
    override val GOAL_FAMILY_NOTE = "Blokuje treści dla dorosłych"
    override val GOAL_SECURITY_NOTE = "Blokuje szkodliwe strony i phishing"
    override fun recommended(name: String) = "Polecany: $name"

    override val PRIVATE_DNS = "Nazwa prywatnego DNS"
    override val PRIVATE_DNS_NOTE = "Możesz wkleić ją w ustawieniu Prywatny DNS Androida. System użyje wtedy tego serwera bezpośrednio, z pominięciem aplikacji."
    override val CLEAR_HISTORY = "Wyczyść historię pomiarów"
    override val HISTORY_CLEARED = "Wyczyszczono pomiary"

    override val GUARD = "Stała ochrona"
    override val GUARD_NOTE = "Zawsze włączony VPN"
    override val GUARD_BODY = listOf(
        "Gdy aplikacja nie jest połączona (wyłączona, wstrzymana lub po zerwaniu), Twoje zapytania DNS trafiają do serwera dostawcy internetu.",
        "Aby temu zapobiec, włącz dla tej aplikacji „Zawsze włączony VPN” w ustawieniach VPN Androida. Jeśli włączone jest też „Blokuj połączenia bez VPN”, internet nie działa wcale, gdy aplikacja nie jest połączona: nic nie wycieka, ale wstrzymanie oznacza też brak internetu.",
        "Przy zawsze włączonym VPN system sam uruchamia aplikację po włączeniu telefonu i po jej zatrzymaniu.",
    )
    override val GUARD_BUTTON = "Otwórz systemowe ustawienia VPN"
    override val BATTERY = "Ustawienia baterii"
    override val BATTERY_OK = "Bez ograniczeń"
    override val BATTERY_LIMITED = "Może być ograniczana"
    override val BATTERY_BODY = listOf(
        "Android zwykle chroni aplikacje VPN. Mimo to niektórzy producenci (Xiaomi, Huawei, Oppo, Vivo, niektóre wersje Samsunga) mogą zamykać aplikacje w tle, aby oszczędzać baterię.",
        "Jeśli połączenie samo się zrywa, ustaw zużycie baterii tej aplikacji na „Bez ograniczeń” lub „Nie optymalizuj”; na niektórych telefonach zezwól też na „Autostart”.",
    )
    override val BATTERY_BUTTON = "Otwórz ustawienia baterii"

    override val STAT_AVG = "Średni czas odpowiedzi"
    override val STAT_SAVED = "Czas zaoszczędzony (cache)"
    override val STAT_TRAFFIC = "Ruch DNS"
    override val SESSIONS = "Historia połączeń"
    override val SESSIONS_NOTE = "Ostatnie 30 połączeń; nazwy zapytań nie są zapisywane"
    override val SESSIONS_EMPTY = "Brak zapisanych połączeń."
    override val MOST_USED = "Najczęściej używane"
    override val TODAY = "Dziś"
    override val ORB_SHAPE = "Kształt kuli"
    override val ORB_SHAPE_EACH = "Kształt dla motywu"
    override val ORB_SHAPE_NAMES = listOf("Kula", "Trójkąt", "Kwadrat", "Sześciokąt", "Gwiazda", "Ośmiokąt", "Pięciokąt", "Prostokąt", "Odwrócony trójkąt", "Diament", "Kwiat", "Sześcioramienna gwiazda")
    override val SHIELD_WORD = "Tarcza"
    override val LIQUID_COLOR = "Kolor cieczy"
    override val LIQUID_THEME = "Wg motywu"
    override val COLOR_WORD = "Kolor"
    override val LIQUID_NOTE = "Wybrany kolor zastępuje odcień szybkości; prędkość fal nadal zależy od szybkości serwera."
    override val YESTERDAY = "Wczoraj"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Rozłączono ręcznie"
        EndReason.PAUSE -> "Wstrzymano"
        EndReason.SWITCH -> "Zmiana serwera"
        EndReason.DROP -> "Zerwane"
        EndReason.REVOKED -> "Zamknięte przez system"
        EndReason.FAILED -> "Brak odpowiedzi"
        EndReason.NETWORK -> "Zmiana sieci"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · zapytania: $queries"

    override val SOUND_MOTION = "Dźwięk i ruch"
    override val SEC_SOUND = "Dźwięk"
    override val SOUND_ON = "Efekty dźwiękowe"
    override val SOUND_ON_NOTE = "Krótkie, łagodne dźwięki przy dotknięciu i łączeniu. Bez dźwięku, gdy telefon jest wyciszony."
    override val SOUND_UI = "Dźwięki dotyku"
    override val SOUND_UI_NOTE = "Przyciski, przełączniki i zmiany stron"
    override val SOUND_CONN = "Dźwięki połączenia"
    override val SOUND_CONN_NOTE = "Osobne dźwięki przy łączeniu, rozłączaniu i błędach"
    override val SOUND_VOL = "Głośność"
    override val SOUND_PACK = "Pakiet dźwięków"
    override val SOUND_TEST = "Wypróbuj dźwięk połączenia"
    override val QUIET_HOURS = "Godziny ciszy"
    override val QUIET_NOTE = "W tych godzinach bez dźwięku i wibracji"
    override val QUIET_RANGE = "Zakres godzin ciszy"
    override val SEC_MOTION_FX = "Ruch i efekty"
    override val ANIM_SPEED = "Szybkość animacji"
    override val TAP_FX = "Efekt dotyku"
    override val TAP_FX_NOTE = "Mały efekt typowy dla stylu w miejscu dotknięcia"
    override val CELEBRATE = "Świętowanie połączenia"
    override val CELEBRATE_NOTE = "Pokaz typowy dla stylu wokół kuli po połączeniu"
    override val HAPTIC_LEVEL = "Siła wibracji"
    override val REMEMBER_MODS = "Pamiętaj moduły"
    override val REMEMBER_MODS_NOTE = "Po połączeniu Obejście DPI i Reklamy+ włączą się tak, jak je zostawiono"
    override val PROFILES = "Profile"
    override val COPY_STATUS = "Kopiuj podsumowanie stanu"
    override val OPT_PACK = listOf("Auto", "Miękki", "Szkło", "Klasyk")
    override val SOUND_PACK_NOTE = "Auto: dźwięk bieżącego stylu"
    override val PACK_SPACE = "Kosmos"
    override val PACKS_NOTE = "Nowe pakiety (także Liquid Glass) mają własne dźwięki i po dziesięć animacji: dotyk, przełącznik, połączenie, rozłączenie, błąd, gotowe, panel, wstecz, wybór i odświeżanie."
    override val OPT_HAPTIC = listOf("Lekka", "Normalna", "Mocna")
    override val PROFILE_NAMES = listOf("Szybkość", "Prywatność", "Rodzina", "Pełna ochrona")
    override val PROFILE_NOTES = listOf("Najszybszy serwer, duża pamięć podręczna, bez blokowania", "Ścisłe szyfrowanie, blokowanie śledzenia, Reklamy+", "Serwer z filtrem rodzinnym, średnie blokowanie", "Blokowanie reklam i śledzenia, Obejście DPI, Reklamy+")
    override fun profileApplied(name: String) = "Zastosowano profil: $name"

    override val WHATS_NEW = "Co nowego?"
    override val WHATS_NEW_TOAST = "Aplikacja została zaktualizowana"
    override val SHOW = "Pokaż"
    override val WHATS_NEW_ITEMS = listOf(
        "Nowość: efekty dźwiękowe, od nowa napisany płynny silnik animacji, efekty dotyku typowe dla każdego stylu, profile, godziny ciszy i więcej. ☰ > Dźwięk i ruch.",
        "Nowość: przyciski Obejście DPI i Reklamy+. Działają z DNS lub osobno; domyślnie wyłączone.",
        "Nowość: import własnej listy blokad, powiadomienia o połączeniu, zerwaniu i limicie czasu, wykres opóźnień i blokada DNS po zerwaniu.",
        "Nowość: lista pokazuje najpierw 8 serwerów (Pokaż wszystkie / Pokaż mniej), Dodaj własny DNS na górze, cienki pasek przewijania.",
        "Nowość: blokowanie reklam, śledzenia i złośliwego oprogramowania (Wył./Podst./Średni/Ścisły) z własnymi listami. ☰ > Blokowanie. Wszystko w telefonie.",
        "Nowość: styl Frutiger Aurora; Y2K holograficzny, Metro z miastem i muzyką. Wybierz w ☰ > Personalizacja > Styl.",
        "Nowość: IPv4 i IPv6 razem, szybsze wykrywanie awarii; dla prywatności z zapytań usuwane są ślady urządzenia, a długości wiadomości ukrywane.",
        "Nowe: ustawienia podzielone tematycznie. Menu ☰ otwiera Ustawienia DNS, Połączenie i aplikacje, Powiadomienia, Listę serwerów, Statystyki i historię oraz Dane.",
        "Nowość: okno Personalizacja (w menu ☰): język, motyw, styl, tło, ikona, tekst i dostępność.",
        "Nowe: menu ☰ na ekranie głównym i okno O aplikacji (nowości, pomoc, dziennik, udostępnij, wersja).",
        "Poprawka: własne zdjęcie i wbudowane obrazy znów działają jako tło (źle odczytywano rozmiar zdjęcia).",
        "Poprawka: test połączenia odróżnia awarię serwera od telefonu, który nie używa DNS, i wtedy ostrzega.",
        "Poprawka: style Metro, Eco i Y2K narysowane od nowa; zmiana ikony działa po wyjściu z aplikacji.",
        "Nowość: 8 wbudowanych teł (☰ → Personalizacja → Zdjęcie tła → Wbudowane obrazy).",
        "Nowość: rozwiązywanie problemów, wyszukiwanie serwerów, udostępnianie pomiarów, edycja własnych serwerów i opcja bez historii.",
        "Ikona aplikacji: wybierz jedną z pięciu ikon pasujących do pięciu stylów.",
        "Zdjęcie w tle: użyj własnego obrazu jako tła, z regulowaną przysłoną i rozmyciem; tekst zawsze pozostaje czytelny.",
        "Pięć stylów: Aqua (klasyczny), Aero (niebo i trawa), Metro (płaskie kafelki), Eco (natura) i różowy Y2K – każdy z własnymi animacjami i płynniejszymi przejściami.",
        "Wybór aplikacji: stosuj DNS tylko do wybranych aplikacji lub pomiń niektóre.",
        "Dodawanie własnych serwerów DNS (do 8), 10 nowych serwerów i sekcja informacji przy każdym: do czego służy, właściciel, średni ping.",
        "Bezpieczniejsze połączenie: dodatkowa ochrona przed fałszywymi odpowiedziami DNS, ostrzeżenie przy przejściu na zwykły DNS, opcja ścisłego szyfrowania i automatyczny powrót do szyfrowania.",
        "Test połączenia: jednym dotknięciem sprawdzisz, czy DNS odpowiada z wybranego serwera, a także weryfikację DNSSEC i blokowanie reklam.",
        "Serwer zapasowy i automatyczne ponowne łączenie: aplikacja sama sobie radzi, gdy wybrany serwer nie odpowiada lub połączenie się zrywa.",
        "Historia połączeń, najczęściej używane serwery, średni czas odpowiedzi i ruch DNS.",
        "Nowe filtry (Szyfrowane, Bez filtra), sortowanie według nazwy, „Dobierz mi serwer” i pomiar po uruchomieniu.",
        "Liczniki na żywo w powiadomieniu, przycisk pauzy na 15 minut, ukrywanie na ekranie blokady i opcja cichego powiadomienia.",
        "Trzy nowe motywy (Sakura, Miód, Zorza), motyw z tapety oraz wybór jasnego/ciemnego wariantu motywu automatycznego.",
        "Cztery nowe języki: indonezyjski, wietnamski, polski i ukraiński.",
    )
    override fun importedWith(changes: String) = "Wczytano ustawienia · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "osłabiono szyfrowanie"
        SensitiveChange.AUTO_START -> "włączono automatyczne łączenie"
        SensitiveChange.RULES -> "zmieniono reguły serwerów"
        SensitiveChange.PRIVACY -> "złagodzono ustawienia prywatności lub alertów"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · zapytania: $queries · zablokowane: $blocked"
    override val NOTIF_LOCKED = "Ochrona DNS włączona"
    override val NOTIF_QUIET_CHANNEL = "Stan połączenia (cichy)"
    override fun widgetToday(queries: String) = "Zapytania dziś: $queries"
    override fun pauseAction(minutes: Int) = "Wstrzymaj ${minutes(minutes)}"

    override val CUSTOM_NOTE = "Serwer dodany przez Ciebie"
    override val CUSTOM_ADD = "Dodaj własny DNS"
    override val CUSTOM_F_NAME = "Nazwa"
    override val CUSTOM_F_IP1 = "Adres IPv4 (np. 1.2.3.4)"
    override val CUSTOM_F_IP2 = "Drugi adres IPv4 (opcjonalnie)"
    override val CUSTOM_F_DOT = "Nazwa DoT (opcjonalnie)"
    override val CUSTOM_F_DOH = "Adres DoH, https://… (opcjonalnie)"
    override val CUSTOM_SAVE = "Dodaj"
    override val CUSTOM_CANCEL = "Anuluj"
    override val CUSTOM_HINT = "Wypełnij DoT lub DoH, aby połączyć się szyfrowanym łączem; puste pola oznaczają zwykły DNS."
    override val CUSTOM_ERR_NAME = "Nazwa: 1–24 znaki (bez | ; , =)"
    override val CUSTOM_ERR_IP = "Podaj poprawny adres IPv4 (np. 1.2.3.4)"
    override val CUSTOM_ERR_DOT = "Nazwa DoT musi być poprawną nazwą domeny"
    override val CUSTOM_ERR_DOH = "Adres DoH musi zaczynać się od https://"
    override val CUSTOM_ERR_LIMIT = "Można dodać najwyżej 8 własnych serwerów"
    override fun customAdded(name: String) = "Dodano $name"
    override val CUSTOM_DELETE = "Usuń ten serwer"
    override val CUSTOM_IN_USE = "Nie można usunąć podczas połączenia"
    override fun customDeleted(name: String) = "Usunięto $name"
    override val INFO_PURPOSE = "Do czego służy"
    override val INFO_OWNER = "Właściciel"
    override val INFO_AVG = "Średni ping"
    override fun avgPing(ms: Int, n: Int) = "$ms $msU · pomiarów: $n"

    override val APPS = "Aplikacje"
    override val APPS_ALL = "Wszystkie"
    override fun appsOnly(n: Int) = "Tylko wybrane ($n)"
    override fun appsExcept(n: Int) = "Wszystkie oprócz wybranych ($n)"
    override val APPS_MODE = "Które aplikacje używają tego DNS?"
    override val OPT_APPS = listOf("Wszystkie", "Wybrane", "Oprócz wybr.")
    override val APPS_NOTE = "Pozostałe aplikacje używają DNS telefonu. Działa jeden serwer DNS naraz; nie można wybrać innego dla każdej aplikacji."
    override val APPS_LOADING = "Wczytywanie aplikacji…"
    override val APPS_EMPTY = "Nie znaleziono aplikacji"
    override val APPS_NONE_SELECTED = "Nie wybrano aplikacji: ochrona nie ruszy. Wybierz aplikacje lub przełącz na „Wszystkie aplikacje”."
    override val APPS_APPLY = "Zastosuj teraz"
    override val APPS_PENDING = "Zmiana zadziała po odnowieniu połączenia (przerwa na sekundę lub dwie)."

    override val NOTES = mapOf(
        "cloudflare" to "Szybki, dba o prywatność",
        "google" to "Stabilny, popularny",
        "quad9" to "Blokuje szkodliwe domeny",
        "adguard" to "Blokuje reklamy i trackery",
        "controld" to "Bez filtrów, szybki",
        "opendns" to "Cisco, ochrona przed phishingiem",
        "dnssb" to "Dba o prywatność, szybki",
        "dns4eu" to "DNS UE, ochrona przed malware",
        "uncensored" to "Bez filtrów i przekierowań",
        "quad9-open" to "Nic nie blokuje",
        "adguard-open" to "Bez blokad, dba o prywatność",
        "dns4eu-open" to "DNS UE, bez filtrów",
        "controld-ads" to "Reklamy, trackery, malware",
        "dns4eu-ads" to "DNS UE, reklamy i malware",
        "cloudflare-security" to "Blokuje szkodliwe strony",
        "controld-malware" to "Blokuje szkodliwe strony",
        "cleanbrowsing-security" to "Phishing i szkodliwe strony",
        "cloudflare-family" to "Filtr malware i treści 18+",
        "opendns-family" to "Filtr treści dla dorosłych",
        "adguard-family" to "Filtr reklam i treści 18+",
        "cleanbrowsing-family" to "Treści 18+, bezpieczne wyszukiwanie",
        "dns4eu-child" to "DNS UE, ochrona dzieci",
        "controld-family" to "Filtr treści dla dorosłych",
        "nextdns" to "Konfigurowalny filtr, szybki",
        "cira-private" to "Kanada, bez filtrów, prywatność",
        "cira-protected" to "Kanada, blokuje groźne strony",
        "libredns" to "Niezależny, bez filtrów",
        "switch" to "Szwajcaria, blokuje groźne strony",
        "wikimedia" to "DNS Wikimedii, prywatność",
        "digitale" to "Szwajcarska organizacja non-profit",
        "quad101" to "Tajwan, szybki",
        "alidns" to "Chiny, szybki",
    )
}
