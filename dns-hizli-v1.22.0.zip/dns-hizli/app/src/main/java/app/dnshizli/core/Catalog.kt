package app.dnshizli.core

enum class Tag(val id: String) {
    FAST("fast"),
    PRIVACY("privacy"),
    ADS("ads"),
    FAMILY("family"),
    SECURITY("security");

    /** Etkin dildeki adı. */
    val label: String get() = L.tx.tag(this)

    companion object {
        fun byId(id: String?): Tag? = values().firstOrNull { it.id == id }
    }
}

/** Aynı sağlayıcının filtre türü; adın ikinci kısmı olarak etkin dilde gösterilir ("AdGuard Aile"). */
enum class Variant { OPEN, ADS, SECURITY, FAMILY }

/** DNS taşıma yöntemi. */
enum class Proto { PLAIN, DOT, DOH }

/**
 * Kullanıcının şifreleme tercihi.
 *  - AUTO: önce DoT, olmazsa DoH, ikisi de olmazsa (sunucu izin veriyorsa ve "sıkı şifreleme" kapalıysa) düz DNS.
 *  - DOT / DOH: yalnızca o yöntem; sunucu desteklemiyorsa bağlanılmaz.
 *  - OFF: düz DNS; sunucu yalnızca şifreli çalışıyorsa (özel eklenmiş) DoT/DoH kullanılır.
 */
enum class Encryption(val id: String) {
    AUTO("auto"), DOT("dot"), DOH("doh"), OFF("off");

    /**
     * Bu sunucu için sırayla denenecek yöntemler. Boşsa bu tercihle bağlanılamaz.
     * [strict] açıkken AUTO hiçbir zaman şifresiz DNS'e düşmez.
     */
    fun plan(s: DnsServer, strict: Boolean = false): List<Proto> {
        val enc = ArrayList<Proto>(3)
        if (s.dot != null) enc.add(Proto.DOT)
        if (s.doh != null) enc.add(Proto.DOH)
        return when (this) {
            AUTO -> if (s.plain && !strict) enc + Proto.PLAIN else enc
            DOT -> if (s.dot != null) listOf(Proto.DOT) else emptyList()
            DOH -> if (s.doh != null) listOf(Proto.DOH) else emptyList()
            OFF -> if (s.plain) listOf(Proto.PLAIN) else enc
        }
    }
}

class DnsServer(
    val id: String,
    /** Sağlayıcı (marka) adı: çevrilmez. */
    val brand: String,
    val variant: Variant?,
    val primary: String,
    val secondary: String?,
    val tags: Set<Tag>,
    /** DNS-over-TLS sertifika adı (SNI); yoksa DoT desteklenmez. */
    val dot: String? = null,
    /** İkincil adres başka bir sertifika adı kullanıyorsa (ör. UncensoredDNS unicast). */
    val dot2: String? = null,
    /** DNS-over-HTTPS adresi (https://ad/yol); yoksa DoH desteklenmez. */
    val doh: String? = null,
    /** Düz DNS'e (UDP/53) cevap veriyor mu? Yalnızca şifreli çalışan sunucular (özel eklenenler) için false. */
    val plain: Boolean = true,
    /** Sunucuyu işleten kuruluş (özel ad: çevrilmez); özel sunucularda yok. */
    val owner: String? = null,
    /** Kullanıcının kendi eklediği sunucu mu? */
    val custom: Boolean = false,
    /** Birincil / ikincil adresin IPv6 karşılıkları (katalogda); özel sunucularda adresler [primary]/[secondary] içinde olabilir. */
    val primary6: String? = null,
    val secondary6: String? = null,
) {
    /** Düz DNS'in IPv4 ve IPv6 adresleri (özel sunucularda girilen sırayla); [addresses4] ve [addresses6] bunun ailelere göre ayrımıdır. */
    val addresses: List<String> get() = listOfNotNull(primary, secondary)

    /** Tüm IPv4 adresleri: birincil önce. */
    val addresses4: List<String> get() = listOfNotNull(primary, secondary).filter { Ip.isV4(it) }

    /** Tüm IPv6 adresleri: birincil önce (özel sunucuda IPv6 girilmişse o da buradadır). */
    val addresses6: List<String> get() = (listOfNotNull(primary, secondary).filter { Ip.isV6(it) } + listOfNotNull(primary6, secondary6)).distinct()

    /** Görünen ad: marka + (varsa) etkin dilde filtre türü. */
    val name: String get() = if (variant == null) brand else brand + " " + L.tx.variant(variant)

    /** Etkin dildeki kısa açıklama. */
    val note: String get() = if (custom) L.tx.CUSTOM_NOTE else L.tx.note(id)

    val encrypted: Boolean get() = dot != null || doh != null

    /** [index]. adres (0 birincil, 1 ikincil) için TLS sertifika adı. */
    fun tlsHost(proto: Proto, index: Int): String? = when (proto) {
        Proto.DOT -> if (index == 1 && dot2 != null) dot2 else dot
        Proto.DOH -> doh?.let { DohUrl.host(it) }
        Proto.PLAIN -> null
    }
}

/** "https://ad/yol" -> ad ve yol. */
object DohUrl {
    fun host(url: String): String = url.removePrefix("https://").substringBefore('/').substringBefore(':')
    fun path(url: String): String = "/" + url.removePrefix("https://").substringAfter('/', "")
}

/**
 * Uygulamanın bilinen, herkese açık DNS sunucuları. Her sunucu tek satırdır:
 * `tools/catalog_check.py` bu satırları okuyup gerçek sunuculara (düz ve DoT) sorgu atarak adresleri doğrular.
 * Kaynaklar (Ekim 2026): sağlayıcıların kendi sayfaları ve AdGuard'ın DNS sağlayıcıları listesi (bkz. OKUBENI.md).
 */
object Catalog {
    const val DEFAULT_ID = "cloudflare"

    /** Sağlayıcı (marka) -> işleten kuruluş. Özel adlardır, çevrilmez; ülke ISO koduyla. */
    private val OWNERS = mapOf(
        "Cloudflare" to "Cloudflare, Inc. (US)",
        "Google" to "Google LLC (US)",
        "Quad9" to "Quad9 Foundation (CH)",
        "AdGuard" to "AdGuard Software Ltd (CY)",
        "Control D" to "Control D Inc. (CA)",
        "OpenDNS" to "Cisco Systems (US)",
        "DNS.SB" to "DNS.SB",
        "DNS4EU" to "Whalebone + EU consortium (EU)",
        "UncensoredDNS" to "censurfridns.dk (DK)",
        "CleanBrowsing" to "CleanBrowsing (US)",
        "NextDNS" to "NextDNS, Inc. (US)",
        "CIRA Shield" to "CIRA (CA)",
        "LibreDNS" to "LibreDNS (GR)",
        "SWITCH" to "SWITCH Foundation (CH)",
        "Wikimedia" to "Wikimedia Foundation (US)",
        "Digitale Gesellschaft" to "Digitale Gesellschaft (CH)",
        "Quad101" to "TWNIC (TW)",
        "AliDNS" to "Alibaba Cloud (CN)",
    )

    private fun s(
        id: String, brand: String, variant: Variant?, primary: String, secondary: String?, tags: Set<Tag>,
        dot: String? = null, doh: String? = null, dot2: String? = null, plain: Boolean = true,
    ) = DnsServer(id, brand, variant, primary, secondary, tags, dot, dot2, doh, plain, OWNERS[brand], false, V6[id]?.first, V6[id]?.second)

    /**
     * Sunucuların IPv6 adresleri (birincil, ikincil): sağlayıcıların kendi sayfalarından (Ekim 2026). Çift yığınlı ağda
     * şifreli bağlantı önce IPv6'dan denenir, olmazsa IPv4'e geçilir; adres yanlışsa sertifika denetimi bağlantıyı reddeder.
     */
    private val V6: Map<String, Pair<String, String?>> = mapOf(
        "cloudflare" to ("2606:4700:4700::1111" to "2606:4700:4700::1001"),
        "cloudflare-security" to ("2606:4700:4700::1112" to "2606:4700:4700::1002"),
        "cloudflare-family" to ("2606:4700:4700::1113" to "2606:4700:4700::1003"),
        "google" to ("2001:4860:4860::8888" to "2001:4860:4860::8844"),
        "quad9" to ("2620:fe::fe" to "2620:fe::9"),
        "quad9-open" to ("2620:fe::10" to "2620:fe::fe:10"),
        "adguard" to ("2a10:50c0::ad1:ff" to "2a10:50c0::ad2:ff"),
        "adguard-open" to ("2a10:50c0::1:ff" to "2a10:50c0::2:ff"),
        "adguard-family" to ("2a10:50c0::bad1:ff" to "2a10:50c0::bad2:ff"),
        "controld" to ("2606:1a40::" to "2606:1a40:1::"),
        "controld-malware" to ("2606:1a40::1" to "2606:1a40:1::1"),
        "controld-ads" to ("2606:1a40::2" to "2606:1a40:1::2"),
        "controld-family" to ("2606:1a40::4" to "2606:1a40:1::4"),
        "opendns" to ("2620:119:35::35" to "2620:119:53::53"),
        "dnssb" to ("2a09::" to "2a11::"),
        "dns4eu" to ("2a13:1001::86:54:11:1" to "2a13:1001::86:54:11:201"),
        "dns4eu-open" to ("2a13:1001::86:54:11:100" to "2a13:1001::86:54:11:200"),
        "dns4eu-ads" to ("2a13:1001::86:54:11:13" to "2a13:1001::86:54:11:213"),
        "dns4eu-child" to ("2a13:1001::86:54:11:12" to "2a13:1001::86:54:11:212"),
        "cleanbrowsing-security" to ("2a0d:2a00:1::2" to "2a0d:2a00:2::2"),
        "cleanbrowsing-family" to ("2a0d:2a00:1::" to "2a0d:2a00:2::"),
        "uncensored" to ("2001:67c:28a4::" to "2a01:3a0:53:53::"),
        "nextdns" to ("2a07:a8c0::" to "2a07:a8c1::"),
        "cira-private" to ("2620:10a:80bb::10" to "2620:10a:80bc::10"),
        "cira-protected" to ("2620:10a:80bb::20" to "2620:10a:80bc::20"),
        "libredns" to ("2a01:4f8:1c0c:8274::1" to null),
        "switch" to ("2001:620:0:ff::2" to "2001:620:0:ff::3"),
        "wikimedia" to ("2001:67c:930::1" to null),
        "digitale" to ("2a05:fc84::42" to "2a05:fc84::43"),
        "alidns" to ("2400:3200::1" to "2400:3200:baba::1"),
        "opendns-family" to ("2620:119:35::123" to "2620:119:53::123"),
        "quad101" to ("2001:de4::101" to "2001:de4::102"),
    )

    private val FP = setOf(Tag.FAST, Tag.PRIVACY)

    /** Hazır liste. Adresler sağlayıcıların sayfalarından alınmıştır; `tools/catalog_check.py` ile doğrulanır. */
    val builtin: List<DnsServer> = listOf(
        s("cloudflare", "Cloudflare", null, "1.1.1.1", "1.0.0.1", FP, "one.one.one.one", "https://cloudflare-dns.com/dns-query"),
        s("google", "Google", null, "8.8.8.8", "8.8.4.4", setOf(Tag.FAST), "dns.google", "https://dns.google/dns-query"),
        s("quad9", "Quad9", null, "9.9.9.9", "149.112.112.112", setOf(Tag.SECURITY, Tag.PRIVACY), "dns.quad9.net", "https://dns.quad9.net/dns-query"),
        s("adguard", "AdGuard", null, "94.140.14.14", "94.140.15.15", setOf(Tag.ADS, Tag.PRIVACY), "dns.adguard-dns.com", "https://dns.adguard-dns.com/dns-query"),
        s("controld", "Control D", null, "76.76.2.0", "76.76.10.0", FP, "p0.freedns.controld.com", "https://freedns.controld.com/p0"),
        s("opendns", "OpenDNS", null, "208.67.222.222", "208.67.220.220", setOf(Tag.SECURITY), null, "https://doh.opendns.com/dns-query"),
        s("dnssb", "DNS.SB", null, "185.222.222.222", "45.11.45.11", FP, "dot.sb", "https://doh.dns.sb/dns-query"),
        s("dns4eu", "DNS4EU", null, "86.54.11.1", "86.54.11.201", setOf(Tag.SECURITY, Tag.PRIVACY), "protective.joindns4.eu", "https://protective.joindns4.eu/dns-query"),
        s("uncensored", "UncensoredDNS", null, "91.239.100.100", "89.233.43.71", setOf(Tag.PRIVACY), "anycast.censurfridns.dk", null, dot2 = "unicast.censurfridns.dk"),
        s("quad9-open", "Quad9", Variant.OPEN, "9.9.9.10", "149.112.112.10", setOf(Tag.PRIVACY), "dns10.quad9.net", "https://dns10.quad9.net/dns-query"),
        s("adguard-open", "AdGuard", Variant.OPEN, "94.140.14.140", "94.140.14.141", setOf(Tag.PRIVACY), "unfiltered.adguard-dns.com", "https://unfiltered.adguard-dns.com/dns-query"),
        s("dns4eu-open", "DNS4EU", Variant.OPEN, "86.54.11.100", "86.54.11.200", setOf(Tag.PRIVACY), "unfiltered.joindns4.eu", "https://unfiltered.joindns4.eu/dns-query"),
        s("controld-ads", "Control D", Variant.ADS, "76.76.2.2", "76.76.10.2", setOf(Tag.ADS, Tag.SECURITY), "p2.freedns.controld.com", "https://freedns.controld.com/p2"),
        s("dns4eu-ads", "DNS4EU", Variant.ADS, "86.54.11.13", "86.54.11.213", setOf(Tag.ADS, Tag.SECURITY), "noads.joindns4.eu", "https://noads.joindns4.eu/dns-query"),
        s("cloudflare-security", "Cloudflare", Variant.SECURITY, "1.1.1.2", "1.0.0.2", setOf(Tag.SECURITY), "security.cloudflare-dns.com", "https://security.cloudflare-dns.com/dns-query"),
        s("controld-malware", "Control D", Variant.SECURITY, "76.76.2.1", "76.76.10.1", setOf(Tag.SECURITY), "p1.freedns.controld.com", "https://freedns.controld.com/p1"),
        s("cleanbrowsing-security", "CleanBrowsing", Variant.SECURITY, "185.228.168.9", "185.228.169.9", setOf(Tag.SECURITY), "security-filter-dns.cleanbrowsing.org", "https://doh.cleanbrowsing.org/doh/security-filter/"),
        s("cloudflare-family", "Cloudflare", Variant.FAMILY, "1.1.1.3", "1.0.0.3", setOf(Tag.FAMILY, Tag.SECURITY), "family.cloudflare-dns.com", "https://family.cloudflare-dns.com/dns-query"),
        s("opendns-family", "OpenDNS", Variant.FAMILY, "208.67.222.123", "208.67.220.123", setOf(Tag.FAMILY), "familyshield.opendns.com", "https://doh.familyshield.opendns.com/dns-query"),
        s("adguard-family", "AdGuard", Variant.FAMILY, "94.140.14.15", "94.140.15.16", setOf(Tag.FAMILY, Tag.ADS), "family.adguard-dns.com", "https://family.adguard-dns.com/dns-query"),
        s("cleanbrowsing-family", "CleanBrowsing", Variant.FAMILY, "185.228.168.168", "185.228.169.168", setOf(Tag.FAMILY), "family-filter-dns.cleanbrowsing.org", "https://doh.cleanbrowsing.org/doh/family-filter/"),
        s("dns4eu-child", "DNS4EU", Variant.FAMILY, "86.54.11.12", "86.54.11.212", setOf(Tag.FAMILY, Tag.SECURITY), "child.joindns4.eu", "https://child.joindns4.eu/dns-query"),
        s("controld-family", "Control D", Variant.FAMILY, "76.76.2.4", "76.76.10.4", setOf(Tag.FAMILY), "family.freedns.controld.com", "https://freedns.controld.com/family"),
        s("nextdns", "NextDNS", null, "45.90.28.0", "45.90.30.0", FP, "dns.nextdns.io", "https://dns.nextdns.io/dns-query"),
        s("cira-private", "CIRA Shield", Variant.OPEN, "149.112.121.10", "149.112.122.10", setOf(Tag.PRIVACY), "private.canadianshield.cira.ca", "https://private.canadianshield.cira.ca/dns-query"),
        s("cira-protected", "CIRA Shield", Variant.SECURITY, "149.112.121.20", "149.112.122.20", setOf(Tag.SECURITY, Tag.PRIVACY), "protected.canadianshield.cira.ca", "https://protected.canadianshield.cira.ca/dns-query"),
        s("libredns", "LibreDNS", null, "116.202.176.26", null, setOf(Tag.PRIVACY), "dot.libredns.gr", "https://doh.libredns.gr/dns-query"),
        s("switch", "SWITCH", null, "130.59.31.248", "130.59.31.251", setOf(Tag.SECURITY, Tag.PRIVACY), "dns.switch.ch", "https://dns.switch.ch/dns-query"),
        s("wikimedia", "Wikimedia", null, "185.71.138.138", null, setOf(Tag.PRIVACY), "wikimedia-dns.org", "https://wikimedia-dns.org/dns-query"),
        s("digitale", "Digitale Gesellschaft", null, "185.95.218.42", "185.95.218.43", setOf(Tag.PRIVACY), "dns.digitale-gesellschaft.ch", "https://dns.digitale-gesellschaft.ch/dns-query"),
        s("quad101", "Quad101", null, "101.101.101.101", "101.102.103.104", setOf(Tag.FAST), "dns.twnic.tw", "https://dns.twnic.tw/dns-query"),
        s("alidns", "AliDNS", null, "223.5.5.5", "223.6.6.6", setOf(Tag.FAST), "dns.alidns.com", "https://dns.alidns.com/dns-query"),
    )

    @Volatile private var customList: List<DnsServer> = emptyList()

    /** Hazır + kullanıcının eklediği sunucular (önbelleklenir; [setCustom] ile yenilenir). */
    @Volatile var all: List<DnsServer> = builtin
        private set

    val custom: List<DnsServer> get() = customList

    /** Kullanıcının eklediği sunucuları yükler; ayarlar okunurken ([SettingsCodec.decode]) ve eklenip silinirken çağrılır. */
    fun setCustom(list: List<DnsServer>) {
        customList = list
        all = if (list.isEmpty()) builtin else builtin + list
    }

    val default: DnsServer get() = byId(DEFAULT_ID)!!

    fun byId(id: String?): DnsServer? = if (id == null) null else all.firstOrNull { it.id == id }

    /** "a.b.c.d" biçiminde, her parçası 0..255 olan geçerli bir IPv4 adresi mi? */
    fun isIpv4(s: String): Boolean {
        val parts = s.split('.')
        if (parts.size != 4) return false
        return parts.all { p -> p.isNotEmpty() && p.length <= 3 && p.all { it in '0'..'9' } && (p.length == 1 || p[0] != '0') && p.toInt() in 0..255 }   // "01" gibi öndeki sıfırlar (sekizlik belirsizliği) kabul edilmez
    }

    /** Geçerli bir IPv4 ya da IPv6 adresi mi? (Ad çözümlemesi yapmaz.) */
    fun isIp(s: String): Boolean = isIpv4(s) || Ip.isV6(s)
}
