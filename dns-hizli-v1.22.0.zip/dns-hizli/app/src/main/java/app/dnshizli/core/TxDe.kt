package app.dnshizli.core

/** Deutsch. */
object TxDe : Tx() {
    override val lang = Lang.DE

    override val decimalSep = ','
    override val thousand = " Tsd."
    override val million = " Mio."
    override fun percent(n: Int) = "$n %"
    override val dayU = "T."
    override val hourU = "Std."
    override val minU = "Min."
    override val secU = "s"
    override val justNow = "gerade eben"
    override fun ago(span: String) = "vor $span"

    override val OFF = "Nicht verbunden"
    override val CONNECTING = "Verbinde…"
    override val ON = "Verbunden"
    override val ERROR = "Keine Verbindung"
    override val PAUSED = "Pausiert"
    override val HINT_OFF = "Zum Verbinden auf die Kugel tippen"
    override val HINT_CONNECTING = "Das kann einige Sekunden dauern"
    override val HINT_ERROR = "Zum erneuten Versuch tippen"
    override val HINT_PAUSED = "Tippen, um sofort fortzusetzen"
    override val ERR_DEFAULT = "Verbindung fehlgeschlagen"
    override fun selected(name: String) = "$name ausgewählt"
    override fun pausedUntil(time: String) = "Weiter um $time"
    override fun blockedShort(n: String) = "$n blockiert"
    override fun queriesShort(n: String) = "$n Anfragen"
    override fun cacheShort(pct: String) = "$pct Cache"

    override val SERVERS = "Server"
    override val FILTER_ALL = "Alle"
    override val FILTER_FAV = "Favoriten"
    override val FILTER_RECENT = "Zuletzt"
    override val EMPTY_FAV = "Noch keine Favoriten. Tippe auf den Stern eines Servers."
    override val EMPTY_RECENT = "Du hast dich noch mit keinem Server verbunden."
    override val EMPTY_FILTER = "In dieser Kategorie gibt es keine Server."
    override val MEASURE = "Geschwindigkeit messen"
    override val MEASURING = "Messe…"
    override val SORT = "Nach Tempo sortieren"
    override val PULL_TO_MEASURE = "Zum Messen ziehen"
    override val RELEASE_TO_MEASURE = "Loslassen zum Messen"
    override fun serversCount(n: Int) = "$n Server"
    override fun showAllServers(n: Int) = "Alle anzeigen ($n)"
    override val SHOW_LESS = "Weniger anzeigen"
    override val TAG_FAST = "Schnell"
    override val TAG_PRIVACY = "Privatsphäre"
    override val TAG_ADS = "Werbung"
    override val TAG_FAMILY = "Familie"
    override val TAG_SECURITY = "Sicherheit"
    override val VAR_OPEN = "Ungefiltert"
    override val VAR_ADS = "Werbefilter"
    override val VAR_SECURITY = "Sicherheit"
    override val VAR_FAMILY = "Familie"
    override val A11Y_CONNECTED = "verbunden"
    override val A11Y_ENCRYPTED = "verschlüsselt"
    override fun favA11y(name: String) = "$name Favorit"

    override val COPIED = "In die Zwischenablage kopiert"
    override val DISCONNECTED = "Verbindung getrennt"
    override val BACKUP = "Auf Ersatzserver gewechselt"
    override val NO_REPLY = "Kein Server hat geantwortet"
    override val MEASURE_FIRST = "Zuerst Geschwindigkeit messen"
    override val CONNECT = "Verbinden"
    override val UNDO = "Rückgängig"
    override fun fastest(name: String, ms: Int) = "Am schnellsten: $name · $ms ms"
    override fun switched(name: String) = "Wechsle zu $name"
    override fun hiddenToast(name: String) = "$name ausgeblendet"

    override val PRIMARY = "Primär"
    override val SECONDARY = "Sekundär"
    override val COPY = "Kopieren"
    override fun addressA11y(label: String, ip: String) = "$label Adresse: $ip"
    override val CONNECT_TO_THIS = "Mit diesem Server verbinden"
    override val SWITCH_TO_THIS = "Zu diesem Server wechseln"
    override val CONNECTED_NOW = "Jetzt verbunden"
    override val ADD_FAV = "Zu Favoriten"
    override val REMOVE_FAV = "Favorit entfernen"
    override val MEASURE_THIS = "Tempo messen"
    override val HIDE = "In Liste ausblenden"
    override val UNHIDE = "In Liste zeigen"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Letzte Messung: keine Antwort · $ago" else "Letzte Messung: $ms ms · $ago"
    override val NEVER_MEASURED = "Noch nicht gemessen"
    override val ENC_SUPPORT = "Verschlüsseltes DNS"
    override val ENC_NONE = "Nicht unterstützt"
    override val ENC_ONLY = "Nimmt nur verschlüsselte Verbindungen an"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Bestwert $best ms · Median $median ms · Verlust $lossPct %"
    override val HISTORY = "Messverlauf"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: $n Messungen, keine Antwort" else "$HISTORY: $n Messungen, Median $median ms"

    override val QUICK_TITLE = "Schnellwahl"
    override val QUICK_FAVORITES = "Favoriten"
    override val QUICK_RECENT = "Zuletzt verwendet"
    override val PAUSE_FOR = "Pausieren"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} Std." else "$n Min."
    override val RESUME = "Fortsetzen"

    override val SETTINGS = "Einstellungen"
    override val MENU = "Menü"
    override val PERSONALIZE = "Anpassen"
    override val PZ_BACKGROUND = "Hintergrund"
    override val PZ_AUTO = "Automatisches Design"
    override val PZ_FEEL = "Glas, Text und Bewegung"
    override val PZ_ACCESS = "Barrierefreiheit und Energie"
    override val DNS_SETTINGS = "DNS-Einstellungen"
    override val CONN_APPS = "Verbindung & Apps"
    override val STATS_HISTORY = "Statistik & Verlauf"
    override val SEC_LOOK = "Darstellung"
    override val SEC_LIST = "Serverliste"
    override val SEC_DATA = "Daten"
    override val ABOUT = "Über"
    override val LANGUAGE = "Sprache"
    override val LANG_AUTO = "Automatisch (Systemsprache)"
    override val THEME = "Design"
    override val THEME_AUTO = "Automatisch"
    override val THEME_AUTO_NOTE = "Automatisch · folgt hell/dunkel des Systems"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Wiese"
        "ocean" -> "Ozean"
        "sunset" -> "Abendrot"
        "lavender" -> "Lavendel"
        "coral" -> "Koralle"
        "mint" -> "Minze"
        "night" -> "Nacht"
        "amoled" -> "Schwarz (AMOLED)"
        "sakura" -> "Sakura"
        "honey" -> "Honey"
        "aurora" -> "Aurora"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Design: $name"
    override val THEME_SCHEDULE = "Nachtdesign nach Uhrzeit"
    override val THEME_SCHEDULE_NOTE = "Bei Automatisch Nacht von 22:00 bis 07:00"
    override val GLASS = "Glasdeckkraft"
    override val BUBBLES = "Blasen"
    override val STYLE = "Stil"
    override val STYLE_NOTES = listOf(
        "Gläsern, glänzend, mit Blasen: das ursprüngliche Aussehen.",
        "Himmel, grünes Gras, Glastropfen und Gel-Tasten.",
        "Stadt, Musik und Jugend: Hochhäuser, Lautsprecher, Ringe, Sterne und Strahlen.",
        "Natur trifft Technik: grüne Erde, Windräder, Solarpanels und Blätter.",
        "Holografisches Pink und Lila, Chrom-Herzen, Blasen, Funkeln und Pixelfenster.",
        "Türkis, Grün und Gelb, heller Lichtstrahl und durchsichtige Drahtgitter-Wellen.",
        "Durchscheinendes blau-violettes Glas mit hellem weißem Kantenlicht und Lichtbrechung.",
    )
    override val WALLPAPER = "Hintergrundfoto"
    override val WP_OFF = "Keins"
    override val WP_ON = "Foto"
    override val WP_PICK = "Foto aus der Galerie wählen"
    override val WP_PICK_NOTE = "Bleibt auf dem Telefon, wird nie hochgeladen. Der Schleier wird bei Bedarf automatisch stärker, damit Text lesbar bleibt."
    override val WP_PRESETS = "Mitgelieferte Bilder"
    override val WP_PRESETS_NOTE = "8 Bilder, die in der App stecken. Kein Internet nötig."
    override val WP_REMOVE = "Foto entfernen"
    override val WP_DIM = "Schleierstärke"
    override val WP_BLUR = "Unschärfe"
    override val OPT_WP_BLUR = listOf("Aus", "Leicht", "Stark")
    override val WP_SAVED = "Hintergrund gesetzt"
    override val WP_FAILED = "Foto konnte nicht geöffnet werden"
    override val WP_REMOVED = "Hintergrund entfernt"
    override val APP_ICON = "App-Symbol"
    override val ICON_NOTES = listOf(
        "Glaskugel: das ursprüngliche Symbol.",
        "Glastropfen über Himmel und Gras.",
        "Limetten-türkise Stadt mit Sonnenstrahlen und Ein-Aus-Taste.",
        "Glänzende grüne Erde mit sprießendem Blatt.",
        "Glänzendes Chromherz auf holografischem Pink und Lila.",
        "Glaskugel über türkis-gelbem Leuchten und Lichtwellen.",
        "Eine Milchglas-Kugel mit hellem Rand über blau-violettem Licht.",
    )
    override val ICON_SET = "Symbol ändert sich beim Verlassen"
    override val ICON_NOTE = "Verschwindet die Verknüpfung auf dem Startbildschirm, füge die App erneut hinzu."
    override val ICON_FAILED = "Symbol konnte nicht geändert werden"
    override val HELP_WHY_TITLE = "Warum diese App?"
    override val HELP_WHY_BODY = "DNS Hızlı ist klein und schlicht, von einer einzelnen Person gebaut, ohne großes Unternehmen dahinter. Kein Konto, keine Werbung: Du wählst dein DNS, die Verschlüsselung, für welche Apps es gilt und wie es aussieht."
    override val HELP_WHY_TAIL = "Vielleicht ist sie nicht besser als die Konkurrenz, aber sie funktioniert und einen Versuch ist sie wert."
    override val TROUBLE = "Fehlersuche"
    override val TROUBLE_RECHECK = "Erneut prüfen"
    override val TROUBLE_ALL_OK = "Alles sieht gut aus. Verbindet es trotzdem nicht, probiere einen anderen Server."
    override val TROUBLE_SOME = "Das braucht Aufmerksamkeit:"
    override val T_NET = "Internet"
    override val NET_OK = "verbunden."
    override val NET_BAD = "fehlt oder ist eingeschränkt. Prüfe WLAN oder mobile Daten."
    override val T_PERM = "VPN-Berechtigung"
    override val PERM_OK = "erteilt."
    override val PERM_BAD = "noch nicht erteilt. Android fragt beim Verbinden nach; erlaube es."
    override val T_VPN = "Anderes VPN"
    override val VPN_OK = "keines."
    override val VPN_BAD = "scheint aktiv. Android erlaubt nur ein VPN gleichzeitig; schalte es aus."
    override val T_DNS = "Android Privates DNS"
    override val PDNS_OK = "aus oder automatisch, kein Problem."
    override val PDNS_BAD = "ist auf einen Server festgelegt und kann das DNS dieser App umgehen. Wähle unter Einstellungen > Netzwerk > Privates DNS Automatisch oder Aus."
    override val SEARCH = "Suchen"
    override val SEARCH_HINT = "Servername oder Betreiber"
    override val SEARCH_CLEAR = "Löschen"
    override val SHARE_RESULTS = "Messergebnisse teilen"
    override val SHARE_RESULTS_HEAD = "DNS-Hızlı-Messwerte (schnellste zuerst)"
    override val NO_RESULTS = "Miss zuerst einmal"
    override val CUSTOM_EDIT = "Bearbeiten"
    override fun customUpdated(name: String) = "$name aktualisiert"
    override val KEEP_HISTORY = "Verlauf speichern"
    override val KEEP_HISTORY_NOTE = "Wenn aus, werden zuletzt genutzte Server, Verlauf und Messwerte nicht gespeichert. Vorhandenes bleibt."
    override val MOTION = "Animationen"
    override val TEXT_SIZE = "Schriftgröße"
    override val HIGH_CONTRAST = "Hoher Kontrast"
    override val HIGH_CONTRAST_NOTE = "Deckenderes Glas und dunklere Schrift"
    override val MINIMAL = "Schlichte Ansicht"
    override val MINIMAL_NOTE = "Blendet Filter und Statistikzeile aus"
    override val LOW_POWER = "Energiesparmodus"
    override val LOW_POWER_NOTE = "Schaltet alle Bewegungen ab, schont den Akku"
    override val HAPTICS = "Vibration"
    override val HAPTICS_NOTE = "Leichtes Feedback beim Tippen"
    override val ENCRYPTION = "Verschlüsseltes DNS"
    override val ENCRYPTION_NOTE = "Auto: erst DoT, dann DoH, zuletzt einfaches DNS"
    override val AUTO_CONNECT = "Beim App-Start verbinden"
    override val AUTO_CONNECT_NOTE = "Verbindet beim Öffnen mit dem letzten Server"
    override val CONNECT_ON_BOOT = "Beim Gerätestart verbinden"
    override val CONNECT_ON_BOOT_NOTE = "Verbindet nach einem Neustart automatisch"
    override val AUTO_FASTEST = "Mit dem schnellsten verbinden"
    override val AUTO_FASTEST_NOTE = "Die Kugel wählt den schnellsten Server der letzten Messung"
    override val REFRESH_ON_NET = "Bei Netzwechsel erneuern"
    override val REFRESH_ON_NET_NOTE = "DNS wird beim Wechsel zwischen WLAN und Mobilfunk erneuert"
    override val NOTIFY_DROP = "Bei Abbruch benachrichtigen"
    override val NOTIFY_DROP_NOTE = "Hinweis mit Taste zum Neuverbinden bei unerwartetem Abbruch"
    override val NOTIFY_CONNECT = "Bei Verbindung melden"
    override val NOTIFY_CONNECT_NOTE = "Kurzer Hinweis, sobald die Verbindung steht"
    override val NOTIFY_STOP = "Beim Trennen melden"
    override val NOTIFY_STOP_NOTE = "Kurzer Hinweis, wenn du die Verbindung trennst"
    override val NOTIFY_TIMEOUT = "Bei Zeitüberschreitung melden"
    override val NOTIFY_TIMEOUT_NOTE = "Hinweis, wenn der DNS-Server nicht mehr antwortet"
    override val NOTIF_PERM = "System-Benachrichtigungen"
    override val PERM_ALLOWED = "Erlaubt"
    override val PERM_BLOCKED = "Aus · beheben"
    override val NOTIF_CONNECTED_TITLE = "DNS verbunden"
    override val NOTIF_STOPPED_TITLE = "DNS getrennt"
    override val NOTIF_STOPPED_TEXT = "Schutz ist aus"
    override val NOTIF_TIMEOUT_TITLE = "DNS-Zeitüberschreitung"
    override val FAIL_CLOSED = "DNS sperren, wenn getrennt"
    override val FAIL_CLOSED_NOTE = "Bricht die Verbindung ab, gehen DNS-Anfragen nicht an den Anbieter; sie scheitern bis zur Wiederverbindung"
    override val FILTER_MEM = "Filterspeicher"
    override val OPT_FILTER_MEM = listOf("Auto", "Leicht", "Voll")
    override val FILTER_MEM_NOTE = "Auto: bei wenig Speicher ohne große Liste. Leicht: immer ohne. Voll: immer mit"
    override val ERR_NO_APPS = "Keine Apps gewählt, der Schutz wurde nicht gestartet. Apps wählen oder auf „Alle Apps“ wechseln."
    override val NOTIF_SEALED = "DNS gesperrt, verbinde neu"
    override val ERR_SEALED = "Verbindung fehlgeschlagen. DNS ist gesperrt, damit nichts durchsickert. Zum Freigeben auf Trennen tippen."
    override val SEALED_INFO = "DNS ist gesperrt, bis die Verbindung zurück ist"
    override val LATENCY_TITLE = "Latenz pro Anfrage"
    override val LATENCY_EMPTY = "Erscheint live, sobald du verbunden bist und Anfragen kommen"
    override val FILTER_MINE = "Meine eigene Liste"
    override val MINE_PASTE = "Aus Zwischenablage importieren"
    override val MINE_PASTE_NOTE = "hosts-Datei oder eine Domain pro Zeile"
    override val MINE_FILE = "Aus Datei importieren"
    override val MINE_FILE_NOTE = "Eine .txt- oder hosts-Datei auf dem Handy"
    override val MINE_EXPORT = "Meine Sperrliste kopieren"
    override val MINE_EXPORT_NOTE = "Im hosts-Format in die Zwischenablage"
    override val MINE_CLEAR = "Importierte Liste löschen"
    override val MINE_FOOT = "Gelesen werden hosts-Zeilen (0.0.0.0 Domain), einfache Domainlisten und ||domain^-Regeln. Höchstens 50.000 Namen. Deine Erlaubnisliste gilt immer zuerst."
    override val MINE_NOTHING = "Keine gültigen Domains gefunden"
    override val MINE_CLIP_EMPTY = "Zwischenablage ist leer"
    override val MINE_FILE_ERR = "Datei konnte nicht gelesen werden"
    override val MINE_CLEARED = "Importierte Liste gelöscht"
    override val MINE_CLEAR_ASK = "Importierte Liste löschen?"
    override val MINE_CUT = "Grenze erreicht, der Rest wurde ausgelassen"
    override fun notifTimeout(name: String) = "$name antwortet nicht. Neuer Versuch."
    override val MOD_DPI = "DPI-Umgehung"
    override val MOD_ADS = "Werbung+"
    override val MOD_DPI_SUB = "Öffnet gesperrte Seiten"
    override val MOD_ADS_SUB = "Blockt auch ohne DNS"
    override val MOD_ON = "An"
    override val MOD_OFF = "Aus"
    override val BLOCK_QUIC = "QUIC blockieren"
    override val BLOCK_QUIC_NOTE = "Apps wechseln zu TCP, so erfassen DPI-Umgehung und Werbung+ sie ebenfalls"
    override val GW_TRIPPED = "Verbindungsproblem erkannt: DPI-Umgehung und Werbung+ wurden ausgeschaltet"
    override val MOD_FAILED = "Konnte nicht aktiviert werden. VPN-Erlaubnis fehlt oder ein anderes VPN ist aktiv."
    override fun gwOn(modules: String) = "Gateway aktiv: $modules"
    override fun gwOnStats(modules: String, blocked: String) = "Gateway aktiv: $modules · $blocked blockiert"
    override fun modOn(name: String) = "$name eingeschaltet"
    override fun modOff(name: String) = "$name ausgeschaltet"
    override fun modAdsCount(n: String) = "$n blockiert"
    override fun modDpiCount(n: String) = "$n Verbindungen geteilt"
    override fun latencyLine(avg: String, max: String, timeouts: Int) = "Ø $avg · max. $max" + (if (timeouts > 0) " · $timeouts Zeitüberschreitungen" else "")
    override fun mineCount(n: Int) = "$n Domains"
    override fun mineAdded(n: Int) = "$n Domains hinzugefügt"
    override fun mineCopied(n: Int) = "$n Domains kopiert"
    override val CACHE = "DNS-Cache"
    override val CLEAR_CACHE = "Cache leeren"
    override val CACHE_CLEARED = "Cache geleert"
    override val ONLY_CONNECTED = "Nur bei aktiver Verbindung"
    override val RULE_WIFI = "WLAN-Server"
    override val RULE_MOBILE = "Mobilfunk-Server"
    override val RULE_AUTO = "Automatisch"
    override val RULE_AUTO_NOTE = "Zuletzt verwendeter Server"
    override val COMPACT = "Kompakte Liste"
    override val COMPACT_NOTE = "Kürzere Zeilen ohne Beschreibung"
    override val HIDDEN = "Ausgeblendete Server"
    override val HIDDEN_NONE = "Keine"
    override val STAT_QUERIES = "Anfragen gesamt"
    override val STAT_HITS = "Aus dem Cache"
    override val STAT_BLOCKED = "Blockiert (geschätzt)"
    override val STAT_TIME = "Verbunden insgesamt"
    override val WEEK = "Letzte 7 Tage"
    override fun weekA11y(total: String) = "$total Anfragen in den letzten 7 Tagen"
    override val WEEKDAYS = listOf("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")
    override val EXPORT = "Einstellungen exportieren"
    override val IMPORT = "Einstellungen importieren"
    override val EXPORTED = "Einstellungscode kopiert"
    override val IMPORTED = "Einstellungen geladen"
    override val IMPORT_BAD = "Kein gültiger Einstellungscode in der Zwischenablage"
    override val RESET_SETTINGS = "Einstellungen zurücksetzen"
    override val RESET_STATS = "Statistik zurücksetzen"
    override val CONFIRM = "Bist du sicher?"
    override val RESET = "Zurücksetzen"
    override val RESET_DONE = "Zurückgesetzt"
    override val LOG = "Diagnoseprotokoll"
    override val HELP = "Wie funktioniert es?"
    override val VPN_SETTINGS = "System-VPN-Einstellungen"
    override val SHARE_APP = "App teilen"
    override val RATE_APP = "App bewerten"
    override val FEEDBACK = "Feedback senden"
    override fun shareAppText(url: String) = "$APP verbindet dich mit einem Tipp mit bekannten DNS-Servern: $url"
    override val VERSION = "Version"
    override val OPT_BUBBLES = listOf("Aus", "Wenige", "Viele")
    override val OPT_MOTION = listOf("Voll", "Wenig", "Aus")
    override val OPT_CACHE = listOf("Aus", "Klein", "Normal", "Groß")
    override val OPT_ENCRYPTION = listOf("Auto", "DoT", "DoH", "Aus")
    override val PLAIN_DNS = "Einfaches DNS"

    override val LOG_NOTE = "Nur Verbindungsereignisse werden gespeichert. Anfragenamen und persönliche Daten nie."
    override val LOG_EMPTY = "Noch keine Einträge."
    override val SHARE = "Teilen"
    override val CLEAR = "Leeren"
    override val CLEARED = "Geleert"
    override val HELP_SECTIONS = listOf(
        "Was ist DNS?" to
            "DNS ist der Dienst, der Internetadressen (zum Beispiel example.com) in Zahlen übersetzt, die Geräte verstehen. " +
            "Der verwendete DNS kann Tempo, Privatsphäre und blockierte Inhalte beeinflussen.",
        "Was macht die App?" to
            "Sie nutzt den gewählten DNS-Server in allen Apps. Dafür öffnet sie auf dem Telefon eine lokale VPN-Schnittstelle, " +
            "dein Datenverkehr geht aber an keinen VPN-Server. Nur DNS-Anfragen werden an den gewählten Server geleitet, " +
            "alles andere nimmt seinen normalen Weg.",
        "Verschlüsseltes DNS (DoT / DoH)" to
            "Bei Servern, die es unterstützen, werden Anfragen verschlüsselt: Niemand im Netz (WLAN-Betreiber, Mobilfunkanbieter) sieht, " +
            "welche Seiten du aufrufst, oder kann die Antworten verändern. Bei Automatisch wird erst DoT, dann DoH versucht; " +
            "klappt beides nicht, wird einfaches DNS genutzt. Du wirst dann gewarnt, und die App versucht bei jedem Netzwechsel " +
            "und alle 10 Minuten, zur Verschlüsselung zurückzukehren. Mit \"Strikte Verschlüsselung\" wird nie einfaches DNS genutzt. " +
            "Der Startbildschirm zeigt das verwendete Verfahren.",
        "Verbindungstest" to
            "☰ > DNS-Einstellungen > Verbindungstest schickt echte DNS-Anfragen durch den Tunnel. Er zeigt, dass " +
            "DNS wirklich vom gewählten Server antwortet, wie schnell, ob der Server DNSSEC-Signaturen prüft " +
            "und ob er eine bekannte Werbedomain blockiert.",
        "Privatsphäre" to
            "Kein Konto, keine Datensammlung, keine Werbung. Die App speichert keine Anfragenamen und sendet von sich aus nichts. " +
            "Deine Anfragen gehen nur an den gewählten DNS-Anbieter; es gilt dessen Datenschutzerklärung. " +
            "Verschlüsseltes DNS (DoT/DoH) verhindert, dass jemand im Netzwerk deine Anfragen liest oder verändert. Vor dem Senden entfernt die App Zusatzdaten, die dein Gerät verraten könnten (Client-Subnetz, Cookies, Geräte-IDs), polstert Nachrichten auf, um ihre Länge zu verbergen, und verwirft TLS-Sitzungstickets beim Netzwerkwechsel. " +
            "Ehrlich gesagt: ohne Relay sieht der DNS-Anbieter weiterhin deine öffentliche IP-Adresse (er muss dir ja antworten), und ein Zertifikatsfehler kann bedeuten, dass jemand die Verbindung manipuliert. " +
            "Das Diagnoseprotokoll enthält nur Verbindungsereignisse.",
        "Akku und Ressourcen" to
            "Im Hintergrund braucht sie sehr wenig. Bei ausgeschaltetem Bildschirm läuft keine Schleife; " +
            "sie arbeitet nur, wenn eine DNS-Anfrage kommt. Verschlüsselte Verbindungen schließen sich im Leerlauf selbst.",
        "Gut zu wissen" to
            "Android erlaubt nur ein VPN gleichzeitig; ist eine andere VPN-App aktiv, kann diese App nicht verbinden. " +
            "Die Browser-Einstellung \"Sicheres DNS\" und Androids \"Privates DNS\" mit festem Hostnamen nutzen eigene Server " +
            "und umgehen diese Umleitung womöglich; \"Automatisch\" oder \"Aus\" genügt. " +
            "Lange auf die Kugel drücken: schnell zu deinen Servern wechseln oder die Verbindung kurz pausieren.",
    )

    override val NOTIF_CHANNEL = "Verbindungsstatus"
    override val NOTIF_CHANNEL_NOTE = "Wird angezeigt, solange die DNS-Verbindung aktiv ist"
    override val NOTIF_ALERT_CHANNEL = "Verbindungswarnungen"
    override val NOTIF_CONNECTING = "Verbinde…"
    override val NOTIF_STOP = "Trennen"
    override val NOTIF_NEXT = "Nächster"
    override val NOTIF_DROP_TITLE = "DNS-Verbindung unterbrochen"
    override val NOTIF_RECONNECT = "Neu verbinden"
    override fun notifOn(name: String, proto: String) = "Verbunden mit $name · $proto"
    override fun notifPaused(time: String) = "Pausiert · weiter um $time"
    override val TILE_ON = "Verbunden"
    override val TILE_OFF = "Aus"
    override val WIDGET_TAP = "Tippen: verbinden / trennen"
    override val ERR_PERMISSION = "VPN-Berechtigung nicht erteilt"
    override val ERR_ESTABLISH = "VPN-Schnittstelle ließ sich nicht öffnen. Evtl. ist ein anderes VPN aktiv."
    override fun errNoReply(name: String) = "$name hat nicht geantwortet"
    override val PHONE_BYPASS = "Handy nutzt diesen DNS nicht (Privates DNS?)"
    override fun errNoProto(name: String, proto: String) = "$name unterstützt $proto nicht"
    override val ERR_SOCKET = "Netzwerk nicht erreichbar"
    override fun errPrivateDns(host: String) = "Androids privates DNS ist auf $host festgelegt und umgeht die App. Stelle Einstellungen > Netzwerk > Privates DNS auf Automatisch oder Aus."
    override val ERR_REVOKED = "Die Verbindung wurde vom System beendet"
    override val ERR_TUNNEL = "Der Tunnel wurde unerwartet geschlossen"
    override val ERR_UNKNOWN = "Ein unerwarteter Fehler ist aufgetreten"

    override val CONSENT_TITLE = "Bevor du dich verbindest"
    override val CONSENT_BODY = listOf(
        "$APP nutzt die VPN-Schnittstelle von Android, um deine DNS-Anfragen (die Namen der besuchten Seiten) an den gewählten DNS-Server zu leiten.",
        "Dein Datenverkehr geht an keinen VPN-Server; nur DNS-Anfragen gehen an den gewählten Anbieter. Bei unterstützten Servern " +
            "werden sie verschlüsselt (DoT/DoH), sonst unverschlüsselt gesendet. Es gilt die Datenschutzerklärung des Anbieters." +
            " Schaltest du „$MOD_DPI“ oder „$MOD_ADS“ ein, läuft der gesamte Datenverkehr durch ein Relais, das nur in deinem Telefon arbeitet; er wird trotzdem nirgendwohin sonst gesendet.",
        "Die App sammelt keine persönlichen Daten, speichert keine Anfragenamen und teilt nichts.",
        "Wenn du fortfährst, zeigt Android eine VPN-Verbindungsanfrage; tippe dort auf \"OK\".",
    )
    override val CONSENT_OK = "Verstanden, weiter"
    override val CLOSE = "Schließen"
    override val BACK = "Zurück"

    // ---- 3. sürüm ----
    override val RESUMING = "Wird fortgesetzt…"
    override val DOWNGRADED = "Keine Verschlüsselung möglich, einfaches DNS"
    override val UPGRADED = "Wieder verschlüsseltes DNS"
    override val NOTIF_DOWNGRADE_TITLE = "DNS ist nicht verschlüsselt"
    override fun notifDowngrade(name: String) = "Keine verschlüsselte Verbindung zu $name möglich. Einfaches DNS ist aktiv; die App versucht, zur Verschlüsselung zurückzukehren."
    override fun backupUsed(failed: String, used: String) = "$failed antwortet nicht, verbunden mit $used"
    override val NOTIF_RETRYING = "Verbindung verloren, neuer Versuch…"
    override fun errNoEncrypted(name: String) = "Keine verschlüsselte Verbindung zu $name möglich"
    override fun errUntrusted(name: String) = "Zertifikat von $name nicht verifizierbar; Netzwerk oder Software greift womöglich in verschlüsselte Verbindungen ein"
    override val APPLYING = "Neue Einstellung wird übernommen"
    override val CONFIRM_DISCONNECT = "Verbindung trennen?"
    override val DISCONNECT = "Trennen"

    override val SEC_NOTIF = "Benachrichtigungen"
    override val STRICT_ENC = "Strikte Verschlüsselung"
    override val STRICT_ENC_NOTE = "Nie auf einfaches DNS zurückfallen"
    override val IP_MODE = "IP-Version"
    override val IP_MODE_NOTE = "Was dein Netz bietet, wird zuerst versucht; das andere ist die Reserve"
    override val OPT_IP_MODE = listOf("IPv4 + IPv6", "Nur IPv4")
    override val FILTER = "Blockieren"
    override val FILTER_LEVEL = "Werbe- und Trackerblockade"
    override val OPT_FILTER = listOf(
        "Aus",
        "Basis",
        "Mittel",
        "Streng",
    )
    override val FILTER_NOTES = listOf(
        "Nichts wird blockiert.",
        "Bekannte Werbe-, Phishing- und Malware-Seiten. Sehr geringes Risiko für Störungen.",
        "Basis plus mehr Tracker und Analysen. Manche Seiten können Probleme machen.",
        "Die größte Liste, auch Betrug, Missbrauch und Weiterleitungen. Häufige Störungen.",
    )
    override val FILTER_INFO = "Das Blockieren geschieht komplett auf dem Handy: Wird eine gelistete Seite abgefragt, kommt die Antwort NXDOMAIN, die Anfrage geht an keinen Server und es wird kein Name gespeichert. Nur während der Verbindung aktiv. Die eigene sichere DNS-Einstellung eines Browsers kann es umgehen. Geht eine Seite kaputt, erlauben Sie sie unter Zuletzt blockiert."
    override val FILTER_LAST = "Zuletzt blockiert"
    override val FILTER_RECENT_NOTE = "Tippen: erlauben"
    override val FILTER_RECENT_EMPTY = "In dieser Sitzung nichts blockiert. Namen erscheinen hier, solange verbunden und eine Stufe aktiv ist."
    override val FILTER_RECENT_FOOT = "Nur für diese Sitzung im Speicher; wird nie gespeichert und beim Trennen gelöscht."
    override val FILTER_ALLOW = "Erlaubt"
    override val FILTER_BLOCK = "Meine Sperrliste"
    override val FILTER_ADD = "Hinzufügen…"
    override val FILTER_REMOVE = "Tippen: entfernen"
    override val FILTER_ALLOW_ADD = "Domain erlauben"
    override val FILTER_BLOCK_ADD = "Domain blockieren"
    override val FILTER_ERR = "Gültige Domain eingeben, z. B. beispiel.de"
    override val FILTER_ERR_LIMIT = "Höchstens 200 Domains"
    override val FILTER_ALLOW_EMPTY = "Keine erlaubten Domains. Geht eine Seite kaputt, fügen Sie sie hier hinzu."
    override val FILTER_BLOCK_EMPTY = "Ihre eigene Sperrliste ist leer."
    override val FILTER_ALLOW_FOOT = "Die Domain und alle Subdomains werden nie blockiert. Erlauben schlägt jede Liste und Ihre Sperrliste."
    override val FILTER_BLOCK_FOOT = "Die Domain und alle Subdomains werden immer blockiert (auch bei Stufe Aus)."
    override val FILTER_REMOVE_BTN = "Entfernen"
    override fun filterAllowed(name: String) = "$name ist jetzt erlaubt"
    override fun filterBlocked(name: String) = "$name wird blockiert"
    override fun filterRemoved(name: String) = "$name entfernt"
    override fun filterRemoveAsk(name: String) = "$name aus der Liste entfernen?"
    override val TEST_IPV6 = "IPv6-Weg"
    override val AUTO_RECONNECT = "Automatisch neu verbinden"
    override val AUTO_RECONNECT_NOTE = "Bei Abbruch neuer Versuch nach 5 s, 30 s und 2 Min."
    override val BACKUP_SERVER = "Ersatzserver"
    override val BACKUP_OFF = "Aus"
    override val BACKUP_OFF_NOTE = "Nicht verbinden, wenn der gewählte Server nicht antwortet"
    override val BACKUP_FASTEST = "Schnellster"
    override val BACKUP_FASTEST_NOTE = "Der schnellste andere Server der letzten Messung"
    override val CONFIRM_OFF = "Vor dem Trennen fragen"
    override val CONFIRM_OFF_NOTE = "Ein versehentlicher Tipp auf die Kugel trennt nicht"
    override val LOCK_HIDE = "Im Sperrbildschirm verbergen"
    override val LOCK_HIDE_NOTE = "Kein Servername in der Benachrichtigung auf dem Sperrbildschirm"
    override val QUIET_NOTIF = "Dezente Benachrichtigung"
    override val QUIET_NOTIF_NOTE = "Ohne Symbol in der Statusleiste, lautlos"
    override val REMEMBER_FILTER = "Letzten Filter merken"
    override val REMEMBER_FILTER_NOTE = "Beim Öffnen der App gilt wieder der zuletzt gewählte Filter"
    override val AUTO_MEASURE = "Beim Start messen"
    override val AUTO_MEASURE_NOTE = "Misst automatisch, wenn die letzte Messung über einen Tag alt ist"
    override val MEASURE_ENC = "Verschlüsselt messen"
    override val MEASURE_ENC_NOTE = "Misst über DoT, näher an echter verschlüsselter Nutzung"
    override val OPT_SORT = listOf("Standard", "Tempo", "Name")
    override fun sortA11y(mode: String) = "Sortierung: $mode"
    override val AUTO_LIGHT = "Automatisch: helles Design"
    override val AUTO_DARK = "Automatisch: dunkles Design"
    override val NIGHT_HOURS = "Nachtstunden"
    override val FILTER_ENCRYPTED = "Verschlüsselt"
    override val FILTER_UNFILTERED = "Ungefiltert"

    override val TEST = "Verbindung testen"
    override val TEST_NOTE = "DNS, DNSSEC und Werbefilter"
    override val TESTING = "Teste…"
    override val TEST_TITLE = "Verbindungstest"
    override val TEST_OK = "DNS funktioniert"
    override val TEST_FAIL = "Keine Antwort"
    override val TEST_SERVER = "Server"
    override val TEST_METHOD = "Verfahren"
    override val TEST_LATENCY = "Antwortzeit"
    override val TEST_DNSSEC = "DNSSEC-Prüfung"
    override val TEST_ADS = "Werbefilter"
    override val DNSSEC_YES = "Aktiv"
    override val DNSSEC_NO = "Nicht aktiv"
    override val ADS_YES = "Aktiv"
    override val ADS_NO = "Nicht aktiv"
    override val UNKNOWN = "Unbekannt"
    override val TEST_EXPLAIN = "Die Anfragen liefen wie bei einer App durch den Tunnel; die Antworten kamen von deinem gewählten Server."
    override val TEST_AGAIN = "Erneut testen"

    override val RECOMMEND = "Passenden Server finden"
    override val RECOMMEND_NOTE = "Wähle dein Ziel, wir verbinden mit dem schnellsten passenden Server"
    override val GOAL_SPEED = "Tempo"
    override val GOAL_SPEED_NOTE = "Der schnellste Server laut deinen Messungen"
    override val GOAL_PRIVACY_NOTE = "Keine Logs, datenschutzfreundlich"
    override val GOAL_ADS_NOTE = "Blockiert Werbung und Tracker"
    override val GOAL_FAMILY_NOTE = "Blockiert Inhalte ab 18"
    override val GOAL_SECURITY_NOTE = "Blockiert schädliche und Phishing-Seiten"
    override fun recommended(name: String) = "Empfohlen: $name"

    override val PRIVATE_DNS = "Name für privates DNS"
    override val PRIVATE_DNS_NOTE = "Du kannst ihn in Androids Einstellung \"Privates DNS\" einfügen. Dann nutzt das System diesen Server direkt und diese App wird umgangen."
    override val CLEAR_HISTORY = "Messverlauf löschen"
    override val HISTORY_CLEARED = "Messungen gelöscht"

    override val GUARD = "Dauerhafter Schutz"
    override val GUARD_NOTE = "Durchgehend aktives VPN"
    override val GUARD_BODY = listOf(
        "Solange die App nicht verbunden ist (ausgeschaltet, pausiert oder nach einem Abbruch), gehen deine DNS-Anfragen an den Server deines Internetanbieters.",
        "Um das zu verhindern, aktiviere für diese App in Androids VPN-Einstellungen \"Durchgehend aktives VPN\". Ist auch \"Verbindungen ohne VPN blockieren\" an, funktioniert das Internet gar nicht, solange die App nicht verbunden ist: Nichts gelangt nach außen, aber Pausieren heißt dann auch kein Internet.",
        "Mit durchgehend aktivem VPN startet das System die App automatisch beim Hochfahren des Telefons und nachdem sie beendet wurde.",
    )
    override val GUARD_BUTTON = "System-VPN-Einstellungen öffnen"
    override val BATTERY = "Akku-Einstellungen"
    override val BATTERY_OK = "Nicht eingeschränkt"
    override val BATTERY_LIMITED = "Evtl. eingeschränkt"
    override val BATTERY_BODY = listOf(
        "Android schützt VPN-Apps normalerweise. Manche Hersteller (Xiaomi, Huawei, Oppo, Vivo, einige Samsung-Versionen) beenden aber Hintergrund-Apps, um Akku zu sparen.",
        "Bricht die Verbindung immer wieder von selbst ab, stelle die Akkunutzung dieser App auf \"Nicht eingeschränkt\" oder \"Nicht optimiert\"; erlaube auf manchen Telefonen auch \"Autostart\".",
    )
    override val BATTERY_BUTTON = "Akku-Einstellungen öffnen"

    override val STAT_AVG = "Mittlere Antwortzeit"
    override val STAT_SAVED = "Zeitersparnis durch Cache"
    override val STAT_TRAFFIC = "DNS-Datenverkehr"
    override val SESSIONS = "Verbindungsverlauf"
    override val SESSIONS_NOTE = "Letzte 30 Verbindungen; Anfragenamen werden nie gespeichert"
    override val SESSIONS_EMPTY = "Noch keine Verbindungen aufgezeichnet."
    override val MOST_USED = "Am häufigsten genutzt"
    override val TODAY = "Heute"
    override val ORB_SHAPE = "Kugelform"
    override val ORB_SHAPE_EACH = "Form je Design"
    override val ORB_SHAPE_NAMES = listOf("Kugel", "Dreieck", "Quadrat", "Sechseck", "Stern", "Achteck", "Fünfeck", "Rechteck", "Umgekehrtes Dreieck", "Diamant", "Blume", "Sechszackiger Stern")
    override val SHIELD_WORD = "Schild"
    override val LIQUID_COLOR = "Flüssigkeitsfarbe"
    override val LIQUID_THEME = "Wie Design"
    override val COLOR_WORD = "Farbe"
    override val LIQUID_NOTE = "Eine gewählte Farbe ersetzt den Tempo-Farbton; die Wellengeschwindigkeit folgt weiter dem Servertempo."
    override val YESTERDAY = "Gestern"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Von dir getrennt"
        EndReason.PAUSE -> "Pausiert"
        EndReason.SWITCH -> "Server gewechselt"
        EndReason.DROP -> "Abgebrochen"
        EndReason.REVOKED -> "Vom System beendet"
        EndReason.FAILED -> "Keine Antwort"
        EndReason.NETWORK -> "Netz gewechselt"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries Anfragen"

    override val SOUND_MOTION = "Ton und Bewegung"
    override val SEC_SOUND = "Ton"
    override val SOUND_ON = "Soundeffekte"
    override val SOUND_ON_NOTE = "Kurze, leise Töne beim Tippen und Verbinden. Stumm, wenn das Handy stummgeschaltet ist."
    override val SOUND_UI = "Tipptöne"
    override val SOUND_UI_NOTE = "Schaltflächen, Schalter und Seitenwechsel"
    override val SOUND_CONN = "Verbindungstöne"
    override val SOUND_CONN_NOTE = "Eigene Töne für Verbinden, Trennen und Fehler"
    override val SOUND_VOL = "Lautstärke"
    override val SOUND_PACK = "Klangpaket"
    override val SOUND_TEST = "Verbindungston testen"
    override val QUIET_HOURS = "Ruhezeiten"
    override val QUIET_NOTE = "In diesem Zeitraum keine Töne und keine Vibration"
    override val QUIET_RANGE = "Ruhezeit-Bereich"
    override val SEC_MOTION_FX = "Bewegung und Effekte"
    override val ANIM_SPEED = "Animationstempo"
    override val TAP_FX = "Tippeffekt"
    override val TAP_FX_NOTE = "Ein kleiner, stiltypischer Effekt an der berührten Stelle"
    override val CELEBRATE = "Verbindungs-Feier"
    override val CELEBRATE_NOTE = "Eine stiltypische Show um die Kugel, sobald verbunden"
    override val HAPTIC_LEVEL = "Vibrationsstärke"
    override val REMEMBER_MODS = "Module merken"
    override val REMEMBER_MODS_NOTE = "Beim Verbinden gehen DPI-Umgehung und Werbung+ so an, wie du sie zuletzt gelassen hast"
    override val PROFILES = "Profile"
    override val COPY_STATUS = "Statusübersicht kopieren"
    override val OPT_PACK = listOf("Auto", "Weich", "Glas", "Klassik")
    override val SOUND_PACK_NOTE = "Auto: der Klang deines aktuellen Stils"
    override val PACK_SPACE = "Weltraum"
    override val PACKS_NOTE = "Die neuen Pakete (auch Liquid Glass) bringen eigene Klänge und je zehn Animationen mit: Tippen, Schalter, Verbinden, Trennen, Fehler, Fertig, Panel, Zurück, Auswahl und Aktualisieren."
    override val OPT_HAPTIC = listOf("Leicht", "Normal", "Stark")
    override val PROFILE_NAMES = listOf("Tempo", "Privatsphäre", "Familie", "Vollschutz")
    override val PROFILE_NOTES = listOf("Schnellster Server, großer Cache, keine Blockierung", "Strenge Verschlüsselung, Tracker-Blockierung, Werbung+", "Server mit Familienfilter, mittlere Blockierung", "Werbe- und Tracker-Blockierung, DPI-Umgehung, Werbung+")
    override fun profileApplied(name: String) = "Profil angewendet: $name"

    override val WHATS_NEW = "Was ist neu?"
    override val WHATS_NEW_TOAST = "Die App wurde aktualisiert"
    override val SHOW = "Anzeigen"
    override val WHATS_NEW_ITEMS = listOf(
        "Neu: Soundeffekte, eine neu geschriebene flüssige Animations-Engine, stiltypische Tippeffekte, Profile, Ruhezeiten und mehr. ☰ > Ton und Bewegung.",
        "Neu: Tasten für DPI-Umgehung und Werbung+. Sie laufen mit DNS oder allein; beide sind standardmäßig aus.",
        "Neu: eigene Sperrliste importieren, Hinweise bei Verbindung, Abbruch und Zeitüberschreitung, Latenz-Diagramm und DNS-Sperre bei Abbruch.",
        "Neu: Serverliste zeigt zuerst 8 (Alle anzeigen / Weniger anzeigen), Eigenen DNS hinzufügen oben, dünne Bildlaufleiste.",
        "Neu: Werbe-, Tracker- und Schadsoftware-Blocker (Aus/Basis/Mittel/Streng) mit Erlaubt- und eigener Sperrliste. ☰ > Blockieren. Alles lokal.",
        "Neu: Stil Frutiger Aurora; Y2K jetzt holografisch, Metro mit Stadt und Musik. Wählen unter ☰ > Anpassen > Stil.",
        "Neu: IPv4 und IPv6 zusammen, schnellere Fehlererkennung; für mehr Privatsphäre werden Geräte-Spuren entfernt und Nachrichtenlängen verborgen.",
        "Neu: Einstellungen nach Themen getrennt. Im ☰-Menü: DNS, Verbindung und Apps, Benachrichtigungen, Serverliste, Statistik und Verlauf, Daten.",
        "Neu: Fenster „Anpassen“ (im ☰-Menü): Sprache, Design, Stil, Hintergrund, Symbol, Text und Barrierefreiheit.",
        "Neu: ☰-Menü auf dem Startbildschirm und ein neues Fenster „Über“ (Neuigkeiten, Hilfe, Protokoll, Teilen, Version).",
        "Fix: Eigenes Foto oder mitgeliefertes Bild als Hintergrund funktioniert wieder (Bildgröße wurde falsch gelesen).",
        "Fix: Der Verbindungstest trennt Serverprobleme von einem Telefon, das den DNS nicht nutzt, und warnt im zweiten Fall.",
        "Korrektur: Metro-, Eco- und Y2K-Stil neu gezeichnet; der Symbolwechsel gilt jetzt beim Verlassen der App.",
        "Neu: 8 mitgelieferte Hintergrundbilder (☰ → Anpassen → Hintergrundfoto → Mitgelieferte Bilder).",
        "Neu: Fehlersuche, Serversuche, Messergebnisse teilen, eigene Server bearbeiten und Verlauf nicht speichern.",
        "App-Symbol: Wähle eines von fünf Symbolen, passend zu den fünf Stilen.",
        "Hintergrundfoto: eigenes Bild als Hintergrund, mit einstellbarem Schleier und Unschärfe; der Text bleibt immer lesbar.",
        "Fünf Stile: Aqua (klassisch), Aero (Himmel und Gras), Metro (flache Kacheln), Eco (Natur) und rosa Y2K – jeweils mit eigenen Animationen und weicheren Übergängen.",
        "App-Auswahl: DNS nur für gewählte Apps nutzen oder einzelne Apps ausnehmen.",
        "Eigene DNS-Server hinzufügen (bis zu 8), 10 neue Server und ein Infobereich pro Server: wofür er gut ist, Betreiber, durchschnittlicher Ping.",
        "Sicherere Verbindung: zusätzliche Prüfungen gegen gefälschte DNS-Antworten, eine Warnung beim Rückfall auf einfaches DNS, strikte Verschlüsselung als Option und automatische Rückkehr zur Verschlüsselung.",
        "Verbindungstest: Prüfe mit einem Tipp, ob DNS wirklich von deinem gewählten Server antwortet, dazu DNSSEC-Prüfung und Werbefilter.",
        "Ersatzserver und automatisches Neuverbinden: Die App fängt sich selbst, wenn der gewählte Server nicht antwortet oder die Verbindung abbricht.",
        "Verbindungsverlauf, meistgenutzte Server, mittlere Antwortzeit und DNS-Datenverkehr.",
        "Neue Filter (Verschlüsselt, Ungefiltert), Sortieren nach Name, \"Passenden Server finden\" und Messen beim Start.",
        "Live-Zähler in der Benachrichtigung, eine Pausetaste für 15 Minuten, Verbergen im Sperrbildschirm und eine dezente Benachrichtigung.",
        "Drei neue Designs (Sakura, Honig, Polarlicht), ein Design aus deinem Hintergrundbild und Hell/Dunkel-Wahl für das automatische Design.",
        "Vier neue Sprachen: Indonesisch, Vietnamesisch, Polnisch und Ukrainisch.",
    )
    override fun importedWith(changes: String) = "Einstellungen geladen · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "Verschlüsselung abgeschwächt"
        SensitiveChange.AUTO_START -> "automatisches Verbinden aktiviert"
        SensitiveChange.RULES -> "Serverregeln geändert"
        SensitiveChange.PRIVACY -> "Datenschutz- oder Warneinstellungen gelockert"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries Anfragen · $blocked blockiert"
    override val NOTIF_LOCKED = "DNS-Schutz ist aktiv"
    override val NOTIF_QUIET_CHANNEL = "Verbindungsstatus (dezent)"
    override fun widgetToday(queries: String) = "Heute $queries Anfragen"
    override fun pauseAction(minutes: Int) = "${minutes(minutes)} pausieren"


    override val CUSTOM_NOTE = "Von dir hinzugefügter Server"
    override val CUSTOM_ADD = "Eigenen DNS hinzufügen"
    override val CUSTOM_F_NAME = "Name"
    override val CUSTOM_F_IP1 = "IPv4-Adresse (z. B. 1.2.3.4)"
    override val CUSTOM_F_IP2 = "Zweite IPv4-Adresse (optional)"
    override val CUSTOM_F_DOT = "DoT-Name (optional)"
    override val CUSTOM_F_DOH = "DoH-Adresse, https://… (optional)"
    override val CUSTOM_SAVE = "Hinzufügen"
    override val CUSTOM_CANCEL = "Abbrechen"
    override val CUSTOM_HINT = "Für eine verschlüsselte Verbindung DoT oder DoH ausfüllen; sonst wird unverschlüsseltes DNS genutzt."
    override val CUSTOM_ERR_NAME = "Name: 1–24 Zeichen (ohne | ; , =)"
    override val CUSTOM_ERR_IP = "Gültige IPv4-Adresse eingeben (z. B. 1.2.3.4)"
    override val CUSTOM_ERR_DOT = "DoT-Name muss ein gültiger Domainname sein"
    override val CUSTOM_ERR_DOH = "DoH-Adresse muss mit https:// beginnen"
    override val CUSTOM_ERR_LIMIT = "Es sind höchstens 8 eigene Server möglich"
    override fun customAdded(name: String) = "$name hinzugefügt"
    override val CUSTOM_DELETE = "Diesen Server löschen"
    override val CUSTOM_IN_USE = "Während der Verbindung nicht löschbar"
    override fun customDeleted(name: String) = "$name gelöscht"
    override val INFO_PURPOSE = "Wofür er gut ist"
    override val INFO_OWNER = "Betreiber"
    override val INFO_AVG = "Durchschnittlicher Ping"
    override fun avgPing(ms: Int, n: Int) = "$ms $msU · $n Messungen"

    override val APPS = "Apps"
    override val APPS_ALL = "Alle Apps"
    override fun appsOnly(n: Int) = "Nur ausgewählte ($n)"
    override fun appsExcept(n: Int) = "Alle außer ausgewählten ($n)"
    override val APPS_MODE = "Für welche Apps gilt dieser DNS?"
    override val OPT_APPS = listOf("Alle", "Nur gewählte", "Alle außer gewählten")
    override val APPS_NOTE = "Nicht erfasste Apps nutzen den DNS des Telefons. Es läuft immer nur ein DNS-Server; pro App kann kein anderer gewählt werden."
    override val APPS_LOADING = "Apps werden geladen…"
    override val APPS_EMPTY = "Keine Apps gefunden"
    override val APPS_NONE_SELECTED = "Keine Apps gewählt: Der Schutz startet nicht. Apps wählen oder auf „Alle Apps“ wechseln."
    override val APPS_APPLY = "Jetzt anwenden"
    override val APPS_PENDING = "Die Änderung gilt nach dem Erneuern der Verbindung (kurze Unterbrechung)."

    override val NOTES = mapOf(
        "cloudflare" to "Schnell, datenschutzfreundlich",
        "google" to "Stabil, weit verbreitet",
        "quad9" to "Blockiert schädliche Domains",
        "adguard" to "Blockiert Werbung und Tracker",
        "controld" to "Ungefiltert, schnell",
        "opendns" to "Cisco, Phishing-Schutz",
        "dnssb" to "Datenschutzfreundlich, schnell",
        "dns4eu" to "DNS der EU, Malware-Schutz",
        "uncensored" to "Keine Filter, keine Umleitung",
        "quad9-open" to "Blockiert nichts",
        "adguard-open" to "Keine Sperren, datenschutzfreundlich",
        "dns4eu-open" to "DNS der EU, ungefiltert",
        "controld-ads" to "Werbung, Tracker, Malware",
        "dns4eu-ads" to "DNS der EU, Werbung und Malware",
        "cloudflare-security" to "Blockiert schädliche Seiten",
        "controld-malware" to "Blockiert schädliche Seiten",
        "cleanbrowsing-security" to "Phishing und schädliche Seiten",
        "cloudflare-family" to "Filter für Malware und Erotik",
        "opendns-family" to "Filter für Inhalte ab 18",
        "adguard-family" to "Filter für Werbung und Inhalte ab 18",
        "cleanbrowsing-family" to "Inhalte ab 18, sichere Suche",
        "dns4eu-child" to "DNS der EU, Jugendschutz",
        "controld-family" to "Filter für Inhalte ab 18",
        "nextdns" to "Einstellbarer Filter, schnell",
        "cira-private" to "Kanada, ungefiltert, Datenschutz",
        "cira-protected" to "Kanada, blockiert schädliche Seiten",
        "libredns" to "Unabhängig, ungefiltert",
        "switch" to "Schweiz, blockiert schädliche Seiten",
        "wikimedia" to "DNS von Wikimedia, Datenschutz",
        "digitale" to "Schweizer Non-Profit, ungefiltert",
        "quad101" to "Taiwan, schnell",
        "alidns" to "China, schnell",
    )
}
