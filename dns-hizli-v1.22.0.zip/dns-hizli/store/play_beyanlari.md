# Play Console beyanları — hazır cevap taslakları (v1.9.11)

Hukuki tavsiye değildir. Formlardaki seçimler **senin** beyanındır; Play Console'daki güncel soru metni esastır. Aşağıdakiler
uygulamanın gerçekte yaptığına göre yazıldı. Emin olmadığın yerde olduğu gibi anlat, abartma.

## 1) Veri güvenliği formu

Uygulama kendi sunucusuna veri **göndermez**, analitik/reklam SDK'sı yok. Tek veri hareketi: DNS sorguları (alan adları), senin
seçtiğin DNS sağlayıcısına gider (varsayılan olarak DoT/DoH ile şifreli).

| Soru | Önerilen cevap | Not |
|---|---|---|
| Uygulama kullanıcı verisi **topluyor** mu? | Hayır (geliştirici olarak toplamıyor, saklamıyor) | Sorgular geliştiriciye gelmez. |
| Uygulama kullanıcı verisi **paylaşıyor** mu? | Değerlendir: DNS sorguları kullanıcının seçtiği üçüncü taraf sağlayıcıya iletiliyor | Play'in "paylaşma" tanımında kullanıcının kendi seçtiği hizmete aktarım için muafiyetler var; hangisinin uyduğuna sen karar ver. En güvenlisi: web gezinti geçmişi benzeri veri → "paylaşılıyor, isteğe bağlı değil çünkü uygulamanın çekirdek işlevi" diye işaretleyip politikada anlatmak. |
| Veri türü (paylaşılıyorsa) | Web gezinti geçmişi (ziyaret edilen alan adları) | Başka tür yok: konum, kişi, kimlik, finans, mesaj, fotoğraf (arka plan fotoğrafı cihazdan çıkmaz) toplanmıyor. |
| Aktarım sırasında şifreleniyor mu? | Evet (varsayılan DoT/DoH). Kullanıcı kapatırsa düz DNS | Politika ve mağaza metninde yazıyor. |
| Kullanıcı verinin silinmesini isteyebilir mi? | Geliştiricide veri yok; sağlayıcıdaki veri için sağlayıcıya başvurulur | |
| Güvenlik uygulamaları | Hesap yok, yedekleme kapalı, kendi sunucu yok | |

## 2) VPN hizmeti beyanı (VpnService)

Metin (formda İngilizce istenirse):

> The app uses Android's VpnService locally and only to forward DNS queries from the device to the public DNS server the user chooses (Cloudflare, Google, Quad9, AdGuard and others, or a custom server). It is not a remote VPN service: no traffic is tunnelled to a VPN server operated by the developer or anyone else. By default the tunnel only captures DNS queries to a private virtual address and all other traffic uses its normal route. If the user switches on one of two optional features ("DPI bypass" or "Ads+", both off by default), all of the device's traffic is routed through the tunnel into a relay that runs inside the app on the device and is forwarded directly from there to its destination; it is never sent to the developer or any other party. The relay reads only the host name in the first packet of a connection (TLS SNI or HTTP Host), in memory, to match it against an on-device blocklist or to split the packet; it stores and logs nothing and does not decrypt or alter encrypted content. DNS queries are encrypted by default (DNS-over-TLS / DNS-over-HTTPS); the user can switch encryption off in settings and the app says so. The app shows a prominent disclosure on first launch before the system VPN permission dialog and does not collect or share user data for advertising or analytics.

Gerekenler: uygulama içi açık bilgilendirme (ilk açılış ekranı bunu yapar), kısa video (≤ 90 sn): uygulamayı aç → bilgilendirmeyi göster →
küreye dokun → Android VPN izin penceresini göster → bağlı + bildirim → Ayarlar'da şifreleme seçeneği.

## 3) Önplan hizmeti (foreground service) beyanı

- Hizmet türü: `systemExempted` (VPN hizmeti için Android belgelerinde izinli tür).
- Neden: kullanıcı bağlandığı sürece DNS yönlendirmesi çalışmalı; bildirim her zaman görünür (Kes / Sonraki / Duraklat).
- Video: uygulamayı aç → bağlan → bildirim çubuğunda kalıcı bildirimi göster.

## 4) Diğer Uygulama içeriği formları

- Reklamlar: **Yok**. Hedef kitle: 18 yaş ve üzeri / çocuklara yönelik değil. Haberler uygulaması: Hayır. Sağlık: Hayır.
- Uygulama erişimi: tüm işlevler giriş gerektirmeden açık.
- İçerik derecelendirme anketi: şiddet/cinsellik/kumar yok; kullanıcı etkileşimi ve konum paylaşımı yok.
- Finansal özellikler: Yok. Devlet uygulaması: Hayır.
- İzinler (manifest): INTERNET, ACCESS_NETWORK_STATE, FOREGROUND_SERVICE (+ SYSTEM_EXEMPTED), RECEIVE_BOOT_COMPLETED (isteğe bağlı "telefon açılınca bağlan"),
  POST_NOTIFICATIONS (durum bildirimi). Hepsinin nedeni `GIZLILIK.md` "İzinler" bölümünde.

## 5) Yayından önce yapacakların

1. Benzersiz `applicationId` seç (`app/build.gradle.kts`, bir kez; sonradan değişmez).
2. Kendi yükleme anahtarını üret, **depoya ve yapay zekalara verme** (`OKUBENI.md` §4); GitHub'da dört gizli değer olarak tanımla; Actions → *Yayin AAB derle*.
3. `GIZLILIK.md`'deki köşeli yerleri doldur, herkese açık bir adrese koy.
4. Gerçek telefonda tam deneme (özellikle sunucu değiştirme, kopma/yeniden bağlanma, kendini onarma).
5. Kişisel hesapsa: en az 12 test kullanıcısıyla 14 gün kapalı test.

## 6) 2026-10 araştırmasından Play kontrol listesi (kaynaklar aşağıda; Console'daki güncel form esastır)

**En büyük risk: "reklam engelleyici" konumlandırması.** Play'in Device and Network Abuse politikası, başka uygulamaların reklam göstermesini
engelleyen/engellemeye karışan uygulamaları ihlal sayıyor; cihaz genelinde reklam engelleyen uygulamalar bu yüzden mağazadan kaldırıldı
(AdGuard örneği). Şu an mağaza başlığı/kısa açıklaması ("Blocks ads and trackers" / "Reklam ve izleyici engelleme") ve metin 72. satır
(`magaza_metni.md`) reklam engellemeyi öne çıkarıyor. Öneri: konumu **"cihaz güvenliği / ağ aracı"** yap: önce şifreli DNS, sonra
"zararlı, kimlik avı ve izleyici alan adlarına karşı koruma". Reklam ağlarını öne çıkarma; "reklam engelleme" ifadesini ana mesaj yapma.
**Güncelleme (v1.22.0):** `magaza_metni.md` bu konuma göre yeniden yazıldı (kısa açıklamalar 12 dilde, tam açıklamanın girişi ve özellik satırları: "ağ güvenliği aracı", "zararlı, kimlik avı ve izleyici alan adlarına karşı koruma"). Console'daki metinleri de aynı şekilde güncelle; VpnService formunda "Device security / Network-related tools" seç.

**VpnService formu (App content):**
1. "VPN çekirdek işlev mi?" → Hayır (DNS filtresi/şifreli DNS). İzinli işlev olarak "Device security" ya da "Network-related tools" seç;
   uygulamanın gerçek amacına uymayan kategori reddedilmeye yol açar.
2. Video 1 (en çok 90 sn): uygulamayı aç, bağlan, kullanımı göster. Video 2 (en çok 90 sn): ilk açılıştaki **uygulama içi açık bildirim**
   ekranı, yavaş kaydırıp metni okunur göster; onay → sistem VPN penceresi → onay; reddedince ne olduğunu da göster.
3. Açık bildirim uygulama içinde, normal akışta, olumlu bir eylem (dokunma) gerektiren ve diğer bildirimlerden ayrı olmalı. Kullanım şekli
   değişirse (ör. "DPI atlatma" ya da "Reklam+" varsayılan olursa) formu yeniden gönder.
4. "Trafiği para kazanmak için yönlendiriyor mu?" → Hayır.
5. (Uygulamada yapıldı v1.21.9: boş "yalnızca seçilenler" listesinde koruma başlamaz.) Upstream DNS'in DoT/DoH ile şifreli olduğunu beyan metninde açıkça yaz (2. bölümdeki İngilizce metin bunu söylüyor).

**Önplan hizmeti:** `systemExempted` doğru tür (VPN uygulamaları için Android belgelerinde izinli; `dataSync` Android 15'ten beri 24 saatte
6 saatle sınırlı, VPN için uygun değil). Play'in FGS politikası bu türü kriterlerden muaf tutuyor; yine de Console "FGS izinleri" formunu
gösterirse doldur: "Kullanıcının başlattığı, kalıcı bildirimle görünen yerel DNS filtresi; durdurulursa koruma kesilir." Video 1'i yeniden
kullanabilirsin (bildirim ve Kes eylemini göster). Manifestte `systemExempted` dışında FGS türü bırakma. Bağlam: servis `onStartCommand`
içinde hemen `startForeground()` çağırmalı (uygulamada böyle).

**Android 16 bilinen platform sorunları (destek sayfasına not düş):** bir VPN uygulaması güncellendikten sonra internete erişememe hatası
(Proton/Mullvad/WireGuard etkilendi, Google Issue Tracker'da kayıtlı) ve Mayıs 2026'da duyurulan, "Won't Fix" kapatılan bir VPN atlatma açığı.
Uygulama kodundan kaynaklanmaz; kullanıcı "güncelleme sonrası bağlanmıyor" derse önce VPN'i kapatıp açmasını, sonra telefonu yeniden
başlatmasını öner.

**Kaynaklar:** support.google.com/googleplay/android-developer/answer/12564964, /16558241, /16559646, /13392821;
developer.android.com/develop/background-work/services/fgs/service-types; developer.android.com/develop/connectivity/vpn.
