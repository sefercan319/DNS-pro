package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Frutiger Eco: doğa ile teknolojinin buluşması (yenilenebilir enerji). Yeşile çalan gökyüzü, altta yeşil tepeler üzerinde
 * dönen rüzgâr türbinleri ve parlak güneş panelleri, süzülen bokeh kabarcıkları, ağaç dallarından süzülen güneş lekeleri
 * (geceleri ateşböcekleri), köşelerde sallanan dal ve yapraklar, yaprak biçimli kartlar ve düğmeler. Küre, yeşil kıtalı
 * bir Dünya'dır. Hareket: yapraklar düşer, türbinler döner, seçili kartın köşesinde yaprak büyür, bağlanınca kürede filiz uzar.
 */
class EcoArt(theme: AeroTheme, glass: Float) : AeroArt(theme, glass) {
    override val style: UiStyle get() = UiStyle.ECO
    override val particleMode: ParticleMode get() = ParticleMode.FALL
    override val liveSky: Boolean get() = true
    override val motion: StyleMotion = StyleMotion(PageMotion.FADE_SCALE, 0.40f, 0.04f, 0.35f)

    // ------------------------------------------------------------------ yaprak biçimi

    private val leaf = GPath().apply {
        moveTo(0f, 0f)
        cubicTo(0.64f, -0.16f, 0.58f, -0.76f, 0f, -1f)
        cubicTo(-0.58f, -0.76f, -0.64f, -0.16f, 0f, 0f)
        close()
    }
    private val leafFill = Fill.linear(0f, 0f, 0f, -1f,
        if (dark) 0xFF1B6B3A.toInt() else 0xFF2E8B3A.toInt(), if (dark) 0xFF47B36B.toInt() else 0xFF9BDB5F.toInt())
    private val leafFillB = Fill.linear(0f, 0f, 0f, -1f,
        if (dark) 0xFF2C7A46.toInt() else 0xFF55A83F.toInt(), if (dark) 0xFF7CCB8A.toInt() else 0xFFC9E86A.toInt())
    private val leafAutumn = Fill.linear(0f, 0f, 0f, -1f,
        if (dark) 0xFF8A5A22.toInt() else 0xFFD9892B.toInt(), if (dark) 0xFFC9A04A.toInt() else 0xFFF3CF5E.toInt())

    private fun drawLeaf(g: Gfx, x: Float, y: Float, angleDeg: Float, size: Float, fill: Fill, veins: Boolean = true) {
        g.save(); g.translate(x, y); g.rotate(angleDeg); g.scale(size, size)
        g.paint(fill); g.path(leaf)
        if (veins) {
            g.strokeWidth(0.045f); g.paint(white(if (dark) 0.28f else 0.55f)); g.line(0f, -0.04f, 0f, -0.88f)
        }
        g.restore()
    }

    // ------------------------------------------------------------------ gökyüzü

    private class Backdrop(val w: Float, val h: Float, art: EcoArt) {
        val th = art.theme
        val dk = art.dark
        private val g0 = if (dk) 0xFF0B2A20.toInt() else 0xFFE9F8D6.toInt()
        private val g1 = if (dk) 0xFF0E3A2A.toInt() else 0xFFCBEBAE.toInt()
        private val g2 = if (dk) 0xFF123522.toInt() else 0xFFA4D38B.toInt()
        val base = Fill.linear(0f, 0f, 0f, h,
            Rgb.lerp(th.skyTop, g0, 0.55f), Rgb.lerp(th.skyMid, g1, 0.55f), Rgb.lerp(th.skyBottom, g2, 0.55f), AeroTheme.SKY_MID_POS)
        val dapple = Fill.radial(0f, 0f, 1f, Rgb.alpha(0xFFFFF4C0.toInt(), 0.55f), Rgb.alpha(0xFFFFF4C0.toInt(), 0.18f), Rgb.alpha(0xFFFFF4C0.toInt(), 0f), 0.5f)
        val firefly = Fill.radial(0f, 0f, 1f, Rgb.alpha(0xFFE9FF8A.toInt(), 0.95f), Rgb.alpha(0xFFB6F25A.toInt(), 0.30f), Rgb.alpha(0xFFB6F25A.toInt(), 0f), 0.30f)
        val light = Fill.radial(w * 0.85f, 0f, w * 1.0f, Rgb.alpha(0xFFFFF8D0.toInt(), if (dk) 0.06f else 0.55f), Rgb.alpha(0xFFFFF8D0.toInt(), 0f))
        val stem = if (dk) 0xFF1F5A38.toInt() else 0xFF4E7D3A.toInt()
        val stemPath = GPath()

        // tepeler: ön ve arka; çizgiler bir kez kurulur
        val hillFar = GPath()
        val hillNear = GPath()
        val farFill = Fill.linear(0f, h * 0.76f, 0f, h,
            Rgb.alpha(if (dk) 0xFF1B6B3A.toInt() else 0xFF7FCB5A.toInt(), if (dk) 0.55f else 0.62f),
            Rgb.alpha(if (dk) 0xFF0E3A22.toInt() else 0xFF3E9B3F.toInt(), if (dk) 0.70f else 0.78f))
        val nearFill = Fill.linear(0f, h * 0.84f, 0f, h,
            Rgb.alpha(if (dk) 0xFF14502F.toInt() else 0xFF56B23F.toInt(), if (dk) 0.70f else 0.80f),
            Rgb.alpha(if (dk) 0xFF0A2E1B.toInt() else 0xFF2E8B3A.toInt(), if (dk) 0.85f else 0.90f))
        // güneş paneli: birim paralelkenar
        val panel = GPath().poly(0.14f, 0f, 1f, 0f, 0.86f, 1f, 0f, 1f, closed = true)
        val panelFill = Fill.linear(0f, 0f, 1f, 1f,
            if (dk) 0xFF1E4F8F.toInt() else 0xFF2F7FD0.toInt(), if (dk) 0xFF0F2B57.toInt() else 0xFF0E4A9A.toInt(), if (dk) 0xFF1E4F8F.toInt() else 0xFF5BB0F0.toInt(), 0.6f)
        val blade = GPath().apply { moveTo(0f, 0f); quadTo(0.10f, -0.45f, 0f, -1f); quadTo(-0.05f, -0.45f, 0f, 0f); close() }
        val bokeh = Fill.radial(0f, 0f, 1f, Rgb.alpha(Rgb.WHITE, if (dk) 0.03f else 0.10f), Rgb.alpha(Rgb.WHITE, if (dk) 0.06f else 0.16f), Rgb.alpha(Rgb.WHITE, if (dk) 0.22f else 0.55f), 0.82f)
        val sun = Fill.radial(0f, 0f, 1f, Rgb.alpha(0xFFFFFBD6.toInt(), if (dk) 0.0f else 0.95f), Rgb.alpha(0xFFFFF0A0.toInt(), if (dk) 0.0f else 0.35f), Rgb.alpha(0xFFFFF0A0.toInt(), 0f), 0.30f)

        init {
            hillFar.moveTo(0f, h)
            for (i in 0..16) { val u = i / 16f; hillFar.lineTo(u * w, crestFar(u)) }
            hillFar.lineTo(w, h).close()
            hillNear.moveTo(0f, h)
            for (i in 0..16) { val u = i / 16f; hillNear.lineTo(u * w, crestNear(u)) }
            hillNear.lineTo(w, h).close()
        }

        fun crestFar(u: Float) = h * (0.800f + 0.026f * sin(u * 3.4f + 0.5f))
        fun crestNear(u: Float) = h * (0.885f + 0.020f * sin(u * 2.6f + 2.2f))
    }

    private var back: Backdrop? = null

    private fun backdrop(w: Float, h: Float): Backdrop {
        var b = back
        if (b == null || b.w != w || b.h != h) { b = Backdrop(w, h, this); back = b }
        return b
    }

    override fun sky(g: Gfx, w: Float, h: Float) = skyFrame(g, w, h, false, 0f)

    override fun skyFrame(g: Gfx, w: Float, h: Float, live: Boolean, time: Float) {
        val b = backdrop(w, h)
        g.paint(b.base); g.rect(0f, 0f, w, h)
        g.paint(b.light); g.rect(0f, 0f, w, h)
        val t = if (live) time else 0f
        if (!dark) {
            // yaprak aralarından süzülen güneş lekeleri (yavaşça kayar)
            for (i in 0 until 4) {
                val x = w * (0.18f + 0.25f * i) + sin(t * 0.20f + i * 2.1f) * w * 0.07f
                val y = h * (0.14f + 0.17f * i) + cos(t * 0.17f + i * 1.3f) * h * 0.035f
                g.save(); g.translate(x, y); g.rotate(-24f); g.scale(w * 0.34f, w * 0.20f)
                g.alpha(0.55f + 0.30f * sin(t * 0.5f + i * 1.7f)); g.paint(b.dapple); g.circle(0f, 0f, 1f)
                g.restore()
            }
        } else {
            // ateşböcekleri
            for (i in 0 until 8) {
                val x = w * ((i * 0.137f + 0.07f) % 1f) + sin(t * 0.35f + i * 1.9f) * 18f
                val y = h * (0.10f + 0.08f * i) + cos(t * 0.28f + i * 2.3f) * 14f
                val pulse = 0.35f + 0.65f * max(0f, sin(t * 0.9f + i * 2.7f))
                val r = 7f + (i % 3) * 3f
                g.save(); g.translate(x, y); g.scale(r, r); g.alpha(pulse); g.paint(b.firefly); g.circle(0f, 0f, 1f); g.restore()
            }
        }
        scenery(g, b, w, h, t)
        // köşelerde dallar
        g.save(); g.alpha(if (dark) 0.62f else 0.72f)
        branch(g, b, w + 8f, -8f, 126f, min(h * 0.34f, w * 0.95f), 7, t, 0f)
        branch(g, b, w + 8f, -8f, 150f, min(h * 0.20f, w * 0.60f), 5, t, 1.7f)
        branch(g, b, -10f, h + 10f, -52f, min(h * 0.20f, w * 0.60f), 5, t, 3.1f)
        g.restore()
    }

    /** Alt kısım: tepeler, rüzgâr türbinleri, güneş panelleri; üstte yavaşça süzülen bokeh kabarcıkları ve güneş. */
    private fun scenery(g: Gfx, b: Backdrop, w: Float, h: Float, t: Float) {
        if (!dark) {
            g.save(); g.translate(w * 0.80f, h * 0.10f); g.scale(w * 0.34f, w * 0.34f); g.paint(b.sun); g.circle(0f, 0f, 1f); g.restore()
        }
        for (i in 0 until 6) {
            val r = w * (0.035f + 0.022f * (i % 3))
            val x = w * ((0.12f + i * 0.17f) % 1f) + sin(t * 0.18f + i * 1.7f) * w * 0.02f
            val y = h * (0.20f + 0.11f * i) + cos(t * 0.14f + i * 2.1f) * h * 0.015f
            g.save(); g.translate(x, y); g.scale(r, r); g.paint(b.bokeh); g.circle(0f, 0f, 1f); g.restore()
        }
        g.paint(b.farFill); g.path(b.hillFar)
        // rüzgâr türbinleri (arka tepenin sırtında)
        for (i in 0 until 3) {
            val u = 0.60f + 0.17f * i
            val bx = u * w
            val by = b.crestFar(u)
            val th = h * (0.058f + 0.008f * i)
            val hx = bx
            val hy = by - th
            g.strokeWidth(1.6f); g.paint(white(if (dark) 0.45f else 0.80f)); g.line(bx, by, hx, hy)
            val bl = th * 0.62f
            for (k in 0 until 3) {
                g.save(); g.translate(hx, hy); g.rotate(t * (26f + 5f * i) + k * 120f + i * 40f); g.scale(bl * 0.30f, bl)
                g.paint(white(if (dark) 0.60f else 0.97f)); g.path(b.blade)
                g.restore()
            }
            g.paint(white(if (dark) 0.75f else 1f)); g.circle(hx, hy, 2.2f)
        }
        g.paint(b.nearFill); g.path(b.hillNear)
        // güneş panelleri (ön tepenin sağında, eğimli sıra)
        val pw = w * 0.115f
        val ph = h * 0.026f
        for (i in 0 until 3) {
            val u = 0.56f + 0.15f * i
            val x = u * w
            val y = b.crestNear(u) + h * 0.008f
            g.save(); g.translate(x, y); g.scale(pw, ph); g.alpha(0.50f)
            g.paint(b.panelFill); g.path(b.panel)
            g.strokeWidth(0.05f); g.paint(white(if (dark) 0.35f else 0.75f))
            g.line(0.38f, 0f, 0.32f, 1f); g.line(0.69f, 0f, 0.66f, 1f); g.line(0.07f, 0.5f, 0.93f, 0.5f)
            g.paint(white(if (dark) 0.10f else 0.30f)); g.rect(0.14f, 0f, 0.80f, 0.34f)
            g.restore()
        }
    }

    /** Eğimli bir dal: gövde bir ikinci derece eğri, yapraklar sırayla iki yana dizilir ve rüzgârda sallanır. */
    private fun branch(g: Gfx, b: Backdrop, ox: Float, oy: Float, angleDeg: Float, len: Float, n: Int, t: Float, seed: Float) {
        val a = angleDeg * PI.toFloat() / 180f
        val ex = ox + cos(a) * len
        val ey = oy + sin(a) * len
        val cx = (ox + ex) / 2f + sin(a) * len * 0.12f
        val cy = (oy + ey) / 2f - cos(a) * len * 0.12f
        val sw = sin(t * 0.7f + seed) * 0.02f
        b.stemPath.reset().moveTo(ox, oy).quadTo(cx, cy, ex + sw * len, ey)
        g.strokeWidth(2.4f); g.paint(b.stem); g.strokePath(b.stemPath)
        for (i in 1..n) {
            val u = i / (n + 1f) + 0.04f
            val iu = 1f - u
            val px = iu * iu * ox + 2f * iu * u * cx + u * u * (ex + sw * len)
            val py = iu * iu * oy + 2f * iu * u * cy + u * u * ey
            val side = if (i % 2 == 0) 1f else -1f
            val ang = angleDeg + 90f + side * 52f + sin(t * 0.9f + seed + i * 0.8f) * 5f
            val sz = len * 0.20f * (1.05f - 0.55f * u)
            drawLeaf(g, px, py, ang, sz, if (i % 3 == 0) leafFillB else leafFill)
        }
        drawLeaf(g, ex + sw * len, ey, angleDeg + 90f + sin(t * 0.9f + seed) * 4f, len * 0.13f, leafFillB)
    }

    // ------------------------------------------------------------------ düşen yapraklar

    override fun particle(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float, phase: Float) {
        val pick = ((phase * 3.1f).toInt() and 0x7fffffff) % 5
        val fill = if (pick == 0) leafAutumn else if (pick % 2 == 1) leafFill else leafFillB
        g.save(); g.alpha(alpha * (if (dark) 0.75f else 0.9f))
        drawLeaf(g, cx, cy, phase * 38f + 20f, r * 1.7f, fill, veins = r > 9f)
        g.restore()
    }

    // ------------------------------------------------------------------ yaprak biçimli yüzeyler

    private class Shape(val w: Float, val h: Float, rad: Float) {
        val path = GPath()
        val avg: Float

        init {
            val m = min(w, h) / 2f
            val big = min(rad * 1.25f, m)
            val small = min(rad * 0.38f, m)
            // sol üst büyük, sağ üst küçük, sağ alt büyük, sol alt küçük
            path.moveTo(big, 0f)
            path.lineTo(w - small, 0f); path.arc(w - small, small, small, small, -90f, 90f, true)
            path.lineTo(w, h - big); path.arc(w - big, h - big, big, big, 0f, 90f, true)
            path.lineTo(small, h); path.arc(small, h - small, small, small, 90f, 90f, true)
            path.lineTo(0f, big); path.arc(big, big, big, big, 180f, 90f, true)
            path.close()
            avg = (big + small) / 2f
        }
    }

    private val shapes = LongCache<Shape>(80)

    private fun shapeOf(w: Float, h: Float, rad: Float): Shape {
        val k = key(w, h, rad)
        var s = shapes[k]
        if (s == null) { s = Shape(w, h, rad); shapes[k] = s }
        return s
    }

    private class Paints(val w: Float, val h: Float, art: EcoArt) {
        val body = Fill.linear(0f, 0f, 0f, h, art.tint(art.aTop), art.tint(art.aBot))
        val wash = Fill.linear(0f, 0f, w, h, Rgb.alpha(0xFF9BDB5F.toInt(), if (art.dark) 0.05f else 0.16f), Rgb.alpha(0xFF2E8B3A.toInt(), 0.04f))
        val rim = Fill.linear(0f, 0f, w, h, art.white(if (art.dark) 0.50f else 0.92f), Rgb.alpha(0xFF6CBF5A.toInt(), if (art.dark) 0.30f else 0.50f))
        val bodyStrong = Fill.linear(0f, 0f, 0f, h, Rgb.alpha(art.theme.skyTop, 0.97f), Rgb.alpha(art.theme.skyMid, 0.97f))
    }

    private val paints = LongCache<Paints>(80)

    private fun paintsOf(w: Float, h: Float): Paints {
        val k = key(w, h, 9f)
        var p = paints[k]
        if (p == null) { p = Paints(w, h, this); paints[k] = p }
        return p
    }

    override fun card(
        g: Gfx, l: Float, t: Float, r: Float, b: Float, rad: Float,
        selected: Float, press: Float, strong: Float, shadow: Float,
    ) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        val sp = shapeOf(w, h, min(rad, min(w, h) / 2f))
        val pt = paintsOf(w, h)
        g.save()
        g.translate(l, t)
        if (shadow > 0f) {
            g.strokeWidth(2.2f)
            val base = (if (dark) 0.16f else 0.10f) * shadow
            for (i in 0 until 5) {
                val f = 1f - i / 5f
                g.paint(Rgb.alpha(if (dark) 0xFF000000.toInt() else 0xFF1E5A2A.toInt(), base * f * f))
                val e = 0.9f + i * 1.9f
                g.strokeRoundRect(-e, -e + 2.4f, w + e, h + e + 2.4f, sp.avg + e)
            }
        }
        g.paint(pt.body); g.path(sp.path)
        g.paint(pt.wash); g.path(sp.path)
        if (strong > 0f) { g.save(); g.alpha(strong); g.paint(pt.bodyStrong); g.path(sp.path); g.restore() }
        if (selected > 0f) { g.save(); g.alpha(selected); g.paint(Rgb.alpha(theme.accent, 0.16f)); g.path(sp.path); g.restore() }
        g.strokeWidth(1.2f); g.paint(pt.rim); g.strokePath(sp.path)
        if (selected > 0f) {
            g.save(); g.alpha(selected)
            g.strokeWidth(2f); g.paint(theme.accent); g.strokePath(sp.path)
            g.restore()
            if (w >= 90f && h >= 44f) {
                // seçilince köşede iki yaprak büyür (sağ üst)
                val gr = Easing.outBack(selected, 1.6f)
                val sway = sin(clock * 1.3f) * 4f
                drawLeaf(g, w - 10f, 5f, 28f + sway, 17f * gr, leafFillB)
                drawLeaf(g, w - 10f, 5f, -22f + sway, 13f * gr, leafFill)
            }
        }
        if (press > 0f) { g.save(); g.alpha(press); g.paint(Rgb.alpha(theme.accent, 0.18f)); g.path(sp.path); g.restore() }
        g.restore()
    }

    private class PillShape(val w: Float, val h: Float) {
        val path = GPath()
        init {
            val big = h / 2f
            val small = h * 0.20f
            path.moveTo(big, 0f)
            path.lineTo(w - small, 0f); path.arc(w - small, small, small, small, -90f, 90f, true)
            path.lineTo(w, h - big); path.arc(w - big, h - big, big, big, 0f, 90f, true)
            path.lineTo(small, h); path.arc(small, h - small, small, small, 90f, 90f, true)
            path.lineTo(0f, big); path.arc(big, big, big, big, 180f, 90f, true)
            path.close()
        }
    }

    private val pillShapes = LongCache<PillShape>(40)
    private val pillBody = LongCache<Fill>(40)

    override fun pill(g: Gfx, l: Float, t: Float, r: Float, b: Float, press: Float, shadow: Float) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        val k = key(w, h, 5f)
        var ps = pillShapes[k]
        if (ps == null) { ps = PillShape(w, h); pillShapes[k] = ps }
        var f = pillBody[k]
        if (f == null) { f = Fill.linear(0f, 0f, 0f, h, Rgb.lerp(theme.control, 0xFF8FD35A.toInt(), 0.18f), theme.controlDeep); pillBody[k] = f }
        g.save(); g.translate(l, t)
        if (shadow > 0f) {
            g.strokeWidth(2.2f)
            for (i in 0 until 4) {
                val ff = 1f - i / 4f
                g.paint(Rgb.alpha(theme.controlDeep, (if (dark) 0.22f else 0.12f) * shadow * ff * ff))
                val e = 1.1f + i * 1.9f
                g.strokeRoundRect(-e, -e + 2f, w + e, h + e + 2f, h / 2f + e)
            }
        }
        g.paint(f); g.path(ps.path)
        g.paint(white(0.20f)); g.roundRect(h * 0.35f, 1.4f, w - h * 0.25f, h * 0.42f, h * 0.2f)
        g.strokeWidth(1.2f); g.paint(white(0.65f)); g.strokePath(ps.path)
        if (press > 0f) { g.save(); g.alpha(press); g.paint(Rgb.alpha(theme.shadow, 0.22f)); g.path(ps.path); g.restore() }
        g.restore()
    }

    // ------------------------------------------------------------------ küre: filiz

    override fun orb(g: Gfx, cx: Float, cy: Float, r: Float, level: Float, phase: Float, glow: Float, error: Float, press: Float) {
        super.orb(g, cx, cy, r, level, phase, glow, error, press)
        if (r >= 24f && error < 0.5f) continents(g, cx, cy, r, press)
        val gr = Easing.clamp01((level - 0.08f) / 0.45f)
        if (gr <= 0.01f || r < 24f || error > 0.5f) return
        val s = Easing.outBack(gr, 1.5f)
        val sway = sin(phase * 0.8f) * 5f
        g.save(); g.translate(cx, cy); g.scale(1f - 0.03f * press, 1f - 0.03f * press)
        // filiz kürenin sağ üst kenarından çıkar
        val bx = r * 0.62f
        val by = -r * 0.80f
        g.strokeWidth(2.6f); g.paint(if (dark) 0xFF47B36B.toInt() else 0xFF3C9A43.toInt())
        g.line(bx, by + 2f, bx + 6f * s, by - 22f * s)
        drawLeaf(g, bx + 6f * s, by - 22f * s, 38f + sway, r * 0.26f * s, leafFillB)
        drawLeaf(g, bx + 3f * s, by - 12f * s, -52f + sway, r * 0.20f * s, leafFill)
        g.restore()
    }

    /** Küre bir Dünya: kenarlara yakın, güç simgesini örtmeyen yeşil kıtalar ve ince bir meridyen. */
    private val land = GPath().apply {
        moveTo(-0.34f, -0.10f)
        cubicTo(-0.30f, -0.26f, -0.12f, -0.30f, -0.02f, -0.22f)
        cubicTo(0.06f, -0.34f, 0.22f, -0.26f, 0.20f, -0.12f)
        cubicTo(0.34f, -0.08f, 0.30f, 0.06f, 0.16f, 0.08f)
        cubicTo(0.12f, 0.24f, -0.02f, 0.30f, -0.08f, 0.16f)
        cubicTo(-0.18f, 0.20f, -0.22f, 0.06f, -0.30f, 0.04f)
        cubicTo(-0.38f, 0.02f, -0.38f, -0.06f, -0.34f, -0.10f)
        close()
    }
    private val globeRing = GPath().apply {
        arc(0f, 0f, 1f, 1f, 0f, 90f, false); arc(0f, 0f, 1f, 1f, 90f, 90f, true)
        arc(0f, 0f, 1f, 1f, 180f, 90f, true); arc(0f, 0f, 1f, 1f, 270f, 90f, true); close()
    }
    private val landFill = Fill.linear(0f, -0.3f, 0f, 0.3f,
        if (dark) 0xFF2F9A55.toInt() else 0xFF3FA845.toInt(), if (dark) 0xFF1B6B3A.toInt() else 0xFF2E8B3A.toInt())

    private fun continents(g: Gfx, cx: Float, cy: Float, r: Float, press: Float) {
        val k = 1f - 0.03f * press
        g.save(); g.translate(cx, cy); g.scale(k, k); g.clipCircle(0f, 0f, r - 3f)
        // enlem / boylam çizgileri (ince, açık)
        g.save(); g.alpha(if (dark) 0.22f else 0.38f); g.strokeWidth(1f); g.paint(white(1f))
        g.line(-r, 0f, r, 0f)
        val lat = r * 0.55f
        val chord = sqrt(r * r - lat * lat)
        g.line(-chord, -lat, chord, -lat); g.line(-chord, lat, chord, lat)
        g.save(); g.scale(r * 0.46f, r); g.strokeWidth(0.02f); g.strokePath(globeRing); g.restore()
        g.save(); g.scale(r * 0.82f, r); g.strokeWidth(0.016f); g.strokePath(globeRing); g.restore()
        g.restore()
        g.alpha(if (dark) 0.50f else 0.60f)
        val drift = sin(clock * 0.25f) * r * 0.04f
        g.save(); g.translate(-r * 0.50f + drift, -r * 0.40f); g.scale(r * 0.85f, r * 0.85f); g.paint(landFill); g.path(land); g.restore()
        g.save(); g.translate(r * 0.52f - drift, r * 0.58f); g.scale(r * 0.72f, r * 0.72f); g.rotate(170f); g.paint(landFill); g.path(land); g.restore()
        g.restore()
    }

    // ------------------------------------------------------------------ anahtar: yaprak topuzlu

    override fun switch(g: Gfx, l: Float, t: Float, w: Float, h: Float, on: Float, press: Float) {
        val o = on.coerceIn(0f, 1f)
        g.save(); g.translate(l, t)
        g.paint(insetFill(h)); g.roundRect(0f, 0f, w, h, h / 2f)
        if (o > 0.001f) {
            g.save(); g.alpha(o)
            g.paint(Rgb.lerp(theme.control, 0xFF4DAF4A.toInt(), 0.25f)); g.roundRect(0f, 0f, w, h, h / 2f)
            g.paint(white(0.20f)); g.roundRect(1.5f, 1.2f, w - 1.5f, h * 0.46f, h / 2f - 1.2f)
            g.restore()
        }
        g.strokeWidth(1.2f); g.paint(white(if (dark) 0.40f else 0.85f)); g.strokeRoundRect(0.6f, 0.6f, w - 0.6f, h - 0.6f, h / 2f - 0.6f)
        val kr = h / 2f - 3.2f + press * 0.8f
        val kx = h / 2f + (w - h) * on.coerceIn(-0.12f, 1.12f)
        g.paint(Rgb.alpha(theme.shadow, if (dark) 0.35f else 0.20f)); g.circle(kx, h / 2f + 1.5f, kr + 0.6f)
        g.paint(white(0.97f)); g.circle(kx, h / 2f, kr)
        // topuzdaki yaprak açıldıkça büyür
        drawLeaf(g, kx, h / 2f + kr * 0.55f, 18f, kr * 1.45f * (0.45f + 0.55f * o), if (o > 0.5f) leafFillB else leafFill)
        g.restore()
    }

    override fun iconDisc(g: Gfx, cx: Float, cy: Float, r: Float) {
        g.paint(Rgb.alpha(theme.accent, if (dark) 0.28f else 0.26f)); g.circle(cx, cy, r)
        g.strokeWidth(1f); g.paint(white(if (dark) 0.30f else 0.75f)); g.strokeCircle(cx, cy, r - 0.5f)
    }
}
