package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Frutiger Aero çizimleri: gökyüzü, cam kartlar, parlak düğmeler, sıvı küre, kabarcıklar, anahtar, kaydırıcı.
 * Yalnızca [Gfx] kullanır (Android'e de AWT'ye de bağlı değil). Bir örnek tek bir tema + cam yoğunluğu içindir;
 * tema veya cam değişince yeni örnek kurulur. Boyuta bağlı gradyanlar ilk kullanımda üretilip saklanır,
 * böylece kare başına bellek ayrılmaz.
 */
open class AeroArt(val theme: AeroTheme, val glass: Float) {
    protected val dark = theme.dark
    protected val aTop = GlassMath.top(glass, dark)
    protected val aBot = GlassMath.bottom(glass, dark)
    protected val aTopStrong = GlassMath.top(1f, dark)
    protected val aBotStrong = GlassMath.bottom(1f, dark)

    protected fun white(a: Float) = Rgb.alpha(Rgb.WHITE, a)
    protected fun tint(a: Float) = Rgb.alpha(theme.tint, a)

    /** Alt sayfa ve bildirimlerin "dolu cam" rengi: arkadaki içerik görünmesin diye neredeyse opak. */
    private val solidTop: Int = if (dark) Rgb.alpha(Rgb.over(tint(0.10f), theme.skyMid), 0.97f)
        else Rgb.alpha(Rgb.lerp(Rgb.WHITE, theme.skyTop, 0.18f), 0.96f)
    private val solidBottom: Int = if (dark) Rgb.alpha(Rgb.over(tint(0.05f), theme.skyBottom), 0.97f)
        else Rgb.alpha(Rgb.lerp(Rgb.WHITE, theme.skyMid, 0.22f), 0.94f)

    /** Üst parıltının başlangıç opaklığı: açık temada belirgin, koyu temada hafif. */
    protected val sheen = if (dark) 0.11f else 0.34f

    // ------------------------------------------------------------------ stil kancaları (Aqua varsayılanı)

    /** Bu çizicinin stili. */
    open val style: UiStyle get() = UiStyle.AQUA

    /** Süs parçacıklarının davranışı ve çizimi (Aqua: yükselen kabarcıklar). */
    open val particleMode: ParticleMode get() = ParticleMode.RISE

    /** Süs parçacığı. [phase] 0..2π yavaş değişen evre (sallanma, dönüş, parıltı için). Varsayılan: kabarcık. */
    open fun particle(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float, phase: Float) = bubble(g, cx, cy, r, alpha)

    /** Arka planda sürekli hareket eden katman var mı (çim sallanması vb.)? Varsa hareket açıkken kareler akar. */
    open val liveSky: Boolean get() = false

    /**
     * Bir karenin arka planı. [live] açıksa (hareket açık) hareketli parçalar [time] sn'ye göre çizilir; kapalıysa
     * dinlenme hallerinde. Varsayılan: durağan [sky].
     */
    open fun skyFrame(g: Gfx, w: Float, h: Float, live: Boolean, time: Float) = sky(g, w, h)

    /** Stilin hareket kişiliği (sayfa geçişi, liste girişi). */
    open val motion: StyleMotion get() = StyleMotion.AQUA

    /** Başlık yazısı çarpanı (Metro büyük yazı kullanır). */
    open val titleScale: Float get() = 1f

    /** Sahne saati (sn): kart ve düğme süsleri (parıltı, tarama ışığı) bununla oynar. Sahne her karede yazar. */
    var clock: Float = 0f

    // ------------------------------------------------------------------ gökyüzü

    private class SkyStyle(val w: Float, val h: Float, theme: AeroTheme, dark: Boolean) {
        val base = Fill.linear(0f, 0f, 0f, h, theme.skyTop, theme.skyMid, theme.skyBottom, AeroTheme.SKY_MID_POS)
        val bloom = Fill.radial(
            w * 0.20f, -h * 0.04f, w * 1.25f,
            Rgb.alpha(Rgb.WHITE, if (dark) 0.10f else 0.66f),
            Rgb.alpha(Rgb.WHITE, if (dark) 0.04f else 0.22f),
            Rgb.alpha(Rgb.WHITE, 0f), 0.42f,
        )
        private val ribbon = if (dark) theme.accent else Rgb.WHITE
        private val ra = if (dark) 0.5f else 1f
        val ribbonA = Fill.linear(
            0f, 0f, w, 0f,
            Rgb.alpha(ribbon, 0.03f * ra), Rgb.alpha(ribbon, 0.21f * ra), Rgb.alpha(ribbon, 0.03f * ra), 0.55f,
        )
        val ribbonB = Fill.linear(
            0f, 0f, w, 0f,
            Rgb.alpha(ribbon, 0.02f * ra), Rgb.alpha(ribbon, 0.13f * ra), Rgb.alpha(ribbon, 0.02f * ra), 0.40f,
        )
        val haze = Fill.linear(
            0f, h * 0.62f, 0f, h,
            Rgb.alpha(Rgb.WHITE, 0f), Rgb.alpha(Rgb.WHITE, if (dark) 0.04f else 0.20f),
        )
        val pathA = GPath()
        val pathB = GPath()

        init {
            pathA.moveTo(-0.1f * w, 0.70f * h)
                .cubicTo(0.25f * w, 0.50f * h, 0.62f * w, 0.88f * h, 1.1f * w, 0.52f * h)
                .lineTo(1.1f * w, 0.66f * h)
                .cubicTo(0.62f * w, 1.02f * h, 0.25f * w, 0.66f * h, -0.1f * w, 0.90f * h)
                .close()
            pathB.moveTo(-0.1f * w, 0.30f * h)
                .cubicTo(0.30f * w, 0.18f * h, 0.70f * w, 0.42f * h, 1.1f * w, 0.20f * h)
                .lineTo(1.1f * w, 0.27f * h)
                .cubicTo(0.70f * w, 0.50f * h, 0.30f * w, 0.26f * h, -0.1f * w, 0.38f * h)
                .close()
        }
    }

    private var sky: SkyStyle? = null

    /** Tüm ekranı kaplayan gökyüzü: gradyan, ışık hâlesi, iki yumuşak şerit ve alt sis. */
    open fun sky(g: Gfx, w: Float, h: Float) {
        var s = sky
        if (s == null || s.w != w || s.h != h) { s = SkyStyle(w, h, theme, dark); sky = s }
        g.paint(s.base); g.rect(0f, 0f, w, h)
        g.paint(s.bloom); g.rect(0f, 0f, w, h)
        g.paint(s.ribbonB); g.path(s.pathB)
        g.paint(s.ribbonA); g.path(s.pathA)
        g.paint(s.haze); g.rect(0f, h * 0.62f, w, h)
    }

    // ------------------------------------------------------------------ kabarcık

    private val bubbleBody = Fill.radial(
        0f, 0f, 1f,
        tint(0.03f), tint(0.10f), white(if (dark) 0.34f else 0.62f), 0.68f,
    )
    private val bubbleRim = Fill.linear(-1f, -1f, 1f, 1f, white(0.95f), white(0.18f))
    private val softSpot = Fill.radial(0f, 0f, 1f, white(0.95f), white(0f))
    private val bounceSpot = Fill.radial(0f, 0f, 1f, Rgb.alpha(theme.accentLight, 0.75f), Rgb.alpha(theme.accentLight, 0f))

    /** Sabun köpüğü gibi parlak, saydam küre. [alpha] 0..1. */
    open fun bubble(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float) {
        if (alpha <= 0.01f || r <= 0.5f) return
        g.save()
        g.translate(cx, cy)
        g.scale(r, r)
        g.alpha(alpha)
        g.paint(bubbleBody); g.circle(0f, 0f, 1f)
        g.strokeWidth(0.07f)
        g.paint(bubbleRim); g.strokeCircle(0f, 0f, 0.96f)
        // üst-sol parlama
        g.save(); g.translate(-0.36f, -0.44f); g.rotate(-34f); g.scale(0.27f, 0.14f)
        g.paint(softSpot); g.circle(0f, 0f, 1f); g.restore()
        if (r >= 9f) {
            // alt-sağ yansıma
            g.save(); g.translate(0.40f, 0.50f); g.rotate(-40f); g.scale(0.22f, 0.09f)
            g.paint(bounceSpot); g.circle(0f, 0f, 1f); g.restore()
        }
        g.restore()
    }

    // ------------------------------------------------------------------ cam kart

    private class CardStyle(
        val w: Float, val h: Float, rad: Float, art: AeroArt,
    ) {
        val body = Fill.linear(0f, 0f, 0f, h, art.tint(art.aTop), art.tint(art.aBot))
        val bodyStrong = Fill.linear(0f, 0f, 0f, h, art.solidTop, art.solidBottom)
        val selTint = Fill.linear(
            0f, 0f, 0f, h,
            Rgb.alpha(art.theme.accentLight, if (art.dark) 0.22f else 0.30f),
            Rgb.alpha(art.theme.accent, if (art.dark) 0.14f else 0.16f),
        )
        val gloss = GPath()
        val glossFill: Fill
        val rim = Fill.linear(0f, 0f, 0f, h, art.white(if (art.dark) 0.60f else 0.95f), art.white(if (art.dark) 0.14f else 0.34f))
        val rimSel = Fill.linear(0f, 0f, 0f, h, art.theme.accentLight, art.theme.accent)

        init {
            val k = rad.coerceIn(0f, min(w, h) / 2f)
            val edgeL = max(k, h * 0.50f)
            val edgeR = max(k, h * 0.27f)
            val bow = max(edgeL, edgeR) + h * 0.13f
            gloss.moveTo(0f, edgeL)
            gloss.lineTo(0f, k)
            gloss.arc(k, k, k, k, 180f, 90f, true)
            gloss.lineTo(w - k, 0f)
            gloss.arc(w - k, k, k, k, -90f, 90f, true)
            gloss.lineTo(w, edgeR)
            gloss.quadTo(w * 0.52f, bow, 0f, edgeL)
            gloss.close()
            glossFill = Fill.linear(0f, 0f, 0f, max(edgeL, edgeR) + h * 0.06f, art.white(art.sheen), art.white(art.sheen * 0.12f))
        }
    }

    private val cards = LongCache<CardStyle>(80)

    protected fun key(w: Float, h: Float, r: Float): Long =
        ((w * 2f).toInt().toLong() shl 40) or ((h * 2f).toInt().toLong() shl 20) or (r * 2f).toInt().toLong()

    private fun cardStyle(w: Float, h: Float, rad: Float): CardStyle {
        val k = key(w, h, rad)
        var s = cards[k]
        if (s == null) {
            s = CardStyle(w, h, rad, this)
            cards[k] = s
        }
        return s
    }

    /** Dışa doğru sönen yumuşak gölge halkaları (kartın altına değil, yalnızca dışına çizilir). */
    private fun shadow(g: Gfx, w: Float, h: Float, rad: Float, strength: Float) {
        val n = 6
        val step = 1.9f
        val base = (if (dark) 0.14f else 0.085f) * strength
        g.strokeWidth(step + 0.35f)
        for (i in 0 until n) {
            val f = 1f - i / n.toFloat()
            g.paint(Rgb.alpha(theme.shadow, base * f * f))
            val e = 0.9f + i * step
            val dy = 1.6f + i * 0.4f
            g.strokeRoundRect(-e, -e + dy, w + e, h + e + dy, rad + e)
        }
    }

    /**
     * Cam kart. [selected] 0..1 vurgu kenarı ve renk; [press] 0..1 basılı parlama; [strong] 0..1 daha opak yüzey
     * (alt sayfalar için); [shadow] gölge katsayısı (0 = yok).
     */
    open fun card(
        g: Gfx, l: Float, t: Float, r: Float, b: Float, rad: Float,
        selected: Float = 0f, press: Float = 0f, strong: Float = 0f, shadow: Float = 1f,
    ) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        val rr = min(rad, min(w, h) / 2f)
        val st = cardStyle(w, h, rr)
        g.save()
        g.translate(l, t)
        if (shadow > 0f) shadow(g, w, h, rr, shadow)
        g.paint(st.body); g.roundRect(0f, 0f, w, h, rr)
        if (strong > 0f) { g.save(); g.alpha(strong); g.paint(st.bodyStrong); g.roundRect(0f, 0f, w, h, rr); g.restore() }
        if (selected > 0f) { g.save(); g.alpha(selected); g.paint(st.selTint); g.roundRect(0f, 0f, w, h, rr); g.restore() }
        g.paint(st.glossFill); g.path(st.gloss)
        g.strokeWidth(1.2f)
        g.paint(st.rim); g.strokeRoundRect(0.6f, 0.6f, w - 0.6f, h - 0.6f, max(0f, rr - 0.6f))
        if (selected > 0f) {
            g.save(); g.alpha(selected)
            g.strokeWidth(2f)
            g.paint(st.rimSel); g.strokeRoundRect(1.1f, 1.1f, w - 1.1f, h - 1.1f, max(0f, rr - 1.1f))
            g.restore()
        }
        if (press > 0f) {
            g.save(); g.alpha(press)
            g.paint(Rgb.alpha(theme.accent, 0.20f)); g.roundRect(0f, 0f, w, h, rr)
            g.restore()
        }
        g.restore()
    }

    // ------------------------------------------------------------------ parlak düğme (seçili çip, birincil)

    private class PillStyle(val w: Float, val h: Float, art: AeroArt) {
        val body = Fill.linear(0f, 0f, 0f, h, art.theme.control, art.theme.controlDeep)
        val gloss = GPath()
        val glossFill: Fill
        val rim = Fill.linear(0f, 0f, 0f, h, art.white(0.80f), Rgb.alpha(art.theme.accentLight, 0.60f))

        init {
            val k = min(w, h) / 2f
            gloss.arc(k, k, k, k, 180f, 90f, false)
            gloss.lineTo(w - k, 0f)
            gloss.arc(w - k, k, k, k, -90f, 90f, true)
            gloss.lineTo(w, h * 0.50f)
            gloss.quadTo(w * 0.5f, h * 0.64f, 0f, h * 0.50f)
            gloss.close()
            glossFill = Fill.linear(0f, 0f, 0f, h * 0.55f, art.white(0.40f), art.white(0.05f))
        }
    }

    private val pills = LongCache<PillStyle>(40)

    /** Dolu, parlak vurgu düğmesi (tam yuvarlak uçlu). Beyaz yazı üzerinde okunur. [alpha] ile solup gelebilir. */
    open fun pill(g: Gfx, l: Float, t: Float, r: Float, b: Float, press: Float = 0f, shadow: Float = 1f) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        val k = key(w, h, 0f)
        var st = pills[k]
        if (st == null) {
            st = PillStyle(w, h, this); pills[k] = st
        }
        g.save()
        g.translate(l, t)
        if (shadow > 0f) {
            val n = 4
            g.strokeWidth(2.2f)
            for (i in 0 until n) {
                val f = 1f - i / n.toFloat()
                g.paint(Rgb.alpha(theme.controlDeep, (if (dark) 0.24f else 0.11f) * shadow * f * f))
                val e = 1.1f + i * 1.9f
                g.strokeRoundRect(-e, -e + 2f, w + e, h + e + 2f, h / 2f + e)
            }
        }
        g.paint(st.body); g.roundRect(0f, 0f, w, h, h / 2f)
        g.paint(st.glossFill); g.path(st.gloss)
        g.strokeWidth(1.2f)
        g.paint(st.rim); g.strokeRoundRect(0.6f, 0.6f, w - 0.6f, h - 0.6f, h / 2f - 0.6f)
        if (press > 0f) { g.save(); g.alpha(press); g.paint(Rgb.alpha(theme.shadow, 0.22f)); g.roundRect(0f, 0f, w, h, h / 2f); g.restore() }
        g.restore()
    }

    // ------------------------------------------------------------------ sıvı küre

    private class OrbStyle(val r: Float, art: AeroArt) {
        private val th = art.theme
        private val dk = art.dark
        val ground = Fill.radial(0f, 0f, 1f, Rgb.alpha(th.shadow, if (dk) 0.60f else 0.34f), Rgb.alpha(th.shadow, 0f))
        val glow = Fill.radial(
            0f, 0f, r * 1.75f,
            Rgb.alpha(th.glow, 0.62f), Rgb.alpha(th.glow, 0.22f), Rgb.alpha(th.glow, 0f), 0.52f,
        )
        val glass = Fill.radial(
            0f, 0f, r,
            art.white(if (dk) 0.05f else 0.10f), art.white(if (dk) 0.09f else 0.16f), art.white(if (dk) 0.40f else 0.72f), 0.70f,
        )
        val bounce = Fill.linear(
            0f, r * 0.10f, 0f, r,
            Rgb.alpha(th.accentLight, 0f), Rgb.alpha(th.accentLight, if (dk) 0.34f else 0.55f),
        )
        val liquid = Fill.linear(
            0f, -r, 0f, r,
            Rgb.alpha(th.accentLight, 0.97f), Rgb.alpha(th.accent, 0.97f), Rgb.alpha(th.accentDeep, 1f), 0.38f,
        )
        val liquidBack = Fill.linear(
            0f, -r, 0f, r,
            Rgb.alpha(th.accentLight, 0.55f), Rgb.alpha(th.accent, 0.55f), Rgb.alpha(th.accentDeep, 0.6f), 0.38f,
        )
        val liquidErr = Fill.linear(
            0f, -r, 0f, r,
            Rgb.alpha(ERR_LIGHT, 0.97f), Rgb.alpha(ERR_MID, 0.97f), Rgb.alpha(ERR_DEEP, 1f), 0.38f,
        )
        val rim = Fill.linear(-r * 0.75f, -r * 0.75f, r * 0.75f, r * 0.75f, art.white(0.96f), Rgb.alpha(th.accent, 0.62f))
        val shine = Fill.linear(0f, -1f, 0f, 1f, art.white(0.88f), art.white(0.05f))
        val crescent = GPath().arc(0f, 0f, r * 0.86f, r * 0.86f, 38f, 104f, false)
        val wave = GPath()
        val wave2 = GPath()
    }

    private val orbs = LongCache<OrbStyle>(6)

    private val bx = floatArrayOf(-0.48f, -0.16f, 0.26f, 0.52f, -0.04f, 0.12f)
    private val bs = floatArrayOf(0.55f, 0.80f, 0.45f, 0.65f, 1.00f, 0.38f)
    private val bo = floatArrayOf(0.00f, 0.31f, 0.57f, 0.82f, 0.16f, 0.68f)
    private val br = floatArrayOf(2.4f, 1.7f, 3.0f, 1.9f, 1.5f, 2.6f)

    private fun fillWave(p: GPath, r: Float, yLevel: Float, amp: Float, phase: Float, cycles: Float) {
        p.reset()
        val n = 28
        val x0 = -r - 3f
        val x1 = r + 3f
        for (i in 0..n) {
            val u = i / n.toFloat()
            val x = x0 + (x1 - x0) * u
            val y = yLevel + amp * sin(2.0 * PI * cycles * u + phase).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.lineTo(x1, r + 3f).lineTo(x0, r + 3f).close()
    }

    /**
     * Ana düğme: cam küre ve içinde yükselen sıvı.
     * [level] sıvı seviyesi (0..1), [phase] dalga evresi (radyan), [glow] dış ışıma (0..1),
     * [error] hata rengine karışım (0..1), [press] basılı parlama (0..1).
     */
    open fun orb(g: Gfx, cx: Float, cy: Float, r: Float, level: Float, phase: Float, glow: Float, error: Float, press: Float) {
        val k = key(r, r, 0f)
        var st = orbs[k]
        if (st == null) {
            st = OrbStyle(r, this); orbs[k] = st
        }
        val lv = level.coerceIn(0f, 1f)
        g.save()
        g.translate(cx, cy)

        // zemin gölgesi
        g.save(); g.translate(0f, r * 1.07f); g.scale(r * 0.92f, r * 0.15f)
        g.paint(st.ground); g.circle(0f, 0f, 1f); g.restore()

        if (glow > 0.01f) { g.save(); g.alpha(glow.coerceIn(0f, 1f)); g.paint(st.glow); g.circle(0f, 0f, r * 1.75f); g.restore() }

        // cam gövde
        g.paint(st.glass); g.circle(0f, 0f, r)
        g.paint(st.bounce); g.circle(0f, 0f, r)

        // sıvı (kürenin içine kırpılır)
        if (lv > 0.012f) {
            val yLevel = r - 2f * r * lv
            val edge = min(1f, min(lv * 5f, (1f - lv) * 5f))
            val amp = 3.6f * edge
            g.save()
            g.clipCircle(0f, 0f, r - 1.2f)
            fillWave(st.wave2, r, yLevel - 1.5f, amp * 0.8f, phase * 0.8f + 2.1f, 1.2f)
            fillWave(st.wave, r, yLevel, amp, phase, 1.5f)
            g.paint(st.liquidBack); g.path(st.wave2)
            if (error < 0.999f) { g.save(); g.alpha(1f - error); g.paint(st.liquid); g.path(st.wave); g.restore() }
            if (error > 0.001f) { g.save(); g.alpha(error); g.paint(st.liquidErr); g.path(st.wave); g.restore() }
            // yüzey çizgisi
            g.strokeWidth(1.6f)
            g.paint(white(0.55f)); g.strokePath(st.wave)
            // sıvı içinde yükselen minik baloncuklar
            if (lv > 0.2f && r >= 30f) {
                val bottom = r * 0.86f
                for (i in bx.indices) {
                    val f = (((phase / (2f * PI.toFloat())) * bs[i] + bo[i]) % 1f + 1f) % 1f
                    val top = yLevel + 6f
                    val y = bottom - f * (bottom - top)
                    val hw = max(0f, sqrt(max(0f, (r - 4f) * (r - 4f) - y * y)) - br[i])
                    val x = (bx[i] * r + 2f * sin(phase * 1.3f + i)).coerceIn(-hw, hw)
                    val fade = min(1f, min(f * 6f, (1f - f) * 6f))
                    g.paint(white(0.42f * fade)); g.circle(x, y, br[i])
                    g.paint(white(0.85f * fade)); g.circle(x - br[i] * 0.3f, y - br[i] * 0.3f, br[i] * 0.34f)
                }
            }
            g.restore()
        }

        // cam kenar halkaları
        g.strokeWidth(2.4f)
        g.paint(st.rim); g.strokeCircle(0f, 0f, r - 1.2f)
        g.strokeWidth(1f)
        g.paint(white(if (dark) 0.14f else 0.30f)); g.strokeCircle(0f, 0f, r - 5f)
        // alt yansıma (yay)
        g.strokeWidth(3.2f)
        g.paint(white(if (dark) 0.22f else 0.45f)); g.strokePath(st.crescent)
        // üst parlama
        g.save(); g.translate(-r * 0.20f, -r * 0.58f); g.rotate(-16f); g.scale(r * 0.56f, r * 0.30f)
        g.paint(st.shine); g.circle(0f, 0f, 1f); g.restore()

        if (press > 0f) { g.save(); g.alpha(press); g.paint(white(0.22f)); g.circle(0f, 0f, r); g.restore() }
        g.restore()

        // güç simgesi
        val mix = Easing.clamp01((lv - 0.38f) / 0.20f)
        val off = if (dark) theme.accentLight else theme.controlDeep
        val isz = r * 0.62f
        Icons.draw(g, Icon.POWER, cx, cy + r * 0.04f + 1.6f, isz, Rgb.alpha(theme.shadow, 0.30f * mix), 2.5f)
        Icons.draw(g, Icon.POWER, cx, cy + r * 0.04f, isz, Rgb.lerp(off, Rgb.WHITE, mix), 2.5f)
    }

    // ------------------------------------------------------------------ anahtar, kaydırıcı, segment

    protected val knobFill = Fill.radial(-0.3f, -0.4f, 1.4f, white(1f), Rgb.lerp(Rgb.WHITE, theme.accentLight, 0.30f), Rgb.lerp(Rgb.WHITE, theme.accent, 0.42f), 0.55f)
    private val trackOn = LongCache<Fill>(12)

    protected fun onFill(h: Float): Fill {
        val k = key(1f, h, 1f)
        var f = trackOn[k]
        if (f == null) { f = Fill.linear(0f, 0f, 0f, h, theme.control, theme.controlDeep); trackOn[k] = f }
        return f
    }

    private val trackIn = LongCache<Fill>(12)

    protected fun insetFill(h: Float): Fill {
        val k = key(1f, h, 2f)
        var f = trackIn[k]
        if (f == null) {
            f = Fill.linear(0f, 0f, 0f, h, Rgb.alpha(theme.shadow, if (dark) 0.55f else 0.34f), Rgb.alpha(theme.shadow, if (dark) 0.18f else 0.12f))
            trackIn[k] = f
        }
        return f
    }

    /** Parlak küre düğme (anahtarın ve kaydırıcının tutamacı). */
    protected fun knob(g: Gfx, cx: Float, cy: Float, r: Float, press: Float) {
        g.paint(Rgb.alpha(theme.shadow, if (dark) 0.35f else 0.22f)); g.circle(cx, cy + 1.6f, r + 0.6f)
        g.save(); g.translate(cx, cy); g.scale(r, r)
        g.paint(knobFill); g.circle(0f, 0f, 1f)
        g.restore()
        g.strokeWidth(1f)
        g.paint(white(0.95f)); g.strokeCircle(cx, cy, r - 0.5f)
        g.paint(white(0.75f)); g.oval(cx - r * 0.55f, cy - r * 0.78f, cx + r * 0.55f, cy - r * 0.18f)
        if (press > 0f) { g.save(); g.alpha(press); g.paint(Rgb.alpha(theme.accent, 0.25f)); g.circle(cx, cy, r); g.restore() }
    }

    /** Açma/kapama anahtarı. [on] 0..1 (animasyonlu). Boyut (l,t) ile (w,h). */
    open fun switch(g: Gfx, l: Float, t: Float, w: Float, h: Float, on: Float, press: Float) {
        g.save()
        g.translate(l, t)
        g.paint(insetFill(h)); g.roundRect(0f, 0f, w, h, h / 2f)
        if (on > 0.001f) {
            g.save(); g.alpha(on)
            g.paint(onFill(h)); g.roundRect(0f, 0f, w, h, h / 2f)
            g.paint(white(0.28f)); g.roundRect(1.5f, 1.2f, w - 1.5f, h * 0.5f, h / 2f - 1.2f)
            g.restore()
        }
        g.strokeWidth(1.2f)
        g.paint(white(if (dark) 0.40f else 0.85f)); g.strokeRoundRect(0.6f, 0.6f, w - 0.6f, h - 0.6f, h / 2f - 0.6f)
        val kr = h / 2f - 3.2f + press * 0.8f
        knob(g, h / 2f + (w - h) * on.coerceIn(0f, 1f), h / 2f, kr, press)
        g.restore()
    }

    /** Yatay kaydırıcı: (l, cy) sol-orta, genişlik [w], değer [v] 0..1. Tutamaç merkezi l+12 ile l+w-12 arasında gezer. */
    open fun slider(g: Gfx, l: Float, cy: Float, w: Float, v: Float, press: Float) {
        val th = 8f
        val top = cy - th / 2f
        val kx = l + 12f + (w - 24f) * v.coerceIn(0f, 1f)
        g.save()
        g.translate(l, top)
        g.paint(insetFill(th)); g.roundRect(0f, 0f, w, th, th / 2f)
        val fw = (kx - l).coerceAtLeast(th)
        g.paint(onFill(th)); g.roundRect(0f, 0f, fw, th, th / 2f)
        g.paint(white(0.30f)); g.roundRect(1f, 0.8f, max(1.5f, fw - 1f), th * 0.5f, th / 2f - 0.8f)
        g.strokeWidth(1f)
        g.paint(white(if (dark) 0.35f else 0.80f)); g.strokeRoundRect(0.5f, 0.5f, w - 0.5f, th - 0.5f, th / 2f - 0.5f)
        g.restore()
        knob(g, kx, cy, 12f + press * 1.5f, press)
    }

    /** Segmentli seçici: [pos] seçili parçanın (kesirli, animasyonlu) sırası, [n] parça sayısı. */
    open fun segmented(g: Gfx, l: Float, t: Float, r: Float, b: Float, n: Int, pos: Float) {
        val w = r - l
        val h = b - t
        g.save()
        g.translate(l, t)
        g.paint(insetFill(h)); g.roundRect(0f, 0f, w, h, h / 2f)
        g.strokeWidth(1.2f)
        g.paint(white(if (dark) 0.35f else 0.80f)); g.strokeRoundRect(0.6f, 0.6f, w - 0.6f, h - 0.6f, h / 2f - 0.6f)
        val inset = 3f
        val sw = (w - inset * 2f) / n
        val x = inset + sw * pos.coerceIn(0f, (n - 1).toFloat())
        g.restore()
        pill(g, l + x, t + inset, l + x + sw, b - inset, 0f, 0.6f)
    }

    // ------------------------------------------------------------------ küçük parçalar

    /** Gecikme çubukları: [level] 0..4. */
    /**
     * Hız çubukları. [colored] açıksa dolu çubuklar hıza göre renklenir (4-3: yeşil, 2: sarı, 1: kırmızı); renkler açık ve
     * koyu temada cam üzerinde ayrı ayrı okunaklı seçilmiştir. Renk tek başına anlam taşımaz: çubuk sayısı aynı bilgiyi verir.
     */
    open fun bars(g: Gfx, x: Float, bottom: Float, level: Int, active: Boolean, colored: Boolean = false) {
        val on = when {
            colored && level >= 3 -> if (dark) 0xFF5BD47A.toInt() else 0xFF1E7F3A.toInt()
            colored && level == 2 -> if (dark) 0xFFF2B544.toInt() else 0xFF9A5B00.toInt()
            colored && level == 1 -> if (dark) 0xFFFF8A7A.toInt() else 0xFFB3261E.toInt()
            active -> theme.link
            else -> Rgb.alpha(theme.textSoft, 0.85f)
        }
        val off = Rgb.alpha(theme.textSoft, 0.22f)
        for (i in 0 until 4) {
            val bh = 5f + i * 3f
            g.paint(if (i < level) on else off)
            g.roundRect(x + i * 5.2f, bottom - bh, x + i * 5.2f + 3.4f, bottom, 1.4f)
        }
    }

    /** Tema örneği: gökyüzü gradyanlı küçük küre. [t] null ise "otomatik" (yarı açık, yarı koyu). */
    open fun swatch(g: Gfx, cx: Float, cy: Float, r: Float, t: AeroTheme?, selected: Float) {
        g.paint(Rgb.alpha(theme.shadow, if (dark) 0.40f else 0.20f)); g.circle(cx, cy + 1.8f, r + 0.8f)
        g.save()
        g.translate(cx, cy)
        val sz = (r * 2f).toInt()
        if (t != null) {
            g.paint(swatchFill(t.id.hashCode() * 31 + t.skyMid, sz, t)); g.circle(0f, 0f, r)   // renk de anahtarda: dinamik tema değişebilir
        } else {
            val a = Themes.aqua
            val n = Themes.night
            val half1 = swatchHalf1
            val half2 = swatchHalf2
            if (half1.isEmpty) {
                half1.arc(0f, 0f, r, r, 135f, 180f, false).close()
                half2.arc(0f, 0f, r, r, 315f, 180f, false).close()
            }
            g.paint(swatchFill(1, sz, a)); g.path(half1)
            g.paint(swatchFill(2, sz, n)); g.path(half2)
        }
        val ac = t ?: Themes.aqua
        g.paint(swatchOrb(ac)); g.save(); g.translate(0f, r * 0.12f); g.scale(r * 0.46f, r * 0.46f); g.circle(0f, 0f, 1f); g.restore()
        g.paint(white(0.55f)); g.oval(-r * 0.62f, -r * 0.86f, r * 0.18f, -r * 0.34f)
        g.strokeWidth(1.4f)
        g.paint(white(0.95f)); g.strokeCircle(0f, 0f, r - 0.7f)
        g.restore()
        if (selected > 0.001f) {
            g.save(); g.alpha(selected)
            g.strokeWidth(2.4f)
            g.paint(theme.link); g.strokeCircle(cx, cy, r + 4.2f)
            g.restore()
        }
    }

    private val swatchFills = LongCache<Fill>(24)

    private fun swatchFill(idHash: Int, sz: Int, th: AeroTheme): Fill {
        val k = (idHash.toLong() shl 32) or (sz.toLong() and 0xFFFFFFFFL)
        var f = swatchFills[k]
        if (f == null) {
            val r = sz / 2f
            f = Fill.linear(-r * 0.7f, -r, r * 0.7f, r, th.skyTop, th.skyMid, th.skyBottom, 0.5f)
            swatchFills[k] = f
        }
        return f
    }
    private val swatchHalf1 = GPath()
    private val swatchHalf2 = GPath()
    private val swatchOrbs = HashMap<String, Fill>()

    private fun swatchOrb(t: AeroTheme): Fill =
        swatchOrbs.getOrPut(t.id) { Fill.linear(0f, -1f, 0f, 1f, t.accentLight, t.accent, t.accentDeep, 0.5f) }

    /** Vurgu renkli simgeler ve çizgiler için okunaklı renk (koyu temada açık, açık temada koyu). */
    val ink: Int get() = theme.link

    /** Satır başı simge diski: cam gibi parlak, vurgu renkli yuvarlak. */
    open fun iconDisc(g: Gfx, cx: Float, cy: Float, r: Float) {
        g.save(); g.translate(cx, cy); g.scale(r, r)
        g.paint(discFill); g.circle(0f, 0f, 1f)
        g.restore()
        g.strokeWidth(1f)
        g.paint(white(if (dark) 0.35f else 0.85f)); g.strokeCircle(cx, cy, r - 0.5f)
        g.paint(white(if (dark) 0.14f else 0.45f)); g.oval(cx - r * 0.62f, cy - r * 0.92f, cx + r * 0.62f, cy - r * 0.18f)
    }

    private val discFill = Fill.linear(0f, -1f, 0f, 1f, Rgb.alpha(theme.accentLight, if (dark) 0.34f else 0.62f), Rgb.alpha(theme.accent, if (dark) 0.24f else 0.34f))

    /** Küçük onay rozeti (bağlı sunucu işareti). */
    open fun badge(g: Gfx, cx: Float, cy: Float, r: Float) {
        g.paint(Rgb.alpha(theme.shadow, 0.25f)); g.circle(cx, cy + 1f, r + 0.6f)
        g.paint(theme.control); g.circle(cx, cy, r)
        g.strokeWidth(1f); g.paint(white(0.9f)); g.strokeCircle(cx, cy, r - 0.5f)
        Icons.draw(g, Icon.CHECK, cx, cy, r * 1.35f, Rgb.WHITE, 2.6f)
    }

    private var barFill: Fill? = null
    private var barShadow: Fill? = null
    private var barH = 0f
    private var barSky = 0f

    /**
     * Üst çubuk zemini: gökyüzü renginde, neredeyse opak bir cam şerit. İçerik başlığın altından geçerken
     * yazılar birbirine karışmasın diye. [a] 0..1 (kaydırdıkça belirir), [skyH] gökyüzünün (ekranın) yüksekliği.
     */
    open fun bar(g: Gfx, w: Float, h: Float, a: Float, skyH: Float) {
        if (a <= 0.01f) return
        var f = barFill
        if (f == null || barH != h || barSky != skyH) {
            val t0 = Rgb.over(tint(if (dark) 0.10f else 0.34f), theme.skyAt(0f))
            val t1 = Rgb.over(tint(if (dark) 0.06f else 0.20f), theme.skyAt((h / skyH).coerceIn(0f, 1f)))
            f = Fill.linear(0f, 0f, 0f, h, Rgb.alpha(t0, 1f), Rgb.alpha(t1, 1f))
            barFill = f
            barShadow = Fill.linear(0f, h, 0f, h + 10f, Rgb.alpha(theme.shadow, if (dark) 0.30f else 0.13f), Rgb.alpha(theme.shadow, 0f))
            barH = h; barSky = skyH
        }
        g.save(); g.alpha(a)
        g.paint(barShadow!!); g.rect(0f, h, w, h + 10f)
        g.paint(f); g.rect(0f, 0f, w, h)
        g.paint(white(if (dark) 0.22f else 0.70f)); g.rect(0f, h - 1f, w, h)
        g.restore()
    }

    /** Alt sayfanın üstündeki küçük tutamaç. */
    open fun grabber(g: Gfx, cx: Float, y: Float) {
        g.paint(white(if (dark) 0.40f else 0.85f)); g.roundRect(cx - 18f, y, cx + 18f, y + 4.5f, 2.25f)
    }

    companion object {
        /** Hata durumunda sıvı renkleri (tema bağımsız, kırmızımsı). */
        const val ERR_LIGHT: Int = 0xFF8F72 or (0xFF shl 24)
        const val ERR_MID: Int = 0xE5533D or (0xFF shl 24)
        const val ERR_DEEP: Int = 0xB3342A or (0xFF shl 24)
    }
}
