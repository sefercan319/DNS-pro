package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

/** Animasyon eğrileri. Hepsi 0..1 aralığını 0..1'e eşler. */
object Easing {
    fun clamp01(t: Float): Float = if (t < 0f) 0f else if (t > 1f) 1f else t

    fun outCubic(t: Float): Float {
        val u = 1f - clamp01(t)
        return 1f - u * u * u
    }

    fun inOutCubic(t: Float): Float {
        val x = clamp01(t)
        return if (x < 0.5f) 4f * x * x * x else 1f - (-2f * x + 2f).pow(3) / 2f
    }

    /** Hafif geri sekmeli çıkış (düğme bırakma hissi). */
    fun outBack(t: Float, s: Float = 1.2f): Float {
        val x = clamp01(t) - 1f
        return 1f + (s + 1f) * x * x * x + s * x * x
    }
}

/** Arka plandaki yükselen kabarcıklar. Koordinatlar 0..1 (y: 0 üst, 1 alt), yarıçap ve salınım dp cinsinden. */
class BubbleField(seed: Long = 11L) {
    class Bubble {
        var x = 0f
        var y = 0f
        var r = 0f
        var speed = 0f
        var phase = 0f
        var sway = 0f
        var alpha = 1f
    }

    private val rnd = java.util.Random(seed)
    private val list = ArrayList<Bubble>()
    val items: List<Bubble> get() = list

    /** Davranış: RISE kabarcık (varsayılan), FALL yaprak gibi süzülerek düşen, TWINKLE yerinde parlayıp sönen. */
    var mode: ParticleMode = ParticleMode.RISE
        private set

    fun setMode(m: ParticleMode) {
        if (m == mode) return
        mode = m
        for (b in list) reset(b, initial = true)
    }

    fun setCount(n: Int) {
        while (list.size > n) list.removeAt(list.size - 1)
        while (list.size < n) list.add(Bubble().also { reset(it, initial = true) })
    }

    private fun reset(b: Bubble, initial: Boolean) {
        when (mode) {
            ParticleMode.FALL -> {
                b.x = rnd.nextFloat()
                b.y = if (initial) rnd.nextFloat() else -0.08f - rnd.nextFloat() * 0.25f
                b.r = 7f + rnd.nextFloat() * 9f
                b.speed = 0.020f + rnd.nextFloat() * 0.030f
                b.phase = rnd.nextFloat() * (2f * PI.toFloat())
                b.sway = 14f + rnd.nextFloat() * 22f
                b.alpha = 0.55f + rnd.nextFloat() * 0.45f
                return
            }
            ParticleMode.TWINKLE -> {
                b.x = rnd.nextFloat()
                b.y = rnd.nextFloat()
                b.r = 3.5f + rnd.nextFloat() * rnd.nextFloat() * 9f
                b.speed = 0.6f + rnd.nextFloat() * 1.0f          // parıltı hızı (evre ilerlemesi)
                b.phase = rnd.nextFloat() * (2f * PI.toFloat())
                b.sway = 0f
                b.alpha = 0.6f + rnd.nextFloat() * 0.4f
                return
            }
            else -> {}
        }
        b.x = rnd.nextFloat()
        b.y = if (initial) rnd.nextFloat() else 1.06f + rnd.nextFloat() * 0.25f
        b.r = 5f + rnd.nextFloat() * rnd.nextFloat() * 30f      // çoğu küçük, birkaçı büyük
        b.speed = 0.018f + rnd.nextFloat() * 0.04f
        b.phase = rnd.nextFloat() * (2f * PI.toFloat())
        b.sway = 4f + rnd.nextFloat() * 10f
        b.alpha = 0.5f + rnd.nextFloat() * 0.5f
    }

    fun update(dtSec: Float, speedScale: Float = 1f) {
        val dt = dtSec.coerceIn(0f, 0.1f)
        var i = 0
        if (mode == ParticleMode.FALL) {
            while (i < list.size) {
                val b = list[i++]
                b.y += b.speed * speedScale * dt
                b.phase += dt * 0.7f
                if (b.y > 1.1f) reset(b, initial = false)
            }
            return
        }
        if (mode == ParticleMode.TWINKLE) {
            while (i < list.size) { val b = list[i++]; b.phase += dt * b.speed }
            return
        }
        while (i < list.size) {
            val b = list[i++]
            b.y -= b.speed * speedScale * dt
            b.phase += dt * 0.9f
            if (b.y < -0.12f) reset(b, initial = false)
        }
    }
}

enum class OrbState { OFF, CONNECTING, ON, ERROR }

object OrbMath {
    /** Küre içindeki sıvı seviyesi hedefi (0..1). */
    fun targetLevel(s: OrbState): Float = when (s) {
        OrbState.OFF -> 0f
        OrbState.CONNECTING -> 0.40f
        OrbState.ON -> 0.66f
        OrbState.ERROR -> 0.10f
    }

    /** Hedefe üstel yaklaşım: kare hızından bağımsız, asla aşmaz. */
    fun approach(current: Float, target: Float, dtSec: Float, rate: Float = 5f): Float =
        current + (target - current) * (1f - exp(-rate * dtSec.coerceAtLeast(0f)))

    fun settled(current: Float, target: Float): Boolean = abs(current - target) < 0.002f

    /** Sıvı yüzeyindeki dalga: [x01] 0..1 genişlik konumu, dönüş -amp..amp. */
    fun wave(x01: Float, phase: Float, amp: Float): Float =
        amp * sin((2.0 * PI * 1.5 * x01 + phase).toFloat())
}
