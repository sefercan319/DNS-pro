package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Gerçek Frutiger Aero: gökyüzü (seçili renk temasından), bulutlar, güneş ışınları, yeşil çimen tepeler ve rüzgârda
 * sallanan çim; üzerinde cam kartlar, cam damlaları ve jel düğmeler. Çim her temada yeşildir (anlamı çimen).
 * Koyu temada gece çimeni ve yıldızlar. Çim sallanması yalnızca hareket açıkken kare kare hesaplanır.
 */
class AeroSkyArt(theme: AeroTheme, glass: Float) : AeroArt(theme, glass) {
    override val style: UiStyle get() = UiStyle.AERO
    override val liveSky: Boolean get() = true
    override val motion: StyleMotion = StyleMotion(PageMotion.SLIDE, 0.42f, 0.03f, 0.5f)

    // ------------------------------------------------------------------ manzara

    private class Scenery(val w: Float, val h: Float, val dark: Boolean) {
        private fun c(v: Long) = v.toInt()

        val farFill: Fill
        val midFill: Fill
        val nearFill: Fill
        val far = GPath()
        val mid = GPath()
        val near = GPath()
        val haze: Fill
        val bloom = Fill.radial(w * 0.18f, h * 0.02f, w * 1.15f,
            Rgb.alpha(Rgb.WHITE, if (dark) 0.06f else 0.70f), Rgb.alpha(Rgb.WHITE, if (dark) 0.02f else 0.24f), Rgb.alpha(Rgb.WHITE, 0f), 0.40f)
        val ray = Fill.linear(w * 0.18f, h * 0.02f, w * 0.75f, h * 0.60f,
            Rgb.alpha(Rgb.WHITE, if (dark) 0f else 0.26f), Rgb.alpha(Rgb.WHITE, 0f))
        val rays = Array(3) { GPath() }

        // çim
        val count = 130
        val bx = FloatArray(count); val by = FloatArray(count); val bh = FloatArray(count); val bw = FloatArray(count)
        val lean = FloatArray(count); val ph = FloatArray(count); val shade = IntArray(count)
        val bladeFill = Array(3) { i -> Fill.linear(0f, h * 0.74f, 0f, h + 10f, bladeTip(i), bladeBase(i)) }
        val bladePath = Array(3) { GPath() }

        private fun bladeTip(i: Int): Int = if (dark) arrayOf(c(0xFF4DBB6A), c(0xFF35945A), c(0xFF247045))[i]
            else arrayOf(c(0xFFB5EE6A), c(0xFF78D44E), c(0xFF4DB345))[i]
        private fun bladeBase(i: Int): Int = if (dark) arrayOf(c(0xFF1E6B3E), c(0xFF165433), c(0xFF0F3D26))[i]
            else arrayOf(c(0xFF3AA33A), c(0xFF2C8F33), c(0xFF1F7A2B))[i]

        // bulutlar: (merkez x, merkez y, ölçek)
        val clouds = arrayOf(floatArrayOf(0.30f, 0.15f, 1.0f), floatArrayOf(0.80f, 0.27f, 0.8f), floatArrayOf(0.52f, 0.42f, 0.6f))
        val puff = Fill.radial(0f, 0f, 1f, Rgb.alpha(Rgb.WHITE, 0.92f), Rgb.alpha(Rgb.WHITE, 0.55f), Rgb.alpha(Rgb.WHITE, 0f), 0.55f)
        val starX = FloatArray(14); val starY = FloatArray(14); val starR = FloatArray(14)

        fun hillY(x: Float, base: Float, a1: Float, f1: Float, p1: Float, a2: Float, f2: Float, p2: Float): Float =
            base + a1 * sin(x * f1 + p1) + a2 * sin(x * f2 + p2)

        private fun hill(p: GPath, base: Float, a1: Float, f1: Float, p1: Float, a2: Float, f2: Float, p2: Float) {
            p.reset()
            val n = 36
            for (i in 0..n) {
                val x = -8f + (w + 16f) * i / n
                val y = hillY(x, base, a1, f1, p1, a2, f2, p2)
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            p.lineTo(w + 8f, h + 8f).lineTo(-8f, h + 8f).close()
        }

        init {
            val k = 2f * PI.toFloat() / w
            hill(far, h * 0.665f, h * 0.022f, k * 1.3f, 0.6f, h * 0.012f, k * 3.1f, 1.7f)
            hill(mid, h * 0.735f, h * 0.026f, k * 1.0f, 2.2f, h * 0.012f, k * 2.6f, 0.4f)
            hill(near, h * 0.815f, h * 0.024f, k * 1.2f, 4.1f, h * 0.010f, k * 3.3f, 2.9f)
            farFill = if (dark) Fill.linear(0f, h * 0.62f, 0f, h * 0.76f, c(0xFF1C4E4A), c(0xFF133B3B))
                else Fill.linear(0f, h * 0.62f, 0f, h * 0.76f, c(0xFF9ADCA6), c(0xFF6FC58A))
            midFill = if (dark) Fill.linear(0f, h * 0.70f, 0f, h * 0.85f, c(0xFF1A5C3B), c(0xFF10432C))
                else Fill.linear(0f, h * 0.70f, 0f, h * 0.85f, c(0xFF6FD064), c(0xFF3FA13F))
            nearFill = if (dark) Fill.linear(0f, h * 0.78f, 0f, h, c(0xFF165232), c(0xFF0A2C1B))
                else Fill.linear(0f, h * 0.78f, 0f, h, c(0xFF4CB542), c(0xFF1D7A2A))
            haze = Fill.linear(0f, h * 0.48f, 0f, h * 0.70f, Rgb.alpha(Rgb.WHITE, 0f), Rgb.alpha(Rgb.WHITE, if (dark) 0.05f else 0.42f))

            // güneş ışınları
            val sx = w * 0.18f; val sy = h * 0.02f
            val spread = floatArrayOf(0.30f, 0.56f, 0.82f)
            for (i in 0 until 3) {
                val a0 = spread[i] * w * 1.4f
                rays[i].moveTo(sx, sy).lineTo(a0, h * 0.78f).lineTo(a0 + w * 0.16f, h * 0.78f).close()
            }

            val rnd = java.util.Random(7L)
            val crestMin = h * 0.78f
            for (i in 0 until count) {
                bx[i] = rnd.nextFloat() * (w + 20f) - 10f
                val t = rnd.nextFloat()
                by[i] = crestMin + (h - crestMin + 6f) * t * t * 0.9f + rnd.nextFloat() * 6f
                val depth = ((by[i] - crestMin) / (h - crestMin)).coerceIn(0f, 1f)
                bh[i] = (16f + 34f * depth) * (0.75f + 0.6f * rnd.nextFloat())
                bw[i] = 2.6f + 3.4f * depth
                lean[i] = (rnd.nextFloat() - 0.5f) * 8f
                ph[i] = rnd.nextFloat() * 6.28f
                shade[i] = rnd.nextInt(3)
            }
            // yakındakiler sonra çizilsin (üstte)
            val order = (0 until count).sortedBy { by[it] }
            fun reorder(a: FloatArray) { val b = a.copyOf(); for (i in 0 until count) a[i] = b[order[i]] }
            reorder(bx); reorder(by); reorder(bh); reorder(bw); reorder(lean); reorder(ph)
            val sh = shade.copyOf(); for (i in 0 until count) shade[i] = sh[order[i]]

            for (i in starX.indices) { starX[i] = rnd.nextFloat() * w; starY[i] = rnd.nextFloat() * h * 0.55f; starR[i] = 0.6f + rnd.nextFloat() * 1.4f }
        }

        fun buildBlades(live: Boolean, time: Float) {
            for (p in bladePath) p.reset()
            for (i in 0 until count) {
                val sway = if (live) (sin(time * 1.5f + ph[i] + bx[i] * 0.011f) * 0.6f + sin(time * 0.6f + bx[i] * 0.004f) * 0.4f) else 0f
                val tipX = bx[i] + lean[i] + sway * bh[i] * 0.30f
                val tipY = by[i] - bh[i]
                val p = bladePath[shade[i]]
                val half = bw[i] / 2f
                p.moveTo(bx[i] - half, by[i] + 2f)
                p.quadTo(bx[i] - half * 0.3f + (tipX - bx[i]) * 0.35f, by[i] - bh[i] * 0.55f, tipX, tipY)
                p.quadTo(bx[i] + half * 0.3f + (tipX - bx[i]) * 0.35f, by[i] - bh[i] * 0.55f, bx[i] + half, by[i] + 2f)
                p.close()
            }
        }
    }

    private fun scene(w: Float, h: Float): Scenery {
        var s = if (dark) sceneDark else sceneLight
        if (s == null || s.w != w || s.h != h) { s = Scenery(w, h, dark); if (dark) sceneDark = s else sceneLight = s }
        return s
    }

    private var skyBase: Fill? = null
    private var skyBaseW = 0f
    private var skyBaseH = 0f

    override fun sky(g: Gfx, w: Float, h: Float) = skyFrame(g, w, h, false, 0f)

    override fun skyFrame(g: Gfx, w: Float, h: Float, live: Boolean, time: Float) {
        val s = scene(w, h)
        var base = skyBase
        if (base == null || skyBaseW != w || skyBaseH != h) {
            base = Fill.linear(0f, 0f, 0f, h * 0.72f, theme.skyTop, theme.skyMid, theme.skyBottom, AeroTheme.SKY_MID_POS)
            skyBase = base; skyBaseW = w; skyBaseH = h
        }
        g.paint(base); g.rect(0f, 0f, w, h)
        g.paint(s.bloom); g.rect(0f, 0f, w, h)
        if (!dark) {
            for (r in s.rays) { g.paint(s.ray); g.path(r) }
            // bulutlar (yavaşça sürüklenir)
            val drift = if (live) (time * 2.2f) % (w + 240f) else 0f
            for (cl in s.clouds) {
                val sc = cl[2] * w * 0.075f
                var cx = cl[0] * w + drift * cl[2]
                if (cx > w + sc * 3f) cx -= w + sc * 6f
                val cy = cl[1] * h
                g.paint(s.puff)
                for (k in PUFFS) {
                    g.save(); g.translate(cx + k[0] * sc, cy + k[1] * sc); g.scale(k[2] * sc, k[2] * sc * 0.66f)
                    g.circle(0f, 0f, 1f); g.restore()
                }
            }
        } else {
            g.paint(Rgb.alpha(Rgb.WHITE, 0.75f))
            for (i in s.starX.indices) {
                val tw = if (live) 0.55f + 0.45f * sin(time * 1.1f + i * 1.7f) else 1f
                g.save(); g.alpha(tw); g.circle(s.starX[i], s.starY[i], s.starR[i]); g.restore()
            }
        }
        g.paint(s.haze); g.rect(0f, h * 0.48f, w, h * 0.70f)
        g.paint(s.farFill); g.path(s.far)
        g.paint(s.midFill); g.path(s.mid)
        g.paint(s.nearFill); g.path(s.near)
        s.buildBlades(live, time)
        for (i in 0 until 3) { g.paint(s.bladeFill[i]); g.path(s.bladePath[i]) }
    }

    // ------------------------------------------------------------------ cam damlaları

    private val dropBody = Fill.radial(0f, 0f, 1f, white(0.04f), white(0.10f), white(if (dark) 0.34f else 0.62f), 0.72f)
    private val dropShade = Fill.radial(0.35f, 0.5f, 1f, Rgb.alpha(theme.shadow, if (dark) 0.30f else 0.16f), Rgb.alpha(theme.shadow, 0f))

    private fun droplet(g: Gfx, cx: Float, cy: Float, r: Float) {
        g.save(); g.translate(cx, cy); g.scale(r, r)
        g.paint(dropShade); g.circle(0.12f, 0.22f, 1.25f)
        g.paint(dropBody); g.circle(0f, 0f, 1f)
        g.restore()
        g.strokeWidth(0.8f); g.paint(white(if (dark) 0.35f else 0.8f)); g.strokeCircle(cx, cy, r - 0.4f)
        g.paint(white(0.95f)); g.circle(cx - r * 0.38f, cy - r * 0.40f, max(0.8f, r * 0.24f))
    }

    override fun card(g: Gfx, l: Float, t: Float, r: Float, b: Float, rad: Float, selected: Float, press: Float, strong: Float, shadow: Float) {
        super.card(g, l, t, r, b, rad, selected, press, strong, shadow)
        val w = r - l
        val h = b - t
        if (w < 80f || h < 40f || strong > 0.5f) return
        val n = min(5, 1 + (h / 110f).toInt())
        var s = (w * 7f).toInt() * 31 + (h * 7f).toInt()
        for (i in 0 until n) {
            s = s * 1103515245 + 12345
            val fx = ((s ushr 8) and 0xFFFF) / 65535f
            s = s * 1103515245 + 12345
            val fy = ((s ushr 8) and 0xFFFF) / 65535f
            val rr = 2.6f + (i % 3) * 1.1f
            // sağ kenara yakın: yazılar solda
            droplet(g, l + w * (0.62f + 0.34f * fx), t + 9f + (h - 18f) * fy, rr)
        }
    }

    // ------------------------------------------------------------------ jel düğme

    private class GelStyle(val w: Float, val h: Float, art: AeroSkyArt) {
        val body = Fill.linear(0f, 0f, 0f, h, art.theme.control, art.theme.controlDeep)
        val upper = GPath()
        val upperFill = Fill.linear(0f, 0f, 0f, h * 0.5f, art.white(0.55f), art.white(0.16f))
        val glow = Fill.radial(w * 0.5f, h * 1.05f, w * 0.55f, Rgb.alpha(art.theme.accentLight, 0.75f), Rgb.alpha(art.theme.accentLight, 0f))
        val rim = Fill.linear(0f, 0f, 0f, h, art.white(0.85f), Rgb.alpha(art.theme.accentLight, 0.60f))

        init {
            val k = min(w, h) / 2f
            upper.arc(k, k, k, k, 180f, 90f, false)
            upper.lineTo(w - k, 0f)
            upper.arc(w - k, k, k, k, -90f, 90f, true)
            upper.lineTo(w, h * 0.5f)
            upper.lineTo(0f, h * 0.5f)
            upper.close()
        }
    }

    private val gels = LongCache<GelStyle>(40)

    private fun gel(g: Gfx, w: Float, h: Float, press: Float, shadow: Float) {
        val k = key(w, h, 7f)
        var st = gels[k]
        if (st == null) { st = GelStyle(w, h, this); gels[k] = st }
        if (shadow > 0f) {
            g.strokeWidth(2.2f)
            for (i in 0 until 4) {
                val f = 1f - i / 4f
                g.paint(Rgb.alpha(theme.controlDeep, (if (dark) 0.24f else 0.12f) * shadow * f * f))
                val e = 1.1f + i * 1.9f
                g.strokeRoundRect(-e, -e + 2f, w + e, h + e + 2f, h / 2f + e)
            }
        }
        g.paint(st.body); g.roundRect(0f, 0f, w, h, h / 2f)
        g.save(); g.clipRoundRect(0f, 0f, w, h, h / 2f); g.paint(st.glow); g.rect(0f, h * 0.45f, w, h); g.restore()
        g.paint(st.upperFill); g.path(st.upper)
        g.strokeWidth(1.2f)
        g.paint(st.rim); g.strokeRoundRect(0.6f, 0.6f, w - 0.6f, h - 0.6f, h / 2f - 0.6f)
        if (press > 0f) { g.save(); g.alpha(press); g.paint(Rgb.alpha(theme.shadow, 0.22f)); g.roundRect(0f, 0f, w, h, h / 2f); g.restore() }
    }

    override fun pill(g: Gfx, l: Float, t: Float, r: Float, b: Float, press: Float, shadow: Float) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        g.save(); g.translate(l, t); gel(g, w, h, press, shadow); g.restore()
    }

    override fun switch(g: Gfx, l: Float, t: Float, w: Float, h: Float, on: Float, press: Float) {
        g.save()
        g.translate(l, t)
        g.paint(insetFill(h)); g.roundRect(0f, 0f, w, h, h / 2f)
        if (on > 0.001f) { g.save(); g.alpha(on); gel(g, w, h, 0f, 0f); g.restore() }
        g.strokeWidth(1.2f)
        g.paint(white(if (dark) 0.40f else 0.85f)); g.strokeRoundRect(0.6f, 0.6f, w - 0.6f, h - 0.6f, h / 2f - 0.6f)
        knob(g, h / 2f + (w - h) * on.coerceIn(0f, 1f), h / 2f, h / 2f - 3.2f + press * 0.8f, press)
        g.restore()
    }

    // ------------------------------------------------------------------ küre: çim yansıması

    private val grassReflect = LongCache<Fill>(6)

    override fun orb(g: Gfx, cx: Float, cy: Float, r: Float, level: Float, phase: Float, glow: Float, error: Float, press: Float) {
        super.orb(g, cx, cy, r, level, phase, glow, error, press)
        if (r < 24f) return
        val f = grassReflect.get(key(r, r, 3f)) ?: Fill.linear(0f, r * 0.45f, 0f, r,
            Rgb.alpha(0xFF6FD064.toInt(), 0f), Rgb.alpha(0xFF2E9A3A.toInt(), if (dark) 0.35f else 0.50f)).also { grassReflect[key(r, r, 3f)] = it }
        g.save(); g.translate(cx, cy); g.clipCircle(0f, 0f, r - 1.6f)
        g.paint(f); g.save(); g.translate(0f, r * 1.02f); g.scale(r * 0.92f, r * 0.42f); g.circle(0f, 0f, 1f); g.restore()
        g.restore()
    }

    private companion object {
        // Manzara temadan bağımsızdır: tema geçişinde çizici her karede yenilense de yeniden kurulmaz.
        private var sceneLight: Scenery? = null
        private var sceneDark: Scenery? = null

        val PUFFS = arrayOf(
            floatArrayOf(-1.5f, 0.25f, 0.9f), floatArrayOf(-0.6f, -0.25f, 1.2f), floatArrayOf(0.5f, -0.10f, 1.1f),
            floatArrayOf(1.4f, 0.22f, 0.9f), floatArrayOf(0.0f, 0.30f, 1.3f),
        )
    }
}
