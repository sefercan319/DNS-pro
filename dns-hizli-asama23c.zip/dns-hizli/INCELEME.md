# İnceleyici için kısa rehber (insan ya da yapay zekâ)

Bu dosya, projeyi hızlı ve doğru okumak içindir. Önce bunu, sonra `OKUBENI.md` (durum ve bilinen sınırlar) ve `OZELLIKLER.md` (130 özellik, her biri nerede ve nasıl sınandı) dosyalarını oku.

## Ne bu?
Android (Kotlin), yerel `VpnService` ile yalnızca DNS sorgularını yakalayan, sunucu listesi + tek dokunuşla bağlanma + isteğe bağlı reklam/izleyici engelleme olan uygulama. **Dış bağımlılık yok.** Arayüz Android View/Compose kullanmaz; kendi çizim sahnesi (`ui/`, `core/Gfx.kt`) tek bir `SceneView` üzerine çizer.

## Dizin haritası
- `app/src/main/java/app/dnshizli/core/` — Android'siz çekirdek (JVM'de çalışır): DNS paketleri (`Packets.kt`), yönlendiriciler (`DnsForwarder.kt` düz UDP, `SecureForwarder.kt` DoT/DoH), önbellek, **engelleme motoru (`Filter.kt`)**, ayarlar ve kodlayıcı (`Settings.kt`), katalog, çizim sanatı (`Art*.kt`, `Themes.kt`), metinler (`Lang.kt` + `Tx??.kt`, 12 dil).
- `.../ui/` — model (`Model.kt`: tek durum kaynağı), sahne düğümleri, sayfalar (`Pages.kt`), pencereler (`Sheets.kt`).
- `.../platform/` — Android'e özgü: `DnsVpnService.kt` (tünel), `MainActivity.kt`, bildirim, widget, karo, açılışta bağlanma.
- `selftest/` — JVM testleri (4077 kontrol). **Gradle'a bağlı değildir, bilerek:** `run-tests.sh` Kotlin derleyicisiyle `core/` + `ui/` + `selftest/` dosyalarını derleyip düz JVM'de koşturur. APK'ya girmez.
- `tools/` — `build_filter.py` (engelleme listelerini üretir), `icons.py` (simgeleri üretir).
- `app/src/main/assets/filter/` — **ikili** engelleme listeleri (`*.bin`, "DNF1" başlıklı, sıralı 48 bitlik özetler; bkz. `Filter.kt` `FilterTier.read`), `protected.txt`, `KAYNAKLAR.txt` (lisanslar).
- `app/src/main/assets/wallpapers/` — hazır arka plan fotoğrafları (JPEG, ikili).
- `app/debug.keystore` — **yalnızca debug imzası**, bilerek repoda (her derleme aynı imzayla çıksın, güncelleme bozulmasın). Yayın anahtarı projede yoktur; `.gitignore` onu dışarıda tutar.

## İkili dosyalar hakkında
`*.bin`, `*.jpg`, `*.png`, `*.keystore` metin değildir. Zip'i metin olarak okuyan bir araç bunları "bozuk" sanabilir; değildir (zip testinden geçer, başlıkları doğrudur). İnceleme için `*-inceleme.zip` sürümünde ikili dosyalar çıkarılmıştır. Bu sürümde `gradle/wrapper/gradle-wrapper.jar` da çıkarılmıştır; tam projede vardır, "Gradle wrapper eksik" bulgusu bu yüzden geçersizdir. Aynı şekilde `selftest/` testleri tam projede çalışır (filtre listeleri gerekir).

## Doğrulama
`./run-tests.sh` (kotlinc + JDK 17+ gerekir; JDK 25 ve Kotlin 2.4.20 ile de 4077 kontrol geçti) → "4077 kontrol, 0 başarısız" beklenir. Android'e özgü kısım (VPN tüneli vb.) **gerçek telefonda tam test edilmedi**; ilk sürüm bir telefonda çalıştı, sonraki aşamalar yalnızca derleme + JVM testleriyle sınandı.

## Bilinçli tasarım kararları (hata sanılmasın)
- Engelleme yalnızca DNS düzeyinde ve yalnızca bağlıyken; tarayıcının kendi güvenli DNS'i atlayabilir. Listeler çevrimiçi güncellenmez.
- Kullanıcının girdiği alan adları kaydedilmez; "Son engellenenler" yalnızca bellekte tutulur.
- Çeviriler anadili konuşanlarca denetlenmedi.
- Testlerin standart `src/test` yerine `selftest/` altında olması bilinçlidir (Android SDK'sız çalışsın diye).

## İncelemede özellikle bakılabilecek yerler
1. `core/Filter.kt`: öncelik sırası (izin > kendi engel > korunan > seviye listeleri), son ek eşleme, yanıt üretimi, canlı motor değişimi (iş parçacığı güvenliği).
2. `platform/DnsVpnService.kt`: tünel okuma döngüsü, yeniden bağlanma, yedek sunucu geçişi, kaynak sızıntıları.
3. `core/Settings.kt`: içe/dışa aktarma kodlayıcısı ve riskli değişiklik uyarıları.
4. `core/SecureForwarder.kt`: DoT/DoH zaman aşımı, bağlantı yeniden kullanımı.
Her bulgu için dosya ve satır, ve nasıl yeniden üretileceği istenir; testlerle çelişen iddialar önce `selftest/` içinde denenmelidir.
