package app.dnshizli.core

import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

data class Stats(
    val queries: Long = 0,
    val cacheHits: Long = 0,
    val forwarded: Long = 0,
    val answered: Long = 0,
    val retries: Long = 0,
    val timeouts: Long = 0,
    val dropped: Long = 0,
    val resets: Long = 0,
    val latencySumMs: Long = 0,
    /** Birincil sunucu cevap vermeyince yedeğe kalıcı geçiş sayısı. */
    val failovers: Long = 0,
    /** Şu an yedek (ikinci) sunucu birincil olarak kullanılıyor mu? */
    val backup: Boolean = false,
    /** Engelleme cevabı olduğu tahmin edilen cevaplar (0.0.0.0 / :: ya da "engellendi" hata kodu). */
    val blocked: Long = 0,
    /** Sunucuya gönderilen / sunucudan alınan DNS verisi (bayt; şifreleme ve başlıklar hariç). */
    val bytesUp: Long = 0,
    val bytesDown: Long = 0,
    /** Aynı anda bekleyen özdeş bir sorguya eklenen (ağa ayrıca gönderilmeyen) sorgular. */
    val merged: Long = 0,
    /** Kimliği tuttuğu halde soru bölümü uyuşmadığı için atılan (sahte ya da bozuk) cevaplar. */
    val rejected: Long = 0,
    /** Şifreli bağlantıda sertifika/ad doğrulaması başarısız olan denemeler (araya girme ya da yanlış sunucu belirtisi). */
    val tlsFailures: Long = 0,
    /** Sunucu cevap vermediği için süresi dolmuş önbellekten (RFC 8767 "bayat cevap") verilen cevaplar. */
    val stale: Long = 0,
    /** Bilinen bir engel sayfası/sahte havuz adresi gösterdiği için atılan düz DNS cevapları ([BlockPages]). */
    val blockPages: Long = 0,
    /** [tlsFailures]'un içindeki, yalnızca sertifika süresi (saat) yüzünden olanlar: saldırı değil, cihaz saati sorunu. */
    val clockFailures: Long = 0,
    /** Birincil geç kalınca sorgunun iki sunucuya birden gönderildiği (yarış) sayısı. */
    val races: Long = 0,
    /** Yarışlardan ikinci sunucunun cevabının önce geldiği sayı (yarış işe yaradı). Uyum motoru yarışın bu ağdaki faydasını buna göre ölçer. */
    val raceWins: Long = 0,
) {
    /** Ağdan gelen cevapların ortalama süresi (ms). Hiç cevap yoksa 0. */
    val avgMs: Int get() = if (answered == 0L) 0 else (latencySumMs / answered).toInt()

    /** Önbellekten karşılanan sorguların yüzdesi. */
    val hitPercent: Int get() = if (queries == 0L) 0 else (cacheHits * 100 / queries).toInt()
}

/**
 * Tünelden gelen DNS sorgularını bir sunucuya ileten bileşen. İki uygulaması vardır:
 * düz DNS için [DnsForwarder] (UDP/53) ve şifreli DNS için [SecureForwarder] (DoT / DoH).
 * Servis yalnızca bu arayüzü görür.
 */
interface Forwarder : AutoCloseable {
    val proto: Proto
    fun start()

    /** Tünelden okunan ham IP paketi. Tek bir iş parçacığından (tünel okuyucu) çağrılmalıdır. */
    fun onPacket(p: ByteArray, len: Int)
    fun stats(): Stats

    /** Ağ değişti: bağlantıları yenile, önbelleği boşalt, yeniden birincil sunucuyla başla. */
    fun resetNetwork(reason: String = "ağ değişti")
    fun clearCache()

    /**
     * Son sorguların cevap süreleri (ms), eskiden yeniye, [out]'a yazılır; zaman aşımına uğrayan sorgu [LatencyRing.TIMEOUT]
     * (-1) olarak girer. Alan adı tutulmaz. Kaç değer yazıldığını döner (desteklemeyen yönlendirici 0).
     */
    fun latencies(out: IntArray): Int = 0
}

/** Tünelden gelen bir DNS sorgusunun ayrıştırılmış hali (kaynak/hedef adres ve port, istemci kimliği). IPv4 ya da IPv6. */
internal class ParsedQuery {
    var clientIp = 0
    var serverIp = 0
    var clientPort = 0
    var serverPort = 0
    var clientId = 0
    var dnsOff = 0
    var dnsLen = 0

    /** IPv6 paketi mi? Öyleyse adresler [client6] / [server6] içindedir ([clientIp] / [serverIp] kullanılmaz). */
    var isV6 = false
    val client6 = ByteArray(16)
    val server6 = ByteArray(16)

    /** Paket geçerli bir DNS sorgusuysa (IPv4 ya da IPv6) alanları doldurup true döner. Nesne ayırmaz. */
    fun parse(p: ByteArray, len: Int, maxDns: Int): Boolean {
        if (len > 0 && ((p[0].toInt() and 0xF0) shr 4) == 6) return parse6(p, len, maxDns)
        val ihl = Packets.queryHeaderLen(p, len)
        if (ihl < 0) return false
        val off = ihl + Packets.UDP_HDR
        val dl = Packets.dnsLength(p, ihl)
        if (dl < Packets.DNS_HDR || dl > maxDns) return false
        if ((p[off + 2].toInt() and 0x80) != 0) return false        // sorgu değil (QR=1)
        isV6 = false
        clientIp = Packets.i32(p, 12)
        serverIp = Packets.i32(p, 16)
        clientPort = Packets.u16(p, ihl)
        serverPort = Packets.u16(p, ihl + 2)
        clientId = Packets.u16(p, off)
        dnsOff = off
        dnsLen = dl
        return true
    }

    private fun parse6(p: ByteArray, len: Int, maxDns: Int): Boolean {
        val ihl = Packets.queryHeaderLen6(p, len)
        if (ihl < 0) return false
        val off = ihl + Packets.UDP_HDR
        val dl = Packets.dnsLength6(p)
        if (dl < Packets.DNS_HDR || dl > maxDns || off + dl > len) return false
        if ((p[off + 2].toInt() and 0x80) != 0) return false
        isV6 = true
        System.arraycopy(p, 8, client6, 0, 16)
        System.arraycopy(p, 24, server6, 0, 16)
        clientPort = Packets.u16(p, ihl)
        serverPort = Packets.u16(p, ihl + 2)
        clientId = Packets.u16(p, off)
        dnsOff = off
        dnsLen = dl
        return true
    }

    /** Önbellekten hazırlanan cevabı ([out]: DNS verisi [Packets.HDR] konumunda, istemci kimliği yazılmış) istemciye yazar. */
    fun writeCached(out: ByteArray, scratch: ByteArray, n: Int, write: (ByteArray, Int, Int) -> Unit) {
        if (isV6) Packets.writeReply6(out, scratch, Packets.nextIdent(), server6, client6, serverPort, clientPort, n, write)
        else Packets.writeReply(out, scratch, Packets.nextIdent(), serverIp, clientIp, serverPort, clientPort, n, write)
    }

    /** Cevap bekleyen istemci kaydı (adresler kopyalanır; [ParsedQuery] yeniden kullanılır). */
    fun waiter(): Waiter =
        if (isV6) Waiter(0, 0, clientPort, serverPort, clientId, client6.copyOf(), server6.copyOf())
        else Waiter(clientIp, serverIp, clientPort, serverPort, clientId)
}

/**
 * Cevabı bekleyen bir istemci (aynı soruyu soran birden çok istemci tek sorguya eklenebilir). IPv4 istemcilerde adresler
 * [clientIp] / [serverIp]; IPv6 istemcilerde [client6] / [server6] doludur.
 */
internal class Waiter(
    val clientIp: Int, val serverIp: Int, val clientPort: Int, val serverPort: Int, val clientId: Int,
    val client6: ByteArray? = null, val server6: ByteArray? = null,
) {
    /**
     * Cevabı bu istemciye gönderir. [out]: DNS cevabı [Packets.HDR] konumunda hazır; istemcinin kimliği oraya yazılır.
     * [out] IPv6'da hiç değiştirilmez (başlıklar [scratch]'ta kurulur); IPv4'te baştaki başlık alanına yazılır.
     */
    fun deliver(out: ByteArray, scratch: ByteArray, len: Int, write: (ByteArray, Int, Int) -> Unit) {
        Packets.put16(out, Packets.HDR, clientId)
        val c6 = client6
        val s6 = server6
        if (c6 != null && s6 != null) {
            Packets.writeReply6(out, scratch, Packets.nextIdent(), s6, c6, serverPort, clientPort, len, write)
        } else {
            Packets.writeReply(out, scratch, Packets.nextIdent(), serverIp, clientIp, serverPort, clientPort, len, write)
        }
    }
}

/**
 * Tünelden gelen DNS sorgularını seçilen sunucuya düz DNS (UDP/53) ile iletir. Android'e bağlı değildir.
 *
 * Kaynak tüketimini düşük tutan tasarım:
 *  - Az sayıda UDP soketi ([SLOTS] "yuva"; sorgu başına soket/thread yok). Her yuvanın tek bir alıcı thread'i vardır.
 *  - Sorgu id'leri yeniden yazılır; cevap id ile eşleştirilir.
 *  - Zaman aşımı kontrolü sadece bekleyen sorgu varken uyanır, boştayken hiç CPU harcanmaz.
 *  - Küçük LRU önbellek, tekrar eden sorgular ağa çıkmaz. Aynı anda bekleyen ÖZDEŞ sorgular tek sorguya birleşir.
 *  - Sıcak yolda tampon yeniden kullanılır; sorgu başına sadece küçük bir kayıt nesnesi ve anahtar metni oluşur.
 *
 * Sahte cevaplara karşı (RFC 5452):
 *  - Kimlik [SecureRandom] ile rastgele; cevabın kaynak adresi ve portu sunucununki olmalı.
 *  - Cevabın soru bölümü (ad, tür, sınıf) sorununkiyle aynı olmalı ([Dns.sameQuestion]); değilse atılır.
 *  - Kaynak portu sabit kalmaz: her yuva [rotateAfter] sorgudan sonra, üzerinde bekleyen sorgu kalmayınca yeni bir
 *    soket (yeni rastgele port) açar. Diğer yuva bu sırada trafiği taşır; böylece yoğun trafikte de port değişir.
 *
 * Sağlamlık:
 *  - [resetNetwork]: ağ değişince (Wi-Fi <-> mobil) soketleri yeniler, önbelleği boşaltır, bekleyen
 *    sorguları yeni soketlerden yeniden gönderir.
 *  - Alım hatası üst üste tekrarlarsa yuvanın soketi kendiliğinden yenilenir.
 *  - Yedek geçişi: birincil sunucu üst üste [FAILOVER_AFTER] sorguda zamanında cevap vermez ve ikincisi verirse,
 *    sonraki sorgular doğrudan ikinciye gider. Ağ değişince birincile dönülür.
 *  - Bozuk, kesik, sahte kaynaklı paketler sessizce atılır. Alım tamponuna sığmayan cevap "kesildi" (TC)
 *    işaretiyle iletilir ve önbelleğe alınmaz.
 *
 * [onPacket] tek bir thread'den (tünel okuyucu) çağrılmalıdır.
 */
class DnsForwarder(
    private val upstreams: List<InetSocketAddress>,
    private val writeToTun: (ByteArray, Int, Int) -> Unit,
    private val protect: (DatagramSocket) -> Boolean = { true },
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000 },
    /** İlk yeniden deneme gecikmesi. [ADAPTIVE] (varsayılan): ölçülen cevap süresinden ([MobilePolicy.dnsRetryMs]); testler sabit değer verebilir. */
    private val retryAfterMs: Long = ADAPTIVE,
    private val giveUpAfterMs: Long = 4000,
    private val sweepMs: Long = 50,
    cacheEntries: Int = 256,
    private val threadFactory: (Runnable, String) -> Thread =
        { r, name -> Thread(r, name).apply { isDaemon = true } },
    private val log: (String) -> Unit = {},
    /** Bir yuvanın kaç sorgudan sonra yeni bir kaynak portuna geçeceği. */
    private val rotateAfter: Int = ROTATE_AFTER,
    /** Sunucu bu kadar sürede cevap vermezse (ve süresi dolmuş olumlu bir kayıt varsa) bayat cevap verilir. [ADAPTIVE]: ölçülen cevap süresinden ([MobilePolicy.dnsStaleMs]). */
    private val staleAfterMs: Long = ADAPTIVE,
    /** Birincil geç kalınca sorgu iki sunucuya birden gider (ayar: dnsRace). */
    private val raceEnabled: Boolean = true,
) : Forwarder {

    override val proto: Proto get() = Proto.PLAIN

    /** Bir UDP soketi ve onun alıcı thread'i. Soket yenilenince [gen] artar. */
    private class Slot(val index: Int) {
        @Volatile var socket: DatagramSocket? = null
        @Volatile var gen = 0
        @Volatile var draining = false
        val inflight = AtomicInteger()
        val uses = AtomicInteger()
        var thread: Thread? = null
    }

    private class Pending(
        val key: String,
        val query: ByteArray,      // upstream id'si yazılmış DNS verisi (yeniden deneme için)
        val qEnd: Int,             // soru bölümünün sonu (cevap doğrulaması); -1: denetlenemez
        val addedOpt: Boolean,     // OPT kaydını biz ekledik: cevaptaki OPT istemciye verilmez
        val firstSentAt: Long,
        val slot: Slot,
        first: Waiter?,               // null: ön yenileme (kimse beklemez; yalnızca önbellek tazelenir)
        @Volatile var firstIdx: Int,   // ilk gönderildiği sunucu (yeniden deneme diğerine gider)
        val qCase: ByteArray?,         // 0x20: istemcinin özgün soru adı (harf durumu); karıştırılmadıysa null
        val zone: String = "",         // kayıtlı alan (alan başı bekleyen sorgu sınırı için); finish() sayacı düşürür
    ) {
        @Volatile var sentAt: Long = firstSentAt
        @Volatile var attempt = 0
        /** Bekleyenlere bayat cevap denendi (bir kez); gerçek cevap gelirse yalnızca önbelleği tazeler. */
        @Volatile var staleTried = false
        /** Sorgu yarışla iki sunucuya birden gitti ([races]); ikincinin cevabı önce gelirse yarış kazanılmış sayılır ([raceWins]). */
        @Volatile var raced = false
        val waiters = ArrayList<Waiter>(1).also { if (first != null) it.add(first) }   // [this] kilidiyle korunur
        var done = false                                          // [this] kilidiyle korunur
    }

    init {
        require(upstreams.isNotEmpty()) { "en az bir DNS sunucusu gerekli" }
    }

    private val slots = Array(SLOTS) { Slot(it) }
    private val slotLock = Any()
    @Volatile private var primaryIdx = 0
    private val streak = AtomicInteger()
    private val pending = ConcurrentHashMap<Int, Pending>()
    private val byKey = ConcurrentHashMap<String, Pending>()
    /**
     * Alan başına bekleyen sorgu sayısı. Cevap vermeyen (yavaş / tarpit) bir alandan gelen yüzlerce farklı ad, [MAX_PENDING] tablosunu
     * dolduruyor ve TÜM öteki alanların sorgularını düşürüyordu (bir web sayfası dns-prefetch ile saniyede yüzlerce ad üretebilir).
     * Alan başına [ZONE_PENDING]'den fazlası kabul edilmez; kayıt sayaç 0'a inince silinir (tablo en çok [MAX_PENDING] alan tutar).
     */
    private val zonePend = ConcurrentHashMap<String, Int>()
    private val zoneDrops = AtomicLong()
    private val internalErrs = AtomicLong()
    @Volatile private var lastErr = ""
    @Volatile private var lastErrLogAt = 0L
    private val cache = DnsCache(cacheEntries, nowMs)
    private val random = SecureRandom()
    private val sweepScheduled = AtomicBoolean(false)
    private val scheduler: ScheduledExecutorService =
        Executors.newSingleThreadScheduledExecutor { r -> threadFactory(r, "dns-sweep") }
    @Volatile private var started = false
    @Volatile private var closed = false
    @Volatile private var lastTimeoutLog = 0L

    // yalnızca onPacket thread'i kullanır
    private val tunBuf = ByteArray(Packets.HDR6 + MAX_DNS)
    private val tunScratch = ByteArray(Packets.MTU)

    private val queries = AtomicLong()
    private val cacheHits = AtomicLong()
    private val forwarded = AtomicLong()
    private val answered = AtomicLong()
    private val retries = AtomicLong()
    private val timeouts = AtomicLong()
    private val staleServed = AtomicLong()
    private val dropped = AtomicLong()
    private val resets = AtomicLong()
    private val latencySum = AtomicLong()
    private val failovers = AtomicLong()
    private val blocked = AtomicLong()
    private val bytesUp = AtomicLong()
    private val bytesDown = AtomicLong()
    private val merged = AtomicLong()
    private val races = AtomicLong()
    private val raceWins = AtomicLong()
    private val rejected = AtomicLong()
    private val blockPages = AtomicLong()
    private val ring = LatencyRing()
    private val rttEst = RttEstimator()
    private val parsed = ParsedQuery()

    override fun start() {
        check(!started) { "zaten başlatıldı" }
        started = true
        try {
            for (sl in slots) {
                sl.socket = newSocket()
                sl.thread = threadFactory(Runnable { receiveLoop(sl) }, "dns-recv-" + sl.index).also { it.start() }
            }
        } catch (e: Throwable) {
            close()   // kısmen açılmış soketler ve iş parçacıkları sızmasın
            throw e
        }
    }

    override fun stats() = Stats(
        queries.get(), cacheHits.get(), forwarded.get(), answered.get(), retries.get(),
        timeouts.get(), dropped.get(), resets.get(), latencySum.get(), failovers.get(), primaryIdx != 0, blocked.get(),
        bytesUp.get(), bytesDown.get(), merged.get(), rejected.get(), stale = staleServed.get(), blockPages = blockPages.get(), races = races.get(), raceWins = raceWins.get(),
    )

    override fun latencies(out: IntArray): Int = ring.copyTo(out)

    internal fun pendingCount() = pending.size
    internal fun zonePendingCount(): Int = zonePend.values.sum()
    internal fun zoneDropped() = zoneDrops.get()
    internal fun internalErrors() = internalErrs.get()
    internal fun lastInternalError() = lastErr

    /** Beklenmeyen iç hata (ağ hatası değil): sayılır, saniyede en çok bir kez günlüğe yazılır; iş parçacığı ölmez. */
    private fun internalError(where: String, t: Throwable) {
        internalErrs.incrementAndGet()
        lastErr = "$where: ${t.javaClass.simpleName} ${t.message ?: ""} @ ${t.stackTrace.firstOrNull() ?: "?"}"
        val now = nowMs()
        if (now - lastErrLogAt >= 1000L) { lastErrLogAt = now; try { log("iç hata ($lastErr)") } catch (_: Throwable) { } }
    }

    /** Alanın bekleyen sayacını bir artırır; sınırdaysa artırmaz ve false döner (atomik). */
    private fun zoneAcquire(zone: String, reserved: Boolean = false): Boolean {
        var ok = true
        val limit = if (reserved) ZONE_PENDING + ZONE_RESERVE else ZONE_PENDING
        zonePend.compute(zone) { _, v -> val c = v ?: 0; if (c >= limit) { ok = false; v } else c + 1 }
        return ok
    }

    private fun zoneRelease(zone: String) {
        zonePend.compute(zone) { _, v -> if (v == null || v <= 1) null else v - 1 }
    }
    // Bilinen adlar: yakın zamanda olumlu cevap almış tam sorular (sınırlı LRU). Yoğunlukta yalnızca bunlara rezerv pay açık kalır.
    private val knownNames = java.util.Collections.synchronizedMap(object : LinkedHashMap<String, Boolean>(256, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Boolean>?): Boolean = size > KNOWN_NAMES
    })
    private val unknownShed = AtomicLong()
    private fun isKnownName(key: String): Boolean = knownNames[key] != null
    private fun noteKnownName(key: String) { knownNames[key] = true }
    internal fun raceCount() = races.get()
    internal fun raceWinCount() = raceWins.get()
    internal fun streakCount() = streak.get()
    internal fun localPort() = slots[0].socket?.localPort ?: -1
    internal fun localPorts(): List<Int> = slots.map { it.socket?.localPort ?: -1 }

    override fun clearCache() = cache.clear()

    /**
     * Ağ değişti (ör. Wi-Fi'den mobil veriye geçildi): eski soketler artık yanlış ağa bağlı olabilir.
     * Soketleri yeniler, önbelleği boşaltır (cevaplar ağa göre değişebilir) ve bekleyen
     * sorguları yeni soketlerden bir kez daha gönderir. Herhangi bir thread'den çağrılabilir.
     */
    override fun resetNetwork(reason: String) {
        if (closed || !started) return
        // Her yuva ayrı denenir: biri başarısız olsa bile (eski soketi yerinde kalır) ötekiler yenilenir ve sıfırlama tamamlanır.
        var renewed = 0
        synchronized(slotLock) {
            for (sl in slots) {
                try { rebind(sl); renewed++ } catch (e: IOException) { log("soket yenilenemedi (${e.javaClass.simpleName})") }
            }
        }
        if (renewed == 0) return
        log("soket yenilendi ($reason, $renewed/${slots.size})")
        cache.clear()
        rttEst.reset()                       // yeni ağın gecikmesi eskisinden çok farklı olabilir
        primaryIdx = 0                       // yeni ağda önce yine birincil denenir
        streak.set(0)
        val now = nowMs()
        for (e in pending.values) {
            e.sentAt = now
            e.attempt = 0
            e.firstIdx = 0
            send(e.slot, e.query, upstreams[0])
        }
        resets.incrementAndGet()
        if (pending.isNotEmpty()) scheduleSweep()
    }

    private fun newSocket(): DatagramSocket {
        val s = DatagramSocket()
        if (!protect(s)) {
            s.close()
            throw IOException("protect() başarısız: soket tünel dışında tutulamadı")
        }
        // Yoğun anda (sel, aynı anda açılan uygulamalar) cevaplar çekirdek kuyruğunda beklemeli, düşmemeli: Linux paket başına ~1 KB
        // ayırır; 64 KB yalnızca ~60 cevap tutardı. 512 KB ≈ 500 cevap (iki yuva: en çok 1 MB çekirdek belleği).
        try { s.receiveBufferSize = RCVBUF } catch (_: Exception) {}
        return s
    }

    /** [slotLock] altında: yuvaya yeni soket (yeni kaynak portu) takar, eskisini kapatır. */
    private fun rebind(sl: Slot) {
        if (closed) return
        val fresh = newSocket()
        val old = sl.socket
        sl.socket = fresh
        sl.gen++
        sl.uses.set(0)
        sl.draining = false
        try { old?.close() } catch (_: Exception) {}
    }

    /** Boşalan ve süresi dolan yuvanın portunu değiştirir. Üzerinde bekleyen sorgu varsa dokunmaz. */
    private fun rotate(sl: Slot) {
        synchronized(slotLock) {
            if (closed || !sl.draining || sl.inflight.get() > 0) return
            try { rebind(sl) } catch (_: IOException) { sl.draining = false; sl.uses.set(0) }
        }
    }

    private fun otherDraining(sl: Slot): Boolean {
        for (o in slots) if (o !== sl && o.draining) return true
        return false
    }

    /** Yeni sorgu için yuva: süresi dolmamış yuvalar arasından rastgele; hepsi boşalmayı bekliyorsa en az yüklü olan. */
    private fun pickSlot(): Slot {
        val a = slots[random.nextInt(SLOTS)]
        if (!a.draining) return a
        for (sl in slots) if (!sl.draining) return sl
        var best = slots[0]
        for (sl in slots) if (sl.inflight.get() < best.inflight.get()) best = sl
        return best
    }

    /** Tünelden okunan ham IP paketi. [p] çağrıdan sonra yeniden kullanılabilir; burada saklanmaz. */
    override fun onPacket(p: ByteArray, len: Int) {
        if (closed) return
        val q = parsed
        if (!q.parse(p, len, MAX_DNS)) return
        queries.incrementAndGet()
        val dnsOff = q.dnsOff
        val dnsLen = q.dnsLen
        val key = String(p, dnsOff + 2, dnsLen - 2, Charsets.ISO_8859_1)

        // 1) önbellek
        val n = cache.get(key, q.clientId, tunBuf, Packets.HDR)
        if (n > 0) {
            cacheHits.incrementAndGet()
            if (Dns.isBlocked(tunBuf, Packets.HDR, n)) blocked.incrementAndGet()
            q.writeCached(tunBuf, tunScratch, n, writeToTun)
            // Sık sorulan ve süresi dolmak üzere olan kayıt: istemci eski cevabı hemen aldı, yenisi arka planda çekilir.
            if (HarmonyLive.allows(Knob.PREFETCH) && cache.prefetchDue(key)) prefetch(p, dnsOff, dnsLen, key)     // uyum motoru kısabilir (veri, pil)
            return
        }

        val waiter = q.waiter()

        // 2) aynı soru zaten yolda: istemciyi o sorguya ekle (istemcinin yeniden denemeleri ağa çıkmaz)
        val same = byKey[key]
        if (same != null) {
            synchronized(same) {
                if (!same.done && same.waiters.size < MAX_WAITERS) {
                    same.waiters.add(waiter)
                    merged.incrementAndGet()
                    return
                }
            }
        }

        // 3) yeni sorgu: upstream'e gönder
        if (pending.size >= MAX_PENDING) {
            dropped.incrementAndGet()
            return
        }
        // Gizlilik: istemciye ait EDNS seçenekleri (alt ağ, çerez, kimlik) atılır; "alt ağı iletme" işareti konur.
        val san = Dns.sanitizeQuery(p, dnsOff, dnsLen, pad = false, absentPayload = 512)
        if (san == null) { dropped.incrementAndGet(); return }
        val zone = ZoneKey.of(p, dnsOff, dnsLen)
        // Bilinen ad: yakın zamanda OLUMLU cevap almış tam soru (önbelleği dolup yeniden sorulan, sık kullanılan adlar). Sel anında bunlara
        // iki rezerv pay açılır: (1) tablo [UNKNOWN_CAP]'i aşınca bilinmeyen adlar düşer; (2) alan sınırı dolsa da ek [ZONE_RESERVE] yer.
        // Rastgele ad selleri ("rastgele alt alan", dağıtılmış alan seli) olumlu cevap almadığı için bu paylara giremez.
        val busy = pending.size >= UNKNOWN_CAP
        val known = (busy || (zonePend[zone] ?: 0) >= ZONE_PENDING) && isKnownName(key)
        if (busy && !known) {
            dropped.incrementAndGet(); unknownShed.incrementAndGet()
            return
        }
        launch(key, san, waiter, zone, reserved = known)
    }

    /** Ön yenileme: istemcisiz bir sorgu gönderir; cevap önbelleği tazeler. Yoğunlukta yer açmak için atlanır. */
    private fun prefetch(p: ByteArray, dnsOff: Int, dnsLen: Int, key: String) {
        if (pending.size >= MAX_PENDING / 2) return
        val san = Dns.sanitizeQuery(p, dnsOff, dnsLen, pad = false, absentPayload = 512) ?: return
        launch(key, san, null, ZoneKey.of(p, dnsOff, dnsLen))
    }

    /** Yeni bir sorguyu yukarı akışa gönderir ve bekleyenlere kaydeder. */
    private fun launch(key: String, san: Dns.Sanitized, waiter: Waiter?, zone: String, reserved: Boolean = false) {
        if (!zoneAcquire(zone, reserved)) { dropped.incrementAndGet(); zoneDrops.incrementAndGet(); return }
        val query = san.query
        val first = primaryIdx
        var upId = 0
        val entry: Pending = try {
            val qEnd = Dns.questionEnd(query, 0, query.size)
            val sl = pickSlot()
            // 0x20 (draft-vixie-dnsext-dns0x20): sorgunun ad harfleri rastgele büyük/küçük gönderilir; sahte cevap bunu tutturamaz.
            // Sunucu harfleri yansıtmıyorsa (nadir ama var) uyarlamalı olarak kapanır, bkz. [caseOff].
            val qCase = if (qEnd > 0 && !caseOff(first)) randomizeCase(query, qEnd) else null
            val en = Pending(key, query, qEnd, san.addedOpt, nowMs(), sl, waiter, first, qCase, zone)
            do {
                upId = random.nextInt(65536)
            } while (pending.putIfAbsent(upId, en) != null)
            en
        } catch (t: Throwable) {
            zoneRelease(zone)                 // kayda girmeden hata: sayaç sızmasın
            throw t
        }
        val slot = entry.slot
        Packets.put16(query, 0, upId)
        byKey[key] = entry
        slot.inflight.incrementAndGet()
        // Süresi dolan yuva yeni soru almaz ve boşalınca portunu değiştirir. Aynı anda yalnızca BİR yuva boşalmaya
        // alınır: diğeri trafiği taşırken bu yuva birkaç milisaniyede boşalır (yoğun trafikte de port değişir).
        if (slot.uses.incrementAndGet() >= rotateAfter && !otherDraining(slot)) slot.draining = true

        forwarded.incrementAndGet()
        bytesUp.addAndGet(query.size.toLong())
        // Gönderim hemen başarısızsa (ör. o IP ailesinin yolu yok) beklemeden öbür adrese gönderilir.
        // Yarış: birincil son sorguda geç kaldıysa (streak > 0) sorgu iki sunucuya birden gider, ilk cevap kazanır.
        // Yeniden deneme süresi beklenmez; birincil düzelince (cevabı ilk gelince) sayaç sıfırlanır ve yarış biter.
        // Karar GÖNDERMEDEN ÖNCE verilir: hızlı cevap alıcı thread'de sayacı sıfırlayıp kararı yarıda değiştirmesin.
        val race = raceEnabled && upstreams.size > 1 && streak.get() > 0 && HarmonyLive.allows(Knob.DNS_RACE)      // uyum motoru (pil, ölçülü veri, yük) kısabilir
        val sent = send(slot, query, upstreams[first])
        if (upstreams.size > 1 && (!sent || race)) {
            if (sent) entry.raced = true                    // gönderimden ÖNCE: hızlı cevap alıcıda işaretsiz görülmesin
            send(slot, query, upstreams[(first + 1) % upstreams.size])
            if (sent) races.incrementAndGet()
        }
        scheduleSweep()
    }

    /** Sorguyu gönderir. Hemen başarısız olursa (ör. IPv6 yolu yok: "ağa ulaşılamıyor") false döner. */
    private fun send(sl: Slot, data: ByteArray, to: InetSocketAddress): Boolean {
        val s = sl.socket ?: return false
        return try {
            s.send(DatagramPacket(data, data.size, to))
            true
        } catch (_: IOException) {
            // ağ yok olabilir ya da soket o an yenileniyor; zaman aşımı kontrolü ikinci denemeyi yapar
            false
        }
    }

    /** Sorgu bitti (cevap, zaman aşımı): kayıtlardan düş, yuvası boşaldıysa portunu değiştir. */
    private fun finish(e: Pending) {
        zoneRelease(e.zone)
        byKey.remove(e.key, e)
        val sl = e.slot
        if (sl.inflight.decrementAndGet() <= 0 && sl.draining) rotate(sl)
    }

    private fun receiveLoop(sl: Slot) {
        val buf = ByteArray(MAX_REPLY)
        val out = ByteArray(Packets.HDR6 + MAX_REPLY)
        val scratch = ByteArray(Packets.MTU)
        val pkt = DatagramPacket(buf, buf.size)
        var failures = 0
        while (!closed) {
            val s = sl.socket ?: return
            val gen = sl.gen
            try {
                pkt.length = buf.size
                s.receive(pkt)
                failures = 0
            } catch (e: IOException) {
                if (closed) return
                if (gen != sl.gen) continue                       // yeni soket takıldı, hemen dön
                failures++
                if (failures >= 5) {
                    failures = 0
                    try { synchronized(slotLock) { if (gen == sl.gen) rebind(sl) } } catch (_: IOException) {}
                    log("soket yenilendi (alım hatası: ${e.javaClass.simpleName})")
                }
                try { Thread.sleep(minOf(100L * (failures + 1), 1000L)) } catch (_: InterruptedException) { return }
                continue
            }
            try {
                var len = pkt.length
                if (len < Packets.DNS_HDR) continue
                val from = upstreamIndex(pkt)
                if (from < 0) continue                               // sahte kaynak
                val id = Packets.u16(buf, 0)
                val entry = pending[id] ?: continue
                // Cevap, sorunun gönderildiği soketten (aynı kaynak portu) gelmelidir. Bekleyen kimlikler tüm yuvalarda ortaktır;
                // bu denetim olmadan sahte cevap gönderen biri iki porttan herhangi birini tutturmakla yetinirdi (RFC 5452 §9.2).
                if (entry.slot !== sl) { rejected.incrementAndGet(); continue }
                if (!Dns.sameQuestion(entry.query, 0, entry.qEnd, buf, 0, len)) {
                    rejected.incrementAndGet()                       // kimlik tuttu ama soru farklı: sahte ya da bozuk
                    continue
                }
                if (entry.qCase != null) {
                    // 0x20: ad harfleri birebir yankılanmalı. Sunucu daha önce birebir yanıt verdiyse harf farkı sahtelik sayılır ve
                    // atılır. Hiç birebir yanıt vermemiş (harfleri yansıtmayan) sunucuda harf farkı kabul edilir: DNS kesilmez, ama
                    // bu sunucuda 0x20 sayaçla kapanır (bkz. caseOff).
                    if (!caseExact(entry.query, entry.qEnd, buf, len)) {
                        caseBad.incrementAndGet(from)
                        if (caseOk.get(from) > 0) {
                            rejected.incrementAndGet()
                            continue
                        }
                    } else {
                        caseOk.incrementAndGet(from)
                    }
                    System.arraycopy(entry.qCase, 0, buf, Packets.DNS_HDR, entry.qCase.size)   // istemciye ve önbelleğe özgün harfler
                }
                // Bilinen engel sayfası / sahte havuz adresi: sansürcünün enjekte ettiği cevap. Atılır, bekleyen sorgu AÇIK kalır; gerçek cevap
                // (yarış kaybeden asıl sunucu ya da yeniden deneme) gelirse o kabul edilir.
                if (BlockPages.inAnswer(buf, 0, len)) { blockPages.incrementAndGet(); continue }
                if (!pending.remove(id, entry)) continue
                // Buradan sonra kayıt tablodan çıktı: işleme ne olursa olsun (istisna dahil) finish() çalışmalı; yoksa bayt/sayaç/alan kaydı sızar.
                try {
                    val truncated = len >= buf.size
                    if (truncated) Dns.setTruncated(buf, 0) else len = CnameGuard.guard(buf, 0, len)      // gizli izleyici (CNAME) engeli
                    answered.incrementAndGet()
                    if (upstreams.size > 1) noteAnswer(entry, from)
                    val took = maxOf(0L, nowMs() - entry.firstSentAt)
                    if (entry.attempt == 0) rttEst.sample(took.toDouble())      // Karn: yeniden denenen sorgunun süresi güvenilir örnek değil
                    latencySum.addAndGet(took)
                    ring.add(took.coerceAtMost(LatencyRing.MAX_MS.toLong()).toInt())
                    bytesDown.addAndGet(len.toLong())

                    if (Dns.isBlocked(buf, len)) blocked.incrementAndGet()
                    if (len >= Packets.DNS_HDR && (buf[3].toInt() and 0x0F) == 0 && Packets.u16(buf, 6) > 0) noteKnownName(entry.key)
                    // İstemci EDNS istemediği halde biz OPT eklediysek cevaptaki OPT atılır (önbelleğe de böyle girer).
                    val rlen = if (entry.addedOpt && !truncated) Dns.stripOpt(buf, 0, len) else len
                    if (!truncated) {
                        val ttl = Dns.cacheTtl(buf, rlen)
                        if (ttl > 0) cache.put(entry.key, buf, rlen, ttl)
                    }

                    synchronized(entry) {
                        entry.done = true
                        for (w in entry.waiters) {
                            // Bir istemciye teslim hatası (ör. tünel yazması) ötekilerin teslimini ve alıcı iş parçacığını durdurmaz.
                            try {
                                System.arraycopy(buf, 0, out, Packets.HDR, rlen)
                                w.deliver(out, scratch, rlen, writeToTun)      // istemcinin id'sini geri koyar
                            } catch (t: Throwable) { internalError("teslim", t) }
                        }
                    }
                } catch (t: Throwable) {
                    internalError("cevap işleme", t)
                } finally {
                    synchronized(entry) { entry.done = true }
                    finish(entry)
                }
            } catch (t: Throwable) {
                // Tek bir bozuk/düşman cevap alıcı iş parçacığını öldürmesin (ölürse o yuvanın tüm cevapları sonsuza dek kaybolurdu).
                internalError("alıcı", t)
            }
        }
    }

    /** 0x20 sayaçları (sunucu başına): birebir yankı ve harf farkıyla gelen cevaplar. */
    private val caseOk = java.util.concurrent.atomic.AtomicIntegerArray(maxOf(1, upstreams.size))
    private val caseBad = java.util.concurrent.atomic.AtomicIntegerArray(maxOf(1, upstreams.size))

    /**
     * 0x20 bu sunucu için kapalı mı? Sunucu hiç birebir yanıt vermeden [CASE_BAD_LIMIT] kez harf farkı yaptıysa kapatılır
     * (bozuk ama meşru bir sunucu DNS'i kesmesin). Bir kez bile birebir yanıt verdiyse açık kalır.
     */
    private fun caseOff(idx: Int): Boolean {
        if (idx < 0 || idx >= caseOk.length()) return false
        return caseOk.get(idx) == 0 && caseBad.get(idx) >= CASE_BAD_LIMIT
    }

    /** Ad bölümündeki harfleri rastgele büyük/küçük yapar; özgün hâli döner. Uzunluk baytlarına dokunulmaz (≤ 63 < 'A'). */
    private fun randomizeCase(q: ByteArray, qEnd: Int): ByteArray? {
        val from = Packets.DNS_HDR
        val to = qEnd - 4                                         // soru tipi + sınıf hariç
        if (to <= from) return null
        val orig = q.copyOfRange(from, qEnd)
        var changed = false
        var i = from
        var bits = 0; var nb = 0
        while (i < to) {
            val b = q[i].toInt() and 0xFF
            if (b in 0x41..0x5A || b in 0x61..0x7A) {
                if (nb == 0) { bits = random.nextInt(); nb = 32 }
                val up = bits and 1 == 1; bits = bits ushr 1; nb--
                val nv = if (up) (b and 0xDF) else (b or 0x20)
                if (nv != b) { q[i] = nv.toByte(); changed = true }
            }
            i++
        }
        return if (changed) orig else null
    }

    /** Ad bölümü (soru tipi/sınıf hariç) harf harf aynı mı? */
    private fun caseExact(q: ByteArray, qEnd: Int, r: ByteArray, rLen: Int): Boolean {
        val from = Packets.DNS_HDR
        val to = qEnd - 4
        if (to <= from || from + (to - from) > rLen) return true
        for (i in from until to) if (q[i] != r[i]) return false
        return true
    }

    /** Paketin geldiği sunucunun [upstreams] içindeki sırası; hiçbiri değilse -1 (sahte kaynak). */
    private fun upstreamIndex(pkt: DatagramPacket): Int {
        for (i in upstreams.indices) {
            val u = upstreams[i]
            if (u.port == pkt.port && u.address == pkt.address) return i
        }
        return -1
    }

    /**
     * Cevabın hangi sunucudan geldiğine bakar. Birincil sunucuya gönderilen sorgu ona değil diğerine
     * (yeniden denemeye) cevaplandıysa sayaç artar; üst üste [FAILOVER_AFTER] kez olursa yedek birincil olur.
     * Birincilden gelen her cevap sayacı sıfırlar, bu yüzden tek seferlik yavaşlık geçişe yol açmaz.
     */
    private fun noteAnswer(entry: Pending, from: Int) {
        if (entry.raced && from != entry.firstIdx) raceWins.incrementAndGet()
        val primary = primaryIdx
        if (from == entry.firstIdx) {
            if (from == primary) streak.set(0)
        } else if (entry.firstIdx == primary) {
            if (streak.incrementAndGet() >= FAILOVER_AFTER) {
                streak.set(0)
                primaryIdx = from
                failovers.incrementAndGet()
                log("yedek sunucuya geçildi")
            }
        }
    }

    /**
     * Sunucu [staleAfterMs] içinde cevap vermedi: bekleyen istemcilere, varsa süresi dolmuş olumlu cevap verilir (RFC 8767).
     * Sorgu ağda sürer; gerçek cevap gelirse yalnızca önbelleği tazeler (istemciye ikinci cevap gitmez).
     */
    private fun serveStale(e: Pending) {
        val out = ByteArray(Packets.HDR6 + CACHE_MAX)
        val n = cache.getStale(e.key, 0, out, Packets.HDR)
        if (n <= 0) return
        val scratch = ByteArray(Packets.MTU)
        synchronized(e) {
            if (e.done || e.waiters.isEmpty()) return
            for (w in e.waiters) w.deliver(out, scratch, n, writeToTun)      // istemcinin kimliğini geri koyar
            e.waiters.clear()
        }
        staleServed.incrementAndGet()
    }

    /** Sadece bekleyen sorgu varken çalışır; boştayken hiç uyanmaz. */
    private fun scheduleSweep() {
        if (closed) return
        if (sweepScheduled.compareAndSet(false, true)) {
            try {
                scheduler.schedule({ sweep() }, sweepMs, TimeUnit.MILLISECONDS)
            } catch (_: RejectedExecutionException) {
                sweepScheduled.set(false)
            }
        }
    }

    private fun sweep() {
        sweepScheduled.set(false)
        // Zamanlayıcıda atılan istisna sessizce yutulur ve bir sonraki süpürmeyi planlayan satıra hiç ulaşılmazdı: bekleyen sorgular
        // zaman aşımına uğramaz, tablo dolardı. Bu yüzden her kayıt ayrı korunur ve yeniden planlama her durumda çalışır.
        try {
            val now = nowMs()
            val retryAt = if (retryAfterMs >= 0) retryAfterMs else MobilePolicy.dnsRetryMs(rttEst)
            val staleAt = if (staleAfterMs >= 0) staleAfterMs else MobilePolicy.dnsStaleMs(rttEst)
            val it = pending.entries.iterator()
            while (it.hasNext()) {
                val ent = it.next()
                val e = ent.value
                try {
                    val age = now - e.sentAt
                    if (!e.staleTried && now - e.firstSentAt >= staleAt) { e.staleTried = true; serveStale(e) }
                    if (age >= giveUpAfterMs) {
                        // Anahtar + değerle sil: bu arada cevap gelip kimlik yeniden kullanıldıysa yeni girdiye dokunma, iki kez bitirme.
                        if (!pending.remove(ent.key, e)) continue
                        try {
                            synchronized(e) { e.done = true }
                            timeouts.incrementAndGet()
                            ring.add(LatencyRing.TIMEOUT)
                            if (now - lastTimeoutLog > 5000) {
                                lastTimeoutLog = now
                                log("zaman aşımı (toplam ${timeouts.get()})")
                            }
                        } finally { finish(e) }
                    } else if (e.attempt == 0 && age >= retryAt) {
                        e.attempt = 1
                        retries.incrementAndGet()
                        // İlk gönderilenin dışındaki sunucuya, tek sunucu varsa aynısına bir kez daha dene.
                        send(e.slot, e.query, upstreams[(e.firstIdx + 1) % upstreams.size])
                    } else if (e.attempt == 1 && retryAfterMs < 0 && age >= retryAt * 3) {
                        e.attempt = 2                  // uyarlanır kipte üçüncü deneme: ilk sunucuya geri dön (art arda kayıplara karşı)
                        retries.incrementAndGet()
                        send(e.slot, e.query, upstreams[e.firstIdx])
                    }
                } catch (t: Throwable) { internalError("süpürme", t) }
            }
        } catch (t: Throwable) {
            internalError("süpürme", t)
        } finally {
            if (pending.isNotEmpty()) scheduleSweep()
        }
    }

    override fun close() {
        if (closed) return
        closed = true
        synchronized(slotLock) { for (sl in slots) try { sl.socket?.close() } catch (_: Exception) {} }
        scheduler.shutdownNow()
        for (sl in slots) sl.thread?.interrupt()
        pending.clear()
        byKey.clear()
        zonePend.clear()
        cache.clear()
    }

    companion object {
        /** Tünelden gelen DNS sorgusunun üst sınırı (UDP). */
        const val MAX_DNS = 4096
        /** 0x20: bu kadar harf farkı var ve hiç birebir yanıt yoksa sunucu için 0x20 kapanır. */
        const val CASE_BAD_LIMIT = 8

        /** Sunucudan kabul edilen en büyük cevap; daha büyüğü "kesildi" (TC) olarak iletilir. */
        const val MAX_REPLY = 16384

        /** Bayat cevap verilmeden önce beklenen süre (ms; RFC 8767 önerisi 1,8 sn). */
        const val STALE_AFTER_MS = 1800L
        private const val CACHE_MAX = DnsCache.MAX_ENTRY_BYTES

        /** Sel koruması: aynı anda bekleyebilecek en fazla sorgu. */
        const val MAX_PENDING = 1024
        /** Üst sunucu soketlerinin alım arabelleği (bayt). */
        const val RCVBUF = 512 * 1024

        /** Alan başına aynı anda bekleyebilecek en fazla sorgu: cevapsız (tarpit) tek bir alan tüm tabloyu dolduramaz. */
        const val ZONE_PENDING = 64

        /** Bekleyen tablo bu sayıyı aşınca bilinmeyen (olumlu cevap almamış) adlara yeni sorgu açılmaz; kalan pay bilinen adlara ayrılır. */
        const val UNKNOWN_CAP = MAX_PENDING * 3 / 4

        /** Alan sınırı dolsa da bilinen adlara açık ek yer (rastgele alt alan selinde meşru adların yaşaması için). */
        const val ZONE_RESERVE = 16

        /** Hatırlanan bilinen ad sayısı (LRU). */
        const val KNOWN_NAMES = 4096

        /** Bekleyen tek sorguya eklenebilecek en fazla istemci. */
        const val MAX_WAITERS = 16

        /** Yedek sunucuya geçmek için birincilin üst üste kaç sorguda cevapsız kalması gerektiği. */
        const val FAILOVER_AFTER = 2

        /** Soket (kaynak portu) yuvası sayısı ve kaç sorguda bir port değiştiği. */
        const val SLOTS = 2
        const val ROTATE_AFTER = 64

        /** [retryAfterMs] için "ölçülen cevap süresinden türet". */
        const val ADAPTIVE = -1L
    }
}
