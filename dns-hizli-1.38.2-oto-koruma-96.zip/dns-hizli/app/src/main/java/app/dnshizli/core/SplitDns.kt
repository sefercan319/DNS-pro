package app.dnshizli.core

/**
 * DNS bölme: sorgular 2–3 sağlayıcıya dağıtılır, böylece hiçbir sağlayıcı tüm gezinme geçmişini göremez.
 *
 * Her site (kayıt edilebilir alan adına yakın: "a.b.example.co.uk" → "example.co.uk") her zaman AYNI sağlayıcıya gider: site,
 * cihaza özgü gizli bir tuzla özetlenir ([salt]) ve sağlayıcı sayısına bölünür. Tutarlılık önemli: aynı site dönüşümlü olarak
 * farklı sağlayıcılara gitseydi zamanla hepsi her şeyi görürdü. Tuz cihaza özgü olduğundan hangi sitenin hangi sağlayıcıya
 * gittiği dışarıdan tahmin edilemez.
 *
 * Bir sağlayıcı yanıt vermezse ([DOWN_FAILS] zaman aşımı, arada hiç cevap yok) [DOWN_MS] boyunca onun siteleri sıradaki sağlayıcıya
 * gider (erişilebilirlik gizlilikten önce gelir: internet kesilmez); süre dolunca yeniden denenir.
 */
object SplitDns {
    const val MAX_PARTS = 3
    const val DOWN_FAILS = 3
    const val DOWN_MS = 60_000L
    /** Erken fark etme: art arda bu kadar sağlık ölçümünde (2 sn'de bir) ... */
    const val SILENT_ROUNDS = 2
    /** ... ölçüm başına en az bu kadar sorgu gidip hiç cevap gelmediyse sağlayıcı yanıt vermiyor sayılır. */
    const val SILENT_MIN = 2

    /**
     * Sorgunun sorusundaki adın sitesi için sağlayıcı sırası (0 until [n]). Ad okunamazsa 0. [scratch] en az 256 bayt.
     * Nesne ayırmaz.
     */
    fun index(p: ByteArray, dnsOff: Int, dnsLen: Int, n: Int, salt: Long, scratch: ByteArray): Int {
        if (n <= 1) return 0
        val len = readName(p, dnsOff, dnsLen, scratch)
        if (len <= 0) return 0
        return Math.floorMod(hashSite(scratch, len, salt), n.toLong()).toInt()
    }

    /** Metin addan sıra (testler ve arayüz önizlemesi için). */
    fun indexOf(name: String, n: Int, salt: Long): Int {
        if (n <= 1) return 0
        val b = name.lowercase().trimEnd('.').toByteArray(Charsets.US_ASCII)
        if (b.isEmpty()) return 0
        return Math.floorMod(hashSite(b, b.size, salt), n.toLong()).toInt()
    }

    /**
     * Sitenin (≈ eTLD+1) tuzlu 64 bit özeti. Site sınırı, genel sonek listesinin yüklü olup olmamasından BAĞIMSIZ sabit bir kuralla
     * bulunur ([siteStart]): liste sonradan yüklenince sitelerin sağlayıcısı değişmesin (tutarlılık gizliliğin temeli).
     */
    internal fun hashSite(b: ByteArray, len: Int, salt: Long): Long {
        var end = len
        if (end > 0 && b[end - 1] == '.'.code.toByte()) end--
        val start = siteStart(b, end)
        // Tuzla başlatılmış FNV-1a + splitmix64 son karıştırması: gizli tuz bilinmeden dağılım tahmin edilemez.
        var h = salt xor -0x340d631b7bdddcdbL
        for (i in start until end) { h = h xor (b[i].toLong() and 0xFF); h *= 0x100000001b3L }
        h = h xor (h ushr 30); h *= -0x40a7b892e31b1a47L
        h = h xor (h ushr 27); h *= -0x6b2fb644ecceee15L
        return h xor (h ushr 31)
    }

    /** Ülke alan adlarında ikinci düzey genel etiketler ("co.uk", "com.tr", "gov.au"): site bir etiket daha uzundur. */
    private val SLD = setOf("co", "com", "net", "org", "gov", "edu", "ac", "gen", "bel", "k12", "ltd", "plc", "ne", "or", "go", "mil", "nom", "biz",
        "info", "av", "dr", "pol", "tsk", "web", "tv", "bbs", "name", "tel", "kep", "per", "res", "sch", "nic", "gob", "mod")

    /** [b]'nin ilk [end] baytındaki adda sitenin başlangıcı: son iki etiket; ülke kodlu TLD'de ikinci düzey genel etiket varsa son üç. */
    internal fun siteStart(b: ByteArray, end: Int): Int {
        var d1 = -1; var d2 = -1; var d3 = -1
        var i = end - 1
        while (i >= 0) {
            if (b[i] == '.'.code.toByte()) { if (d1 < 0) d1 = i else if (d2 < 0) d2 = i else { d3 = i; break } }
            i--
        }
        if (d1 < 0 || d2 < 0) return 0                                  // tek ya da iki etiket: adın tamamı
        val tldLen = end - d1 - 1
        if (tldLen == 2 && isSld(b, d2 + 1, d1)) return if (d3 < 0) 0 else d3 + 1
        return d2 + 1
    }

    private fun isSld(b: ByteArray, from: Int, to: Int): Boolean {
        val n = to - from
        if (n < 2 || n > 4) return false
        for (w in SLD) if (w.length == n) { var ok = true; for (k in 0 until n) if (b[from + k].toInt() != w[k].code) { ok = false; break }; if (ok) return true }
        return false
    }

    /** Sorudaki adı küçük harf, noktalı biçimde [out]'a (en az 256 bayt) yazar ([DnsName] kuralları; soru bölümünde işaretçi yok). Uzunluk ya da -1. */
    internal fun readName(p: ByteArray, dnsOff: Int, dnsLen: Int, out: ByteArray): Int {
        val r = DnsName.read(p, dnsOff, dnsOff + Packets.DNS_HDR, dnsOff + dnsLen, out, false)
        return if (r < 0) -1 else DnsName.length(r)
    }

    /**
     * Ek sağlayıcılar: kullanıcının seçtikleri ([chosen], sırayla) ya da (boşsa) önerilenlerden ana sunucuyla AYNI markadan olmayanlar.
     * Her biri ana sunucunun şifreleme yöntemini destekliyorsa onunla; desteklemiyorsa planındaki ilk ŞİFRELİ yöntemle (ana sunucu
     * şifreliyken düz DNS'e asla düşülmez). Uygun yöntemi olmayan atlanır. En çok [MAX_PARTS] - 1 ek.
     */
    fun partners(primary: DnsServer, proto: Proto, chosen: List<String>, byId: (String) -> DnsServer?, plan: (DnsServer) -> List<Proto>): List<Pair<DnsServer, Proto>> {
        val ids = chosen.ifEmpty { suggested(primary) }
        val out = ArrayList<Pair<DnsServer, Proto>>()
        val brands = hashSetOf(primary.brand)
        for (id in ids) {
            if (out.size >= MAX_PARTS - 1) break
            val s = byId(id) ?: continue
            if (s.id == primary.id || (chosen.isEmpty() && s.brand in brands)) continue
            val pl = plan(s)
            val p = when {
                proto in pl -> proto
                proto == Proto.PLAIN -> pl.firstOrNull() ?: continue
                else -> pl.firstOrNull { it != Proto.PLAIN && it != Proto.ODOH } ?: continue
            }
            if (proto != Proto.PLAIN && p == Proto.PLAIN) continue
            out.add(s to p); brands.add(s.brand)
        }
        return out
    }

    /**
     * Önerilen ek sağlayıcılar, ana sunucunun TÜRÜNE göre: aile/güvenlik/reklam süzgeçli bir sunucu seçildiyse ortakları da aynı
     * türdendir (bölme, sitelerin bir kısmını süzgeçsiz sunucuya kaçırarak korumayı delmesin). Hepsi şifreli DNS sunar.
     */
    fun suggested(primary: DnsServer): List<String> = when (primary.variant) {
        Variant.FAMILY -> listOf("cloudflare-family", "adguard-family", "cleanbrowsing-family", "dns4eu-child", "opendns-family", "controld-family")
        Variant.SECURITY -> listOf("cloudflare-security", "quad9", "controld-malware", "dns4eu", "cira-protected", "cleanbrowsing-security")
        Variant.ADS -> listOf("adguard", "controld-ads", "dns4eu-ads")
        else -> listOf("quad9", "cloudflare", "dns4eu-open", "adguard-open", "switch", "nextdns")
    }

    /** Tuz yoksa (0) cihaza özgü yeni gizli tuz üretir (kriptografik rastgele, 0 olmayan); varsa aynen döner. */
    fun ensureSalt(cur: Long): Long {
        if (cur != 0L) return cur
        val r = java.security.SecureRandom()
        while (true) { val v = r.nextLong() ushr 1; if (v != 0L) return v }
    }

    /** "id1,id2" → en çok 2 geçerli biçimli kimlik. */
    fun decode(s: String?): List<String> =
        (s ?: "").split(',').map { it.trim() }.filter { it.isNotEmpty() && it.length <= 64 && it.all { c -> c.isLetterOrDigit() || c == '-' || c == '_' || c == ':' } }
            .distinct().take(MAX_PARTS - 1)

    fun encode(ids: List<String>): String = decode(ids.joinToString(",")).joinToString(",")
}

/**
 * [SplitDns] yönlendiricisi: her sorguyu sitesine göre bir alt yönlendiriciye verir. Alt yönlendiriciler cevaplarını tünele kendileri
 * yazar. Yalnızca tünel okuyucu iş parçacığından çağrılır ([Forwarder.onPacket] sözleşmesi).
 */
class SplitForwarder(
    private val parts: List<Forwarder>,
    private val salt: Long,
    private val now: () -> Long = { System.currentTimeMillis() },
) : Forwarder {
    init { require(parts.isNotEmpty()) }

    override val proto: Proto get() = parts[0].proto
    private val parsed = ParsedQuery()
    private val scratch = ByteArray(256)
    private val downUntil = LongArray(parts.size)
    private val sent = LongArray(parts.size)
    private val lastTimeouts = LongArray(parts.size)
    private val lastAnswered = LongArray(parts.size)
    private val lastForwarded = LongArray(parts.size)
    private val fails = IntArray(parts.size)
    /** Art arda "gönderildi ama hiç cevap yok" ölçüm sayısı (zaman aşımını beklemeden erken fark etmek için). */
    private val silent = IntArray(parts.size)
    private var lastCheck = 0L

    /** Sağlayıcı başına yönlendirilen sorgu sayısı (arayüz: "Cloudflare %52 · Quad9 %48"). */
    fun shares(): LongArray = sent.copyOf()
    /** Şu an devre dışı (yanıt vermeyen) sağlayıcılar. */
    fun down(): BooleanArray { val t = now(); return BooleanArray(parts.size) { downUntil[it] > t } }
    val size: Int get() = parts.size

    override fun start() { for (f in parts) f.start() }

    override fun onPacket(p: ByteArray, len: Int) {
        if (parts.size == 1) { sent[0]++; parts[0].onPacket(p, len); return }
        val t = now()
        if (t - lastCheck >= 2_000L || t < lastCheck) { lastCheck = t; health(t) }
        var i = 0
        if (parsed.parse(p, len, 4096)) i = SplitDns.index(p, parsed.dnsOff, parsed.dnsLen, parts.size, salt, scratch)
        // yanıt vermeyen sağlayıcının siteleri geçici olarak sıradakine
        var k = 0
        while (k < parts.size && downUntil[(i + k) % parts.size] > t) k++
        val target = if (k == parts.size) i else (i + k) % parts.size
        sent[target]++
        parts[target].onPacket(p, len)
    }

    /**
     * Sağlayıcı sağlığı (2 sn'de bir). İki yoldan devre dışı kalır ([SplitDns.DOWN_MS]):
     *  - zaman aşımları artıp hiç cevap gelmiyorsa ([SplitDns.DOWN_FAILS]);
     *  - ERKEN: art arda [SplitDns.SILENT_ROUNDS] ölçümde ona sorgu gidip ([SplitDns.SILENT_MIN] ve üstü) hiç cevap gelmediyse ve aynı
     *    sürede başka bir sağlayıcı cevap veriyorsa (ağ değil, o sağlayıcı sorunlu). Zaman aşımı sorgu başına birkaç saniye sürdüğü için
     *    eski yol ~10 sn'de fark ederdi; bu yol ~4 sn'de, o sağlayıcının sitelerini beklemeden diğerine verir.
     */
    private fun health(t: Long) {
        val da = LongArray(parts.size)
        val df = LongArray(parts.size)
        val dt = LongArray(parts.size)
        for (i in parts.indices) {
            val s = try { parts[i].stats() } catch (_: Exception) { continue }
            dt[i] = s.timeouts - lastTimeouts[i]
            da[i] = s.answered - lastAnswered[i]
            df[i] = s.forwarded - lastForwarded[i]
            lastTimeouts[i] = s.timeouts; lastAnswered[i] = s.answered; lastForwarded[i] = s.forwarded
        }
        for (i in parts.indices) {
            if (da[i] > 0) { fails[i] = 0; silent[i] = 0 } else if (dt[i] > 0) fails[i] += dt[i].toInt()
            val othersOk = parts.indices.any { it != i && da[it] > 0 }
            if (da[i] == 0L && df[i] >= SplitDns.SILENT_MIN && othersOk) silent[i]++ else if (da[i] > 0 || df[i] == 0L) silent[i] = 0
            if (downUntil[i] <= t && (fails[i] >= SplitDns.DOWN_FAILS || silent[i] >= SplitDns.SILENT_ROUNDS)) {
                downUntil[i] = t + SplitDns.DOWN_MS; fails[i] = 0; silent[i] = 0
            }
        }
    }

    override fun stats(): Stats {
        val a = parts.map { it.stats() }
        return Stats(
            queries = a.sumOf { it.queries }, cacheHits = a.sumOf { it.cacheHits }, forwarded = a.sumOf { it.forwarded }, answered = a.sumOf { it.answered },
            retries = a.sumOf { it.retries }, timeouts = a.sumOf { it.timeouts }, dropped = a.sumOf { it.dropped }, resets = a.sumOf { it.resets },
            latencySumMs = a.sumOf { it.latencySumMs }, failovers = a.sumOf { it.failovers }, backup = a[0].backup, blocked = a.sumOf { it.blocked },
            bytesUp = a.sumOf { it.bytesUp }, bytesDown = a.sumOf { it.bytesDown }, merged = a.sumOf { it.merged }, rejected = a.sumOf { it.rejected },
            tlsFailures = a.sumOf { it.tlsFailures }, stale = a.sumOf { it.stale }, blockPages = a.sumOf { it.blockPages },
            clockFailures = a.sumOf { it.clockFailures }, races = a.sumOf { it.races }, raceWins = a.sumOf { it.raceWins },
        )
    }

    override fun resetNetwork(reason: String) { for (f in parts) f.resetNetwork(reason); java.util.Arrays.fill(downUntil, 0L); java.util.Arrays.fill(fails, 0); java.util.Arrays.fill(silent, 0) }
    override fun clearCache() { for (f in parts) f.clearCache() }
    override fun close() { for (f in parts) try { f.close() } catch (_: Exception) {} }

    /** Tüm sağlayıcıların son süreleri, sırayla iç içe (en yeni sonda kalır). */
    override fun latencies(out: IntArray): Int {
        val bufs = parts.map { f -> IntArray(out.size).let { b -> b to f.latencies(b) } }
        var n = 0
        val idx = IntArray(parts.size)
        while (n < out.size) {
            var progressed = false
            for ((j, pair) in bufs.withIndex()) {
                if (idx[j] < pair.second && n < out.size) { out[n++] = pair.first[idx[j]++]; progressed = true }
            }
            if (!progressed) break
        }
        return n
    }
}
