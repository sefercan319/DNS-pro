package app.dnshizli.core

/**
 * ISO 3166-1 sayısal ülke kodu → iki harfli kod (ör. 792 → "TR"). Android, ICU'nun Region sınıfını uygulamalara açmadığı için
 * (derleme hatası: Unresolved reference 'Region') tablo burada tutulur. Kaynak: ISO 3166-1 (249 ülke/bölge; pycountry verisi).
 */
object IsoNumeric {
    private val MAP: Map<Int, String> = mapOf(
        4 to "AF", 8 to "AL", 10 to "AQ", 12 to "DZ", 16 to "AS", 20 to "AD", 24 to "AO", 28 to "AG",
        31 to "AZ", 32 to "AR", 36 to "AU", 40 to "AT", 44 to "BS", 48 to "BH", 50 to "BD", 51 to "AM",
        52 to "BB", 56 to "BE", 60 to "BM", 64 to "BT", 68 to "BO", 70 to "BA", 72 to "BW", 74 to "BV",
        76 to "BR", 84 to "BZ", 86 to "IO", 90 to "SB", 92 to "VG", 96 to "BN", 100 to "BG", 104 to "MM",
        108 to "BI", 112 to "BY", 116 to "KH", 120 to "CM", 124 to "CA", 132 to "CV", 136 to "KY", 140 to "CF",
        144 to "LK", 148 to "TD", 152 to "CL", 156 to "CN", 158 to "TW", 162 to "CX", 166 to "CC", 170 to "CO",
        174 to "KM", 175 to "YT", 178 to "CG", 180 to "CD", 184 to "CK", 188 to "CR", 191 to "HR", 192 to "CU",
        196 to "CY", 203 to "CZ", 204 to "BJ", 208 to "DK", 212 to "DM", 214 to "DO", 218 to "EC", 222 to "SV",
        226 to "GQ", 231 to "ET", 232 to "ER", 233 to "EE", 234 to "FO", 238 to "FK", 239 to "GS", 242 to "FJ",
        246 to "FI", 248 to "AX", 250 to "FR", 254 to "GF", 258 to "PF", 260 to "TF", 262 to "DJ", 266 to "GA",
        268 to "GE", 270 to "GM", 275 to "PS", 276 to "DE", 288 to "GH", 292 to "GI", 296 to "KI", 300 to "GR",
        304 to "GL", 308 to "GD", 312 to "GP", 316 to "GU", 320 to "GT", 324 to "GN", 328 to "GY", 332 to "HT",
        334 to "HM", 336 to "VA", 340 to "HN", 344 to "HK", 348 to "HU", 352 to "IS", 356 to "IN", 360 to "ID",
        364 to "IR", 368 to "IQ", 372 to "IE", 376 to "IL", 380 to "IT", 384 to "CI", 388 to "JM", 392 to "JP",
        398 to "KZ", 400 to "JO", 404 to "KE", 408 to "KP", 410 to "KR", 414 to "KW", 417 to "KG", 418 to "LA",
        422 to "LB", 426 to "LS", 428 to "LV", 430 to "LR", 434 to "LY", 438 to "LI", 440 to "LT", 442 to "LU",
        446 to "MO", 450 to "MG", 454 to "MW", 458 to "MY", 462 to "MV", 466 to "ML", 470 to "MT", 474 to "MQ",
        478 to "MR", 480 to "MU", 484 to "MX", 492 to "MC", 496 to "MN", 498 to "MD", 499 to "ME", 500 to "MS",
        504 to "MA", 508 to "MZ", 512 to "OM", 516 to "NA", 520 to "NR", 524 to "NP", 528 to "NL", 531 to "CW",
        533 to "AW", 534 to "SX", 535 to "BQ", 540 to "NC", 548 to "VU", 554 to "NZ", 558 to "NI", 562 to "NE",
        566 to "NG", 570 to "NU", 574 to "NF", 578 to "NO", 580 to "MP", 581 to "UM", 583 to "FM", 584 to "MH",
        585 to "PW", 586 to "PK", 591 to "PA", 598 to "PG", 600 to "PY", 604 to "PE", 608 to "PH", 612 to "PN",
        616 to "PL", 620 to "PT", 624 to "GW", 626 to "TL", 630 to "PR", 634 to "QA", 638 to "RE", 642 to "RO",
        643 to "RU", 646 to "RW", 652 to "BL", 654 to "SH", 659 to "KN", 660 to "AI", 662 to "LC", 663 to "MF",
        666 to "PM", 670 to "VC", 674 to "SM", 678 to "ST", 682 to "SA", 686 to "SN", 688 to "RS", 690 to "SC",
        694 to "SL", 702 to "SG", 703 to "SK", 704 to "VN", 705 to "SI", 706 to "SO", 710 to "ZA", 716 to "ZW",
        724 to "ES", 728 to "SS", 729 to "SD", 732 to "EH", 740 to "SR", 744 to "SJ", 748 to "SZ", 752 to "SE",
        756 to "CH", 760 to "SY", 762 to "TJ", 764 to "TH", 768 to "TG", 772 to "TK", 776 to "TO", 780 to "TT",
        784 to "AE", 788 to "TN", 792 to "TR", 795 to "TM", 796 to "TC", 798 to "TV", 800 to "UG", 804 to "UA",
        807 to "MK", 818 to "EG", 826 to "GB", 831 to "GG", 832 to "JE", 833 to "IM", 834 to "TZ", 840 to "US",
        850 to "VI", 854 to "BF", 858 to "UY", 860 to "UZ", 862 to "VE", 876 to "WF", 882 to "WS", 887 to "YE",
        894 to "ZM",
        383 to "XK",
    )

    /** İki harfli kod; bilinmeyen sayıda null. */
    fun alpha2(numeric: Int): String? = MAP[numeric]

    val size: Int get() = MAP.size
}
