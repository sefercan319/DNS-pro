package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.Section
import app.dnshizli.ui.SectionPage
import app.dnshizli.ui.Strings
import java.io.File

/** sizma52: mevcut özelliklerin iyileştirilmesi — WireGuard canlı durumu, bağlantı denetiminde daha çok marka. */
internal fun runRound28Tests() {
    wgLive()
    linkBrands()
    globeCountries()
    previews52()
}

private fun previews52() {
    T.group("sizma52: ön izleme görselleri")
    val awt = AwtGfx(java.awt.image.BufferedImage(1, 1, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics())
    app.dnshizli.ui.GlobeNode.syncShading = true; app.dnshizli.ui.GlobeNode.syncBuild = true
    GlobeLand.map
    val trNames = mapOf(792 to "Türkiye", 300 to "Yunanistan", 100 to "Bulgaristan", 250 to "Fransa", 276 to "Almanya", 380 to "İtalya", 392 to "Japonya")
    fun globeShot(theme: String, st: UiStyle, lat: Double, lon: Double, zoom: Double, tapAt: Boolean, file: String) {
        val r = Rig(Rig.base(theme).copy(style = st), 360, 780, metrics = awt)
        r.host.countryNames = { n, _ -> trNames[n] }
        r.tapText(Strings.GLOBE, settleMs = 900)
        val g = findGlobe(r.scene.currentPage!!)!!
        g.camera.focus(Math.toRadians(lat), Math.toRadians(lon)); if (zoom > 1) g.camera.zoomBy(zoom); r.settle(50)
        if (tapAt) r.tap(g.absX() + g.w / 2, g.absY() + g.h / 2, settleMs = 400)
        val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/$file.png"); cv.dispose()
    }
    globeShot("aqua", UiStyle.AQUA, 39.0, 35.0, 3.0, true, "kure3-ulke-adi-turkiye")
    globeShot("night", UiStyle.AERO, 46.0, 1.5, 4.0, true, "kure3-ulke-adi-fransa")
    globeShot("aqua", UiStyle.AQUA, 30.0, 30.0, 1.0, false, "kure3-tam")
    globeShot("sapphire", UiStyle.LIQUID, 40.6, 27.5, 12.0, false, "kure3-marmara-12x")
    globeShot("northern", UiStyle.AURORA, 60.0, 20.0, 1.6, false, "kure3-aurora")
    globeShot("aqua", UiStyle.METRO, 36.8, 138.4, 2.0, true, "kure3-metro-japonya")
    // WireGuard canlı durumu
    run {
        val r = Rig(Rig.base("aqua"), 360, 780, metrics = awt)
        r.host.wgText = "[Interface]\nPrivateKey = yAnz5TF+lXXJte14tji3zlMNq+hd2rYUIgJBgB3fBmk=\nAddress = 10.0.0.2/32\n[Peer]\nPublicKey = xTIBA5rboUvnH4htodjb6e697QjLERt1NAB4mZqp8Dg=\nEndpoint = 1.2.3.4:51820\nAllowedIPs = 0.0.0.0/0\n"
        r.host.wgConnect()
        r.host.wgStatsVal = WgStats(true, true, true, false, false, false, 48_300_000, 6_120_000, 37, 1800)
        r.scene.openSection(Section.EXPERIMENTAL); r.settle(900)
        val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/wg-canli-durum.png"); cv.dispose()
    }
    T.check("ön izlemeler üretildi", listOf("kure3-ulke-adi-turkiye", "kure3-ulke-adi-fransa", "kure3-tam", "kure3-marmara-12x", "kure3-aurora", "kure3-metro-japonya", "wg-canli-durum").all { File("build/onizleme/$it.png").isFile })
}

private fun findGlobe(n: app.dnshizli.ui.Node): app.dnshizli.ui.GlobeNode? = (n as? app.dnshizli.ui.GlobeNode) ?: n.children.firstNotNullOfOrNull { findGlobe(it) }

private fun globeCountries() {
    T.group("sizma52: küre: dokunulan ülkenin adı")
    val map = GlobeLand.map
    T.check("her ülkenin ISO sayısal kodu (Türkiye 792, Fransa 250, Japonya 392); kodsuz bölgeler 0", map.numeric.size == map.countryCount &&
        map.numeric[map.countryAt(39.0, 35.0)] == 792 && map.numeric[map.countryAt(47.0, 2.5)] == 250 && map.numeric[map.countryAt(36.0, 138.0)] == 392 &&
        map.numeric.count { it == 0 } in 1..30)
    // hızlı (halka başlığı süzgeçli) arama, tüm halkaları gezen aramayla aynı sonucu verir
    fun slow(la: Double, lo: Double): Int {
        for (c in 0 until map.countryCount) {
            var inside = false
            for (q in map.ringStart[c] until map.ringStart[c + 1]) {
                var px = Double.NaN; var py = 0.0
                map.forRing(q) { x, y, z ->
                    val a = Math.toDegrees(kotlin.math.asin(z.toDouble().coerceIn(-1.0, 1.0))); val o = Math.toDegrees(kotlin.math.atan2(y.toDouble(), x.toDouble()))
                    if (!px.isNaN() && kotlin.math.abs(o - px) < 180 && ((py > la) != (a > la)) && lo < (o - px) * (la - py) / (a - py) + px) inside = !inside
                    px = o; py = a
                }
            }
            if (inside) return c
        }
        return -1
    }
    val rnd = java.util.Random(52)
    val pts = (0 until 150).map { (rnd.nextDouble() * 140 - 60) to (rnd.nextDouble() * 360 - 180) }
    // tam arama düzlemde ışın atar: 180. boylamda bölünen Fiji'nin dikiş kenarı yüzünden uzak okyanus noktalarını Fiji sanabilir;
    // hızlı arama halka başlığıyla bunu da düzeltir. Fark yalnız bu tür noktalarda olmalı (hızlı -1, tam Fiji).
    val diff = pts.filter { (a, o) -> map.countryAt(a, o) != slow(a, o) }
    T.check("hızlı ülke araması tam aramayla aynı; tek fark tam aramanın 180° dikiş hatası (Fiji)", diff.all { (a, o) -> map.countryAt(a, o) == -1 && map.names[slow(a, o)] == "Fiji" } &&
        diff.size < 10 && map.countryAt(-17.8, 178.0).let { it >= 0 && map.names[it] == "Fiji" }, diff.joinToString { (a, o) -> "%.1f,%.1f".format(a, o) })
    val t0 = System.nanoTime(); repeat(20) { map.countryAt(39.0, 35.0) }; val ms = (System.nanoTime() - t0) / 1e6 / 20
    T.check("dokunuşta ülke araması hızlı (< 5 ms)", ms < 5.0, "%.2f ms".format(ms))

    app.dnshizli.ui.GlobeNode.syncShading = true; app.dnshizli.ui.GlobeNode.syncBuild = true
    val rig = Rig(Rig.base()); rig.tapText(Strings.GLOBE, settleMs = 900)
    val g = findGlobe(rig.scene.currentPage!!)!!
    g.camera.focus(Math.toRadians(39.0), Math.toRadians(35.0)); g.camera.zoomBy(3.0); rig.settle(50)
    rig.tap(g.absX() + g.w / 2, g.absY() + g.h / 2, settleMs = 100)
    T.check("karaya dokununca ülkenin adı (cihaz adı yoksa Natural Earth adı)", g.tapLabel == "Turkey", "${g.tapLabel}")
    class Txt : CountingGfx() { val texts2 = ArrayList<String>(); override fun text(s: String, x: Float, baseline: Float, size: Float, bold: Boolean, align: Int) { texts2.add(s) } }
    val tx = Txt(); g.draw(tx, rig.scene.env)
    T.check("ad küreye iğneli etiketle çizilir, ekran okuyucu da okur", tx.texts2.contains("Turkey") && g.a11y().label.contains("Turkey"))
    rig.settle(3500)
    T.check("ad birkaç saniye sonra kaybolur", g.tapLabel == null)
    rig.host.countryNames = { n, lang -> if (n == 792 && lang == "tr") "Türkiye" else null }
    rig.settle(400)
    rig.tap(g.absX() + g.w / 2, g.absY() + g.h / 2, settleMs = 100)
    T.check("cihazın ülke adları tablosu uygulama dilinde kullanılır (Türkiye)", g.tapLabel == "Türkiye", "${g.tapLabel}")
    rig.settle(3500)
    g.camera.focus(Math.toRadians(-20.0), Math.toRadians(-140.0)); rig.settle(50)
    rig.tap(g.absX() + g.w / 2, g.absY() + g.h / 2, settleMs = 100)
    T.check("denize dokununca ad yok", g.tapLabel == null)
    val ma = File("app/src/main/java/app/dnshizli/platform/MainActivity.kt").readText()
    T.check("Android: ad kendi ISO tablomuzdan (sayısal kod → iki harfli kod → uygulama dilinde ad; ICU Region uygulamalara açık değil)", ma.contains("app.dnshizli.core.IsoNumeric.alpha2(numeric)") && ma.contains("getDisplayCountry(java.util.Locale.forLanguageTag(lang))") && !ma.contains("android.icu.util.Region"))
    val svc = File("app/src/main/java/app/dnshizli/platform/WgVpnService.kt").readText()
    T.check("WireGuard bildirimi bağlıyken 30 sn'de bir sessizce canlı durumu gösterir", svc.contains("NOTIF_REFRESH_MS = 30_000L") && svc.contains("val live = if (connected) snapshot()?.line() else null"))
}

private fun wgLive() {
    T.group("sizma52: WireGuard canlı durumu")
    val s = WgStats(connected = true, stealth = true, pq = true, pqWait = false, hop = false, shaping = false,
        rxBytes = 13_000_000, txBytes = 3_250_000, handshakeAgeSec = 45, upSec = 600)
    val line = s.line()
    T.check("durum satırı: bağlı, yol, PQ, trafik (dile göre birim), son el sıkışma", line.startsWith(Strings.WG_LIVE_ON) && line.contains("Stealth") && line.contains("PQ") &&
        line.contains("↓ 12 MB") && line.contains("↑ 3,1 MB") && line.contains("45 sn önce"), line)
    val old = WgStats(true, false, false, true, true, true, 0, 0, 4 * 60, 600)
    T.check("3 dakikadır el sıkışma yoksa 'yanıt yok' uyarısı; PQ bekleniyor, çoklu atlama, gizleme yazılır",
        old.stale && old.line().startsWith(Strings.WG_STALE) && old.line().contains(Strings.WG_PQ_WAIT) && old.line().contains(Strings.WG_HOP_SHORT) && old.line().contains("4 dk önce"))
    T.check("el sıkışma hiç olmadıysa yaş yazılmaz, 'el sıkışılıyor'", WgStats(false, false, false, false, false, false, 0, 0, -1, 1).line().let { it.startsWith(Strings.WG_LIVE_WAIT) && !it.contains("önce") })

    val rig = Rig(Rig.base())
    rig.host.wgText = "[Interface]\nPrivateKey = yAnz5TF+lXXJte14tji3zlMNq+hd2rYUIgJBgB3fBmk=\nAddress = 10.0.0.2/32\n[Peer]\nPublicKey = xTIBA5rboUvnH4htodjb6e697QjLERt1NAB4mZqp8Dg=\nEndpoint = 1.2.3.4:51820\nAllowedIPs = 0.0.0.0/0\n"
    val summary = rig.model.wgSummary()
    T.check("tünel kapalıyken yapılandırma özeti", summary != null && rig.model.wgStatusLine() == summary)
    rig.host.wgConnect(); rig.host.wgStatsVal = s
    T.check("tünel açıkken canlı durum satırı", rig.model.wgStatusLine() == line)
    rig.scene.openSection(Section.EXPERIMENTAL); rig.settle(900)
    val page = rig.scene.currentPage as? SectionPage
    fun wgValue() = rig.find(Strings.WG_TITLE, exact = true)?.info?.value ?: ""
    T.check("WireGuard satırında canlı durum görünür (ekran okuyucu değerin tamamını okur)", wgValue() == line, wgValue())
    T.check("boştaki sahne saniyede bir uyanır (sürekli kare çizmeden)", page != null && page.slowWakeMs() == 1000 && rig.scene.tick(rig.host.now + 5000) in 1..1000L)
    rig.host.wgStatsVal = WgStats(true, true, true, false, false, false, 20_000_000, 3_250_000, 2, 610)
    rig.advance(1100)
    T.check("değer saniyede bir yenilenir", wgValue().contains("↓ 19 MB"), wgValue())
    rig.host.wgDisconnect()
    T.check("tünel kapanınca uyanma isteği biter", page!!.slowWakeMs() == -1)
    val svc = File("app/src/main/java/app/dnshizli/platform/WgVpnService.kt").readText()
    T.check("Android: servis anlık görüntüsü (giriş tüneli trafiği, el sıkışma yaşı), kapanışta oturum trafiği günlüğe",
        svc.contains("fun stats(): WgStats? = if (running) live?.snapshot() else null") && svc.contains("rxBytes = e.rxBytes, txBytes = e.txBytes") &&
            svc.contains("Journal.add(\"WireGuard durdu: \$why\$traffic\")"))
    T.check("Android: ana etkinlik canlı durumu servisten okur", File("app/src/main/java/app/dnshizli/platform/MainActivity.kt").readText().contains("override fun wgStats(): app.dnshizli.core.WgStats? = WgVpnService.stats()"))
}

private fun linkBrands() {
    T.group("sizma52: bağlantı denetimi: yeni markalar")
    fun lv(u: String) = LinkCheck.check(u).level
    val ok = listOf("https://www.ing.com.tr/tr/bireysel", "https://www.kuveytturk.com.tr", "https://www.teb.com.tr", "https://www.yemeksepeti.com",
        "https://www.n11.com/kampanyalar", "https://www.btcturk.com", "https://www.binance.tr", "https://www.binance.com/tr", "https://enabiz.gov.tr",
        "https://mhrs.gov.tr", "https://www.egm.gov.tr", "https://steamcommunity.com/market", "https://store.steampowered.com", "https://telegram.org",
        "https://telegra.ph/abc", "https://www.suratkargo.com.tr/gonderi-takip", "https://www.dhl.com.tr")
    val badOk = ok.filter { lv(it) != LinkCheck.Level.OK }
    T.check("resmî adresler temiz (yanlış alarm yok)", badOk.isEmpty(), badOk.joinToString())
    val danger = listOf("https://ingbank-guvenlik.com/giris", "http://teb-mobil.net", "https://kuveytturk-destek.xyz", "https://steamcommunity-gift.ru/trade",
        "https://steamcommunlty.com/login", "https://yemeksepeti-hediye.top", "https://binance-odeme.xyz/claim", "https://egmceza.com",
        "https://enabiz-randevu.com", "https://btcturk-airdrop.com", "https://suratkargo-teslimat.info", "https://paribu.com-giris.ru")
    val missed = danger.filter { lv(it) != LinkCheck.Level.DANGER }
    T.check("taklit ve marka içeren sahte adresler TEHLİKE", missed.isEmpty(), missed.joinToString { "$it=${lv(it)}" })
    T.check("küresel markalarda ülke alanı serbest, başka alanda dikkat", lv("https://www.binance.us") == LinkCheck.Level.OK && lv("https://telegram-kanal.example.com") != LinkCheck.Level.OK)
    T.check("yeni tuzak sözcükler (icra, vergi, kimlik, tahsilat) resmî olmayan adreste dikkat", listOf("icra", "vergi", "kimlik", "tahsilat").all { lv("https://ornek-$it.example.com") != LinkCheck.Level.OK } && lv("https://www.gib.gov.tr/vergi") == LinkCheck.Level.OK)
}
