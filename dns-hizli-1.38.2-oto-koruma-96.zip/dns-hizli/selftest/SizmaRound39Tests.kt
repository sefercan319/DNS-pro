package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File

/**
 * sizma63: altı mevcut özelliğin işini daha iyi yapması — DNS sel dayanıklılığı (alım arabelleği), ağ geçidinde süren bağlantılara
 * öncelik, DNS bölmede yanıt vermeyen sağlayıcıyı erken fark etme, tünel kuyruğu dolunca DNS cevabını kaybetmeme, gizlilik testinde
 * yedek ölçüm adresleri, ağa uyarlanan bayat cevap süresi. (Sel ölçümleri: sizma16.)
 */
internal fun runRound39Tests() {
    rcvbufTests()
    synPriorityTests()
    splitSilentTests()
    tunnelWriteTests()
    probeFallbackTests()
    staleTests()
    isoTests()
}

private fun rcvbufTests() {
    T.group("sizma63: DNS sel dayanıklılığı: üst sunucu soketi alım arabelleği")
    T.check("alım arabelleği 512 KB (önce 64 KB ≈ 60 cevap; şimdi ≈ 500)", DnsForwarder.RCVBUF == 512 * 1024)
    val src = File("app/src/main/java/app/dnshizli/core/DnsForwarder.kt").readText()
    T.check("yuva soketleri bu değeri kullanır", src.contains("s.receiveBufferSize = RCVBUF") && !src.contains("receiveBufferSize = 64 * 1024"))
}

private fun synPriorityTests() {
    T.group("sizma63: ağ geçidi: süren bağlantılara öncelik")
    val r = GRig()
    try {
        val b = ByteArray(80)
        fun tcp(flags: Int, v6: Boolean = false): Int = Gw.tcp(b, v6, if (v6) SelfTest.CLIENT6 else CLI4, if (v6) SelfTest.CLIENT6 else LO4, 41000, 443, 1, 0, flags, 65535, ByteArray(0), 0, 0, 0)
        T.check("yalın SYN yeni bağlantıdır", r.gw.isPureSyn(b, tcp(F_SYN)))
        T.check("SYN+ACK, ACK, veri, FIN, RST yeni bağlantı değildir", listOf(F_SYN or F_ACK, F_ACK, F_ACK or F_PSH, F_FIN or F_ACK, F_RST).none { r.gw.isPureSyn(b, tcp(it)) })
        T.check("IPv6 SYN de tanınır", r.gw.isPureSyn(b, tcp(F_SYN, v6 = true)))
        val u = ByteArray(64); val n = Gw.udp(u, false, CLI4, LO4, 41000, 53, ByteArray(8), 0, 8)
        T.check("UDP ve kısa paket yeni bağlantı değildir", !r.gw.isPureSyn(u, n) && !r.gw.isPureSyn(b, 30))
        b[6] = 0x20.toByte(); b[7] = 1    // parça (ilk parça değil)
        T.check("parça yeni bağlantı sayılmaz (ana kuyruğa gider)", !r.gw.isPureSyn(b, tcp(F_SYN).also { Packets.put16(b, 6, 0x0010) }))
    } finally { r.close() }
    val src = File("app/src/main/java/app/dnshizli/core/Gateway.kt").readText()
    T.check("yeni bağlantı kuyruğu ayrı ve sınırlı; tur başına sınırlı sayıda SYN işlenir (süren trafik önce)",
        src.contains("const val FRESH_MAX = 1024") && src.contains("const val FRESH_PER_ROUND = 256") && src.indexOf("var p = inbox.poll()") < src.indexOf("val q = fresh.poll()"))
}

private class SilentFw(val answers: Boolean) : Forwarder {
    override val proto: Proto = Proto.DOH
    var got = 0L
    override fun start() {}
    override fun onPacket(p: ByteArray, len: Int) { got++ }
    override fun stats() = Stats(queries = got, forwarded = got, answered = if (answers) got else 0L, latencySumMs = if (answers) got * 10 else 0L)
    override fun resetNetwork(reason: String) {}
    override fun clearCache() {}
    override fun close() {}
}

private fun dq(name: String): ByteArray {
    val dns = Dns.buildQuery(0x4242, name)
    val b = ByteArray(Packets.HDR + dns.size)
    System.arraycopy(dns, 0, b, Packets.HDR, dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size); Packets.put16(b, 6, 0x4000); b[8] = 64; b[9] = 17
    Packets.put32(b, 12, Packets.ip(10, 111, 222, 1)); Packets.put32(b, 16, Packets.ip(10, 111, 222, 2))
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, 40600); Packets.put16(b, 22, 53); Packets.put16(b, 24, 8 + dns.size)
    return b
}

private fun splitSilentTests() {
    T.group("sizma63: DNS bölme: yanıt vermeyen sağlayıcıyı erken fark etme")
    val dead = SilentFw(false); val ok = SilentFw(true)
    var now = 5_000_000L
    val sf = SplitForwarder(listOf(dead, ok), 7L) { now }
    val names = (0 until 400).map { "s$it.site$it.org" }
    val toDead = names.filter { SplitDns.indexOf(it, 2, 7L) == 0 }
    val toOk = names.filter { SplitDns.indexOf(it, 2, 7L) == 1 }
    fun round(k: Int) { for (i in 0 until 4) { val a = dq(toDead[(k * 4 + i) % toDead.size]); sf.onPacket(a, a.size); val b = dq(toOk[(k * 4 + i) % toOk.size]); sf.onPacket(b, b.size) }; now += 2_100 }
    round(0); round(1)
    T.check("ilk ölçümlerde henüz karar yok (tek pencere yetmez)", !sf.down()[0])
    round(2); round(3)
    T.check("~4–6 sn içinde yanıt vermeyen sağlayıcı devre dışı (zaman aşımı beklenmeden)", sf.down()[0] && !sf.down()[1])
    val before = dead.got
    val a = dq(toDead[0]); sf.onPacket(a, a.size)
    T.check("onun siteleri diğer sağlayıcıya gider", dead.got == before && ok.got > 0)
    now += SplitDns.DOWN_MS + 1
    sf.onPacket(a, a.size)
    T.check("1 dk sonra yeniden denenir", !sf.down()[0])
    // Ağ yoksa (kimse cevap vermiyor) hiçbiri devre dışı bırakılmaz: sorun sağlayıcıda değil ağda.
    val d1 = SilentFw(false); val d2 = SilentFw(false)
    val sf2 = SplitForwarder(listOf(d1, d2), 7L) { now }
    repeat(6) { k -> for (i in 0 until 4) { val x = dq(names[(k * 8 + i) % names.size]); sf2.onPacket(x, x.size) }; now += 2_100 }
    T.check("hiçbiri cevap vermiyorsa (ağ yok) erken devre dışı yok", sf2.down().none { it })
}

private fun tunnelWriteTests() {
    T.group("sizma63: tünel: kuyruk dolunca DNS cevabı kaybolmaz")
    val t = File("app/src/main/java/app/dnshizli/platform/Tunnel.kt").readText()
    T.check("DNS cevapları kuyruk boşalana dek kısa beklenip yeniden yazılır; ağ geçidi beklemez",
        t.contains("rawWrite(b, off, len, retry = true)") && t.contains("e.errno != OsConstants.EAGAIN") && t.contains("OsConstants.POLLOUT") &&
            t.contains("fun writeRaw(b: ByteArray, off: Int, len: Int) = rawWrite(b, off, len)"))
    T.check("bekleme üst sınırlı (en çok 3 × 2 ms)", t.contains("const val WRITE_TRIES = 3") && t.contains("const val WRITE_WAIT_MS = 2"))
}

private fun probeFallbackTests() {
    T.group("sizma63: gizlilik testi: yedek ölçüm adresleri")
    T.check("IPv4/IPv6 için ikişer sabit IP'li adres; ilki eskisiyle aynı", PrivacyCheck.TRACE4_ALL.size == 2 && PrivacyCheck.TRACE4_ALL[0] == PrivacyCheck.TRACE4 &&
        PrivacyCheck.TRACE6_ALL.size == 2 && PrivacyCheck.TRACE6_ALL[0] == PrivacyCheck.TRACE6 && (PrivacyCheck.TRACE4_ALL + PrivacyCheck.TRACE6_ALL).all { it.startsWith("https://") && it.endsWith("/cdn-cgi/trace") })
    T.check("üç STUN sunucusu, farklı işletmeciler", PrivacyCheck.STUNS.size == 3 && PrivacyCheck.STUNS.map { it.first.substringAfter('.').substringAfter('.') }.toSet().size >= 2)
    val pr = File("app/src/main/java/app/dnshizli/platform/PrivacyProber.kt").readText()
    T.check("sıradaki adres ancak öncekinden sonuç alınamazsa; toplam süre sınırlı", pr.contains("firstOk(PrivacyCheck.TRACE4_ALL)") && pr.contains("for ((host, port) in PrivacyCheck.STUNS)") && pr.contains("TOTAL_MS = 9_000L"))
}

private fun staleTests() {
    T.group("sizma63: DNS önbellek: ağa uyarlanan bayat cevap süresi")
    val e = RttEstimator()
    T.check("ölçüm yokken eski sabit (1,8 sn)", MobilePolicy.dnsStaleMs(e) == 1800L)
    repeat(20) { e.sample(30.0) }
    T.check("hızlı ağda takılan sorgu ~0,7 sn'de eski cevapla karşılanır", MobilePolicy.dnsStaleMs(e) == 700L)
    val slow = RttEstimator(); repeat(20) { slow.sample(if (it % 2 == 0) 500.0 else 900.0) }
    T.check("yavaş/dalgalı ağda gerçek cevaba şans tanınır (1,8 sn'ye kadar)", MobilePolicy.dnsStaleMs(slow) == 1800L)
    val mid = RttEstimator(); repeat(20) { mid.sample(120.0) }
    T.check("orta ağda arada bir değer", MobilePolicy.dnsStaleMs(mid) in 701L..1799L || MobilePolicy.dnsStaleMs(mid) == 700L)
    val src = File("app/src/main/java/app/dnshizli/core/DnsForwarder.kt").readText()
    T.check("yönlendirici varsayılan olarak uyarlanan süreyi kullanır", src.contains("private val staleAfterMs: Long = ADAPTIVE,") && src.contains("MobilePolicy.dnsStaleMs(rttEst)"))
}

private fun isoTests() {
    T.group("sizma63: derleme düzeltmesi: ülke adı (ICU Region yok)")
    T.check("ISO 3166-1 tablosu tam (249 + Kosova)", IsoNumeric.size == 250)
    T.check("örnekler: 792 TR, 276 DE, 840 US, 4 AF, 383 XK; bilinmeyen null", IsoNumeric.alpha2(792) == "TR" && IsoNumeric.alpha2(276) == "DE" &&
        IsoNumeric.alpha2(840) == "US" && IsoNumeric.alpha2(4) == "AF" && IsoNumeric.alpha2(383) == "XK" && IsoNumeric.alpha2(999) == null)
    T.check("Türkçe ad Java yerel ayarından", java.util.Locale("", IsoNumeric.alpha2(792)!!).getDisplayCountry(java.util.Locale.forLanguageTag("tr")) == "Türkiye")
    val bad = File("app/src/main/java/app/dnshizli").walk().filter { it.extension == "kt" }.filter { it.readText().contains("android.icu.util.Region") }.map { it.name }.toList()
    T.check("Android'in uygulamalara açmadığı ICU Region sınıfı hiçbir yerde kullanılmaz", bad.isEmpty(), bad.toString())
}
