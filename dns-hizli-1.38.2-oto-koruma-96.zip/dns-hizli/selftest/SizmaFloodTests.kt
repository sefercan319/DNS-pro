package app.dnshizli.selftest

import app.dnshizli.core.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.ScheduledThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicLongArray

/**
 * Sızma 16 — yük / DDoS kampanyası. Normal bir telefon saniyede on-yüz DNS sorgusu üretir; burada her katman, üretici iş
 * parçacığının yapabildiği en yüksek hızla (normalin 2000 katı ve üstü) sürülür. Her saldırıda: süre, yığın, iş parçacığı,
 * dosya tanıtıcısı, tablo sınırları ve "mağdur" (dürüst) trafiğin kaybı/gecikmesi ölçülür; saldırı bitince sistem eski haline dönmelidir.
 */

internal fun usedHeapMb(): Long { System.gc(); System.gc(); val rt = Runtime.getRuntime(); return (rt.totalMemory() - rt.freeMemory()) shr 20 }
internal fun liveThreads(): Int = Thread.getAllStackTraces().keys.count { it.isAlive }

/** Hızlı (isteğe bağlı gecikmeli) üst sunucu: her sorguya A kaydı döner. */
private class FloodUp(val delayMs: Long = 0, val answer: Boolean = true, val nxFor: (String) -> Boolean = { it.startsWith("u") }, val ttl: Int = 1) : AutoCloseable {
    private val loop = InetAddress.getLoopbackAddress()
    val socket = DatagramSocket(0, loop).also { it.receiveBufferSize = 8 * 1024 * 1024 }
    val addr: InetSocketAddress get() = InetSocketAddress(loop, socket.localPort)
    val received = AtomicLong()
    private val pool = ScheduledThreadPoolExecutor(2)
    private val ip = byteArrayOf(9, 9, 9, 9)

    init {
        Thread {
            val buf = ByteArray(2048)
            val p = DatagramPacket(buf, buf.size)
            while (!socket.isClosed) {
                try { p.length = buf.size; socket.receive(p) } catch (_: Exception) { return@Thread }
                received.incrementAndGet()
                if (!answer) continue
                val q = buf.copyOf(p.length)
                val nm = floodName(q)
                val resp = if (nxFor(nm)) q.copyOf().also { Packets.put16(it, 2, 0x8183) } else buildAnswer(q, q.size, aRecord(ip, ttl), 1)
                val to = p.socketAddress
                if (delayMs <= 0) { try { socket.send(DatagramPacket(resp, resp.size, to)) } catch (_: Exception) { return@Thread } }
                else try { pool.schedule(Runnable { try { socket.send(DatagramPacket(resp, resp.size, to)) } catch (_: Exception) { } }, delayMs, TimeUnit.MILLISECONDS) } catch (_: Exception) { }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    override fun close() { socket.close(); pool.shutdownNow() }
}

private fun floodName(q: ByteArray): String {
    val sb = StringBuilder(); var i = 12
    while (i < q.size) { val l = q[i].toInt() and 0xFF; if (l == 0 || i + 1 + l > q.size) break; if (sb.isNotEmpty()) sb.append('.'); sb.append(String(q, i + 1, l, Charsets.ISO_8859_1)); i += 1 + l }
    return sb.toString().lowercase()
}

private class FloodResult(val sent: Long, val seconds: Double, val victims: Int, val victimOk: Int, val p50: Long, val p95: Long, val maxPending: Int, val replies: Long)

/**
 * [ms] boyunca tek üretici iş parçacığı (gerçek tünel okuyucusu gibi tek iş parçacığı) mümkün olan en yüksek hızla benzersiz adlı
 * sorgu basar; her [victimEvery] sorguda bir "mağdur" sorgu (ayrı kaynak port) karışır. Cevaplar ayrı bir iş parçacığında sayılır.
 */
private fun dnsFlood(h: Harness, ms: Long, victimEvery: Int, attackPorts: Int, zones: Int, qpsCap: Long = 0, newZoneVictims: Boolean = false, nameOf: (Long) -> String = { "u$it.d${it % zones}.net" }): FloodResult {
    val sentAt = AtomicLongArray(65536)
    val lat = java.util.Collections.synchronizedList(ArrayList<Long>())
    val replies = AtomicLong()
    val stop = java.util.concurrent.atomic.AtomicBoolean(false)
    val drain = Thread {
        while (!stop.get() || h.tunWrites.isNotEmpty()) {
            val r = h.tunWrites.poll(20, TimeUnit.MILLISECONDS) ?: continue
            replies.incrementAndGet()
            if (Packets.u16(r, 22) == 50000) {
                val id = Packets.u16(r, 28)
                val t = sentAt.get(id)
                if (t != 0L && sentAt.compareAndSet(id, t, 0L)) lat.add((System.nanoTime() - t) / 1_000_000)
            }
        }
    }.also { it.isDaemon = true; it.start() }
    var n = 0L
    var victims = 0
    var maxPending = 0
    val t0 = System.nanoTime()
    val end = t0 + ms * 1_000_000
    while (System.nanoTime() < end) {
        if (qpsCap > 0) { val due = t0 + n * 1_000_000_000L / qpsCap; while (System.nanoTime() < due) Thread.onSpinWait() }
        for (k in 0 until 64) {
            n++
            h.send(clientPacket((n and 0xFFFF).toInt(), nameOf(n), srcPort = 20000 + (n % attackPorts).toInt()))
        }
        if (victimEvery > 0 && n % victimEvery < 64) {
            val id = (victims++ and 0x7FFF) + 1
            sentAt.set(id, System.nanoTime())
            h.send(clientPacket(id, if (newZoneVictims) "v$victims.nz$victims.org" else "v${victims % 200}.victim.org", srcPort = 50000))
        }
        maxPending = maxOf(maxPending, h.fw.pendingCount())
    }
    val secs = (System.nanoTime() - t0) / 1e9
    // cevaplar için 3 sn bekle
    val waitEnd = System.currentTimeMillis() + 3000
    while (System.currentTimeMillis() < waitEnd && lat.size < victims) Thread.sleep(20)
    stop.set(true); drain.join(3000)
    val l = synchronized(lat) { lat.sorted() }
    return FloodResult(n, secs, victims, l.size, if (l.isEmpty()) -1 else l[l.size / 2], if (l.isEmpty()) -1 else l[(l.size * 95 / 100).coerceAtMost(l.size - 1)], maxPending, replies.get())
}

fun runFloodTests() {
    udpDnsFloodTests()
    runGatewayFloodTests()
}

private fun udpDnsFloodTests() {
    // (ad, üst sunucu gecikmesi, hız sınırı: 0 = üreticinin yapabildiği en yüksek hız ≈ milyonlarca sorgu/sn, mağdur payı beklenmez)
    // Saldırı türleri: dağıtık (5000 ayrı rastgele alan) ve aynı alan (mağdurun kendi alanında rastgele alt alan = "water torture")
    val distributed: (Long) -> String = { "u$it.d${it % 5000}.net" }
    val sameZone: (Long) -> String = { "u$it.victim.org" }
    class Sc(val label: String, val delay: Long, val cap: Long, val names: (Long) -> String)
    for (sc in listOf(
        Sc("hızlı üst sunucu, dağıtık alanlar, 100 bin sorgu/sn", 0L, 100_000L, distributed),
        Sc("60 ms gecikmeli üst sunucu, dağıtık alanlar, 100 bin sorgu/sn", 60L, 100_000L, distributed),
        Sc("60 ms gecikmeli üst sunucu, mağdurun kendi alanında rastgele alt alan, 100 bin sorgu/sn", 60L, 100_000L, sameZone),
        Sc("60 ms gecikmeli üst sunucu, dağıtık alanlar, sınırsız hız", 60L, 0L, distributed),
    )) {
        val label = sc.label; val delay = sc.delay; val cap = sc.cap
        T.group("Sızma 16 / UDP DNS seli ($label): tek üretici en yüksek hızda benzersiz ad + araya mağdur sorgular")
        val up = FloodUp(delay)
        val h = Harness(listOf(up.addr), retryAfterMs = 400, giveUpAfterMs = 1500, sweepMs = 50)
        try {
            for (blk in 0 until 5) { for (w in blk * 40 until blk * 40 + 40) h.send(clientPacket(65000 - w, "v$w.victim.org", srcPort = 50000)); Thread.sleep(150) }
            Thread.sleep(300); h.tunWrites.clear()
            val heap0 = usedHeapMb(); val th0 = liveThreads(); val fd0 = fdCount()
            val r = dnsFlood(h, 6000, victimEvery = 500, attackPorts = 40, zones = 5000, qpsCap = cap, nameOf = sc.names)
            val qps = (r.sent / r.seconds).toLong()
            println("    ($label: ${r.sent} sorgu ${"%.1f".format(r.seconds)} sn = $qps sorgu/sn; cevap ${r.replies}; üst sunucuya ${up.received.get()}; bekleyen tepe ${r.maxPending}; düşen ${h.fw.stats().dropped}; mağdur ${r.victimOk}/${r.victims} p50=${r.p50} p95=${r.p95} ms)")
            // Ön koşul (ürünün değil test üreticisinin hızı): tüm testler aynı anda koşarken üretici yük altında 90 binin biraz altına inebiliyor.
            T.check("saldırı uygulandı (≥ 80 bin sorgu/sn ≈ normalin 4000 katı; ölçülen $qps)", qps >= 80_000, "$qps")
            T.check("bekleyen tablo sınırı aşılmadı (≤ ${DnsForwarder.MAX_PENDING + 64}, en çok ${r.maxPending})", r.maxPending <= DnsForwarder.MAX_PENDING + 64, "${r.maxPending}")
            T.check("iç hata yok", h.fw.internalErrors() == 0L, h.fw.lastInternalError())
            T.check("sel bitince bekleyen tablo ve alan sayaçları boşalır", waitUntil(8000) { h.fw.pendingCount() == 0 && h.fw.zonePendingCount() == 0 }, "bekleyen=${h.fw.pendingCount()} alan=${h.fw.zonePendingCount()}")
            val vOk = (0 until 30).count { i -> h.send(clientPacket(40000 + i, "after$i.victim.org", srcPort = 50001)); true }
            val got = HashSet<Int>(); val t0 = System.currentTimeMillis()
            while (got.size < 30 && System.currentTimeMillis() - t0 < 3000) { val rr = h.reply(100) ?: continue; if (Packets.u16(rr, 22) == 50001) got.add(Packets.u16(rr, 28)) }
            T.check("sel sonrası 30 yeni sorgunun hepsi cevaplanır ($vOk gönderildi, ${got.size} cevap)", got.size == 30, "${got.size}")
            val heap1 = usedHeapMb(); val th1 = liveThreads()
            T.check("yığın şişmez: ${heap0} → ${heap1} MB (en çok +60)", heap1 - heap0 <= 60, "$heap0 → $heap1")
            T.check("iş parçacığı sızmaz: $th0 → $th1 (en çok +12)", th1 - th0 <= 12, "$th0 → $th1")
            T.check("dosya tanıtıcısı sızmaz: $fd0 → ${fdCount()} (en çok +10)", fdSettles(fd0 + 10, 5000), "${fdCount()}")
            // Eşik %2'den %0,5'e, p95 1 sn'den 400 ms'ye sıkılaştırıldı (üst sunucu soketlerinin alım arabelleği büyütüldü: sel anında cevaplar
            // çekirdekte düşmüyor; ölçülen kayıp %0, p95 hızlı sunucuda ~10–30 ms).
            if (cap > 0) T.check("mağdur sorgular selde: kayıp ≤ %0,5 (cevap ${r.victimOk}/${r.victims}, p95 ${r.p95} ms)", r.victims > 0 && r.victimOk * 1000 >= r.victims * 995 && r.p95 <= 400, "${r.victimOk}/${r.victims} p95=${r.p95}")
            else println("    (sınırsız hızda mağdur payı beklenmez: tünel aygıtı bu hızı zaten üretemez; ölçülen ${r.victimOk}/${r.victims})")
        } finally { h.close(); up.close() }
    }
}

// ---------------------------------------------------------------- Ağ geçidi: SYN / UDP seli

/**
 * Dürüst istemci: veriyi yazar, cevap gelmezse AYNI segmenti yeniden gönderir (gerçek bir TCP yığını gibi). Geçit, gelen kutusu
 * dolunca paketleri kasıtlı atar (istemci yeniden iletir); test istemcisinin yeniden iletmemesi bunu bir hataya çevirirdi.
 */
internal fun echoWithRetx(c: GCli, msg: ByteArray, ms: Long): ByteArray {
    val seq0 = c.seq
    c.write(msg)
    val got = java.io.ByteArrayOutputStream()
    val end = System.currentTimeMillis() + ms
    while (got.size() < msg.size && System.currentTimeMillis() < end) {
        val part = c.read(msg.size - got.size(), 1000)
        got.write(part)
        if (got.size() < msg.size) c.send(F_ACK or F_PSH, msg, seqNo = seq0)
    }
    return got.toByteArray()
}

/** Yankı sunucusu: gelen her baytı aynen geri yollar (dürüst akışın bütünlüğünü sınamak için). */
private fun gwEcho() = Srv { s ->
    val i = s.getInputStream(); val o = s.getOutputStream(); val b = ByteArray(4096)
    while (true) { val n = try { i.read(b) } catch (_: Exception) { -1 }; if (n < 0) break; o.write(b, 0, n); o.flush() }
}

/**
 * Yarım bağlantıları kabul eden ama OKUMAYAN yığın sunucusu: tek bir kabul-et iş parçacığı vardır, kabul ettiği her soketi
 * (okumadan) saklar. Gerçek bir sel hedefinin davranışını taklit eder; bağlantı başına okuyucu iş parçacığı AÇMAZ (böylece
 * iş parçacığı sayımı gerçek geçidin kendi davranışını ölçer, test yardımcısının değil).
 */
private class SinkServer : AutoCloseable {
    val ss = java.net.ServerSocket(0, 2048, java.net.InetAddress.getByAddress(LO4))
    val port get() = ss.localPort
    val accepted = AtomicInteger()
    private val held = java.util.Collections.synchronizedList(ArrayList<java.net.Socket>())
    init {
        Thread({
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (_: Exception) { break }
                accepted.incrementAndGet()
                held.add(s)
                if (held.size > 5000) try { held.removeAt(0).close() } catch (_: Exception) {}
            }
        }, "sink-accept").also { it.isDaemon = true }.start()
    }
    override fun close() { ss.close(); synchronized(held) { held.forEach { try { it.close() } catch (_: Exception) {} } } }
}

/** [n] adet tek paketlik SYN gönderir (ACK beklemeden): her biri ayrı kaynak port, gerçek bir el sıkışma tamamlamaz. */
private fun synFlood(r: GRig, n: Int, dport: Int, v6: Boolean = false): Int {
    var sent = 0
    for (i in 0 until n) { GCli(r, dport, v6).send(F_SYN, mss = 1460); sent++ }
    return sent
}

/** [n] adet tek paketlik UDP gönderir: her biri ayrı kaynak port + hedef, gerçek bir akışa dönüşür (UDP durumsuz kabul eder). */
private fun udpFlood(r: GRig, n: Int, dport: Int): Int {
    var sent = 0
    for (i in 0 until n) {
        val c = GCli(r, dport)
        val buf = ByteArray(64); java.util.Arrays.fill(buf, 7)
        val pkLen = app.dnshizli.core.Gw.udp(ByteArray(2048), false, c.src, c.dst, c.sport, dport, buf, 0, buf.size)
        // GCli yalnızca TCP kuruyor; burada doğrudan Gw.udp çerçevesini basıyoruz.
        val out = ByteArray(2048)
        val m = app.dnshizli.core.Gw.udp(out, false, c.src, c.dst, c.sport, dport, buf, 0, buf.size)
        r.gw.onPacket(out, m)
        sent++
    }
    return sent
}

fun runGatewayFloodTests() {
    T.group("Sızma 16 / Ağ geçidi: tamamlanmayan yüz binlerce SYN (el sıkışma bitmez) — tablo sınırında kalır, dürüst akış hayatta")
    run {
        val r = GRig()
        val srv = gwEcho()
        val sink = SinkServer()
        try {
            val honest = GCli(r, srv.port)
            val sa0 = honest.connect()
            T.check("dürüst akış saldırıdan önce kuruldu", sa0 != null && sa0.flags == (F_SYN or F_ACK))
            val th0 = liveThreads(); val fd0 = fdCount(); val heap0 = usedHeapMb()
            val t0 = System.nanoTime()
            val sent = synFlood(r, Integer.parseInt(System.getenv("NSYN") ?: "60000"), sink.port)
            val secs = (System.nanoTime() - t0) / 1e9
            val st = r.gw.stats()
            println("    (${sent} SYN ${"%.1f".format(secs)} sn'de (${(sent / secs).toLong()}/sn); açık akış=${st.tcpFlows} kabul edilen=${sink.accepted.get()})")
            T.check("akış sayısı tavanı (maxTcp) aşılmadı (≤ ${r.gw.config.maxTcp}, şimdi ${st.tcpFlows})", st.tcpFlows <= r.gw.config.maxTcp, "${st.tcpFlows}")
            val tw0 = System.nanoTime()
            val echoed = echoWithRetx(honest, "saglik".toByteArray(), 15000)
            val tw = (System.nanoTime() - tw0) / 1_000_000
            println("    (dürüst akışın yankısı ${tw} ms'de geldi)")
            T.check("dürüst akış saldırı sırasında/sonrasında yankısını aldı (${tw} ms)", String(echoed) == "saglik", "\"${String(echoed)}\"")
            // Süren bağlantılar SYN kuyruğunun önünde işlenir: sel artığı beklenmez (önce ~400 ms, şimdi ~80 ms).
            T.check("dürüst akış SYN seli artığını beklemez (≤ 300 ms, ölçülen ${tw})", tw <= 300, "$tw")
            T.check("iç hata yok", st.internalErrors == 0L, r.gw.lastInternalError())
            val heap1 = usedHeapMb(); val th1 = liveThreads()
            T.check("yığın şişmez (${heap0} → ${heap1} MB, en çok +80)", heap1 - heap0 <= 80, "$heap0 → $heap1")
            T.check("iş parçacığı sızmaz ($th0 → $th1, en çok +4: test sunucusu bağlantı başına iş parçacığı açmıyor)", th1 - th0 <= 4, "$th0 → $th1")
            // Sink aynı süreçte: her akış iki tanıtıcı tutar (istemci tarafı + kabul edilmiş yukarı soket). Beklenen tavan 2 × akış + pay.
            T.check("dosya tanıtıcısı akış tavanıyla sınırlı ($fd0 → ${fdCount()}, tavan 2 × ${r.gw.config.maxTcp} + 60)", fdCount() <= fd0 + 2 * r.gw.config.maxTcp + 60, "${fdCount()}")
            sink.close()            // kabul edilmiş yukarı soketler de bırakılsın (aynı süreçte kalıp taban değeri ölçmesin)
            r.gw.networkReset()
            T.check("ağ sıfırlama sonrası dosya tanıtıcıları taban değere döner (en çok +20)", fdSettles(fd0 + 20, 8000), "${fdCount()}")
            T.check("ağ sıfırlama sonrası tablo boşalır", waitUntil(8000) { r.gw.stats().tcpFlows == 0 }, "${r.gw.stats().tcpFlows}")
        } finally { srv.close(); sink.close(); r.close() }
    }

    T.group("Sızma 16 / Ağ geçidi: tek kaynaktan onlarca bin UDP 'akış' (her biri ayrı port) — dürüst UDP akışı kaybolmaz")
    run {
        val r = GRig()
        val up = FloodUp(0)
        try {
            val honest = GCli(r, up.socket.localPort)
            val buf = ByteArray(32); java.util.Arrays.fill(buf, 5)
            val out0 = ByteArray(2048)
            val m0 = app.dnshizli.core.Gw.udp(out0, false, honest.src, honest.dst, honest.sport, up.socket.localPort, buf, 0, buf.size)
            r.gw.onPacket(out0, m0)
            Thread.sleep(50)
            val th0 = liveThreads(); val heap0 = usedHeapMb()
            val t0 = System.nanoTime()
            val sent = udpFlood(r, 40_000, up.socket.localPort)
            Thread.sleep(500)       // arka plandaki geçit iş parçacığının kuyruğu boşaltması için (ölçüm ve sıfırlama bu bitince yapılmalı)
            val secs = (System.nanoTime() - t0) / 1e9
            val st = r.gw.stats()
            println("    (${sent} UDP ${"%.1f".format(secs)} sn'de; açık akış=${st.udpFlows})")
            T.check("UDP akış tavanı (maxUdp) aşılmadı (≤ ${r.gw.config.maxUdp}, şimdi ${st.udpFlows})", st.udpFlows <= r.gw.config.maxUdp, "${st.udpFlows}")
            T.check("iç hata yok", st.internalErrors == 0L, r.gw.lastInternalError())
            val heap1 = usedHeapMb(); val th1 = liveThreads()
            T.check("yığın şişmez (${heap0} → ${heap1} MB, en çok +80)", heap1 - heap0 <= 80, "$heap0 → $heap1")
            T.check("iş parçacığı sızmaz ($th0 → $th1, en çok +8)", th1 - th0 <= 8, "$th0 → $th1")
            r.gw.networkReset()
            T.check("ağ sıfırlama sonrası UDP tablosu boşalır", waitUntil(8000) { r.gw.stats().udpFlows == 0 }, "${r.gw.stats().udpFlows}")
        } finally { r.close(); up.close() }
    }
}
