package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.ArrayDeque
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * Sızma 4 — şerit zamanlayıcısı ([ZoneQueue], [ZoneKey]): sahte saatle belirleyici testler, bağımsız modelle rastgele karşılaştırma
 * (diferansiyel) ve çok iş parçacıklı yük altında "her iş tam bir kez" ile canlılık denetimi.
 */

private class FakeClock { @Volatile var t = 10_000L }

private fun newQ(
    c: FakeClock, capacity: Int = 256, perZone: Int = 64, zoneCap: Int = 3, flagMs: Long = 30_000, aging: Long = 1500, maxZones: Int = 1024,
    after: () -> Long = { 200L },
): ZoneQueue<String> = ZoneQueue(capacity, perZone, zoneCap, { c.t }, after, flagMs, aging, maxZones)

/** Sahte saati 1 ms ilerletip teklif eder (her işin varış anı benzersiz olsun). */
private fun ZoneQueue<String>.put(c: FakeClock, zone: String, job: String): Boolean { c.t += 1; return offer(zone, job, c.t) }

private fun ZoneQueue<String>.take(): Ticket<String>? = poll(0)

private fun ZoneQueue<String>.takeStarted(c: FakeClock): Ticket<String>? = poll(0)?.also { started(it) }

fun runSchedulerTests() {
    zoneKeyTests()
    zoneQueueUnitTests()
    zoneQueueModelTests()
    zoneQueueConcurrencyTests()
}

// ====================================================================================================== alan anahtarı

private fun zoneKeyTests() {
    T.group("Sızma 4 / alan anahtarı (ZoneKey): sezgi, PSL, sıkıştırma/taşma/çöp adlar — asla atmaz")
    run {
        val was = PublicSuffix.ready
        val psl = java.io.File("app/src/main/assets/filter/psl.txt")
        fun zk(name: String): String { val q = Dns.buildQuery(1, name); return ZoneKey.of(q, 0, q.size) }
        try {
            PublicSuffix.clear()
            T.check("sezgi: derin alt alan → son iki etiket", zk("a.b.example.com") == "example.com" && zk("x.y.z.flood.test") == "flood.test", zk("a.b.example.com") + " " + zk("x.y.z.flood.test"))
            T.check("sezgi: büyük/küçük harf aynı alan", zk("WWW.Example.COM") == "example.com" && zk("a.EXAMPLE.com") == zk("b.example.COM"))
            T.check("sezgi: co.uk / com.tr / co.jp → son üç etiket", zk("x.bbc.co.uk") == "bbc.co.uk" && zk("shop.site.com.tr") == "site.com.tr" && zk("a.b.y.co.jp") == "y.co.jp")
            T.check("sezgi: tek etiket ve iki etiket kendisi", zk("localhost") == "localhost" && zk("site.com") == "site.com")
            T.check("sezgi: kök ('.') ve boş ad", zk("") == "" )
            T.check("ofName: sondaki nokta ve büyük harf", ZoneKey.ofName("A.B.Example.Org.") == "example.org" && ZoneKey.ofName("") == "")
        } finally {
            PublicSuffix.clear()
        }
        if (psl.exists()) {
            try {
                psl.inputStream().use { PublicSuffix.install(it) }
                T.check("PSL: github.io kullanıcıları ayrı alan", zk("x.a.github.io") == "a.github.io" && zk("b.github.io") == "b.github.io" && zk("x.a.github.io") != zk("y.b.github.io"))
                T.check("PSL: com.tr / co.uk / joker (*.ck)", zk("www.magaza.com.tr") == "magaza.com.tr" && zk("x.y.site.co.uk") == "site.co.uk" && zk("www.a.b.ck") == "a.b.ck")
            } finally {
                PublicSuffix.clear()
            }
        }
        if (was && psl.exists()) psl.inputStream().use { PublicSuffix.install(it) }

        // Bozuk mesajlar
        fun raw(vararg parts: ByteArray): ByteArray { val o = java.io.ByteArrayOutputStream(); for (p in parts) o.write(p); return o.toByteArray() }
        val hdr = ByteArray(12).also { it[5] = 1 }
        val tail = byteArrayOf(0, 0, 1, 0, 1)
        T.check("kısa mesaj → \"\"", ZoneKey.of(ByteArray(5), 0, 5) == "" && ZoneKey.of(ByteArray(0), 0, 0) == "")
        T.check("64 baytlık etiket → \"\"", ZoneKey.of(raw(hdr, byteArrayOf(64), ByteArray(64) { 'a'.code.toByte() }, tail), 0, 12 + 1 + 64 + 5) == "")
        T.check("sıkıştırma işaretçisi (0xC0) soru adında → \"\"", ZoneKey.of(raw(hdr, byteArrayOf(0xC0.toByte(), 12), tail), 0, 12 + 2 + 5) == "")
        val longName = raw(hdr, *(0 until 5).map { raw(byteArrayOf(63), ByteArray(63) { 'b'.code.toByte() }) }.toTypedArray(), tail)
        T.check("255 baytı aşan ad → \"\"", ZoneKey.of(longName, 0, longName.size) == "")
        T.check("etiket mesajın dışına taşıyor → \"\"", ZoneKey.of(raw(hdr, byteArrayOf(30), ByteArray(5) { 'c'.code.toByte() }), 0, 12 + 1 + 5) == "")
        val q = Dns.buildQuery(7, "a.b.example.com")
        val shifted = ByteArray(20 + q.size).also { System.arraycopy(q, 0, it, 20, q.size) }
        T.check("ofset (base) ile okuma", ZoneKey.of(shifted, 20, q.size) == "example.com")
        T.check("geçersiz base/uzunluk → \"\"", ZoneKey.of(q, -1, q.size) == "" && ZoneKey.of(q, 0, q.size + 10) == "")
        val rnd = Random(99)
        var thrown = 0
        repeat(6000) {
            val n = rnd.nextInt(80)
            val b = ByteArray(n).also { rnd.nextBytes(it) }
            if (n >= 12 && rnd.nextBoolean()) b[4] = 0
            try { ZoneKey.of(b, 0, n) } catch (_: Throwable) { thrown++ }
        }
        T.check("6000 rastgele bayt dizisi: istisna yok", thrown == 0, "atılan=$thrown")
    }
}

// ====================================================================================================== belirleyici birim testleri

private fun zoneQueueUnitTests() {
    T.group("Sızma 4 / ZoneQueue: şüphe yokken sıra birebir FIFO (alanlar arası), alan başına sınır yok")
    run {
        val c = FakeClock()
        val q = newQ(c, after = { Long.MAX_VALUE })
        q.put(c, "a.test", "A1"); q.put(c, "b.test", "B1"); q.put(c, "a.test", "A2"); q.put(c, "c.test", "C1"); q.put(c, "b.test", "B2")
        val got = ArrayList<String>()
        repeat(5) { val t = q.takeStarted(c); if (t != null) got.add(t.job); c.t += 5000 }      // kanıt kapalı: ne kadar uzun çalışırsa çalışsın şüphe yok
        T.check("kanıt kapalıyken sıra varış sırası", got == listOf("A1", "B1", "A2", "C1", "B2"), got.toString())
        T.check("kanıt kapalıyken aynı alandan sınırsız eşzamanlı iş (6 çalışan)", run {
            val q2 = newQ(c, after = { Long.MAX_VALUE })
            for (i in 1..6) q2.put(c, "h.test", "H$i")
            val ts = (1..6).map { q2.takeStarted(c) }
            c.t += 10_000
            ts.all { it != null } && q2.runningOf("h.test") == 6 && !q2.isSuspect("h.test")
        })
        T.check("hepsi alındı: kuyruk boş", q.isEmpty() && q.size() == 0)
    }

    T.group("Sızma 4 / ZoneQueue: şüphe KANITA bağlı (çalışan iş yaşı ≥ eşik; bağlantı kurulumu ve kanıtsız durum sayılmaz)")
    run {
        fun scenario(ageMs: Long, startIt: Boolean, evidence: Long): String {
            val c = FakeClock()
            val q = newQ(c, after = { evidence })
            q.put(c, "h.test", "H1"); q.put(c, "h.test", "H2")
            val t1 = q.take()!!
            if (startIt) q.started(t1)
            c.t += ageMs - 1                                            // put() saati 1 ms ilerletir: poll anında yaş tam ageMs
            q.put(c, "g.test", "G1")                                    // H2'den YENİ
            return q.take()!!.job
        }
        T.check("yaş 150 < 200: şüphe yok → eski iş (H2) önce", scenario(150, true, 200) == "H2")
        T.check("yaş 199: hâlâ şüphe yok", scenario(199, true, 200) == "H2")
        T.check("yaş 200 (eşikte): şüpheli → başka alanın işi (G1) önce", scenario(200, true, 200) == "G1")
        T.check("yaş 5000 ama soru-cevap başlamadı (bağlantı kuruluyor): şüphe yok", scenario(5000, false, 200) == "H2")
        T.check("yaş 5000 ama kanıt yok (sunucu cevap vermiyor/hat yavaş): şüphe yok", scenario(5000, true, Long.MAX_VALUE) == "H2")
        T.check("started ikinci kez çağrılsa ilk an geçerli", run {
            val c = FakeClock(); val q = newQ(c)
            q.put(c, "h.test", "H1"); q.put(c, "h.test", "H2")
            val t = q.take()!!; q.started(t); c.t += 150; q.started(t); c.t += 60            // ilk andan 210 ms
            q.put(c, "g.test", "G1")
            q.take()!!.job == "G1"
        })
    }

    T.group("Sızma 4 / ZoneQueue: şüpheli alanın eşzamanlı işi sınırlı (zoneCap), fazlası verilmez, ek şerit açtırmaz")
    run {
        val c = FakeClock()
        val q = newQ(c)
        for (i in 1..6) q.put(c, "h.test", "H$i")
        val run3 = (1..3).map { q.takeStarted(c)!! }
        c.t += 250                                                      // üçü de ≥ 200 ms: alan şüpheli
        T.check("3 çalışan + yaş ≥ 200 → şüpheli", q.isSuspect("h.test") && q.runningOf("h.test") == 3)
        T.check("sınırdaki şüpheli alanın bekleyenleri verilmez (poll null)", q.take() == null && q.size() == 3)
        T.check("verilebilir iş sayısı 0 (şerit açtırmaz)", q.ready() == 0)
        c.t += 20_000
        T.check("ne kadar beklese de ek şerit gerekmez (sınırdaki alan sayılmaz)", !q.burstDue(300, 100))
        q.put(c, "g.test", "G1")
        T.check("başka alanın işi hemen verilebilir (ready=1) ve alınır", q.ready() == 1 && q.take()!!.job == "G1")
        q.finish(run3[0], false)
        T.check("bir çalışan bitince alanın payı boşalır → ready=1", q.ready() == 1 && q.runningOf("h.test") == 2)
        T.check("ve sıradaki iş (H4) verilir", q.take()!!.job == "H4")
        T.check("yeniden sınırda: bir sonraki yok", q.take() == null)
    }

    T.group("Sızma 4 / ZoneQueue: zaman aşımı bayrağı (slow) 30 sn şüphe doğurur ve söner; bayraklı alan aç kalmaz (yaşlanma)")
    run {
        val c = FakeClock()
        var ev = Long.MAX_VALUE
        val q = newQ(c, after = { ev }, aging = 1500)
        q.put(c, "h.test", "H0")
        val t0 = q.takeStarted(c)!!
        q.finish(t0, true)
        T.check("slow bitiş → alan şüpheli (kanıt kapalıyken de)", q.isSuspect("h.test") && q.trackedZones0() == 1)
        c.t += 29_000
        T.check("29 sn sonra hâlâ şüpheli", q.isSuspect("h.test"))
        c.t += 1_001
        T.check("30 sn sonra söner", !q.isSuspect("h.test"))

        // bayraklı alan, başka alanın YENİ işinden sonra gelir
        val q2 = newQ(c, after = { ev }, aging = 1500)
        q2.put(c, "h.test", "H0"); q2.finish(q2.take()!!, true)
        q2.put(c, "h.test", "H1")
        c.t += 1000
        q2.put(c, "g.test", "G1")
        c.t += 400                                                       // H1 1400 ms bekledi (< 1500)
        T.check("bayraklı alanın işi (1400 ms bekledi) başkasının yeni işinden sonra", q2.take()!!.job == "G1")
        T.check("sonra H1 verilir (sınırda değil)", q2.take()!!.job == "H1")
        // yaşlanma: 1500 ms bekleyen bayraklı iş normal sayılır → en eski olduğu için önce
        val q3 = newQ(c, after = { ev }, aging = 1500)
        q3.put(c, "h.test", "H0"); q3.finish(q3.take()!!, true)
        q3.put(c, "h.test", "H1")
        c.t += 1000
        q3.put(c, "g.test", "G1")
        c.t += 500                                                       // H1 1500 ms bekledi
        T.check("1500 ms bekleyen bayraklı iş normal sayılır (aç kalmaz): en eskisi önce", q3.take()!!.job == "H1")
        // bayraklı alan sınırı: çalışan sayısı sınırdaysa (3) yaşlanma da aşamaz
        val q4 = newQ(c, after = { ev }, aging = 1500)
        q4.put(c, "h.test", "H0"); q4.finish(q4.take()!!, true)
        for (i in 1..5) q4.put(c, "h.test", "H$i")
        val three = (1..3).map { q4.take()!! }
        c.t += 5000
        T.check("bayraklı alan sınırında: yaşlanma sınırı aşmaz", q4.take() == null && q4.runningOf("h.test") == 3)
        three.forEach { q4.finish(it, false) }
        ev = Long.MAX_VALUE
    }

    T.group("Sızma 4 / ZoneQueue: bellek sınırları (toplam, alan başına, izlenen alan sayısı) ve temizlik")
    run {
        val c = FakeClock()
        val q = newQ(c, capacity = 5, perZone = 3)
        val r = (1..4).map { q.put(c, "a.test", "A$it") }
        T.check("alan başına 3: dördüncü teklif reddedilir, başka alan etkilenmez", r == listOf(true, true, true, false) && q.put(c, "b.test", "B1"))
        T.check("toplam 5: altıncı teklif reddedilir", q.put(c, "c.test", "C1") && !q.put(c, "d.test", "D1") && q.size() == 5)
        // sel kuyruğu dolduramaz: tek alan en çok perZone tutar, başkasına yer kalır
        val q2 = newQ(c, capacity = 256, perZone = 64)
        var acc = 0
        for (i in 1..1000) if (q2.put(c, "flood.test", "F$i")) acc++
        T.check("tek alan 1000 teklifte en çok 64 tutar", acc == 64 && q2.size() == 64, "kabul=$acc")
        T.check("selden sonra başka alanın işi hâlâ kabul edilir", q2.put(c, "victim.test", "V1"))
        // alan kayıtları temizlenir
        val q3 = newQ(c)
        for (i in 1..50) q3.put(c, "z$i.test", "J$i")
        T.check("50 alan izleniyor", q3.trackedZones0() == 50)
        val ts = ArrayList<Ticket<String>>()
        while (true) { val t = q3.take() ?: break; ts.add(t) }
        T.check("hepsi çalışıyor: kayıtlar duruyor", q3.trackedZones0() == 50 && ts.size == 50)
        ts.forEach { q3.finish(it, false) }
        T.check("bitince alan kayıtları silinir (bellek sızmaz)", q3.trackedZones0() == 0 && q3.size() == 0)
        // izlenen alan sınırı: bayraklı-boş kayıtlar yer açmak için atılır, dolu kayıtlar atılmaz
        val q4 = newQ(c, maxZones = 3)
        for (i in 1..3) { q4.put(c, "f$i.test", "J$i"); q4.finish(q4.take()!!, true) }          // üç bayraklı ama boş kayıt
        T.check("üç bayraklı boş kayıt tutuluyor", q4.trackedZones0() == 3)
        T.check("dördüncü alan: eski bayrak kayıtları atılıp kabul edilir", q4.put(c, "new.test", "N1") && q4.trackedZones0() <= 3)
        val q5 = newQ(c, maxZones = 2)
        T.check("iki dolu alan + üçüncü alan: reddedilir (dolu kayıt atılamaz)", q5.put(c, "a.test", "A") && q5.put(c, "b.test", "B") && !q5.put(c, "c.test", "C"))
        T.check("var olan alana eklemek yine mümkün", q5.put(c, "a.test", "A2"))
    }

    T.group("Sızma 4 / ZoneQueue: ek şerit kuralları (burstDue)")
    run {
        val c = FakeClock()
        val q = newQ(c)
        T.check("boş kuyruk: ek şerit yok", !q.burstDue(300, 100))
        q.put(c, "a.test", "A1")
        c.t += 299
        T.check("299 ms bekledi: yok", !q.burstDue(300, 100))
        c.t += 1
        T.check("300 ms bekledi: var", q.burstDue(300, 100))
        // erken kural: yalnızca şüpheli bir alan şerit TUTARKEN ve şüpheli olmayan alanın işi için
        val q2 = newQ(c)
        q2.put(c, "h.test", "H1")
        q2.takeStarted(c)
        c.t += 250                                                      // H1 şüpheli (çalışıyor, ≥ 200); bekleyen yalnızca G1 olacak
        q2.put(c, "g.test", "G1")
        c.t += 99
        T.check("şüpheli alan şerit tutuyor, G1 99 ms bekledi: henüz yok", !q2.burstDue(300, 100))
        c.t += 1
        T.check("G1 100 ms bekledi: erken kuralla var (300 ms beklemeden)", q2.burstDue(300, 100))
        // erken kural şüpheli çalışan yokken işlemez
        val q3 = newQ(c, after = { Long.MAX_VALUE })
        q3.put(c, "h.test", "H1"); q3.takeStarted(c); c.t += 5000
        q3.put(c, "g.test", "G1"); c.t += 150
        T.check("kanıt yokken erken kural işlemez", !q3.burstDue(300, 100))
        c.t += 200
        T.check("ama 300 ms kuralı hâlâ işler", q3.burstDue(300, 100))
        // şüpheli alanın sınırda olmayan kendi bekleyeni 300 ms'den sonra ek şerit açtırır; sınırdaysa açtırmaz
        val q4 = newQ(c)
        for (i in 1..4) q4.put(c, "h.test", "H$i")
        q4.takeStarted(c); c.t += 250
        c.t += 400
        T.check("şüpheli ama sınırda olmayan alanın bekleyeni (400 ms) ek şerit açtırır", q4.burstDue(300, 100))
        q4.takeStarted(c); q4.takeStarted(c)
        c.t += 5000
        T.check("sınıra ulaşınca (3 çalışan) açtırmaz", !q4.burstDue(300, 100))
    }

    T.group("Sızma 4 / ZoneQueue: ready() hesabı, bilet bırakma idempotent, clear() sonrası bırakma zararsız")
    run {
        val c = FakeClock()
        val q = newQ(c)
        for (i in 1..5) q.put(c, "h.test", "H$i")
        val two = (1..2).map { q.takeStarted(c)!! }
        c.t += 250
        q.put(c, "g.test", "G1"); q.put(c, "g.test", "G2")
        // H şüpheli, 2 çalışıyor, 3 bekliyor, sınır 3 → 1 verilebilir; G: 2 → toplam 3
        T.check("ready = şüpheli alandan (3-2)=1 + normal alandan 2", q.ready() == 3, "ready=${q.ready()}")
        q.finish(two[0], false); q.finish(two[0], false); q.finish(two[0], true)
        T.check("aynı bileti üç kez bırakmak tek kez sayılır (çalışan 2→1)", q.runningOf("h.test") == 1)
        q.finish(two[1], false)
        T.check("ikinci (slow=true) bırakma bayrak koymadı: alan şüpheli değil", q.runningOf("h.test") == 0 && !q.isSuspect("h.test"))
        val live = q.take()!!
        q.clear()
        T.check("clear: kuyruk boş", q.size() == 0 && q.trackedZones0() == 0)
        q.finish(live, false)
        T.check("clear sonrası bırakma zararsız (kayıt yeniden oluşmaz)", q.trackedZones0() == 0)
        T.check("clear sonrası kuyruk yine çalışır", q.put(c, "z.test", "Z1") && q.take()!!.job == "Z1")
    }

    T.group("Sızma 4 / ZoneQueue: poll bekleme semantiği (gerçek saat): zaman aşımı, uyandırma, kesinti")
    run {
        val q = ZoneQueue<String>(16, 8, 3, { System.nanoTime() / 1_000_000 }, { Long.MAX_VALUE })
        val t0 = System.nanoTime()
        val r = q.poll(120)
        val ms = (System.nanoTime() - t0) / 1_000_000
        T.check("boş kuyrukta poll(120) ≈120 ms sonra null ($ms ms)", r == null && ms in 100..600)
        val got = AtomicReference<String?>(null)
        val woke = AtomicInteger(-1)
        val waiter = Thread {
            val s = System.nanoTime()
            val t = q.poll(5000)
            woke.set(((System.nanoTime() - s) / 1_000_000).toInt())
            got.set(t?.job)
        }.also { it.isDaemon = true; it.start() }
        Thread.sleep(150)
        q.offer("a.test", "WAKE", System.nanoTime() / 1_000_000)
        waiter.join(3000)
        T.check("bekleyen şerit teklifle hemen uyanır (${woke.get()} ms)", got.get() == "WAKE" && woke.get() in 100..1500)
        val intr = AtomicBoolean(false)
        val w2 = Thread { try { q.poll(10_000) } catch (_: InterruptedException) { intr.set(true) } }.also { it.isDaemon = true; it.start() }
        Thread.sleep(100); w2.interrupt(); w2.join(3000)
        T.check("bekleyen şerit kesilince InterruptedException (kapanış yolu)", intr.get())
    }
}

// ====================================================================================================== bağımsız modelle karşılaştırma

/** [ZoneQueue]'nun belirtimi, uygulamadan bağımsız ve olabildiğince saf biçimde yeniden yazılmış hâli. */
private class ModelQ(val capacity: Int, val perZone: Int, val cap: Int, val flagMs: Long, val aging: Long) {
    class Job(val id: String, val at: Long)
    class Run(val job: Job, val zone: String) { var started = Long.MAX_VALUE }
    val queues = HashMap<String, ArrayDeque<Job>>()
    val running = HashMap<String, ArrayList<Run>>()
    val flagged = HashMap<String, Long>()
    var total = 0

    fun runOf(z: String) = running.getOrPut(z) { ArrayList() }

    fun offer(z: String, id: String, at: Long): Boolean {
        if (total >= capacity) return false
        val q = queues.getOrPut(z) { ArrayDeque() }
        if (q.size >= perZone) return false
        q.addLast(Job(id, at)); total++
        return true
    }

    fun suspect(z: String, now: Long, after: Long): Boolean {
        if ((flagged[z] ?: Long.MIN_VALUE) > now) return true
        if (after == Long.MAX_VALUE) return false
        return runOf(z).any { it.started != Long.MAX_VALUE && now - it.started >= after }
    }

    /** Beklenen bir sonraki iş (alan, iş); yoksa null. */
    fun expected(now: Long, after: Long): Pair<String, Job>? {
        var best: String? = null; var bestLow = false; var bestAt = 0L
        for ((z, q) in queues) {
            val head = q.peekFirst() ?: continue
            val sus = suspect(z, now, after)
            if (sus && runOf(z).size >= cap) continue
            val low = sus && now - head.at < aging
            if (best == null || (bestLow && !low) || (low == bestLow && head.at < bestAt)) { best = z; bestLow = low; bestAt = head.at }
        }
        return if (best == null) null else best to queues[best]!!.peekFirst()
    }

    fun take(z: String): Run { val j = queues[z]!!.pollFirst(); total--; return Run(j, z).also { runOf(z).add(it) } }

    fun ready(now: Long, after: Long): Int {
        var n = 0
        for ((z, q) in queues) { if (q.isEmpty()) continue; n += if (suspect(z, now, after)) maxOf(0, minOf(q.size, cap - runOf(z).size)) else q.size }
        return n
    }

    fun burstDue(now: Long, after: Long, afterMs: Long, earlyMs: Long): Boolean {
        if (total == 0) return false
        val susRun = running.keys.any { runOf(it).isNotEmpty() && suspect(it, now, after) }
        for ((z, q) in queues) {
            val head = q.peekFirst() ?: continue
            val sus = suspect(z, now, after)
            if (sus && runOf(z).size >= cap) continue
            val w = now - head.at
            if (w >= afterMs) return true
            if (susRun && !sus && w >= earlyMs) return true
        }
        return false
    }
}

private fun zoneQueueModelTests() {
    T.group("Sızma 4 / ZoneQueue: bağımsız modelle rastgele karşılaştırma (300 tohum × 600 işlem: sıra, sınır, sayım, ek şerit, bayrak)")
    run {
        var firstFail: String? = null
        var totalOps = 0
        var picks = 0
        var suspectPicks = 0
        val zonesN = 6
        for (seed in 1..300) {
            val rnd = Random(seed * 7919L)
            val c = FakeClock()
            var ev = 200L
            val capacity = 12 + rnd.nextInt(40); val perZone = 3 + rnd.nextInt(8); val cap = 1 + rnd.nextInt(4)
            val flagMs = 2000L + rnd.nextInt(6000); val aging = 500L + rnd.nextInt(2500)
            val q = newQ(c, capacity, perZone, cap, flagMs, aging, after = { ev })
            val m = ModelQ(capacity, perZone, cap, flagMs, aging)
            val tickets = ArrayList<Pair<Ticket<String>, ModelQ.Run>>()
            var id = 0
            val seen = HashSet<String>()
            val acc = HashSet<String>()
            fun fail(step: Int, what: String) { if (firstFail == null) firstFail = "tohum=$seed adım=$step: $what" }
            for (step in 0 until 600) {
                if (firstFail != null) break
                totalOps++
                val op = rnd.nextInt(100)
                when {
                    op < 36 -> {
                        val z = "z${rnd.nextInt(zonesN)}.test"
                        c.t += 1 + rnd.nextInt(3)
                        val job = "j${id++}"
                        val ok = q.offer(z, job, c.t)
                        val mok = m.offer(z, job, c.t)
                        if (ok != mok) fail(step, "offer($z) gerçek=$ok model=$mok")
                        if (ok) acc.add(job)
                    }
                    op < 66 -> {
                        val exp = m.expected(c.t, ev)
                        val t = q.poll(0)
                        if (exp == null) { if (t != null) fail(step, "poll: model boş, gerçek ${t.job} verdi") }
                        else if (t == null) fail(step, "poll: model ${exp.second.id} bekliyor, gerçek null")
                        else if (t.job != exp.second.id) fail(step, "poll: gerçek ${t.job} model ${exp.second.id}")
                        else {
                            picks++
                            if (m.suspect(exp.first, c.t, ev)) suspectPicks++
                            tickets.add(t to m.take(exp.first))
                            if (!seen.add(t.job)) fail(step, "aynı iş iki kez verildi: ${t.job}")
                        }
                    }
                    op < 80 -> if (tickets.isNotEmpty()) {
                        val (t, r) = tickets[rnd.nextInt(tickets.size)]
                        q.started(t)
                        if (r.started == Long.MAX_VALUE) r.started = c.t
                    }
                    op < 93 -> if (tickets.isNotEmpty()) {
                        val i = rnd.nextInt(tickets.size)
                        val (t, r) = tickets.removeAt(i)
                        val slow = rnd.nextInt(5) == 0
                        q.finish(t, slow)
                        if (rnd.nextInt(6) == 0) q.finish(t, rnd.nextBoolean())          // ikinci bırakma etkisiz olmalı
                        m.runOf(r.zone).remove(r)
                        if (slow) m.flagged[r.zone] = c.t + flagMs
                    }
                    else -> c.t += rnd.nextInt(700)
                }
                if (rnd.nextInt(25) == 0) ev = if (rnd.nextInt(3) == 0) Long.MAX_VALUE else 100L + rnd.nextInt(300)
                // her adımda değişmezler
                if (q.size() != m.total) fail(step, "size gerçek=${q.size()} model=${m.total}")
                if (q.ready() != m.ready(c.t, ev)) fail(step, "ready gerçek=${q.ready()} model=${m.ready(c.t, ev)}")
                if (q.burstDue(300, 100) != m.burstDue(c.t, ev, 300, 100)) fail(step, "burstDue gerçek=${q.burstDue(300, 100)} model=${m.burstDue(c.t, ev, 300, 100)}")
                for (zi in 0 until zonesN) {
                    val z = "z$zi.test"
                    if (q.runningOf(z) != m.runOf(z).size) fail(step, "running($z) gerçek=${q.runningOf(z)} model=${m.runOf(z).size}")
                    if (q.isSuspect(z) != m.suspect(z, c.t, ev)) fail(step, "isSuspect($z) gerçek=${q.isSuspect(z)} model=${m.suspect(z, c.t, ev)}")
                }
            }
            if (firstFail != null) break
            // boşaltma: her kabul edilen iş tam bir kez verilir
            for ((t, r) in tickets) { q.finish(t, false); m.runOf(r.zone).remove(r) }
            tickets.clear()
            c.t += 100_000
            ev = Long.MAX_VALUE
            var guard = 0
            while (guard++ < 5000) { val t = q.poll(0) ?: break; if (!seen.add(t.job)) { fail(-1, "boşaltmada tekrar: ${t.job}"); break }; q.finish(t, false) }
            if (q.size() != 0) fail(-1, "boşaltma sonrası size=${q.size()}")
            if (firstFail == null && q.trackedZones0() > zonesN) fail(-1, "alan kaydı sızıntısı: ${q.trackedZones0()}")
            if (firstFail == null && seen != acc) fail(-1, "kabul edilen ${acc.size} işten ${seen.size}'i verildi (eksik=${(acc - seen).take(3)} fazla=${(seen - acc).take(3)})")
        }
        T.check("300 tohum: model ile gerçek uygulama bütün adımlarda aynı ($totalOps işlem, $picks seçim, bunun $suspectPicks şüpheli alandan)", firstFail == null, firstFail ?: "")
        T.check("rastgele akış şüpheli alan seçimlerini de kapsadı (kapsam)", suspectPicks > 300 && picks > 3000, "seçim=$picks şüpheli=$suspectPicks")
    }
}

// ====================================================================================================== eşzamanlılık

private fun zoneQueueConcurrencyTests() {
    T.group("Sızma 4 / ZoneQueue: 6 üretici × 3000 iş, 5 tüketici, 40 alan, sürekli şüphe/bayrak — her kabul edilen iş tam bir kez, kilitlenme yok")
    run {
        val clock = { System.nanoTime() / 1_000_000 }
        val q = ZoneQueue<Int>(2000, 200, 2, clock, { 2L }, flagMs = 50, agingMs = 30, maxZones = 64)
        val producers = 6; val perProducer = 3000
        val processed = ConcurrentHashMap<Int, AtomicInteger>()
        val accepted = ConcurrentHashMap.newKeySet<Int>()
        val rejected = AtomicInteger()
        val prodDone = AtomicInteger()
        val stop = AtomicBoolean(false)
        val errors = java.util.concurrent.CopyOnWriteArrayList<String>()
        val start = CountDownLatch(1)
        val consumers = (1..5).map { k ->
            Thread {
                val r = Random(k * 31L)
                start.await()
                while (true) {
                    val t = try { q.poll(20) } catch (_: InterruptedException) { break }
                    if (t == null) { if (stop.get() && q.isEmpty()) break else continue }
                    if (processed.computeIfAbsent(t.job) { AtomicInteger() }.incrementAndGet() != 1) errors.add("iş ${t.job} birden çok kez verildi")
                    q.started(t)
                    if (r.nextInt(8) == 0) Thread.sleep(0, 200_000)
                    q.finish(t, r.nextInt(40) == 0)
                }
            }.also { it.isDaemon = true; it.start() }
        }
        val ps = (0 until producers).map { p ->
            Thread {
                val r = Random(p * 17L + 5)
                start.await()
                for (i in 0 until perProducer) {
                    val job = p * 1_000_000 + i
                    val zone = "z${r.nextInt(40)}.test"
                    if (q.offer(zone, job, clock())) accepted.add(job) else rejected.incrementAndGet()
                    if (i % 97 == 0) Thread.yield()
                }
                prodDone.incrementAndGet()
            }.also { it.isDaemon = true; it.start() }
        }
        start.countDown()
        val t0 = System.currentTimeMillis()
        ps.forEach { it.join(30_000) }
        val deadline = System.currentTimeMillis() + 30_000
        while (System.currentTimeMillis() < deadline && !(q.isEmpty() && processed.size >= accepted.size)) Thread.sleep(10)
        stop.set(true)
        consumers.forEach { it.join(5000) }
        val ms = System.currentTimeMillis() - t0
        val missing = accepted.count { !processed.containsKey(it) }
        val extra = processed.keys.count { !accepted.contains(it) }
        T.check("üreticiler bitti, tüketiciler bitti ($ms ms)", prodDone.get() == producers && consumers.none { it.isAlive })
        T.check("kabul edilen ${accepted.size} işin hepsi işlendi (eksik=$missing), kabul edilmeyen işlenmedi (fazla=$extra), tekrar yok", missing == 0 && extra == 0 && errors.isEmpty(), errors.take(3).toString())
        T.check("toplam teklif = kabul + ret (${accepted.size}+${rejected.get()})", accepted.size + rejected.get() == producers * perProducer)
        T.check("sonunda kuyruk boş ve alan kayıtları sınırda (${q.zoneCount()} ≤ 64)", q.size() == 0 && q.zoneCount() <= 64)
    }
}

/** Testlerde izlenen alan sayısı (ZoneQueue.zoneCount). */
private fun ZoneQueue<String>.trackedZones0(): Int = zoneCount()
