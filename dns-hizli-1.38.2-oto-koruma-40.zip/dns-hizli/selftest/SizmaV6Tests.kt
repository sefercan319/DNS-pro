package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.ServerSocket
import java.util.Random
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * Sızma 13 — IPv6 durum makinesi ve v4 ↔ v6 eşlik (diferansiyel) testi.
 *
 * Sandbox'ta gerçek IPv6 yığını yok; ama JDK `::ffff:127.0.0.1` adresini Inet4Address'e çözer. Tünelden giren paketler gerçek IPv6
 * çerçevesiyle (40 bayt başlık, IPv6 sahte başlıklı sağlama, uzantı başlıkları, 1440 MSS, 1452 UDP sınırı, ayrı v6 akış tabloları)
 * ağ geçidine verilir; sunucu tarafı yine loopback'te kalır. Böylece IPv6'ya özgü tüm kod yolları gerçekten çalışır.
 *
 *  1) Bağımsız paket denetçisi ([wireViolations], [V6Wire]): geçidin tünele yazdığı HER paket RFC 791/793/768/8200 kurallarıyla (ayrı
 *     yazılmış, farklı biçimde formüle edilmiş sağlama toplamı dahil) denetlenir; denetçinin kendisi de bozulmuş paketlerle sınanır.
 *  2) Eşlik: aynı senaryo v4 ve v6'da koşar, gözlem imzaları birebir aynı olmalıdır (yaşam döngüsü, UDP, DPI yöntemleri, süzgeç).
 *  3) IPv6'ya özgü saldırılar: uzantı başlığı zincirleri, bozuk uzunluk alanları, UDP sağlaması 0 köşesi, MTU sınırı.
 *  4) Kaos konuşması: rastgele sıra dışı/yinelenen/örtüşen/sıfır pencereli segmentlerle yankı bütünlüğü, her iki ailede aynı tohumlarla.
 */

/** v4'e eşlenmiş IPv6 hedef (::ffff:127.0.0.1). JDK bunu Inet4Address'e çözer: IPv6 yığını olmayan makinede bile gerçek IPv6 çerçeveleme sınanır. */
internal val MAPPED6: ByteArray = ByteArray(16).also { it[10] = 0xFF.toByte(); it[11] = 0xFF.toByte(); it[12] = 127; it[15] = 1 }

private val V6_HELLO_REPLY = byteArrayOf(0x16, 3, 3, 0, 4, 2, 0, 0, 0)

private class V6Fam(val v6: Boolean) {
    val name: String get() = if (v6) "IPv6" else "IPv4"
    val dst: ByteArray get() = if (v6) MAPPED6 else LO4
    val src: ByteArray get() = if (v6) SelfTest.CLIENT6 else CLI4
    val hdr: Int get() = if (v6) 40 else 20
    val mss: Int get() = if (v6) Gw.MSS6 else Gw.MSS4
    val maxUdp: Int get() = Gw.MTU - (if (v6) 48 else 28)
    fun cli(r: GRig, port: Int) = GCli(r, port, v6, dst)
}

private val V6_FAMS = listOf(V6Fam(false), V6Fam(true))

private fun v6Preflight(): Boolean {
    val a = try { InetAddress.getByAddress(MAPPED6) } catch (_: Exception) { null }
    return a is java.net.Inet4Address && a.address.contentEquals(LO4)
}

fun runIpv6StatefulTests() {
    if (!v6Preflight()) {
        T.group("Sızma 13 / IPv6 (v4-eşlemeli hedef)")
        T.check("::ffff:127.0.0.1 bu JDK'da Inet4Address'e çözülmüyor: IPv6 eşlik testleri atlandı", true)
        return
    }
    v6OracleSelfTest()
    v6HandshakeBulk()
    v6LifecycleParity()
    v6UdpParity()
    v6ExtTests()
    v6LengthLies()
    v6DpiParity()
    v6FilterParity()
    v6ChaosTests()
}

// ====================================================================================================== bağımsız denetçi

/** 16 bitlik sözcüklerin ham toplamı (katlama yok): geçerlilik "toplam % 65535 == 0 ve > 0" biçiminde, ayrı formülle denetlenir. */
private fun v6Sum(init: Long, b: ByteArray, off: Int, len: Int): Long {
    var s = init
    var i = off
    val end = off + len
    while (i + 1 < end) { s += (((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)).toLong(); i += 2 }
    if (i < end) s += ((b[i].toInt() and 0xFF) shl 8).toLong()
    return s
}

private fun v6Valid(s: Long): Boolean = s > 0L && s % 65535L == 0L

private fun v6Hex(p: ByteArray, n: Int = 64): String = p.take(n).joinToString("") { "%02x".format(it) }

/** Paketi değiştirdikten sonra sağlamaları (IPv4 başlığı + TCP/UDP) yeniden hesaplar: tek bir kuralı yalıtarak sınamak için. */
private fun v6Refix(p: ByteArray) {
    val v6 = ((p[0].toInt() ushr 4) and 0xF) == 6
    val ip = if (v6) 40 else (p[0].toInt() and 0xF) * 4
    val proto = if (v6) p[6].toInt() and 0xFF else p[9].toInt() and 0xFF
    val l = p.size - ip
    if (proto == 6 || proto == 17) {
        val cs = ip + (if (proto == 6) 16 else 6)
        p[cs] = 0; p[cs + 1] = 0
        val src = if (v6) p.copyOfRange(8, 24) else p.copyOfRange(12, 16)
        val dst = if (v6) p.copyOfRange(24, 40) else p.copyOfRange(16, 20)
        var s = v6Sum(0L, src, 0, src.size)
        s = v6Sum(s, dst, 0, dst.size)
        s += if (v6) (l ushr 16).toLong() + (l and 0xFFFF).toLong() + proto.toLong() else proto.toLong() + l.toLong()
        s = v6Sum(s, p, ip, l)
        val m = (s % 65535L).toInt()
        var c = 0xFFFF - (if (m == 0) 0xFFFF else m)
        if (proto == 17 && c == 0) c = 0xFFFF
        Packets.put16(p, cs, c)
    }
    if (!v6) {
        p[10] = 0; p[11] = 0
        val m = (v6Sum(0L, p, 0, ip) % 65535L).toInt()
        Packets.put16(p, 10, 0xFFFF - (if (m == 0) 0xFFFF else m))
    }
}

/** TCP segmentindeki MSS seçeneği; yoksa -1. */
private fun v6TcpMss(p: ByteArray, ip: Int): Int {
    val doff = (p[ip + 12].toInt() and 0xF0) ushr 2
    var i = ip + 20
    val end = minOf(ip + doff, p.size)
    while (i < end) {
        val k = p[i].toInt() and 0xFF
        if (k == 0) break
        if (k == 1) { i++; continue }
        if (i + 1 >= end) break
        val l = p[i + 1].toInt() and 0xFF
        if (l < 2) break
        if (k == 2 && l == 4 && i + 4 <= end) return Packets.u16(p, i + 2)
        i += l
    }
    return -1
}

/** Geçidin tünele yazdığı tek bir paketin kural ihlalleri (boş liste = kurala uygun). Durumsuz kurallar; durumlu olanlar [V6Wire]'dadır. */
internal fun wireViolations(p: ByteArray): List<String> {
    val out = ArrayList<String>()
    if (p.size < 20) return listOf("paket çok kısa: ${p.size}")
    val ver = (p[0].toInt() ushr 4) and 0xF
    val v6 = ver == 6
    val ip: Int
    val proto: Int
    val src: ByteArray
    val dst: ByteArray
    when (ver) {
        4 -> {
            ip = (p[0].toInt() and 0xF) * 4
            if (ip < 20 || ip > p.size) return listOf("v4 başlık uzunluğu geçersiz: $ip")
            if (Packets.u16(p, 2) != p.size) out.add("v4 toplam uzunluk ${Packets.u16(p, 2)} ≠ ${p.size}")
            if ((Packets.u16(p, 6) and 0xBFFF) != 0) out.add("v4 parça/ayrılmış bit")
            if ((p[8].toInt() and 0xFF) < 2) out.add("v4 TTL çok küçük")
            if (!v6Valid(v6Sum(0L, p, 0, ip))) out.add("v4 başlık sağlaması geçersiz")
            proto = p[9].toInt() and 0xFF
            src = p.copyOfRange(12, 16); dst = p.copyOfRange(16, 20)
        }
        6 -> {
            if (p.size < 40) return listOf("v6 paket çok kısa")
            ip = 40
            if (Packets.u16(p, 4) != p.size - 40) out.add("v6 yük uzunluğu ${Packets.u16(p, 4)} ≠ ${p.size - 40}")
            if ((p[0].toInt() and 0x0F) != 0 || p[1].toInt() != 0 || p[2].toInt() != 0 || p[3].toInt() != 0) out.add("v6 sınıf/akış etiketi sıfır değil")
            if ((p[7].toInt() and 0xFF) < 2) out.add("v6 hop limiti çok küçük")
            proto = p[6].toInt() and 0xFF
            src = p.copyOfRange(8, 24); dst = p.copyOfRange(24, 40)
        }
        else -> return listOf("IP sürümü $ver")
    }
    if (proto != 6 && proto != 17) { out.add("beklenmeyen protokol $proto"); return out }
    val l = p.size - ip
    // sahte başlık: RFC 793/768 (v4: proto + uzunluk), RFC 8200 §8.1 (v6: 32 bit uzunluk + proto)
    var s = v6Sum(0L, src, 0, src.size)
    s = v6Sum(s, dst, 0, dst.size)
    s += if (v6) (l ushr 16).toLong() + (l and 0xFFFF).toLong() + proto.toLong() else proto.toLong() + l.toLong()
    s = v6Sum(s, p, ip, l)
    if (!v6Valid(s)) out.add("sağlama toplamı geçersiz (proto $proto)")
    val maxData = if (v6) Gw.MSS6 else Gw.MSS4
    if (proto == 6) {
        if (l < 20) { out.add("TCP başlığı kısa"); return out }
        val doff = (p[ip + 12].toInt() and 0xF0) ushr 2
        if (doff < 20 || doff > l) { out.add("TCP veri ofseti $doff"); return out }
        if ((p[ip + 12].toInt() and 0x0F) != 0) out.add("TCP ayrılmış bitler set")
        val fl = p[ip + 13].toInt() and 0xFF
        val dl = l - doff
        if (fl and Gw.SYN != 0) {
            if (fl and Gw.ACK == 0) out.add("SYN tek başına (geçit yalnızca SYN+ACK yollar)")
            if (fl and (Gw.FIN or Gw.RST) != 0) out.add("SYN ile FIN/RST birlikte")
            if (dl != 0) out.add("SYN yük taşıyor")
        }
        if (fl and Gw.RST != 0 && dl != 0) out.add("RST yük taşıyor")
        if (fl and 0x20 == 0 && Packets.u16(p, ip + 18) != 0) out.add("acil işaretçi var ama URG yok")
        if (dl > maxData) out.add("segment verisi $dl bayt: MTU'yu aşıyor")
        var i = ip + 20
        val end = ip + doff
        var mss = -1
        var optBad = false
        while (i < end && !optBad) {
            val k = p[i].toInt() and 0xFF
            if (k == 0) { for (j in i until end) if (p[j].toInt() != 0) optBad = true; break }
            if (k == 1) { i++; continue }
            if (i + 1 >= end) { optBad = true; break }
            val ol = p[i + 1].toInt() and 0xFF
            if (ol < 2 || i + ol > end) { optBad = true; break }
            if (k == 2) { if (ol != 4) optBad = true else mss = Packets.u16(p, i + 2) }
            i += ol
        }
        if (optBad) out.add("TCP seçenekleri bozuk")
        if (fl and Gw.SYN != 0) {
            if (mss < 0) { if (!optBad) out.add("SYN+ACK'ta MSS seçeneği yok") }
            else if (mss > maxData || mss < 100) out.add("SYN+ACK MSS=$mss aralık dışı")
        } else if (mss >= 0) out.add("MSS seçeneği SYN dışında")
    } else {
        if (l < 8) { out.add("UDP başlığı kısa"); return out }
        if (Packets.u16(p, ip + 4) != l) out.add("UDP uzunluğu ${Packets.u16(p, ip + 4)} ≠ $l")
        if (Packets.u16(p, ip + 6) == 0) out.add("UDP sağlaması 0")
        if (l - 8 > Gw.MTU - (if (v6) 48 else 28)) out.add("UDP yükü ${l - 8} bayt: MTU'yu aşıyor")
    }
    return out
}

/**
 * Geçidin tünele yazdığı her paketi (gw-io iş parçacığında, yazma anında) denetler. Durumsuz kurallara ek olarak akış başına durumlu kurallar:
 * el sıkışmadan önce segment yok, RST sonrası segment yok, gönderilen veri bildirilen MSS'yi aşmaz, bayt akışında boşluk yok.
 * İhlaller [bad] listesine yazılır (en çok 40); denetçi hiçbir zaman istisna fırlatmaz (yazma hatası sayılmasın).
 */
internal class V6Wire(r: GRig) {
    val bad = CopyOnWriteArrayList<String>()
    val pkts = AtomicInteger()
    val v6Pkts = AtomicInteger()
    val dataSegs = AtomicInteger()
    val maxData = AtomicInteger()

    private class Fl { var mss = 0; var open = false; var rst = false; var top = 0 }
    private val flows = HashMap<Long, Fl>()

    init { r.outFault = { p -> observe(p); null } }

    private fun note(msg: String, p: ByteArray) {
        if (bad.size < 40) bad.add(msg + " [" + v6Hex(p) + "]")
    }

    fun observe(p: ByteArray) {
        pkts.incrementAndGet()
        try {
            for (v in wireViolations(p)) note(v, p)
            stateful(p)
        } catch (e: Throwable) { note("denetçi hatası: $e", p) }
    }

    private fun stateful(p: ByteArray) {
        val v6 = ((p[0].toInt() ushr 4) and 0xF) == 6
        if (v6) v6Pkts.incrementAndGet()
        val ip = if (v6) 40 else (p[0].toInt() and 0xF) * 4
        val proto = if (v6) p[6].toInt() and 0xFF else p[9].toInt() and 0xFF
        if (proto != 6 || p.size < ip + 20) return
        val key = (Packets.u16(p, ip).toLong() shl 16) or Packets.u16(p, ip + 2).toLong()
        val doff = (p[ip + 12].toInt() and 0xF0) ushr 2
        val fl = p[ip + 13].toInt() and 0xFF
        val seq = Packets.i32(p, ip + 4)
        val dl = p.size - ip - doff
        val f = flows[key]
        if (fl and Gw.SYN != 0) {
            val nf = f ?: Fl().also { flows[key] = it }
            nf.open = true; nf.rst = false; nf.top = seq + 1
            nf.mss = v6TcpMss(p, ip)
            return
        }
        if (fl and Gw.RST != 0) { if (f != null) f.rst = true; return }
        if (f == null || !f.open) { note("el sıkışmadan önce segment", p); return }
        if (f.rst) { note("RST sonrası segment", p); return }
        if (dl > 0) { dataSegs.incrementAndGet(); if (dl > maxData.get()) maxData.set(dl) }
        if (dl > 0 && f.mss > 0 && dl > f.mss) note("segment $dl bayt, bildirilen MSS ${f.mss}", p)
        if (Gw.seqLt(f.top, seq)) note("gönderim sırasında boşluk: üst sınır ${f.top}, gelen $seq", p)
        val end = seq + dl + (if (fl and Gw.FIN != 0) 1 else 0)
        if (Gw.seqLt(f.top, end)) f.top = end
    }
}

private class V6Mut(val name: String, val kinds: String, val fam: Int, val expect: String, val fn: (ByteArray, Int, Boolean) -> ByteArray)

private fun v6OracleSelfTest() {
    T.group("Sızma 13 / bağımsız paket denetçisi (kâhin): geçerli paketleri kabul eder, her kural ihlalini yakalar")
    val b = ByteArray(4096)
    val data = ByteArray(100) { (it * 3 + 1).toByte() }
    val bases = ArrayList<Triple<String, Boolean, ByteArray>>()
    for (v6 in listOf(false, true)) {
        val src = if (v6) SelfTest.CLIENT6 else CLI4
        val dst = if (v6) MAPPED6 else LO4
        val fam = if (v6) "v6" else "v4"
        var n = Gw.tcp(b, v6, dst, src, 80, 4000, 11, 22, F_ACK or F_PSH, 5000, data, 0, data.size)
        bases.add(Triple("$fam TCP veri", v6, b.copyOf(n)))
        n = Gw.tcp(b, v6, dst, src, 80, 4000, 11, 22, F_SYN or F_ACK, 5000, null, 0, 0, 1400)
        bases.add(Triple("$fam SYN+ACK", v6, b.copyOf(n)))
        n = Gw.tcp(b, v6, dst, src, 80, 4000, 11, 22, F_RST or F_ACK, 0, null, 0, 0)
        bases.add(Triple("$fam RST", v6, b.copyOf(n)))
        n = Gw.udp(b, v6, dst, src, 53, 4000, data, 0, data.size)
        bases.add(Triple("$fam UDP", v6, b.copyOf(n)))
    }
    for ((name, _, pkt) in bases) {
        val v = wireViolations(pkt)
        T.check("kâhin: geçerli paket kabul edilir ($name)", v.isEmpty(), "$v")
    }
    val muts = listOf(
        V6Mut("yükte bir bit", "TCP veri,UDP", 0, "sağlama") { p, _, _ -> p[p.size - 3] = (p[p.size - 3].toInt() xor 0x10).toByte(); p },
        V6Mut("sağlama alanı bozuk", "TCP veri,SYN+ACK,RST", 0, "sağlama") { p, ip, _ -> p[ip + 16] = (p[ip + 16].toInt() xor 1).toByte(); p },
        V6Mut("UDP sağlaması 0", "UDP", 0, "sağlaması 0") { p, ip, _ -> p[ip + 6] = 0; p[ip + 7] = 0; p },
        V6Mut("UDP uzunluk alanı yanlış", "UDP", 0, "UDP uzunlu") { p, ip, _ -> Packets.put16(p, ip + 4, Packets.u16(p, ip + 4) + 3); v6Refix(p); p },
        V6Mut("IP uzunluk alanı yanlış", "TCP veri,SYN+ACK,RST,UDP", 0, "uzunlu") { p, _, v6 ->
            if (v6) Packets.put16(p, 4, Packets.u16(p, 4) + 2) else Packets.put16(p, 2, Packets.u16(p, 2) + 2)
            v6Refix(p); p
        },
        V6Mut("TCP ayrılmış bit", "TCP veri,SYN+ACK,RST", 0, "ayrılmış") { p, ip, _ -> p[ip + 12] = (p[ip + 12].toInt() or 1).toByte(); v6Refix(p); p },
        V6Mut("TCP veri ofseti 12 bayt", "TCP veri", 0, "veri ofseti") { p, ip, _ -> p[ip + 12] = 0x30; v6Refix(p); p },
        V6Mut("acil işaretçi URG olmadan", "TCP veri,RST", 0, "acil işaretçi") { p, ip, _ -> Packets.put16(p, ip + 18, 5); v6Refix(p); p },
        V6Mut("SYN tek başına", "SYN+ACK", 0, "SYN tek başına") { p, ip, _ -> p[ip + 13] = F_SYN.toByte(); v6Refix(p); p },
        V6Mut("MSS seçeneği yok", "SYN+ACK", 0, "MSS seçeneği yok") { p, ip, _ -> for (i in 0 until 4) p[ip + 20 + i] = 1; v6Refix(p); p },
        V6Mut("MSS aralık dışı", "SYN+ACK", 0, "aralık dışı") { p, ip, _ -> Packets.put16(p, ip + 22, 9000); v6Refix(p); p },
        V6Mut("MSS seçenek uzunluğu 5", "SYN+ACK", 0, "bozuk") { p, ip, _ -> p[ip + 21] = 5; v6Refix(p); p },
        V6Mut("TTL / hop limiti 0", "TCP veri,UDP", 0, "çok küçük") { p, _, v6 -> if (v6) p[7] = 0 else p[8] = 0; v6Refix(p); p },
        V6Mut("beklenmeyen protokol", "TCP veri,UDP", 0, "protokol") { p, _, v6 -> if (v6) p[6] = 50 else p[9] = 50; p },
        V6Mut("v4 parça biti (MF)", "TCP veri,UDP", 4, "parça") { p, _, _ -> p[6] = (p[6].toInt() or 0x20).toByte(); v6Refix(p); p },
        V6Mut("v4 başlık sağlaması bozuk", "TCP veri,UDP", 4, "başlık sağlaması") { p, _, _ -> p[10] = (p[10].toInt() xor 0x01).toByte(); p },
        V6Mut("v6 akış etiketi sıfır değil", "TCP veri,UDP", 6, "etiketi") { p, _, _ -> p[1] = 0x01; v6Refix(p); p },
    )
    for (m in muts) for ((name, v6, pkt) in bases) {
        if (!m.kinds.split(",").any { name.endsWith(it) }) continue
        if ((m.fam == 4 && v6) || (m.fam == 6 && !v6)) continue
        val mp = m.fn(pkt.copyOf(), if (v6) 40 else 20, v6)
        val v = wireViolations(mp)
        T.check("kâhin: $name — ${m.name} yakalanır", v.any { it.contains(m.expect) }, "ihlaller=$v")
    }
    for (v6 in listOf(false, true)) {
        val src = if (v6) SelfTest.CLIENT6 else CLI4
        val dst = if (v6) MAPPED6 else LO4
        val fam = if (v6) "v6" else "v4"
        var n = Gw.tcp(b, v6, dst, src, 80, 4000, 1, 2, F_RST or F_ACK, 0, data, 0, 10)
        T.check("kâhin: $fam RST yük taşıyor → yakalanır", wireViolations(b.copyOf(n)).any { it.contains("RST yük") })
        val big = ByteArray(1461)
        n = Gw.tcp(b, v6, dst, src, 80, 4000, 1, 2, F_ACK, 100, big, 0, big.size)
        T.check("kâhin: $fam MTU'yu aşan TCP verisi → yakalanır", wireViolations(b.copyOf(n)).any { it.contains("MTU") })
        val ub = ByteArray(if (v6) 1453 else 1473)
        n = Gw.udp(b, v6, dst, src, 53, 4000, ub, 0, ub.size)
        T.check("kâhin: $fam MTU'yu aşan UDP yükü → yakalanır", wireViolations(b.copyOf(n)).any { it.contains("MTU") })
        val okU = ByteArray(if (v6) 1452 else 1472)
        n = Gw.udp(b, v6, dst, src, 53, 4000, okU, 0, okU.size)
        T.check("kâhin: $fam tam sınırdaki UDP yükü (${okU.size}) kabul edilir", wireViolations(b.copyOf(n)).isEmpty())
    }
}

// ====================================================================================================== istemci yardımcıları

private fun GCli.connectMss(m: Int): GSeg? {
    send(F_SYN, mss = m); seq++
    val sa = next() ?: return null
    if (sa.flags != (F_SYN or F_ACK)) return sa
    rcv = sa.seq + 1
    send(F_ACK)
    return sa
}

/** Pencere uyumlu gönderici (GatewayTests'teki 300 KB yüklemeyle aynı mantık): [data] eksiksiz onaylanınca true. */
private fun GCli.upload(data: ByteArray, ms: Long): Boolean {
    val base = seq
    var sent = 0
    var una = base
    var peer = 65535
    val end = System.currentTimeMillis() + ms
    var lastProgress = System.currentTimeMillis()
    while (una - base < data.size && System.currentTimeMillis() < end) {
        val room = peer - (base + sent - una)
        if (sent < data.size && room > 0) {
            val n = minOf(1400, data.size - sent, room)
            send(F_ACK or F_PSH, data.copyOfRange(sent, sent + n), seqNo = base + sent)
            sent += n
        }
        val s = next(if (sent < data.size && room > 0) 1 else 100)
        if (s == null) {
            if (System.currentTimeMillis() - lastProgress > 400) {
                sent = una - base; lastProgress = System.currentTimeMillis()
                if (peer == 0) peer = 1                                    // pencere güncellemesi kaybolduysa 1 baytlık yoklama
            }
            continue
        }
        if (s.flags and F_RST != 0) return false
        if (s.flags and F_ACK != 0 && Gw.seqLt(una, s.ack) && Gw.seqLe(s.ack, base + sent)) { una = s.ack; lastProgress = System.currentTimeMillis() }
        peer = s.win
    }
    seq = base + data.size
    return una - base >= data.size
}

private class V6Drain(val data: ByteArray, val fin: Boolean, val rst: Boolean)

/** FIN ya da RST gelene (en çok [ms]) dek gelen veriyi toplar; her şeyi onaylar. */
private fun v6Drain(c: GCli, ms: Long): V6Drain {
    val o = ByteArrayOutputStream()
    var fin = false
    var rst = false
    val end = System.currentTimeMillis() + ms
    while (!fin && !rst) {
        val left = end - System.currentTimeMillis()
        if (left <= 0) break
        val s = c.next(left) ?: break
        if (s.flags and F_RST != 0) { rst = true; break }
        if (s.data.isNotEmpty()) {
            val skip = c.rcv - s.seq
            if (skip >= 0 && skip < s.data.size) { o.write(s.data, skip, s.data.size - skip); c.rcv += s.data.size - skip }
            c.send(F_ACK)
        }
        if (s.flags and F_FIN != 0 && s.seq + s.data.size == c.rcv) { c.rcv++; fin = true; c.send(F_ACK) }
    }
    return V6Drain(o.toByteArray(), fin, rst)
}

private fun v6IndexOf(h: ByteArray, n: ByteArray): Int {
    outer@ for (i in 0..h.size - n.size) {
        for (j in n.indices) if (h[i + j] != n[j]) continue@outer
        return i
    }
    return -1
}

private fun v6Clean(r: GRig, w: V6Wire, v6: Boolean, tag: String, minPkts: Int = 3) {
    T.check("$tag: geçidin yazdığı ${w.pkts.get()} paketin hepsi RFC denetçisinden geçti", w.bad.isEmpty() && w.pkts.get() >= minPkts, w.bad.take(3).joinToString(" | "))
    T.check("$tag: yanıt ailesi korunur (${if (v6) "v6 istemciye yalnız v6" else "v4 istemciye yalnız v4"})", w.v6Pkts.get() == (if (v6) w.pkts.get() else 0), "v6=${w.v6Pkts.get()}/${w.pkts.get()}")
    T.check("$tag: beklenmeyen iç hata yok", r.gw.stats().internalErrors == 0L, "${r.gw.stats().internalErrors} ${r.gw.lastInternalError()}")
}

// ====================================================================================================== 1) el sıkışma, MSS, yankı, toplu aktarım

private fun v6HandshakeBulk() {
    T.group("Sızma 13 / v4 ↔ v6: el sıkışma (MSS sıkıştırma), 5 KB yankı, 300 KB indirme ve yükleme; her paket bağımsız denetçiden geçer")
    val dl = ByteArray(300_000) { (it * 31 + 7).toByte() }
    val up = ByteArray(300_000) { (it * 13 + 5).toByte() }
    for (f in V6_FAMS) {
        val r = GRig()
        val wire = V6Wire(r)
        val echo = Sink(echo = true)
        val big = Srv { s -> s.getOutputStream().write(dl); s.getOutputStream().flush(); try { s.soTimeout = 4000; while (s.getInputStream().read() >= 0) { } } catch (_: Exception) { } }
        val recv = ByteArrayOutputStream()
        val done = CountDownLatch(1)
        val upSrv = Srv { s -> val i = s.getInputStream(); val b = ByteArray(8192); while (true) { val n = i.read(b); if (n < 0) break; synchronized(recv) { recv.write(b, 0, n) } }; done.countDown() }
        try {
            val cases = listOf(0 to 536, 1460 to minOf(1460, f.mss), 9000 to f.mss, 1220 to 1220, 536 to 536, 100 to 100, 50 to 100)
            for ((cm, want) in cases) {
                val c = f.cli(r, echo.port)
                val sa = c.connectMss(cm)
                T.check("${f.name}: SYN MSS=$cm → SYN+ACK bayrakları, ack=7001, sağlama doğru, MSS=$want", sa != null && sa.flags == (F_SYN or F_ACK) && sa.ack == 7001 && sa.ok && sa.mss == want,
                    "flags=${sa?.flags} ack=${sa?.ack} ok=${sa?.ok} mss=${sa?.mss}")
                val msg = ByteArray(5000) { (it * 7 + cm).toByte() }
                var o = 0
                while (o < msg.size) { val n = minOf(1000, msg.size - o); c.write(msg.copyOfRange(o, o + n)); o += n }
                val e = c.read(msg.size, 5000)
                T.check("${f.name}: MSS=$cm bağlantısında 5000 bayt yankı bozulmadan döner", e.contentEquals(msg), "${e.size}")
                c.send(F_RST or F_ACK)
            }
            val c = f.cli(r, big.port)
            c.connect()
            val got = c.readAll(dl.size, 20_000)
            T.check("${f.name}: 300 KB indirme sıra ve içerik bozulmadan geldi", got.size == dl.size && got.contentEquals(dl), "${got.size}")
            T.check("${f.name}: en büyük veri segmenti tam MSS (${f.mss}), hiçbiri aşmadı", wire.maxData.get() == f.mss, "en büyük=${wire.maxData.get()}")
            c.send(F_RST or F_ACK)
            val u = f.cli(r, upSrv.port)
            u.connect()
            val ok = u.upload(up, 25_000)
            u.send(F_FIN or F_ACK); u.seq++
            T.check("${f.name}: 300 KB yükleme pencere sınırına uyularak tamamlandı, sunucu bayt bayt aynısını aldı", ok && done.await(8, TimeUnit.SECONDS) && synchronized(recv) { recv.toByteArray().contentEquals(up) }, "ok=$ok alınan=${synchronized(recv) { recv.size() }}")
            v6Clean(r, wire, f.v6, f.name)
        } finally { big.close(); upSrv.close(); echo.close(); r.close() }
    }
}

// ====================================================================================================== 2) yaşam döngüsü eşliği

private fun v6Lifecycle(f: V6Fam): List<String> {
    val sig = ArrayList<String>()
    val tag = f.name
    val r = GRig()
    val wire = V6Wire(r)
    try {
        // S1: sunucu veriyi yollayıp kapatır
        run {
            val srv = Srv { s -> s.getOutputStream().write("hello".toByteArray()); s.getOutputStream().flush() }
            val c = f.cli(r, srv.port); c.connect()
            val d = v6Drain(c, 4000)
            c.send(F_FIN or F_ACK); c.seq++
            val a = c.next(2500)
            val acked = a != null && a.flags and F_ACK != 0 && a.ack == c.seq
            val s1 = "S1 sunucu kapanır: veri=${String(d.data)} fin=${d.fin} rst=${d.rst} istemci-FIN-onayı=$acked"
            sig.add(s1)
            T.check("$tag: sunucu veriyi yollayıp kapatınca istemci veri + FIN alır, kendi FIN'i onaylanır", String(d.data) == "hello" && d.fin && !d.rst && acked, s1)
            srv.close()
        }
        // S2: istemci yarım kapanış (FIN) — sunucu EOF'a dek okuyup cevap verir
        run {
            val srv = Srv { s ->
                val i = s.getInputStream(); val t = ByteArray(512); var n = 0
                while (true) { val k = i.read(t); if (k < 0) break; n += k }
                s.getOutputStream().write("got$n".toByteArray()); s.getOutputStream().flush()
            }
            val c = f.cli(r, srv.port); c.connect()
            c.write("ping".toByteArray()); c.send(F_FIN or F_ACK); c.seq++
            val d = v6Drain(c, 5000)
            val s2 = "S2 istemci yarım kapanış: yanıt=${String(d.data)} fin=${d.fin} rst=${d.rst}"
            sig.add(s2)
            T.check("$tag: istemci FIN'inden sonra sunucunun cevabı yine gelir (yarım kapanış)", String(d.data) == "got4" && d.fin && !d.rst, s2)
            srv.close()
        }
        // S3: sunucu yarım kapanış — FIN'den sonra istemci yine veri yollayabilir
        run {
            val late = AtomicReference<String?>(null)
            val srv = Srv { s ->
                s.getOutputStream().write("bye".toByteArray()); s.getOutputStream().flush(); s.shutdownOutput()
                val i = s.getInputStream(); val t = ByteArray(512); val b = ByteArrayOutputStream()
                s.soTimeout = 4000
                try { while (true) { val k = i.read(t); if (k < 0) break; b.write(t, 0, k) } } catch (_: Exception) { }
                late.set(String(b.toByteArray()))
            }
            val c = f.cli(r, srv.port); c.connect()
            val d = v6Drain(c, 4000)
            c.write("late".toByteArray()); c.send(F_FIN or F_ACK); c.seq++
            waitUntil(4500) { late.get() != null }
            val s3 = "S3 sunucu yarım kapanış: istemci=${String(d.data)} fin=${d.fin} rst=${d.rst} sunucu-sonradan-aldı=${late.get()}"
            sig.add(s3)
            T.check("$tag: sunucu yarım kapatınca istemci FIN alır ve sonradan yolladığı veri sunucuya ulaşır", String(d.data) == "bye" && d.fin && !d.rst && late.get() == "late", s3)
            srv.close()
        }
        // S4: pencere içi istemci RST'si sunucu soketini kapatır
        run {
            val closed = AtomicBoolean(false)
            val srv = Srv { s -> try { s.soTimeout = 4000; while (s.getInputStream().read() >= 0) { } } catch (_: Exception) { }; closed.set(true) }
            val c = f.cli(r, srv.port); c.connect(); c.write("x".toByteArray())
            c.send(F_RST or F_ACK)
            val ok = waitUntil(3500) { closed.get() }
            val s4 = "S4 istemci RST: sunucu-soketi-kapandı=$ok"
            sig.add(s4)
            T.check("$tag: istemci RST'si sunucu bağlantısını hemen kapatır", ok, s4)
            srv.close()
        }
        // S5: sunucu RST ile keser (SO_LINGER 0)
        run {
            val srv = Srv { s -> s.getOutputStream().write("part".toByteArray()); s.getOutputStream().flush(); Thread.sleep(120); s.setSoLinger(true, 0) }
            val c = f.cli(r, srv.port); c.connect()
            val d = v6Drain(c, 4000)
            val s5 = "S5 sunucu RST: rst=${d.rst} fin=${d.fin}"
            sig.add(s5)
            T.check("$tag: sunucu RST'si istemciye RST olarak iletilir", d.rst && !d.fin, s5)
            srv.close()
        }
        // S6: reddedilen bağlantı
        run {
            val dead = ServerSocket(0, 1, InetAddress.getByAddress(LO4)).let { val p = it.localPort; it.close(); p }
            val c = f.cli(r, dead)
            c.send(F_SYN, mss = 1460); c.seq++
            val x = c.next(5000)
            val s6 = "S6 reddedilen bağlantı: bayrak=${x?.flags} ack=${x?.ack} sağlama=${x?.ok}"
            sig.add(s6)
            T.check("$tag: kapalı porta SYN → RST|ACK, ack=7001, sağlama doğru", x != null && x.flags == (F_RST or F_ACK) && x.ack == 7001 && x.ok, s6)
        }
        // S7: bilinmeyen akışa gelen segmentler (RFC 793 §3.4)
        run {
            val c = f.cli(r, 9)
            c.send(F_ACK or F_PSH, "x".toByteArray(), seqNo = 5000, ackNo = 123456)
            val a = c.next(1500)
            c.send(0, "abc".toByteArray(), seqNo = 5000, ackNo = 0)
            val b = c.next(1500)
            c.send(F_FIN or F_ACK, seqNo = 5000, ackNo = 777)
            val d = c.next(1500)
            c.send(F_RST, seqNo = 5000, ackNo = 0)
            val e = c.next(400)
            val s7 = "S7 bilinmeyen akış: ACK→${a?.flags}/${a?.seq} bayraksız→${b?.flags}/${b?.ack} FIN→${d?.flags}/${d?.seq} RST→${e?.flags}"
            sig.add(s7)
            T.check("$tag: bilinmeyen akışa ACK'li segment → RST (seq = gelen ack)", a != null && a.flags == F_RST && a.seq == 123456 && a.ok, s7)
            T.check("$tag: bilinmeyen akışa ACK'siz veri → RST|ACK (ack = seq + uzunluk)", b != null && b.flags == (F_RST or F_ACK) && b.ack == 5003 && b.ok, s7)
            T.check("$tag: bilinmeyen akışa FIN|ACK → RST (seq = gelen ack)", d != null && d.flags == F_RST && d.seq == 777, s7)
            T.check("$tag: RST'ye RST ile karşılık verilmez", e == null, s7)
        }
        // S8: aynı portta yeni ISN (uygulama yeniden başladı): eski akış kapanır, yenisi kurulur
        run {
            val eofs = AtomicInteger()
            val srv = Srv { s ->
                val i = s.getInputStream(); val o = s.getOutputStream(); val t = ByteArray(512)
                while (true) { val k = try { i.read(t) } catch (_: Exception) { -1 }; if (k < 0) break; o.write(t, 0, k); o.flush() }
                eofs.incrementAndGet()
            }
            val c = f.cli(r, srv.port); c.connect()
            c.write("one".toByteArray()); val r1 = String(c.read(3, 3000))
            c.seq = 123456
            val sa2 = c.connect()
            val old = waitUntil(3000) { eofs.get() >= 1 }
            c.write("two".toByteArray()); val r2 = String(c.read(3, 3000))
            val s8 = "S8 aynı port, yeni ISN: ilk=$r1 yeni-synack=${sa2?.flags}/${sa2?.ack} eski-kapandı=$old ikinci=$r2"
            sig.add(s8)
            T.check("$tag: aynı porttan yeni SYN eski akışı kapatır, yeni akış çalışır", r1 == "one" && sa2 != null && sa2.flags == (F_SYN or F_ACK) && sa2.ack == 123457 && old && r2 == "two", s8)
            c.send(F_RST or F_ACK)
            srv.close()
        }
        val cleared = waitUntil(10_000) { r.gw.stats().tcpFlows == 0 }
        sig.add("tablo temizlendi=$cleared")
        T.check("$tag: tüm akışlar kapanınca tablo boşalır (bekleme süresi sonrası)", cleared, "kalan=${r.gw.stats().tcpFlows}")
        T.check("$tag: ortak bellek tamamen geri verildi", r.gw.mem.used == 0, "kullanım=${r.gw.mem.used}")
        v6Clean(r, wire, f.v6, tag)
    } finally { r.close() }
    return sig
}

private fun v6LifecycleParity() {
    T.group("Sızma 13 / v4 ↔ v6 eşlik: bağlantı yaşam döngüsü (sunucu FIN, iki yönlü yarım kapanış, RST'ler, reddedilen bağlantı, bilinmeyen akış, port yeniden kullanımı)")
    val sigs = V6_FAMS.map { v6Lifecycle(it) }
    val diff = sigs[0].zip(sigs[1]).filter { it.first != it.second }
    T.check("IPv6 gözlem imzası IPv4 ile birebir aynı (${sigs[0].size} gözlem)", sigs[0].size == sigs[1].size && diff.isEmpty(), "fark=$diff")
}

// ====================================================================================================== 3) UDP eşliği

/** [data] datagramını istemci olarak yollar, aynı portlardan dönen ilk UDP paketini (tam IP paketi) döner; [waitMs] içinde gelmezse null. */
private fun v6UdpRound(f: V6Fam, r: GRig, cport: Int, dport: Int, data: ByteArray, waitMs: Long, wrap: ((ByteArray) -> ByteArray)? = null): ByteArray? {
    val b = ByteArray(8192)
    val n = Gw.udp(b, f.v6, f.src, f.dst, cport, dport, data, 0, data.size)
    val pk = b.copyOf(n)
    val o = if (wrap != null) wrap(pk) else pk
    r.gw.onPacket(o, o.size)
    val end = System.currentTimeMillis() + waitMs
    while (true) {
        val left = end - System.currentTimeMillis()
        if (left <= 0) return null
        val p = r.q.poll(left, TimeUnit.MILLISECONDS) ?: return null
        val ver = (p[0].toInt() ushr 4) and 0xF
        val ip = if (ver == 6) 40 else (p[0].toInt() and 0xF) * 4
        val proto = if (ver == 6) p[6].toInt() and 0xFF else p[9].toInt() and 0xFF
        if (proto != 17 || Packets.u16(p, ip) != dport || Packets.u16(p, ip + 2) != cport) continue
        return p
    }
}

/** Yankı cevabının UDP sağlaması tam 0 çıkacak yükü üretir: son iki bayt serbest (sağlama toplamı simetrik: yön fark etmez). */
private fun v6ZeroSumPayload(f: V6Fam, cport: Int, dport: Int): ByteArray {
    val d = byteArrayOf(0x12, 0x34, 0x56, 0x78, 0, 0)
    val udpLen = 8 + d.size
    val hdr = ByteArray(8)
    Packets.put16(hdr, 0, dport); Packets.put16(hdr, 2, cport); Packets.put16(hdr, 4, udpLen)
    var s = v6Sum(0L, f.dst, 0, f.dst.size)
    s = v6Sum(s, f.src, 0, f.src.size)
    s += udpLen.toLong() + 17L
    s = v6Sum(s, hdr, 0, 8)
    s = v6Sum(s, d, 0, 4)
    for (w in 0..0xFFFF) if ((s + w.toLong()) % 65535L == 0L) { d[4] = (w ushr 8).toByte(); d[5] = w.toByte(); return d }
    return d
}

private fun v6UdpSignature(f: V6Fam): List<String> {
    val sig = ArrayList<String>()
    val tag = f.name
    val r = GRig()
    val wire = V6Wire(r)
    val echo = DatagramSocket(0, InetAddress.getByAddress(LO4))
    val th = Thread({
        val buf = ByteArray(65535)
        while (!echo.isClosed) {
            val p = DatagramPacket(buf, buf.size)
            try { echo.receive(p); echo.send(DatagramPacket(p.data, p.offset, p.length, p.socketAddress)) } catch (_: Exception) { }
        }
    }, "v6-udp-yanki")
    th.isDaemon = true
    th.start()
    try {
        r.gw.config.udpIdleMs = 800
        val cport = portCounter.incrementAndGet()
        // boyutlar aileye göre değişir (v4: 1472, v6: 1452); imzada sembolik adlarla yazılır ki iki aile karşılaştırılabilsin
        for ((label, n) in listOf("1" to 1, "33" to 33, "512" to 512, "1200" to 1200, "max-1" to f.maxUdp - 1, "max" to f.maxUdp)) {
            val d = ByteArray(n) { (it * 5 + n).toByte() }
            val rep = v6UdpRound(f, r, cport, echo.localPort, d, 3000)
            val ok = rep != null && Gw.checksumOk(rep, rep.size) && rep.size == f.hdr + 8 + n && rep.copyOfRange(f.hdr + 8, rep.size).contentEquals(d)
            sig.add("udp $label yankı=$ok")
            T.check("$tag: $n baytlık UDP yankılanır (üst sınır ${f.maxUdp}), sağlama doğru, paket ≤ ${Gw.MTU}", ok && rep != null && rep.size <= Gw.MTU, "rep=${rep?.size}")
        }
        for ((label, n) in listOf("max+1" to f.maxUdp + 1, "max+9" to f.maxUdp + 9, "1500" to 1500, "4000" to 4000)) {
            val rep = v6UdpRound(f, r, cport, echo.localPort, ByteArray(n) { 7 }, 600)
            sig.add("udp $label (MTU üstü) cevap=${rep != null}")
            T.check("$tag: MTU'dan büyük UDP cevabı ($n bayt) düşürülür (IP parçalama yok)", rep == null)
        }
        val alive = v6UdpRound(f, r, cport, echo.localPort, "canlı".toByteArray(), 3000)
        sig.add("MTU üstü sonrası akış canlı=${alive != null}")
        T.check("$tag: büyük cevap düşürülse de akış canlı kalır", alive != null)
        // sağlama toplamı tam sıfır çıkan yük: 0xFFFF yazılmalı (v6'da 0 geçersiz, v4'te 'sağlama yok' demek)
        val zp = v6ZeroSumPayload(f, cport, echo.localPort)
        val zr = v6UdpRound(f, r, cport, echo.localPort, zp, 3000)
        val zOk = zr != null && Packets.u16(zr, f.hdr + 6) == 0xFFFF && Gw.checksumOk(zr, zr.size) && wireViolations(zr).isEmpty() && zr.copyOfRange(f.hdr + 8, zr.size).contentEquals(zp)
        sig.add("sağlama-sıfır köşesi=$zOk")
        T.check("$tag: sağlaması 0 çıkan UDP cevabında 0xFFFF yazılır (RFC 768 / 8200 §8.1)", zOk, "alan=${if (zr != null) Packets.u16(zr, f.hdr + 6) else -1}")
        // çok noktaya hedef: akış açılmaz
        val mc = if (f.v6) ByteArray(16).also { it[0] = 0xFF.toByte(); it[1] = 0x02; it[15] = 0xFB.toByte() } else byteArrayOf(224.toByte(), 0, 0, 251.toByte())
        val bb = ByteArray(512)
        val md = "mdns".toByteArray()
        val before = r.gw.stats().udpFlows
        val mn = Gw.udp(bb, f.v6, f.src, mc, 5353, 5353, md, 0, md.size)
        r.gw.onPacket(bb.copyOf(mn), mn)
        Thread.sleep(250)
        sig.add("çok noktaya: akış-artışı=${r.gw.stats().udpFlows - before}")
        T.check("$tag: çok noktaya UDP (mDNS) aktarılmaz, akış açılmaz", r.gw.stats().udpFlows == before)
        // boşta zaman aşımı
        val gone = waitUntil(8000) { r.gw.stats().udpFlows == 0 }
        sig.add("boşta zaman aşımı=$gone")
        T.check("$tag: boşta kalan UDP akışı zaman aşımıyla kapanır (800 ms)", gone, "kalan=${r.gw.stats().udpFlows}")
        // iki istemci portu: cevaplar doğru porta gider, iki ayrı akış
        r.gw.config.udpIdleMs = 30_000
        val pA = portCounter.incrementAndGet(); val pB = portCounter.incrementAndGet()
        val ra = v6UdpRound(f, r, pA, echo.localPort, "A".toByteArray(), 2000)
        val rb = v6UdpRound(f, r, pB, echo.localPort, "BB".toByteArray(), 2000)
        val two = ra != null && rb != null && ra.size == f.hdr + 8 + 1 && rb.size == f.hdr + 8 + 2 && r.gw.stats().udpFlows == 2
        sig.add("iki istemci portu=$two")
        T.check("$tag: iki istemci portu iki ayrı UDP akışı olur, cevaplar doğru porta döner", two, "akış=${r.gw.stats().udpFlows}")
        // kapalı porta datagram: ICMP port ulaşılamaz akışı kapatır (boşta süresi 30 sn: kapanış yalnızca ICMP'den gelebilir)
        r.gw.networkReset()
        waitUntil(5000) { r.gw.stats().udpFlows == 0 }
        val closedPort = DatagramSocket(0, InetAddress.getByAddress(LO4)).let { val p = it.localPort; it.close(); p }
        v6UdpRound(f, r, portCounter.incrementAndGet(), closedPort, "x".toByteArray(), 300)
        val unreach = waitUntil(3000) { r.gw.stats().udpFlows == 0 }
        sig.add("ICMP port ulaşılamaz akışı kapattı=$unreach")
        println("  (bilgi) $tag: ICMP port-ulaşılamaz akışı kapattı=$unreach")
        T.check("$tag: UDP hata yolları iç hata üretmedi", r.gw.stats().internalErrors == 0L, "${r.gw.lastInternalError()}")
        T.check("$tag: UDP'de geçidin yazdığı ${wire.pkts.get()} paketin hepsi RFC denetçisinden geçti", wire.bad.isEmpty() && wire.pkts.get() >= 10, wire.bad.take(3).joinToString(" | "))
        T.check("$tag: UDP yanıt ailesi korunur", wire.v6Pkts.get() == (if (f.v6) wire.pkts.get() else 0), "v6=${wire.v6Pkts.get()}/${wire.pkts.get()}")
    } finally { echo.close(); r.close() }
    return sig
}

private fun v6UdpParity() {
    T.group("Sızma 13 / v4 ↔ v6 eşlik: UDP (yankı sınırları, MTU, sağlama=0 köşesi, çok noktaya, boşta süresi, iki istemci, ICMP port ulaşılamaz)")
    val sigs = V6_FAMS.map { v6UdpSignature(it) }
    val diff = sigs[0].zip(sigs[1]).filter { it.first != it.second }
    T.check("IPv6 UDP gözlem imzası IPv4 ile birebir aynı (${sigs[0].size} gözlem)", sigs[0].size == sigs[1].size && diff.isEmpty(), "fark=$diff")
}

// ====================================================================================================== 4) IPv6 uzantı başlıkları

/** v6 paketinin taban başlığından sonra [chain] (tür, 8 baytlık birim sayısı) uzantı başlıklarını ekler. Sağlama değişmez (RFC 8200 §8.1). v4'e dokunmaz. */
private fun v6WithExt(p: ByteArray, chain: List<Pair<Int, Int>>): ByteArray {
    if (chain.isEmpty() || ((p[0].toInt() ushr 4) and 0xF) != 6) return p
    val proto = p[6].toInt() and 0xFF
    val extLen = chain.sumOf { it.second * 8 }
    val o = ByteArray(p.size + extLen)
    System.arraycopy(p, 0, o, 0, 40)
    System.arraycopy(p, 40, o, 40 + extLen, p.size - 40)
    Packets.put16(o, 4, Packets.u16(p, 4) + extLen)
    o[6] = chain[0].first.toByte()
    var off = 40
    for ((i, h) in chain.withIndex()) {
        val len = h.second * 8
        o[off] = (if (i + 1 < chain.size) chain[i + 1].first else proto).toByte()
        o[off + 1] = (h.second - 1).toByte()
        if (h.first == 0 || h.first == 60) { o[off + 2] = 1; o[off + 3] = (len - 4).toByte() }      // PadN
        if (h.first == 43) { o[off + 2] = 4; o[off + 3] = 0 }                                          // yönlendirme türü 4, kalan segment 0
        off += len
    }
    return o
}

private val EXT_OK: List<List<Pair<Int, Int>>> = listOf(
    listOf(0 to 1),
    listOf(60 to 1),
    listOf(0 to 2, 60 to 3),
    listOf(0 to 1, 43 to 2, 60 to 1),
    listOf(0 to 1) + List(7) { 60 to 1 },
)

private fun v6ExtTests() {
    T.group("Sızma 13 / IPv6 uzantı başlıkları: geçerli zincirler durumlu akışta çalışır; sınır dışı, parçalı, bilinmeyen ve bozuk zincirler sessizce düşer")
    val f = V6_FAMS[1]
    val r = GRig()
    val wire = V6Wire(r)
    val echo = Sink(echo = true)
    val udpEcho = DatagramSocket(0, InetAddress.getByAddress(LO4))
    val th = Thread({
        val buf = ByteArray(4096)
        while (!udpEcho.isClosed) {
            val p = DatagramPacket(buf, buf.size)
            try { udpEcho.receive(p); udpEcho.send(DatagramPacket(p.data, p.offset, p.length, p.socketAddress)) } catch (_: Exception) { }
        }
    }, "v6-ext-udp")
    th.isDaemon = true
    th.start()
    try {
        for ((k, chain) in EXT_OK.withIndex()) {
            val c = f.cli(r, echo.port)
            c.wrap = { p -> v6WithExt(p, chain) }
            val sa = c.connect()
            val msg = ByteArray(3000) { (it + k).toByte() }
            var o = 0
            while (o < msg.size) { val n = minOf(900, msg.size - o); c.write(msg.copyOfRange(o, o + n)); o += n }
            val got = c.read(msg.size, 5000)
            c.send(F_FIN or F_ACK); c.seq++
            T.check("zincir #$k (${chain.size} başlık, ${chain.sumOf { it.second * 8 }} bayt): el sıkışma + 3000 bayt yankı + FIN", sa != null && sa.flags == (F_SYN or F_ACK) && got.contentEquals(msg), "sa=${sa?.flags} got=${got.size}")
        }
        // her pakette farklı (bazen hiç) zincir: akış bütünlüğü
        run {
            val rnd = Random(1313)
            val c = f.cli(r, echo.port)
            c.wrap = { p -> v6WithExt(p, if (rnd.nextInt(3) == 0) emptyList<Pair<Int, Int>>() else EXT_OK[rnd.nextInt(EXT_OK.size)]) }
            c.connect()
            val msg = ByteArray(20_000) { (it * 11 + 3).toByte() }
            var o = 0
            while (o < msg.size) { val n = minOf(1000, msg.size - o); c.write(msg.copyOfRange(o, o + n)); o += n }
            val got = c.read(msg.size, 8000)
            T.check("her pakette farklı rastgele uzantı zinciri: 20 KB yankı bozulmadan", got.contentEquals(msg), "${got.size}")
            c.send(F_RST or F_ACK)
        }
        // UDP + geçerli zincir
        run {
            val cport = portCounter.incrementAndGet()
            var all = true
            for (chain in EXT_OK) {
                val d = ByteArray(300) { (it * 3).toByte() }
                val rep = v6UdpRound(f, r, cport, udpEcho.localPort, d, 2000) { p -> v6WithExt(p, chain) }
                if (rep == null || !rep.copyOfRange(48, rep.size).contentEquals(d)) all = false
            }
            T.check("UDP: tüm geçerli uzantı zincirleriyle yankı çalışır", all)
        }
        // geçersiz zincirler: SYN yanıtsız, akış açılmaz
        val bad: List<Pair<String, (ByteArray) -> ByteArray>> = listOf(
            "9 başlık (sınır 8)" to { p: ByteArray -> v6WithExt(p, List(9) { 60 to 1 }) },
            "parça başlığı (44)" to { p: ByteArray -> v6WithExt(p, listOf(44 to 1)) },
            "hop-by-hop + parça başlığı" to { p: ByteArray -> v6WithExt(p, listOf(0 to 1, 44 to 1)) },
            "kimlik doğrulama başlığı (51)" to { p: ByteArray -> v6WithExt(p, listOf(51 to 1)) },
            "ESP (50)" to { p: ByteArray -> v6WithExt(p, listOf(50 to 1)) },
            "bilinmeyen protokol (99)" to { p: ByteArray -> v6WithExt(p, listOf(99 to 1)) },
            "uzunluk alanı paketten büyük" to { p: ByteArray -> v6WithExt(p, listOf(0 to 1)).also { it[41] = 200.toByte() } },
            "uzantı başlığının ortasında kesik" to { p: ByteArray -> v6WithExt(p, listOf(0 to 1)).copyOf(44) },
            "uzantıdan sonra taşıma başlığı yok" to { p: ByteArray -> v6WithExt(p, listOf(0 to 1)).copyOf(48) },
            "yük uzunluğu 0" to { p: ByteArray -> p.also { Packets.put16(it, 4, 0) } },
        )
        for ((name, fn) in bad) {
            val st0 = r.gw.stats()
            val c = f.cli(r, echo.port)
            c.wrap = fn
            c.send(F_SYN, mss = 1460)
            val x = c.next(350)
            val st1 = r.gw.stats()
            T.check("geçersiz zincir ($name): SYN yanıtsız kalır, akış açılmaz", x == null && st1.opened == st0.opened && st1.connectFail == st0.connectFail, "yanıt=${x?.flags} açılan=${st1.opened - st0.opened}")
        }
        val dropUdp = v6UdpRound(f, r, portCounter.incrementAndGet(), udpEcho.localPort, "x".toByteArray(), 400) { p -> v6WithExt(p, List(9) { 60 to 1 }) }
        T.check("UDP: 9 başlıklı zincir düşer (cevap yok)", dropUdp == null)
        val ctl = f.cli(r, echo.port); ctl.connect(); ctl.write("kontrol".toByteArray())
        T.check("kontrol: saldırı dizisinden sonra normal akış çalışır", String(ctl.read(7, 3000)) == "kontrol")
        ctl.send(F_RST or F_ACK)
        T.check("uzantı testlerinde geçidin yazdığı ${wire.pkts.get()} paket RFC denetçisinden geçti", wire.bad.isEmpty() && wire.pkts.get() > 20, wire.bad.take(3).joinToString(" | "))
        T.check("uzantı testlerinde iç hata yok", r.gw.stats().internalErrors == 0L, "${r.gw.lastInternalError()}")
    } finally { udpEcho.close(); echo.close(); r.close() }
}

// ====================================================================================================== 5) uzunluk alanı yalanları

private fun v6LengthLies() {
    T.group("Sızma 13 / v4 ↔ v6 eşlik: IP uzunluk alanı yalanı (kısa iddia: artık baytlar yok sayılır; uzun iddia: eldeki bayt alınır)")
    val sigs = ArrayList<String>()
    for (f in V6_FAMS) {
        val r = GRig()
        val wire = V6Wire(r)
        val sink = Sink()
        try {
            val delta = AtomicInteger(0)
            val c = f.cli(r, sink.port)
            c.wrap = { p ->
                val d = delta.getAndSet(0)
                if (d != 0) { if (f.v6) Packets.put16(p, 4, Packets.u16(p, 4) + d) else { Packets.put16(p, 2, Packets.u16(p, 2) + d); v6Refix(p) } }
                p
            }
            c.connect()
            val d1 = ByteArray(40) { (it + 1).toByte() }
            delta.set(-10)
            c.write(d1)                                                     // iddia: 10 bayt eksik → sunucu 30 bayt alır, ack 30
            val got1 = waitUntil(2000) { sink.bytes().size >= 30 }
            Thread.sleep(150)
            val after1 = sink.bytes().size
            val ack = c.next(1500)
            val wantAck = c.seq - 10
            // eksik kalan 10 baytı doğru sıra numarasıyla yeniden gönder: akış tutarlı kalmalı
            c.send(F_ACK or F_PSH, d1.copyOfRange(30, 40), seqNo = c.seq - 10)
            val got2 = waitUntil(2000) { sink.bytes().size >= 40 }
            val whole = sink.bytes().contentEquals(d1)
            val d2 = ByteArray(25) { (it * 2).toByte() }
            delta.set(+7)
            c.write(d2)                                                     // iddia: 7 bayt fazla → eldeki 25 bayt alınır
            val got3 = waitUntil(2000) { sink.bytes().size >= 65 }
            Thread.sleep(100)
            val all = sink.bytes().contentEquals(d1 + d2)
            val sg = "${f.name}: kısa-iddia alınan=$after1 ack-doğru=${ack != null && ack.ack == wantAck} bütün=$whole uzun-iddia-tamam=$all"
            sigs.add("kısa=$after1 ack=${ack != null && ack.ack == wantAck} bütün=$whole uzun=$all")
            T.check("${f.name}: kısa uzunluk iddiasında yalnızca iddia edilen 30 bayt iletilir, ack buna göre", got1 && after1 == 30 && ack != null && ack.ack == wantAck, sg)
            T.check("${f.name}: kalan 10 bayt doğru sıra numarasıyla gelince akış bütün (40 bayt)", got2 && whole, sg)
            T.check("${f.name}: uzun uzunluk iddiasında eldeki baytlar alınır, akış bozulmaz", got3 && all, sg)
            c.send(F_RST or F_ACK)
            v6Clean(r, wire, f.v6, f.name)
        } finally { sink.close(); r.close() }
    }
    T.check("kısa/uzun uzunluk iddialarının sonucu iki ailede aynı", sigs.size == 2 && sigs[0] == sigs[1], "$sigs")
}

// ====================================================================================================== 6) DPI eşliği

private class V6Cap(val need: Int) {
    private val got = ByteArrayOutputStream()
    private val srv = Srv { s ->
        val i = s.getInputStream(); val o = s.getOutputStream(); val b = ByteArray(4096)
        s.soTimeout = 600
        var replied = false
        while (true) {
            val n = try { i.read(b) } catch (_: Exception) { -1 }
            if (n < 0) break
            val total = synchronized(got) { got.write(b, 0, n); got.size() }
            if (!replied && total >= need) { replied = true; o.write(V6_HELLO_REPLY); o.flush() }
        }
    }
    val port get() = srv.port
    fun bytes(): ByteArray = synchronized(got) { got.toByteArray() }
    fun close() = srv.close()
}

/** Ardışık TLS kayıtlarının yüklerini birleştirir (DPI kayıt bölmesi başlık ekler); kayıt dizisi bozuksa null. */
private fun v6TlsBody(b: ByteArray): ByteArray? {
    val o = ByteArrayOutputStream()
    var i = 0
    while (i + 5 <= b.size) {
        if (b[i].toInt() != 0x16) return null
        val len = Packets.u16(b, i + 3)
        if (i + 5 + len > b.size) return null
        o.write(b, i + 5, len); i += 5 + len
    }
    return if (i == b.size) o.toByteArray() else null
}

private fun v6DpiParity() {
    T.group("Sızma 13 / v4 ↔ v6 eşlik: ${Dpi.TLS_PLANS} DPI bölme yönteminin her biri aynı baytları üretir; sunucu özgün ClientHello'yu eksiksiz alır")
    val raw = Array(2) { arrayOfNulls<ByteArray>(Dpi.TLS_PLANS) }
    for ((fi, f) in V6_FAMS.withIndex()) {
        val r = GRig()
        r.gw.config.dpi = true
        val wire = V6Wire(r)
        try {
            for (plan in 0 until Dpi.TLS_PLANS) {
                val host = "sizma13-y$plan.example"
                val hello = testHello(host, 100 + plan * 17)
                r.gw.planner.worked(host, Dpi.TLS, plan)
                val cap = V6Cap(hello.size)
                try {
                    val c = f.cli(r, cap.port)
                    c.connect(); c.write(hello)
                    val rep = c.read(V6_HELLO_REPLY.size, 4000)
                    Thread.sleep(150)
                    val got = cap.bytes()
                    raw[fi][plan] = got
                    val body = v6TlsBody(got)
                    T.check("${f.name}: DPI yöntemi $plan — sunucu ClientHello'yu eksiksiz alır (kayıt gövdeleri birleşince özgün), cevap istemciye ulaşır",
                        rep.contentEquals(V6_HELLO_REPLY) && body != null && body.contentEquals(hello.copyOfRange(5, hello.size)), "cevap=${rep.size} alınan=${got.size} özgün=${hello.size}")
                    c.send(F_RST or F_ACK)
                } finally { cap.close() }
            }
            T.check("${f.name}: DPI akışlarında geçidin yazdığı ${wire.pkts.get()} paket RFC denetçisinden geçti", wire.bad.isEmpty() && wire.pkts.get() > 20, wire.bad.take(3).joinToString(" | "))
            T.check("${f.name}: DPI akışlarında iç hata yok", r.gw.stats().internalErrors == 0L, "${r.gw.lastInternalError()}")
        } finally { r.close() }
    }
    val diff = (0 until Dpi.TLS_PLANS).filter { val a = raw[0][it]; val b = raw[1][it]; a == null || b == null || !a.contentEquals(b) }
    T.check("her DPI yönteminde sunucunun gördüğü bayt dizisi v4 ve v6'da birebir aynı", diff.isEmpty(), "farklı yöntemler=$diff ${diff.map { "${raw[0][it]?.size}/${raw[1][it]?.size}" }}")
}

// ====================================================================================================== 7) süzgeç eşliği

/** Engelli ad: [parts] sırayla yazılır; RST gelirse ve sunucu hiç bayt almadıysa true. */
private fun v6Blocked(f: V6Fam, r: GRig, sink: Sink, parts: List<ByteArray>): Boolean {
    val before = sink.bytes().size
    val c = f.cli(r, sink.port)
    if (c.connect() == null) return true
    for (d in parts) { var o = 0; while (o < d.size) { val n = minOf(1400, d.size - o); c.write(d.copyOfRange(o, o + n)); o += n } }
    var rst = false
    val end = System.currentTimeMillis() + 3000
    while (System.currentTimeMillis() < end) {
        val x = c.next(end - System.currentTimeMillis()) ?: break
        if (x.flags and F_RST != 0) { rst = true; break }
    }
    Thread.sleep(80)
    return rst && sink.bytes().size == before
}

private fun v6Passes(f: V6Fam, r: GRig, sink: Sink, d: ByteArray): Boolean {
    val before = sink.bytes().size
    val c = f.cli(r, sink.port)
    if (c.connect() == null) return false
    c.write(d)
    return waitUntil(2500) { sink.bytes().size >= before + d.size }
}

private fun v6FilterParity() {
    T.group("Sızma 13 / v4 ↔ v6 eşlik: engelli ad (TLS SNI ve HTTP Host) ilk uçuş her noktada bölünse de engellenir; benzer izinli adlar geçer")
    for (f in V6_FAMS) {
        val r = GRig()
        r.gw.config.ads = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example"))
        val wire = V6Wire(r)
        val sink = Sink()
        try {
            val hello = testHello("reklam.example")
            val at = v6IndexOf(hello, "reklam.example".toByteArray())
            val cuts = (listOf(1, 2, 3, 4, 5, 6, 9, 20, 43) + (at - 2..at + 16) + listOf(hello.size - 2, hello.size - 1)).filter { it in 1 until hello.size }.distinct()
            val leaked = ArrayList<Int>()
            for (k in cuts) if (!v6Blocked(f, r, sink, listOf(hello.copyOfRange(0, k), hello.copyOfRange(k, hello.size)))) leaked.add(k)
            T.check("${f.name}: engelli SNI'li ClientHello ${cuts.size} farklı noktada ikiye bölününce de engellenir", leaked.isEmpty(), "sızan kesimler=$leaked")
            T.check("${f.name}: bütün ClientHello (engelli SNI) engellenir", v6Blocked(f, r, sink, listOf(hello)))
            val req = "GET /x HTTP/1.1\r\nHost: reklam.example\r\nAccept: */*\r\n\r\n".toByteArray(Charsets.ISO_8859_1)
            val hAt = v6IndexOf(req, "reklam".toByteArray())
            val hcuts = (listOf(1, 3, 4, 9, 16, 20) + (hAt - 3..hAt + 16) + listOf(req.size - 4, req.size - 2)).filter { it in 1 until req.size }.distinct()
            val hleak = ArrayList<Int>()
            for (k in hcuts) if (!v6Blocked(f, r, sink, listOf(req.copyOfRange(0, k), req.copyOfRange(k, req.size)))) hleak.add(k)
            T.check("${f.name}: engelli Host'lu HTTP isteği ${hcuts.size} farklı noktada bölününce de engellenir", hleak.isEmpty(), "sızan kesimler=$hleak")
            T.check("${f.name}: kontrol — izinli ad (guvenli.example.org) geçer", v6Passes(f, r, sink, testHello("guvenli.example.org")))
            T.check("${f.name}: kontrol — benzer ad (xreklam.example) engellenmez", v6Passes(f, r, sink, testHello("xreklam.example")))
            T.check("${f.name}: kontrol — benzer ad (reklam.example.org) engellenmez", v6Passes(f, r, sink, testHello("reklam.example.org")))
            T.check("${f.name}: süzgeç akışlarında geçidin yazdığı ${wire.pkts.get()} paket RFC denetçisinden geçti", wire.bad.isEmpty() && wire.pkts.get() > 20, wire.bad.take(3).joinToString(" | "))
            T.check("${f.name}: süzgeç akışlarında iç hata yok", r.gw.stats().internalErrors == 0L, "${r.gw.lastInternalError()}")
        } finally { sink.close(); r.close() }
    }
}

// ====================================================================================================== 8) kaos konuşması

private fun v6ChaosChunk(rnd: Random, f: V6Fam): ByteArray {
    val n = when (rnd.nextInt(10)) {
        0, 1, 2, 3 -> 1 + rnd.nextInt(60)
        4, 5, 6 -> 61 + rnd.nextInt(1340)
        7 -> intArrayOf(f.mss - 1, f.mss, f.mss + 1, 1400, 1459, 1460, 1461)[rnd.nextInt(7)]
        else -> 1 + rnd.nextInt(10)
    }
    return ByteArray(n).also { rnd.nextBytes(it); if (it[0].toInt() == 0x16) it[0] = 0x17 }
}

/** Rastgele bir TCP konuşması; yankı sunucusu bütünlük kâhinidir. Sorun varsa açıklama, yoksa null döner. */
private fun v6Chaos(f: V6Fam, seed: Long, r: GRig, steps: Int): String? {
    val rnd = Random(seed)
    val sink = Sink(echo = true)
    try {
        val c = f.cli(r, sink.port)
        val sa = c.connect() ?: return "SYN+ACK gelmedi"
        if (sa.flags != (F_SYN or F_ACK)) return "SYN+ACK yerine bayrak ${sa.flags}"
        val sent = ByteArrayOutputStream()
        val recv = ByteArrayOutputStream()
        var last = ByteArray(0)
        var lastSeq = 0
        var rst = false
        fun pump(ms: Long) {
            val end = System.currentTimeMillis() + ms
            while (!rst) {
                val left = end - System.currentTimeMillis()
                if (left <= 0) break
                val s = c.next(left) ?: break
                if (s.flags and F_RST != 0) { rst = true; break }
                if (s.data.isNotEmpty()) {
                    val skip = c.rcv - s.seq
                    if (skip >= 0 && skip < s.data.size) { recv.write(s.data, skip, s.data.size - skip); c.rcv += s.data.size - skip }
                    c.send(F_ACK)
                }
            }
        }
        for (i in 0 until steps) {
            if (rst) return "beklenmedik RST (adım $i)"
            when (rnd.nextInt(12)) {
                0, 1, 2, 3 -> { val d = v6ChaosChunk(rnd, f); lastSeq = c.seq; c.write(d); sent.write(d); last = d; pump(2) }
                4 -> {                                       // sıra dışı: önce boşluklu ikinci parça (yutulur), sonra birincisi, sonra ikincisi yeniden
                    val a = v6ChaosChunk(rnd, f); val b = v6ChaosChunk(rnd, f)
                    c.send(F_ACK or F_PSH, b, seqNo = c.seq + a.size)
                    c.write(a); sent.write(a)
                    lastSeq = c.seq; c.write(b); sent.write(b); last = b
                    pump(3)
                }
                5 -> if (last.isNotEmpty()) { c.send(F_ACK or F_PSH, last, seqNo = lastSeq); pump(2) }      // eski kopya: yok sayılır
                6 -> if (last.isNotEmpty()) {                // örtüşme: son parçanın sonundan k bayt + yeni veri
                    val k = 1 + rnd.nextInt(last.size); val nd = v6ChaosChunk(rnd, f)
                    c.send(F_ACK or F_PSH, last.copyOfRange(last.size - k, last.size) + nd, seqNo = c.seq - k)
                    lastSeq = c.seq; c.seq += nd.size; sent.write(nd); last = nd; pump(2)
                }
                7 -> { repeat(3 + rnd.nextInt(3)) { c.send(F_ACK) }; pump(3) }                              // yinelenen ACK'ler
                8 -> { c.send(F_ACK or F_PSH, byteArrayOf(rnd.nextInt().toByte()), seqNo = c.seq - 1); pump(2) }   // canlılık yoklaması
                9 -> { c.win = 0; c.send(F_ACK); pump(4); c.win = 65535; c.send(F_ACK); pump(2) }          // sıfır pencere dönemi
                10 -> Thread.sleep(rnd.nextInt(4).toLong())
                else -> { c.win = intArrayOf(536, 1460, 4096, 65535)[rnd.nextInt(4)]; c.send(F_ACK); pump(1) }
            }
        }
        c.win = 65535; c.send(F_ACK)
        val total = sent.size()
        val end = System.currentTimeMillis() + 10_000
        while (recv.size() < total && !rst && System.currentTimeMillis() < end) pump(30)
        if (rst) return "beklenmedik RST"
        val a = sent.toByteArray(); val b = recv.toByteArray()
        if (b.size != a.size) return "yankı boyu ${b.size} ≠ gönderilen ${a.size}"
        if (!a.contentEquals(b)) return "yankı içeriği bozuk (ilk fark ${a.indices.first { a[it] != b[it] }})"
        if (!waitUntil(3000) { sink.bytes().size >= a.size }) return "sunucu ${sink.bytes().size}/${a.size} bayt aldı"
        val sv = sink.bytes()
        if (sv.size != a.size || !sv.contentEquals(a)) return "sunucunun aldığı bayt dizisi gönderilenden farklı (${sv.size}/${a.size}; yinelenen/örtüşen veri sızdı mı?)"
        c.send(F_RST or F_ACK)
        return null
    } finally { sink.close() }
}

private fun v6ChaosTests() {
    val convs = 6 + 2 * DEEP_X
    T.group("Sızma 13 / v4 ↔ v6: $convs rastgele TCP konuşması (sıra dışı, yinelenen, örtüşen, canlılık yoklaması, sıfır pencere) — yankı bütünlüğü ve gerçek veri akışı her iki ailede aynı tohumlarla")
    for (f in V6_FAMS) {
        val r = GRig()
        val wire = V6Wire(r)
        try {
            val fails = ArrayList<String>()
            for (k in 0 until convs) {
                val why = v6Chaos(f, 0xC4A05L + k * 7919L, r, 50 + (k % 4) * 15)
                if (why != null) fails.add("#$k: $why")
            }
            T.check("${f.name}: $convs kaos konuşmasının hepsi bozulmadan tamamlanır", fails.isEmpty(), fails.take(3).joinToString(" | "))
            v6Clean(r, wire, f.v6, f.name)
            r.gw.networkReset()
            T.check("${f.name}: kaos sonrası ağ sıfırlamayla tablo ve bellek sıfırlanır", waitUntil(10_000) { r.gw.stats().tcpFlows == 0 } && r.gw.mem.used == 0, "akış=${r.gw.stats().tcpFlows} bellek=${r.gw.mem.used}")
        } finally { r.close() }
    }
}
