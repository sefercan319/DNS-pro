package app.dnshizli.platform

import android.content.Context
import app.dnshizli.core.Cosmetic
import app.dnshizli.core.MitmCa
import java.io.File

/** Tarayıcı kipinin yerel CA'sı: uygulamanın özel klasöründe (yedeklenmez) tutulur; yoksa, bozuksa ya da kural alanları değiştiyse (Ad Kısıtı eşleşmez) yeniden üretilir; yeni sertifika yeniden kurulmalıdır. */
object MitmStore {
    private var cached: MitmCa? = null

    @Synchronized fun get(ctx: Context): MitmCa {
        cached?.let { return it }
        val dir = File(ctx.filesDir, "mitm").also { it.mkdirs() }
        val kf = File(dir, "ca.key")
        val cf = File(dir, "ca.crt")
        val xf = File(dir, "inter.crt")
        val domains = Cosmetic.BUILTIN.domains()
        val loaded = try { if (kf.exists() && cf.exists() && xf.exists()) MitmCa.load(kf.readBytes(), cf.readBytes(), xf.readBytes(), domains = domains) else null } catch (_: Exception) { null }
        val ca = loaded ?: MitmCa.generate(domains).also {
            try { cf.writeBytes(it.certDer()); xf.writeBytes(it.interDer()); kf.writeBytes(it.keyBytes()) } catch (_: Exception) { /* yazılamadı: bu oturumda bellekte kalır */ }
        }
        cached = ca
        return ca
    }
}
