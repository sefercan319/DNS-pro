package app.dnshizli.core

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicLongArray
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLPeerUnverifiedException
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * Şifreli DNS hedefi: bağlanılacak IP:port, sertifikada beklenen ad (SNI) ve DoH için yol.
 * [alt]: aynı sunucunun öbür IP ailesindeki adresi (IPv4 ↔ IPv6). Varsa bağlantı önce [addr]'a, olmazsa [alt]'a kurulur;
 * hangisinin çalıştığı ağ değişene kadar hatırlanır. Sertifika her iki adreste aynı [host] adına göre doğrulanır.
 */
class SecureTarget(val addr: InetSocketAddress, val host: String, val path: String = "/dns-query", val alt: InetSocketAddress? = null)

/**
 * Şifreli DNS yönlendiricisi: DNS-over-TLS (RFC 7858, port 853) ya da DNS-over-HTTPS (RFC 8484, HTTP/1.1 POST, port 443).
 * Android'e bağlı değildir; JVM testlerinde yerel bir TLS sunucusuyla uçtan uca sınanır.
 *
 * Tasarım ("şeritler"):
 *  - Sorgular bir kuyruğa girer. Her şerit = 1 iş parçacığı + 1 TLS bağlantısı; sırayla soru gönderir, cevabı okur.
 *  - Şeritler iş varken açılır (en çok [maxLanes]); kuyrukta [BURST_AFTER_MS]'den uzun bekleyen iş varsa (ör. yavaş
 *    cevaplanan adlar şeritleri meşgul ediyorsa) geçici olarak [burstLanes]'e kadar ek şerit açılır.
 *    [idleMs] boyunca iş gelmezse şerit bağlantısını kapatıp biter: boştayken hiç iş parçacığı, soket ya da zamanlayıcı kalmaz.
 *  - Aynı anda bekleyen ÖZDEŞ sorgular tek sorguya birleşir (istemcinin yeniden denemeleri şerit tüketmez).
 *  - TLS bağlantısı sunucunun gerçek IP'sine açılır (ad çözümlemesi gerekmez, tünel döngüsü olmaz);
 *    sertifika, katalogdaki ada ([SecureTarget.host]) göre doğrulanır. Doğrulanamayan sunucuya sorgu gönderilmez.
 *  - Cevabın kimliği (DoT) ve soru bölümü sorguyla aynı olmalıdır.
 *  - Bayat bağlantı (sunucu boşta kapatmış) fark edilince sessizce yenisi açılır; bu sunucu hatası sayılmaz.
 *  - Sunucu yakın zamanda başka sorulara cevap verdiyse tek bir sorunun zaman aşımı "yavaş ad" sayılır, sunucu hatası
 *    sayılmaz. Birincil hedefe bağlantılar üst üste gerçekten başarısız olursa yedeğe geçilir; ağ değişince birincile dönülür.
 *  - Büyük cevaplar IP parçalarıyla tünele yazılır (bkz. [Packets.writeReply]).
 */
class SecureForwarder(
    override val proto: Proto,
    private val targets: List<SecureTarget>,
    private val writeToTun: (ByteArray, Int, Int) -> Unit,
    /** Tünel dışında tutulacak (VpnService.protect) ve bağlanmış ham soket üretir. */
    private val openSocket: (InetSocketAddress, Int) -> Socket = { a, t -> Socket().also { it.connect(a, t) } },
    tls: SSLSocketFactory = SSLSocketFactory.getDefault() as SSLSocketFactory,
    /**
     * Ağ değiştiğinde TLS oturum önbelleği olmayan yeni bir fabrika üretir. Oturum biletleri sunucunun bizi iki ağ arasında
     * (Wi-Fi ↔ mobil) tanımasına yarardı; bu yüzden ağ değişince eski biletler atılır. null: fabrika değişmez (testler).
     */
    private val freshTls: (() -> SSLSocketFactory)? = null,
    private val verifier: HostnameVerifier = HttpsURLConnection.getDefaultHostnameVerifier(),
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000 },
    private val timeoutMs: Int = 4000,
    private val connectTimeoutMs: Int = 3000,
    private val giveUpMs: Long = 6000,
    private val idleMs: Long = 20_000,
    private val maxLanes: Int = 4,
    private val burstLanes: Int = maxOf(maxLanes, 12),
    cacheEntries: Int = 256,
    private val threadFactory: (Runnable, String) -> Thread =
        { r, name -> Thread(r, name).apply { isDaemon = true } },
    private val log: (String) -> Unit = {},
    /** QUIC (DoQ, DoH3) için tünel dışı UDP yuvası: bağlanmış ve korunmuş olmalı. */
    private val openUdp: (InetSocketAddress) -> java.net.DatagramSocket = { a -> java.net.DatagramSocket().also { it.connect(a) } },
    /** QUIC sertifika zinciri doğrulayıcısı (testler kendi sertifikasını verir). */
    private val quicTrust: javax.net.ssl.X509TrustManager? = null,
    /** [Proto.ODOH] için motor; [targets] bu durumda rölelerdir ([OdohEngine.relayTargets]). */
    private val odoh: OdohEngine? = null,
) : Forwarder {

    init {
        require(proto == Proto.DOT || proto == Proto.DOH || proto == Proto.ODOH || proto == Proto.DOQ || proto == Proto.DOH3) { "yalnızca DoT, DoH, DoQ, DoH3 ya da ODoH" }
        require((proto == Proto.ODOH) == (odoh != null)) { "ODoH için motor gerekli (yalnızca ODoH için)" }
        require(targets.isNotEmpty()) { "en az bir hedef gerekli" }
        if (odoh != null) require(targets.size == odoh.relays.size) { "röle sayısı uyuşmuyor" }
    }

    private class Job(val key: String, val query: ByteArray, val qEnd: Int, val addedOpt: Boolean, val at: Long, first: Waiter?) {
        val waiters = ArrayList<Waiter>(1).also { if (first != null) it.add(first) }   // [this] kilidiyle korunur
        var done = false                                          // [this] kilidiyle korunur
    }

    /**
     * İş kuyruğu: alana göre gruplanır; yavaş çözülen bir alan şeritlerin hepsini tutamaz ([ZoneQueue]). Şüphe yokken sıra eskisi gibi FIFO'dur.
     * Kanıt yalnızca sunucu şu an sağlıklıyken sayılır: sunucu hiç cevap vermiyorsa herkes yavaştır, kimse cezalandırılmaz.
     */
    private val zq = ZoneQueue<Job>(MAX_QUEUE, ZONE_BACKLOG, maxOf(1, maxLanes - 1), nowMs, { suspectAfter() })
    /**
     * Başarılı soru-cevapların (bağlantı kurulumu ve sıra beklemesi HARİÇ) süresinin üstel ortalaması (ms; 0 = henüz örnek yok).
     * Alan şüphesinin eşiği bu hattın olağan hızına göre ayarlanır: yavaş mobil hatta sıradan bir sorgu şüphe doğurmaz.
     */
    @Volatile private var exchangeEwma = 0L
    private val byKey = ConcurrentHashMap<String, Job>()
    private val cache = DnsCache(cacheEntries, nowMs)
    private val parsed = ParsedQuery()
    private val lanes = AtomicInteger()
    private val idleLanes = AtomicInteger()
    private val laneSeq = AtomicInteger()
    private val connecting = AtomicInteger()
    /**
     * Şeritlerin tek bağlantıyı paylaştığı protokoller: DoQ, DoH3 (QUIC akışları) ve DoH (HTTP/2 akışları; sunucu HTTP/2 seçmişse).
     * HTTP/1.1'de bağlantı tek seferde tek soru taşır, o yüzden her şerit kendisininkini tutar. ODoH kendi yolunu kullanır.
     */
    private val muxProto = odoh == null && (proto == Proto.DOQ || proto == Proto.DOH3 || proto == Proto.DOH)
    private val sharedLock = Any()
    @Volatile private var sharedConn: Conn? = null
    private val conns: MutableSet<Conn> = ConcurrentHashMap.newKeySet()
    private val laneThreads: MutableSet<Thread> = ConcurrentHashMap.newKeySet()
    private val lastOk = AtomicLongArray(targets.size).also { for (i in targets.indices) it.set(i, Long.MIN_VALUE / 2) }
    @Volatile private var tlsFactory: SSLSocketFactory = tls
    /** Hedef başına: önce öbür aile ([SecureTarget.alt]) mi denenecek? Ağ değişince sıfırlanır. */
    private val altFirst = java.util.concurrent.atomic.AtomicIntegerArray(targets.size)
    private val tlsFailures = AtomicLong()
    /** [tlsFailures]'un alt kümesi: sertifika süresi dolmuş/henüz geçerli değil (çoğunlukla cihaz saati yanlış; saldırı belirtisi değil). */
    private val clockFailures = AtomicLong()
    @Volatile private var closed = false
    @Volatile private var started = false
    @Volatile private var netGen = 0
    private val connEst = RttEstimator()      // TCP bağlantı süresi (ağ değişince sıfırlanır): ilk IP ailesine tanınan süreyi belirler
    private val primaryRef = AtomicInteger()
    private var primaryIdx: Int
        get() = primaryRef.get()
        set(v) = primaryRef.set(v)
    private val streak = AtomicInteger()

    // yalnızca onPacket (tünel) iş parçacığı
    private val tunBuf = ByteArray(Packets.HDR6 + MAX_MSG)
    private val tunScratch = ByteArray(Packets.MTU)

    private val queries = AtomicLong()
    private val cacheHits = AtomicLong()
    private val forwarded = AtomicLong()
    private val answered = AtomicLong()
    private val retries = AtomicLong()
    private val timeouts = AtomicLong()
    private val staleServed = AtomicLong()
    /** Son hata ve son başarı anı: hata daha yeniyse sunucu şu an sorunlu sayılır ([upstreamTrouble]). */
    @Volatile private var lastFailAt = Long.MIN_VALUE / 2
    @Volatile private var lastAnyOk = Long.MIN_VALUE / 2
    private val dropped = AtomicLong()
    private val resets = AtomicLong()
    private val latencySum = AtomicLong()
    private val failovers = AtomicLong()
    private val blocked = AtomicLong()
    private val bytesUp = AtomicLong()
    private val bytesDown = AtomicLong()
    private val merged = AtomicLong()
    private val rejected = AtomicLong()
    private val ring = LatencyRing()

    override fun start() {
        started = true
        // ODoH: en iyi yolun hedef anahtarı ilk sorgudan önce arka planda alınır.
        odoh?.let { e ->
            try { threadFactory(Runnable { e.warm() }, "odoh-warm").start() } catch (_: Throwable) {}
        }
    }

    override fun latencies(out: IntArray): Int = ring.copyTo(out)

    override fun stats() = Stats(
        queries.get(), cacheHits.get(), forwarded.get(), answered.get(), retries.get(),
        timeouts.get(), dropped.get(), resets.get(), latencySum.get(), failovers.get(), primaryIdx != 0, blocked.get(),
        bytesUp.get(), bytesDown.get(), merged.get(), rejected.get(), tlsFailures.get(), staleServed.get(),
        clockFailures = clockFailures.get(),
    )

    internal fun laneCount() = lanes.get()
    internal fun openConnections() = conns.size
    /** Kuyrukta bekleyen iş sayısı, izlenen alan sayısı ve bir alanın şüpheli olup olmadığı (testler/tanılama). */
    internal fun queuedJobs() = zq.size()
    internal fun trackedZones() = zq.zoneCount()
    internal fun zoneSuspect(zone: String) = zq.isSuspect(zone)

    override fun clearCache() = cache.clear()

    override fun resetNetwork(reason: String) {
        if (closed) return
        netGen++
        noSni.clear()
        connEst.reset()
        primaryIdx = 0
        streak.set(0)
        cache.clear()
        for (i in targets.indices) altFirst.set(i, 0)
        freshTls?.let { f -> try { tlsFactory = f() } catch (_: Exception) {} }
        for (i in targets.indices) lastOk.set(i, Long.MIN_VALUE / 2)
        lastFailAt = Long.MIN_VALUE / 2; lastAnyOk = Long.MIN_VALUE / 2
        exchangeEwma = 0
        odoh?.resetNetwork()
        // Açık bağlantıları kapat: eski ağdaki okumada bekleyen şerit hemen uyanıp yeni bağlantıyla yeniden dener.
        for (c in conns.toTypedArray()) c.close()
        resets.incrementAndGet()
        log("şifreli bağlantılar yenilendi ($reason)")
    }

    override fun onPacket(p: ByteArray, len: Int) {
        if (closed) return
        val q = parsed
        if (!q.parse(p, len, MAX_UDP_QUERY)) return
        queries.incrementAndGet()
        val key = String(p, q.dnsOff + 2, q.dnsLen - 2, Charsets.ISO_8859_1)

        val n = cache.get(key, q.clientId, tunBuf, Packets.HDR)
        if (n > 0) {
            cacheHits.incrementAndGet()
            if (Dns.isBlocked(tunBuf, Packets.HDR, n)) blocked.incrementAndGet()
            q.writeCached(tunBuf, tunScratch, n, writeToTun)
            // Sık sorulan ve süresi dolmak üzere olan kayıt: istemci eski cevabı hemen aldı, yenisi arka planda çekilir.
            if (cache.prefetchDue(key)) prefetchJob(p, q, key)
            return
        }

        // Sunucu şu an sorunluysa (son hata, son başarıdan yeni) süresi dolmuş olumlu cevap hemen verilir (RFC 8767); sorgu yine de
        // ağa gider ve dönünce önbelleği tazeler. İstemci boşuna zaman aşımını beklemez.
        var servedStale = false
        if (upstreamTrouble()) {
            val sn = cache.getStale(key, q.clientId, tunBuf, Packets.HDR)
            if (sn > 0) {
                staleServed.incrementAndGet()
                q.writeCached(tunBuf, tunScratch, sn, writeToTun)
                servedStale = true
            }
        }

        val waiter = q.waiter()
        val same = byKey[key]
        if (same != null) {
            synchronized(same) {
                if (servedStale) return                      // aynı soru zaten yolda: önbelleği o tazeler
                if (!same.done && same.waiters.size < MAX_WAITERS && nowMs() - same.at <= giveUpMs) {         // sırada giveUp'tan uzun bekleyen iş vazgeçilecek: yeni istemci ona eklenmez, kendi işini açar
                    same.waiters.add(waiter)
                    merged.incrementAndGet()
                    return
                }
            }
        }

        // Gizlilik: istemciye ait EDNS seçenekleri atılır, "alt ağı iletme" işareti ve 128 baytlık dolgu eklenir.
        val san = Dns.sanitizeQuery(p, q.dnsOff, q.dnsLen, pad = true, absentPayload = 1232)
        if (san == null) { dropped.incrementAndGet(); return }
        val query = san.query
        val job = Job(key, query, Dns.questionEnd(query, 0, query.size), san.addedOpt, nowMs(), waiter)
        if (servedStale) job.waiters.clear()                  // istemci cevabını aldı; bu sorgu yalnızca önbelleği tazeler
        // Boşta bekleyen şerit sayısı kuyruğa koymadan ÖNCE okunur: koyduktan sonra okunsa, işi hemen kapan
        // boştaki şerit sayacı sıfırlamış olur ve gereksiz yeni bir şerit (TLS bağlantısı) açılırdı.
        val idleBefore = idleLanes.get()
        byKey[key] = job
        if (!zq.offer(ZoneKey.of(query, 0, query.size), job, job.at)) { byKey.remove(key, job); dropped.incrementAndGet(); return }
        forwarded.incrementAndGet()
        if (zq.ready() > idleBefore || lanes.get() == 0) ensureLane(force = true)
        maybeBurst()
    }

    /** Ön yenileme: istemcisiz bir iş kuyruğa girer; cevap önbelleği tazeler. Yoğunlukta ya da zaten yolda ise atlanır. */
    private fun prefetchJob(p: ByteArray, q: ParsedQuery, key: String) {
        if (zq.size() >= MAX_QUEUE / 2 || byKey.containsKey(key)) return
        val san = Dns.sanitizeQuery(p, q.dnsOff, q.dnsLen, pad = true, absentPayload = 1232) ?: return
        val query = san.query
        val job = Job(key, query, Dns.questionEnd(query, 0, query.size), san.addedOpt, nowMs(), null)
        val idleBefore = idleLanes.get()
        byKey[key] = job
        if (!zq.offer(ZoneKey.of(query, 0, query.size), job, job.at)) { byKey.remove(key, job); return }
        if (zq.ready() > idleBefore || lanes.get() == 0) ensureLane(force = true)
    }

    /**
     * Verilebilir bir iş çok bekliyorsa ve şeritlerin hiçbiri bağlantı kurmuyorsa (yani hepsi cevap bekliyor:
     * yavaş çözülen adlarla meşguller) geçici bir ek şerit açar. Bağlantı kuran şerit varsa beklemek yeterlidir.
     * Şüpheli (yavaş) bir alan şerit tutarken başka bir alanın işi [EARLY_BURST_MS]'den uzun beklediyse daha da erken açılır;
     * sınırı dolmuş şüpheli alanın kendi bekleyenleri ek şerit açtırmaz ([ZoneQueue.burstDue]).
     */
    private fun maybeBurst() {
        if (connecting.get() > 0) return
        if (zq.burstDue(BURST_AFTER_MS, maxOf(EARLY_BURST_MS, exchangeEwma))) ensureLane(force = true, burst = true)
    }

    /** Boşta şerit yoksa (ya da [force]) ve sınır aşılmadıysa yeni şerit açar. */
    private fun ensureLane(force: Boolean = false, burst: Boolean = false) {
        if (closed || !started) return
        if (!force && idleLanes.get() > 0) return
        val cap = if (burst) burstLanes else maxLanes
        while (true) {
            val n = lanes.get()
            if (n >= cap) return
            if (lanes.compareAndSet(n, n + 1)) break
        }
        val t = threadFactory(Runnable { laneLoop() }, "dns-lane-" + laneSeq.incrementAndGet())
        laneThreads.add(t)
        try {
            t.start()
        } catch (e: Throwable) {
            laneThreads.remove(t)
            lanes.decrementAndGet()
        }
    }

    private fun markDone(job: Job) {
        synchronized(job) { job.done = true }
        byKey.remove(job.key, job)
    }

    /** Hedef son [HEALTH_MS] içinde başka bir soruya cevap verdi mi? */
    private fun healthy(target: Int): Boolean = nowMs() - lastOk.get(target) < HEALTH_MS

    /** Hedeflerden biri sağlıklı mı? (Alan şüphesi için kanıt: sunucu başka işlere cevap veriyorsa yavaşlık o alana özgüdür.) */
    private fun anyHealthy(): Boolean {
        for (i in targets.indices) if (healthy(i)) return true
        return false
    }

    /**
     * Çalışan bir iş bu süreden uzun sürerse alanı şüpheli sayılır ([ZoneQueue]). Sunucu hiç cevap vermiyorsa kanıt yoktur
     * ([Long.MAX_VALUE]): herkes yavaştır, kimse cezalandırılmaz. Eşik olağan soru-cevap süresinin 3 katı (en az [ZoneQueue.SUSPECT_MS]).
     */
    private fun suspectAfter(): Long {
        if (!anyHealthy()) return Long.MAX_VALUE
        return (3 * exchangeEwma).coerceIn(ZoneQueue.SUSPECT_MS, SUSPECT_MAX_MS)
    }

    private fun noteExchange(ms: Long) {
        val e = exchangeEwma
        exchangeEwma = if (e == 0L) maxOf(1L, ms) else maxOf(1L, e + (ms - e) / 8)
    }

    // ------------------------------------------------------------------ şerit

    private fun laneLoop() {
        val buf = ByteArray(Packets.HDR6 + MAX_MSG)
        val scratch = ByteArray(Packets.MTU)
        var conn: Conn? = null
        var muxHeld: Conn? = null          // paylaşılan QUIC bağlantısı: bu denemede kullanılan (bırakılana kadar)
        var idleMarked = false
        try {
            while (!closed) {
                if (!idleMarked) idleLanes.incrementAndGet()
                idleMarked = false
                val tk = try {
                    zq.poll(idleMs)
                } catch (_: InterruptedException) {
                    null
                } finally {
                    idleLanes.decrementAndGet()
                }
                if (tk == null) {
                    // Boşta kaldı: kuyruğa bu arada iş düştüyse devam et, yoksa bitir.
                    if (zq.isEmpty() || closed) break else continue
                }
                val job = tk.job
                var slowZone = false               // iş sunucu sağlıklıyken zaman aşımına uğradı: alan bir süre şüpheli sayılır
                try {
                    maybeBurst()
                    if (nowMs() - job.at > giveUpMs) { timeouts.incrementAndGet(); ring.add(LatencyRing.TIMEOUT); markDone(job); continue }

                    var replyLen = -1
                    var attempt = 0
                    var avoid = -1                     // son denemede başarısız olan hedef: sıradaki deneme diğerine gider
                    var avoidMask = 0L                 // ODoH: bu sorguda başarısız olan yolların maskesi
                    var keyRejects = 0                 // ODoH: bu sorguda hedefin anahtarı kaç kez reddetti
                    while (attempt < 3 && !closed && nowMs() - job.at <= giveUpMs) {
                        attempt++
                        muxHeld?.let { releaseShared(it) }; muxHeld = null
                        var c = conn
                        if (c != null && (c.dead || c.gen != netGen || (c.quic != null && (!c.quic.usable || !c.quic.canOpenBidi())))) { c.close(); c = null; conn = null }      // kopmuş/bayat ya da akış sınırı dolmuş QUIC bağlantısı yeniden kullanılmaz (boşuna bir deneme ve sunucu hatası sayılmasın)
                        var pathIdx = -1
                        var idx: Int
                        if (odoh != null) {
                            // ODoH: yol (röle + hedef) her sorguda tahtadan seçilir; bağlantı başka bir röleye aitse yenisi açılır.
                            pathIdx = odoh.choose(avoidMask)
                            idx = odoh.relayOf(pathIdx)
                            if (c != null && c.target != idx) { c.close(); c = null; conn = null }
                        } else {
                            idx = c?.target ?: (if (avoid >= 0 && avoid == primaryIdx && targets.size > 1) (avoid + 1) % targets.size else primaryIdx)
                        }
                        var fresh = c == null
                        var exchanging = false
                        try {
                            if (c == null) {
                                connecting.incrementAndGet()
                                try { c = if (muxProto) sharedAcquire(idx) else open(idx) } finally { connecting.decrementAndGet() }
                                if (c.shared) muxHeld = c else conn = c
                                fresh = !c.used
                            }
                            exchanging = true
                            zq.started(tk)
                            val ex0 = nowMs()
                            replyLen = exchange(c, job, buf, Packets.HDR, pathIdx)
                            noteExchange(nowMs() - ex0)
                            noteSuccess(c.target)
                            c.used = true
                            break
                        } catch (e: RuntimeException) {
                            // Beklenmeyen bir hata (ör. bozuk cevap) şeridi öldürmesin: bağlantıyı bırak, bu soruyu düşür.
                            dropAttempt(c)
                            conn = null
                            log("beklenmeyen şifreli DNS hatası: ${e.javaClass.simpleName}")
                            break
                        } catch (e: IOException) {
                            // "Bayat bağlantı" yalnızca: daha önce çalışmış bağlantı, İLK denemede, BAĞLANTININ KOPTUĞUNU gösteren hatayla (EOF/sıfırlama/kapanmış) başarısız olduysa.
                            // Zaman aşımı, HTTP 5xx ya da tek akış hatası gerçek sunucu/hat arızasıdır; sayılmazsa yedek sunucuya geçiş ve bayat önbellek hiç devreye girmezdi.
                            val wasStale = e !is OdohException && c != null && ((!fresh && c.used && attempt == 1 && connectionLost(c, e)) || c.gen != netGen)   // ağ değişince kapanan bağlantı sunucu hatası sayılmaz
                            // ODoH'ta anahtar reddi ve yapılandırma alım hatası bağlantıyı bozmaz (cevap eksiksiz okundu / hiç gönderilmedi).
                            val keep = e is OdohException && (e.kind == OdohError.KEY_REJECTED || e.kind == OdohError.CONFIG_FETCH) && c != null && !c.dead
                            if (!keep) { dropAttempt(c); conn = null }
                            if (closed) break
                            if (odoh != null && pathIdx >= 0 && !wasStale) {
                                if (e is OdohException && e.kind == OdohError.KEY_REJECTED && ++keyRejects < 2) {
                                    // anahtar döndü: yolun suçu değil; yenilenen anahtarla aynı yoldan yeniden denenir.
                                    // İkinci ret yenilenen anahtarın da tutmadığını gösterir: bu yol (hedef) bu sorgu için bırakılır.
                                } else {
                                    if (e is OdohException && e.kind == OdohError.AUTH) rejected.incrementAndGet()   // kimlik doğrulaması tutmayan cevap = bozulmuş/sahte cevap
                                    odoh.failure(pathIdx, e)
                                    avoidMask = odoh.avoidAfter(avoidMask, pathIdx, e)
                                }
                            }
                            val slow = exchanging && e is SocketTimeoutException
                            if (slow && odoh == null && healthy(idx)) {
                                // Sunucu başka sorulara cevap veriyor: bu ad yavaş çözülüyor. Şeridi daha fazla meşgul etme;
                                // istemci kendi yeniden denemesini yapar (o sırada cevap önbelleğe girmiş olabilir).
                                slowZone = true
                                break
                            }
                            // Daha önce çalışmış bir bağlantı koptuysa (sunucu boşta kapatmış) bu bir sunucu hatası değildir.
                            if (!wasStale) {
                                noteFailure(idx, e)
                                avoid = idx
                            }
                            if (attempt < 3) retries.incrementAndGet()
                        }
                    }
                    muxHeld?.let { releaseShared(it) }; muxHeld = null
                    if (replyLen < Packets.DNS_HDR) {
                        timeouts.incrementAndGet(); ring.add(LatencyRing.TIMEOUT)
                        deliverStale(job, buf, scratch)
                        markDone(job); continue
                    }
                    // Cevabı teslim etmeden ÖNCE boşta say: istemcinin bu cevaba hemen gönderdiği bir sonraki soru
                    // yeni bir şerit (ve gereksiz bir TLS el sıkışması) açtırmasın, bu şeride düşsün.
                    idleLanes.incrementAndGet()
                    idleMarked = true
                    deliver(job, buf, replyLen, scratch)
                } finally {
                    zq.finish(tk, slowZone)
                }
            }
        } finally {
            if (idleMarked) idleLanes.decrementAndGet()
            conn?.close()
            muxHeld?.let { releaseShared(it) }            // beklenmeyen bir Error ile çıkılsa da kullanıcı sayacı sızmasın
            if (lanes.decrementAndGet() == 0) closeIdleShared()
            laneThreads.remove(Thread.currentThread())
            // Kapanırken kuyrukta iş kaldıysa ve başka şerit yoksa yenisini aç.
            if (!closed && !zq.isEmpty()) ensureLane()
        }
    }

    /** Sunucu son denemelerden sonra da cevap vermedi: bekleyenlere varsa süresi dolmuş olumlu cevap verilir (RFC 8767). */
    private fun deliverStale(job: Job, buf: ByteArray, scratch: ByteArray) {
        val n = cache.getStale(job.key, 0, buf, Packets.HDR)
        if (n <= 0) return
        synchronized(job) {
            if (job.done || job.waiters.isEmpty()) return
            staleServed.incrementAndGet()                     // cevaptan önce sayılır: istatistiği okuyan cevabı görünce sayaç da hazır olsun
            for (i in 0 until job.waiters.size) job.waiters[i].deliver(buf, scratch, n, writeToTun)
            job.waiters.clear()
        }
    }

    /** Son hata, son başarıdan yeni ve en çok [TROUBLE_MS] önce mi? (Boşta kalmak sorun sayılmaz: yalnızca gerçek hata.) */
    private fun upstreamTrouble(): Boolean {
        val f = lastFailAt
        return f > lastAnyOk && nowMs() - f < TROUBLE_MS
    }

    private fun deliver(job: Job, buf: ByteArray, len0: Int, scratch: ByteArray) {
        val len = CnameGuard.guard(buf, Packets.HDR, len0)            // gizli izleyici (CNAME) engeli
        answered.incrementAndGet()
        val took = maxOf(0L, nowMs() - job.at)
        latencySum.addAndGet(took)
        ring.add(took.coerceAtMost(LatencyRing.MAX_MS.toLong()).toInt())
        bytesDown.addAndGet(len.toLong())
        if (Dns.isBlocked(buf, Packets.HDR, len)) blocked.incrementAndGet()
        // İstemci EDNS istemediği halde biz OPT eklediysek cevaptaki OPT atılır (önbelleğe de böyle girer).
        val rlen = if (job.addedOpt) Dns.stripOpt(buf, Packets.HDR, len) else len
        val ttl = Dns.cacheTtl(buf, Packets.HDR, rlen)
        if (ttl > 0) cache.put(job.key, buf, Packets.HDR, rlen, ttl)
        synchronized(job) {
            job.done = true
            val n = job.waiters.size
            for (i in 0 until n) {
                // Her istemci için kimlik ve başlıklar (sağlama toplamı dahil) yeniden yazılır; DNS verisi aynı kalır.
                job.waiters[i].deliver(buf, scratch, rlen, writeToTun)
            }
        }
        byKey.remove(job.key, job)
    }

    private fun noteSuccess(target: Int) {
        lastOk.set(target, nowMs())
        lastAnyOk = nowMs()
        if (target == primaryIdx) streak.set(0)
    }

    private fun noteFailure(target: Int, e: IOException) {
        lastFailAt = nowMs()
        log("şifreli bağlantı hatası: ${e.javaClass.simpleName}")
        if (isTrustFailure(e)) { tlsFailures.incrementAndGet(); if (isClockFailure(e)) clockFailures.incrementAndGet() }
        if (odoh != null || targets.size < 2 || target != primaryIdx) return      // ODoH'ta yedeğe geçişi yol tahtası yönetir
        if (streak.incrementAndGet() >= FAILOVER_AFTER) {
            streak.set(0)
            // CAS: aynı anda başka bir şerit zaten geçtiyse ikinci kez ilerletilmez (birincil bir adım fazla kaymaz).
            if (primaryRef.compareAndSet(target, (target + 1) % targets.size)) {
                failovers.incrementAndGet()
                log("yedek sunucuya geçildi")
            }
        }
    }

    // ------------------------------------------------------------------ bağlantı

    private inner class Conn(val target: Int, val gen: Int, val sock: SSLSocket?, val quic: QuicClient? = null) {
        val input: InputStream = if (sock != null) BufferedInputStream(sock.inputStream, 8192) else java.io.ByteArrayInputStream(ByteArray(0))
        val output: OutputStream = if (sock != null) BufferedOutputStream(sock.outputStream, 1024) else java.io.ByteArrayOutputStream()
        var h3: Http3Client? = null
        @Volatile var dead = false
        @Volatile var used = false
        /** Ortak QUIC bağlantısı: şu an kullanan şerit sayısı; yerine yenisi geçtiyse [retired] ve sayı sıfıra inince kapanır. */
        val users = java.util.concurrent.atomic.AtomicInteger(0)
        @Volatile var retired = false
        /** Paylaşılan (QUIC ya da HTTP/2) bağlantı: şeritler arasında dolaşır, kendi sahibi yoktur. */
        @Volatile var shared = false
        /** HTTP/2 bağlantısı (ALPN "h2" seçildiyse). */
        var h2: Http2Client? = null
        var code = 0              // son HTTP cevabının durum kodu ve içerik türü (yalnızca şerit iş parçacığı)
        var type = ""

        /** Süren soru-cevabın son anı: yavaş yavaş bayt gönderen bir sunucu şeridi sonsuza dek tutamaz. */
        var deadline = Long.MAX_VALUE

        fun close() {
            dead = true
            conns.remove(this)
            try { h2?.close() } catch (_: Exception) {}
            try { sock?.close() } catch (_: Exception) {}
            try { quic?.close() } catch (_: Exception) {}
        }
    }

    /** Doğrulama yalnızca sertifikanın geçerlilik süresi yüzünden mi başarısız oldu? (Saat sapması; araya girme kanıtı değil.) */
    private fun isClockFailure(e: Throwable): Boolean {
        var c: Throwable? = e
        var depth = 0
        while (c != null && depth++ < 6) {
            if (c is java.security.cert.CertificateExpiredException || c is java.security.cert.CertificateNotYetValidException) return true
            c = c.cause
        }
        return false
    }

    /** Sertifika ya da ad doğrulaması başarısız oldu mu? (Araya girilmiş ya da yanlış sunucu belirtisi.) */
    private fun isTrustFailure(e: Throwable): Boolean {
        var c: Throwable? = e
        var depth = 0
        while (c != null && depth++ < 6) {
            if (c is SSLPeerUnverifiedException || c is java.security.cert.CertificateException || (c is QuicTlsException && c.trust)) return true
            c = c.cause
        }
        return false
    }

    /** Bu hedef için sırayla denenecek adresler: tek aile ya da (öbür aile varsa) hatırlanan sıra. */
    private fun attemptOrder(idx: Int): List<InetSocketAddress> {
        val t = targets[idx]
        val alt = t.alt ?: return listOf(t.addr)
        return if (altFirst.get(idx) == 1) listOf(alt, t.addr) else listOf(t.addr, alt)
    }

    /** ODoH rölesine bağlantı: son çalışan adres → ipucu adresleri → (hepsi başarısızsa) şifreli çözümlemeyle bulunanlar. */
    private fun openOdoh(idx: Int, e: OdohEngine): Conn {
        val t = targets[idx]
        var last: IOException? = null
        var trustEx: IOException? = null            // güvenlik açısından önemli hata, sonraki adreslerin sıradan hatasıyla ezilmesin
        val tried = HashSet<InetSocketAddress>()
        for (round in 0..1) {
            val addrs = e.relayAddresses(idx, more = round == 1).filter { tried.add(it) }
            for ((k, a) in addrs.withIndex()) {
                if (closed) break
                // Birden çok adres varken sonuncuya kadar kısa süre tanınır: kopuk bir adres bağlantıyı geciktirmesin.
                val budget = if (k < addrs.size - 1) minOf(connectTimeoutMs, ODOH_HINT_MS) else connectTimeoutMs
                try {
                    val c = openOne(idx, t, a, budget)
                    e.relayConnected(idx, a)
                    return c
                } catch (ex: IOException) {
                    last = ex
                    if (isTrustFailure(ex) && trustEx == null) trustEx = ex      // sayım noteFailure'da, sorgu başına bir kez
                }
            }
            if (closed) break
        }
        throw trustEx ?: last ?: IOException("röle adresi yok")
    }

    private fun open(idx: Int): Conn {
        if (odoh != null) return openOdoh(idx, odoh)
        val t = targets[idx]
        val order = attemptOrder(idx)
        var last: IOException? = null
        for ((k, addr) in order.withIndex()) {
            // İki aile varken ilkine kısa süre tanınır: yanıt vermeyen (ör. kopuk IPv6) aile bağlantıyı geciktirmesin.
            val budget = if (order.size > 1 && k == 0) minOf(connectTimeoutMs, MobilePolicy.firstFamilyMs(connEst).toInt()) else connectTimeoutMs
            try {
                val c = openOne(idx, t, addr, budget)
                if (order.size > 1) altFirst.set(idx, if (addr == t.alt) 1 else 0)
                return c
            } catch (e: IOException) {
                last = e
                if (closed) break
            }
        }
        throw last ?: IOException("adres yok")
    }

    /**
     * Paylaşılan bağlantıyı alır (QUIC ya da HTTP/2): kullanılabilir olan varsa onu (kullanıcı sayacı artırılmış), yoksa yenisini açar.
     * Eskisi kopmuş, ağ değişmiş, akış sınırı dolmuş ya da boşta kalmışsa yerine yenisi geçer; eskisi kullanımdaki işler bitince kapanır.
     * HTTP/1.1 (paylaşılamaz) bağlantı döner: çağıran onu kendisi sahiplenir ([Conn.shared] false). Dönen paylaşılan bağlantının sayacı
     * artırılmıştır; çağıran [releaseShared] ile bırakmalıdır.
     */
    private fun sharedAcquire(idx: Int): Conn = synchronized(sharedLock) {
        val s = sharedConn
        if (s != null && sharedUsable(s, idx)) { s.users.incrementAndGet(); return s }
        if (s != null) {
            sharedConn = null
            s.retired = true
            if (s.users.get() == 0) s.close()
        }
        val c = open(idx)
        if (c.quic == null && c.h2 == null) return c
        c.shared = true
        c.users.incrementAndGet()
        sharedConn = c
        c
    }

    private fun sharedUsable(s: Conn, idx: Int): Boolean {
        if (s.dead || s.gen != netGen || s.target != idx) return false
        s.quic?.let { return it.usable && it.canOpenBidi() }
        s.h2?.let { return it.usable(nowMs()) }
        return false
    }

    /** Son şerit de boşta çıkınca paylaşılan bağlantı bırakılır: aksi halde soket ve okuyucu iş parçacığı sunucu kapatana kadar açık kalırdı. */
    private fun closeIdleShared() = synchronized(sharedLock) {
        val s = sharedConn ?: return
        if (lanes.get() != 0 || !zq.isEmpty()) return
        sharedConn = null
        s.retired = true
        if (s.users.get() <= 0) s.close()
    }

    private fun releaseShared(c: Conn) {
        if (c.users.decrementAndGet() <= 0 && c.retired) c.close()
    }

    /** Bir denemenin bağlantısını bırakır: paylaşılan bağlantı yalnızca kopmuşsa kapanır; öteki işler etkilenmesin. */
    /** [e] bağlantının karşı taraftan kapatıldığını/koptuğunu mu gösteriyor? (Zaman aşımı ve HTTP hataları göstermez.) */
    private fun connectionLost(c: Conn, e: Throwable): Boolean {
        if (c.dead || (c.h2 != null && c.h2?.alive == false) || (c.quic != null && !c.quic.isOpen)) return true
        var x: Throwable? = e
        var depth = 0
        while (x != null && depth++ < 6) {
            if (x is java.io.EOFException || (x is java.net.SocketException && x !is java.net.SocketTimeoutException)) return true
            x = x.cause
        }
        return false
    }

    private fun dropAttempt(c: Conn?) {
        if (c == null) return
        if (!c.shared) { c.close(); return }
        val q = c.quic
        val h = c.h2
        if (c.dead || (q != null && !q.isOpen) || (h != null && !h.alive)) c.close()
    }

    /** QUIC (DoQ/DoH3) bağlantısı: UDP yuvası [openUdp] ile, sertifika adı hedefin adına göre doğrulanır. */
    private fun openQuic(idx: Int, t: SecureTarget, addr: InetSocketAddress, connectMs: Int): Conn {
        val gen = netGen
        val t0 = nowMs()
        val q = QuicClient(t.host, addr, if (proto == Proto.DOQ) "doq" else "h3", openUdp, quicTrust ?: QuicClient.systemTrust())
        try {
            q.connect(connectMs)
        } catch (e: IOException) {
            q.close(); throw e
        } catch (e: RuntimeException) {
            q.close(); throw IOException("QUIC kurulamadı: ${e.javaClass.simpleName}", e)
        }
        connEst.sample((nowMs() - t0).toDouble())
        val c = Conn(idx, gen, null, q)
        if (proto == Proto.DOH3) c.h3 = Http3Client(q, t.host)
        if (gen != netGen) { c.close(); throw IOException("ağ değişti") }
        conns.add(c)
        if (closed) { c.close(); throw IOException("kapandı") }
        return c
    }

    /** TLS el sıkışması başarısız oldu (sertifika reddi değil): sunucu adını (SNI) gören bir filtre bağlantıyı kesmiş olabilir. */
    private class HandshakeFail(cause: IOException) : IOException(cause.message ?: "el sıkışma", cause)

    /** SNI'siz bağlanılması gereken hedefler; ağ değişince sıfırlanır. */
    private val noSni = java.util.concurrent.ConcurrentHashMap.newKeySet<Int>()

    /**
     * DoT/DoH: önce normal (SNI'li) bağlanılır. El sıkışma kesilirse (ör. DPI DNS sunucusunun adını görüp bağlantıyı sıfırlıyor) AYNI
     * hedefe bir kez SNI'siz denenir; çalışırsa o hedef bu ağda SNI'siz bağlanır. Sertifika yine hedef adına karşı doğrulanır: SNI
     * yalnızca sunucunun hangi sertifikayı göstereceğini etkiler, güveni değil. Sertifika reddi ve bağlantı kurulamaması yeniden denenmez.
     */
    private fun openOne(idx: Int, t: SecureTarget, addr: InetSocketAddress, connectMs: Int): Conn {
        if (proto == Proto.DOQ || proto == Proto.DOH3) return openQuic(idx, t, addr, connectMs)
        val useSni = idx !in noSni
        try {
            return openTls(idx, t, addr, connectMs, useSni)
        } catch (e: HandshakeFail) {
            if (!useSni || closed) throw e
            val c = openTls(idx, t, addr, connectMs, false)       // bu da başarısızsa hata aynen yükselir
            noSni.add(idx)
            log("${t.host}: SNI'li el sıkışma kesildi, SNI'siz bağlantı çalıştı")
            return c
        }
    }

    private fun openTls(idx: Int, t: SecureTarget, addr: InetSocketAddress, connectMs: Int, sni: Boolean): Conn {
        val gen = netGen   // el sıkışma sürerken ağ değişirse bu bağlantı eski ağdandır
        val t0 = nowMs()
        val raw = try {
            openSocket(addr, connectMs).also { connEst.sample((nowMs() - t0).toDouble()) }
        } catch (e: IOException) {
            throw e
        } catch (e: Exception) {
            throw IOException("soket açılamadı: ${e.javaClass.simpleName}", e)   // şerit beklenmedik hatayla ölmesin
        }
        val ssl: SSLSocket
        try {
            raw.soTimeout = timeoutMs
            raw.tcpNoDelay = true
            ssl = tlsFactory.createSocket(raw, t.host, addr.port, true) as SSLSocket
            // Yalnızca TLS 1.2 ve 1.3: eski sürümlere (ve onların zayıf takımlarına) düşürme saldırısı mümkün olmasın.
            val modern = ssl.supportedProtocols.filter { it == "TLSv1.3" || it == "TLSv1.2" }
            if (modern.isNotEmpty()) ssl.enabledProtocols = modern.toTypedArray()
            ssl.soTimeout = timeoutMs
            if (!sni) ssl.sslParameters = ssl.sslParameters.also { it.serverNames = emptyList() }
            if (proto == Proto.DOH) {
                // DoH: HTTP/2 teklif edilir; sunucu seçmezse HTTP/1.1 yolu aynen kullanılır.
                ssl.sslParameters = ssl.sslParameters.also { it.applicationProtocols = arrayOf("h2", "http/1.1") }
            }
            try { ssl.startHandshake() } catch (e: javax.net.ssl.SSLPeerUnverifiedException) { throw e }
            catch (e: java.security.cert.CertificateException) { throw e }
            catch (e: javax.net.ssl.SSLHandshakeException) {
                if (e.cause is java.security.cert.CertificateException) throw e          // sertifika sorunu: SNI'siz denemek çözmez
                throw HandshakeFail(e)
            } catch (e: java.net.SocketTimeoutException) { throw e                    // zaman aşımı: ölü sunucuyu iki kez beklemeyelim
            } catch (e: IOException) { throw HandshakeFail(e) }
            TlsPolicy.require(ssl.session.protocol, ssl.session.cipherSuite)      // zayıf sürüm/takım pazarlığını reddet
            if (!verifier.verify(t.host, ssl.session)) {
                try { ssl.close() } catch (_: Exception) {}
                throw SSLPeerUnverifiedException("sertifika ${t.host} adına ait değil")
            }
        } catch (e: IOException) {
            try { raw.close() } catch (_: Exception) {}
            throw e
        } catch (e: RuntimeException) {
            try { raw.close() } catch (_: Exception) {}
            throw IOException("TLS kurulamadı: ${e.javaClass.simpleName}", e)
        }
        val alpn = try { ssl.applicationProtocol } catch (_: Exception) { "" }
        val c = try { Conn(idx, gen, ssl) } catch (e: Exception) {
            try { raw.close() } catch (_: Exception) {}
            throw IOException("TLS akışı açılamadı: ${e.javaClass.simpleName}", e)
        }
        if (alpn == "h2") {
            // HTTP/2 okuyucusu bağlantıyı kendisi bekler: zaman aşımı yok (tek akışların zaman aşımı kendi içinde ele alınır).
            try {
                ssl.soTimeout = 0
                c.h2 = Http2Client(c.input, c.output, t.host, nowMs).also { it.start() }
            } catch (e: IOException) {
                c.close()
                throw e
            }
        }
        if (gen != netGen) { c.close(); throw IOException("ağ değişti") }
        conns.add(c)
        if (closed) { c.close(); throw IOException("kapandı") }
        return c
    }

    /** Soruyu gönderir, cevabı [out] içine [off] konumuna yazar; cevap uzunluğunu döner. Cevabın sorusu denetlenir. */
    private fun exchange(c: Conn, job: Job, out: ByteArray, off: Int, path: Int = -1): Int {
        c.deadline = nowMs() + timeoutMs
        bytesUp.addAndGet(job.query.size.toLong())
        val len = when (proto) {
            Proto.DOT -> exchangeDot(c, job.query, out, off)
            Proto.DOQ -> exchangeDoq(c, job.query, out, off)
            Proto.DOH3 -> exchangeDoh3(c, job.query, out, off)
            Proto.ODOH -> exchangeOdoh(c, job.query, out, off, path)
            else -> if (c.h2 != null) exchangeH2(c, job.query, out, off) else exchangeDoh(c, job.query, out, off)
        }
        if (!Dns.sameQuestion(job.query, 0, job.qEnd, out, off, len)) {
            rejected.incrementAndGet()
            throw IOException("cevabın sorusu uyuşmadı")
        }
        return len
    }

    private fun exchangeDot(c: Conn, query: ByteArray, out: ByteArray, off: Int): Int {
        val o = c.output
        o.write(query.size ushr 8)
        o.write(query.size and 0xFF)
        o.write(query)
        o.flush()
        val wantId = Packets.u16(query, 0)
        // Aynı bağlantıda sırayla soru-cevap yapıldığı için ilk gelen cevap bizimdir; yine de kimlik denetlenir.
        repeat(4) {
            val len = (readByte(c) shl 8) or readByte(c)
            if (len < Packets.DNS_HDR || len > MAX_MSG) throw IOException("geçersiz uzunluk $len")
            readFully(c, out, off, len)
            if (Packets.u16(out, off) == wantId) return len
        }
        throw IOException("cevap kimliği uyuşmadı")
    }

    /** DNS-over-QUIC (RFC 9250): her soru yeni bir çift yönlü akışta, 2 bayt uzunluk önekiyle, kimlik 0; cevap aynı akışta gelir. */
    private fun exchangeDoq(c: Conn, query: ByteArray, out: ByteArray, off: Int): Int {
        val q = c.quic ?: throw IOException("QUIC bağlantısı yok")
        val msg = ByteArray(2 + query.size)
        msg[0] = (query.size ushr 8).toByte(); msg[1] = query.size.toByte()
        System.arraycopy(query, 0, msg, 2, query.size)
        Packets.put16(msg, 2, 0)                                    // RFC 9250 §4.2.1: kimlik 0
        val r = q.request(msg, timeoutMs)
        if (r.size < 2 + Packets.DNS_HDR) throw IOException("kısa DoQ cevabı")
        val len = ((r[0].toInt() and 0xFF) shl 8) or (r[1].toInt() and 0xFF)
        if (len != r.size - 2 || len > MAX_MSG) throw IOException("DoQ uzunluğu uyuşmadı")
        System.arraycopy(r, 2, out, off, len)
        Packets.put16(out, off, Packets.u16(query, 0))             // istemcinin kimliği geri yazılır
        return len
    }

    /** DNS-over-HTTP/3 (RFC 8484 + RFC 9114): QUIC üzerinde POST. */
    private fun exchangeDoh3(c: Conn, query: ByteArray, out: ByteArray, off: Int): Int {
        val h = c.h3 ?: throw IOException("HTTP/3 bağlantısı yok")
        val t = targets[c.target]
        val q = query.copyOf()
        Packets.put16(q, 0, 0)
        val r = h.post(t.path, "application/dns-message", q, timeoutMs)
        if (r.size < Packets.DNS_HDR || r.size > MAX_MSG) throw IOException("geçersiz DoH3 cevabı")
        System.arraycopy(r, 0, out, off, r.size)
        Packets.put16(out, off, Packets.u16(query, 0))
        return r.size
    }

    /** DoH over HTTP/2: aynı bağlantıda eşzamanlı bir akış (RFC 8484 §4.1, POST). */
    private fun exchangeH2(c: Conn, query: ByteArray, out: ByteArray, off: Int): Int {
        val h = c.h2 ?: throw IOException("HTTP/2 bağlantısı yok")
        val t = targets[c.target]
        val q = query.copyOf()
        Packets.put16(q, 0, 0)                     // RFC 8484: önbellek dostu olsun diye kimlik 0
        val r = h.post(t.path, "application/dns-message", q, timeoutMs)
        if (r.status != 200) throw IOException("HTTP/2 ${r.status}")
        val ct = r.contentType?.lowercase() ?: ""
        if (!ct.startsWith("application/dns-message")) throw IOException("beklenmeyen içerik: $ct")   // HTTP/1.1 yoluyla aynı denetim
        if (r.body.size < Packets.DNS_HDR || r.body.size > MAX_MSG) throw IOException("geçersiz DoH cevabı")
        System.arraycopy(r.body, 0, out, off, r.body.size)
        Packets.put16(out, off, Packets.u16(query, 0))
        return r.body.size
    }

    private fun exchangeDoh(c: Conn, query: ByteArray, out: ByteArray, off: Int): Int {
        val t = targets[c.target]
        val q = query.copyOf()
        Packets.put16(q, 0, 0)                     // RFC 8484: önbellek dostu olsun diye kimlik 0
        val head = "POST ${t.path} HTTP/1.1\r\nHost: ${t.host}\r\nUser-Agent: Mozilla/5.0\r\n" +
            "Accept: application/dns-message\r\nContent-Type: application/dns-message\r\n" +
            "Content-Length: ${q.size}\r\n\r\n"
        val o = c.output
        o.write(head.toByteArray(Charsets.ISO_8859_1))
        o.write(q)
        o.flush()

        val len = readHttp(c, out, off)
        if (c.code != 200) throw IOException("HTTP ${c.code}")
        if (!c.type.startsWith("application/dns-message")) throw IOException("beklenmeyen içerik: ${c.type}")
        if (len < Packets.DNS_HDR) throw IOException("kısa cevap")
        // DoH cevabının kimliği 0'dır: istemciye giden kimlik teslimde yazılır; soru bölümü exchange()'de denetlenir.
        Packets.put16(out, off, Packets.u16(query, 0))
        return len
    }

    /**
     * ODoH (RFC 9230): sorgu hedefin anahtarıyla şifrelenir, röleye `application/oblivious-dns-message` olarak gönderilir.
     * Röle yalnızca şifreli yükü, hedef yalnızca röleyi görür. 401: hedef anahtarımızı tanımıyor (anahtar döndü) → yenilenir.
     */
    private fun exchangeOdoh(c: Conn, query: ByteArray, out: ByteArray, off: Int, path: Int): Int {
        val e = odoh ?: throw IOException("ODoH motoru yok")
        val relay = targets[c.target]
        val q = query.copyOf()
        Packets.put16(q, 0, 0)                     // kimlik 0: sorgular arasında ayırt edici bir iz kalmaz (RFC 9230 §6.2)
        val req = e.begin(path, q)
        try {
            val body = req.query.wire
            val head = "POST ${req.relayPath} HTTP/1.1\r\nHost: ${relay.host}\r\nUser-Agent: Mozilla/5.0\r\n" +
                "Accept: ${OdohClient.MEDIA_TYPE}\r\nContent-Type: ${OdohClient.MEDIA_TYPE}\r\n" +
                "Content-Length: ${body.size}\r\n\r\n"
            val t0 = nowMs()
            val o = c.output
            o.write(head.toByteArray(Charsets.ISO_8859_1))
            o.write(body)
            o.flush()
            val len = readHttp(c, out, off)
            when (c.code) {
                200 -> {}
                401 -> { e.keyRejected(req); throw OdohException(OdohError.KEY_REJECTED, "hedef anahtarı tanımadı") }
                else -> throw OdohException(OdohError.HTTP, "HTTP ${c.code}")
            }
            if (!c.type.startsWith(OdohClient.MEDIA_TYPE)) throw OdohException(OdohError.BAD_RESPONSE, "beklenmeyen içerik: ${c.type}")
            val dns = req.query.open(out, off, len)
            if (off + dns.size > out.size) throw OdohException(OdohError.BAD_RESPONSE, "cevap çok büyük")
            System.arraycopy(dns, 0, out, off, dns.size)
            Packets.put16(out, off, Packets.u16(query, 0))
            e.success(req, maxOf(1L, nowMs() - t0))
            return dns.size
        } finally {
            req.query.wipe()                       // hata yolunda open() çağrılmadıysa sırlar yine silinsin
            java.util.Arrays.fill(q, 0)
        }
    }

    /**
     * HTTP/1.1 cevabını okur: durum kodu [Conn.code], içerik türü [Conn.type] alanlarına yazılır; gövde [out]'a [off] konumuna
     * yazılır ve uzunluğu döner. "Connection: close" gelirse bağlantı ölü işaretlenir.
     */
    private fun readHttp(c: Conn, out: ByteArray, off: Int): Int {
        var interim = 0
        while (true) {
            val status = readLine(c) ?: throw EOFException("cevap yok")
            c.code = HttpRules.statusCode(status)
            if (!HttpRules.isInterim(c.code)) break
            // 100/103 ara cevabı: başlıkları atlanır, asıl cevap arkadan gelir (gövdesi yoktur).
            if (++interim > HttpRules.MAX_INTERIM) throw IOException("çok fazla ara cevap")
            var skipped = 0
            while (true) {
                val l = readLine(c) ?: throw EOFException("başlık kesildi")
                if (l.isEmpty()) break
                if (++skipped > MAX_HEADER_LINES) throw IOException("çok fazla başlık")
            }
        }
        if (c.code == 101) throw IOException("beklenmeyen protokol değişimi")
        var contentLength = -1
        var chunked = false
        var sawTe = false
        var close = false
        var type = ""
        var lines = 0
        while (true) {
            val line = readLine(c) ?: throw EOFException("başlık kesildi")
            if (line.isEmpty()) break
            if (++lines > MAX_HEADER_LINES) throw IOException("çok fazla başlık")
            val (name, value) = HttpRules.header(line)
            when (name) {
                "content-length" -> {
                    // Bozuk ya da çelişen uzunluk reddedilir (sessizce "bilinmiyor" sayılmaz).
                    val v = HttpRules.contentLength(value)
                    if (contentLength >= 0 && v != contentLength) throw IOException("çelişen içerik uzunluğu")
                    contentLength = v
                }
                "transfer-encoding" -> {
                    if (sawTe) throw IOException("birden çok aktarım kodlaması")
                    sawTe = true
                    chunked = HttpRules.chunked(value)
                }
                "connection" -> close = value.lowercase().contains("close")
                "content-type" -> type = value.lowercase()
            }
        }
        if (sawTe && contentLength >= 0) throw IOException("çelişen çerçeveleme")
        val len = when {
            chunked -> readChunked(c, out, off)
            contentLength >= 0 -> {
                if (contentLength > MAX_MSG) throw IOException("cevap çok büyük")
                readFully(c, out, off, contentLength); contentLength
            }
            else -> throw IOException("uzunluk bilinmiyor")
        }
        if (close) c.dead = true
        c.type = type
        return len
    }

    private fun checkDeadline(c: Conn) {
        if (nowMs() > c.deadline) throw SocketTimeoutException("cevap süresi doldu")
    }

    private fun readByte(c: Conn): Int {
        checkDeadline(c)
        val b = c.input.read()
        if (b < 0) throw EOFException("bağlantı kapandı")
        return b
    }

    private fun readFully(c: Conn, out: ByteArray, off: Int, n: Int) {
        var got = 0
        while (got < n) {
            checkDeadline(c)
            val r = c.input.read(out, off + got, n - got)
            if (r < 0) throw EOFException("bağlantı kapandı")
            got += r
        }
    }

    /** CRLF ile biten ASCII satırı (CRLF hariç); bağlantı kapandıysa null. */
    private fun readLine(c: Conn): String? {
        val sb = StringBuilder(64)
        while (true) {
            checkDeadline(c)
            val b = c.input.read()
            if (b < 0) return if (sb.isEmpty()) null else throw EOFException("satır kesildi")
            if (b == '\n'.code) {
                if (sb.isNotEmpty() && sb[sb.length - 1] == '\r') sb.setLength(sb.length - 1)
                return sb.toString()
            }
            if (sb.length > MAX_LINE) throw IOException("satır çok uzun")
            sb.append(b.toChar())
        }
    }

    private fun readChunked(c: Conn, out: ByteArray, off: Int): Int {
        var total = 0
        while (true) {
            val sizeLine = readLine(c) ?: throw EOFException("parça kesildi")
            // Yalnızca onaltılık rakamlar (işaret, boşluk, "0x" yok) ve makul uzunluk.
            val size = HttpRules.chunkSize(sizeLine)
            if (size == 0) {
                var trailers = 0
                while (true) {
                    val l = readLine(c) ?: break
                    if (l.isEmpty()) break
                    if (++trailers > MAX_HEADER_LINES) throw IOException("çok fazla son başlık")
                }
                return total
            }
            if (size > MAX_MSG - total) throw IOException("cevap çok büyük")
            readFully(c, out, off + total, size)
            total += size
            HttpRules.chunkEnd(readLine(c))               // parça sonundaki CRLF: başka bir şey gelirse çerçeve bozuktur
        }
    }

    override fun close() {
        if (closed) return
        closed = true
        for (c in conns.toTypedArray()) c.close()
        for (t in laneThreads.toTypedArray()) t.interrupt()
        zq.clear()
        byKey.clear()
        cache.clear()
    }

    companion object {
        /** Şifreli bağlantıda kabul edilen en büyük DNS mesajı. */
        const val MAX_MSG = 16384

        /** Tünelden gelen UDP sorgusunun üst sınırı. */
        const val MAX_UDP_QUERY = 4096

        /** Çift aile varken ilk ailenin bağlantı süresi (ms); yanıt vermezse öbürüne geçilir. */
        const val FIRST_FAMILY_MS = 1500

        const val MAX_QUEUE = 256

        /** Tek alanın (kayıt edilebilir ad) kuyrukta bekleyebileceği en fazla iş: bir alan kuyruğun tamamını dolduramaz. */
        const val ZONE_BACKLOG = 64

        /** Son hatadan sonra sunucu bu süre boyunca (ms) sorunlu sayılır: önbellekte süresi dolmuş olumlu kayıt varsa hemen o verilir. */
        const val TROUBLE_MS = 30_000L
        const val FAILOVER_AFTER = 2

        /** ODoH: birden çok röle adresi varken her birine tanınan bağlantı süresi (ms). */
        const val ODOH_HINT_MS = 1500

        /** Bekleyen tek sorguya eklenebilecek en fazla istemci. */
        const val MAX_WAITERS = 16

        /** Kuyruktaki iş bu kadar beklerse geçici ek şerit açılır (ms). */
        const val BURST_AFTER_MS = 300L

        /**
         * Şüpheli (yavaş) bir alan şerit tutarken başka alanın işi bu kadar (en az; hattın olağan soru-cevap süresinden kısa olamaz) beklerse
         * geçici ek şerit açılır (ms).
         */
        const val EARLY_BURST_MS = 100L

        /** Alan şüphesi eşiğinin üst sınırı (ms): çok yavaş hatta bile bir iş bu süreyi aşarsa şüphelidir. */
        const val SUSPECT_MAX_MS = 2000L

        /** Hedefin "sağlıklı" sayılması için son başarılı cevaptan bu yana en fazla geçen süre (ms). */
        const val HEALTH_MS = 10_000L

        private const val MAX_HEADER_LINES = 64
        private const val MAX_LINE = 8192
    }
}
