package app.dnshizli.core

/**
 * DPI atlatma: bir bağlantının İLK uçuşunu (TLS ClientHello ya da HTTP isteği) ayrıştırır ve ağdaki derin paket denetimi
 * (DPI) cihazları şaşırsın diye parçalara böler. Hepsi sıradan soketlerle yapılabilen (kök gerektirmeyen) yöntemlerdir;
 * sahte paket / düşük TTL / bozuk sağlama toplamı gibi ham soket gerektirenler bilerek yoktur.
 *
 * Yöntemler (TLS): 0 = bayt 1'de ve SNI ortasında TCP bölme; 1 = ClientHello'yu iki TLS kaydına böl (+ TCP bölme);
 * 2 = SNI ortasında bölme + araya 1 bayt acil (OOB) veri (sunucu atar, DPI akışa katar); 3 = 1+2 birlikte.
 * Yöntemler (HTTP): 0 = Host başlığının içinde bölme; 1 = "hOsT" harf karışımı + bölme; 2 = iki nokta sonrası sekme + bölme;
 * 3 = metot içinde bölme + harf karışımı.
 * Hepsi sunucuya göre anlamca aynı veriyi taşır. Otomatik mod, çalışmayan yöntemde bir sonrakine geçer ([Planner]).
 */
internal object Dpi {
    const val NONE = 0
    const val TLS = 1
    const val HTTP = 2

    const val TLS_PLANS = 14
    const val HTTP_PLANS = 8

    /** Gecikmeli yöntemlerde parçalar arası bekleme (ms): DPI'ın kısa ömürlü yeniden birleştirme belleğini aşar, kullanıcıya hissettirmez. */
    const val DELAY_MS = 60

    /** Tüm yöntemleri tükenen bir hedefin yeniden yöntem gezmeden bekleme süresi (ms). */
    /** [Planner.cut]: yöntemi değiştirmek için gereken puan ve puanların geçerli olduğu süre. */
    const val CUT_NEED = 3
    const val CUT_WINDOW_MS = 10 * 60_000L
    const val EXHAUST_MS = 45_000L
    /** Bir yöntemin ağ düzeyinde atlanması için gereken başarısızlık oyu ([Planner.demoted]). */
    const val SKIP_AT = 3.0

    /**
     * TLS yöntemlerinin deneme sırası (bkz. [Planner]). 5 = mikro parçalama, 6 = üç kayıt, 7 = kayıt bölme + düşük TTL,
     * 8 = alan adı sınırında (son noktada) kayıt bölme, 9 = gecikmeli TCP bölme, 10 = gecikmeli kayıt bölme. Gecikmeli olanlar
     * en sonda: yalnızca öbürleri işe yaramazsa denenir (her biri tek bağlantıya [DELAY_MS] ekler). 11 = kayıt bölme, ikinci kaydın
     * başlığındaki sürüm baytı (minör) değiştirilmiş (ByeDPI `--tlsminor` fikri): kayıt başlığı sürümü RFC 8446'ya göre yok sayılır ve
     * el sıkışma özetine girmez, ama başlığı sabit bir sürümle eşleyen DPI kuralları ikinci kaydı tanımaz. En sonda: katı sunucular reddedebilir.
     */
    val TLS_ORDER = intArrayOf(1, 0, 5, 3, 2, 6, 8, 7, 4, 9, 10, 11, 12, 13)

    /**
     * 12 = sahte ClientHello: SNI'yi içeren ilk parça önce DÜŞÜK TTL'le, SNI'sı değiştirilmiş (aynı uzunlukta, iana.org alt alanı)
     * bir kopya olarak gider; DPI bunu görüp akışı "izinli" sayar, sunucuya ulaşmaz. Parça, çekirdeğin yeniden iletim kuyruğunda
     * gerçek veriyle değiştirilir (ByeDPI "fake" tekniği: sendfile + eşlenmiş dosya sayfası); sonra yeniden iletim GERÇEK baytları
     * taşır. Platform bunu yapamazsa ya da TTL düşürülemezse düz bölme gibi davranır (sahte veri asla normal TTL'le gitmez).
     * En sonda: yeniden iletim beklemesi nedeniyle her bağlantıya birkaç yüz ms ekler.
     */
    const val FAKE_TTL = 8
    /** Sahte parçanın en çok uzunluğu (bayt): tek sayfaya sığmalı. */
    const val FAKE_MAX = 2048

    /** Sunucuya TCP düzeyinde bölünmüş TLS kaydı yerine KAYIT düzeyinde bölünmüş ClientHello gönderen yöntemler (eski/hatalı sunucu yığınları bunları reddedebilir). */
    val TLS_RECORD_SPLIT_PLANS = intArrayOf(1, 3, 6, 7, 8, 10, 11, 13)

    /** Eski (v1.12 ve öncesi) yöntem kümesi: yalnızca karşılaştırma / ölçüm içindir ([TLS_ORDER_OLD] ile aynı sırayla). */
    val TLS_ORDER_OLD = intArrayOf(1, 0, 3, 2, 4)
    const val HTTP_PLANS_OLD = 4

    /** DNS'i atlatan bilinen DoH sağlayıcı adları (Reklam+ DNS açıkken engeller: tarayıcı sistem DNS'ine döner). Alt alan adları da kapsanır. */
    /** Bilinen şifreli DNS (DoH/DoT) sağlayıcı adları; tarayıcı/uygulama içi şifreli DNS'i DNS süzgecinden saklayan adlar. */
    internal val DOH_HOSTS = listOf(
        // Google, Cloudflare, Quad9, OpenDNS
        "dns.google", "dns.google.com", "cloudflare-dns.com", "one.one.one.one", "dns.cloudflare.com", "1dot1dot1dot1.cloudflare-dns.com",
        "dns.quad9.net", "dns9.quad9.net", "dns10.quad9.net", "dns11.quad9.net", "dns12.quad9.net",
        "doh.opendns.com", "dns.opendns.com", "doh.familyshield.opendns.com",
        // AdGuard, NextDNS, DNS.SB, CleanBrowsing, ControlD, Mullvad
        "dns.adguard.com", "dns.adguard-dns.com", "dns-family.adguard.com", "dns-unfiltered.adguard.com", "family.adguard-dns.com", "unfiltered.adguard-dns.com",
        "dns.nextdns.io", "doh.dns.sb", "dns.sb", "doh.cleanbrowsing.org", "dns.controld.com", "freedns.controld.com", "doh.mullvad.net", "dns.mullvad.net",
        // diğer kamu / kâr amacı gütmeyen sağlayıcılar
        "doh.libredns.gr", "dns.alidns.com", "doh.pub", "dot.pub", "dns.twnic.tw", "doh.applied-privacy.net", "dns.digitale-gesellschaft.ch", "dnsforge.de",
        "doh.dnslify.com", "dns0.eu", "dns.switch.ch", "doh.ffmuc.net", "doh.tiarap.org", "jp.tiar.app", "doh.li", "dns.containerpi.com", "dns.rubyfish.cn",
        "blahdns.com", "dns.therifleman.name", "wikimedia-dns.org", "doh.xfinity.com", "dns.bebasid.com", "doh.360.cn",
    )

    /** [host] bilinen bir DoH sağlayıcısı mı (kendisi ya da alt alanı)? */
    fun isDohHost(host: String): Boolean = DOH_HOSTS.any { host == it || host.endsWith(".$it") }

    /** Bilinen DoH/DoT sağlayıcılarının IPv4 adresleri: SNI olmadan (ya da IP ile) HTTPS'e bağlanan uygulamalar için. */
    private val DOH_V4 = intArrayOf(
        Packets.ip(8, 8, 8, 8), Packets.ip(8, 8, 4, 4), Packets.ip(1, 1, 1, 1), Packets.ip(1, 0, 0, 1), Packets.ip(1, 1, 1, 2), Packets.ip(1, 0, 0, 2),
        Packets.ip(1, 1, 1, 3), Packets.ip(1, 0, 0, 3), Packets.ip(9, 9, 9, 9), Packets.ip(149, 112, 112, 112), Packets.ip(9, 9, 9, 10), Packets.ip(149, 112, 112, 10),
        Packets.ip(9, 9, 9, 11), Packets.ip(149, 112, 112, 11), Packets.ip(208, 67, 222, 222), Packets.ip(208, 67, 220, 220), Packets.ip(208, 67, 222, 123), Packets.ip(208, 67, 220, 123),
        Packets.ip(94, 140, 14, 14), Packets.ip(94, 140, 15, 15), Packets.ip(94, 140, 14, 140), Packets.ip(94, 140, 14, 141), Packets.ip(94, 140, 14, 15), Packets.ip(94, 140, 15, 16),
        Packets.ip(185, 228, 168, 9), Packets.ip(185, 228, 169, 9), Packets.ip(185, 228, 168, 168), Packets.ip(185, 228, 169, 168), Packets.ip(76, 76, 2, 0), Packets.ip(76, 76, 10, 0),
        Packets.ip(185, 222, 222, 222), Packets.ip(45, 11, 45, 11), Packets.ip(194, 242, 2, 2), Packets.ip(194, 242, 2, 3), Packets.ip(193, 110, 81, 0), Packets.ip(185, 253, 5, 0),
    )

    /** Aynı sağlayıcıların IPv6 adresleri (sabit değerler; ad çözümlemesi yapılmaz). */
    private val DOH_V6: List<ByteArray> = listOf(
        "2001:4860:4860::8888", "2001:4860:4860::8844", "2606:4700:4700::1111", "2606:4700:4700::1001", "2606:4700:4700::1112", "2606:4700:4700::1002",
        "2606:4700:4700::1113", "2606:4700:4700::1003", "2620:fe::fe", "2620:fe::9", "2620:fe::10", "2620:fe::fe:10", "2620:fe::11", "2620:fe::fe:11",
        "2620:119:35::35", "2620:119:53::53", "2a10:50c0::ad1:ff", "2a10:50c0::ad2:ff", "2a0d:2a00:1::2", "2a0d:2a00:2::2", "2606:1a40::", "2606:1a40:1::",
    ).map { java.net.InetAddress.getByName(it).address }

    /**
     * Bilinen herkese açık çözümleyici/DoH/DoT adresleri (IPv4: 4 bayt, IPv6: 16 bayt). DNS modunda (ağ geçidi kapalı) bu adreslerin
     * tünele yönlendirilmesi, sabit bir sunucuya (8.8.8.8:53, DoT 853, DoH 443) doğrudan soran uygulamaların DNS'i tünelden
     * kaçırmasını önler: düz DNS seçilen şifreli DNS'e gider, DoH/DoT bağlantıları reddedilir ve uygulama sistem DNS'ine döner.
     */
    fun knownResolverAddresses(v6: Boolean): List<ByteArray> {
        val out = ArrayList<ByteArray>()
        val seen = HashSet<String>()
        fun add(a: ByteArray) { if (seen.add(a.joinToString(","))) out.add(a) }
        for (x in DOH_V4) add(byteArrayOf((x ushr 24).toByte(), (x ushr 16).toByte(), (x ushr 8).toByte(), x.toByte()))
        for (x in CATALOG_V4) add(byteArrayOf((x ushr 24).toByte(), (x ushr 16).toByte(), (x ushr 8).toByte(), x.toByte()))
        if (v6) { for (a in DOH_V6) add(a); for (a in CATALOG_V6) add(a) }
        return out
    }

    /** [addr] (4 ya da 16 bayt) bilinen bir DoH/DoT sağlayıcı adresi mi? */
    fun isDohAddress(addr: ByteArray): Boolean {
        if (addr.size == 4) { val x = Packets.i32(addr, 0); for (a in DOH_V4) if (a == x) return true; return x in CATALOG_V4 }
        if (addr.size != 16) return false
        for (a in DOH_V6) if (a.contentEquals(addr)) return true
        // IPv4'e eşlenmiş (::ffff:a.b.c.d) ve standart NAT64 (64:ff9b::/96) adresleri: IPv6-only ağlarda 1.1.1.1 gibi IPv4 DoH sunucuları böyle görünür.
        embeddedV4(addr)?.let { return isDohAddress(it) }
        return CATALOG_V6.any { it.contentEquals(addr) }
    }

    /** ::ffff:0:0/96 ya da 64:ff9b::/96 adresinin gömülü IPv4 adresi (son 4 bayt); başka adres için null. */
    internal fun embeddedV4(addr: ByteArray): ByteArray? {
        if (addr.size != 16) return null
        var mapped = true
        for (k in 0 until 10) if (addr[k].toInt() != 0) { mapped = false; break }
        if (mapped && (addr[10].toInt() and 0xFF) == 0xFF && (addr[11].toInt() and 0xFF) == 0xFF) return addr.copyOfRange(12, 16)
        val nat64 = addr[0].toInt() == 0x00 && addr[1].toInt() == 0x64 && (addr[2].toInt() and 0xFF) == 0xFF && (addr[3].toInt() and 0xFF) == 0x9B
        if (nat64) { for (k in 4 until 12) if (addr[k].toInt() != 0) return null; return addr.copyOfRange(12, 16) }
        return null
    }

    /** Katalogdaki (yerleşik) sunucuların adresleri de listeye girer: sabit liste ile katalog ayrışıp açık bırakmasın. */
    private val CATALOG_V4: Set<Int> by lazy {
        val out = HashSet<Int>()
        for (sv in Catalog.builtin) for (a in sv.addresses4) runCatching { out.add(Packets.i32(java.net.InetAddress.getByName(a).address, 0)) }
        out
    }
    private val CATALOG_V6: List<ByteArray> by lazy {
        val out = ArrayList<ByteArray>()
        for (sv in Catalog.builtin) for (a in sv.addresses6) runCatching { out.add(java.net.InetAddress.getByName(a).address) }
        out.filter { it.size == 16 }
    }

    /**
     * Hedef adres yerel mi (özel, döngü, bağlantı-yerel, operatör NAT'ı 100.64/10, çok noktaya yayın)? Yerel hedefler (modem arayüzü,
     * yazıcı, NAS, VPN düğümleri) DPI cihazlarının arkasında değildir: bölmek yalnızca gecikme ve hata riski ekler, başarıları da
     * ağın DPI yöntem oylarını yanıltır. 4 bayt IPv4, 16 bayt IPv6 (IPv4'e eşlenmiş adresler IPv4 gibi sayılır).
     */
    fun isLocalAddress(addr: ByteArray): Boolean {
        if (addr.size == 4) {
            val a = addr[0].toInt() and 0xFF
            val b = addr[1].toInt() and 0xFF
            return FilterEngine.privateV4(addr, 0) || (a == 100 && b in 64..127) || a >= 224
        }
        if (addr.size != 16) return false
        if (FilterEngine.privateV6(addr, 0)) return true
        if ((addr[0].toInt() and 0xFF) == 0xFF) return true                           // ff00::/8 çok noktaya yayın
        // ::ffff:a.b.c.d
        var mapped = true
        for (k in 0 until 10) if (addr[k].toInt() != 0) { mapped = false; break }
        if (mapped && (addr[10].toInt() and 0xFF) == 0xFF && (addr[11].toInt() and 0xFF) == 0xFF) return isLocalAddress(addr.copyOfRange(12, 16))
        return false
    }

    /**
     * TLS ilk uçuşuna gelen İLK cevap baytları bir TLS kaydı mı (el sıkışma 0x16 ya da uyarı 0x15, sürüm 3.x)? Değilse (ör. düz
     * "HTTP/1.1 403" ya da "<html>") bu bir DPI cihazının enjekte ettiği engel sayfasıdır: gerçek bir TLS sunucusu hep kayıtla
     * konuşur. Cevap sayılıp yöntem "işe yaradı" diye öğrenilmemeli, sıradaki yöntem denenmeli.
     */
    fun looksLikeTlsReply(b: ByteArray, n: Int): Boolean {
        if (n < 1) return false
        val t = b[0].toInt() and 0xFF
        if (t != 0x16 && t != 0x15) return false
        return n < 2 || b[1].toInt() == 3
    }

    /**
     * Düz HTTP isteğine gelen ilk cevap "30x" yönlendirmesi ve Location adresi bilinen bir engel sayfası IPv4'ü ([BlockPages]) ise bu bir DPI
     * cihazının enjekte ettiği yönlendirmedir: yöntem "işe yaradı" diye öğrenilmemeli, sıradaki yöntem denenmeli. Yalnızca IP ile
     * eşleşir (ad uydurulmaz); ilk [n] bayt dışına bakılmaz; nesne ayırmaz.
     */
    fun looksLikeBlockRedirect(b: ByteArray, n: Int): Boolean {
        val end = minOf(n, b.size, 2048)
        if (end < 16 || b[0] != 'H'.code.toByte() || b[4] != '/'.code.toByte() || b[9] != '3'.code.toByte()) return false
        var i = 0
        while (i < end - 11) {
            // satır başında "location:" (büyük/küçük harf fark etmez)
            if ((i == 0 || b[i - 1] == '\n'.code.toByte()) && (b[i].toInt() or 0x20) == 'l'.code && regionIs(b, i, "location:", end)) {
                var p = i + 9
                while (p < end && b[p] == ' '.code.toByte()) p++
                if (p + 7 <= end && regionIs(b, p, "http://", end)) p += 7
                else if (p + 8 <= end && regionIs(b, p, "https://", end)) p += 8
                else return false
                var ip = 0; var parts = 0; var cur = 0; var digits = 0
                while (p < end) {
                    val c = b[p].toInt()
                    if (c in '0'.code..'9'.code) { cur = cur * 10 + (c - '0'.code); digits++; if (digits > 3 || cur > 255) return false }
                    else if (c == '.'.code) { if (digits == 0 || parts >= 3) return false; ip = (ip shl 8) or cur; parts++; cur = 0; digits = 0 }
                    else break
                    p++
                }
                if (parts != 3 || digits == 0) return false
                return BlockPages.isBlockPage((ip shl 8) or cur)
            }
            i++
        }
        return false
    }

    private fun regionIs(b: ByteArray, off: Int, lower: String, end: Int): Boolean {
        if (off + lower.length > end) return false
        for (k in lower.indices) if ((b[off + k].toInt() or 0x20) != lower[k].code) return false
        return true
    }

    class Hello {
        var sniOff = -1          // SNI adının [b] içindeki konumu
        var sniLen = 0
        var recLen = 0           // ilk TLS kaydının yük uzunluğu
        var ech = false          // Encrypted ClientHello var: SNI gerçek ad değil olabilir
        fun host(b: ByteArray): String? =
            if (sniOff >= 0 && sniLen > 0) normHost(String(b, sniOff, sniLen, Charsets.ISO_8859_1)) else null
    }

    /**
     * Süzgeç için ad normalleştirme: küçük harf, baştaki/sondaki boşluk ve SONDAKİ NOKTA (FQDN yazımı "ornek.com." sunucularca "ornek.com"
     * ile aynıdır; noktalı yazım listeyi ve DoH denetimini atlatmasın).
     */
    internal fun normHost(raw: String): String {
        var e = raw.length
        while (e > 0 && (raw[e - 1] == '.' || raw[e - 1] == ' ' || raw[e - 1] == '\t')) e--
        var st = 0
        while (st < e && (raw[st] == ' ' || raw[st] == '\t')) st++
        return raw.substring(st, e).lowercase()
    }

    /** İlk baytlara bakıp TLS / HTTP / bilinmiyor ayırır. Karar için en az 3 bayt gerekir. Baştaki boş satırlar (CR/LF) HTTP'de yok sayılır (RFC 9112 §2.2). */
    fun classify(b: ByteArray, len: Int): Int {
        if (len < 3) return NONE
        if (b[0].toInt() == 0x16 && b[1].toInt() == 3 && (b[2].toInt() and 0xFF) <= 4) return TLS
        val s = skipBlank(b, len)
        val m = METHODS.any { m -> len - s >= m.length && m.indices.all { b[s + it].toInt() == m[it].code } }
        return if (m) HTTP else NONE
    }

    /**
     * [classify] henüz NONE diyor ama bayt sayısı artınca HTTP olabilir mi (bir yöntem adının öneki, "GE" / "PROPF" gibi, ya da yalnız boş satırlar)?
     * Evetse ilk uçuş karara bağlanmadan beklenir: aksi halde ilk parçası 3 baytlık gelen bir istek hiç denetlenmezdi.
     */
    fun mayBecomeHttp(b: ByteArray, len: Int): Boolean {
        val s = skipBlank(b, len)
        val n = len - s
        if (n <= 0) return len > 0
        if (n >= MAX_METHOD) return false
        return METHODS.any { m -> n < m.length && (0 until n).all { b[s + it].toInt() == m[it].code } }
    }

    /** Baştaki CR/LF baytlarının sayısı (sunucular istek satırından önceki boş satırları yok sayar). */
    private fun skipBlank(b: ByteArray, len: Int): Int {
        var i = 0
        while (i < len && i < MAX_LEADING_BLANK && (b[i].toInt() == '\r'.code || b[i].toInt() == '\n'.code)) i++
        return i
    }

    private const val MAX_LEADING_BLANK = 64

    /** Bilinen HTTP yöntemleri (RFC 9110 + WebDAV + yaygın uzantılar); sunucular bunların hepsini işler. Boşluk dahil. */
    private val METHODS = listOf(
        "GET ", "POST ", "HEAD ", "PUT ", "DELETE ", "OPTIONS ", "PATCH ", "CONNECT ", "TRACE ",
        "PROPFIND ", "PROPPATCH ", "MKCOL ", "COPY ", "MOVE ", "LOCK ", "UNLOCK ", "REPORT ", "SEARCH ", "PURGE ", "LINK ", "UNLINK ",
        "MKACTIVITY ", "CHECKOUT ", "MERGE ", "NOTIFY ", "SUBSCRIBE ", "UNSUBSCRIBE ", "BIND ", "UNBIND ", "REBIND ", "ACL ", "QUERY ",
    )
    private val MAX_METHOD = METHODS.maxOf { it.length }

    /**
     * TLS: ilk uçuşun tamamı için gereken toplam bayt. Normalde ilk kayıt (5 + yük); ClientHello birden çok el sıkışma
     * kaydına bölünmüşse (SNI ikinci kayıtta olabilir) ClientHello'nun bittiği kayıt sonu. Başlık eksikse -1.
     */
    fun tlsNeed(b: ByteArray, len: Int): Int {
        if (len < 5) return -1
        val first = 5 + Packets.u16(b, 3)
        if (b[0].toInt() != 0x16) return first
        val hl = helloLen(b, len)
        if (hl == -1) return -1
        if (hl <= 0 || hl <= Packets.u16(b, 3)) return first
        var pos = 0
        var got = 0
        while (got < hl) {
            if (pos + 5 > len) return -1
            if (b[pos].toInt() != 0x16) return first                  // el sıkışma dışı kayıt: bölünme değil, ilk kaydı kullan
            val rl = Packets.u16(b, pos + 3)
            got += rl
            pos += 5 + rl
            if (pos > MAX_HELLO + 5 * 16) return first
        }
        return pos
    }

    /**
     * ClientHello'nun toplam el sıkışma uzunluğu (4 baytlık başlık dahil). 4 baytlık el sıkışma başlığı kayıt sınırlarına bölünmüş
     * olabilir (ilk kayıt 1-3 bayt); bu yüzden başlık kayıtlar boyunca toplanır. Başlık için bayt yetmiyorsa -1, ClientHello değilse
     * ya da çok büyükse 0.
     */
    private fun helloLen(b: ByteArray, len: Int): Int {
        var n = 0
        var h0 = 0; var h1 = 0; var h2 = 0; var h3 = 0
        var pos = 0
        while (n < 4) {
            if (pos + 5 > len) return -1
            if (b[pos].toInt() != 0x16) return 0
            val rl = Packets.u16(b, pos + 3)
            var i = 0
            while (i < rl && n < 4) {
                if (pos + 5 + i >= len) return -1
                val v = b[pos + 5 + i].toInt() and 0xFF
                when (n) { 0 -> h0 = v; 1 -> h1 = v; 2 -> h2 = v; else -> h3 = v }
                n++; i++
            }
            pos += 5 + rl
            if (pos > MAX_HELLO + 5 * 16) return 0
        }
        if (h0 != 1) return 0
        val hl = 4 + ((h1 shl 16) or (h2 shl 8) or h3)
        return if (hl > MAX_HELLO) 0 else hl
    }

    /**
     * ClientHello birden çok TLS kaydına bölünmüşse kayıtların yüklerini tek kayıtta birleştirilmiş kopya olarak döndürür
     * ([parseHello] SNI'yı buradan okur). Tek kayıtlık ya da bozuk ise null: çağıran özgün baytları kullanır.
     */
    fun mergedHello(b: ByteArray, len: Int): ByteArray? {
        if (len < 5 || b[0].toInt() != 0x16) return null
        val hl = helloLen(b, len)
        if (hl <= 0 || hl <= Packets.u16(b, 3)) return null
        val out = ByteArray(5 + hl)
        System.arraycopy(b, 0, out, 0, 3)
        var w = 5
        var pos = 0
        while (w - 5 < hl && pos + 5 <= len && b[pos].toInt() == 0x16) {
            val rl = Packets.u16(b, pos + 3)
            val take = minOf(rl, len - pos - 5, hl - (w - 5))
            if (take < 0) break
            System.arraycopy(b, pos + 5, out, w, take)
            w += take
            pos += 5 + rl
        }
        Packets.put16(out, 3, w - 5)
        return out.copyOf(w)
    }

    private const val MAX_HELLO = 12 * 1024
    private fun u24(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xFF) shl 16) or ((b[o + 1].toInt() and 0xFF) shl 8) or (b[o + 2].toInt() and 0xFF)

    /**
     * Sonraki satır: (içerik sonu shl 32) or (sonraki satırın başı); satır bitmediyse -1. Sunucular (nginx, Apache...) yalın LF'yi de satır sonu
     * sayar; yalnızca CRLF arayan bir denetim "GET / HTTP/1.1\nHost: x\n\n" biçimini hiç göremezdi.
     */
    private fun nextLine(b: ByteArray, from: Int, len: Int): Long {
        var i = from
        while (i < len) {
            if (b[i].toInt() == '\n'.code) {
                val ce = if (i > from && b[i - 1].toInt() == '\r'.code) i - 1 else i
                return (ce.toLong() shl 32) or (i + 1).toLong()
            }
            i++
        }
        return -1L
    }

    /** HTTP: başlıkların bittiği konum (boş satır sonrası; CRLF ya da yalın LF) ya da -1. Baştaki boş satırlar atlanır. */
    fun httpEnd(b: ByteArray, len: Int): Int {
        var i = skipBlank(b, len)
        var lines = 0
        while (true) {
            val x = nextLine(b, i, len)
            if (x < 0) return -1
            val ce = (x ushr 32).toInt(); val nx = x.toInt()
            if (ce == i && lines > 0) return nx                     // boş satır: başlıkların sonu
            lines++; i = nx
            if (lines > MAX_HEADER_LINES) return -1
        }
    }

    private const val MAX_HEADER_LINES = 400

    /** ClientHello'dan SNI'yı çıkarır. Bozuk/eksik ise false. */
    fun parseHello(b: ByteArray, len: Int, h: Hello): Boolean {
        h.sniOff = -1; h.sniLen = 0; h.ech = false
        if (len < 44 || b[0].toInt() != 0x16 || b[5].toInt() != 1) return false
        h.recLen = Packets.u16(b, 3)
        val end = minOf(len, 5 + h.recLen)
        var p = 5 + 4 + 2 + 32                         // kayıt başlığı, el sıkışma başlığı, sürüm, rastgele
        if (p + 1 > end) return false
        p += 1 + (b[p].toInt() and 0xFF)               // oturum kimliği
        if (p + 2 > end) return false
        p += 2 + Packets.u16(b, p)                     // şifre takımları
        if (p + 1 > end) return false
        p += 1 + (b[p].toInt() and 0xFF)               // sıkıştırma
        if (p + 2 > end) return false
        val extEnd = minOf(end, p + 2 + Packets.u16(b, p))
        p += 2
        while (p + 4 <= extEnd) {
            val t = Packets.u16(b, p)
            val l = Packets.u16(b, p + 2)
            val body = p + 4
            if (body + l > extEnd) return h.sniOff >= 0
            if (t == 0 && l >= 5) {
                // ServerNameList: birden çok giriş olabilir (RFC 6066); ilk host_name (tür 0) alınır.
                var q = body + 2
                val qEnd = body + l
                while (q + 3 <= qEnd) {
                    val nl = Packets.u16(b, q + 1)
                    if (q + 3 + nl > qEnd) break
                    if (b[q].toInt() == 0 && nl > 0) { h.sniOff = q + 3; h.sniLen = nl; break }
                    q += 3 + nl
                }
            } else if (t == 0xFE0D) h.ech = true
            p = body + l
        }
        return h.sniOff >= 0
    }

    /** HTTP isteğinde Host değerinin konumu ve uzunluğu (başlık adının başlangıcı [hdrOff] ile). */
    class HttpInfo { var hdrOff = -1; var valOff = -1; var valLen = 0; var get = false }

    fun parseHttp(b: ByteArray, len: Int, h: HttpInfo): Boolean {
        h.hdrOff = -1; h.valOff = -1; h.valLen = 0
        h.get = len >= 4 && (startsWith(b, "GET ") || startsWith(b, "HEAD"))
        var i = skipBlank(b, len)
        var lines = 0
        while (i < len && lines++ < MAX_HEADER_LINES) {
            val x = nextLine(b, i, len)
            if (x < 0) break
            val e = (x ushr 32).toInt(); val nx = x.toInt()
            if (e == i) { if (lines > 1) break; i = nx; continue }       // boş satır: başlıkların sonu (istek satırından sonra)
            if (lines > 1 && e - i >= 5 && lower(b[i]) == 'h' && lower(b[i + 1]) == 'o' && lower(b[i + 2]) == 's' && lower(b[i + 3]) == 't' && b[i + 4].toInt() == ':'.code) {
                var v = i + 5
                var ve = e
                var next = nx
                // Başlık katlama (obs-fold): değer boşsa ya da sonraki satır boşlukla başlıyorsa devam satırları değere katılır. İlk dolu parça alınır.
                while (true) {
                    while (v < ve && (b[v].toInt() == ' '.code || b[v].toInt() == '\t'.code)) v++
                    while (ve > v && (b[ve - 1].toInt() == ' '.code || b[ve - 1].toInt() == '\t'.code)) ve--
                    if (ve > v) break
                    val y = nextLine(b, next, len)
                    if (y < 0 || next >= len || (b[next].toInt() != ' '.code && b[next].toInt() != '\t'.code)) break
                    v = next; ve = (y ushr 32).toInt(); next = y.toInt()
                }
                if (ve > v) { h.hdrOff = i; h.valOff = v; h.valLen = ve - v; return true }
                i = next
                continue
            }
            i = nx
        }
        return false
    }

    /**
     * İsteğin BÜTÜN Host başlıklarının adları (küçük harf, port ve sondaki nokta atılmış). Sunucular yinelenen Host'ta farklı davranır
     * (kimi ilkini, kimi sonuncusunu alır) ve katlanmış ("Host:\r\n ad") değeri kabul eder: yalnızca ilk satıra bakan bir denetim
     * ikinci Host'a ya da katlamaya gizlenmiş engelli adı görmezdi. İsim ile ":" arasındaki boşluğu da Host sayar (katı olmayan sunucular).
     */
    fun allHttpHosts(b: ByteArray, len: Int): List<String> {
        val out = ArrayList<String>(2)
        var i = skipBlank(b, len)
        var lines = 0
        while (i < len && lines++ < MAX_HEADER_LINES) {
            val x = nextLine(b, i, len)
            if (x < 0) break
            val e = (x ushr 32).toInt(); val nx = x.toInt()
            if (e == i) { if (lines > 1) break; i = nx; continue }
            if (lines > 1) {
                var ne = i
                while (ne < e && b[ne].toInt() != ':'.code) ne++
                var te = ne
                while (te > i && (b[te - 1].toInt() == ' '.code || b[te - 1].toInt() == '\t'.code)) te--
                if (ne < e && te - i == 4 && lower(b[i]) == 'h' && lower(b[i + 1]) == 'o' && lower(b[i + 2]) == 's' && lower(b[i + 3]) == 't') {
                    var v = ne + 1
                    var ve = e
                    var next = nx
                    while (true) {
                        while (v < ve && (b[v].toInt() == ' '.code || b[v].toInt() == '\t'.code)) v++
                        while (ve > v && (b[ve - 1].toInt() == ' '.code || b[ve - 1].toInt() == '\t'.code)) ve--
                        if (ve > v) break
                        val y = nextLine(b, next, len)
                        if (y < 0 || next >= len || (b[next].toInt() != ' '.code && b[next].toInt() != '\t'.code)) break
                        v = next; ve = (y ushr 32).toInt(); next = y.toInt()
                    }
                    if (ve > v) hostOf(String(b, v, ve - v, Charsets.ISO_8859_1))?.let { if (it !in out) out.add(it) }
                    i = next
                    continue
                }
            }
            i = nx
        }
        return out
    }

    /** "Ad:port" / "[v6]:port" değerinden küçük harfli adı çıkarır (sondaki nokta atılır); boşsa null. */
    private fun hostOf(value: String): String? {
        val s = value.lowercase().trim()
        val host = if (s.startsWith("[")) s.substringAfter('[').substringBefore(']') else s.substringBefore(':')
        return normHost(host).ifEmpty { null }
    }

    fun httpHost(b: ByteArray, h: HttpInfo): String? {
        if (h.valOff < 0) return null
        return hostOf(String(b, h.valOff, h.valLen, Charsets.ISO_8859_1))
    }

    /**
     * İstek satırındaki hedefin adı: mutlak biçim (`GET http://ad.example/yol HTTP/1.1`) ya da CONNECT (`CONNECT ad:443`).
     * Sunucu (ve vekil sunucular) bu biçimde Host başlığını DEĞİL bu adı kullanır (RFC 9112 §3.2.2): yalnızca Host'a bakan
     * bir süzgeç "Host: izinli.com" yazılarak atlatılabilirdi. Sıradan (köken biçimli, "/yol") istekte null.
     */
    fun requestTargetHost(b: ByteArray, len: Int): String? {
        val i = skipBlank(b, len)                                                        // baştaki boş satırlar
        val lineEnd = nextLine(b, i, len).let { if (it < 0) minOf(len, i + MAX_REQ_LINE) else (it ushr 32).toInt() }
        var sp = i
        while (sp < lineEnd && b[sp].toInt() != ' '.code) sp++
        if (sp >= lineEnd || sp - i > 16) return null
        val method = String(b, i, sp - i, Charsets.ISO_8859_1)
        var t = sp + 1
        var te = t
        while (te < lineEnd && b[te].toInt() != ' '.code) te++
        if (te <= t) return null
        val target = String(b, t, minOf(te - t, MAX_REQ_LINE), Charsets.ISO_8859_1)
        val authority = when {
            method == "CONNECT" -> target
            target.length > 7 && target.regionMatches(0, "http://", 0, 7, ignoreCase = true) -> target.substring(7)
            target.length > 8 && target.regionMatches(0, "https://", 0, 8, ignoreCase = true) -> target.substring(8)
            else -> return null
        }.substringBefore('/').substringBefore('?').substringBefore('#').substringAfterLast('@').lowercase()
        val host = if (authority.startsWith("[")) authority.substringAfter('[').substringBefore(']') else authority.substringBefore(':')
        return normHost(host).ifEmpty { null }
    }

    private const val MAX_REQ_LINE = 4096

    private fun startsWith(b: ByteArray, s: String): Boolean = s.indices.all { b[it].toInt() == s[it].code }
    private fun lower(x: Byte): Char = (x.toInt() or 0x20).toChar()
    private fun lineEnd(b: ByteArray, from: Int, len: Int): Int {
        var i = from
        while (i + 1 < len) { if (b[i].toInt() == '\r'.code && b[i + 1].toInt() == '\n'.code) return i; i++ }
        return -1
    }

    /**
     * Sunucuya sırayla yazılacak bir parça; [oobAfter] doğruysa arkasından 1 bayt acil veri gönderilir. [delayMs] > 0 ise bu
     * parça yazılmadan ÖNCE o kadar beklenir (kuyruktaki sonraki parçalar da bekler; sıra bozulmaz).
     */
    class Part(val data: ByteArray, val oobAfter: Boolean = false, val lowTtl: Boolean = false, val delayMs: Int = 0, val fake: ByteArray? = null)

    private fun delayed(p: Part, ms: Int = DELAY_MS) = Part(p.data, p.oobAfter, p.lowTtl, ms, p.fake)

    private fun slice(b: ByteArray, from: Int, to: Int): ByteArray = b.copyOfRange(from, to)

    /**
     * [plan] numaralı yönteme göre ilk uçuşu parçalara böler. Veri tek parçaysa (bölünemiyorsa) tek elemanlı dizi döner.
     * [n] ilk uçuşun uzunluğudur (b'nin tamamı olmayabilir).
     */
    fun split(kind: Int, plan: Int, b: ByteArray, n0: Int): List<Part> {
        val n = n0.coerceIn(0, b.size)
        if (n == 0) return emptyList()
        val raw = when (kind) {
            TLS -> splitTls(plan, b, n)
            HTTP -> splitHttp(plan, b, n)
            else -> listOf(Part(slice(b, 0, n)))
        }
        // güvenlik ağı: boş parça asla yazılmaz (bozuk girdide bölme noktaları çakışabilir)
        return if (raw.any { it.data.isEmpty() }) raw.filter { it.data.isNotEmpty() }.ifEmpty { listOf(Part(slice(b, 0, n))) } else raw
    }

    private fun splitTls(plan: Int, b: ByteArray, n: Int): List<Part> {
        if (n < 8) return listOf(Part(slice(b, 0, n)))
        val h = Hello()
        val ok = parseHello(b, n, h)
        val mid = if (ok) h.sniOff + h.sniLen / 2 else n / 2
        val cut = mid.coerceIn(2, n - 1)
        return when (plan) {
            0 -> listOf(Part(slice(b, 0, 1)), Part(slice(b, 1, cut)), Part(slice(b, cut, n)))
            1 -> tlsRecordParts(b, n, cut)
            2 -> listOf(Part(slice(b, 0, cut), oobAfter = true), Part(slice(b, cut, n)))
            // 4 = "disorder": ilk bayt çok düşük TTL ile gider (DPI'a ya da sunucuya ulaşmaz), çekirdek biraz sonra normal TTL ile
            // yeniden yollar; DPI akışı sırasız görür. TTL ayarlanamazsa yalnızca 0 numaralı bölme gibi davranır.
            4 -> listOf(Part(slice(b, 0, 1), lowTtl = true), Part(slice(b, 1, cut)), Part(slice(b, cut, n)))
            // 5 = mikro parçalama: kayıt başlığı bayt bayt, SNI küçük dilimlerle; her dilim ayrı TCP parçası (en çok 16).
            5 -> microParts(b, n, if (ok) h.sniOff else cut, if (ok) h.sniLen else 0)
            // 6 = üç TLS kaydı: [el sıkışma başlığı] [SNI'nın ilk yarısına dek] [kalan]; DPI'ın kayıt birleştirme sınırını aşar.
            6 -> tlsThreeRecords(b, n, cut)
            // 7 = kayıt bölme + ilk kayıt düşük TTL ile (çekirdek yeniden yollayana dek DPI akışta boşluk görür).
            7 -> {
                val x = tlsRecordParts(b, n, cut)
                if (x.size >= 3) listOf(Part(x[0].data + x[1].data, lowTtl = true), x[2]) else listOf(Part(slice(b, 0, cut), lowTtl = true), Part(slice(b, cut, n)))
            }
            // 8 = alan adı sınırı: kayıt, SNI'nın SON noktasında bölünür ("cdn.ornek" | ".com"). Tüm alan adını ya da yalnızca son ekini
            // (".com") arayan DPI kuralları ilk kayıtta tam eşleşme bulamaz. Noktasız adda ortadan bölünür (1 ile aynı).
            8 -> tlsRecordParts(b, n, labelCut(b, n, h, ok, cut))
            // 9 = gecikmeli TCP bölme: SNI ortasına dek giden parça DPI'a ulaştıktan DELAY_MS sonra kalanı gelir; kısa ömürlü
            // yeniden birleştirme belleği olan cihaz ilk parçayı unutmuştur (kayıt yapısı bozulmadığından sunucular için güvenlidir).
            9 -> listOf(Part(slice(b, 0, 1)), Part(slice(b, 1, cut)), Part(slice(b, cut, n), delayMs = DELAY_MS))
            // 11 = kayıt bölme + ikinci kaydın sürüm baytı değişik (03 01 <-> 03 03). Bölünemiyorsa (tek parça) yöntem 1 gibi.
            11 -> {
                val x = tlsRecordParts(b, n, cut)
                if (x.size >= 3 && x[2].data.size > 3) {
                    val d = x[2].data.copyOf()
                    d[2] = if (d[2].toInt() == 1) 3 else 1
                    listOf(x[0], x[1], Part(d))
                } else x
            }
            // 12 = sahte ClientHello (bkz. FAKE_TTL): SNI'nın sonuna dek olan ilk parçanın sahte kopyası düşük TTL'le gider.
            12 -> {
                val e = (if (ok) h.sniOff + h.sniLen else cut).coerceIn(2, n - 1)
                val real = slice(b, 0, e)
                listOf(Part(real, fake = if (ok && h.sniOff >= 0 && h.sniLen > 0 && h.sniOff + h.sniLen <= e && e <= FAKE_MAX) fakeHello(real, h.sniOff, h.sniLen) else null), Part(slice(b, e, n)))
            }
            // 13 = birleşik (12 + kayıt bölme): SNI'nın sonunda biten ilk TLS kaydı, sahte kopyasıyla birlikte düşük TTL'le gider;
            // kalan yük ikinci kayıtta, ayrı bir TCP parçası olarak. Hem "sahte" hem "kayıt sınırı" kuralını birlikte bozar.
            13 -> {
                val e = (if (ok) h.sniOff + h.sniLen else cut).coerceIn(2, n - 1)
                val x = tlsRecordParts(b, n, e)
                if (x.size >= 3 && ok && h.sniOff >= 0 && h.sniLen > 0 && h.sniOff + h.sniLen <= e && e <= FAKE_MAX) {
                    val rec1 = x[0].data + x[1].data                 // ilk kayıt: başlık + SNI'yi de içeren yük
                    listOf(Part(rec1, fake = fakeHello(rec1, h.sniOff, h.sniLen)), x[2])
                } else x
            }
            // 10 = gecikmeli kayıt bölme: iki TLS kaydı; ikincisi DELAY_MS sonra.
            10 -> {
                val x = tlsRecordParts(b, n, cut)
                if (x.size >= 3) listOf(x[0], x[1], delayed(x[2])) else listOf(Part(slice(b, 0, cut)), Part(slice(b, cut, n), delayMs = DELAY_MS))
            }
            else -> {
                val x = tlsRecordParts(b, n, cut)
                if (x.size >= 3) listOf(x[0], Part(x[1].data, oobAfter = true), x[2]) else listOf(Part(slice(b, 0, cut), oobAfter = true), Part(slice(b, cut, n)))
            }
        }
    }

    /** [real]in kopyasında SNI adı aynı uzunlukta bir iana.org alt alanıyla değiştirilir (DPI için "izinli" görünür). */
    fun fakeHello(real: ByteArray, sniOff: Int, sniLen: Int): ByteArray {
        val out = real.copyOf()
        if (sniOff < 0 || sniLen <= 0 || sniOff + sniLen > out.size) return out
        val base = ".iana.org"
        val name = if (sniLen >= base.length + 1) "w".repeat(sniLen - base.length) + base else "iana.org".padStart(sniLen, 'w').takeLast(sniLen)
        for (i in 0 until sniLen) out[sniOff + i] = name[i].code.toByte()
        return out
    }

    /** SNI adının son noktasındaki bölme konumu (nokta ikinci parçanın ilk baytı olur); nokta yoksa ya da SNI okunamadıysa [fallback]. */
    private fun labelCut(b: ByteArray, n: Int, h: Hello, ok: Boolean, fallback: Int): Int {
        if (!ok || h.sniLen < 3) return fallback
        var i = h.sniOff + h.sniLen - 1
        while (i > h.sniOff && b[i].toInt() != '.'.code) i--
        if (i <= h.sniOff) return fallback
        return i.coerceIn(2, n - 1)
    }

    // --- TLS kaydı bölme

    /**
     * ClientHello'yu [cut] noktasında iki TLS kaydına bölüp üç TCP parçası verir: [0,1) [1, kayıt1 sonu) [kayıt2].
     * Birleşik akış geçerli iki ardışık el sıkışma kaydıdır; sunucu parçalı kaydı birleştirir (RFC 8446 §5.1).
     */
    fun tlsRecordParts(b: ByteArray, n: Int, cut: Int): List<Part> {
        val recEnd = 5 + Packets.u16(b, 3)
        if (n < recEnd || cut <= 5 || cut >= recEnd) return listOf(Part(slice(b, 0, 1)), Part(slice(b, 1, n)))
        val first = ByteArray(cut)                       // kayıt 1: başlık + yükün ilk kısmı
        System.arraycopy(b, 0, first, 0, cut)
        Packets.put16(first, 3, cut - 5)
        val second = ByteArray(5 + (recEnd - cut) + (n - recEnd))   // kayıt 2: yeni başlık + kalan yük (+ varsa sonrası)
        System.arraycopy(b, 0, second, 0, 3)
        Packets.put16(second, 3, recEnd - cut)
        System.arraycopy(b, cut, second, 5, n - cut)
        return listOf(Part(slice(first, 0, 1)), Part(slice(first, 1, first.size)), Part(second))
    }

    /** Akış aynı kalır; yalnızca TCP parça sınırları değişir (kayıt başlığı + SNI boyunca küçük dilimler). */
    private fun microParts(b: ByteArray, n: Int, sniOff: Int, sniLen: Int): List<Part> {
        val cuts = java.util.TreeSet<Int>()
        for (i in 1..5) cuts.add(i)                                   // kayıt başlığı bayt bayt
        if (sniLen > 0) {
            val step = maxOf(2, sniLen / 5)
            var c = sniOff - 1
            while (c < sniOff + sniLen + 1) { cuts.add(c); c += step }
        } else cuts.add(n / 2)
        val pts = cuts.filter { it in 1 until n }.toMutableList()
        while (pts.size > 15) pts.removeAt(pts.size / 2)
        val out = ArrayList<Part>(pts.size + 1)
        var prev = 0
        for (c in pts) { if (c > prev) { out.add(Part(slice(b, prev, c))); prev = c } }
        out.add(Part(slice(b, prev, n)))
        return out
    }

    /** ClientHello'yu üç geçerli TLS kaydına böler (RFC 8446 §5.1: el sıkışma iletisi birden çok kayda bölünebilir). */
    fun tlsThreeRecords(b: ByteArray, n: Int, cut: Int): List<Part> {
        val recEnd = 5 + Packets.u16(b, 3)
        val c1 = 5 + 4                                                // el sıkışma başlığı (tip + 3 bayt uzunluk) ilk kayıtta
        if (n < recEnd || cut <= c1 + 1 || cut >= recEnd) return tlsRecordParts(b, n, cut)
        val out = java.io.ByteArrayOutputStream(n + 10)
        fun rec(from: Int, to: Int) {
            out.write(b[0].toInt()); out.write(b[1].toInt()); out.write(b[2].toInt())
            out.write((to - from) shr 8); out.write(to - from)
            out.write(b, from, to - from)
        }
        rec(5, c1); val l1 = out.size()
        rec(c1, cut); val l2 = out.size()
        rec(cut, recEnd)
        if (n > recEnd) out.write(b, recEnd, n - recEnd)
        val all = out.toByteArray()
        return listOf(Part(slice(all, 0, 1)), Part(slice(all, 1, l1)), Part(slice(all, l1, l2)), Part(slice(all, l2, all.size)))
    }

    private fun splitHttp(plan: Int, b: ByteArray, n: Int): List<Part> {
        val h = HttpInfo()
        val ok = parseHttp(b, n, h)
        val d = b.copyOfRange(0, n)
        if (!ok) return listOf(Part(d))
        val cut: Int
        when (plan) {
            0 -> cut = h.hdrOff + 2
            1 -> { mixCase(d, h.hdrOff); cut = h.hdrOff + 2 }
            2 -> {
                // "Host:" ile değer arasına sekme: çoğu sunucu başlık değerindeki boşluğu yok sayar.
                val x = ByteArray(n + 1)
                System.arraycopy(d, 0, x, 0, h.hdrOff + 5)
                x[h.hdrOff + 5] = '\t'.code.toByte()
                System.arraycopy(d, h.hdrOff + 5, x, h.hdrOff + 6, n - h.hdrOff - 5)
                val c = (h.hdrOff + 2).coerceAtMost(x.size - 1)
                return listOf(Part(slice(x, 0, c)), Part(slice(x, c, x.size)))
            }
            3 -> { mixCase(d, h.hdrOff); cut = 2 }
            // 4 = en başa boş satır (RFC 9112 §2.2: sunucu istek satırından önceki boş satırı yok sayar) + Host içinde bölme.
            4 -> {
                val x = ByteArray(n + 2)
                x[0] = '\r'.code.toByte(); x[1] = '\n'.code.toByte()
                System.arraycopy(d, 0, x, 2, n)
                val c = h.hdrOff + 4
                return listOf(Part(slice(x, 0, c)), Part(slice(x, c, x.size)))
            }
            // 5 = Host başlığını sona taşı + ":" sonrası fazladan boşluk; "Ho|st" ortasından böl. Başlık sırası anlam taşımaz (RFC 9110 §5.3).
            5 -> {
                val he = httpEnd(d, n)
                val le = lineEnd(d, h.hdrOff, n)
                // Yalnızca saf CRLF'li, katlanmamış Host satırı taşınır; yalın LF'li ya da devam satırlı (obs-fold) istekte başlık taşımak isteği bozar.
                if (he < 0 || le < 0 || he < le + 4 || !crlfOnly(d, he) || (le + 2 < n && (d[le + 2].toInt() == ' '.code || d[le + 2].toInt() == '\t'.code))) { cut = h.hdrOff + 2 }
                else {
                    val hostLine = d.copyOfRange(h.hdrOff, le)
                    val sb = java.io.ByteArrayOutputStream(n + 4)
                    sb.write(d, 0, h.hdrOff)                          // istek satırı + önceki başlıklar
                    sb.write(d, le + 2, he - 2 - (le + 2))            // sonraki başlıklar (son boş satır hariç)
                    val hostAt = sb.size()
                    sb.write(hostLine, 0, 5); sb.write(' '.code); sb.write(' '.code); sb.write(hostLine, 5, hostLine.size - 5)
                    sb.write('\r'.code); sb.write('\n'.code); sb.write('\r'.code); sb.write('\n'.code)
                    sb.write(d, he, n - he)                           // gövde varsa
                    val x = sb.toByteArray()
                    val c = hostAt + 2
                    return listOf(Part(slice(x, 0, c)), Part(slice(x, c, x.size)))
                }
            }
            // 7 = gecikmeli bölme: Host DEĞERİNİN ortasında böl, ikinci parça DELAY_MS sonra (kısa ömürlü birleştirme belleği olan DPI).
            7 -> {
                val c = (h.valOff + h.valLen / 2).coerceIn(1, n - 1)
                return listOf(Part(slice(d, 0, c)), Part(slice(d, c, n), delayMs = DELAY_MS))
            }
            // 6 = çoklu bölme: metodun içinde, Host adının içinde ve değerin ortasında (+ harf karışımı).
            else -> {
                mixCase(d, h.hdrOff)
                val pts = java.util.TreeSet<Int>(listOf(2.coerceAtMost(n - 1), h.hdrOff + 2, h.valOff + h.valLen / 2))
                val out = ArrayList<Part>()
                var prev = 0
                for (c in pts) { if (c in (prev + 1) until n) { out.add(Part(slice(d, prev, c))); prev = c } }
                out.add(Part(slice(d, prev, n)))
                return out
            }
        }
        val c = cut.coerceIn(1, n - 1)
        return listOf(Part(slice(d, 0, c)), Part(slice(d, c, n)))
    }

    /** [d] içinde ilk [n] bayt boyunca her LF'nin önünde CR var mı (saf CRLF)? */
    private fun crlfOnly(d: ByteArray, n: Int): Boolean {
        for (i in 0 until minOf(n, d.size)) if (d[i].toInt() == '\n'.code && (i == 0 || d[i - 1].toInt() != '\r'.code)) return false
        return true
    }

    private fun mixCase(d: ByteArray, off: Int) {
        d[off] = 'h'.code.toByte(); d[off + 1] = 'O'.code.toByte(); d[off + 2] = 's'.code.toByte(); d[off + 3] = 'T'.code.toByte()
    }

    /**
     * Hedef başına çalışan yöntemi hatırlar (en çok [cap] hedef, en eski atılır). Yöntem çalışmazsa sıradakine geçilir.
     * İlk deneme: o hedef için öğrenilen yöntem; yoksa AĞ ÖNCELİĞİ (bu ağda son zamanlarda en çok işe yarayan yöntem, oylar zamanla
     * sönümlenir); o da yoksa TLS'te 1, HTTP'de 0. Böylece aynı ağdaki yeni sitelerde baştan doğru yöntemle başlanır.
     * Bekleme süresi sabit değil, bağlantı süresinden (RTT) türetilir: [waitMs].
     */
    /** Site belleği anahtarı: hedef adının 48 bitlik özeti (onaltılık). Kalıcı kayıtta ad açık yazılmaz. */
    fun siteKey(key: String): String { val b = key.toByteArray(Charsets.UTF_8); return java.lang.Long.toHexString(FilterHash.hash(b, 0, b.size)) }

    class Planner(private val cap: Int = 512, private val slow: Boolean = false) {
        private val ok = object : LinkedHashMap<String, Int>(64, 0.75f, true) {
            override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Int>?) = size > cap
        }
        private val votes = Array(3) { DoubleArray(16) }          // [tür][yöntem]
        private var rtt = 0.0
        private val est = RttEstimator()

        /** Bu ağda kalıcı bellekten gelen tohum yöntemler (-1 = yok). Öğrenilmiş bilgi her zaman oylamadan önce gelir. */
        private var seedTls = -1
        private var seedHttp = -1

        @Synchronized fun seed(kind: Int, plan: Int) { if (kind == TLS) seedTls = plan else seedHttp = plan }

        private fun prior(kind: Int): Int {
            val seed = if (kind == TLS) seedTls else seedHttp
            if (seed >= 0) return seed
            val def = if (kind == TLS) TLS_ORDER[0] else 0
            val v = votes[kind]
            val n = if (kind == TLS) TLS_PLANS else HTTP_PLANS
            var best = def
            if (demoted(kind, best)) best = (if (kind == TLS) TLS_ORDER.firstOrNull { !demoted(kind, it) } else (0 until n).firstOrNull { !demoted(kind, it) }) ?: def
            for (i in 0 until n) if (!demoted(kind, i) && v[i] > v[best] * 1.5 + 0.5) best = i
            // Oyları yakın olan yöntemler arasında ölçülen ilk-cevap süresi belirgin kısa olanı seç (yavaş çalışan yerine hızlı çalışan).
            val l = lat[kind]
            if (l[best] > 0.0) for (i in 0 until n) {
                if (i != best && !demoted(kind, i) && v[i] > 0.0 && v[i] >= v[best] * 0.8 && l[i] > 0.0 && l[i] < l[best] * 0.7) best = i
            }
            return best
        }

        /**
         * Bellek anahtarı. TLS ve HTTP aynı adı paylaşır ama yöntem numaraları ayrı anlam taşır (TLS 12 = sahte ClientHello, HTTP 5 = başlık taşıma);
         * ortak bellekte http://ornek.com'da öğrenilen yöntem https://ornek.com'a (ya da tersi) geçerdi. HTTP girdileri ayrı anahtarlanır; TLS anahtarı
         * kalıcı belleğin ([PlanMemory] site özeti) biçimiyle aynı kalır.
         */
        private fun mk(key: String, kind: Int) = if (kind == HTTP) "\u0001$key" else key
        private fun okKey(key: String, kind: Int) = siteKey(mk(key, kind))
        private fun valid(kind: Int, plan: Int) = plan in 0 until (if (kind == TLS) TLS_PLANS else HTTP_PLANS)

        @Synchronized fun first(key: String, kind: Int = HTTP): Int = ok[okKey(key, kind)]?.takeIf { valid(kind, it) } ?: prior(kind)

        /**
         * Yeniden denenemeyen uçuş (ör. POST, ClientHello'dan sonra fazladan veri) için başlangıç yöntemi: yalnızca bu hedefte
         * kanıtlanmış yöntem ya da en güvenli varsayılan (TLS 1, HTTP 0). Ağ oylarından gelen cesur yöntemler (başlık taşıma, başa
         * boş satır…) denenemeyen bir istekte sunucuyu bozabilir; kurtarma şansı olmadığı için kullanılmaz.
         */
        @Synchronized fun firstSafe(key: String, kind: Int = HTTP): Int = ok[okKey(key, kind)]?.takeIf { valid(kind, it) } ?: (if (kind == TLS) TLS_ORDER[0] else 0)
        /**
         * [tried]: bu bağlantıda [plan]'dan ÖNCE denenip başarısız olan yöntemlerin bit maskesi (bit i = yöntem i). Başka bir yöntem
         * çalıştığına göre bunlar gerçekten engelli sayılır (hedef çökük olsaydı hiçbiri çalışmazdı): ağ düzeyinde "başarısızlık oyu"
         * alırlar. Bir yöntem farklı hedeflerde [SKIP_AT] kez başarısız olup hiç kazanmadıysa [next] onu atlar (her denemesi saniyeler
         * sürer); oylar zamanla söner, böylece ağ değişirse yöntem yeniden denenir.
         */
        @Synchronized fun worked(key: String, kind: Int, plan: Int, tried: Int = 0, latencyMs: Long = -1L) {
            ok[okKey(key, kind)] = plan
            val v = votes[kind]
            val f = fails[kind]
            for (i in v.indices) { v[i] *= 0.95; f[i] *= 0.97 }
            v[plan.coerceIn(0, 15)] += 1.0
            f[plan.coerceIn(0, 15)] *= 0.3
            for (i in 0 until 16) if (i != plan && tried and (1 shl i) != 0) { f[i] += 1.0; failN[kind][i]++ }
            if (plan in 0 until 16) {
                winN[kind][plan]++
                if (latencyMs in 1..30_000L) { val l = lat[kind]; l[plan] = if (l[plan] == 0.0) latencyMs.toDouble() else l[plan] * 0.8 + latencyMs * 0.2 }
            }
        }
        // Yöntem başına ölçümler (kalıcı değil): toplam kazanç / başarısız deneme sayısı ve ilk cevaba kadar geçen süre (üstel ortalama, ms).
        private val winN = Array(3) { IntArray(16) }
        private val failN = Array(3) { IntArray(16) }
        private val lat = Array(3) { DoubleArray(16) }

        /** Bu ağdaki yöntem tablosu: tanılama raporu ve günlük için. Yalnızca denenmiş yöntemler. */
        class MethodStat(val kind: Int, val plan: Int, val wins: Int, val fails: Int, val avgMs: Int, val demoted: Boolean)

        @Synchronized fun methodStats(): List<MethodStat> {
            val out = ArrayList<MethodStat>()
            for (kind in intArrayOf(TLS, HTTP)) {
                val n = if (kind == TLS) TLS_PLANS else HTTP_PLANS
                for (i in 0 until n) if (winN[kind][i] + failN[kind][i] > 0) out += MethodStat(kind, i, winN[kind][i], failN[kind][i], lat[kind][i].toInt(), demoted(kind, i))
            }
            return out
        }
        private val fails = Array(3) { DoubleArray(16) }          // [tür][yöntem]: ağ düzeyinde başarısızlık oyları

        /** Bu ağda [plan] art arda başarısız, hiç kazanmayan bir yöntem mi (atlanmalı)? */
        @Synchronized fun demoted(kind: Int, plan: Int): Boolean {
            if (plan !in 0 until 16) return false
            return fails[kind][plan] >= SKIP_AT && fails[kind][plan] > votes[kind][plan] * 2.0
        }
        /** Bir site için tüm yöntemler tükendi: öğrenilmiş (artık çalışmayan) yöntem, sonraki bağlantıyı da aynı yerden başlatmasın. */
        @Synchronized fun failed(key: String, kind: Int = -1) {
            if (kind != HTTP) ok.remove(okKey(key, TLS))
            if (kind != TLS) ok.remove(okKey(key, HTTP))
        }

        /** Site belleğini dışa/içe aktarır (anahtar = [siteKey], ad açık yazılmaz). İçe aktarma yalnızca eksikleri doldurur: canlı öğrenilen önce gelir. */
        @Synchronized fun siteExport(): Map<String, Int> = LinkedHashMap(ok)
        @Synchronized fun siteImport(m: Map<String, Int>) {
            for ((k, v) in m) if (v in 0 until TLS_PLANS && !ok.containsKey(k)) ok[k] = v          // kalıcı bellek yalnızca TLS yöntemi tutar; bozuk değer alınmaz
        }

        /**
         * "Tükendi" belleği: bir hedefte TÜM yöntemler denendi ve hiçbiri işe yaramadı (DPI değil sunucu/ağ sorunu olabilir ya da
         * hiçbir yöntem yetmiyor). [EXHAUST_MS] boyunca bu hedefe yeni bağlantılar 11 yöntemi yeniden gezmez (her biri
         * saniyeler sürer); düz, bölünmeden bağlanır ve süre dolunca yöntemler yeniden denenir.
         */
        private val spent = object : LinkedHashMap<String, Long>(16, 0.75f, false) {
            override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Long>?) = size > 256
        }
        @Synchronized fun exhaust(key: String, now: Long, kind: Int = TLS) { val k = mk(key, kind); spent.remove(k); spent[k] = now + EXHAUST_MS }
        @Synchronized fun isExhausted(key: String, now: Long, kind: Int = TLS): Boolean {
            val k = mk(key, kind)
            val until = spent[k] ?: return false
            if (now >= until) { spent.remove(k); return false }
            return true
        }

        /**
         * Kesinti belleği: bağlantı kurulduktan sonra kesilen (bkz. [CutWatch]) hedefler. Tek belirti yetmez (yavaş ağ, kapanan canlı
         * tutma bağlantısı ve uzun bekleyen istek de benzer görünür): [CUT_NEED] puana ulaşılınca (kayıt ortasında susma 2, sıfırlama
         * ve cevapsızlık 1, [CUT_WINDOW_MS] içinde) o hedefin öğrenilmiş yöntemi SIRADAKİNE geçer; bir sonraki bağlantı onu dener.
         * Sırada yöntem kalmadıysa hiçbir şey değişmez. Dönüş: yöntem değiştiyse yeni yöntem, değişmediyse -1.
         */
        private val cuts = object : LinkedHashMap<String, LongArray>(16, 0.75f, false) {
            override fun removeEldestEntry(e: MutableMap.MutableEntry<String, LongArray>?) = size > 256
        }
        @Synchronized fun cut(key: String, kind: Int, plan: Int, weight: Int, now: Long): Int {
            if (plan < 0) return -1
            val ck = mk(key, kind)
            val e = cuts.remove(ck)?.takeIf { now - it[1] <= CUT_WINDOW_MS } ?: longArrayOf(0L, now)
            e[0] += weight.toLong()
            if (e[0] < CUT_NEED) { cuts[ck] = e; return -1 }
            val nxt = next(kind, plan)
            if (nxt < 0) { cuts[ck] = longArrayOf(0L, now); return -1 }
            ok[okKey(key, kind)] = nxt
            return nxt
        }

        @Synchronized fun forget() { for (f in fails) f.fill(0.0); for (a in winN) a.fill(0); for (a in failN) a.fill(0); for (a in lat) a.fill(0.0); ok.clear(); spent.clear(); cuts.clear(); for (v in votes) v.fill(0.0); rtt = 0.0; est.reset(); seedTls = -1; seedHttp = -1 }

        /** Bağlantıda yedek (ikinci) denemenin başlama gecikmesi, bu ağın ölçülen bağlantı süresinden ([MobilePolicy.connectHedgeMs]). */
        fun hedgeMs(): Long = MobilePolicy.connectHedgeMs(est, slow)

        /** Bağlantı kurma süresi (ms) örneği; üstel ortalama. */
        @Synchronized fun noteRtt(ms: Long) { val x = ms.coerceIn(1, 3000).toDouble(); rtt = if (rtt == 0.0) x else rtt * 0.8 + x * 0.2; est.sample(x) }

        /** Yanıt gelmezse yeniden denemeden önce beklenecek süre: yavaş ağda uzun, hızlı ağda kısa (eski sabit: TLS 2000 / HTTP 5000 ms). */
        @Synchronized fun waitMs(kind: Int): Long {
            val r = rtt
            if (slow) return if (kind == TLS) (if (r == 0.0) 2200L else (6 * r + 800).toLong().coerceIn(1500L, 3000L))
            else (if (r == 0.0) 4000L else (8 * r + 1500).toLong().coerceIn(2500L, 6000L))
            return if (kind == TLS) (if (r == 0.0) 1500L else (4 * r + 500).toLong().coerceIn(900L, 2000L))
            else (if (r == 0.0) 3000L else (6 * r + 1000).toLong().coerceIn(1500L, 5000L))
        }

        fun next(kind: Int, plan: Int): Int {
            if (kind == TLS) {
                var i = TLS_ORDER.indexOf(plan)
                if (i < 0) return -1
                while (++i < TLS_ORDER.size) if (!demoted(kind, TLS_ORDER[i])) return TLS_ORDER[i]
                return -1
            }
            var n = plan + 1
            while (n < HTTP_PLANS) { if (!demoted(kind, n)) return n; n++ }
            return -1
        }
    }
}
