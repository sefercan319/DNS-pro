package app.dnshizli.core

import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * QUIC v1 (RFC 9000/9001) istemci Initial paketini çözer, SNI'ya göre yeniden kurar ve yeniden şifreler.
 *
 * Initial paketlerin anahtarları gizli değildir: yalnızca paketin kendi hedef bağlantı kimliğinden (DCID) türer (RFC 9001 §5.2). Bu yüzden
 * DPI cihazları da paketi çözüp SNI'yı okur. Burada aynısını biz yaparız ve iki şey üretiriz:
 *  - [reorder]: ClientHello'yu taşıyan CRYPTO çerçevesi SNI'nın ortasından ikiye bölünür ve çerçeveler TERS sırayla yazılır (RFC 9000 §19.6:
 *    sunucu offset'e göre birleştirir, sıra önemsizdir). Çerçeveleri sırayla okuyan basit DPI SNI'yı bütün göremez. Paket numarası, boyut
 *    ve sayı AYNI kalır; yeni paket numarası/ACK sorunu yoktur.
 *  - [fake]: aynı paketin SNI'sı aynı uzunlukta başka bir adla değiştirilmiş kopyası (düşük TTL'le gönderilir, bkz. Gateway).
 * Çözülemeyen / ilgisiz her pakette null döner ve paket olduğu gibi gider.
 */
object QuicInitial {
    private val SALT_V1 = hex("38762cf7f55934b34d179ae6a4c80cadccbb7f0a")

    private fun hex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    internal fun hmac(key: ByteArray, data: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA256"); m.init(SecretKeySpec(key, "HmacSHA256")); return m.doFinal(data)
    }

    /** HKDF-Expand-Label (RFC 8446 §7.1), bağlam boş. */
    fun expandLabel(secret: ByteArray, label: String, len: Int): ByteArray = expandLabel(secret, label, ByteArray(0), len)

    /** Bağlamlı (ör. döküm özeti) HKDF-Expand-Label; [len] en çok 32 (tek HMAC bloğu). */
    fun expandLabel(secret: ByteArray, label: String, context: ByteArray, len: Int): ByteArray {
        val full = "tls13 $label".toByteArray(Charsets.ISO_8859_1)
        val info = ByteArray(2 + 1 + full.size + 1 + context.size)
        info[0] = (len shr 8).toByte(); info[1] = len.toByte(); info[2] = full.size.toByte()
        System.arraycopy(full, 0, info, 3, full.size)
        info[3 + full.size] = context.size.toByte()
        System.arraycopy(context, 0, info, 4 + full.size, context.size)
        // HKDF-Expand tek blok: T(1) = HMAC(secret, info || 0x01); en çok 32 bayt istenir
        val t = hmac(secret, info + byteArrayOf(1))
        return t.copyOf(len)
    }

    class Keys(val key: ByteArray, val iv: ByteArray, val hp: ByteArray)

    /** İstemci Initial anahtarları (RFC 9001 §5.2). */
    fun clientKeys(dcid: ByteArray): Keys {
        val initial = hmac(SALT_V1, dcid)                                 // HKDF-Extract
        val cs = expandLabel(initial, "client in", 32)
        return Keys(expandLabel(cs, "quic key", 16), expandLabel(cs, "quic iv", 12), expandLabel(cs, "quic hp", 16))
    }

    internal fun aesEcb(key: ByteArray, block: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/ECB/NoPadding"); c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES")); return c.doFinal(block)
    }

    internal fun gcm(mode: Int, k: Keys, pn: Long, aad: ByteArray, data: ByteArray, off: Int, len: Int): ByteArray {
        val nonce = k.iv.copyOf()
        for (i in 0 until 8) nonce[11 - i] = (nonce[11 - i].toInt() xor ((pn ushr (8 * i)) and 0xFF).toInt()).toByte()
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(mode, SecretKeySpec(k.key, "AES"), GCMParameterSpec(128, nonce))
        c.updateAAD(aad)
        return c.doFinal(data, off, len)
    }

    // ---- değişken uzunluklu tamsayı (RFC 9000 §16)
    internal fun varLen(first: Int) = 1 shl (first ushr 6)
    internal fun readVar(b: ByteArray, p: Int, end: Int): Long {
        if (p >= end) return -1
        val n = varLen(b[p].toInt() and 0xFF)
        if (p + n > end) return -1
        var v = (b[p].toLong() and 0x3F)
        for (i in 1 until n) v = (v shl 8) or (b[p + i].toLong() and 0xFF)
        return v
    }

    class Pkt(
        val dcid: ByteArray, val keys: Keys,
        /** Başlığın (paket numarası dahil) çözülmüş hâli. */
        val header: ByteArray, val pnOff: Int, val pnLen: Int, val pn: Long,
        /** Paketin şifresiz yükü (çerçeveler). */
        val plain: ByteArray,
        /** Paketin datagram içindeki toplam uzunluğu (başlık + şifreli yük + etiket). */
        val total: Int,
    )

    /** [b]'nin [off]'undaki datagramın ilk paketi bir QUIC v1 istemci Initial'ı mı? Çözer; değilse null. Hata fırlatmaz. */
    fun parse(b: ByteArray, off: Int, len: Int): Pkt? = try { parse0(b, off, len) } catch (_: Exception) { null }

    private fun parse0(b: ByteArray, off: Int, len: Int): Pkt? {
        val end = off + len
        if (len < 1200) return null
        val f0 = b[off].toInt() and 0xFF
        if (f0 and 0xC0 != 0xC0 || (f0 and 0x30) != 0) return null                // uzun başlık, tür 0 = Initial
        if (off + 6 > end) return null
        val ver = ((b[off + 1].toInt() and 0xFF) shl 24) or ((b[off + 2].toInt() and 0xFF) shl 16) or ((b[off + 3].toInt() and 0xFF) shl 8) or (b[off + 4].toInt() and 0xFF)
        if (ver != 1) return null
        var p = off + 5
        val dl = b[p++].toInt() and 0xFF
        if (dl < 8 || dl > 20 || p + dl > end) return null                         // istemci ilk DCID'si en az 8 bayt (RFC 9000 §7.2)
        val dcid = b.copyOfRange(p, p + dl); p += dl
        val sl = b[p++].toInt() and 0xFF
        if (sl > 20 || p + sl > end) return null
        p += sl
        val tl = readVar(b, p, end); if (tl < 0) return null
        p += varLen(b[p].toInt() and 0xFF)
        if (tl != 0L) return null                                                  // istemci ilk Initial'ında belirteç olmaz (Retry sonrası olur: dokunma)
        val pl = readVar(b, p, end); if (pl < 0) return null
        p += varLen(b[p].toInt() and 0xFF)
        if (pl < 20 || p + pl > end) return null
        val pnOff = p
        val keys = clientKeys(dcid)
        val sample = aesEcb(keys.hp, b.copyOfRange(pnOff + 4, pnOff + 20))
        val first = f0 xor (sample[0].toInt() and 0x0F)
        val pnLen = (first and 3) + 1
        var pn = 0L
        val hdr = b.copyOfRange(off, pnOff + pnLen)
        hdr[0] = first.toByte()
        for (i in 0 until pnLen) {
            val x = (b[pnOff + i].toInt() xor sample[1 + i].toInt()) and 0xFF
            hdr[pnOff - off + i] = x.toByte()
            pn = (pn shl 8) or x.toLong()
        }
        val ctLen = pl.toInt() - pnLen
        if (ctLen < 16) return null
        val plain = gcm(Cipher.DECRYPT_MODE, keys, pn, hdr, b, pnOff + pnLen, ctLen)
        return Pkt(dcid, keys, hdr, pnOff - off, pnLen, pn, plain, (pnOff - off) + pl.toInt())
    }

    /** Şifresiz yükü çerçevelere ayırır: yalnızca PADDING, PING ve CRYPTO kabul edilir; başka çerçeve varsa null. */
    class Crypto(val offset: Int, val data: ByteArray)

    fun frames(plain: ByteArray): List<Crypto>? {
        val out = ArrayList<Crypto>()
        var p = 0
        while (p < plain.size) {
            when (plain[p].toInt() and 0xFF) {
                0x00, 0x01 -> p++
                0x06 -> {
                    p++
                    val o = readVar(plain, p, plain.size); if (o < 0) return null; p += varLen(plain[p].toInt() and 0xFF)
                    val l = readVar(plain, p, plain.size); if (l < 0) return null; p += varLen(plain[p].toInt() and 0xFF)
                    if (o > 100_000 || l > plain.size - p) return null
                    out.add(Crypto(o.toInt(), plain.copyOfRange(p, p + l.toInt()))); p += l.toInt()
                }
                else -> return null
            }
        }
        return out
    }

    /** CRYPTO parçalarını 0'dan kesintisiz birleştirir; boşluk ya da çakışan farklı baytlar varsa null. */
    fun assemble(fr: List<Crypto>): ByteArray? {
        if (fr.isEmpty()) return null
        var end = 0
        for (c in fr.sortedBy { it.offset }) {
            if (c.offset > end) return null
            end = maxOf(end, c.offset + c.data.size)
        }
        val d = ByteArray(end)
        val have = BooleanArray(end)
        for (c in fr) for (i in c.data.indices) {
            val at = c.offset + i
            // Çakışan baytlar birbirini tutmalı. Farklıysa sunucunun hangisini seçeceği bilinemez (ilk gelen mi, son gelen mi): "benign" adı
            // son çerçeveye, gerçek adı ilkine koyan istemci denetimi atlatırdı. Belirsiz → null; çağıran QUIC akışını düşürür.
            if (have[at]) { if (d[at] != c.data[i]) return null } else { d[at] = c.data[i]; have[at] = true }
        }
        return d
    }

    /** ClientHello'daki (el sıkışma iletisi, kayıt başlığı yok) SNI konumu: (konum, uzunluk) ya da null. */
    fun sni(hello: ByteArray): IntArray? {
        if (hello.size < 40 || hello[0].toInt() != 1) return null
        val rec = ByteArray(5 + hello.size)
        rec[0] = 0x16; rec[1] = 3; rec[2] = 1; rec[3] = (hello.size shr 8).toByte(); rec[4] = hello.size.toByte()
        System.arraycopy(hello, 0, rec, 5, hello.size)
        val h = Dpi.Hello()
        if (!Dpi.parseHello(rec, rec.size, h) || h.sniOff < 5 || h.sniLen <= 0) return null
        return intArrayOf(h.sniOff - 5, h.sniLen)
    }

    private fun putVar2(o: java.io.ByteArrayOutputStream, v: Int) { o.write(0x40 or (v shr 8)); o.write(v and 0xFF) }

    private fun crypto(o: java.io.ByteArrayOutputStream, off: Int, d: ByteArray, from: Int, to: Int) {
        o.write(0x06); putVar2(o, off + from); putVar2(o, to - from); o.write(d, from, to - from)
    }

    /** Verilen şifresiz yükle paketi (aynı başlık, aynı paket numarası) şifreler ve başlığı korur. Datagramın kalanı eklenir. */
    private fun seal(pk: Pkt, plain: ByteArray, tail: ByteArray?): ByteArray {
        val hdr = pk.header
        val ct = gcm(Cipher.ENCRYPT_MODE, pk.keys, pk.pn, hdr, plain, 0, plain.size)
        val pnOff = pk.pnOff
        val out = ByteArray(hdr.size + ct.size + (tail?.size ?: 0))
        System.arraycopy(hdr, 0, out, 0, hdr.size)
        System.arraycopy(ct, 0, out, hdr.size, ct.size)
        if (tail != null) System.arraycopy(tail, 0, out, hdr.size + ct.size, tail.size)
        val sample = aesEcb(pk.keys.hp, out.copyOfRange(pnOff + 4, pnOff + 20))
        out[0] = (out[0].toInt() xor (sample[0].toInt() and 0x0F)).toByte()
        for (i in 0 until pk.pnLen) out[pnOff + i] = (out[pnOff + i].toInt() xor sample[1 + i].toInt()).toByte()
        return out
    }

    private fun tailOf(b: ByteArray, off: Int, len: Int, pk: Pkt): ByteArray? =
        if (pk.total < len) b.copyOfRange(off + pk.total, off + len) else null

    /** Her iki dönüşüm için ortak kısım: ClientHello'yu ve SNI'yı bulur. */
    private class Ctx(val pk: Pkt, val hello: ByteArray, val sni: IntArray, val tail: ByteArray?)

    private fun ctx(b: ByteArray, off: Int, len: Int): Ctx? {
        val pk = parse(b, off, len) ?: return null
        val fr = frames(pk.plain) ?: return null
        val hello = assemble(fr) ?: return null
        val s = sni(hello) ?: return null
        return Ctx(pk, hello, s, tailOf(b, off, len, pk))
    }

    /**
     * ClientHello'yu SNI'nın ortasından iki CRYPTO çerçevesine böler ve çerçeveleri TERS sırayla yazar. Datagram boyutu değişmez.
     * ClientHello bu pakete sığmıyorsa (ikinci Initial'a taşıyorsa), SNI burada yoksa ya da yer yetmiyorsa null.
     */
    fun reorder(b: ByteArray, off: Int, len: Int): ByteArray? = try {
        val c = ctx(b, off, len)
        if (c == null) null else {
            val cut = (c.sni[0] + c.sni[1] / 2).coerceIn(1, c.hello.size - 1)
            val o = java.io.ByteArrayOutputStream(c.pk.plain.size)
            crypto(o, 0, c.hello, cut, c.hello.size)      // ikinci yarı önce
            crypto(o, 0, c.hello, 0, cut)                 // ilk yarı sonra
            val used = o.size()
            if (used > c.pk.plain.size) null else {
                val plain = ByteArray(c.pk.plain.size)
                System.arraycopy(o.toByteArray(), 0, plain, 0, used)        // kalanı 0 = PADDING
                seal(c.pk, plain, c.tail)
            }
        }
    } catch (_: Exception) { null }

    /**
     * QUIC v1 istemci Initial'ından (şifreli ama anahtarları paket başlığındaki DCID'den türetilebilir) SNI adını okur.
     * Adın tamamı bu pakette değilse (ClientHello ikinci Initial'a taşmışsa), biçim tanınmıyorsa ya da ad yoksa null.
     */
    fun peekSni(b: ByteArray, off: Int, len: Int): String? = try {
        val c = ctx(b, off, len)
        if (c == null) null else String(c.hello, c.sni[0], c.sni[1], Charsets.ISO_8859_1).lowercase()
    } catch (_: Exception) { null }

    /** Aynı paketin, SNI'sı aynı uzunlukta bir iana.org alt alanıyla değiştirilmiş kopyası (şifreli, aynı boyutta); yapılamazsa null. */
    fun fake(b: ByteArray, off: Int, len: Int): ByteArray? = try {
        val c = ctx(b, off, len)
        if (c == null) null else {
            val h = Dpi.fakeHello(c.hello, c.sni[0], c.sni[1])
            val o = java.io.ByteArrayOutputStream(c.pk.plain.size)
            crypto(o, 0, h, 0, h.size)
            if (o.size() > c.pk.plain.size) null else {
                val plain = ByteArray(c.pk.plain.size)
                System.arraycopy(o.toByteArray(), 0, plain, 0, o.size())
                seal(c.pk, plain, c.tail)
            }
        }
    } catch (_: Exception) { null }
}
