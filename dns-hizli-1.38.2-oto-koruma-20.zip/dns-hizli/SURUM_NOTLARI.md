# Sürüm notları

Ayrıntılı geliştirme tarihçesi ve kararlar: [DNS_HIZLI_TARIHCE.txt](DNS_HIZLI_TARIHCE.txt). En yeni sürüm en üstte.

## 1.38.2 oto-koruma 12–16 (ara düzeltmeler, sürüm numarası değişmedi)

- **Reklam engeli (Sıkı):** birinci taraf gibi görünen reklam/izleme alt alan adları ("ads.site.com", "tracking.site.net", "telemetry.", "smetrics." vb.) listelerde olmasa da engellenir. Yalnızca kayıtlı adın önündeki etiketlere bakılır ("ads.com" gibi iki etiketli adlar ve "stats", "click", "push" gibi geniş sözcükler kapsam dışıdır). Kullanıcının izin listesi önce gelir.
- **Süzgeç kendini onarma:** liste dosyaları okunamayıp yedek (listesiz) motor devreye girdiyse engelleme artık sonsuza dek kapalı kalmaz; 3 hızlı denemeden sonra da 5 dakikada bir yeniden denenir.
- **DNS sızıntı kalkanı:** DNS modunda bilinen herkese açık çözümleyici adresleri (8.8.8.8, 1.1.1.1 …) tünele alınır: sabit sunucuya soran uygulamanın düz DNS'i şifreli DNS'e gider, DoH/DoT bağlantıları reddedilir ("DoH koruması" ayarına bağlı).
- **DPI vanası:** DPI atlatma ağdaki TLS el sıkışmalarını bozuyorsa (bağlantılar açılıyor ama hiçbir el sıkışma tamamlanmıyor) yalnızca DPI otomatik kapatılır; Reklam+ ve DNS sürer. 5/15/45/60 dk ile yeniden denenir. Önceki vana yalnızca "hiçbir bağlantı açılmıyor" durumuna bakıyordu.
- **İmzalı yayın APK'sı:** `anahtar-uret.yml` kendi anahtarını üretir, `release.yml` artık imzalı APK da çıkarır (itch.io için). Debug APK herkese açık anahtarla imzalıdır, mağaza dışında dağıtılmamalıdır.
- Güvenlik ve kararlılık: IPv6 uzantılı TCP/53, NAT64/IPv4-eşlenmiş DoH adresleri, TLS saat/sertifika ayrımı, ayar kodu içe aktarma uyarıları, Immune çakışma ve saat geri sarması, HTTP/2 sessiz kopma, QUIC yeniden gönderim, tanılama maskesi, yalnızca-DPI/Reklam+ kipinde kutucuk/widget.

## 1.38.2 (versionCode 59)

**İkinci tur denetim: engelli ağda QUIC beklemesi, akış sınırı, pil, ek sertleştirme**

> Dürüst not: JVM testleriyle (10605 kontrol, 0 başarısız) ve yerel aioquic sunucusuyla sınandı; Android kaynakları ayrıca saplama (stub) kitaplığıyla derlendi. Samsung A34 / Xiaomi 17T'de, gerçek operatörde, gerçek DNS sağlayıcılarında, Gradle ile derlemede DENENMEDİ. Somut bir hata tarifi gelmediği için bu tur da kod taraması: bulunanlar aşağıdadır, bu turda 1.38.1'e göre çok daha az kusur çıktı.

- **UDP'nin engelli olduğu ağda DoQ/DoH3 her bağlanışta ~10 sn bekletiyordu.** QUIC artık yedek yöntem varken tek denemeyle, 2,5 sn'lik yoklamayla denenir; başarısız olursa 10 dk atlanır (ağ değişince sıfırlanır). Yeni sınıf: `QuicBackoff`.
- **QUIC bağlantısında sunucunun akış sınırı dolunca** (yaklaşık 100 sorgu) bağlantı sunucu hatası sayılıyordu; artık bağlantı baştan, sessizce yenilenir.
- **Boşta QUIC bağlantısı saniyede ~66 kez uyanıp pil yiyordu**; boştayken 250 ms'de bir uyanır, havada paket varken eski sıklıkta çalışır (yeniden gönderim zamanlayıcısını bekleyen istek de sürer).
- El sıkışma iletilerinde (TLS) bozuk alan artık beklenmeyen bir istisna değil, kontrollü bağlantı hatasıdır.
- Rastgele girdi (fuzz) testleri: kurulu bağlantıya bozuk TCP segmentleri (ağ geçidi), yetkili ama rastgele QUIC çerçeveleri, rastgele datagramlar, rastgele TLS iletileri.
- Gözden geçirilip değişiklik gerektirmeyenler: manifest ve ağ güvenliği yapılandırması, BootReceiver / ActionReceiver / intent işleme, liste güncelleme ve depolama, DNS önbelleği, CrashLog, CutWatch, UdpDecoy, ağ geçidinin TCP durum makinesi.

*Testler:* 10587 → 10605.

## 1.38.1 (versionCode 58)

**Güvenlik sertleştirmesi (QUIC/TLS, sahte paket, ağ geçidi) ve yeni özelliklerdeki hatalar**

> Dürüst not: JVM testleriyle (10587 kontrol, 0 başarısız) ve yerel aioquic sunucusuyla sınandı. Samsung A34 / Xiaomi 17T'de, gerçek operatörde, gerçek DNS sağlayıcılarında, Gradle ile derlemede DENENMEDİ. "Bozuk" özellikler için somut bir hata tarifi gelmediği için kod baştan okundu; aşağıdakiler bulunanlardır, cihazda görülen bir hata başka olabilir.

*Güvenlik* (ayrıntı: GUVENLIK_INCELEMESI.md, "Ek inceleme 1.38.1")
- **QUIC'te yol üstü saldırgan DoQ/DoH3 cevabını değiştirebilirdi** (herkesçe türetilebilen Initial anahtarıyla sahte STREAM çerçevesi): Initial/Handshake paketlerinde yalnızca izinli çerçeveler kabul edilir, bu anahtarlar zamanında atılır.
- Doğrulanmamış sürüm pazarlığı/Retry bağlantıyı düşüremez (kimlik yansıması, v1 denetimi, Retry bütünlük etiketi).
- Sıra dışı CRYPTO/STREAM tamponları, çerçeve uzunluğu taşması (sonsuz döngü), ACK aralığı CPU yükü sınırlandı; sahte datagram bağlantıyı canlı tutamaz; kısa başlık/sunucu kimliği/eski paket numarası denetimleri.
- Joker sertifika `*.com` eşleşmez; ServerHello sıkıştırma/sürüm denetimi; QUIC sertifika hataları güven hatası sayılır.
- Sahte ClientHello sayfa dosyası tünel kapanınca sıfırlanıp silinir (gerçek SNI'lar diskte kalmaz).

*Hatalar*
- **Ağ geçidi UDP akış sayacı** açılamayan akışlarda eksiye kayıyor, 400 akış sınırını işlevsiz bırakıyordu; TCP akış sayacı çift düşüşe karşı korundu.
- **DoH3**: 126 bayttan uzun yol/yetki değerleri bozuk kodlanıyordu.
- **Bayat QUIC bağlantısı**: sunucunun sessizce attığı boşta bağlantıya yazılan ilk soru cevap süresi dolana dek bekliyordu; 20 sn sessiz ya da kopmuş bağlantı artık yeniden kurulur.
- Zaman aşımına uğrayan QUIC akışı tabloda kalıyordu (sızıntı).

*Testler:* 10565 → 10587 (saldırgan sunucu senaryoları: sahte sürüm pazarlığı/Retry, Initial'da yasak çerçeveler, şişirme ve taşma girdileri; sayaç; bayat bağlantı; uzun QPACK değeri; QUIC güven hatası sayacı).

*Bilinen sınırlar:* 1.38.0'dakiler geçerlidir (Retry/0-RTT/anahtar güncelleme yok; çift paketli Chrome ClientHello'sunda QUIC bölme uygulanmaz). Sahte paket yöntemleri (TCP yöntem 12, UDP/QUIC sahte Initial) düşük TTL'e güvenir.

## 1.38.0 (versionCode 57)

**QUIC: DNS-over-QUIC (DoQ), DNS-over-HTTP/3 (DoH3) ve QUIC Initial paketini DPI'a karşı yeniden kurma**

> Dürüst not: JVM testleriyle (10565 kontrol, 0 başarısız) ve gerçek bir QUIC sunucusuyla (aioquic, yerel döngü) sınandı. Gerçek DNS sağlayıcılarında, Samsung A34 / Xiaomi 17T'de, gerçek operatörde, Gradle ile derlemede DENENMEDİ. Katalogdaki QUIC bayrakları sağlayıcıların belgelerinden alındı, doğrulanmadı.

*Eklenenler*
- **Saf Kotlin QUIC v1 istemcisi** (`QuicClient`, `QuicTls`, `QuicInitial`): TLS 1.3 (x25519, AES-128-GCM; RSA-PSS ve ECDSA imzaları), Initial/Handshake/1-RTT paket ve başlık koruması, ACK, akış birleştirme, akış denetimi, kayıp telafisi (yeniden gönderim), sertifika zinciri + SAN ad denetimi + CertificateVerify + Finished. Yapılmayanlar: Retry, 0-RTT, anahtar güncelleme, bağlantı taşıma.
- **DoQ (RFC 9250)** ve **DoH3** (`Http3Client`, QPACK yalnızca statik tablo): `SecureForwarder` içinde `Proto.DOQ` / `Proto.DOH3`. DNS ayarlarında "QUIC ile DNS'i dene (deneysel)" anahtarı (varsayılan kapalı): açıkken destekleyen sunucuda önce DoQ/DoH3 denenir, UDP engelliyse DoT/DoH'a düşülür. Katalog: AdGuard, Cloudflare, Google, NextDNS, Control D.
- **QUIC Initial yeniden kurma** (Bağlantı ve uygulamalar > "QUIC Initial'ı değiştir"): istemcinin ilk Initial paketi çözülür (anahtarlar yalnızca DCID'den türer), ClientHello CRYPTO çerçeveleri SNI'nın ortasından ikiye bölünüp ters sırada yazılır (paket numarası/boyut aynı), önce düşük TTL'li sahte Initial (SNI iana.org alt alanı) gider. QUIC'i engelleme kapalıyken ve DPI açıkken çalışır.
- **Test düzeneği:** `selftest/quic/` (aioquic sunucusu, sertifika üretici, kayıplı UDP aktarıcı). python3 + aioquic yoksa yalnızca birlikte çalışma testleri atlanır; CI'da sürüm sabitlenerek kurulur. Rastgele paket kaybında (%20) bağlantı ve sorgular sınandı.

*Çapraz doğrulama:* QUIC Initial anahtarları RFC 9001 A.1 değerleriyle, paket biçimi bağımsız bir Python uygulamasıyla (iki yönde) doğrulandı.

*Bilinen sınırlar:* Retry gönderen sunucuya bağlanılamaz (hata ile düşülür); sunucu anahtar güncellemesi yapınca bağlantı yenilenir; DoQ/DoH3 her şerit için ayrı bağlantıdır; Android'de VpnService.protect UDP yuvasında denenmedi; QUIC Initial'da çift paketli (Kyber) ClientHello değiştirilmez (SNI ilk pakette değilse dokunulmaz).

## 1.37.0 (versionCode 56)

**Yeni DPI yöntemi 12: sahte ClientHello (ByeDPI "fake" tekniği, ham yuva olmadan)**

> Dürüst not: yalnızca JVM testleriyle sınandı (10565 kontrol, 0 başarısız). Bu yöntem çekirdeğin davranışına dayanır; gerçek cihazda, gerçek operatörde, Gradle ile derlemede DENENMEDİ. Başarısız olursa planlayıcı yöntemi eler (en son sırada).

*Nasıl çalışır*
- SNI'yı içeren ilk parçanın SNI'sı aynı uzunlukta bir iana.org alt alanıyla değiştirilir (sahte kopya).
- TTL 8'e düşürülür; sahte kopya `Os.sendfile` ile (bir dosya sayfasından, kopyalamadan) yuvaya verilir; DPI görür, sunucuya varmadan ölür. TTL hemen 64'e döner.
- Sayfa GERÇEK baytlarla ezilir. Sunucu hiçbir şey onaylamadığından çekirdek aynı sıra numaralarını yeniden iletir ve bu kez gerçek veri gider; DPI bunu "zaten gördüğüm yeniden iletim" sayabilir.
- Güvenlik: TTL düşürülemezse ya da platform desteklemezse sahte HİÇ gönderilmez, düz bölmeye düşer. Sayfa her durumda (hata dahil) gerçekle ezilir.
- Sayaç: Günlükte "sahte ClientHello N". `platform/FakeSender.kt` (256 sayfalık halka, uygulama önbelleğinde).

*Bilinen riskler (cihazda sınanmadı)*: bazı sürücüler sayfayı kopyalarsa yeniden iletim sahte baytı taşır (bağlantı başarısız olur, yöntem elenir); TTL 8 bazı ağlarda DPI'a ulaşmayabilir ya da sunucuya ulaşabilir; her bağlantıya yeniden iletim süresi (yüzlerce ms) eklenir.

*Testler:* 10431 → 10565 (yöntem 12 bölme, sahte kopya biçimi, kısmi/tam/desteksiz/TTL'siz ağ geçidi senaryoları, plan belleği, rastgele girdi). Rastgele girdi testi başta bir taşma hatası yakaladı, düzeltildi.

## 1.36.0 (versionCode 55)

**Android 17+ için "ECH'ye izin ver" anahtarı (eski Android'de hiç görünmez)**

> Dürüst not: yalnızca JVM testleriyle sınandı (10565 kontrol, 0 başarısız). Android 17 cihazda, Gradle ile derlemede DENENMEDİ.

*Eklenenler*
- **ECH'ye izin ver (☰ > Bağlantı ve uygulamalar):** satır yalnızca cihazın Android sürümü 17 (API 37) ve üstüyse oluşur; 17'den düşükte hiç gösterilmez ve etkisi de yoktur. Açıkken Reklam+ HTTPS/SVCB (ECH yapılandırması) kayıtlarını silmez; Android 17 şifreli SNI'yi kendisi kullanır. Varsayılan kapalı. Bedeli: ECH'li sitede Gateway gerçek SNI'yi göremez, o sitede DPI yöntemleri SNI'ye göre çalışmaz.
- 10 yeni test; 12 dilde yenilikler girişi.

*Yapılmadı (yol haritasında)*: DoQ/DoH3, QUIC Initial bölme, MD5/NDK sahte paket, API 37 sınıflarıyla gerçek ECH erişim sınaması (compileSdk 36; cihaz ve sunucu gerekir).

## 1.35.0 (versionCode 54)

**Araştırmadan çıkan eksiklerin kod karşılığı olanlar: yeni TLS yöntemi, Discord/STUN sahte paketleri, DPI sayaçları günlükte**

> Dürüst not: yalnızca JVM testleriyle sınandı (10565 kontrol, 0 başarısız). Gerçek operatörde, Samsung A34 ve Xiaomi 17T'de, Gradle ile derlemede DENENMEDİ. Araştırma raporu (açık kaynak DPI/DNS/reklam engelleme projeleri) bizim kodu görmeden yazıldığı için önerilerinin bir kısmı zaten vardı; aşağıda hangisi hangisi ayrı yazıldı.

*Eklenenler*
- **TLS yöntemi 11 (kayıt sürüm baytı):** kayıt bölme + ikinci kaydın başlığındaki sürüm baytı (03 01 ↔ 03 03) değişik (ByeDPI `--tlsminor` fikri). Başlık sürümü RFC 8446'ya göre yok sayılır ve el sıkışma özetine girmez. Sıranın EN SONUNDA (katı sunucular reddedebilir; reddederse hedef zaten tükenmiş sayılır). Gerçek bir JSSE sunucusuyla el sıkışma testinden geçti. `Dpi.TLS_PLANS` 12.
- **Discord ses / STUN sahte paketleri (deneysel, varsayılan KAPALI):** ☰ > Bağlantı ve uygulamalar > "Ses/STUN sahte paketi". DPI açıkken Discord "IP keşfi" paketinden (74 bayt, UDP 50000-65535) ve STUN bağlama isteğinden (UDP 3478, 19302-19309) önce 4 rastgele paket, IP TTL=4 ile gider ve sunucuya varmadan ölür (UDP'de TTL gönderim anında okunur, ham soket gerekmez). TTL ayarlanamıyorsa HİÇ gönderilmez. Başka hiçbir UDP paketine dokunulmaz. Hangi TTL'in DPI'a ulaşıp sunucuya ulaşmadığı operatöre göre değişir: ⚠ gerçek ağda doğrulanmadı.
- **DPI sayaçları günlükte:** kesinti, yöntem değişimi, UDP sahte paket, atılan engel sayfası cevabı ve yeniden deneme sayısı değiştikçe günlüğe tek satır ("DPI: kesinti n, ..."). Telefonda "işe yarıyor mu" sorusu için: sayaç hiç artmıyorsa özellik tetiklenmiyor demektir.

*Araştırma önerilerinden ZATEN VAR olanlar (kodda doğrulandı)*
- Ağ türüne/operatöre göre ayrı yöntem belleği (`PlanMemory`, `Gateway.networkChanged`, kalıcı).
- Özel DNS (Private DNS) çakışma denetimi (`strictPrivateDns`, `PrivateDns`).
- İstemci alt ağı (ECS) bilgisi giden sorgularda sıfırlanır (`Packets.kt`).
- İmzalı liste güncellemesi (ECDSA P-256, `ListUpdater`).
- Uygulama bazında kapsam (`AppScope`: hepsi / yalnızca seçilenler / seçilenler hariç).
- HTTPS/SVCB (tür 65) kayıtları: engelli ad ve SVCB hedefi denetimi var; Reklam+ açıkken bilerek verilmez (ECH gerçek adı gizlerdi).
- Yavaş el sıkışma: yeniden deneme süresi ölçülen gecikmeye göre 0,9-3 sn; daha yavaş el sıkışma zaten sıradaki yönteme geçirir. Ayrıca "yavaşlatma" sayacı eklenmedi, çünkü bu yol onu kapsıyor.

*Eklenmeyenler ve nedeni*
- TCP_MD5SIG "sahte paket" (NDK, çekirdek/sandbox izni bilinmiyor): YOLHARITASI.md'de deneysel madde.
- DoQ / DoH3 (saf Kotlin'de QUIC yığını; Türkiye'de DoH'tan az engelli olduğuna kanıt yok), QUIC Initial CRYPTO bölme, yöntem zincirleme (planlayıcı yeniden tasarımı), kendi ECH/DoH erişim testi (Android 17 cihaz gerekir), paralel üst sunucu yarışı (gizlilik bedeli), NRD/DGA/HaGeZi listeleri ve joker biçime geçiş (liste verisi indirme ve lisans doğrulaması gerekir; bu ortamda ağ yok, HaGeZi/OISD lisansı doğrulanmadı, OISD GPL-3.0 olduğu için gömülmemeli).

- Metinler: 12 dilde 2 yeni metin, yeni ilk "Yenilikler" maddesi.
- Testler: 10404 → 10565 kontrol, 0 başarısız (UDP sahte paket: sunucuda 4 sahte + 1 gerçek, TTL 4 sonra 64, ayar kapalı / TTL ayarlanamıyor / parmak izi uymuyor durumları, STUN ayrıştırıcı; yöntem 11 bölme ve kalıcı bellek). Android 35 stub derlemesi temiz (R/BuildConfig zinciri hariç).

## 1.34.0 (versionCode 53)

**Bağlantı kurulduktan sonra kesilen siteleri algılama ve düz DNS'te sahte engel sayfası koruması**

> Dürüst not: Shroudly 2.5.6'nın (açık kaynak, MIT) kaynağını inceledim; aynı yaklaşımları Android'e uyarladım. Bunlar yalnızca JVM testleriyle sınandı (10404 kontrol, 0 başarısız); gerçek operatörde, Samsung A34 ve Xiaomi 17T'de, Gradle ile gerçek derlemede DENENMEDİ. Kesinti algılama sezgiseldir: yanlış alarm ihtimalini azaltmak için tek belirtide yöntem değiştirmez.

*Kesinti algılama (yeni: `core/CutWatch.kt`, `Dpi.Planner.cut`)*
- Bazı filtreler (İran, Rusya'nın 16 KB dondurması) el sıkışmayı geçirip veriyi keser; tarayıcıda boş sayfa olur, el sıkışma denetimi ise "başarı" görürdü. Artık bölme uygulanan TLS bağlantılarında sunucunun TLS kayıtları izlenir (yalnızca 5 baytlık başlıklar; içerik saklanmaz), ilk 64 KB boyunca:
  - **susma:** sunucu bir kaydın ORTASINDA 8 sn susar (puan 2),
  - **sıfırlama:** bekleyen iş varken bağlantı "Connection reset" ile kopar (puan 1); iş bittikten sonraki sıfırlama (canlı tutma kapanışı) sayılmaz,
  - **cevapsız:** en az 300 baytlık gerçek bir istek 15 sn cevapsız kalır (puan 1). Küçük yazmalar (el sıkışmanın istemci bitişi, tarayıcının önceden açtığı boşta bağlantılar) cevap beklemez, yoksa sahte alarm olurdu.
- 10 dk içinde toplam puan 3'e ulaşırsa o hedefin öğrenilmiş yöntemi SIRADAKİNE geçer; sonraki bağlantı onu dener. Sırada yöntem kalmadıysa hiçbir şey değişmez. Bellek 256 hedefle sınırlı. Mevcut bağlantıya dokunulmaz (kesilmez).
- `GwStats.cuts` ve `cutSwitched` sayar.

*Engel sayfası adresleri (yeni: `core/BlockPages.kt`)*
- Düz DNS (UDP/53) cevabının cevap bölümünde bilinen bir engel sayfası/sahte havuz adresi (Türkiye 195.175.254.2 ve 193.192.98.x, Çin'in enjekte havuzu ve toplam 21 ülkenin adresleri, 170 adres) varsa cevap atılır, bekleyen sorgu açık kalır; gerçek cevap (yarışı kaybeden asıl sunucu ya da yeniden deneme) gelirse o kabul edilir. Sahte cevap önbelleğe girmez ve istemciye verilmez. `Stats.blockPages` sayar.
- Bilerek listede YOK: ortak bulut adresleri (yarın gerçek siteye atanabilir; Shroudly'nin listesindeki tek Hetzner adresi de çıkarıldı) ve DNS süzme hizmetlerinin (AdGuard, OpenDNS, CleanBrowsing…) sayfaları: kullanıcı o hizmeti seçtiyse engelli saymak doğrudur.
- Şifreli DNS'te (DoT/DoH/ODoH) bakılmaz: cevabı ağ değiştiremez.
- Liste OONI verisine dayanır ve eskiyebilir; gerçek bir siteye ait bir adres listede kalırsa o site düz DNS'te açılmaz. Kaynak ve lisans: `app/src/main/assets/filter/KAYNAKLAR.txt` (Shroudly, MIT).

*Neden bunlar, neden başka şeyler değil*
- Shroudly'nin Linux'ta TCP_MD5SIG ile "sahte paket" hilesi ve ham paket gerektiren yöntemleri (bozuk sağlama toplamı, sahte RST'yi düşürme, gerçek `split-seqovl`) alınmadı: Android'de uygulama ham paket yazamaz, TCP_MD5SIG için yerel kod (NDK) gerekir ve çekirdek/sandbox izni bilinmiyor.
- Bizde zaten olanlar: TLS kayıt bölme, TTL=1 ile sırasız gönderim, OOB, `hOsT`, QUIC düşürme.

- Metinler: "Yenilikler" listesine 12 dilde yeni ilk madde.
- Testler: 10340 → 10404 kontrol, 0 başarısız (yeni `yeni134` grubu: izleyici, CutWatch, Planner.cut, BlockPages, düz DNS iletici ile yarış; gerçek soketli ağ geçidi testleri: kayıt ortasında susma, sıfırlama, cevapsız istek, sağlıklı bağlantıda alarm yok). Android 35 stub derlemesi: yalnızca üretilen R/BuildConfig zinciri.

## 1.33.0 (versionCode 52)

**Güvenlik sertleştirmesi, hata taraması ve 69 arayüz iyileştirmesi (Kişiselleştirme + diğer sekmeler)**

> Dürüst not: her şey yalnızca JVM testleriyle ve masaüstü önizlemesiyle sınandı (10340 kontrol, 0 başarısız). Gradle ile gerçek APK derlemesi ve gerçek cihaz (Samsung A34, Xiaomi 17T vb.) denemesi YAPILMADI. Düzeltme: sürüm derlemesinde küçültme (`isMinifyEnabled`, `isShrinkResources`, proguard) zaten açık; önceki "küçültme görünmüyor" ve Google Play özelliklerinin MB tahmini yanlış/kabaydı.

*Güvenlik (69'a dahil değil)*
- Yeni `core/TextSafe.kt`: dışarıdan gelen metinlerden (cihaz bilgisi, getprop, tanılama raporu) denetim, çift yönlü (bidi), sıfır genişlikli ve gizli karakterler temizlenir; boşluklar birleştirilir, uzunluk kısıtlanır, vekil çiftleri bölünmez.
- `DeviceProfiler.sanitize`: alan uzunlukları, en çok 64 özellik, sayısal alanlar (SDK, RAM, bellek, Hz) makul aralığa kırpılır. `parseProp` 400 karakterden uzun satırı reddeder, anahtar/değeri temizler.
- `DiagReport` gizli karakter temizliği ortak `TextSafe`'e bağlandı (tek doğru kaynak).
- Yeni `pzClosed` ayarı: bilinmeyen/bozuk değer okunurken temizlenir (`PzFolds.sanitize`), yerel anahtardır, dışa aktarılan dosyaya girmez.
- Ayar dosyası kodlayıcısına rastgele bozuk girdi taraması (`fuzz2`) ve yeni `audit` grubu varsayılan tam takıma eklendi; hata bulunmadı.

*Gerçek hatalar (düzeltildi)*
- Titreşimi olmayan cihazda "Titreşim gücü" satırı gösteriliyordu.
- Kaydırıcının erişilebilirlik adımı kayan noktadan kayıyordu; artık %5 ızgarasına oturur.
- Kişiselleştirme sayfasının koşullu satır imzası Int bit maskesiydi (31'den fazla koşulda taşardı); `Conds` sınıfına geçildi.
- Büyük yazı boyutunda segment, kaydırıcı, anahtar notu, bölüm başlığı ve üst başlık metinleri kesiliyordu.
- Her karede Bildirim izni sorgusu (binder çağrısı) yapılıyordu; önbelleğe alındı.
- İlk karede koşullu satırlar yanlış görünüp sonra zıplıyordu.
- `PzFolds.isClosed` her karede bellek ayırıyordu (kare başı 96 B sınırı).

*69 iyileştirme*

Ortak bileşenler (1–21)
1. Segment seçici dokunma yüksekliği 44 dp.
2. Çok seçenekli segment birden çok satıra bölünür.
3. Segment etiketleri sığacak şekilde küçülür.
4. Kaydırıcı başlığı/değeri sığmazsa kısaltılır.
5. Kaydırıcı erişilebilirlik adımı %5.
6. Kaydırıcı bırakılınca bir "onRelease" kancası çalışır.
7. Segmentte yalnızca seçim değişince çalışan "after" kancası.
8. Anahtar notları büyük yazıda 6 satıra kadar.
9. Bilgi satırına uzun basınca "başlık: değer" kopyalanır.
10. Bilgi satırı erişilebilirlikte ham değerin tamamını okur.
11. Bölüm başlığı 2 satıra kadar sarar.
12. Üst başlık büyük yazıda %62'ye kadar küçülür.
13. Katlanabilir başlık kapalıyken sağda özet gösterir.
14. Katlanabilir başlık 2 satıra sarar.
15. Katlanabilir başlık erişilebilirlikte açık/kapalı değeri ve uzun basma eylemi bildirir.
16. Başlığa uzun basınca tüm bölümler açılır/kapanır (bildirimle).
17. Önizlemeye dokununca hazır görünümler açılır.
18. Önizlemede ok işareti.
19. Önizleme erişilebilirlikte "düğme" olarak okunur.
20. Hareket kapalıyken önizleme küresi durağandır.
21. Düşük güç modunda önizlemede rozet; `Conds` yardımcısı (koşullu görünürlük, bellek ayırmaz).

Kişiselleştirme (22–36)
22. Kapalı/açık bölümler hatırlanır.
23. Kayıt doğrulanır ve dışa aktarılmaz.
24. Açılan bölüm görünür alana kaydırılır.
25. Yeni hazır görünüm: Pil dostu.
26. Yeni hazır görünüm: Okunaklı (yazıyı küçültmez).
27. 5 hazır görünüm adı ve notu 12 dilde.
28. Elle değiştirilmişse "Özel ayar" yazar.
29–35. Yedi bölümün kapalıyken özeti: tema, şekil, arka plan, his, erişilebilirlik (n/4), cihaz, dil.
36. İlk karede doğru satırlar görünür.

Diğer sekmeler (37–69)
37–43. Ana menü: tema adı, ses paketi, uygulama kapsamı, istatistik sayısı, sürüm, bildirim izni durumu; değişince menü kendini günceller.
44. DNS: "Sıkı şifreleme" yalnızca Otomatik şifrelemede.
45. DNS: "Önbelleği temizle" yalnızca önbellek açıkken.
46–48. Filtre: bellek, son, geçen satırları yalnızca filtre açıkken.
49. Bildirimler: izin engelliyse uyarı kartı en üstte.
50. İzin sorgusu önbelleğe alındı.
51. Listeler: "Şifrelemeyi ölç" yalnızca otomatik ölçümde.
52–56. İstatistik: kazanılan süre, oturumlar, sonuçları paylaş, istatistikleri sıfırla, haftalık grafik yalnızca veri varken.
57. Geçmişi temizle onay ister.
58. Ses kapalıyken ayrıntılar gizlenir.
59. Sessiz saat aralığı yalnızca sessiz saat açıkken.
60. Animasyon kapalıyken animasyon satırları gizlenir, yerine açıklama.
61. Titreşimsiz cihazda titreşim gücü yok.
62. Titreşim gücü yalnızca titreşim açıkken.
63. Boş kart oluşmaz.
64. Ses çıkışı değişince önizleme çalar.
65. Titreşim gücü değişince önizleme titrer.
66. Ses seviyesi bırakılınca örnek çalar.
67. Hazır görünüm penceresinde açıklama alt notu.
68. Uygulanan görünümün adı bildirimde yazar.
69. "Geçmişi temizle" yalnızca temizlenecek veri varken.

- Metinler: 12 dilde 6 yeni metin, "Yenilikler" listesine yeni ilk madde.
- Testler: 8161 → 10340 kontrol, 0 başarısız (yeni `yeni69` grubu, yerleşim denetimine 5 durum). Android 35 stub derlemesi: yalnızca üretilen R/BuildConfig çözülemedi, bunların zincirleme hataları dışında yeni hata yok.

## 1.32.0 (versionCode 51)

**Daha güçlü DPI, cihazı tanıyan uyum katmanı ve baştan düzenlenen Kişiselleştirme sayfası**

> Dürüst not: DPI ve cihaz tanıma yalnızca JVM benzetimiyle ve birim testleriyle sınandı. Gerçek operatörde DPI sonucu ve ROM'ların sistem özelliği adları (aşağıda) gerçek cihazda doğrulanmadı; tanıma okunamazsa uygulama üretici bilgisine düşer ve hiçbir şey bozulmaz.

*DPI atlatma*
- **Üç yeni TLS yöntemi (toplam 11):** 8 = alan adının SON noktasında kayıt bölme (".com" ya da tüm adı arayan kurallar ilk kayıtta eşleşmez); 9 = gecikmeli TCP bölme; 10 = gecikmeli kayıt bölme. Gecikmeli yöntemlerde ikinci parça 60 ms sonra gider (kısa ömürlü yeniden birleştirme belleği olan DPI ilk parçayı unutur); yalnızca öbürleri işe yaramazsa denenir. Yeni sıra: 1, 0, 5, 3, 2, 6, 8, 7, 4, 9, 10.
- **Yeni HTTP yöntemi (toplam 8):** Host DEĞERİNİN ortasında gecikmeli bölme.
- **Tükenen hedef belleği:** tüm yöntemleri başarısız olan bir hedef 45 sn boyunca yeniden yöntem gezilmeden doğrudan geçirilir (her bağlantıda 11 yöntem denemek kullanıcıyı bekletiyordu). `GwStats.exhaustSkipped` sayar.
- **Ağ geçidi:** parçalara gecikme eklenebilir (bağlantı kendi zamanlayıcısıyla uyanır, seçici döngüsü bloke olmaz).
- **Benzetim sonucu (kafes modeli, gerçek ağ garantisi DEĞİL):** TLS'te ilk denemede başarı %20 → %94, ortalama gecikme 2211 → 176 ms; HTTP'de %25 → %96, 3321 → 96 ms.

*Cihaz tanıma (yeni: `core/DeviceProfile.kt`, `platform/DeviceProbe.kt`)*
- Telefonu üreticiye göre ve SİSTEMİNE göre tanır: One UI, HyperOS/MIUI, HarmonyOS/EMUI, MagicOS, ColorOS/realme UI/OxygenOS, Funtouch/OriginOS, HiOS/XOS/itel OS, Nothing OS, Hello UX, Xperia, ZTE/nubia/RedMagic, Flyme, ZenUI/ROG UI, Casper, General Mobile, Reeder, Pixel ve düz Android.
- **Özel ROM'lar** (LineageOS, GrapheneOS, CalyxOS, /e/OS, crDroid, PixelExperience, Evolution X, RisingOS ve bilinmeyen test-keys derlemeleri) donanım üreticisinden ÖNCE tanınır: Xiaomi donanımında LineageOS "agresif Xiaomi" sayılmaz, kapatma riski düşük, sıkı pil rehberi gösterilmez.
- Bellek sınıfı (düşük/orta/yüksek; satış adındaki RAM'den ~%10 az bildirilen değere göre), uygulama kapatılma riski (düşük/orta/yüksek) ve cihaza göre öneriler (Samsung "uyuyan uygulamalar", Xiaomi/Honor/Huawei otomatik başlatma, düşük RAM, özel ROM).
- **Kendini ayarlar:** düşük sınıf cihazda "Tam" animasyon etkin olarak "Az"a iner (kullanıcının seçimi DEĞİŞMEZ, kapatılabilir: "Cihaza göre ayarla"). Kabarcık miktarı da buna uyar.
- Xiaomi/HyperOS için uygulamaya özel PowerKeeper pil ekranı eklendi; Huawei güç yöneticisi ekranı eklendi.
- Getprop yalnız izin verilen ro./hw_sc. adlarını okur (seri no, IMEI, MAC yok), arka planda, en düşük öncelikte, bir kez, en çok 3 sn / 512 KB; ağ kullanmaz. Tanılama raporuna "Sistem:" satırı eklendi.

*Kişiselleştirme sayfası (24 iyileştirme)*
1. Canlı önizleme: seçili tema/stil/küre şekliyle dönen küre, tema adı, stil ve hazır görünüm adı.
2. Önizlemede cihaza göre sadeleştirme etiketi.
3. Yedi katlanabilir bölüm (başlığa dokun: açılır/kapanır; ok döner; erişilebilirlikte açık/kapalı okunur).
4. Tema renkleri Özel / Açık / Koyu olarak gruplu.
5. Açık/koyu tema ve zamanlama satırları yalnızca "Otomatik" tema seçiliyken.
6. Gece saatleri satırı yalnızca zamanlama açıkken.
7. Arka plan karartma ve bulanıklık yalnızca fotoğraf varken.
8. Cam şeffaflığı kaydırıcısı yüksek kontrastta gizli (zaten opak).
9. "Hazır görünüm": Sade / Dengeli / Canlı (cam + hareket + hız); geçerli olan satırda yazar.
10. Hazır görünüm uygulanınca "Geri al".
11. "Görünümü sıfırla" satırı yalnızca varsayılandan farklı bir ayar varken, kaçının farklı olduğunu yazar.
12. Sıfırlama yalnızca görünümü etkiler (DNS, filtre, favoriler, fotoğraf, simge korunur) ve geri alınır.
13. Yazı boyutunda seçili yüzde altta yazılır.
14. Animasyon sırası Yok · Az · Tam (her dilde); ayrı kabarcık satırı yok.
15. Hareket satırında düşük güç / cihaza göre sadeleştirme notu.
16. Titreşim motoru olmayan cihazda "Titreşim" satırı gizli.
17. "Bu cihaz" bölümü: cihaz adı, sistem ve sürüm, sınıf, kapatılma riski, uygulanan otomatik ayar, üreticiye özel öneriler.
18. Riskli sistemlerde "Pil ayarlarını aç" düğmesi.
19. "Cihaza göre ayarla" anahtarı.
20. Satır değerleri ekran okuyucuya okunur (NavRow değeri).
21. "Kendi stilim" ve "Temaya göre şekil" satırlarında dolu/toplam sayacı.
22. Dil ve simge nadir değişen ayar olarak sayfa sonuna alındı.
23. Önizleme yazı boyutuna uyar, uzun adlar kısaltılır; kare başına bellek ayırmaz (test).
24. Bölüm durumu sayfa açıkken hatırlanır; yerleşim yalnızca gerçekten değişince yenilenir.

*Genel*
- 12 dilde 30 yeni metin ve yeni "Neler yeni" maddesi.
- Testler: 7970 → 8161 kontrol (cihaz tanıma tabloları, ayar etkileri, Kişiselleştirme sayfası, 12 dil).

## 1.31.0 (versionCode 50)

**Güvenlik katmanları, filtre, DPI, kriptografi ve arayüz iyileştirmeleri**

*Şifreli DNS tüneli*
- **Bayat cevap (RFC 8767, "serve-stale"):** üst sunucu yanıt vermezse ya da son hatası son başarısından yeniyse, süresi dolmuş OLUMLU cevap (en çok 6 saat eski, TTL 30 sn) hemen verilir; gerçek sorgu arkada çalışıp önbelleği tazeler. Düz UDP'de 1,8 sn sonra, DoT/DoH/ODoH'ta üst sunucu "sorunlu" sayılınca. Olumsuz (NXDOMAIN/boş) cevaplar asla bayat verilmez. İstemci artık sunucu kesintisinde saniyelerce zaman aşımı beklemez. `Stats.stale` bayat verilen cevapları sayar.

*Kriptografi*
- **El sıkışma sonrası TLS politikası (`TlsPolicy`):** pazarlık edilen sürüm ve şifre takımı denetlenir (DoT, DoH, ODoH, ODoH yapılandırma alımı, sunucu sınaması). Yalnızca TLS 1.3/1.2; TLS 1.3'te yalnızca AES/ChaCha20; TLS 1.2'de ileri gizlilik (ECDHE/DHE) şart. Statik RSA/DH/ECDH, NULL, anonim, EXPORT, RC4, DES/3DES, RC2, IDEA, SEED, MD5 reddedilir; ret sertifika hatası gibi "güven hatası" sayılır (yedek sunucuya geçilir, `tlsFailures` artar). Gerçek sağlayıcıları etkilemez; savunma derinliğidir.

*DPI atlatma*
- **Yerel adreslere DPI uygulanmaz** (modem, yazıcı, 10.x/192.168.x/100.64/10, IPv6 yerel): eskiden bölme bu hedeflere de uygulanıp yöntem oylarını ve öğrenilen belleği bozuyordu. `GwConfig.dpiOnLocal` ile (yalnız testlerde) açılabilir.
- **Sahte cevap tanıma:** ilk TLS cevabı TLS kaydı (0x16/0x15) değilse (DPI'ın enjekte ettiği düz metin/yönlendirme) bu cevap kabul edilmez, bir sonraki yönteme geçilir ve öğrenilmez; son yöntemde olduğu gibi iletilir. `GwStats.injected` sayar.
- **Güvenli ilk yöntem:** yeniden denenemeyecek uçuşlarda (ilk veri birden çok parça) artık "cesur" yöntem değil, öğrenilmiş ya da en güvenli ilk yöntem seçilir.

*Reklam engelleme ve filtre (kendi liste içe aktarma)*
- **AdBlock istisnaları:** `@@||alan^` (zararsız seçeneklerle) okunur; ad ya da üst alan adı istisnaysa listeden çıkarılır (etiket sınırında: `example.com` istisnası `notexample.com`'u çıkarmaz).
- **Zararsız seçenekler kabul:** `$important`, `$third-party`, `$3p`, `$all` (eskiden bütün `$` kuralları atılıyordu). Kısıtlayıcı seçenekler (`$script`, `$image`…) alan adı düzeyinde anlamlandırılamadığından yine atılır.
- **Yeni biçimler:** dnsmasq (`address=/ad/0.0.0.0`, `server=/ad/`, `local=/ad/`), Unbound (`local-zone: "ad" always_nxdomain|always_null|…`), RPZ (`ad CNAME .`).
- **Ortak son ek koruması:** `com.tr`, `co.uk`, `*.ck` gibi ICANN son ekleri (Public Suffix List; GitHub.io/blogspot gibi özel bölüm adları hariç) ne içe aktarmada ne elle engel/izin listesine alınır: tek kural bütün siteleri kapatırdı.

*Arayüz (18 iyileştirme)*
1. Eylem satırlarında radyo yerine eylem simgesi (izin ver ✓, engelle ⃠, kaldır ✕, ekle +, kopyala).
2. "Son engellenenler"de sağda kaç kez engellendiği (12×).
3. "Son izin verilenler"de aynı sayaç; reklama benzeyenler sıklığa göre sıralı.
4. Erişilebilirlik: eylem satırları artık "seçili değil" demez; sayaç okunur.
5. İzin/engel listeleri aynı sitenin alt alanları yan yana olacak biçimde sıralı.
6. "Ekle…" satırında + simgesi ve doluluk (ör. 12/200).
7. Uzun alan adları baştan kısalır ("…reklam-sunucusu.example.com"): önemli olan sondaki kayıtlı alan adı görünür.
8. Filtre sayfasında "Site neden açılmıyor?" kısayolu (eskiden yalnız DNS sayfasındaydı).
9. Menüde Engelleme satırı düzey + toplam engel ("Orta · 1,2 bin").
10. İstatistiklerde engellenen sayısı toplam sorgudaki payıyla ("300 · %15").
11. Ortak son ek için ayrı ve açıklayıcı uyarı (eskiden "geçerli ad yazın" deniyordu).
12. Engelleme/izin verme tek dokunuşla GERİ ALINIR (iki liste de eski haline döner).
13. Toplu "şüphelilerin hepsini engelle" de geri alınır.
14. Kendi liste içe aktarması geri alınır.
15. İçe aktarma bildirimi istisna yüzünden çıkarılan ad sayısını söyler.
16. İçe aktarma açıklaması yeni biçimleri (AdBlock @@, dnsmasq, Unbound, RPZ) sayar (12 dil).
17. Son engellenen/geçen listelerinde "Kopyala" satırı (adları satır satır panoya).
18. Seçenek satırındaki açıklama sağdaki rozete çarpmaz (genişlik rozete göre ayrılır).
- 12 dilde 3 yeni metin (ortak son ek uyarısı, istisna notu, içe aktarma açıklaması).

*Araçlar*
- Önizleme betiğinde (`UiPreview`) "stylepick" artık Kişiselleştirme sayfasından açılır; `filter` önizlemeleri sayaçları ve geçenler panelini de üretir.
- Testler: 7970 kontrol, 0 başarısız (Kotlin 2.4.21, JDK 25); `core/ui/platform` Android 35 saplamalarıyla da derlendi. Gerçek Gradle/AGP derlemesi ve cihaz davranışı (DPI'ın gerçek operatörde, serve-stale'in gerçek ağda) bu ortamda DOĞRULANAMADI; APK'yı GitHub Actions derlesin.

## 1.30.1 (versionCode 49)

**Eksik ve hata taraması (küçük düzeltmeler + araç güncellemeleri)**
- **Duraklatma bitince bağlantı:** "duraklat" süresi dolup alarm tetiklendiğinde yeniden bağlanma denemeleri tükenirse, ağ geri geldiğinde bağlantı kendiliğinden kurulmuyordu (`userWanted` bayrağı açılmıyordu). Bildirimden "devam et" yolundaki davranışla aynı hâle getirildi.
- **Rastgele kaynak portu aralığı:** TCP DNS için seçilen kaynak portu 1000–65000 aralığının son değerini (65000) hiç üretmiyordu; aralık artık tam (`PORT_SPAN`).
- **Araçlar:** Gradle 9.8.1, Kotlin 2.4.21, `actions/setup-python@v7`, `gitleaks/gitleaks-action@v3`. Üç iş akışı (apk, release, security) aynı Gradle sürümünü kullanıyor.
- **Yeni "Testler" iş akışı:** `selftest/` altındaki JVM testlerini (7793 kontrol) GitHub'da çalıştırır; Kotlin derleyicisini JetBrains'in resmî yayınından indirip SHA-256 ile doğrular. Telefondan Actions → Testler ile görülür; bir kontrol başarısızsa kırmızı olur. APK derlemesi testleri çalıştırmaz, bu iş akışı o boşluğu kapatır.
- **Belgeler:** README, OKUBENI, INCELEME'deki test sayısı, Gradle ve Kotlin sürümleri güncellendi; manifestteki "altı takma ad" yorumu "sekiz" olarak düzeltildi; `RegressionTests.kt` içindeki dört eski "AÇIK" çıktı satırı güncel duruma getirildi.
- **Not (davranış değişmedi):** tünel açıkken tutulan `PARTIAL_WAKE_LOCK`, "ekran kapalıyken hiçbir şey dönmez" anlatımıyla ve düşük arka plan kaynağı hedefiyle çelişir; Play'in "aşırı kısmi wake lock" ölçütüne de takılabilir. Gerçek cihazda pil ölçümüyle ele alınmalı.
- Testler: 7793 kontrol, 0 başarısız. Gerçek Gradle/AGP derlemesi ve cihaz davranışı bu ortamda doğrulanamadı; APK'yı GitHub Actions derlesin.


## 1.30.0 (versionCode 48)

**Geniş güvenlik geçişi: şifreli DNS, ODoH, kriptografi, ağ geçidi (ayrıntı: GUVENLIK_INCELEMESI.md, "Ek inceleme 1.30.0")**
- **HTTP çerçeveleme (DoH, ODoH, yapılandırma alımı):** tek ortak kural kümesi (`HttpRules`). Katlanmış başlık, boşluklu başlık adı, "gzip, chunked" gibi çözülemeyen aktarım kodlamaları, ikinci Transfer-Encoding ve parça sonunda CRLF olmayan cevaplar reddedilir; 100/103 ara cevapları atlanır (en çok 4); durum satırı tam 3 basamak olmalı.
- **ODoH:** her sorgu tek kullanımlık (aynı cevap ikinci kez açılamaz); cevap anahtarı, nonce, ara anahtar, dışa aktarılan sır ve sorgunun düz metni başarıda da hatada da bellekten silinir.
- **HPKE/HKDF:** ara sırlar (paylaşılan sır, anahtar çizelgesi sırrı, KEM ara anahtarı, HKDF blokları) kullanıldıktan hemen sonra silinir. RFC vektörleri ve çapraz doğrulama aynen geçiyor.
- **Düz DNS:** cevap, sorunun gönderildiği soketten (aynı kaynak portundan) gelmek zorunda; sahte cevap gönderen biri artık iki porttan herhangi birini tutturmakla yetinemez.
- **Reklam+:** mutlak biçimli HTTP isteği (`GET http://reklam.example/ …` + izinli görünen Host) ve CONNECT hedefi de denetlenir; "Host: izinli.com" yazarak engel atlatılamaz.
- **Ağ geçidi belleği:** tüm TCP akışlarının kuyruklarına ortak 24 MB tavan. Önceden 1500 bağlantı × 224 KB ≈ 330 MB'a kadar büyüyebiliyordu; okumayan bir uygulama servisi bellek yetersizliğinden öldürebilirdi. Tavan dolunca TCP geri basıncı devreye girer, boşalınca duran akışlar kendiliğinden sürer.
- **Kilitlenme düzeltmesi:** istemci penceresi dolduğunda sunucudan gelen veri istemciye gönderilmeden bekleyebiliyordu (iki yön birbirini bekliyordu). Artık her durumda akıtılır; zamanlayıcı da bekleyen veriyi yoklar.
- **Liste güncelleme:** manifestte ikinci sürüm satırı ve rakam dışı sürüm reddedilir; gömülü anahtar yalnızca P-256 olabilir.

- Testler: 7594 kontrol, 0 başarısız (yeni: HTTP kuralları, ODoH tek kullanım/silme, yanlış soketten cevap, mutlak biçim atlatması uçtan uca, ortak bellek tavanı uçtan uca). Android tarafı bu sürümde değişmedi.

**Reklam engelleme güçlendirmesi**
- **Yeni listeler (Basit):** GoodbyeAds (mobil uygulama reklamları, MIT) ve turk-adlist (Türkçe haber/alışveriş sitelerinin reklam sunucuları, CC BY-SA 3.0). Türkçe sitelerin reklam sunucularında kapsam %81'den %98'e çıktı; Basit katman 360 binden 506 bin ada çıktı. Tüm listeler bugünkü sürümleriyle yeniden derlendi.
- **Yeni liste (Orta):** AdGuard CNAME gizli izleyicileri (MIT): birinci taraf gibi görünen izleyici alt alan adları.
- **Bozulma koruması:** liste derlenirken siteleri/uygulamaları bozan girdiler (AliExpress görselleri, JW Player videoları, TRT oynatıcısının bölge denetimi, giriş servisleri, kısa bağlantılar...) çıkarılır; popüler alan adları ayrıca bağımsız bir listede yoksa yalnızca Sıkı'ya girer.
- **Bildirim düzeltmesi:** eski Basit liste `fcm.googleapis.com` adını engelliyordu (anlık bildirim altyapısı); bazı uygulamaların bildirimleri gecikebilir ya da gelmeyebilirdi. FCM, Firebase kurulum kimliği ve OneSignal artık hiçbir seviyede engellenmez.
- **Son izin verilenler:** Engelleme sayfasında yeni liste. Reklam hâlâ görünüyorsa süzgeçten geçen son 60 adı görüp kaçan reklam sunucusunu tek dokunuşla engelleyebilirsin. Yalnızca bellekte tutulur ("Geçmişi tut" kapalıyken hiç tutulmaz). 12 dilde.
- **Reklam+ ve QUIC:** Reklam+ açıkken QUIC (UDP/443) da düşürülür. QUIC'te site adı şifreli olduğundan QUIC kullanan reklam sunucuları ve uygulamalar Reklam+'ı atlıyordu; artık TCP/TLS'e dönüp adları görünür oluyor.
- **Yabancı siteler, açılır pencere ve yönlendirmeler:** EasyList reklam sunucuları ve EasyList açılır pencere/yönlendirme sunucuları (yalnızca bütün alan adını engelleyen kurallar; CC BY-SA 3.0) Basit'e, EasyPrivacy izleyici sunucuları Orta'ya eklendi. Genel karşılaştırma listesinde (HaGeZi Multi Normal, yalnızca ölçüt, pakete girmez) Basit kapsamı %54'ten %64'e çıktı; bilinen açılır pencere ağlarında %96.
- **Tarayıcının DNS atlatmasını engelle (yeni ayar, varsayılan açık):** tarayıcı ya da uygulama kendi şifreli DNS'ini (Chrome "Güvenli DNS", uygulama içi DoH) kullanırsa sorgular süzgece hiç gelmez, reklamlar ve açılır pencereler geçerdi. Engelleme açıkken bilinen şifreli DNS sağlayıcılarının adları engellenir; tarayıcı sistem DNS'ine döner. Chrome'da "Güvenli DNS" belirli bir sağlayıcıya ayarlıysa sayfa açılmayabilir: o ayar kapatılmalı ya da bu ayar kapatılmalı (notta yazıyor). 12 dilde.
- **Her gün değişen reklam adları:**
  - *Günlük liste güncellemesi:* GitHub her gün listeleri yeniden üretip imzalar; uygulama Wi-Fi'de 12 saatte bir, mobil veride 3 günde bir denetler. Açık anahtar ve yayın adresi artık koddan değil derleme ortamından (GitHub gizli değeri `LIST_PUBLIC_KEY`) gelir; kurulum 2 gizli değer + 1 tıklama (tools/yayin/README.md). Proje zip olarak yüklenmiş depoda da çalışır.
  - *Şüpheli ad işaretleme:* "Son izin verilenler" listesinde reklam/yönlendirme sunucusuna benzeyen adlar (reklam sözcükleri, rastgele onaltılık ya da harf-rakam dizileri, riskli uzantılar) başa alınır ve "Reklama benziyor" diye işaretlenir; "Şüphelilerin hepsini engelle" tek dokunuşla hepsini kendi engel listesine ekler. Yalnızca öne çıkarır, kendiliğinden engellemez (en popüler 10 bin sitenin ~%0,5'i işaretlenir; çoğu zaten reklam/bahis adı).
  - *Sıkı seviyede riskli uzantılar:* yaygın sitelerde neredeyse hiç görülmeyen, dönen reklam adlarında sık kullanılan uzantılar (.cfd, .cyou, .icu, .sbs, .rest, .quest, .buzz…) bütünüyle engellenir. EasyList reklam sunucularının ~%11'i bu uzantılarda. İzin listesi önce gelir. Seviye notu 12 dilde güncellendi.
  - *Kendi adresinden reklam veren siteler:* reklam ayrı bir alt alan adındaysa (ads.site.com) yukarıdaki listeden engellenebilir; sayfa ile aynı adresten geliyorsa DNS ile ayırt edilemez (HTTPS içeriğini açmak gerekir, bu uygulama bunu bilerek yapmaz).
- Testler: 7754 kontrol, 0 başarısız (yeni: Türkçe, mobil ve açılır pencere reklam sunucuları, bozulmaması gereken 33 ad, lisans bildirimleri, son izin verilenler, DNS atlatma koruması, şüpheli ad işaretleme ve toplu engelleme, riskli uzantılar).


## 1.29.1 (versionCode 47)

**Reklam+, DPI ve DNS düzeltmeleri**
- **Sabit DNS sunucusuna soran uygulamalar:** ağ geçidi açıkken, DNS de açıksa, bir uygulama kendi DNS sunucusuna (ör. 8.8.8.8:53) düz DNS ile sorsa bile sorgu artık seçtiğin sunucuya ve süzgece yönlenir (önceden şifresiz olarak doğrudan çıkıyordu). Yerel/özel hedefler (yönlendirici, şirket DNS'i) yönlendirilmez.
- **TCP/53 DNS:** sabit sunucuya TCP ile giden DNS soruları da süzülür (önceden yalnızca UDP süzülüyordu).
- **Gizli izleyici (CNAME):** sabit sunucudan UDP/53 ile gelen cevaplarda da CNAME zinciri denetlenir.
- **ECH:** Reklam+ açıkken HTTPS/SVCB (tür 65/64) sorgularına "kayıt yok" denir. Bu kayıtlar şifreli ClientHello (ECH) anahtarı taşır; tarayıcı ECH kullanınca gerçek site adı ağ geçidinden görünmez, reklam engeli atlanırdı. Kayıt yoksa tarayıcı düz TLS'e döner. Reklam+ kapalıyken davranış değişmedi.
- **Engelli ad asla sızmaz:** sınıfı IN olmayan (CHAOS, ANY...) bir soruyla engelli ad üst sunucuya gidebiliyordu; artık "reddedildi" (RCODE 5) cevabı verilir. Aynı sağlamlaştırma gizli izleyici cevabında da var.
- **Kök ad sorgusu** (".") biçim hatası sayılıyordu; artık normal iletilir.
- **HTTP Host okuma:** gövdedeki "Host:" satırı Host başlığı sayılmaz (yalnızca başlık bölümü okunur).
- Testler: yeni kontroller eklendi (UDP/TCP 53 uçtan uca dahil).

## 1.29.0 (versionCode 46)

**Güvenlik sertleştirmesi (ayrıntı: GUVENLIK_INCELEMESI.md, "Ek inceleme 1.29.0")**
- **Filtre atlatmaları kapatıldı:** 0x80 ve üstü baytlı etiketlerle (ör. `x.doubleclick.net` önüne eklenen sahte bayt) engel atlanabiliyordu; artık ad bayt bayt doğru okunur. Birden çok soru içeren, sıkıştırma işaretçili, ayrılmış etiket türlü ya da kesik sorgular filtre açıkken yönlendirilmez; istemciye hata (FORMERR) döner.
- **Reklam+ / DPI:** ağdan gelen SNI ve Host adları, kullanıcı girişi gibi katı değil, gevşek biçimde temizlenir; alışılmadık yazımlar engel listesini artık aşamaz.
- **Kayıt sızıntısı:** günlüğe yazılan adlardaki denetim ve garip karakterler "?" ile değiştirilir.
- **Liste güncelleme:** liste kümesi tek dizin değişimiyle yerine konur (yarım kalan güncelleme eski ve yeni dosyaları karıştırmaz); uygulama güncellenince eski önbellek yok sayılır; dosya başına 90 sn toplam süre sınırı; aynı anda tek güncelleme.
- Testler: 7457 kontrol, 0 başarısız. Android tarafı (ListUpdater) bu ortamda derlenmedi; GitHub derlemesinde doğrulanır.

**Metinler:** Yenilikler ilk maddesi ve mağaza/gizlilik metinleri Google Play koşullarına göre güncellendi (VPN açıklaması, isteğe bağlı DPI/Reklam+ kipleri, liste güncelleme beyanı).

## 1.28.0 (versionCode 45)

**Engelleme motoru ve liste güncellemesi**
- **Otomatik liste güncellemesi:** engelleme listeleri (basic/medium/strict) uygulamanın içinde değil, imzalı bir yayın adresinde tutulur. Uygulama en çok günde bir kontrol eder, indirir, doğrular ve yerine koyar. Varsayılan açık; gizlilik metninde ayrıntı var.
- **İmza zorunluluğu:** manifest ECDSA P-256 ile imzalanır; imza gömülü açık anahtarla doğrulanmadan hiçbir liste kabul edilmez. Açık anahtar tanımlı değilse güncelleme kapalıdır (güvenli varsayılan).
- **Geri dönüş (rollback) engeli:** sürüm numarası kurulu sürümden büyük olmalı; eski imzalı bir sürüme dönülemez.
- **Boyut ve özet kontrolü:** her dosyanın boyu ve SHA-256 özeti manifestle eşleşmeli; 100 KB altındaki (boş/kırpılmış) listeler reddedilir, böylece bir yayın hatası tüm kullanıcılarda engellemeyi kapatamaz.
- **Katman bazında yedek:** önbellekteki bir liste bozuksa yalnızca o katman paketteki sürümden okunur; eskiden tek bozuk dosya tüm engellemeyi kapatıyordu.
- **Yeniden yükleme:** liste değişince motor, ayarları korunarak senkron ya da arka planda yeniden kurulabilir.
- **Yayın iş akışı:** `.github/workflows/listeleri-yayinla.yml` haftada bir listeleri üretir, imzalar ve "listeler" yayınına koyar. Kurulum adımları: `tools/yayin/README.md`.

**Hazır arka planlar**
- Uygulamayla gelen 8 görsel yerine 28 görsel. Filigranlı iki görsel (onedio ve pngtree damgalı) listeye alınmadı. Hazır görseller ekran oranına kırpılır; küçük çözünürlüklü görseller (genişlik 240–500 px) telefonda yumuşak görünebilir.

**Kendi stilim**
- Kişiselleştirmede "Kendi stilim" sayfası beş bölümden oluşur: Görünüm (gökyüzü, vurgu, sıvı hareketi, dalga yüksekliği kaydırıcısı), Hareket (animasyon türü, biçimi ve büyüklük kaydırıcısı), Ses (tını, dizi ve perde), Kayıtlı stillerim (altı yuva) ve Araçlar (karıştır, sesi dinle, sıfırla).
- Kayıtlı stillerim: Bir yuvaya dokunup mevcut ayarları kaydedebilirsin. Dolu bir yuvada uygula ya da sil seçilir. Kayıtlar telefona özgüdür.
- 24 yeni tema (12 açık, 12 koyu): toplam 48 tema. Her tema WCAG kontrolünden geçer.
- Güvenlik: ağ geçidi açıkken IPv4 tünelinde IPv6 trafiğinin reklam, DoH ve DPI denetimini atladığı sızıntı kapatıldı.
- IPv6 uzantı başlıkları (hop-by-hop, yönlendirme, hedef seçenekleri) artık geçiyor; önceden bu paketler düşüyordu.
- HTTP Host başlığında IPv6 değişmezi doğru okunuyor.
- Yeni dillerde (Almanca, İspanyolca, Fransızca, Endonezyaca, İtalyanca, Lehçe, Portekizce, Rusça, Ukraynaca, Vietnamca) yeni özel stil ve tema adları çevrildi.
- Uzun seçim listelerinde (dil, tema, parça vb.) açılışta seçili seçenek görünür; artık en alttaki seçenekten sonra listenin başına dönülmez.
- 162 animasyon parçası: 18 efekt türü × 9 biçim. Türler birbirinden farklı çizilir: yörünge, taç yaprağı, kabarcık, şimşek, kristal, ateşböceği, sarmal, ışın, kırılma ve piksel türleri eklendi. "Stilin kendi animasyonu" varsayılandır.
- 384 ses parçası: 16 tını × 12 nota dizisi × 2 perde (normal ve yüksek). Dizilere titreşim ve akor eklendi. "Otomatik (paket)" varsayılandır.

**Efekt biçimleri ve ses parçaları**
- Dokunma efekti biçimi 5'ten 9'a çıktı: Eğik, Ayna, Büyüyen, Hızlı (her stil için ayrı seçilir).
- 384 ses parçası (16 tını × 12 nota dizisi × 2 perde): Ayarlar › Ses › "Ses parçası" ile seçilir, tını, dizi ve perde sırayla sorulur; "Otomatik (paket)" varsayılandır ve eski davranış aynıdır. Parça seçiliyken arayüz sesleri parçayla çalar.

**Özel tema**
- Kişiselleştirmede "Gökyüzü" (8 seçenek: 4 açık, 4 koyu) ve "Vurgu" (6 seçenek) ile kendi temanı kur. Metin ve yüzey renkleri seçime göre türetilir; 48 kombinasyonun hepsi WCAG 4,5:1 okunabilirlik testinden geçer.
- Tema seçicide "Özel" örneği, seçilen kombinasyonu gösterir.
- Sıvı rengi önizlemesi artık süs animasyonu olarak 33 ms kare hızında çalışır (eskiden 16 ms istiyordu).

**Yeni temalar**
- 12 yeni tema eklendi (toplam 24): açık olarak Şeftali, Turunç, Gül, Buzul, Kum, Lagün, Kakao, Şeker; koyu olarak Orman, Kor, Erik, Arduvaz. Her biri 12 dilde adlandırıldı; okunabilirlik testleri (WCAG 4,5:1) geçiyor.
- Tema seçicideki örnek önbelleği 24 temaya göre büyütüldü; eskiden her karede yeniden ayrım yapıyordu.

**Küre animasyonları ve sesler**
- **10 sıvı hareketi:** Ayarlar › Görünüm › Küre › "Sıvı hareketi" (tüm stillerde): Sakin (özgün), Gelgit, Halka, Kabarma, İkiz, Üçgen, Yumuşak kare, Kaynama, Sarmal, Durgun. Varsayılan Sakin; görünüm değişmez.
- **Her stil için 4 yeni dokunma/kutlama efekti:** "Dokunma efekti biçimi" seçeneği, aktif stil için ayrı saklanır. Seçenekler: özgün, yoğun, dönen, çift nabız, toplanan. Özgün varsayılandır.
- **3 yeni ses:** kaydırma (sayfa geçişi), uzun basış, uyarı (bağlı değilken duraklatma isteğinde). Ses paketi tınısıyla çalar.
- Sıvı hareketleri yeniden ayarlandı: her hareketin kendi hızı ve genlik çarpanı var; "Durgun" eskiden neredeyse hiç hareket etmiyordu. Sakin (varsayılan) değişmedi. Sıvı yalnızca bağlanırken/bağlıyken görünür; kapalıyken küre boştur.
- Sıvı hareketi tüm tasarım stillerinde çalışır (Duru'nun düz daire küresi dahil). Türkçe dışındaki dillerde yeni etiketler İngilizce gösterilir.

**Arayüz düzeltmeleri**
- "Kabarcıklar" ayrı ayar satırı kaldırıldı. Kabarcık miktarı artık animasyon seviyesinden gelir: Tam → çok, Az → az, Yok → kapalı. Varsayılan (Tam) görünümde kabarcık sayısı önceki "az"dan "çok"a çıktı; geri almak istersen söyle.
- Animasyon seçenekleri Yok · Az · Tam sırasıyla gösterilir (her dilde). Türkçe "Kapalı" etiketi "Yok" oldu. Kayıtlı ayarlar bozulmaz (enum sırası aynı).

**Önceki sürümden düzeltmeler (1.27.x içinde)**
- DNS cevap doğrulama açığı (soru çözülemeyen sorgularda kimlik tutan her cevap kabul ediliyordu) kapatıldı.
- HTTP çerçeveleme sertleştirildi (bozuk ya da çelişen uzunluk ve chunked+Content-Length reddedilir).

**Testler:** liste imzası, manifest biçimi, özet/boy, rollback, minimum boyut ve bozuk önbellekte yedek (57 kontrol, "girdi" grubu).

**Henüz yapılmadı (bilerek):**
- Gerçek yayın adresi ve açık anahtar: `ListUpdater.BASE_URL` ve `PUBLIC_KEY_B64` yayın kurulumunda doldurulmalı; boşken güncelleme kapalıdır.
- Ayarlarda "Listeleri otomatik güncelle" anahtarı: şimdilik yalnızca varsayılan açıktır, arayüz anahtarı sonraki adımda eklenmeli.
- Üç dosyanın yerine taşınması sırasında çökme olursa karışık sürüm kalabilir (her dosya ayrı ayrı doğrulanmış olur).

## 1.27.0 (versionCode 44)

**Güvenlik ve sağlamlık**
- **HPKE çapraz doğrulama:** ODoH'un şifreleme katmanı bağımsız bir referans uygulamayla (pyhpke, RFC 9180) iki yönde doğrulandı. Kodda değişiklik yok; test ve vektörler eklendi.
- **Nonce ve anahtar kuralları:** her kurulumda yeni efemer anahtar, nonce tekrarı olmadığı ve sıra dışı mesajların reddedildiği testlerle korunuyor.
- **Bozuk girdi fuzzing:** şifreli metne 4000 bozuk girdi; istisna ya da kabul yok, alıcı durumu korunuyor.
- **Yayın imzalama koruması:** yayın derlemesinin debug anahtarına düşmediğini ve gizli anahtar dosyalarının depo dışında kaldığını doğrulayan testler.
- **Dependabot:** Gradle bağımlılıkları ve GitHub Actions sürümleri haftalık izleniyor.
- **Ad etiketi dizisi taşması:** filtre, 128'den fazla etiketli adlarda sağdaki sonekleri sessizce atıyordu. Dizi, 255 baytlık DNS adının en çok etiket sayısına (128) göre boyutlandırıldı. Gerçek ağ sorgularında bu durum zaten oluşamıyordu; yine de düzeltildi.
- **HTTP çerçeveleme sertliği:** ODoH ve DoH cevaplarında bozuk içerik uzunluğu, birbirini tutmayan iki içerik uzunluğu ve hem chunked hem içerik uzunluğu birlikte gelen cevaplar artık reddediliyor (önceden sessizce kabul ya da 'kapanana kadar oku' moduna düşüyordu). Testler: 'HTTP çerçeveleme' grubu.
- **DNS cevabı doğrulama açığı (kritik, düzeltildi):** sorgunun sorusu çözülemediğinde (soru yok ya da sıkıştırılmış ad) soru denetimi atlanıyordu; kimlik tutan her cevap önbelleğe giriyordu. Artık yalnızca soru bölümü ve cevabı boş hata cevabı kabul ediliyor. Düz DNS ve şifreli DNS yolları aynı fonksiyonu kullandığı için ikisi de kapandı. Testler: 'Güvenlik' grubu (2 yeni kontrol).
- **Eşleştirme sınır testleri:** DNS sınırında (≤253 bayt) çok etiketli adlarda engel yakalanıyor; 253 bayttan uzun adlar geçersiz sayılıp güvenle reddediliyor.
- **Güvenlik taraması iş akışı:** Lint, mobsfscan, gitleaks ve MobSF (APK) taraması.
- **Eşzamanlılık hatası düzeltildi (kripto):** Aynı şifreleme bağlamı birden çok iş parçacığından kullanılınca nonce çakışabiliyordu (test 4000 şifrelemede 128 çakışma buldu). Artık sayaç ve şifreleme tek kilit altında; sayaç tükenirse bağlam kullanılmaz.
- **Türkçe alan adları:** `örnek.com` gibi IDN adlar artık kabul edilir ve punycode'a çevrilir (`xn--rnek-4qa.com`). Büyük harf eşlemesi (İ/ı) doğru çalışır.
- **Gizlilik politikası:** Tanılama raporunun içeriği, çökme özeti ve bildirim/açılış izinleri politikaya işlendi.
- **Tanılama raporu** (☰ > Sorun giderici > Tanılama raporu): sürüm, Android sürümü, cihaz modeli, ağ türü, ayar kodları ve sorun sayısını gösterir. Önce önizlenir, paylaşımı sen onaylarsın; alan adı, IP ya da kişisel veri içermez.

## 1.26.0 (versionCode 43)

**Yeni**
- **Duru stili** (☰ > Kişiselleştir > Stil): sakin ve sade; nane tonlu zemin, altta saydam su bandı, ince kenarlı düz yüzeyler, az hareket (solarak büyüyen sayfa geçişi, yumuşak yaylar, halka efekti).
- **Duru uygulama simgesi:** suya süzülen iki yaprak, saydam su ve cam rozette "DNS" (uyarlanabilir + tek renkli simge dahil).
- **Duru ses paketi:** yumuşak, kısa, sıcak tınılı 11 olay sesi; Otomatik pakette Duru stiliyle eşleşir, ayrıca kendi paketi olarak seçilebilir.
- **Duru animasyonları:** 10 olay için yaprak süzülmesi ve su halkaları (dokunma, anahtar, bağlanma, kesilme, hata, tamamlanma, panel, geri, seçim, yenileme).
- 12 dilde stil ve simge açıklamaları.

**Bağlantı (aynı sürüm):**
- **Uyanık kalma kilidi:** Tünel açıkken (bağlanıyor, bağlı, yeniden denerken) CPU uyanık tutulur; ekran kapalıyken bağlantı donup sessizce düşmesin diye. Kullanıcı kestiğinde, duraklattığında ya da hata verince bırakılır. Pil tüketimi bu kilidin bedelidir; pil ayarları sayfasındaki muafiyet durumu hâlâ geçerli.
- **Ağ dönünce yeniden bağlanma:** Yeniden denemeler tükendikten sonra bile, kullanıcı bağlantıyı kesmediyse ağ geri geldiğinde bağlantı yeniden kurulur. Kullanıcı kestiyse hiçbir şey kendiliğinden açılmaz.
- **DNS sızıntı kontrolü:** Sorun gidericide, tünel açıkken sistemin DNS sunucusu bizim sanal adresimiz değilse uyarı verir. Uygulamalar kendi DNS'lerini (ör. tarayıcının DoH ayarı) kullanıyorsa bu kontrol görmez; bunu da not olarak belirtiyorum.

- **Ağa göre DPI öğrenmesi (kalıcı):** Hangi DPI yönteminin hangi ağda çalıştığı artık uygulama kapansa da hatırlanır. Anahtar: ağ türü ve mobilde operatör kodu (MCC+MNC); Wi-Fi'de SSID kullanılmaz (konum izni gerekir), yalnızca "Wi-Fi" olarak tutulur. Kayıt yalnızca telefonda durur. Bir yöntem artık çalışmazsa sıradakine geçilir ve yeni çalışan kayda yazılır.

- **"Site neden açılmıyor?" (☰ > Sorun giderici alanında ayrı satır):** Bir alan adı yazılır; uygulama sırayla bakar: bağlantı açık mı, kullanıcı engel listesinde mi, reklam/izleme listesinde mi, şifreli DNS sağlayıcısı mı, izin verilmiş mi. Engelliyorsa "İzin ver" düğmesi çıkar. Engellemiyorsa sorunun büyük olasılıkla sitede ya da tarayıcıda olduğunu söyler.

- **YouTube reklam sunucuları (yalnızca kişisel sürüm, kısmi):** Ayarlarda isteğe bağlı anahtar. Bilinen reklam ve reklam ölçüm alan adlarını DNS'te engeller. İçerik sunucuları (googlevideo.com, youtubei, youtube.com) asla engellenmez; oynatıcı içi reklamları kaldırmaz, bu yüzden kısmidir. Play sürümünde anahtar görünmez ve etkin olmaz. Kişisel APK: `./gradlew assembleRelease -Ppersonal=true`.

**Düzeltme (aynı sürüm):** Duru Aqua çakması gibi duruyordu; bileşenler baştan düz çizildi (cam küre yerine düz daire + sakin su düzeyi, hap yerine yumuşak köşeli düğmeler, gölgesiz kartlar, düz simge kareleri, düz üst çubuk), yeni "süzülme" sayfa geçişi ve ince halka + yaprak efekti eklendi.

**Test:** tüm JVM testleri, 0 hata (stil/paket/tını sayıları 8/14/16'ya güncellendi).

## 1.25.0 (versionCode 42)

**Değişti**
- **Ses varsayılanı (Otomatik):** dokunma ve bağlanma sesleri artık telefon **titreşim** modundayken de çalar (oyun ve klavye sesleri gibi, medya kanalından). Yalnızca **tam sessiz** modda susar. Önceden Otomatik modda telefon titreşimdeyken de susuyordu; "bazı telefonlarda ses gelmiyor" geri bildiriminin başlıca nedeni buydu (çok kullanıcı telefonu sürekli titreşimde tutuyor). Sistem/medya ses seviyesine ve "sessiz başarı" / yedek yol mantığına dokunulmadı. İsteyen eski davranışa Ses çıkışı: Sistem ile dönebilir, tam sessizde de duymak isteyen Medya seçebilir.

**İnceleme**
- Şifreli bağlantı çekirdeği (`SecureForwarder`: DoT / DoH / ODoH) kaynak kodundan yeniden gözden geçirildi: HTTP ayrıştırma (chunked + content-length çakışmasında chunked önceliği), sınır denetimleri, şerit eşzamanlılığı ve TLS 1.2/1.3 sabitlemesi. Yeni bir açık ya da hata bulunmadı; değişiklik yapılmadı.

**Test:** tüm JVM testleri, 0 hata (ses kanalı seçimine titreşim + medya durumları eklendi).

## 1.23.0 (versionCode 40)

**Yeni**
- **Oblivious DoH (ODoH, RFC 9230)**, isteğe bağlı, varsayılan **kapalı** (☰ > DNS ayarları > Oblivious DoH: Kapalı / Yedekli / Sıkı). Sorgu hedef sunucunun anahtarıyla şifrelenip bir **röle** üzerinden gider: röle IP'nizi görür ama soruyu göremez, DNS sunucusu soruyu görür ama sizi göremez.
  - *Yedekli:* önce ODoH; kurulamazsa normal şifreli yöntemler (gizlilik düştü uyarısıyla) ve ODoH'a dönmek için arka planda yeniden deneme. *Sıkı:* yalnızca ODoH; kurulamazsa bağlanmaz, hiçbir yönteme düşmez.
  - ODoH seçili DNS sunucusundan bağımsızdır; uygulamanın kendi röle + hedef çiftlerini kullanır (2 röle × 3 hedef, her çiftte iki ayrı işletmeci; aynı işletmeci ya da alan adı eşleşmez, kurucu bunu reddeder).
- **Kendini onaran, çok katmanlı motor:** (1) yol seçimi: gecikme + hata puanı, devre kesici, üstel geri çekilme (2 sn → 2 dk, ±%20 sapma), yarı açık tek deneme, bayat yolların yoklanması; (2) anahtar yönetimi: tek uçuşlu alım, 6 saat taze, alınamazsa 7 güne kadar bayat anahtarla devam, 401'de hız sınırlı yenileme (anahtar dönmesi arıza sayılmaz); (3) adresler: son çalışan → ipucu → şifreli (DoT) ad çözümü, düz DNS hiç kullanılmaz; (4) bağlantı: aynı sorguda ölü röleden sonra başka röleye geçiş, sahte/bozuk cevap yolu uzun süre keser; (5) ağ değişince yol bilgisi sıfırlanır.
- Gizlilik ayrıntıları: her sorgu için taze HPKE anahtarı, DNS kimliği 0, düz metin 128 baytın katına doldurulur, cevaplar kimlik doğrulamalı; hedefin yapılandırması doğrudan (röleden değil) alınır, bu sırada hedef IP'nizi görür ama soru görmez.
- Kendi X25519 + HPKE (RFC 9180) gerçeklemesi (dış kütüphane yok); RFC 7748 / RFC 9180 vektörleriyle ve JDK ile 300 rastgele çapraz sınamayla doğrulandı.
- Araç: `tools/odoh_check.py` canlı röle/hedef denetimi.

**Dürüst sınırlar**
- ODoH yalnızca **DNS sağlayıcısından IP'nizi** saklar. Operatörünüz, Wi-Fi sahibi ve bağlandığınız siteler IP'nizi yine görür; röle trafik zamanını ve hacmini görür. Gizlilik, rölenin ve hedefin **anlaşmamasına** dayanır.
- Gerçek röle/hedeflerle **canlı uyumluluk bu ortamda denenemedi** (ağ yok); şifreleme RFC vektörleriyle ve bağımsız bir sunucu benzetimiyle sınandı. Röle/hedef IP ipuçları Ekim 2026 tarihlidir. Cihazda denenmedi: VPN servisi entegrasyonu, bildirimler, ağ değişimi.

**Test:** 6153 kontrol, 0 hata (212 yeni: şifreleme, yapılandırma, ileti biçimi, yol tahtası, anahtar önbelleği, katalog, adres defteri, ayarlar, uçtan uca benzetim).

## 1.22.0 (versionCode 39)

**Yeni**
- **Liquid Glass stili:** yarı saydam mavi-indigo cam, parlak beyaz kenar ışığı, cam anahtar damlası. Kendi dokunma efekti, ses paketi (parlak, dalgalanan cam tınısı) ve uygulama simgesi (cam küre içinde kalkan ve güç simgesi).
- **Her stile 4 yeni animasyon:** panel açılması, geri, seçim, yenileme. Sekiz mevcut paket için ayrı çizimler; Liquid Glass'ın 10 animasyonunun hepsi kendine özel. Toplam 10 paket × 10 animasyon.
- **Her ses paketine 2 yeni ses:** seçim ve yenileme. Seçenek, sunucu veya tema seçince seçim sesi; ölçüm ve bağlantı testi başlayınca yenileme sesi çalar.

**Değişti**
- Uygulama **güvenlik / ağ aracı** olarak konumlandırıldı: mağaza metni ve kısa açıklamalar (12 dil) "zararlı, kimlik avı ve izleyici alan adlarına karşı koruma" diline çevrildi.
- Stil, simge ve ses paketi açıklamaları 12 dilde güncellendi.

**Test:** 5941 kontrol, 0 hata. Cihazda doğrulanmadı: görünüm, ses beğenisi, yeni simgenin başlatıcıdaki görünümü.

## 1.21.9
- Gömülü **Public Suffix List**: "aynı site" kararı gerçek eTLD+1'e bakar (co.uk, com.tr, github.io…); sıcak yolda bellek ayırmaz.
- **Filtre belleği** ayarı: Otomatik / Hafif / Tam. Az belleği olan telefonda en büyük liste atlanır, bellek yetmezse çökmeden devam edilir.
- "Yalnızca seçilenler"de seçili uygulama yoksa koruma **başlamaz** (Android boş listeyi "hepsi" sayar); hata gösterilir.
- Play beyan taslağına kontrol listesi eklendi.

## 1.21.8
- Filtre listeleri akışla okunur (tam dosya ayrıca belleğe alınmaz), bellek yetmezse yedek yol.
- Özel son ek listesi, SecureForwarder yarışı, TcpDns port sarması düzeltmeleri, ayar önbelleği.

## 1.21.5 – 1.21.7
- Dış incelemelerden doğrulanan düzeltmeler: içe aktarılan listenin korunan adları geçemesi, tema örnek küresi önbelleği, CNAME sayacının atomik olması, ağ geçidi adres elemesi, regresyon testleri.

## 1.10 – 1.21
- Kendi kullanıcı alanı TCP/UDP aktarıcısı (ağ geçidi), DPI atlatma ve Reklam+ düğmeleri, mobil ağ politikası, ses uyumluluğu (Rahatsız Etmeyin), yeni hareket motoru, ses efektleri, stile özgü efektler, profiller, sessiz saatler.

## 1.9.x
- Dört seviyeli koruma/engelleme, izin ve engel listesi, kendini onarma, kendi TCP katmanımız, bildirim sistemi, gecikme grafiği, kendi liste içe/dışa aktarma, Aurora stili, IPv4 + IPv6.

## 1.1 – 1.8
- Özel DNS sunucuları ve 32'lik katalog, uygulama başına kapsam, stiller ve sayfa geçişleri, arka plan fotoğrafı, uygulama simgeleri, sorun giderici, sunucu arama, ☰ menü ve Hakkında, kişiselleştirme penceresi.

### oto-koruma 18: günlük ayrıntısı, sızıntı denetimi, modül uyumu
- Günlük: kapasite 120 → 400; satırlar `[KATEGORİ]`, `! [KATEGORİ]` (uyarı), `!! [KATEGORİ]` (hata) önekli. Hata satırlarında artık özel durumun sınıfı, nedeni ve kodun dosya:satır konumu var (ileti metni yine yazılmaz: ad/adres sızmasın). Tanılama raporu 40 → 90 olay, 9000 karakter.
- 5 dakikada bir `[ÖZET]` satırı: ağ türü, DNS, ağ geçidi, DPI başarı/başarısızlık, DoH engeli, sızıntı sayaçları, liste durumu, aktif oto-koruma önlemleri.
- Sızıntı: DNS+DPI (Reklam+ kapalı) birleşiminde DoH/DoT atlatması artık ağ geçidinde engellenir (`Coherence.blockDoh`: DNS açık ve Reklam+ ya da DNS sızıntı kalkanı açık). Önceden yalnızca Reklam+ ile engelleniyordu.
- `LeakAudit`: sabit sunucuya giden düz UDP/TCP 53'ün tünele alınma sayıları. `[SIZINTI]` satırları: DoH girişimi engeli, Özel DNS sabitliği, kalkan.
- `Coherence.warnings`: modüller birbiriyle çelişirse `[UYUM]` uyarısı (DPI açık/DNS kapalı, liste yüklenmedi, DoH engeli yok…).
- Not: Android'e özel kod (DnsVpnService) yerelde derlenemedi; JVM testleri 10850 kontrol, 0 başarısız.

### oto-koruma 19: sürekli denetim katmanı, ayrıntılı kategorili günlük, cihaz uyumu
- `Audit` (core/Audit.kt): 30 sn'de bir sayaç ölçümü alır, 5 dk'lık pencerede sızıntı (tünel yok, DNS atlatma, DoH açık), DPI (başarısızlık, kesinti, tükenen hedef), reklam (liste yok, hiç engel yok, ECH), sızma (sahte DNS cevabı, sertifika uyuşmazlığı, saat, yoğun trafik), istikrar (zaman aşımı, bağlantı hatası, yedeğe geçiş, ağ dalgalanması, sık yeniden kurulma) ve kaynak (akış sınırı) bulguları üretir. Her bulgu bir kez bildirilir, sürerse 30 dk'da bir tekrarlanır. Güven puanı: 100 − 30×kritik − 10×uyarı.
- Kritik bulgularda (uyarı bildirimleri açıksa) bildirim; her bulgu günlüğe kategorisiyle yazılır.
- Günlük: kapasite 800 (2 kat), eski satırlar anahtar sözcükle kategorilenir; rapor 18000 karakter, 220 olay; bölümler: Denetim, Uyumluluk, Ayarlar, Olay özeti, Kategoriler, Son sayaçlar, kategori başlıklı olaylar.
- Hata/kopma anında (tünel kapandı, bağlanamadı, bağlantı kesildi) durum özeti anında yazılır.
- `Compat`: cihaz sınıfı/RAM/yığın sınırına göre ağ geçidi akış sınırları (TCP 400–1500, UDP 120–400), agresif sistemlerde 3 dk'da bir özet ve pil/ROM notları (Samsung, özel ROM, GrapheneOS/CalyxOS, eski Android).
- Android'e özel kod (DnsVpnService, Notifier, MainActivity) yerelde derlenemedi; JVM testleri 10890 kontrol, 0 başarısız.

### oto-koruma 20: 12 dilde bulgu metinleri, katmanlı uyum planı
- Denetim bulguları, uyum notları ve modül uyarıları artık KOD + değişken olarak taşınır; metin görüntülenirken seçili dilde üretilir (`AuditText`; TR, EN, DE, ES, FR, PT, RU, IT, ID, VI, PL, UK; 55+ kod). Testler her kodun 12 dilde dolu, değişkenlerinin aynı ve içinde alan adı/IP benzeri değer olmadığını doğrular. Günlüğe yazılan satırlar yazıldığı andaki dilde kalır.
- `Compat` katmanlı hale geldi: cihaz sınıfı/bellek, kapatılma eğilimi (üretici/ROM), pil tasarrufu, ağ türü (ölçülü mobil, yalnızca IPv6), soket yeteneği (TTL), bileşik kısıt (≥2 kısıt: ek daralma + Hafif filtre önerisi), sistem sürümü. Katmanlar yalnızca kısar; test bunu doğrular.
- Plan ağ geçidine uygulanır: TCP/UDP akış sınırı, UDP/TCP boşta süresi, paralel yedek deneme; ayrıca denetim ve özet aralığı. Üretici başına (Xiaomi, Huawei/Honor, OPPO/realme/OnePlus, vivo, Samsung) yönerge notları.
- Android'e özel kod (DnsVpnService) yerelde derlenemedi; JVM testleri 11119 kontrol, 0 başarısız.
