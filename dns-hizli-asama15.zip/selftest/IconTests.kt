package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

private fun contrast(a: Int, b: Int): Float {
    fun lin(c: Int): Float { val v = c / 255f; return if (v <= 0.03928f) v / 12.92f else Math.pow(((v + 0.055f) / 1.055f).toDouble(), 2.4).toFloat() }
    fun lum(c: Int) = 0.2126f * lin(Rgb.r(c)) + 0.7152f * lin(Rgb.g(c)) + 0.0722f * lin(Rgb.b(c))
    val x = lum(a); val y = lum(b)
    return (maxOf(x, y) + 0.05f) / (minOf(x, y) + 0.05f)
}

/** Aşama 7: uygulama simgesi seçimi ve yardım sayfasının yeşil kapanış cümlesi. */
fun testAppIcon() {
    T.group("Simge: ayar")
    run {
        T.check("varsayılan simge Aqua", AppSettings().appIcon == UiStyle.AQUA)
        for (st in UiStyle.values()) T.check("${st.label}: kodlayıcı gidiş-dönüş", SettingsCodec.decode(SettingsCodec.encode(AppSettings(appIcon = st))).appIcon == st)
        T.check("bozuk simge değeri varsayılana düşer", SettingsCodec.decode(mapOf("appIcon" to "zzz")).appIcon == UiStyle.AQUA)
        val exp = SettingsCodec.export(AppSettings(appIcon = UiStyle.ECO))
        val keys = String(Base64Mini.decode(exp.removePrefix("DNSH1:"))!!, Charsets.UTF_8).lines().map { it.substringBefore('=') }
        T.check("simge cihaza özel: dışa aktarılmaz", "appIcon" !in keys, keys.toString())
        T.check("içe aktarım bu telefonun simgesini değiştirmez", SettingsCodec.import(exp, AppSettings(appIcon = UiStyle.Y2K))?.appIcon == UiStyle.Y2K)
    }

    T.group("Simge: ayarlardan akış")
    run {
        val r = Rig()
        r.scene.openPersonalize(); r.settle(900)
        fun shown(w: String) = TextRecorder().also { r.scene.draw(it) }.runs.any { it.s == w }
        T.check("kişiselleştirmede Uygulama simgesi satırı var, geçerli adı gösterir", r.find(Strings.APP_ICON) != null && r.find(Strings.APP_ICON)!!.info.label.isNotBlank())
        r.tapText(Strings.APP_ICON, settleMs = 800)
        T.check("seçici beş simgeyi ve açıklamalarını listeler", UiStyle.values().all { r.find(it.label, exact = false) != null } && r.find(Strings.ICON_NOTES[3]) != null)
        T.check("seçicinin altında kısayol uyarısı yazar", shown(Strings.ICON_NOTE) || TextRecorder().also { r.scene.draw(it) }.runs.any { Strings.ICON_NOTE.startsWith(it.s.removeSuffix("…").trim()) && it.s.length > 8 })
        r.tapText(Strings.ICON_NOTES[3], settleMs = 1000)
        T.check("Eco seçilince platform çağrılır, ayar kaydedilir, bildirim çıkar",
            r.host.calls.contains("icon:eco") && r.model.settings.appIcon == UiStyle.ECO && r.scene.toastActive)
        T.check("bildirim metni", TextRecorder().also { r.scene.draw(it) }.runs.any { it.s == Strings.ICON_SET })
        r.settle(4500)
        val n = r.host.calls.count { it.startsWith("icon:") }
        r.tapText(Strings.APP_ICON, settleMs = 800)
        r.tapText(Strings.ICON_NOTES[3], settleMs = 1000)
        T.check("aynı simge yeniden seçilince platform çağrılmaz", r.host.calls.count { it.startsWith("icon:") } == n)
        r.tapText(Strings.APP_ICON, settleMs = 800)
        r.host.iconOk = false
        r.tapText(Strings.ICON_NOTES[4], settleMs = 1000)
        T.check("platform reddederse ayar değişmez ve hata bildirimi çıkar", r.model.settings.appIcon == UiStyle.ECO && shown(Strings.ICON_FAILED))
        r.host.iconOk = true
        r.settle(4500)
        r.tapText(Strings.APP_ICON, settleMs = 800)
        r.tapText(Strings.ICON_NOTES[0], settleMs = 1000)
        T.check("Aqua'ya dönüş", r.model.settings.appIcon == UiStyle.AQUA && r.host.calls.last() == "icon:aqua")
    }

    T.group("Simge: yardım sayfasının yeşil kapanış cümlesi")
    run {
        var worst = 99f; var worstId = ""
        for (t in Themes.all) {
            val th = t
            val ink = if (th.dark) 0xFF7EE2A2.toInt() else 0xFF166534.toInt()
            val card = if (th.dark) Rgb.lerp(th.skyMid, 0xFF000000.toInt(), 0.35f) else Rgb.lerp(th.skyMid, Rgb.WHITE, 0.6f)
            val c = contrast(ink, card); if (c < worst) { worst = c; worstId = th.id }
        }
        T.check("yeşil yazı her temada kartın üstünde okunur (kontrast ≥ 4,5)", worst >= 4.5f, "en düşük %.2f (%s)".format(worst, worstId))
    }
    for (th in listOf("aqua", "night", "sakura", "meadow", "amoled", "honey")) for (st in UiStyle.values()) {
        val r = Rig(Rig.base(th).copy(style = st))
        r.scene.openHelp(); r.settle(1200)
        val page = r.scene.currentPage as ScrollPage
        var last = -1f
        repeat(40) { if (page.scrollOffset != last) { last = page.scrollOffset; r.drag(180f, r.h * 0.7f, r.h * 0.7f - 260f, 8); r.advance(300) } }
        val rec = TextRecorder().also { r.scene.draw(it) }
        val tail = rec.runs.firstOrNull { Strings.HELP_WHY_TAIL.startsWith(it.s) }
        val body = rec.runs.firstOrNull { Strings.HELP_WHY_BODY.startsWith(it.s) }
        val want = if (r.scene.env.theme.dark) 0xFF7EE2A2.toInt() else 0xFF166534.toInt()
        val where = "$th/${st.label}"
        T.check("$where: son cümle sayfanın sonunda, yeşil ve gövdenin altında", tail != null && body != null && tail.color == want && tail.t > body.b && body.color != tail.color, "tail=${tail?.s} color=${tail?.color?.toString(16)}")
        T.check("$where: kapanış kartında üst üste binen yazı yok", rec.overlaps().none { (a, b) -> a === tail || b === tail || a === body || b === body })
    }
    run {
        val r = Rig(); r.scene.openHelp(); r.settle(900)
        val page = r.scene.currentPage as ScrollPage
        val seen = LinkedHashSet<String>()
        var last = -1f
        repeat(40) { for (i in r.items()) seen.add(i.info.label); if (page.scrollOffset != last) { last = page.scrollOffset; r.drag(180f, r.h * 0.7f, r.h * 0.7f - 260f, 8); r.advance(300) } }
        T.check("a11y: gövde ve son cümle tek metin olarak okunur", seen.any { it == Strings.HELP_WHY_BODY + " " + Strings.HELP_WHY_TAIL })
    }

    T.group("Simge: her dilde metinler")
    val saved = L.lang
    try {
        for (lang in Lang.values()) {
            L.set(lang)
            val n = Strings.ICON_NOTES
            T.check("${lang.native}: simge metinleri dolu, 5 açıklama benzersiz ve kısa",
                Strings.APP_ICON.isNotBlank() && n.size == 5 && n.toSet().size == 5 && n.all { it.length in 10..90 } &&
                    Strings.ICON_SET.length in 8..34 && Strings.ICON_NOTE.length in 25..110 && Strings.ICON_FAILED.length in 8..40, n.toString())
            T.check("${lang.native}: kapanış bölümü: başlık, gövde, son cümle", Strings.HELP_WHY_TITLE.length in 5..40 && Strings.HELP_WHY_BODY.length in 80..260 && Strings.HELP_WHY_TAIL.length in 30..120,
                "${Strings.HELP_WHY_BODY.length}/${Strings.HELP_WHY_TAIL.length}")
            T.check("${lang.native}: yenilikler arasında simge maddesi", Strings.WHATS_NEW_ITEMS.size >= 3 && Strings.WHATS_NEW_ITEMS[1].length in 25..160)
        }
    } finally { L.set(saved) }
}
