import java.util.Properties
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Yayın imzası: proje köküne keystore.properties koyarsan (bkz. OKUBENI.md) yayın derlemesi imzalanır.
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

// Play Store'a yüklemeden önce kendi benzersiz kimliğinle değiştir (ör. com.seninadin.dnshizli).
// Yalnızca BU satır değişir: kod paketi (namespace) "app.dnshizli" kalır, kısayollar kimliği buradan alır.
val appId = "app.dnshizli"

android {
    namespace = "app.dnshizli"
    // Google Play, yeni uygulama ve güncellemelerde (31 Ağustos 2026'dan beri) hedef API 36 ister; her yıl bir üst sürüme çıkar.
    compileSdk = 36

    defaultConfig {
        applicationId = appId
        // shortcuts.xml içindeki targetPackage bu değeri kullanır (@string/app_package).
        resValue("string", "app_package", appId)
        minSdk = 26
        targetSdk = 36
        versionCode = 18
        versionName = "1.9.7"
    }

    signingConfigs {
        // Sabit, herkese açık "debug" anahtarı (gizli değildir): GitHub'da her derleme aynı anahtarla imzalanır, böylece yeni APK
        // eskisinin ÜZERİNE kurulur (her çalıştırmada rastgele yeni anahtar üretilseydi "paket çakışıyor" hatası alınırdı).
        // Play Store'a yüklenecek yayın için bu anahtar KULLANILMAZ; aşağıdaki "release" anahtarı kullanılır.
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        create("release") {
            if (keystoreProps.isNotEmpty()) {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (keystoreProps.isNotEmpty()) signingConfig = signingConfigs.getByName("release")
        }
    }

    buildFeatures {
        resValues = true   // AGP 8'de varsayılan kapalı; app_package metin kaynağı için gerekli
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        // Yayın derlemesi, uyarılar yüzünden durmasın; ./gradlew lint ile raporu ayrıca incele.
        abortOnError = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

// Bağımlılık yok: yalnızca Android çatısı ve Kotlin standart kütüphanesi. Bu, uygulamanın küçük
// ve hızlı açılan kalmasının nedenlerinden biridir.
