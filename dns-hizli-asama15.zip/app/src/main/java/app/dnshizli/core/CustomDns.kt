package app.dnshizli.core

/**
 * Kullanıcının kendi eklediği DNS sunucuları. Adresler IPv4 ya da IPv6 olabilir; şifreli bağlantı için isteğe bağlı
 * DoT sertifika adı ve DoH adresi girilebilir. Girdiler hem eklerken hem diskten okurken aynı kurallarla
 * doğrulanır: bozuk ya da elle değiştirilmiş bir kayıt sessizce atlanır, uygulamayı bozmaz.
 * Özel sunucular dışa aktarılan koda GİRMEZ (paylaşılan bir kod DNS'ini başkasına yönlendirmesin).
 */
object CustomDns {
    const val MAX = 8
    const val NAME_MAX = 24
    private const val URL_MAX = 200

    /** Kullanıcının doldurduğu alanlar (boşlar ""). */
    class Draft(val name: String, val ip1: String, val ip2: String, val dot: String, val doh: String)

    enum class Error { NAME, IP, IP2, DOT, DOH, LIMIT }

    private val HOST = Regex("^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$")
    private val PATH = Regex("^[A-Za-z0-9._~/%=-]*$")
    private val ID = Regex("^u[0-9a-z]{1,10}$")

    fun cleanName(s: String): String = s.trim().replace(Regex("\\s+"), " ")

    fun validName(s: String): Boolean =
        s.length in 1..NAME_MAX && s.none { it.isISOControl() || it in "|;,=" }

    /**
     * IPv4 ya da IPv6 adresi. Geri döngü, "bu ağ", çok noktaya yayın ve bu uygulamanın tünel adresleri geçersizdir.
     * IPv6'da yalnızca herkese açık (2000::/3) ve yerel (fc00::/7) adresler kabul edilir (bağlantı-yerel adresler bölge
     * numarası ister; IPv4'e eşlenmiş adresler anlamsızdır).
     */
    fun validIp(s: String): Boolean {
        val v4 = Ip.parse4(s)
        if (v4 != null) {
            val p = IntArray(4) { v4[it].toInt() and 0xFF }
            if (p[0] == 0 || p[0] == 127 || p[0] >= 224) return false
            if (p[0] == 10 && p[1] == 111 && p[2] == 222) return false
            return Catalog.isIpv4(s)                                   // öndeki sıfırlar ("01.2.3.4") kabul edilmez
        }
        val v6 = Ip.parse6(s) ?: return false
        val b0 = v6[0].toInt() and 0xFF
        if ((b0 and 0xE0) != 0x20 && (b0 and 0xFE) != 0xFC) return false   // 2000::/3 ya da fc00::/7
        if (Ip.sameNet(v6, SelfTest.CLIENT6, 6)) return false                // bu uygulamanın tünel adresleri
        return true
    }

    fun validDot(s: String): Boolean = s.length <= 253 && HOST.matches(s) && !Ip.isAddress(s)

    fun validDoh(s: String): Boolean {
        if (s.length > URL_MAX || !s.startsWith("https://")) return false
        val rest = s.removePrefix("https://")
        val host = rest.substringBefore('/')
        val path = if (rest.contains('/')) rest.substring(rest.indexOf('/')) else ""
        return HOST.matches(host) && !Ip.isAddress(host) && PATH.matches(path)
    }

    /** Aynı adres mi? (IPv6 farklı yazılabilir: "2606:4700::1" = "2606:4700:0:0:0:0:0:1".) */
    private fun sameIp(a: String, b: String): Boolean {
        val x = Ip.parse(a)
        val y = Ip.parse(b)
        return if (x != null && y != null) x.contentEquals(y) else a == b
    }

    /** İlk hata ya da null (geçerli). [existing]: şimdiki özel sunucu sayısı. */
    fun validate(d: Draft, existing: Int = 0): Error? {
        if (existing >= MAX) return Error.LIMIT
        if (!validName(cleanName(d.name))) return Error.NAME
        if (!validIp(d.ip1.trim())) return Error.IP
        val ip2 = d.ip2.trim()
        if (ip2.isNotEmpty() && (!validIp(ip2) || sameIp(ip2, d.ip1.trim()))) return Error.IP2
        val dot = d.dot.trim()
        if (dot.isNotEmpty() && !validDot(dot)) return Error.DOT
        val doh = d.doh.trim()
        if (doh.isNotEmpty() && !validDoh(doh)) return Error.DOH
        return null
    }

    fun build(id: String, d: Draft): DnsServer = DnsServer(
        id = id, brand = cleanName(d.name), variant = null,
        primary = d.ip1.trim(), secondary = d.ip2.trim().ifEmpty { null },
        tags = emptySet(),
        dot = d.dot.trim().ifEmpty { null }, doh = d.doh.trim().ifEmpty { null },
        custom = true,
    )

    /** Çakışmayan yeni kimlik: "u" + zaman (36'lık tabanda). Silinen bir kimlik eski kayıtlara bağlanmasın diye zamana bağlı. */
    fun newId(nowMs: Long, taken: Collection<String>): String {
        var n = nowMs / 1000
        while (true) {
            val id = "u" + java.lang.Long.toString(n, 36)
            if (id.length <= 11 && id !in taken && Catalog.builtin.none { it.id == id }) return id
            n++
        }
    }

    /** "kimlik|ad|ip1|ip2|dot|doh" satırları ";" ile ayrılır. */
    fun encode(list: List<DnsServer>): String = list.filter { it.custom }.joinToString(";") {
        listOf(it.id, it.brand, it.primary, it.secondary ?: "", it.dot ?: "", it.doh ?: "").joinToString("|")
    }

    fun decode(s: String?): List<DnsServer> {
        if (s.isNullOrBlank() || s.length > 4096) return emptyList()
        val out = ArrayList<DnsServer>()
        for (part in s.split(';')) {
            if (out.size >= MAX) break
            val f = part.split('|')
            if (f.size != 6) continue
            val id = f[0]
            if (!ID.matches(id) || out.any { it.id == id } || Catalog.builtin.any { it.id == id }) continue
            val d = Draft(f[1], f[2], f[3], f[4], f[5])
            if (validate(d, 0) != null || cleanName(d.name) != d.name) continue
            out.add(build(id, d))
        }
        return out
    }
}
