package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Y2K fütürizmi: buz mavisi, gümüş ve parlak beyaz; keskin vurgu olarak lime yeşili ve turuncu. Gökyüzünde yavaşça süzülen
 * sıvı krom damlalar ve yörünge halkası, dört köşeli yıldız parıltıları, şeffaf plastik (iMac G3 gibi) şeker düğmeler,
 * kalın krom çerçeveli buzlu cam kartlar.
 * Hareket: yaylı (geri sekmeli) açılış; kürede ışık taraması ve dönen parıltı.
 */
class Y2kArt(theme: AeroTheme, glass: Float) : AeroArt(theme, glass) {
    override val style: UiStyle get() = UiStyle.Y2K
    override val particleMode: ParticleMode get() = ParticleMode.TWINKLE
    override val liveSky: Boolean get() = true
    override val motion: StyleMotion = StyleMotion(PageMotion.POP, 0.42f, 0.03f, 1f)

    private val ice = 0xFFBFE8FF.toInt()
    private val cyan = 0xFF7FE3FF.toInt()
    private val silver = 0xFF8FA3C0.toInt()
    private val lime = 0xFFB4F03C.toInt()
    private val orange = 0xFFFF8A2B.toInt()

    // ------------------------------------------------------------------ parıltı (dört köşeli yıldız)

    private val star = GPath().apply {
        moveTo(0f, -1f)
        quadTo(0.13f, -0.13f, 1f, 0f)
        quadTo(0.13f, 0.13f, 0f, 1f)
        quadTo(-0.13f, 0.13f, -1f, 0f)
        quadTo(-0.13f, -0.13f, 0f, -1f)
        close()
    }
    private val starFill = Fill.radial(0f, 0f, 1f, white(1f), white(0.92f), Rgb.alpha(ice, 0.85f), 0.45f)
    private val starLime = Fill.radial(0f, 0f, 1f, white(1f), Rgb.alpha(lime, 0.95f), Rgb.alpha(lime, 0.80f), 0.40f)
    private val starOrange = Fill.radial(0f, 0f, 1f, white(1f), Rgb.alpha(orange, 0.95f), Rgb.alpha(orange, 0.80f), 0.40f)
    private val starGlow = Fill.radial(0f, 0f, 1f, white(if (dark) 0.40f else 0.55f), white(0f))

    private fun sparkle(g: Gfx, x: Float, y: Float, r: Float, a: Float, tone: Int = 0) {
        if (a <= 0.02f) return
        g.save(); g.translate(x, y); g.alpha(min(1f, a))
        g.save(); g.scale(r * 1.7f, r * 1.7f); g.paint(starGlow); g.circle(0f, 0f, 1f); g.restore()
        g.scale(r, r); g.paint(if (tone == 1) starLime else if (tone == 2) starOrange else starFill); g.path(star)
        g.restore()
    }

    override fun particle(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float, phase: Float) {
        val tw = 0.5f + 0.5f * sin(phase * 2f)
        val tone = ((phase * 3.1f).toInt() and 0x7fffffff) % 6
        sparkle(g, cx, cy, r * (0.45f + 0.65f * tw), alpha * (0.25f + 0.75f * tw), if (tone == 0) 1 else if (tone == 3) 2 else 0)
    }

    override fun bubble(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float) = particle(g, cx, cy, r, alpha, 0.8f)

    // ------------------------------------------------------------------ gökyüzü

    private class Backdrop(val w: Float, val h: Float, art: Y2kArt) {
        val th = art.theme
        val dk = art.dark
        private val p0 = if (dk) 0xFF0D1B3D.toInt() else 0xFFEAF6FF.toInt()
        private val p1 = if (dk) 0xFF16305E.toInt() else 0xFFC3E4FF.toInt()
        private val p2 = if (dk) 0xFF0B1E40.toInt() else 0xFF9CCBF0.toInt()
        val base = Fill.linear(0f, 0f, 0f, h,
            Rgb.lerp(th.skyTop, p0, 0.62f), Rgb.lerp(th.skyMid, p1, 0.62f), Rgb.lerp(th.skyBottom, p2, 0.62f), AeroTheme.SKY_MID_POS)
        private val ha = if (dk) 0.14f else 0.34f
        val holo = Fill.linear(-w * 0.2f, 0f, w * 1.2f, h * 0.9f,
            Rgb.alpha(art.cyan, ha), Rgb.alpha(Rgb.WHITE, ha * 1.4f), Rgb.alpha(art.silver, ha), 0.5f)
        val flare = Fill.radial(0f, 0f, 1f, Rgb.alpha(Rgb.WHITE, if (dk) 0.14f else 0.70f), Rgb.alpha(art.cyan, if (dk) 0.06f else 0.20f), Rgb.alpha(art.cyan, 0f), 0.45f)
        // sıvı krom damla: birim koordinatlarda
        val blob = GPath().apply {
            moveTo(0f, -1f)
            cubicTo(0.70f, -1.00f, 1.10f, -0.30f, 0.90f, 0.30f)
            cubicTo(0.70f, 0.90f, 0.10f, 1.10f, -0.50f, 0.80f)
            cubicTo(-1.10f, 0.50f, -1.00f, -0.60f, -0.40f, -0.90f)
            close()
        }
        val blobFill = Fill.linear(-1f, -1f, 1f, 1f,
            Rgb.alpha(Rgb.WHITE, if (dk) 0.45f else 0.97f), Rgb.alpha(0xFF6F86AA.toInt(), if (dk) 0.55f else 0.88f),
            Rgb.alpha(Rgb.WHITE, if (dk) 0.35f else 0.95f), 0.50f)
        val blobShine = Fill.radial(-0.35f, -0.45f, 0.55f, Rgb.alpha(Rgb.WHITE, if (dk) 0.50f else 0.95f), Rgb.alpha(Rgb.WHITE, 0f))
        val ring = GPath().apply {
            arc(0f, 0f, 1f, 1f, 0f, 90f, false); arc(0f, 0f, 1f, 1f, 90f, 90f, true)
            arc(0f, 0f, 1f, 1f, 180f, 90f, true); arc(0f, 0f, 1f, 1f, 270f, 90f, true); close()
        }
    }

    private var back: Backdrop? = null

    private fun backdrop(w: Float, h: Float): Backdrop {
        var b = back
        if (b == null || b.w != w || b.h != h) { b = Backdrop(w, h, this); back = b }
        return b
    }

    override fun sky(g: Gfx, w: Float, h: Float) = skyFrame(g, w, h, false, 0f)

    private fun chromeBlob(g: Gfx, b: Backdrop, x: Float, y: Float, r: Float, rot: Float, flip: Float) {
        g.save(); g.translate(x, y); g.rotate(rot); g.scale(r * flip, r)
        g.paint(b.blobFill); g.path(b.blob)
        g.paint(b.blobShine); g.path(b.blob)
        g.strokeWidth(0.035f); g.paint(white(if (dark) 0.55f else 0.95f)); g.strokePath(b.blob)
        g.restore()
    }

    override fun skyFrame(g: Gfx, w: Float, h: Float, live: Boolean, time: Float) {
        val b = backdrop(w, h)
        g.paint(b.base); g.rect(0f, 0f, w, h)
        val t = if (live) time else 0f
        // buz mavisi parıltı şeridi yavaşça yana kayar
        g.save(); g.translate(sin(t * 0.22f) * w * 0.28f, 0f)
        g.paint(b.holo); g.rect(-w * 0.6f, 0f, w * 1.8f, h)
        g.restore()
        // yumuşak ışık lekeleri
        for (i in 0 until 3) {
            val x = w * (0.2f + 0.3f * i) + sin(t * 0.25f + i * 2f) * w * 0.05f
            val y = h * (0.12f + 0.30f * i) + cos(t * 0.2f + i) * h * 0.03f
            g.save(); g.translate(x, y); g.scale(w * (0.55f - 0.08f * i), w * (0.55f - 0.08f * i)); g.paint(b.flare); g.circle(0f, 0f, 1f); g.restore()
        }
        // ince sayısal ızgara (teknolojik Y2K dokusu)
        g.strokeWidth(1f); g.paint(white(if (dark) 0.05f else 0.20f))
        var gx = 14f
        while (gx < w) { g.line(gx, 0f, gx, h); gx += 28f }
        var gy = 14f
        while (gy < h) { g.line(0f, gy, w, gy); gy += 28f }
        // yörünge halkası ve üstünde turuncu / lime noktalar (kalın, sade çizgi)
        val rx = w * 0.62f
        val ry = w * 0.19f
        val rot = -18f
        val ox = w * 0.52f
        val oy = h * 0.30f
        g.save(); g.translate(ox, oy); g.rotate(rot); g.scale(rx, ry)
        g.strokeWidth(0.05f); g.paint(white(if (dark) 0.22f else 0.70f)); g.strokePath(b.ring)
        g.restore()
        val rr = rot * PI.toFloat() / 180f
        for (i in 0 until 2) {
            val a = t * (0.35f + 0.1f * i) + i * 3.2f
            val ex = rx * cos(a)
            val ey = ry * sin(a)
            val px = ox + ex * cos(rr) - ey * sin(rr)
            val py = oy + ex * sin(rr) + ey * cos(rr)
            g.paint(if (i == 0) lime else orange); g.circle(px, py, 4.2f)
            g.paint(white(0.85f)); g.circle(px - 1.1f, py - 1.3f, 1.3f)
        }
        // sıvı krom damlalar
        chromeBlob(g, b, -w * 0.02f + sin(t * 0.19f) * w * 0.02f, h * 0.20f + cos(t * 0.15f) * h * 0.015f, w * 0.22f, 20f + sin(t * 0.1f) * 6f, 1f)
        chromeBlob(g, b, w * 1.0f + cos(t * 0.17f) * w * 0.02f, h * 0.98f + sin(t * 0.13f) * h * 0.012f, w * 0.20f, -35f + cos(t * 0.1f) * 6f, -1f)
    }

    // ------------------------------------------------------------------ krom

    private val chromeCache = LongCache<Fill>(40)

    private fun chrome(h: Float, vertical: Boolean = true): Fill {
        val k = key(1f, h, if (vertical) 11f else 12f)
        var f = chromeCache[k]
        if (f == null) {
            val c0 = white(0.98f)
            val c1 = Rgb.alpha(silver, 0.92f)
            f = if (vertical) Fill.linear(0f, 0f, 0f, h, c0, c1, c0, 0.55f) else Fill.linear(0f, 0f, h, h, c0, c1, c0, 0.55f)
            chromeCache[k] = f
        }
        return f
    }

    // ------------------------------------------------------------------ kart

    private class CardP(val w: Float, val h: Float, art: Y2kArt) {
        val body = Fill.linear(0f, 0f, 0f, h, art.tint(art.aTop), art.tint(art.aBot))
        val bodyStrong = Fill.linear(0f, 0f, 0f, h, Rgb.alpha(art.theme.skyTop, 0.97f), Rgb.alpha(art.theme.skyMid, 0.97f))
        val holo = Fill.linear(0f, 0f, w, h, Rgb.alpha(Rgb.WHITE, 0.98f), Rgb.alpha(art.silver, 0.95f), Rgb.alpha(Rgb.WHITE, 0.98f), 0.5f)
        val gloss = GPath()
        val glossFill: Fill

        init {
            val rr = min(14f, min(w, h) / 2f)
            gloss.arc(rr, rr, rr, rr, 180f, 90f, false)
            gloss.lineTo(w - rr, 0f)
            gloss.arc(w - rr, rr, rr, rr, -90f, 90f, true)
            gloss.lineTo(w, h * 0.38f)
            gloss.quadTo(w * 0.5f, h * 0.52f, 0f, h * 0.38f)
            gloss.close()
            glossFill = Fill.linear(0f, 0f, 0f, h * 0.5f, art.white(if (art.dark) 0.18f else 0.55f), art.white(0.04f))
        }
    }

    private val cardPs = LongCache<CardP>(80)

    override fun card(
        g: Gfx, l: Float, t: Float, r: Float, b: Float, rad: Float,
        selected: Float, press: Float, strong: Float, shadow: Float,
    ) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        val rr = min(rad, min(w, h) / 2f)
        val k = key(w, h, 13f)
        var p = cardPs[k]
        if (p == null) { p = CardP(w, h, this); cardPs[k] = p }
        g.save(); g.translate(l, t)
        if (shadow > 0f) {
            g.strokeWidth(2.2f)
            val base = (if (dark) 0.20f else 0.12f) * shadow
            for (i in 0 until 5) {
                val f = 1f - i / 5f
                g.paint(Rgb.alpha(if (dark) 0xFF000000.toInt() else 0xFF3B5E8C.toInt(), base * f * f))
                val e = 0.9f + i * 1.9f
                g.strokeRoundRect(-e, -e + 2f, w + e, h + e + 2f, rr + e)
            }
        }
        g.paint(p.body); g.roundRect(0f, 0f, w, h, rr)
        if (strong > 0f) { g.save(); g.alpha(strong); g.paint(p.bodyStrong); g.roundRect(0f, 0f, w, h, rr); g.restore() }
        if (selected > 0f) { g.save(); g.alpha(selected); g.paint(Rgb.alpha(theme.accent, 0.16f)); g.roundRect(0f, 0f, w, h, rr); g.restore() }
        g.paint(p.glossFill); g.path(p.gloss)
        // kalın krom kenar
        g.strokeWidth(2.4f); g.paint(p.holo); g.strokeRoundRect(1.2f, 1.2f, w - 1.2f, h - 1.2f, max(0f, rr - 1.2f))
        g.strokeWidth(1f); g.paint(white(if (dark) 0.30f else 0.85f)); g.strokeRoundRect(3f, 3f, w - 3f, h - 3f, max(0f, rr - 3f))
        if (selected > 0f) {
            g.save(); g.alpha(selected)
            g.strokeWidth(2.2f); g.paint(theme.accent); g.strokeRoundRect(1.2f, 1.2f, w - 1.2f, h - 1.2f, max(0f, rr - 1.2f))
            g.restore()
        }
        // köşe parıltıları: sönüp yanar
        if (strong <= 0.5f && w >= 80f && h >= 40f) {
            val n = min(3, 1 + (h / 120f).toInt())
            var s = (w * 5f).toInt() * 31 + (h * 5f).toInt()
            for (i in 0 until n) {
                s = s * 1103515245 + 12345
                val fx = ((s ushr 8) and 0xFFFF) / 65535f
                s = s * 1103515245 + 12345
                val fy = ((s ushr 8) and 0xFFFF) / 65535f
                val tw = 0.5f + 0.5f * sin(clock * 1.8f + i * 2.1f + fx * 6f)
                sparkle(g, w * (0.50f + 0.44f * fx), 6f + min(26f, h * 0.30f) * fy, 2.6f + 2.2f * tw, 0.35f + 0.65f * tw, if (i == 0 && fx > 0.6f) 1 else 0)
            }
        }
        if (press > 0f) { g.save(); g.alpha(press); g.paint(Rgb.alpha(theme.accent, 0.20f)); g.roundRect(0f, 0f, w, h, rr); g.restore() }
        g.restore()
    }

    // ------------------------------------------------------------------ şeker düğme

    private class CandyP(val w: Float, val h: Float, art: Y2kArt) {
        val body = Fill.linear(0f, 0f, 0f, h, art.theme.control, art.theme.controlDeep)
        val glow = Fill.radial(w * 0.5f, h * 1.1f, w * 0.55f, Rgb.alpha(art.theme.accentLight, 0.80f), Rgb.alpha(art.theme.accentLight, 0f))
        val upper = GPath()
        val upperFill = Fill.linear(0f, 0f, 0f, h * 0.5f, art.white(0.78f), art.white(0.12f))

        init {
            val k = min(w, h) / 2f
            upper.arc(k, k, k, k, 180f, 90f, false)
            upper.lineTo(w - k, 0f)
            upper.arc(w - k, k, k, k, -90f, 90f, true)
            upper.lineTo(w, h * 0.5f)
            upper.quadTo(w * 0.5f, h * 0.60f, 0f, h * 0.5f)
            upper.close()
        }
    }

    private val candyPs = LongCache<CandyP>(40)

    private fun candy(g: Gfx, w: Float, h: Float, press: Float, shadow: Float) {
        val k = key(w, h, 14f)
        var p = candyPs[k]
        if (p == null) { p = CandyP(w, h, this); candyPs[k] = p }
        if (shadow > 0f) {
            g.strokeWidth(2.2f)
            for (i in 0 until 4) {
                val f = 1f - i / 4f
                g.paint(Rgb.alpha(theme.controlDeep, (if (dark) 0.26f else 0.16f) * shadow * f * f))
                val e = 1.1f + i * 1.9f
                g.strokeRoundRect(-e, -e + 2f, w + e, h + e + 2f, h / 2f + e)
            }
        }
        g.paint(p.body); g.roundRect(0f, 0f, w, h, h / 2f)
        g.save(); g.clipRoundRect(0f, 0f, w, h, h / 2f); g.paint(p.glow); g.rect(0f, h * 0.45f, w, h); g.restore()
        g.paint(p.upperFill); g.path(p.upper)
        g.strokeWidth(1.8f); g.paint(chrome(h)); g.strokeRoundRect(0.9f, 0.9f, w - 0.9f, h - 0.9f, h / 2f - 0.9f)
        if (w > 40f) sparkle(g, w * 0.82f, h * 0.30f, 2.4f + 1.6f * (0.5f + 0.5f * sin(clock * 2.2f + w * 0.07f)), 0.9f)
        if (press > 0f) { g.save(); g.alpha(press); g.paint(Rgb.alpha(theme.shadow, 0.24f)); g.roundRect(0f, 0f, w, h, h / 2f); g.restore() }
    }

    override fun pill(g: Gfx, l: Float, t: Float, r: Float, b: Float, press: Float, shadow: Float) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        g.save(); g.translate(l, t); candy(g, w, h, press, shadow); g.restore()
    }

    private val knobChrome = Fill.radial(-0.25f, -0.35f, 1.35f, white(1f), Rgb.alpha(silver, 0.95f), white(0.98f), 0.62f)

    private fun chromeKnob(g: Gfx, cx: Float, cy: Float, r: Float, press: Float) {
        g.paint(Rgb.alpha(theme.shadow, if (dark) 0.40f else 0.26f)); g.circle(cx, cy + 1.6f, r + 0.6f)
        g.save(); g.translate(cx, cy); g.scale(r, r); g.paint(knobChrome); g.circle(0f, 0f, 1f); g.restore()
        g.strokeWidth(1f); g.paint(white(0.95f)); g.strokeCircle(cx, cy, r - 0.5f)
        g.paint(Rgb.alpha(cyan, 0.60f)); g.oval(cx - r * 0.5f, cy - r * 0.78f, cx + r * 0.5f, cy - r * 0.2f)
        if (press > 0f) { g.save(); g.alpha(press); g.paint(Rgb.alpha(theme.accent, 0.25f)); g.circle(cx, cy, r); g.restore() }
    }

    override fun switch(g: Gfx, l: Float, t: Float, w: Float, h: Float, on: Float, press: Float) {
        val o = on.coerceIn(0f, 1f)
        g.save(); g.translate(l, t)
        g.paint(insetFill(h)); g.roundRect(0f, 0f, w, h, h / 2f)
        if (o > 0.001f) { g.save(); g.alpha(o); candy(g, w, h, 0f, 0f); g.restore() }
        else { g.strokeWidth(1.4f); g.paint(chrome(h)); g.strokeRoundRect(0.7f, 0.7f, w - 0.7f, h - 0.7f, h / 2f - 0.7f) }
        chromeKnob(g, h / 2f + (w - h) * on.coerceIn(-0.12f, 1.12f), h / 2f, h / 2f - 3.2f + press * 0.9f, press)
        g.restore()
    }

    override fun slider(g: Gfx, l: Float, cy: Float, w: Float, v: Float, press: Float) {
        val th = 8f
        val kx = l + 12f + (w - 24f) * v.coerceIn(0f, 1f)
        g.save(); g.translate(l, cy - th / 2f)
        g.paint(insetFill(th)); g.roundRect(0f, 0f, w, th, th / 2f)
        val fw = (kx - l).coerceAtLeast(th)
        g.paint(onFill(th)); g.roundRect(0f, 0f, fw, th, th / 2f)
        g.paint(white(0.45f)); g.roundRect(1f, 0.8f, max(1.5f, fw - 1f), th * 0.5f, th / 2f - 0.8f)
        g.strokeWidth(1f); g.paint(white(if (dark) 0.35f else 0.85f)); g.strokeRoundRect(0.5f, 0.5f, w - 0.5f, th - 0.5f, th / 2f - 0.5f)
        g.restore()
        chromeKnob(g, kx, cy, 12f + press * 1.5f, press)
    }

    private val ringCache = LongCache<Fill>(6)

    private fun ringFill(r: Float): Fill {
        val k = key(r, r, 15f)
        var f = ringCache[k]
        if (f == null) { f = Fill.linear(-r, -r, r, r, white(1f), Rgb.alpha(silver, 0.95f), white(1f), 0.5f); ringCache[k] = f }
        return f
    }

    // ------------------------------------------------------------------ küre: krom halka, ışık taraması, parıltı

    override fun orb(g: Gfx, cx: Float, cy: Float, r: Float, level: Float, phase: Float, glow: Float, error: Float, press: Float) {
        super.orb(g, cx, cy, r, level, phase, glow, error, press)
        if (r < 24f) return
        g.save(); g.translate(cx, cy)
        // ışık taraması: her birkaç saniyede bir çapraz bir parlama küreyi geçer
        val sweep = ((clock * 0.22f) % 1.7f) / 1.7f
        if (sweep < 0.62f) {
            val u = sweep / 0.62f
            g.save(); g.clipCircle(0f, 0f, r - 2f); g.rotate(24f)
            g.translate(-r * 1.3f + u * r * 2.6f, 0f)
            g.alpha(0.34f * sin(u * PI.toFloat()))
            g.paint(white(1f)); g.rect(-r * 0.10f, -r * 1.5f, r * 0.10f, r * 1.5f)
            g.paint(white(0.45f)); g.rect(-r * 0.26f, -r * 1.5f, -r * 0.10f, r * 1.5f)
            g.restore()
        }
        // krom halka
        g.strokeWidth(3.2f); g.paint(ringFill(r))
        g.strokeCircle(0f, 0f, r + 1.2f)
        g.restore()
        sparkle(g, cx - r * 0.62f, cy - r * 0.70f, r * 0.15f * (0.7f + 0.3f * sin(clock * 2.4f)), 0.95f)
        sparkle(g, cx + r * 0.70f, cy - r * 0.42f, r * 0.08f * (0.7f + 0.3f * sin(clock * 3.1f + 1f)), 0.8f)
    }
}
