package app.dnshizli.core

/** DNS hangi uygulamalara uygulanır: hepsine, yalnızca seçilenlere ya da seçilenler dışındakilere. */
enum class AppScope(val id: String) { ALL("all"), ONLY("only"), EXCEPT("except") }

/** Telefondaki bir uygulama (başlatıcıda görünen): paket adı ve görünen ad. */
class AppEntry(val pkg: String, val label: String)

/** [AppScope] ayarının tünele çevrilmiş hali. */
class ScopePlan(val kind: Kind, val packages: List<String>) {
    enum class Kind { ALL, ALLOW, DENY }
}

object AppScopes {
    const val MAX_APPS = 400
    private val PKG = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

    fun validPkg(s: String): Boolean = s.length <= 255 && PKG.matches(s)

    /** "a.b,c.d" -> geçerli paket adları (en çok [MAX_APPS], tekrarsız). */
    fun decode(s: String?): Set<String> {
        if (s.isNullOrBlank() || s.length > 100_000) return emptySet()
        val out = LinkedHashSet<String>()
        for (p in s.split(',')) {
            if (out.size >= MAX_APPS) break
            if (validPkg(p)) out.add(p)
        }
        return out
    }

    fun encode(apps: Set<String>): String = apps.filter { validPkg(it) }.sorted().take(MAX_APPS).joinToString(",")

    /**
     * Tünelin hangi uygulamaları kapsayacağı. [own] uygulamanın kendisidir: bağlantı doğrulaması ve ölçümler kendi
     * trafiğimizden gider, bu yüzden "yalnızca seçilenler"de her zaman kapsama alınır, "hariç"te asla dışarıda bırakılmaz.
     * Seçili hiçbir uygulama yüklü değilse (liste boşsa) tüm uygulamalar kapsanır: boş bir "yalnızca" listesi
     * Android'de zaten "hepsi" demektir, böylece davranış her zaman açık ve aynıdır.
     */
    fun plan(s: AppSettings, own: String, installed: (String) -> Boolean): ScopePlan {
        if (s.appScope == AppScope.ALL) return ScopePlan(ScopePlan.Kind.ALL, emptyList())
        val pk = s.apps.filter { it != own && installed(it) }
        if (pk.isEmpty()) return ScopePlan(ScopePlan.Kind.ALL, emptyList())
        return if (s.appScope == AppScope.ONLY) ScopePlan(ScopePlan.Kind.ALLOW, pk + own) else ScopePlan(ScopePlan.Kind.DENY, pk)
    }
}
