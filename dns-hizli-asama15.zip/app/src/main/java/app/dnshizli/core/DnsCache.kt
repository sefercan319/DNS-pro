package app.dnshizli.core

/**
 * Küçük bir LRU DNS önbelleği. İki sınırı vardır: en fazla [maxEntries] kayıt VE en fazla [maxBytes] bayt
 * (varsayılan: kayıt başına ortalama 1 KB). Böylece büyük cevaplarla (ör. uzun TXT kayıtları) doldurulmaya
 * çalışılsa bile bellek tavanı sabittir. Tek bir cevap [MAX_ENTRY_BYTES]'tan büyükse hiç saklanmaz.
 * Tekrarlayan sorgular ağa hiç çıkmaz: hem hız hem pil kazancı. [maxEntries] sıfır veya negatifse önbellek kapalıdır.
 *
 * Anahtar: sorgu mesajının ilk 2 bayt (id) hariç tamamı. Böylece bayrak ve EDNS farkları
 * yanlışlıkla aynı kayda düşmez.
 *
 * Önbellekten verilen cevaplarda TTL'ler geçen süre kadar azaltılır ([Dns.ageTtls]): istemci, cevabı sunucunun
 * izin verdiğinden daha uzun saklamaz.
 */
internal class DnsCache(
    private val maxEntries: Int,
    private val nowMs: () -> Long,
    private val maxBytes: Int = maxOf(0, maxEntries) * 1024,
) {
    private class Cached(val data: ByteArray, val storedAt: Long, val expiresAt: Long)

    private val map = LinkedHashMap<String, Cached>(64, 0.75f, true)
    private var bytes = 0

    fun put(key: String, resp: ByteArray, len: Int, ttlSec: Int) = put(key, resp, 0, len, ttlSec)

    /** [resp] içinde [off] konumundan başlayan [len] baytlık cevabı saklar. */
    @Synchronized
    fun put(key: String, resp: ByteArray, off: Int, len: Int, ttlSec: Int) {
        if (maxEntries <= 0 || ttlSec < 1 || len <= 0 || len > MAX_ENTRY_BYTES || len > maxBytes) return
        val life = minOf(ttlSec, MAX_TTL_S) * 1000L
        val now = nowMs()
        map.remove(key)?.let { bytes -= it.data.size }
        map[key] = Cached(resp.copyOfRange(off, off + len), now, now + life)
        bytes += len
        trim()
    }

    /** En eski (en az yakın zamanda kullanılan) kayıtlardan başlayarak iki sınıra da inene kadar atar. */
    private fun trim() {
        if (map.size <= maxEntries && bytes <= maxBytes) return
        val it = map.entries.iterator()
        while (it.hasNext() && (map.size > maxEntries || bytes > maxBytes)) {
            bytes -= it.next().value.data.size
            it.remove()
        }
    }

    /**
     * Kayıt varsa cevabı [out] içine [off] konumundan başlayarak kopyalar, DNS id'sini istemcinin
     * id'siyle değiştirir, TTL'leri eskitir ve uzunluğu döner. Yoksa, süresi dolduysa ya da [out]'a sığmıyorsa -1.
     */
    @Synchronized
    fun get(key: String, clientId: Int, out: ByteArray, off: Int): Int {
        if (maxEntries <= 0) return -1
        val e = map[key] ?: return -1
        val now = nowMs()
        if (now >= e.expiresAt) {
            map.remove(key)
            bytes -= e.data.size
            return -1
        }
        val n = e.data.size
        if (off < 0 || off + n > out.size) return -1
        System.arraycopy(e.data, 0, out, off, n)
        Packets.put16(out, off, clientId)
        val age = ((now - e.storedAt) / 1000).toInt()
        if (age > 0) Dns.ageTtls(out, off, n, age)
        return n
    }

    @Synchronized
    fun size(): Int = map.size

    /** Saklanan cevapların toplam boyutu (bayt). */
    @Synchronized
    fun byteSize(): Int = bytes

    @Synchronized
    fun clear() { map.clear(); bytes = 0 }

    companion object {
        /** Sunucu çok uzun TTL verse bile en fazla 5 dakika tutulur. */
        const val MAX_TTL_S = 300

        /** Tek bir cevabın önbelleğe alınabilecek en büyük boyu. */
        const val MAX_ENTRY_BYTES = 8192
    }
}
