package app.dnshizli.platform

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import app.dnshizli.core.Journal
import app.dnshizli.core.Pic
import app.dnshizli.core.WallpaperMath
import app.dnshizli.core.WallpaperPresets
import app.dnshizli.core.WpBlur
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * Arka plan fotoğrafının saklanması. Seçilen görüntü ekran oranına kırpılıp küçültülür ve uygulamaya özel klasöre
 * (`filesDir`) tek bir JPEG olarak yazılır: ne yedeğe ne buluta gider (bkz. data_extraction_rules.xml), başka uygulamalar
 * okuyamaz, internete hiç çıkmaz. Seçici izin istemez (sistem seçicisi yalnızca seçilen dosyayı verir).
 *
 * Bellek: hazırlanan görüntü en çok [WallpaperMath.MAX_WIDTH] x [WallpaperMath.MAX_HEIGHT] pikseldir (≈ 6 MB bitmap);
 * giriş görüntüsü çözülürken örnekleme ile küçültülür ve çözülen piksel sayısı sınırlanır; bellek yetmezse işlem sessizce
 * başarısız olur (uygulama çökmez).
 */
internal object WallpaperStore {
    private const val FILE = "wallpaper.jpg"
    private const val TMP = "wallpaper.tmp"
    private const val QUALITY = 88
    private const val MAX_DECODED_PIXELS = 16_000_000L

    private fun file(ctx: Context) = File(ctx.filesDir, FILE)

    fun exists(ctx: Context): Boolean = file(ctx).isFile

    fun delete(ctx: Context) {
        try { file(ctx).delete(); File(ctx.filesDir, TMP).delete() } catch (_: Exception) {}
    }

    /** Fotoğrafı okur, [aspect] (ekran genişlik/yükseklik) oranına kırpar, küçültür ve kaydeder. @return başarılı mı */
    fun save(ctx: Context, uri: Uri, aspect: Float): Boolean =
        saveFrom(ctx, aspect) { ctx.contentResolver.openInputStream(uri) }

    /** Uygulamayla gelen hazır görseli (assets) aynı hattan geçirip kaydeder. */
    fun savePreset(ctx: Context, index: Int, aspect: Float): Boolean {
        if (index !in WallpaperPresets.NAMES.indices) return false
        return saveFrom(ctx, aspect) { ctx.assets.open(WallpaperPresets.asset(index)) }
    }

    private fun saveFrom(ctx: Context, aspect: Float, open: () -> java.io.InputStream?): Boolean {
        var decoded: Bitmap? = null
        var oriented: Bitmap? = null
        var out: Bitmap? = null
        try {
            // 1) boyut ve yön
            // Dikkat: inJustDecodeBounds açıkken decodeStream HER ZAMAN null döner; boyut `bounds` alanlarından okunur.
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            val first = open()
            if (first == null) { Journal.add("arka plan: dosya açılamadı"); return false }
            first.use { BitmapFactory.decodeStream(it, null, bounds) }
            val bw = bounds.outWidth
            val bh = bounds.outHeight
            if (bw <= 0 || bh <= 0) { Journal.add("arka plan: görüntü okunamadı"); return false }
            if (bw.toLong() * bh > WallpaperMath.MAX_INPUT_PIXELS) { Journal.add("arka plan: görüntü çok büyük"); return false }
            val exif = try {
                open()?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
            } catch (_: Exception) { null } ?: ExifInterface.ORIENTATION_NORMAL
            val quarter = exif == ExifInterface.ORIENTATION_ROTATE_90 || exif == ExifInterface.ORIENTATION_ROTATE_270 ||
                exif == ExifInterface.ORIENTATION_TRANSPOSE || exif == ExifInterface.ORIENTATION_TRANSVERSE
            val ow0 = if (quarter) bh else bw
            val oh0 = if (quarter) bw else bh

            // 2) örnekleme: çıktının ≈ 3/4'ünden küçük olmayacak, çözülen piksel sayısı sınırlı kalacak
            val plan = WallpaperMath.prepare(ow0, oh0, aspect)
            val cw = plan[2] - plan[0]
            val ch = plan[3] - plan[1]
            var sample = 1
            while (cw / (sample * 2) >= plan[4] * 3 / 4 && ch / (sample * 2) >= plan[5] * 3 / 4) sample *= 2
            while (bw.toLong() / sample * (bh.toLong() / sample) > MAX_DECODED_PIXELS) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            decoded = open()?.use { BitmapFactory.decodeStream(it, null, opts) }
            if (decoded == null) { Journal.add("arka plan: görüntü çözülemedi"); return false }

            // 3) yön düzelt, ekran oranına kırp, küçült
            val src = decoded
            oriented = orient(src, exif)
            if (oriented !== src) { src.recycle(); decoded = null }
            val p = WallpaperMath.prepare(oriented.width, oriented.height, aspect)
            val crop = Bitmap.createBitmap(oriented, p[0], p[1], p[2] - p[0], p[3] - p[1])
            if (crop !== oriented) { oriented.recycle(); oriented = null }
            out = if (crop.width != p[4] || crop.height != p[5]) Bitmap.createScaledBitmap(crop, p[4], p[5], true) else crop
            if (out !== crop) crop.recycle()

            // 4) yaz (önce geçici dosyaya, sonra yerine taşı: yarım dosya kalmaz)
            val tmp = File(ctx.filesDir, TMP)
            tmp.outputStream().use { if (!out.compress(Bitmap.CompressFormat.JPEG, QUALITY, it)) return false }
            val dst = file(ctx)
            if (!tmp.renameTo(dst)) { dst.delete(); if (!tmp.renameTo(dst)) return false }
            return true
        } catch (e: OutOfMemoryError) {
            Journal.add("arka plan: bellek yetmedi")
            return false
        } catch (e: Exception) {
            Journal.add("arka plan kaydedilemedi: ${e.javaClass.simpleName}")
            return false
        } finally {
            decoded?.recycle(); oriented?.recycle(); out?.recycle()
        }
    }

    private fun orient(src: Bitmap, exif: Int): Bitmap {
        val m = Matrix()
        when (exif) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return src
        }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    /** Kayıtlı fotoğrafı yükler ve istenen bulanıklığı uygular. Dosya yoksa ya da bozuksa null. */
    fun load(ctx: Context, blur: WpBlur): Pic? {
        val f = file(ctx)
        if (!f.isFile) return null
        var bmp: Bitmap? = null
        try {
            bmp = BitmapFactory.decodeFile(f.path) ?: return null
            if (bmp.width <= 0 || bmp.height <= 0) return null
            val (lo, hi) = lumaRange(bmp)
            var shown = bmp
            if (blur.divisor > 1) {
                val b = blurred(bmp, blur.divisor)
                bmp.recycle(); bmp = null
                shown = b
            }
            val keep = shown
            bmp = null
            return Pic(keep.width, keep.height, keep, lo, hi) { if (!keep.isRecycled) keep.recycle() }
        } catch (e: OutOfMemoryError) {
            Journal.add("arka plan yüklenemedi: bellek")
            return null
        } catch (e: Exception) {
            Journal.add("arka plan yüklenemedi: ${e.javaClass.simpleName}")
            return null
        } finally {
            bmp?.recycle()
        }
    }

    /** Fotoğrafın en koyu ve en açık bölgelerinin parlaklığı: 24x24 örnek, yüzde 10 ve 90. */
    private fun lumaRange(b: Bitmap): Pair<Float, Float> {
        val n = 24
        val s = FloatArray(n * n)
        var k = 0
        for (j in 0 until n) for (i in 0 until n) {
            val x = ((i + 0.5f) / n * b.width).toInt().coerceIn(0, b.width - 1)
            val y = ((j + 0.5f) / n * b.height).toInt().coerceIn(0, b.height - 1)
            s[k++] = WallpaperMath.luma(b.getPixel(x, y))
        }
        return WallpaperMath.percentile(s, 0.10f) to WallpaperMath.percentile(s, 0.90f)
    }

    /** Küçültüp kademeli büyüterek yumuşatma: gerçek bulanıklık değil ama ucuz ve kare maliyeti sıfır. */
    private fun blurred(src: Bitmap, div: Int): Bitmap {
        val tw = max(1, src.width / 2)
        val th = max(1, src.height / 2)
        var cur = Bitmap.createScaledBitmap(src, max(1, src.width / div), max(1, src.height / div), true)
        while (cur.width < tw) {
            val nw = min(tw, cur.width * 2)
            val nh = min(th, cur.height * 2)
            val next = Bitmap.createScaledBitmap(cur, nw, nh, true)
            if (next !== cur) cur.recycle()
            cur = next
        }
        return cur
    }
}
