package app.dnshizli.platform

import android.app.AlarmManager
import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.system.ErrnoException
import android.system.Os
import android.system.OsConstants
import android.system.StructPollfd
import app.dnshizli.core.AdBlockResult
import app.dnshizli.core.AppScope
import app.dnshizli.core.AppScopes
import app.dnshizli.core.AppSettings
import app.dnshizli.core.Bootstrap
import app.dnshizli.core.Catalog
import app.dnshizli.core.CheckResult
import app.dnshizli.core.ConnectionCheck
import app.dnshizli.core.DnsForwarder
import app.dnshizli.core.DnsServer
import app.dnshizli.core.DnssecResult
import app.dnshizli.core.DohUrl
import app.dnshizli.core.EndReason
import app.dnshizli.core.Encryption
import app.dnshizli.core.Format
import app.dnshizli.core.Forwarder
import app.dnshizli.core.Ip
import app.dnshizli.core.IpMode
import app.dnshizli.core.Journal
import app.dnshizli.core.NetFamilies
import app.dnshizli.core.NetKind
import app.dnshizli.core.OrbState
import app.dnshizli.core.Proto
import app.dnshizli.core.Rules
import app.dnshizli.core.ScopePlan
import app.dnshizli.core.SecureForwarder
import app.dnshizli.core.SecureTarget
import app.dnshizli.core.SelfTest
import app.dnshizli.core.SelfTestResult
import app.dnshizli.core.ServerList
import app.dnshizli.core.Session
import app.dnshizli.core.Targets
import app.dnshizli.ui.Strings
import app.dnshizli.ui.VpnUi
import java.io.FileDescriptor
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory

/**
 * DNS-only VPN: telefonda yerel bir tünel arayüzü açar, yalnızca sahte DNS adreslerine (IPv4 10.111.222.2 ve, kurulabilirse,
 * IPv6 fd6e:7368:a1c2::2) giden paketleri bu arayüze yönlendirir. Gelen DNS sorgularını bir [Forwarder] seçilen sunucuya iletir: düz DNS
 * ([DnsForwarder]) ya da şifreli DNS ([SecureForwarder], DoT/DoH). Diğer tüm trafik normal yolundan, hiç dokunulmadan devam eder.
 *
 * Kaynak kullanımı:
 *  - Tünel okuyucu `poll()` ile bloklanır: paket yokken hiç uyanmaz.
 *  - Durum değişiklikleri tek bir çalışan iş parçacığında sıralanır; yarış durumu ve kilit karmaşası yok.
 *  - Ağ izleme sistem olaylarıyla çalışır. İstatistikler trafik varken en çok dakikada bir depoya aktarılır.
 *
 * Dayanıklılık:
 *  - Otomatik şifrelemede şifreli yöntem kurulamazsa şifresiz DNS'e düşülür ve kullanıcı uyarılır; her ağ değişiminde ve
 *    10 dakikada bir şifreli yönteme dönülmeye çalışılır. "Sıkı şifreleme" açıksa hiç düşülmez.
 *  - Bağlantı ağ yokken kurulduysa (açılışta) ilk ağ olayında doğrulanır; yeni ağda yanıt yoksa yöntemler baştan denenir.
 *  - Seçili sunucu yanıt vermezse (ayarlıysa) yedek sunucuya bağlanılır.
 *  - Kendiliğinden (açılış, sistem, duraklatma sonu) başlayan bağlanmalar ve kopmalar artan aralıklarla yeniden denenir.
 *  - Duraklatma sırasında servis önplanda kalır (geri sayımlı bildirim); süre bitince izin gerektirmeyen bir zamanlayıcı ve
 *    yedek bir sistem alarmı ([PauseAlarm]) bağlantıyı sürdürür. Telefon yeniden başlasa da alarm yeniden kurulur.
 *
 * Her şey `cancelGen` ile iptal edilebilir: kullanıcı bağlanırken "kes" derse süren deneme en yakın noktada bırakılır.
 */
class DnsVpnService : VpnService() {

    private lateinit var prefs: PrefsStore
    private val main = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor { r -> Thread(r, "dns-vpn").also { it.isDaemon = true } }
    private val lock = Any()
    private val random = SecureRandom()
    private val live: () -> VpnUi = { snapshot() }
    private val tap = SelfTest.Tap()

    @Volatile private var watcher: NetworkWatcher? = null

    // Tünel durumu: yazma yalnızca çalışan iş parçacığında (ve [lock] altında); okuma her yerden.
    @Volatile private var tun: Tunnel? = null
    @Volatile private var fw: Forwarder? = null
    @Volatile private var state = OrbState.OFF
    @Volatile private var serverId: String? = null
    @Volatile private var sinceMs = 0L
    @Volatile private var lastError: String? = null
    @Volatile private var lastInfo: String? = null
    @Volatile private var baseQueries = 0L
    @Volatile private var baseHits = 0L
    @Volatile private var baseBlocked = 0L
    @Volatile private var pausedUntil = 0L

    /** Şifreli yöntem planlanmışken şifresiz DNS'e düşüldü. */
    @Volatile private var downgraded = false

    /** Tünelde IPv6 DNS adresi de var mı (kurulamazsa yalnızca IPv4). */
    @Volatile private var tunnelV6 = false

    /** Bu ağın kullanabildiği IP aileleri; yukarı akış adreslerinin sırasını belirler. */
    @Volatile private var netFamilies = NetFamilies.UNKNOWN

    /** Son denemelerde sunucunun TLS sertifikası reddedildi (araya girme ya da yanlış sunucu belirtisi). */
    @Volatile private var untrusted = false

    /** Bağlantı gerçekten sınandı mı (ağ yokken kurulan bağlantı sınanmamış sayılır). */
    @Volatile private var verified = true

    /**
     * Sunucuya tünelden gönderilen kendi sorgumuz ulaşıyor ama telefonun çözümleyicisi sorgularını tünele göndermiyor
     * (ör. Özel DNS sabit ya da ağ ayarı henüz uygulanmadı). Bağlantı "kurulu" sayılır, kullanıcı uyarılır, arka planda
     * yeniden sınanır ([recheckTask]).
     */
    @Volatile private var phoneBypass = false
    private var bypassChecks = 0

    /** Kendiliğinden yeniden deneme sürüyor (açılış/sistem bağlantısı ya da kopma). */
    @Volatile private var retrying = false
    private var retryStep = 0

    @Volatile private var cancelGen = 0
    @Volatile private var lastStartId = 0
    @Volatile private var destroyed = false
    @Volatile private var lastFlush = 0L

    // Toplamlara aktarım sayaçları (yalnızca [lock] altında)
    private var flushedQueries = 0L
    private var flushedHits = 0L
    private var flushedBlocked = 0L
    private var flushedAnswered = 0L
    private var flushedLatency = 0L
    private var flushedUp = 0L
    private var flushedDown = 0L
    private var flushedAt = 0L
    private val retired = ArrayList<Forwarder>()

    // Oturum (bağlantı geçmişi için). Çoğunlukla çalışan iş parçacığında; iptalde ([onRevoke]) ana iş parçacığından da kapanır.
    @Volatile private var sessionServer: String? = null
    @Volatile private var sessionProto = Proto.PLAIN
    @Volatile private var sessionStart = 0L
    @Volatile private var sessionBase = 0L

    private val retryTask = Runnable { submit(lastStartId) { retryNow() } }
    private val upgradeTask = Runnable { submit(lastStartId) { tryUpgrade() } }
    private val recheckTask = Runnable { submit(lastStartId) { recheckPhone() } }
    private val pauseListener = AlarmManager.OnAlarmListener { submit(lastStartId) { resumeFromAlarm() } }

    // ------------------------------------------------------------------ yaşam döngüsü

    override fun onCreate() {
        super.onCreate()
        prefs = PrefsStore(this)
        App.applyLanguage(this, prefs.loadSettings().lang)
        Notifier.ensureChannel(this)
        pausedUntil = prefs.pausedUntil()
        VpnStatus.live = live
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastStartId = startId
        // startForegroundService() sözü: kısa sürede startForeground() çağrılmalı. Her komutta, durumu yansıtan bildirimle çağırırız.
        foreground(currentNotification())

        val action = intent?.action
        val wanted = intent?.getStringExtra(EXTRA_SERVER)
        val minutes = intent?.getIntExtra(EXTRA_MINUTES, 15) ?: 15
        val auto = intent?.getBooleanExtra(EXTRA_AUTO, false) == true     // açılış, güncelleme, duraklatma sonu: başarısızsa yeniden dene
        if (action == ACTION_DISCONNECT || action == ACTION_PAUSE) cancelGen++
        // Komutun geldiği andaki iptal numarası: sıradayken "kes" gelirse bu komut hiç başlamadan düşer.
        val gen = cancelGen

        submit(startId) {
            when {
                action == ACTION_DISCONNECT -> disconnect(startId)
                action == ACTION_PAUSE -> pause(minutes, startId)
                action == ACTION_RESUME -> { clearPause(); cancelRetry(); markAuto(auto); connect(null, startId, gen) }
                action == ACTION_CONNECT -> { clearPause(); cancelRetry(); markAuto(auto); connect(wanted, startId, gen) }
                action == ACTION_NEXT -> next(startId)
                action == ACTION_REAPPLY -> { reapply(gen); idleShutdown(startId) }
                action == ACTION_REBUILD -> { rebuild(startId, gen); idleShutdown(startId) }
                action == ACTION_TEST -> { runTest(); idleShutdown(startId) }
                action == ACTION_CLEAR_CACHE -> {
                    fw?.clearCache(); Journal.add("önbellek temizlendi")
                    if (state != OrbState.ON && !pausedNow() && !retrying) shutdown(startId)
                }
                // Süreç duraklatma sırasında öldürülüp yeniden başlatıldıysa: duraklatmaya devam.
                action == null && pausedNow() -> enterPaused()
                // Sistemden (her zaman açık VPN, açılış) ya da süreç öldürüldükten sonra yeniden başlatma: kendiliğinden
                // bağlanma; başarısız olursa artan aralıklarla yeniden denenir.
                action == SERVICE_INTERFACE || prefs.loadSettings().wasActive -> { retrying = true; retryStep = 0; connect(null, startId, gen) }
                else -> shutdown(startId)
            }
        }
        return START_STICKY
    }

    /** Kendiliğinden başlayan bağlanma (açılış, güncelleme, duraklatma sonu): başarısızsa artan aralıklarla yeniden denenir. */
    private fun markAuto(auto: Boolean) {
        if (!auto) return
        retrying = true
        retryStep = 0
        prefs.setWasActive(true)           // süreç bu sırada ölürse yeniden başlatma bağlanmayı sürdürsün
    }

    /** Bağlı değilken gelen yan komutlar (test, yeniden uygulama) servisi önplanda asılı bırakmasın. */
    private fun idleShutdown(startId: Int) {
        if (state != OrbState.ON && tun == null && !pausedNow() && !retrying) shutdown(startId)
    }

    /** Sistem VPN'i iptal etti (başka bir VPN uygulaması veya kullanıcı). Temizle ve durumu bildir. */
    override fun onRevoke() {
        Journal.add("sistem VPN bağlantısını iptal etti")
        val wasOn = state == OrbState.ON
        cancelGen++
        main.removeCallbacks(retryTask)
        main.removeCallbacks(upgradeTask)
        retrying = false
        synchronized(lock) {
            // Önce bağlı geçen süre ve sayılar aktarılır (durum ERROR olunca saniyeler sayılmaz).
            flushTotalsLocked()
            state = OrbState.ERROR
            lastError = Strings.ERR_REVOKED
        }
        endSession(EndReason.REVOKED)
        prefs.setWasActive(false)
        // Soket kapatma (TLS close_notify) ana iş parçacığında ağ işi sayılır: ayrı iş parçacığında yapılır.
        Thread({ teardown(); publish() }, "dns-teardown").start()
        publish()
        if (wasOn) notifyDrop(Strings.ERR_REVOKED)
        super.onRevoke()   // servisi durdurur
    }

    override fun onDestroy() {
        destroyed = true
        cancelGen++
        main.removeCallbacks(retryTask)
        main.removeCallbacks(upgradeTask)
        cancelListener()
        worker.shutdownNow()
        Thread({ teardown() }, "dns-teardown").start()
        if (!pausedNow()) Notifier.cancel(this)
        if (VpnStatus.live === live) VpnStatus.live = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ komutlar (çalışan iş parçacığı)

    private fun submit(startId: Int, task: () -> Unit) {
        try {
            worker.execute {
                try {
                    task()
                } catch (e: Throwable) {
                    Journal.add("beklenmeyen hata: ${e.javaClass.simpleName}")
                    try { fail(Strings.ERR_UNKNOWN, startId) } catch (_: Throwable) {}
                }
            }
        } catch (_: RejectedExecutionException) {
            // servis kapanıyor
        }
    }

    private fun pausedNow(): Boolean = pausedUntil > 0L

    private fun connect(requested: String?, startId: Int, gen: Int) {
        if (destroyed || cancelGen != gen) return     // servis kapanıyor ya da komut sıradayken iptal edildi
        val settings = prefs.loadSettings()
        val kind = NetworkWatcher.currentKind(this)
        val id = requested?.takeIf { Catalog.byId(it) != null } ?: Rules.initialServer(settings, kind)
        val server = Catalog.byId(id) ?: Catalog.default
        if (tun != null && state == OrbState.ON) {
            if (server.id == serverId) publish() else switchServer(server, settings, gen)
        } else {
            startTunnel(server, settings, kind, startId, gen)
        }
    }

    private fun startTunnel(server: DnsServer, settings: AppSettings, kind: NetKind, startId: Int, gen: Int) {
        Journal.add("bağlanıyor: ${server.name}")
        main.removeCallbacks(upgradeTask)
        synchronized(lock) {
            state = OrbState.CONNECTING
            serverId = server.id
            lastError = null
            lastInfo = null
            sinceMs = System.currentTimeMillis()
            baseQueries = 0
            baseHits = 0
            baseBlocked = 0
            downgraded = false
        }
        untrusted = false
        netFamilies = NetworkWatcher.families(this)
        publish()

        val plan = settings.plan(server)
        if (plan.isEmpty()) {
            fail(noProtoMessage(server, settings), startId)
            return
        }
        if (prepare(this) != null) { fail(Strings.ERR_PERMISSION, startId); return }
        strictPrivateDns()?.let { host -> fail(Strings.errPrivateDns(host), startId); return }

        var v6 = settings.ipMode == IpMode.BOTH
        var pfd = try {
            establishTunnel(settings, v6)
        } catch (e: Exception) {
            Journal.add("tünel açılamadı: ${e.javaClass.simpleName}")
            null
        }
        if (pfd == null && v6) {
            // Bazı sistemler IPv6 adresli tüneli reddeder: yalnızca IPv4 ile yeniden dene.
            Journal.add("IPv6'lı tünel kurulamadı, yalnızca IPv4 deneniyor")
            v6 = false
            pfd = try {
                establishTunnel(settings, false)
            } catch (e: Exception) {
                Journal.add("tünel açılamadı: ${e.javaClass.simpleName}")
                null
            }
        }
        if (pfd == null) { fail(Strings.ERR_ESTABLISH, startId); return }
        tunnelV6 = v6
        Journal.add("tünel: ${if (v6) "IPv4 + IPv6" else "IPv4"}, ağ: ${netFamilies}")

        val t = try {
            Tunnel(pfd, { tunnel, why -> tunnelEnded(tunnel, why) }, { onTunnelActivity() })
        } catch (e: Exception) {
            try { pfd.close() } catch (_: Exception) {}
            Journal.add("tünel başlatılamadı: ${e.javaClass.simpleName}")
            fail(Strings.ERR_SOCKET, startId, retryable = true)
            return
        }
        synchronized(lock) { tun = t }
        if (destroyed) { teardown(); return }     // servis tam bu sırada kapandı: açılan tüneli bırakma
        t.start()

        var used = server
        var chosen = tryPlan(server, settings, t, plan, kind, gen)
        if (cancelGen != gen || destroyed) return
        if (chosen == null) {
            // Seçili sunucu yanıt vermedi: yedek sunucu ayarlıysa onu dene.
            val backup = backupFor(server, settings)
            if (backup != null) {
                Journal.add("yedek sunucu deneniyor: ${backup.name}")
                synchronized(lock) { serverId = backup.id }
                chosen = tryPlan(backup, settings, t, settings.plan(backup), kind, gen)
                if (cancelGen != gen || destroyed) return
                if (chosen != null) {
                    used = backup
                    lastInfo = Strings.backupUsed(server.name, backup.name)
                    prefs.setSelection(backup.id, settings.withRecent(backup.id).recent)
                }
            }
        }
        if (chosen == null) {
            val strictFail = plan.none { it == Proto.PLAIN } && settings.encryption == Encryption.AUTO
            val msg = when {
                untrusted -> Strings.errUntrusted(server.name)
                strictFail -> Strings.errNoEncrypted(server.name)
                else -> Strings.errNoReply(server.name)
            }
            fail(msg, startId, retryable = true)
            return
        }

        val down = chosen.proto == Proto.PLAIN && settings.plan(used).firstOrNull() != Proto.PLAIN
        synchronized(lock) {
            state = OrbState.ON
            serverId = used.id
            sinceMs = System.currentTimeMillis()
            downgraded = down
            flushedQueries = 0; flushedHits = 0; flushedBlocked = 0
            flushedAnswered = 0; flushedLatency = 0; flushedUp = 0; flushedDown = 0
            flushedAt = SystemClock.elapsedRealtime()
            lastFlush = flushedAt
        }
        retrying = false
        retryStep = 0
        main.removeCallbacks(retryTask)
        prefs.setWasActive(true)
        Notifier.cancelAlert(this)
        if (down) {
            Journal.add("şifreli bağlantı kurulamadı, düz DNS kullanılıyor")
            if (settings.notifyDrop) Notifier.downgrade(this, used.name)
            scheduleUpgrade()
        } else {
            Notifier.cancelDowngrade(this)
        }
        startSession(used.id, chosen.proto)
        updateNotification()
        startWatcher()
        Journal.add("bağlandı: ${used.name} (${chosen.proto.name})")
        noteBypass()
        publish()
    }

    private fun noProtoMessage(server: DnsServer, settings: AppSettings): String =
        if (settings.encryption == Encryption.AUTO) Strings.errNoEncrypted(server.name)
        else Strings.errNoProto(server.name, Strings.OPT_ENCRYPTION[settings.encryption.ordinal])

    /**
     * [plan]'daki yöntemleri sırayla dener; ilk doğrulanan yönlendiriciyi tünele takıp döner. Ağ yoksa (ör. açılışta) ilk
     * yöntem doğrulamasız kabul edilir ve ilk ağ olayında sınanır ([verified]). Hiçbiri olmazsa null (tünelde yönlendirici yok).
     */
    private fun tryPlan(server: DnsServer, settings: AppSettings, t: Tunnel, plan: List<Proto>, kind: NetKind, gen: Int): Forwarder? {
        for ((i, proto) in plan.withIndex()) {
            if (cancelGen != gen || destroyed) return null
            val f = try {
                newForwarder(server, settings, t, proto)
            } catch (e: Exception) {
                Journal.add("yönlendirici (${proto.name}) başlatılamadı: ${e.javaClass.simpleName}")
                continue
            }
            t.forwarder = f
            synchronized(lock) { fw = f }
            // Bu arada servis kapandı ya da iptal edildiyse yeni yönlendirici sızmasın.
            if (destroyed || cancelGen != gen) { detach(t, f); return null }
            if (kind == NetKind.NONE) { verified = false; return f }
            if (verify(f, gen, triesFor(proto, i == plan.size - 1), msFor(proto))) { verified = true; return f }
            detach(t, f)
            if (cancelGen != gen) return null
            Journal.add("${proto.name} yanıt vermedi")
        }
        return null
    }

    private fun detach(t: Tunnel, f: Forwarder) {
        if (t.forwarder === f) t.forwarder = null
        synchronized(lock) { if (fw === f) fw = null }
        f.close()
    }

    /** Şifreli yöntemlerde el sıkışma sürdüğü için doğrulamaya daha uzun süre tanınır. */
    private fun triesFor(proto: Proto, last: Boolean): Int = if (last) CHECK_TRIES else if (proto == Proto.PLAIN) 2 else 3
    private fun msFor(proto: Proto): Long = if (proto == Proto.PLAIN) CHECK_MS else CHECK_MS_SECURE

    /** Yedek sunucu: ayarlı değilse null; "en hızlı" ise son ölçümlere göre seçili sunucu dışındaki en hızlı kullanılabilir sunucu. */
    private fun backupFor(failed: DnsServer, s: AppSettings): DnsServer? {
        val b = s.backupServer ?: return null
        val usable: (DnsServer) -> Boolean = { it.id != failed.id && it.id !in s.hidden && s.plan(it).isNotEmpty() }
        if (b == AppSettings.BACKUP_AUTO) {
            val lat = prefs.loadLatencies()
            return ServerList.fastest(Catalog.all, lat, usable)?.first ?: Catalog.all.firstOrNull(usable)
        }
        return Catalog.byId(b)?.takeIf(usable)
    }

    /**
     * Bağlıyken tüneli koparmadan sunucuyu (ya da aynı sunucuda yöntemi) değiştirir. [protos] sırayla denenir; hiçbiri
     * yanıt vermezse eskisi korunur. [force]: aynı sunucu için de yeni yönlendirici kur (ayar değişti, şifreye dönüş).
     * [quiet]: başarısızlık kullanıcıya bildirilmez (arka plandaki denemeler). @return geçildiyse true.
     */
    private fun switchServer(
        server: DnsServer, settings: AppSettings, gen: Int = cancelGen,
        protos: List<Proto> = settings.plan(server), force: Boolean = false, quiet: Boolean = false,
    ): Boolean {
        val t = tun ?: return false
        val old = fw ?: return false
        if (!force && server.id == serverId) return true
        if (!quiet) Journal.add("sunucu değişiyor: ${server.name}")
        if (protos.isEmpty()) {
            if (!quiet) publish(noProtoMessage(server, settings))
            return false
        }
        var fresh: Forwarder? = null
        untrusted = false
        for ((i, proto) in protos.withIndex()) {
            val f = try {
                newForwarder(server, settings, t, proto)
            } catch (e: Exception) {
                Journal.add("yeni yönlendirici (${proto.name}) başlatılamadı: ${e.javaClass.simpleName}")
                continue
            }
            t.forwarder = f
            if (verify(f, gen, triesFor(proto, i == protos.size - 1), msFor(proto))) { fresh = f; break }
            t.forwarder = old
            f.close()
            if (cancelGen != gen || destroyed) return false
        }
        if (fresh == null) {
            if (!quiet) {
                Journal.add("sunucu değişmedi: ${server.name} yanıt vermedi")
                publish(if (untrusted) Strings.errUntrusted(server.name) else Strings.errNoReply(server.name))
            }
            return false
        }
        val prevServer: String?
        synchronized(lock) {
            flushTotalsLocked()
            val os = old.stats()
            baseQueries += os.queries
            baseHits += os.cacheHits
            baseBlocked += os.blocked
            fw = fresh
            prevServer = serverId
            serverId = server.id
            flushedQueries = 0; flushedHits = 0; flushedBlocked = 0
            flushedAnswered = 0; flushedLatency = 0; flushedUp = 0; flushedDown = 0
            retired.add(old)
        }
        verified = true
        if (prevServer != server.id) {
            endSession(EndReason.SWITCH)
            startSession(server.id, fresh.proto)
        }
        val wasDown = downgraded
        downgraded = fresh.proto == Proto.PLAIN && settings.plan(server).firstOrNull() != Proto.PLAIN
        if (downgraded) {
            if (!wasDown && settings.notifyDrop) Notifier.downgrade(this, server.name)
            scheduleUpgrade()
        } else {
            main.removeCallbacks(upgradeTask)
            Notifier.cancelDowngrade(this)
        }
        sessionProto = fresh.proto          // aynı sunucuda yöntem değiştiyse (şifresizden DoT'a) süre doğru yönteme yazılsın
        // Eski yönlendiricinin son cevapları gelsin diye kısa süre açık tutulur.
        main.postDelayed({ submit(lastStartId) { retire(old) } }, RETIRE_MS)
        updateNotification()
        noteBypass()
        publish()
        return true
    }

    private fun retire(f: Forwarder) {
        synchronized(lock) { retired.remove(f) }
        f.close()
    }

    /** Bildirimdeki "Sonraki": favorilerde (yoksa son kullanılanlarda) katalog sırasıyla sıradaki sunucuya geçer. */
    private fun next(startId: Int) {
        if (state != OrbState.ON) { if (tun == null && !pausedNow()) shutdown(startId); return }
        val s = prefs.loadSettings()
        val ring = nextRing(s)
        if (ring.size < 2) return
        val cur = ring.indexOf(serverId)
        val target = Catalog.byId(ring[(cur + 1).mod(ring.size)]) ?: return
        // Seçim yalnızca geçiş başarılı olursa kaydedilir (yanıt vermeyen sunucu "son kullanılan" olmasın).
        if (switchServer(target, s)) prefs.setSelection(target.id, s.withRecent(target.id).recent)
    }

    /** Halka katalog sırasıyla kurulur: son kullanılanların sırası her geçişte değiştiği için aksi halde iki sunucu arasında gidilip gelinirdi. */
    private fun nextRing(s: AppSettings): List<String> {
        val usable: (DnsServer) -> Boolean = { s.plan(it).isNotEmpty() && it.id !in s.hidden }
        val fav = Catalog.all.filter { it.id in s.favorites && usable(it) }.map { it.id }
        if (fav.size >= 2) return fav
        return Catalog.all.filter { it.id in s.recent && usable(it) }.map { it.id }
    }

    /** Bağlıyken değişen ayarları (şifreleme, önbellek, ağ kuralı, bildirim) hemen uygular. */
    /** Uygulama seçimi değişti: tüneli aynı sunucuyla yeniden kurar (DNS bir iki saniye kesilir). */
    private fun rebuild(startId: Int, gen: Int) {
        if (state != OrbState.ON || tun == null || destroyed || cancelGen != gen) return
        val s = prefs.loadSettings()
        val server = Catalog.byId(serverId) ?: Catalog.default
        Journal.add("uygulama seçimi için tünel yeniden kuruluyor")
        endSession(EndReason.SWITCH)
        teardown()
        startTunnel(server, s, NetworkWatcher.currentKind(this), startId, gen)
    }

    private fun reapply(gen: Int) {
        if (state != OrbState.ON) { publish(); return }
        val s = prefs.loadSettings()
        val kind = NetworkWatcher.currentKind(this)
        val desired = Catalog.byId(Rules.ruleFor(s, kind) ?: serverId) ?: return
        Journal.add("ayarlar yeniden uygulanıyor")
        switchServer(desired, s, gen, force = true)
        updateNotification()
    }

    // ------------------------------------------------------------------ şifreli yönteme dönüş

    private fun scheduleUpgrade() {
        main.removeCallbacks(upgradeTask)
        main.postDelayed(upgradeTask, UPGRADE_MS)
    }

    /** Şifresiz DNS'e düşülmüşse şifreli yöntemleri sessizce yeniden dener; olmazsa 10 dakika sonra yine dener. */
    private fun tryUpgrade() {
        if (!downgraded || state != OrbState.ON || destroyed) return
        val s = prefs.loadSettings()
        val server = Catalog.byId(serverId) ?: return
        val enc = s.plan(server).filter { it != Proto.PLAIN }
        if (enc.isEmpty()) { downgraded = false; return }
        if (switchServer(server, s, cancelGen, protos = enc, force = true, quiet = true)) {
            Journal.add("şifreli bağlantıya dönüldü")
        } else {
            scheduleUpgrade()
        }
    }

    // ------------------------------------------------------------------ kendiliğinden yeniden deneme

    private fun cancelRetry() {
        retrying = false
        retryStep = 0
        main.removeCallbacks(retryTask)
    }

    /** Sıradaki denemeyi kurar; deneme hakkı bittiyse false. */
    private fun scheduleRetry(): Boolean {
        if (retryStep >= RETRY_DELAYS.size || destroyed) return false
        val delay = RETRY_DELAYS[retryStep]
        retrying = true
        synchronized(lock) { state = OrbState.CONNECTING; lastError = null }
        Journal.add("yeniden denenecek: ${delay / 1000} sn sonra")
        foreground(currentNotification())
        publish()
        main.removeCallbacks(retryTask)
        main.postDelayed(retryTask, delay)
        return true
    }

    private fun retryNow() {
        if (!retrying || destroyed || state == OrbState.ON) return
        retryStep++
        connect(null, lastStartId, cancelGen)
    }

    // ------------------------------------------------------------------ duraklatma

    private fun pause(minutes: Int, startId: Int) {
        val until = System.currentTimeMillis() + minutes.coerceIn(1, 24 * 60) * 60_000L
        Journal.add("duraklatıldı: $minutes dk")
        cancelRetry()
        main.removeCallbacks(upgradeTask)
        endSession(EndReason.PAUSE)
        teardown()
        prefs.setWasActive(false)
        prefs.setPausedUntil(until)
        pausedUntil = until
        synchronized(lock) { state = OrbState.OFF; lastError = null; serverId = null; downgraded = false }
        Notifier.cancelDowngrade(this)
        enterPaused()
    }

    /** Duraklatma durumu: servis önplanda kalır (geri sayımlı bildirim), süre bitince iki yoldan biri bağlantıyı sürdürür. */
    private fun enterPaused() {
        val until = pausedUntil
        if (until <= 0L) return
        PauseAlarm.schedule(this, until)
        armListener(until)
        foreground(currentNotification())
        publish()
    }

    /** Süreç yaşadıkça izin gerektirmeyen kesin zamanlayıcı (OnAlarmListener). Süreç ölürse [PauseAlarm] devralır. */
    private fun armListener(until: Long) {
        val am = getSystemService(AlarmManager::class.java) ?: return
        try {
            am.cancel(pauseListener)
            am.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + maxOf(0L, until - System.currentTimeMillis()),
                "dnshizli-resume", pauseListener, main)
        } catch (e: Exception) {
            Journal.add("zamanlayıcı kurulamadı: ${e.javaClass.simpleName}")
        }
    }

    private fun cancelListener() {
        try { getSystemService(AlarmManager::class.java)?.cancel(pauseListener) } catch (_: Exception) {}
    }

    private fun resumeFromAlarm() {
        if (!pausedNow()) return      // bu arada sürdürüldü ya da kesildi
        Journal.add("duraklatma bitti")
        clearPause()
        markAuto(true)
        connect(null, lastStartId, cancelGen)
    }

    private fun clearPause() {
        if (pausedUntil == 0L && prefs.pausedUntil() == 0L) return
        pausedUntil = 0L
        prefs.setPausedUntil(0L)
        PauseAlarm.cancel(this)
        cancelListener()
    }

    // ------------------------------------------------------------------ doğrulama, test ve kapatma

    /**
     * Android 9+ "Özel DNS" bir ada sabitse (katı mod) sistem DNS'i doğrudan o sunucuya şifreli gönderir; VPN'in
     * DNS adresi hiç kullanılmaz ve bağlantı testi asla geçmez. Bunu baştan tanıyıp kullanıcıya ne yapacağını söyleriz.
     */
    private fun strictPrivateDns(): String? {
        if (Build.VERSION.SDK_INT < 28) return null
        return try {
            val cm = getSystemService(android.net.ConnectivityManager::class.java) ?: return null
            val lp = cm.getLinkProperties(cm.activeNetwork ?: return null) ?: return null
            if (lp.isPrivateDnsActive) lp.privateDnsServerName else null
        } catch (_: Exception) { null }
    }

    private enum class Check { OK, UPSTREAM_ONLY, FAIL }

    /**
     * İki aşamalı doğrulama:
     *  1) Sunucu çalışıyor mu? Tünele kendi sorgumuz verilir (bkz. [SelfTest.packet]); telefonun çözümleyicisinden
     *     bağımsızdır, bu yüzden "sunucu mu bozuk, telefon mu sorgu göndermiyor" ayrımı yapılabilir.
     *  2) Telefon sorguları tünelden gönderiyor mu? Sistemin çözümleyicisiyle rastgele bir ad çözdürülür.
     * Birincisi geçip ikincisi geçmezse [Check.UPSTREAM_ONLY]: sunucu sağlam, sorun telefon tarafında.
     */
    private fun verifyDetailed(f: Forwarder, gen: Int, tries: Int, ms: Long): Check {
        val t = tun
        if (t != null) {
            var upstream = false
            for (attempt in 0 until tries) {
                if (cancelGen != gen || destroyed) return Check.FAIL
                val r = ConnectionCheck.run(f, { t.inject(SelfTest.packet(random.nextInt(0x10000), randomName())) }, ms)
                if (r is CheckResult.Ok) {
                    Journal.add("sunucu testi (${f.proto.name}): ${r.ms} ms")
                    upstream = true
                    break
                }
                if (r is CheckResult.Untrusted) {
                    untrusted = true
                    Journal.add("sertifika doğrulanamadı (${f.proto.name}): şifreli bağlantıya karışılıyor olabilir")
                    return Check.FAIL
                }
            }
            if (!upstream) {
                Journal.add("sunucuya ulaşılamadı (${f.proto.name})")
                return Check.FAIL
            }
        }
        val sysTries = if (t != null) 2 else tries
        for (attempt in 0 until sysTries) {
            if (cancelGen != gen || destroyed) return Check.FAIL
            val r = ConnectionCheck.run(f, { InetAddress.getByName(randomName()) }, ms)
            if (r is CheckResult.Ok) {
                Journal.add("bağlantı testi (${f.proto.name}): ${r.ms} ms")
                return Check.OK
            }
        }
        if (t != null) {
            Journal.add("sunucu çalışıyor ama telefon sorguları tünelden göndermiyor (${f.proto.name})")
            return Check.UPSTREAM_ONLY
        }
        Journal.add("bağlantı testi başarısız (${f.proto.name})")
        return Check.FAIL
    }

    /** [verifyDetailed] sonucunu boolean'a çevirir; telefon tarafı sorunu [phoneBypass] ile işaretlenir. */
    private fun verify(f: Forwarder, gen: Int, tries: Int, ms: Long = CHECK_MS): Boolean {
        val c = verifyDetailed(f, gen, tries, ms)
        if (c == Check.FAIL) return false
        phoneBypass = c == Check.UPSTREAM_ONLY
        return true
    }

    /** Doğrulama sonrası: telefon tünel dışı kalıyorsa uyarı ve arka planda yeniden sınama kur; düzeldiyse uyarıyı kaldır. */
    private fun noteBypass() {
        main.removeCallbacks(recheckTask)
        if (phoneBypass) {
            bypassChecks = 0
            main.postDelayed(recheckTask, RECHECK_MS)
        }
    }

    /** Telefon sorgularını artık tünelden gönderiyor mu? Gönderiyorsa uyarı kalkar; değilse birkaç kez daha denenir. */
    private fun recheckPhone() {
        if (!phoneBypass || state != OrbState.ON || destroyed) return
        val f = fw ?: return
        val r = ConnectionCheck.run(f, { InetAddress.getByName(randomName()) }, CHECK_MS_SECURE)
        if (r is CheckResult.Ok) {
            phoneBypass = false
            Journal.add("telefon artık sorguları tünelden gönderiyor")
            publish()
        } else if (++bypassChecks < 3) {
            main.postDelayed(recheckTask, RECHECK_MS * 2)
        }
    }

    private fun randomName(): String = "dh" + java.lang.Long.toString(random.nextLong() ushr 1, 36) + ".example.com"

    /** Kullanıcının istediği bağlantı testi: tünelin içinden üç soru (bkz. [SelfTest]); sonuç arayüze yayınlanır. */
    private fun runTest() {
        val t = tun
        val f = fw
        val sid = serverId
        if (state != OrbState.ON || t == null || f == null) {
            VpnStatus.publishTest(SelfTestResult(false, null, null, sid, DnssecResult.UNKNOWN, AdBlockResult.UNKNOWN))
            return
        }
        Thread({
            val r = try {
                SelfTest.run(inject = { p -> t.inject(p) }, tap = tap, proto = f.proto, serverId = sid, tunnelV6 = tunnelV6)
            } catch (e: Exception) {
                SelfTestResult(false, null, f.proto, sid, DnssecResult.UNKNOWN, AdBlockResult.UNKNOWN)
            }
            Journal.add("bağlantı testi: ${if (r.ok) "${r.ms} ms" else "yanıt yok"}, DNSSEC ${r.dnssec}, reklam ${r.ads}")
            VpnStatus.publishTest(r)
        }, "dns-test").also { it.isDaemon = true }.start()
    }

    private fun disconnect(startId: Int) {
        Journal.add("bağlantı kesildi")
        cancelRetry()
        main.removeCallbacks(upgradeTask)
        clearPause()
        endSession(EndReason.USER)
        teardown()
        prefs.setWasActive(false)
        synchronized(lock) { state = OrbState.OFF; lastError = null; serverId = null; downgraded = false }
        Notifier.cancelDowngrade(this)
        publish()
        shutdown(startId)
    }

    /**
     * Bağlanamadı. [retryable] (ağ/sunucu kaynaklı) ve kendiliğinden yeniden deneme sürüyorsa bir sonraki deneme kurulur;
     * değilse hata gösterilir ve servis durur.
     */
    private fun fail(message: String, startId: Int, retryable: Boolean = false) {
        Journal.add("bağlanamadı: $message")
        endSession(EndReason.FAILED)
        teardown()
        if (retryable && retrying && prefs.loadSettings().autoReconnect && scheduleRetry()) return
        val wasRetrying = retrying
        retrying = false
        retryStep = 0
        prefs.setWasActive(false)
        synchronized(lock) { state = OrbState.ERROR; lastError = message; downgraded = false }
        publish()
        if (wasRetrying) notifyDrop(message)
        shutdown(startId)
    }

    private fun tunnelEnded(t: Tunnel, why: String) {
        val sid = lastStartId
        submit(sid) {
            if (tun !== t) return@submit        // zaten kapatıldı ya da değiştirildi
            Journal.add("tünel kapandı: $why")
            val wasOn = state == OrbState.ON
            endSession(EndReason.DROP)
            val s = prefs.loadSettings()
            if (wasOn && s.autoReconnect && prepare(this) == null) {
                teardown()
                retrying = true
                retryStep = 0
                if (scheduleRetry()) return@submit
            }
            fail(Strings.ERR_TUNNEL, sid)
            if (wasOn) notifyDrop(Strings.ERR_TUNNEL)
        }
    }

    /** "Bağlantı koparsa bildir" açıksa yeniden bağlan düğmeli uyarı gösterir. */
    private fun notifyDrop(reason: String) {
        if (prefs.loadSettings().notifyDrop) Notifier.drop(this, reason)
    }

    private fun onNetwork(kind: NetKind) {
        if (state != OrbState.ON || kind == NetKind.NONE) return
        netFamilies = NetworkWatcher.families(this)
        Journal.add("ağ değişti: $kind ($netFamilies)")
        val settings = prefs.loadSettings()
        val gen = cancelGen
        if (settings.refreshOnNetwork) fw?.resetNetwork("ağ: $kind")
        val rule = Rules.ruleFor(settings, kind)
        if (rule != null && rule != serverId) {
            Catalog.byId(rule)?.let { if (switchServer(it, settings, gen)) return }
        }
        // Yeni ağda bağlantı gerçekten çalışıyor mu? (Ağ yokken kurulan bağlantı da burada ilk kez sınanır.)
        val f = fw ?: return
        if (verify(f, gen, 2, msFor(f.proto))) {
            verified = true
            noteBypass()
            publish()
        } else if (cancelGen == gen) {
            Journal.add("yeni ağda yanıt yok: yöntemler yeniden deneniyor")
            Catalog.byId(serverId)?.let { switchServer(it, settings, gen, force = true, quiet = true) }
        }
        if (downgraded) tryUpgrade()
    }

    // ------------------------------------------------------------------ oturum (bağlantı geçmişi)

    private fun totalQueriesNow(): Long = baseQueries + (fw?.stats()?.queries ?: 0L)

    private fun startSession(id: String, proto: Proto) {
        sessionServer = id
        sessionProto = proto
        sessionStart = System.currentTimeMillis()
        sessionBase = totalQueriesNow()
    }

    @Synchronized
    private fun endSession(reason: EndReason) {
        val id = sessionServer ?: return
        sessionServer = null
        val now = System.currentTimeMillis()
        if (now - sessionStart < 1000L) return                // anlık oturumlar geçmişi doldurmasın
        try {
            prefs.addSession(Session(id, sessionProto, sessionStart, now, reason, maxOf(0L, totalQueriesNow() - sessionBase)))
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ temizlik, durum

    /** Tüneli, yönlendiriciyi ve ağ izleyiciyi kapatır; toplamları depoya aktarır. Birden çok kez çağrılabilir. */
    private fun teardown() {
        var t: Tunnel? = null
        var f: Forwarder? = null
        var old: List<Forwarder> = emptyList()
        synchronized(lock) {
            flushTotalsLocked()
            t = tun; f = fw
            tun = null; fw = null
            old = retired.toList()
            retired.clear()
        }
        stopWatcher()
        main.removeCallbacks(recheckTask)
        phoneBypass = false
        t?.close()
        f?.close()
        for (x in old) x.close()
    }

    /** [lock] altında çağrılır: son aktarımdan bu yana biriken sayıları depoya ekler. */
    private fun flushTotalsLocked() {
        val f = fw ?: return
        val st = f.stats()
        val now = SystemClock.elapsedRealtime()
        val secs = if (state == OrbState.ON) maxOf(0L, (now - flushedAt) / 1000) else 0L
        prefs.addTotals(
            PrefsStore.Delta(
                queries = st.queries - flushedQueries, hits = st.cacheHits - flushedHits, blocked = st.blocked - flushedBlocked,
                seconds = secs, answered = st.answered - flushedAnswered, latencyMs = st.latencySumMs - flushedLatency,
                bytesUp = st.bytesUp - flushedUp, bytesDown = st.bytesDown - flushedDown,
            ),
            serverId,
        )
        flushedQueries = st.queries
        flushedHits = st.cacheHits
        flushedBlocked = st.blocked
        flushedAnswered = st.answered
        flushedLatency = st.latencySumMs
        flushedUp = st.bytesUp
        flushedDown = st.bytesDown
        flushedAt += secs * 1000
    }

    /**
     * Tünel okuyucusundan (her uyanışta) çağrılır: trafik varken en çok dakikada bir toplamlar depoya aktarılır,
     * bildirimdeki sayaçlar ve widget güncellenir. Trafik yokken hiçbir şey yapılmaz (zamanlayıcı yok).
     */
    private fun onTunnelActivity() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastFlush < FLUSH_MS) return
        lastFlush = now
        submit(lastStartId) {
            synchronized(lock) { flushTotalsLocked() }
            if (state == OrbState.ON) { updateNotification(); publishWidget(snapshot()) }
        }
    }

    /** Arayüzün gördüğü canlı durum. Her iş parçacığından çağrılabilir. */
    private fun snapshot(): VpnUi {
        val f = fw
        val st = f?.stats()
        val s = state
        // Arayüz görünürken (istatistik çekerken) toplamlar arada bir depoya aktarılır; ek zamanlayıcı yok.
        if (s == OrbState.ON) {
            val now = SystemClock.elapsedRealtime()
            if (now - lastFlush > FLUSH_MS) {
                lastFlush = now
                submit(lastStartId) { synchronized(lock) { flushTotalsLocked() } }
            }
        }
        return VpnUi(
            state = s,
            serverId = serverId,
            sinceMs = sinceMs,
            queries = baseQueries + (st?.queries ?: 0L),
            cacheHits = baseHits + (st?.cacheHits ?: 0L),
            avgMs = st?.avgMs ?: 0,
            error = if (s == OrbState.ERROR) lastError else null,
            onBackup = st?.backup ?: false,
            proto = if (s == OrbState.ON) f?.proto else null,
            blocked = baseBlocked + (st?.blocked ?: 0L),
            pausedUntil = if (s == OrbState.OFF) pausedUntil else 0L,
            downgraded = s == OrbState.ON && downgraded,
            retrying = s == OrbState.CONNECTING && retrying,
            info = lastInfo ?: (if (s == OrbState.ON && phoneBypass) Strings.PHONE_BYPASS else null),
        )
    }

    /** Güncel durumu yayınlar. [error] doluysa bu yayına tek seferlik hata olarak eklenir (ör. başarısız sunucu geçişi). */
    private fun publish(error: String? = null) {
        val s = snapshot()
        val v = if (error != null) s.copy(error = error) else s
        VpnStatus.publish(v)
        publishWidget(v)
    }

    private fun publishWidget(v: VpnUi) {
        try { DnsWidget.updateAll(this, v) } catch (_: Exception) {}
    }

    private fun startWatcher() {
        stopWatcher()
        val sid = lastStartId
        val w = NetworkWatcher(this) { kind -> submit(sid) { onNetwork(kind) } }
        watcher = w
        w.start()
    }

    private fun stopWatcher() {
        watcher?.stop()
        watcher = null
    }

    /** Servisi durdurur. Bu arada daha yeni bir başlatma komutu geldiyse ([startId] eskiyse) dokunmaz; yeni komut devralır. */
    private fun shutdown(startId: Int) {
        main.post {
            if (startId == lastStartId && !pausedNow() && !retrying) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
            }
        }
    }

    // ------------------------------------------------------------------ bildirim

    private fun currentNotification(): Notification {
        val s = prefs.loadSettings()
        return when {
            pausedNow() -> Notifier.paused(this, s, pausedUntil, Format.hm(pausedUntil))
            state == OrbState.ON -> onNotification(s)
            retrying -> Notifier.build(this, s, Strings.NOTIF_RETRYING, false)
            else -> Notifier.build(this, s, Strings.NOTIF_CONNECTING, false)
        }
    }

    private fun onNotification(s: AppSettings = prefs.loadSettings()): Notification {
        val name = Catalog.byId(serverId)?.name ?: Catalog.default.name
        val proto = Strings.protoName(fw?.proto ?: Proto.PLAIN)
        val ui = snapshot()
        val text = if (ui.queries > 0) Strings.notifOnStats(name, proto, Format.count(ui.queries), Format.count(ui.blocked))
            else Strings.notifOn(name, proto)
        return Notifier.build(this, s, text, true, sinceMs, nextRing(s).size >= 2)
    }

    private fun updateNotification() {
        if (destroyed) return
        // Kanal (sade bildirim) değişmiş olabilir: önplan bildirimi yeniden verilir.
        foreground(onNotification())
    }

    private fun foreground(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(Notifier.NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
            } else {
                startForeground(Notifier.NOTIF_ID, n)
            }
        } catch (e: Exception) {
            // Önplana alınamazsa (ör. arka plandan başlatma kısıtı) servis yine çalışır; VPN uygulaması sistemce korunur.
            Journal.add("önplan bildirimi açılamadı: ${e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------------------------ tünel kurulumu

    private fun establishTunnel(settings: AppSettings, v6: Boolean): ParcelFileDescriptor? {
        val configure = PendingIntent.getActivity(
            this, 0, Notifier.appIntent(this),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = Builder()
            .setSession(Strings.APP)
            .setMtu(MTU)
            .addAddress(CLIENT_ADDR, 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)      // yalnızca DNS adresi tünele girer; diğer tüm trafik normal gider
            .setBlocking(false)
            .setConfigureIntent(configure)
        if (v6) {
            // IPv6 ağlarda sistem çözümleyicisi IPv6 DNS adresine de sorabilir: o da aynı yerel yönlendiriciye gelir.
            b.addAddress(CLIENT_ADDR6, 128).addDnsServer(FAKE_DNS6).addRoute(FAKE_DNS6, 128)
        }
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)
        applyScope(b, settings)
        // Yalnızca IPv4 adres/yol eklendiğinde Android varsayılan olarak tüm IPv6 trafiğini engeller; engellenmesin.
        b.allowFamily(OsConstants.AF_INET6)
        return b.establish()
    }

    /** "Hangi uygulamalar" ayarını tünele uygular (izinli ya da dışlanan paketler; ikisi aynı anda kullanılamaz). */
    private fun applyScope(b: Builder, settings: AppSettings) {
        val pm = packageManager
        val plan = AppScopes.plan(settings, packageName) { p ->
            try { pm.getApplicationInfo(p, 0); true } catch (_: Exception) { false }
        }
        if (plan.kind == ScopePlan.Kind.ALL) {
            if (settings.appScope != AppScope.ALL) Journal.add("uygulama seçimi boş ya da yüklü değil: tüm uygulamalar")
            return
        }
        var added = 0
        for (p in plan.packages) {
            try {
                if (plan.kind == ScopePlan.Kind.ALLOW) b.addAllowedApplication(p) else b.addDisallowedApplication(p)
                added++
            } catch (_: Exception) { /* paket tam bu sırada kaldırıldı */ }
        }
        Journal.add(if (plan.kind == ScopePlan.Kind.ALLOW) "yalnızca $added uygulama tünelde" else "$added uygulama tünel dışında")
    }

    private fun newForwarder(server: DnsServer, settings: AppSettings, t: Tunnel, proto: Proto): Forwarder {
        // Bağlantı testinin cevapları tünele yazılmaz, teste gider.
        val write: (ByteArray, Int, Int) -> Unit = { b, off, len -> if (!tap.offer(b, off, len)) t.write(b, off, len) }
        val f: Forwarder = when (proto) {
            Proto.PLAIN -> DnsForwarder(
                // IPv4 ve IPv6 birlikte: ağın kullandığı aile önce, öbürü yedek ([Targets.plain]).
                upstreams = Targets.plain(server, settings.ipMode, netFamilies).map { InetSocketAddress(addr(it), 53) },
                writeToTun = write,
                protect = { s -> protect(s) },
                cacheEntries = settings.cache.entries,
                log = { Journal.add(it) },
            )
            Proto.DOT, Proto.DOH -> SecureForwarder(
                proto = proto,
                targets = secureTargets(server, proto, settings),
                writeToTun = write,
                openSocket = { a, timeout -> protectedSocket(a, timeout) },
                tls = freshTlsFactory(),
                freshTls = { freshTlsFactory() },
                cacheEntries = settings.cache.entries,
                log = { Journal.add(it) },
            )
        }
        f.start()
        return f
    }

    /**
     * TLS oturum önbelleği boş, yeni bir soket fabrikası. Önceki bağlantıların oturum biletleri yeniden kullanılmaz:
     * biletler sunucunun bizi iki bağlantı (ya da iki ağ) arasında tanımasına yarardı.
     */
    private fun freshTlsFactory(): SSLSocketFactory {
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(null, null, null)
        return ctx.socketFactory
    }

    /** Yazılı IP adresinden [InetAddress]; ad çözümlemesi yapmaz. */
    private fun addr(ip: String): InetAddress = InetAddress.getByAddress(Ip.parse(ip) ?: throw IllegalArgumentException("geçersiz adres"))

    /**
     * Tünel dışında tutulan (VpnService.protect) TCP soketi. Bağlanmamış bir Socket'in dosya tanıtıcısı henüz
     * yoktur ve protect() onu işaretleyemez; bu yüzden önce yerel bir adrese bağlanır (bind), sonra korunur, sonra
     * hedefe bağlanır. Koruma yine de başarısız olursa bağlantı sürdürülür: tünel yalnızca sahte DNS adresini
     * yönlendirdiği için sunucu trafiği zaten tünele girmez (yalnızca "her zaman açık + kilitli" modda koruma şarttır).
     */
    private fun protectedSocket(addr: InetSocketAddress, timeout: Int): Socket {
        val s = Socket()
        try {
            try { s.bind(null) } catch (_: java.io.IOException) {}
            val ok = try { protect(s) } catch (_: Exception) { false }
            if (!ok) Journal.add("uyarı: TLS soketi korunamadı")
            s.connect(addr, timeout)
            return s
        } catch (e: java.io.IOException) {
            try { s.close() } catch (_: Exception) {}
            throw e
        } catch (e: RuntimeException) {
            try { s.close() } catch (_: Exception) {}
            throw java.io.IOException(e)
        }
    }

    /**
     * Şifreli hedefler: sertifika adı katalogdan, adresler katalogdan (IPv4 ve IPv6; bkz. [Targets.secure]). DoH adı çoğu
     * zaman DNS adresinden başka bir adreste yayındadır (ör. doh.opendns.com): yalnızca "Otomatik" kipte ve şifresiz yola
     * düşmeye izin verilmişken, sağlayıcının kendi düz DNS adresine tek bir A sorusu sorulur ([Bootstrap]). Şifreli-yalnızca
     * kiplerde ve sıkı şifrelemede hiçbir şifresiz sorgu gönderilmez; katalogdaki adresler kullanılır.
     */
    private fun secureTargets(server: DnsServer, proto: Proto, settings: AppSettings): List<SecureTarget> {
        val port = if (proto == Proto.DOT) 853 else 443
        val dns4 = server.addresses4.firstOrNull()
        val host = server.tlsHost(proto, 0)
        val bootstrap = proto == Proto.DOH && server.plain && settings.encryption == Encryption.AUTO &&
            !settings.strictEncryption && settings.ipMode == IpMode.BOTH && netFamilies.v4 && dns4 != null && host != null
        val extra = if (!bootstrap) emptyList() else Bootstrap.resolveA(host, dns4, timeoutMs = 800, tries = 1, newSocket = {
            DatagramSocket().also { s -> try { protect(s) } catch (_: Exception) {} }
        })
        return Targets.secure(server, proto, settings.ipMode, netFamilies, extra).map {
            SecureTarget(InetSocketAddress(addr(it.ip), port), it.host, it.path, it.alt?.let { a -> InetSocketAddress(addr(a), port) })
        }
    }

    // ------------------------------------------------------------------ tünel okuyucu

    /**
     * Tünel arayüzünü okuyan tek iş parçacığı. `poll()` tünel ile bir uyandırma borusunu birlikte bekler: paket
     * yokken hiç uyanmaz; kapatılırken ya da bağlantı testi bir soru eklediğinde boruya yazılarak anında uyandırılır.
     * Eklenen sorular da bu iş parçacığında yönlendiriciye verilir ([Forwarder.onPacket] tek iş parçacıklıdır).
     */
    private class Tunnel(
        private val pfd: ParcelFileDescriptor,
        private val onEnded: (Tunnel, String) -> Unit,
        private val onActivity: () -> Unit,
    ) {
        @Volatile var forwarder: Forwarder? = null
        @Volatile private var stopping = false

        private val fd: FileDescriptor = pfd.fileDescriptor
        private val pipe: Array<FileDescriptor> = Os.pipe()
        private val thread = Thread({ loop() }, "dns-tun").also { it.isDaemon = true }
        private val injected = ConcurrentLinkedQueue<ByteArray>()

        // Yazma ve kapatma birbirini dışlar: kapanan bir dosya tanıtıcısının numarası başka bir dosyaya verilmişken
        // gecikmiş bir cevabın oraya yazılması (klasik fd yeniden kullanım hatası) böylece imkânsız olur.
        private val writeLock = Any()
        private var closed = false
        private val closing = AtomicBoolean(false)

        fun start() = thread.start()

        /** Cevabı tünele yazar. Kuyruk doluysa ya da arayüz kapandıysa paket sessizce atılır; istemci yeniden dener. */
        fun write(b: ByteArray, off: Int, len: Int) {
            synchronized(writeLock) {
                if (closed) return
                try { Os.write(fd, b, off, len) } catch (_: Exception) {}
            }
        }

        /** Tünelden gelmiş gibi bir paket ekler (bağlantı testi). Okuyucu iş parçacığı uyandırılır. */
        fun inject(p: ByteArray) {
            if (stopping) return
            injected.add(p)
            synchronized(writeLock) {
                if (closed) return
                try { Os.write(pipe[1], byteArrayOf(2), 0, 1) } catch (_: Exception) {}
            }
        }

        fun close() {
            if (!closing.compareAndSet(false, true)) return     // ikinci çağrı: borular zaten kapalı olabilir
            stopping = true
            try { Os.write(pipe[1], byteArrayOf(1), 0, 1) } catch (_: Exception) {}
            if (Thread.currentThread() !== thread && thread.isAlive) {
                try { thread.join(1000) } catch (_: InterruptedException) {}
            }
            synchronized(writeLock) {
                if (closed) return
                closed = true
                try { pfd.close() } catch (_: Exception) {}
                try { Os.close(pipe[0]) } catch (_: Exception) {}
                try { Os.close(pipe[1]) } catch (_: Exception) {}
            }
        }

        private fun loop() {
            var why = "okuma bitti"
            try {
                val tunPoll = StructPollfd()
                tunPoll.fd = fd
                tunPoll.events = OsConstants.POLLIN.toShort()
                val wakePoll = StructPollfd()
                wakePoll.fd = pipe[0]
                wakePoll.events = OsConstants.POLLIN.toShort()
                val fds = arrayOf(tunPoll, wakePoll)
                val buf = ByteArray(BUF)
                val wake = ByteArray(64)
                val bad = OsConstants.POLLERR or OsConstants.POLLHUP or OsConstants.POLLNVAL
                while (!stopping) {
                    tunPoll.revents = 0
                    wakePoll.revents = 0
                    try {
                        Os.poll(fds, -1)
                    } catch (e: ErrnoException) {
                        if (e.errno == OsConstants.EINTR) continue
                        throw e
                    }
                    if (stopping) break
                    if (wakePoll.revents.toInt() != 0) {
                        // Uyandırma: borudaki baytları boşalt (poll hazır dediği için okuma bloklamaz), eklenenleri işle.
                        try { Os.read(pipe[0], wake, 0, wake.size) } catch (_: ErrnoException) {}
                        if (stopping) break
                        while (true) {
                            val p = injected.poll() ?: break
                            try { forwarder?.onPacket(p, p.size) } catch (_: Exception) {}
                        }
                    }
                    val r = tunPoll.revents.toInt()
                    if (r and OsConstants.POLLIN != 0) drain(buf)
                    else if (r and bad != 0) { why = "tünel arayüzü kapandı"; break }
                    onActivity()
                }
            } catch (e: Exception) {
                why = "hata: ${e.javaClass.simpleName}"
            }
            if (!stopping) onEnded(this, why)
        }

        /** Hazır paketleri (en çok [MAX_BURST]) okuyup yönlendiriciye verir. Okunacak kalmayınca döner. */
        private fun drain(buf: ByteArray) {
            var n = 0
            while (n++ < MAX_BURST && !stopping) {
                val len = try {
                    Os.read(fd, buf, 0, buf.size)
                } catch (e: ErrnoException) {
                    if (e.errno == OsConstants.EAGAIN) return
                    if (e.errno == OsConstants.EINTR) continue
                    throw e
                }
                if (len <= 0) throw IllegalStateException("tünel okuması 0 bayt döndü")
                // Tek bir bozuk paket tüneli düşürmesin.
                try { forwarder?.onPacket(buf, len) } catch (_: Exception) {}
            }
        }

        private companion object {
            const val BUF = 4096
            const val MAX_BURST = 32
        }
    }

    companion object {
        const val ACTION_CONNECT = "app.dnshizli.CONNECT"
        const val ACTION_DISCONNECT = "app.dnshizli.DISCONNECT"
        const val ACTION_PAUSE = "app.dnshizli.PAUSE"
        const val ACTION_RESUME = "app.dnshizli.RESUME"
        const val ACTION_NEXT = "app.dnshizli.NEXT"
        const val ACTION_CLEAR_CACHE = "app.dnshizli.CLEAR_CACHE"
        const val ACTION_REAPPLY = "app.dnshizli.REAPPLY"
        const val ACTION_REBUILD = "app.dnshizli.REBUILD"
        const val ACTION_TEST = "app.dnshizli.TEST"
        const val EXTRA_SERVER = "server"
        const val EXTRA_MINUTES = "minutes"
        const val EXTRA_AUTO = "auto"

        /** Tünelin istemci adresi ve sahte DNS adresi (özel aralık; gerçek bir cihazla çakışmaz). */
        const val CLIENT_ADDR = SelfTest.CLIENT_ADDR
        const val FAKE_DNS = SelfTest.FAKE_DNS
        const val CLIENT_ADDR6 = SelfTest.CLIENT_ADDR6
        const val FAKE_DNS6 = SelfTest.FAKE_DNS6
        const val MTU = 1500

        private const val CHECK_TRIES = 4
        private const val CHECK_MS = 2000L
        private const val CHECK_MS_SECURE = 3500L
        private const val RECHECK_MS = 8_000L
        private const val RETIRE_MS = 3000L
        private const val FLUSH_MS = 60_000L
        private const val UPGRADE_MS = 10 * 60_000L
        private val RETRY_DELAYS = longArrayOf(5_000L, 30_000L, 120_000L)

        /** [serverId] boşsa servis ağ kuralına, yoksa son kullanılan sunucuya bakar. */
        fun connectIntent(ctx: Context, serverId: String?, auto: Boolean = false): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_CONNECT).also {
                if (serverId != null) it.putExtra(EXTRA_SERVER, serverId)
                if (auto) it.putExtra(EXTRA_AUTO, true)
            }

        fun disconnectIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_DISCONNECT)

        fun pauseIntent(ctx: Context, minutes: Int): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_PAUSE).putExtra(EXTRA_MINUTES, minutes)

        fun resumeIntent(ctx: Context, auto: Boolean = false): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_RESUME).also { if (auto) it.putExtra(EXTRA_AUTO, true) }

        fun nextIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_NEXT)

        fun clearCacheIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_CLEAR_CACHE)

        fun reapplyIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_REAPPLY)

        fun rebuildIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_REBUILD)

        fun testIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_TEST)
    }
}
