package app.dnshizli.platform

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import app.dnshizli.R
import app.dnshizli.core.AppSettings
import app.dnshizli.ui.Strings

/**
 * Bildirimler:
 *  - Durum bildirimi (önplan servisi için zorunlu): bağlıyken sunucu, şifreleme, canlı sayaçlar ve süre (sistem
 *    kronometresi, uygulama her saniye uyanmaz); "Kes", "Sonraki", "15 dk duraklat". Duraklatılmışken geri sayım ve "Devam et".
 *    "Sade bildirim" açıksa en düşük önemdeki kanal (durum çubuğunda simge yok); "Kilit ekranında gizle" açıksa kilit
 *    ekranında sunucu adı yerine yalnızca "DNS koruması açık" görünür.
 *  - Uyarılar: bağlantı beklenmedik koptu (yeniden bağlan), şifreli bağlantı kurulamadı, VPN izni için uygulamayı aç.
 *
 * Tüm düğmeler dışa kapalı [ActionReceiver]'a gider; o da servisi ancak VPN izni varken başlatır.
 */
object Notifier {
    private const val CHANNEL_ID = "status"
    private const val QUIET_CHANNEL_ID = "status_quiet"
    private const val ALERT_CHANNEL_ID = "alerts"
    const val NOTIF_ID = 1
    const val ALERT_ID = 2
    const val DOWNGRADE_ID = 3
    const val NEED_APP_ID = 4

    /** Kanalları (yoksa) oluşturur; adlarını etkin dile göre günceller. */
    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val ch = NotificationChannel(CHANNEL_ID, Strings.NOTIF_CHANNEL, NotificationManager.IMPORTANCE_LOW)
        ch.description = Strings.NOTIF_CHANNEL_NOTE
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
        val quiet = NotificationChannel(QUIET_CHANNEL_ID, Strings.NOTIF_QUIET_CHANNEL, NotificationManager.IMPORTANCE_MIN)
        quiet.description = Strings.NOTIF_CHANNEL_NOTE
        quiet.setShowBadge(false)
        nm.createNotificationChannel(quiet)
        val alert = NotificationChannel(ALERT_CHANNEL_ID, Strings.NOTIF_ALERT_CHANNEL, NotificationManager.IMPORTANCE_DEFAULT)
        alert.setShowBadge(false)
        nm.createNotificationChannel(alert)
    }

    /** Uygulamayı açan niyet: içeriden (dışa kapalı takma ad) gönderilir; [action] doluysa uygulama onu güvenle işler. */
    fun appIntent(ctx: Context, action: String? = null): Intent =
        Intent().setClassName(ctx, MainActivity.INTERNAL_ALIAS).also { if (action != null) it.action = action }
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)

    private fun openApp(ctx: Context, code: Int = 0, action: String? = null): PendingIntent = PendingIntent.getActivity(
        ctx, code, appIntent(ctx, action), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun act(ctx: Context, code: Int, action: String, minutes: Int = 0): PendingIntent = PendingIntent.getBroadcast(
        ctx, code,
        Intent(ctx, ActionReceiver::class.java).setAction(action).also { if (minutes > 0) it.putExtra(ActionReceiver.EXTRA_MINUTES, minutes) },
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun button(ctx: Context, text: String, pi: PendingIntent): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(ctx, R.drawable.ic_stat_dns), text, pi).build()

    private fun channel(s: AppSettings) = if (s.quietNotification) QUIET_CHANNEL_ID else CHANNEL_ID

    /** Kilit ekranında gösterilecek genel sürüm (sunucu adı yok). */
    private fun lockVersion(ctx: Context, s: AppSettings, text: String): Notification =
        Notification.Builder(ctx, channel(s))
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.APP)
            .setContentText(text)
            .build()

    private fun privacy(ctx: Context, b: Notification.Builder, s: AppSettings, lockText: String) {
        if (s.hideOnLockscreen) {
            b.setVisibility(Notification.VISIBILITY_PRIVATE)
            b.setPublicVersion(lockVersion(ctx, s, lockText))
        }
    }

    /**
     * Durum bildirimi. [text] ikinci satırdır (ör. "Cloudflare · DoT · 1,2 bin sorgu · 34 engellendi"). [sinceMs] > 0 ise
     * sistem bildirimde bağlantı süresini kendisi sayar. [connected] ise "Kes", "15 dk duraklat" ve (favori/son kullanılan
     * varsa) "Sonraki" eklenir.
     */
    fun build(ctx: Context, s: AppSettings, text: String, connected: Boolean, sinceMs: Long = 0L, canNext: Boolean = false): Notification {
        val b = Notification.Builder(ctx, channel(s))
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.APP)
            .setContentText(text)
            .setContentIntent(openApp(ctx))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
        if (sinceMs > 0L) b.setWhen(sinceMs).setShowWhen(true).setUsesChronometer(true) else b.setShowWhen(false)
        if (connected) {
            b.addAction(button(ctx, Strings.NOTIF_STOP, act(ctx, 1, ActionReceiver.ACTION_STOP)))
            if (canNext) b.addAction(button(ctx, Strings.NOTIF_NEXT, act(ctx, 3, ActionReceiver.ACTION_NEXT)))
            b.addAction(button(ctx, Strings.pauseAction(PAUSE_MIN), act(ctx, 5, ActionReceiver.ACTION_PAUSE, PAUSE_MIN)))
        }
        privacy(ctx, b, s, if (connected) Strings.NOTIF_LOCKED else Strings.NOTIF_CONNECTING)
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }

    /** Duraklatılmışken gösterilen bildirim: bitiş saati, geri sayım, "Devam et" ve "Kes". */
    fun paused(ctx: Context, s: AppSettings, untilMs: Long, untilText: String): Notification {
        val b = Notification.Builder(ctx, channel(s))
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.APP)
            .setContentText(Strings.notifPaused(untilText))
            .setContentIntent(openApp(ctx))
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setWhen(untilMs).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true)
            .setCategory(Notification.CATEGORY_STATUS)
            .addAction(button(ctx, Strings.RESUME, act(ctx, 4, ActionReceiver.ACTION_RESUME)))
            .addAction(button(ctx, Strings.NOTIF_STOP, act(ctx, 1, ActionReceiver.ACTION_STOP)))
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }

    /** Beklenmedik kopma uyarısı. "Yeniden bağlan" uygulamayı açar (VPN izni geri alınmışsa orada yeniden istenir). */
    fun drop(ctx: Context, reason: String) {
        val n = Notification.Builder(ctx, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.NOTIF_DROP_TITLE)
            .setContentText(reason)
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_ERROR)
            .addAction(button(ctx, Strings.NOTIF_RECONNECT, openApp(ctx, 6, DnsVpnService.ACTION_CONNECT)))
            .build()
        notify(ctx, ALERT_ID, n)
    }

    /** Otomatik şifrelemede şifreli yöntem kurulamadı, şifresiz DNS kullanılıyor. */
    fun downgrade(ctx: Context, name: String) {
        val n = Notification.Builder(ctx, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.NOTIF_DOWNGRADE_TITLE)
            .setContentText(Strings.notifDowngrade(name))
            .setStyle(Notification.BigTextStyle().bigText(Strings.notifDowngrade(name)))
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_STATUS)
            .build()
        notify(ctx, DOWNGRADE_ID, n)
    }

    /** Bir işlem için VPN izni gerekiyor ama arka planda istenemez: uygulamayı açmaya davet eden bildirim. */
    fun needApp(ctx: Context) {
        val n = Notification.Builder(ctx, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.APP)
            .setContentText(Strings.ERR_PERMISSION)
            .setContentIntent(openApp(ctx, 8, DnsVpnService.ACTION_CONNECT))
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_ERROR)
            .build()
        notify(ctx, NEED_APP_ID, n)
    }

    fun update(ctx: Context, n: Notification) = notify(ctx, NOTIF_ID, n)

    private fun notify(ctx: Context, id: Int, n: Notification) {
        try {
            ctx.getSystemService(NotificationManager::class.java)?.notify(id, n)
        } catch (_: Exception) {
            // bildirim izni yoksa sessizce geçilir; servis yine çalışır
        }
    }

    fun cancel(ctx: Context) = cancelId(ctx, NOTIF_ID)
    fun cancelAlert(ctx: Context) = cancelId(ctx, ALERT_ID)
    fun cancelDowngrade(ctx: Context) = cancelId(ctx, DOWNGRADE_ID)

    private fun cancelId(ctx: Context, id: Int) {
        try { ctx.getSystemService(NotificationManager::class.java)?.cancel(id) } catch (_: Exception) {}
    }

    /** Bildirimdeki duraklatma düğmesinin süresi (dakika). */
    const val PAUSE_MIN = 15
}
