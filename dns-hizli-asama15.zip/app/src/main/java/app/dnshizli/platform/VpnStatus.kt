package app.dnshizli.platform

import android.os.Handler
import android.os.Looper
import app.dnshizli.core.SelfTestResult
import app.dnshizli.ui.VpnUi
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Servis ile arayüzü (etkinlik, hızlı ayar kutucuğu) birbirine bağlayan, süreç içi tek durum noktası.
 *  - Servis durum değişince [publish] eder; dinleyiciler ana iş parçacığında çağrılır.
 *  - Arayüz canlı sayaçları (sorgu sayısı vb.) istediği zaman [snapshot] ile çeker; servis kendi başına
 *    periyodik uyanmaz, böylece boştayken sıfır kaynak harcar.
 */
object VpnStatus {
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<(VpnUi) -> Unit>()

    @Volatile private var last = VpnUi()

    /** Servis çalışırken canlı durumu üreten işlev; yoksa null. */
    @Volatile var live: (() -> VpnUi)? = null

    fun snapshot(): VpnUi = live?.invoke() ?: last

    fun publish(v: VpnUi) {
        last = v
        main.post { for (l in listeners) l(v) }
    }

    fun addListener(l: (VpnUi) -> Unit) { if (!listeners.contains(l)) listeners.add(l) }
    fun removeListener(l: (VpnUi) -> Unit) { listeners.remove(l) }

    // ---- bağlantı testi sonuçları (servis üretir, etkinlik gösterir)
    private val testListeners = CopyOnWriteArrayList<(SelfTestResult) -> Unit>()

    fun publishTest(r: SelfTestResult) { main.post { for (l in testListeners) l(r) } }
    fun addTestListener(l: (SelfTestResult) -> Unit) { if (!testListeners.contains(l)) testListeners.add(l) }
    fun removeTestListener(l: (SelfTestResult) -> Unit) { testListeners.remove(l) }
}
