package app.dnshizli.selftest

import kotlin.system.exitProcess

/**
 * Tüm JVM testlerinin giriş noktası (Android gerekmez).
 *   hepsi:            java -cp ... app.dnshizli.selftest.AllTests
 *   seçilenler:       ... AllTests core secure privacy filter harden gfx model ui monkey
 *   bellek raporu:    ... AllTests alloc
 */
object AllTests {
    @JvmStatic
    fun main(args: Array<String>) {
        val which = args.toSet()
        fun want(n: String) = which.isEmpty() || n in which

        val t0 = System.nanoTime()
        if (want("core")) runCoreTests()
        if (want("secure")) runSecureTests()
        if (want("tcp")) { println("\nTCP katmanı testleri\n"); runTcpTests() }
        if (want("privacy")) runPrivacyTests()
        if (want("filter")) runFilterTests()
        if (want("harden")) { runHardeningTests(); runHealthTests(); runManifestTests() }
        if (want("stage22")) runStage22Tests()
        if (want("gateway")) { println("\nAğ geçidi testleri\n"); runGatewayTests() }
        if (want("wrap")) runWrapGuardTests()
        if (want("stage24")) { println("\nAşama 24 testleri\n"); runStage24Tests() }
        if (want("modules")) { println("\nModül testleri\n"); runModuleTests() }
        if (want("gfx")) { println("\nÇizim ve geometri testleri\n"); runGfxTests() }
        if (want("model")) { println("\nModel testleri\n"); runModelTests() }
        if (want("ui")) { println("\nArayüz testleri\n"); runUiTests(); runListTests() }
        if (want("device")) { println("\nCihaz benzetimi testleri\n"); runDeviceTests(); runControlAudit() }
        if (want("monkey")) { println("\nRastgele kullanım (maymun) testleri\n"); runMonkeyTests() }
        if ("alloc" in which) { println("\nKare başına bellek ayırma\n"); allocReport() }
        T.flush()
        val sec = (System.nanoTime() - t0) / 1_000_000_000.0
        println("\n${T.total} kontrol, ${T.failures} başarısız  (%.1f sn)".format(sec))
        exitProcess(if (T.failures > 0) 1 else 0)
    }
}
