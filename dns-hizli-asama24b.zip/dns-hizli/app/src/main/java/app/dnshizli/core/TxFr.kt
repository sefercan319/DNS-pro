package app.dnshizli.core

/** Français. */
object TxFr : Tx() {
    override val lang = Lang.FR

    override val decimalSep = ','
    override val thousand = " k"
    override val million = " M"
    override fun percent(n: Int) = "$n %"
    override val dayU = "j"
    override val hourU = "h"
    override val minU = "min"
    override val secU = "s"
    override val justNow = "à l'instant"
    override fun ago(span: String) = "il y a $span"

    override val OFF = "Non connecté"
    override val CONNECTING = "Connexion…"
    override val ON = "Connecté"
    override val ERROR = "Connexion impossible"
    override val PAUSED = "En pause"
    override val HINT_OFF = "Touchez la sphère pour vous connecter"
    override val HINT_CONNECTING = "Cela peut prendre quelques secondes"
    override val HINT_ERROR = "Touchez pour réessayer"
    override val HINT_PAUSED = "Touchez pour reprendre maintenant"
    override val ERR_DEFAULT = "La connexion a échoué"
    override fun selected(name: String) = "$name sélectionné"
    override fun pausedUntil(time: String) = "Reprise à $time"
    override fun blockedShort(n: String) = "$n bloquées"
    override fun queriesShort(n: String) = "$n requêtes"
    override fun cacheShort(pct: String) = "$pct en cache"

    override val SERVERS = "Serveurs"
    override val FILTER_ALL = "Tous"
    override val FILTER_FAV = "Favoris"
    override val FILTER_RECENT = "Récents"
    override val EMPTY_FAV = "Pas encore de favoris. Touchez l'étoile d'un serveur."
    override val EMPTY_RECENT = "Vous ne vous êtes encore connecté à aucun serveur."
    override val EMPTY_FILTER = "Aucun serveur dans cette catégorie."
    override val MEASURE = "Mesurer les vitesses"
    override val MEASURING = "Mesure…"
    override val SORT = "Trier par vitesse"
    override val PULL_TO_MEASURE = "Tirez pour mesurer"
    override val RELEASE_TO_MEASURE = "Relâchez pour mesurer"
    override fun serversCount(n: Int) = if (n == 1) "1 serveur" else "$n serveurs"
    override fun showAllServers(n: Int) = "Tout afficher ($n)"
    override val SHOW_LESS = "Afficher moins"
    override val TAG_FAST = "Rapide"
    override val TAG_PRIVACY = "Vie privée"
    override val TAG_ADS = "Pubs"
    override val TAG_FAMILY = "Famille"
    override val TAG_SECURITY = "Sécurité"
    override val VAR_OPEN = "Sans filtre"
    override val VAR_ADS = "Anti-pub"
    override val VAR_SECURITY = "Sécurité"
    override val VAR_FAMILY = "Famille"
    override val A11Y_CONNECTED = "connecté"
    override val A11Y_ENCRYPTED = "chiffré"
    override fun favA11y(name: String) = "$name favori"

    override val COPIED = "Copié dans le presse-papiers"
    override val DISCONNECTED = "Déconnecté"
    override val BACKUP = "Passage au serveur de secours"
    override val NO_REPLY = "Aucun serveur n'a répondu"
    override val MEASURE_FIRST = "Mesurez d'abord les vitesses"
    override val CONNECT = "Connecter"
    override val UNDO = "Annuler"
    override fun fastest(name: String, ms: Int) = "Le plus rapide : $name · $ms ms"
    override fun switched(name: String) = "Passage à $name"
    override fun hiddenToast(name: String) = "$name masqué"

    override val PRIMARY = "Principal"
    override val SECONDARY = "Secondaire"
    override val COPY = "Copier"
    override fun addressA11y(label: String, ip: String) = "Adresse $label : $ip"
    override val CONNECT_TO_THIS = "Se connecter à ce serveur"
    override val SWITCH_TO_THIS = "Passer à ce serveur"
    override val CONNECTED_NOW = "Connecté maintenant"
    override val ADD_FAV = "Ajouter aux favoris"
    override val REMOVE_FAV = "Retirer des favoris"
    override val MEASURE_THIS = "Mesurer la vitesse"
    override val HIDE = "Masquer de la liste"
    override val UNHIDE = "Afficher dans la liste"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Dernière mesure : pas de réponse · $ago" else "Dernière mesure : $ms ms · $ago"
    override val NEVER_MEASURED = "Pas encore mesuré"
    override val ENC_SUPPORT = "DNS chiffré"
    override val ENC_NONE = "Non pris en charge"
    override val ENC_ONLY = "N'accepte que les connexions chiffrées"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Meilleur $best ms · médiane $median ms · perte $lossPct %"
    override val HISTORY = "Historique des mesures"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY : $n mesures, pas de réponse" else "$HISTORY : $n mesures, médiane $median ms"

    override val QUICK_TITLE = "Choix rapide"
    override val QUICK_FAVORITES = "Favoris"
    override val QUICK_RECENT = "Utilisés récemment"
    override val PAUSE_FOR = "Mettre en pause"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} h" else "$n min"
    override val RESUME = "Reprendre"

    override val SETTINGS = "Réglages"
    override val MENU = "Menu"
    override val PERSONALIZE = "Personnaliser"
    override val PZ_BACKGROUND = "Arrière-plan"
    override val PZ_AUTO = "Thème automatique"
    override val PZ_FEEL = "Verre, texte et mouvement"
    override val PZ_ACCESS = "Accessibilité et énergie"
    override val DNS_SETTINGS = "Réglages DNS"
    override val CONN_APPS = "Connexion et apps"
    override val STATS_HISTORY = "Statistiques et historique"
    override val SEC_LOOK = "Apparence"
    override val SEC_LIST = "Liste des serveurs"
    override val SEC_DATA = "Données"
    override val ABOUT = "À propos"
    override val LANGUAGE = "Langue"
    override val LANG_AUTO = "Automatique (langue du système)"
    override val THEME = "Thème"
    override val THEME_AUTO = "Automatique"
    override val THEME_AUTO_NOTE = "Automatique · suit le mode clair/sombre"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Prairie"
        "ocean" -> "Océan"
        "sunset" -> "Crépuscule"
        "lavender" -> "Lavande"
        "coral" -> "Corail"
        "mint" -> "Menthe"
        "night" -> "Nuit"
        "amoled" -> "Noir (AMOLED)"
        "sakura" -> "Sakura"
        "honey" -> "Honey"
        "aurora" -> "Aurora"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Thème : $name"
    override val THEME_SCHEDULE = "Thème nuit selon l'heure"
    override val THEME_SCHEDULE_NOTE = "En Automatique, Nuit de 22:00 à 07:00"
    override val GLASS = "Opacité du verre"
    override val BUBBLES = "Bulles"
    override val STYLE = "Style"
    override val STYLE_NOTES = listOf(
        "Verre, brillance et bulles : le design d'origine.",
        "Ciel, herbe verte, gouttes de verre et boutons gel.",
        "Ville, musique et jeunesse : gratte-ciel, enceinte, anneaux, étoiles et rayons.",
        "Nature et technologie : Terre verte, éoliennes, panneaux solaires et feuilles.",
        "Rose et violet holographiques, cœurs chromés, bulles, étincelles et fenêtres pixel.",
        "Lumière turquoise, verte et jaune, faisceau brillant et ondes en filet transparent.",
    )
    override val WALLPAPER = "Photo d'arrière-plan"
    override val WP_OFF = "Aucune"
    override val WP_ON = "Photo"
    override val WP_PICK = "Choisir une photo dans la galerie"
    override val WP_PICK_NOTE = "Reste sur votre téléphone, jamais envoyée. Le voile se renforce automatiquement si nécessaire pour garder le texte lisible."
    override val WP_PRESETS = "Images incluses"
    override val WP_PRESETS_NOTE = "8 images fournies avec l'appli. Sans internet."
    override val WP_REMOVE = "Retirer la photo"
    override val WP_DIM = "Intensité du voile"
    override val WP_BLUR = "Flou"
    override val OPT_WP_BLUR = listOf("Non", "Léger", "Fort")
    override val WP_SAVED = "Arrière-plan défini"
    override val WP_FAILED = "Impossible d'ouvrir la photo"
    override val WP_REMOVED = "Arrière-plan retiré"
    override val APP_ICON = "Icône de l'appli"
    override val ICON_NOTES = listOf(
        "Globe de verre : l'icône d'origine.",
        "Une goutte de verre sur ciel et herbe.",
        "Ville lime-turquoise, rayons de soleil et bouton marche.",
        "Terre verte brillante avec une feuille qui pousse.",
        "Un cœur chromé brillant sur rose et violet holographiques.",
        "Globe de verre sur lueur turquoise-jaune et ondes de lumière.",
    )
    override val ICON_SET = "L'icône change à la sortie"
    override val ICON_NOTE = "Si le raccourci de l'écran d'accueil disparaît, ajoute à nouveau l'appli."
    override val ICON_FAILED = "Impossible de changer l'icône"
    override val HELP_WHY_TITLE = "Pourquoi cette appli ?"
    override val HELP_WHY_BODY = "DNS Hızlı est petite et simple, faite par une seule personne, sans grande entreprise derrière. Pas de compte ni de publicité : tu choisis ton DNS, le chiffrement, les applis concernées et l'apparence."
    override val HELP_WHY_TAIL = "Elle n'est peut-être pas meilleure que la concurrence, mais elle fonctionne et mérite d'être essayée."
    override val TROUBLE = "Dépannage"
    override val TROUBLE_RECHECK = "Revérifier"
    override val TROUBLE_ALL_OK = "Tout semble correct. Si la connexion échoue quand même, essaie un autre serveur."
    override val TROUBLE_SOME = "Points à vérifier :"
    override val T_NET = "Internet"
    override val NET_OK = "connecté."
    override val NET_BAD = "absent ou limité. Vérifie le Wi-Fi ou les données mobiles."
    override val T_PERM = "Autorisation VPN"
    override val PERM_OK = "accordée."
    override val PERM_BAD = "pas encore accordée. Android la demandera à la connexion ; accepte."
    override val T_VPN = "Autre VPN"
    override val VPN_OK = "aucun."
    override val VPN_BAD = "semble actif. Android n'autorise qu'un VPN à la fois ; désactive-le."
    override val T_DNS = "DNS privé d'Android"
    override val PDNS_OK = "désactivé ou automatique, aucun souci."
    override val PDNS_BAD = "est fixé sur un serveur et peut contourner le DNS de cette appli. Dans Paramètres > Réseau > DNS privé, choisis Automatique ou Désactivé."
    override val SEARCH = "Rechercher"
    override val SEARCH_HINT = "Nom ou propriétaire du serveur"
    override val SEARCH_CLEAR = "Effacer"
    override val SHARE_RESULTS = "Partager les résultats des mesures"
    override val SHARE_RESULTS_HEAD = "Mesures DNS Hızlı (du plus rapide)"
    override val NO_RESULTS = "Fais d'abord une mesure"
    override val CUSTOM_EDIT = "Modifier"
    override fun customUpdated(name: String) = "$name mis à jour"
    override val KEEP_HISTORY = "Garder l'historique"
    override val KEEP_HISTORY_NOTE = "Désactivé : serveurs récents, historique et mesures ne sont pas enregistrés. L'existant est conservé."
    override val MOTION = "Animations"
    override val TEXT_SIZE = "Taille du texte"
    override val HIGH_CONTRAST = "Contraste élevé"
    override val HIGH_CONTRAST_NOTE = "Verre plus opaque et texte plus foncé"
    override val MINIMAL = "Vue épurée"
    override val MINIMAL_NOTE = "Masque les filtres et la ligne de statistiques"
    override val LOW_POWER = "Mode économie"
    override val LOW_POWER_NOTE = "Coupe toutes les animations, ménage la batterie"
    override val HAPTICS = "Vibration"
    override val HAPTICS_NOTE = "Léger retour au toucher"
    override val ENCRYPTION = "DNS chiffré"
    override val ENCRYPTION_NOTE = "Auto : d'abord DoT, puis DoH, enfin DNS non chiffré"
    override val AUTO_CONNECT = "Connexion à l'ouverture"
    override val AUTO_CONNECT_NOTE = "Se connecte au dernier serveur à l'ouverture de l'app"
    override val CONNECT_ON_BOOT = "Connexion au démarrage"
    override val CONNECT_ON_BOOT_NOTE = "Se connecte seul après un redémarrage du téléphone"
    override val AUTO_FASTEST = "Connexion au plus rapide"
    override val AUTO_FASTEST_NOTE = "La sphère choisit le serveur le plus rapide de la dernière mesure"
    override val REFRESH_ON_NET = "Actualiser au changement de réseau"
    override val REFRESH_ON_NET_NOTE = "Le DNS est actualisé lors du passage Wi-Fi / données mobiles"
    override val NOTIFY_DROP = "Prévenir en cas de coupure"
    override val NOTIFY_DROP_NOTE = "Notification avec bouton de reconnexion en cas de coupure"
    override val NOTIFY_CONNECT = "Prévenir à la connexion"
    override val NOTIFY_CONNECT_NOTE = "Une courte notification quand la connexion est établie"
    override val NOTIFY_STOP = "Prévenir à la déconnexion"
    override val NOTIFY_STOP_NOTE = "Une courte notification quand vous vous déconnectez"
    override val NOTIFY_TIMEOUT = "Prévenir en cas de délai dépassé"
    override val NOTIFY_TIMEOUT_NOTE = "Notification si le serveur DNS ne répond plus"
    override val NOTIF_PERM = "Autorisation de notifications"
    override val PERM_ALLOWED = "Autorisée"
    override val PERM_BLOCKED = "Non · corriger"
    override val NOTIF_CONNECTED_TITLE = "DNS connecté"
    override val NOTIF_STOPPED_TITLE = "DNS déconnecté"
    override val NOTIF_STOPPED_TEXT = "La protection est désactivée"
    override val NOTIF_TIMEOUT_TITLE = "Délai DNS dépassé"
    override val FAIL_CLOSED = "Bloquer le DNS si coupure"
    override val FAIL_CLOSED_NOTE = "Si la connexion tombe, les requêtes DNS ne fuient pas vers votre opérateur ; elles échouent jusqu'à la reconnexion"
    override val NOTIF_SEALED = "DNS bloqué pendant la reconnexion"
    override val ERR_SEALED = "Connexion impossible. Le DNS est bloqué pour éviter toute fuite. Touchez Arrêter pour le libérer."
    override val SEALED_INFO = "DNS bloqué jusqu'au retour de la connexion"
    override val LATENCY_TITLE = "Latence par requête"
    override val LATENCY_EMPTY = "S'affiche en direct une fois connecté et les requêtes reçues"
    override val FILTER_MINE = "Ma propre liste"
    override val MINE_PASTE = "Importer du presse-papiers"
    override val MINE_PASTE_NOTE = "Fichier hosts ou un domaine par ligne"
    override val MINE_FILE = "Importer depuis un fichier"
    override val MINE_FILE_NOTE = "Un fichier .txt ou hosts du téléphone"
    override val MINE_EXPORT = "Copier ma liste de blocage"
    override val MINE_EXPORT_NOTE = "Dans le presse-papiers, au format hosts"
    override val MINE_CLEAR = "Supprimer la liste importée"
    override val MINE_FOOT = "Lit les lignes hosts (0.0.0.0 domaine), les listes de domaines simples et les règles ||domaine^. 50 000 noms au plus. Votre liste d'autorisation prime toujours."
    override val MINE_NOTHING = "Aucun domaine valide trouvé"
    override val MINE_CLIP_EMPTY = "Le presse-papiers est vide"
    override val MINE_FILE_ERR = "Fichier illisible"
    override val MINE_CLEARED = "Liste importée supprimée"
    override val MINE_CLEAR_ASK = "Supprimer la liste importée ?"
    override val MINE_CUT = "Limite atteinte, le reste a été ignoré"
    override fun notifTimeout(name: String) = "$name ne répond pas. Nouvel essai."
    override val MOD_DPI = "Contourner DPI"
    override val MOD_ADS = "Pubs+"
    override val MOD_DPI_SUB = "Ouvre les sites bloqués"
    override val MOD_ADS_SUB = "Bloque au-delà du DNS"
    override val MOD_ON = "Activé"
    override val MOD_OFF = "Désactivé"
    override val BLOCK_QUIC = "Bloquer QUIC"
    override val BLOCK_QUIC_NOTE = "Les applis reviennent à TCP, donc Contourner DPI et Pubs+ les couvrent aussi"
    override val GW_TRIPPED = "Problème de connexion détecté : Contourner DPI et Pubs+ ont été désactivés"
    override val MOD_FAILED = "Activation impossible. Autorisation VPN refusée ou un autre VPN est actif."
    override fun gwOn(modules: String) = "Passerelle active : $modules"
    override fun gwOnStats(modules: String, blocked: String) = "Passerelle active : $modules · $blocked bloqués"
    override fun modOn(name: String) = "$name activé"
    override fun modOff(name: String) = "$name désactivé"
    override fun modAdsCount(n: String) = "$n bloqués"
    override fun modDpiCount(n: String) = "$n connexions fractionnées"
    override fun latencyLine(avg: String, max: String, timeouts: Int) = "moy. $avg · max. $max" + (if (timeouts > 0) " · $timeouts délais dépassés" else "")
    override fun mineCount(n: Int) = "$n domaines"
    override fun mineAdded(n: Int) = "$n domaines ajoutés"
    override fun mineCopied(n: Int) = "$n domaines copiés"
    override val CACHE = "Cache DNS"
    override val CLEAR_CACHE = "Vider le cache"
    override val CACHE_CLEARED = "Cache vidé"
    override val ONLY_CONNECTED = "Disponible une fois connecté"
    override val RULE_WIFI = "Serveur Wi-Fi"
    override val RULE_MOBILE = "Serveur données mobiles"
    override val RULE_AUTO = "Automatique"
    override val RULE_AUTO_NOTE = "Le dernier serveur utilisé"
    override val COMPACT = "Liste compacte"
    override val COMPACT_NOTE = "Lignes plus courtes, sans description"
    override val HIDDEN = "Serveurs masqués"
    override val HIDDEN_NONE = "Aucun"
    override val STAT_QUERIES = "Requêtes au total"
    override val STAT_HITS = "Servies par le cache"
    override val STAT_BLOCKED = "Bloquées (estimation)"
    override val STAT_TIME = "Temps connecté au total"
    override val WEEK = "7 derniers jours"
    override fun weekA11y(total: String) = "$total requêtes sur les 7 derniers jours"
    override val WEEKDAYS = listOf("Lu", "Ma", "Me", "Je", "Ve", "Sa", "Di")
    override val EXPORT = "Exporter les réglages"
    override val IMPORT = "Importer les réglages"
    override val EXPORTED = "Code des réglages copié"
    override val IMPORTED = "Réglages chargés"
    override val IMPORT_BAD = "Aucun code de réglages valide dans le presse-papiers"
    override val RESET_SETTINGS = "Réinitialiser les réglages"
    override val RESET_STATS = "Réinitialiser les statistiques"
    override val CONFIRM = "Vous êtes sûr ?"
    override val RESET = "Réinitialiser"
    override val RESET_DONE = "Réinitialisé"
    override val LOG = "Journal de diagnostic"
    override val HELP = "Comment ça marche ?"
    override val VPN_SETTINGS = "Réglages VPN du système"
    override val SHARE_APP = "Partager l'app"
    override val RATE_APP = "Noter l'app"
    override val FEEDBACK = "Envoyer un avis"
    override fun shareAppText(url: String) = "$APP vous connecte d'un geste aux DNS populaires : $url"
    override val VERSION = "Version"
    override val OPT_BUBBLES = listOf("Non", "Peu", "Beaucoup")
    override val OPT_MOTION = listOf("Toutes", "Réduites", "Non")
    override val OPT_CACHE = listOf("Non", "Petit", "Normal", "Grand")
    override val OPT_ENCRYPTION = listOf("Auto", "DoT", "DoH", "Non")
    override val PLAIN_DNS = "DNS non chiffré"

    override val LOG_NOTE = "Seuls les événements de connexion sont conservés. Jamais les noms de requêtes ni de données personnelles."
    override val LOG_EMPTY = "Aucune entrée pour l'instant."
    override val SHARE = "Partager"
    override val CLEAR = "Effacer"
    override val CLEARED = "Effacé"
    override val HELP_SECTIONS = listOf(
        "Qu'est-ce que le DNS ?" to
            "Le DNS est le service qui traduit les adresses internet (comme example.com) en numéros compris par les appareils. " +
            "Le DNS utilisé peut influencer la vitesse, la confidentialité et les contenus bloqués.",
        "Que fait l'app ?" to
            "Elle utilise le serveur DNS choisi dans toutes les apps. Pour cela, elle ouvre une interface VPN locale sur votre téléphone, " +
            "mais votre trafic ne passe par aucun serveur VPN. Seules les requêtes DNS sont envoyées au serveur choisi ; " +
            "tout le reste suit son chemin habituel.",
        "DNS chiffré (DoT / DoH)" to
            "Avec les serveurs compatibles, les requêtes sont chiffrées : personne sur le réseau (propriétaire du Wi-Fi, opérateur) " +
            "ne voit les sites visités ni ne peut modifier les réponses. En Automatique, DoT est essayé d'abord, puis DoH ; " +
            "si aucun ne fonctionne, le DNS non chiffré est utilisé. Vous en êtes averti, et l'app tente de revenir au chiffrement " +
            "à chaque changement de réseau et toutes les 10 minutes. Avec \"Chiffrement strict\", le DNS non chiffré n'est jamais utilisé. " +
            "L'écran d'accueil indique la méthode utilisée.",
        "Test de connexion" to
            "☰ > Réglages DNS > Test de connexion envoie de vraies requêtes DNS à travers le tunnel. Il montre que " +
            "le DNS répond bien depuis le serveur choisi, à quelle vitesse, si le serveur valide les signatures DNSSEC " +
            "et s'il bloque un domaine publicitaire connu.",
        "Confidentialité" to
            "Pas de compte, pas de collecte de données, pas de publicité. L'app n'enregistre pas les noms de requêtes et n'envoie rien d'elle-même. " +
            "Vos requêtes vont uniquement au fournisseur DNS choisi, selon sa propre politique de confidentialité. " +
            "Le DNS chiffré (DoT/DoH) empêche quiconque sur le réseau de lire ou de modifier vos requêtes. Avant l'envoi, l'app retire les données annexes qui pourraient identifier votre appareil (sous-réseau client, cookies, identifiants), complète les messages pour masquer leur longueur et oublie les tickets de session TLS quand le réseau change. " +
            "Soyons honnêtes : sans relais, le fournisseur DNS voit toujours votre adresse IP publique (il doit bien vous répondre), et une erreur de certificat peut signifier que quelqu'un interfère avec la connexion. " +
            "Le journal de diagnostic ne contient que des événements de connexion.",
        "Batterie et ressources" to
            "Elle consomme très peu en arrière-plan. Aucune boucle ne tourne écran éteint ; " +
            "elle ne travaille que lorsqu'une requête DNS arrive. Les connexions chiffrées se ferment seules quand elles sont inactives.",
        "Bon à savoir" to
            "Android n'autorise qu'un seul VPN à la fois ; si une autre app VPN est active, celle-ci ne peut pas se connecter. " +
            "Le réglage \"DNS sécurisé\" de certains navigateurs et le \"DNS privé\" d'Android fixé sur un nom utilisent leur propre serveur " +
            "et peuvent contourner cette redirection ; il suffit de les laisser sur \"Automatique\" ou \"Désactivé\". " +
            "Appui long sur la sphère : changer vite de serveur ou mettre la connexion en pause.",
    )

    override val NOTIF_CHANNEL = "État de la connexion"
    override val NOTIF_CHANNEL_NOTE = "Affichée tant que la connexion DNS est active"
    override val NOTIF_ALERT_CHANNEL = "Alertes de connexion"
    override val NOTIF_CONNECTING = "Connexion…"
    override val NOTIF_STOP = "Déconnecter"
    override val NOTIF_NEXT = "Suivant"
    override val NOTIF_DROP_TITLE = "Connexion DNS perdue"
    override val NOTIF_RECONNECT = "Reconnecter"
    override fun notifOn(name: String, proto: String) = "Connecté à $name · $proto"
    override fun notifPaused(time: String) = "En pause · reprise à $time"
    override val TILE_ON = "Connecté"
    override val TILE_OFF = "Désactivé"
    override val WIDGET_TAP = "Touchez : connecter / déconnecter"
    override val ERR_PERMISSION = "L'autorisation VPN n'a pas été accordée"
    override val ERR_ESTABLISH = "Impossible d'ouvrir l'interface VPN. Un autre VPN est peut-être actif."
    override fun errNoReply(name: String) = "$name n'a pas répondu"
    override val PHONE_BYPASS = "Ce DNS n'est pas utilisé (DNS privé ?)"
    override fun errNoProto(name: String, proto: String) = "$name ne prend pas en charge $proto"
    override val ERR_SOCKET = "Réseau inaccessible"
    override fun errPrivateDns(host: String) = "Le DNS privé d'Android est fixé sur $host et contourne l'app. Réglez Paramètres > Réseau > DNS privé sur Automatique ou Désactivé."
    override val ERR_REVOKED = "Le système a fermé la connexion"
    override val ERR_TUNNEL = "Le tunnel s'est fermé de façon inattendue"
    override val ERR_UNKNOWN = "Une erreur inattendue s'est produite"

    override val CONSENT_TITLE = "Avant de vous connecter"
    override val CONSENT_BODY = listOf(
        "$APP utilise l'interface VPN d'Android pour diriger vos requêtes DNS (les noms des sites visités) vers le serveur DNS choisi.",
        "Votre trafic n'est envoyé à aucun serveur VPN ; seules les requêtes DNS vont au fournisseur choisi. Avec les serveurs compatibles, " +
            "elles sont chiffrées (DoT/DoH) ; sinon elles circulent en clair. La politique de confidentialité du fournisseur s'applique." +
            " Si tu actives « $MOD_DPI » ou « $MOD_ADS », tout le trafic passe par un relais qui fonctionne uniquement dans ton téléphone ; il n’est toujours envoyé nulle part ailleurs.",
        "L'app ne collecte aucune donnée personnelle, n'enregistre pas les noms de requêtes et ne partage rien.",
        "Si vous continuez, Android affichera une demande de connexion VPN ; touchez \"OK\".",
    )
    override val CONSENT_OK = "Compris, continuer"
    override val CLOSE = "Fermer"
    override val BACK = "Retour"

    // ---- 3. sürüm ----
    override val RESUMING = "Reprise…"
    override val DOWNGRADED = "Chiffrement impossible, DNS non chiffré"
    override val UPGRADED = "DNS chiffré rétabli"
    override val NOTIF_DOWNGRADE_TITLE = "Le DNS n'est pas chiffré"
    override fun notifDowngrade(name: String) = "Impossible d'établir une connexion chiffrée avec $name. Le DNS non chiffré est utilisé ; l'app tentera de revenir au chiffrement."
    override fun backupUsed(failed: String, used: String) = "$failed n'a pas répondu, connecté à $used"
    override val NOTIF_RETRYING = "Connexion perdue, nouvel essai…"
    override fun errNoEncrypted(name: String) = "Impossible d'établir une connexion chiffrée avec $name"
    override fun errUntrusted(name: String) = "Certificat de $name non vérifié ; le réseau ou un logiciel interfère peut-être avec les connexions chiffrées"
    override val APPLYING = "Application du nouveau réglage à la connexion"
    override val CONFIRM_DISCONNECT = "Se déconnecter ?"
    override val DISCONNECT = "Déconnecter"

    override val SEC_NOTIF = "Notifications"
    override val STRICT_ENC = "Chiffrement strict"
    override val STRICT_ENC_NOTE = "Ne jamais revenir au DNS non chiffré"
    override val IP_MODE = "Version d'IP"
    override val IP_MODE_NOTE = "Celle de votre réseau est essayée en premier, l'autre sert de secours"
    override val OPT_IP_MODE = listOf("IPv4 + IPv6", "IPv4 seul")
    override val FILTER = "Blocage"
    override val FILTER_LEVEL = "Blocage des pubs et traqueurs"
    override val OPT_FILTER = listOf(
        "Non",
        "Basique",
        "Moyen",
        "Strict",
    )
    override val FILTER_NOTES = listOf(
        "Rien n'est bloqué.",
        "Sites de pub, d'hameçonnage et de logiciels malveillants connus. Très peu de risques de casse.",
        "Basique plus davantage de traqueurs et d'analyses. Certains sites peuvent poser problème.",
        "La liste la plus large, aussi fraude, abus et redirections. Casse fréquente.",
    )
    override val FILTER_INFO = "Le blocage se fait entièrement sur votre téléphone : si un site de la liste est demandé, la réponse est 0.0.0.0, la requête ne part vers aucun serveur et aucun nom n'est enregistré. Actif seulement en connexion. Le DNS sécurisé propre à un navigateur peut le contourner. Si un site ne marche plus, autorisez-le dans Bloqués récemment."
    override val FILTER_LAST = "Bloqués récemment"
    override val FILTER_RECENT_NOTE = "Toucher : autoriser"
    override val FILTER_RECENT_EMPTY = "Rien de bloqué dans cette session. Les noms apparaissent ici en connexion avec un niveau actif."
    override val FILTER_RECENT_FOOT = "Gardé en mémoire pour cette session seulement ; jamais enregistré, effacé à la déconnexion."
    override val FILTER_ALLOW = "Autorisés"
    override val FILTER_BLOCK = "Ma liste de blocage"
    override val FILTER_ADD = "Ajouter…"
    override val FILTER_REMOVE = "Toucher : retirer"
    override val FILTER_ALLOW_ADD = "Domaine à autoriser"
    override val FILTER_BLOCK_ADD = "Domaine à bloquer"
    override val FILTER_ERR = "Saisissez un domaine valide, ex. exemple.fr"
    override val FILTER_ERR_LIMIT = "200 domaines au maximum"
    override val FILTER_ALLOW_EMPTY = "Aucun domaine autorisé. Si un site ne marche plus, ajoutez-le ici."
    override val FILTER_BLOCK_EMPTY = "Votre liste de blocage est vide."
    override val FILTER_ALLOW_FOOT = "Le domaine et tous ses sous-domaines ne sont jamais bloqués. L'autorisation l'emporte sur toutes les listes."
    override val FILTER_BLOCK_FOOT = "Le domaine et tous ses sous-domaines sont toujours bloqués (même niveau désactivé)."
    override val FILTER_REMOVE_BTN = "Retirer"
    override fun filterAllowed(name: String) = "$name autorisé"
    override fun filterBlocked(name: String) = "$name sera bloqué"
    override fun filterRemoved(name: String) = "$name retiré"
    override fun filterRemoveAsk(name: String) = "Retirer $name de la liste ?"
    override val TEST_IPV6 = "Chemin IPv6"
    override val AUTO_RECONNECT = "Reconnexion automatique"
    override val AUTO_RECONNECT_NOTE = "En cas de coupure, nouvel essai après 5 s, 30 s et 2 min"
    override val BACKUP_SERVER = "Serveur de secours"
    override val BACKUP_OFF = "Désactivé"
    override val BACKUP_OFF_NOTE = "Pas de connexion si le serveur choisi ne répond pas"
    override val BACKUP_FASTEST = "Le plus rapide"
    override val BACKUP_FASTEST_NOTE = "L'autre serveur le plus rapide de la dernière mesure"
    override val CONFIRM_OFF = "Confirmer la déconnexion"
    override val CONFIRM_OFF_NOTE = "Un appui accidentel sur la sphère ne déconnecte pas"
    override val LOCK_HIDE = "Masquer sur écran verrouillé"
    override val LOCK_HIDE_NOTE = "Nom du serveur absent de la notification sur l'écran verrouillé"
    override val QUIET_NOTIF = "Notification discrète"
    override val QUIET_NOTIF_NOTE = "Sans icône dans la barre d'état, silencieuse"
    override val REMEMBER_FILTER = "Mémoriser le dernier filtre"
    override val REMEMBER_FILTER_NOTE = "Le dernier filtre choisi revient à l'ouverture de l'app"
    override val AUTO_MEASURE = "Mesurer au démarrage"
    override val AUTO_MEASURE_NOTE = "Mesure automatiquement si la dernière mesure date de plus d'un jour"
    override val MEASURE_ENC = "Mesure chiffrée"
    override val MEASURE_ENC_NOTE = "Mesure la vitesse via DoT, plus proche d'un usage chiffré réel"
    override val OPT_SORT = listOf("Par défaut", "Vitesse", "Nom")
    override fun sortA11y(mode: String) = "Tri : $mode"
    override val AUTO_LIGHT = "Automatique : thème clair"
    override val AUTO_DARK = "Automatique : thème sombre"
    override val NIGHT_HOURS = "Heures de nuit"
    override val FILTER_ENCRYPTED = "Chiffrés"
    override val FILTER_UNFILTERED = "Sans filtre"

    override val TEST = "Tester la connexion"
    override val TEST_NOTE = "DNS, DNSSEC et blocage des pubs"
    override val TESTING = "Test en cours…"
    override val TEST_TITLE = "Test de connexion"
    override val TEST_OK = "Le DNS fonctionne"
    override val TEST_FAIL = "Pas de réponse"
    override val TEST_SERVER = "Serveur"
    override val TEST_METHOD = "Méthode"
    override val TEST_LATENCY = "Temps de réponse"
    override val TEST_DNSSEC = "Validation DNSSEC"
    override val TEST_ADS = "Blocage des pubs"
    override val DNSSEC_YES = "Active"
    override val DNSSEC_NO = "Inactive"
    override val ADS_YES = "Actif"
    override val ADS_NO = "Inactif"
    override val UNKNOWN = "Inconnu"
    override val TEST_EXPLAIN = "Les requêtes sont passées par le tunnel, comme celles d'une app ; les réponses venaient du serveur choisi."
    override val TEST_AGAIN = "Tester à nouveau"

    override val RECOMMEND = "Trouver un serveur pour moi"
    override val RECOMMEND_NOTE = "Choisissez un objectif : connexion au serveur adapté le plus rapide"
    override val GOAL_SPEED = "Vitesse"
    override val GOAL_SPEED_NOTE = "Le serveur le plus rapide selon vos mesures"
    override val GOAL_PRIVACY_NOTE = "Sans journaux, axé sur la vie privée"
    override val GOAL_ADS_NOTE = "Bloque pubs et traqueurs"
    override val GOAL_FAMILY_NOTE = "Bloque les contenus pour adultes"
    override val GOAL_SECURITY_NOTE = "Bloque les sites malveillants et d'hameçonnage"
    override fun recommended(name: String) = "Recommandé : $name"

    override val PRIVATE_DNS = "Nom DNS privé"
    override val PRIVATE_DNS_NOTE = "Vous pouvez le coller dans le réglage \"DNS privé\" d'Android. Le système utilise alors ce serveur directement et cette app est contournée."
    override val CLEAR_HISTORY = "Effacer les mesures"
    override val HISTORY_CLEARED = "Mesures effacées"

    override val GUARD = "Protection permanente"
    override val GUARD_NOTE = "VPN permanent"
    override val GUARD_BODY = listOf(
        "Tant que l'app n'est pas connectée (désactivée, en pause ou après une coupure), vos requêtes DNS vont au serveur de votre fournisseur d'accès.",
        "Pour l'éviter, activez \"VPN permanent\" pour cette app dans les réglages VPN d'Android. Si \"Bloquer les connexions sans VPN\" est aussi activé, internet ne fonctionne plus du tout tant que l'app n'est pas connectée : rien ne fuit, mais une pause signifie aussi pas d'internet.",
        "Avec le VPN permanent, le système lance l'app automatiquement au démarrage du téléphone et après son arrêt.",
    )
    override val GUARD_BUTTON = "Ouvrir les réglages VPN"
    override val BATTERY = "Réglages de batterie"
    override val BATTERY_OK = "Non restreinte"
    override val BATTERY_LIMITED = "Peut être restreinte"
    override val BATTERY_BODY = listOf(
        "Android protège généralement les apps VPN. Certains fabricants (Xiaomi, Huawei, Oppo, Vivo, certaines versions de Samsung) peuvent toutefois fermer les apps en arrière-plan pour économiser la batterie.",
        "Si la connexion se coupe d'elle-même, réglez l'utilisation de la batterie de cette app sur \"Non restreinte\" ou \"Non optimisée\" ; sur certains téléphones, autorisez aussi le \"Démarrage automatique\".",
    )
    override val BATTERY_BUTTON = "Ouvrir les réglages batterie"

    override val STAT_AVG = "Temps de réponse moyen"
    override val STAT_SAVED = "Temps gagné grâce au cache"
    override val STAT_TRAFFIC = "Trafic DNS"
    override val SESSIONS = "Historique des connexions"
    override val SESSIONS_NOTE = "30 dernières connexions ; aucun nom de requête n'est enregistré"
    override val SESSIONS_EMPTY = "Aucune connexion enregistrée pour l'instant."
    override val MOST_USED = "Les plus utilisés"
    override val TODAY = "Aujourd'hui"
    override val YESTERDAY = "Hier"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Déconnecté par vous"
        EndReason.PAUSE -> "En pause"
        EndReason.SWITCH -> "Serveur changé"
        EndReason.DROP -> "Coupure"
        EndReason.REVOKED -> "Fermée par le système"
        EndReason.FAILED -> "Pas de réponse"
        EndReason.NETWORK -> "Réseau changé"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries requêtes"

    override val SOUND_MOTION = "Son et mouvement"
    override val SEC_SOUND = "Son"
    override val SOUND_ON = "Effets sonores"
    override val SOUND_ON_NOTE = "Sons courts et doux au toucher et à la connexion. Muets si le téléphone est en silencieux."
    override val SOUND_UI = "Sons au toucher"
    override val SOUND_UI_NOTE = "Boutons, interrupteurs et changements de page"
    override val SOUND_CONN = "Sons de connexion"
    override val SOUND_CONN_NOTE = "Sons distincts à la connexion, à la déconnexion et en cas d'erreur"
    override val SOUND_VOL = "Volume"
    override val SOUND_PACK = "Pack sonore"
    override val SOUND_TEST = "Tester le son de connexion"
    override val QUIET_HOURS = "Heures calmes"
    override val QUIET_NOTE = "Ni son ni vibration pendant ces heures"
    override val QUIET_RANGE = "Plage des heures calmes"
    override val SEC_MOTION_FX = "Mouvement et effets"
    override val ANIM_SPEED = "Vitesse d'animation"
    override val TAP_FX = "Effet au toucher"
    override val TAP_FX_NOTE = "Un petit effet propre au style là où tu touches"
    override val CELEBRATE = "Célébration à la connexion"
    override val CELEBRATE_NOTE = "Un spectacle propre au style autour de la sphère une fois connecté"
    override val HAPTIC_LEVEL = "Intensité des vibrations"
    override val REMEMBER_MODS = "Mémoriser les modules"
    override val REMEMBER_MODS_NOTE = "À la connexion, Contourner DPI et Pubs+ s'activent comme tu les as laissés"
    override val PROFILES = "Profils"
    override val COPY_STATUS = "Copier le résumé de l'état"
    override val OPT_PACK = listOf("Auto", "Doux", "Verre", "Rétro")
    override val SOUND_PACK_NOTE = "Auto : le son de ton style actuel"
    override val OPT_HAPTIC = listOf("Légère", "Normale", "Forte")
    override val PROFILE_NAMES = listOf("Vitesse", "Confidentialité", "Famille", "Protection totale")
    override val PROFILE_NOTES = listOf("Serveur le plus rapide, grand cache, aucun blocage", "Chiffrement strict, blocage des traceurs, Pubs+", "Serveur à filtre familial, blocage moyen", "Blocage des pubs et traceurs, Contourner DPI, Pubs+")
    override fun profileApplied(name: String) = "Profil appliqué : $name"

    override val WHATS_NEW = "Quoi de neuf ?"
    override val WHATS_NEW_TOAST = "L'app a été mise à jour"
    override val SHOW = "Afficher"
    override val WHATS_NEW_ITEMS = listOf(
        "Nouveau : effets sonores, moteur d'animation fluide réécrit, effets au toucher par style, profils, heures calmes et plus. ☰ > Son et mouvement.",
        "Nouveau : boutons Contourner DPI et Pubs+. Ils marchent avec le DNS ou seuls ; désactivés par défaut.",
        "Nouveau : importez votre liste de blocage, notifications de connexion, coupure et délai dépassé, graphique de latence, blocage du DNS si coupure.",
        "Nouveau : la liste affiche d'abord 8 serveurs (Tout afficher / Afficher moins), Ajouter un DNS en haut, barre de défilement fine.",
        "Nouveau : blocage des pubs, traqueurs et malwares (Non/Basique/Moyen/Strict) avec listes d'autorisation et de blocage. ☰ > Blocage. Tout en local.",
        "Nouveau : style Frutiger Aurora ; Y2K holographique et Metro ville et musique. À choisir dans ☰ > Personnaliser > Style.",
        "Nouveau : IPv4 et IPv6 ensemble, détection des pannes plus rapide ; pour la vie privée, traces de l'appareil supprimées et longueurs des messages masquées.",
        "Nouveau : réglages séparés par thème. Dans le menu ☰ : DNS, Connexion et applis, Notifications, Liste des serveurs, Statistiques et historique, Données.",
        "Nouveau : fenêtre Personnaliser (menu ☰) : langue, thème, style, arrière-plan, icône, texte et accessibilité.",
        "Nouveau : menu ☰ sur l'écran d'accueil et une fenêtre À propos (nouveautés, aide, journal, partage, version).",
        "Correctif : choisir sa photo ou une image fournie comme arrière-plan fonctionne (la taille était mal lue).",
        "Correctif : le test de connexion distingue un serveur en panne d'un téléphone qui n'utilise pas le DNS, et avertit.",
        "Correctif : styles Metro, Eco et Y2K redessinés ; le changement d'icône s'applique à la sortie de l'appli.",
        "Nouveau : 8 images de fond incluses (☰ → Personnaliser → Photo de fond → Images incluses).",
        "Nouveau : dépannage, recherche de serveurs, partage des mesures, modification des serveurs perso et option sans historique.",
        "Icône de l'appli : choisis parmi cinq icônes assorties aux cinq styles.",
        "Photo d'arrière-plan : utilisez votre propre image en fond, avec voile et flou réglables ; le texte reste toujours lisible.",
        "Cinq styles : Aqua (classique), Aero (ciel et herbe), Metro (tuiles plates), Eco (nature) et Y2K rose, chacun avec ses animations, et des transitions plus fluides.",
        "Choix des applis : appliquez le DNS seulement aux applis choisies ou excluez-en certaines.",
        "Ajoutez vos propres serveurs DNS (jusqu'à 8), 10 nouveaux serveurs et une section d'infos pour chaque serveur : à quoi il sert, propriétaire, ping moyen.",
        "Connexion plus sûre : contrôles supplémentaires contre les fausses réponses DNS, alerte en cas de repli sur le DNS non chiffré, option de chiffrement strict et retour automatique au chiffrement.",
        "Test de connexion : vérifiez d'un geste que le DNS répond bien depuis le serveur choisi, ainsi que la validation DNSSEC et le blocage des pubs.",
        "Serveur de secours et reconnexion automatique : l'app se rétablit seule si le serveur choisi ne répond pas ou si la connexion se coupe.",
        "Historique des connexions, serveurs les plus utilisés, temps de réponse moyen et trafic DNS.",
        "Nouveaux filtres (Chiffrés, Sans filtre), tri par nom, \"Trouver un serveur pour moi\" et mesure au démarrage.",
        "Compteurs en direct dans la notification, bouton de pause de 15 minutes, masquage sur l'écran verrouillé et option de notification discrète.",
        "Trois nouveaux thèmes (Sakura, Miel, Aurore boréale), un thème tiré de votre fond d'écran et le choix clair/sombre pour le thème automatique.",
        "Quatre nouvelles langues : indonésien, vietnamien, polonais et ukrainien.",
    )
    override fun importedWith(changes: String) = "Réglages chargés · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "chiffrement affaibli"
        SensitiveChange.AUTO_START -> "connexion auto activée"
        SensitiveChange.RULES -> "règles de serveur modifiées"
        SensitiveChange.PRIVACY -> "réglages de confidentialité ou d'alertes assouplis"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries requêtes · $blocked bloquées"
    override val NOTIF_LOCKED = "Protection DNS active"
    override val NOTIF_QUIET_CHANNEL = "État de la connexion (discret)"
    override fun widgetToday(queries: String) = "Aujourd'hui $queries requêtes"
    override fun pauseAction(minutes: Int) = "Pause ${minutes(minutes)}"


    override val CUSTOM_NOTE = "Serveur que vous avez ajouté"
    override val CUSTOM_ADD = "Ajouter un DNS personnalisé"
    override val CUSTOM_F_NAME = "Nom"
    override val CUSTOM_F_IP1 = "Adresse IPv4 (ex. 1.2.3.4)"
    override val CUSTOM_F_IP2 = "Seconde adresse IPv4 (facultatif)"
    override val CUSTOM_F_DOT = "Nom DoT (facultatif)"
    override val CUSTOM_F_DOH = "Adresse DoH, https://… (facultatif)"
    override val CUSTOM_SAVE = "Ajouter"
    override val CUSTOM_CANCEL = "Annuler"
    override val CUSTOM_HINT = "Renseignez DoT ou DoH pour une connexion chiffrée ; sinon un DNS non chiffré est utilisé."
    override val CUSTOM_ERR_NAME = "Le nom doit faire 1 à 24 caractères (sans | ; , =)"
    override val CUSTOM_ERR_IP = "Saisissez une adresse IPv4 valide (ex. 1.2.3.4)"
    override val CUSTOM_ERR_DOT = "Le nom DoT doit être un nom de domaine valide"
    override val CUSTOM_ERR_DOH = "L'adresse DoH doit commencer par https://"
    override val CUSTOM_ERR_LIMIT = "Vous pouvez ajouter 8 serveurs personnalisés au maximum"
    override fun customAdded(name: String) = "$name ajouté"
    override val CUSTOM_DELETE = "Supprimer ce serveur"
    override val CUSTOM_IN_USE = "Suppression impossible pendant la connexion"
    override fun customDeleted(name: String) = "$name supprimé"
    override val INFO_PURPOSE = "À quoi il sert"
    override val INFO_OWNER = "Propriétaire"
    override val INFO_AVG = "Ping moyen"
    override fun avgPing(ms: Int, n: Int) = "$ms $msU · $n mesures"

    override val APPS = "Applications"
    override val APPS_ALL = "Toutes"
    override fun appsOnly(n: Int) = "Seulement la sélection ($n)"
    override fun appsExcept(n: Int) = "Toutes sauf la sélection ($n)"
    override val APPS_MODE = "Quelles applis utilisent ce DNS ?"
    override val OPT_APPS = listOf("Toutes", "Sélection", "Sauf sélection")
    override val APPS_NOTE = "Les applis non incluses utilisent le DNS du téléphone. Un seul serveur DNS fonctionne à la fois ; on ne peut pas en choisir un par appli."
    override val APPS_LOADING = "Chargement des applications…"
    override val APPS_EMPTY = "Aucune application trouvée"
    override val APPS_NONE_SELECTED = "Aucune appli sélectionnée : le DNS s'applique à toutes."
    override val APPS_APPLY = "Appliquer maintenant"
    override val APPS_PENDING = "Le changement prend effet au renouvellement de la connexion (coupure d'une ou deux secondes)."

    override val NOTES = mapOf(
        "cloudflare" to "Rapide, axé sur la vie privée",
        "google" to "Stable, très répandu",
        "quad9" to "Bloque les domaines malveillants",
        "adguard" to "Bloque pubs et traqueurs",
        "controld" to "Sans filtre, rapide",
        "opendns" to "Cisco, protection anti-phishing",
        "dnssb" to "Axé sur la vie privée, rapide",
        "dns4eu" to "DNS de l'UE, anti-malware",
        "uncensored" to "Ni filtre ni redirection",
        "quad9-open" to "Ne bloque rien",
        "adguard-open" to "Sans blocage, axé vie privée",
        "dns4eu-open" to "DNS de l'UE, sans filtre",
        "controld-ads" to "Pubs, traqueurs, malwares",
        "dns4eu-ads" to "DNS de l'UE, pubs et malwares",
        "cloudflare-security" to "Bloque les sites malveillants",
        "controld-malware" to "Bloque les sites malveillants",
        "cleanbrowsing-security" to "Phishing et sites malveillants",
        "cloudflare-family" to "Filtre malwares et contenu adulte",
        "opendns-family" to "Filtre de contenu adulte",
        "adguard-family" to "Filtre pubs et contenu adulte",
        "cleanbrowsing-family" to "Contenu adulte, recherche sûre",
        "dns4eu-child" to "DNS de l'UE, protection enfants",
        "controld-family" to "Filtre de contenu adulte",
        "nextdns" to "Filtrage configurable, rapide",
        "cira-private" to "Canada, sans filtre, vie privée",
        "cira-protected" to "Canada, bloque les sites malveillants",
        "libredns" to "Indépendant, sans filtre",
        "switch" to "Suisse, bloque les sites malveillants",
        "wikimedia" to "DNS de Wikimedia, vie privée",
        "digitale" to "Association suisse, sans filtre",
        "quad101" to "Taïwan, rapide",
        "alidns" to "Chine, rapide",
    )
}
