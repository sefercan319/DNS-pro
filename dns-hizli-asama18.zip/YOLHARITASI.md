# Yol haritası

## Yapıldı
- Aşama 15 (v1.9.7): IPv4 + IPv6, gizlilik sertleştirmesi, DNS hata düzeltmeleri.
- Aşama 16 (v1.9.8): Y2K ve Metro yeniden çizildi, Frutiger Aurora eklendi (6 stil).
- Aşama 17 (v1.9.9): reklam, izleyici ve zararlı site engelleme (4 seviye, izin ve engel listesi, son engellenenler, sayaç).
- Aşama 18 (v1.9.10): ilk 8 sunucu + Tümünü göster / Daha az göster, Özel DNS ekle üstte, ince kaydırma çubuğu.

## Sıradaki
1. **Arayüz düzeltmeleri:** bildirilen yeni hatalar (kalan arayüz sorunları).
2. **Kalite denetimi:** kod ve özellik listesi taranıp gerçek eksikler çıkarılır.
3. Play Store açıklaması ve gizlilik metni.
4. (İsteğe bağlı, düşük öncelik) `selftest/` testlerini Gradle'a bağlama (`src/test` ya da `sourceSets`), Android Studio ve CI'dan çalışsın diye. Şimdilik `run-tests.sh` yeterli.

## Gelecek planı (uzun, ayrı ana başlık)
- **DPI atlatma:** kendi yerel kodumuzla (dış kütüphane gömmeden), cihazda çalışır, kademeli ve deneysel, varsayılan kapalı.
  Aşamalar: (a) modüler tünel mimarisi ve "tüm trafiği geçir" anahtarı, (b) kendi TCP aktarma katmanımız, (c) atlatma yöntemleri
  ve gerçek telefonda deneme. DNS ve DPI ileride tek uygulamada birleşir.
- **Röle (IP gizleme):** sağlayıcının IP'nizi görmemesi için; güvenilir röle seçenekleri araştırılarak.
