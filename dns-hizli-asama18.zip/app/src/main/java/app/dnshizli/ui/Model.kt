package app.dnshizli.ui

import app.dnshizli.core.AppEntry
import app.dnshizli.core.FilterNames
import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.NetCheck
import app.dnshizli.core.ResultsText
import app.dnshizli.core.ServerSearch
import app.dnshizli.core.AppScope
import app.dnshizli.core.AppSettings
import app.dnshizli.core.Catalog
import app.dnshizli.core.CustomDns
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Format
import app.dnshizli.core.ImportReview
import app.dnshizli.core.Latency
import app.dnshizli.core.LatencyHistory
import app.dnshizli.core.OrbState
import app.dnshizli.core.Proto
import app.dnshizli.core.WpBlur
import app.dnshizli.core.UiStyle
import app.dnshizli.core.Pic
import app.dnshizli.core.SelfTestResult
import app.dnshizli.core.ServerList
import app.dnshizli.core.SettingsCodec
import app.dnshizli.core.SortMode
import app.dnshizli.core.Tag

/** Liste süzgeçleri (üstteki çipler). Etiketleri etkin dilden okunur. [id] ayarda saklanır. */
enum class Filter(val tag: Tag?) {
    ALL(null),
    FAVORITES(null),
    RECENT(null),
    FAST(Tag.FAST),
    PRIVACY(Tag.PRIVACY),
    ADS(Tag.ADS),
    FAMILY(Tag.FAMILY),
    SECURITY(Tag.SECURITY),
    ENCRYPTED(null),
    UNFILTERED(null);

    val id: String get() = name.lowercase()

    val label: String get() = when (this) {
        ALL -> Strings.FILTER_ALL
        FAVORITES -> Strings.FILTER_FAV
        RECENT -> Strings.FILTER_RECENT
        ENCRYPTED -> Strings.FILTER_ENCRYPTED
        UNFILTERED -> Strings.FILTER_UNFILTERED
        else -> tag!!.label
    }

    /** Etiket dışı ek koşul (şifreli / filtresiz). */
    val extra: ((DnsServer) -> Boolean)? get() = when (this) {
        ENCRYPTED -> ServerList::encrypted
        UNFILTERED -> ServerList::unfiltered
        else -> null
    }

    companion object {
        fun byId(id: String?): Filter = values().firstOrNull { it.id == id } ?: ALL
    }
}

/** Arayüzün gördüğü VPN durumu. Servis bunu üretir, etkinlik modele iletir. */
data class VpnUi(
    val state: OrbState = OrbState.OFF,
    val serverId: String? = null,
    val sinceMs: Long = 0L,
    val queries: Long = 0L,
    val cacheHits: Long = 0L,
    val avgMs: Int = 0,
    val error: String? = null,
    val onBackup: Boolean = false,
    /** Kullanılan taşıma yöntemi (bağlıyken). */
    val proto: Proto? = null,
    val blocked: Long = 0L,
    /** Kısa süreli duraklatma bitiş zamanı (epoch ms); 0 ise duraklatılmamış. */
    val pausedUntil: Long = 0L,
    /** Otomatik şifrelemede şifreli yöntem kurulamadı, şifresiz DNS kullanılıyor. */
    val downgraded: Boolean = false,
    /** Bağlantı koptu, servis kendiliğinden yeniden deniyor. */
    val retrying: Boolean = false,
    /** Hata olmayan tek seferlik bilgi (ör. "yedek sunucuya bağlanıldı"); arayüz bir kez gösterir. */
    val info: String? = null,
) {
    val active: Boolean get() = state == OrbState.ON || state == OrbState.CONNECTING
}

/** Geçici kısa mesaj (alt kısımda cam hap). [action] doluysa yanında dokunulabilir bir eylem olur. */
class ToastMsg(val text: String, val action: String? = null, val onAction: (() -> Unit)? = null)

/**
 * Platformun (Android) arayüze sunduğu yetenekler. Testlerde sahte bir uygulaması kullanılır.
 * Tüm çağrılar ve [AppModel]'in tüm metotları ana (arayüz) iş parçacığında çalışır.
 */
interface Host {
    /** [serverId] sunucusuna bağlan; zaten bağlıysa tüneli koparmadan sunucuyu değiştir. Durum [AppModel.onVpn] ile döner. */
    fun connect(serverId: String)
    fun disconnect()

    /** Bağlantıyı [minutes] dakika duraklat; süre bitince servis kendiliğinden yeniden bağlanır. */
    fun pause(minutes: Int)

    /** Duraklatmayı bitir ve hemen yeniden bağlan. */
    fun resume()

    /** Bağlıyken servisteki DNS önbelleğini boşalt. */
    fun clearCache()

    /** Listedeki sunucuların gecikmesini arka planda ölç; her sonuç [AppModel.onLatency], bitiş [AppModel.onMeasureDone] ile döner. */
    fun measure(serverIds: List<String>)

    fun saveSettings(s: AppSettings)

    /** Başlatıcıda görünen uygulamaları arka planda listele; sonuç (ada göre sıralı) ana iş parçacığında [onDone] ile gelir. */
    fun loadApps(onDone: (List<AppEntry>) -> Unit)

    /** Bağlıyken uygulama seçimini uygulamak için tüneli aynı sunucuyla yeniden kur. */
    fun applyApps()

    /**
     * Özel DNS ekleme penceresini göster. Kullanıcı "Ekle"ye basınca [validate] hata metni döndürürse pencere
     * açık kalıp metni gösterir; null dönerse kapanır ve [onDone] çağrılır.
     */
    fun promptCustomServer(validate: (CustomDns.Draft) -> String?, initial: CustomDns.Draft?, onDone: (CustomDns.Draft) -> Unit)
    fun saveLatencies(m: Map<String, Latency>)
    fun saveHistory(h: Map<String, List<Int?>>)

    /** Servisin yazdığı toplam istatistikleri ve günlük sayıları sıfırla. */
    fun resetTotals()
    fun copyText(text: String)
    fun readClipboard(): String?
    fun shareText(text: String)
    fun shareApp()
    fun rateApp()
    fun haptic(strong: Boolean)
    fun openVpnSettings()

    /** Ayardaki dili ("auto" ya da kod) uygula (Android 13+ sistemin uygulama dili ayarıyla eşitlenir). */
    fun applyLanguage(setting: String)
    fun diagnostics(): String
    fun clearDiagnostics()
    fun versionName(): String
    fun now(): Long
    fun requestFrame()

    /** Cihazın yerel saatine göre saat (0..23); "gece temasını saate bağla" kullanır. */
    fun localHour(): Int {
        val c = java.util.Calendar.getInstance()
        c.timeInMillis = now()
        return c.get(java.util.Calendar.HOUR_OF_DAY)
    }

    /** Sistem galerisinden arka plan fotoğrafı seçtir; sonuç [AppModel.onWallpaperPicked] ile döner. */
    fun pickWallpaper()

    /** Uygulamayla gelen hazır görselin [index]'ini arka plan yap; sonuç [AppModel.onWallpaperPicked] ile döner. */
    fun usePresetWallpaper(index: Int)

    /** Kayıtlı arka plan fotoğrafını sil. */
    fun removeWallpaper()

    /**
     * Kayıtlı fotoğrafı [blur] düzeyiyle arka planda yükle; ana iş parçacığında [onDone] ile gelir.
     * Dosya yoksa ya da bozuksa null. Dönen [Pic]'in sahibi çağıran olur (işi bitince [Pic.release]).
     */
    fun loadWallpaper(blur: WpBlur, onDone: (Pic?) -> Unit)

    /** Başlatıcıdaki uygulama simgesini [style] simgesiyle değiştir. Başarılıysa true. */
    fun setAppIcon(style: UiStyle): Boolean

    /** Sorun gidericinin okuduğu telefon durumu (VPN izni, internet, başka VPN, Android Özel DNS). Hızlıdır, ana iş parçacığında çağrılır. */
    fun networkCheck(): NetCheck

    /** Tek satırlık metin girişi penceresi; boş sonuç "temizle" demektir. */
    fun promptText(title: String, hint: String, initial: String, onDone: (String) -> Unit)

    /** Bağlıyken bağlantı testini başlat; sonuç [AppModel.onTestResult] ile döner. */
    fun runTest()

    /** Bağlıyken değişen bağlantı ayarlarını (şifreleme, önbellek, kurallar) hemen uygula. */
    fun reapply()

    /** Uygulama simgesinin kısayollarını favorilerle güncelle (Android 7.1+ dinamik kısayollar). */
    fun updateShortcuts(serverIds: List<String>)

    /** Android 12+ duvar kağıdından gelen vurgu rengi (dinamik tema için); yoksa null. */
    fun systemAccent(): Int?

    /** Sistem pil ayarlarını aç. */
    fun openBatterySettings()

    /** Uygulama pil optimizasyonu ile kısıtlanıyor mu? Bilinmiyorsa null. */
    fun batteryRestricted(): Boolean?
}

/**
 * Uygulamanın tüm durumu ve kuralları. Arayüzden bağımsızdır: dokunma eylemleri burada anlam kazanır,
 * sahne yalnızca [version] değişince kendini günceller. Bu sayede her şey JVM'de test edilebilir.
 */
class AppModel(
    val host: Host,
    settings: AppSettings,
    latencies: Map<String, Latency> = emptyMap(),
    history: Map<String, List<Int?>> = emptyMap(),
) {
    var settings: AppSettings = settings
        private set
    var vpn: VpnUi = VpnUi()
        private set
    val latencies: MutableMap<String, Latency> = LinkedHashMap(latencies)
    var history: Map<String, List<Int?>> = history
        private set
    var filter: Filter = Filter.ALL
        private set
    var measuring: Boolean = false
        private set
    var consentOpen: Boolean = false
        private set
    var toast: ToastMsg? = null
        private set
    var testing: Boolean = false
        private set
    var testResult: SelfTestResult? = null
        private set

    /** Yeni bir test sonucu geldiğinde artar: sahne sonucu panelde gösterir. */
    var testSeq: Int = 0
        private set

    /** "Neler yeni" sayfasını açma isteği (sahne izler). */
    var whatsNewSeq: Int = 0
        private set

    /** Duvar kağıdı rengi (dinamik tema için); platform yapılandırma değişince günceller. */
    var accentSeed: Int? = null
        private set

    /** Her görünür değişimde artar; sahne bunu izleyip yeniden kurulur. */
    var version: Int = 0
        private set

    /** Her yeni geçici mesajda artar. */
    var toastSeq: Int = 0
        private set

    /** Dil değişince artar: sahne bütün sayfaları yeni dilde yeniden kurar. */
    var langSeq: Int = 0
        private set

    private var pendingConnect: String? = null
    private var measureRemaining = 0
    private var measureStart = 0L

    /** Bağlıyken istenen ama platformun henüz bildirmediği geçiş hedefi: çift dokunmada ikinci çağrıyı eler. */
    private var switchingTo: String? = null
    private var switchAt = 0L

    private var started = false

    init {
        if (settings.rememberFilter) filter = Filter.byId(settings.lastFilter)
        accentSeed = host.systemAccent()
    }

    private fun bump() { version++; host.requestFrame() }

    // ------------------------------------------------------------------ okuma

    fun selectedId(): String = settings.lastServer ?: Catalog.DEFAULT_ID

    fun server(id: String?): DnsServer? = id?.let { Catalog.byId(it) }

    fun nameOf(id: String?): String = server(id)?.name ?: Catalog.default.name

    /** Şu an bağlı (veya bağlanmakta) sunucunun kimliği; yoksa null. */
    fun connectedId(): String? = if (vpn.active) (vpn.serverId ?: selectedId()) else null

    /** Duraklatma sürüyor mu (süre bitmiş ama servis henüz yeniden bağlanmamış olabilir)? */
    val paused: Boolean get() = !vpn.active && vpn.pausedUntil != 0L

    /** Duraklatma süresi doldu, servisin yeniden bağlanması bekleniyor. */
    val resuming: Boolean get() = paused && vpn.pausedUntil <= host.now()

    /** Seçili şifreleme tercihiyle bu sunucuya bağlanılabilir mi? */
    fun canUse(s: DnsServer): Boolean = settings.plan(s).isNotEmpty()

    /** Sade görünümde süzgeçler gizlidir: liste hep "Tümü"dür. */
    val effectiveFilter: Filter get() = if (settings.minimal) Filter.ALL else filter

    /** Sunucu araması (yalnızca oturum boyunca tutulur, kaydedilmez). Sade görünümde süzgeçler gibi gizlidir. */
    var query: String = ""
        private set

    val effectiveQuery: String get() = if (settings.minimal) "" else query

    fun setQuery(q: String) {
        val c = ServerSearch.clean(q)
        if (c == query) return
        query = c
        bump()
    }

    /** Arama penceresini açar; boş girdi aramayı temizler. */
    fun promptSearch() = host.promptText(Strings.SEARCH, Strings.SEARCH_HINT, query) { setQuery(it) }

    /** Ölçüm sonuçlarını (en hızlıdan) metin olarak paylaşır; ölçüm yoksa uyarır. */
    fun shareResults() {
        val text = ResultsText.build(Strings.SHARE_RESULTS_HEAD, Catalog.all, latencies)
        if (text == null) { toast(Strings.NO_RESULTS); return }
        host.shareText(text)
    }

    fun visibleServers(): List<DnsServer> {
        val filter = effectiveFilter
        val base = when (filter) {
            Filter.FAVORITES -> Catalog.all.filter { it.id in settings.favorites }
            Filter.RECENT -> settings.recent.mapNotNull { Catalog.byId(it) }
            else -> Catalog.all
        }
        val q = effectiveQuery
        if (filter == Filter.RECENT) return ServerSearch.filter(base.filter { it.id !in settings.hidden }, q)   // son kullanım sırası korunur
        return ServerSearch.filter(ServerList.visible(base, filter.tag, settings.favorites, latencies, settings.sortMode, settings.hidden, filter.extra), q)
    }

    // ------------------------------------------------------------------ uzun liste: ilk sunucular + "Tümünü göster"

    /** Liste açık mı (yalnızca bu oturumda; kaydedilmez). */
    var listExpanded: Boolean = false
        private set

    /** Liste, kısaltılacak kadar uzun mu? En az [LIST_MIN_HIDDEN] sunucu gizlenecekse kısaltılır (tek sunucu için düğme gereksiz). */
    fun listCollapsible(): Boolean = visibleServers().size >= LIST_LIMIT + LIST_MIN_HIDDEN

    /** Ekranda gösterilecek sunucular: kısaltılabilir ve kapalıysa ilk [LIST_LIMIT]. */
    fun shownServers(): List<DnsServer> {
        val all = visibleServers()
        return if (!listExpanded && all.size >= LIST_LIMIT + LIST_MIN_HIDDEN) all.subList(0, LIST_LIMIT) else all
    }

    fun toggleList() { listExpanded = !listExpanded; bump() }

    /** Özel sunucu ekleme penceresini açar. */
    fun promptCustom() {
        host.promptCustomServer({ d -> CustomDns.validate(d, Catalog.custom.size)?.let { customErrorText(it) } }, null) { commitCustom(it) }
    }

    fun customErrorText(e: CustomDns.Error): String = when (e) {
        CustomDns.Error.NAME -> Strings.CUSTOM_ERR_NAME
        CustomDns.Error.IP, CustomDns.Error.IP2 -> Strings.CUSTOM_ERR_IP
        CustomDns.Error.DOT -> Strings.CUSTOM_ERR_DOT
        CustomDns.Error.DOH -> Strings.CUSTOM_ERR_DOH
        CustomDns.Error.LIMIT -> Strings.CUSTOM_ERR_LIMIT
    }

    /** Doğrulanmış girdiyi özel sunucu olarak kaydeder (geçersizse hiçbir şey yapmaz). */
    fun commitCustom(d: CustomDns.Draft) {
        if (CustomDns.validate(d, Catalog.custom.size) != null) return
        val s = CustomDns.build(CustomDns.newId(host.now(), Catalog.all.map { it.id }), d)
        val list = Catalog.custom + s
        Catalog.setCustom(list)
        update { it.copy(custom = CustomDns.encode(list)) }
        toast(Strings.customAdded(s.name))
    }

    /** Özel sunucunun bilgilerini düzenleme penceresini açar (bağlıyken düzenlenmez). */
    fun editCustom(id: String) {
        val s = Catalog.custom.firstOrNull { it.id == id } ?: return
        if (connectedId() == id) { toast(Strings.CUSTOM_IN_USE); return }
        val cur = CustomDns.Draft(s.brand, s.primary, s.secondary ?: "", s.dot ?: "", s.doh ?: "")
        host.promptCustomServer({ d -> CustomDns.validate(d, Catalog.custom.size - 1)?.let { customErrorText(it) } }, cur) { commitEdit(id, it) }
    }

    /** Doğrulanmış girdiyi aynı kimlikle kaydeder; adresler değiştiği için eski ölçümler silinir. */
    fun commitEdit(id: String, d: CustomDns.Draft) {
        if (Catalog.custom.none { it.id == id } || connectedId() == id) return
        if (CustomDns.validate(d, Catalog.custom.size - 1) != null) return
        val s = CustomDns.build(id, d)
        val list = Catalog.custom.map { if (it.id == id) s else it }
        Catalog.setCustom(list)
        update { it.copy(custom = CustomDns.encode(list)) }
        latencies.remove(id)
        history = history - id
        host.saveLatencies(latencies)
        host.saveHistory(history)
        toast(Strings.customUpdated(s.name))
    }

    /** Özel sunucuyu siler ve ona bağlı tüm seçimleri (favori, kural, yedek, ölçümler) temizler. Bağlıyken silinmez. */
    fun removeCustom(id: String): Boolean {
        val s = Catalog.custom.firstOrNull { it.id == id } ?: return false
        if (connectedId() == id) { toast(Strings.CUSTOM_IN_USE); return false }
        val list = Catalog.custom.filter { it.id != id }
        Catalog.setCustom(list)
        update {
            it.copy(
                custom = CustomDns.encode(list),
                favorites = it.favorites - id, hidden = it.hidden - id, recent = it.recent.filter { r -> r != id },
                lastServer = it.lastServer.takeIf { l -> l != id },
                wifiServer = it.wifiServer.takeIf { w -> w != id }, mobileServer = it.mobileServer.takeIf { m -> m != id },
                backupServer = it.backupServer.takeIf { b -> b != id },
            )
        }
        latencies.remove(id)
        history = history - id
        host.saveLatencies(latencies)
        host.saveHistory(history)
        host.updateShortcuts(Catalog.all.filter { it.id in settings.favorites }.map { it.id })
        toast(Strings.customDeleted(s.name))
        return true
    }

    fun hiddenServers(): List<DnsServer> = Catalog.all.filter { it.id in settings.hidden }

    fun statusTitle(): String = when {
        paused -> Strings.PAUSED
        else -> when (vpn.state) {
            OrbState.OFF -> Strings.OFF
            OrbState.CONNECTING -> Strings.CONNECTING
            OrbState.ON -> Strings.ON
            OrbState.ERROR -> Strings.ERROR
        }
    }

    fun statusSub(): String {
        if (resuming) return Strings.RESUMING
        if (paused) return Strings.pausedUntil(Format.hm(vpn.pausedUntil))
        return when (vpn.state) {
            OrbState.OFF -> Strings.selected(nameOf(selectedId()))
            OrbState.CONNECTING -> nameOf(vpn.serverId ?: selectedId())
            OrbState.ON -> Strings.onLine(nameOf(vpn.serverId ?: selectedId()), vpn.proto?.let { Strings.protoName(it) }, vpn.avgMs.takeIf { it > 0 })
            OrbState.ERROR -> vpn.error ?: Strings.ERR_DEFAULT
        }
    }

    fun statusHint(): String {
        if (paused) return Strings.HINT_PAUSED
        return when (vpn.state) {
            OrbState.OFF -> Strings.HINT_OFF
            OrbState.CONNECTING -> if (vpn.retrying) Strings.NOTIF_RETRYING else Strings.HINT_CONNECTING
            OrbState.ON -> {
                val secs = ((host.now() - vpn.sinceMs) / 1000).coerceAtLeast(0)
                if (settings.minimal) Format.clock(secs)
                else {
                    val pct = if (vpn.queries > 0) (vpn.cacheHits * 100 / vpn.queries).toInt().coerceIn(0, 100) else 0
                    Strings.statsLine(secs, vpn.queries, pct, vpn.blocked)
                }
            }
            OrbState.ERROR -> Strings.HINT_ERROR
        }
    }

    // ------------------------------------------------------------------ eylemler (kullanıcı)

    /** Küreye dokunuldu: bağlıysa kes, duraklatılmışsa sürdür, değilse seçili (ya da ayar açıksa en hızlı) sunucuya bağlan. */
    fun tapOrb() {
        when {
            vpn.active && settings.confirmDisconnect -> toast(Strings.CONFIRM_DISCONNECT, Strings.DISCONNECT) { disconnectNow() }
            vpn.active -> disconnectNow()
            paused -> {
                host.resume()
                vpn = vpn.copy(state = OrbState.CONNECTING, pausedUntil = 0L, error = null, sinceMs = host.now())
                bump()
            }
            else -> {
                val target = if (settings.autoFastest) fastestUsable()?.first?.id ?: selectedId() else selectedId()
                requestConnect(target)
            }
        }
    }

    /** Onaysız kesme (onaydan sonra ya da onay kapalıyken). */
    fun disconnectNow() {
        if (!vpn.active) return
        switchingTo = null
        host.disconnect()
        toast(Strings.DISCONNECTED)
    }

    private fun fastestUsable() =
        ServerList.fastest(Catalog.all, latencies) { it.id !in settings.hidden && canUse(it) }

    /** Listedeki bir sunucuya dokunuldu: ona bağlan (bağlıysa kesintisiz geç). */
    fun tapServer(id: String) {
        val s = Catalog.byId(id) ?: return
        if (vpn.active && vpn.serverId == id) return
        if (vpn.active && switchingTo == id && host.now() - switchAt < SWITCH_GRACE_MS) return
        if (!canUse(s)) {
            toast(Strings.errNoProto(s.name, Strings.OPT_ENCRYPTION[settings.encryption.ordinal]))
            return
        }
        requestConnect(id)
        if (vpn.active && vpn.serverId != id) toast(Strings.switched(nameOf(id)))
    }

    private fun requestConnect(id: String) {
        if (!settings.onboarded) {
            pendingConnect = id
            consentOpen = true
            bump()
            return
        }
        doConnect(id)
    }

    private fun doConnect(id: String) {
        settings = settings.copy(lastServer = id).withRecent(id)
        host.saveSettings(settings)
        if (vpn.active) { switchingTo = id; switchAt = host.now() }
        else {
            switchingTo = null
            vpn = vpn.copy(state = OrbState.CONNECTING, serverId = id, error = null, sinceMs = host.now(), onBackup = false, pausedUntil = 0L)
        }
        host.connect(id)
        bump()
    }

    fun acceptConsent() {
        consentOpen = false
        settings = settings.copy(onboarded = true)
        host.saveSettings(settings)
        val id = pendingConnect
        pendingConnect = null
        if (id != null) doConnect(id) else bump()
    }

    fun dismissConsent() {
        consentOpen = false
        pendingConnect = null
        bump()
    }

    fun setFilter(f: Filter) {
        if (filter == f) return
        filter = f
        if (settings.rememberFilter) {
            settings = settings.copy(lastFilter = f.id)
            host.saveSettings(settings)
        }
        bump()
    }

    fun toggleFavorite(id: String) {
        if (Catalog.byId(id) == null) return
        val fav = settings.favorites
        update { it.copy(favorites = if (id in fav) fav - id else fav + id) }
        host.updateShortcuts(Catalog.all.filter { it.id in settings.favorites }.map { it.id })
    }

    /** Sıralamayı sırayla değiştirir: varsayılan → hız → ad → varsayılan. */
    fun toggleSort() = update {
        val next = SortMode.values()[(it.sortMode.ordinal + 1) % SortMode.values().size]
        it.copy(sortMode = next)
    }

    /** Sunucuyu listeden gizler; mesajdaki "Geri al" ile geri getirilir. */
    fun hide(id: String) {
        val s = Catalog.byId(id) ?: return
        if (id in settings.hidden) return
        update { it.copy(hidden = it.hidden + id) }
        toast(Strings.hiddenToast(s.name), Strings.UNDO) { unhide(id) }
    }

    fun unhide(id: String) = update { it.copy(hidden = it.hidden - id) }

    /** Tüm sunucuların hızını ölç (gizlenenler hariç). Zaten ölçülüyorsa yok sayılır. */
    fun measureAll() = measure(Catalog.all.filter { it.id !in settings.hidden }.map { it.id })

    fun measure(ids: List<String>) {
        if (measuring || ids.isEmpty()) return
        measuring = true
        measureStart = host.now()
        measureRemaining = ids.size
        host.measure(ids)
        bump()
    }

    /** Ölçülmüş en hızlı (kullanılabilir) sunucuya bağlan. */
    fun connectFastest() {
        val best = fastestUsable()
        if (best == null) toast(Strings.MEASURE_FIRST) else tapServer(best.first.id)
    }

    /** Bağlıyken bağlantı testini başlat. */
    fun testConnection() {
        if (vpn.state != OrbState.ON) { toast(Strings.ONLY_CONNECTED); return }
        if (testing) return
        testing = true
        testStart = host.now()
        host.runTest()
        bump()
    }

    private var testStart = 0L

    fun onTestResult(r: SelfTestResult) {
        testing = false
        testResult = r
        testSeq++
        bump()
    }

    /**
     * Amaca uygun sunucu: [goal] etiketli (null ise hepsi) kullanılabilir sunucular arasında ölçülmüş en hızlısı.
     * Hiç ölçüm yoksa önce ölçmeyi önerir (ölçüm bitince en hızlı mesajı zaten gelir).
     */
    fun recommend(goal: Tag?) {
        val usable: (DnsServer) -> Boolean = { it.id !in settings.hidden && canUse(it) }
        val s = ServerList.recommend(Catalog.all, goal, latencies, usable)
        if (s == null) { toast(Strings.NO_REPLY); return }
        // Hiç ölçüm yoksa katalogdaki ilk uygun sunucu önerilir ve arkadan ölçülür (bir sonraki öneri ölçüme dayanır).
        if (latencies.isEmpty()) measureAll()
        tapServer(s.id)
        toast(Strings.recommended(s.name))
    }

    /** Tüm ölçümleri ve geçmişi siler. */
    fun clearHistory() {
        latencies.clear()
        history = emptyMap()
        host.saveLatencies(latencies)
        host.saveHistory(history)
        toast(Strings.HISTORY_CLEARED)
    }

    /**
     * Uygulama ön plana ilk geldiğinde: açılışta ölçüm (ayar açıksa ve son ölçüm 1 günden eskiyse) ve
     * sürüm yükseldiyse "Neler yeni" duyurusu.
     */
    fun onStart() {
        if (started) return
        started = true
        if (settings.autoMeasure && settings.onboarded) {
            val newest = latencies.values.maxOfOrNull { it.at } ?: 0L
            if (host.now() - newest > DAY_MS) measureAll()
        }
        if (settings.lastSeenVersion < WHATS_NEW_VERSION) {
            val wasUsing = settings.onboarded
            settings = settings.copy(lastSeenVersion = WHATS_NEW_VERSION)
            host.saveSettings(settings)
            if (wasUsing) toast(Strings.WHATS_NEW_TOAST, Strings.SHOW) { openWhatsNew() }
        }
    }

    fun openWhatsNew() { whatsNewSeq++; bump() }

    /** Duvar kağıdı rengi değişti (ya da ilk kez okundu). */
    fun setAccentSeed(v: Int?) { if (v != accentSeed) { accentSeed = v; bump() } }

    /** Bağlantıyı [minutes] dakika duraklat. */
    fun pause(minutes: Int) {
        if (!vpn.active || minutes <= 0) return
        switchingTo = null
        host.pause(minutes)
        vpn = vpn.copy(state = OrbState.OFF, pausedUntil = host.now() + minutes * 60_000L)
        bump()
    }

    fun clearCache() {
        if (vpn.state != OrbState.ON) { toast(Strings.ONLY_CONNECTED); return }
        host.clearCache()
        toast(Strings.CACHE_CLEARED)
    }

    /** Ayarı değiştir ve kaydet. Tüm ayar kontrolleri bunu kullanır. */
    fun update(change: (AppSettings) -> AppSettings) {
        val next = change(settings)
        if (next == settings) return
        val prev = settings
        val langChanged = next.lang != prev.lang
        settings = next
        host.saveSettings(settings)
        if (langChanged) { host.applyLanguage(next.lang); langSeq++ }
        if (prev.filterLevel != next.filterLevel || prev.filterAllow != next.filterAllow || prev.filterBlock != next.filterBlock) {
            FilterRuntime.update(next.filterLevel, next.filterAllow, next.filterBlock)
        }
        // Bağlıyken bağlantıyı etkileyen bir ayar değiştiyse servise hemen uygulat (yeniden bağlanmak gerekmesin).
        if (vpn.state == OrbState.ON && (prev.appScope != next.appScope || prev.apps != next.apps)) appsPending = true
        if (vpn.state == OrbState.ON && prev.ipMode != next.ipMode) {
            // Tünelin IPv6 adresi ekleniyor ya da çıkıyor: tünel aynı sunucuyla yeniden kurulur (DNS bir iki saniye kesilir).
            host.applyApps()
            toast(Strings.APPLYING)
        } else if (vpn.state == OrbState.ON && connectionChanged(prev, next)) {
            host.reapply()
            toast(Strings.APPLYING)
        }
        bump()
    }

    // ------------------------------------------------------------------ reklam / izleyici engelleme

    /** Alan adı yazma penceresi; geçerliyse listeye ekler ([allow]: izin listesi, değilse kendi engel listesi). Bitince [done] çağrılır. */
    fun promptFilterName(allow: Boolean, done: () -> Unit = {}) {
        host.promptText(if (allow) Strings.FILTER_ALLOW_ADD else Strings.FILTER_BLOCK_ADD, "ornek.com", "") { raw ->
            if (raw.isNotBlank() && addFilterName(allow, raw)) done()
        }
    }

    /** Alan adını izin ya da engel listesine ekler; öbür listeden çıkarır. Geçersizse ya da liste doluysa uyarır, false döner. */
    fun addFilterName(allow: Boolean, raw: String): Boolean {
        val name = FilterNames.normalize(raw)
        if (name == null) { toast(Strings.FILTER_ERR); return false }
        val cur = if (allow) settings.filterAllow else settings.filterBlock
        if (name !in cur && cur.size >= FilterNames.MAX_LIST) { toast(Strings.FILTER_ERR_LIMIT); return false }
        update {
            if (allow) it.copy(filterAllow = (it.filterAllow.filter { n -> n != name } + name), filterBlock = it.filterBlock.filter { n -> n != name })
            else it.copy(filterBlock = (it.filterBlock.filter { n -> n != name } + name), filterAllow = it.filterAllow.filter { n -> n != name })
        }
        toast(if (allow) Strings.filterAllowed(name) else Strings.filterBlocked(name))
        return true
    }

    /** Listeden kaldırmadan önce sorar. */
    fun askRemoveFilterName(allow: Boolean, name: String) =
        toast(Strings.filterRemoveAsk(name), Strings.FILTER_REMOVE_BTN) { removeFilterName(allow, name) }

    fun removeFilterName(allow: Boolean, name: String) {
        update { if (allow) it.copy(filterAllow = it.filterAllow.filter { n -> n != name }) else it.copy(filterBlock = it.filterBlock.filter { n -> n != name }) }
        toast(Strings.filterRemoved(name))
    }

    private fun connectionChanged(a: AppSettings, b: AppSettings): Boolean =
        a.encryption != b.encryption || a.strictEncryption != b.strictEncryption || a.cache != b.cache ||
            a.wifiServer != b.wifiServer || a.mobileServer != b.mobileServer ||
            a.hideOnLockscreen != b.hideOnLockscreen || a.quietNotification != b.quietNotification

    // ------------------------------------------------------------------ uygulama seçimi

    /** Yüklü (başlatıcıda görünen) uygulamalar; sayfa açılınca yüklenir, yüklenene kadar null. */
    var apps: List<AppEntry>? = null
        private set

    /** Bağlıyken uygulama seçimi değişti ama tünel henüz yenilenmedi. */
    var appsPending: Boolean = false
        private set

    fun loadApps() {
        host.loadApps { list -> apps = list; bump() }
    }

    fun setAppScope(scope: AppScope) = update { it.copy(appScope = scope) }

    fun toggleApp(pkg: String, on: Boolean) = update { it.copy(apps = if (on) it.apps + pkg else it.apps - pkg) }

    /** Değişikliği şimdi uygula: tünel yeniden kurulur. */
    fun applyAppsNow() {
        if (!appsPending) return
        appsPending = false
        if (vpn.state == OrbState.ON) { host.applyApps(); toast(Strings.APPLYING) }
        bump()
    }

    fun setLanguage(setting: String) = update { it.copy(lang = setting) }

    /** Dil platformdan değişti (ör. Android'in uygulama dili ayarı): sayfaları yeniden kur. */
    fun onLanguageChanged() { langSeq++; bump() }

    // ------------------------------------------------------------------ arka plan fotoğrafı

    fun pickWallpaper() = host.pickWallpaper()

    fun usePresetWallpaper(index: Int) = host.usePresetWallpaper(index)

    /** Seçici döndü: [ok] ise fotoğraf hazırlanıp kaydedilmiştir. */
    fun onWallpaperPicked(ok: Boolean) {
        if (ok) { update { it.copy(wallpaper = true, wpRev = it.wpRev + 1) }; toast(Strings.WP_SAVED) }
        else toast(Strings.WP_FAILED)
    }

    fun removeWallpaper() {
        host.removeWallpaper()
        update { it.copy(wallpaper = false) }
        toast(Strings.WP_REMOVED)
    }

    /** Ayar "var" diyor ama dosya yok/bozuk: ayarı sessizce kapat (kendini onarır). */
    fun onWallpaperMissing() { update { it.copy(wallpaper = false) } }

    // ------------------------------------------------------------------ uygulama simgesi

    /** Simge değişince ayar yalnızca platform değiştirebildiyse güncellenir (ayar ile gerçek durum ayrışmasın). */
    fun setAppIcon(style: UiStyle) {
        if (style == settings.appIcon) return
        if (host.setAppIcon(style)) { update { it.copy(appIcon = style) }; toast(Strings.ICON_SET) }
        else toast(Strings.ICON_FAILED)
    }

    fun exportSettings() {
        host.copyText(SettingsCodec.export(settings))
        toast(Strings.EXPORTED)
    }

    /**
     * Panodaki ayar kodunu yükler. Güvenliği etkileyen değişiklikler (şifrelemenin zayıflaması, otomatik bağlanma,
     * sunucu kuralları) mesajda ayrıca yazılır; "Geri al" önceki ayarları geri getirir.
     */
    fun importSettings() {
        val code = host.readClipboard()
        val next = if (code == null) null else SettingsCodec.import(code, settings)
        if (next == null) { toast(Strings.IMPORT_BAD); return }
        val before = settings
        update { next.copy(onboarded = it.onboarded, wasActive = it.wasActive, lastSeenVersion = it.lastSeenVersion) }
        val changes = ImportReview.changes(before, settings)
        val text = if (changes.isEmpty()) Strings.IMPORTED else Strings.importedWith(changes.joinToString(", ") { Strings.sensitive(it) })
        toast(text, Strings.UNDO) { undoImport(before) }
    }

    private fun undoImport(before: AppSettings) {
        // Servisin bu arada yazdığı istatistikler korunur; yalnızca kullanıcı ayarları geri alınır.
        val cur = settings
        update {
            before.copy(
                wasActive = cur.wasActive, totalQueries = cur.totalQueries, totalHits = cur.totalHits, totalBlocked = cur.totalBlocked,
                totalSeconds = cur.totalSeconds, daily = cur.daily, totalAnswered = cur.totalAnswered, totalLatencyMs = cur.totalLatencyMs,
                bytesUp = cur.bytesUp, bytesDown = cur.bytesDown, usage = cur.usage, sessions = cur.sessions,
                lastServer = cur.lastServer, recent = cur.recent,
            )
        }
    }

    /** Görünüm/bağlantı ayarlarını varsayılana döndürür; favoriler, onay ve istatistikler korunur. Onay mesajıyla çağrılır. */
    fun askResetSettings() = toast(Strings.CONFIRM, Strings.RESET) { resetSettings() }

    fun resetSettings() {
        val keep = settings
        update {
            AppSettings(
                lang = keep.lang, favorites = keep.favorites, recent = keep.recent, lastServer = keep.lastServer,
                onboarded = keep.onboarded, lastSeenVersion = keep.lastSeenVersion, wasActive = keep.wasActive, totalQueries = keep.totalQueries,
                totalHits = keep.totalHits, totalBlocked = keep.totalBlocked, totalSeconds = keep.totalSeconds, daily = keep.daily,
                totalAnswered = keep.totalAnswered, totalLatencyMs = keep.totalLatencyMs, bytesUp = keep.bytesUp, bytesDown = keep.bytesDown,
                usage = keep.usage, sessions = keep.sessions,
            )
        }
        toast(Strings.RESET_DONE)
    }

    fun askResetStats() = toast(Strings.CONFIRM, Strings.RESET) { resetStats() }

    fun resetStats() {
        host.resetTotals()
        settings = settings.copy(
            totalQueries = 0, totalHits = 0, totalBlocked = 0, totalSeconds = 0, daily = "",
            totalAnswered = 0, totalLatencyMs = 0, bytesUp = 0, bytesDown = 0, usage = "", sessions = "",
        )
        bump()
        toast(Strings.RESET_DONE)
    }

    fun copy(text: String) {
        host.copyText(text)
        toast(Strings.COPIED)
    }

    fun toast(text: String, action: String? = null, onAction: (() -> Unit)? = null) {
        if (text.isBlank()) return
        toast = ToastMsg(text, action, onAction)
        toastSeq++
        bump()
    }

    /** Platform ölçümün bittiğini bildirmezse dönen gösterge sonsuza dek sürmesin. Sahne her karede çağırır. */
    fun watchdog() {
        if (measuring && host.now() - measureStart > MEASURE_TIMEOUT_MS) onMeasureDone()
        if (testing && host.now() - testStart > TEST_TIMEOUT_MS) { testing = false; bump() }
        if (vpn.pausedUntil != 0L && !vpn.active && vpn.pausedUntil <= host.now() - PAUSE_GRACE_MS) {
            // Süre çoktan doldu ama servis hiç dönmedi (ör. sistem alarmı ertelendi ve servis yok): takılı kalma.
            vpn = vpn.copy(pausedUntil = 0L)
            bump()
        }
    }

    // ------------------------------------------------------------------ platformdan gelenler

    fun onVpn(v: VpnUi) {
        val old = vpn
        vpn = v
        if (v.state != OrbState.ON) appsPending = false       // yeni bağlantı güncel seçimi zaten kullanır
        if (!v.active || v.serverId == switchingTo) switchingTo = null
        if (v.state != old.state && settings.haptics && (v.state == OrbState.ON || v.state == OrbState.ERROR)) host.haptic(true)
        if (v.state == OrbState.ON && v.onBackup && !old.onBackup) toast(Strings.BACKUP)
        // Bağlıyken bir işlem (ör. sunucu değiştirme) başarısız olduysa servis nedenini bir kez bildirir.
        if (v.state == OrbState.ON && v.error != null && v.error != old.error) {
            toast(v.error)
            // İstenen sunucuya geçilemedi, eskisinde kalındı: seçim de eskisine döner (kesip yeniden bağlanınca o kullanılsın).
            val sid = v.serverId
            if (switchingTo != null && sid != null && sid != switchingTo) {
                switchingTo = null
                settings = settings.copy(lastServer = sid)
                host.saveSettings(settings)
            }
        }
        if (v.state == OrbState.ON && v.downgraded && !(old.state == OrbState.ON && old.downgraded)) toast(Strings.DOWNGRADED)
        if (v.state == OrbState.ON && old.state == OrbState.ON && old.downgraded && !v.downgraded) toast(Strings.UPGRADED)
        if (v.info != null && v.info != old.info) toast(v.info)
        // Servis sunucuyu kendisi değiştirdiyse (bildirimdeki "Sonraki", yedek sunucu, ağ kuralı) seçimi izle.
        val sid = v.serverId
        if (v.state == OrbState.ON && sid != null && sid != settings.lastServer && Catalog.byId(sid) != null && switchingTo == null) {
            settings = settings.copy(lastServer = sid).let { if (settings.keepHistory) it.withRecent(sid) else it }
        }
        bump()
    }

    fun onLatency(id: String, ms: Int?, loss: Int = 0) {
        if (Catalog.byId(id) == null) return
        latencies[id] = Latency(ms, host.now(), loss)
        if (settings.keepHistory) history = LatencyHistory.add(history, id, ms)
        if (measureRemaining > 0) measureRemaining--
        bump()
    }

    fun onMeasureDone() {
        if (!measuring) return
        measuring = false
        measureRemaining = 0
        host.saveLatencies(latencies)
        host.saveHistory(history)
        val best = fastestUsable()
        if (best == null) toast(Strings.NO_REPLY)
        else toast(Strings.fastest(best.first.name, best.second), Strings.CONNECT) { tapServer(best.first.id) }
        bump()
    }

    /** Depolamadan okunan ayarları (ör. servisin yazdığı toplamlar) modele al; yeniden kaydetmez. */
    fun replaceSettings(s: AppSettings) {
        if (s == settings) return
        settings = s
        bump()
    }

    // ------------------------------------------------------------------ gösterim yardımcıları

    fun latencyText(id: String): String? {
        val l = latencies[id] ?: return null
        return l.ms?.let { Format.ms(it) } ?: "—"
    }

    fun hitPercentTotal(): Int {
        val q = settings.totalQueries
        return if (q > 0) (settings.totalHits * 100 / q).toInt().coerceIn(0, 100) else 0
    }

    companion object {
        /** Aynı sunucuya art arda dokunmanın ikinci çağrı sayılmayacağı süre. */
        const val SWITCH_GRACE_MS = 2500L

        /** Tüm sunucuların ölçümü için üst süre. */
        const val MEASURE_TIMEOUT_MS = 60_000L

        /** Duraklatma bitince servisin yeniden bağlanmasını beklerken tanınan pay (sistem alarmı gecikebilir). */
        const val PAUSE_GRACE_MS = 30 * 60_000L

        /** Hızlı seçimdeki duraklatma süreleri (dakika). */
        val PAUSE_OPTIONS = listOf(5, 15, 30, 60, 120)

        /** Bağlantı testi için üst süre. */
        const val TEST_TIMEOUT_MS = 15_000L

        private const val DAY_MS = 24 * 3_600_000L

        /** "Neler yeni" duyurusunun ait olduğu sürüm: yükseldiğinde güncelleyen kullanıcıya bir kez gösterilir. */
        const val WHATS_NEW_VERSION = 20
        const val LIST_LIMIT = 8
        const val LIST_MIN_HIDDEN = 3
    }
}
