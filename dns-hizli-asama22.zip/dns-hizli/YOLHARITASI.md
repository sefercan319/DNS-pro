# Yol haritası

## Yapıldı
- Aşama 15 (v1.9.7): IPv4 + IPv6, gizlilik sertleştirmesi, DNS hata düzeltmeleri.
- Aşama 16 (v1.9.8): Y2K ve Metro yeniden çizildi, Frutiger Aurora eklendi (6 stil).
- Aşama 17 (v1.9.9): reklam, izleyici ve zararlı site engelleme (4 seviye, izin ve engel listesi, son engellenenler, sayaç).
- Aşama 18 (v1.9.10): ilk 8 sunucu + Tümünü göster / Daha az göster, Özel DNS ekle üstte, ince kaydırma çubuğu.
- Aşama 19 (v1.9.11): kalite ve güvenlik denetimi; sunucu değişiminde kesintisiz sınama, uzun yeniden deneme, olumsuz önbellek, AAB iş akışı.
- Aşama 22 (v1.9.14): kendi engelleme listeni içe/dışa aktar, bildirim sistemi (bağlandı/koptu/zaman aşımı/durdu) + ilk açılışta izin, sorgu gecikme grafiği, kapalı kalırsa dur.
- Aşama 21 (v1.9.13): kendi TCP katmanımız (DNS-over-TCP): "kesildi" sonrası TCP yeniden denemeleri karşılanır.
- Aşama 20 (v1.9.12): kendini onarma (kademeli), manifest denetim testi, mağaza metni 12 dil + Play beyanları.

## Sıradaki
1. **Arayüz düzeltmeleri:** bildirilen yeni hatalar (kalan arayüz sorunları).
2. **Telefonda deneme:** v1.9.11 servis değişiklikleri (sunucu değişimi, yeniden deneme) gerçek telefonda sınanmalı.
3. Kalan: benzersiz applicationId, kendi yayın anahtarın. (Yukarı akışa TCP, yani düz UDP yukarı akışta 1232 baytı aşan cevaplar, DPI başlığındaki genel TCP aktarmayla gelecek.)
4. Play Store: metin ve beyanlar hazır (`store/`); sende kalan: benzersiz kimlik, kendi anahtar, gizlilik politikası adresi, gerçek ekran görüntüleri, 14 gün test.
5. (İsteğe bağlı, düşük öncelik) `selftest/` testlerini Gradle'a bağlama (`src/test` ya da `sourceSets`), Android Studio ve CI'dan çalışsın diye. Şimdilik `run-tests.sh` yeterli.

## Gelecek planı (uzun, ayrı ana başlık)
- **DPI atlatma:** kendi yerel kodumuzla (dış kütüphane gömmeden), cihazda çalışır, kademeli ve deneysel, varsayılan kapalı.
  Aşamalar: (a) modüler tünel mimarisi ve "tüm trafiği geçir" anahtarı, (b) kendi TCP aktarma katmanımız (DNS için sunucu tarafı TCP Aşama 21'de yazıldı; genel aktarma onun üzerine kurulur), (c) atlatma yöntemleri
  ve gerçek telefonda deneme. DNS ve DPI ileride tek uygulamada birleşir.
- **Röle (IP gizleme):** sağlayıcının IP'nizi görmemesi için; güvenilir röle seçenekleri araştırılarak.
