package app.dnshizli.platform

import android.content.Context
import android.content.SharedPreferences
import app.dnshizli.core.AppSettings
import app.dnshizli.core.DailyStats
import app.dnshizli.core.Latency
import app.dnshizli.core.LatencyCodec
import app.dnshizli.core.LatencyHistory
import app.dnshizli.core.Session
import app.dnshizli.core.SessionLog
import app.dnshizli.core.SettingsCodec
import app.dnshizli.core.UsageStats

/**
 * Kalıcı depo: ayarlar ve gecikme ölçümleri SharedPreferences'ta düz metin olarak durur.
 * Etkinlik ve servis aynı süreçte çalışır; her biri kendi [PrefsStore] örneğini kullanabilir, ama oku-değiştir-yaz
 * işlemleri SÜREÇ GENELİNDE tek bir kilitle ([LOCK]) sıralanır. Yazma sahipliği ayrıdır:
 *  - Arayüz yalnızca kullanıcı ayarlarını yazar ([saveSettings] servis alanlarını atlar).
 *  - Servis durum ve toplamları yazar ([setWasActive], [addTotals], [addSession], [setPausedUntil]).
 *
 * Sağlamlık: bir anahtar beklenmedik türde saklanmışsa (ör. eski bir sürümün hatası) okuma çökmez, o değer
 * varsayılana düşer. Hiçbir okuma hatası uygulamanın açılmasını engellemez.
 */
class PrefsStore(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun str(k: String): String? = try { sp.getString(k, null) } catch (_: ClassCastException) { null }

    fun loadSettings(): AppSettings {
        val m = HashMap<String, String?>()
        for (k in KEYS) m[k] = str(k)
        for (k in SettingsCodec.LEGACY_KEYS) m[k] = str(k)
        return try {
            SettingsCodec.decode(m)
        } catch (_: RuntimeException) {
            AppSettings()                         // son çare: bozuk depo uygulamayı açılmaz hale getirmesin
        }
    }

    /** Kullanıcı ayarlarını yazar. Servisin sahip olduğu alanlar (durum, toplamlar) elle değiştirilmez. */
    fun saveSettings(s: AppSettings) {
        synchronized(LOCK) {
            val e = sp.edit()
            for ((k, v) in SettingsCodec.encode(s)) if (k !in SettingsCodec.SERVICE_KEYS) e.putString(k, v)
            for (k in SettingsCodec.LEGACY_KEYS) e.remove(k)      // taşındı, artık okunmasın
            e.apply()
        }
    }

    fun loadLatencies(): Map<String, Latency> = LatencyCodec.decode(str(LATENCIES))

    fun saveLatencies(m: Map<String, Latency>) {
        sp.edit().putString(LATENCIES, LatencyCodec.encode(m)).apply()
    }

    fun loadHistory(): Map<String, List<Int?>> = LatencyHistory.decode(str(HISTORY))

    fun saveHistory(h: Map<String, List<Int?>>) {
        sp.edit().putString(HISTORY, LatencyHistory.encode(h)).apply()
    }

    /** Servis: kendi değiştirdiği seçimi (bildirimdeki "Sonraki", yedek sunucu) yalnızca bu iki alana yazar. */
    fun setSelection(lastServer: String, recent: List<String>) {
        synchronized(LOCK) {
            sp.edit().putString("lastServer", lastServer).putString("recent", recent.joinToString(",")).apply()
        }
    }

    /** Servis: tünel açık mıydı? Süreç öldürülüp servis yeniden başlatılırsa bağlanmak için kullanılır. */
    fun setWasActive(v: Boolean) {
        sp.edit().putString("wasActive", v.toString()).apply()
    }

    /** Servis: kısa süreli duraklatmanın bitiş zamanı (epoch ms); 0 = duraklatılmamış. */
    fun pausedUntil(): Long = try { sp.getLong(PAUSED_UNTIL, 0L) } catch (_: ClassCastException) { 0L }

    fun setPausedUntil(t: Long) {
        sp.edit().putLong(PAUSED_UNTIL, t).apply()
    }

    /** Bildirim izni (Android 13+) bir kez istendi mi? İzin reddedilirse bir daha sorulmaz; uygulama izinsiz de çalışır. */
    fun askedNotifications(): Boolean = try { sp.getBoolean(ASKED_NOTIF, false) } catch (_: ClassCastException) { false }

    fun setAskedNotifications() {
        sp.edit().putBoolean(ASKED_NOTIF, true).apply()
    }

    /** İçe aktarılan engel listesindeki ad sayısı (listeyi okumadan göstermek için). */
    fun importedCount(): Int = try { sp.getInt(IMPORTED_COUNT, 0) } catch (_: ClassCastException) { 0 }

    fun setImportedCount(n: Int) {
        sp.edit().putInt(IMPORTED_COUNT, n).apply()
    }

    /** Android 13+: uygulama içi dil seçimi sistemin "uygulama dili" ayarına en az bir kez yazıldı mı? */
    fun localeSynced(): Boolean = try { sp.getBoolean(LOCALE_SYNCED, false) } catch (_: ClassCastException) { false }

    fun setLocaleSynced() {
        sp.edit().putBoolean(LOCALE_SYNCED, true).apply()
    }

    /** Son beklenmeyen çökmenin kısa özeti (tanılama raporu için; kişisel veri içermez). */
    fun lastCrash(): String? = str(LAST_CRASH)

    /** Çökme anında çağrılır: süreç birazdan biteceği için eşzamanlı yazılır. */
    fun setLastCrashNow(summary: String) {
        try { sp.edit().putString(LAST_CRASH, summary.take(600)).commit() } catch (_: Throwable) {}
    }

    /** Oturum boyunca biriken artışlar (servis, son aktarımdan bu yana farkları verir). */
    class Delta(
        val queries: Long = 0, val hits: Long = 0, val blocked: Long = 0, val seconds: Long = 0,
        val answered: Long = 0, val latencyMs: Long = 0, val bytesUp: Long = 0, val bytesDown: Long = 0,
    ) {
        val empty: Boolean get() = queries <= 0 && hits <= 0 && blocked <= 0 && seconds <= 0 && answered <= 0 && bytesUp <= 0 && bytesDown <= 0
    }

    /**
     * Servis: oturumun yeni sorgu, önbellek isabeti, engellenen, saniye, yanıt ve trafik sayılarını toplamlara;
     * sorguları bugünün sayısına, saniyeleri [serverId] sunucusunun kullanım süresine ekler.
     */
    fun addTotals(d: Delta, serverId: String?, nowMs: Long = System.currentTimeMillis()) {
        if (d.empty) return
        synchronized(LOCK) {
            val cur = loadSettings()
            fun p(v: Long) = maxOf(0L, v)
            sp.edit()
                .putString("totalQueries", (cur.totalQueries + p(d.queries)).toString())
                .putString("totalHits", (cur.totalHits + p(d.hits)).toString())
                .putString("totalBlocked", (cur.totalBlocked + p(d.blocked)).toString())
                .putString("totalSeconds", (cur.totalSeconds + p(d.seconds)).toString())
                .putString("totalAnswered", (cur.totalAnswered + p(d.answered)).toString())
                .putString("totalLatencyMs", (cur.totalLatencyMs + p(d.latencyMs)).toString())
                .putString("bytesUp", (cur.bytesUp + p(d.bytesUp)).toString())
                .putString("bytesDown", (cur.bytesDown + p(d.bytesDown)).toString())
                .putString("daily", DailyStats.add(cur.daily, DailyStats.today(nowMs), p(d.queries)))
                .putString("usage", if (cur.keepHistory) UsageStats.add(cur.usage, serverId, p(d.seconds)) else cur.usage)
                .apply()
        }
    }

    /** Servis: biten bir bağlantı oturumunu geçmişe ekler (en çok [SessionLog.KEEP]). */
    fun addSession(s: Session) {
        synchronized(LOCK) {
            val cur = loadSettings()
            if (!cur.keepHistory) return     // "Geçmişi tut" kapalı
            sp.edit().putString("sessions", SessionLog.add(cur.sessions, s)).apply()
        }
    }

    /** Kullanıcı istatistikleri sıfırladı. */
    fun resetTotals() {
        synchronized(LOCK) {
            val e = sp.edit()
            for (k in listOf("totalQueries", "totalHits", "totalBlocked", "totalSeconds", "totalAnswered", "totalLatencyMs", "bytesUp", "bytesDown")) {
                e.putString(k, "0")
            }
            e.putString("daily", "").putString("usage", "").putString("sessions", "").apply()
        }
    }

    companion object {
        private const val FILE = "dnshizli"
        private const val LATENCIES = "latencies"
        private const val HISTORY = "history"
        private const val ASKED_NOTIF = "askedNotif"
        private const val IMPORTED_COUNT = "importedCount"
        private const val PAUSED_UNTIL = "pausedUntil"
        private const val LOCALE_SYNCED = "localeSynced"
        private const val LAST_CRASH = "lastCrash"
        private val KEYS: Set<String> = SettingsCodec.encode(AppSettings()).keys

        /** Süreç genelinde tek kilit: etkinlik ve servis aynı dosyayı oku-değiştir-yaz ile güncellerken birbirini ezmesin. */
        private val LOCK = Any()
    }
}
