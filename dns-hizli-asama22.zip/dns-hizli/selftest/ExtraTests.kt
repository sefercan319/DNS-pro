package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*
import java.lang.management.ManagementFactory

private val mx3 = ManagementFactory.getThreadMXBean() as com.sun.management.ThreadMXBean

private fun has(r: Rig, text: String): Boolean = r.find(text) != null || runCatching { r.need(text) }.isSuccess

private fun shownTexts(r: Rig): List<String> = TextRecorder().also { r.scene.draw(it) }.runs.map { it.s }

/** Aşama 8: sorun giderici, sunucu arama, ölçüm paylaşımı, özel sunucu düzenleme, geçmişi tutma. */
fun testExtras() {
    T.group("Sorun giderici: mantık")
    run {
        val ok = NetCheck(true, true, false, PrivateDns.AUTO)
        val r0 = Troubleshoot.report(ok, false)
        T.check("hepsi tamam: özet + 4 satır, uyarı yok", r0.problems == 0 && r0.paragraphs.size == 5 && r0.paragraphs[0] == Strings.TROUBLE_ALL_OK && r0.paragraphs.drop(1).all { it.startsWith("• ") })
        val bad = Troubleshoot.report(NetCheck(false, false, true, PrivateDns.STRICT), false)
        T.check("dördü de sorunlu: 4 uyarı, '!' ile başlar", bad.problems == 4 && bad.paragraphs[0] == Strings.TROUBLE_SOME && bad.paragraphs.drop(1).all { it.startsWith("! ") })
        T.check("her uyarı kendi açıklamasını taşır", bad.paragraphs.any { it.contains(Strings.NET_BAD) } && bad.paragraphs.any { it.contains(Strings.PERM_BAD) } && bad.paragraphs.any { it.contains(Strings.VPN_BAD) } && bad.paragraphs.any { it.contains(Strings.PDNS_BAD) })
        val own = Troubleshoot.report(NetCheck(true, true, true, PrivateDns.OFF), true)
        T.check("kendi tünelimiz açıkken başka VPN denetlenmez", own.problems == 0 && own.paragraphs.none { it.contains(Strings.T_VPN) })
        val unk = Troubleshoot.report(NetCheck(null, null, null, null), false)
        T.check("okunamayan değerler gösterilmez, sorun sayılmaz", unk.problems == 0 && unk.paragraphs.size == 1)
        T.check("Özel DNS: kapalı ve otomatik tamam, yalnızca sabit sorunlu",
            listOf(PrivateDns.OFF, PrivateDns.AUTO, PrivateDns.STRICT).map { Troubleshoot.report(NetCheck(null, null, null, it), false).problems } == listOf(0, 0, 1))
    }

    T.group("Arama, paylaşım, ayar: mantık")
    run {
        T.check("arama metni temizlenir ve kısalır", ServerSearch.clean("  a   b  ") == "a b" && ServerSearch.clean("x".repeat(60)).length == ServerSearch.MAX)
        val cf = Catalog.byId("cloudflare")!!
        T.check("ad, sahip, adres ve şifreli ad içinde bulur, büyük/küçük harf ayırmaz",
            ServerSearch.matches(cf, "CLOUD") && ServerSearch.matches(cf, cf.owner!!.take(4).uppercase()) && ServerSearch.matches(cf, cf.primary) && cf.dot?.let { ServerSearch.matches(cf, it.take(6)) } != false)
        T.check("boş arama hepsini eşler, olmayan söz hiçbirini", ServerSearch.filter(Catalog.all, "  ").size == Catalog.all.size && ServerSearch.filter(Catalog.all, "zzzqqq").isEmpty())
        T.check("süzme sırayı korur", ServerSearch.filter(Catalog.all, "dns").map { it.id } == Catalog.all.filter { ServerSearch.matches(it, "dns") }.map { it.id })
        val lat = mapOf("cloudflare" to Latency(30, 0), "google" to Latency(12, 0), "quad9" to Latency(null, 0), "u1" to Latency(5, 0))
        val custom = DnsServer("u1", "Evim", null, "192.168.1.2", null, emptySet(), custom = true)
        val txt = ResultsText.build("BAŞLIK", Catalog.all + custom, lat)
        T.check("sonuç metni: en hızlıdan, numaralı, başarısız ve özel sunucu yok",
            txt != null && txt.lines()[0] == "BAŞLIK" && txt.lines()[1].startsWith("1. ") && txt.lines()[1].endsWith("— 12 ms") && txt.lines()[2].endsWith("— 30 ms") && txt.lines().size == 3 && !txt.contains("Evim"), txt ?: "")
        T.check("ölçüm yoksa metin yok", ResultsText.build("B", Catalog.all, emptyMap()) == null && ResultsText.build("B", Catalog.all, mapOf("quad9" to Latency(null, 0))) == null)
        T.check("geçmişi tut: varsayılan açık, kodlayıcı gidiş-dönüş, bozuk değer varsayılana düşer",
            AppSettings().keepHistory && !SettingsCodec.decode(SettingsCodec.encode(AppSettings(keepHistory = false))).keepHistory && SettingsCodec.decode(mapOf("keepHistory" to "x")).keepHistory)
        T.check("geçmişi tut dışa aktarılır", SettingsCodec.import(SettingsCodec.export(AppSettings(keepHistory = false)), AppSettings())?.keepHistory == false)
    }

    T.group("Sorun giderici: arayüz")
    run {
        val r = Rig(); r.scene.openSection(Section.DNS); r.settle(900)
        T.check("DNS ayarlarında Sorun gider satırı var", has(r, Strings.TROUBLE))
        r.tapText(Strings.TROUBLE, settleMs = 900)
        val t = shownTexts(r)
        T.check("tamam durumunda telefon okunur ve özet + 4 satır görünür", r.host.calls.contains("networkCheck") && t.any { Strings.TROUBLE_ALL_OK.startsWith(it.removeSuffix("…")) && it.length > 8 } && t.count { it.startsWith("• ") } >= 3, t.take(12).toString())
        r.host.net = NetCheck(true, false, true, PrivateDns.STRICT)
        val n = r.host.calls.count { it == "networkCheck" }
        r.tapText(Strings.TROUBLE_RECHECK, settleMs = 1000)
        val t2 = shownTexts(r)
        T.check("Yeniden denetle telefonu yeniden okur ve uyarıları gösterir", r.host.calls.count { it == "networkCheck" } == n + 1 && t2.count { it.startsWith("! ") } >= 3, t2.take(12).toString())
    }

    T.group("Sunucu arama: arayüz")
    run {
        val r = Rig()
        T.check("süzgeç satırının sonunda Ara çipi var, seçili değil", r.find(Strings.SEARCH, exact = true)?.info?.checked == false)
        r.tapText(Strings.SEARCH, exact = true, settleMs = 500)
        T.check("çip dokunuşu arama penceresini açar (boş başlangıç)", r.host.calls.contains("promptText") && r.host.lastTextInitial == "")
        r.host.textAnswer = "cloud"
        r.tapText(Strings.SEARCH, exact = true, settleMs = 900)
        val ids = r.model.visibleServers().map { it.id }
        T.check("liste aramaya göre süzülür", ids.isNotEmpty() && ids.all { id -> ServerSearch.matches(Catalog.byId(id)!!, "cloud") } && "cloudflare" in ids && "google" !in ids, ids.toString())
        T.check("çip aranan sözü gösterir ve seçilidir", r.find("“cloud”", exact = true)?.info?.checked == true)
        T.check("başlıktaki sayı süzülmüş sayıyı gösterir", r.find(Strings.serversCount(ids.size)) != null)
        r.host.textAnswer = null
        r.model.setFilter(Filter.FAVORITES); r.settle(600)
        T.check("süzgeçle birleşir: favoriler içinde arama", r.model.visibleServers().all { it.id in r.model.settings.favorites && ServerSearch.matches(it, "cloud") } && r.model.visibleServers().size == 1)
        r.model.setFilter(Filter.ALL)
        r.model.setQuery("zzzqqq"); r.settle(600)
        T.check("sonuç yoksa boş liste metni görünür", r.model.visibleServers().isEmpty() && shownTexts(r).contains(Strings.EMPTY_FILTER))
        r.host.textAnswer = ""
        r.tapText("“zzzqqq”", exact = true, settleMs = 500)
        T.check("pencerede mevcut söz başlangıçtır, boş cevap temizler", r.host.lastTextInitial == "zzzqqq" && r.model.query == "" && r.model.visibleServers().size == Catalog.all.size - r.model.settings.hidden.size)
        T.check("çip yine Ara olur", r.find(Strings.SEARCH, exact = true)?.info?.checked == false)
        r.model.setQuery("cloud"); r.model.update { it.copy(minimal = true) }; r.settle(600)
        T.check("sade görünümde arama uygulanmaz (süzgeçler gibi gizli)", r.model.visibleServers().size > 1 && r.model.effectiveQuery == "")
    }
    run {
        // uzun arama sözü: çip yazısı kısalır, satırda üst üste binen yazı yok, her stilde çizim geçerli
        val g = CountingGfx()
        for (st in UiStyle.values()) {
            val r = Rig(Rig.base().copy(style = st)); r.model.setQuery("x".repeat(24)); r.settle(600)
            val rec = TextRecorder().also { r.scene.draw(it) }
            val chip = rec.runs.firstOrNull { it.s.startsWith("“") }
            T.check("${st.label}: uzun arama sözü kısalır ve çipler üst üste binmez", chip != null && chip.s.length <= 14 && rec.overlaps().none { (a, b) -> a === chip || b === chip }, chip?.s ?: "")
            g.reset(); r.scene.draw(g)
            T.check("${st.label}: arama açıkken çizim geçerli", g.bad == 0 && !g.underflow && g.depth == 0)
        }
    }
    run {
        val r = Rig(); r.model.setQuery("cloud"); r.settle(600)
        val g = CountingGfx()
        repeat(150) { r.host.now += 16; r.scene.tick(r.host.now); g.reset(); r.scene.draw(g) }
        val before = mx3.getThreadAllocatedBytes(Thread.currentThread().id)
        repeat(300) { r.host.now += 16; r.scene.tick(r.host.now); g.reset(); r.scene.draw(g) }
        val per = (mx3.getThreadAllocatedBytes(Thread.currentThread().id) - before) / 300.0
        T.check("arama açıkken kare başına ≤96 bayt", per <= 96.0, "%.1f".format(per))
    }

    T.group("Ölçüm sonuçlarını paylaş: arayüz")
    run {
        val r = Rig(); r.scene.openSection(Section.STATS); r.settle(900)
        T.check("İstatistikler ve geçmiş penceresinde Ölçüm sonuçlarını paylaş satırı var", has(r, Strings.SHARE_RESULTS))
        r.tapText(Strings.SHARE_RESULTS, settleMs = 600)
        val s = r.host.shared
        T.check("paylaşılan metin başlıkla başlar, en hızlı sunucu ilk sırada", s != null && s.startsWith(Strings.SHARE_RESULTS_HEAD + "\n1. ") && s.lines()[1].contains("— 18 ms"), s ?: "")
    }
    run {
        val r = Rig(latencies = emptyMap()); r.scene.openSection(Section.STATS); r.settle(900)
        r.tapText(Strings.SHARE_RESULTS, settleMs = 600)
        T.check("ölçüm yoksa paylaşılmaz, uyarı çıkar", r.host.shared == null && shownTexts(r).contains(Strings.NO_RESULTS))
    }

    T.group("Özel sunucuyu düzenle")
    try {
        val r = Rig()
        r.host.customDraft = CustomDns.Draft("Evim", "192.168.1.2", "", "dns.example.com", "")
        r.model.promptCustom()
        val s = Catalog.custom.single()
        r.model.latencies[s.id] = Latency(40, r.host.now)
        r.scene.openDetails(s); r.settle(700)
        T.check("özel sunucunun ayrıntısında Düzenle düğmesi var", r.find(Strings.CUSTOM_EDIT, exact = true) != null)
        r.host.customDraft = CustomDns.Draft("Evim 2", "192.168.1.3", "192.168.1.4", "", "https://dns.example.com/q")
        r.tapText(Strings.CUSTOM_EDIT, exact = true, settleMs = 700)
        val i = r.host.lastInitial
        T.check("pencere mevcut değerlerle açılır, ayrıntı paneli kapanır", i != null && i.name == "Evim" && i.ip1 == "192.168.1.2" && i.dot == "dns.example.com" && !r.scene.hasSheet)
        val e = Catalog.custom.single()
        T.check("aynı kimlikle güncellenir, ayara yazılır", e.id == s.id && e.name == "Evim 2" && e.primary == "192.168.1.3" && e.secondary == "192.168.1.4" && e.doh == "https://dns.example.com/q" && e.dot == null && r.model.settings.custom.contains("Evim 2"))
        T.check("eski ölçüm silinir, bildirim çıkar", r.model.latencies[s.id] == null && r.model.toast?.text == Strings.customUpdated("Evim 2"))
        r.host.customDraft = CustomDns.Draft("x", "bozuk", "", "", "")
        r.model.editCustom(s.id)
        T.check("geçersiz düzenleme hata verir, değişmez", r.host.customError == Strings.CUSTOM_ERR_IP && Catalog.custom.single().name == "Evim 2")
        r.model.commitEdit(s.id, CustomDns.Draft("x", "bozuk", "", "", ""))
        T.check("geçersiz girdi doğrudan da uygulanmaz", Catalog.custom.single().name == "Evim 2")
        r.model.onVpn(VpnUi(OrbState.ON, s.id, r.host.now, 0, 0, 20)); r.settle(300)
        val before = r.host.calls.count { it == "promptCustom" }
        r.model.editCustom(s.id)
        T.check("bağlıyken düzenlenmez", r.host.calls.count { it == "promptCustom" } == before && r.model.toast?.text == Strings.CUSTOM_IN_USE)
        r.model.onVpn(VpnUi(OrbState.OFF)); r.settle(300)
        for (k in 1 until CustomDns.MAX) r.model.commitCustom(CustomDns.Draft("S$k", "192.168.5.$k", "", "", ""))
        T.check("sınır dolu olsa da düzenlenebilir", Catalog.custom.size == CustomDns.MAX && run { r.host.customDraft = CustomDns.Draft("Evim 3", "192.168.1.9", "", "", ""); r.model.editCustom(s.id); Catalog.byId(s.id)?.name == "Evim 3" })
        r.scene.openDetails(Catalog.byId("quad9")!!); r.settle(700)
        T.check("hazır sunucuda Düzenle yok", r.find(Strings.CUSTOM_EDIT, exact = true) == null)
    } finally { Catalog.setCustom(emptyList()) }

    T.group("Geçmişi tutma")
    run {
        val on = Rig(); on.model.update { it.copy(recent = emptyList()) }
        on.model.onVpn(VpnUi(OrbState.ON, "google", on.host.now, 0, 0, 20)); on.model.onLatency("google", 15)
        T.check("açıkken: son kullanılanlara eklenir, ölçüm geçmişi yazılır", "google" in on.model.settings.recent && on.model.history["google"] == listOf(15))
        val off = Rig(Rig.base().copy(keepHistory = false, recent = emptyList()))
        off.model.onVpn(VpnUi(OrbState.ON, "google", off.host.now, 0, 0, 20)); off.model.onLatency("google", 15)
        T.check("kapalıyken: son kullanılanlar ve ölçüm geçmişi yazılmaz", off.model.settings.recent.isEmpty() && off.model.history["google"] == null)
        T.check("kapalıyken bile son sunucu ve anlık ölçüm tutulur (sıralama/hatırlama bozulmaz)", off.model.settings.lastServer == "google" && off.model.latencies["google"]?.ms == 15)
        val r = Rig(); r.scene.openSection(Section.STATS); r.settle(900)
        T.check("istatistikler ve geçmiş penceresinde Geçmişi tut anahtarı var ve açık", r.need(Strings.KEEP_HISTORY).let { it.info.role == Role.SWITCH && it.info.checked == true })
    }

    T.group("Aşama 8: her dilde metinler")
    val saved = L.lang
    try {
        for (lang in Lang.values()) {
            L.set(lang)
            val all = listOf(Strings.TROUBLE, Strings.TROUBLE_RECHECK, Strings.TROUBLE_ALL_OK, Strings.TROUBLE_SOME, Strings.T_NET, Strings.NET_OK, Strings.NET_BAD, Strings.T_PERM, Strings.PERM_OK, Strings.PERM_BAD,
                Strings.T_VPN, Strings.VPN_OK, Strings.VPN_BAD, Strings.T_DNS, Strings.PDNS_OK, Strings.PDNS_BAD, Strings.SEARCH, Strings.SEARCH_HINT, Strings.SEARCH_CLEAR,
                Strings.SHARE_RESULTS, Strings.SHARE_RESULTS_HEAD, Strings.NO_RESULTS, Strings.CUSTOM_EDIT, Strings.KEEP_HISTORY, Strings.KEEP_HISTORY_NOTE)
            T.check("${lang.native}: 25 metin dolu ve makul uzunlukta", all.all { it.isNotBlank() && it.length <= 190 }, all.filter { it.isBlank() || it.length > 190 }.toString())
            T.check("${lang.native}: arama çipi ve düğme adları kısa", Strings.SEARCH.length in 2..14 && Strings.CUSTOM_EDIT.length in 2..16 && Strings.SEARCH_CLEAR.length in 2..16 && Strings.TROUBLE_RECHECK.length in 4..24)
            T.check("${lang.native}: güncellendi bildirimi ad içerir", Strings.customUpdated("Evim").contains("Evim"))
            val rep = Troubleshoot.report(NetCheck(false, false, true, PrivateDns.STRICT), false)
            T.check("${lang.native}: sorun giderici raporu 5 paragraf", rep.paragraphs.size == 5 && rep.paragraphs.all { it.length > 10 })
            T.check("${lang.native}: yenilikler ilk maddesi", Strings.WHATS_NEW_ITEMS.first().length in 40..170, Strings.WHATS_NEW_ITEMS.first().length.toString())
        }
    } finally { L.set(saved) }
}
