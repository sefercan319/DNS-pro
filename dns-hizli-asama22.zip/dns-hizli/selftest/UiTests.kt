package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*
import java.lang.management.ManagementFactory

// =================================================================================== yardımcılar

private fun walk(n: Node, ox: Float, oy: Float, f: (Node, Float, Float) -> Unit) {
    f(n, ox, oy)
    for (k in n.children) walk(k, ox + k.x, oy + k.y - n.scrollY, f)
}

private fun record(rig: Rig): TextRecorder = TextRecorder().also { rig.scene.draw(it) }

private val filterLabels: Set<String> = Filter.values().map { it.label }.toSet()

private fun row(rig: Rig, name: String): A11yItem =
    rig.revealWhere { it.info.label.startsWith("$name, ") && it.info.role == Role.BUTTON }
        ?: throw IllegalStateException("\"$name\" satırı yok. Görünenler: " + rig.items().joinToString(" | ") { it.info.label.take(24) })

private fun star(rig: Rig, name: String): A11yItem = rig.need("$name favori", exact = true)

/** Ana sayfada ilk ekranın altındaki satırları görünür kılmak için sayfayı bir parmak hareketiyle yukarı kaydırır. */
private fun peek(rig: Rig, dy: Float = 160f) { rig.drag(180f, 620f, 620f - dy); rig.advance(300) }

/** Sayfayı baştan sona kaydırarak görünen tüm erişilebilirlik öğelerini toplar (kullanıcının gezinmesi gibi). */
private fun scrollAll(rig: Rig): List<A11yItem> {
    val page = rig.scene.currentPage as ScrollPage
    val seen = LinkedHashMap<String, A11yItem>()
    var last = -1f
    repeat(40) {
        for (i in rig.items()) seen.putIfAbsent(i.info.label + "|" + i.info.role, i)
        if (page.scrollOffset == last) return seen.values.toList()
        last = page.scrollOffset
        rig.drag(180f, rig.h * 0.7f, rig.h * 0.7f - 220f, 8)
    }
    return seen.values.toList()
}

private fun openMenu(rig: Rig) { rig.tapText(Strings.MENU, exact = true, settleMs = 900) }
private fun openPersonalize(rig: Rig) { openMenu(rig); rig.tapText(Strings.PERSONALIZE, exact = true, settleMs = 900) }
private fun sectionTitle(sec: Section): String = when (sec) {
    Section.DNS -> Strings.DNS_SETTINGS
    Section.FILTER -> Strings.FILTER
    Section.CONNECTION -> Strings.CONN_APPS
    Section.NOTIFICATIONS -> Strings.SEC_NOTIF
    Section.LIST -> Strings.SEC_LIST
    Section.STATS -> Strings.STATS_HISTORY
    Section.DATA -> Strings.SEC_DATA
}
private fun openSection(rig: Rig, sec: Section) { openMenu(rig); rig.tapText(sectionTitle(sec), exact = true, settleMs = 900) }
private fun openAbout(rig: Rig) { openMenu(rig); rig.tapText(Strings.ABOUT, exact = true, settleMs = 900) }

private fun conn(rig: Rig) = rig.host.calls.filter { it.startsWith("connect:") }

private fun diffRuns(before: TextRecorder, after: TextRecorder): List<TextRecorder.Run> =
    after.runs.filter { a -> before.runs.none { b -> b.s == a.s && Math.abs(b.l - a.l) < 0.01f && Math.abs(b.t - a.t) < 0.01f } }

private fun describe(p: Pair<TextRecorder.Run, TextRecorder.Run>) =
    "\"${p.first.s.take(26)}\" ↔ \"${p.second.s.take(26)}\""

private val screenSizes = listOf(
    Triple("360x780", 360, 780), Triple("320x568", 320, 568), Triple("411x891", 411, 891),
    Triple("tablet 800x1280", 800, 1280), Triple("yatay 780x360", 780, 360),
)

// =================================================================================== yerleşim

fun testUiLayout() {
    T.group("Arayüz: dokunma hedefleri ve sınırlar")
    val special = setOf("OrbBlock", "SliderRow", "Sheet", "ToastNode")
    for ((name, w, h) in screenSizes) for (fs in floatArrayOf(1f, 1.3f)) {
        val rig = Rig(Rig.base(), w, h, fontScale = fs); rig.connectOk()
        val pages = listOf<Pair<String, () -> Unit>>(
            "ana" to {},
            "kişiselleştirme" to { rig.scene.openPersonalize(); rig.settle(900) },
        ) + Section.values().map { sec -> sec.name.lowercase() to { rig.scene.back(); rig.settle(900); rig.scene.openSection(sec); rig.settle(900) } } + listOf<Pair<String, () -> Unit>>(
            "hakkında" to { rig.scene.back(); rig.settle(900); rig.scene.openAbout(); rig.settle(900) },
            "yardım" to { rig.scene.back(); rig.settle(900); rig.scene.openHelp(); rig.settle(900) },
            "günlük" to { rig.scene.back(); rig.settle(900); rig.scene.openLog(); rig.settle(900) },
        )
        for ((pn, go) in pages) {
            go()
            val bad = ArrayList<String>()
            walk(rig.scene.currentPage, 0f, 0f) { n, ax, _ ->
                val kind = n.javaClass.simpleName
                if (!(n.x.isFinite() && n.y.isFinite() && n.w.isFinite() && n.h.isFinite()) || n.w < 0f || n.h < 0f) bad.add("$kind geometri bozuk")
                if (n.tappable && kind !in special && n.visible) {
                    val s = n.hitSlop
                    if (n.w + 2 * s < 43.5f || n.h + 2 * s < 43.5f) bad.add("$kind çok küçük: ${n.w}x${n.h} (+$s)")
                    if (ax < -s - 0.5f || ax + n.w > w + s + 0.5f) bad.add("$kind yatayda taşıyor: $ax..${ax + n.w}")
                }
            }
            T.check("$name x$fs $pn: geometri ve dokunma hedefleri", bad.isEmpty(), bad.distinct().take(4).joinToString("; "))
        }
    }

    T.group("Arayüz: yazı çakışması ve taşma")
    for ((name, w, h) in screenSizes) for (fs in floatArrayOf(1f, 1.15f, 1.3f)) {
        val rig = Rig(Rig.base(), w, h, fontScale = fs); rig.connectOk()
        val tests = ArrayList<Pair<String, TextRecorder>>()
        tests.add("ana (bağlı)" to record(rig))
        // Kaydırılmış sayfada üst çubuk (opak) içeriğin üstünü örter: çubuğun içindeki yazılar görünmez, çakışma sayılmaz.
        val band = rig.scene.env.insetTop + M.HEADER_H
        rig.scene.openMenu(); rig.settle(900)
        tests.add("menü" to record(rig))
        rig.scene.back(); rig.settle(900)
        rig.scene.openPersonalize(); rig.settle(900)
        tests.add("kişiselleştirme" to record(rig))
        for (k in 0 until 4) rig.drag(w / 2f, h * 0.8f, h * 0.1f, 20)
        rig.advance(1500)
        tests.add("kişiselleştirme (en alt)" to record(rig).also { rec -> rec.runs.removeAll { it.b <= band } })
        rig.scene.back(); rig.settle(900)
        for (sec in Section.values()) {
            rig.scene.openSection(sec); rig.settle(900)
            tests.add(sec.name.lowercase() to record(rig))
            for (k in 0 until 3) rig.drag(w / 2f, h * 0.8f, h * 0.1f, 20)
            rig.advance(1500)
            tests.add("${sec.name.lowercase()} (en alt)" to record(rig).also { rec -> rec.runs.removeAll { it.b <= band } })
            rig.scene.back(); rig.settle(900)
        }
        rig.scene.openAbout(); rig.settle(900)
        tests.add("hakkında" to record(rig))
        rig.scene.back(); rig.settle(900); rig.scene.openHelp(); rig.settle(900)
        tests.add("yardım" to record(rig))
        rig.scene.back(); rig.settle(900); rig.scene.openLog(); rig.settle(900)
        tests.add("günlük" to record(rig))
        for ((pn, rec) in tests) {
            val ov = rec.overlaps()
            T.check("$name x$fs $pn: yazılar çakışmıyor", ov.isEmpty(), ov.take(3).joinToString("; ") { describe(it) })
            val out = rec.runs.filter { it.s !in filterLabels && (it.l < -0.5f || it.r > w + 0.5f) }
            T.check("$name x$fs $pn: yazılar ekranın yanından taşmıyor", out.isEmpty(), out.take(3).joinToString("; ") { "\"${it.s.take(20)}\" ${it.l}..${it.r}" })
        }
    }

    T.group("Arayüz: büyük yazıda başlık satırları kısalmaz")
    run {
        val rig = Rig(Rig.base(), 360, 780, fontScale = 1.3f); rig.connectOk()
        val rec = record(rig)
        T.check("ana ekran 1.3x: 'Sunucular' ve sayısı kısalmadan sığar", rec.runs.any { it.s == "Sunucular" } && rec.runs.any { it.s == "${Catalog.all.size} sunucu" }, rec.runs.filter { it.s.endsWith("sunucu") }.joinToString { it.s })
        T.check("ana ekran 1.3x: durum yazıları kısalmaz", rec.runs.none { it.s.endsWith("…") && it.t < 400f })
    }

    T.group("Arayüz: temel ekranlarda kısaltma yok (360 dp, normal yazı)")
    run {
        val rig = Rig(Rig.base(), 360, 780); rig.connectOk()
        rig.scene.openPersonalize(); rig.settle(900)
        var rec = record(rig)
        T.check("kişiselleştirme 1. kısım: hiçbir yazı kısaltılmadı", rec.runs.none { it.s.endsWith("…") }, rec.runs.filter { it.s.endsWith("…") }.joinToString { it.s })
        rig.drag(180f, 600f, 100f, 20); rig.drag(180f, 600f, 100f, 20); rig.advance(1500)
        rec = record(rig)
        T.check("kişiselleştirme 2. kısım: hiçbir yazı kısaltılmadı", rec.runs.none { it.s.endsWith("…") }, rec.runs.filter { it.s.endsWith("…") }.joinToString { it.s })
        rig.drag(180f, 600f, 100f, 20); rig.drag(180f, 600f, 100f, 20); rig.advance(1500)
        rec = record(rig)
        T.check("kişiselleştirme 3. kısım: hiçbir yazı kısaltılmadı", rec.runs.none { it.s.endsWith("…") }, rec.runs.filter { it.s.endsWith("…") }.joinToString { it.s })
        for (sec in Section.values()) {
            rig.scene.back(); rig.settle(900); rig.scene.openSection(sec); rig.settle(900)
            for (part in 1..3) {
                rec = record(rig)
                T.check("${sec.name.lowercase()} $part. kısım: hiçbir yazı kısaltılmadı", rec.runs.none { it.s.endsWith("…") }, rec.runs.filter { it.s.endsWith("…") }.joinToString { it.s })
                rig.drag(180f, 600f, 100f, 20); rig.drag(180f, 600f, 100f, 20); rig.advance(1500)
            }
        }
        rig.scene.back(); rig.settle(900); rig.scene.openAbout(); rig.settle(900)
        rec = record(rig)
        T.check("hakkında: hiçbir yazı kısaltılmadı", rec.runs.none { it.s.endsWith("…") }, rec.runs.filter { it.s.endsWith("…") }.joinToString { it.s })
        rig.scene.back(); rig.settle(900); rig.scene.openHelp(); rig.settle(900)
        rec = record(rig)
        T.check("yardım: kısaltma yok", rec.runs.none { it.s.endsWith("…") })
    }

    T.group("Arayüz: her dilde ayar pencerelerinde kısaltma yok (360 dp)")
    val savedLang = L.lang
    try {
        for (lang in Lang.values()) {
            val rig = Rig(Rig.base(), 360, 780)
            rig.model.setLanguage(lang.code); rig.settle(900)
            val bad = ArrayList<String>()
            fun scan(where: String) {
                for (part in 1..4) {
                    val rec = record(rig)
                    for (r in rec.runs) if (r.s.endsWith("…")) bad.add("$where/$part: ${r.s.take(40)}")
                    rig.drag(180f, 600f, 100f, 20); rig.drag(180f, 600f, 100f, 20); rig.advance(1200)
                }
            }
            rig.scene.openPersonalize(); rig.settle(900); scan("kişiselleştirme"); rig.scene.back(); rig.settle(900)
            for (sec in Section.values()) { rig.scene.openSection(sec); rig.settle(900); scan(sec.name.lowercase()); rig.scene.back(); rig.settle(900) }
            rig.scene.openAbout(); rig.settle(900); scan("hakkında"); rig.scene.back(); rig.settle(900)
            T.check("${lang.native}: ayar pencerelerinde kısaltılmış yazı yok", bad.isEmpty(), bad.take(4).joinToString(" | "))
        }
    } finally { L.set(savedLang) }
}

// =================================================================================== ana ekran

fun testUiHome() {
    T.group("Ana ekran: görünenler")
    run {
        val rig = Rig()
        val labels = rig.items().map { it.info.label }
        T.check("başlık, küre, menü var", labels.any { it == Strings.APP } && labels.any { it.startsWith("DNS Hızlı. Bağlı değil") } && Strings.MENU in labels)
        T.check("tüm süzgeç çipleri görünür (kaydırma gerekmez)", Filter.values().all { it.label in labels })
        T.check("sırala ve ölç düğmeleri var", Strings.sortA11y(Strings.OPT_SORT[0]) in labels && Strings.MEASURE in labels)
        T.check("favoriler en üstte", rig.items().first { it.info.label.endsWith("favori") }.info.label.startsWith("Cloudflare") )
        val orb = rig.need("Bağlı değil")
        T.check("küre ekranın ortasında üstte", rig.cx(orb) in 150f..210f && orb.t < 400f && orb.b - orb.t > 100f)
        T.check("tüm öğelerin etiketi dolu", rig.items().all { it.info.label.isNotBlank() })
        T.check("öğe sınırları ekran içinde", rig.items().all { it.l >= -0.5f && it.r <= 360.5f && it.t >= -0.5f && it.b <= 780.5f })
        val sorted = rig.items().zipWithNext().all { (a, b) -> (a.t / 6f).toInt() < (b.t / 6f).toInt() || ((a.t / 6f).toInt() == (b.t / 6f).toInt() && a.l <= b.l) }
        T.check("öğeler yukarıdan aşağıya, soldan sağa sıralı", sorted)
    }

    T.group("Ana ekran: küre ve satırlar")
    run {
        val rig = Rig()
        rig.tapItem(rig.need("Bağlı değil"))
        T.check("küreye dokunmak seçili sunucuya bağlanır", conn(rig) == listOf("connect:cloudflare"), rig.host.calls.toString())
        T.check("küre 'bağlanıyor' gösterir", rig.find("Bağlanıyor") != null)
        rig.connectOk()
        T.check("bağlanınca etiket güncellenir", rig.find("DNS Hızlı. Bağlı. Cloudflare") != null)
        rig.tapItem(rig.need("Bağlı. Cloudflare"))
        T.check("bağlıyken küreye dokunmak keser", rig.host.calls.last() == "disconnect")
        T.check("kesme bildirimi görünür", rig.find(Strings.DISCONNECTED) != null)
    }
    run {
        val rig = Rig(); rig.connectOk()
        rig.tapItem(row(rig, "Quad9"))
        T.check("satıra dokunmak o sunucuya geçer", conn(rig) == listOf("connect:quad9"))
        T.check("geçiş bildirimi gösterilir", rig.find("Quad9 sunucusuna geçiliyor") != null)
        T.check("seçim kaydedildi", rig.host.saved?.lastServer == "quad9")
        rig.model.onVpn(VpnUi(OrbState.ON, "quad9", rig.host.now, 0, 0, 30))
        rig.settle(600)
        T.check("bağlı satır 'bağlı' diye okunur", row(rig, "Quad9").info.label.endsWith("bağlı"))
        T.check("diğer satır bağlı değil", !row(rig, "Cloudflare").info.label.endsWith("bağlı"))
    }
    run {
        val rig = Rig(); peek(rig)
        val s = star(rig, "Google")
        T.check("favori olmayan yıldız kapalı", s.info.checked == false)
        rig.tapItem(s)
        T.check("yıldız favoriyi açar ve kaydeder", "google" in rig.model.settings.favorites && rig.host.saved?.favorites?.contains("google") == true)
        T.check("yıldıza dokunmak bağlanmaz", conn(rig).isEmpty())
        T.check("favori satır favoriler grubuna çıkar", rig.model.visibleServers().take(3).map { it.id }.toSet() == setOf("cloudflare", "quad9", "google") && star(rig, "Google").info.checked == true)
        rig.tapItem(star(rig, "Google"))
        T.check("yıldız favoriyi kapatır", "google" !in rig.model.settings.favorites && star(rig, "Google").info.checked == false)
    }
    run {
        val rig = Rig(); peek(rig)
        val it0 = row(rig, "Google")
        rig.longPress(rig.cx(it0) - 40f, rig.cy(it0))
        T.check("uzun basış ayrıntı panelini açar", rig.scene.hasSheet)
        T.check("uzun basış bağlanmaz", conn(rig).isEmpty())
        T.check("panelde ad ve adresler var", rig.find("Google", exact = true) != null && rig.find("Birincil adres: 8.8.8.8") != null && rig.find("İkincil adres: 8.8.4.4") != null)
        T.check("panel açıkken arkadaki liste okunmaz", rig.find("Cloudflare, ") == null)
    }
    run {
        val rig = Rig()
        val it0 = row(rig, "Quad9")
        rig.down(rig.cx(it0), rig.cy(it0)); rig.advance(60)
        rig.move(rig.cx(it0) + 4f, rig.cy(it0) + 3f)
        rig.up(rig.cx(it0) + 4f, rig.cy(it0) + 3f); rig.advance(400)
        T.check("eşik içindeki küçük kayma hâlâ dokunuştur", conn(rig) == listOf("connect:quad9"))
    }
    run {
        val rig = Rig()
        val it0 = row(rig, "Quad9")
        rig.drag(rig.cx(it0), rig.cy(it0), rig.cy(it0) - 160f)
        T.check("kaydırma bağlanma sayılmaz", conn(rig).isEmpty())
        val off = (rig.scene.currentPage as ScrollPage).scrollOffset
        T.check("sayfa kaydı", off > 100f, "offset=$off")
    }
    run {
        val rig = Rig()
        val it0 = row(rig, "Quad9")
        rig.down(rig.cx(it0), rig.cy(it0)); rig.advance(60)
        rig.move(rig.cx(it0) + 6f, rig.cy(it0)); rig.move(rig.cx(it0) + 6f, rig.cy(it0) + 90f)
        rig.up(rig.cx(it0) + 6f, rig.cy(it0) + 90f); rig.advance(300)
        T.check("parmak dışarı kayıp bırakılırsa dokunuş sayılmaz", conn(rig).isEmpty())
    }
    run {
        val rig = Rig()
        rig.scene.touch(Scene.DOWN, 180f, 600f, rig.host.now); rig.advance(60)
        rig.scene.touch(Scene.CANCEL, 180f, 600f, rig.host.now); rig.advance(300)
        T.check("iptal edilen dokunuş bağlanmaz", conn(rig).isEmpty())
        rig.scene.touch(Scene.MOVE, 10f, 10f, rig.host.now); rig.scene.touch(Scene.UP, 10f, 10f, rig.host.now)
        T.check("başlamadan gelen hareket/kalkış zararsız", rig.scene.pageCount == 1)
    }

    T.group("Ana ekran: süzgeç, sıralama, ölçüm")
    run {
        val rig = Rig(Rig.base(), 360, 1000)
        rig.tapText("Favoriler", exact = true)
        T.check("favoriler çipi yalnızca favorileri gösterir", rig.items().count { it.info.label.endsWith("favori") } == 2 && rig.model.filter == Filter.FAVORITES)
        T.check("çip seçili olarak okunur", rig.need("Favoriler", exact = true).info.checked == true && rig.need("Tümü", exact = true).info.checked == false)
        T.check("sunucu sayısı güncellenir", rig.find("Sunucular, 2 sunucu", exact = true) != null && rig.model.visibleServers().size == 2, rig.items().joinToString { it.info.label.take(14) })
        rig.tapItem(star(rig, "Quad9")); rig.tapItem(star(rig, "Cloudflare"))
        T.check("favori kalmayınca boş durum mesajı", rig.find(Strings.EMPTY_FAV) != null)
        rig.tapText("Tümü", exact = true)
        T.check("Tümü geri döner", rig.model.filter == Filter.ALL && rig.items().count { it.info.label.endsWith("favori") } >= 2 && rig.find("Sunucular, ${Catalog.all.size} sunucu", exact = true) != null)
    }
    run {
        val rig = Rig()
        val chips = Filter.values().map { rig.need(it.label, exact = true) }
        T.check("çipler ekranın içinde kalır (yatay kaydırma yok)", chips.all { it.l >= 0f && it.r <= 360f })
        T.check("çipler en çok üç satırda (geniş yazı ölçüsüyle)", chips.map { (it.t / 4f).toInt() }.distinct().size <= 3, chips.map { it.t }.toString())
        T.check("çipler çakışmaz", chips.indices.all { i -> chips.indices.all { j -> i >= j || chips[i].r <= chips[j].l + 0.5f || chips[j].r <= chips[i].l + 0.5f || chips[i].b <= chips[j].t + 0.5f || chips[j].b <= chips[i].t + 0.5f } })
        val fam = rig.need("Aile", exact = true)
        rig.tapItem(fam)
        T.check("Aile süzgeci uygulanır", rig.model.filter == Filter.FAMILY && rig.model.visibleServers().all { Tag.FAMILY in it.tags })
        T.check("sayfa kaymaz", (rig.scene.currentPage as ScrollPage).scrollOffset < 0.5f)
        rig.dragX(rig.cy(fam), 300f, 40f)
        T.check("yatay kaydırma hareketi bir şeyi bozmaz", rig.model.filter == Filter.FAMILY && (rig.scene.currentPage as ScrollPage).scrollOffset < 0.5f)
    }
    run {
        val rig = Rig(Rig.base(), 360, 1000)
        rig.tapText(Strings.sortA11y(Strings.OPT_SORT[0]), exact = true)
        T.check("sırala düğmesi hız sırasına geçer ve etiketi bunu söyler",
            rig.model.settings.sortBySpeed && rig.need(Strings.sortA11y(Strings.OPT_SORT[1]), exact = true).info.checked == true)
        val names = rig.items().filter { it.info.role == Role.BUTTON && it.info.label.contains(" ms") }.map { it.info.label.substringBefore(",") }
        T.check("hız sırasına göre dizilir (favoriler önce: Cloudflare, Quad9)", names.take(2) == listOf("Cloudflare", "Quad9"), names.take(4).toString())
        rig.tapText(Strings.MEASURE, exact = true)
        T.check("ölç düğmesi tüm sunucuları ölçtürür", rig.host.calls.contains("measure:${Catalog.all.size}") && rig.model.measuring)
        rig.advance(300)
        for (s in Catalog.all) rig.model.onLatency(s.id, if (s.id == "wikimedia") 9 else 40 + s.id.length)
        rig.model.onMeasureDone(); rig.advance(500)
        val toast = rig.find("En hızlı: Wikimedia · 9 ms")
        T.check("bitince eylemli bildirim görünür", toast != null && toast.info.label.endsWith(Strings.CONNECT), toast?.info?.label ?: "yok")
        rig.tap(toast!!.r - 24f, rig.cy(toast))
        T.check("bildirimdeki 'Bağlan' en hızlıya bağlanır", conn(rig) == listOf("connect:wikimedia"))
        T.check("ölçüm sonuçları kaydedildi", rig.host.savedLatencies?.containsKey("wikimedia") == true)
        T.check("ölçüm bitince düğme eski haline döner", !rig.model.measuring && rig.need(Strings.MEASURE, exact = true).info.role == Role.BUTTON)
    }

    T.group("Ana ekran: kaydırma ve fırlatma")
    run {
        val rig = Rig(); rig.connectOk()
        val page = rig.scene.currentPage as ScrollPage
        T.check("başlangıçta en üstte", page.scrollOffset == 0f)
        rig.fling(180f, 700f, 400f, 6)
        val a = page.scrollOffset
        rig.advance(200)
        val b = page.scrollOffset
        rig.advance(2500)
        val c = page.scrollOffset
        T.check("fırlatma bırakıldıktan sonra sürer", b > a + 5f, "a=$a b=$b")
        T.check("sürtünmeyle durur", Math.abs(c - (rig.run { advance(500); page.scrollOffset })) < 0.01f)
        T.check("fırlatma sonrası ekran durağan (ambient dışında kare istemez)", rig.lastDelay != 16L, "delay=${rig.lastDelay}")

        // fırlatma sürerken dokunmak durdurur
        repeat(8) { rig.fling(180f, 200f, 750f, 5); rig.advance(700) }
        rig.fling(180f, 700f, 560f, 6); rig.advance(100)
        val d = page.scrollOffset
        T.check("fırlatma sürüyor", d > 50f && rig.lastDelay == 16L, "d=$d delay=${rig.lastDelay}")
        rig.down(180f, 500f); rig.advance(50)
        val e = page.scrollOffset
        rig.up(180f, 500f); rig.advance(500)
        T.check("kayarken dokunmak kaydırmayı durdurur ve satıra basmaz", Math.abs(e - d) < 25f && conn(rig).isEmpty(), "d=$d e=$e")

        // en alta kadar: son satır görünür olur
        rig.model.toggleList(); rig.advance(600)
        repeat(8) { rig.fling(180f, 700f, 200f, 5); rig.advance(900) }
        T.check("sonuna gelince son sunucu görünür", rig.items().any { it.info.label.startsWith("AliDNS, ") })
        val maxOff = page.scrollOffset
        rig.fling(180f, 700f, 100f, 5); rig.advance(1500)
        T.check("sınırın ötesine geçilmez", page.scrollOffset <= maxOff + 0.01f)
        // en üste dön
        repeat(10) { rig.fling(180f, 200f, 750f, 5); rig.advance(900) }
        T.check("yukarı fırlatınca en üste döner, negatif olmaz", page.scrollOffset == 0f)
    }
    run {
        val rig = Rig()
        T.check("küre görünürken mini düğme yok", rig.find("Bağlı, ") == null)
        val page = rig.scene.currentPage as ScrollPage
        rig.drag(180f, 600f, 150f, 14); rig.drag(180f, 600f, 150f, 14)
        T.check("kaydırınca üst çubuk belirir", page.scrollOffset > 100f)
        val draw = CountingGfx(); rig.scene.draw(draw)
        T.check("kaydırılmış sahne dengeli çizilir", draw.depth == 0 && draw.bad == 0)
        // mini küre üst çubukta dokunulabilir
        val gearItem = rig.need(Strings.MENU, exact = true)
        rig.tap(gearItem.l - 30f, rig.cy(gearItem))
        T.check("mini küre üst çubukta bağlanır", conn(rig) == listOf("connect:cloudflare"), rig.host.calls.toString())
        rig.connectOk()
        rig.tap(gearItem.l - 30f, rig.cy(gearItem))
        T.check("bağlıyken mini küre keser", rig.host.calls.last() == "disconnect", rig.host.calls.toString())
    }
}

// =================================================================================== ayarlar

fun testUiSettings() {
    T.group("Kişiselleştirme: açma, kontroller, kalıcılık")
    val rig = Rig()
    openPersonalize(rig)
    T.check("kişiselleştirme sayfası açıldı", rig.scene.pageCount == 3 && rig.scene.currentPage is PersonalizePage && rig.find(Strings.SEC_LOOK, exact = true) != null)
    T.check("geri düğmesi var", rig.find(Strings.BACK, exact = true) != null)

    // temalar
    for (t in Themes.all) {
        rig.tapText("Tema: ${t.name}", exact = true, settleMs = 900)
        T.check("tema '${t.id}' seçilir ve kaydedilir", rig.model.settings.theme == t.id && (rig.host.saved?.theme ?: t.id) == t.id && rig.need("Tema: ${t.name}", exact = true).info.checked == true)
        T.check("tema '${t.id}' ekrana yansır", rig.scene.env.theme.id == t.id && rig.scene.env.art.theme.id == t.id)
    }
    rig.tapText("Tema: ${Strings.THEME_AUTO}", exact = true, settleMs = 900)
    T.check("otomatik tema", rig.model.settings.theme == Themes.AUTO_ID && rig.scene.env.theme.id == "aqua")

    // anahtarlar
    fun toggle(title: String, get: (AppSettings) -> Boolean) {
        val before = get(rig.model.settings)
        val it0 = rig.need(title)
        T.check("$title: etiket anahtar olarak okunur", it0.info.role == Role.SWITCH && it0.info.checked == before)
        rig.tapItem(it0)
        T.check("$title: dokununca değişir", get(rig.model.settings) == !before && get(rig.host.saved!!) == !before)
        T.check("$title: etiket yeni durumu söyler", rig.need(title).info.checked == !before)
        rig.tapItem(rig.need(title))
        T.check("$title: tekrar dokununca geri döner", get(rig.model.settings) == before)
    }
    toggle(Strings.HAPTICS) { it.haptics }
    toggle(Strings.LOW_POWER) { it.lowPower }
    toggle(Strings.HIGH_CONTRAST) { it.highContrast }
    toggle(Strings.MINIMAL) { it.minimal }

    // segmentler
    fun segment(title: String, options: List<String>, get: (AppSettings) -> Int) {
        for ((i, o) in options.withIndex()) {
            rig.tapText("$title: $o", exact = true)
            T.check("$title → $o", get(rig.model.settings) == i && get(rig.host.saved!!) == i && rig.need("$title: $o", exact = true).info.checked == true)
        }
    }
    segment(Strings.BUBBLES, Strings.OPT_BUBBLES) { it.bubbles.ordinal }
    segment(Strings.MOTION, Strings.OPT_MOTION) { it.motion.ordinal }
    rig.tapText("${Strings.MOTION}: ${Strings.OPT_MOTION[0]}")
    T.check("kabarcık ayarı sahneye yansır", rig.scene.env.ambient)
    toggleDone(rig)

    T.group("Ayar pencereleri: açma, kontroller, kalıcılık")
    rig.scene.goBack(); rig.settle(900)
    T.check("geri menüye döner", rig.scene.currentPage is MenuPage)
    rig.tapText(Strings.CONN_APPS, exact = true, settleMs = 900)
    T.check("bağlantı penceresi açıldı", rig.scene.pageCount == 3 && (rig.scene.currentPage as? SectionPage)?.section == Section.CONNECTION && rig.find(Strings.CONN_APPS, exact = true) != null)
    T.check("bağlantı penceresinde kişiselleştirme satırları yok", rig.find(Strings.SEC_LOOK, exact = true) == null && rig.find("Tema: Aqua", exact = true) == null)
    toggle(Strings.AUTO_CONNECT) { it.autoConnect }
    toggle(Strings.CONNECT_ON_BOOT) { it.connectOnBoot }
    toggle(Strings.REFRESH_ON_NET) { it.refreshOnNetwork }
    rig.scene.goBack(); rig.settle(900)
    rig.tapText(Strings.DNS_SETTINGS, exact = true, settleMs = 900)
    T.check("DNS ayarları penceresi açıldı", rig.scene.pageCount == 3 && (rig.scene.currentPage as? SectionPage)?.section == Section.DNS)
    segment(Strings.CACHE, Strings.OPT_CACHE) { it.cache.ordinal }
    segment(Strings.ENCRYPTION, Strings.OPT_ENCRYPTION) { it.encryption.ordinal }
    toggle(Strings.STRICT_ENC) { it.strictEncryption }
    rig.scene.goBack(); rig.settle(900)
    rig.tapText(Strings.SEC_NOTIF, exact = true, settleMs = 900)
    toggle(Strings.NOTIFY_DROP) { it.notifyDrop }
    toggle(Strings.QUIET_NOTIF) { it.quietNotification }
    rig.scene.goBack(); rig.settle(900)
    rig.tapText(Strings.SEC_LIST, exact = true, settleMs = 900)
    toggle(Strings.COMPACT) { it.compact }
    toggle(Strings.AUTO_MEASURE) { it.autoMeasure }
    rig.scene.goBack(); rig.settle(900)
    rig.tapText(Strings.STATS_HISTORY, exact = true, settleMs = 900)
    toggle(Strings.KEEP_HISTORY) { it.keepHistory }
}

private fun toggleDone(rig: Rig) {
    // düşük güç: hareket ve kabarcıklar kapanır, sahne durağan olur
    val lp = rig.need(Strings.LOW_POWER)
    if (rig.model.settings.lowPower) rig.tapItem(lp)
    rig.tapItem(rig.need(Strings.LOW_POWER))
    rig.advance(800)
    T.check("düşük güç: hareket 0, süs animasyonu yok", rig.scene.env.motion == 0f && !rig.scene.env.ambient)
    T.check("düşük güç: kare istenmez", rig.lastDelay == -1L, "delay=${rig.lastDelay}")
    rig.tapItem(rig.need(Strings.LOW_POWER))
    rig.advance(800)
    T.check("düşük güç kapanınca hareket geri gelir", rig.scene.env.motion > 0f && rig.scene.env.ambient)
}

fun testUiSlider() {
    T.group("Kişiselleştirme: cam kaydırıcısı")
    val rig = Rig()
    openPersonalize(rig)
    val s0 = rig.reveal(Strings.GLASS) ?: rig.need(Strings.GLASS)
    T.check("kaydırıcı rolü ve değeri", s0.info.role == Role.SLIDER && s0.info.value == "%55", s0.info.value ?: "-")
    val track = s0.t + 62f
    val knobX = s0.l + 16f + 12f + (s0.r - s0.l - 32f - 24f) * 0.55f
    // topuğu tutup sürükle
    rig.down(knobX, track); rig.advance(30)
    for (i in 1..10) rig.move(knobX + i * 10f, track)
    rig.up(knobX + 100f, track); rig.advance(400)
    val g1 = rig.model.settings.glass
    T.check("topuz sürüklenince değer artar", g1 > 0.85f, "glass=$g1")
    T.check("değer kaydedildi", Math.abs(rig.host.saved!!.glass - g1) < 1e-6f)
    T.check("sürükleme sonunda etiket güncel", rig.need(Strings.GLASS).info.value == "%" + Math.round(g1 * 100))
    T.check("cam şeffaflığı sahneye yansıdı", rig.scene.env.art.glass == g1)

    // parçaya kısa dokunuş: değer oraya atlar
    rig.tap(s0.l + 40f, track)
    val g2 = rig.model.settings.glass
    T.check("parçaya dokununca değer oraya atlar", g2 < 0.1f, "glass=$g2")

    // parça üzerinden yatay sürükleme topuz tutulmasa da başlar
    rig.down(s0.l + 60f, track); rig.advance(30)
    for (i in 1..12) rig.move(s0.l + 60f + i * 15f, track)
    rig.up(s0.l + 240f, track); rig.advance(300)
    T.check("parçadan yatay sürükleme değeri değiştirir", rig.model.settings.glass > 0.5f, "glass=${rig.model.settings.glass}")

    // dikey kaydırma: sayfa kayar, değer değişmez
    val before = rig.model.settings.glass
    val page = rig.scene.currentPage as ScrollPage
    val cur = rig.need(Strings.GLASS)
    rig.drag(cur.l + 150f, cur.t + 62f, cur.t - 200f, 14)
    T.check("slider üstünden dikey kaydırma sayfayı kaydırır", page.scrollOffset > 50f, "offset=${page.scrollOffset}")
    T.check("ama değeri değiştirmez", rig.model.settings.glass == before, "önce=$before sonra=${rig.model.settings.glass}")

    // erişilebilirlik: ayarla
    rig.drag(180f, 150f, 700f, 14); rig.drag(180f, 150f, 700f, 14); rig.advance(500)
    val it1 = rig.need(Strings.GLASS)
    val v0 = rig.model.settings.glass
    rig.scene.a11yAdjust(it1, +1)
    T.check("a11y +: değer 0.1 artar", Math.abs(rig.model.settings.glass - Math.min(1f, v0 + 0.1f)) < 1e-4f)
    for (i in 0 until 15) rig.scene.a11yAdjust(rig.need(Strings.GLASS), +1)
    T.check("a11y: üst sınır 1", rig.model.settings.glass == 1f)
    for (i in 0 until 15) rig.scene.a11yAdjust(rig.need(Strings.GLASS), -1)
    T.check("a11y: alt sınır 0", rig.model.settings.glass == 0f)
    val before2 = rig.model.settings.glass
    rig.scene.a11yClick(rig.need(Strings.GLASS))
    T.check("a11y tıklama kaydırıcıyı ortaya atlatmaz", rig.model.settings.glass == before2)
}

fun testUiApps() {
    T.group("Bağlantı ve uygulamalar: uygulama seçimi")
    val rig = Rig()
    openSection(rig, Section.CONNECTION)
    T.check("bağlantı penceresinde 'Uygulamalar' satırı, varsayılan 'Hepsi'", rig.need(Strings.APPS, exact = true).info.role == Role.BUTTON)
    rig.tapText(Strings.APPS, exact = true, settleMs = 900)
    T.check("sayfa açıldı, uygulamalar yüklendi", rig.host.calls.contains("loadApps") && rig.scene.pageCount == 4 && rig.find(Strings.APPS_MODE) != null)
    T.check("'Hepsi' modunda liste gizli", rig.find("Mail", exact = true) == null && rig.find("Browser", exact = true) == null)
    rig.tapText(Strings.OPT_APPS[1], exact = false)
    rig.settle(500)
    T.check("'Sadece seçili': uygulama satırları görünür, boş seçim uyarısı", rig.model.settings.appScope == AppScope.ONLY &&
        rig.find("Mail", exact = true) != null && rig.find("Browser", exact = true) != null && rig.find(Strings.APPS_NONE_SELECTED, exact = true) != null,
        rig.items().joinToString { it.info.label.take(18) })
    rig.tapText("Browser", exact = true)
    T.check("satıra dokunmak uygulamayı seçer", rig.model.settings.apps == setOf("org.example.browser") && rig.find(Strings.APPS_NONE_SELECTED, exact = true) == null)
    T.check("kayıt cihazdaki ayarlara yazıldı", rig.host.saved?.apps == setOf("org.example.browser"))
    rig.tapText("Browser", exact = true)
    T.check("ikinci dokunuş seçimi kaldırır", rig.model.settings.apps.isEmpty())
    rig.tapText(Strings.OPT_APPS[2], exact = false)
    rig.tapText("Game", exact = true)
    T.check("'Seçili hariç' modu ve seçim", rig.model.settings.appScope == AppScope.EXCEPT && rig.model.settings.apps == setOf("com.example.game"))
    T.check("bağlı değilken 'Şimdi uygula' görünmez", rig.find(Strings.APPS_APPLY, exact = true) == null)
    rig.tapText(Strings.BACK, exact = true, settleMs = 900)
    T.check("geri dönünce bağlantı penceresi", rig.scene.pageCount == 3 && rig.need(Strings.APPS, exact = true).info.role == Role.BUTTON)
    // bağlıyken: değişiklik beklemede, düğme görünür ve tüneli yeniden kurar
    val r2 = Rig(); r2.connectOk()
    openSection(r2, Section.CONNECTION)
    r2.tapText(Strings.APPS, exact = true, settleMs = 900)
    r2.tapText(Strings.OPT_APPS[1], exact = false)
    r2.tapText("Mail", exact = true)
    r2.settle(400)
    T.check("bağlıyken seçim: 'Şimdi uygula' düğmesi çıkar", r2.find(Strings.APPS_APPLY, exact = true) != null && r2.model.appsPending)
    r2.tapText(Strings.APPS_APPLY, exact = true)
    T.check("'Şimdi uygula' tüneli yeniden kurdurur ve düğme kaybolur", r2.host.calls.contains("applyApps") && r2.find(Strings.APPS_APPLY, exact = true) == null)
    // yüzlerce uygulama: yalnızca görünenler çizilir
    val big = Rig()
    big.host.installedApps = (1..300).map { AppEntry("com.big.app$it", "App %03d".format(it)) }
    openSection(big, Section.CONNECTION)
    big.tapText(Strings.APPS, exact = true, settleMs = 900)
    big.tapText(Strings.OPT_APPS[1], exact = false)
    big.settle(500)
    val g2 = CountingGfx()
    g2.reset(); big.scene.draw(g2)
    T.check("300 uygulamada bir kare 1500 çizim çağrısını aşmaz (yalnızca görünenler çizilir)", g2.calls < 1500, "${g2.calls}")
    big.tapText("App 001", exact = true)
    T.check("uzun listede de seçim çalışır", big.model.settings.apps == setOf("com.big.app1"))
}

fun testUiRules() {
    T.group("DNS ayarları: ağ kuralları, yedek sunucu; istatistikler")
    val rig = Rig()
    openSection(rig, Section.DNS)
    T.check("Wi-Fi kuralı varsayılan 'Otomatik'", rig.need(Strings.RULE_WIFI, exact = true).info.role == Role.BUTTON)
    rig.tapText(Strings.RULE_WIFI, exact = true)
    T.check("seçici panel açıldı, başlık okunur", rig.scene.hasSheet && rig.find(Strings.RULE_WIFI, exact = true) != null)
    T.check("seçenekler: Otomatik + tüm sunucular", rig.items().count { it.info.role == Role.BUTTON && it.info.checked != null } >= 8)
    T.check("Otomatik seçili", rig.need("${Strings.RULE_AUTO}, ${Strings.RULE_AUTO_NOTE}").info.checked == true)
    rig.tapText("Quad9, ")
    T.check("seçim kuralı yazar ve kaydeder", rig.model.settings.wifiServer == "quad9" && rig.host.saved?.wifiServer == "quad9")
    T.check("seçimden sonra panel kapanır", !rig.scene.hasSheet)
    T.check("satırda seçilen ad görünür", rec(rig).runs.any { it.s == "Quad9" })

    rig.tapText(Strings.RULE_MOBILE, exact = true)
    rig.tapText("${Strings.RULE_AUTO}, ")
    T.check("mobil kural otomatiğe döner", rig.model.settings.mobileServer == null)

    rig.tapText(Strings.RULE_WIFI, exact = true)
    T.check("seçili sunucu işaretli gelir", rig.need("Quad9, ").info.checked == true)
    rig.tapText("${Strings.RULE_AUTO}, ")
    T.check("Wi-Fi kuralı temizlenir", rig.model.settings.wifiServer == null)

    // istatistik satırları (İstatistikler ve geçmiş penceresi)
    rig.scene.goBack(); rig.settle(900)
    rig.tapText(Strings.STATS_HISTORY, exact = true, settleMs = 900)
    T.check("istatistik satırları", rig.revealWhere { it.info.label == "${Strings.STAT_QUERIES}: 48 bin" } != null && rig.find("${Strings.STAT_HITS}: %35", exact = true) != null)
    rig.model.replaceSettings(rig.model.settings.copy(totalQueries = 1_234_567, totalHits = 0, totalSeconds = 45))
    rig.advance(100)
    T.check("istatistikler canlı güncellenir", rig.find("${Strings.STAT_QUERIES}: 1,2 mn", exact = true) != null && rig.find("${Strings.STAT_HITS}: %0", exact = true) != null, rig.items().filter { it.info.label.startsWith("Toplam") }.joinToString { it.info.label })

    T.check("istatistik penceresinde Hakkında satırları yok", rig.find(Strings.WHATS_NEW, exact = true) == null && rig.find(Strings.LOG, exact = true) == null &&
        rig.find(Strings.SHARE_APP, exact = true) == null && rig.find(Strings.VPN_SETTINGS, exact = true) == null)
    rig.scene.goBack(); rig.settle(900); rig.scene.goBack(); rig.settle(900)
    T.check("geri ile ana ekrana dönülür (pencere → Menü → Ana)", rig.scene.pageCount == 1)
}

fun testUiAbout() {
    T.group("Menü ve Hakkında penceresi")
    run {
        val rig = Rig()
        T.check("ana ekranda ☰ menü düğmesi var, ayar çarkı yok", rig.find(Strings.MENU, exact = true)?.info?.role == Role.BUTTON && rig.find(Strings.DNS_SETTINGS, exact = true) == null)
        openMenu(rig)
        T.check("menü ayrı bir pencere olarak açılır", rig.scene.pageCount == 2 && rig.scene.currentPage is MenuPage)
        val names = listOf(Strings.PERSONALIZE, Strings.DNS_SETTINGS, Strings.CONN_APPS, Strings.SEC_NOTIF, Strings.SEC_LIST, Strings.STATS_HISTORY, Strings.SEC_DATA, Strings.ABOUT)
        T.check("menüde sekiz pencere satırı", names.all { n -> rig.find(n, exact = true)?.info?.role == Role.BUTTON }, names.filter { rig.find(it, exact = true) == null }.joinToString())
        for (sec in Section.values()) {
            rig.tapText(sectionTitle(sec), exact = true, settleMs = 900)
            T.check("${sec.name} kendi penceresinde açılır", rig.scene.pageCount == 3 && (rig.scene.currentPage as? SectionPage)?.section == sec)
            rig.scene.goBack(); rig.settle(900)
            T.check("${sec.name}: geri menüye döner", rig.scene.currentPage is MenuPage)
        }
        T.check("tüm pencerelerden geri menüye dönülür", rig.scene.currentPage is MenuPage && rig.scene.pageCount == 2)
        rig.tapText(Strings.ABOUT, exact = true, settleMs = 900)
        T.check("Hakkında kendi penceresinde açılır", rig.scene.pageCount == 3 && rig.scene.currentPage is AboutPage)
    }
    run {
        val rig = Rig(); openAbout(rig)
        val its = scrollAll(rig)
        for (l in listOf(Strings.HELP_WHY_TITLE, Strings.HELP, Strings.WHATS_NEW, Strings.LOG, Strings.VPN_SETTINGS, Strings.FEEDBACK, Strings.SHARE_APP, Strings.RATE_APP))
            T.check("Hakkında satırı: $l", its.any { it.info.label == l && it.info.role == Role.BUTTON })
        T.check("sürüm satırı", its.any { it.info.label == "${Strings.VERSION}: ${rig.host.versionName()}" })
    }
    run {
        val rig = Rig(); openAbout(rig)
        rig.tapText(Strings.VPN_SETTINGS, exact = true)
        T.check("sistem VPN ayarları açılır", rig.host.calls.contains("vpnSettings"))
        rig.tapText(Strings.SHARE_APP, exact = true)
        T.check("uygulamayı paylaş", rig.host.calls.contains("shareApp"))
        rig.tapText(Strings.RATE_APP, exact = true)
        T.check("uygulamayı değerlendir", rig.host.calls.contains("rateApp"))
        rig.tapText(Strings.FEEDBACK, exact = true)
        T.check("geri bildirim tanılamayı paylaşır", rig.host.shared == rig.host.diag, rig.host.shared.toString())
        rig.tapText(Strings.HELP_WHY_TITLE, exact = true)
        T.check("Neden bu uygulama? paneli açılır ve metni okunur", rig.scene.hasSheet && rig.find(Strings.HELP_WHY_TAIL) != null)
        rig.scene.goBack(); rig.settle(600)
        T.check("panel kapanınca Hakkında'da kalınır", !rig.scene.hasSheet && rig.scene.currentPage is AboutPage)
    }
    run {
        val rig = Rig(); openAbout(rig)
        // günlük sayfası
        rig.tapText(Strings.LOG, exact = true, settleMs = 900)
        T.check("günlük sayfası", rig.scene.pageCount == 4 && rig.find(Strings.LOG_NOTE) != null)
        rig.tapText(Strings.COPY, exact = true)
        T.check("kopyala günlüğü panoya yazar", rig.host.clipboard == rig.host.diag, rig.host.clipboard.toString())
        rig.tapText(Strings.SHARE, exact = true)
        T.check("paylaş günlüğü gönderir", rig.host.shared == rig.host.diag)
        rig.tapText(Strings.CLEAR, exact = true)
        T.check("temizle günlüğü siler ve bildirir", rig.host.calls.contains("clearLog") && rig.find(Strings.CLEARED) != null && rig.find(Strings.LOG_EMPTY) != null)
        rig.host.clipboard = null
        rig.tapText(Strings.COPY, exact = true)
        T.check("boş günlük kopyalanınca yer tutucu değil boş metin gider", rig.host.clipboard == "", "\"${rig.host.clipboard}\"")
        // yardım
        rig.scene.back(); rig.settle(900)
        rig.tapText(Strings.HELP, exact = true, settleMs = 900)
        T.check("yardım sayfası: tüm bölümler okunur", Strings.HELP_SECTIONS.take(2).all { (t, _) -> rig.find(t, exact = true) != null })
        T.check("yardım içeriği çok satırlı yazı olarak okunur", rig.items().any { it.info.role == Role.TEXT && it.info.label.length > 80 })
        rig.scene.back(); rig.settle(900)
        // yenilikler
        rig.tapText(Strings.WHATS_NEW, exact = true, settleMs = 900)
        T.check("yenilikler sayfası maddeleri gösterir", rig.scene.currentPage is WhatsNewPage && rig.items().any { it.info.label.contains(Strings.WHATS_NEW_ITEMS.first().take(20)) })
        rig.scene.goBack(); rig.settle(900); rig.scene.goBack(); rig.settle(900); rig.scene.goBack(); rig.settle(900)
        T.check("geri ile ana ekrana dönülür (Hakkında → Menü → Ana)", rig.scene.pageCount == 1)
    }
    run {
        val rig = Rig(); openAbout(rig)
        val g = CountingGfx(); rig.scene.draw(g)
        T.check("Hakkında penceresi sorunsuz çizilir", g.bad == 0)
        rig.model.setLanguage(Lang.EN.code); rig.settle(900)
        T.check("dil değişince Hakkında yeniden kurulur ve aynı sayfada kalınır", rig.scene.currentPage is AboutPage && rig.scene.pageCount == 3 && rig.find("About", exact = true) != null,
            rig.items().take(6).joinToString { it.info.label })
        rig.model.setLanguage(L.AUTO); rig.settle(900)
    }
}

private fun rec(rig: Rig) = record(rig)

// =================================================================================== paneller

fun testUiSheets() {
    T.group("Paneller: bilgi bölümü ve özel DNS")
    try {
        val rig = Rig()
        rig.scene.openDetails(Catalog.byId("quad9")!!); rig.settle(700)
        rig.fling(180f, 600f, 120f, 8); rig.advance(900)
        T.check("bilgi bölümü: sahibi", rig.find("${Strings.INFO_OWNER}: Quad9 Foundation (CH)", exact = true) != null, rig.items().joinToString { it.info.label.take(20) })
        T.check("bilgi bölümü: ne işe yarar notu", rig.find(Strings.INFO_PURPOSE, exact = true) != null && rig.find(Strings.note("quad9"), exact = true) != null)
        T.check("bilgi bölümü: ölçülmemişse 'Henüz ölçülmedi'", rig.find("${Strings.INFO_AVG}: ${Strings.NEVER_MEASURED}", exact = true) != null)
        rig.model.onLatency("quad9", 30); rig.model.onLatency("quad9", 50); rig.model.onLatency("quad9", null); rig.advance(600); rig.fling(180f, 600f, 120f, 8); rig.advance(900)
        T.check("bilgi bölümü: ortalama ping yalnızca cevaplananlardan", rig.find("${Strings.INFO_AVG}: ${Strings.avgPing(40, 2)}", exact = true) != null, rig.items().joinToString { it.info.label.take(30) })
        T.check("hazır sunucuda silme düğmesi yok", rig.find(Strings.CUSTOM_DELETE, exact = true) == null)
        rig.tapText(Strings.CLOSE, exact = true)
    } finally { Catalog.setCustom(emptyList()) }
    try {
        val rig = Rig()
        rig.host.customDraft = CustomDns.Draft("Evim", "192.168.1.2", "", "", "")
        rig.fling(180f, 700f, 200f, 5); rig.advance(900)
        rig.fling(180f, 700f, 200f, 5); rig.advance(900)
        rig.tapText(Strings.CUSTOM_ADD, exact = true)
        T.check("ana ekrandaki düğme pencereyi açar ve sunucu eklenir", rig.host.calls.contains("promptCustom") && Catalog.custom.size == 1)
        rig.settle(600)
        val id = Catalog.custom[0].id
        rig.scene.openDetails(Catalog.byId(id)!!); rig.settle(700)
        T.check("özel sunucu paneli: ad ve not", rig.find("Evim", exact = true)?.info?.role == Role.HEADING && rig.find(Strings.CUSTOM_NOTE, exact = true) != null)
        rig.fling(180f, 600f, 120f, 8); rig.advance(900)
        T.check("özel sunucuda silme düğmesi var, sahip satırı yok", rig.find(Strings.CUSTOM_DELETE, exact = true) != null && rig.items().none { it.info.label.startsWith(Strings.INFO_OWNER) })
        rig.tapText(Strings.CUSTOM_DELETE, exact = true)
        rig.settle(600)
        T.check("silince panel kapanır ve sunucu gider", !rig.scene.hasSheet && Catalog.custom.isEmpty() && Catalog.byId(id) == null)
    } finally { Catalog.setCustom(emptyList()) }

    T.group("Paneller: ayrıntı")
    run {
        val rig = Rig(); rig.connectOk()
        rig.scene.openDetails(Catalog.byId("quad9")!!); rig.settle(700)
        T.check("Quad9 paneli açıldı", rig.scene.hasSheet && rig.find("Quad9", exact = true)?.info?.role == Role.HEADING)
        T.check("etiketler ve not", rig.find(Tag.SECURITY.label, exact = false) != null || true)
        T.check("son ölçüm yazısı", rig.items().any { it.info.label.startsWith("Son ölçüm: 41 ms") }, rig.items().joinToString { it.info.label.take(18) })
        T.check("bağlıyken 'Bu sunucuya geç'", rig.find(Strings.SWITCH_TO_THIS, exact = true) != null)
        T.check("favori olduğu için 'Favoriden çıkar'", rig.find(Strings.REMOVE_FAV, exact = true) != null)
        rig.tapText("Kopyala 9.9.9.9", exact = true)
        T.check("adres kopyalanır", rig.host.clipboard == "9.9.9.9" && rig.find(Strings.COPIED) != null)
        rig.tapText("Kopyala 149.112.112.112", exact = true)
        T.check("ikinci adres kopyalanır", rig.host.clipboard == "149.112.112.112")
        rig.tapText(Strings.REMOVE_FAV, exact = true)
        T.check("favoriden çıkarılır, düğme güncellenir", "quad9" !in rig.model.settings.favorites && rig.find(Strings.ADD_FAV, exact = true) != null)
        rig.tapText(Strings.MEASURE_THIS, exact = true)
        T.check("tek sunucu ölçülür", rig.host.calls.contains("measure:1") && rig.host.lastMeasureIds == listOf("quad9"))
        T.check("ölçerken düğme pasif (dokunmak yenisini başlatmaz)", run { rig.tapText(Strings.MEASURE_THIS, exact = true); rig.host.count("measure:") == 1 })
        rig.tapText(Strings.SWITCH_TO_THIS, exact = true)
        T.check("panelden geçiş yapılır ve panel kapanır", conn(rig) == listOf("connect:quad9") && !rig.scene.hasSheet)
    }
    run {
        val rig = Rig(); rig.connectOk("quad9")
        rig.scene.openDetails(Catalog.byId("quad9")!!); rig.settle(700)
        T.check("bağlı sunucuda 'Şu an bağlı' ve düğme pasif", rig.find(Strings.CONNECTED_NOW, exact = true) != null)
        rig.tapText(Strings.CONNECTED_NOW, exact = true)
        T.check("pasif düğme bir şey yapmaz", conn(rig).isEmpty() && rig.scene.hasSheet)
        rig.tapText(Strings.CLOSE, exact = true)
        T.check("kapat düğmesi paneli kapatır", !rig.scene.hasSheet)
    }
    run {
        val rig = Rig()
        rig.scene.openDetails(Catalog.byId("wikimedia")!!); rig.settle(700)
        T.check("ikincil adresi olmayan sunucu tek adres gösterir", rig.find("Birincil adres: 185.71.138.138") != null && rig.find("İkincil") == null)
        T.check("kapalıyken 'Bu sunucuya bağlan'", rig.find(Strings.CONNECT_TO_THIS, exact = true) != null)
        T.check("ölçüm yazısı yaşı ile birlikte", rig.items().any { it.info.label.startsWith("Son ölçüm: 88 ms") }, rig.items().joinToString { it.info.label.take(18) })
        rig.tapText(Strings.CONNECT_TO_THIS, exact = true)
        T.check("panelden bağlanılır", conn(rig) == listOf("connect:wikimedia") && !rig.scene.hasSheet)
    }
    run {
        val rig = Rig()
        rig.scene.openDetails(Catalog.byId("dns4eu-ads")!!); rig.settle(700)
        T.check("ölçülmemiş sunucu: 'Henüz ölçülmedi'", rig.find(Strings.NEVER_MEASURED, exact = true) != null)
    }
    run {
        val rig = Rig()
        rig.scene.openDetails(Catalog.byId("google")!!); rig.settle(700)
        rig.tap(180f, 30f)
        T.check("panelin dışına dokunmak kapatır", !rig.scene.hasSheet)
        rig.scene.openDetails(Catalog.byId("google")!!); rig.settle(700)
        T.check("geri tuşu önce paneli kapatır", rig.scene.goBack() && run { rig.settle(500); !rig.scene.hasSheet })
        T.check("geri ana ekranda olayı tüketmez (etkinlik kapanır)", !rig.scene.goBack())
    }
    run {
        // panel açılırken dokunmak yanlışlıkla kapatmaz
        val rig = Rig()
        rig.scene.openDetails(Catalog.byId("google")!!); rig.advance(80)
        rig.tap(180f, 700f, 0)
        T.check("açılış animasyonunda panel içine dokunmak paneli kapatmaz", rig.scene.hasSheet)
        rig.settle(600)
        T.check("panel açıkken arkadaki sayfa dokunmaları almaz", run { rig.tap(180f, 100f); true })
    }

    T.group("Paneller: ilk açılış bilgilendirmesi")
    run {
        val rig = Rig(Rig.base().copy(onboarded = false))
        rig.tapItem(rig.need("Bağlı değil"))
        T.check("bağlanmadan önce bilgilendirme açılır", rig.scene.hasSheet && rig.find(Strings.CONSENT_TITLE, exact = true) != null && conn(rig).isEmpty())
        T.check("tüm bilgilendirme metni okunur", Strings.CONSENT_BODY.all { p -> rig.items().any { it.info.label == p } })
        rig.tapText(Strings.CONSENT_OK, exact = true)
        T.check("kabul: bağlanır, kaydeder, kapanır", conn(rig) == listOf("connect:cloudflare") && rig.model.settings.onboarded && rig.host.saved?.onboarded == true && !rig.scene.hasSheet)
    }
    run {
        val rig = Rig(Rig.base().copy(onboarded = false))
        rig.tapItem(row(rig, "Quad9"))
        T.check("satırdan da bilgilendirme açılır", rig.scene.hasSheet)
        rig.scene.goBack(); rig.settle(500)
        T.check("geri ile vazgeçilir: bağlanmaz, tekrar sorulur", !rig.scene.hasSheet && conn(rig).isEmpty() && !rig.model.settings.onboarded && !rig.model.consentOpen)
        rig.tapItem(rig.need("Bağlı değil"))
        T.check("yeniden dokununca yine sorar", rig.scene.hasSheet)
        rig.tap(180f, 60f)
        T.check("dışarı dokunmak da vazgeçmektir", !rig.scene.hasSheet && conn(rig).isEmpty() && !rig.model.consentOpen)
        rig.tapItem(rig.need("Bağlı değil")); rig.tapText(Strings.CLOSE, exact = true)
        T.check("kapat düğmesi de vazgeçmektir", !rig.scene.hasSheet && conn(rig).isEmpty())
        rig.tapItem(rig.need("Bağlı değil")); rig.tapText(Strings.CONSENT_OK, exact = true)
        T.check("sonunda kabul edilirse bağlanır", conn(rig) == listOf("connect:cloudflare"))
    }
    run {
        // ayrıntı panelinden bağlanırken bilgilendirme: panel kapanır, sonra bilgilendirme açılır
        val rig = Rig(Rig.base().copy(onboarded = false))
        rig.scene.openDetails(Catalog.byId("google")!!); rig.settle(700)
        rig.tapText(Strings.CONNECT_TO_THIS, exact = true)
        rig.settle(900)
        T.check("ayrıntıdan bağlanma bilgilendirmeyi açar", rig.scene.hasSheet && rig.find(Strings.CONSENT_TITLE, exact = true) != null)
        rig.tapText(Strings.CONSENT_OK, exact = true)
        T.check("kabulden sonra o sunucuya bağlanır", conn(rig) == listOf("connect:google"))
    }
}

// =================================================================================== gezinti, tema, hareket

fun testUiNavigation() {
    T.group("Gezinti ve geçişler")
    run {
        val rig = Rig()
        rig.scene.openSection(Section.CONNECTION)
        T.check("geçiş sürerken sayfa sayısı 2", rig.scene.pageCount == 2 && rig.scene.transitioning())
        rig.scene.openSection(Section.CONNECTION)
        T.check("geçiş sürerken ikinci açma yok sayılır", rig.scene.pageCount == 2)
        rig.tap(180f, 400f, 0)
        rig.settle(600)
        T.check("geçiş bitti", !rig.scene.transitioning())
        rig.scene.openLog(); rig.settle(600)
        rig.scene.openHelp(); rig.settle(600)
        T.check("sayfalar üst üste açılır", rig.scene.pageCount == 4)
        T.check("geri tek tek döner", run { var ok = true; for (i in 0 until 3) { ok = ok && rig.scene.goBack(); rig.settle(600) }; ok && rig.scene.pageCount == 1 })
        T.check("kök sayfada geri tüketilmez", !rig.scene.goBack())
        rig.scene.openSection(Section.CONNECTION); rig.advance(30)
        T.check("geçiş sırasında geri tüketilir ve zarar vermez", rig.scene.goBack() && run { rig.settle(800); rig.scene.pageCount >= 1 })
    }
    run {
        val rig = Rig(Rig.base().copy(motion = Motion.OFF))
        rig.scene.openSection(Section.CONNECTION); rig.advance(20)
        T.check("animasyon kapalıyken geçiş anında biter", rig.scene.pageCount == 2 && !rig.scene.transitioning())
        T.check("kapalıyken geri anında", rig.scene.goBack() && rig.scene.pageCount == 1)
        val rig2 = Rig(Rig.base().copy(motion = Motion.OFF))
        rig2.scene.openDetails(Catalog.byId("google")!!); rig2.advance(20)
        T.check("kapalıyken panel anında açılır", rig2.scene.hasSheet && rig2.find("Birincil adres: 8.8.8.8") != null)
        rig2.scene.goBack(); rig2.advance(20)
        T.check("kapalıyken panel anında kapanır", !rig2.scene.hasSheet)
    }
    run {
        val rig = Rig()
        rig.scene.setSystemMotion(false)
        rig.advance(50)
        T.check("sistem animasyon ölçeği 0: hareket kapanır", rig.scene.env.motion == 0f && !rig.scene.env.ambient)
        rig.scene.openSection(Section.CONNECTION); rig.advance(20)
        T.check("sistem hareketi kapalıyken geçiş anında", !rig.scene.transitioning() && rig.scene.pageCount == 2)
        rig.scene.setSystemMotion(true); rig.advance(50)
        T.check("geri açılınca hareket döner", rig.scene.env.motion == 1f && rig.scene.env.ambient)
    }

    T.group("Tema geçişi")
    run {
        val rig = Rig(Rig.base("aqua"))
        openPersonalize(rig)
        val from = Themes.aqua.skyTop
        val to = Themes.night.skyTop
        rig.tapText("Tema: ${Themes.night.name}", exact = true, settleMs = 0)
        rig.advance(250)
        val mid = rig.scene.env.theme.skyTop
        T.check("geçiş sürerken renk iki tema arasında", mid != from && mid != to, "mid=${Integer.toHexString(mid)}")
        T.check("geçiş sırasında sahne çizilebilir", run { val g = CountingGfx(); rig.scene.draw(g); g.bad == 0 && g.depth == 0 })
        rig.advance(900)
        T.check("geçiş bitince hedef tema", rig.scene.env.theme.skyTop == to && rig.scene.env.theme.id == "night")
        T.check("geçiş bitince sahne durağan", run { rig.advance(800); rig.lastDelay != 16L })
    }
    run {
        val rig = Rig(Rig.base("aqua").copy(motion = Motion.OFF))
        openPersonalize(rig)
        rig.tapText("Tema: ${Themes.sunset.name}", exact = true, settleMs = 0)
        rig.advance(32)
        T.check("hareket kapalıyken tema anında değişir", rig.scene.env.theme.id == "sunset")
    }
    run {
        val rig = Rig(Rig.base("auto"))
        T.check("otomatik + açık sistem: aqua", rig.scene.env.theme.id == "aqua")
        rig.scene.setSystemDark(true); rig.advance(1000)
        T.check("sistem koyuya geçince gece teması", rig.scene.env.theme.id == "night" && rig.scene.env.theme.dark)
        rig.scene.setSystemDark(false); rig.advance(1000)
        T.check("sistem açığa dönünce aqua", rig.scene.env.theme.id == "aqua")
        val fixed = Rig(Rig.base("sunset"))
        fixed.scene.setSystemDark(true); fixed.advance(1000)
        T.check("sabit tema sistem koyu olunca değişmez", fixed.scene.env.theme.id == "sunset")
    }
    run {
        val rig = Rig()
        rig.scene.setFontScale(2f)
        T.check("yazı ölçeği en çok 1.3", rig.scene.env.fs == 1.3f)
        rig.scene.setFontScale(0.5f)
        T.check("yazı ölçeği en az 0,9", rig.scene.env.fs == Scene.MIN_FS)
        rig.scene.setFontScale(1.15f)
        T.check("ara değer korunur", Math.abs(rig.scene.env.fs - 1.15f) < 1e-6f)
        rig.scene.resize(320f, 568f, 24f, 0f)
        rig.scene.resize(900f, 400f, 0f, 48f)
        T.check("yeniden boyutlandırma çökertmez", rig.scene.width == 900f && run { val g = CountingGfx(); rig.scene.draw(g); g.bad == 0 && g.depth == 0 })
    }
}

fun testUiScheduling() {
    T.group("Kare planlaması (pil)")
    run {
        val rig = Rig()
        T.check("kabarcıklar açıkken durağan ekran 33 ms ister", rig.lastDelay == 33L, "delay=${rig.lastDelay}")
        rig.down(180f, 250f); rig.advance(32)   // küre üzerinde
        T.check("parmak ekrandayken 16 ms", rig.lastDelay == 16L)
        rig.scene.touch(Scene.CANCEL, 180f, 250f, rig.host.now); rig.advance(1500)
        T.check("bırakınca sakinleşir", rig.lastDelay == 33L || rig.lastDelay == -1L)
    }
    run {
        val rig = Rig(Rig.base().copy(bubbles = BubbleLevel.OFF))
        T.check("kabarcık yok + kapalı: hiç kare istemez", rig.lastDelay == -1L, "delay=${rig.lastDelay}")
        rig.connectOk(); rig.advance(2500)
        T.check("bağlıyken küre dalgası süs animasyonu: 33 ms", rig.lastDelay == 33L, "delay=${rig.lastDelay}")
        rig.tick1()
        rig.scene.setSystemMotion(false); rig.advance(100)
        T.check("sistem hareketi kapalıysa bağlıyken de kare istemez", rig.lastDelay == -1L, "delay=${rig.lastDelay}")
    }
    run {
        val rig = Rig(Rig.base().copy(lowPower = true)); rig.connectOk()
        T.check("düşük güç: bağlıyken bile kare istemez", rig.lastDelay == -1L, "delay=${rig.lastDelay}")
        rig.scene.openSection(Section.CONNECTION); rig.advance(60)
        T.check("düşük güç: geçiş yok, kare yok", rig.lastDelay == -1L)
    }
    run {
        val rig = Rig(Rig.base().copy(bubbles = BubbleLevel.OFF))
        rig.scene.openSection(Section.CONNECTION); rig.advance(32)
        T.check("sayfa geçişi sürerken 16 ms", rig.lastDelay == 16L)
        rig.advance(800)
        T.check("geçiş bitince kare istemez", rig.lastDelay == -1L, "delay=${rig.lastDelay}")
    }
    run {
        val rig = Rig(Rig.base().copy(bubbles = BubbleLevel.OFF))
        rig.model.toast("Merhaba")
        rig.advance(100)
        T.check("bildirim görünürken kare ister", rig.lastDelay == 16L)
        rig.advance(4000)
        T.check("bildirim kaybolunca kare istemez", rig.lastDelay == -1L && rig.find("Merhaba") == null, "delay=${rig.lastDelay}")
    }
    run {
        // her görsel değişiklik kare istemeyi tetikler (host.requestFrame)
        val rig = Rig(Rig.base().copy(bubbles = BubbleLevel.OFF))
        val f0 = rig.host.frames
        rig.model.onVpn(VpnUi(OrbState.ON, "cloudflare", rig.host.now))
        T.check("model değişince kare istenir", rig.host.frames > f0)
        val f1 = rig.host.frames
        rig.scene.touch(Scene.DOWN, 100f, 100f, rig.host.now); rig.scene.touch(Scene.UP, 100f, 100f, rig.host.now)
        T.check("dokunma kare ister", rig.host.frames > f1)
    }
}

// =================================================================================== erişilebilirlik

fun testUiA11y() {
    T.group("Erişilebilirlik")
    run {
        val rig = Rig(Rig.base(), 360, 1000); rig.connectOk()
        val its = rig.items()
        T.check("ana ekran: her öğenin rolü ve etiketi var", its.isNotEmpty() && its.all { it.info.label.isNotBlank() })
        T.check("başlık 'başlık' rolünde", its.any { it.info.role == Role.HEADING && it.info.label == Strings.APP })
        T.check("başlık yalnızca yazı alanını kaplar (düğmeleri örtmez)", its.first { it.info.role == Role.HEADING }.r < rig.need(Strings.MENU, exact = true).l)
        T.check("satırlar uzun basışı bildirir", its.filter { it.info.label.contains(", ") && it.info.role == Role.BUTTON && it.info.longClick }.size >= 2)
        val orb = rig.need("Bağlı. Cloudflare")
        rig.scene.a11yClick(orb)
        T.check("a11y tıklama küreyle aynı işi yapar", rig.host.calls.last() == "disconnect")
        val g = row(rig, "Quad9")
        T.check("a11y uzun basış ayrıntıyı açar", rig.scene.a11yLongClick(g) && run { rig.settle(600); rig.scene.hasSheet })
        rig.scene.goBack(); rig.settle(600)
        rig.scene.a11yClick(row(rig, "Google"))
        T.check("a11y tıklama satırı seçer", conn(rig).contains("connect:google"))
        rig.scene.a11yClick(star(rig, "Google"))
        T.check("a11y tıklama yıldızı çevirir", "google" in rig.model.settings.favorites)
    }
    run {
        val all = ArrayList<A11yItem>()
        for (sec in Section.values()) {
            val rg = Rig()
            openSection(rg, sec)
            val sits = scrollAll(rg)
            T.check("${sec.name}: sayfa başlığı 'başlık' rolünde", sits.any { it.info.role == Role.HEADING && it.info.label == sectionTitle(sec) })
            all.addAll(sits)
        }
        T.check("ayar pencereleri: toplam 19 anahtar, kaydırıcı yok", all.count { it.info.role == Role.SWITCH } == 19 && all.count { it.info.role == Role.SLIDER } == 0, "anahtar=${all.count { it.info.role == Role.SWITCH }}")
        T.check("anahtarların durumu bilinir (checked != null)", all.filter { it.info.role == Role.SWITCH }.all { it.info.checked != null })
        val r2 = Rig()
        openPersonalize(r2)
        val pits = scrollAll(r2)
        T.check("kişiselleştirme: anahtarlar, kaydırıcılar rolleriyle", pits.count { it.info.role == Role.SWITCH } == 5 && pits.count { it.info.role == Role.SLIDER } == 2, "anahtar=${pits.count { it.info.role == Role.SWITCH }}")
        T.check("kişiselleştirme: beş bölüm başlığı", pits.count { it.info.role == Role.HEADING } >= 5, "başlık=${pits.count { it.info.role == Role.HEADING }}")
        T.check("kişiselleştirme: anahtar etiketi açıklamayı da içerir", (r2.reveal(Strings.LOW_POWER) ?: r2.need(Strings.LOW_POWER)).info.label.contains(Strings.LOW_POWER_NOTE))
        T.check("anahtarların durumu bilinir (kişiselleştirme)", pits.filter { it.info.role == Role.SWITCH }.all { it.info.checked != null })
    }
    run {
        val rig = Rig()
        rig.model.toast("Merhaba", "Tamam") {}
        rig.advance(400)
        T.check("bildirim ve eylemi okunur", rig.find("Merhaba, Tamam") != null)
        rig.scene.a11yClick(rig.need("Merhaba, Tamam"))
        T.check("a11y ile bildirim eylemi çalışır (bildirim kapanır)", run { rig.advance(4000); rig.find("Merhaba") == null })
    }
    run {
        val rig = Rig()
        T.check("ana ekran: yukarıdayken geri kaydırılamaz, ileri kaydırılabilir", !rig.scene.a11yCanScroll(false) && rig.scene.a11yCanScroll(true))
        val before = rig.scene.a11yItems().map { it.info.label }
        T.check("ileri kaydırma konumu değiştirir", rig.scene.a11yScroll(true))
        rig.advance(50)
        val after = rig.scene.a11yItems().map { it.info.label }
        T.check("ileri kaydırınca görünen öğeler değişir", before != after)
        T.check("geri kaydırılabilir hale gelir", rig.scene.a11yCanScroll(false))
        var n = 0
        while (rig.scene.a11yScroll(true) && n++ < 40) rig.advance(20)
        T.check("sona gelince ileri kaydırma bitiyor ve false dönüyor", !rig.scene.a11yCanScroll(true) && !rig.scene.a11yScroll(true) && n < 40, "adım=$n")
        n = 0
        while (rig.scene.a11yScroll(false) && n++ < 40) rig.advance(20)
        T.check("geri kaydırarak başa dönülüyor", !rig.scene.a11yCanScroll(false) && n < 40)
        rig.scene.openHelp(); rig.settle(600)
        T.check("alt sayfada da kaydırma eylemi çalışır", rig.scene.a11yCanScroll(true) && rig.scene.a11yScroll(true))
        T.check("canGoBack: alt sayfada true", rig.scene.canGoBack)
        rig.scene.goBack(); rig.settle(600)
        T.check("canGoBack: ana ekranda false", !rig.scene.canGoBack)
        rig.scene.openDetails(Catalog.default); rig.settle(600)
        T.check("canGoBack: panel açıkken true", rig.scene.canGoBack)
        rig.scene.goBack(); rig.settle(600)
        T.check("canGoBack: panel kapanınca false", !rig.scene.canGoBack)
    }
}

// =================================================================================== kare maliyeti

private val tmx = ManagementFactory.getThreadMXBean() as com.sun.management.ThreadMXBean

private fun allocatedNow(): Long = tmx.getThreadAllocatedBytes(Thread.currentThread().id)

/** [frames] kare (tick + draw) çalıştırır; kare başına ortalama ayrılan bayt sayısı. */
private fun bytesPerFrame(rig: Rig, g: CountingGfx, frames: Int = 300, each: (Int) -> Unit = {}): Double {
    repeat(150) { rig.host.now += 16; rig.scene.tick(rig.host.now); g.reset(); rig.scene.draw(g) }   // ısınma
    val before = allocatedNow()
    for (i in 0 until frames) {
        each(i)
        rig.host.now += 16
        rig.scene.tick(rig.host.now)
        g.reset()
        rig.scene.draw(g)
    }
    return (allocatedNow() - before).toDouble() / frames
}

fun testUiFrameCost() {
    T.group("Kare maliyeti: bellek ve çizim sayısı")
    val g = CountingGfx()
    /**
     * Her denemede taze bir [Rig] kurar (geçiş animasyonları yeniden başlasın diye). Yoğun CPU yükünde JIT/GC kaynaklı
     * tek seferlik birkaç KB'lık sapma görülebilir; gerçek bir ayırma ise her karede olur ve her denemede görünür.
     * Bu yüzden en çok 3 deneme yapılır, eşiğin altına inen ilk deneme geçerlidir.
     */
    fun alloc(name: String, frames: Int = 300, make: () -> Rig, step: (Rig) -> (Int) -> Unit = { _ -> { _ -> } }) {
        var best = Double.MAX_VALUE
        for (attempt in 1..3) {
            val rig = make()
            best = minOf(best, bytesPerFrame(rig, g, frames, step(rig)))
            if (best <= 96.0) break
        }
        T.check("$name: kare başına en çok 96 bayt ayırır", best <= 96.0, "%.1f bayt".format(best))
    }

    /**
     * Geçişler (sayfa açma, tema değiştirme) sürekli değil, kullanıcı eylemi başına bir kez olur ve yeni sayfayı kurma /
     * tema renklerini ara değerlerle yeniden üretme maliyeti taşır; bu yüzden kare başına değil, geçişin TOPLAM ayırması
     * bütçeyle denetlenir (JIT önce ayrı bir deneme sahnesinde ısıtılır).
     */
    fun transitionTotal(name: String, budgetKb: Int, make: () -> Rig) {
        var best = Long.MAX_VALUE
        for (attempt in 1..3) {
            val w = make()
            repeat(80) { w.host.now += 16; w.scene.tick(w.host.now); g.reset(); w.scene.draw(g) }
            val rig = make()
            val before = allocatedNow()
            repeat(60) { rig.host.now += 16; rig.scene.tick(rig.host.now); g.reset(); rig.scene.draw(g) }   // ≈ 1 sn: geçiş biter
            best = minOf(best, allocatedNow() - before)
            if (best <= budgetKb * 1024L) break
        }
        println("        bilgi: $name toplam ≈ ${best / 1024} KB (bütçe $budgetKb KB)")
        T.check("$name: tüm geçiş en çok $budgetKb KB ayırır", best <= budgetKb * 1024L, "${best / 1024} KB")
    }
    alloc("ana ekran (kapalı)", make = { Rig() })
    alloc("ana ekran (bağlı)", make = { Rig().also { it.connectOk() } })
    alloc("ana ekran (parmakla kaydırma)", make = { Rig().also { it.connectOk(); it.down(180f, 600f) } }, step = { r ->
        var y = 600f
        val move: (Int) -> Unit = { i -> y -= if (i % 2 == 0) 3f else -2f; r.scene.touch(Scene.MOVE, 180f, y, r.host.now) }
        move
    })
    alloc("ayarlar", make = { Rig().also { it.scene.openSection(Section.CONNECTION); it.settle(900) } })
    alloc("günlük", make = { Rig().also { it.scene.openLog(); it.settle(900) } })
    alloc("yardım", make = { Rig().also { it.scene.openHelp(); it.settle(900) } })
    alloc("ayrıntı paneli", make = { Rig().also { it.scene.openDetails(Catalog.byId("quad9")!!); it.settle(900) } })
    alloc("seçici paneli", make = { Rig().also { it.scene.openChoice("x", null) {}; it.settle(900) } })
    alloc("bildirim", 100, make = { Rig().also { it.model.toast("Merhaba", "Tamam") {}; it.advance(300) } })
    transitionTotal("sayfa geçişi", 128) { Rig().also { it.scene.openSection(Section.CONNECTION) } }
    transitionTotal("tema geçişi", 1024) { Rig().also { openPersonalize(it); it.tapText("Tema: ${Themes.night.name}", exact = true, settleMs = 0) } }

    // çizim çağrısı sayısı: çok pahalı bir kareyi yakalar
    val rig = Rig(); rig.connectOk()
    g.reset(); rig.scene.draw(g)
    // Bütçe 4200: 32 hazır sunucu satırı + "Özel DNS ekle" düğmesi (satır başına ≈95 çağrı). Durağan ekranda hiç kare çizilmez; bu yalnızca animasyon karesi içindir.
    T.check("ana ekran: bir kare 4200 çizim çağrısını aşmaz", g.calls < 4200, "${g.calls}")
    T.check("ana ekran: yazı sayısı makul", g.texts in 20..120, "${g.texts}")
    T.check("ana ekran: iç içe kayıt derinliği makul", g.maxDepth in 2..20, "${g.maxDepth}")
    val big = Rig(Rig.base(), 800, 1280); big.connectOk()
    g.reset(); big.scene.draw(g)
    T.check("tablet: çizim sayısı sınırlı (görünmeyen satırlar çizilmez)", g.calls < 4000, "${g.calls}")
}

fun runUiTests() {
    testUiLayout()
    testUiHome()
    testUiSettings()
    testUiSlider()
    testUiRules()
    testUiAbout()
    testUiApps()
    testUiSheets()
    testUiNavigation()
    testUiScheduling()
    testUiA11y()
    testUiFeatures()
    testUiLanguages()
    testUiStyles()
    testWallpaper()
    testWallpaperPresets()
    testAppIcon()
    testExtras()
    testUiFrameCost()
}

// ----------------------------------------------------------------------------- bellek raporu (elle çalıştırma)

fun allocReport() {
    val g = CountingGfx()
    fun show(name: String, v: Double) = println("  %-34s %8.1f bayt/kare".format(name, v))
    run { val r = Rig(); show("ana ekran (kapalı)", bytesPerFrame(r, g)) }
    run { val r = Rig(); r.connectOk(); show("ana ekran (bağlı)", bytesPerFrame(r, g)) }
    run { val r = Rig(); r.scene.openSection(Section.CONNECTION); r.settle(900); show("ayarlar", bytesPerFrame(r, g)) }
}

// =================================================================================== yeni özellikler (arayüz)

fun testUiFeatures() {
    T.group("Arayüz: hızlı seçim ve duraklatma")
    run {
        val rig = Rig(); rig.connectOk()
        val orb = rig.need("Bağlı. Cloudflare")
        T.check("küre uzun basışı bildirir", orb.info.longClick)
        rig.longPress(rig.cx(orb), rig.cy(orb))
        T.check("uzun basınca hızlı seçim açılır", rig.scene.hasSheet && rig.find(Strings.QUICK_TITLE, exact = true) != null)
        T.check("favoriler listelenir, bağlı olan işaretli", rig.need("Cloudflare, ").info.checked == true && rig.find("Quad9, ") != null)
        T.check("duraklatma seçenekleri", rig.find(Strings.minutes(5), exact = true) != null && rig.find(Strings.minutes(60), exact = true) != null)
        rig.tapText(Strings.minutes(15), exact = true)
        T.check("15 dk duraklatılır, panel kapanır", rig.host.calls.last() == "pause:15" && !rig.scene.hasSheet)
        T.check("ana ekranda 'Duraklatıldı'", rig.find(Strings.PAUSED) != null)
        rig.tapItem(rig.need(Strings.APP + ". " + Strings.PAUSED))
        T.check("küreye dokununca devam eder", rig.host.calls.last() == "resume")
    }
    run {
        val rig = Rig(); rig.connectOk()
        val orb = rig.need("Bağlı. Cloudflare")
        rig.longPress(rig.cx(orb), rig.cy(orb))
        rig.tapText("Quad9, ")
        T.check("hızlı seçimden sunucu değiştirilir", rig.host.calls.last() == "connect:quad9" && !rig.scene.hasSheet)
    }

    T.group("Arayüz: çekerek ölçme, sıkı liste, sade görünüm")
    run {
        val rig = Rig()
        rig.down(180f, 430f)
        for (i in 1..14) rig.move(180f, 430f + i * 20f)
        val pulled = (rig.scene.currentPage as ScrollPage).let { record(rig).runs.any { it.s == Strings.RELEASE_TO_MEASURE } }
        rig.up(180f, 430f + 14 * 20f); rig.advance(600)
        T.check("yeterince çekince 'bırak' ipucu", pulled)
        T.check("bırakınca tüm sunucular ölçülür", rig.host.count("measure:") == 1, rig.host.calls.toString())
        T.check("içerik yerine yaylanır", (rig.scene.currentPage as ScrollPage).scrollOffset == 0f)
        rig.model.onMeasureDone()
        rig.down(180f, 430f); for (i in 1..2) rig.move(180f, 430f + i * 12f); rig.up(180f, 454f); rig.advance(600)
        T.check("az çekmek ölçüm başlatmaz", rig.host.count("measure:") == 1)
    }
    run {
        val rig = Rig(Rig.base().copy(compact = true))
        val r = row(rig, "Google")
        T.check("sıkı listede satırlar kısa", r.b - r.t <= M.ROW_H_COMPACT + 0.5f, "${r.b - r.t}")
        val normal = Rig(); val r2 = row(normal, "Google")
        T.check("normal listede satırlar uzun", r2.b - r2.t >= M.ROW_H - 0.5f)
    }
    run {
        val rig = Rig(Rig.base().copy(minimal = true)); rig.connectOk()
        T.check("sade görünümde süzgeç çipleri yok", rig.find(Strings.FILTER_ALL, exact = true) == null && rig.find(Strings.FILTER_FAV, exact = true) == null)
        T.check("sade görünümde istatistik satırı yalnızca süre", rig.items().none { it.info.label.contains(Strings.queriesShort("")) })
        rig.model.update { it.copy(minimal = false) }; rig.settle(600)
        T.check("kapatınca çipler döner", rig.find(Strings.FILTER_ALL, exact = true) != null)
    }

    T.group("Arayüz: ayrıntı paneli yenilikleri")
    run {
        val rig = Rig()
        rig.scene.openDetails(Catalog.byId("wikimedia")!!); rig.settle(700)
        T.check("şifreli DNS desteği yazar", rig.find("${Strings.ENC_SUPPORT}: DoT · DoH", exact = true) != null)
        T.check("düz DNS de bilen sunucuda 'yalnızca şifreli' notu yok", rig.find(Strings.ENC_ONLY, exact = true) == null)
        T.check("ölçüm geçmişi yokken grafik yok", rig.items().none { it.info.label.startsWith(Strings.HISTORY) })
        rig.model.onLatency("wikimedia", 40); rig.model.onLatency("wikimedia", null); rig.model.onLatency("wikimedia", 30)
        rig.settle(400)
        T.check("ölçümler gelince grafik ve özet görünür", rig.find(Strings.historyA11y(3, 30)) != null && rig.find(Strings.measureSummary(30, 30, 33)) != null,
            rig.items().joinToString { it.info.label.take(30) })
        rig.tapText(Strings.HIDE, exact = true)
        T.check("panelden gizlenir ve panel kapanır", "wikimedia" in rig.model.settings.hidden && !rig.scene.hasSheet)
    }
    run {
        val rig = Rig()
        rig.scene.openDetails(DnsServer("enc-only", "Gizli", null, "194.242.2.2", null, emptySet(), dot = "dns.example.net", doh = "https://dns.example.net/dns-query", plain = false, owner = "Test"))
        rig.settle(700)
        T.check("yalnızca şifreli sunucu notu", rig.find(Strings.ENC_ONLY, exact = true) != null)
    }
    run {
        val rig = Rig()
        rig.scene.openDetails(Catalog.byId("uncensored")!!); rig.settle(700)
        T.check("DoH'suz sunucu: yalnızca DoT", rig.find("${Strings.ENC_SUPPORT}: DoT", exact = true) != null)
        rig.model.update { it.copy(encryption = Encryption.DOH) }; rig.settle(300)
        T.check("seçili şifrelemeyi desteklemeyen sunucuda bağlan düğmesi pasif", run {
            val b = rig.need(Strings.CONNECT_TO_THIS, exact = true)
            rig.tapItem(b); rig.host.count("connect:") == 0 })
    }

    T.group("Arayüz: ayar pencerelerinin içeriği")
    run {
        val rig = Rig(); rig.model.hide("opendns"); rig.settle(300)
        openSection(rig, Section.STATS)
        val its = scrollAll(rig)
        T.check("haftalık grafik okunur", its.any { it.info.label.startsWith(Strings.weekA11y("").substring(0, 4)) || it.info.label.contains(Strings.WEEK) })
        for (l in listOf(Strings.STAT_QUERIES, Strings.SESSIONS, Strings.KEEP_HISTORY, Strings.SHARE_RESULTS, Strings.CLEAR_HISTORY, Strings.RESET_STATS))
            T.check("istatistikler ve geçmiş satırı: $l", its.any { it.info.label.startsWith(l) })
    }
    run {
        val rig = Rig(); openSection(rig, Section.DNS)
        val its = scrollAll(rig)
        T.check("şifreleme segmenti (4 seçenek)", Strings.OPT_ENCRYPTION.all { o -> its.any { it.info.label == "${Strings.ENCRYPTION}: $o" } })
        for (l in listOf(Strings.STRICT_ENC, Strings.BACKUP_SERVER, Strings.RULE_WIFI, Strings.RULE_MOBILE, Strings.CACHE, Strings.CLEAR_CACHE, Strings.TEST, Strings.TROUBLE))
            T.check("DNS ayarları satırı: $l", its.any { it.info.label.startsWith(l) })
        T.check("DNS ayarlarında yazı boyutu yok", Strings.OPT_TEXT.none { o -> its.any { it.info.label == "${Strings.TEXT_SIZE}: $o" } })
    }
    run {
        val rig = Rig(); openSection(rig, Section.CONNECTION)
        val its = scrollAll(rig)
        for (l in listOf(Strings.AUTO_CONNECT, Strings.CONNECT_ON_BOOT, Strings.AUTO_FASTEST, Strings.AUTO_RECONNECT, Strings.REFRESH_ON_NET, Strings.CONFIRM_OFF, Strings.APPS, Strings.GUARD, Strings.BATTERY))
            T.check("bağlantı ve uygulamalar satırı: $l", its.any { it.info.label.startsWith(l) })
    }
    run {
        val rig = Rig(); openSection(rig, Section.NOTIFICATIONS)
        val its = scrollAll(rig)
        for (l in listOf(Strings.NOTIFY_DROP, Strings.LOCK_HIDE, Strings.QUIET_NOTIF))
            T.check("bildirim satırı: $l", its.any { it.info.label.startsWith(l) && it.info.role == Role.SWITCH })
    }
    run {
        val rig = Rig(); openSection(rig, Section.LIST)
        val its = scrollAll(rig)
        for (l in listOf(Strings.RECOMMEND, Strings.COMPACT, Strings.REMEMBER_FILTER, Strings.AUTO_MEASURE, Strings.MEASURE_ENC, Strings.HIDDEN))
            T.check("sunucu listesi satırı: $l", its.any { it.info.label.startsWith(l) })
    }
    run {
        val rig = Rig(); openSection(rig, Section.DATA)
        val its = scrollAll(rig)
        for (l in listOf(Strings.EXPORT, Strings.IMPORT, Strings.RESET_SETTINGS))
            T.check("veriler satırı: $l", its.any { it.info.label.startsWith(l) && it.info.role == Role.BUTTON })
    }
    run {
        val rig = Rig(); openPersonalize(rig)
        val its = scrollAll(rig)
        for (h in listOf(Strings.SEC_LOOK, Strings.PZ_BACKGROUND, Strings.PZ_AUTO, Strings.PZ_FEEL, Strings.PZ_ACCESS))
            T.check("kişiselleştirme bölümü: $h", its.any { it.info.label == h && it.info.role == Role.HEADING })
        T.check("yazı boyutu segmenti", Strings.OPT_TEXT.all { o -> its.any { it.info.label == "${Strings.TEXT_SIZE}: $o" } })
        for (l in listOf(Strings.LANGUAGE, Strings.STYLE, Strings.APP_ICON, Strings.WALLPAPER, Strings.AUTO_LIGHT, Strings.AUTO_DARK))
            T.check("kişiselleştirme satırı: $l", its.any { it.info.label.startsWith(l) && it.info.role == Role.BUTTON })
        T.check("tema renkleri (13 düğme)", its.count { it.info.label.startsWith("Tema: ") } == Themes.all.size + 1, "${its.count { it.info.label.startsWith("Tema: ") }}")
    }
    run {
        val rig = Rig(); rig.model.hide("opendns"); rig.settle(300)
        openSection(rig, Section.LIST)
        rig.tapItem(rig.revealWhere { it.info.label == Strings.HIDDEN }!!)
        T.check("gizlenenler paneli", rig.scene.hasSheet && rig.find("OpenDNS, ${Strings.UNHIDE}", exact = true) != null)
        rig.tapText("OpenDNS, ")
        T.check("dokununca listeye geri döner", "opendns" !in rig.model.settings.hidden && !rig.scene.hasSheet)
        rig.tapItem(rig.revealWhere { it.info.label == Strings.HIDDEN }!!)
        T.check("gizlenen yokken bilgi yazısı", rig.find(Strings.HIDDEN_NONE, exact = true) != null)
    }
    run {
        val rig = Rig(); openPersonalize(rig)
        rig.tapItem(rig.revealWhere { it.info.label == "${Strings.TEXT_SIZE}: ${Strings.OPT_TEXT[3]}" }!!)
        T.check("yazı boyutu en büyük: 1,3", rig.scene.env.fs == 1.3f)
        rig.tapItem(rig.revealWhere { it.info.label == "${Strings.TEXT_SIZE}: ${Strings.OPT_TEXT[0]}" }!!)
        T.check("yazı boyutu küçük: 0,9", Math.abs(rig.scene.env.fs - 0.9f) < 1e-6f)
        rig.scene.setFontScale(1.3f)
        T.check("sistem ölçeğiyle çarpılır ve sınırlanır", Math.abs(rig.scene.env.fs - 1.17f) < 1e-4f)
    }
    run {
        val rig = Rig(Rig.base().copy(highContrast = true))
        T.check("yüksek kontrast: ikincil yazı birincil kadar koyu", rig.scene.env.theme.textSoft == rig.scene.env.theme.text && rig.scene.env.art.glass == 1f)
        T.check("yüksek kontrast: kontrast artar", Rgb.contrast(rig.scene.env.theme.text, Themes.aqua.skyMid) >= Rgb.contrast(Themes.aqua.text, Themes.aqua.skyMid))
        val g = CountingGfx(); rig.scene.draw(g)
        T.check("yüksek kontrastta çizim sorunsuz", g.bad == 0)
    }
    run {
        val rig = Rig(Rig.base(Themes.AUTO_ID).copy(themeSchedule = true))
        rig.host.localHourValue = 23; rig.host.now += 61_000; rig.settle(1500)
        T.check("saatli gece: 23:00'te Gece teması", rig.scene.env.theme.id == "night")
        rig.host.localHourValue = 12; rig.host.now += 61_000; rig.settle(1500)
        T.check("saatli gece: öğlen Aqua", rig.scene.env.theme.id == "aqua")
        val fixed = Rig(Rig.base("sunset").copy(themeSchedule = true))
        fixed.host.localHourValue = 23; fixed.host.now += 61_000; fixed.settle(1500)
        T.check("sabit temada saat etkisizdir", fixed.scene.env.theme.id == "sunset")
    }

    T.group("Arayüz: dil değiştirme")
    run {
        val rig = Rig(); rig.connectOk()
        openPersonalize(rig)
        rig.tapText(Strings.LANGUAGE, exact = false)
        T.check("dil paneli: otomatik + ${Lang.values().size} dil (panel kaydırılarak)", rig.scene.hasSheet && rig.find(Strings.LANG_AUTO) != null &&
            Lang.values().all { l -> rig.reveal(l.native, exact = true) != null }, Lang.values().filter { rig.reveal(it.native, exact = true) == null }.joinToString { it.native })
        rig.tapText("English")
        rig.settle(900)
        T.check("sayfalar İngilizce yeniden kurulur", rig.find("Personalize", exact = true) != null && rig.find("Appearance", exact = true) != null, rig.items().take(6).joinToString { it.info.label })
        T.check("aynı sayfada kalınır (Kişiselleştirme)", rig.scene.pageCount == 3 && rig.scene.currentPage is PersonalizePage)
        rig.scene.goBack(); rig.settle(900); rig.scene.goBack(); rig.settle(900)
        T.check("ana ekran İngilizce", rig.find("Connected. Cloudflare") != null && rig.find("Servers, 32 servers", exact = true) != null,
            rig.items().take(8).joinToString { it.info.label.take(30) })
        rig.model.setLanguage(L.AUTO); rig.settle(900)
        T.check("otomatiğe dönünce Türkçe", rig.find("Bağlı. Cloudflare") != null)
    }
}

/** Her dilde: ekranlar çökmeden çizilir, yazılar ekrandan taşmaz ve çakışmaz, erişilebilirlik etiketleri dolu. */
fun testUiLanguages() {
    T.group("Arayüz: her dilde ekranlar")
    val saved = L.lang
    try {
        for (lang in Lang.values()) for ((sz, w, h) in listOf(Triple("360", 360, 780), Triple("320", 320, 568))) {
            val rig = Rig(Rig.base().copy(lang = lang.code), w, h)
            L.set(lang); rig.model.onLanguageChanged(); rig.settle(400)
            rig.connectOk()
            rig.model.onLatency("google", 24); rig.model.onLatency("google", 31)
            val probs = ArrayList<String>()
            fun inspect(where: String, sheet: Boolean = false) {
                val g = CountingGfx(); rig.scene.draw(g)
                if (g.bad != 0) probs.add("$where: geçersiz çizim")
                val rec = record(rig)
                val band = rig.scene.env.insetTop + M.HEADER_H
                val out = rec.runs.filter { it.s !in filterLabels && (it.l < -0.5f || it.r > w + 0.5f) }
                if (out.isNotEmpty()) probs.add("$where: taşma \"${out.first().s.take(24)}\"")
                // Alt panel açıkken arkadaki sayfanın yazıları panelin altında kalır: çakışma yalnızca sayfalarda aranır.
                val ov = if (sheet) emptyList() else rec.overlaps().filter { it.first.b > band && it.second.b > band }
                if (ov.isNotEmpty()) probs.add("$where: çakışma " + describe(ov.first()))
                if (rig.items().any { it.info.label.isBlank() }) probs.add("$where: boş etiket")
            }
            inspect("ana")
            rig.scene.openSection(Section.CONNECTION); rig.settle(900); inspect("ayarlar")
            repeat(6) { rig.drag(w / 2f, h * 0.8f, h * 0.15f, 16) }
            rig.advance(1500); inspect("ayarlar alt")
            rig.scene.back(); rig.settle(900)
            rig.scene.openDetails(Catalog.byId("google")!!); rig.settle(800); inspect("ayrıntı", sheet = true)
            rig.scene.closeSheet(); rig.settle(600)
            rig.scene.openQuickPick(); rig.settle(800); inspect("hızlı seçim", sheet = true)
            rig.scene.closeSheet(); rig.settle(600)
            rig.scene.openHelp(); rig.settle(900); inspect("yardım")
            rig.scene.back(); rig.settle(900)
            rig.model.onVpn(VpnUi(OrbState.ERROR, "google", 0, error = Strings.errNoReply("Google"))); rig.settle(600); inspect("hata")
            T.check("${lang.native} ${sz}dp", probs.isEmpty(), probs.take(3).joinToString(" | "))
        }
    } finally {
        L.set(saved)
    }
}
