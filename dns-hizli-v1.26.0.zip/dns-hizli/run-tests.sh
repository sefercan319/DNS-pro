#!/bin/sh
# DNS Hızlı: Android gerektirmeyen tüm JVM testleri (çekirdek, çizim, model, arayüz, rastgele kullanım).
# Gerekenler: JDK 17+ ve kotlinc (https://kotlinlang.org/docs/command-line.html)
#
# Kullanım:
#   ./run-tests.sh                    tüm testler
#   ./run-tests.sh core ui            yalnızca seçilen gruplar: core gfx model ui monkey
#   ./run-tests.sh alloc              kare başına bellek ayırma raporu
#   ./run-tests.sh previews [KLASÖR]  önizleme görsellerini (PNG) üretir
#
# Ortam: KOTLINC=/yol/kotlinc  VERBOSE=1 (her kontrolü yazar)  MONKEY_SEEDS=200 MONKEY_STEPS=4000 (uzun rastgele tarama)
set -e
cd "$(dirname "$0")"
KOTLINC=${KOTLINC:-kotlinc}
OUT=${TMPDIR:-/tmp}/dnshizli-selftest.jar

# Derleme başarısızsa testlere hiç geçilmez (eski bir jar varsa o çalışıp yanıltmasın).
rm -f "$OUT"
LOG=${TMPDIR:-/tmp}/dnshizli-derleme.log
if ! $KOTLINC -J-Xmx4g -nowarn app/src/main/java/app/dnshizli/core/*.kt app/src/main/java/app/dnshizli/ui/*.kt selftest/*.kt \
    -include-runtime -d "$OUT" > "$LOG" 2>&1; then
    grep -v "^Picked up" "$LOG"
    echo "DERLEME HATASI: testler çalıştırılmadı." >&2
    exit 1
fi
grep -v "^Picked up" "$LOG" || true

# -XX:-DoEscapeAnalysis: bellek ayırma ölçümü, JIT'in nesneleri yok saymasına bağlı olmasın.
JAVA="java -XX:-DoEscapeAnalysis -Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -Djava.awt.headless=true -cp $OUT"

if [ "$1" = "previews" ]; then
    DIR=${2:-previews}
    mkdir -p "$DIR"
    exec $JAVA app.dnshizli.selftest.UiPreview "$DIR"
fi
exec $JAVA app.dnshizli.selftest.AllTests "$@"
