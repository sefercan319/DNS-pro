package app.dnshizli.core

/**
 * ODoH düğümü: bir röle ya da bir hedef. [group]: işleten kuruluş etiketi. Aynı grubun röle ve hedefi hiçbir zaman eşleşmez:
 * ODoH'un gizlilik sözü, rölenin (IP'nizi görür) ve hedefin (soruyu görür) birbirine bilgi vermemesine dayanır.
 * [ips]: ipucu adresleri (en çok [MAX_IPS]); sertifika her zaman [host] adına göre doğrulandığı için bayat bir ipucu güvenlik
 * açığı değil, yalnızca bir yavaşlık/başarısızlık nedenidir; o durumda şifreli ad çözümü ve son çalışan adres devreye girer.
 */
class OdohNode(
    val id: String,
    val name: String,
    val group: String,
    val host: String,
    val path: String,
    val ips: List<String> = emptyList(),
) {
    init {
        require(id.isNotEmpty() && host.isNotEmpty() && path.startsWith("/")) { "geçersiz ODoH düğümü" }
        require(host.all { it.isLetterOrDigit() || it == '.' || it == '-' }) { "geçersiz ad" }
        // HTTP isteğine doğrudan yazıldığı için denetim karakteri, boşluk ve satır sonu yasak (istek bölme/başlık enjeksiyonu).
        require(path.all { it.code in 0x21..0x7E }) { "geçersiz yol" }
    }

    companion object { const val MAX_IPS = 4 }
}

/** Seçilen röle + hedef çifti; indisler [OdohCatalog]/[OdohEngine] listelerine göredir. */
class OdohPathSpec(val relay: Int, val target: Int)

object OdohCatalog {
    /** Röleler: istemcinin IP'sini görür, soruyu göremez. */
    val relays: List<OdohNode> = listOf(
        OdohNode("fastly", "Fastly (edgecompute)", "frankdenis", "odoh-relay.edgecompute.app", "/", listOf("151.101.1.51", "151.101.65.51", "151.101.129.51", "151.101.193.51")),
        OdohNode("numa", "numa.rs", "numa", "odoh-relay.numa.rs", "/relay", listOf("178.104.229.30")),
    )

    /** Hedefler: soruyu görür, istemcinin IP'sini göremez. */
    val targets: List<OdohNode> = listOf(
        OdohNode("cloudflare", "Cloudflare", "cloudflare", "odoh.cloudflare-dns.com", "/dns-query", listOf("172.64.42.1", "162.159.62.1")),
        OdohNode("snowstorm", "Snowstorm", "snowstorm", "dope.snowstorm.love", "/dns-query", listOf("104.21.68.92", "172.67.192.188")),
        OdohNode("dnscrypt-pt", "dnscry.pt (İstanbul)", "dnscrypt-pt", "ist01.dnscry.pt", "/dns-query", listOf("188.132.192.168")),
    )

    /** Ad olarak kayıtlı alan (son iki etiket): grup etiketi yanlış girilse bile aynı alan adı iki uçta olamaz. */
    internal fun domainOf(host: String): String {
        val l = host.lowercase().trimEnd('.').split('.')
        return if (l.size <= 2) l.joinToString(".") else l.takeLast(2).joinToString(".")
    }

    /** Röle ve hedef birbirinden bağımsız mı (grup ve alan adı farklı, ad farklı)? */
    fun independent(r: OdohNode, t: OdohNode): Boolean =
        r.group != t.group && domainOf(r.host) != domainOf(t.host) && r.host != t.host

    /** Geçerli tüm (röle, hedef) çiftleri: bağımsızlık kuralını sağlayanlar. */
    fun pairs(relays: List<OdohNode> = this.relays, targets: List<OdohNode> = this.targets): List<OdohPathSpec> {
        val out = ArrayList<OdohPathSpec>()
        for (r in relays.indices) for (t in targets.indices) if (independent(relays[r], targets[t])) out.add(OdohPathSpec(r, t))
        return out
    }
}
