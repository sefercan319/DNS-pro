package app.dnshizli.core

/**
 * Ses çalma yolları, en çok tercih edilenden en uyumluya. Aynı efekt, cihaz/ROM'a göre farklı bir yolla çalabilir:
 *  - [STATIC_RELOAD]: tek bellek tamponu, durdur + yeniden yükle + çal (en hızlı, gecikmesi en az).
 *  - [STREAM_SONIFICATION]: her çalmada akış; tampon/başlatma farklarına karşı daha toleranslı.
 *  - [STREAM_MEDIA]: medya kullanım türü; bazı ROM'lar "dokunma sesi" kullanımını tamamen kısıyor.
 *  - [TONE]: sistemin kendi bip sesi (sentezlenmiş ses çalınamazsa son çare; sesin tınısı değişir ama duyulur).
 *
 * İlk iki yol Android'de "sistem sesi" kanalından çıkar (zil modu titreşim/sessizken kısılır), son ikisi "medya sesi" kanalından.
 */
enum class SoundPath(val system: Boolean) { STATIC_RELOAD(true), STREAM_SONIFICATION(true), STREAM_MEDIA(false), TONE(false) }

/** Kullanıcının ses çıkışı tercihi (☰ → Ses ve hareket → Ses çıkışı). */
enum class SoundOutput(val id: String) {
    /** Sistem sesi açıksa onu, kısıksa medya sesini kullanır; telefon sessiz/titreşimdeyse çalmaz. */
    AUTO("auto"),
    /** Yalnızca sistem sesi (dokunma sesleri gibi). */
    SYSTEM("system"),
    /** Yalnızca medya sesi (oyunlar gibi): zil modundan bağımsızdır, medya seviyesi sıfır değilse çalar. */
    MEDIA("media"),
}

enum class Ringer { NORMAL, VIBRATE, SILENT }

/** Neden çalınmadığı (kullanıcıya açıklanabilir); [NONE] = çalınabilir. */
enum class SoundBlock { NONE, RINGER, ZERO_VOLUME }

/**
 * Cihazın anlık ses durumu (Android'de AudioManager'dan okunur). Android'de "sistem" kanalı zil moduna bağlıdır: titreşim ya da
 * sessiz modda sistem kanalından çalan ses duyulmaz, ama API "çalıyor" der. Eski sürümün sessizlik sorununun ana nedeni buydu:
 * çalma başarılı sayılıyor, yedek yola hiç geçilmiyordu.
 */
data class AudioState(
    val ringer: Ringer,
    val systemVol: Int,
    val systemMuted: Boolean,
    val mediaVol: Int,
    val mediaMuted: Boolean,
) {
    val systemAudible: Boolean get() = ringer == Ringer.NORMAL && !systemMuted && systemVol > 0
    val mediaAudible: Boolean get() = !mediaMuted && mediaVol > 0
}

class SoundPlan(val paths: List<SoundPath>, val block: SoundBlock)

/** Ses durumuna ve tercihe göre hangi yolların denenebileceğine karar verir. Saf mantık. */
object SoundRoute {
    private val ALL = SoundPath.values().toList()
    private val SYS = ALL.filter { it.system }
    private val MEDIA = ALL.filter { !it.system }

    fun plan(state: AudioState?, out: SoundOutput): SoundPlan {
        if (state == null) return when (out) {          // durum okunamadı: tercih edilen kanaldan sırayla dene
            SoundOutput.AUTO -> SoundPlan(ALL, SoundBlock.NONE)
            SoundOutput.SYSTEM -> SoundPlan(SYS, SoundBlock.NONE)
            SoundOutput.MEDIA -> SoundPlan(MEDIA, SoundBlock.NONE)
        }
        return when (out) {
            SoundOutput.AUTO -> when {
                state.ringer == Ringer.SILENT -> SoundPlan(emptyList(), SoundBlock.RINGER)   // yalnızca TAM sessiz modda sus
                // Medya kanalı kısıksa ona düşmek sessizlik demektir: yalnızca duyulabilir kanalların yolları denenir.
                state.systemAudible -> SoundPlan(if (state.mediaAudible) ALL else SYS, SoundBlock.NONE)
                // Titreşim modunda sistem kanalı duyulmaz; medya açıksa oyun/klavye sesleri gibi medyadan çalarız (sistem sesi sıfırsa da aynı — Samsung'da sık).
                state.mediaAudible -> SoundPlan(MEDIA, SoundBlock.NONE)
                state.ringer != Ringer.NORMAL -> SoundPlan(emptyList(), SoundBlock.RINGER)   // titreşim ama medya da kapalı: nedeni zil modu
                else -> SoundPlan(emptyList(), SoundBlock.ZERO_VOLUME)
            }
            SoundOutput.SYSTEM -> when {
                state.systemAudible -> SoundPlan(SYS, SoundBlock.NONE)
                state.ringer != Ringer.NORMAL -> SoundPlan(emptyList(), SoundBlock.RINGER)
                else -> SoundPlan(emptyList(), SoundBlock.ZERO_VOLUME)
            }
            SoundOutput.MEDIA -> if (state.mediaAudible) SoundPlan(MEDIA, SoundBlock.NONE) else SoundPlan(emptyList(), SoundBlock.ZERO_VOLUME)
        }
    }
}

/**
 * Hoparlör ısınması. Birçok telefonda (özellikle Samsung) ses donanımı birkaç saniye boşta kalınca bekleme kipine girer; uyanırken
 * ilk 60–150 ms yutulur. Efektlerimiz kısa olduğu için (dokunuş ~60 ms) bu, sesin tamamen kaybolması demektir. Çıkış soğuksa
 * sesin önüne kısa bir sessizlik eklenir; art arda dokunuşlarda (çıkış sıcakken) gecikme eklenmez.
 */
class SoundWarmup(private val coldAfterMs: Long = COLD_AFTER_MS, private val preRollMs: Int = PRE_ROLL_MS) {
    private var warmUntil = Long.MIN_VALUE / 2

    /** Bu çalmanın önüne eklenecek sessizlik (ms). */
    fun preRoll(now: Long): Int = if (now >= warmUntil) preRollMs else 0

    /** Çalma başladı; [durationMs] sürecek. Çıkış, bittikten [coldAfterMs] sonrasına kadar sıcak sayılır. */
    fun played(now: Long, durationMs: Long) { warmUntil = now + durationMs.coerceAtLeast(0) + coldAfterMs }

    companion object {
        const val COLD_AFTER_MS = 2_500L
        const val PRE_ROLL_MS = 90
    }
}

/** Android tarafının çalma işlemi. [play] true dönerse çalma başlatıldı demektir; hata fırlatabilir (sarmalanır). */
interface SoundBackend {
    fun play(path: SoundPath, e: Sfx, volume: Float): Boolean
}

/**
 * Hangi yolun çalıştığını hatırlayan ve başarısız olunca sıradakine geçen seçici. Saf mantık: Android'den bağımsızdır.
 * - Cihazda çalıştığı bilinen en iyi yol ([best]) önce denenir; olmazsa sırayla diğerleri. Sıra bittiyse sessizce vazgeçilir.
 * - [best] yalnızca bir yol gerçekten başarısız olunca değişir (aşağı iner). Ses durumu yüzünden atlanan yollar (ör. telefon
 *   titreşimde) cihazın yeteneği hakkında bir şey söylemez: hatırlanan yolu bozmaz.
 * - "Sessiz başarı": API çalıyor dese de çalma kafası hiç ilerlemezse ([stalled]), o yol iki kez üst üste böyle olunca aşağı inilir.
 * - Kayıtlı yol en iyisi değilse, her oturumda bir kez bir üst yol yeniden denenir: geçici bir aksaklık cihazı kalıcı olarak
 *   bip sesine mahkûm etmez.
 * - Çalışan yol değişince [remember] çağrılır (kalıcı kayıt) ve günlüğe yazılır. Hata satırlarında kişisel veri yok.
 */
class SoundCompat(
    private val backend: SoundBackend,
    initial: SoundPath?,
    private val remember: (SoundPath) -> Unit,
    private val log: (String) -> Unit,
) {
    @Volatile var best: SoundPath? = initial
        private set
    /** Üst üste başarısız çalma sayısı (tanılama için). */
    @Volatile var failures = 0
        private set
    private var promoteTried = initial == null || initial == SoundPath.STATIC_RELOAD
    private val stalls = IntArray(SoundPath.values().size)

    /** Efekti çalar (tüm yollar serbest). Çalan yolu döner; hiçbiri çalamazsa null. */
    fun play(e: Sfx, volume: Float): SoundPath? = play(e, volume, SoundPath.values().toList())

    /** Efekti yalnızca [allowed] yollardan biriyle çalar. */
    fun play(e: Sfx, volume: Float, allowed: List<SoundPath>): SoundPath? {
        if (allowed.isEmpty()) return null
        val order = order(allowed)
        var failedAny = false
        for (p in order) {
            val ok = try {
                backend.play(p, e, volume)
            } catch (ex: Throwable) {
                log("ses yolu ${p.name} hata: ${ex.javaClass.simpleName}")
                false
            }
            if (ok) {
                failures = 0
                val b = best
                // Yalnızca gerçek bir başarısızlıktan sonra, ya da ilk kez/üst yol denemesi başarılıysa hatırla.
                if (b == null || (failedAny && p.ordinal > b.ordinal) || p.ordinal < b.ordinal) setBest(p)
                return p
            }
            failedAny = true
        }
        failures++
        if (failures == 1 || failures % 50 == 0) log("hiçbir ses yolu çalamadı (üst üste $failures)")
        return null
    }

    private fun order(allowed: List<SoundPath>): List<SoundPath> {
        val b = best ?: return allowed
        val res = ArrayList<SoundPath>(allowed.size + 1)
        if (!promoteTried) {
            promoteTried = true
            val up = allowed.filter { it.ordinal < b.ordinal }.maxByOrNull { it.ordinal }
            if (up != null) res.add(up)                                     // oturumda bir kez: bir üst yolu dene
        }
        // Bilinen en iyi yoldan başla; ondan daha iyi yollar (bozuk bilindiği için) sona.
        for (p in allowed) if (p.ordinal >= b.ordinal && p !in res) res.add(p)
        for (p in allowed) if (p !in res) res.add(p)
        return res
    }

    /** Çalma kafası beklenen sürede hiç ilerlemedi: API "çalıyor" dedi ama ses çıkmadı. */
    fun stalled(path: SoundPath) {
        val n = ++stalls[path.ordinal]
        log("ses yolu ${path.name}: çalma ilerlemedi ($n)")
        // Bazı cihazlar çalma kafasını yanlış bildirebilir: bu yüzden bu yolla oturumda en çok bir kez, bip sesine hiç inilmez.
        if (n >= STALL_LIMIT && best == path && !stallDemoted) {
            val next = SoundPath.values().getOrNull(path.ordinal + 1) ?: return
            if (next == SoundPath.TONE) return
            stalls[path.ordinal] = 0
            stallDemoted = true
            setBest(next)
        }
    }
    private var stallDemoted = false

    /** Çalma kafası ilerledi: yol gerçekten çalışıyor. */
    fun rendered(path: SoundPath) { stalls[path.ordinal] = 0 }

    private fun setBest(p: SoundPath) {
        if (best == p) return
        best = p
        try { remember(p) } catch (_: Throwable) {}
        log("ses yolu: ${p.name}")
    }

    companion object { const val STALL_LIMIT = 2 }
}
