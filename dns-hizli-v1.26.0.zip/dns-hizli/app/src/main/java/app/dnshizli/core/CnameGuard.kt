package app.dnshizli.core

/**
 * Gizli izleyici (CNAME) engeli. Sitenin kendi alt alan adı (ör. "metrik.site.com") bir izleyici sunucusuna CNAME ile
 * yönlendirilebilir; yalnızca SORULAN adı denetleyen süzgeçler bunu göremez. Burada üst DNS'ten gelen CEVAP incelenir: zincir
 * engelli bir adda bitiyorsa cevap, engelleme cevabı ("boş adres") ile DEĞİŞTİRİLİR ve önbelleğe öyle girer.
 *
 * Güvenlik ve sağlamlık: yalnızca başarılı (NOERROR), tek sorulu cevaplara dokunur; bozuk, kesik ya da çok uzun zincirli
 * cevaplar olduğu gibi bırakılır (süzgeç hiçbir zaman bağlantıyı bozmaz). Kullanıcı izin listesi her zaman üstündür.
 * Aynı yerde DNS yeniden bağlama koruması da uygulanır ([FilterEngine.rebindVerdict]): genel bir ad yerel ağ adresine
 * çözülürse cevap engelleme cevabıyla değiştirilir.
 * Cevap alıcı iş parçacıkları paralel çalışır; her iş parçacığı motorun KENDİ kopyasını ([FilterEngine.fork]) kullanır.
 */
internal object CnameGuard {
    private class Slot(var source: FilterEngine?, var mine: FilterEngine?)
    private val local = ThreadLocal<Slot>()

    /** Engellenen gizli izleyici sayısı (test ve istatistik için). */
    private val blockedCount = java.util.concurrent.atomic.AtomicLong()
    val blocked: Long get() = blockedCount.get()

    /** Yeniden bağlama koruması nedeniyle engellenen cevap sayısı. */
    private val rebindCount = java.util.concurrent.atomic.AtomicLong()
    val rebindBlocked: Long get() = rebindCount.get()

    /**
     * [b] içinde [base] konumundan başlayan [n] baytlık DNS cevabını denetler. Engellenmeliyse cevabı yerinde engelleme
     * cevabına çevirir ve yeni uzunluğu; aksi halde [n]'i döner. (Uzunluk her zaman >0.)
     */
    fun guard(b: ByteArray, base: Int, n: Int): Int {
        val src = FilterRuntime.engine ?: return n
        val rebind = FilterRuntime.rebind
        if (!src.active && !rebind) return n
        var s = local.get()
        if (s == null) { s = Slot(null, null); local.set(s) }
        var e = s.mine
        if (e == null || s.source !== src) { e = src.fork(); s.source = src; s.mine = e }
        var v = if (src.active) e.cnameVerdict(b, base, n) else FilterVerdict.PASS
        if (v == FilterVerdict.PASS && rebind && e.rebindVerdict(b, base, n)) { rebindCount.incrementAndGet(); v = FilterVerdict.LIST }
        if (v == FilterVerdict.PASS) return n
        val qEnd = Dns.questionEnd(b, base, n)
        if (qEnd <= base) return n
        val out = FilterEngine.buildBlocked(b, base, qEnd, b, base)
        if (out <= 0 || base + out > b.size) return n
        blockedCount.incrementAndGet()
        FilterLive.note(queryName(b, base, qEnd), v == FilterVerdict.USER)
        return out
    }

    /** Sorulan ad (yalnızca engellenen cevaplar için; ayırma yapar). */
    private fun queryName(b: ByteArray, base: Int, qEnd: Int): String {
        val sb = StringBuilder()
        var i = base + Packets.DNS_HDR
        while (i < qEnd) {
            val l = b[i].toInt() and 0xFF
            if (l == 0 || (l and 0xC0) != 0 || i + 1 + l > qEnd) break
            if (sb.isNotEmpty()) sb.append('.')
            for (k in 1..l) sb.append((b[i + k].toInt() and 0xFF).toChar().lowercaseChar())
            i += 1 + l
        }
        return sb.toString()
    }
}
