package app.dnshizli.core

/**
 * Üretici uyumluluğu: bazı Android sürümleri (özellikle Çinli üreticilerin arayüzleri) arka plandaki uygulamaları pil için
 * kapatır, telefon açılınca uygulamanın başlamasını ("otomatik başlatma") engeller. Bunun ayarı her üreticide başka bir
 * ekrandadır. Bu nesne üreticiyi tanır ve denenecek ekranları sırayla verir; saf mantıktır (Android'den bağımsız, sınanabilir).
 *
 * Ekran adları üreticilerin yıllardır değişmeyen, herkesçe bilinen ayar ekranlarıdır (bkz. dontkillmyapp.com). Hiçbiri izin
 * gerektirmez; açılamazsa (sürüm değişmiş, ekran yok) sıradakine geçilir ve en sonda Android'in standart ekranları denenir.
 */
object OemCompat {
    enum class Family(val aggressive: Boolean) {
        XIAOMI(true), HUAWEI(true), HONOR(true), OPPO(true), VIVO(true), ONEPLUS(true), TRANSSION(true), MEIZU(true), ASUS(true),
        SAMSUNG(false), GOOGLE(false), OTHER(false),
    }

    sealed class Target {
        /** Android'in uygulama ayrıntıları ekranı (Xiaomi ve Samsung'da pil + otomatik başlatma buradadır). */
        object AppDetails : Target()
        /** Android'in "pil optimizasyonu" listesi. */
        object BatteryList : Target()
        /** Üreticiye özgü ekran. */
        data class Component(val pkg: String, val cls: String) : Target()
    }

    fun family(manufacturer: String?, brand: String?): Family {
        val m = (manufacturer ?: "").lowercase().trim()
        val b = (brand ?: "").lowercase().trim()
        fun any(vararg k: String) = k.any { m.contains(it) || b.contains(it) }
        return when {
            any("xiaomi", "redmi", "poco") -> Family.XIAOMI
            any("honor") -> Family.HONOR                                 // Honor, Huawei'den önce: bağımsız şirket, ayrı paket
            any("huawei") -> Family.HUAWEI
            any("oneplus") -> Family.ONEPLUS
            any("oppo", "realme") -> Family.OPPO
            any("vivo", "iqoo") -> Family.VIVO
            any("tecno", "infinix", "itel", "transsion") -> Family.TRANSSION
            any("meizu") -> Family.MEIZU
            any("asus") -> Family.ASUS
            any("samsung") -> Family.SAMSUNG
            any("google") -> Family.GOOGLE
            else -> Family.OTHER
        }
    }

    private val COLOROS = listOf(
        Target.Component("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
        Target.Component("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"),
        Target.Component("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
    )

    /** Pil/otomatik başlatma için denenecek ekranlar, en uygundan başlayarak. Hep standart ekranlarla biter. */
    fun batteryTargets(f: Family): List<Target> {
        val oem: List<Target> = when (f) {
            // MIUI/HyperOS: uygulama ayrıntılarında hem "Otomatik başlatma" hem "Pil tasarrufu" vardır.
            Family.XIAOMI -> listOf(Target.AppDetails, Target.Component("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"))
            Family.HUAWEI -> listOf(
                Target.Component("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
                Target.Component("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"),
            )
            Family.HONOR -> listOf(Target.Component("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"))
            Family.OPPO -> COLOROS
            Family.ONEPLUS -> listOf(Target.Component("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity")) + COLOROS
            Family.VIVO -> listOf(
                Target.Component("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
                Target.Component("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"),
            )
            Family.TRANSSION -> listOf(Target.Component("com.transsion.phonemaster", "com.cyin.himgr.autostart.AutoStartActivity"))
            Family.MEIZU -> listOf(Target.Component("com.meizu.safe", "com.meizu.safe.permission.SmartBGActivity"))
            Family.ASUS -> listOf(Target.Component("com.asus.mobilemanager", "com.asus.mobilemanager.powersaver.PowerSaverSettings"))
            // One UI: uygulama ayrıntıları → Pil → "Kısıtlanmamış" en kısa yoldur ("uyuyan uygulamalar"dan da çıkarır).
            Family.SAMSUNG -> listOf(Target.AppDetails)
            Family.GOOGLE, Family.OTHER -> emptyList()
        }
        val tail = if (Target.AppDetails in oem) listOf(Target.BatteryList) else listOf(Target.BatteryList, Target.AppDetails)
        return oem + tail
    }
}
