package app.dnshizli.platform

import android.app.AlarmManager
import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.system.ErrnoException
import android.system.Os
import android.system.OsConstants
import android.system.StructPollfd
import app.dnshizli.core.AdBlockResult
import app.dnshizli.core.FilterLive
import app.dnshizli.core.FilterLevel
import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.Gateway
import app.dnshizli.core.FilteringForwarder
import app.dnshizli.core.AppScope
import app.dnshizli.core.AppScopes
import app.dnshizli.core.AppSettings
import app.dnshizli.core.Bootstrap
import app.dnshizli.core.Catalog
import app.dnshizli.core.CheckResult
import app.dnshizli.core.ConnectionCheck
import app.dnshizli.core.DnsForwarder
import app.dnshizli.core.DnsServer
import app.dnshizli.core.DnssecResult
import app.dnshizli.core.DohUrl
import app.dnshizli.core.EndReason
import app.dnshizli.core.Encryption
import app.dnshizli.core.OdohAddressBook
import app.dnshizli.core.OdohBootstrap
import app.dnshizli.core.OdohCatalog
import app.dnshizli.core.OdohEngine
import app.dnshizli.core.OdohMode
import app.dnshizli.core.Format
import app.dnshizli.core.Forwarder
import app.dnshizli.core.HealPlan
import app.dnshizli.core.SinkholeForwarder
import app.dnshizli.core.HealthMonitor
import app.dnshizli.core.Ip
import app.dnshizli.core.IpMode
import app.dnshizli.core.Journal
import app.dnshizli.core.NetFamilies
import app.dnshizli.core.NetKind
import app.dnshizli.core.OrbState
import app.dnshizli.core.Proto
import app.dnshizli.core.Rules
import app.dnshizli.core.ScopePlan
import app.dnshizli.core.lightEffective
import app.dnshizli.core.SecureForwarder
import app.dnshizli.core.SecureTarget
import app.dnshizli.core.TcpDns
import app.dnshizli.core.SelfTest
import app.dnshizli.core.SelfTestResult
import app.dnshizli.core.ServerList
import app.dnshizli.core.Session
import app.dnshizli.core.Targets
import app.dnshizli.ui.Strings
import app.dnshizli.ui.VpnUi
import java.io.FileDescriptor
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory

/**
 * DNS-only VPN: telefonda yerel bir tünel arayüzü açar, yalnızca sahte DNS adreslerine (IPv4 10.111.222.2 ve, kurulabilirse,
 * IPv6 fd6e:7368:a1c2::2) giden paketleri bu arayüze yönlendirir. Gelen DNS sorgularını bir [Forwarder] seçilen sunucuya iletir: düz DNS
 * ([DnsForwarder]) ya da şifreli DNS ([SecureForwarder], DoT/DoH). Diğer tüm trafik normal yolundan, hiç dokunulmadan devam eder.
 *
 * Kaynak kullanımı:
 *  - Tünel okuyucu `poll()` ile bloklanır: paket yokken hiç uyanmaz.
 *  - Durum değişiklikleri tek bir çalışan iş parçacığında sıralanır; yarış durumu ve kilit karmaşası yok.
 *  - Ağ izleme sistem olaylarıyla çalışır. İstatistikler trafik varken en çok dakikada bir depoya aktarılır.
 *
 * Dayanıklılık:
 *  - Otomatik şifrelemede şifreli yöntem kurulamazsa şifresiz DNS'e düşülür ve kullanıcı uyarılır; her ağ değişiminde ve
 *    10 dakikada bir şifreli yönteme dönülmeye çalışılır. "Sıkı şifreleme" açıksa hiç düşülmez.
 *  - Bağlantı ağ yokken kurulduysa (açılışta) ilk ağ olayında doğrulanır; yeni ağda yanıt yoksa yöntemler baştan denenir.
 *  - Seçili sunucu yanıt vermezse (ayarlıysa) yedek sunucuya bağlanılır.
 *  - Kendiliğinden (açılış, sistem, duraklatma sonu) başlayan bağlanmalar ve kopmalar artan aralıklarla yeniden denenir.
 *  - Duraklatma sırasında servis önplanda kalır (geri sayımlı bildirim); süre bitince izin gerektirmeyen bir zamanlayıcı ve
 *    yedek bir sistem alarmı ([PauseAlarm]) bağlantıyı sürdürür. Telefon yeniden başlasa da alarm yeniden kurulur.
 *
 * Her şey `cancelGen` ile iptal edilebilir: kullanıcı bağlanırken "kes" derse süren deneme en yakın noktada bırakılır.
 */
class DnsVpnService : VpnService() {

    private lateinit var prefs: PrefsStore
    private val main = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor { r -> Thread(r, "dns-vpn").also { it.isDaemon = true } }
    private val lock = Any()
    private val random = SecureRandom()
    private val live: () -> VpnUi = { snapshot() }
    private val tap = SelfTest.Tap()

    @Volatile private var watcher: NetworkWatcher? = null

    // Tünel durumu: yazma yalnızca çalışan iş parçacığında (ve [lock] altında); okuma her yerden.
    @Volatile private var tun: Tunnel? = null
    @Volatile private var fw: Forwarder? = null

    /** Ağ geçidi (DPI atlatma / Reklam+): tünel açıkken çalışır; yalnızca çalışan iş parçacığı yazar. */
    @Volatile private var gw: Gateway? = null

    /** Tünelde DNS yok, yalnızca ağ geçidi var (DNS düğmesi kapalı). Bu durumda [state] OFF kalır. */
    @Volatile private var gwOnlyNow = false
    private var lastNetHandle = 0L          // son bilinen fiziksel ağ (NetworkWatcher.handleOf); yalnızca servis iş parçacığı
    private var netWasLost = false

    /** Güvenlik vanası modülleri kapattı (bir sonraki modül komutuna dek arayüze bildirilir). */
    @Volatile private var gwTripped = false
    private var gwBadTicks = 0
    @Volatile private var state = OrbState.OFF
    @Volatile private var serverId: String? = null
    @Volatile private var sinceMs = 0L
    @Volatile private var lastError: String? = null
    @Volatile private var lastInfo: String? = null
    @Volatile private var baseQueries = 0L
    @Volatile private var baseHits = 0L
    @Volatile private var baseBlocked = 0L
    @Volatile private var pausedUntil = 0L

    /** Şifreli yöntem planlanmışken şifresiz DNS'e düşüldü. */
    @Volatile private var downgraded = false
    @Volatile private var odohEngineRef: OdohEngine? = null

    /** Tünelde IPv6 DNS adresi de var mı (kurulamazsa yalnızca IPv4). */
    @Volatile private var tunnelV6 = false

    /** Bu ağın kullanabildiği IP aileleri; yukarı akış adreslerinin sırasını belirler. */
    @Volatile private var netFamilies = NetFamilies.UNKNOWN

    /** Son denemelerde sunucunun TLS sertifikası reddedildi (araya girme ya da yanlış sunucu belirtisi). */
    @Volatile private var untrusted = false

    /**
     * Sunucuya tünelden gönderilen kendi sorgumuz ulaşıyor ama telefonun çözümleyicisi sorgularını tünele göndermiyor
     * (ör. Özel DNS sabit ya da ağ ayarı henüz uygulanmadı). Bağlantı "kurulu" sayılır, kullanıcı uyarılır, arka planda
     * yeniden sınanır ([recheckTask]).
     */
    @Volatile private var phoneBypass = false
    private var bypassChecks = 0

    /** Kendiliğinden yeniden deneme sürüyor (açılış/sistem bağlantısı ya da kopma). */
    @Volatile private var retrying = false
    private var retryStep = 0

    @Volatile private var cancelGen = 0
    @Volatile private var lastStartId = 0
    @Volatile private var destroyed = false
    @Volatile private var lastFlush = 0L

    // Toplamlara aktarım sayaçları (yalnızca [lock] altında)
    private var flushedQueries = 0L
    private var flushedHits = 0L
    private var flushedBlocked = 0L
    private var flushedAnswered = 0L
    private var flushedLatency = 0L
    private var flushedUp = 0L
    private var flushedDown = 0L
    private var flushedAt = 0L
    private val retired = ArrayList<Forwarder>()

    // Oturum (bağlantı geçmişi için). Çoğunlukla çalışan iş parçacığında; iptalde ([onRevoke]) ana iş parçacığından da kapanır.
    @Volatile private var sessionServer: String? = null
    @Volatile private var sessionProto = Proto.PLAIN
    @Volatile private var sessionStart = 0L
    @Volatile private var sessionBase = 0L

    /**
     * "Kapalı kalırsa dur" (ayar): gerçek bağlantı yokken tünel açık kalır ve [sink] her sorguya hemen hata cevabı verir; sorgular
     * operatörün DNS'ine sızmaz. Yalnızca çalışan iş parçacığı yazar.
     */
    @Volatile private var sealed = false
    private var sink: SinkholeForwarder? = null
    private var lastNetRetryAt = 0L

    /** Bu kopma/zaman aşımı dönemi için zaman aşımı bildirimi gösterildi (sağlıklı cevap gelince ya da bağlanınca sıfırlanır). */
    private var timeoutNotified = false
    private val samples: (IntArray) -> Int = { out -> fw?.latencies(out) ?: 0 }
    private var openError = ""
    private var openRetryable = false

    private val retryTask = Runnable { submit(lastStartId) { retryNow() } }
    private val upgradeTask = Runnable { submit(lastStartId) { tryUpgrade() } }
    private val recheckTask = Runnable { submit(lastStartId) { recheckPhone() } }
    private val healthTask = Runnable { submit(lastStartId) { healthTick() } }
    private val gwTask = Runnable { submit(lastStartId) { gwTick() } }
    private val health = HealthMonitor()
    private var healStep = 0
    private var lastHealAt = 0L
    private val pauseListener = AlarmManager.OnAlarmListener { submit(lastStartId) { resumeFromAlarm() } }

    // ------------------------------------------------------------------ yaşam döngüsü

    override fun onCreate() {
        super.onCreate()
        prefs = PrefsStore(this)
        App.applyLanguage(this, prefs.loadSettings().lang)
        Notifier.ensureChannel(this)
        pausedUntil = prefs.pausedUntil()
        VpnStatus.live = live
        VpnStatus.samples = samples
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastStartId = startId
        // startForegroundService() sözü: kısa sürede startForeground() çağrılmalı. Her komutta, durumu yansıtan bildirimle çağırırız.
        foreground(currentNotification())

        val action = intent?.action
        val wanted = intent?.getStringExtra(EXTRA_SERVER)
        val minutes = intent?.getIntExtra(EXTRA_MINUTES, 15) ?: 15
        val auto = intent?.getBooleanExtra(EXTRA_AUTO, false) == true
        val modDpi = intent?.getBooleanExtra(EXTRA_DPI, false) == true
        val modAds = intent?.getBooleanExtra(EXTRA_ADS, false) == true     // açılış, güncelleme, duraklatma sonu: başarısızsa yeniden dene
        if (action == ACTION_DISCONNECT || action == ACTION_PAUSE) cancelGen++
        // Komutun geldiği andaki iptal numarası: sıradayken "kes" gelirse bu komut hiç başlamadan düşer.
        val gen = cancelGen

        submit(startId) {
            when {
                action == ACTION_DISCONNECT -> disconnect(startId)
                action == ACTION_PAUSE -> pause(minutes, startId)
                action == ACTION_RESUME -> { clearPause(); cancelRetry(); markAuto(auto); connect(null, startId, gen) }
                action == ACTION_CONNECT -> {
                    clearPause(); cancelRetry(); markAuto(auto)
                    if (!auto) prefs.setDnsOn(true)          // kullanıcı DNS düğmesine bastı (açılış/otomatik denemeler son durumu korur)
                    connect(wanted, startId, gen)
                }
                action == ACTION_DNS_OFF -> dnsOff(startId, gen)
                action == ACTION_MODULES -> applyModules(startId, gen, modDpi, modAds)
                action == ACTION_NEXT -> next(startId)
                action == ACTION_REAPPLY -> { reapply(gen); idleShutdown(startId) }
                action == ACTION_REBUILD -> { rebuild(startId, gen); idleShutdown(startId) }
                action == ACTION_TEST -> { runTest(); idleShutdown(startId) }
                action == ACTION_CLEAR_CACHE -> {
                    fw?.clearCache(); Journal.add("önbellek temizlendi")
                    if (state != OrbState.ON && !pausedNow() && !retrying) shutdown(startId)
                }
                // Süreç duraklatma sırasında öldürülüp yeniden başlatıldıysa: duraklatmaya devam.
                action == null && pausedNow() -> enterPaused()
                // Sistemden (her zaman açık VPN, açılış) ya da süreç öldürüldükten sonra yeniden başlatma: kendiliğinden
                // bağlanma; başarısız olursa artan aralıklarla yeniden denenir.
                action == SERVICE_INTERFACE || prefs.loadSettings().wasActive -> { retrying = true; retryStep = 0; connect(null, startId, gen) }
                else -> shutdown(startId)
            }
        }
        return START_STICKY
    }

    /** Kendiliğinden başlayan bağlanma (açılış, güncelleme, duraklatma sonu): başarısızsa artan aralıklarla yeniden denenir. */
    private fun markAuto(auto: Boolean) {
        if (!auto) return
        retrying = true
        retryStep = 0
        prefs.setWasActive(true)           // süreç bu sırada ölürse yeniden başlatma bağlanmayı sürdürsün
    }

    /** Bağlı değilken gelen yan komutlar (test, yeniden uygulama) servisi önplanda asılı bırakmasın. */
    private fun idleShutdown(startId: Int) {
        if (state != OrbState.ON && tun == null && !pausedNow() && !retrying && !sealed) shutdown(startId)
    }

    /** Sistem VPN'i iptal etti (başka bir VPN uygulaması veya kullanıcı). Temizle ve durumu bildir. */
    override fun onRevoke() {
        Journal.add("sistem VPN bağlantısını iptal etti")
        val wasOn = state == OrbState.ON
        cancelGen++
        main.removeCallbacks(retryTask)
        main.removeCallbacks(upgradeTask)
        retrying = false
        synchronized(lock) {
            // Önce bağlı geçen süre ve sayılar aktarılır (durum ERROR olunca saniyeler sayılmaz).
            flushTotalsLocked()
            state = OrbState.ERROR
            lastError = Strings.ERR_REVOKED
        }
        endSession(EndReason.REVOKED)
        prefs.setWasActive(false)
        prefs.setModules(false, false)
        prefs.setDnsOn(true)
        // Soket kapatma (TLS close_notify) ana iş parçacığında ağ işi sayılır: ayrı iş parçacığında yapılır.
        Thread({ teardown(); publish() }, "dns-teardown").start()
        publish()
        if (wasOn) notifyDrop(Strings.ERR_REVOKED)
        super.onRevoke()   // servisi durdurur
    }

    override fun onDestroy() {
        destroyed = true
        cancelGen++
        main.removeCallbacks(retryTask)
        main.removeCallbacks(upgradeTask)
        main.removeCallbacks(healthTask)
        cancelListener()
        worker.shutdownNow()
        Thread({ teardown() }, "dns-teardown").start()
        if (!pausedNow()) Notifier.cancel(this)
        val before = try { VpnStatus.snapshot().state } catch (_: Exception) { null }
        if (VpnStatus.live === live) VpnStatus.live = null
        if (VpnStatus.samples === samples) VpnStatus.samples = null
        // Servis "bağlı" görünürken sessizce kapandıysa (ör. bildirimden Kes) eski durum kalmasın: kutucuk ve widget yanlış göstermesin.
        // Hata (ERROR) ve duraklatma durumları olduğu gibi kalır.
        if (!pausedNow() && (before == OrbState.ON || before == OrbState.CONNECTING)) try { VpnStatus.publish(VpnUi()) } catch (_: Exception) {}
        super.onDestroy()
    }

    // ------------------------------------------------------------------ komutlar (çalışan iş parçacığı)

    private fun submit(startId: Int, task: () -> Unit) {
        try {
            worker.execute {
                try {
                    task()
                } catch (e: Throwable) {
                    Journal.add("beklenmeyen hata: ${e.javaClass.simpleName}")
                    // Çalışan bir bağlantı tek bir yan işin hatası yüzünden kapatılmaz; yalnızca bağlanmaya çalışırken hata varsa vazgeçilir.
                    try {
                        if (state == OrbState.ON && tun != null) publish() else fail(Strings.ERR_UNKNOWN, startId)
                    } catch (_: Throwable) {}
                }
            }
        } catch (_: RejectedExecutionException) {
            // servis kapanıyor
        }
    }

    private fun pausedNow(): Boolean = pausedUntil > 0L

    private fun connect(requested: String?, startId: Int, gen: Int) {
        if (destroyed || cancelGen != gen) return     // servis kapanıyor ya da komut sıradayken iptal edildi
        val settings = prefs.loadSettings()
        if (!settings.dnsOn && gwWanted(settings)) {
            // DNS düğmesi kapalı, yalnızca modüller isteniyor.
            if (gwOnlyNow && tun != null) publish() else startGatewayOnly(settings, startId, gen)
            return
        }
        val kind = NetworkWatcher.currentKind(this)
        val id = requested?.takeIf { Catalog.byId(it) != null } ?: Rules.initialServer(settings, kind)
        val server = Catalog.byId(id) ?: Catalog.default
        if (tun != null && state == OrbState.ON) {
            if (server.id == serverId) publish() else switchServer(server, settings, gen)
        } else {
            if (gwOnlyNow) teardown()                  // DNS'siz tünel yerine DNS'li yeni tünel kurulacak
            startTunnel(server, settings, kind, startId, gen)
        }
    }

    private fun startTunnel(server: DnsServer, settings: AppSettings, kind: NetKind, startId: Int, gen: Int) {
        Journal.add("bağlanıyor: ${server.name}")
        FilterLive.clear()
        FilterLive.keep(settings.keepHistory)
        FilterRuntime.setGateway(gwLevelFor(settings))
        FilterRuntime.setLight(settings.lightEffective())
        FilterRuntime.rebind = settings.rebindGuard
        FilterRuntime.update(settings.filterLevel, settings.filterAllow, settings.filterBlock)
        main.removeCallbacks(upgradeTask)
        synchronized(lock) {
            state = OrbState.CONNECTING
            serverId = server.id
            lastError = null
            lastInfo = null
            sinceMs = System.currentTimeMillis()
            baseQueries = 0
            baseHits = 0
            baseBlocked = 0
            downgraded = false
        }
        untrusted = false
        netFamilies = NetworkWatcher.families(this)
        publish()

        val plan = settings.plan(server)
        if (plan.isEmpty()) {
            fail(noProtoMessage(server, settings), startId)
            return
        }
        if (prepare(this) != null) { fail(Strings.ERR_PERMISSION, startId); return }
        strictPrivateDns()?.let { host -> fail(Strings.errPrivateDns(host), startId); return }

        // Kapalı kalırsa dur: DNS'i tutan tünel varsa yeniden kurulmaz, içindeki yönlendirici gerçeğiyle değiştirilir.
        val t = (if (sealed) tun else null) ?: openTunnel(settings) ?: run {
            if (!destroyed) fail(openError, startId, retryable = openRetryable)
            return
        }

        var used = server
        var chosen = tryPlan(server, settings, t, plan, kind, gen)
        if (cancelGen != gen || destroyed) return
        if (chosen == null) {
            // Seçili sunucu yanıt vermedi: yedek sunucu ayarlıysa onu dene.
            val backup = if (settings.odoh == OdohMode.STRICT) null else backupFor(server, settings)
            if (backup != null) {
                Journal.add("yedek sunucu deneniyor: ${backup.name}")
                synchronized(lock) { serverId = backup.id }
                chosen = tryPlan(backup, settings, t, settings.plan(backup).filter { it != Proto.ODOH }, kind, gen)
                if (cancelGen != gen || destroyed) return
                if (chosen != null) {
                    used = backup
                    lastInfo = Strings.backupUsed(server.name, backup.name)
                    prefs.setSelection(backup.id, settings.withRecent(backup.id).recent)
                }
            }
        }
        if (chosen == null) {
            val strictFail = plan.none { it == Proto.PLAIN } && settings.encryption == Encryption.AUTO
            val msg = when {
                untrusted -> Strings.errUntrusted(server.name)
                settings.odoh == OdohMode.STRICT -> Strings.ERR_NO_ODOH
                strictFail -> Strings.errNoEncrypted(server.name)
                else -> Strings.errNoReply(server.name)
            }
            if (!untrusted && !strictFail) notifyTimeout(server.name)
            fail(msg, startId, retryable = true)
            return
        }

        val down = isDowngrade(settings.plan(used).firstOrNull(), chosen.proto)
        synchronized(lock) {
            state = OrbState.ON
            serverId = used.id
            sinceMs = System.currentTimeMillis()
            downgraded = down
            flushedQueries = 0; flushedHits = 0; flushedBlocked = 0
            flushedAnswered = 0; flushedLatency = 0; flushedUp = 0; flushedDown = 0
            flushedAt = SystemClock.elapsedRealtime()
            lastFlush = flushedAt
        }
        retrying = false
        retryStep = 0
        main.removeCallbacks(retryTask)
        prefs.setWasActive(true)
        Notifier.cancelAlert(this)
        Notifier.cancelTimeout(this)
        timeoutNotified = false
        if (sealed) leaveSealed()
        if (down) {
            Journal.add("şifreli bağlantı kurulamadı, düz DNS kullanılıyor")
            if (settings.notifyDrop) Notifier.downgrade(this, used.name, odoh = settings.plan(used).firstOrNull() == Proto.ODOH)
            scheduleUpgrade()
        } else {
            Notifier.cancelDowngrade(this)
        }
        startSession(used.id, chosen.proto)
        updateNotification()
        startWatcher()
        health.reset()
        scheduleHealth()
        Journal.add("bağlandı: ${used.name} (${chosen.proto.name})")
        noteBypass()
        publish()
        if (settings.notifyConnect) Notifier.connected(this, prefs.loadSettings(), used.name, Strings.protoName(chosen.proto))
    }

    /**
     * Tüneli kurar, okuyucusunu başlatır ve [tun]'a yazar. Kurulamazsa null döner; nedeni [openError], yeniden denenebilir olup
     * olmadığı [openRetryable] içindedir (çağıran [fail] ile bildirir). Servis tam bu sırada kapandıysa da null (hata yok).
     */
    private fun openTunnel(settings: AppSettings, dns: Boolean = true): Tunnel? {
        val pm = packageManager
        val scope = AppScopes.plan(settings, packageName) { p -> try { pm.getApplicationInfo(p, 0); true } catch (_: Exception) { false } }
        if (scope.kind == ScopePlan.Kind.NONE) {
            // Boş "yalnızca seçilenler" listesi Android'de tüm uygulamalar demektir: sessizce hepsine geçmek yerine başlatılmaz.
            Journal.add("seçili uygulama yok: koruma başlatılmadı")
            openError = Strings.ERR_NO_APPS; openRetryable = false
            return null
        }
        var v6 = settings.ipMode == IpMode.BOTH
        var pfd = try {
            establishTunnel(settings, v6, dns)
        } catch (e: Exception) {
            Journal.add("tünel açılamadı: ${e.javaClass.simpleName}")
            null
        }
        if (pfd == null && v6) {
            // Bazı sistemler IPv6 adresli tüneli reddeder: yalnızca IPv4 ile yeniden dene.
            Journal.add("IPv6'lı tünel kurulamadı, yalnızca IPv4 deneniyor")
            v6 = false
            pfd = try {
                establishTunnel(settings, false, dns)
            } catch (e: Exception) {
                Journal.add("tünel açılamadı: ${e.javaClass.simpleName}")
                null
            }
        }
        if (pfd == null) { openError = Strings.ERR_ESTABLISH; openRetryable = false; return null }
        tunnelV6 = v6
        Journal.add("tünel: ${if (v6) "IPv4 + IPv6" else "IPv4"}, ağ: ${netFamilies}")

        val t = try {
            Tunnel(pfd, { tunnel, why -> tunnelEnded(tunnel, why) }, { onTunnelActivity() })
        } catch (e: Exception) {
            try { pfd.close() } catch (_: Exception) {}
            Journal.add("tünel başlatılamadı: ${e.javaClass.simpleName}")
            openError = Strings.ERR_SOCKET; openRetryable = true
            return null
        }
        synchronized(lock) { tun = t }
        if (destroyed) { teardown(); return null }     // servis tam bu sırada kapandı: açılan tüneli bırakma
        if (gwWanted(settings)) attachGateway(t, settings)
        t.start()
        return t
    }

    private fun noProtoMessage(server: DnsServer, settings: AppSettings): String =
        if (settings.encryption == Encryption.AUTO) Strings.errNoEncrypted(server.name)
        else Strings.errNoProto(server.name, Strings.OPT_ENCRYPTION[settings.encryption.ordinal])

    /**
     * [plan]'daki yöntemleri sırayla dener; ilk doğrulanan yönlendiriciyi tünele takıp döner. Ağ yoksa (ör. açılışta) ilk
     * yöntem doğrulamasız kabul edilir ve ilk ağ olayında sınanır. Hiçbiri olmazsa null (tünelde yönlendirici yok).
     */
    private fun tryPlan(server: DnsServer, settings: AppSettings, t: Tunnel, plan: List<Proto>, kind: NetKind, gen: Int): Forwarder? {
        for ((i, proto) in plan.withIndex()) {
            if (cancelGen != gen || destroyed) return null
            val f = try {
                newForwarder(server, settings, t, proto)
            } catch (e: Exception) {
                Journal.add("yönlendirici (${proto.name}) başlatılamadı: ${e.javaClass.simpleName}")
                continue
            }
            t.forwarder = f
            synchronized(lock) { fw = f }
            // Bu arada servis kapandı ya da iptal edildiyse yeni yönlendirici sızmasın.
            if (destroyed || cancelGen != gen) { detach(t, f); return null }
            if (kind == NetKind.NONE) return f
            if (verify(f, gen, triesFor(proto, i == plan.size - 1), msFor(proto))) return f
            detach(t, f)
            if (cancelGen != gen) return null
            Journal.add("${proto.name} yanıt vermedi")
        }
        return null
    }

    private fun detach(t: Tunnel, f: Forwarder) {
        if (t.forwarder === f) t.forwarder = sink      // kapalı kalırsa dur açıksa sorgular yine cevapsız (sızmaz) kalır
        synchronized(lock) { if (fw === f) fw = null }
        f.close()
    }

    /** Şifreli yöntemlerde el sıkışma sürdüğü için doğrulamaya daha uzun süre tanınır. */
    private fun triesFor(proto: Proto, last: Boolean): Int = if (proto == Proto.ODOH) 3 else if (last) CHECK_TRIES else if (proto == Proto.PLAIN) 2 else 3
    private fun msFor(proto: Proto): Long = when (proto) {
        Proto.PLAIN -> CHECK_MS
        Proto.ODOH -> CHECK_MS_ODOH          // anahtar alımı + röleye TLS + hedefe giden yol
        else -> CHECK_MS_SECURE
    }

    /** Gizlilik düştü mü? Düz DNS'e inilmesi ya da ODoH beklenirken ODoH dışı bir yönteme geçilmesi. */
    private fun isDowngrade(first: Proto?, chosen: Proto): Boolean =
        (chosen == Proto.PLAIN && first != Proto.PLAIN) || (first == Proto.ODOH && chosen != Proto.ODOH)

    /** Yedek sunucu: ayarlı değilse null; "en hızlı" ise son ölçümlere göre seçili sunucu dışındaki en hızlı kullanılabilir sunucu. */
    private fun backupFor(failed: DnsServer, s: AppSettings): DnsServer? {
        val b = s.backupServer ?: return null
        val usable: (DnsServer) -> Boolean = { it.id != failed.id && it.id !in s.hidden && s.plan(it).isNotEmpty() }
        if (b == AppSettings.BACKUP_AUTO) {
            val lat = prefs.loadLatencies()
            return ServerList.fastest(Catalog.all, lat, usable)?.first ?: Catalog.all.firstOrNull(usable)
        }
        return Catalog.byId(b)?.takeIf(usable)
    }

    /**
     * Bağlıyken tüneli koparmadan sunucuyu (ya da aynı sunucuda yöntemi) değiştirir. [protos] sırayla denenir; hiçbiri
     * yanıt vermezse eskisi korunur. [force]: aynı sunucu için de yeni yönlendirici kur (ayar değişti, şifreye dönüş).
     * [quiet]: başarısızlık kullanıcıya bildirilmez (arka plandaki denemeler). @return geçildiyse true.
     */
    private fun switchServer(
        server: DnsServer, settings: AppSettings, gen: Int = cancelGen,
        protos: List<Proto> = settings.plan(server), force: Boolean = false, quiet: Boolean = false,
    ): Boolean {
        val t = tun ?: return false
        val old = fw ?: return false
        if (!force && server.id == serverId) return true
        if (!quiet) Journal.add("sunucu değişiyor: ${server.name}")
        if (protos.isEmpty()) {
            if (!quiet) publish(noProtoMessage(server, settings))
            return false
        }
        var fresh: Forwarder? = null
        untrusted = false
        for ((i, proto) in protos.withIndex()) {
            val f = try {
                newForwarder(server, settings, t, proto)
            } catch (e: Exception) {
                Journal.add("yeni yönlendirici (${proto.name}) başlatılamadı: ${e.javaClass.simpleName}")
                continue
            }
            // Yeni yönlendirici tünele takılmadan, doğrudan kendisine verilen sınama sorgusuyla denenir: bu sürede gerçek
            // sorgular çalışan eski yönlendiriciden gitmeye devam eder (yeni sunucu yanıt vermezse DNS kesilmez).
            if (verify(f, gen, triesFor(proto, i == protos.size - 1), msFor(proto), direct = true)) { fresh = f; break }
            f.close()
            if (cancelGen != gen || destroyed) return false
        }
        if (fresh == null) {
            if (!quiet) {
                Journal.add("sunucu değişmedi: ${server.name} yanıt vermedi")
                publish(if (untrusted) Strings.errUntrusted(server.name) else Strings.errNoReply(server.name))
            }
            return false
        }
        if (destroyed || cancelGen != gen) { fresh.close(); return false }
        t.forwarder = fresh
        val prevServer: String?
        synchronized(lock) {
            flushTotalsLocked()
            val os = old.stats()
            baseQueries += os.queries
            baseHits += os.cacheHits
            baseBlocked += os.blocked
            fw = fresh
            prevServer = serverId
            serverId = server.id
            flushedQueries = 0; flushedHits = 0; flushedBlocked = 0
            flushedAnswered = 0; flushedLatency = 0; flushedUp = 0; flushedDown = 0
            retired.add(old)
        }
        if (prevServer != server.id) {
            endSession(EndReason.SWITCH)
            startSession(server.id, fresh.proto)
        }
        val wasDown = downgraded
        val first = settings.plan(server).firstOrNull()
        downgraded = isDowngrade(first, fresh.proto)
        if (downgraded) {
            if (!wasDown && settings.notifyDrop) Notifier.downgrade(this, server.name, odoh = first == Proto.ODOH)
            scheduleUpgrade()
        } else {
            main.removeCallbacks(upgradeTask)
            Notifier.cancelDowngrade(this)
        }
        sessionProto = fresh.proto          // aynı sunucuda yöntem değiştiyse (şifresizden DoT'a) süre doğru yönteme yazılsın
        // Eski yönlendiricinin son cevapları gelsin diye kısa süre açık tutulur.
        main.postDelayed({ submit(lastStartId) { retire(old) } }, RETIRE_MS)
        updateNotification()
        noteBypass()
        publish()
        return true
    }

    private fun retire(f: Forwarder) {
        synchronized(lock) { retired.remove(f) }
        f.close()
    }

    /** Bildirimdeki "Sonraki": favorilerde (yoksa son kullanılanlarda) katalog sırasıyla sıradaki sunucuya geçer. */
    private fun next(startId: Int) {
        if (state != OrbState.ON) { if (tun == null && !pausedNow()) shutdown(startId); return }
        val s = prefs.loadSettings()
        val ring = nextRing(s)
        if (ring.size < 2) return
        val cur = ring.indexOf(serverId)
        val target = Catalog.byId(ring[(cur + 1).mod(ring.size)]) ?: return
        // Seçim yalnızca geçiş başarılı olursa kaydedilir (yanıt vermeyen sunucu "son kullanılan" olmasın).
        if (switchServer(target, s)) prefs.setSelection(target.id, s.withRecent(target.id).recent)
    }

    /** Halka katalog sırasıyla kurulur: son kullanılanların sırası her geçişte değiştiği için aksi halde iki sunucu arasında gidilip gelinirdi. */
    private fun nextRing(s: AppSettings): List<String> {
        val usable: (DnsServer) -> Boolean = { s.plan(it).isNotEmpty() && it.id !in s.hidden }
        val fav = Catalog.all.filter { it.id in s.favorites && usable(it) }.map { it.id }
        if (fav.size >= 2) return fav
        return Catalog.all.filter { it.id in s.recent && usable(it) }.map { it.id }
    }

    /** Bağlıyken değişen ayarları (şifreleme, önbellek, ağ kuralı, bildirim) hemen uygular. */
    /** Uygulama seçimi değişti: tüneli aynı sunucuyla yeniden kurar (DNS bir iki saniye kesilir). */
    private fun rebuild(startId: Int, gen: Int) {
        if (gwOnlyNow && tun != null && !destroyed && cancelGen == gen) {
            // DNS'siz (yalnızca modül) tünel: uygulama seçimi değişti, aynı modüllerle yeniden kurulur.
            Journal.add("uygulama seçimi için tünel yeniden kuruluyor (yalnızca modüller)")
            teardown()
            startGatewayOnly(prefs.loadSettings(), startId, gen)
            return
        }
        if (state != OrbState.ON || tun == null || destroyed || cancelGen != gen) return
        val s = prefs.loadSettings()
        val server = Catalog.byId(serverId) ?: Catalog.default
        Journal.add("uygulama seçimi için tünel yeniden kuruluyor")
        endSession(EndReason.SWITCH)
        teardown()
        startTunnel(server, s, NetworkWatcher.currentKind(this), startId, gen)
    }

    private fun reapply(gen: Int) {
        if (state != OrbState.ON) { publish(); return }
        val s = prefs.loadSettings()
        val kind = NetworkWatcher.currentKind(this)
        val desired = Catalog.byId(Rules.ruleFor(s, kind) ?: serverId) ?: return
        Journal.add("ayarlar yeniden uygulanıyor")
        switchServer(desired, s, gen, force = true)
        updateNotification()
    }

    // ------------------------------------------------------------------ şifreli yönteme dönüş

    private fun scheduleUpgrade() {
        main.removeCallbacks(upgradeTask)
        main.postDelayed(upgradeTask, UPGRADE_MS)
    }

    /** Şifresiz DNS'e düşülmüşse şifreli yöntemleri sessizce yeniden dener; olmazsa 10 dakika sonra yine dener. */
    private fun tryUpgrade() {
        if (!downgraded || state != OrbState.ON || destroyed) return
        val s = prefs.loadSettings()
        val server = Catalog.byId(serverId) ?: return
        // Şu anki yöntemden daha çok tercih edilenler (ODoH → normal şifreli → düz): yalnızca onlara dönülmeye çalışılır.
        val plan = s.plan(server)
        val cur = fw?.proto
        val enc = (if (cur != null && cur in plan) plan.takeWhile { it != cur } else plan).filter { it != Proto.PLAIN }
        if (enc.isEmpty()) { downgraded = false; return }
        if (switchServer(server, s, cancelGen, protos = enc, force = true, quiet = true)) {
            Journal.add("şifreli bağlantıya dönüldü")
        } else {
            scheduleUpgrade()
        }
    }

    // ------------------------------------------------------------------ kendini onarma

    private fun scheduleHealth() {
        main.removeCallbacks(healthTask)
        if (!destroyed) main.postDelayed(healthTask, HEALTH_MS)
    }

    /**
     * Bağlıyken dakikada bir (yalnızca sayaçlara bakılır, ağa çıkılmaz) sunucunun cevap verip vermediğine bakar.
     * Sorgular zaman aşımına uğruyor ve hiç cevap gelmiyorsa [heal] basamakları çalışır. Ağ yokken denenmez.
     */
    private fun healthTick() {
        if (state != OrbState.ON || destroyed || tun == null) return
        val f = fw ?: return
        scheduleHealth()
        when (health.check(f, f.stats())) {
            HealthMonitor.Verdict.HEALTHY -> { healStep = 0; timeoutNotified = false; Notifier.cancelTimeout(this) }
            HealthMonitor.Verdict.SUSPECT -> if (NetworkWatcher.currentKind(this) != NetKind.NONE) {
                notifyTimeout(Catalog.byId(serverId)?.name ?: Catalog.default.name)
                heal()
            }
            HealthMonitor.Verdict.IDLE -> {}
        }
    }

    private fun heal() {
        val now = SystemClock.elapsedRealtime()
        if (lastHealAt != 0L && now - lastHealAt < HealPlan.cooldownMs(healStep)) return
        lastHealAt = now
        val s = prefs.loadSettings()
        val gen = cancelGen
        val server = Catalog.byId(serverId) ?: return
        val step = healStep++
        Journal.add("kendini onarma: basamak ${step + 1}")
        if (step == HealPlan.STEP_REFRESH) {
            if (switchServer(server, s, gen, force = true, quiet = true)) { Journal.add("onarıldı: yönlendirici yenilendi"); return }
        }
        if (step <= HealPlan.STEP_BACKUP) {
            val b = backupFor(server, s)
            if (b != null && switchServer(b, s, gen, quiet = true)) { Journal.add("onarıldı: yedek sunucuya geçildi"); return }
        }
        if (cancelGen == gen && !destroyed) rebuild(lastStartId, gen)
    }

    // ------------------------------------------------------------------ ağ geçidi modülleri (DPI atlatma, Reklam+)

    private fun gwWanted(s: AppSettings): Boolean = s.dpiOn || s.adsPlus

    /** Reklam+ için süzgeç seviyesi: en az ORTA; kullanıcı DNS süzgecini SIKI seçtiyse SIKI. */
    private fun gwLevelFor(s: AppSettings): FilterLevel = when {
        !s.adsPlus -> FilterLevel.OFF
        s.filterLevel == FilterLevel.STRICT -> FilterLevel.STRICT
        else -> FilterLevel.MEDIUM
    }

    /** Tüm trafiği tünele alır; yerel ağ ve çok noktaya yayın (Android 13+) tünel dışında kalır. */
    private fun addGatewayRoutes(b: Builder, v6: Boolean) {
        b.addRoute("0.0.0.0", 0)
        if (v6) b.addRoute("::", 0)
        if (Build.VERSION.SDK_INT >= 33) {
            val skip = ArrayList<Pair<String, Int>>()
            skip += "10.0.0.0" to 8; skip += "172.16.0.0" to 12; skip += "192.168.0.0" to 16
            skip += "169.254.0.0" to 16; skip += "224.0.0.0" to 4
            if (v6) { skip += "fc00::" to 7; skip += "fe80::" to 10; skip += "ff00::" to 8 }
            for ((a, n) in skip) {
                try { b.excludeRoute(android.net.IpPrefix(InetAddress.getByName(a), n)) } catch (_: Exception) {}
            }
        }
    }

    private fun attachGateway(t: Tunnel, s: AppSettings) {
        FilterRuntime.setGateway(gwLevelFor(s))
        val g = Gateway({ b, o, l -> t.writeRaw(b, o, l) }, { sock -> protect(sock) }, { sock -> protect(sock) }, setTtl = { sock, ttl -> setSockTtl(sock, ttl) })
        gwConfigure(g, s)
        gwApplyNetwork(g, NetworkWatcher.currentKind(this), NetworkWatcher.families(this))
        lastNetHandle = NetworkWatcher.currentHandle(this)
        netWasLost = false
        g.start()
        t.gateway = g
        synchronized(lock) { gw = g }
        gwBadTicks = 0
        main.removeCallbacks(gwTask)
        main.postDelayed(gwTask, GW_TICK_MS)
        Journal.add("ağ geçidi açık: ${modulesLabel(s)}")
    }

    /** Ağ geçidine etkin ağı bildirir: DPI yöntem belleği ağ türüne göre ayrılır; IPv6-only ağda NAT64 ön eki verilir. */
    private fun gwApplyNetwork(g: Gateway, kind: NetKind, fam: NetFamilies) {
        try {
            g.networkChanged(kind)
            g.config.noV4 = fam.v6Only
            g.config.nat64 = NetworkWatcher.nat64Prefix(this, fam)
        } catch (e: Exception) { Journal.add("ağ geçidi ağ bilgisi: ${e.javaClass.simpleName}") }
    }

    private fun gwConfigure(g: Gateway, s: AppSettings) {
        val c = g.config
        c.dpi = s.dpiOn
        c.blockQuic = s.blockQuic
        c.blockDoh = s.adsPlus && s.dnsOn          // DNS bizdeyken DNS'i atlatan şifreli DNS'ler kapatılır (DNS kapalıyken dokunulmaz)
        c.adsSource = if (s.adsPlus) ({ FilterRuntime.gatewayEngine }) else null
        c.ads = null
        c.adsDns = true
        c.passthrough = false
        FilterRuntime.setGateway(gwLevelFor(s))
    }

    /** Yuvanın IP TTL'ini ayarlar (DPI "disorder" yöntemi). Platform desteklemezse false: yöntem düz bölmeye düşer. */
    private fun setSockTtl(sock: java.net.Socket, ttl: Int): Boolean = try {
        val pfd = ParcelFileDescriptor.fromSocket(sock)
        try {
            var ok = false
            try { Os.setsockoptInt(pfd.fileDescriptor, OsConstants.IPPROTO_IP, OsConstants.IP_TTL, ttl); ok = true } catch (_: Exception) {}
            try { Os.setsockoptInt(pfd.fileDescriptor, OsConstants.IPPROTO_IPV6, OsConstants.IPV6_UNICAST_HOPS, ttl); ok = true } catch (_: Exception) {}
            ok
        } finally { try { pfd.close() } catch (_: Exception) {} }
    } catch (_: Exception) { false }

    private fun modulesLabel(s: AppSettings = prefs.loadSettings()): String =
        listOfNotNull(if (s.dpiOn) Strings.MOD_DPI else null, if (s.adsPlus) Strings.MOD_ADS else null).joinToString(" + ")

    /** DNS düğmesi kapalı: yalnızca ağ geçidi (DPI atlatma ve/veya Reklam+) çalışır. */
    private fun startGatewayOnly(settings: AppSettings, startId: Int, gen: Int) {
        if (destroyed || cancelGen != gen) return
        Journal.add("yalnızca modüller başlıyor: ${modulesLabel(settings)}")
        gwTripped = false
        FilterRuntime.setGateway(gwLevelFor(settings))
        FilterRuntime.setLight(settings.lightEffective())
        FilterRuntime.rebind = settings.rebindGuard
        FilterRuntime.update(settings.filterLevel, settings.filterAllow, settings.filterBlock)
        synchronized(lock) { state = OrbState.OFF; serverId = null; lastError = null; lastInfo = null; sinceMs = System.currentTimeMillis() }
        gwOnlyNow = true
        if (prepare(this) != null) { fail(Strings.ERR_PERMISSION, startId); return }
        val t = openTunnel(settings, dns = false) ?: run {
            if (!destroyed) fail(openError, startId)
            return
        }
        if (cancelGen != gen || destroyed) return
        retrying = false
        retryStep = 0
        main.removeCallbacks(retryTask)
        prefs.setWasActive(true)
        Notifier.cancelAlert(this)
        updateNotification()
        startWatcher()                      // yalnızca modül kipinde de ağ değişimi (Wi-Fi ↔ mobil) ağ geçidine bildirilir
        publish()
    }

    /** DNS'i durdurur; modül açıksa tünel DNS'siz yeniden kurulur, değilse her şey kapanır. */
    private fun dnsOff(startId: Int, gen: Int) {
        if (destroyed || cancelGen != gen) return
        val s = prefs.loadSettings()
        if (!gwWanted(s)) { disconnect(startId); return }
        if (gwOnlyNow) { publish(); return }
        Journal.add("DNS durduruldu, modüller sürüyor")
        cancelRetry()
        main.removeCallbacks(upgradeTask)
        clearPause()
        endSession(EndReason.USER)
        teardown()
        prefs.setDnsOn(false)
        Notifier.cancelDowngrade(this)
        Notifier.cancelTimeout(this)
        startGatewayOnly(prefs.loadSettings(), startId, gen)
    }

    /** Arayüzden gelen modül durumu (DPI atlatma, Reklam+). Çalışan duruma göre canlı uygular, gerekirse tüneli yeniden kurar. */
    private fun applyModules(startId: Int, gen: Int, dpi: Boolean, ads: Boolean) {
        if (destroyed || cancelGen != gen) return
        gwTripped = false
        prefs.setModules(dpi, ads)
        val s = prefs.loadSettings()
        val wantGw = gwWanted(s)
        if (tun == null) {
            if (!wantGw) { prefs.setDnsOn(true); publish(); idleShutdown(startId); return }
            clearPause(); cancelRetry()
            prefs.setDnsOn(false)
            startGatewayOnly(prefs.loadSettings(), startId, gen)
            return
        }
        if (!wantGw && gwOnlyNow) { disconnect(startId); return }
        val g = gw
        if (wantGw == (g != null)) {
            // Tünelin yapısı aynı: ayar canlı uygulanır (kesinti yok).
            if (g != null) { gwConfigure(g, s); FilterRuntime.setLight(s.lightEffective()); FilterRuntime.update(s.filterLevel, s.filterAllow, s.filterBlock) }
            Journal.add("modüller: ${modulesLabel(s).ifEmpty { "kapalı" }}")
            updateNotification()
            publish()
            return
        }
        if (state != OrbState.ON) { publish(); return }     // bağlanıyor ya da DNS durdurulmuş: sonraki kuruluşta uygulanır
        Journal.add("modüller için tünel yeniden kuruluyor")
        rebuild(startId, gen)
    }

    private fun scheduleGwTick() {
        main.removeCallbacks(gwTask)
        if (!destroyed && gw != null) main.postDelayed(gwTask, GW_TICK_MS)
    }

    /**
     * Güvenlik vanası: ağ varken ağ geçidinden son dakikada hiçbir bağlantı kurulamadı ve çok sayıda denemede hata varsa
     * (iki ölçüm üst üste) modüller kendiliğinden kapatılır; kullanıcı internetsiz kalmaz.
     */
    private fun gwTick() {
        val g = gw ?: return
        if (destroyed || tun == null) return
        scheduleGwTick()
        val st = g.stats()
        val online = NetworkWatcher.currentKind(this) != NetKind.NONE
        if (online && st.recentOk == 0 && st.recentFail >= GW_FAIL_MIN) gwBadTicks++ else gwBadTicks = 0
        if (gwBadTicks < 2) { if (state == OrbState.ON || gwOnlyNow) updateNotificationIfStats(); return }
        gwBadTicks = 0
        Journal.add("ağ geçidi bağlantı kuramıyor: modüller kapatılıyor")
        prefs.setModules(false, false)
        val gen = cancelGen
        if (gwOnlyNow) {
            prefs.setDnsOn(true)
            disconnect(lastStartId)
        } else if (state == OrbState.ON) {
            rebuild(lastStartId, gen)
        }
        gwTripped = true
        lastInfo = Strings.GW_TRIPPED
        publish()
    }

    private fun updateNotificationIfStats() { if (!destroyed) updateNotification() }

    // ------------------------------------------------------------------ kapalı kalırsa dur

    /**
     * DNS'i durdurur ama tüneli açık tutar: [tun] yoksa yeni bir tünel kurulur, içindeki yönlendirici her sorguya hemen hata
     * cevabı veren [SinkholeForwarder] olur. Gerçek bağlantı kurulunca (bkz. [startTunnel]) yönlendirici değişir ve [leaveSealed]
     * çalışır. İzin geri alındıysa ya da tünel kurulamadıysa false (çağıran normal yoldan kapatır).
     */
    private fun enterSealed(): Boolean {
        if (destroyed) return false
        var t = tun
        if (t == null) {
            if (prepare(this) != null) return false
            t = openTunnel(prefs.loadSettings()) ?: return false
        }
        val oldFw: Forwarder?
        val oldRetired: List<Forwarder>
        synchronized(lock) {
            flushTotalsLocked()
            oldFw = fw
            fw = null
            oldRetired = retired.toList()
            retired.clear()
        }
        val tunnel: Tunnel = t
        val sk = sink ?: SinkholeForwarder { b, o, l -> tunnel.write(b, o, l) }.also { it.start(); sink = it }
        tunnel.forwarder = sk
        oldFw?.close()
        for (x in oldRetired) x.close()
        main.removeCallbacks(healthTask)
        main.removeCallbacks(upgradeTask)
        main.removeCallbacks(recheckTask)
        health.reset()
        phoneBypass = false
        downgraded = false
        if (!sealed) Journal.add("kapalı kalırsa dur: DNS durduruldu, sorgular sızmıyor")
        sealed = true
        if (watcher == null) startWatcher()      // ağ geri gelince hemen denemek için
        return true
    }

    /** Yeniden denemeler kapalı ya da sürdürülemiyor: DNS durdurulmuş halde hata gösterilir; "Bağlan" ya da "Kes" kullanıcıya kalır. */
    private fun holdSealed(message: String) {
        retrying = false
        retryStep = 0
        synchronized(lock) { state = OrbState.ERROR; lastError = Strings.ERR_SEALED }
        Journal.add("DNS durdurulmuş halde bekleniyor: $message")
        foreground(currentNotification())
        publish()
        notifyDrop(Strings.ERR_SEALED)
    }

    /** Gerçek bağlantı kuruldu: DNS durdurma biter. */
    private fun leaveSealed() {
        val n = sink?.count ?: 0L
        sealed = false
        sink?.close()
        sink = null
        Journal.add("DNS durdurma bitti ($n sorgu cevapsız kaldı)")
    }

    /** Zaman aşımı bildirimi: ayar açıksa ve bu dönem için daha önce gösterilmediyse. */
    private fun notifyTimeout(name: String) {
        if (timeoutNotified) return
        val s = prefs.loadSettings()
        if (!s.notifyTimeout) return
        timeoutNotified = true
        Notifier.timeout(this, name)
    }

    // ------------------------------------------------------------------ kendiliğinden yeniden deneme

    private fun cancelRetry() {
        retrying = false
        retryStep = 0
        main.removeCallbacks(retryTask)
    }

    /** Sıradaki denemeyi kurar; deneme hakkı bittiyse false. */
    private fun scheduleRetry(): Boolean {
        if ((!sealed && retryStep >= RETRY_DELAYS.size) || destroyed) return false
        // Kapalı kalırsa dur açıkken DNS cevapsız kaldığı için bekleme kısa tutulur ve vazgeçilmez.
        val base = RETRY_DELAYS[minOf(retryStep, RETRY_DELAYS.size - 1)]
        val delay = if (sealed) minOf(base, SEALED_RETRY_MAX_MS) else base
        retrying = true
        synchronized(lock) { state = OrbState.CONNECTING; lastError = null }
        Journal.add("yeniden denenecek: ${delay / 1000} sn sonra")
        foreground(currentNotification())
        publish()
        main.removeCallbacks(retryTask)
        main.postDelayed(retryTask, delay)
        return true
    }

    private fun retryNow() {
        if (!retrying || destroyed || state == OrbState.ON) return
        retryStep++
        connect(null, lastStartId, cancelGen)
    }

    // ------------------------------------------------------------------ duraklatma

    private fun pause(minutes: Int, startId: Int) {
        val until = System.currentTimeMillis() + minutes.coerceIn(1, 24 * 60) * 60_000L
        Journal.add("duraklatıldı: $minutes dk")
        cancelRetry()
        main.removeCallbacks(upgradeTask)
        endSession(EndReason.PAUSE)
        teardown()
        prefs.setWasActive(false)
        prefs.setPausedUntil(until)
        pausedUntil = until
        synchronized(lock) { state = OrbState.OFF; lastError = null; serverId = null; downgraded = false }
        Notifier.cancelDowngrade(this)
        enterPaused()
    }

    /** Duraklatma durumu: servis önplanda kalır (geri sayımlı bildirim), süre bitince iki yoldan biri bağlantıyı sürdürür. */
    private fun enterPaused() {
        val until = pausedUntil
        if (until <= 0L) return
        PauseAlarm.schedule(this, until)
        armListener(until)
        foreground(currentNotification())
        publish()
    }

    /** Süreç yaşadıkça izin gerektirmeyen kesin zamanlayıcı (OnAlarmListener). Süreç ölürse [PauseAlarm] devralır. */
    private fun armListener(until: Long) {
        val am = getSystemService(AlarmManager::class.java) ?: return
        try {
            am.cancel(pauseListener)
            am.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + maxOf(0L, until - System.currentTimeMillis()),
                "dnshizli-resume", pauseListener, main)
        } catch (e: Exception) {
            Journal.add("zamanlayıcı kurulamadı: ${e.javaClass.simpleName}")
        }
    }

    private fun cancelListener() {
        try { getSystemService(AlarmManager::class.java)?.cancel(pauseListener) } catch (_: Exception) {}
    }

    private fun resumeFromAlarm() {
        if (!pausedNow()) return      // bu arada sürdürüldü ya da kesildi
        Journal.add("duraklatma bitti")
        clearPause()
        markAuto(true)
        connect(null, lastStartId, cancelGen)
    }

    private fun clearPause() {
        if (pausedUntil == 0L && prefs.pausedUntil() == 0L) return
        pausedUntil = 0L
        prefs.setPausedUntil(0L)
        PauseAlarm.cancel(this)
        cancelListener()
    }

    // ------------------------------------------------------------------ doğrulama, test ve kapatma

    /**
     * Android 9+ "Özel DNS" bir ada sabitse (katı mod) sistem DNS'i doğrudan o sunucuya şifreli gönderir; VPN'in
     * DNS adresi hiç kullanılmaz ve bağlantı testi asla geçmez. Bunu baştan tanıyıp kullanıcıya ne yapacağını söyleriz.
     */
    private fun strictPrivateDns(): String? {
        if (Build.VERSION.SDK_INT < 28) return null
        return try {
            val cm = getSystemService(android.net.ConnectivityManager::class.java) ?: return null
            val lp = cm.getLinkProperties(cm.activeNetwork ?: return null) ?: return null
            if (lp.isPrivateDnsActive) lp.privateDnsServerName else null
        } catch (_: Exception) { null }
    }

    private enum class Check { OK, UPSTREAM_ONLY, FAIL }

    /**
     * İki aşamalı doğrulama:
     *  1) Sunucu çalışıyor mu? Tünele kendi sorgumuz verilir (bkz. [SelfTest.packet]); telefonun çözümleyicisinden
     *     bağımsızdır, bu yüzden "sunucu mu bozuk, telefon mu sorgu göndermiyor" ayrımı yapılabilir.
     *  2) Telefon sorguları tünelden gönderiyor mu? Sistemin çözümleyicisiyle rastgele bir ad çözdürülür.
     * Birincisi geçip ikincisi geçmezse [Check.UPSTREAM_ONLY]: sunucu sağlam, sorun telefon tarafında.
     */
    private fun verifyDetailed(f: Forwarder, gen: Int, tries: Int, ms: Long, direct: Boolean = false): Check {
        val t = tun
        if (t != null) {
            var upstream = false
            for (attempt in 0 until tries) {
                if (cancelGen != gen || destroyed) return Check.FAIL
                val r = ConnectionCheck.run(f, { t.inject(SelfTest.packet(random.nextInt(0x10000), randomName()), if (direct) f else null) }, ms)
                if (r is CheckResult.Ok) {
                    Journal.add("sunucu testi (${f.proto.name}): ${r.ms} ms")
                    upstream = true
                    break
                }
                if (r is CheckResult.Untrusted) {
                    untrusted = true
                    Journal.add("sertifika doğrulanamadı (${f.proto.name}): şifreli bağlantıya karışılıyor olabilir")
                    return Check.FAIL
                }
            }
            if (!upstream) {
                Journal.add("sunucuya ulaşılamadı (${f.proto.name})")
                return Check.FAIL
            }
            // Doğrudan sınamada yalnızca sunucu denenir; telefonun çözümleyicisi sunucudan bağımsızdır, durumu değişmez.
            if (direct) return Check.OK
        }
        val sysTries = if (t != null) 2 else tries
        for (attempt in 0 until sysTries) {
            if (cancelGen != gen || destroyed) return Check.FAIL
            val r = ConnectionCheck.run(f, { InetAddress.getByName(randomName()) }, ms)
            if (r is CheckResult.Ok) {
                Journal.add("bağlantı testi (${f.proto.name}): ${r.ms} ms")
                return Check.OK
            }
        }
        if (t != null) {
            Journal.add("sunucu çalışıyor ama telefon sorguları tünelden göndermiyor (${f.proto.name})")
            return Check.UPSTREAM_ONLY
        }
        Journal.add("bağlantı testi başarısız (${f.proto.name})")
        return Check.FAIL
    }

    /** [verifyDetailed] sonucunu boolean'a çevirir; telefon tarafı sorunu [phoneBypass] ile işaretlenir. */
    private fun verify(f: Forwarder, gen: Int, tries: Int, ms: Long = CHECK_MS, direct: Boolean = false): Boolean {
        val c = verifyDetailed(f, gen, tries, ms, direct)
        if (c == Check.FAIL) return false
        if (!direct) phoneBypass = c == Check.UPSTREAM_ONLY
        return true
    }

    /** Doğrulama sonrası: telefon tünel dışı kalıyorsa uyarı ve arka planda yeniden sınama kur; düzeldiyse uyarıyı kaldır. */
    private fun noteBypass() {
        main.removeCallbacks(recheckTask)
        if (phoneBypass) {
            bypassChecks = 0
            main.postDelayed(recheckTask, RECHECK_MS)
        }
    }

    /** Telefon sorgularını artık tünelden gönderiyor mu? Gönderiyorsa uyarı kalkar; değilse birkaç kez daha denenir. */
    private fun recheckPhone() {
        if (!phoneBypass || state != OrbState.ON || destroyed) return
        val f = fw ?: return
        val r = ConnectionCheck.run(f, { InetAddress.getByName(randomName()) }, CHECK_MS_SECURE)
        if (r is CheckResult.Ok) {
            phoneBypass = false
            Journal.add("telefon artık sorguları tünelden gönderiyor")
            publish()
        } else if (++bypassChecks < 3) {
            main.postDelayed(recheckTask, RECHECK_MS * 2)
        }
    }

    private fun randomName(): String = "dh" + java.lang.Long.toString(random.nextLong() ushr 1, 36) + ".example.com"

    /** Kullanıcının istediği bağlantı testi: tünelin içinden üç soru (bkz. [SelfTest]); sonuç arayüze yayınlanır. */
    private fun runTest() {
        val t = tun
        val f = fw
        val sid = serverId
        if (state != OrbState.ON || t == null || f == null) {
            VpnStatus.publishTest(SelfTestResult(false, null, null, sid, DnssecResult.UNKNOWN, AdBlockResult.UNKNOWN))
            return
        }
        Thread({
            val r = try {
                SelfTest.run(inject = { p -> t.inject(p) }, tap = tap, proto = f.proto, serverId = sid, tunnelV6 = tunnelV6)
            } catch (e: Exception) {
                SelfTestResult(false, null, f.proto, sid, DnssecResult.UNKNOWN, AdBlockResult.UNKNOWN)
            }
            Journal.add("bağlantı testi: ${if (r.ok) "${r.ms} ms" else "yanıt yok"}, DNSSEC ${r.dnssec}, reklam ${r.ads}")
            VpnStatus.publishTest(r)
        }, "dns-test").also { it.isDaemon = true }.start()
    }

    private fun disconnect(startId: Int) {
        Journal.add("bağlantı kesildi")
        val wasUp = state != OrbState.OFF || tun != null
        cancelRetry()
        main.removeCallbacks(upgradeTask)
        clearPause()
        endSession(EndReason.USER)
        teardown()
        prefs.setWasActive(false)
        prefs.setModules(false, false)             // her şey kapandı: modül düğmeleri de kapalı
        prefs.setDnsOn(true)
        synchronized(lock) { state = OrbState.OFF; lastError = null; serverId = null; downgraded = false }
        Notifier.cancelDowngrade(this)
        Notifier.cancelAlert(this)
        Notifier.cancelTimeout(this)
        publish()
        if (wasUp && prefs.loadSettings().notifyStop) Notifier.stopped(this, prefs.loadSettings())
        shutdown(startId)
    }

    /**
     * Bağlanamadı. [retryable] (ağ/sunucu kaynaklı) ve kendiliğinden yeniden deneme sürüyorsa bir sonraki deneme kurulur;
     * değilse hata gösterilir ve servis durur.
     */
    private fun fail(message: String, startId: Int, retryable: Boolean = false) {
        Journal.add("bağlanamadı: $message")
        endSession(EndReason.FAILED)
        val st = prefs.loadSettings()
        // Kapalı kalırsa dur: bağlantı kopmuşken (ya da kendiliğinden yeniden denerken) tünel açık kalır, DNS sızmaz.
        if (st.failClosed && retryable && !destroyed && (retrying || sealed || st.wasActive) && enterSealed()) {
            if (st.autoReconnect) {
                retrying = true
                if (scheduleRetry()) return
            }
            holdSealed(message)
            return
        }
        val gwFailed = gwOnlyNow
        teardown()
        if (gwFailed) { prefs.setModules(false, false); prefs.setDnsOn(true) }
        if (retryable && retrying && prefs.loadSettings().autoReconnect && scheduleRetry()) return
        val wasRetrying = retrying
        retrying = false
        retryStep = 0
        prefs.setWasActive(false)
        synchronized(lock) { state = OrbState.ERROR; lastError = message; downgraded = false }
        publish()
        if (wasRetrying) notifyDrop(message)
        shutdown(startId)
    }

    private fun tunnelEnded(t: Tunnel, why: String) {
        val sid = lastStartId
        submit(sid) {
            if (tun !== t) return@submit        // zaten kapatıldı ya da değiştirildi
            Journal.add("tünel kapandı: $why")
            if (gwOnlyNow) { endSession(EndReason.DROP); notifyDrop(Strings.ERR_TUNNEL); fail(Strings.ERR_TUNNEL, sid); return@submit }
            val wasOn = state == OrbState.ON
            val wasSealed = sealed
            endSession(EndReason.DROP)
            val s = prefs.loadSettings()
            if (wasOn) notifyDrop(Strings.ERR_TUNNEL)
            if ((wasOn || wasSealed) && s.failClosed && prepare(this) == null) {
                teardown()
                if (enterSealed()) {
                    if (s.autoReconnect) {
                        retrying = true
                        retryStep = 0
                        if (scheduleRetry()) return@submit
                    }
                    holdSealed(Strings.ERR_TUNNEL)
                    return@submit
                }
            }
            if (wasOn && s.autoReconnect && prepare(this) == null) {
                teardown()
                retrying = true
                retryStep = 0
                if (scheduleRetry()) return@submit
            }
            fail(Strings.ERR_TUNNEL, sid)
            if (wasOn) notifyDrop(Strings.ERR_TUNNEL)
        }
    }

    /** "Bağlantı koparsa bildir" açıksa yeniden bağlan düğmeli uyarı gösterir. */
    private fun notifyDrop(reason: String) {
        if (prefs.loadSettings().notifyDrop) Notifier.drop(this, reason)
    }

    private fun onNetwork(kind: NetKind, handle: Long = 0L) {
        // Ağ geçidi (DPI / Reklam+) DNS'ten bağımsız çalışır: yalnızca modül kipinde de ağ değişimi ona bildirilir.
        if (kind == NetKind.NONE) netWasLost = true
        else if (!destroyed) {
            val g = gw
            if (g != null) {
                gwApplyNetwork(g, kind, NetworkWatcher.families(this))
                // Ağ gerçekten değiştiyse (ya da bir süre hiç ağ yoktuysa) eski ağa bağlı sunucu soketleri ölüdür: akışları hemen kes,
                // uygulamalar yeni ağda anında yeniden bağlansın (aksi halde dakikalarca takılırlar).
                val changed = handle != 0L && lastNetHandle != 0L && handle != lastNetHandle
                if (changed || netWasLost) {
                    g.networkReset()
                    Journal.add("ağ değişti: ağ geçidi akışları sıfırlandı")
                }
            }
            if (handle != 0L) lastNetHandle = handle
            netWasLost = false
        }
        if (sealed && retrying && kind != NetKind.NONE && !destroyed) {
            // DNS durdurulmuşken ağ geri geldi: bir sonraki zamanlı denemeyi beklemeden hemen (en çok 10 sn'de bir) bağlanmayı dene.
            val now = SystemClock.elapsedRealtime()
            if (now - lastNetRetryAt >= NET_RETRY_MIN_MS) {
                lastNetRetryAt = now
                Journal.add("ağ geldi: bağlanma yeniden deneniyor")
                main.removeCallbacks(retryTask)
                connect(null, lastStartId, cancelGen)
            }
            return
        }
        if (state != OrbState.ON || kind == NetKind.NONE) return
        netFamilies = NetworkWatcher.families(this)
        Journal.add("ağ değişti: $kind ($netFamilies)")
        val settings = prefs.loadSettings()
        val gen = cancelGen
        if (settings.refreshOnNetwork) fw?.resetNetwork("ağ: $kind")
        val rule = Rules.ruleFor(settings, kind)
        if (rule != null && rule != serverId) {
            Catalog.byId(rule)?.let { if (switchServer(it, settings, gen)) return }
        }
        // Yeni ağda bağlantı gerçekten çalışıyor mu? (Ağ yokken kurulan bağlantı da burada ilk kez sınanır.)
        val f = fw ?: return
        if (verify(f, gen, 2, msFor(f.proto))) {
            noteBypass()
            publish()
        } else if (cancelGen == gen) {
            Journal.add("yeni ağda yanıt yok: yöntemler yeniden deneniyor")
            Catalog.byId(serverId)?.let { switchServer(it, settings, gen, force = true, quiet = true) }
        }
        if (downgraded) tryUpgrade()
    }

    // ------------------------------------------------------------------ oturum (bağlantı geçmişi)

    private fun totalQueriesNow(): Long = baseQueries + (fw?.stats()?.queries ?: 0L)

    private fun startSession(id: String, proto: Proto) {
        sessionServer = id
        sessionProto = proto
        sessionStart = System.currentTimeMillis()
        sessionBase = totalQueriesNow()
    }

    @Synchronized
    private fun endSession(reason: EndReason) {
        val id = sessionServer ?: return
        sessionServer = null
        val now = System.currentTimeMillis()
        if (now - sessionStart < 1000L) return                // anlık oturumlar geçmişi doldurmasın
        try {
            prefs.addSession(Session(id, sessionProto, sessionStart, now, reason, maxOf(0L, totalQueriesNow() - sessionBase)))
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ temizlik, durum

    /** Tüneli, yönlendiriciyi ve ağ izleyiciyi kapatır; toplamları depoya aktarır. Birden çok kez çağrılabilir. */
    private fun teardown() {
        var t: Tunnel? = null
        var f: Forwarder? = null
        var old: List<Forwarder> = emptyList()
        synchronized(lock) {
            flushTotalsLocked()
            t = tun; f = fw
            tun = null; fw = null
            old = retired.toList()
            retired.clear()
        }
        stopWatcher()
        main.removeCallbacks(recheckTask)
        main.removeCallbacks(healthTask)
        main.removeCallbacks(gwTask)
        val g = gw
        synchronized(lock) { gw = null }
        gwOnlyNow = false
        health.reset()
        phoneBypass = false
        sealed = false
        sink?.close()
        sink = null
        t?.close()
        g?.stop()
        f?.close()
        for (x in old) x.close()
    }

    /** [lock] altında çağrılır: son aktarımdan bu yana biriken sayıları depoya ekler. */
    private fun flushTotalsLocked() {
        val f = fw ?: return
        val st = f.stats()
        val now = SystemClock.elapsedRealtime()
        val secs = if (state == OrbState.ON) maxOf(0L, (now - flushedAt) / 1000) else 0L
        prefs.addTotals(
            PrefsStore.Delta(
                queries = st.queries - flushedQueries, hits = st.cacheHits - flushedHits, blocked = st.blocked - flushedBlocked,
                seconds = secs, answered = st.answered - flushedAnswered, latencyMs = st.latencySumMs - flushedLatency,
                bytesUp = st.bytesUp - flushedUp, bytesDown = st.bytesDown - flushedDown,
            ),
            serverId,
        )
        flushedQueries = st.queries
        flushedHits = st.cacheHits
        flushedBlocked = st.blocked
        flushedAnswered = st.answered
        flushedLatency = st.latencySumMs
        flushedUp = st.bytesUp
        flushedDown = st.bytesDown
        flushedAt += secs * 1000
    }

    /**
     * Tünel okuyucusundan (her uyanışta) çağrılır: trafik varken en çok dakikada bir toplamlar depoya aktarılır,
     * bildirimdeki sayaçlar ve widget güncellenir. Trafik yokken hiçbir şey yapılmaz (zamanlayıcı yok).
     */
    private fun onTunnelActivity() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastFlush < FLUSH_MS) return
        lastFlush = now
        submit(lastStartId) {
            synchronized(lock) { flushTotalsLocked() }
            if (state == OrbState.ON) { updateNotification(); publishWidget(snapshot()) }
        }
    }

    /** Arayüzün gördüğü canlı durum. Her iş parçacığından çağrılabilir. */
    private fun snapshot(): VpnUi {
        val f = fw
        val st = f?.stats()
        val s = state
        val gwNow = gw
        val gws = gwNow?.stats()
        // Arayüz görünürken (istatistik çekerken) toplamlar arada bir depoya aktarılır; ek zamanlayıcı yok.
        if (s == OrbState.ON) {
            val now = SystemClock.elapsedRealtime()
            if (now - lastFlush > FLUSH_MS) {
                lastFlush = now
                submit(lastStartId) { synchronized(lock) { flushTotalsLocked() } }
            }
        }
        return VpnUi(
            state = s,
            serverId = serverId,
            sinceMs = sinceMs,
            queries = baseQueries + (st?.queries ?: 0L),
            cacheHits = baseHits + (st?.cacheHits ?: 0L),
            avgMs = st?.avgMs ?: 0,
            error = if (s == OrbState.ERROR) lastError else null,
            onBackup = st?.backup ?: false,
            proto = if (s == OrbState.ON) f?.proto else null,
            blocked = baseBlocked + (st?.blocked ?: 0L),
            pausedUntil = if (s == OrbState.OFF) pausedUntil else 0L,
            downgraded = s == OrbState.ON && downgraded,
            retrying = s == OrbState.CONNECTING && retrying,
            gwOnly = gwOnlyNow && tun != null && s != OrbState.ERROR,
            gwActive = gwNow != null,
            gwDpi = gwNow?.config?.dpi ?: false,
            gwAds = gwNow?.config?.adsSource != null,
            gwBlocked = (gws?.blockedHosts ?: 0L) + (gws?.dnsBlocked ?: 0L) + (gws?.dohBlocked ?: 0L),
            gwSplit = gws?.split ?: 0L,
            gwTripped = gwTripped,
            info = lastInfo ?: (if (sealed) Strings.SEALED_INFO else if (s == OrbState.ON && phoneBypass) Strings.PHONE_BYPASS else null),
        )
    }

    /** Güncel durumu yayınlar. [error] doluysa bu yayına tek seferlik hata olarak eklenir (ör. başarısız sunucu geçişi). */
    private fun publish(error: String? = null) {
        val s = snapshot()
        val v = if (error != null) s.copy(error = error) else s
        VpnStatus.publish(v)
        publishWidget(v)
    }

    private fun publishWidget(v: VpnUi) {
        try { DnsWidget.updateAll(this, v) } catch (_: Exception) {}
    }

    private fun startWatcher() {
        stopWatcher()
        if (destroyed) return   // servis kapanırken kurulan izleyici hiç kaydolmasın (sızıntı)
        val sid = lastStartId
        val w = NetworkWatcher(this) { kind, handle -> submit(sid) { onNetwork(kind, handle) } }
        watcher = w
        w.start()
        if (destroyed) stopWatcher()   // kurulurken servis kapandıysa hemen bırak
    }

    private fun stopWatcher() {
        watcher?.stop()
        watcher = null
    }

    /** Servisi durdurur. Bu arada daha yeni bir başlatma komutu geldiyse ([startId] eskiyse) dokunmaz; yeni komut devralır. */
    private fun shutdown(startId: Int) {
        main.post {
            if (startId == lastStartId && !pausedNow() && !retrying && !sealed && !gwOnlyNow) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
            }
        }
    }

    // ------------------------------------------------------------------ bildirim

    private fun currentNotification(): Notification {
        val s = prefs.loadSettings()
        return when {
            pausedNow() -> Notifier.paused(this, s, pausedUntil, Format.hm(pausedUntil))
            gwOnlyNow && tun != null && state != OrbState.ERROR -> gwNotification(s)
            state == OrbState.ON -> onNotification(s)
            sealed -> Notifier.sealed(this, s)
            retrying -> Notifier.build(this, s, Strings.NOTIF_RETRYING, false)
            else -> Notifier.build(this, s, Strings.NOTIF_CONNECTING, false)
        }
    }

    private fun onNotification(s: AppSettings = prefs.loadSettings()): Notification {
        val name = Catalog.byId(serverId)?.name ?: Catalog.default.name
        val proto = Strings.protoName(fw?.proto ?: Proto.PLAIN)
        val ui = snapshot()
        val text = if (ui.queries > 0) Strings.notifOnStats(name, proto, Format.count(ui.queries), Format.count(ui.blocked))
            else Strings.notifOn(name, proto)
        val mods = if (gw != null) modulesLabel(s) else ""
        return Notifier.build(this, s, if (mods.isEmpty()) text else "$text · $mods", true, sinceMs, nextRing(s).size >= 2)
    }

    private fun gwNotification(s: AppSettings = prefs.loadSettings()): Notification {
        val st = gw?.stats()
        val blocked = (st?.blockedHosts ?: 0L) + (st?.dnsBlocked ?: 0L) + (st?.dohBlocked ?: 0L)
        val mods = modulesLabel(s)
        val text = if (blocked > 0) Strings.gwOnStats(mods, Format.count(blocked)) else Strings.gwOn(mods)
        return Notifier.build(this, s, text, true, sinceMs, false)
    }

    private fun updateNotification() {
        if (destroyed) return
        // Kanal (sade bildirim) değişmiş olabilir: önplan bildirimi yeniden verilir.
        foreground(if (gwOnlyNow) gwNotification() else onNotification())
    }

    private fun foreground(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(Notifier.NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
            } else {
                startForeground(Notifier.NOTIF_ID, n)
            }
        } catch (e: Exception) {
            // Önplana alınamazsa (ör. arka plandan başlatma kısıtı) servis yine çalışır; VPN uygulaması sistemce korunur.
            Journal.add("önplan bildirimi açılamadı: ${e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------------------------ tünel kurulumu

    private fun establishTunnel(settings: AppSettings, v6: Boolean, dns: Boolean = true): ParcelFileDescriptor? {
        val configure = PendingIntent.getActivity(
            this, 0, Notifier.appIntent(this),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = Builder()
            .setSession(Strings.APP)
            .setMtu(MTU)
            .addAddress(CLIENT_ADDR, 32)
            .setBlocking(false)
            .setConfigureIntent(configure)
        // DNS açıksa yalnızca DNS adresi tünele girer; diğer tüm trafik normal gider (ağ geçidi isteniyorsa aşağıda hepsi girer).
        // DNS kapalıysa sistem, ağın kendi DNS'ini kullanır.
        if (dns) b.addDnsServer(FAKE_DNS).addRoute(FAKE_DNS, 32)
        if (v6) {
            // IPv6 ağlarda sistem çözümleyicisi IPv6 DNS adresine de sorabilir: o da aynı yerel yönlendiriciye gelir.
            b.addAddress(CLIENT_ADDR6, 128)
            if (dns) b.addDnsServer(FAKE_DNS6).addRoute(FAKE_DNS6, 128)
        }
        if (gwWanted(settings)) addGatewayRoutes(b, v6)
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)
        applyScope(b, settings)
        // Yalnızca IPv4 adres/yol eklendiğinde Android varsayılan olarak tüm IPv6 trafiğini engeller; engellenmesin.
        b.allowFamily(OsConstants.AF_INET6)
        return b.establish()
    }

    /** "Hangi uygulamalar" ayarını tünele uygular (izinli ya da dışlanan paketler; ikisi aynı anda kullanılamaz). */
    private fun applyScope(b: Builder, settings: AppSettings) {
        val pm = packageManager
        val plan = AppScopes.plan(settings, packageName) { p ->
            try { pm.getApplicationInfo(p, 0); true } catch (_: Exception) { false }
        }
        if (plan.kind == ScopePlan.Kind.ALL || plan.kind == ScopePlan.Kind.NONE) {
            if (settings.appScope != AppScope.ALL) Journal.add("dışlanan uygulama yok: tüm uygulamalar")
            return
        }
        var added = 0
        for (p in plan.packages) {
            try {
                if (plan.kind == ScopePlan.Kind.ALLOW) b.addAllowedApplication(p) else b.addDisallowedApplication(p)
                added++
            } catch (_: Exception) { /* paket tam bu sırada kaldırıldı */ }
        }
        Journal.add(if (plan.kind == ScopePlan.Kind.ALLOW) "yalnızca $added uygulama tünelde" else "$added uygulama tünel dışında")
    }

    private fun newForwarder(server: DnsServer, settings: AppSettings, t: Tunnel, proto: Proto): Forwarder {
        // Bağlantı testinin cevapları tünele yazılmaz, teste gider.
        val write: (ByteArray, Int, Int) -> Unit = { b, off, len -> if (!tap.offer(b, off, len)) t.write(b, off, len) }
        val f: Forwarder = when (proto) {
            Proto.PLAIN -> DnsForwarder(
                // IPv4 ve IPv6 birlikte: ağın kullandığı aile önce, öbürü yedek ([Targets.plain]).
                upstreams = Targets.plain(server, settings.ipMode, netFamilies).map { InetSocketAddress(addr(it), 53) },
                writeToTun = write,
                protect = { s -> protect(s) },
                cacheEntries = settings.cache.entries,
                log = { Journal.add(it) },
            )
            Proto.ODOH -> odohForwarder(write, settings)
            Proto.DOT, Proto.DOH -> SecureForwarder(
                proto = proto,
                targets = secureTargets(server, proto, settings),
                writeToTun = write,
                openSocket = { a, timeout -> protectedSocket(a, timeout) },
                tls = freshTlsFactory(),
                freshTls = { freshTlsFactory() },
                cacheEntries = settings.cache.entries,
                log = { Journal.add(it) },
            )
        }
        f.start()
        // Reklam/izleyici/zararlı alan adı engelleme: sorgu listedeyse cevabı burada verilir (bkz. core/Filter.kt).
        return FilteringForwarder(f, write)
    }

    /**
     * ODoH motoru: servis ömrü boyunca tek (hedef anahtarları, yol sağlığı ve son çalışan adresler yönlendirici yenilense de
     * korunur). Ağ işleri tünel dışı (korunmuş) soketlerle yapılır; ipucu adresleri bayatlarsa şifreli (DoT) ad çözümü kullanılır.
     */
    private fun odohEngine(): OdohEngine {
        odohEngineRef?.let { return it }
        synchronized(this) {
            odohEngineRef?.let { return it }
            val clock = { SystemClock.elapsedRealtime() }
            val boot = OdohBootstrap(
                servers = listOf("1.1.1.1" to "cloudflare-dns.com", "9.9.9.9" to "dns.quad9.net"),
                openSocket = { a, t -> protectedSocket(a, t) },
                tls = { freshTlsFactory() },
            )
            val book = OdohAddressBook(clock, resolve = { boot.resolve(it) })
            val e = OdohEngine(
                relays = OdohCatalog.relays, targets = OdohCatalog.targets, now = clock, rng = java.security.SecureRandom(),
                fetchConfig = OdohEngine.httpsFetcher(book, { a, t -> protectedSocket(a, t) }, { freshTlsFactory() }),
                book = book,
            )
            odohEngineRef = e
            return e
        }
    }

    private fun odohForwarder(write: (ByteArray, Int, Int) -> Unit, settings: AppSettings): Forwarder {
        val e = odohEngine()
        return SecureForwarder(
            proto = Proto.ODOH,
            targets = e.relayTargets(),
            writeToTun = write,
            openSocket = { a, timeout -> protectedSocket(a, timeout) },
            tls = freshTlsFactory(),
            freshTls = { freshTlsFactory() },
            timeoutMs = 5000,
            connectTimeoutMs = 3000,
            giveUpMs = 9000,
            cacheEntries = settings.cache.entries,
            log = { Journal.add(it) },
            odoh = e,
        )
    }

    /**
     * TLS oturum önbelleği boş, yeni bir soket fabrikası. Önceki bağlantıların oturum biletleri yeniden kullanılmaz:
     * biletler sunucunun bizi iki bağlantı (ya da iki ağ) arasında tanımasına yarardı.
     */
    private fun freshTlsFactory(): SSLSocketFactory {
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(null, null, null)
        return ctx.socketFactory
    }

    /** Yazılı IP adresinden [InetAddress]; ad çözümlemesi yapmaz. */
    private fun addr(ip: String): InetAddress = InetAddress.getByAddress(Ip.parse(ip) ?: throw IllegalArgumentException("geçersiz adres"))

    /**
     * Tünel dışında tutulan (VpnService.protect) TCP soketi. Bağlanmamış bir Socket'in dosya tanıtıcısı henüz
     * yoktur ve protect() onu işaretleyemez; bu yüzden önce yerel bir adrese bağlanır (bind), sonra korunur, sonra
     * hedefe bağlanır. Koruma yine de başarısız olursa bağlantı sürdürülür: tünel yalnızca sahte DNS adresini
     * yönlendirdiği için sunucu trafiği zaten tünele girmez (yalnızca "her zaman açık + kilitli" modda koruma şarttır).
     */
    private fun protectedSocket(addr: InetSocketAddress, timeout: Int): Socket {
        val s = Socket()
        try {
            try { s.bind(null) } catch (_: java.io.IOException) {}
            val ok = try { protect(s) } catch (_: Exception) { false }
            if (!ok) Journal.add("uyarı: TLS soketi korunamadı")
            s.connect(addr, timeout)
            return s
        } catch (e: java.io.IOException) {
            try { s.close() } catch (_: Exception) {}
            throw e
        } catch (e: RuntimeException) {
            try { s.close() } catch (_: Exception) {}
            throw java.io.IOException(e)
        }
    }

    /**
     * Şifreli hedefler: sertifika adı katalogdan, adresler katalogdan (IPv4 ve IPv6; bkz. [Targets.secure]). DoH adı çoğu
     * zaman DNS adresinden başka bir adreste yayındadır (ör. doh.opendns.com): yalnızca "Otomatik" kipte ve şifresiz yola
     * düşmeye izin verilmişken, sağlayıcının kendi düz DNS adresine tek bir A sorusu sorulur ([Bootstrap]). Şifreli-yalnızca
     * kiplerde ve sıkı şifrelemede hiçbir şifresiz sorgu gönderilmez; katalogdaki adresler kullanılır.
     */
    private fun secureTargets(server: DnsServer, proto: Proto, settings: AppSettings): List<SecureTarget> {
        val port = if (proto == Proto.DOT) 853 else 443
        val dns4 = server.addresses4.firstOrNull()
        val host = server.tlsHost(proto, 0)
        val bootstrap = proto == Proto.DOH && server.plain && settings.encryption == Encryption.AUTO &&
            !settings.strictEncryption && settings.ipMode == IpMode.BOTH && netFamilies.v4 && dns4 != null && host != null
        val extra = if (!bootstrap) emptyList() else Bootstrap.resolveA(host, dns4, timeoutMs = 800, tries = 1, newSocket = {
            DatagramSocket().also { s -> try { protect(s) } catch (_: Exception) {} }
        })
        return Targets.secure(server, proto, settings.ipMode, netFamilies, extra).map {
            SecureTarget(InetSocketAddress(addr(it.ip), port), it.host, it.path, it.alt?.let { a -> InetSocketAddress(addr(a), port) })
        }
    }

    // ------------------------------------------------------------------ tünel okuyucu

    /**
     * Tünel arayüzünü okuyan tek iş parçacığı. `poll()` tünel ile bir uyandırma borusunu birlikte bekler: paket
     * yokken hiç uyanmaz; kapatılırken ya da bağlantı testi bir soru eklediğinde boruya yazılarak anında uyandırılır.
     * Eklenen sorular da bu iş parçacığında yönlendiriciye verilir ([Forwarder.onPacket] tek iş parçacıklıdır).
     */
    private class Tunnel(
        private val pfd: ParcelFileDescriptor,
        private val onEnded: (Tunnel, String) -> Unit,
        private val onActivity: () -> Unit,
    ) {
        @Volatile var forwarder: Forwarder? = null

        /** Varsa DNS dışındaki tüm paketler buraya gider (DNS adresine gidenler eskisi gibi yönlendiriciye). */
        @Volatile var gateway: Gateway? = null
        @Volatile private var stopping = false

        private val fd: FileDescriptor = pfd.fileDescriptor
        private val pipe: Array<FileDescriptor> = Os.pipe()
        private val thread = Thread({ loop() }, "dns-tun").also { it.isDaemon = true }
        private class Injected(val p: ByteArray, val target: Forwarder?)
        private val injected = ConcurrentLinkedQueue<Injected>()

        // Yazma ve kapatma birbirini dışlar: kapanan bir dosya tanıtıcısının numarası başka bir dosyaya verilmişken
        // gecikmiş bir cevabın oraya yazılması (klasik fd yeniden kullanım hatası) böylece imkânsız olur.
        private val writeLock = Any()
        private var closed = false
        private val closing = AtomicBoolean(false)

        fun start() = thread.start()

        /**
         * Kendi TCP katmanımız (DNS-over-TCP): tünelden gelen TCP/53 bağlantılarını karşılar. Soruları yönlendiriciye sanal
         * UDP istemcisi olarak verir ([feed]; tünel okuyucu iş parçacığında), cevapları [write] yakalayıp TCP olarak yazar.
         */
        private val tcp = TcpDns({ b, o, l -> rawWrite(b, o, l) }, { p, n -> forwarder?.onPacket(p, n) })

        /** Cevabı tünele yazar. Sanal TCP istemcisine gidiyorsa TCP katmanı alır. Kuyruk doluysa paket sessizce atılır; istemci yeniden dener. */
        fun write(b: ByteArray, off: Int, len: Int) {
            if (tcp.offer(b, off, len)) return
            rawWrite(b, off, len)
        }

        /** Ağ geçidinin cevapları (kendi iş parçacığından). */
        fun writeRaw(b: ByteArray, off: Int, len: Int) = rawWrite(b, off, len)

        private fun rawWrite(b: ByteArray, off: Int, len: Int) {
            synchronized(writeLock) {
                if (closed) return
                try { Os.write(fd, b, off, len) } catch (_: Exception) {}
            }
        }

        /** Tünelden gelmiş gibi bir paket ekler (bağlantı testi). Okuyucu iş parçacığı uyandırılır. */
        fun inject(p: ByteArray, target: Forwarder? = null) {
            if (stopping) return
            injected.add(Injected(p, target))
            synchronized(writeLock) {
                if (closed) return
                try { Os.write(pipe[1], byteArrayOf(2), 0, 1) } catch (_: Exception) {}
            }
        }

        fun close() {
            if (!closing.compareAndSet(false, true)) return     // ikinci çağrı: borular zaten kapalı olabilir
            stopping = true
            try { Os.write(pipe[1], byteArrayOf(1), 0, 1) } catch (_: Exception) {}
            if (Thread.currentThread() !== thread && thread.isAlive) {
                try { thread.join(1000) } catch (_: InterruptedException) {}
            }
            synchronized(writeLock) {
                if (closed) return
                closed = true
                try { pfd.close() } catch (_: Exception) {}
                try { Os.close(pipe[0]) } catch (_: Exception) {}
                try { Os.close(pipe[1]) } catch (_: Exception) {}
            }
        }

        private fun loop() {
            var why = "okuma bitti"
            try {
                val tunPoll = StructPollfd()
                tunPoll.fd = fd
                tunPoll.events = OsConstants.POLLIN.toShort()
                val wakePoll = StructPollfd()
                wakePoll.fd = pipe[0]
                wakePoll.events = OsConstants.POLLIN.toShort()
                val fds = arrayOf(tunPoll, wakePoll)
                val buf = ByteArray(BUF)
                val wake = ByteArray(64)
                val bad = OsConstants.POLLERR or OsConstants.POLLHUP or OsConstants.POLLNVAL
                while (!stopping) {
                    tunPoll.revents = 0
                    wakePoll.revents = 0
                    try {
                        Os.poll(fds, -1)
                    } catch (e: ErrnoException) {
                        if (e.errno == OsConstants.EINTR) continue
                        throw e
                    }
                    if (stopping) break
                    if (wakePoll.revents.toInt() != 0) {
                        // Uyandırma: borudaki baytları boşalt (poll hazır dediği için okuma bloklamaz), eklenenleri işle.
                        try { Os.read(pipe[0], wake, 0, wake.size) } catch (_: ErrnoException) {}
                        if (stopping) break
                        while (true) {
                            val inj = injected.poll() ?: break
                            // [target] verilmişse paket yalnızca o (henüz takılmamış) yönlendiriciye gider: gerçek sorgular etkilenmez.
                            try { (inj.target ?: forwarder)?.onPacket(inj.p, inj.p.size) } catch (_: Exception) {}
                        }
                    }
                    val r = tunPoll.revents.toInt()
                    if (r and OsConstants.POLLIN != 0) drain(buf)
                    else if (r and bad != 0) { why = "tünel arayüzü kapandı"; break }
                    onActivity()
                }
            } catch (e: Exception) {
                why = "hata: ${e.javaClass.simpleName}"
            }
            if (!stopping) onEnded(this, why)
        }

        /** Hazır paketleri (en çok [MAX_BURST]) okuyup yönlendiriciye verir. Okunacak kalmayınca döner. */
        private fun drain(buf: ByteArray) {
            var n = 0
            while (n++ < MAX_BURST && !stopping) {
                val len = try {
                    Os.read(fd, buf, 0, buf.size)
                } catch (e: ErrnoException) {
                    if (e.errno == OsConstants.EAGAIN) return
                    if (e.errno == OsConstants.EINTR) continue
                    throw e
                }
                if (len <= 0) throw IllegalStateException("tünel okuması 0 bayt döndü")
                // Tek bir bozuk paket tüneli düşürmesin.
                try {
                    val g = gateway
                    if (g != null && !toDns(buf, len)) g.onPacket(buf, len)
                    else if (isTcp(buf, len)) tcp.onPacket(buf, len) else forwarder?.onPacket(buf, len)
                } catch (_: Exception) {}
            }
        }

        /** Paketin hedefi sahte DNS adresi mi? (Yalnızca ağ geçidi açıkken sorulur.) */
        private fun toDns(b: ByteArray, len: Int): Boolean {
            if (len < 20) return false
            return when ((b[0].toInt() ushr 4) and 0xF) {
                4 -> b[16] == FAKE4[0] && b[17] == FAKE4[1] && b[18] == FAKE4[2] && b[19] == FAKE4[3]
                6 -> len >= 40 && (0 until 16).all { b[24 + it] == SelfTest.FAKE6[it] }
                else -> false
            }
        }

        /** IPv4/IPv6 üzerinde doğrudan TCP mi? (DNS yolu UDP'dir; TCP yalnızca "kesildi" sonrası yeniden denemelerde gelir.) */
        private fun isTcp(b: ByteArray, len: Int): Boolean {
            if (len < 40) return false
            return when ((b[0].toInt() ushr 4) and 0xF) {
                4 -> (b[9].toInt() and 0xFF) == 6
                6 -> (b[6].toInt() and 0xFF) == 6
                else -> false
            }
        }

        private companion object {
            val FAKE4: ByteArray = byteArrayOf(10, 111.toByte(), 222.toByte(), 2)
            const val BUF = 4096
            const val MAX_BURST = 32
        }
    }

    companion object {
        const val ACTION_CONNECT = "app.dnshizli.CONNECT"
        const val ACTION_DISCONNECT = "app.dnshizli.DISCONNECT"
        const val ACTION_PAUSE = "app.dnshizli.PAUSE"
        const val ACTION_RESUME = "app.dnshizli.RESUME"
        const val ACTION_NEXT = "app.dnshizli.NEXT"
        const val ACTION_CLEAR_CACHE = "app.dnshizli.CLEAR_CACHE"
        const val ACTION_REAPPLY = "app.dnshizli.REAPPLY"
        const val ACTION_REBUILD = "app.dnshizli.REBUILD"
        const val ACTION_TEST = "app.dnshizli.TEST"
        const val ACTION_DNS_OFF = "app.dnshizli.DNS_OFF"
        const val ACTION_MODULES = "app.dnshizli.MODULES"
        const val EXTRA_DPI = "dpi"
        const val EXTRA_ADS = "ads"
        const val EXTRA_SERVER = "server"
        const val EXTRA_MINUTES = "minutes"
        const val EXTRA_AUTO = "auto"

        /** Tünelin istemci adresi ve sahte DNS adresi (özel aralık; gerçek bir cihazla çakışmaz). */
        const val CLIENT_ADDR = SelfTest.CLIENT_ADDR
        const val FAKE_DNS = SelfTest.FAKE_DNS
        const val CLIENT_ADDR6 = SelfTest.CLIENT_ADDR6
        const val FAKE_DNS6 = SelfTest.FAKE_DNS6
        const val MTU = 1500

        private const val CHECK_TRIES = 4
        private const val CHECK_MS = 2000L
        private const val CHECK_MS_SECURE = 3500L
        private const val CHECK_MS_ODOH = 6000L
        private const val RECHECK_MS = 8_000L
        private const val HEALTH_MS = 60_000L
        private const val GW_TICK_MS = 30_000L
        private const val GW_FAIL_MIN = 15
        private const val RETIRE_MS = 3000L
        private const val FLUSH_MS = 60_000L
        private const val UPGRADE_MS = 10 * 60_000L
        private const val SEALED_RETRY_MAX_MS = 120_000L
        private const val NET_RETRY_MIN_MS = 10_000L
        // İlk üçü hızlı (kısa kesinti), sonrakiler seyrek: uçak modu ya da uzun kesintide pil harcamadan yaklaşık 1,5 saat denenir.
        private val RETRY_DELAYS = longArrayOf(5_000L, 30_000L, 120_000L, 5 * 60_000L, 10 * 60_000L, 15 * 60_000L, 30 * 60_000L)

        /** [serverId] boşsa servis ağ kuralına, yoksa son kullanılan sunucuya bakar. */
        fun connectIntent(ctx: Context, serverId: String?, auto: Boolean = false): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_CONNECT).also {
                if (serverId != null) it.putExtra(EXTRA_SERVER, serverId)
                if (auto) it.putExtra(EXTRA_AUTO, true)
            }

        fun disconnectIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_DISCONNECT)

        fun pauseIntent(ctx: Context, minutes: Int): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_PAUSE).putExtra(EXTRA_MINUTES, minutes)

        fun resumeIntent(ctx: Context, auto: Boolean = false): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_RESUME).also { if (auto) it.putExtra(EXTRA_AUTO, true) }

        fun nextIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_NEXT)

        fun clearCacheIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_CLEAR_CACHE)

        fun reapplyIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_REAPPLY)

        fun rebuildIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_REBUILD)

        /** DNS'i durdur, çalışan modüller (varsa) sürsün; modül yoksa her şey kapanır. */
        fun dnsOffIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_DNS_OFF)

        /** Modüllerin istenen durumu (DPI atlatma, Reklam+). Tünel yoksa yalnızca modüller başlar. */
        fun modulesIntent(ctx: Context, dpi: Boolean, ads: Boolean): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_MODULES).putExtra(EXTRA_DPI, dpi).putExtra(EXTRA_ADS, ads)

        fun testIntent(ctx: Context): Intent =
            Intent(ctx, DnsVpnService::class.java).setAction(ACTION_TEST)
    }
}
