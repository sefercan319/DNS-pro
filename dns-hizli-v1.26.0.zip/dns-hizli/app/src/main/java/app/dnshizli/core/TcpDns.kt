package app.dnshizli.core

import java.security.SecureRandom
import java.util.Random

/**
 * Tünelin kendi TCP katmanı (DNS-over-TCP). Sıfırdan yazıldı, dış kütüphane yok; yalnızca sahte DNS adresinin 53. portuna
 * gelen bağlantıları karşılar (tünele başka bir şey girmez). Android'e bağlı değildir, JVM'de test edilir.
 *
 * Neden: bir cevap UDP'ye sığmayınca (ya da istemci EDNS bilmiyorsa) sistem "kesildi" (TC) görür ve soruyu TCP ile yineler.
 * Bu bağlantıyı karşılamazsak sorgu sessizce kaybolurdu.
 *
 * Çalışma biçimi:
 *  1. Sunucu tarafı TCP: SYN → SYN+ACK → veri; her mesaj 2 bayt uzunlukla başlar (RFC 1035 §4.2.2). Boru hattı (aynı
 *     bağlantıda birden çok soru) desteklenir. Yalnızca sıralı gelen veri kabul edilir; sıra dışı segment yinelenen ACK ile
 *     geri çevrilir, istemcinin işletim sistemi yeniden gönderir. Cevaplar MSS boyutunda parçalanır; üç yinelenen ACK'de
 *     yeniden gönderilir. FIN/RST doğru işlenir.
 *  2. Soru, mevcut yönlendiriciye sanki sanal bir UDP istemcisinden geliyormuş gibi verilir ([feed]); böylece süzgeç,
 *     önbellek, şifreli DNS ve yedek sunucu mantığı olduğu gibi çalışır. Sanal istemci adresi tünelin gerçek adresi
 *     olmadığından gerçek bir UDP trafiğiyle karışmaz.
 *  3. Yönlendiricinin tünele yazdığı cevaplar [offer] ile yakalanır (IP parçalarına bölünmüşse birleştirilir) ve TCP
 *     olarak istemciye gönderilir. Sanal adrese giden paketler tünele hiç yazılmaz.
 *
 * Zamanlayıcı yoktur: boş bağlantılar ve cevapsız sorular yalnızca yeni paket geldikçe temizlenir (boşta CPU ve pil yok).
 * Kilit sırası: kendi kilidi → [out] (tünel yazma kilidi). [feed] kilit DIŞINDA çağrılır (yönlendirici kilitleriyle
 * kilitlenme olmasın diye).
 */
internal class TcpDns(
    private val out: (ByteArray, Int, Int) -> Unit,
    private val feed: (ByteArray, Int) -> Unit,
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000L },
    private val random: Random = SecureRandom(),
) {
    private val fake4: ByteArray = Ip.parse(SelfTest.FAKE_DNS)!!
    private val fake6: ByteArray = SelfTest.FAKE6
    private val virt4: ByteArray = fake4.copyOf().also { it[3] = 3 }
    private val virt6: ByteArray = fake6.copyOf().also { it[15] = 3 }

    private class Key(val v6: Boolean, val addr: String, val port: Int) {
        override fun equals(other: Any?) = other is Key && v6 == other.v6 && port == other.port && addr == other.addr
        override fun hashCode() = (addr.hashCode() * 31 + port) * 2 + (if (v6) 1 else 0)
    }

    private class Conn(val key: Key, val client: ByteArray, val v6: Boolean) {
        var established = false
        var sndUna = 0
        var sndNxt = 0
        var rcvNxt = 0
        var mss = MSS
        var last = 0L
        val inBuf = ByteArray(2 + MAX_DNS)
        var inLen = 0
        var sendBuf = ByteArray(0)           // sndUna'dan başlayan, henüz onaylanmamış cevap baytları
        var sendLen = 0
        var pending = 0
        var dup = 0
        var clientFin = false
        var finSent = false
    }

    private class Pending(val key: Key, val addedOpt: Boolean, val at: Long)
    private class Frag(val at: Long) { val buf = ByteArray(8 + MAX_DNS + 8); var have = 0 }

    private val conns = HashMap<Key, Conn>()
    private val pend = HashMap<Int, Pending>()
    private val frags = HashMap<Long, Frag>()
    private var nextPort = 1000
    private val PORT_SPAN = 64001 - 1000

    // ------------------------------------------------------------------ tünelden gelen paket

    /** Tünel okuyucusundan gelen bir TCP paketi. Sorular kilit dışında yönlendiriciye verilir. */
    fun onPacket(p: ByteArray, len: Int) {
        val todo: ArrayList<ByteArray>?
        synchronized(this) { todo = handle(p, len) }
        if (todo != null) for (q in todo) feed(q, q.size)
    }

    val connectionCount: Int get() = synchronized(this) { conns.size }

    /** DNS dışı porta (ör. 853) gelip hemen reddedilen bağlantı sayısı. */
    @Volatile var refused = 0L
        private set

    private fun handle(p: ByteArray, len: Int): ArrayList<ByteArray>? {
        if (len < 40) return null
        val v6: Boolean
        val ipLen: Int
        val total: Int
        val src: ByteArray
        val dst: ByteArray
        when ((p[0].toInt() ushr 4) and 0xF) {
            4 -> {
                ipLen = (p[0].toInt() and 0xF) * 4
                if (ipLen < 20 || len < ipLen + 20 || (p[9].toInt() and 0xFF) != 6) return null
                if ((Packets.u16(p, 6) and 0x3FFF) != 0) return null          // parçalı
                total = minOf(Packets.u16(p, 2), len)
                v6 = false
                src = p.copyOfRange(12, 16); dst = p.copyOfRange(16, 20)
            }
            6 -> {
                if (len < 60 || (p[6].toInt() and 0xFF) != 6) return null      // uzantı başlığı yok
                ipLen = 40
                total = minOf(40 + Packets.u16(p, 4), len)
                v6 = true
                src = p.copyOfRange(8, 24); dst = p.copyOfRange(24, 40)
            }
            else -> return null
        }
        if (total < ipLen + 20 || !dst.contentEquals(if (v6) fake6 else fake4)) return null
        val t = ipLen
        val dport = Packets.u16(p, t + 2)
        if (dport != Packets.DNS_PORT) {
            // Sahte DNS adresimize başka bir porttan bağlantı: en sık Android'in "Özel DNS: otomatik" kipinin DoT (853) yoklaması.
            // Sessizce düşürmek, sistemin SYN'i dakikalarca yeniden göndermesine ve doğrulamanın zaman aşımıyla bitmesine yol açar
            // (her deneme tüneli uyandırır). Hemen RST ile "burada yok" denir: sistem düz DNS'e (bize) hızla karar verir.
            val f = p[t + 13].toInt() and 0xFF
            if (f and SYN != 0 && f and ACK == 0 && f and RST == 0) {
                refused++
                emit(v6, src, Packets.u16(p, t), 0, Packets.i32(p, t + 4) + 1, RST or ACK, null, 0, 0, 0, sport = dport)
            }
            return null
        }
        val sport = Packets.u16(p, t)
        val seq = Packets.i32(p, t + 4)
        val ack = Packets.i32(p, t + 8)
        val doff = (p[t + 12].toInt() and 0xF0) ushr 2
        val flags = p[t + 13].toInt() and 0xFF
        if (doff < 20 || t + doff > total) return null
        val payOff = t + doff
        val payLen = total - payOff

        val now = nowMs()
        sweep(now)
        val key = Key(v6, String(src, Charsets.ISO_8859_1), sport)
        var c = conns[key]
        val syn = flags and SYN != 0
        val isAck = flags and ACK != 0

        if (flags and RST != 0) {
            if (c != null && (seq - c.rcvNxt) in 0..65535) conns.remove(key)
            return null
        }
        if (syn && !isAck) {
            if (c != null && !c.established && seq == c.rcvNxt - 1) { synAck(c); return null }   // yinelenen SYN
            c?.let { conns.remove(key) }
            if (conns.size >= MAX_CONNS) conns.values.minByOrNull { it.last }?.let { conns.remove(it.key) }
            val n = Conn(key, src, v6)
            n.rcvNxt = seq + 1
            n.sndUna = random.nextInt()
            n.sndNxt = n.sndUna + 1
            n.last = now
            n.mss = peerMss(p, t + 20, payOff).coerceIn(100, MSS)
            conns[key] = n
            synAck(n)
            return null
        }
        if (c == null) {
            // Bilinmeyen bağlantı: RFC 793 uyarınca RST (RST'ye RST verilmez, yukarıda döndük).
            if (isAck) emit(v6, src, sport, ack, 0, RST, null, 0, 0, 0)
            else emit(v6, src, sport, 0, seq + payLen + (if (flags and FIN != 0) 1 else 0), RST or ACK, null, 0, 0, 0)
            return null
        }
        c.last = now

        if (!c.established) {
            if (!isAck) return null
            if (ack != c.sndNxt) { emit(v6, src, sport, ack, 0, RST, null, 0, 0, 0); conns.remove(key); return null }
            c.established = true
            c.sndUna = ack
        } else if (isAck) {
            processAck(c, ack, payLen == 0 && flags and FIN == 0)
            if (!conns.containsKey(key)) return null
        }

        var todo: ArrayList<ByteArray>? = null
        if (payLen > 0 || flags and FIN != 0) {
            if (seq - c.rcvNxt > 0) { sendAck(c); return null }               // boşluk: yinelenen ACK, istemci yeniden gönderir
            val skip = (c.rcvNxt - seq).coerceIn(0, payLen)
            val avail = payLen - skip
            val take = minOf(avail, c.inBuf.size - c.inLen)
            if (take > 0 && !c.finSent) {
                System.arraycopy(p, payOff + skip, c.inBuf, c.inLen, take)
                c.inLen += take
                c.rcvNxt += take
            } else if (take > 0) {
                c.rcvNxt += take                                               // FIN'imizden sonra gelen veri okunmaz
            }
            if (flags and FIN != 0 && take == avail && seq + payLen == c.rcvNxt) { c.rcvNxt++; c.clientFin = true }
            todo = takeQueries(c)
            if (!conns.containsKey(key)) return null
            sendAck(c)
        }
        maybeFin(c)
        return todo
    }

    /** Tamponda biriken tam DNS mesajlarını ayıklar; yönlendiriciye verilecek sentetik UDP paketlerini döner. */
    private fun takeQueries(c: Conn): ArrayList<ByteArray>? {
        var res: ArrayList<ByteArray>? = null
        while (c.inLen >= 2) {
            val n = Packets.u16(c.inBuf, 0)
            if (n < Packets.DNS_HDR || n > MAX_DNS) {                         // bozuk uzunluk: bağlantıyı sıfırla
                emit(c.v6, c.client, c.key.port, c.sndNxt, 0, RST, null, 0, 0, 0)
                conns.remove(c.key)
                return res
            }
            if (c.inLen < 2 + n) break
            val pkt = dispatch(c, c.inBuf, 2, n)
            if (pkt != null) { if (res == null) res = ArrayList(2); res.add(pkt) }
            System.arraycopy(c.inBuf, 2 + n, c.inBuf, 0, c.inLen - 2 - n)
            c.inLen -= 2 + n
        }
        return res
    }

    /** Bir soruyu sentetik UDP paketine çevirir ve cevabı bekleyenlere yazar. Sınırlar aşılırsa soru atılır. */
    private fun dispatch(c: Conn, buf: ByteArray, off: Int, n: Int): ByteArray? {
        if (c.pending >= MAX_PENDING || pend.size >= MAX_PENDING_ALL) return null
        // EDNS yoksa 1232 baytlık OPT eklenir: düz UDP yukarı akışta cevap 512'de kesilmesin. Cevaptan geri çıkarılır.
        val addOpt = Packets.u16(buf, off + 10) == 0 && n + OPT_LEN <= MAX_DNS
        val q = ByteArray(if (addOpt) n + OPT_LEN else n)
        System.arraycopy(buf, off, q, 0, n)
        if (addOpt) {
            Packets.put16(q, 10, 1)
            q[n] = 0                                                         // kök ad
            Packets.put16(q, n + 1, 41)                                     // OPT
            Packets.put16(q, n + 3, 1232)                                   // UDP yük boyutu
            Packets.put32(q, n + 5, 0)
            Packets.put16(q, n + 9, 0)
        }
        var port: Int
        var tries = 0
        do {                                                                 // kullanımdaki portlar atlanır; hepsi doluysa soru atılır (sonsuz döngü yok)
            if (++tries > PORT_SPAN) return null
            port = nextPort++; if (nextPort > 65000) nextPort = 1000
        } while (pend.containsKey(port))
        val pkt: ByteArray
        if (c.v6) {
            pkt = ByteArray(Packets.HDR6 + q.size)
            System.arraycopy(q, 0, pkt, Packets.HDR6, q.size)
            Packets.writeHeaders6(pkt, virt6, fake6, port, Packets.DNS_PORT, q.size)
        } else {
            pkt = ByteArray(Packets.HDR + q.size)
            System.arraycopy(q, 0, pkt, Packets.HDR, q.size)
            Packets.writeHeaders(pkt, ipInt(virt4), ipInt(fake4), port, Packets.DNS_PORT, q.size, Packets.nextIdent())
        }
        pend[port] = Pending(c.key, addOpt, nowMs())
        c.pending++
        return pkt
    }

    // ------------------------------------------------------------------ yönlendiricinin cevapları

    /**
     * Yönlendiricinin tünele yazmak üzere olduğu bir paket. Sanal istemci adresine gidiyorsa yakalanır (true; tünele
     * yazılmaz), değilse false. Her iş parçacığından çağrılabilir. IP parçaları birleştirilir.
     */
    fun offer(b: ByteArray, off: Int, len: Int): Boolean {
        if (len < 28) return false
        when ((b[off].toInt() ushr 4) and 0xF) {
            4 -> {
                if ((b[off + 9].toInt() and 0xFF) != 17 || !same(b, off + 16, virt4)) return false
                val ihl = (b[off].toInt() and 0xF) * 4
                val total = minOf(Packets.u16(b, off + 2), len)
                if (ihl < 20 || total < ihl + 8) return true
                val ff = Packets.u16(b, off + 6)
                synchronized(this) {
                    datagram(Packets.u16(b, off + 4).toLong(), (ff and 0x1FFF) * 8, ff and 0x2000 != 0, b, off + ihl, total - ihl)
                }
                return true
            }
            6 -> {
                if (len < 48 || !same(b, off + 24, virt6)) return false
                val nh = b[off + 6].toInt() and 0xFF
                if (nh == 17) {
                    synchronized(this) { datagram(0L, 0, false, b, off + 40, len - 40) }
                    return true
                }
                if (nh == 44 && (b[off + 40].toInt() and 0xFF) == 17) {
                    val ff = Packets.u16(b, off + 42)
                    val id = (1L shl 32) or (Packets.i32(b, off + 44).toLong() and 0xFFFFFFFFL)
                    synchronized(this) { datagram(id, (ff ushr 3) * 8, ff and 1 != 0, b, off + 48, len - 48) }
                    return true
                }
                return true         // başka uzantı başlığı: sanal adres, yine de tünele yazılmaz
            }
        }
        return false
    }

    /** UDP verisinin tamamı ya da bir parçası. Parçalar sırayla gelir (kendi yazıcımız); sırası bozulursa atılır. */
    private fun datagram(id: Long, fo: Int, more: Boolean, b: ByteArray, o: Int, n: Int) {
        if (fo == 0 && !more) { udp(b, o, n); return }
        val now = nowMs()
        var f = frags[id]
        if (fo == 0) {
            if (frags.size >= MAX_FRAGS) frags.clear()
            f = Frag(now); frags[id] = f
        }
        if (f == null) return
        if (fo != f.have || f.have + n > f.buf.size) { frags.remove(id); return }
        System.arraycopy(b, o, f.buf, f.have, n)
        f.have += n
        if (!more) { frags.remove(id); udp(f.buf, 0, f.have) }
    }

    private fun udp(b: ByteArray, o: Int, n: Int) {
        if (n < 8 + Packets.DNS_HDR || Packets.u16(b, o) != Packets.DNS_PORT) return
        val dnsLen = minOf(Packets.u16(b, o + 4) - 8, n - 8)
        if (dnsLen < Packets.DNS_HDR) return
        val pd = pend.remove(Packets.u16(b, o + 2)) ?: return
        val c = conns[pd.key] ?: return
        c.pending--
        // Tampon yönlendiriciye aittir (aynı cevap başkasına da verilebilir): kopya üzerinde çalışılır.
        val dns = b.copyOfRange(o + 8, o + 8 + dnsLen)
        val n2 = if (pd.addedOpt) Dns.stripOpt(dns, 0, dns.size) else dns.size
        if (c.finSent || c.sendLen + 2 + n2 > MAX_SEND) return
        val need = c.sendLen + 2 + n2
        if (c.sendBuf.size < need) c.sendBuf = c.sendBuf.copyOf(maxOf(need, c.sendBuf.size * 2))
        Packets.put16(c.sendBuf, c.sendLen, n2)
        System.arraycopy(dns, 0, c.sendBuf, c.sendLen + 2, n2)
        val firstNew = c.sendLen
        c.sendLen += 2 + n2
        // Yeni baytlar parça parça gönderilir.
        var sentOff = firstNew
        while (sentOff < c.sendLen) {
            val take = minOf(c.mss, c.sendLen - sentOff)
            emit(c.v6, c.client, c.key.port, c.sndNxt, c.rcvNxt, ACK or PSH, c.sendBuf, sentOff, take, 0)
            c.sndNxt += take
            sentOff += take
        }
        maybeFin(c)
    }

    // ------------------------------------------------------------------ bağlantı durumu

    private fun processAck(c: Conn, ack: Int, pure: Boolean) {
        val acked = ack - c.sndUna
        if (acked > 0 && ack - c.sndNxt <= 0) {
            val data = minOf(acked, c.sendLen)
            if (data > 0) {
                System.arraycopy(c.sendBuf, data, c.sendBuf, 0, c.sendLen - data)
                c.sendLen -= data
            }
            c.sndUna = ack
            c.dup = 0
            if (c.finSent && ack == c.sndNxt) conns.remove(c.key)          // FIN'imiz onaylandı: kapandı
        } else if (acked == 0 && pure && (c.sendLen > 0 || (c.finSent && ack != c.sndNxt))) {
            if (++c.dup >= 3) { c.dup = 0; retransmit(c) }
        }
    }

    private fun retransmit(c: Conn) {
        if (c.sendLen > 0) {
            emit(c.v6, c.client, c.key.port, c.sndUna, c.rcvNxt, ACK or PSH, c.sendBuf, 0, minOf(c.mss, c.sendLen), 0)
        } else if (c.finSent) {
            emit(c.v6, c.client, c.key.port, c.sndNxt - 1, c.rcvNxt, FIN or ACK, null, 0, 0, 0)
        }
    }

    /** İstemci kapanmak istedi ve bekleyen soru kalmadıysa kendi FIN'imizi göndeririz. */
    private fun maybeFin(c: Conn) {
        if (!c.clientFin || c.pending > 0 || c.finSent || !c.established) return
        emit(c.v6, c.client, c.key.port, c.sndNxt, c.rcvNxt, FIN or ACK, null, 0, 0, 0)
        c.sndNxt++
        c.finSent = true
    }

    private fun synAck(c: Conn) {
        emit(c.v6, c.client, c.key.port, c.sndUna, c.rcvNxt, SYN or ACK, null, 0, 0, MSS)
    }

    private fun sendAck(c: Conn) {
        emit(c.v6, c.client, c.key.port, c.sndNxt, c.rcvNxt, ACK, null, 0, 0, 0, window = c.inBuf.size - c.inLen)
    }

    /** Eski bağlantıları ve cevabı gelmeyen soruları temizler (yalnızca paket gelince çalışır). */
    private fun sweep(now: Long) {
        if (conns.isNotEmpty()) conns.values.removeAll { now - it.last > IDLE_MS }
        if (pend.isNotEmpty()) {
            val it = pend.values.iterator()
            while (it.hasNext()) {
                val pd = it.next()
                if (now - pd.at > PENDING_MS) { it.remove(); conns[pd.key]?.let { c -> if (c.pending > 0) c.pending-- } }
            }
        }
        if (frags.isNotEmpty()) frags.values.removeAll { now - it.at > FRAG_MS }
    }

    // ------------------------------------------------------------------ paket kurma

    /** İstemciye bir TCP segmenti yazar. [mssOpt] > 0 ise MSS seçeneği eklenir (yalnızca SYN+ACK). */
    private fun emit(
        v6: Boolean, dst: ByteArray, dport: Int, seq: Int, ack: Int, flags: Int,
        data: ByteArray?, dOff: Int, dLen: Int, mssOpt: Int, window: Int = WINDOW, sport: Int = Packets.DNS_PORT,
    ) {
        val ipLen = if (v6) 40 else 20
        val tcpLen = 20 + (if (mssOpt > 0) 4 else 0)
        val total = ipLen + tcpLen + dLen
        val pkt = ByteArray(total)
        val src = if (v6) fake6 else fake4
        if (v6) {
            pkt[0] = 0x60
            Packets.put16(pkt, 4, tcpLen + dLen)
            pkt[6] = 6
            pkt[7] = 64
            System.arraycopy(src, 0, pkt, 8, 16)
            System.arraycopy(dst, 0, pkt, 24, 16)
        } else {
            pkt[0] = 0x45
            Packets.put16(pkt, 2, total)
            Packets.put16(pkt, 4, Packets.nextIdent() and 0xFFFF)
            Packets.put16(pkt, 6, 0x4000)                                   // parçalama yok
            pkt[8] = 64
            pkt[9] = 6
            System.arraycopy(src, 0, pkt, 12, 4)
            System.arraycopy(dst, 0, pkt, 16, 4)
            Packets.put16(pkt, 10, Packets.checksum(pkt, 0, 20))
        }
        val t = ipLen
        Packets.put16(pkt, t, sport)
        Packets.put16(pkt, t + 2, dport)
        Packets.put32(pkt, t + 4, seq)
        Packets.put32(pkt, t + 8, ack)
        pkt[t + 12] = ((tcpLen / 4) shl 4).toByte()
        pkt[t + 13] = flags.toByte()
        Packets.put16(pkt, t + 14, window.coerceIn(0, 65535))
        if (mssOpt > 0) { pkt[t + 20] = 2; pkt[t + 21] = 4; Packets.put16(pkt, t + 22, mssOpt) }
        if (dLen > 0 && data != null) System.arraycopy(data, dOff, pkt, t + tcpLen, dLen)
        Packets.put16(pkt, t + 16, tcpChecksum(pkt, t, tcpLen + dLen, src, dst))
        out(pkt, 0, total)
    }

    // ------------------------------------------------------------------ yardımcılar

    private fun same(b: ByteArray, off: Int, a: ByteArray): Boolean {
        for (i in a.indices) if (b[off + i] != a[i]) return false
        return true
    }

    private fun ipInt(a: ByteArray): Int = Packets.ip(a[0].toInt() and 0xFF, a[1].toInt() and 0xFF, a[2].toInt() and 0xFF, a[3].toInt() and 0xFF)

    /** SYN seçeneklerinden MSS (yoksa 536). */
    private fun peerMss(p: ByteArray, from: Int, end: Int): Int {
        var i = from
        while (i < end) {
            val kind = p[i].toInt() and 0xFF
            if (kind == 0) break
            if (kind == 1) { i++; continue }
            if (i + 1 >= end) break
            val l = p[i + 1].toInt() and 0xFF
            if (l < 2 || i + l > end) break
            if (kind == 2 && l == 4) return Packets.u16(p, i + 2)
            i += l
        }
        return 536
    }

    companion object {
        const val FIN = 0x01
        const val SYN = 0x02
        const val RST = 0x04
        const val PSH = 0x08
        const val ACK = 0x10

        /** Bir segmentin taşıyacağı en çok veri: IPv6 + TCP başlığıyla 1280 baytlık en küçük IPv6 MTU'ya bile sığar. */
        const val MSS = 1200
        const val WINDOW = 16384
        const val MAX_DNS = DnsForwarder.MAX_DNS
        const val MAX_CONNS = 32
        const val MAX_PENDING = 8
        const val MAX_PENDING_ALL = 64
        const val MAX_FRAGS = 16
        const val MAX_SEND = 64 * 1024
        const val IDLE_MS = 30_000L
        const val PENDING_MS = 10_000L
        const val FRAG_MS = 5_000L
        private const val OPT_LEN = 11

        /** TCP sağlama toplamı (sözde başlık + segment). [tcpLen]: başlık + veri. */
        fun tcpChecksum(pkt: ByteArray, t: Int, tcpLen: Int, src: ByteArray, dst: ByteArray): Int {
            var sum = 0L
            var i = 0
            while (i < src.size) {
                sum += ((src[i].toInt() and 0xFF) shl 8) or (src[i + 1].toInt() and 0xFF)
                sum += ((dst[i].toInt() and 0xFF) shl 8) or (dst[i + 1].toInt() and 0xFF)
                i += 2
            }
            sum += 6
            sum += tcpLen
            var k = t
            val end = t + tcpLen
            while (k + 1 < end) {
                sum += ((pkt[k].toInt() and 0xFF) shl 8) or (pkt[k + 1].toInt() and 0xFF)
                k += 2
            }
            if (k < end) sum += (pkt[k].toInt() and 0xFF) shl 8
            while ((sum ushr 16) != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
            return sum.toInt().inv() and 0xFFFF
        }
    }
}
