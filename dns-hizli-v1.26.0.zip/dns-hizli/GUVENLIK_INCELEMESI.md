# Güvenlik incelemesi (v1.23.0, kaynak kodu okuma)

Kapsam: manifest ve dışa açık bileşenler, ayar içe aktarma, dosya/fotoğraf okuma, DNS/paket ayrıştırıcılar, ODoH ve şifreli ağ katmanı.
Yöntem: kodu okuma + var olan testler (6154 kontrol, 0 hata). Dinamik test (çalışan uygulamaya saldırı), cihaz ve gerçek ağ YAPILMADI.

## Bulgular
| # | Önem | Konu | Durum |
|---|------|------|-------|
| 1 | Düşük | `OdohNode.path` HTTP isteğine doğrudan yazılıyordu; denetim karakteri/boşluk içeren bir yol istek bölmeye yol açabilirdi. Yollar şu an koda gömülü sabitlerdir, yani sömürülebilir değildi (savunma derinliği). | Düzeltildi + test |
| 2 | Düşük | `MiniHttps`: okuma zaman aşımı bir kez kuruluyordu; damlatan bir hedef toplam süreyi (8 sn) ~2 katına çıkarabiliyordu. | Düzeltildi (v1.24.0): zaman aşımı her okumadan önce kalan bütçeye göre yeniden kurulur; test: "yavaş damlatan hedef toplam bütçeyi aşmaz" |
| 3 | Bilgi | Ayar kodu ile `odoh=strict` içe aktarılırsa bağlantı kurulamayabilir (hizmet aksatma). Ayar gevşemediği için uyarı listesinde değil. | Bilinçli |
| 4 | Bilgi | ODoH yapılandırma alımında hedef, kullanıcının IP'sini görür (soru görmez). Röle/hedef anlaşırsa ODoH'un gizliliği biter. İpucu IP'leri zamanla eskir. | Belgelendi (GIZLILIK.md) |

## Temiz çıkanlar
- Manifest: yedekleme kapalı, düz HTTP yasak, VPN servisi dışa kapalı, widget/bildirim alıcıları dışa kapalı; dışa açık ana etkinlik "kes" isteğini kullanıcıya sorar, "bağlan"da sunucu seçemez; BootReceiver sahte QUICKBOOT yayınına karşı korumalı.
- Ayar içe aktarma: boyut sınırı, bilinmeyen/yerel anahtarlar atılır, gevşeme özeti gösterilir, geri alma var. Özel DNS sunucuları dışa/içe aktarılmaz.
- Dosya okuma: karakter sınırı; fotoğraf: örnekleme ile boyut sınırı.
- DNS ayrıştırıcılar: sıkıştırma işaretçisi sınırlı, uzunluklar denetli, rastgele bozma testleri (yüz binlerce girdi) var; sahte cevap soru/kimlik denetimiyle reddedilir.
- ODoH: sertifika adı doğrulanır; cevap AEAD ile doğrulanır, dolgu sıfır olmalı; yapılandırma doğrudan hedeften alınır (röle anahtarı değiştiremez); 401 yenilemesi hız sınırlı; ölü/sahte röle yolu kesilir; ODoH Sıkı'da başka yönteme düşülmez.

## Kapsam dışı / yapılamayan
Cihazda çalışma zamanı davranışı, gerçek ağ saldırıları, bağımsız şifreleme denetimi (X25519/HPKE kendi gerçeklemedir; RFC vektörleri ve JDK ile doğrulandı ama uzman gözden geçirmesi yok), bağımlılık/derleme zinciri. Yayından önce APK'ya MobSF gibi bir araç ya da ücretli bağımsız pentest önerilir.
