package app.dnshizli.selftest

import app.dnshizli.core.*

/**
 * Ses uyumluluk katmanı: cihazın hangi yolda çalıştığını bulma, hatırlama ve yıkılmadan geçme davranışı.
 * Android'in kendisi burada yok; gerçek cihaz davranışı [SoundBackend] arkasında sahte bir motorla sınanır.
 */
fun runSoundCompatTests() {
    T.group("Ses uyumluluğu: yol seçimi, hatırlama ve dayanıklılık")
    run {
        val calls = ArrayList<SoundPath>()
        val fails = HashSet<SoundPath>()
        val throws = HashSet<SoundPath>()
        val remembered = ArrayList<SoundPath>()
        val logs = ArrayList<String>()
        val backend = object : SoundBackend {
            override fun play(path: SoundPath, e: Sfx, volume: Float): Boolean {
                calls.add(path)
                if (path in throws) throw IllegalStateException("cihaz")
                return path !in fails
            }
        }
        val c = SoundCompat(backend, null, { remembered.add(it) }, { logs.add(it) })

        T.check("ilk çalmada ilk yol denenir ve çalışırsa hatırlanır", c.play(Sfx.TAP, 0.5f) == SoundPath.STATIC_RELOAD && remembered == listOf(SoundPath.STATIC_RELOAD))
        calls.clear()
        c.play(Sfx.TAP, 0.5f)
        T.check("hatırlanan yol bir sonraki çalmada önce denenir", calls == listOf(SoundPath.STATIC_RELOAD) && remembered.size == 1)

        // Samsung benzeri: statik yol istisna atar, akış çalışır.
        throws.add(SoundPath.STATIC_RELOAD)
        calls.clear()
        val p = c.play(Sfx.TAP, 0.5f)
        T.check("istisna atan yol atlanır, sıradaki çalışır ve yeni yol hatırlanır", p == SoundPath.STREAM_SONIFICATION && c.best == p && remembered.last() == p)
        T.check("istisna günlüğe yazılır (tür adıyla, kişisel veri yok)", logs.any { it.contains("STATIC_RELOAD") && it.contains("IllegalStateException") })
        calls.clear()
        c.play(Sfx.TAP, 0.5f)
        T.check("yeni hatırlanan yol önce denenir (statik tekrar denenmez)", calls == listOf(SoundPath.STREAM_SONIFICATION))

        // Çalışan yol bir gün bozulursa (ör. sistem sesi kapandı) sıradakine kendiliğinden geçer.
        fails.add(SoundPath.STREAM_SONIFICATION)
        calls.clear()
        val p2 = c.play(Sfx.TAP, 0.5f)
        T.check("hatırlanan yol bozulursa sıradakine geçilir", p2 == SoundPath.STREAM_MEDIA && c.best == SoundPath.STREAM_MEDIA && calls.first() == SoundPath.STREAM_SONIFICATION)
        T.check("yol değişince günlüğe yazılır", logs.any { it == "ses yolu: STREAM_MEDIA" })
    }

    run {
        // Hiçbir yol çalmıyor: uygulama çökmez, sayaç artar, sonra sıfırlanır.
        val backend = object : SoundBackend {
            override fun play(path: SoundPath, e: Sfx, volume: Float): Boolean = throw RuntimeException("yok")
        }
        val logs = ArrayList<String>()
        val c = SoundCompat(backend, SoundPath.TONE, { }, { logs.add(it) })
        var threw = false
        var nulls = 0
        repeat(120) { if (c.play(Sfx.CONNECT, 0.8f) == null) nulls++ }
        T.check("hiçbir yol çalmazsa istisna çıkmaz ve sessizce vazgeçilir", !threw && nulls == 120)
        T.check("üst üste başarısızlık sayılır", c.failures == 120)
        T.check("başarısızlık günlüğü seyrek yazılır (taşmaz)", logs.count { it.contains("hiçbir ses yolu") } in 1..4)
    }

    run {
        // Başlangıçta kayıtlı yol varsa o önce denenir (uygulama yeniden açılınca).
        val calls = ArrayList<SoundPath>()
        val backend = object : SoundBackend {
            override fun play(path: SoundPath, e: Sfx, volume: Float): Boolean { calls.add(path); return true }
        }
        val c = SoundCompat(backend, SoundPath.STREAM_MEDIA, { }, { })
        c.play(Sfx.DONE, 0.3f)
        T.check("kayıtlı yol en iyisi değilse oturumda bir kez bir üst yol denenir", calls == listOf(SoundPath.STREAM_SONIFICATION))
        T.check("üst yol çalışırsa yeni en iyi yol olur", c.best == SoundPath.STREAM_SONIFICATION)
        calls.clear(); c.play(Sfx.DONE, 0.3f)
        T.check("üst yol denemesi oturumda yalnızca bir kez yapılır", calls == listOf(SoundPath.STREAM_SONIFICATION))
        T.check("sıra dört yolun tümünü kapsar", SoundPath.values().size == 4)
    }

    run {
        // Kayıtlı yol en iyisiyken üst yol denemesi yok; üst yol bozuksa eski yola sessizce dönülür.
        val calls = ArrayList<SoundPath>()
        val backend = object : SoundBackend {
            override fun play(path: SoundPath, e: Sfx, volume: Float): Boolean { calls.add(path); return path != SoundPath.STREAM_SONIFICATION }
        }
        val c = SoundCompat(backend, SoundPath.STREAM_MEDIA, { }, { })
        c.play(Sfx.TAP, 0.5f)
        T.check("bozuk üst yol denenir, hatırlanan yola dönülür", calls == listOf(SoundPath.STREAM_SONIFICATION, SoundPath.STREAM_MEDIA) && c.best == SoundPath.STREAM_MEDIA)
        val c2 = SoundCompat(backend, SoundPath.STATIC_RELOAD, { }, { })
        calls.clear(); c2.play(Sfx.TAP, 0.5f)
        T.check("en iyi yol kayıtlıysa fazladan deneme yok", calls == listOf(SoundPath.STATIC_RELOAD))
    }

    T.group("Ses uyumluluğu: kanal seçimi (titreşim, sıfır seviye, medya)")
    run {
        fun st(r: Ringer = Ringer.NORMAL, sys: Int = 5, sysM: Boolean = false, med: Int = 8, medM: Boolean = false) = AudioState(r, sys, sysM, med, medM)
        val sys = SoundPath.values().filter { it.system }
        val media = SoundPath.values().filter { !it.system }
        val p1 = SoundRoute.plan(st(), SoundOutput.AUTO)
        T.check("otomatik, her şey açık: tüm yollar, sistem önce", p1.block == SoundBlock.NONE && p1.paths == SoundPath.values().toList())
        T.check("otomatik, titreşim + medya açık: medya kanalından çalar (oyun/klavye sesleri gibi)", SoundRoute.plan(st(r = Ringer.VIBRATE), SoundOutput.AUTO).let { it.block == SoundBlock.NONE && it.paths == media })
        T.check("otomatik, titreşim + medya kapalı: çalmaz, nedeni zil modu (normale alınca sistem çalar)", SoundRoute.plan(st(r = Ringer.VIBRATE, med = 0), SoundOutput.AUTO).block == SoundBlock.RINGER)
        T.check("otomatik, sessiz mod: çalmaz (tam sessizde susar)", SoundRoute.plan(st(r = Ringer.SILENT), SoundOutput.AUTO).let { it.block == SoundBlock.RINGER && it.paths.isEmpty() })
        val p2 = SoundRoute.plan(st(sys = 0), SoundOutput.AUTO)
        T.check("otomatik, sistem sesi sıfır, medya açık: medya kanalına geçer (Samsung sessizliği)", p2.block == SoundBlock.NONE && p2.paths == media)
        T.check("otomatik, sistem sesi kapalı (mute), medya açık: medya", SoundRoute.plan(st(sysM = true), SoundOutput.AUTO).paths == media)
        T.check("otomatik, her iki kanal sıfır: çalmaz, neden seviye", SoundRoute.plan(st(sys = 0, med = 0), SoundOutput.AUTO).block == SoundBlock.ZERO_VOLUME)
        T.check("otomatik, medya sıfır: medya yollarına inilmez (sessizliğe düşmesin)", SoundRoute.plan(st(med = 0), SoundOutput.AUTO).paths == sys)
        T.check("sistem çıkışı: yalnızca sistem yolları", SoundRoute.plan(st(), SoundOutput.SYSTEM).paths == sys)
        T.check("sistem çıkışı, titreşim: çalmaz", SoundRoute.plan(st(r = Ringer.VIBRATE), SoundOutput.SYSTEM).block == SoundBlock.RINGER)
        T.check("medya çıkışı, titreşim: yine çalar (oyunlar gibi)", SoundRoute.plan(st(r = Ringer.VIBRATE), SoundOutput.MEDIA).let { it.block == SoundBlock.NONE && it.paths == media })
        T.check("medya çıkışı, medya sıfır: çalmaz", SoundRoute.plan(st(med = 0), SoundOutput.MEDIA).block == SoundBlock.ZERO_VOLUME)
        T.check("durum okunamazsa (null) tercih edilen kanaldan sırayla denenir", SoundRoute.plan(null, SoundOutput.AUTO).paths.size == 4 && SoundRoute.plan(null, SoundOutput.MEDIA).paths == media)

        // Kanal yüzünden atlanan yollar hatırlanan yolu bozmaz.
        val calls = ArrayList<SoundPath>()
        val backend = object : SoundBackend {
            override fun play(path: SoundPath, e: Sfx, volume: Float): Boolean { calls.add(path); return true }
        }
        val c = SoundCompat(backend, null, { }, { })
        c.play(Sfx.TAP, 0.5f)
        T.check("ilk çalma: statik yol", c.best == SoundPath.STATIC_RELOAD)
        c.play(Sfx.TAP, 0.5f, media)
        T.check("sistem kısıkken medya çalar ama en iyi yol (cihaz yeteneği) değişmez", calls.last() == SoundPath.STREAM_MEDIA && c.best == SoundPath.STATIC_RELOAD)
        calls.clear(); c.play(Sfx.TAP, 0.5f, SoundPath.values().toList())
        T.check("sistem sesi geri gelince yine statik yol", calls == listOf(SoundPath.STATIC_RELOAD))
        T.check("boş izin listesi: hiçbir şey denenmez", c.play(Sfx.TAP, 0.5f, emptyList()) == null)
    }

    T.group("Ses uyumluluğu: sessiz başarı ve hoparlör ısınması")
    run {
        val logs = ArrayList<String>()
        val backend = object : SoundBackend { override fun play(path: SoundPath, e: Sfx, volume: Float) = true }
        val c = SoundCompat(backend, null, { }, { logs.add(it) })
        c.play(Sfx.TAP, 0.5f)
        c.stalled(SoundPath.STATIC_RELOAD)
        T.check("tek ilerlemeyen çalma yolu değiştirmez", c.best == SoundPath.STATIC_RELOAD)
        c.rendered(SoundPath.STATIC_RELOAD)
        c.stalled(SoundPath.STATIC_RELOAD)
        T.check("arada çalışan bir çalma sayacı sıfırlar", c.best == SoundPath.STATIC_RELOAD)
        c.stalled(SoundPath.STATIC_RELOAD)
        T.check("üst üste iki ilerlemeyen çalma: sıradaki yola geçilir", c.best == SoundPath.STREAM_SONIFICATION)
        c.stalled(SoundPath.STREAM_SONIFICATION); c.stalled(SoundPath.STREAM_SONIFICATION)
        T.check("bu yolla oturumda en çok bir kez inilir (yanlış bildiren cihazda zincirleme düşüş yok)", c.best == SoundPath.STREAM_SONIFICATION)
        val c2 = SoundCompat(backend, SoundPath.STREAM_MEDIA, { }, { })
        c2.play(Sfx.TAP, 0.5f, listOf(SoundPath.STREAM_MEDIA, SoundPath.TONE))
        c2.stalled(SoundPath.STREAM_MEDIA); c2.stalled(SoundPath.STREAM_MEDIA)
        T.check("ilerlemeyen çalma yüzünden bip sesine inilmez", c2.best == SoundPath.STREAM_MEDIA)
        T.check("ilerlemeyen çalma günlüğe yazılır", logs.any { it.contains("ilerlemedi") })

        val w = SoundWarmup(coldAfterMs = 2500, preRollMs = 90)
        T.check("soğuk çıkış: ilk sese ön sessizlik eklenir", w.preRoll(10_000) == 90)
        w.played(10_000, 80)
        T.check("art arda dokunuş: gecikme eklenmez", w.preRoll(10_500) == 0 && w.preRoll(12_579) == 0)
        T.check("çıkış soğuyunca yine ön sessizlik", w.preRoll(12_580) == 90)
        T.check("ön sessizlik kısa (algılanan gecikme < 0,1 sn)", SoundWarmup.PRE_ROLL_MS in 40..100)
    }
}
