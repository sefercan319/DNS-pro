package app.dnshizli.selftest

import app.dnshizli.core.*

/** ODoH yol tahtası dayanıklılık ölçümü (test değil; `./run-tests.sh bench`). */
fun runOdohBench() {
    // 8 yoldan 5'i bozuk (bağlantı hatası verir); tahta kaç sorguda sağlam yola oturuyor ve kararlı durumda sağlam seçim oranı.
    val n = 8
    var clock = 0L
    val board = OdohPathBoard(n, { clock }, java.util.Random(1))
    val healthy = setOf(2, 5, 7)
    var firstHealthyAt = -1
    var healthyPicks = 0
    val total = 2000
    for (q in 0 until total) {
        clock += 5
        var mask = 0L
        var pick = -1
        // bir sorguda en çok 3 deneme (SecureForwarder gibi)
        for (a in 0 until 3) {
            val p = board.choose(mask)
            if (p in healthy) { board.success(p, 20); pick = p; break }
            board.failure(p, false); mask = mask or (1L shl p)
        }
        if (pick >= 0) {
            if (firstHealthyAt < 0) firstHealthyAt = q
            if (q >= total - 500) healthyPicks++
        }
    }
    println("\nODoH yol tahtası dayanıklılığı (8 yol, 3'ü sağlam)")
    println("  ilk sağlam cevaba kadar sorgu: ${firstHealthyAt + 1}")
    println("  son 500 sorguda sağlam seçim: %d / 500 (%.0f%%)".format(healthyPicks, healthyPicks / 5.0))
}
