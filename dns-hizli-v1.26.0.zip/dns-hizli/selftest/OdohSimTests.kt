package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.BufferedInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.net.ssl.SSLServerSocket

private val loop: InetAddress = InetAddress.getLoopbackAddress()

/** Sunucu tarafı ODoH (hedef) benzetimi: istemciden bağımsız yazılmış; sorguyu çözer, cevabı RFC 9230 §6.2'ye göre şifreler. */
internal class SimTarget(val host: String) {
    private val rng = SecureRandom()
    @Volatile var sk: ByteArray = X25519.generatePrivate(rng)
    @Volatile var configBytes: ByteArray = odohConfigBytes(X25519.publicKey(sk))
    @Volatile var keyId: ByteArray = OdohConfigs.parse(configBytes)[0].keyId
    val handled = AtomicInteger()
    val rejected = AtomicInteger()
    val plains = CopyOnWriteArrayList<ByteArray>()

    /** Yeni anahtar çifti yayımlanır; eski anahtar artık tanınmaz (günlük döndürme). */
    fun rotate() {
        sk = X25519.generatePrivate(rng)
        configBytes = odohConfigBytes(X25519.publicKey(sk))
        keyId = OdohConfigs.parse(configBytes)[0].keyId
    }

    /** (HTTP durumu, gövde). */
    fun handle(wire: ByteArray): Pair<Int, ByteArray> {
        val o = open(sk, keyId, wire)
        if (o == null) { rejected.incrementAndGet(); return 401 to ByteArray(0) }
        plains.add(o.plain)
        val dl = ((o.plain[0].toInt() and 0xFF) shl 8) or (o.plain[1].toInt() and 0xFF)
        val dns = o.plain.copyOfRange(2, 2 + dl)
        handled.incrementAndGet()
        return 200 to respond(o, answer(dns, dns.size, listOf(byteArrayOf(1, 2, 3, 4))))
    }

    class Opened(val ctx: HpkeContext, val plain: ByteArray)

    companion object {
        fun open(sk: ByteArray, keyId: ByteArray, wire: ByteArray): Opened? {
            if (wire.size < 3 + 32 + 2 + 32 + 16 || wire[0].toInt() != 1) return null
            val kl = ((wire[1].toInt() and 0xFF) shl 8) or (wire[2].toInt() and 0xFF)
            if (kl != keyId.size || wire.size < 3 + kl + 2) return null
            if (!wire.copyOfRange(3, 3 + kl).contentEquals(keyId)) return null
            val p = 3 + kl
            val el = ((wire[p].toInt() and 0xFF) shl 8) or (wire[p + 1].toInt() and 0xFF)
            if (el != wire.size - p - 2 || el < 32 + 16) return null
            val ctx = Hpke.setupBaseR(wire.copyOfRange(p + 2, p + 2 + 32), sk, "odoh query".toByteArray()) ?: return null
            val aad = byteArrayOf(1) + u16b(kl) + keyId
            val plain = ctx.open(aad, wire.copyOfRange(p + 2 + 32, wire.size)) ?: return null
            return Opened(ctx, plain)
        }

        fun respond(o: Opened, dns: ByteArray, tweak: (String, ByteArray) -> ByteArray = { _, b -> b }): ByteArray {
            val base = 2 + dns.size + 2
            val pad = (128 - base % 128) % 128
            val plain = tweak("plain", u16b(dns.size) + dns + u16b(pad) + ByteArray(pad))
            val secret = o.ctx.export("odoh response".toByteArray(), 16)
            val nonce = ByteArray(16).also { SecureRandom().nextBytes(it) }
            val salt = o.plain + u16b(16) + nonce
            val prk = Hkdf.extract(salt, secret)
            val key = Hkdf.expand(prk, "odoh key".toByteArray(), 16)
            val n12 = Hkdf.expand(prk, "odoh nonce".toByteArray(), 12)
            val aad = byteArrayOf(2) + u16b(16) + nonce
            val ct = tweak("ct", Hpke.aeadSeal(key, n12, aad, plain))
            return tweak("wire", byteArrayOf(2) + u16b(16) + nonce + u16b(ct.size) + ct)
        }

        fun respondTo(sk: ByteArray, keyId: ByteArray, wire: ByteArray, dns: ByteArray, tweak: (String, ByteArray) -> ByteArray): ByteArray =
            respond(open(sk, keyId, wire)!!, dns, tweak)
    }
}

internal enum class RelayMode { NORMAL, DROP_CONN, NO_REPLY, STATUS, GARBAGE, WRONG_TYPE, FORGED }

/** ODoH rölesi benzetimi (TLS, HTTP/1.1 keep-alive): hedefe yönlendirir; çeşitli arıza kipleri. */
internal class SimRelay(val targets: Map<String, SimTarget>, val ip: String) : AutoCloseable {
    private val ctx = TestTls.serverContext(TestTls.good)
    val server = ctx.serverSocketFactory.createServerSocket(0, 50, loop) as SSLServerSocket
    val port get() = server.localPort
    val accepted = AtomicInteger()
    @Volatile var mode = RelayMode.NORMAL
    @Volatile var status = 502
    @Volatile var delayMs = 0L
    val down = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    val requests = CopyOnWriteArrayList<String>()
    val headers = CopyOnWriteArrayList<String>()
    val bodies = CopyOnWriteArrayList<ByteArray>()
    val posts = AtomicInteger()
    private val socks = CopyOnWriteArrayList<Socket>()

    init {
        Thread {
            while (!server.isClosed) {
                val s = try { server.accept() } catch (_: Exception) { return@Thread }
                accepted.incrementAndGet()
                socks.add(s)
                Thread { try { serve(s) } catch (_: Exception) {} finally { try { s.close() } catch (_: Exception) {} } }.apply { isDaemon = true; start() }
            }
        }.apply { isDaemon = true; start() }
    }

    private fun line(i: InputStream): String? {
        val sb = StringBuilder()
        while (true) { val c = i.read(); if (c < 0) return null; if (c == '\n'.code) return sb.toString().trimEnd('\r'); sb.append(c.toChar()) }
    }

    private fun serve(s: Socket) {
        if (mode == RelayMode.DROP_CONN) { s.close(); return }
        (s as javax.net.ssl.SSLSocket).startHandshake()
        val i = BufferedInputStream(s.getInputStream())
        val o = s.getOutputStream()
        while (true) {
            if (mode == RelayMode.DROP_CONN) return
            val req = line(i) ?: return
            var len = 0
            val hs = ArrayList<String>()
            while (true) {
                val l = line(i) ?: return
                if (l.isEmpty()) break
                hs.add(l.lowercase())
                if (l.lowercase().startsWith("content-length:")) len = l.substringAfter(':').trim().toInt()
            }
            val body = ByteArray(len)
            var got = 0
            while (got < len) { val r = i.read(body, got, len - got); if (r < 0) return; got += r }
            requests.add(req); headers.addAll(hs); posts.incrementAndGet(); bodies.add(body)
            if (mode == RelayMode.NO_REPLY) continue
            if (delayMs > 0) Thread.sleep(delayMs)
            val q = req.substringAfter('?', "")
            val th = q.split('&').firstOrNull { it.startsWith("targethost=") }?.substringAfter('=') ?: ""
            val t = targets[th]
            when {
                mode == RelayMode.STATUS -> write(o, status, "text/plain", ByteArray(0))
                mode == RelayMode.GARBAGE -> write(o, 200, OdohClient.MEDIA_TYPE, ByteArray(60) { it.toByte() })
                mode == RelayMode.WRONG_TYPE -> write(o, 200, "text/html", "<html>captive</html>".toByteArray())
                t == null || th in down -> write(o, 502, "text/plain", ByteArray(0))
                mode == RelayMode.FORGED -> {
                    // doğru biçimde ama başka bir gizli bilgiyle şifrelenmiş cevap
                    val other = SimTarget("x")
                    write(o, 200, OdohClient.MEDIA_TYPE, SimTarget.respond(
                        SimTarget.Opened(Hpke.setupBaseS(X25519.publicKey(other.sk), "odoh query".toByteArray(), SecureRandom())!!.context, ByteArray(128)),
                        Dns.buildQuery(0, "forged.test")))
                }
                else -> { val (code, out) = t.handle(body); write(o, code, OdohClient.MEDIA_TYPE, out) }
            }
        }
    }

    private fun write(o: OutputStream, code: Int, type: String, body: ByteArray) {
        o.write("HTTP/1.1 $code X\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\n\r\n".toByteArray() + body)
        o.flush()
    }

    fun dropConnections() { for (s in socks) try { s.close() } catch (_: Exception) {}; socks.clear() }
    override fun close() { try { server.close() } catch (_: Exception) {}; dropConnections() }
}

/** 2 röle × 2 hedef, sahte saat, gerçek [SecureForwarder] + [OdohEngine]. */
internal class OdohRig(timeoutMs: Int = 1500, relayCount: Int = 2, targetCount: Int = 2) : AutoCloseable {
    val clock = AtomicLong(1_000_000)
    val targets = (0 until targetCount).map { SimTarget("t$it.test") }
    val relays = (0 until relayCount).map { SimRelay(targets.associateBy { t -> t.host }, "127.0.0.${it + 2}") }
    val relayNodes = (0 until relayCount).map { OdohNode("r$it", "R$it", "rg$it", "dns.test", "/relay", listOf("127.0.0.${it + 2}")) }
    val targetNodes = targets.mapIndexed { i, t -> OdohNode("t$i", "T$i", "tg$i", t.host, "/dns-query", listOf("127.0.1.${i + 1}")) }
    val fetches = AtomicInteger()
    @Volatile var configDown = false
    val engine = OdohEngine(
        relayNodes, targetNodes, { clock.get() }, SecureRandom(),
        { node -> fetches.incrementAndGet(); if (configDown) throw java.io.IOException("ağ yok"); targets.first { it.host == node.host }.configBytes },
        OdohAddressBook({ clock.get() }),
    )
    val tun = LinkedBlockingQueue<ByteArray>()
    val logs = CopyOnWriteArrayList<String>()
    val fw = SecureForwarder(
        proto = Proto.ODOH, targets = engine.relayTargets(),
        writeToTun = { b, off, len -> tun.add(b.copyOfRange(off, off + len)) },
        openSocket = { a, to ->
            val k = relays.indexOfFirst { it.ip == a.address.hostAddress }
            if (k < 0) throw java.io.IOException("bilinmeyen adres ${a.address.hostAddress}")
            Socket().also { it.connect(InetSocketAddress(loop, relays[k].port), to) }
        },
        tls = TestTls.client, verifier = TestTls.verifier,
        timeoutMs = timeoutMs, connectTimeoutMs = 1500, giveUpMs = 6000, idleMs = 20_000, maxLanes = 4,
        log = { logs.add(it) }, odoh = engine,
    ).also { it.start() }

    fun send(id: Int, name: String = "example.com", port: Int = 40000) { val p = qpacket(id, name, port); fw.onPacket(p, p.size) }
    fun reply(ms: Long = 4000): ByteArray? = tun.poll(ms, TimeUnit.MILLISECONDS)
    /** Tek sorgu gönderir, doğru cevap geldiyse true. */
    fun ask(id: Int, name: String): Boolean {
        send(id, name)
        val r = reply() ?: return false
        return checkReply(r, id) == null
    }
    override fun close() { fw.close(); relays.forEach { it.close() } }
}

fun runOdohSimTests() {
    basicFlow()
    keyRotation()
    relayFailures()
    targetFailures()
    hostileRelay()
    recovery()
    concurrencyAndPrivacy()
    configFetch()
    bootstrapTests()
    warmTest()
}

private fun warmTest() {
    T.group("ODoH: anahtar ön ısıtma (iki farklı hedef)")
    OdohRig().use { r ->
        r.engine.warm()
        // iki hedef de en az bir kez istenmeli ki yedek yol ilk sorguda anahtar beklemesin
        T.check("ön ısıtma iki farklı hedefin anahtarını alır", r.fetches.get() >= 2, "fetch=${r.fetches.get()}")
        T.check("iki hedefin de anahtarı önbellekte", r.targetNodes.all { r.engine.keyring.cachedKeyId(it.host) != null })
        val f = r.fetches.get()
        r.engine.warm()
        T.check("taze anahtarlar yeniden alınmaz", r.fetches.get() == f, "fetch=${r.fetches.get() - f}")
    }
    OdohRig(targetCount = 1).use { r ->
        r.engine.warm()
        T.check("tek hedefli kurulumda ısıtma tek istek yapar ve çökmez", r.fetches.get() == 1, "fetch=${r.fetches.get()}")
    }
}

private fun basicFlow() {
    T.group("ODoH: uçtan uca (benzetilmiş röle + hedef)")
    OdohRig().use { r ->
        T.check("sorgu cevaplanır", r.ask(0x1234, "example.com"))
        val rl = r.relays[0]
        T.check("istek röleye POST + hedef parametreleri", rl.requests.firstOrNull() == "POST /relay?targethost=t0.test&targetpath=%2Fdns-query HTTP/1.1", rl.requests.toString())
        T.check("ortam türü başlıkları", rl.headers.any { it == "content-type: application/oblivious-dns-message" } && rl.headers.any { it == "accept: application/oblivious-dns-message" })
        T.check("röle adı Host başlığında", rl.headers.any { it == "host: dns.test" })
        val body = rl.bodies[0]
        T.check("röle düz DNS adını göremez", String(body, Charsets.ISO_8859_1).indexOf("example") < 0)
        val plain = r.targets[0].plains.firstOrNull()
        T.check("hedef sorguyu çözdü; DNS kimliği 0", plain != null && plain[2].toInt() == 0 && plain[3].toInt() == 0)
        T.check("düz metin 128'in katı", plain != null && plain.size % 128 == 0)
        T.check("istemcinin kimliği cevapta korunur", r.ask(0xBEEF, "second.example"))
        T.check("ikinci sorgu aynı bağlantıyı kullanır", rl.accepted.get() == 1, "accepted=${rl.accepted.get()}")
        T.check("aynı ad önbellekten gelir (röleye gitmez)", run { val n = rl.posts.get(); r.ask(0x2222, "example.com") && rl.posts.get() == n })
        T.check("DoH'a düşme yok: yalnızca ODoH", r.fw.proto == Proto.ODOH)
        val st = r.engine.status()
        T.check("durum: yol adı ve gecikme", st.ok >= 2 && st.lastPath == "R0 → T0" && st.lastRttMs >= 1, st.lastPath ?: "null")
    }
}

private fun keyRotation() {
    T.group("ODoH: anahtar dönmesi (401 → yapılandırmayı yenile)")
    OdohRig().use { r ->
        T.check("ilk sorgu", r.ask(1, "a.example"))
        val f0 = r.fetches.get()
        r.targets[0].rotate()
        r.clock.addAndGet(60_000)
        T.check("anahtar döndü: sorgu yine cevaplanır", r.ask(2, "b.example"))
        T.check("hedef bir kez 401 verdi", r.targets[0].rejected.get() == 1, "rejected=${r.targets[0].rejected.get()}")
        T.check("yapılandırma bir kez yenilendi", r.fetches.get() == f0 + 1, "fetch=${r.fetches.get() - f0}")
        T.check("yol cezalandırılmadı (anahtar dönmesi arıza değil)", r.engine.board.snapshot().all { it.fails == 0 })
        T.check("sonraki sorgular normal", r.ask(3, "c.example") && r.targets[0].rejected.get() == 1)
        // hız sınırı
        val f1 = r.fetches.get()
        r.targets[0].rotate()
        r.targets[1].rotate()
        T.check("hemen tekrar dönünce yenileme hız sınırına takılır: sorgu şimdilik cevapsız", !r.ask(4, "d.example"))
        T.check("hız sınırı: kontrolsüz yapılandırma isteği yok", r.fetches.get() <= f1 + 1, "fetch=${r.fetches.get() - f1}")
        T.check("yol yine de cezalanmadı", r.engine.board.snapshot().all { it.fails == 0 })
        r.clock.addAndGet(40_000)
        T.check("süre geçince toparlanır", r.ask(5, "e.example"))
    }
}

private fun relayFailures() {
    T.group("ODoH: röle arızaları ve yük devri")
    OdohRig().use { r ->
        T.check("başlangıç", r.ask(1, "warm.example"))
        r.relays[0].mode = RelayMode.DROP_CONN
        r.relays[0].dropConnections()
        var ok = 0
        for (k in 0 until 12) if (r.ask(100 + k, "n$k.example")) ok++
        T.check("birinci röle ölünce tüm sorgular ikinci röleden cevaplanır", ok == 12, "ok=$ok logs=${r.logs} snap=${r.engine.board.snapshot().map { "${it.fails}/${it.open}/${it.rttMs}" }} st=${r.fw.stats().timeouts}")
        T.check("ikinci röle iş gördü", r.relays[1].posts.get() >= 10)
        T.check("ölü röleye çok az deneme gitti", r.relays[0].accepted.get() <= 8, "accepted=${r.relays[0].accepted.get()}")
        // röle geri gelir
        r.relays[0].mode = RelayMode.NORMAL
        r.clock.addAndGet(300_000)
        var back = false
        for (k in 0 until 80) { r.ask(500 + k, "m$k.example"); if (r.relays[0].posts.get() > 1) { back = true; break } }
        T.check("röle geri gelince yol yeniden kullanılır (keşif/yarı açık)", back, "posts=${r.relays[0].posts.get()}")
    }
    OdohRig().use { r ->
        r.relays[0].mode = RelayMode.NO_REPLY
        var ok = 0
        for (k in 0 until 4) if (r.ask(10 + k, "slow$k.example")) ok++
        T.check("cevap vermeyen röle: sorgular zaman aşımından sonra diğer yoldan gelir", ok >= 2, "ok=$ok")
    }
    OdohRig().use { r ->
        r.relays[0].mode = RelayMode.STATUS; r.relays[0].status = 403
        var ok = 0
        for (k in 0 until 6) if (r.ask(20 + k, "s$k.example")) ok++
        T.check("röle 403 verirse diğerine geçilir", ok == 6, "ok=$ok")
    }
    OdohRig().use { r ->
        T.check("başlangıç", r.ask(1, "x.example"))
        r.relays[0].dropConnections()
        T.check("sunucunun kapattığı bağlantı sessizce yenilenir", r.ask(2, "y.example"))
        T.check("bu bir arıza sayılmadı", r.engine.board.snapshot().all { it.fails == 0 })
    }
}

private fun targetFailures() {
    T.group("ODoH: hedef arızaları")
    OdohRig().use { r ->
        r.relays.forEach { it.down.add("t0.test") }
        var ok = 0
        for (k in 0 until 10) if (r.ask(30 + k, "q$k.example")) ok++
        T.check("hedef çökünce (502) öteki hedefe geçilir", ok == 10, "ok=$ok")
        T.check("öteki hedef iş gördü", r.targets[1].handled.get() >= 8)
        r.relays.forEach { it.down.clear() }
        r.clock.addAndGet(400_000)
        for (k in 0 until 80) { r.ask(300 + k, "z$k.example"); if (r.targets[0].handled.get() > 0) break }
        T.check("hedef dönünce yeniden kullanılır", r.targets[0].handled.get() > 0)
    }
    OdohRig().use { r ->
        r.configDown = true
        T.check("anahtar alınamazsa sorgu cevapsız kalır, çökme yok", !r.ask(1, "k.example"))
        T.check("yapılandırma isteği yağmuru yok", r.fetches.get() <= 6, "fetch=${r.fetches.get()}")
        r.configDown = false
        r.clock.addAndGet(60_000)
        T.check("ağ gelince toparlanır", run { var ok = false; for (k in 0 until 6) if (r.ask(2 + k, "k$k.example")) { ok = true; break }; ok })
    }
}

private fun hostileRelay() {
    T.group("ODoH: kötü niyetli / bozuk röle")
    OdohRig().use { r ->
        r.relays[0].mode = RelayMode.FORGED
        var ok = 0
        for (k in 0 until 6) if (r.ask(40 + k, "f$k.example")) ok++
        T.check("sahte cevaplar kabul edilmez; gerçek yoldan cevap gelir", ok == 6, "ok=$ok")
        T.check("sahte cevap veren yol uzun süre kesilir", r.engine.board.snapshot()[0].open || r.engine.board.snapshot()[1].open)
    }
    OdohRig().use { r ->
        r.relays[0].mode = RelayMode.GARBAGE
        var ok = 0
        for (k in 0 until 6) if (r.ask(50 + k, "g$k.example")) ok++
        T.check("anlamsız gövde reddedilir", ok == 6, "ok=$ok")
    }
    OdohRig().use { r ->
        r.relays[0].mode = RelayMode.WRONG_TYPE
        var ok = 0
        for (k in 0 until 6) if (r.ask(60 + k, "w$k.example")) ok++
        T.check("yanlış içerik türü (ör. giriş sayfası) reddedilir", ok == 6, "ok=$ok")
    }
    OdohRig().use { r ->
        T.check("başlangıç", r.ask(1, "a.example"))
        // ODoH cevabı yerine DoH düz DNS cevabı dönse bile (ortam türü doğru) kabul edilmez
        r.relays[0].mode = RelayMode.GARBAGE
        r.relays[1].mode = RelayMode.GARBAGE
        T.check("tüm yollar bozukken cevap verilmez ama çökme/sızıntı yok", !r.ask(2, "b.example"))
        T.check("bozuk cevap istemciye iletilmedi", r.tun.isEmpty())
        r.relays[0].mode = RelayMode.NORMAL; r.relays[1].mode = RelayMode.NORMAL
        r.clock.addAndGet(300_000)
        T.check("röleler düzelince toparlanır", run { var ok = false; for (k in 0 until 10) if (r.ask(3 + k, "c$k.example")) { ok = true; break }; ok })
    }
}

private fun recovery() {
    T.group("ODoH: ağ değişimi ve kendini toparlama")
    OdohRig().use { r ->
        T.check("başlangıç", r.ask(1, "a.example"))
        r.relays[0].mode = RelayMode.DROP_CONN; r.relays[0].dropConnections()
        for (k in 0 until 6) r.ask(10 + k, "d$k.example")
        r.fw.resetNetwork("test")
        T.check("ağ değişince yol bilgisi sıfırlanır", r.engine.board.snapshot().all { it.fails == 0 && !it.open })
        T.check("sıfırlamadan sonra sorgu çalışır", r.ask(99, "after.example"))
        T.check("açık bağlantılar yenilendi", r.fw.stats().resets >= 1)
    }
    OdohRig().use { r ->
        r.relays.forEach { it.mode = RelayMode.DROP_CONN; it.dropConnections() }
        T.check("tüm röleler kapalı: cevap yok ama canlı", !r.ask(1, "dead.example"))
        r.relays.forEach { it.mode = RelayMode.NORMAL }
        r.clock.addAndGet(200_000)
        T.check("röleler dönünce toparlanır", run { var ok = false; for (k in 0 until 10) if (r.ask(2 + k, "back$k.example")) { ok = true; break }; ok })
    }
}

private fun concurrencyAndPrivacy() {
    T.group("ODoH: eşzamanlılık ve gizlilik")
    OdohRig().use { r ->
        val n = 40
        for (k in 0 until n) r.send(1000 + k, "par$k.example", 41000 + k)
        val ids = HashSet<Int>()
        var bad = 0
        repeat(n) { val x = r.reply(6000); if (x == null) bad++ else { ids.add(Packets.u16(x, 28)) } }
        T.check("40 eşzamanlı sorgunun hepsi cevaplanır", bad == 0 && ids.size == n, "bad=$bad ids=${ids.size}")
        T.check("şeritler sınırlı: en çok 4 bağlantı/röle", r.relays.sumOf { it.accepted.get() } <= 8, r.relays.map { it.accepted.get() }.toString())
        val allBodies = r.relays.flatMap { it.bodies }
        T.check("hiçbir röle gövdesinde düz ad yok", allBodies.none { String(it, Charsets.ISO_8859_1).contains("par") && String(it, Charsets.ISO_8859_1).contains("example") })
        T.check("hiçbir iki sorgu gövdesi aynı değil", allBodies.map { it.toList() }.toSet().size == allBodies.size)
        val enc = allBodies.map { it.copyOfRange(37, 69).toList() }
        T.check("her sorgu taze geçici anahtar kullanır", enc.toSet().size == enc.size)
        T.check("hedefe giden tüm düz DNS kimlikleri 0", r.targets.flatMap { it.plains }.all { it[2].toInt() == 0 && it[3].toInt() == 0 })
        T.check("istemci EDNS seçenekleri / dolgu: düz metin 128'in katı", r.targets.flatMap { it.plains }.all { it.size % 128 == 0 })
    }
}

private fun configFetch() {
    T.group("ODoH: yapılandırma alımı (MiniHttps)")
    val cfg = odohConfigBytes(X25519.publicKey(ByteArray(32) { 5 }))
    HttpSim(cfg).use { h ->
        val open: (InetSocketAddress, Int) -> Socket = { _, to -> Socket().also { it.connect(InetSocketAddress(loop, h.port), to) } }
        val addr = InetSocketAddress(InetAddress.getByAddress(byteArrayOf(127, 0, 0, 9)), 443)
        fun get(host: String = "dns.test", addrs: List<InetSocketAddress> = listOf(addr)): Result<ByteArray> =
            runCatching { MiniHttps.get(host, "/.well-known/odohconfigs", addrs, open, TestTls.client, TestTls.verifier, connectMs = 1500, totalMs = 4000) }
        T.check("content-length ile alır", get().getOrNull()?.contentEquals(cfg) == true)
        T.check("istek yolu ve Host", h.requests.last() == "GET /.well-known/odohconfigs HTTP/1.1" && h.lastHost == "dns.test")
        h.mode = "chunked"
        T.check("parçalı gövde", get().getOrNull()?.contentEquals(cfg) == true)
        h.mode = "close"
        T.check("bağlantı kapanışıyla biten gövde", get().getOrNull()?.contentEquals(cfg) == true)
        h.mode = "404"
        T.check("404 hata verir (adres değiştirmeyi denemeden)", get().exceptionOrNull() is MiniHttps.HttpStatusException)
        h.mode = "301"
        T.check("yönlendirme izlenmez", get().isFailure)
        h.mode = "huge"
        T.check("aşırı büyük gövde reddedilir", get().isFailure)
        h.mode = "lie"
        T.check("kesik gövde reddedilir", get().isFailure)
        h.mode = "ok"
        T.check("yanlış sertifika adı reddedilir", get(host = "other.test").exceptionOrNull() is javax.net.ssl.SSLPeerUnverifiedException || get(host = "other.test").isFailure)
        val dead = InetSocketAddress(InetAddress.getByAddress(byteArrayOf(127, 0, 0, 77)), 443)
        val open2: (InetSocketAddress, Int) -> Socket = { a, to ->
            if (a.address.address[3].toInt() == 77) throw java.io.IOException("bağlanamadı") else Socket().also { it.connect(InetSocketAddress(loop, h.port), to) }
        }
        val good = java.util.concurrent.atomic.AtomicReference<InetSocketAddress>()
        val body = runCatching { MiniHttps.get("dns.test", "/.well-known/odohconfigs", listOf(dead, addr), open2, TestTls.client, TestTls.verifier, onGood = { good.set(it) }) }.getOrNull()
        T.check("ilk adres ölüyse ikinciye geçer ve çalışanı bildirir", body?.contentEquals(cfg) == true && good.get() == addr)
        T.check("adres listesi boşsa hata", runCatching { MiniHttps.get("dns.test", "/", emptyList(), open, TestTls.client, TestTls.verifier) }.isFailure)
    }
    // Yavaş damlatma: her baytta sahte saat 50 ms ilerler; okuma zaman aşımı kalan bütçeye göre yeniden kurulur.
    // Eski kod (tek seferlik zaman aşımı) burada toplam süreyi aşabilirdi; yeni kod bütçe dolunca durur.
    run {
        var clock = 1000L
        val head = "HTTP/1.1 200 OK\r\nContent-Length: 60000\r\n\r\n".toByteArray(Charsets.ISO_8859_1)
        var i = 0
        val drip = object : java.io.InputStream() {
            override fun read(): Int { clock += 50; return if (i < head.size) head[i++].toInt() and 0xFF else 0x41 }
            // Gerçek soket gibi: her çağrı tek bayt verir (take() döngüsünde check() sık çalışsın, gerçek soTimeout'u taklit).
            override fun read(b: ByteArray, off: Int, len: Int): Int { if (len <= 0) return 0; b[off] = read().toByte(); return 1 }
        }
        var minTimeout = Int.MAX_VALUE
        val deadline = 1000L + 4000L
        val res = runCatching { MiniHttps.readResponse(drip, deadline, { clock }) { ms -> if (ms < minTimeout) minTimeout = ms } }
        T.check("yavaş damlatan hedef toplam bütçeyi asmaz (süre dolunca durur)", res.exceptionOrNull() is java.net.SocketTimeoutException && clock <= deadline + 60)
        T.check("okuma zaman asimi kalan bütçeye göre küçülür (tek seferlik degil)", minTimeout <= 4000 && minTimeout > 0)
    }
    run {
        var clock = 0L
        val msg = "HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhello".toByteArray(Charsets.ISO_8859_1)
        var i = 0
        val stream = object : java.io.InputStream() {
            override fun read(): Int { clock += 1; return if (i < msg.size) msg[i++].toInt() and 0xFF else -1 }
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                if (i >= msg.size) return -1
                val n = minOf(len, msg.size - i); System.arraycopy(msg, i, b, off, n); i += n; clock += 1; return n
            }
        }
        val body = runCatching { MiniHttps.readResponse(stream, 10_000L, { clock }) {} }.getOrNull()
        T.check("zaman asimi yinelemesi normal gövdeyi bozmaz", body?.toString(Charsets.ISO_8859_1) == "hello")
    }
        T.group("ODoH: motorun HTTPS alıcısı")
    HttpSim(cfg).use { h ->
        val open: (InetSocketAddress, Int) -> Socket = { _, to -> Socket().also { it.connect(InetSocketAddress(loop, h.port), to) } }
        val node = OdohNode("t", "T", "g", "dns.test", "/dns-query", listOf("127.0.0.31"))
        val resolved = AtomicInteger()
        val book = OdohAddressBook({ 0L }, resolve = { resolved.incrementAndGet(); listOf("127.0.0.32") })
        val fetch = OdohEngine.httpsFetcher(book, open, { TestTls.client }, TestTls.verifier)
        T.check("alıcı yapılandırmayı getirir ve adresi öğrenir", fetch(node).contentEquals(cfg) && book.lastGood(node) == "127.0.0.31")
        T.check("çözümleme gerekmedi", resolved.get() == 0)
        val open3: (InetSocketAddress, Int) -> Socket = { a, to -> if (a.address.hostAddress == "127.0.0.31") throw java.io.IOException("ölü") else Socket().also { it.connect(InetSocketAddress(loop, h.port), to) } }
        val book2 = OdohAddressBook({ 0L }, resolve = { resolved.incrementAndGet(); listOf("127.0.0.32") })
        val got = OdohEngine.httpsFetcher(book2, open3, { TestTls.client }, TestTls.verifier)(node)
        T.check("ipucu adresi ölüyse şifreli çözümlemeyle yeni adres bulunur", got.contentEquals(cfg) && resolved.get() == 1 && book2.lastGood(node) == "127.0.0.32")
    }
}

private fun bootstrapTests() {
    T.group("ODoH: şifreli ad çözümü (DoT önyükleme)")
    FakeTlsDns(doh = false).use { dns ->
        val open: (InetSocketAddress, Int) -> Socket = { _, to -> Socket().also { it.connect(InetSocketAddress(loop, dns.server.localPort), to) } }
        val bs = OdohBootstrap(listOf("127.0.0.1" to "dns.test"), open, { TestTls.client }, TestTls.verifier)
        T.check("A kaydı bulunur", bs.resolve("relay.example") == listOf("1.2.3.4"))
        T.check("sorgu şifreli kanaldan gitti", dns.queries.get() == 1)
        val wrong = OdohBootstrap(listOf("127.0.0.1" to "wrong.test"), open, { TestTls.client }, TestTls.verifier)
        T.check("sertifika adı uyuşmazsa sonuç alınmaz", wrong.resolve("relay.example").isEmpty())
        val two = OdohBootstrap(listOf("127.0.0.1" to "wrong.test", "127.0.0.1" to "dns.test"), open, { TestTls.client }, TestTls.verifier)
        T.check("ilk sunucu güvenilmezse ikincisi denenir", two.resolve("relay.example") == listOf("1.2.3.4"))
        dns.respond = false
        val slow = OdohBootstrap(listOf("127.0.0.1" to "dns.test"), open, { TestTls.client }, TestTls.verifier, timeoutMs = 400)
        T.check("sunucu cevap vermezse boş döner (takılmaz)", slow.resolve("relay.example").isEmpty())
    }
    T.check("sunucu yoksa boş", OdohBootstrap(emptyList(), { _, _ -> throw java.io.IOException() }, { TestTls.client }).resolve("x.example").isEmpty())
}

/** `/.well-known/odohconfigs` sunan küçük TLS sunucusu ("dns.test" sertifikası). */
internal class HttpSim(private val config: ByteArray) : AutoCloseable {
    private val ctx = TestTls.serverContext(TestTls.good)
    val server = ctx.serverSocketFactory.createServerSocket(0, 20, loop) as SSLServerSocket
    val port get() = server.localPort
    @Volatile var mode = "ok"
    val requests = CopyOnWriteArrayList<String>()
    @Volatile var lastHost = ""

    init {
        Thread {
            while (!server.isClosed) {
                val s = try { server.accept() } catch (_: Exception) { return@Thread }
                Thread { try { serve(s) } catch (_: Exception) {} finally { try { s.close() } catch (_: Exception) {} } }.apply { isDaemon = true; start() }
            }
        }.apply { isDaemon = true; start() }
    }

    private fun serve(s: Socket) {
        (s as javax.net.ssl.SSLSocket).startHandshake()
        val i = BufferedInputStream(s.getInputStream())
        fun line(): String? { val sb = StringBuilder(); while (true) { val c = i.read(); if (c < 0) return null; if (c == '\n'.code) return sb.toString().trimEnd('\r'); sb.append(c.toChar()) } }
        val req = line() ?: return
        while (true) { val l = line() ?: return; if (l.isEmpty()) break; if (l.lowercase().startsWith("host:")) lastHost = l.substringAfter(':').trim() }
        requests.add(req)
        val o = s.getOutputStream()
        val head = "HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\n"
        when (mode) {
            "ok" -> { o.write((head + "Content-Length: ${config.size}\r\n\r\n").toByteArray() + config) }
            "chunked" -> {
                val h = config.size / 2
                o.write((head + "Transfer-Encoding: chunked\r\n\r\n").toByteArray())
                for ((a, b) in listOf(0 to h, h to config.size)) { o.write("${Integer.toHexString(b - a)}\r\n".toByteArray()); o.write(config, a, b - a); o.write("\r\n".toByteArray()) }
                o.write("0\r\n\r\n".toByteArray())
            }
            "close" -> o.write((head + "Connection: close\r\n\r\n").toByteArray() + config)
            "404" -> o.write("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n".toByteArray())
            "301" -> o.write("HTTP/1.1 301 Moved\r\nLocation: https://evil.test/\r\nContent-Length: 0\r\n\r\n".toByteArray())
            "huge" -> { o.write((head + "Content-Length: 5000000\r\n\r\n").toByteArray()); o.write(ByteArray(100_000)) }
            "lie" -> o.write((head + "Content-Length: ${config.size + 50}\r\n\r\n").toByteArray() + config)
        }
        o.flush()
    }

    override fun close() { try { server.close() } catch (_: Exception) {} }
}
