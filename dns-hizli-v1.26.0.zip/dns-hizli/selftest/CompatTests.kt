package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.core.OemCompat.Family as F

/** Üretici uyumluluk katmanı: üretici tanıma ve pil / otomatik başlatma ekranı sırası. */
fun runCompatTests() {
    T.group("Uyumluluk: üretici tanıma ve pil ekranları")

    T.check("Xiaomi, Redmi ve POCO aynı aile", OemCompat.family("Xiaomi", "Redmi") == F.XIAOMI && OemCompat.family("Xiaomi", "POCO") == F.XIAOMI && OemCompat.family("", "poco") == F.XIAOMI)
    T.check("Honor, Huawei'den ayrı tanınır", OemCompat.family("HONOR", "HONOR") == F.HONOR && OemCompat.family("HUAWEI", "HUAWEI") == F.HUAWEI)
    T.check("OnePlus, Oppo'dan önce tanınır; Realme Oppo ailesinde", OemCompat.family("OnePlus", "OnePlus") == F.ONEPLUS && OemCompat.family("realme", "realme") == F.OPPO)
    T.check("Vivo / iQOO, Tecno / Infinix", OemCompat.family("vivo", "iQOO") == F.VIVO && OemCompat.family("TECNO MOBILE LIMITED", "TECNO") == F.TRANSSION && OemCompat.family("INFINIX MOBILITY LIMITED", "Infinix") == F.TRANSSION)
    T.check("Samsung ve Google agresif değil, bilinmeyen üretici OTHER", OemCompat.family("samsung", "samsung") == F.SAMSUNG && !F.SAMSUNG.aggressive && OemCompat.family("Google", "google") == F.GOOGLE && OemCompat.family(null, null) == F.OTHER)
    T.check("agresif aileler işaretli", listOf(F.XIAOMI, F.HUAWEI, F.HONOR, F.OPPO, F.VIVO, F.ONEPLUS, F.TRANSSION).all { it.aggressive })
    for (f in F.values()) {
        val t = OemCompat.batteryTargets(f)
        T.check("${f.name}: liste standart ekranlarla biter, yineleme yok", t.isNotEmpty() && t.last() !is OemCompat.Target.Component &&
            OemCompat.Target.BatteryList in t && OemCompat.Target.AppDetails in t && t.toSet().size == t.size)
        T.check("${f.name}: üretici ekranı adları geçerli Java adları", t.filterIsInstance<OemCompat.Target.Component>().all {
            it.pkg.matches(Regex("[a-z][a-z0-9_]*(\\.[a-z0-9_]+)+")) && it.cls.matches(Regex("[a-z][a-z0-9_]*(\\.[A-Za-z0-9_]+)+")) })
        if (f.aggressive) T.check("${f.name}: agresif üreticide ilk ekran standart pil listesi değil", t.first() != OemCompat.Target.BatteryList)
    }
    T.check("Xiaomi: önce uygulama ayrıntıları (otomatik başlatma ve pil orada)", OemCompat.batteryTargets(F.XIAOMI).first() == OemCompat.Target.AppDetails)
    T.check("Google / bilinmeyen: standart pil listesi önce", OemCompat.batteryTargets(F.OTHER) == listOf(OemCompat.Target.BatteryList, OemCompat.Target.AppDetails))
}
