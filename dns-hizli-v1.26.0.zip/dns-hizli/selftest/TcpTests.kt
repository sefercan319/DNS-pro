package app.dnshizli.selftest

import app.dnshizli.core.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

private const val FIN = TcpDns.FIN
private const val SYN = TcpDns.SYN
private const val RST = TcpDns.RST
private const val PSH = TcpDns.PSH
private const val ACK = TcpDns.ACK

private val FAKE4 = byteArrayOf(10, 111, 222.toByte(), 2)
private val VIRT4 = byteArrayOf(10, 111, 222.toByte(), 3)
private val VIRT6 = SelfTest.FAKE6.copyOf().also { it[15] = 3 }
private fun i4(a: ByteArray) = Packets.ip(a[0].toInt() and 0xFF, a[1].toInt() and 0xFF, a[2].toInt() and 0xFF, a[3].toInt() and 0xFF)

/** Tünelden okunan bir TCP segmenti (bizim yazdığımız). */
private class Seg(val flags: Int, val seq: Int, val ack: Int, val win: Int, val data: ByteArray, val mss: Int, val sumOk: Boolean, val hdrOk: Boolean, val sport: Int)

/** Sahte TCP istemcisi: ham paket kurar, gelen segmentleri doğrular. */
private class Peer(val tcp: TcpDns, val v6: Boolean, val port: Int, val outs: LinkedBlockingQueue<ByteArray>) {
    val addr: ByteArray = if (v6) SelfTest.CLIENT6 else byteArrayOf(10, 111, 222.toByte(), 1)
    var seq = 5000          // bir sonraki göndereceğimiz bayt numarası
    var rcv = 0             // sunucudan beklediğimiz bir sonraki numara
    val stream = java.io.ByteArrayOutputStream()

    fun pkt(flags: Int, seq: Int, ack: Int, data: ByteArray = ByteArray(0), mss: Int = 0, dport: Int = 53): ByteArray {
        val ipLen = if (v6) 40 else 20
        val tcpLen = 20 + (if (mss > 0) 4 else 0)
        val total = ipLen + tcpLen + data.size
        val p = ByteArray(total)
        val dst = if (v6) SelfTest.FAKE6 else FAKE4
        if (v6) {
            p[0] = 0x60; Packets.put16(p, 4, tcpLen + data.size); p[6] = 6; p[7] = 64
            System.arraycopy(addr, 0, p, 8, 16); System.arraycopy(dst, 0, p, 24, 16)
        } else {
            p[0] = 0x45; Packets.put16(p, 2, total); Packets.put16(p, 6, 0x4000); p[8] = 64; p[9] = 6
            System.arraycopy(addr, 0, p, 12, 4); System.arraycopy(dst, 0, p, 16, 4)
            Packets.put16(p, 10, Packets.checksum(p, 0, 20))
        }
        val t = ipLen
        Packets.put16(p, t, port); Packets.put16(p, t + 2, dport)
        Packets.put32(p, t + 4, seq); Packets.put32(p, t + 8, ack)
        p[t + 12] = ((tcpLen / 4) shl 4).toByte(); p[t + 13] = flags.toByte(); Packets.put16(p, t + 14, 65535)
        if (mss > 0) { p[t + 20] = 2; p[t + 21] = 4; Packets.put16(p, t + 22, mss) }
        System.arraycopy(data, 0, p, t + tcpLen, data.size)
        Packets.put16(p, t + 16, TcpDns.tcpChecksum(p, t, tcpLen + data.size, addr, dst))
        return p
    }

    fun send(flags: Int, data: ByteArray = ByteArray(0), seq: Int = this.seq, ack: Int = rcv, mss: Int = 0, dport: Int = 53) {
        val p = pkt(flags, seq, ack, data, mss, dport)
        tcp.onPacket(p, p.size)
    }

    /** Veri gönderir ve numarayı ilerletir. */
    fun sendData(data: ByteArray) { send(ACK or PSH, data); seq += data.size }

    fun next(): Seg? {
        val p = outs.poll(0, TimeUnit.MILLISECONDS) ?: return null
        val six = (p[0].toInt() ushr 4) == 6
        val ipLen = if (six) 40 else 20
        val src = if (six) SelfTest.FAKE6 else FAKE4
        val total = if (six) 40 + Packets.u16(p, 4) else Packets.u16(p, 2)
        val t = ipLen
        val tcpLen = total - t
        val doff = (p[t + 12].toInt() and 0xF0) ushr 2
        var mss = 0
        if (doff >= 24 && p[t + 20].toInt() == 2) mss = Packets.u16(p, t + 22)
        val sumOk = TcpDns.tcpChecksum(p, t, tcpLen, src, addr) == 0
        val hdrOk = six || Packets.checksum(p, 0, 20) == 0
        return Seg(p[t + 13].toInt() and 0xFF, Packets.i32(p, t + 4), Packets.i32(p, t + 8), Packets.u16(p, t + 14),
            p.copyOfRange(t + doff, total), mss, sumOk, hdrOk, Packets.u16(p, t))
    }

    fun all(): List<Seg> { val l = ArrayList<Seg>(); while (true) l.add(next() ?: break); return l }

    /** SYN gönderir, SYN+ACK'i alır, ACK'ler. Alınan SYN+ACK'i döner. */
    fun connect(mss: Int = 1460): Seg? {
        send(SYN, seq = seq, ack = 0, mss = mss)
        seq++
        val sa = next() ?: return null
        rcv = sa.seq + 1
        send(ACK)
        return sa
    }

    /** Gelen veri segmentlerini sırayla toplar ve onaylar. Toplanan bayt sayısını döner. */
    fun collect(): Int {
        var n = 0
        for (s in all()) {
            if (s.data.isNotEmpty() && s.seq == rcv) { stream.write(s.data); rcv += s.data.size; n += s.data.size }
            if (s.flags and FIN != 0 && s.seq == rcv) rcv++
        }
        if (n > 0) send(ACK)
        return n
    }
}

/** Yönlendirici taklidi: sentetik UDP sorgularını kaydeder; cevabı gerçek yazıcılarla (parçalayarak) [TcpDns.offer]'a verir. */
private class Fwd {
    class Q(val v6: Boolean, val port: Int, val dns: ByteArray, val fromOk: Boolean)
    lateinit var tcp: TcpDns
    val got = ArrayList<Q>()

    fun feed(p: ByteArray, n: Int) {
        val six = (p[0].toInt() ushr 4) == 6
        if (six) {
            val fromOk = p.copyOfRange(8, 24).contentEquals(VIRT6) && p.copyOfRange(24, 40).contentEquals(SelfTest.FAKE6) && Packets.udpChecksum6Ok(p, n)
            got.add(Q(true, Packets.u16(p, 40), p.copyOfRange(Packets.HDR6, n), fromOk))
        } else {
            val fromOk = p.copyOfRange(12, 16).contentEquals(VIRT4) && p.copyOfRange(16, 20).contentEquals(FAKE4) &&
                Packets.udpChecksumOk(p, 20, n - 20, i4(VIRT4), i4(FAKE4)) && Packets.checksum(p, 0, 20) == 0
            got.add(Q(false, Packets.u16(p, 20), p.copyOfRange(Packets.HDR, n), fromOk))
        }
    }

    fun reply(q: Q, dns: ByteArray) {
        val scratch = ByteArray(2200)
        if (q.v6) {
            val out = ByteArray(Packets.HDR + dns.size + Packets.ROOM)
            System.arraycopy(dns, 0, out, Packets.HDR, dns.size)
            Packets.writeReply6(out, scratch, 77, SelfTest.FAKE6, VIRT6, 53, q.port, dns.size) { b, o, l -> tcp.offer(b, o, l) }
        } else {
            val out = ByteArray(Packets.HDR + dns.size)
            System.arraycopy(dns, 0, out, Packets.HDR, dns.size)
            Packets.writeReply(out, scratch, Packets.nextIdent(), i4(FAKE4), i4(VIRT4), 53, q.port, dns.size) { b, o, l -> tcp.offer(b, o, l) }
        }
    }
}

/** Sorgudan cevap üretir: büyük bir TXT kaydı ([txt] bayt) ve istenirse sondaki OPT. */
private fun answerFor(q: ByteArray, txt: Int, withOpt: Boolean): ByteArray {
    val qEnd = Dns.questionEnd(q, 0, q.size)
    val rr = ByteArray(12 + txt) { 0x61 }
    rr[0] = 0xC0.toByte(); rr[1] = 12
    Packets.put16(rr, 2, 16); Packets.put16(rr, 4, 1); Packets.put32(rr, 6, 30); Packets.put16(rr, 10, txt)
    val opt = ByteArray(11); Packets.put16(opt, 1, 41); Packets.put16(opt, 3, 1232)
    val o = java.io.ByteArrayOutputStream()
    o.write(q, 0, qEnd); o.write(rr); if (withOpt) o.write(opt)
    val b = o.toByteArray()
    Packets.put16(b, 2, 0x8180); Packets.put16(b, 4, 1); Packets.put16(b, 6, 1); Packets.put16(b, 8, 0); Packets.put16(b, 10, if (withOpt) 1 else 0)
    return b
}

private fun framed(dns: ByteArray): ByteArray = ByteArray(2 + dns.size).also { Packets.put16(it, 0, dns.size); System.arraycopy(dns, 0, it, 2, dns.size) }

private class Rig2(var now: Long = 1_000_000L) {
    val outs = LinkedBlockingQueue<ByteArray>()
    val fwd = Fwd()
    val tcp = TcpDns({ b, o, l -> outs.add(b.copyOfRange(o, o + l)) }, { p, n -> fwd.feed(p, n) }, { now }, java.util.Random(7))
    init { fwd.tcp = tcp }
    fun peer(v6: Boolean = false, port: Int = 40001) = Peer(tcp, v6, port, outs)
}

fun runTcpTests() {
    T.group("TCP katmanı: el sıkışma ve temel akış (IPv4)")
    run {
        val r = Rig2()
        val c = r.peer()
        val sa = c.connect(mss = 1460)
        T.check("SYN'e SYN+ACK döner, ack = bizim ISN+1", sa != null && sa.flags == (SYN or ACK) && sa.ack == 5001)
        T.check("SYN+ACK sağlama toplamları geçerli, MSS 1200 ilan edilir", sa != null && sa.sumOk && sa.hdrOk && sa.mss == 1200 && sa.sport == 53)
        T.check("bağlantı kuruldu", r.tcp.connectionCount == 1)

        val q = Dns.buildQuery(0x1234, "example.com")
        c.sendData(framed(q))
        val ack1 = c.all()
        T.check("veri için ACK döner (ack ilerler), sağlama toplamı geçerli", ack1.size == 1 && ack1[0].flags == ACK && ack1[0].ack == c.seq && ack1[0].sumOk && ack1[0].hdrOk)
        T.check("soru yönlendiriciye sentetik UDP olarak verildi (sanal adres, geçerli sağlama toplamı)", r.fwd.got.size == 1 && r.fwd.got[0].fromOk)
        val got = r.fwd.got[0]
        T.check("soru kimliği korunur", Packets.u16(got.dns, 0) == 0x1234)
        T.check("EDNS yoksa 1232 baytlık OPT eklenir", Packets.u16(got.dns, 10) == 1 && got.dns.size == q.size + 11 && Packets.u16(got.dns, q.size + 3) == 1232)

        r.fwd.reply(got, answerFor(got.dns, 100, true))
        val n = c.collect()
        val bytes = c.stream.toByteArray()
        T.check("cevap TCP olarak uzunluk önekiyle geldi", n > 0 && Packets.u16(bytes, 0) == bytes.size - 2)
        T.check("eklenen OPT cevaptan çıkarıldı (ek kayıt 0)", Packets.u16(bytes, 2 + 10) == 0 && bytes.size - 2 == answerFor(got.dns, 100, false).size)
        T.check("cevap kimliği doğru", Packets.u16(bytes, 2) == 0x1234)

        // İstemci kapanır: FIN → sunucu ACK + FIN
        c.send(FIN or ACK); c.seq++
        val fin = c.all()
        T.check("FIN'e ACK ve kendi FIN'imiz", fin.any { it.flags and FIN != 0 && it.sumOk })
        c.rcv++
        c.send(ACK)
        T.check("FIN onaylanınca bağlantı kapanır", r.tcp.connectionCount == 0)
    }

    T.group("TCP katmanı: sıra, yineleme, parça ve boru hattı")
    run {
        val r = Rig2()
        val c = r.peer()
        c.connect()
        val q1 = framed(Dns.buildQuery(1, "a.example.com"))
        val q2 = framed(Dns.buildQuery(2, "b.example.com"))
        // sıra dışı (boşluk): yinelenen ACK, soru verilmez
        val gap = c.seq + 7
        c.send(ACK or PSH, q1, seq = gap)
        val dupAck = c.all()
        T.check("sıra dışı segment: ack değişmez, soru verilmez", dupAck.size == 1 && dupAck[0].ack == c.seq && r.fwd.got.isEmpty())
        // iki soru tek segmentte (boru hattı)
        c.sendData(q1 + q2)
        c.all()
        T.check("iki soru tek segmentte: ikisi de verilir", r.fwd.got.size == 2 && Packets.u16(r.fwd.got[0].dns, 0) == 1 && Packets.u16(r.fwd.got[1].dns, 0) == 2)
        // yinelenen segment: tekrar soru üretmez
        c.send(ACK or PSH, q1 + q2, seq = c.seq - (q1.size + q2.size))
        c.all()
        T.check("yinelenen segment ikinci kez işlenmez", r.fwd.got.size == 2)
        // soru iki segmente bölünmüş
        val q3 = framed(Dns.buildQuery(3, "c.example.com"))
        c.sendData(q3.copyOfRange(0, 5)); c.all()
        T.check("yarım soru bekler", r.fwd.got.size == 2)
        c.sendData(q3.copyOfRange(5, q3.size)); c.all()
        T.check("kalan parça gelince soru verilir", r.fwd.got.size == 3 && Packets.u16(r.fwd.got[2].dns, 0) == 3)
        // iki cevap ters sırada gelir; her biri kendi sorusuna
        r.fwd.reply(r.fwd.got[1], answerFor(r.fwd.got[1].dns, 20, true))
        r.fwd.reply(r.fwd.got[0], answerFor(r.fwd.got[0].dns, 20, true))
        c.collect()
        val s = c.stream.toByteArray()
        val l1 = Packets.u16(s, 0)
        T.check("cevaplar geliş sırasıyla yazılır, kimlikler eşleşir", Packets.u16(s, 2) == 2 && Packets.u16(s, 2 + l1 + 2) == 1)
    }

    T.group("TCP katmanı: büyük cevap (parçalı IP, çok segment)")
    run {
        for (six in listOf(false, true)) {
            val r = Rig2()
            val c = r.peer(v6 = six)
            c.connect()
            c.sendData(framed(Dns.buildQuery(9, "big.example.com")))
            c.all()
            val q = r.fwd.got[0]
            T.check("${if (six) "IPv6" else "IPv4"}: sentetik soru geçerli", q.fromOk && q.v6 == six)
            val ans = answerFor(q.dns, 3000, true)
            r.fwd.reply(q, ans)                       // 3 KB: IP parçalarına bölünür, TcpDns birleştirir
            val segs = c.all()
            val data = segs.filter { it.data.isNotEmpty() }
            T.check("büyük cevap en çok 1200 baytlık segmentlere bölünür, sağlama toplamları geçerli",
                data.size >= 3 && data.all { it.data.size <= 1200 && it.sumOk && it.hdrOk })
            val total = data.sumOf { it.data.size }
            val expected = answerFor(q.dns, 3000, false)
            T.check("toplam akış = 2 + cevap boyu (OPT çıkarılmış)", total == 2 + expected.size, "$total / ${2 + expected.size}")
            var ok = true
            var next = data[0].seq
            val bs = java.io.ByteArrayOutputStream()
            for (s in data) { if (s.seq != next) ok = false; next += s.data.size; bs.write(s.data) }
            val b = bs.toByteArray()
            T.check("segment numaraları ardışık, içerik birebir aynı", ok && b.copyOfRange(2, b.size).contentEquals(expected))
            // yalnızca ilk segmenti onayla; üç yinelenen ACK ile ikinci segment yeniden gönderilir
            c.rcv = data[0].seq + data[0].data.size
            c.send(ACK); c.send(ACK); c.send(ACK); c.send(ACK)
            val re = c.all().filter { it.data.isNotEmpty() }
            T.check("üç yinelenen ACK sonrası ilk onaylanmamış segment yeniden gönderilir", re.size == 1 && re[0].seq == c.rcv && re[0].data.contentEquals(data[1].data))
        }
    }

    T.group("TCP katmanı: hata ve sınır durumları")
    run {
        val r = Rig2()
        val c = r.peer()
        c.connect()
        // bozuk uzunluk
        c.sendData(byteArrayOf(0, 3, 1, 2, 3))
        val rst = c.all()
        T.check("geçersiz DNS uzunluğu: RST ve bağlantı kapanır", rst.any { it.flags and RST != 0 } && r.tcp.connectionCount == 0)

        // bilinmeyen bağlantıya ACK'li segment: RST (seq = ack)
        val c2 = r.peer(port = 41000)
        c2.send(ACK, seq = 100, ack = 777)
        val s2 = c2.all()
        T.check("bilinmeyen bağlantı: RST, seq = gelen ack", s2.size == 1 && s2[0].flags == RST && s2[0].seq == 777 && s2[0].sumOk)
        // RST'ye RST verilmez
        c2.send(RST, seq = 100, ack = 0)
        T.check("RST'ye cevap verilmez", c2.all().isEmpty())
        // 53 dışı port yok sayılır
        val c3 = r.peer(port = 42000)
        c3.send(SYN, seq = 1, ack = 0, dport = 853)
        val rf = c3.all()
        T.check("53 dışı porta SYN (Özel DNS 853 yoklaması): hemen RST+ACK, bağlantı açılmaz",
            rf.size == 1 && rf[0].flags == (RST or ACK) && rf[0].ack == 2 && rf[0].sport == 853 && rf[0].sumOk && rf[0].hdrOk && r.tcp.connectionCount == 0 && r.tcp.refused == 1L)
        c3.send(ACK, seq = 2, ack = 1, dport = 80)
        c3.send(RST, seq = 2, ack = 0, dport = 853)
        T.check("53 dışı porta SYN olmayan paket yok sayılır (RST'ye RST yok)", c3.all().isEmpty() && r.tcp.connectionCount == 0)
        // yinelenen SYN: aynı SYN+ACK yeniden
        val c4 = r.peer(port = 43000)
        c4.send(SYN, seq = 10, ack = 0, mss = 1460)
        val a = c4.next()
        c4.send(SYN, seq = 10, ack = 0, mss = 1460)
        val b = c4.next()
        T.check("yinelenen SYN: aynı ISN ile SYN+ACK yeniden", a != null && b != null && a.seq == b.seq && b.flags == (SYN or ACK))
        // el sıkışma tamamlanmadan yanlış ack
        c4.send(ACK, seq = 11, ack = 12345)
        T.check("yanlış ack: RST ve bağlantı düşer", c4.all().any { it.flags and RST != 0 })
        // istemci RST
        val c5 = r.peer(port = 44000)
        c5.connect()
        val before = r.tcp.connectionCount
        c5.send(RST, seq = c5.seq, ack = 0)
        T.check("istemci RST bağlantıyı kapatır", r.tcp.connectionCount == before - 1)
    }

    T.group("TCP katmanı: sınırlar ve temizlik")
    run {
        val r = Rig2()
        val c = r.peer()
        c.connect()
        val all = ByteArray(0).let { var x = it; for (i in 1..10) x += framed(Dns.buildQuery(i, "q$i.example.com")); x }
        c.sendData(all)
        c.all()
        T.check("bir bağlantıda en çok ${TcpDns.MAX_PENDING} bekleyen soru", r.fwd.got.size == TcpDns.MAX_PENDING)
        // cevapsız sorular zaman aşımıyla temizlenir; yeni soru kabul edilir
        r.now += TcpDns.PENDING_MS + 1
        val c2 = r.peer(port = 40002)
        c2.connect()
        c.sendData(framed(Dns.buildQuery(50, "late.example.com")))
        c.all()
        T.check("cevapsız sorular süre dolunca bırakılır, yeni soru kabul edilir", r.fwd.got.size == TcpDns.MAX_PENDING + 1)
        // boşta kalan bağlantılar yeni paket gelince temizlenir
        r.now += TcpDns.IDLE_MS + 1
        val c3 = r.peer(port = 40003)
        c3.connect()
        T.check("boşta kalan bağlantılar temizlenir (yalnızca yeni olan kalır)", r.tcp.connectionCount == 1)
        // en çok MAX_CONNS bağlantı
        val r2 = Rig2()
        for (i in 0 until TcpDns.MAX_CONNS + 8) r2.peer(port = 30000 + i).connect()
        T.check("bağlantı sayısı sınırı aşılmaz", r2.tcp.connectionCount == TcpDns.MAX_CONNS)
        // sanal adrese olmayan paketler yakalanmaz
        val udp = ByteArray(40)
        udp[0] = 0x45; udp[9] = 17
        T.check("sanal adrese gitmeyen paket yakalanmaz (tünele yazılır)", !r.tcp.offer(udp, 0, udp.size))
    }

    T.group("TCP katmanı: gerçek yönlendirici ile uçtan uca")
    run {
        // UDP sunucu: her sorguya ~2400 baytlık TXT cevabı verir ve gelen sorguyu kaydeder
        val sock = DatagramSocket(0, InetAddress.getLoopbackAddress())
        val seen = LinkedBlockingQueue<ByteArray>()
        val th = Thread {
            val buf = ByteArray(4096)
            while (!sock.isClosed) {
                val p = DatagramPacket(buf, buf.size)
                try { sock.receive(p) } catch (_: Exception) { return@Thread }
                val q = buf.copyOf(p.length)
                seen.add(q)
                val a = answerFor(q, 2400, true)
                try { sock.send(DatagramPacket(a, a.size, p.socketAddress)) } catch (_: Exception) { return@Thread }
            }
        }.apply { isDaemon = true; start() }
        val outs = LinkedBlockingQueue<ByteArray>()
        lateinit var tcp: TcpDns
        val fw = DnsForwarder(
            upstreams = listOf(java.net.InetSocketAddress(InetAddress.getLoopbackAddress(), sock.localPort)),
            writeToTun = { b, o, l -> if (!tcp.offer(b, o, l)) outs.add(b.copyOfRange(o, o + l)) },
            protect = { true }, cacheEntries = 0, log = {},
        ).also { it.start() }
        tcp = TcpDns({ b, o, l -> outs.add(b.copyOfRange(o, o + l)) }, { p, n -> fw.onPacket(p, n) })
        for (six in listOf(false, true)) {
            val c = Peer(tcp, six, 45000 + (if (six) 1 else 0), outs)
            c.connect()
            c.sendData(framed(Dns.buildQuery(0x4242, "tcp.example.com")))
            var got = 0
            val end = System.nanoTime() + 3_000_000_000L
            while (System.nanoTime() < end && got < 2400) { got += c.collect(); if (got == 0) Thread.sleep(20) }
            val s = c.stream.toByteArray()
            T.check("${if (six) "IPv6" else "IPv4"}: ~2,4 KB cevap gerçek yönlendiriciden TCP ile tam gelir",
                s.size > 2400 && Packets.u16(s, 0) == s.size - 2 && Packets.u16(s, 2) == 0x4242, "${s.size}")
            T.check("${if (six) "IPv6" else "IPv4"}: cevaptaki OPT çıkarılmış (ek kayıt 0)", s.size > 12 && Packets.u16(s, 2 + 10) == 0)
        }
        val q = seen.poll(1, TimeUnit.SECONDS)
        T.check("yukarı akışa giden soruda OPT var (cevap 512'de kesilmesin)", q != null && Packets.u16(q, 10) >= 1)
        fw.close(); sock.close()
    }

    T.group("TCP katmanı: bozuk ve rastgele paketler")
    run {
        val rnd = java.util.Random(12345)
        val r = Rig2()
        var crashed = 0
        val seeds = ArrayList<ByteArray>()
        for (six in listOf(false, true)) {
            val c = r.peer(v6 = six, port = 46000 + (if (six) 1 else 0))
            seeds.add(c.pkt(SYN, 1, 0, mss = 1460))
            seeds.add(c.pkt(ACK, 2, 3))
            seeds.add(c.pkt(ACK or PSH, 2, 3, framed(Dns.buildQuery(5, "fuzz.example.com"))))
            seeds.add(c.pkt(FIN or ACK, 2, 3))
            seeds.add(c.pkt(RST, 2, 3))
        }
        for (i in 0 until 30000) {
            val base = seeds[rnd.nextInt(seeds.size)].copyOf()
            val mode = rnd.nextInt(4)
            val p = when (mode) {
                0 -> ByteArray(rnd.nextInt(120)).also { rnd.nextBytes(it) }
                1 -> base.also { for (k in 0 until 1 + rnd.nextInt(4)) it[rnd.nextInt(it.size)] = rnd.nextInt().toByte() }
                2 -> base.copyOf(rnd.nextInt(base.size + 1))
                else -> base.also { if (it.size > 53) { it[(if ((it[0].toInt() ushr 4) == 6) 52 else 32) + 1] = rnd.nextInt().toByte(); it[rnd.nextInt(it.size)] = 0 } }
            }
            try {
                r.tcp.onPacket(p, p.size)
                if (i % 3 == 0) r.tcp.offer(p, 0, p.size)
            } catch (e: Throwable) { crashed++ }
            if (i % 1000 == 0) r.now += 200
            r.outs.clear()
        }
        T.check("30 bin rastgele/bozuk paket istisna fırlatmaz", crashed == 0, "$crashed")
        T.check("bağlantı sayısı sınırı rastgele paketlerle de aşılmaz", r.tcp.connectionCount <= TcpDns.MAX_CONNS)
        // sanal adrese giden bozuk UDP/parça paketleri
        val junk = ByteArray(60) { 0x45 }
        junk[0] = 0x45; junk[9] = 17; System.arraycopy(VIRT4, 0, junk, 16, 4); Packets.put16(junk, 2, 60); Packets.put16(junk, 6, 0x2000 or 100)
        var ok = true
        try { repeat(100) { r.tcp.offer(junk, 0, junk.size) } } catch (e: Throwable) { ok = false }
        T.check("sırası bozuk IP parçaları birikmez ve hata vermez", ok)
    }
}
