package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File

/**
 * Engelleme motoru ölçümü (test değildir, yalnızca `./run-tests.sh bench` ile çalışır): liste yükleme süresi, listelerin
 * bellekte kapladığı yer ve sorgu başına karar süresi. Sonuçlar makineye bağlıdır; karşılaştırma aynı makinede yapılmalıdır.
 */
fun runFilterBench() {
    val dir = File("app/src/main/assets/filter")
    val names = listOf("basic.bin", "medium.bin", "strict.bin")
    fun load() = names.map { n -> File(dir, n).inputStream().buffered().use { FilterTier.read(it) } }

    // yükleme süresi
    repeat(2) { load() }
    val loads = LongArray(5)
    var tiers: List<FilterTier> = emptyList()
    for (i in loads.indices) { val t0 = System.nanoTime(); tiers = load(); loads[i] = System.nanoTime() - t0 }
    loads.sort()
    val entries = tiers.sumOf { it.size }

    // bellek: yüklenmiş katmanların tutulan yığın alanı (GC sonrası fark)
    fun used(): Long { repeat(4) { System.gc(); Thread.sleep(60) }; val r = Runtime.getRuntime(); return r.totalMemory() - r.freeMemory() }
    tiers = emptyList()
    val before = used()
    val held = load()
    val mem = used() - before

    // karar süresi: gerçekçi karışım (çoğu sorgu engellenmez)
    val engine = FilterEngine(held, FilterTier.EMPTY, emptyList(), emptyList())
    val rnd = kotlin.random.Random(7)
    val popular = listOf("google.com", "youtube.com", "trendyol.com", "hepsiburada.com", "instagram.com", "whatsapp.net", "turkiye.gov.tr",
        "akamaihd.net", "cloudfront.net", "fbcdn.net", "netflix.com", "spotify.com", "microsoft.com", "apple.com", "sahibinden.com")
    val ads = listOf("doubleclick.net", "googlesyndication.com", "adservice.google.com", "app-measurement.com", "scorecardresearch.com", "adnxs.com")
    val qs = ArrayList<ByteArray>()
    for (i in 0 until 50_000) {
        val name = when (rnd.nextInt(10)) {
            in 0..6 -> listOf("www", "cdn${rnd.nextInt(40)}", "api", "static", "img${rnd.nextInt(9)}.media").random(rnd) + "." + popular.random(rnd)
            7, 8 -> "x${rnd.nextInt(1_000_000)}.site${rnd.nextInt(100_000)}.com"
            else -> (if (rnd.nextBoolean()) "" else "s${rnd.nextInt(50)}.") + ads.random(rnd)
        }
        qs.add(Dns.buildQuery(i and 0xFFFF, name))
    }
    var blocked = 0
    fun pass(): Long {
        val t0 = System.nanoTime()
        for (q in qs) if (engine.verdict(q, 0, q.size) != FilterVerdict.PASS) blocked++
        return System.nanoTime() - t0
    }
    repeat(8) { pass() }
    val runs = LongArray(15) { pass() }
    runs.sort()
    blocked /= (8 + 15)
    val nsPerQuery = runs[runs.size / 2].toDouble() / qs.size

    println("\nEngelleme motoru ölçümü")
    println("  alan adı (3 katman): $entries")
    println("  yükleme (en iyi / ortanca): %.1f / %.1f ms".format(loads[0] / 1e6, loads[loads.size / 2] / 1e6))
    val bytes = held.sumOf { it.bytes } + FilterEngine.PRE_BYTES
    println("  bellek (dizi): %.2f MB  (%.2f bayt/ad)".format(bytes / 1048576.0, bytes.toDouble() / entries))
    println("  karar süresi (ortanca): %.0f ns/sorgu, engellenen %d / %d".format(nsPerQuery, blocked, qs.size))
}
