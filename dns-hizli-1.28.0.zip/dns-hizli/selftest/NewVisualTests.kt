package app.dnshizli.selftest

import app.dnshizli.core.*
import java.awt.image.BufferedImage
import kotlin.math.abs
import kotlin.math.sin

/** Küre sıvı hareketleri (10), stil başına dokunma/kutlama varyantları (4 yeni) ve yeni sesler (3). */
fun runNewVisualTests() {
    T.group("Küre sıvı hareketleri")
    run {
        val flows = OrbFlow.values()
        T.check("10 sıvı hareketi var", flows.size == 10)
        T.check("kimlikler benzersiz", flows.map { it.id }.toSet().size == flows.size)
        T.check("kimlik çevrimi çalışır", flows.all { OrbFlow.byId(it.id) == it })
        T.check("geçersiz kimlik null", OrbFlow.byId("yok") == null && OrbFlow.byId(null) == null)
        T.check("CALM özgün sinüsle aynı", (0 until 50).all { i ->
            val u = i / 49f; val c = 3.5f; val p = i * 0.37f
            abs(OrbFlow.CALM.offset(u, c, p) - sin(6.2831855f * c * u + p)) < 1e-5f
        })
        val grid = (0..40).flatMap { i -> (0..12).map { j -> Triple(i / 40f, 0.5f + j * 0.7f, j * 0.45f) } }
        T.check("Duru çemberi eski dalgayla aynı (CALM)", (0..20).all { i ->
            val n = 20; val cyc = 0.55f * n / 6.2831855f; val p = 1.3f
            abs(OrbFlow.CALM.offset(i / n.toFloat(), cyc, p) - sin(p + i * 0.55f)) < 1e-4f
        })
        T.check("hiçbiri taşmaz: değerler [-1,1] içinde", flows.all { f ->
            grid.all { (u, c, p) -> val y = f.offset(u, c, p); y.isFinite() && y >= -1.0001f && y <= 1.0001f }
        })
        T.check("hiçbiri düz değil: her biri zamanla değişir", flows.all { f ->
            (0..20).map { f.offset(0.3f, 2f, it * 0.3f) }.toSet().size > 5
        })
        val sig = flows.associateWith { f -> grid.take(60).map { (u, c, p) -> f.offset(u, c, p) }.toList() }
        T.check("her iki hareket birbirinden farklı", flows.all { a -> flows.all { b -> a == b || sig.getValue(a) != sig.getValue(b) } })
    }

    T.group("Küre sıvısı ayarı: kayıt ve geri okuma")
    run {
        T.check("varsayılan CALM", AppSettings().orbFlow == OrbFlow.CALM)
        for (f in OrbFlow.values()) {
            val back = SettingsCodec.decode(SettingsCodec.encode(AppSettings(orbFlow = f)))
            T.check("sıvı ${f.id} kaydedilip geri okunur", back.orbFlow == f)
        }
        val bad = SettingsCodec.decode(SettingsCodec.encode(AppSettings()) + ("orbFlow" to "bozuk"))
        T.check("bozuk sıvı kimliği varsayılana döner", bad.orbFlow == OrbFlow.CALM)
    }

    T.group("Stil başına dokunma varyantları")
    run {
        T.check("5 seçenek: özgün + 4 yeni", FxVariants.COUNT == 5)
        T.check("boş metin: varsayılan 0", FxVariants.get("", UiStyle.AQUA) == 0 && FxVariants.get(null, UiStyle.DURU) == 0)
        var s = ""
        for (st in UiStyle.values()) for (v in 1..4) {
            s = FxVariants.with(s, st, v)
            T.check("${st.id} için $v okunur", FxVariants.get(s, st) == v)
        }
        T.check("her stil kendi değerini korur", UiStyle.values().all { st -> FxVariants.get(s, st) == 4 })
        val mixed = FxVariants.with(FxVariants.with("", UiStyle.ECO, 2), UiStyle.Y2K, 3)
        T.check("stiller birbirini ezmez", FxVariants.get(mixed, UiStyle.ECO) == 2 && FxVariants.get(mixed, UiStyle.Y2K) == 3 && FxVariants.get(mixed, UiStyle.DURU) == 0)
        T.check("0'a dönmek kaydı siler", FxVariants.with(mixed, UiStyle.ECO, 0).let { FxVariants.get(it, UiStyle.ECO) == 0 && FxVariants.get(it, UiStyle.Y2K) == 3 })
        T.check("geçersiz varyant reddedilir", FxVariants.with("", UiStyle.AQUA, 5) == "" && FxVariants.with("", UiStyle.AQUA, -1) == "")
        val junk = FxVariants.decode("aqua=9;aero=x;;=2;nope=3;metro=1")
        T.check("bozuk girdi atlanır, geçerli kalır", junk == mapOf(UiStyle.METRO to 1))
        val rt = SettingsCodec.decode(SettingsCodec.encode(AppSettings(fxVariants = mixed)))
        T.check("varyantlar ayar kaydında korunur", FxVariants.get(rt.fxVariants, UiStyle.ECO) == 2 && FxVariants.get(rt.fxVariants, UiStyle.Y2K) == 3)
    }

    T.group("Stil efekt varyantları çizilir")
    run {
        val img = BufferedImage(240, 240, BufferedImage.TYPE_INT_ARGB)
        val g2 = img.createGraphics()
        val g = AwtGfx(g2)
        var ok = true
        for (st in UiStyle.values()) {
            val art = ArtFactory.create(st, Themes.resolve("aqua", false), 0.55f)
            for (v in 0 until FxVariants.COUNT) for (t in listOf(0.1f, 0.5f, 0.9f)) {
                try {
                    g.save(); StyleFx.tap(art.motion.fx, g, Themes.resolve("aqua", false), 120f, 120f, t, v); g.restore()
                    g.save(); StyleFx.celebrate(art.motion.fx, g, Themes.resolve("aqua", false), 120f, 120f, 60f, t, v); g.restore()
                } catch (e: Exception) { ok = false; println("  hata: ${st.id} v=$v t=$t ${e}") }
            }
        }
        T.check("her stil × 5 varyant × 3 an çizilebilir", ok)
    }

    T.group("Yeni sesler")
    run {
        val newSfx = listOf(Sfx.SWIPE, Sfx.LONG_PRESS, Sfx.WARNING)
        T.check("3 yeni olay, eskiler 11 kaldı", Sfx.LEGACY_COUNT == 11 && Sfx.values().size == 14 && newSfx.all { it.ordinal >= Sfx.LEGACY_COUNT })
        val maxLen = (Synth.MAX_SEC * Synth.RATE).toInt()
        var allOk = true
        for (e in newSfx) for (v in Voice.values()) {
            val a = Synth.render(e, v)
            val b = Synth.render(e, v)
            val peak = a.maxOf { abs(it.toInt()) }
            if (a.isEmpty() || a.size > maxLen || peak < 1000 || !a.contentEquals(b)) { allOk = false; println("  ses hatası: $e $v n=${a.size} peak=$peak") }
        }
        T.check("yeni sesler her tınıda boş değil, kısa, sessiz değil, deterministik", allOk)
        T.check("yeni sesler birbirinden farklı (tını başına)", Voice.values().all { v ->
            newSfx.map { Synth.render(it, v).toList().hashCode() }.toSet().size == 3
        })
        T.check("eski sesler değişmedi: TAP hâlâ kısa", Voice.values().all { Synth.render(Sfx.TAP, it).size <= Synth.RATE * 0.2f })
    }
}
