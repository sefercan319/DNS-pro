package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*
import java.awt.image.BufferedImage
import kotlin.math.abs
import kotlin.math.sin

/** Küre sıvı hareketleri (10), stil başına dokunma/kutlama varyantları (4 yeni) ve yeni sesler (3). */
fun runNewVisualTests() {
    T.group("Küre sıvı hareketleri")
    run {
        val flows = OrbFlow.values()
        T.check("10 sıvı hareketi var", flows.size == 10)
        T.check("kimlikler benzersiz", flows.map { it.id }.toSet().size == flows.size)
        T.check("kimlik çevrimi çalışır", flows.all { OrbFlow.byId(it.id) == it })
        T.check("geçersiz kimlik null", OrbFlow.byId("yok") == null && OrbFlow.byId(null) == null)
        T.check("CALM özgün sinüsle aynı", (0 until 50).all { i ->
            val u = i / 49f; val c = 3.5f; val p = i * 0.37f
            abs(OrbFlow.CALM.offset(u, c, p) - sin(6.2831855f * c * u + p)) < 1e-5f
        })
        val grid = (0..40).flatMap { i -> (0..12).map { j -> Triple(i / 40f, 0.5f + j * 0.7f, j * 0.45f) } }
        T.check("Duru çemberi eski dalgayla aynı (CALM)", (0..20).all { i ->
            val n = 20; val cyc = 0.55f * n / 6.2831855f; val p = 1.3f
            abs(OrbFlow.CALM.offset(i / n.toFloat(), cyc, p) - sin(p + i * 0.55f)) < 1e-4f
        })
        T.check("CALM hız ve genlik çarpanı 1", OrbFlow.CALM.pace == 1f && OrbFlow.CALM.gain == 1f)
        T.check("hepsinin hız ve genlik çarpanı pozitif ve sınırlı", flows.all { it.pace in 0.3f..3f && it.gain in 0.8f..2f })
        T.check("hiçbir hareket neredeyse sabit değil (aralık ≥ 1,5)", flows.all { f ->
            var mn = 9f; var mx = -9f
            for (i in 0..40) for (k in 0..40) { val y = f.offset(i / 40f, 1.5f, k * 0.157f); mn = minOf(mn, y); mx = maxOf(mx, y) }
            mx - mn >= 1.5f
        })
        T.check("hiçbiri taşmaz: değerler [-1,1] içinde", flows.all { f ->
            grid.all { (u, c, p) -> val y = f.offset(u, c, p); y.isFinite() && y >= -1.0001f && y <= 1.0001f }
        })
        T.check("hiçbiri düz değil: her biri zamanla değişir", flows.all { f ->
            (0..20).map { f.offset(0.3f, 2f, it * 0.3f) }.toSet().size > 5
        })
        val sig = flows.associateWith { f -> grid.take(60).map { (u, c, p) -> f.offset(u, c, p) }.toList() }
        T.check("her iki hareket birbirinden farklı", flows.all { a -> flows.all { b -> a == b || sig.getValue(a) != sig.getValue(b) } })
    }

    T.group("Küre sıvısı ayarı: kayıt ve geri okuma")
    run {
        T.check("varsayılan CALM", AppSettings().orbFlow == OrbFlow.CALM)
        for (f in OrbFlow.values()) {
            val back = SettingsCodec.decode(SettingsCodec.encode(AppSettings(orbFlow = f)))
            T.check("sıvı ${f.id} kaydedilip geri okunur", back.orbFlow == f)
        }
        val bad = SettingsCodec.decode(SettingsCodec.encode(AppSettings()) + ("orbFlow" to "bozuk"))
        T.check("bozuk sıvı kimliği varsayılana döner", bad.orbFlow == OrbFlow.CALM)
    }

    T.group("Stil başına dokunma varyantları")
    run {
        T.check("9 seçenek: özgün + 8 yeni", FxVariants.COUNT == 9 && Strings.FX_VARIANT_NAMES.size == 9)
        T.check("boş metin: varsayılan 0", FxVariants.get("", UiStyle.AQUA) == 0 && FxVariants.get(null, UiStyle.DURU) == 0)
        var s = ""
        for (st in UiStyle.values()) for (v in 1 until FxVariants.COUNT) {
            s = FxVariants.with(s, st, v)
            T.check("${st.id} için $v okunur", FxVariants.get(s, st) == v)
        }
        T.check("her stil kendi değerini korur", UiStyle.values().all { st -> FxVariants.get(s, st) == FxVariants.COUNT - 1 })
        val mixed = FxVariants.with(FxVariants.with("", UiStyle.ECO, 2), UiStyle.Y2K, 3)
        T.check("stiller birbirini ezmez", FxVariants.get(mixed, UiStyle.ECO) == 2 && FxVariants.get(mixed, UiStyle.Y2K) == 3 && FxVariants.get(mixed, UiStyle.DURU) == 0)
        T.check("0'a dönmek kaydı siler", FxVariants.with(mixed, UiStyle.ECO, 0).let { FxVariants.get(it, UiStyle.ECO) == 0 && FxVariants.get(it, UiStyle.Y2K) == 3 })
        T.check("geçersiz varyant reddedilir", FxVariants.with("", UiStyle.AQUA, FxVariants.COUNT) == "" && FxVariants.with("", UiStyle.AQUA, -1) == "")
        val junk = FxVariants.decode("aqua=9;aero=x;;=2;nope=3;metro=1")
        T.check("bozuk girdi atlanır, geçerli kalır", junk == mapOf(UiStyle.METRO to 1))
        val rt = SettingsCodec.decode(SettingsCodec.encode(AppSettings(fxVariants = mixed)))
        T.check("varyantlar ayar kaydında korunur", FxVariants.get(rt.fxVariants, UiStyle.ECO) == 2 && FxVariants.get(rt.fxVariants, UiStyle.Y2K) == 3)
    }

    T.group("Stil efekt varyantları çizilir")
    run {
        val img = BufferedImage(240, 240, BufferedImage.TYPE_INT_ARGB)
        val g2 = img.createGraphics()
        val g = AwtGfx(g2)
        var ok = true
        for (st in UiStyle.values()) {
            val art = ArtFactory.create(st, Themes.resolve("aqua", false), 0.55f)
            for (v in 0 until FxVariants.COUNT) for (t in listOf(0.1f, 0.5f, 0.9f)) {
                try {
                    g.save(); StyleFx.tap(art.motion.fx, g, Themes.resolve("aqua", false), 120f, 120f, t, v); g.restore()
                    g.save(); StyleFx.celebrate(art.motion.fx, g, Themes.resolve("aqua", false), 120f, 120f, 60f, t, v); g.restore()
                } catch (e: Exception) { ok = false; println("  hata: ${st.id} v=$v t=$t ${e}") }
            }
        }
        T.check("her stil × 5 varyant × 3 an çizilebilir", ok)
    }

    T.group("Yeni sesler")
    run {
        val newSfx = listOf(Sfx.SWIPE, Sfx.LONG_PRESS, Sfx.WARNING)
        T.check("3 yeni olay, eskiler 11 kaldı", Sfx.LEGACY_COUNT == 11 && Sfx.values().size == 14 && newSfx.all { it.ordinal >= Sfx.LEGACY_COUNT })
        val maxLen = (Synth.MAX_SEC * Synth.RATE).toInt()
        var allOk = true
        for (e in newSfx) for (v in Voice.values()) {
            val a = Synth.render(e, v)
            val b = Synth.render(e, v)
            val peak = a.maxOf { abs(it.toInt()) }
            if (a.isEmpty() || a.size > maxLen || peak < 1000 || !a.contentEquals(b)) { allOk = false; println("  ses hatası: $e $v n=${a.size} peak=$peak") }
        }
        T.check("yeni sesler her tınıda boş değil, kısa, sessiz değil, deterministik", allOk)
        T.check("yeni sesler birbirinden farklı (tını başına)", Voice.values().all { v ->
            newSfx.map { Synth.render(it, v).toList().hashCode() }.toSet().size == 3
        })
        T.check("eski sesler değişmedi: TAP hâlâ kısa", Voice.values().all { Synth.render(Sfx.TAP, it).size <= Synth.RATE * 0.2f })
    }

    T.group("Özel tema")
    run {
        T.check("özel tema kimliği geçerli", Themes.isValidId(Themes.CUSTOM_ID) && Themes.byId(Themes.CUSTOM_ID) == null)
        T.check("6 vurgu, 8 gökyüzü: 4 açık + 4 koyu", CustomPalette.accents.size == 6 && CustomPalette.skies.size == 8 && CustomPalette.skies.count { it.dark } == 4)
        T.check("kayıt gidip gelir", CustomPalette.decode(CustomPalette.encode(5, 2)) == (5 to 2))
        T.check("geçersiz kayıtlar varsayılana düşer", CustomPalette.normalize("") == "0,0" && CustomPalette.normalize("9,9") == "0,0" && CustomPalette.normalize("x") == "0,0" && CustomPalette.normalize("1,2,3") == "0,0")
        var ok = true; var worst = "" ; var worstV = 99.0
        for (si in CustomPalette.skies.indices) for (ai in CustomPalette.accents.indices) {
            val t = CustomPalette.theme(CustomPalette.encode(si, ai))
            if (t.dark != CustomPalette.skies[si].dark) { ok = false; worst = "koyuluk $si,$ai" }
            for (g in listOf(0f, 0.55f, 1f)) for (y in listOf(0.3f, 0.45f, 0.6f, 0.75f, 0.9f, 1.0f)) for (top in listOf(true, false)) {
                val a = if (top) GlassMath.top(g, t.dark) else GlassMath.bottom(g, t.dark)
                val card = Rgb.over(Rgb.alpha(t.tint, a), t.skyAt(y))
                val c1 = minOf(Rgb.contrast(t.text, card), Rgb.contrast(t.textSoft, card), Rgb.contrast(t.link, card))
                if (c1 < 4.5 && c1 < worstV) { worstV = c1; worst = "$si,$ai kart" }
            }
            val ctl = minOf(Rgb.contrast(t.onControl, t.control), Rgb.contrast(t.onControl, t.controlDeep))
            if (ctl < 4.5 && ctl < worstV) { worstV = ctl; worst = "$si,$ai düğme" }
            if (!(Rgb.luminance(t.accentLight) > Rgb.luminance(t.accent) && Rgb.luminance(t.accent) > Rgb.luminance(t.accentDeep))) { ok = false; worst = "vurgu sırası $ai" }
        }
        T.check("48 özel kombinasyonun hepsi okunur (WCAG 4,5:1) ve koyuluğu doğru", ok && worstV >= 4.5, "$worst en kötü %.2f".format(worstV))
        val r = Themes.resolve("custom", false, "", "", null, "4,1")
        T.check("özel tema ayardan çözülür ve koyu gökyüzüyle koyu olur", r.id == Themes.CUSTOM_ID && r.dark)
        T.check("özel tema önbellekli: aynı kayıt aynı nesne", CustomPalette.theme("1,1") === CustomPalette.theme("1,1"))
        T.check("ayar kaydı özel temayı korur", SettingsCodec.decode(SettingsCodec.encode(AppSettings(customTheme = "6,3"))).customTheme == "6,3")
        T.check("tema adı her dilde tanımlı (yalnız Türkçe'de değil)", Strings.themeName(Themes.CUSTOM_ID) != Strings.THEME_AUTO && Strings.themeName(Themes.CUSTOM_ID).isNotBlank())
    }

    T.group("Ses parçaları ve yeni efekt biçimleri")
    run {
        T.check("60 ses parçası: 6 tını × 10 dizi", SoundParts.COUNT == 60 && SoundParts.VOICES.size * SoundParts.CONTOURS == 60 && SoundParts.CONTOUR_NAMES.size == SoundParts.CONTOURS)
        val maxLen = (Synth.MAX_SEC * Synth.RATE).toInt()
        var ok = true
        for (i in 0 until SoundParts.COUNT) {
            val a = SoundParts.render(i)
            val b = SoundParts.render(i)
            val peak = a.maxOf { abs(it.toInt()) }
            if (a.isEmpty() || a.size > maxLen || peak < 1000 || !a.contentEquals(b)) { ok = false; println("  parça hatası: $i n=${a.size} peak=$peak") }
        }
        T.check("her parça boş değil, kısa, sessiz değil ve aynı girdide aynı", ok)
        T.check("60 parça birbirinden farklı", (0 until SoundParts.COUNT).map { SoundParts.render(it).toList().hashCode() }.toSet().size == SoundParts.COUNT)
        T.check("parça dizini sınır dışıysa reddedilir", runCatching { SoundParts.render(60) }.isFailure && runCatching { SoundParts.render(-1) }.isFailure)
        val tones = (0 until SoundParts.COUNT).map { SoundParts.render(it) }
        T.check("tepe genliği hedefte (≈0,55)", tones.all { a -> val pk = a.maxOf { abs(it.toInt()) } / 32767f; pk in 0.50f..0.58f })
        // yeni efekt biçimleri 5..8 her stilde ve her anda hatasız çizilir
        val img = java.awt.image.BufferedImage(240, 240, java.awt.image.BufferedImage.TYPE_INT_ARGB)
        val gfx = AwtGfx(img.createGraphics())
        var drawn = true
        for (st in UiStyle.values()) {
            val art = ArtFactory.create(st, Themes.resolve("aqua", false), 0.55f)
            for (v in 5 until FxVariants.COUNT) for (t in listOf(0.05f, 0.5f, 0.95f)) {
                try {
                    gfx.save(); StyleFx.tap(art.motion.fx, gfx, Themes.resolve("aqua", false), 120f, 120f, t, v); gfx.restore()
                    gfx.save(); StyleFx.celebrate(art.motion.fx, gfx, Themes.resolve("aqua", false), 120f, 120f, 60f, t, v); gfx.restore()
                } catch (e: Exception) { drawn = false; println("  efekt hatası: ${st.id} v=$v t=$t $e") }
            }
        }
        T.check("yeni efekt biçimleri 5–8 her stilde çizilir", drawn)
    }

    T.group("Ses parçası: ayar ve yönlendirme")
    run {
        T.check("varsayılan: ses paketi (parça yok)", AppSettings().soundPart == -1)
        T.check("parça kaydı gidip gelir", listOf(-1, 0, 59).all { SettingsCodec.decode(SettingsCodec.encode(AppSettings(soundPart = it))).soundPart == it })
        T.check("geçersiz parça dizini varsayılana döner", listOf("99", "-5", "x").all { bad ->
            SettingsCodec.decode(SettingsCodec.encode(AppSettings()) + ("soundPart" to bad)).soundPart == -1 })
        val rig = Rig()
        rig.model.update { it.copy(soundOn = true, soundUi = true, soundConn = true, soundPart = 7, soundVolume = 0.5f) }
        rig.host.sounds.clear(); rig.model.sfx(Sfx.TAP)
        T.check("parça seçiliyken olay parçanın tınısıyla çalar", rig.host.sounds.lastOrNull() == (Sfx.TAP to SoundParts.voice(7)))
        rig.model.update { it.copy(soundPart = -1) }
        rig.host.sounds.clear(); rig.model.sfx(Sfx.TAP)
        T.check("parça kapalıyken ses paketinin tınısı", rig.host.sounds.lastOrNull() == (Sfx.TAP to Synth.voiceFor(rig.model.settings.soundPack, rig.model.settings.style)))
    }

    T.group("Kendi stilim: animasyon parçaları")
    run {
        T.check("72 animasyon parçası: 8 tür × 9 biçim", FxParts.COUNT == 72 && FxParts.KINDS.size == 8 && FxParts.VARIANTS == 9)
        T.check("her parça farklı (tür, biçim) çifti", (0 until FxParts.COUNT).map { FxParts.kind(it) to FxParts.variant(it) }.toSet().size == FxParts.COUNT)
        T.check("her parça için ad var", (0 until FxParts.COUNT).all { Strings.fxPartName(it).isNotBlank() })
        val img = java.awt.image.BufferedImage(240, 240, java.awt.image.BufferedImage.TYPE_INT_ARGB)
        val gfx = AwtGfx(img.createGraphics())
        val th = Themes.resolve("aqua", false)
        var drawn = true
        for (i in 0 until FxParts.COUNT) for (t in listOf(0.1f, 0.6f)) {
            try {
                gfx.save(); StyleFx.tap(FxParts.kind(i), gfx, th, 120f, 120f, t, FxParts.variant(i)); gfx.restore()
                gfx.save(); StyleFx.celebrate(FxParts.kind(i), gfx, th, 120f, 120f, 60f, t, FxParts.variant(i)); gfx.restore()
            } catch (e: Exception) { drawn = false; println("  animasyon parçası hatası: $i $e") }
        }
        T.check("72 parça dokunma ve kutlamada hatasız çizilir", drawn)
        T.check("ayar kaydı gidip gelir", listOf(-1, 0, 71).all { SettingsCodec.decode(SettingsCodec.encode(AppSettings(fxPart = it))).fxPart == it })
        T.check("geçersiz animasyon dizini -1 olur", listOf("72", "-3", "x").all { bad -> SettingsCodec.decode(SettingsCodec.encode(AppSettings()) + ("fxPart" to bad)).fxPart == -1 })
        val rig = Rig()
        rig.model.setFxPart(20)
        T.check("parça seçimi kaydedilir", rig.model.settings.fxPart == 20)
        rig.model.setFxPart(999)
        T.check("geçersiz seçim stilin kendi animasyonuna döner", rig.model.settings.fxPart == -1)
        rig.scene.openCustomStyle(); rig.settle(900)
        T.check("kendi stilim sayfası açılır ve animasyon satırını gösterir", rig.find(Strings.FX_PART, exact = true) != null)
        T.check("kendi stilim sayfası gökyüzü ve ses satırlarını da gösterir", rig.find(Strings.CUSTOM_SKY, exact = true) != null || rig.find(Strings.SOUND_PART, exact = true) != null)
    }
}
