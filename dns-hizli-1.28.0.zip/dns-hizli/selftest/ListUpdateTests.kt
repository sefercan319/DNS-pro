package app.dnshizli.selftest

import app.dnshizli.core.FilterEngine
import app.dnshizli.core.FilterLevel
import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.FilterSource
import app.dnshizli.core.FilterVerdict
import app.dnshizli.core.ListUpdate
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.spec.ECGenParameterSpec

private fun signWith(kp: KeyPair, data: ByteArray): ByteArray =
    Signature.getInstance("SHA256withECDSA").run { initSign(kp.private); update(data); sign() }

private fun manifestText(version: Long, names: List<String>, bytes: ByteArray): ByteArray {
    val sb = StringBuilder("DNSHIZLI-LISTE 1\n").append("surum=$version\n")
    for (n in names) sb.append("$n ${ListUpdate.sha256Hex(bytes)} ${bytes.size}\n")
    return sb.toString().toByteArray(Charsets.UTF_8)
}

/** Liste güncellemesi: imza, manifest biçimi, özet/boy, sürüm geri dönüşü ve bozuk önbellekte paket yedeği. */
fun runListUpdateTests() {
    val good = KeyPairGenerator.getInstance("EC").run { initialize(ECGenParameterSpec("secp256r1")); generateKeyPair() }
    val other = KeyPairGenerator.getInstance("EC").run { initialize(ECGenParameterSpec("secp256r1")); generateKeyPair() }
    val payload = ByteArray(200_000) { (it * 7).toByte() }
    val all = ListUpdate.UPDATABLE
    val manifest = manifestText(5, all, payload)
    val sig = signWith(good, manifest)

    T.group("Liste güncelleme: imza doğrulama")
    run {
        T.check("doğru anahtar ve imza kabul edilir", ListUpdate.verifySignature(manifest, sig, good.public))
        val tampered = manifest.copyOf().also { it[it.size - 3] = (it[it.size - 3] + 1).toByte() }
        T.check("değiştirilmiş manifest reddedilir", !ListUpdate.verifySignature(tampered, sig, good.public))
        T.check("başka anahtarla imza reddedilir", !ListUpdate.verifySignature(manifest, sig, other.public))
        T.check("bozuk imza reddedilir", !ListUpdate.verifySignature(manifest, ByteArray(70) { 1 }, good.public))
        T.check("açık anahtar boşsa (güncelleme kapalı) anahtar üretilmez", ListUpdate.publicKey(ByteArray(0)) == null)
        T.check("bozuk açık anahtar reddedilir", ListUpdate.publicKey(ByteArray(40) { 3 }) == null)
    }

    T.group("Liste güncelleme: manifest biçimi")
    run {
        val m = ListUpdate.parse(manifest)
        T.check("geçerli manifest okunur (3 liste, sürüm 5)", m != null && m.entries.size == 3 && m.version == 5L)
        T.check("biçim satırı yanlışsa reddedilir", ListUpdate.parse("YANLIS\n".toByteArray()) == null)
        T.check("boş manifest reddedilir", ListUpdate.parse(ByteArray(0)) == null)
        T.check("eksik liste reddedilir", ListUpdate.parse(manifestText(5, all.take(2), payload)) == null)
        T.check("bilinmeyen dosya (psl.txt) reddedilir", ListUpdate.parse(manifestText(5, all + "psl.txt", payload)) == null)
        T.check("korunan liste (protected.txt) güncellenebilir listede değil", "protected.txt" !in ListUpdate.UPDATABLE)
        T.check("sürüm 0 reddedilir", ListUpdate.parse(manifestText(0, all, payload)) == null)
        val badHash = "DNSHIZLI-LISTE 1\nsurum=5\n" + all.joinToString("") { "$it ${"z".repeat(64)} 10\n" }
        T.check("geçersiz özet biçimi reddedilir", ListUpdate.parse(badHash.toByteArray()) == null)
        val huge = "DNSHIZLI-LISTE 1\nsurum=5\n" + all.joinToString("") { "$it ${"a".repeat(64)} ${ListUpdate.MAX_FILE + 1}\n" }
        T.check("sınırı aşan boy reddedilir", ListUpdate.parse(huge.toByteArray()) == null)
        val dup = "DNSHIZLI-LISTE 1\nsurum=5\n" + "basic.bin ${"a".repeat(64)} 10\n".repeat(2) + "medium.bin ${"a".repeat(64)} 10\nstrict.bin ${"a".repeat(64)} 10\n"
        T.check("yinelenen liste girdisi reddedilir", ListUpdate.parse(dup.toByteArray()) == null)
        val tiny = "DNSHIZLI-LISTE 1\nsurum=5\n" + all.joinToString("") { "$it ${"a".repeat(64)} 10\n" }
        T.check("boş/küçük liste yayını reddedilir (tüm kullanıcılarda engellemeyi kapatmasın)", ListUpdate.parse(tiny.toByteArray()) == null)
        T.check("çok büyük manifest reddedilir", ListUpdate.parse(ByteArray(ListUpdate.MAX_MANIFEST + 1) { 65 }) == null)
    }

    T.group("Liste güncelleme: dosya özeti ve sürüm geri dönüşü")
    run {
        val e = ListUpdate.parse(manifest)!!.entries[0]
        val e2 = ListUpdate.Entry(e.name, e.sha256, e.bytes)
        T.check("özeti ve boyu tutan dosya kabul edilir", ListUpdate.matches(payload, e2))
        val flipped = payload.copyOf().also { it[500] = (it[500] + 1).toByte() }
        T.check("tek bayt değişen dosya reddedilir", !ListUpdate.matches(flipped, e2))
        T.check("kısa dosya reddedilir", !ListUpdate.matches(payload.copyOf(999), e2))
        val m5 = ListUpdate.parse(manifest)!!
        T.check("kurulu sürümden yeni manifest kabul edilir", ListUpdate.isNewer(4, m5))
        T.check("aynı sürüm yeniden uygulanmaz", !ListUpdate.isNewer(5, m5))
        T.check("eski imzalı sürüme geri dönüş (rollback) reddedilir", !ListUpdate.isNewer(6, m5))
    }

    T.group("Liste güncelleme: bozuk önbellekte paket yedeği (motor)")
    run {
        val assets = File("app/src/main/assets/filter")
        val packaged = FilterSource { name -> File(assets, name).inputStream() }
        // Önbellekteki basic.bin bozuk (rastgele bayt): okuma başarısız olmalı, ama motor tüm engellemeyi kaybetmemeli.
        val corrupt = FilterSource { name ->
            if (name == "basic.bin") ByteArrayInputStream(ByteArray(64) { 9 }) else File(assets, name).inputStream()
        }
        val probes = listOf("doubleclick.net", "googlesyndication.com", "adnxs.com", "criteo.com")
        try {
            FilterRuntime.fallbackSource = packaged
            FilterRuntime.source = packaged
            FilterRuntime.updateNow(FilterLevel.BASIC, emptyList(), emptyList())
            val healthy = probes.map { FilterRuntime.engine!!.verdictOf(it) }

            FilterRuntime.source = corrupt
            FilterRuntime.reloadListsNow()
            val recovered = probes.map { FilterRuntime.engine!!.verdictOf(it) }
            T.check("bozuk önbellek varken paketteki listeyle aynı kararlar verilir", recovered == healthy, "$recovered / $healthy")
            T.check("bozuk önbellek varken en az bir reklam alan adı hâlâ engellenir",
                recovered.any { it == FilterVerdict.LIST })

            FilterRuntime.fallbackSource = null
            FilterRuntime.source = corrupt
            FilterRuntime.reloadListsNow()
            val noFallback = FilterRuntime.engine!!.verdictOf("doubleclick.net")
            T.check("yedek yoksa bozuk liste hiçbir şeyi engellemez (güvenli başarısızlık, çökme yok)", noFallback == FilterVerdict.PASS)
        } finally {
            FilterRuntime.fallbackSource = null
            FilterRuntime.source = packaged
            FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), emptyList())
        }
    }
}
