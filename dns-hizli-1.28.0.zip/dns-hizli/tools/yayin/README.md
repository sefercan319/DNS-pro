# Filtre listeleri: otomatik güncelleme kurulumu

Uygulama, engelleme listelerini bir yayın adresinden imzalı olarak indirir. Kurulum bir kez yapılır.

## 1. Anahtar çifti (bilgisayarsız: GitHub Codespaces ya da herhangi bir Linux ortamında)

    openssl ecparam -name prime256v1 -genkey -noout -out liste-anahtar.pem
    openssl ec -in liste-anahtar.pem -pubout -outform DER | base64 -w0

- Ekrana çıkan base64 metni **açık anahtardır**: `app/.../platform/ListUpdater.kt` içinde `PUBLIC_KEY_B64` alanına yazılır.
- `liste-anahtar.pem` **özel anahtardır**: içeriği GitHub'da *Settings → Secrets and variables → Actions* altında
  `LIST_SIGNING_KEY` adıyla eklenir. Dosyayı depoya koyma, kimseyle paylaşma. Kaybolursa yeni anahtarla yeni uygulama sürümü gerekir.

## 2. Yayın adresi

`ListUpdater.BASE_URL` alanını `https://github.com/<sahip>/<depo>/releases/download/listeler/` olarak ayarla.

## 3. Açık anahtar gömülmeden güncelleme KAPALIDIR

`PUBLIC_KEY_B64` boşken uygulama hiçbir indirme yapmaz. Bu bilinçli bir güvenli varsayılandır.

## 4. Çalışma

`.github/workflows/listeleri-yayinla.yml` her Pazartesi çalışır: listeleri üretir, `tools/yayin/imzala.sh` ile imzalar,
`listeler` yayınına yükler. Elle de çalıştırılabilir (Actions → Run workflow).

Yayın iptal edilen durumlar: liste boyu 100 KB'ın altındaysa, anahtar yoksa.
