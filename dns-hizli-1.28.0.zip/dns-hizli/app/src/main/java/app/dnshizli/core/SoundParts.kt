package app.dnshizli.core

/**
 * 60 ses parçası: 6 tını × 10 nota dizisi. Parça [i] = tını (i / 10) ve dizi (i % 10). Her parça kendi ayrı sesidir;
 * [Synth.renderPart] ile üretilir. Çalma yolu bağlı değil: Android ses çıkışı bu diziyi henüz kullanmıyor.
 */
object SoundParts {
    const val COUNT = 60
    const val CONTOURS = 10

    val VOICES: List<Voice> = listOf(Voice.BUBBLE, Voice.GLASS, Voice.CHIME, Voice.KALIMBA, Voice.DROP, Voice.CHROME)

    /** Her dizi: (C5'ten yarım ton, başlangıç sn, süre sn). */
    val CONTOUR_STEPS: List<List<Triple<Float, Float, Float>>> = listOf(
        listOf(Triple(0f, 0f, 0.06f)),                                                        // 0 tek vuruş
        listOf(Triple(0f, 0f, 0.06f), Triple(4f, 0.06f, 0.06f), Triple(7f, 0.12f, 0.10f)),    // 1 yukarı üçlü
        listOf(Triple(7f, 0f, 0.06f), Triple(4f, 0.06f, 0.06f), Triple(0f, 0.12f, 0.12f)),    // 2 aşağı
        listOf(Triple(0f, 0f, 0.04f), Triple(0f, 0.08f, 0.04f)),                              // 3 çift nokta
        listOf(Triple(0f, 0f, 0.05f), Triple(2f, 0.05f, 0.05f), Triple(4f, 0.10f, 0.05f), Triple(2f, 0.15f, 0.08f)), // 4 kıvrım
        listOf(Triple(0f, 0f, 0.05f), Triple(12f, 0.06f, 0.12f)),                             // 5 oktav atlama
        listOf(Triple(0f, 0f, 0.06f), Triple(7f, 0.07f, 0.14f)),                              // 6 beşli
        listOf(Triple(0f, 0f, 0.10f), Triple(3f, 0.11f, 0.10f), Triple(5f, 0.22f, 0.10f), Triple(7f, 0.33f, 0.16f)), // 7 yavaş yükseliş
        listOf(Triple(0f, 0f, 0.03f), Triple(2f, 0.03f, 0.03f), Triple(4f, 0.06f, 0.03f), Triple(5f, 0.09f, 0.03f), Triple(7f, 0.12f, 0.06f)), // 8 hızlı gama
        listOf(Triple(12f, 0f, 0.08f), Triple(7f, 0.09f, 0.08f), Triple(4f, 0.18f, 0.08f), Triple(0f, 0.27f, 0.18f)), // 9 kapanış
    )

    val CONTOUR_NAMES: List<String> = listOf("Tek vuruş", "Yukarı üçlü", "Aşağı", "Çift nokta", "Kıvrım",
        "Oktav atlama", "Beşli", "Yavaş yükseliş", "Hızlı gama", "Kapanış")

    fun voice(i: Int): Voice = VOICES[(i / CONTOURS).coerceIn(0, VOICES.size - 1)]

    fun render(i: Int): ShortArray {
        require(i in 0 until COUNT) { "ses parçası dizini: $i" }
        return Synth.renderPart(voice(i), CONTOUR_STEPS[i % CONTOURS])
    }
}
