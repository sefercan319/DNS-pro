package app.dnshizli.ui

import app.dnshizli.core.*

/**
 * Kendi stilim: parçaları ayrı ayrı seçersin. Gökyüzü ve vurgu ([CustomPalette]), sıvı hareketi ([OrbFlow]), animasyon
 * parçası ([FxParts], 72) ve ses parçası ([SoundParts], 60). Her parça tek başına, stilden bağımsız uygulanır.
 */
class CustomStylePage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.CUSTOM_STYLE, true, nav) {
    init {
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.CUSTOM_SKY, { Strings.customSkyName(skyOf(it)) }) { openSky() })
            c.add(NavRow(Strings.CUSTOM_ACCENT, { Strings.customAccentName(accentOf(it)) }) { openAccent() })
            c.add(NavRow(Strings.ORB_FLOW, { Strings.orbFlowName(it.orbFlow) }) { openFlow() })
        })
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.FX_PART, { if (it.fxPart < 0) Strings.FX_PART_AUTO else Strings.fxPartName(it.fxPart) }) { openFxPart() })
            c.add(NavRow(Strings.SOUND_PART, { if (it.soundPart < 0) Strings.SOUND_PART_AUTO else Strings.soundPartName(it.soundPart) }) { openSoundPart() })
        })
    }

    private fun skyOf(s: AppSettings) = CustomPalette.decode(s.customTheme)?.first ?: CustomPalette.DEFAULT_SKY
    private fun accentOf(s: AppSettings) = CustomPalette.decode(s.customTheme)?.second ?: CustomPalette.DEFAULT_ACCENT

    private fun openSky() {
        val cur = skyOf(model.settings)
        val acc = accentOf(model.settings)
        val opts = CustomPalette.skies.indices.map { Option(it.toString(), Strings.customSkyName(it), "", it == cur) }
        nav.openOptions(Strings.CUSTOM_SKY, opts) { id -> id?.toIntOrNull()?.let { model.setCustomTheme(it, acc) } }
    }

    private fun openAccent() {
        val sky = skyOf(model.settings)
        val cur = accentOf(model.settings)
        val opts = CustomPalette.accents.indices.map { Option(it.toString(), Strings.customAccentName(it), "", it == cur) }
        nav.openOptions(Strings.CUSTOM_ACCENT, opts) { id -> id?.toIntOrNull()?.let { model.setCustomTheme(sky, it) } }
    }

    private fun openFlow() {
        val cur = model.settings.orbFlow
        val opts = OrbFlow.values().map { Option(it.id, Strings.orbFlowName(it), "", it == cur) }
        nav.openOptions(Strings.ORB_FLOW, opts) { id -> OrbFlow.byId(id)?.let { model.setOrbFlow(it) } }
    }

    private fun openFxPart() {
        val cur = model.settings.fxPart
        val opts = listOf(Option("-1", Strings.FX_PART_AUTO, "", cur < 0)) +
            (0 until FxParts.COUNT).map { Option(it.toString(), Strings.fxPartName(it), "", it == cur) }
        nav.openOptions(Strings.FX_PART, opts) { id -> id?.toIntOrNull()?.let { model.setFxPart(it) } }
    }

    private fun openSoundPart() {
        val cur = model.settings.soundPart
        val opts = listOf(Option("-1", Strings.SOUND_PART_AUTO, "", cur < 0)) +
            (0 until SoundParts.COUNT).map { Option(it.toString(), Strings.soundPartName(it), "", it == cur) }
        nav.openOptions(Strings.SOUND_PART, opts) { id ->
            val i = id?.toIntOrNull() ?: return@openOptions
            model.update { it.copy(soundPart = i) }; model.previewSound()
        }
    }
}
