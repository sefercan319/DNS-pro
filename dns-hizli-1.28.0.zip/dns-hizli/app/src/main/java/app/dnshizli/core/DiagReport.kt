package app.dnshizli.core

/**
 * Tanılama raporu girdisi. Yalnızca sürüm, cihaz modeli, ağ türü, ayar kodları ve sayılar taşır.
 * Alan adı, IP adresi, sunucu adı, geçmiş ya da kişisel veri alanı YOKTUR: rapor bu yüzden içermez.
 */
class DiagInput(
    val appVersion: String,
    val versionCode: Int,
    val androidSdk: Int,
    val deviceModel: String,
    val netKind: String,
    val vpnActive: Boolean,
    val encryption: String,
    val odoh: String,
    val ipMode: String,
    val failClosed: Boolean,
    val strictEncryption: Boolean,
    val filterMem: String,
    val problems: Int,
    val crashCount: Int,
    val lastCrash: String?,
)

/**
 * Destek için paylaşılabilir, sade teknik özet. Otomatik gönderilmez: kullanıcı önce metni görür, sonra kendisi paylaşır.
 * Metin alanları [clean] ile temizlenir; alan adı ya da IP benzeri bir değer gelse bile rapora çıkmaz.
 */
object DiagReport {
    const val MAX = 3000
    private const val MAX_FIELD = 60

    private val DOMAIN = Regex("[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,}")
    private val IPV4 = Regex("\\b\\d{1,3}(\\.\\d{1,3}){3}\\b")
    private val IPV6 = Regex("\\b([0-9A-Fa-f]{1,4}:){2,7}[0-9A-Fa-f]{0,4}\\b")

    /** Kontrol karakterlerini, '@' işaretini ve alan adı/IP benzeri parçaları siler; uzunluğu sınırlar. */
    fun clean(s: String, max: Int = MAX_FIELD): String {
        var t = s.filter { it.code >= 0x20 && it.code != 0x7F && it != '@' }
        t = IPV4.replace(t, "?")
        t = IPV6.replace(t, "?")
        t = DOMAIN.replace(t, "?")
        t = t.trim().replace(Regex("\\s+"), " ")
        return t.take(max)
    }

    private fun yn(b: Boolean) = if (b) "açık" else "kapalı"

    fun build(i: DiagInput): String {
        val lines = listOf(
            "DNS Hızlı tanılama raporu",
            "Sürüm: ${clean(i.appVersion)} (${i.versionCode})",
            "Android: ${i.androidSdk}",
            "Cihaz: ${clean(i.deviceModel)}",
            "Ağ türü: ${clean(i.netKind)}",
            "Tünel: ${yn(i.vpnActive)}",
            "Şifreleme: ${clean(i.encryption)}",
            "ODoH: ${clean(i.odoh)}",
            "IP modu: ${clean(i.ipMode)}",
            "Bağlantı kesilince engelle: ${yn(i.failClosed)}",
            "Sıkı şifreleme: ${yn(i.strictEncryption)}",
            "Filtre belleği: ${clean(i.filterMem)}",
            "Sorun sayısı: ${i.problems.coerceAtLeast(0)}",
            "Kayıtlı çökme: ${i.crashCount.coerceAtLeast(0)}",
            "Son çökme: ${i.lastCrash?.let { clean(it, 200) }?.takeIf { it.isNotBlank() } ?: "yok"}",
        )
        return lines.joinToString("\n").take(MAX)
    }

    /** Test ve güvence için: metinde alan adı, IP ya da '@' var mı. */
    fun containsSensitive(text: String): Boolean =
        DOMAIN.containsMatchIn(text) || IPV4.containsMatchIn(text) || IPV6.containsMatchIn(text) || text.contains('@')
}
