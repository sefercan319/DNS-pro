package app.dnshizli.core

import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PublicKey
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

/**
 * Filtre listesi güncellemesinin saf (ağ ve Android'siz) çekirdeği.
 *
 * Yayın tarafı [MANIFEST] ile birlikte her listenin SHA-256 özetini ve boyunu yayımlar; manifest ECDSA P-256 ile imzalanır.
 * İstemci şunları yapar: imzayı gömülü açık anahtarla doğrular, her dosyanın özetini ve boyunu manifestle karşılaştırır,
 * sürüm numarasının artmasını ister (eski bir imzalı sürüme geri dönüş = rollback reddedilir).
 *
 * Gömülü açık anahtar boşsa güncelleme KAPALIDIR (güvenli varsayılan): imzasız hiçbir liste kabul edilmez.
 */
object ListUpdate {
    /** Manifestin ilk satırı: biçim sürümü. */
    const val FORMAT = "DNSHIZLI-LISTE 1"

    /** Tek bir liste dosyası için en büyük boyut (strict.bin ~2.3 MB; pay bırakılmış). */
    const val MAX_FILE = 8L * 1024 * 1024

    /**
     * Bir liste dosyası için en küçük boyut. Boş ya da kırpılmış bir liste imzalı olsa bile tüm kullanıcılarda engellemeyi
     * kapatırdı; bu sınır böyle bir yayını baştan reddeder. (basic.bin ~1.6 MB, medium.bin ~0.6 MB.)
     */
    const val MIN_FILE = 100_000L

    /** Manifest için en büyük boyut. */
    const val MAX_MANIFEST = 16 * 1024

    /** Güncellenebilen liste dosyaları. psl.txt ve protected.txt bilerek YOKTUR: korunan adlar yalnızca paketten gelir. */
    val UPDATABLE: List<String> = listOf("basic.bin", "medium.bin", "strict.bin")

    class Entry(val name: String, val sha256: String, val bytes: Long)

    class Manifest(val version: Long, val entries: List<Entry>) {
        fun entry(name: String): Entry? = entries.firstOrNull { it.name == name }
    }

    /** Manifesti okur. Biçim bozuk, eksik ya da sınır dışıysa null. */
    fun parse(bytes: ByteArray): Manifest? {
        if (bytes.isEmpty() || bytes.size > MAX_MANIFEST) return null
        val lines = String(bytes, Charsets.UTF_8).split('\n')
        if (lines.firstOrNull()?.trimEnd('\r') != FORMAT) return null
        var version = -1L
        val entries = ArrayList<Entry>()
        for (raw in lines.drop(1)) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("tarih=")) continue
            if (line.startsWith("surum=")) {
                version = line.removePrefix("surum=").toLongOrNull() ?: return null
                continue
            }
            val p = line.split(' ')
            if (p.size != 3) return null
            val size = p[2].toLongOrNull() ?: return null
            if (p[1].length != 64 || !p[1].all { it in '0'..'9' || it in 'a'..'f' }) return null
            if (p[0] !in UPDATABLE || size < MIN_FILE || size > MAX_FILE) return null
            if (entries.any { it.name == p[0] }) return null
            entries.add(Entry(p[0], p[1], size))
        }
        if (version <= 0) return null
        if (entries.map { it.name }.toSet() != UPDATABLE.toSet()) return null
        return Manifest(version, entries)
    }

    /** Manifestin imzası (DER biçimli ECDSA) gömülü anahtarla geçerli mi? */
    fun verifySignature(manifest: ByteArray, signature: ByteArray, key: PublicKey): Boolean = try {
        Signature.getInstance("SHA256withECDSA").run {
            initVerify(key)
            update(manifest)
            verify(signature)
        }
    } catch (_: Exception) {
        false
    }

    /** DER (X.509 SubjectPublicKeyInfo) biçimli açık anahtarı çözer. Bozuksa null. */
    fun publicKey(der: ByteArray): PublicKey? = try {
        KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(der))
    } catch (_: Exception) {
        null
    }

    fun sha256Hex(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    /** İndirilen dosya manifestteki boy ve özetle birebir uyuyor mu? */
    fun matches(file: ByteArray, e: Entry): Boolean = file.size.toLong() == e.bytes && sha256Hex(file) == e.sha256

    /** Yeni manifest, kurulu sürümden yeniyse kabul edilir (eşit ya da eski = geri dönüş saldırısı). */
    fun isNewer(installed: Long, incoming: Manifest): Boolean = incoming.version > installed
}
