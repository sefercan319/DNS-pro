# Güvenlik incelemesi (v1.23.0, kaynak kodu okuma)

Kapsam: manifest ve dışa açık bileşenler, ayar içe aktarma, dosya/fotoğraf okuma, DNS/paket ayrıştırıcılar, ODoH ve şifreli ağ katmanı.
Yöntem: kodu okuma + var olan testler (6154 kontrol, 0 hata). Dinamik test (çalışan uygulamaya saldırı), cihaz ve gerçek ağ YAPILMADI.

## Bulgular
| # | Önem | Konu | Durum |
|---|------|------|-------|
| 1 | Düşük | `OdohNode.path` HTTP isteğine doğrudan yazılıyordu; denetim karakteri/boşluk içeren bir yol istek bölmeye yol açabilirdi. Yollar şu an koda gömülü sabitlerdir, yani sömürülebilir değildi (savunma derinliği). | Düzeltildi + test |
| 2 | Düşük | `MiniHttps`: okuma zaman aşımı bir kez kuruluyordu; damlatan bir hedef toplam süreyi (8 sn) ~2 katına çıkarabiliyordu. | Düzeltildi (v1.24.0): zaman aşımı her okumadan önce kalan bütçeye göre yeniden kurulur; test: "yavaş damlatan hedef toplam bütçeyi aşmaz" |
| 3 | Bilgi | Ayar kodu ile `odoh=strict` içe aktarılırsa bağlantı kurulamayabilir (hizmet aksatma). Ayar gevşemediği için uyarı listesinde değil. | Bilinçli |
| 4 | Bilgi | ODoH yapılandırma alımında hedef, kullanıcının IP'sini görür (soru görmez). Röle/hedef anlaşırsa ODoH'un gizliliği biter. İpucu IP'leri zamanla eskir. | Belgelendi (GIZLILIK.md) |

## Temiz çıkanlar
- Manifest: yedekleme kapalı, düz HTTP yasak, VPN servisi dışa kapalı, widget/bildirim alıcıları dışa kapalı; dışa açık ana etkinlik "kes" isteğini kullanıcıya sorar, "bağlan"da sunucu seçemez; BootReceiver sahte QUICKBOOT yayınına karşı korumalı.
- Ayar içe aktarma: boyut sınırı, bilinmeyen/yerel anahtarlar atılır, gevşeme özeti gösterilir, geri alma var. Özel DNS sunucuları dışa/içe aktarılmaz.
- Dosya okuma: karakter sınırı; fotoğraf: örnekleme ile boyut sınırı.
- DNS ayrıştırıcılar: sıkıştırma işaretçisi sınırlı, uzunluklar denetli, rastgele bozma testleri (yüz binlerce girdi) var; sahte cevap soru/kimlik denetimiyle reddedilir.
- ODoH: sertifika adı doğrulanır; cevap AEAD ile doğrulanır, dolgu sıfır olmalı; yapılandırma doğrudan hedeften alınır (röle anahtarı değiştiremez); 401 yenilemesi hız sınırlı; ölü/sahte röle yolu kesilir; ODoH Sıkı'da başka yönteme düşülmez.

## Kapsam dışı / yapılamayan
Cihazda çalışma zamanı davranışı, gerçek ağ saldırıları, bağımsız şifreleme denetimi (X25519/HPKE kendi gerçeklemedir; RFC vektörleri ve JDK ile doğrulandı ama uzman gözden geçirmesi yok), bağımlılık/derleme zinciri. Yayından önce APK'ya MobSF gibi bir araç ya da ücretli bağımsız pentest önerilir.

## HPKE çapraz doğrulama (ek inceleme)
- Bağımsız referans: pyhpke (RFC 9180). Yön 1 (pyhpke gönderir, Kotlin alır) ve yön 2 (Kotlin gönderir, pyhpke açar), 50 rastgele vektörde tutarlı.
- Testler: `selftest/HpkeInteropTests.kt` (grup "hpke"), vektörler `selftest/HpkeVectors.kt`, araçlar `tools/hpke-referans/`.
- Nonce/anahtar kuralları: her kurulumda yeni efemer anahtar, 3000 ardışık şifrelemede nonce tekrarı yok, sıra dışı mesaj reddedilir.
- Bozuk girdi fuzzing: 4000 bit çevirme/kırpma/uzatma; istisna yok, kabul yok, alıcı durumu korunuyor.
- Kapsam dışı: kütüphane (Tink/Bouncy Castle) üretimde kullanılmadı; Maven erişimi bu ortamda kapalı. Coverage-guided fuzzing (Jazzer) ve zamanlama (yan kanal) ölçümü yapılmadı. Zamanlama testi JVM'de güvenilir değildir; kod dallanmasızdır (TweetNaCl yaklaşımı), ama ölçülmedi.

## Ek inceleme (1.28.x): DPI, reklam engeli, şifreli DNS (kripto), IPv4/IPv6

Yöntem: kaynak kodu okuma, hedefli arama (IPv6 başlıkları, Host ayrıştırma, yanıt eşleştirme, rastgelelik, ayar
kodlama) ve yeni testler. Dinamik test ve gerçek ağ YAPILMADI. Kapsam dışı: tam bir sızma testi.

| # | Önem | Konu | Durum |
|---|------|------|-------|
| 1 | Yüksek (ağ geçidi açıkken) | IPv4 tünelinde IPv6 izni verilince (`allowFamily(AF_INET6)`) uygulamaların IPv6 trafiği tünelin dışından çıkıyordu; reklam, DoH ve DPI denetimi bu trafikte atlanıyordu. | Düzeltildi: ağ geçidi açık ve IPv6 tünelde değilse IPv6 izin verilmez, uygulamalar IPv4'e düşer. DNS modunda davranış değişmedi (bilinçli). Android tarafı derlenmedi (bkz. aşağı). |
| 2 | Orta | IPv6 uzantı başlıkları (hop-by-hop, yönlendirme, hedef seçenekleri) desteklenmediği için bu paketler sessizce düşüyordu; bağlantılar takılabiliyordu. | Düzeltildi: `Gw.ipv6Transport` uzantıları atlar; parçalama (44) ve kimlik doğrulama (51) bilinçli olarak düşürülür; zincir en çok 8. Testler eklendi. |
| 3 | Düşük | HTTP `Host` başlığında IPv6 değişmezi (`[2001:db8::1]:8080`) yanlış ayrıştırılıyordu (`[2001`). Reklam/engel eşleşmesi kaçabiliyordu. | Düzeltildi + test. |
| 4 | Düşük (test kararlılığı) | ODoH "anahtar alınamazsa" testi, arka plan ısıtması ile yarışıyordu; bazı çalıştırmalarda başarısız oluyordu. | Test düzeltildi: ağ en baştan kapalı başlatılıyor. Üretim kodu değişmedi. |

Kontrol edilip sorun bulunmayanlar: DNS yanıtı eşleştirme (kimlik + soru + yanıt bayrağı), CNAME gizli izleyici koruması,
ad normalizasyonu (IDN, sonda nokta, şema, bağlantı noktası), çok noktaya yayın ve genel yayın filtresi, IPv6 UDP sağlama
toplamı, TCP başlangıç sıra numarası (SecureRandom), ODoH kimlikleri (SecureRandom), HPKE/AES-GCM kullanımı (önceki incelemedeki
doğrulamalar geçerli).

Bilinen sınırlar (değiştirilmedi):
- DNS modunda yalnızca sistem çözümleyicisi tünele girer. Bir uygulama 8.8.8.8:53 gibi sabit bir sunucuya doğrudan sorarsa
  o sorgu tünelden geçmez. Bu, DNS modunun tasarımıdır; istenirse sabit DNS trafiğini engelleyen ayrı bir seçenek eklenebilir.
- Ağ geçidi açıkken IPv6 kapalı olduğunda IPv6'ya bağımlı (IPv6-only) bir ağda bağlantı zayıflayabilir; IPv6 normal modda açıktır.
- Android tarafındaki değişiklik (DnsVpnService) bu ortamda derlenmedi. Derleme hatası çıkarsa bu bölüme bakılmalı.
- Gerçek telefonda sızıntı testi (örn. IPv6 sızıntı sayfası) yapılmadı; yapılmasını öneririm.
