package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tan

/**
 * Gradyan dolgusu. Düz renk için [Gfx.paint] doğrudan renk alır; bu sınıf yalnızca gradyanlar içindir.
 * Koordinatlar çizimin o anki yerel koordinatlarındadır. [native] alanını bağdaştırıcılar (Android Shader,
 * AWT Paint) önbellek olarak kullanır; çekirdek kod ona dokunmaz. Aynı nesne tekrar tekrar çizilebilir,
 * bu yüzden kare başına bellek ayırmamak için sık kullanılan dolgular saklanır.
 */
sealed class Fill {
    @JvmField var native: Any? = null

    class Linear(
        @JvmField val x0: Float, @JvmField val y0: Float, @JvmField val x1: Float, @JvmField val y1: Float,
        @JvmField val colors: IntArray, @JvmField val stops: FloatArray,
    ) : Fill()

    class Radial(
        @JvmField val cx: Float, @JvmField val cy: Float, @JvmField val r: Float,
        @JvmField val colors: IntArray, @JvmField val stops: FloatArray,
    ) : Fill()

    companion object {
        fun linear(x0: Float, y0: Float, x1: Float, y1: Float, c0: Int, c1: Int): Fill =
            Linear(x0, y0, x1, y1, intArrayOf(c0, c1), floatArrayOf(0f, 1f))

        /** Üç duraklı gradyan: [c0] başta, [c1] [mid] konumunda, [c2] sonda. */
        fun linear(x0: Float, y0: Float, x1: Float, y1: Float, c0: Int, c1: Int, c2: Int, mid: Float): Fill =
            Linear(x0, y0, x1, y1, intArrayOf(c0, c1, c2), floatArrayOf(0f, mid.coerceIn(0.01f, 0.99f), 1f))

        fun radial(cx: Float, cy: Float, r: Float, c0: Int, c1: Int): Fill =
            Radial(cx, cy, r, intArrayOf(c0, c1), floatArrayOf(0f, 1f))

        fun radial(cx: Float, cy: Float, r: Float, c0: Int, c1: Int, c2: Int, mid: Float): Fill =
            Radial(cx, cy, r, intArrayOf(c0, c1, c2), floatArrayOf(0f, mid.coerceIn(0.01f, 0.99f), 1f))
    }
}

/** Bağdaştırıcıların yol komutlarını gezmesi için. */
interface PathSink {
    fun move(x: Float, y: Float)
    fun line(x: Float, y: Float)
    fun quad(cx: Float, cy: Float, x: Float, y: Float)
    fun cubic(c1x: Float, c1y: Float, c2x: Float, c2y: Float, x: Float, y: Float)
    fun close()
}

/** Yeniden kullanılabilir vektör yolu (Android Path / AWT Path2D'nin ortak alt kümesi). */
class GPath {
    private var cmds = ByteArray(24)
    private var pts = FloatArray(72)
    private var n = 0
    private var np = 0

    /** Her değişiklikte artar; bağdaştırıcılar yerel yolu buna göre yeniden kurar. */
    @JvmField var version = 0
    @JvmField var native: Any? = null
    @JvmField var nativeVersion = -1

    fun reset(): GPath { n = 0; np = 0; version++; return this }

    val isEmpty: Boolean get() = n == 0

    private fun cmd(c: Int) {
        if (n == cmds.size) cmds = cmds.copyOf(n * 2)
        cmds[n++] = c.toByte()
        version++
    }

    private fun pt(x: Float, y: Float) {
        if (np + 2 > pts.size) pts = pts.copyOf(pts.size * 2)
        pts[np++] = x
        pts[np++] = y
    }

    fun moveTo(x: Float, y: Float): GPath { cmd(0); pt(x, y); return this }
    fun lineTo(x: Float, y: Float): GPath { cmd(1); pt(x, y); return this }
    fun quadTo(cx: Float, cy: Float, x: Float, y: Float): GPath { cmd(2); pt(cx, cy); pt(x, y); return this }
    fun cubicTo(c1x: Float, c1y: Float, c2x: Float, c2y: Float, x: Float, y: Float): GPath {
        cmd(3); pt(c1x, c1y); pt(c2x, c2y); pt(x, y); return this
    }
    fun close(): GPath { cmd(4); return this }

    /**
     * Elips yayı ekler (derece cinsinden; 0° = sağ, saat yönünde artar). [connect] doğruysa yayın başına
     * çizgi çeker, değilse yeni bir alt yol başlatır. Yay, en çok 90°'lik kübik Bézier parçalarına bölünür.
     */
    fun arc(cx: Float, cy: Float, rx: Float, ry: Float, startDeg: Float, sweepDeg: Float, connect: Boolean): GPath {
        val a0 = startDeg * (PI / 180.0)
        val sx = (cx + rx * cos(a0)).toFloat()
        val sy = (cy + ry * sin(a0)).toFloat()
        if (connect && n > 0) lineTo(sx, sy) else moveTo(sx, sy)
        val segs = maxOf(1, ceil(abs(sweepDeg) / 90f).toInt())
        val step = sweepDeg / segs
        var a = startDeg
        for (i in 0 until segs) {
            val t0 = a * (PI / 180.0)
            val t1 = (a + step) * (PI / 180.0)
            val k = 4.0 / 3.0 * tan((t1 - t0) / 4.0)
            val c0 = cos(t0); val s0 = sin(t0); val c1 = cos(t1); val s1 = sin(t1)
            cubicTo(
                (cx + rx * (c0 - k * s0)).toFloat(), (cy + ry * (s0 + k * c0)).toFloat(),
                (cx + rx * (c1 + k * s1)).toFloat(), (cy + ry * (s1 - k * c1)).toFloat(),
                (cx + rx * c1).toFloat(), (cy + ry * s1).toFloat(),
            )
            a += step
        }
        return this
    }

    /** Köşeleri yuvarlatılmış dikdörtgen (kapalı). Köşe yarıçapı yarı kenardan büyük olamaz. */
    fun roundRect(l: Float, t: Float, r: Float, b: Float, rad: Float): GPath {
        val k = rad.coerceIn(0f, minOf((r - l) / 2f, (b - t) / 2f))
        moveTo(l + k, t)
        lineTo(r - k, t)
        arc(r - k, t + k, k, k, -90f, 90f, true)
        lineTo(r, b - k)
        arc(r - k, b - k, k, k, 0f, 90f, true)
        lineTo(l + k, b)
        arc(l + k, b - k, k, k, 90f, 90f, true)
        lineTo(l, t + k)
        arc(l + k, t + k, k, k, 180f, 90f, true)
        return close()
    }

    /** Çokgen / kırık çizgi. */
    fun poly(vararg xy: Float, closed: Boolean = false): GPath {
        var i = 0
        while (i + 1 < xy.size) {
            if (i == 0) moveTo(xy[0], xy[1]) else lineTo(xy[i], xy[i + 1])
            i += 2
        }
        return if (closed) close() else this
    }

    fun visit(s: PathSink) {
        var p = 0
        for (i in 0 until n) {
            when (cmds[i].toInt()) {
                0 -> { s.move(pts[p], pts[p + 1]); p += 2 }
                1 -> { s.line(pts[p], pts[p + 1]); p += 2 }
                2 -> { s.quad(pts[p], pts[p + 1], pts[p + 2], pts[p + 3]); p += 4 }
                3 -> { s.cubic(pts[p], pts[p + 1], pts[p + 2], pts[p + 3], pts[p + 4], pts[p + 5]); p += 6 }
                else -> s.close()
            }
        }
    }

    /** Test ve hata ayıklama için: komut sayısı. */
    val size: Int get() = n
}

/**
 * Küçük, bağımsız çizim arayüzü. Arayüz ve sanat kodu yalnızca bunu bilir: Android'de Canvas, JVM
 * testlerinde Graphics2D arkasında çalışır, böylece aynı kod hem cihazda hem önizleme görsellerinde
 * aynı resmi üretir. Birim: dp (çağıran taraf ekran yoğunluğuna göre ölçekler).
 *
 * Durum: dönüşüm, kırpma ve [alpha] save/restore ile korunur. Boya ([paint]) ve çizgi kalınlığı
 * ([strokeWidth]) korunmaz; her çizimden önce çağıran belirler. Çizgiler her zaman yuvarlak uçlu ve köşelidir.
 */
interface TextMetrics {
    fun textWidth(s: String, size: Float, bold: Boolean): Float
}

interface Gfx : TextMetrics {
    fun save()
    fun restore()
    fun translate(dx: Float, dy: Float)
    fun scale(sx: Float, sy: Float)
    fun rotate(deg: Float)

    /** Sonraki çizimlerin saydamlığını [a] (0..1) ile çarpar. save/restore ile geri alınır. */
    fun alpha(a: Float)

    fun clipRect(l: Float, t: Float, r: Float, b: Float)
    fun clipRoundRect(l: Float, t: Float, r: Float, b: Float, rad: Float)
    fun clipCircle(cx: Float, cy: Float, r: Float)

    fun paint(color: Int)
    fun paint(fill: Fill)
    fun strokeWidth(w: Float)

    fun rect(l: Float, t: Float, r: Float, b: Float)
    fun roundRect(l: Float, t: Float, r: Float, b: Float, rad: Float)
    fun circle(cx: Float, cy: Float, r: Float)
    fun oval(l: Float, t: Float, r: Float, b: Float)
    fun path(p: GPath)

    fun strokeRoundRect(l: Float, t: Float, r: Float, b: Float, rad: Float)
    fun strokeCircle(cx: Float, cy: Float, r: Float)
    fun strokePath(p: GPath)
    fun line(x0: Float, y0: Float, x1: Float, y1: Float)

    /**
     * [p] fotoğrafının kaynak dikdörtgenini (piksel: sl, st, sr, sb) hedef dikdörtgene (dp: dl, dt, dr, db) çizer;
     * saydamlık [alpha] ile uygulanır. Görüntü desteklemeyen çizicilerde (ör. yazı ölçen sahte çizici) hiçbir şey yapmaz.
     */
    fun image(p: Pic, sl: Float, st: Float, sr: Float, sb: Float, dl: Float, dt: Float, dr: Float, db: Float) {}

    /** [align]: 0 sola, 1 ortaya, 2 sağa dayalı. [baseline] yazının taban çizgisinin y konumudur. */
    fun text(s: String, x: Float, baseline: Float, size: Float, bold: Boolean, align: Int)
}

const val ALIGN_LEFT = 0
const val ALIGN_CENTER = 1
const val ALIGN_RIGHT = 2

/** Yazı yardımcıları: tek satıra sığdırma ve sözcüklerden satır kaydırma. [Gfx.textWidth]'e dayanır. */
object TextFit {
    private const val DOTS = "…"

    /** [s] [maxW]'ye sığmıyorsa sonuna "…" koyarak kısaltır. */
    fun ellipsize(g: TextMetrics, s: String, maxW: Float, size: Float, bold: Boolean): String {
        if (s.isEmpty() || g.textWidth(s, size, bold) <= maxW) return s
        var lo = 0
        var hi = s.length
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            val cand = s.substring(0, mid).trimEnd() + DOTS
            if (g.textWidth(cand, size, bold) <= maxW) lo = mid else hi = mid - 1
        }
        return if (lo == 0) DOTS else s.substring(0, lo).trimEnd() + DOTS
    }

    /**
     * Sözcük sınırlarında satırlara böler. Tek başına satıra sığmayan uzun bir sözcük (uzun bileşik sözcükler, adresler,
     * büyük yazı boyutu) kaybolmasın diye harf sınırlarından birden çok satıra bölünür. "\n" zorunlu satır sonudur.
     */
    fun wrap(g: TextMetrics, s: String, maxW: Float, size: Float, bold: Boolean): List<String> {
        val out = ArrayList<String>()
        for (para in s.split('\n')) {
            if (para.isBlank()) { out.add(""); continue }
            var line = ""
            for (word in para.split(' ').filter { it.isNotEmpty() }) {
                val cand = if (line.isEmpty()) word else "$line $word"
                if (g.textWidth(cand, size, bold) <= maxW) {
                    line = cand
                    continue
                }
                if (line.isNotEmpty()) out.add(line)
                if (g.textWidth(word, size, bold) <= maxW) { line = word; continue }
                // Sözcük satırdan uzun: sığan en uzun parçaları ayrı satırlara koy, kalan son parça satırı sürdürür.
                var rest = word
                while (g.textWidth(rest, size, bold) > maxW) {
                    var lo = 1
                    var hi = rest.length - 1
                    while (lo < hi) {
                        val mid = (lo + hi + 1) ushr 1
                        if (g.textWidth(rest.substring(0, mid), size, bold) <= maxW) lo = mid else hi = mid - 1
                    }
                    // Bir vekil çiftini (ör. emoji) ortadan bölme.
                    if (lo < rest.length && Character.isLowSurrogate(rest[lo]) && lo > 1) lo--
                    out.add(rest.substring(0, lo))
                    rest = rest.substring(lo)
                }
                line = rest
            }
            if (line.isNotEmpty()) out.add(line)
        }
        return out
    }
}
