package app.dnshizli.ui

import app.dnshizli.core.ALIGN_CENTER
import app.dnshizli.core.ALIGN_LEFT
import app.dnshizli.core.ALIGN_RIGHT
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Easing
import app.dnshizli.core.Gfx
import app.dnshizli.core.GPath
import app.dnshizli.core.Icon
import app.dnshizli.core.Icons
import app.dnshizli.core.OrbMath
import app.dnshizli.core.OrbState
import app.dnshizli.core.Rgb
import app.dnshizli.core.ServerList
import app.dnshizli.core.TextFit
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.sqrt

/** Tek satırlık yazıyı dikey ortalamak için taban çizgisi (büyük harf yüksekliğine göre, yazı tipinden bağımsız). */
internal fun centerBaseline(cy: Float, size: Float): Float = cy + size * 0.355f

/** Yalnızca erişilebilirlik için: hiçbir şey çizmez, verilen alanı okunur bir öğe olarak bildirir. */
class A11yOnly(var label: String, private val role: Role) : Node() {
    override fun draw(g: Gfx, env: Env) {}
    override fun a11y(): A11y? = if (label.isEmpty()) null else A11y(label, role)
}

/** Yatay yığın. Çocuklar kendi genişliğini yerleşimde belirler. */
class Row(var gap: Float = 0f, var padL: Float = 0f, var padR: Float = 0f, var padT: Float = 0f, var padB: Float = 0f) : Node() {
    override fun layout(env: Env, maxW: Float) {
        var cx = padL
        var mh = 0f
        for (k in kids) {
            if (!k.visible) continue
            k.layout(env, maxW)
            k.x = cx
            cx += k.w + gap
            if (k.h > mh) mh = k.h
        }
        w = cx - gap + padR
        h = mh + padT + padB
        for (k in kids) k.y = padT + (mh - k.h) / 2f
    }
}

/** Yuvarlak cam simge düğmesi. [active] ise parlak vurgu rengiyle dolar (ör. "hıza göre sırala" açık). */
class IconButton(
    private val icon: Icon,
    private val label: String,
    private val size: Float = M.MIN_TAP,
    private val onTap: () -> Unit,
) : PressNode() {
    var alpha = 1f
    var spin = 0f
    /** Doluysa erişilebilirlik etiketi buradan okunur (ör. o anki sıralama). */
    var labelFn: (() -> String)? = null
    private val act = Anim(0f)
    var active: Boolean = false
        set(v) { if (v != field) { field = v; actTarget = if (v) 1f else 0f; dirty = true } }
    private var actTarget = 0f
    private var dirty = false
    override val tappable: Boolean get() = alpha > 0.5f
    override val hitSlop: Float get() = if (size < M.MIN_TAP) (M.MIN_TAP - size) / 2f else 0f

    override fun layout(env: Env, maxW: Float) { w = size; h = size; act.set(actTarget) }

    override fun tick(dt: Float, env: Env): Boolean {
        if (dirty) { dirty = false; act.go(actTarget, env.dur(0.22f)) }
        return act.step(dt) or super.tick(dt, env)
    }

    override fun draw(g: Gfx, env: Env) {
        if (alpha <= 0.01f) return
        g.save()
        if (alpha < 1f) g.alpha(alpha)
        pressScale(g, w / 2f, h / 2f, 0.09f)
        env.art.card(g, 0f, 0f, w, h, w / 2f, press = press.value * 0.5f, shadow = 0.7f)
        val a = act.value
        if (a > 0.01f) { g.save(); g.alpha(a); env.art.pill(g, 0f, 0f, w, h, 0f, 0.6f); g.restore() }
        g.save()
        g.translate(w / 2f, h / 2f)
        if (spin != 0f) g.rotate(spin)
        Icons.draw(g, icon, 0f, 0f, w * 0.5f, Rgb.lerp(env.art.ink, Rgb.WHITE, a), 2f)
        g.restore()
        g.restore()
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(); onTap() }
    }

    override fun a11y(): A11y? = if (alpha > 0.5f) A11y(labelFn?.invoke() ?: label, if (actTarget > 0f) Role.SWITCH else Role.BUTTON, checked = if (actTarget > 0f) true else null) else null
}

/** Süzgeç çipi: cam, seçilince parlak vurgu. */
class Chip(text: String, private val onTap: () -> Unit) : PressNode() {
    var text: String = text
    private val sel = Anim(0f)
    var selected: Boolean = false
        private set
    override val hitSlop: Float get() = 4f

    fun setSelected(v: Boolean, env: Env? = null, animate: Boolean = true) {
        if (v == selected && sel.target == (if (v) 1f else 0f)) return
        selected = v
        val d = if (animate && env != null) env.dur(0.22f) else 0f
        sel.go(if (v) 1f else 0f, d)
    }

    override fun layout(env: Env, maxW: Float) {
        w = env.metrics.textWidth(text, env.sz(14f), true) + 26f
        h = M.CHIP_H
    }

    override fun tick(dt: Float, env: Env): Boolean = sel.step(dt) or super.tick(dt, env)

    override fun draw(g: Gfx, env: Env) {
        val art = env.art
        g.save()
        pressScale(g, w / 2f, h / 2f, 0.05f)
        art.card(g, 0f, 0f, w, h, h / 2f, press = press.value * 0.6f, shadow = 0.55f)
        val s = sel.value
        if (s > 0.01f) { g.save(); g.alpha(s); art.pill(g, 0f, 0f, w, h, 0f, 0.8f); g.restore() }
        val fs = env.sz(14f)
        g.paint(Rgb.lerp(env.theme.text, Rgb.WHITE, s))
        g.text(text, w / 2f, centerBaseline(h / 2f, fs), fs, s > 0.5f, ALIGN_CENTER)
        g.restore()
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(); onTap() }
    }

    override fun a11y(): A11y = A11y(text, Role.BUTTON, checked = selected)
}

/** Tam genişlikli eylem düğmesi: birincil (parlak) veya ikincil (cam). */
class ActionButton(
    var text: String,
    private val primary: Boolean = true,
    private val icon: Icon? = null,
    private val onTap: () -> Unit,
) : PressNode() {
    var enabled = true
    override val tappable: Boolean get() = enabled

    override fun layout(env: Env, maxW: Float) { w = maxW; h = 50f }

    override fun draw(g: Gfx, env: Env) {
        val art = env.art
        g.save()
        if (!enabled) g.alpha(0.55f)
        pressScale(g, w / 2f, h / 2f, 0.025f)
        if (primary) art.pill(g, 0f, 0f, w, h, press.value, 1f)
        else art.card(g, 0f, 0f, w, h, h / 2f, press = press.value * 0.6f, shadow = 0.7f)
        val col = if (primary) Rgb.WHITE else env.theme.text
        val iconW = if (icon != null) 26f else 0f
        fitText(env, iconW)
        val fs = shownSize
        val tw = shownW
        val startX = (w - tw - iconW) / 2f
        if (icon != null) Icons.draw(g, icon, startX + 10f, h / 2f, 20f, col, 2.1f)
        g.paint(col)
        g.text(shown, startX + iconW, centerBaseline(h / 2f, fs), fs, true, ALIGN_LEFT)
        g.restore()
    }

    // Dar düğmede uzun yazı önce biraz küçülür (en çok %15), sığmazsa "…" ile kısalır. Sonuç önbellekte tutulur.
    private var shown = ""
    private var shownFor: String? = null
    private var shownSize = 0f
    private var shownW = 0f
    private var shownBoxW = -1f
    private var shownFs = 0f

    private fun fitText(env: Env, iconW: Float) {
        if (shownFor === text && shownBoxW == w && shownFs == env.fs) return
        shownFor = text; shownBoxW = w; shownFs = env.fs
        val fs = env.sz(16f)
        val avail = w - 28f - iconW
        val tw = env.metrics.textWidth(text, fs, true)
        shownSize = if (tw <= avail) fs else maxOf(fs * 0.85f, fs * avail / tw)
        shown = TextFit.ellipsize(env.metrics, text, avail, shownSize, true)
        shownW = env.metrics.textWidth(shown, shownSize, true)
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap && enabled) { env.tap(); onTap() }
    }

    override fun a11y(): A11y = A11y(text, Role.BUTTON)
}

/** Üst çubuk: başlık, soldaki/sağdaki düğmeler ve içerik altından geçerken beliren cam zemin. */
class Header(private val title: String, private val back: Boolean, private val onBack: () -> Unit) : Node() {
    var barAlpha = 0f
    var left = 0f
    var content = 0f

    /** Başlık yazısı; erişilebilirlikte yalnızca kendi alanı "başlık" olarak okunur. */
    private class TitleNode(private val text: String) : Node() {
        val label = Label(text, 20f, bold = true, headline = true, shrink = true)
        override fun layout(env: Env, maxW: Float) { label.layout(env, maxW); w = label.w; h = label.h }
        override fun draw(g: Gfx, env: Env) { label.draw(g, env) }
        override fun a11y(): A11y = A11y(text, Role.HEADING)
    }

    private val titleLabel = TitleNode(title)
    private val backBtn = IconButton(Icon.BACK, Strings.BACK, 44f, onBack)
    val buttons = ArrayList<Node>(2)

    init { add(titleLabel); if (back) add(backBtn) }

    fun addRight(n: Node) { buttons.add(n); add(n) }

    /** Başlığın solunda küçük, isteğe bağlı bir düğüm (ör. mini küre). */
    override fun layout(env: Env, maxW: Float) {
        w = maxW
        h = M.HEADER_H + env.insetTop
        val cw = minOf(maxW, M.MAX_W)
        val l = (maxW - cw) / 2f
        left = l
        content = cw
        val cy = env.insetTop + M.HEADER_H / 2f
        var rx = l + cw - M.PAD
        for (b in buttons) {
            b.layout(env, cw)
            rx -= b.w
            b.x = rx
            b.y = cy - b.h / 2f
            rx -= 10f
        }
        var tx = l + M.PAD
        if (back) { backBtn.layout(env, cw); backBtn.x = l + 12f; backBtn.y = cy - backBtn.h / 2f; tx = backBtn.x + backBtn.w + 8f }
        titleLabel.layout(env, maxOf(40f, rx - tx))
        titleLabel.x = tx
        titleLabel.y = cy - titleLabel.h / 2f
    }

    override fun draw(g: Gfx, env: Env) {
        env.art.bar(g, w, h, barAlpha, env.height)
        drawKids(g, env)
    }
}

/** Ana ekranın kahramanı: cam küre, durum yazıları ve canlı istatistikler. */
class OrbBlock(private val onTap: () -> Unit, private val onLong: (() -> Unit)? = null) : PressNode() {
    private val title = Label("", 28f, bold = true, align = ALIGN_CENTER)
    private val sub = Label("", 15f, ink = Ink.TEXT, align = ALIGN_CENTER)
    private val hint = Label("", 13f, ink = Ink.SOFT, align = ALIGN_CENTER)
    private val swap = Anim(1f)
    private val glowA = Anim(0f)
    private val errA = Anim(0f)
    private val ring = GPath()
    private var level = 0f
    private var phase = 0f
    private var state = OrbState.OFF
    private var seenVersion = -1
    private var seenSec = -1L
    private var a11yText = ""

    val r: Float get() = M.ORB_R
    val cx: Float get() = w / 2f
    val cy: Float get() = 14f + r

    /** Küre ekranın dışına kayınca üst çubukta mini düğme göstermek için küre altının y konumu. */
    val orbBottom: Float get() = y + cy + r

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        title.layout(env, maxW); sub.layout(env, maxW); hint.layout(env, maxW)
        title.x = 0f; title.y = 2f * r + 14f + 22f
        sub.x = 0f; sub.y = title.y + title.h + 2f
        hint.x = 0f; hint.y = sub.y + sub.h + 3f
        h = hint.y + hint.h + 20f
    }

    override fun contains(lx: Float, ly: Float): Boolean {
        val dx = lx - cx
        val dy = ly - cy
        return sqrt(dx * dx + dy * dy) <= r + 10f
    }

    private fun refresh(env: Env, force: Boolean) {
        val m = env.model
        val sec = m.host.now() / 1000
        if (!force && m.version == seenVersion && (m.vpn.state != OrbState.ON || sec == seenSec)) return
        seenVersion = m.version
        seenSec = sec
        val t = m.statusTitle()
        if (t != title.text) {
            title.text = t
            swap.set(0f)
            swap.go(1f, env.dur(0.30f))
        }
        sub.text = m.statusSub()
        hint.text = m.statusHint()
        a11yText = Strings.APP + ". " + t + ". " + sub.text
        if (m.vpn.state != state) {
            state = m.vpn.state
            glowA.go(when (state) { OrbState.ON -> 1f; OrbState.CONNECTING -> 0.6f; else -> 0f }, env.dur(0.6f))
            errA.go(if (state == OrbState.ERROR) 1f else 0f, env.dur(0.5f))
        }
    }

    override fun tick(dt: Float, env: Env): Boolean {
        refresh(env, false)
        var active = press.step(dt)
        if (swap.step(dt)) active = true
        if (glowA.step(dt)) active = true
        if (errA.step(dt)) active = true
        val target = OrbMath.targetLevel(state)
        if (env.motion <= 0f) level = target
        else if (!OrbMath.settled(level, target)) { level = OrbMath.approach(level, target, dt, 3.2f); active = true }
        else level = target
        if (env.ambient && (state == OrbState.ON || state == OrbState.CONNECTING)) {
            phase += dt * (if (state == OrbState.CONNECTING) 3.4f else 1.5f)
        }
        return active
    }

    override fun ambient(env: Env): Boolean = env.ambient && (state == OrbState.ON || state == OrbState.CONNECTING)

    override fun draw(g: Gfx, env: Env) {
        if (seenVersion < 0) refresh(env, true)
        val art = env.art
        g.save()
        pressScale(g, cx, cy, 0.05f)
        val pulse = if (state == OrbState.ON && env.ambient) 0.84f + 0.16f * sin(env.time * 1.8f) else 1f
        art.orb(g, cx, cy, r, level, phase, glowA.value * pulse, errA.value, press.value * 0.6f)
        if (state == OrbState.CONNECTING && env.ambient) {
            val a = env.time * 230f
            ring.reset().arc(cx, cy, r + 9f, r + 9f, a, 95f, false)
            g.strokeWidth(3f)
            g.paint(Rgb.alpha(env.theme.accent, 0.85f))
            g.strokePath(ring)
        }
        g.restore()

        val s = swap.value
        drawLine(g, env, title, s)
        drawLine(g, env, sub, s)
        drawLine(g, env, hint, s)
    }

    private fun drawLine(g: Gfx, env: Env, l: Label, s: Float) {
        l.alpha = Easing.clamp01(s)
        l.dy = (1f - s) * 8f
        g.save(); g.translate(l.x, l.y); l.draw(g, env); g.restore()
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(true); onTap() }
    }

    override val longPressable: Boolean get() = onLong != null

    override fun onLongPress(env: Env): Boolean {
        val l = onLong ?: return false
        env.tap(true)
        l()
        return true
    }

    override fun a11y(): A11y = A11y(a11yText.ifEmpty { Strings.APP }, Role.BUTTON, longClick = onLong != null)
}

/** Sunucu listesinin yıldız düğmesi. */
class StarButton(private val serverId: String, private val name: String) : PressNode() {
    var size = 44f
    var fav = false
    override fun layout(env: Env, maxW: Float) { w = size; h = size }
    override val hitSlop: Float get() = if (size < M.MIN_TAP) (M.MIN_TAP - size) / 2f else 0f

    override fun draw(g: Gfx, env: Env) {
        g.save()
        pressScale(g, w / 2f, h / 2f, 0.12f)
        val col = if (fav) 0xB07400 or (0xFF shl 24) else env.theme.textSoft
        val fill = if (fav) 0xFFC21F or (0xFF shl 24) else 0
        Icons.draw(g, Icon.STAR, w / 2f, h / 2f, 22f, col, 1.8f, fill)
        g.restore()
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(); env.model.toggleFavorite(serverId) }
    }

    override fun a11y(): A11y = A11y(Strings.favA11y(name), Role.SWITCH, checked = fav)
}

/** Listedeki bir DNS sunucusu satırı. Dokun: bağlan. Yıldız: favori. Uzun bas: ayrıntı. */
class ServerRow(val server: DnsServer, private val onLong: (DnsServer) -> Unit) : PressNode() {
    private val star = StarButton(server.id, server.name)
    private val selAnim = Anim(0f)
    private var seenVersion = -1
    private var fs = 0f
    private var laidW = -1f
    private var nameShown = server.name
    private var noteShown = server.note
    private var compact = false
    private var laidLang: Any? = null
    private var latMs: Int? = null
    private var latKnown = false
    private var bars = 0
    private var latText = ""
    private var connected = false
    private val icon = Icons.forTags(server.tags)

    init { add(star) }

    override val longPressable: Boolean get() = true

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        compact = env.model.settings.compact
        h = if (compact) M.ROW_H_COMPACT else M.ROW_H
        star.size = if (compact) 40f else 44f
        star.layout(env, maxW)
        star.x = w - star.w - 2f
        star.y = (h - star.h) / 2f
        laidW = -1f
        refresh(env, true)
    }

    private fun clusterLeft(): Float = w - 26f - 22f - 36f

    private fun relayText(env: Env) {
        val tx = 58f
        val availName = (if (latKnown) clusterLeft() - 10f else w - 50f - 8f) - tx
        val availNote = availName
        nameShown = TextFit.ellipsize(env.metrics, server.name, availName, env.sz(16f), true)
        noteShown = TextFit.ellipsize(env.metrics, server.note, availNote, env.sz(13f), false)
        laidW = w
        fs = env.fs
        laidLang = app.dnshizli.core.L.tx
    }

    private fun refresh(env: Env, force: Boolean) {
        val m = env.model
        if (!force && seenVersion == m.version) return
        seenVersion = m.version
        val id = server.id
        val connId = m.connectedId()
        connected = connId == id
        val selected = connected || (connId == null && m.selectedId() == id)
        selAnim.go(if (selected) 1f else 0f, env.dur(0.25f))
        if (!selAnim.active) selAnim.set(if (selected) 1f else 0f)
        star.fav = id in m.settings.favorites
        val l = m.latencies[id]
        val known = l != null
        latMs = l?.ms
        bars = ServerList.bars(latMs)
        latText = if (!known) "" else (latMs?.let { app.dnshizli.core.Format.ms(it) } ?: "—")
        if (known != latKnown || laidW != w || fs != env.fs || laidLang !== app.dnshizli.core.L.tx) { latKnown = known; relayText(env) }
    }

    override fun tick(dt: Float, env: Env): Boolean {
        refresh(env, false)
        val a = selAnim.step(dt)
        return super.tick(dt, env) or a
    }

    override fun draw(g: Gfx, env: Env) {
        if (fs != env.fs || laidW != w) refresh(env, true)
        val art = env.art
        val th = env.theme
        g.save()
        pressScale(g, w / 2f, h / 2f, 0.018f)
        art.card(g, 0f, 0f, w, h, if (compact) 18f else M.CARD_R, selected = selAnim.value, press = press.value * 0.8f)
        val disc = if (compact) 15f else 18f
        art.iconDisc(g, 30f, h / 2f, disc)
        Icons.draw(g, icon, 30f, h / 2f, if (compact) 17f else 20f, art.ink, 2f)
        if (connected) art.badge(g, 44f, h / 2f + disc - 5f, if (compact) 6f else 7f)
        // Şifreli DNS destekleyen sunucularda simgenin sol üstünde küçük kilit.
        if (server.encrypted) {
            val lx = 16f
            val ly = h / 2f - disc + 4f
            g.paint(Rgb.alpha(Rgb.WHITE, if (th.dark) 0.30f else 0.92f)); g.circle(lx, ly, 7.2f)
            Icons.draw(g, Icon.LOCK, lx, ly, 10f, th.link, 1.6f)
        }
        val n = env.sz(16f)
        val s = env.sz(13f)
        g.paint(th.text)
        if (compact) {
            g.text(nameShown, 58f, centerBaseline(h / 2f, n), n, true, ALIGN_LEFT)
        } else {
            g.text(nameShown, 58f, h / 2f - 4f, n, true, ALIGN_LEFT)
            g.paint(th.textSoft)
            g.text(noteShown, 58f, h / 2f + 15f, s, false, ALIGN_LEFT)
        }
        if (latKnown) {
            val cl = clusterLeft()
            if (compact) {
                g.paint(th.textSoft)
                g.text(latText, cl + 30f, centerBaseline(h / 2f, env.sz(12.5f)), env.sz(12.5f), false, ALIGN_RIGHT)
            } else {
                art.bars(g, cl + 8f, h / 2f + 2f, bars, connected, colored = true)
                g.paint(th.textSoft)
                g.text(latText, cl + 17f, h / 2f + 19f, env.sz(11.5f), false, ALIGN_CENTER)
            }
        }
        g.restore()
        // yıldız çocuk olarak ayrıca çizilir (basınca satırla birlikte küçülmesin)
        drawKids(g, env)
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(); env.model.tapServer(server.id) }
    }

    override fun onLongPress(env: Env): Boolean { env.tap(true); onLong(server); return true }

    override fun a11y(): A11y {
        val m = latText.takeIf { it.isNotEmpty() }
        val parts = listOfNotNull(server.name, server.note, m, if (server.encrypted) Strings.A11Y_ENCRYPTED else null, if (connected) Strings.A11Y_CONNECTED else null)
        return A11y(parts.joinToString(", "), Role.BUTTON, longClick = true)
    }
}

/** Geçici kısa mesaj: altta cam hap, isteğe bağlı eylemle. */
class ToastNode : Node() {
    private val a = Anim(0f)
    private var msg: ToastMsg? = null
    private var life = 0f
    private var shownText = ""
    private var textW = 0f
    private var actionW = 0f
    private var pressed = false
    var screenW = 0f
    var screenH = 0f

    val active: Boolean get() = msg != null
    override val tappable: Boolean get() = msg?.action != null && a.value > 0.6f

    fun show(env: Env, m: ToastMsg) {
        msg = m
        life = if (m.action != null) 5.5f else 2.8f
        a.set(0f)
        a.go(1f, env.dur(0.28f))
        relayout(env)
    }

    fun dismiss(env: Env) { if (msg != null) { life = 0f } }

    fun relayout(env: Env) {
        val m = msg ?: return
        val fs = env.sz(14f)
        val maxW = minOf(screenW, M.MAX_W) - 40f
        val act = m.action
        actionW = if (act != null) env.metrics.textWidth(act, fs, true) + 12f else 0f
        val availText = maxW - 36f - actionW
        shownText = TextFit.ellipsize(env.metrics, m.text, availText, fs, false)
        textW = env.metrics.textWidth(shownText, fs, false)
        w = textW + actionW + 36f
        h = 44f
        x = (screenW - w) / 2f
        y = screenH - env.insetBottom - 28f - h
    }

    override fun tick(dt: Float, env: Env): Boolean {
        val m = msg ?: return false
        val moving = a.step(dt)
        life -= dt
        if (life <= 0f && a.target != 0f) a.go(0f, env.dur(0.25f))
        if (life <= 0f && !a.active) { msg = null; return false }
        return moving   // bekleme süresince tam hız gerekmez: sahne geri sayımı 33 ms'lik karelerle sürdürür
    }

    override fun contains(lx: Float, ly: Float): Boolean = lx >= w - actionW - 20f && lx <= w + 8f && ly >= -6f && ly <= h + 6f

    override fun onDown(lx: Float, ly: Float, env: Env) { pressed = true }
    override fun onCancel(env: Env) { pressed = false }
    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        pressed = false
        val m = msg ?: return
        if (tap && m.action != null) { env.tap(); m.onAction?.invoke(); life = 0f }
    }

    override fun draw(g: Gfx, env: Env) {
        val m = msg ?: return
        val v = a.value
        if (v <= 0.01f) return
        g.save()
        g.alpha(Easing.clamp01(v))
        g.translate(0f, (1f - v) * 16f)
        env.art.card(g, 0f, 0f, w, h, h / 2f, strong = 0.9f, shadow = 1f, press = if (pressed) 0.4f else 0f)
        val fs = env.sz(14f)
        g.paint(env.theme.text)
        g.text(shownText, 18f, centerBaseline(h / 2f, fs), fs, false, ALIGN_LEFT)
        val act = m.action
        if (act != null) {
            g.paint(env.theme.link)
            g.text(act, 18f + textW + 12f, centerBaseline(h / 2f, fs), fs, true, ALIGN_LEFT)
        }
        g.restore()
    }

    override fun a11y(): A11y? = msg?.let { A11y(it.text + (it.action?.let { a -> ", $a" } ?: ""), if (it.action != null) Role.BUTTON else Role.TEXT) }
}

/**
 * Ana ekrandaki büyük modül kartı (DPI atlatma / Reklam+). Dokununca açılır ya da kapanır; DNS düğmesinden bağımsızdır.
 * Durum modelden okunur ([on]); istek sürerken model isteğe göre gösterir.
 */
class ModuleCard(
    private val icon: Icon,
    private val title: () -> String,
    private val sub: () -> String,
    private val on: () -> Boolean,
    private val onTap: () -> Unit,
) : PressNode() {
    private val sel = Anim(0f)
    private var titleLines: List<String> = emptyList()
    private var subLines: List<String> = emptyList()
    private var stateShown = ""
    private var laidW = -1f
    private var laidFs = 0f
    private var laidLang: Any? = null
    private var laidOn = false
    private var laidSub = ""
    override val hitSlop: Float get() = 2f

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        relay(env)
        sel.set(if (on()) 1f else 0f)
    }

    /** En çok [max] satıra sarar; sığmayan son satır "…" ile kısalır. */
    private fun wrapN(env: Env, text: String, avail: Float, size: Float, bold: Boolean, max: Int): List<String> {
        val l = TextFit.wrap(env.metrics, text, avail, size, bold)
        if (l.size <= max) return l
        return l.take(max - 1) + TextFit.ellipsize(env.metrics, l[max - 1] + " …", avail, size, bold)
    }

    private fun relay(env: Env) {
        val t = env.sz(16f)
        val s = env.sz(12.5f)
        val avail = w - 28f
        titleLines = wrapN(env, title(), avail, t, true, 2)
        laidSub = sub()
        subLines = wrapN(env, laidSub, avail, s, false, 3)
        laidOn = on()
        stateShown = if (laidOn) Strings.MOD_ON else Strings.MOD_OFF
        h = 12f + 32f + 8f + titleLines.size * t * 1.2f + 3f + maxOf(subLines.size, 2) * s * 1.3f + 12f
        laidW = w; laidFs = env.fs; laidLang = app.dnshizli.core.L.tx
    }

    override fun tick(dt: Float, env: Env): Boolean {
        val now = on()
        if (now != laidOn) { relay(env); sel.go(if (now) 1f else 0f, env.dur(0.25f)) }
        else if (sub() != laidSub) relay(env)
        return sel.step(dt) or super.tick(dt, env)
    }

    override fun draw(g: Gfx, env: Env) {
        if (laidW != w || laidFs != env.fs || laidLang !== app.dnshizli.core.L.tx) relay(env)
        val art = env.art
        val th = env.theme
        g.save()
        pressScale(g, w / 2f, h / 2f, 0.03f)
        art.card(g, 0f, 0f, w, h, M.CARD_R, selected = sel.value, press = press.value * 0.8f)
        art.iconDisc(g, 14f + 16f, 12f + 16f, 16f)
        Icons.draw(g, icon, 14f + 16f, 12f + 16f, 19f, art.ink, 2f)
        val st = env.sz(12.5f)
        g.paint(env.color(if (laidOn) Ink.GOOD else Ink.SOFT))
        g.text(stateShown, w - 14f, centerBaseline(12f + 16f, st), st, laidOn, ALIGN_RIGHT)
        val t = env.sz(16f)
        val s = env.sz(12.5f)
        val tb = 12f + 32f + 8f + t * 0.95f
        g.paint(th.text)
        for (i in titleLines.indices) g.text(titleLines[i], 14f, tb + i * t * 1.2f, t, true, ALIGN_LEFT)
        val last = tb + (titleLines.size - 1) * t * 1.2f
        g.paint(th.textSoft)
        for (i in subLines.indices) g.text(subLines[i], 14f, last + 3f + (i + 1) * s * 1.3f - s * 0.2f, s, false, ALIGN_LEFT)
        g.restore()
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(true); onTap() }
    }

    override fun a11y(): A11y = A11y(title() + ", " + sub(), Role.SWITCH, checked = on())
}

/** Ana ekranda küreden hemen sonra: iki büyük modül kartı yan yana (DPI atlatma, Reklam+). */
class ModuleCards(private val model: AppModel) : Node() {
    private val dpi = ModuleCard(Icon.BOLT, { Strings.MOD_DPI }, { if (model.vpn.gwDpi && model.vpn.gwSplit > 0) Strings.modDpiCount(app.dnshizli.core.Format.count(model.vpn.gwSplit)) else Strings.MOD_DPI_SUB }, { model.dpiOn }) { model.toggleDpi() }
    private val ads = ModuleCard(Icon.BLOCK, { Strings.MOD_ADS }, { if (model.vpn.gwAds && model.vpn.gwBlocked > 0) Strings.modAdsCount(app.dnshizli.core.Format.count(model.vpn.gwBlocked)) else Strings.MOD_ADS_SUB }, { model.adsPlusOn }) { model.toggleAdsPlus() }

    init { add(dpi); add(ads) }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        val cw = (maxW - GAP) / 2f
        dpi.layout(env, cw)
        ads.layout(env, cw)
        val hh = maxOf(dpi.h, ads.h)
        dpi.h = hh; ads.h = hh
        dpi.x = 0f; ads.x = cw + GAP
        dpi.y = PAD_T; ads.y = PAD_T
        h = PAD_T + hh + PAD_B
    }

    override fun tick(dt: Float, env: Env): Boolean = tickKids(dt, env)

    private companion object {
        const val GAP = 10f
        const val PAD_T = 4f
        const val PAD_B = 8f
    }
}
