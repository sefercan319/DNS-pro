#!/usr/bin/env python3
"""Public Suffix List'i (publicsuffix.org, MPL 2.0) uygulamanın okuduğu küçük metin dosyasına çevirir.

Kullanım: python3 tools/build_psl.py public_suffix_list.dat app/src/main/assets/filter/psl.txt

Çıktı: satır başına bir kural, küçük harf, IDN etiketleri punycode ("xn--"). "!" istisna, "*." joker. ICANN bölümü ile ÖZEL (private)
bölüm "#PRIVATE" satırıyla ayrılır. Yorumlar atılır. Kaynak dosyanın adresi ve lisansı OKUBENI.md / Hakkında ekranında yazılıdır.
"""
import sys

def punycode(rule: str) -> str:
    out = []
    for label in rule.split('.'):
        if label in ('*', ''):
            out.append(label)
            continue
        try:
            label.encode('ascii')
            out.append(label.lower())
        except UnicodeEncodeError:
            out.append(label.encode('idna').decode('ascii').lower())
    return '.'.join(out)

def main(src, dst):
    icann, private, section = [], [], 'icann'
    for raw in open(src, encoding='utf-8'):
        line = raw.strip()
        if line.startswith('// ===BEGIN PRIVATE DOMAINS==='):
            section = 'private'
        if not line or line.startswith('//'):
            continue
        rule = line.split()[0]
        neg = rule.startswith('!')
        body = punycode(rule[1:] if neg else rule)
        (icann if section == 'icann' else private).append(('!' if neg else '') + body)
    with open(dst, 'w', encoding='ascii', newline='\n') as f:
        f.write('\n'.join(sorted(set(icann))) + '\n#PRIVATE\n' + '\n'.join(sorted(set(private))) + '\n')
    print(f'icann={len(set(icann))} private={len(set(private))}')

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
