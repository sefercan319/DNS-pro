#!/usr/bin/env python3
"""
ODoH (RFC 9230) röle ve hedeflerini canlı doğrular (yalnızca Python standart kütüphanesi).

  python3 tools/odoh_check.py

OdohCatalog.kt'deki her HEDEF için `https://<hedef>/.well-known/odohconfigs` alınır (ipucu adresine bağlanılır, sertifika hedef
adına göre doğrulanır) ve yapılandırma uygulamanın ayrıştırıcısıyla aynı kurallarla denetlenir: sürüm 0x0001, KEM X25519
(0x0020), KDF HKDF-SHA256 (0x0001), AEAD AES-128-GCM (0x0001), 32 baytlık açık anahtar. Her RÖLE için `?targethost=…&targetpath=…`
adresine geçersiz (rastgele) bir ODoH gövdesi POST edilir: sağlıklı bir röle bunu hedefe iletir ve hedef 400/401 gibi bir
4xx döner (404 = röle yolu yanlış, bağlantı hatası = röle yok). Çıkış kodu: herhangi bir hedef ya da röle başarısızsa 1.

Tam uçtan uca sorgu (şifreleme dahil) bu araçta yoktur; o, uygulamanın kendi testlerinde (selftest/OdohTests.kt, RFC 9180 / 7748
vektörleri ve bağımsız bir sunucu benzetimi) sınanır. Gerçek ağda ilk deneme için uygulamada ODoH'u "Yedekli" açıp bağlanın.

Katalog değişince ya da yayından önce çalıştırın: ipucu adresleri zamanla bayatlar (uygulama bayat adreste şifreli ad çözümüne
düşer ama ilk bağlanma gecikir).
"""
import os
import re
import socket
import ssl
import sys
import urllib.parse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATALOG = os.path.join(ROOT, "app", "src", "main", "java", "app", "dnshizli", "core", "OdohCatalog.kt")
NODE = re.compile(r'OdohNode\("([^"]+)",\s*"([^"]+)",\s*"([^"]+)",\s*"([^"]+)",\s*"([^"]+)",\s*listOf\(([^)]*)\)\)')
MEDIA = "application/oblivious-dns-message"


def load():
    relays, targets, cur = [], [], None
    for line in open(CATALOG, encoding="utf-8"):
        if "val relays" in line:
            cur = relays
        elif "val targets" in line:
            cur = targets
        m = NODE.search(line)
        if m and cur is not None:
            ips = re.findall(r'"([^"]+)"', m.group(6))
            cur.append(dict(id=m.group(1), name=m.group(2), group=m.group(3), host=m.group(4), path=m.group(5), ips=ips))
    return relays, targets


def http(host, ip, req_head, body=b"", timeout=6):
    ctx = ssl.create_default_context()
    raw = socket.create_connection((ip, 443), timeout=timeout)
    s = ctx.wrap_socket(raw, server_hostname=host)
    s.settimeout(timeout)
    s.sendall(req_head.encode() + body)
    data = b""
    while True:
        try:
            c = s.recv(65536)
        except socket.timeout:
            break
        if not c:
            break
        data += c
        if b"\r\n\r\n" in data:
            head, _, rest = data.partition(b"\r\n\r\n")
            m = re.search(rb"(?i)content-length:\s*(\d+)", head)
            if m and len(rest) >= int(m.group(1)):
                break
    s.close()
    head, _, rest = data.partition(b"\r\n\r\n")
    status = int(head.split(b" ", 2)[1])
    if re.search(rb"(?i)transfer-encoding:\s*chunked", head):
        out, p = b"", 0
        while True:
            e = rest.find(b"\r\n", p)
            n = int(rest[p:e].split(b";")[0], 16)
            if n == 0:
                break
            out += rest[e + 2:e + 2 + n]
            p = e + 2 + n + 2
        rest = out
    return status, head.decode("latin-1"), rest


def parse_config(b):
    """Uygulamanın OdohConfigs.parse kurallarıyla aynı: (desteklenen sayısı, hata)"""
    if len(b) < 2 or int.from_bytes(b[:2], "big") != len(b) - 2:
        return 0, "uzunluk öneki uyuşmuyor"
    p, ok = 2, 0
    while p < len(b):
        if len(b) - p < 4:
            return 0, "kesik başlık"
        ver, ln = int.from_bytes(b[p:p + 2], "big"), int.from_bytes(b[p + 2:p + 4], "big")
        p += 4
        if ln > len(b) - p:
            return 0, "gövde taşıyor"
        c = b[p:p + ln]
        p += ln
        if ver != 1:
            continue
        if len(c) < 8:
            return 0, "kesik içerik"
        kem, kdf, aead, pk = (int.from_bytes(c[i:i + 2], "big") for i in (0, 2, 4, 6))
        if pk != len(c) - 8:
            return 0, "anahtar uzunluğu uyuşmuyor"
        if (kem, kdf, aead, pk) == (0x20, 1, 1, 32):
            ok += 1
    return ok, None if ok else "desteklenen takım yok"


def main():
    relays, targets = load()
    bad = 0
    print("HEDEFLER")
    for t in targets:
        res = None
        for ip in t["ips"]:
            try:
                st, head, body = http(t["host"], ip, f"GET /.well-known/odohconfigs HTTP/1.1\r\nHost: {t['host']}\r\nUser-Agent: odoh_check\r\nConnection: close\r\n\r\n")
                if st != 200:
                    res = f"HTTP {st}"
                    continue
                n, err = parse_config(body)
                res = (f"tamam, {n} geçerli yapılandırma ({ip})" if n else f"yapılandırma geçersiz: {err}")
                if n:
                    break
            except Exception as e:  # noqa: BLE001
                res = f"{ip}: {type(e).__name__} {e}"
        ok = res is not None and res.startswith("tamam")
        bad += 0 if ok else 1
        print(f"  {'✓' if ok else '✗'} {t['name']:<24} {t['host']:<28} {res}")
    print("RÖLELER")
    for r in relays:
        t = targets[0]
        q = urllib.parse.urlencode({"targethost": t["host"], "targetpath": t["path"]}, quote_via=urllib.parse.quote, safe="")
        path = r["path"] + ("&" if "?" in r["path"] else "?") + q
        junk = os.urandom(120)
        res = None
        for ip in r["ips"]:
            try:
                head = (f"POST {path} HTTP/1.1\r\nHost: {r['host']}\r\nUser-Agent: odoh_check\r\nAccept: {MEDIA}\r\n"
                        f"Content-Type: {MEDIA}\r\nContent-Length: {len(junk)}\r\nConnection: close\r\n\r\n")
                st, _, _ = http(r["host"], ip, head, junk)
                res = f"HTTP {st} ({ip})"
                if 400 <= st < 500 and st != 404:
                    res = "tamam, " + res + " (geçersiz gövde hedefçe reddedildi: röle iletiyor)"
                    break
            except Exception as e:  # noqa: BLE001
                res = f"{ip}: {type(e).__name__} {e}"
        ok = res is not None and res.startswith("tamam")
        bad += 0 if ok else 1
        print(f"  {'✓' if ok else '✗'} {r['name']:<24} {r['host']:<28} {res}")
    print("Bağımsızlık: " + ", ".join(f"{r['id']}≠{t['id']}" for r in relays for t in targets if r["group"] != t["group"]))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
