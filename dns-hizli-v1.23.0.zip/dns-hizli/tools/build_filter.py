#!/usr/bin/env python3
"""Filtre listelerini üretir: app/src/main/assets/filter/{basic,medium,strict}.bin ve KAYNAKLAR.txt.
Kaynaklar (lisanslar KAYNAKLAR.txt'te): StevenBlack/hosts (MIT), blocklistproject/Lists (MIT/Unlicense), badmojr/1Hosts Lite (MPL-2.0),
Perflyst/PiHoleBlocklist (MIT), nextdns/native-tracking-domains (MIT).
Ağ gerekir (raw.githubusercontent.com). Kullanım: python3 tools/build_filter.py [--cache klasör]
Her alan adı 48 bitlik bir özete (Filter.kt'deki `hash` ile birebir aynı) çevrilir; sıralı, tekrarsız, fark + LEB128 kodlanır.
Seviyeler birikimlidir: Basit = basic; Orta = basic + medium; Sıkı = hepsi.
"""
import os, re, struct, sys, urllib.request, datetime

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(ROOT, "app", "src", "main", "assets", "filter")
BLP = "https://raw.githubusercontent.com/blocklistproject/Lists/master/%s.txt"
SB = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
ONE_LITE = "https://raw.githubusercontent.com/badmojr/1Hosts/master/Lite/domains.wildcards"
PERF = "https://raw.githubusercontent.com/Perflyst/PiHoleBlocklist/master/%s"
NDNS = "https://raw.githubusercontent.com/nextdns/native-tracking-domains/main/domains/%s"

# Çalışan uygulamaları bozabilecek girdiler (yerel/OEM izleyici kaynaklarından atılır): mesajlaşma/sosyal uygulamaların kendi sunucuları
# (bildirim ve oturum için gerekir) ve Huawei hizmetlerinin yönlendirme (grs) sunucuları.
RISKY = re.compile(r"(^|\.)(facebook|instagram|whatsapp)\.(com|net)$|^grs\.")
RISKY_SOURCES = ("Perflyst", "NextDNS")

# Popülerlik kapısı: "kapılı" bir kaynağın girdisi doğrudan popüler bir alan adıysa (ör. bir alışveriş sitesi) ve ayrıca bir
# kapısız kaynakta da yoksa Basit/Orta'ya GİRMEZ, yalnızca Sıkı'ya gider. Böylece reklam kapsaması artarken yaygın sitelerin
# yanlışlıkla engellenmesi önlenir. Kapı verisi yalnızca derleme sırasında okunur, uygulamaya girmez.
POP_URLS = ["https://raw.githubusercontent.com/opendns/public-domain-lists/master/opendns-top-domains.txt",
            "https://raw.githubusercontent.com/zer0h/top-1000000-domains/master/top-10000-domains"]
# Kapılı kaynakları doğrulayan ek kaynaklar (yalnızca derlemede okunur): iki bağımsız listede de olan girdi yeterince güvenilirdir.
CORROBORATE = ["https://raw.githubusercontent.com/lightswitch05/hosts/master/docs/lists/ads-and-tracking-extended.txt",
               "https://raw.githubusercontent.com/Ultimate-Hosts-Blacklist/Ultimate.Hosts.Blacklist/master/hosts/hosts0"]

# katman -> kaynaklar
TIERS = {
    "basic": [("StevenBlack/hosts (birleşik: reklam + zararlı yazılım)", SB, "MIT"),
              ("blocklistproject ads", BLP % "ads", "Unlicense"),
              ("blocklistproject phishing", BLP % "phishing", "MIT"),
              ("blocklistproject ransomware", BLP % "ransomware", "MIT"),
              ("blocklistproject scam", BLP % "scam", "MIT"),
              ("1Hosts Lite (badmojr)", ONE_LITE, "MPL-2.0", True)],
    "medium": [("blocklistproject tracking", BLP % "tracking", "MIT"),
               ("Perflyst Android izleyicileri", PERF % "android-tracking.txt", "MIT"),
               ("Perflyst Akıllı TV izleyicileri", PERF % "SmartTV.txt", "MIT"),
               ("NextDNS Samsung yerel izleyicileri", NDNS % "samsung", "MIT"),
               ("NextDNS Xiaomi yerel izleyicileri", NDNS % "xiaomi", "MIT"),
               ("NextDNS Huawei yerel izleyicileri", NDNS % "huawei", "MIT"),
               ("NextDNS Windows yerel izleyicileri", NDNS % "windows", "MIT"),
               ("NextDNS Alexa yerel izleyicileri", NDNS % "alexa", "MIT"),
               ("NextDNS Sonos yerel izleyicileri", NDNS % "sonos", "MIT"),
               ("NextDNS Apple yerel izleyicileri", NDNS % "apple", "MIT")],
    "strict": [("blocklistproject fraud", BLP % "fraud", "Unlicense"),
               ("blocklistproject abuse", BLP % "abuse", "MIT"),
               ("blocklistproject redirect", BLP % "redirect", "MIT"),
               ("blocklistproject crypto", BLP % "crypto", "Unlicense")],
}
M = (1 << 64) - 1

def h64(name):
    x = 0xcbf29ce484222325
    for b in name.encode("ascii"):
        x ^= b
        x = (x * 0x100000001b3) & M
    x = ((x ^ (x >> 30)) * 0xbf58476d1ce4e5b9) & M
    x = ((x ^ (x >> 27)) * 0x94d049bb133111eb) & M
    x ^= x >> 31
    return x & 0xFFFFFFFFFFFF

LABEL = re.compile(r"^[a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9_])?$")
NOT_DOMAINS = {"localhost", "localhost.localdomain", "local", "broadcasthost", "0.0.0.0", "ip6-localhost", "ip6-loopback",
               "ip6-localnet", "ip6-mcastprefix", "ip6-allnodes", "ip6-allrouters", "ip6-allhosts"}
# alan adı sahibi yerine bölge olan (engellenirse bütün bölge gider) adlar: listeye alınmaz
PUBLIC_SUFFIXES = {"com.tr", "net.tr", "org.tr", "gen.tr", "web.tr", "biz.tr", "info.tr", "co.uk", "org.uk", "ac.uk", "gov.uk",
                   "com.br", "com.au", "co.jp", "co.in", "co.za", "com.cn", "com.mx", "com.ar", "co.id", "co.kr", "com.ru",
                   "github.io", "blogspot.com", "appspot.com", "herokuapp.com", "cloudfront.net", "amazonaws.com", "azurewebsites.net"}

def valid(d):
    if len(d) > 253 or d in NOT_DOMAINS or d in PUBLIC_SUFFIXES: return False
    parts = d.split(".")
    if len(parts) < 2: return False
    if all(p.isdigit() for p in parts): return False           # IP adresi
    return all(LABEL.match(p) for p in parts)

def parse(text):
    out = set()
    for ln in text.splitlines():
        ln = ln.split("#", 1)[0].strip()
        if not ln: continue
        p = ln.split()
        d = (p[1] if len(p) > 1 else p[0]).lower().rstrip(".")
        if valid(d): out.add(d)
    return out

def fetch(url, cache):
    fn = os.path.join(cache, re.sub(r"[^A-Za-z0-9]+", "_", url)) if cache else None
    if fn and os.path.exists(fn): return open(fn, encoding="utf-8", errors="ignore").read()
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "dns-hizli-build"}), timeout=120) as r:
        t = r.read().decode("utf-8", "ignore")
    if fn:
        os.makedirs(cache, exist_ok=True); open(fn, "w", encoding="utf-8").write(t)
    return t

def suffixes(d):
    p = d.split(".")
    return [".".join(p[i:]) for i in range(len(p) - 1)]       # kendisi dahil, en az iki etiket

def varint(n):
    b = bytearray()
    while True:
        c = n & 0x7F; n >>= 7
        if n: b.append(c | 0x80)
        else: b.append(c); return bytes(b)

def write_bin(path, hashes):
    hs = sorted(hashes)
    prev = 0; body = bytearray()
    for x in hs:
        body += varint(x - prev); prev = x
    with open(path, "wb") as fh:
        fh.write(b"DNF1" + struct.pack(">I", len(hs)) + bytes(body))
    return len(hs), 8 + len(body)

def main():
    cache = None
    if "--cache" in sys.argv: cache = sys.argv[sys.argv.index("--cache") + 1]
    prot = set()
    for ln in open(os.path.join(OUT, "protected.txt"), encoding="utf-8"):
        ln = ln.split("#", 1)[0].strip().lower()
        if ln: prot.add(ln)
    def is_protected(d): return any(s in prot for s in suffixes(d))
    sets, info = {}, []
    gated_names = {t: set() for t in TIERS}                 # kapılı kaynaklardan gelenler (kapısız kaynakta olmayanlar)
    for tier, srcs in TIERS.items():
        s = set(); free = set(); gated = set()
        for src in srcs:
            name, url, lic = src[0], src[1], src[2]
            is_gated = len(src) > 3 and src[3]
            got = parse(fetch(url, cache))
            if name.startswith(RISKY_SOURCES): got = {d for d in got if not RISKY.search(d)}
            s |= got
            (gated if is_gated else free).update(got)
            info.append((tier, name, lic, len(got)))
        sets[tier] = s
        gated_names[tier] = gated - free
    pop = set()
    for u in POP_URLS:
        for ln in fetch(u, cache).splitlines():
            ln = ln.strip().lower().split(",")[-1].strip()
            if valid(ln): pop.add(ln)
    corr = set()
    for u in CORROBORATE: corr |= parse(fetch(u, cache))
    moved = 0
    for tier in TIERS:
        # popüler girdi + başka bağımsız kaynakta yok -> daha sıkı bir katmana (basic -> strict, medium -> strict)
        hold = {d for d in gated_names[tier] if d in pop and d not in corr}
        if hold and tier != "strict":
            sets[tier] -= hold; sets["strict"] |= hold; moved += len(hold)
    print("popülerlik kapısı: Sıkı'ya taşınan", moved)
    # korunan adlar hiçbir katmanda olmaz (alt alan adları dahil)
    for t in sets: sets[t] = {d for d in sets[t] if not is_protected(d)}
    # katman içi ve alt katmanlara göre gereksizleri ele: üst alan adı zaten engelliyse alt alan adı gereksiz
    order = ["basic", "medium", "strict"]
    kept = {}
    lower = set()
    for t in order:
        cur = sets[t]
        allv = lower | cur
        res = set()
        for d in cur:
            if any(s in allv for s in suffixes(d)[1:]): continue      # bir üst alan adı zaten var
            if t != "basic" and d in lower: continue
            res.add(d)
        kept[t] = res
        lower |= res
    os.makedirs(OUT, exist_ok=True)
    stats = {}
    seen = {}
    for t in order:
        hs = {h64(d) for d in kept[t]}
        # 48 bit çakışmaları (çok nadir) ve katmanlar arası yinelenenler
        for other in order[:order.index(t)]: hs -= seen.get(other, set())
        seen[t] = hs
        stats[t] = write_bin(os.path.join(OUT, t + ".bin"), hs)
    today = datetime.date.today().isoformat()
    with open(os.path.join(OUT, "KAYNAKLAR.txt"), "w", encoding="utf-8") as fh:
        fh.write(f"Filtre listeleri ({today}), tools/build_filter.py ile üretildi.\n\n")
        for tier, name, lic, n in info: fh.write(f"[{tier}] {name} - lisans: {lic} - {n} alan adı\n")
        fh.write("\n")
        for t in order: fh.write(f"{t}.bin: {stats[t][0]} alan adı, {stats[t][1]} bayt\n")
        fh.write("\nKaynak projeler: StevenBlack/hosts (Steven Black, MIT), blocklistproject/Lists (The Block List Project, MIT / Unlicense), "
                 "Perflyst/PiHoleBlocklist (Perflyst, MIT), nextdns/native-tracking-domains (NextDNS, MIT) ve badmojr/1Hosts (badmojr, Mozilla Public License 2.0).\n"
                 "MIT lisansı gereği telif ve izin bildirimi korunur: https://github.com/StevenBlack/hosts/blob/master/license.txt ve "
                 "https://github.com/blocklistproject/Lists/blob/master/LICENSE\n"
                 "1Hosts (MPL-2.0): bu uygulamadaki liste, 1Hosts Lite kaynağından türetilmiştir (alan adları özetlenip sıralanmıştır, içerik değiştirilmemiştir). "
                 "Özgün kaynak kodu (liste): https://github.com/badmojr/1Hosts , lisans: https://github.com/badmojr/1Hosts/blob/main/LICENSE ; "
                 "bu listeyi yeniden üreten araç tools/build_filter.py dosyasıdır.\n")
    for t in order: print(t, stats[t])

if __name__ == "__main__":
    main()
