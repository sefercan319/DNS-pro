# Google Play mağaza metni — taslak (v1.9.11)

Play Console → *Mağaza girişi*. Varsayılan dil **İngilizce** (uygulamanın kaynak dili de İngilizce); diğer diller *Çeviri ekle* ile girilir.
Sınırlar: ad 30, kısa açıklama 80, tam açıklama 4000 karakter (hepsi kontrol edildi). Köşeli yerleri doldur.

## Ad ve kısa açıklama (12 dil)

| Dil | Ad | Kısa açıklama |
|---|---|---|
| English (varsayılan) | DNS Fast: Secure DNS Changer | Encrypted DNS and network safety tool. Shields against malware and phishing. |
| Türkçe | DNS Hızlı | Şifreli DNS ve ağ güvenliği aracı. Zararlı ve kimlik avı sitelerine karşı. |
| Deutsch | DNS Hızlı | Verschlüsseltes DNS, Netzwerk-Sicherheitstool. Schutz vor Malware, Phishing. |
| Español | DNS Hızlı | DNS cifrado y herramienta de seguridad de red. Protege de malware y phishing. |
| Français | DNS Hızlı | DNS chiffré et outil de sécurité réseau. Protège du malware et du phishing. |
| Português | DNS Hızlı | DNS criptografado e segurança de rede. Protege de malware e phishing. |
| Русский | DNS Hızlı | Зашифрованный DNS и сетевая защита. Защита от вредоносных сайтов и фишинга. |
| Italiano | DNS Hızlı | DNS cifrato e strumento di sicurezza di rete. Protegge da malware e phishing. |
| Bahasa Indonesia | DNS Hızlı | DNS terenkripsi dan keamanan jaringan. Lindungi dari malware dan phishing. |
| Tiếng Việt | DNS Hızlı | DNS mã hóa và công cụ bảo mật mạng. Chống mã độc và lừa đảo. |
| Polski | DNS Hızlı | Szyfrowany DNS i bezpieczeństwo sieci. Ochrona przed malware i phishingiem. |
| Українська | DNS Hızlı | Зашифрований DNS і мережевий захист. Захист від шкідливих сайтів і фішингу. |

> Ad Türkçe'de marka adıdır ("DNS Hızlı"). İngilizce adda aranabilirlik için açıklayıcı sürüm kullanıldı; markayı tek tutmak istersen "DNS Hızlı" yazabilirsin.

## Tam açıklama — English (varsayılan)

DNS Fast is a network security tool: it sends your DNS queries through encrypted channels (DNS-over-TLS / DNS-over-HTTPS) to a provider you choose, and can shield you from malicious, phishing and tracking domains. Popular public DNS servers (Cloudflare, Google, Quad9, AdGuard and more) sit in one list and connect with one tap.

Tap the orb to connect. Tap another server to switch without dropping the connection. That is all it takes.

WHAT YOU GET
• 32 ready-made DNS servers (fast, privacy-focused, ad-blocking, family-safe, security-focused) and up to 8 of your own
• Encrypted DNS: DNS-over-TLS and DNS-over-HTTPS, chosen automatically, IPv4 and IPv6
• Protection against malicious, phishing and tracking domains with four levels (Off / Basic / Medium / Strict), your own allow and block lists, a counter and a list of recently blocked sites. The lists ship inside the app and everything runs on your phone
• Self-repair: if the server stops answering, the app refreshes the connection, switches to your backup server or rebuilds the tunnel by itself
• Speed tests with history chart, backup server, automatic reconnect, pause for 5 / 15 / 60 minutes
• Choose which apps use the DNS: all, only selected, or all except selected
• Separate servers for Wi-Fi and mobile data, connect on phone start, home-screen widget, quick-settings tile, notification buttons
• Connection test: is DNS working, is DNSSEC validated, is the protection active
• Troubleshooter that tells you why it cannot connect (another VPN, Private DNS, permission, no internet)
• Export and import your settings, optional no-history mode

DESIGN
• Glassy, fluid interface drawn from scratch, in seven styles (Aqua, Aero, Metro, Eco, Y2K, Aurora, Liquid Glass), each with its own sounds, animations and app icon, and twelve colour themes
• Your own photo as background, automatic or timed dark mode, low-power mode, high contrast, text size, TalkBack support
• 12 languages: Türkçe, English, Deutsch, Español, Français, Português, Русский, Italiano, Bahasa Indonesia, Tiếng Việt, Polski, Українська

LIGHT
• No loop runs while the screen is off, small size, no third-party libraries

PRIVACY
• No account, no ads, no analytics. The app does not log query names and sends nothing to the developer
• Your DNS queries go to the DNS provider you choose, encrypted by default. If you turn encryption off, plain DNS is used. The provider's own privacy policy applies

HOW THE VPN INTERFACE IS USED (Android VpnService)
DNS Fast uses Android's VPN interface locally, only to send DNS queries to the server you picked. It is not a remote VPN service: your traffic is not sent to any VPN server, and everything except DNS queries continues on its normal route. The app explains this on first launch and asks for Android's VPN permission.

GOOD TO KNOW
• Android allows one VPN at a time, so the app cannot connect while another VPN app is on.
• Some browsers' "secure DNS" setting and Android's Private DNS pinned to a host name use their own server and can bypass this app. "Automatic" or "Off" is enough.
• With encryption off, some networks (carrier, school, company) may redirect DNS traffic.

## Tam açıklama — Türkçe

DNS Hızlı bir ağ güvenliği aracıdır: DNS sorgularını şifreli kanaldan (DNS-over-TLS / DNS-over-HTTPS) seçtiğin sağlayıcıya iletir ve zararlı, kimlik avı ve izleyici alan adlarına karşı seni koruyabilir. Cloudflare, Google, Quad9, AdGuard gibi bilinen herkese açık DNS sunucuları tek listede, tek dokunuşla bağlanır.

Küreye dokun, bağlan. Başka bir sunucuya dokun, bağlantı kopmadan geç. Hepsi bu.

NELER VAR
• 32 hazır DNS sunucusu (hızlı, gizlilik odaklı, reklam engelleyen, aile filtreli, güvenlik odaklı) ve kendi eklediğin en fazla 8 sunucu
• Şifreli DNS: DNS-over-TLS ve DNS-over-HTTPS, otomatik seçim, IPv4 ve IPv6
• Zararlı, kimlik avı ve izleyici alan adlarına karşı koruma: dört seviye (Kapalı / Basit / Orta / Sıkı), kendi izin ve engel listeni ekleme, sayaç ve son engellenenler. Listeler uygulamayla gelir, her şey telefonda çalışır
• Kendini onarma: sunucu cevap vermeyi keserse uygulama bağlantıyı kendisi yeniler, yedek sunucuya geçer ya da tüneli baştan kurar
• Hız ölçümü ve geçmiş grafiği, yedek sunucu, otomatik yeniden bağlanma, 5 / 15 / 60 dk duraklatma
• DNS'in hangi uygulamalara uygulanacağını seç: hepsi, yalnızca seçilenler ya da seçilenler hariç
• Wi-Fi ve mobil veri için ayrı sunucu, telefon açılınca bağlan, ana ekran widget'ı, hızlı ayarlar kutucuğu, bildirim düğmeleri
• Bağlantı testi: DNS çalışıyor mu, DNSSEC doğrulanıyor mu, koruma etkin mi
• Bağlanamazsan nedenini söyleyen sorun giderici (başka VPN, Özel DNS, izin, internet yok)
• Ayarları dışa / içe aktarma, istersen geçmişi hiç tutmama

TASARIM
• Sıfırdan çizilmiş şeffaf cam, akışkan arayüz: yedi stil (Aqua, Aero, Metro, Eco, Y2K, Aurora, Liquid Glass; her birinin kendi sesi, animasyonu ve simgesi var) ve on iki renk teması
• Kendi fotoğrafını arka plan yap, otomatik ya da saate göre koyu mod, düşük güç modu, yüksek kontrast, yazı boyutu, TalkBack desteği
• 12 dil: Türkçe, English, Deutsch, Español, Français, Português, Русский, Italiano, Bahasa Indonesia, Tiếng Việt, Polski, Українська

HAFİF
• Ekran kapalıyken sürekli çalışan döngü yok, küçük boyut, harici kütüphane yok

GİZLİLİK
• Hesap yok, reklam yok, analitik yok. Uygulama sorgu adlarını kaydetmez ve geliştiriciye hiçbir şey göndermez
• DNS sorguların seçtiğin sağlayıcıya varsayılan olarak şifreli gider. Şifrelemeyi kapatırsan düz DNS kullanılır. Sağlayıcının kendi gizlilik politikası geçerlidir

VPN ARAYÜZÜNÜN KULLANIMI (Android VpnService)
DNS Hızlı, Android'in VPN arayüzünü yalnızca yerelde, DNS sorgularını seçtiğin sunucuya iletmek için kullanır. Uzak bir VPN hizmeti değildir: trafiğin hiçbir VPN sunucusuna gönderilmez, DNS sorguları dışındaki her şey normal yolundan devam eder. Uygulama bunu ilk açılışta anlatır ve Android'in VPN izin penceresini gösterir.

BİLMEN GEREKENLER
• Android aynı anda tek VPN'e izin verir; başka bir VPN uygulaması açıkken bu uygulama bağlanamaz.
• Bazı tarayıcıların "güvenli DNS" ayarı ve belirli bir ada sabitlenmiş Android "Özel DNS" ayarı kendi sunucusunu kullanır, bu uygulamayı atlayabilir. "Otomatik" ya da "Kapalı" yeterli.
• Şifreleme kapalıyken bazı ağlar (operatör, okul, şirket) DNS trafiğini kendi sunucusuna yönlendirebilir.

> Diğer 10 dilde tam açıklama: uygulamanın kendi dil dosyalarından çeviri yapılabilir; yetkin bir kişiye okutmadan yayınlama. Başlangıçta yalnızca ad + kısa açıklama + İngilizce tam metin yeterlidir.

## Yenilikler (sürüm notu, en çok 500 karakter)
English:
• Self-repair: the app now refreshes or rebuilds a stalled connection by itself
• Switching servers no longer interrupts DNS while the new server is tested
• Large DNS answers now work over TCP
• Import your own block list, connection notifications, latency chart, optional "stay closed" mode
• Longer automatic reconnect, faster repeat lookups for unknown names, more stable ad blocking

Türkçe:
• Kendini onarma: takılan bağlantı uygulama tarafından yenilenir ya da baştan kurulur
• Sunucu değiştirirken yeni sunucu denenirken DNS kesilmez
• Büyük DNS cevapları artık TCP ile de çalışır
• Kendi engelleme listeni aktar, bağlantı bildirimleri, gecikme grafiği, isteğe bağlı "kapalı kalırsa dur"
• Daha uzun otomatik yeniden bağlanma, olmayan adlarda daha hızlı tekrar sorgu, daha kararlı reklam engelleme

## Kategori ve etiketler
Kategori: Araçlar. Etiketler: ağ, DNS, hız, gizlilik.

## İletişim
E-posta: [e-posta adresin] · Gizlilik politikası URL: [yayınladığın adres]

## Görseller
- Simge: `ikon-512.png` (512×512)
- Öne çıkan görsel: `one-cikan-gorsel-1024x500.png` (1024×500)
- Ekran görüntüleri: **kendi telefonundan** al (en az 2, tercihen 4–8): bağlı ana ekran, sunucu listesi, engelleme sayfası, ayarlar/temalar. `previews/` çizim önizlemesidir, mağazada gerçek ekran görüntüsü kullan.

Play Console beyanları (veri güvenliği, VPN, önplan hizmeti) için `store/play_beyanlari.md`.
