package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File
import java.nio.ByteBuffer
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLEngine
import javax.net.ssl.SSLEngineResult

/**
 * DPI atlatma ölçümü. İKİ KISIM:
 *  1) Gerçek doğrulama: her TLS yöntemi gerçek bir JSSE ClientHello'su üzerinde çalışır, parçalar birleşince gerçek bir sunucu
 *     (SSLEngine) el sıkışmayı tamamlar. HTTP yöntemleri anlamca aynı isteği taşır.
 *  2) Benzetim: parametre ızgarasıyla tanımlı DPI modelleri. Modeller gerçek bir operatörün cihazı DEĞİL, bilinen zayıflık
 *     sınıflarının (parça sınırı, kayıt birleştirme sınırı, acil veriyi akışa katma, sırasız akışa tahammülsüzlük, büyük/küçük harf,
 *     başlık konumu...) birleşimidir. Sonuç, yöntem kümesinin bu sınıfları ne kadar kapsadığını gösterir; gerçek bir ağdaki başarıyı
 *     garanti etmez. Bölme işlemi gerçek [Dpi.split] kodudur; yalnızca "DPI ne görür" kısmı modeldir.
 */

// ---------------------------------------------------------------- TLS modeli

internal class TlsDpi(
    val segLimit: Int,           // ilk kaç TCP parçasını (varış sırasıyla) birleştirir
    val recLimit: Int,           // kaç TLS kaydını birleştirir
    val oobInline: Boolean,      // acil baytı akışa katar (ayrıştırma kayar)
    val gapGivesUp: Boolean,     // sıra dışı / boşluklu akışta izlemeyi bırakır
    val drop: Boolean,           // engel biçimi: sessiz düşürme (true) ya da RST (false)
    val srvFragOk: Boolean,      // karşı sunucu parçalı kaydı kabul eder mi (eski/hatalı yığınlar)
)

private class SimSeg(val seq: Int, val data: ByteArray)

/** DPI modeli bu parçalardan [host] adını okuyabiliyor mu? */
internal fun tlsSees(m: TlsDpi, parts: List<Dpi.Part>, host: String): Boolean {
    // varış sırası: düşük TTL'liler sona kalır (çekirdek yeniden yollar); sıra numaraları özgün akışa göredir
    val segs = ArrayList<SimSeg>()
    var seq = 0
    val late = ArrayList<SimSeg>()
    for (p in parts) {
        val s = SimSeg(seq, p.data); seq += p.data.size
        if (p.lowTtl) late.add(s) else segs.add(s)
        if (p.oobAfter && m.oobInline) { val o = SimSeg(seq, byteArrayOf(0)); seq += 1; segs.add(o) }
    }
    if (late.isNotEmpty() && m.gapGivesUp) return false
    val arrival = segs + late
    val seen = arrival.take(m.segLimit).sortedBy { it.seq }
    // sıra numarası 0'dan kesintisiz önek
    val o = java.io.ByteArrayOutputStream()
    var next = 0
    for (s in seen) { if (s.seq != next) break; o.write(s.data); next += s.data.size }
    val w = o.toByteArray()
    // kayıtları yürü
    val hs = java.io.ByteArrayOutputStream()
    var p = 0; var recs = 0
    while (recs < m.recLimit && p + 5 <= w.size && w[p].toInt() == 0x16) {
        val l = ((w[p + 3].toInt() and 0xFF) shl 8) or (w[p + 4].toInt() and 0xFF)
        val e = minOf(w.size, p + 5 + l)
        hs.write(w, p + 5, e - (p + 5)); p = e; recs++
        if (e < p + 0) break
    }
    val body = hs.toByteArray()
    val buf = ByteArray(5 + body.size)
    buf[0] = 0x16; buf[1] = 3; buf[2] = 1; buf[3] = (body.size ushr 8).toByte(); buf[4] = body.size.toByte()
    System.arraycopy(body, 0, buf, 5, body.size)
    val h = Dpi.Hello()
    return Dpi.parseHello(buf, buf.size, h) && h.host(buf) == host
}

internal fun tlsGrid(): List<TlsDpi> {
    val out = ArrayList<TlsDpi>()
    for (l in intArrayOf(1, 2, 3, 4, 6, 8, 12, 1000)) for (r in intArrayOf(1, 2, 3, 4, 1000)) for (oob in listOf(false, true))
        for (gap in listOf(false, true)) for (drop in listOf(false, true)) for (srv in listOf(true, false))
            out.add(TlsDpi(l, r, oob, gap, drop, srv))
    return out
}

// ---------------------------------------------------------------- HTTP modeli

internal class HttpDpi(
    val segLimit: Int, val needMethodFirst: Boolean, val caseSensitive: Boolean, val oneSpace: Boolean, val scanLimit: Int, val drop: Boolean,
)

internal fun httpSees(m: HttpDpi, parts: List<Dpi.Part>, host: String): Boolean {
    val w = parts.take(m.segLimit).fold(ByteArray(0)) { a, x -> a + x.data }
    var t = String(w, Charsets.ISO_8859_1)
    if (m.needMethodFirst && !listOf("GET ", "POST ", "HEAD ").any { t.startsWith(it) }) return false
    if (t.length > m.scanLimit) t = t.substring(0, m.scanLimit)
    val re = if (m.caseSensitive) Regex("\r\nHost: ?([^\r\n]*)\r\n") else Regex("\r\n[Hh][Oo][Ss][Tt]:[ \t]*([^\r\n]*)\r\n")
    val mt = re.find(t) ?: return false
    if (m.oneSpace && !mt.value.startsWith("\r\nHost: ") ) return false
    if (m.oneSpace && mt.value.startsWith("\r\nHost:  ")) return false
    return mt.groupValues[1].trim().lowercase().substringBefore(':') == host
}

internal fun httpGrid(): List<HttpDpi> {
    val out = ArrayList<HttpDpi>()
    for (l in intArrayOf(1, 2, 3, 1000)) for (nm in listOf(false, true)) for (cs in listOf(false, true)) for (os in listOf(false, true))
        for (sc in intArrayOf(110, 100000)) for (dr in listOf(false, true)) out.add(HttpDpi(l, nm, cs, os, sc, dr))
    return out
}

private const val RTT = 60L
private const val DISORDER_COST = 250L

private val HTTP_REQ = ("GET /yol HTTP/1.1\r\nHost: engelli.ornek.com\r\nUser-Agent: Mozilla/5.0 (Linux; Android 14) Chrome/120\r\n" +
    "Accept: text/html\r\nAccept-Language: tr\r\nConnection: keep-alive\r\n\r\n").toByteArray(Charsets.ISO_8859_1)

internal class SimResult(val solved: Int, val total: Int, val meanMs: Double, val firstTry: Double)

private fun tlsRun(hello: ByteArray, host: String, newSet: Boolean): SimResult {
    val grid = tlsGrid()
    var solved = 0; var costSum = 0.0; var first = 0; var runs = 0
    for (m in grid) {
        val planner = Dpi.Planner().also { it.noteRtt(RTT) }
        var okAny = false
        for (hi in 0 until 24) {
            val key = "h$hi"
            var plan = if (newSet) planner.first(key, Dpi.TLS) else Dpi.TLS_ORDER_OLD[0]
            var idx = 0
            var cost = 0.0
            var ok = false; var tries = 0
            while (true) {
                tries++
                val parts = Dpi.split(Dpi.TLS, plan, hello, hello.size)
                val blocked = tlsSees(m, parts, host)
                val srvBad = !m.srvFragOk && plan in intArrayOf(1, 3, 6, 7)
                if (!blocked && !srvBad) { ok = true; if (parts.any { it.lowTtl }) cost += DISORDER_COST; break }
                cost += if (blocked && m.drop) (if (newSet) planner.waitMs(Dpi.TLS).toDouble() else 2000.0) else RTT.toDouble()
                val nxt = if (newSet) planner.next(Dpi.TLS, plan) else Dpi.TLS_ORDER_OLD.getOrElse(++idx) { -1 }
                if (nxt < 0) break
                plan = nxt
            }
            if (ok) { if (newSet) planner.worked(key, Dpi.TLS, plan); if (hi == 0) okAny = true }
            costSum += cost; runs++
            if (ok && tries == 1) first++
        }
        if (okAny) solved++
    }
    return SimResult(solved, grid.size, costSum / runs, first.toDouble() / runs)
}

private fun httpRun(host: String, newSet: Boolean): SimResult {
    val grid = httpGrid()
    val maxPlans = if (newSet) Dpi.HTTP_PLANS else Dpi.HTTP_PLANS_OLD
    var solved = 0; var costSum = 0.0; var first = 0; var runs = 0
    for (m in grid) {
        val planner = Dpi.Planner().also { it.noteRtt(RTT) }
        var okAny = false
        for (hi in 0 until 24) {
            val key = "h$hi"
            var plan = if (newSet) planner.first(key, Dpi.HTTP) else 0
            var cost = 0.0; var ok = false; var tries = 0
            while (plan in 0 until maxPlans) {
                tries++
                val parts = Dpi.split(Dpi.HTTP, plan, HTTP_REQ, HTTP_REQ.size)
                if (!httpSees(m, parts, host)) { ok = true; break }
                cost += if (m.drop) (if (newSet) planner.waitMs(Dpi.HTTP).toDouble() else 5000.0) else RTT.toDouble()
                plan = if (newSet) planner.next(Dpi.HTTP, plan) else plan + 1
            }
            if (ok) { if (newSet) planner.worked(key, Dpi.HTTP, plan); if (hi == 0) okAny = true }
            costSum += cost; runs++
            if (ok && tries == 1) first++
        }
        if (okAny) solved++
    }
    return SimResult(solved, grid.size, costSum / runs, first.toDouble() / runs)
}

// ---------------------------------------------------------------- gerçek JSSE doğrulaması

private fun drain(e: SSLEngine) { var t = e.delegatedTask; while (t != null) { t.run(); t = e.delegatedTask } }

/** İstemci ClientHello'sunu [mutate] ile dönüştürüp sunucuya verir; iki taraf da el sıkışmayı tamamlarsa true. */
private fun jsseHandshake(host: String, mutate: (ByteArray) -> ByteArray): Boolean {
    val sctx = TestTls.serverContext(TestTls.good)
    val cctx = SSLContext.getInstance("TLS").also { c ->
        val trust = java.security.KeyStore.getInstance(java.security.KeyStore.getDefaultType()).also { it.load(null, null) }
        trust.setCertificateEntry("g", TestTls.good.getCertificate("s"))
        val tmf = javax.net.ssl.TrustManagerFactory.getInstance(javax.net.ssl.TrustManagerFactory.getDefaultAlgorithm()); tmf.init(trust)
        c.init(null, tmf.trustManagers, null)
    }
    val cl = cctx.createSSLEngine(host, 443).also { it.useClientMode = true; it.sslParameters = it.sslParameters.also { p -> p.serverNames = listOf(SNIHostName(host)); p.endpointIdentificationAlgorithm = null } }
    val sv = sctx.createSSLEngine().also { it.useClientMode = false }
    cl.beginHandshake(); sv.beginHandshake()
    val big = 65536
    val inC = ByteBuffer.allocate(big); val inS = ByteBuffer.allocate(big)      // her tarafın gelen akışı (yazma kipinde)
    val app = ByteBuffer.allocate(big)
    var first = true
    var exchanged = false
    fun step(e: SSLEngine, inb: ByteBuffer, toPeer: ByteBuffer, isClient: Boolean): Boolean {
        when (e.handshakeStatus) {
            SSLEngineResult.HandshakeStatus.NEED_TASK -> { drain(e); return true }
            SSLEngineResult.HandshakeStatus.NEED_WRAP -> {
                val out = ByteBuffer.allocate(big)
                e.wrap(ByteBuffer.allocate(0), out); out.flip()
                var bytes = ByteArray(out.remaining()); out.get(bytes)
                if (isClient && first && bytes.isNotEmpty()) { bytes = mutate(bytes); first = false }
                if (bytes.isNotEmpty()) { toPeer.put(bytes); exchanged = true }
                return true
            }
            SSLEngineResult.HandshakeStatus.NEED_UNWRAP -> {
                inb.flip()
                if (!inb.hasRemaining()) { inb.compact(); return false }
                app.clear()
                val r = try { e.unwrap(inb, app) } catch (_: Exception) { inb.compact(); inb.clear(); return false }
                inb.compact()
                return r.status == SSLEngineResult.Status.OK
            }
            else -> return false
        }
    }
    for (i in 0 until 400) {
        val a = step(cl, inC, inS, true)
        val b = step(sv, inS, inC, false)
        if (System.getenv("DPIDBG") == "1") println("    $i c=${cl.handshakeStatus} s=${sv.handshakeStatus}")
        if (exchanged && !first && cl.handshakeStatus == SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING && sv.handshakeStatus == SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING) return true
        if (!a && !b) break
    }
    return false
}

/** [plan]'ın ürettiği parçaların birleşimi (sunucunun TCP'den gördüğü akış; acil bayt akışa girmez). */
private fun splitJoin(plan: Int, b: ByteArray): ByteArray = Dpi.split(Dpi.TLS, plan, b, b.size).fold(ByteArray(0)) { a, x -> a + x.data }

private fun realClientHello(host: String): ByteArray {
    val cctx = SSLContext.getInstance("TLS").also { it.init(null, null, null) }
    val cl = cctx.createSSLEngine(host, 443).also { it.useClientMode = true; it.sslParameters = it.sslParameters.also { p -> p.serverNames = listOf(SNIHostName(host)) } }
    val out = ByteBuffer.allocate(32768)
    cl.wrap(ByteBuffer.allocate(0), out)
    out.flip()
    return ByteArray(out.remaining()).also { out.get(it) }
}

fun runDpiSimTests() {
    T.group("DPI: gerçek TLS el sıkışması her yöntemden sonra tamamlanır (JSSE)")
    run {
        val host = "engelli.ornek.com"
        val hello = realClientHello(host)
        val h = Dpi.Hello()
        T.check("gerçek ClientHello ayrıştırılır (SNI görülür)", Dpi.parseHello(hello, hello.size, h) && h.host(hello) == host, "n=${hello.size}")
        T.check("kontrol: değiştirilmemiş ClientHello ile el sıkışma tamamlanır", jsseHandshake(host) { it })
        for (p in 0 until Dpi.TLS_PLANS) {
            val parts = Dpi.split(Dpi.TLS, p, hello, hello.size)
            val joined = parts.fold(ByteArray(0)) { a, x -> a + x.data }
            T.check("TLS yöntem $p: ${parts.size} parça, JSSE sunucusu el sıkışmayı tamamlar", parts.size >= 2 && jsseHandshake(host) { b -> splitJoin(p, b) })
        }
        val noSni = jsseHandshake(host) { it.copyOf(it.size - 3) }
        T.check("kontrol: bozuk (kesik) ClientHello ile el sıkışma tamamlanmaz", !noSni)
        for (hn in listOf("a.io", "uzun-bir-alt-alan.cok-uzun-bir-site-adi.example.org", "x.example.com")) {
            val hh = realClientHello(hn)
            T.check("TLS yöntemleri kısa/uzun adlarda da geçerli: $hn", hh.isNotEmpty() && (0 until Dpi.TLS_PLANS).all { p -> jsseHandshake(hn) { b -> splitJoin(p, b) } })
        }
    }

    T.group("DPI: HTTP yöntemleri anlamca aynı isteği taşır")
    run {
        val base = String(HTTP_REQ, Charsets.ISO_8859_1)
        fun headers(s: String): Map<String, String> {
            val t = s.trimStart('\r', '\n')
            return t.substringBefore("\r\n\r\n").split("\r\n").drop(1).associate { l -> l.substringBefore(':').lowercase() to l.substringAfter(':').trim() }
        }
        val want = headers(base)
        for (p in 0 until Dpi.HTTP_PLANS) {
            val ps = Dpi.split(Dpi.HTTP, p, HTTP_REQ, HTTP_REQ.size)
            val j = String(ps.fold(ByteArray(0)) { a, x -> a + x.data }, Charsets.ISO_8859_1)
            T.check("HTTP yöntem $p: ${ps.size} parça; istek satırı ve tüm başlıklar korunur, sonu boş satır",
                ps.size >= 2 && headers(j) == want && j.trimStart('\r', '\n').startsWith("GET /yol HTTP/1.1\r\n") && j.endsWith("\r\n\r\n"), j.replace("\r\n", "|"))
        }
        val post = "POST /a HTTP/1.1\r\nHost: x.example\r\nContent-Length: 4\r\n\r\nabcd".toByteArray()
        val ps5 = Dpi.split(Dpi.HTTP, 5, post, post.size)
        val j5 = String(ps5.fold(ByteArray(0)) { a, x -> a + x.data }, Charsets.ISO_8859_1)
        T.check("HTTP yöntem 5: gövde (POST) bozulmaz", j5.endsWith("\r\n\r\nabcd") && j5.contains("Content-Length: 4"), j5.replace("\r\n", "|"))
        val noHost = "GET / HTTP/1.0\r\n\r\n".toByteArray()
        T.check("Host'suz istekte tüm HTTP yöntemleri veriyi bozmadan tek ya da çok parça döner",
            (0 until Dpi.HTTP_PLANS).all { Dpi.split(Dpi.HTTP, it, noHost, noHost.size).fold(ByteArray(0)) { a, x -> a + x.data }.contentEquals(noHost) })
    }

    T.group("DPI: benzetim, eski ve yeni yöntem kümesi (ızgara modelleri; gerçek ağ garantisi değildir)")
    run {
        val host = "engelli.ornek.com"
        val hello = realClientHello(host)
        val tOld = tlsRun(hello, host, false)
        val tNew = tlsRun(hello, host, true)
        val hOld = httpRun(host, false)
        val hNew = httpRun(host, true)
        fun pct(a: Double, b: Double) = if (a == 0.0) 0.0 else (a - b) / a * 100
        fun line(n: String, o: SimResult, x: SimResult) {
            val fo = (o.total - o.solved).toDouble(); val fx = (x.total - x.solved).toDouble()
            println("    %-5s çözülen: %d → %d / %d   kaçırılan: %.0f → %.0f (%.0f%% az)   ort. gecikme: %.0f → %.0f ms (%.0f%% az)   ilk denemede: %.0f%% → %.0f%%".format(
                n, o.solved, x.solved, o.total, fo, fx, pct(fo, fx), o.meanMs, x.meanMs, pct(o.meanMs, x.meanMs), o.firstTry * 100, x.firstTry * 100))
        }
        line("TLS", tOld, tNew); line("HTTP", hOld, hNew)
        T.check("TLS: yeni küme eskisinden fazla modeli çözer", tNew.solved > tOld.solved, "${tOld.solved} → ${tNew.solved}")
        T.check("HTTP: yeni küme eskisinden fazla modeli çözer", hNew.solved > hOld.solved, "${hOld.solved} → ${hNew.solved}")
        T.check("TLS: kaçırılan engeller en az %50 azalır", (tOld.total - tNew.solved) * 2 <= (tOld.total - tOld.solved), "${tOld.total - tOld.solved} → ${tNew.total - tNew.solved}")
        T.check("HTTP: kaçırılan engeller en az %50 azalır", (hOld.total - hNew.solved) * 2 <= (hOld.total - hOld.solved), "${hOld.total - hOld.solved} → ${hNew.total - hNew.solved}")
        T.check("TLS: ortalama bağlantı gecikmesi en az %50 azalır", tNew.meanMs <= tOld.meanMs * 0.5, "%.0f → %.0f".format(tOld.meanMs, tNew.meanMs))
        T.check("HTTP: ortalama bağlantı gecikmesi en az %50 azalır", hNew.meanMs <= hOld.meanMs * 0.5, "%.0f → %.0f".format(hOld.meanMs, hNew.meanMs))
    }
}
