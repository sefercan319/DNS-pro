package app.dnshizli.selftest

import app.dnshizli.core.*

/**
 * Regresyon testleri: son incelemelerde bulunup düzeltilen hatalar (v1.21.1–v1.21.5) bir daha geri gelmesin diye.
 * Her blok bir hataya karşılık gelir; hatanın sürüm notu DNS_HIZLI_TARIHCE.txt'te.
 * Ayrıca "BİLİNEN AÇIKLAR" bölümü: henüz düzeltilmemiş ama kayda değer bulgular. Bunlar testi KIRMAZ; yalnızca bilgi olarak yazılır.
 */
private fun tierBytes(vararg v: Long): ByteArray {
    val o = java.io.ByteArrayOutputStream()
    o.write("DNF1".toByteArray()); o.write(byteArrayOf(0, 0, 0, v.size.toByte()))
    var prev = 0L
    for (x in v) { var d = x - prev; prev = x; while (d >= 0x80) { o.write(((d and 0x7F) or 0x80).toInt()); d = d ushr 7 }; o.write(d.toInt()) }
    return o.toByteArray()
}

fun runRegressionTests() {
    T.group("Public Suffix List (gömülü psl.txt): kayıt edilebilir alan adı")
    run {
        val f = java.io.File("app/src/main/assets/filter/psl.txt")
        T.check("psl.txt asset'i var", f.exists())
        if (f.exists()) {
            PublicSuffix.clear()
            T.check("liste yüklenmeden NOT_READY", PublicSuffix.registrableStart("a.b.com".toByteArray(), 7) == PublicSuffix.NOT_READY)
            f.inputStream().use { PublicSuffix.install(it) }
            fun site(n: String): String { val b = n.toByteArray(); val i = PublicSuffix.registrableStart(b, b.size); return n.substring(i) }
            T.check("basit: www.ornek.com → ornek.com", site("www.ornek.com") == "ornek.com")
            T.check("co.uk: a.b.site.co.uk → site.co.uk", site("a.b.site.co.uk") == "site.co.uk")
            T.check("com.tr: www.magaza.com.tr → magaza.com.tr", site("www.magaza.com.tr") == "magaza.com.tr")
            T.check("özel bölüm: a.github.io ile b.github.io ayrı", site("x.a.github.io") == "a.github.io" && site("b.github.io") == "b.github.io")
            T.check("joker kuralı: *.ck → a.b.ck", site("www.a.b.ck") == "a.b.ck")
            T.check("istisna kuralı: !www.ck → www.ck", site("x.www.ck") == "www.ck")
            T.check("ad tek başına sonek ise adın tamamı", site("co.uk") == "co.uk" && site("com") == "com")
            T.check("büyük harf ve sondaki nokta sorun çıkarmaz", site("WWW.Ornek.COM.") == "Ornek.COM.")
        }
    }

    T.group("Açık maddeler kapatıldı (v1.21.7+): akışlı filtre okuma, hafif filtre ayarı")
    run {
        val t = FilterTier.read(java.io.ByteArrayInputStream(tierBytes(5L, 300L, 70000L, 1L shl 40)))
        T.check("akışlı okuma: sıralı özetler doğru çözülür", t.size == 4 && t.contains(5L) && t.contains(300L) && t.contains(70000L) && t.contains(1L shl 40) && !t.contains(6L))
        fun fails(b: ByteArray) = try { FilterTier.read(java.io.ByteArrayInputStream(b)); false } catch (_: java.io.IOException) { true }
        val ok = tierBytes(5L, 300L)
        T.check("kesik dosya hata verir", fails(ok.copyOf(ok.size - 1)))
        T.check("fazla bayt hata verir", fails(ok + byteArrayOf(1)))
        T.check("başlık bozuksa hata verir", fails(byteArrayOf(1, 2, 3)) && fails("XXXX\u0000\u0000\u0000\u0000".toByteArray()))
        val d = AppSettings()
        T.check("filterMem varsayılan Otomatik", d.filterMem == FilterMem.AUTO)
        val back = SettingsCodec.decode(SettingsCodec.encode(d.copy(filterMem = FilterMem.LIGHT)))
        T.check("filterMem yazma/okuma gidiş dönüş", back.filterMem == FilterMem.LIGHT && SettingsCodec.decode(mapOf("filterMem" to "x")).filterMem == FilterMem.AUTO)
        T.check("Hafif'i seçmek içe aktarmada gevşeme sayılır", SensitiveChange.RULES in ImportReview.changes(d, d.copy(filterMem = FilterMem.LIGHT)))
        T.check("Hafif'ten çıkmak işaretlenmez", ImportReview.changes(d.copy(filterMem = FilterMem.LIGHT), d).none { it == SensitiveChange.RULES })
        DeviceMem.lowRam = false
        val eff = d.lightEffective() == false && d.copy(filterMem = FilterMem.LIGHT).lightEffective() && !d.copy(filterMem = FilterMem.FULL).lightEffective()
        DeviceMem.lowRam = true
        T.check("etkin hafif kip: Otomatik cihaza bakar, Hafif hep, Tam hiç", eff && d.lightEffective() && d.copy(filterMem = FilterMem.LIGHT).lightEffective() && !d.copy(filterMem = FilterMem.FULL).lightEffective())
        DeviceMem.lowRam = false
    }
    T.group("İnceleme bulguları: önbellek bayt sınırı (DeepSeek/Meta, MD-Y07)")
    run {
        var now = 0L
        val c = DnsCache(maxEntries = 64, nowMs = { now })
        val resp = ByteArray(4096) { 1 }
        for (i in 0 until 64) c.put("k$i", resp, resp.size, 10)
        T.check("sınır aşılmaz: bayt toplamı maxBytes'ı geçmez", c.byteSize() <= 64 * 1024, "bayt=${c.byteSize()}")
        now = 11_000L
        val probe = ByteArray(64)
        c.get("k0", 0, probe, 0)                       // süresi dolmuş girdiyi get temizler
        T.check("süresi dolan girdi sonrası bayt sayacı negatif değil", c.byteSize() >= 0, "bayt=${c.byteSize()}")
    }

    T.group("İnceleme bulguları: sağlama toplamı (Meta KR-Y01 — çürütüldü, yalnızca IPv4 başlığı)")
    run {
        val hdr = ByteArray(20) { (it * 7 + 1).toByte() }
        val c = Packets.checksum(hdr, 0, hdr.size)
        T.check("IPv4 başlık sağlama toplamı 16 bitlik sınırda", c in 0..0xFFFF, "c=$c")
    }

    T.group("İnceleme bulguları: çürütülenler ve tasarım gereği (bilgi)")
    println("  bilgi: DeepSeek 1 (multicast koşulu) — düzeltildi v1.21.2 (GatewayTests).")
    println("  bilgi: DeepSeek 3 (resetNetwork yarım) — düzeltildi v1.21.3 (her yuva ayrı).")
    println("  bilgi: DeepSeek 9 (pullStatus GC) — AÇIK, küçük maliyet.")
    println("  bilgi: DeepSeek 11 (SoundFx shutdown) — çürütüldü: release sonrası post sessizce düşer, zararsız.")
    println("  bilgi: DeepSeek 13 (MAX_PENDING flood) — çürütüldü: UDP istemcileri yeniden dener.")
    println("  bilgi: Gemini 2 (CnameGuard in-place okuma) — çürütüldü: soru bölümü yerinde korunur.")
    println("  bilgi: Gemini 6 (DnsForwarder paylaşımlı tampon) — çürütüldü: tek iş parçacığı (onPacket).")
    println("  bilgi: Gemini 7 (TC bayrağı önbellek) — çürütüldü: Dns.cacheTtl TC için 0 döner.")
    println("  bilgi: Gemini 8 (EDNS 512 çelişkisi) — çürütüldü: düz UDP'de bilinçli; TCP/şifreli 1232.")
    println("  bilgi: Gemini 9 (sweep yeniden deneme) — tasarım gereği: üçüncü deneme yalnızca uyarlanır kipte.")
    println("  bilgi: Gemini 10 (resolveA erken çıkış) — tasarım: ilk geçerli cevap yeterli.")
    println("  bilgi: Gemini 14 (systemExempted Play) — resmî belgede VPN uygulamaları izinli; Play beyanı doğrulanmadı.")
    println("  bilgi: Gemini 15 (Catalog isIpv4 sıfır) — düzeltildi v1.21.4 (IP testleri).")
    println("  bilgi: Meta KR-Y02 (nextPort sarması) — AÇIK: 65000'de başa döner, kullanımdaki portu atlar.")
    println("  bilgi: Meta KR-Y03 (içe aktarılan liste korunan adları) — düzeltildi v1.21.5 (FilterTests).")
    println("  bilgi: Meta MD-Y06 (1,0 bin) — düzeltildi v1.21.5 (CoreTests).")
    println("  bilgi: Meta HI-Y05 (bytesUp) — çürütüldü: UDP yükünü sayar.")
    println("  bilgi: Meta LO-Y10 (SoundFx sınırı) — düzeltildi v1.21.5 (yarışsız).")
    println("  bilgi: Meta KR-Y01 (checksum taşması) — çürütüldü: yalnızca IPv4 başlığı, Int taşmaz.")

    T.group("İnceleme bulguları: Android'e özgü, JVM'de test edilemez (bilgi)")
    println("  bilgi: DeepSeek 4 (ToneGenerator seviyesi) — düzeltildi v1.21.3 (Android'de doğrulanmadı).")
    println("  bilgi: DeepSeek 5 (MainActivity.pullStatus) — AÇIK, küçük GC maliyeti.")
    println("  bilgi: DeepSeek 6 (onRevoke yarışı) — çürütüldü: kaynaklar kilit altında bir kez alınır.")
    println("  bilgi: DeepSeek 7 (isTcp IHL) — çürütüldü: TcpDns kendi başlığını doğrular.")
    println("  bilgi: DeepSeek 8 (DnsCache String anahtar) — AÇIK, küçük GC maliyeti.")
    println("  bilgi: DeepSeek 12 (Notifier.appIntent) — çürütüldü: eylemler ayrı PendingIntent.")
    println("  bilgi: Gemini 1 (WidgetToggleReceiver yok) — çürütüldü: DnsWidget.kt içinde tanımlı.")
    println("  bilgi: Gemini 3 (Java 25 class file 69) — çürütüldü: APK CI'da derlenip kuruluyor.")
    println("  bilgi: Gemini 4 (AeroArt key sign extension) — düzeltildi v1.21.4 (maskeli).")
    println("  bilgi: Gemini 5 (swatch yarıçap donması) — düzeltildi v1.21.1 (GfxTests).")
    println("  bilgi: Gemini 11 (Dpi/SoundFx pending) — düzeltildi v1.21.5.")
    println("  bilgi: Gemini 12 (AppScope boş liste) — tasarım gereği; kullanıcıya uyarı önerildi, eklenmedi.")
    println("  bilgi: Gemini 13 (PSL eksikliği) — kısmen düzeltildi v1.21.4; tam PSL AÇIK.")
    println("  bilgi: Gemini 16 (sürüm/test sayısı tutarsızlığı) — düzeltildi v1.21.4.")
    println("  bilgi: Meta KR-Y02 dışında Meta 'orta' bulguların çoğu çürütüldü (bkz. DNS_HIZLI_TARIHCE.txt).")
}
