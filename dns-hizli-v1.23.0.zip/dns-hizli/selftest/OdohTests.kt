package app.dnshizli.selftest

import app.dnshizli.core.*
import java.math.BigInteger
import java.security.KeyFactory
import java.security.SecureRandom
import java.security.spec.NamedParameterSpec
import java.security.spec.XECPrivateKeySpec
import java.security.spec.XECPublicKeySpec
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.KeyAgreement

private fun String.h(): ByteArray = chunked(2).map { it.toInt(16).toByte() }.toByteArray()
private fun ByteArray.x(): String = joinToString("") { "%02x".format(it) }

/** ODoH: şifreleme (RFC 7748 / 9180 vektörleri), yapılandırma ayrıştırma, ileti biçimi, yol tahtası, anahtar önbelleği, katalog. */
fun runOdohTests() {
    cryptoTests()
    configTests()
    messageTests()
    boardTests()
    keyringTests()
    catalogTests()
    addressTests()
    settingsTests()
}

// ------------------------------------------------------------------------------------------------ şifreleme

private fun cryptoTests() {
    T.group("ODoH: X25519 (RFC 7748 vektörleri + JDK çapraz doğrulama)")
    val k = "a546e36bf0527c9d3b16154b82465edd62144c0ac1fc5a18506a2244ba449ac4".h()
    val u = "e6db6867583030db3594c1a424b15f7c726624ec26b3353b10a903a6d0ab1c4c".h()
    T.check("§5.2 vektör 1", X25519.shared(k, u)!!.x() == "c3da55379de9c6908e94ea4df28d084f32eccf03491c71f754b4075577a28552")
    val aPriv = "77076d0a7318a57d3c16c17251b26645df4c2f87ebc0992ab177fba51db92c2a".h()
    val aPub = "8520f0098930a754748b7ddcb43ef75a0dbf3a0d26381af4eba4a98eaa9b4e6a"
    val bPriv = "5dab087e624a8a4b79e17f8b83800ee66f3bb1292618b6fd1c2f8b27ff88e0eb".h()
    val bPub = "de9edb7d7b7dc1b4d35b61c2ece435373f8343c85b78674dadfc7e146f882b4f"
    val sh = "4a5d9d5ba4ce2de1728e3bf480350f25e07e21c947d19e3376f09b3c1e161742"
    T.check("§6.1 açık anahtarlar", X25519.publicKey(aPriv).x() == aPub && X25519.publicKey(bPriv).x() == bPub)
    T.check("§6.1 ortak sır iki yönde", X25519.shared(aPriv, bPub.h())!!.x() == sh && X25519.shared(bPriv, aPub.h())!!.x() == sh)
    T.check("tümü sıfır ortak sır reddedilir (düşük dereceli nokta)", X25519.shared(aPriv, ByteArray(32)) == null)
    val rng = SecureRandom()
    val kf = KeyFactory.getInstance("XDH")
    val ka = KeyAgreement.getInstance("XDH")
    var bad = 0
    for (i in 0 until 300) {
        val a = ByteArray(32).also { rng.nextBytes(it) }
        val b = ByteArray(32).also { rng.nextBytes(it) }
        val pubB = X25519.publicKey(b)
        val mine = X25519.shared(a, pubB)!!
        ka.init(kf.generatePrivate(XECPrivateKeySpec(NamedParameterSpec.X25519, a)))
        ka.doPhase(kf.generatePublic(XECPublicKeySpec(NamedParameterSpec.X25519, BigInteger(1, pubB.reversedArray()))), true)
        if (!ka.generateSecret().contentEquals(mine)) bad++
    }
    T.check("300 rastgele çift JDK XDH ile aynı sonucu verir", bad == 0, "bad=$bad")

    T.group("ODoH: HPKE (RFC 9180 Ek A.1)")
    val skEm = "52c4a758a802cd8b936eceea314432798d5baf2d7e9235dc084ab1b9cfa2f736".h()
    val pkEm = "37fda3567bdbd628e88668c3c8d7e97d1d1253b6d4ea6d44c150f741f1bf4431"
    val skRm = "4612c550263fc8ad58375df3f557aac531d26850903e55a9f23f21d8534e8ac8".h()
    val pkRm = "3948cfe0ad1ddb695d780e59077195da6c56506b027329794ab02bca80815c4d".h()
    val info = "4f6465206f6e2061204772656369616e2055726e".h()
    val aad0 = "436f756e742d30".h()
    val pt = "4265617574792069732074727574682c20747275746820626561757479".h()
    val s = Hpke.setupBaseS(pkRm, info, rng, skEm)!!
    T.check("enc", s.enc.x() == pkEm)
    val ct0 = s.context.seal(aad0, pt)
    T.check("ilk şifreli metin", ct0.x() == "f938558b5d72f1a23810b4be2ab4f84331acc02fc97babc53a52ae8218a355a96d8770ac83d07bea87e13c512a")
    T.check("dışa aktarma", s.context.export(ByteArray(0), 32).x() == "3853fe2b4035195a573ffc53856e77058e15d9ea064de3e59f4961d0095250ee")
    val r = Hpke.setupBaseR(s.enc, skRm, info)!!
    T.check("alıcı çözer", r.open(aad0, ct0)?.contentEquals(pt) == true)
    T.check("yanlış AAD reddedilir", Hpke.setupBaseR(s.enc, skRm, info)!!.open("436f756e742d39".h(), ct0) == null)
    val bent = ct0.copyOf().also { it[3] = (it[3].toInt() xor 1).toByte() }
    T.check("bozulmuş şifreli metin reddedilir", Hpke.setupBaseR(s.enc, skRm, info)!!.open(aad0, bent) == null)
    T.check("geçersiz uzunlukta anahtar reddedilir", Hpke.setupBaseS(ByteArray(31), info, rng) == null)
    val a = Hpke.setupBaseS(pkRm, info, rng)!!
    val b = Hpke.setupBaseS(pkRm, info, rng)!!
    T.check("her kurulumda taze geçici anahtar", !a.enc.contentEquals(b.enc))
}

// ------------------------------------------------------------------------------------------------ yapılandırma

internal fun u16b(v: Int) = byteArrayOf((v ushr 8).toByte(), v.toByte())

/** ObliviousDoHConfigs seri hâli (tek yapılandırma). */
internal fun odohConfigBytes(pk: ByteArray, version: Int = 1, kem: Int = 0x20, kdf: Int = 1, aead: Int = 1): ByteArray {
    val contents = u16b(kem) + u16b(kdf) + u16b(aead) + u16b(pk.size) + pk
    val cfg = u16b(version) + u16b(contents.size) + contents
    return u16b(cfg.size) + cfg
}

private fun configTests() {
    T.group("ODoH: yapılandırma ayrıştırma")
    val pk = X25519.publicKey(ByteArray(32) { (it + 1).toByte() })
    val good = odohConfigBytes(pk)
    val parsed = OdohConfigs.parse(good)
    T.check("geçerli yapılandırma", parsed.size == 1 && parsed[0].publicKey.contentEquals(pk))
    T.check("anahtar kimliği 32 bayt ve kararlı", parsed[0].keyId.size == 32 && parsed[0].keyId.contentEquals(OdohConfigs.parse(good)[0].keyId))
    fun kind(b: ByteArray): OdohError? = try { OdohConfigs.parse(b); null } catch (e: OdohException) { e.kind }
    T.check("boş girdi", kind(ByteArray(0)) == OdohError.BAD_CONFIG)
    T.check("tek bayt", kind(ByteArray(1)) == OdohError.BAD_CONFIG)
    T.check("uzunluk öneki uyuşmuyor", kind(good.copyOf().also { it[1] = (it[1] + 1).toByte() }) == OdohError.BAD_CONFIG)
    T.check("kesik gövde", kind(good.copyOf(good.size - 3)) == OdohError.BAD_CONFIG)
    T.check("içerik uzunluğu taşıyor", kind(good.copyOf().also { it[5] = (it[5] + 9).toByte() }) == OdohError.BAD_CONFIG)
    T.check("açık anahtar uzunluğu uyuşmuyor", kind(good.copyOf().also { it[13] = 31 }) == OdohError.BAD_CONFIG)
    T.check("32 bayttan kısa anahtar (tutarlı) desteklenmez", kind(odohConfigBytes(pk.copyOf(31))) == OdohError.NO_SUPPORTED_CONFIG)
    T.check("bilinmeyen sürüm atlanır → desteklenen yok", kind(odohConfigBytes(pk, version = 0x0002)) == OdohError.NO_SUPPORTED_CONFIG)
    T.check("bilinmeyen KEM atlanır", kind(odohConfigBytes(pk, kem = 0x10)) == OdohError.NO_SUPPORTED_CONFIG)
    T.check("bilinmeyen KDF atlanır", kind(odohConfigBytes(pk, kdf = 2)) == OdohError.NO_SUPPORTED_CONFIG)
    T.check("bilinmeyen AEAD atlanır", kind(odohConfigBytes(pk, aead = 3)) == OdohError.NO_SUPPORTED_CONFIG)
    val mixed = run {
        val a = odohConfigBytes(pk, version = 2).let { it.copyOfRange(2, it.size) }
        val b = odohConfigBytes(pk).let { it.copyOfRange(2, it.size) }
        u16b(a.size + b.size) + a + b
    }
    T.check("karışık listede desteklenen seçilir", OdohConfigs.parse(mixed).size == 1)
    val many = run {
        val one = odohConfigBytes(pk).let { it.copyOfRange(2, it.size) }
        val all = ByteArray(0).let { var acc = it; repeat(17) { acc += one }; acc }
        u16b(all.size) + all
    }
    T.check("çok fazla yapılandırma reddedilir", kind(many) == OdohError.BAD_CONFIG)
    T.check("aşırı büyük girdi reddedilir", kind(ByteArray(70_000)) == OdohError.BAD_CONFIG)
    val rng = java.util.Random(7)
    var crashed = 0
    repeat(3000) {
        val b = good.copyOf()
        repeat(1 + rng.nextInt(4)) { b[rng.nextInt(b.size)] = rng.nextInt(256).toByte() }
        val cut = if (rng.nextBoolean()) b else b.copyOf(rng.nextInt(b.size + 1))
        try { OdohConfigs.parse(cut) } catch (_: OdohException) {} catch (_: Throwable) { crashed++ }
    }
    T.check("3000 bozuk girdi: yalnızca OdohException (çökme yok)", crashed == 0, "crashed=$crashed")
}

// ------------------------------------------------------------------------------------------------ ileti biçimi

private fun messageTests() {
    T.group("ODoH: sorgu/cevap iletisi (RFC 9230)")
    val rng = SecureRandom()
    val sk = X25519.generatePrivate(rng)
    val cfg = OdohConfigs.parse(odohConfigBytes(X25519.publicKey(sk)))[0]
    val dns = Dns.buildQuery(0, "example.com")
    val q = OdohClient.seal(cfg, dns, rng)
    val w = q.wire
    T.check("tür 1, anahtar kimliği öneki", w[0].toInt() == 1 && ((w[1].toInt() and 0xFF) shl 8 or (w[2].toInt() and 0xFF)) == 32 && w.copyOfRange(3, 35).contentEquals(cfg.keyId))
    val encLen = ((w[35].toInt() and 0xFF) shl 8) or (w[36].toInt() and 0xFF)
    T.check("şifreli yük uzunluğu gövdeyle uyumlu", 37 + encLen == w.size)
    T.check("DNS adı iletide açık görünmüyor", String(w, Charsets.ISO_8859_1).indexOf("example") < 0)
    val ctx = Hpke.setupBaseR(w.copyOfRange(37, 69), sk, "odoh query".toByteArray())!!
    val aad = byteArrayOf(1, 0, 32) + cfg.keyId
    val plain = ctx.open(aad, w.copyOfRange(69, w.size))
    T.check("hedef sorguyu çözer", plain != null)
    plain!!
    val dl = ((plain[0].toInt() and 0xFF) shl 8) or (plain[1].toInt() and 0xFF)
    T.check("düz metin: DNS aynen", dl == dns.size && plain.copyOfRange(2, 2 + dl).contentEquals(dns))
    T.check("düz metin 128'in katı ve dolgu sıfır", plain.size % 128 == 0 && plain.copyOfRange(4 + dl, plain.size).all { it.toInt() == 0 })
    val long = Dns.buildQuery(0, "a-very-long-label-to-push-the-size-past-one-block.another-quite-long-label-here.example.org")
    T.check("uzun sorguda da 128'in katı", OdohClient.seal(cfg, long, rng).let { qq ->
        val c2 = Hpke.setupBaseR(qq.wire.copyOfRange(37, 69), sk, "odoh query".toByteArray())!!
        c2.open(aad, qq.wire.copyOfRange(69, qq.wire.size))!!.size % 128 == 0
    })
    T.check("iki sorgu aynı baytlara şifrelenmez", !OdohClient.seal(cfg, dns, rng).wire.contentEquals(OdohClient.seal(cfg, dns, rng).wire))
    T.check("çok kısa DNS reddedilir", runCatching { OdohClient.seal(cfg, ByteArray(5), rng) }.exceptionOrNull() is OdohException)

    // Cevap: bağımsız (sunucu tarafı) uygulama ile
    fun respond(wire: ByteArray, dnsAnswer: ByteArray, tweak: (String, ByteArray) -> ByteArray = { _, b -> b }): ByteArray = SimTarget.respondTo(sk, cfg.keyId, wire, dnsAnswer, tweak)
    val ans = answer(dns, dns.size, listOf(byteArrayOf(1, 2, 3, 4)))
    val qa = OdohClient.seal(cfg, dns, rng)
    val ok = respond(qa.wire, ans)
    T.check("geçerli cevap çözülür", qa.open(ok, 0, ok.size).contentEquals(ans))
    fun failKind(tweak: (String, ByteArray) -> ByteArray): OdohError? {
        val qq = OdohClient.seal(cfg, dns, rng)
        val body = respond(qq.wire, ans, tweak)
        return try { qq.open(body, 0, body.size); null } catch (e: OdohException) { e.kind }
    }
    T.check("bozulmuş şifreli cevap → AUTH", failKind { stage, b -> if (stage == "ct") b.also { it[it.size - 1] = (it[it.size - 1].toInt() xor 1).toByte() } else b } == OdohError.AUTH)
    T.check("sıfır olmayan dolgu → BAD_RESPONSE", failKind { stage, b -> if (stage == "plain") b.also { it[it.size - 1] = 1 } else b } == OdohError.BAD_RESPONSE)
    T.check("yanlış tür → BAD_RESPONSE", failKind { stage, b -> if (stage == "wire") b.also { it[0] = 1 } else b } == OdohError.BAD_RESPONSE)
    T.check("yanlış nonce uzunluğu → BAD_RESPONSE", failKind { stage, b -> if (stage == "wire") b.also { it[2] = 12 } else b } == OdohError.BAD_RESPONSE)
    T.check("kesik cevap → BAD_RESPONSE", failKind { stage, b -> if (stage == "wire") b.copyOf(b.size - 5) else b } != null)
    T.check("nonce değişirse → AUTH", failKind { stage, b -> if (stage == "wire") b.also { it[5] = (it[5].toInt() xor 1).toByte() } else b } == OdohError.AUTH)
    val qb = OdohClient.seal(cfg, dns, rng)
    val other = respond(OdohClient.seal(cfg, dns, rng).wire, ans)
    T.check("başka sorgunun cevabı → AUTH", runCatching { qb.open(other, 0, other.size) }.exceptionOrNull().let { it is OdohException && it.kind == OdohError.AUTH })
    val qc = OdohClient.seal(cfg, dns, rng)
    val fine = respond(qc.wire, ans)
    qc.open(fine, 0, fine.size)
    T.check("gizli bilgi kullanımdan sonra silinir (tekrar açılamaz)", runCatching { qc.open(fine, 0, fine.size) }.isFailure)
    T.check("aralık dışı → BAD_RESPONSE", runCatching { OdohClient.seal(cfg, dns, rng).open(ok, 0, ok.size + 5) }.exceptionOrNull().let { it is OdohException && it.kind == OdohError.BAD_RESPONSE })
    var crashes = 0
    val jr = java.util.Random(11)
    repeat(2000) {
        val qq = OdohClient.seal(cfg, dns, rng)
        val b = respond(qq.wire, ans).let { g -> if (jr.nextBoolean()) g.copyOf(jr.nextInt(g.size + 1)) else g.also { for (k in 0 until 3) it[jr.nextInt(it.size)] = jr.nextInt(256).toByte() } }
        try { qq.open(b, 0, b.size) } catch (_: OdohException) {} catch (_: Throwable) { crashes++ }
    }
    T.check("2000 bozuk cevap: yalnızca OdohException", crashes == 0, "crashes=$crashes")

    T.group("ODoH: röle yolu")
    T.check("temel biçim", OdohClient.relayPath("/", "odoh.cloudflare-dns.com", "/dns-query") == "/?targethost=odoh.cloudflare-dns.com&targetpath=%2Fdns-query")
    T.check("röle yolunda soru işareti varsa &", OdohClient.relayPath("/relay?k=1", "h.test", "/q") == "/relay?k=1&targethost=h.test&targetpath=%2Fq")
    T.check("özel karakterler yüzde-kodlanır", OdohClient.relayPath("/", "a b", "/x?y=z&w").let { it.contains("a%20b") && it.contains("%2Fx%3Fy%3Dz%26w") })
}

// ------------------------------------------------------------------------------------------------ yol tahtası

private fun boardTests() {
    T.group("ODoH: yol tahtası (devre kesici)")
    val clock = AtomicLong(1_000_000)
    val b = OdohPathBoard(3, { clock.get() }, java.util.Random(1))
    T.check("başlangıçta en küçük indis", b.choose() == 0)
    b.success(0, 100); b.success(1, 50); b.success(2, 200)
    T.check("en düşük gecikme seçilir", b.choose() == 1)
    T.check("avoid sona atılır", b.choose(avoid = 1L shl 1) != 1)
    b.failure(1)
    T.check("tek hata yolu kesmez (ama puanı kötüleşir)", b.snapshot()[1].open.not() && b.snapshot()[1].fails == 1)
    b.failure(1)
    T.check("üst üste iki hata devreyi açar", b.snapshot()[1].open)
    T.check("açık yol seçilmez", (1..30).all { b.choose() != 1 })
    clock.addAndGet(1_000)
    T.check("bekleme dolmadan hâlâ açık", b.snapshot()[1].open)
    clock.addAndGet(4_000)
    T.check("süre dolunca yarı açık: seçilebilir", !b.snapshot()[1].open)
    b.success(1, 40)
    T.check("başarı devreyi kapatır", b.snapshot()[1].fails == 0 && !b.snapshot()[1].open)

    // yarı açık: tek deneme
    val h = OdohPathBoard(2, { clock.get() }, java.util.Random(9))
    h.success(0, 500); h.success(1, 10)
    h.failure(1); h.failure(1)
    clock.addAndGet(5_000)
    T.check("yarı açık yol (en iyi puanlı) denenir", h.choose() == 1)
    T.check("deneme sürerken aynı yola ikinci sorgu gitmez", h.choose() == 0)
    clock.addAndGet(7_000)
    T.check("sonuç gelmezse deneme süresi dolunca yeniden serbest", h.choose() == 1)

    // üstel geri çekilme + üst sınır
    val c = OdohPathBoard(1, { clock.get() }, java.util.Random(2))
    val waits = ArrayList<Long>()
    repeat(9) {
        c.failure(0); c.failure(0)       // her turda yeniden açılır (OPEN_AFTER=2 → ilk hatadan sonra zaten fails>=2 sonraki hatalar da tetikler)
        var w = 0L
        while (c.snapshot()[0].open && w < 400_000) { clock.addAndGet(500); w += 500 }
        waits.add(w)
        clock.addAndGet(0)
    }
    T.check("bekleme artar", waits[0] <= waits[3] && waits[3] <= waits[8], waits.toString())
    T.check("bekleme en çok ~150 sn (120 sn + sapma)", waits.max() <= 150_000, waits.toString())
    T.check("ilk bekleme ~2-3 sn", waits[0] in 1_500..3_500, waits[0].toString())

    // ölümcül hata
    val d = OdohPathBoard(2, { clock.get() }, java.util.Random(3))
    d.failure(0, fatal = true)
    T.check("ölümcül hata hemen açar", d.snapshot()[0].open)
    clock.addAndGet(30_000)
    T.check("ölümcül hata ≥ 48 sn açık kalır", d.snapshot()[0].open)
    clock.addAndGet(40_000)
    T.check("sonra yarı açık", !d.snapshot()[0].open)

    // hepsi açık
    val e = OdohPathBoard(3, { clock.get() }, java.util.Random(4))
    e.failure(0, true); clock.addAndGet(100); e.failure(1, true); clock.addAndGet(100); e.failure(2, true)
    T.check("hepsi açık bildirilir", e.allOpen())
    T.check("hepsi açıkken en erken dolacak yol seçilir (asla 'yol yok' olmaz)", e.choose() == 0)
    T.check("çok iş parçacıklı seçim hata vermez", run {
        val bb = OdohPathBoard(4, { clock.get() }, java.util.Random(5))
        val bad = AtomicInteger()
        val ts = (0 until 8).map { t -> Thread { repeat(2000) { i -> try { val p = bb.choose(); if (i % 3 == 0) bb.failure(p) else bb.success(p, 20L + t) } catch (_: Throwable) { bad.incrementAndGet() } } } }
        ts.forEach { it.start() }; ts.forEach { it.join() }
        bad.get() == 0
    })
    // keşif
    val f = OdohPathBoard(2, { clock.get() }, java.util.Random(6))
    f.success(0, 30); f.success(1, 60)
    clock.addAndGet(200_000)
    var explored = false
    repeat(60) { if (f.choose() == 1) explored = true }
    T.check("bayatlayan ikinci yol zaman zaman denenir (keşif)", explored)
    f.reset()
    T.check("ağ değişince gecikme bilgisi silinir", f.snapshot().all { it.rttMs.isNaN() && it.fails == 0 })
}

// ------------------------------------------------------------------------------------------------ anahtar önbelleği

private fun keyringTests() {
    T.group("ODoH: anahtar önbelleği")
    val clock = AtomicLong(0)
    val cfgA = odohConfigBytes(X25519.publicKey(ByteArray(32) { 1 }))
    val cfgB = odohConfigBytes(X25519.publicKey(ByteArray(32) { 2 }))
    var current = cfgA
    val fetches = AtomicInteger()
    var failing = false
    val kr = OdohKeyring({ _ -> fetches.incrementAndGet(); if (failing) throw java.io.IOException("ağ yok"); current }, { clock.get() }, ttlMs = 1000, staleMaxMs = 10_000, failBackoffMs = 100, minForceMs = 300)
    val a = kr.current("t")
    T.check("ilk çağrı alır", fetches.get() == 1)
    kr.current("t")
    T.check("taze iken önbellekten", fetches.get() == 1)
    clock.addAndGet(1500)
    current = cfgB
    val b = kr.current("t")
    T.check("süre dolunca yenilenir ve yeni anahtarı alır", fetches.get() == 2 && !b.keyId.contentEquals(a.keyId))
    // bayat anahtar
    clock.addAndGet(1500)
    failing = true
    val st = kr.current("t")
    T.check("alım başarısız: bayat anahtarla devam", st.keyId.contentEquals(b.keyId) && fetches.get() == 3)
    kr.current("t")
    T.check("hatadan sonra bekleme süresince ağ dövülmez", fetches.get() == 3)
    clock.addAndGet(150)
    kr.current("t")
    T.check("bekleme sonrası yeniden denenir", fetches.get() == 4)
    clock.addAndGet(20_000)
    T.check("bayatlık sınırı aşılınca hata verir", runCatching { kr.current("t") }.exceptionOrNull().let { it is OdohException && it.kind == OdohError.CONFIG_FETCH })
    failing = false
    clock.addAndGet(200)
    T.check("ağ gelince toparlanır", kr.current("t").keyId.contentEquals(b.keyId) && fetches.get() >= 6)
    // 401
    val before = fetches.get()
    current = cfgA
    clock.addAndGet(400)
    kr.reject("t", b.keyId)
    val c = kr.current("t")
    T.check("401 sonrası zorunlu yenileme yeni anahtarı alır", fetches.get() == before + 1 && c.keyId.contentEquals(a.keyId))
    kr.reject("t", c.keyId)
    kr.current("t")
    T.check("hız sınırı: art arda 401 yeni alım yağdırmaz", fetches.get() == before + 1)
    clock.addAndGet(350)
    kr.current("t")
    T.check("bekleyen zorunlu yenileme süre dolunca yerine getirilir", fetches.get() == before + 2)
    kr.reject("t", b.keyId)       // eski anahtara ait geç 401
    kr.current("t")
    T.check("geç gelen eski 401 yok sayılır", fetches.get() == before + 2)
    // tek uçuş
    val kr2 = OdohKeyring({ _ -> Thread.sleep(150); fetches.incrementAndGet(); cfgA }, { clock.get() })
    val n0 = fetches.get()
    val go = CountDownLatch(1)
    val ts = (0 until 8).map { Thread { go.await(); kr2.current("x") } }
    ts.forEach { it.start() }; go.countDown(); ts.forEach { it.join() }
    T.check("8 eşzamanlı çağrı tek alım yapar", fetches.get() == n0 + 1)
    T.check("bozuk yapılandırma hata verir ve önbelleğe girmez", run {
        val k3 = OdohKeyring({ _ -> byteArrayOf(0, 1, 2) }, { clock.get() })
        runCatching { k3.current("z") }.exceptionOrNull().let { it is OdohException && k3.cachedKeyId("z") == null }
    })
}

// ------------------------------------------------------------------------------------------------ katalog

private fun catalogTests() {
    T.group("ODoH: katalog ve bağımsızlık")
    T.check("en az 2 röle ve 3 hedef", OdohCatalog.relays.size >= 2 && OdohCatalog.targets.size >= 3)
    val all = OdohCatalog.relays + OdohCatalog.targets
    T.check("kimlikler benzersiz", all.map { it.id }.toSet().size == all.size)
    T.check("her düğümün ipucu adresi var ve geçerli", all.all { n -> n.ips.isNotEmpty() && n.ips.all { Ip.isV4(it) && Ip.parse(it) != null } })
    T.check("ipucu adresleri herkese açık (özel aralık yok)", all.all { n -> n.ips.all { ip -> val p = ip.split('.').map { it.toInt() }; Dns.isGlobalIpv4(p[0], p[1], p[2], p[3]) } })
    T.check("yollar boş değil", OdohCatalog.pairs().size >= 4)
    T.check("hiçbir yolda röle ve hedef aynı işletmeci değil", OdohCatalog.pairs().all { OdohCatalog.relays[it.relay].group != OdohCatalog.targets[it.target].group })
    T.check("hiçbir yolda aynı alan adı yok", OdohCatalog.pairs().all { OdohCatalog.domainOf(OdohCatalog.relays[it.relay].host) != OdohCatalog.domainOf(OdohCatalog.targets[it.target].host) })
    val r = OdohNode("r", "R", "g1", "relay.example.net", "/")
    T.check("aynı grup eşleşmez", !OdohCatalog.independent(r, OdohNode("t", "T", "g1", "t.example.org", "/q")))
    T.check("aynı alan adı eşleşmez", !OdohCatalog.independent(r, OdohNode("t", "T", "g2", "dns.example.net", "/q")))
    T.check("aynı ad eşleşmez", !OdohCatalog.independent(r, OdohNode("t", "T", "g2", "relay.example.net", "/q")))
    T.check("bağımsız çift eşleşir", OdohCatalog.independent(r, OdohNode("t", "T", "g2", "t.example.org", "/q")))
    T.check("tüm yollar bağımlıysa kurucu reddeder", runCatching {
        OdohEngine(listOf(r), listOf(OdohNode("t", "T", "g1", "t.example.org", "/q")), { 0L }, SecureRandom(), { ByteArray(0) }, OdohAddressBook({ 0L }))
    }.isFailure)
    T.check("bağımlı çifti elle verilse de kurucu reddeder", runCatching {
        OdohEngine(listOf(r), listOf(OdohNode("t", "T", "g1", "t.example.org", "/q")), { 0L }, SecureRandom(), { ByteArray(0) }, OdohAddressBook({ 0L }), pairs = listOf(OdohPathSpec(0, 0)))
    }.isFailure)
    T.check("geçersiz düğüm reddedilir", runCatching { OdohNode("x", "X", "g", "bad host", "/") }.isFailure && runCatching { OdohNode("x", "X", "g", "h.test", "no-slash") }.isFailure)
    T.check("Proto.ODOH adı", app.dnshizli.ui.Strings.protoName(Proto.ODOH) == "ODoH")
}

// ------------------------------------------------------------------------------------------------ adres defteri

private fun addressTests() {
    T.group("ODoH: adres defteri")
    val clock = AtomicLong(0)
    val resolves = AtomicInteger()
    val node = OdohNode("n", "N", "g", "n.example.net", "/", listOf("1.1.1.1", "1.0.0.1"))
    val book = OdohAddressBook({ clock.get() }, resolve = { resolves.incrementAndGet(); listOf("9.9.9.9", "10.0.0.1", "not-an-ip") }, resolveTtlMs = 1000, resolveCooldownMs = 500)
    fun ips(more: Boolean = false) = book.addresses(node, 443, more).map { it.address.hostAddress }
    T.check("başlangıçta ipuçları, 443 portu", ips() == listOf("1.1.1.1", "1.0.0.1") && book.addresses(node)[0].port == 443)
    T.check("gerekmedikçe çözümleme yapılmaz", resolves.get() == 0)
    book.markGood(node, java.net.InetSocketAddress(java.net.InetAddress.getByName("1.0.0.1"), 443))
    T.check("son çalışan adres öne geçer, yineleme yok", ips() == listOf("1.0.0.1", "1.1.1.1"))
    T.check("çözümleme sonucu sona eklenir; geçersiz yazımlar elenir", ips(true) == listOf("1.0.0.1", "1.1.1.1", "9.9.9.9", "10.0.0.1"))
    val n1 = resolves.get()
    ips(true); ips(true)
    T.check("çözümleme önbelleğe alınır / hız sınırlıdır", resolves.get() == n1)
    clock.addAndGet(1500)
    ips(true)
    T.check("süre dolunca yenilenir", resolves.get() == n1 + 1)
    val noRes = OdohAddressBook({ 0L })
    T.check("çözücü yoksa ipuçlarına düşer", noRes.addresses(node, 443, true).size == 2)
    val boom = OdohAddressBook({ 0L }, resolve = { throw RuntimeException("x") })
    T.check("çözücü hata verirse ipuçları kalır", boom.addresses(node, 443, true).size == 2)
    book.forgetGood()
    T.check("forgetGood son adresi siler", book.lastGood(node) == null)
}

// ------------------------------------------------------------------------------------------------ ayarlar ve plan

private fun settingsTests() {
    T.group("ODoH: ayar, plan ve geçiş kuralları")
    val d = AppSettings()
    val cf = Catalog.byId("cloudflare")!!
    T.check("varsayılan kapalı", d.odoh == OdohMode.OFF)
    T.check("kapalıyken plan değişmez", d.plan(cf) == d.encryption.plan(cf, d.strictEncryption) && Proto.ODOH !in d.plan(cf))
    val fb = d.copy(odoh = OdohMode.FALLBACK).plan(cf)
    T.check("yedekli: önce ODoH, sonra normal sıra", fb.first() == Proto.ODOH && fb.drop(1) == d.plan(cf))
    T.check("sıkı: yalnızca ODoH", d.copy(odoh = OdohMode.STRICT).plan(cf) == listOf(Proto.ODOH))
    T.check("sıkıda düz DNS asla planda yok (şifreleme Kapalı olsa bile)", Proto.PLAIN !in d.copy(odoh = OdohMode.STRICT, encryption = Encryption.OFF).plan(cf))
    val onlyPlain = Catalog.all.firstOrNull { !it.encrypted && it.plain }
    T.check("şifreli desteği olmayan sunucuda da ODoH çalışır (sunucudan bağımsız)", onlyPlain == null || d.copy(odoh = OdohMode.STRICT).plan(onlyPlain) == listOf(Proto.ODOH))
    for (m in OdohMode.values()) T.check("gidiş-dönüş: ${m.id}", SettingsCodec.decode(SettingsCodec.encode(d.copy(odoh = m))).odoh == m)
    T.check("eski kayıtlarda alan yok → kapalı", SettingsCodec.decode(mapOf("encryption" to "auto")).odoh == OdohMode.OFF)
    T.check("bozuk değer → kapalı", SettingsCodec.decode(mapOf("odoh" to "belki")).odoh == OdohMode.OFF)
    T.check("içe aktarmada ODoH'u kapatmak uyarılır", ImportReview.changes(d.copy(odoh = OdohMode.STRICT), d).contains(SensitiveChange.ENCRYPTION_WEAKER))
    T.check("yedekliden sıkıya geçmek uyarı gerektirmez", !ImportReview.changes(d.copy(odoh = OdohMode.FALLBACK), d.copy(odoh = OdohMode.STRICT)).contains(SensitiveChange.ENCRYPTION_WEAKER))
    T.check("açıklamalar 12 dilde dolu", Lang.values().map { L.of(it) }.all { tx -> tx.ODOH.isNotBlank() && tx.OPT_ODOH.size == 3 && tx.OPT_ODOH.all { it.isNotBlank() } &&
        tx.ODOH_NOTE.isNotBlank() && tx.DOWNGRADED_ODOH.isNotBlank() && tx.NOTIF_ODOH_TITLE.isNotBlank() && tx.notifOdoh("X").contains("X") && tx.ERR_NO_ODOH.isNotBlank() })
    T.check("İngilizce dışındaki dillerde ODoH metinleri çevrilmiş", Lang.values().filter { it != Lang.EN }.all { l -> L.of(l).ODOH_NOTE != TxEn.ODOH_NOTE && L.of(l).ERR_NO_ODOH != TxEn.ERR_NO_ODOH })
    T.check("ODoH açıklaması makul uzunlukta (satıra sığar)", Lang.values().all { L.of(it).ODOH_NOTE.length <= 260 })
}
