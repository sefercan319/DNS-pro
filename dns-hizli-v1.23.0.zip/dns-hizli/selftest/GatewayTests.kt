package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

private val CLI4 = byteArrayOf(10, 111, 222.toByte(), 1)
private val LO4 = byteArrayOf(127, 0, 0, 1)
private const val F_FIN = Gw.FIN
private const val F_SYN = Gw.SYN
private const val F_RST = Gw.RST
private const val F_PSH = Gw.PSH
private const val F_ACK = Gw.ACK

private class GSeg(val flags: Int, val seq: Int, val ack: Int, val win: Int, val data: ByteArray, val mss: Int, val ok: Boolean, val sport: Int, val dport: Int)

private class GRig(ttl: (java.net.Socket, Int) -> Boolean = { _, _ -> false }) {
    val q = LinkedBlockingQueue<ByteArray>()
    val gw = Gateway({ b, o, l -> q.add(b.copyOfRange(o, o + l)) }, setTtl = ttl)
    init { gw.start() }
    fun close() = gw.stop()
}

private val portCounter = AtomicInteger(41000)

private class GCli(val r: GRig, val dport: Int, val v6: Boolean = false, val dst: ByteArray = LO4) {
    val sport = portCounter.incrementAndGet()
    val src: ByteArray = if (v6) SelfTest.CLIENT6 else CLI4
    var seq = 7000
    var rcv = 0
    var win = 65535
    val buf = ByteArray(2048)

    fun send(flags: Int, data: ByteArray = ByteArray(0), mss: Int = 0, seqNo: Int = seq, ackNo: Int = rcv) {
        val n = Gw.tcp(buf, v6, src, dst, sport, dport, seqNo, ackNo, flags, win, data, 0, data.size, mss)
        r.gw.onPacket(buf.copyOf(n), n)
    }

    fun next(ms: Long = 3000): GSeg? {
        val end = System.currentTimeMillis() + ms
        while (true) {
            val left = end - System.currentTimeMillis()
            if (left <= 0) return null
            val p = r.q.poll(left, TimeUnit.MILLISECONDS) ?: return null
            val ver = (p[0].toInt() ushr 4) and 0xF
            val ip = if (ver == 6) 40 else (p[0].toInt() and 0xF) * 4
            val proto = if (ver == 6) p[6].toInt() and 0xFF else p[9].toInt() and 0xFF
            if (proto != 6 || Packets.u16(p, ip) != dport || Packets.u16(p, ip + 2) != sport) continue
            val doff = (p[ip + 12].toInt() and 0xF0) ushr 2
            var mss = 0
            if (doff >= 24 && p[ip + 20].toInt() == 2) mss = Packets.u16(p, ip + 22)
            return GSeg(p[ip + 13].toInt() and 0xFF, Packets.i32(p, ip + 4), Packets.i32(p, ip + 8), Packets.u16(p, ip + 14),
                p.copyOfRange(ip + doff, p.size), mss, Gw.checksumOk(p, p.size), dport, sport)
        }
    }

    fun connect(): GSeg? {
        send(F_SYN, mss = 1460); seq++
        val sa = next() ?: return null
        if (sa.flags != (F_SYN or F_ACK)) return sa
        rcv = sa.seq + 1
        send(F_ACK)
        return sa
    }

    fun write(d: ByteArray) { send(F_ACK or F_PSH, d); seq += d.size }

    /** [n] bayt gelene dek veri segmentlerini toplar ve hepsini onaylar. Fin görürse durur. */
    fun read(n: Int, ms: Long = 4000): ByteArray {
        val o = ByteArrayOutputStream()
        val end = System.currentTimeMillis() + ms
        while (o.size() < n && System.currentTimeMillis() < end) {
            val s = next(end - System.currentTimeMillis()) ?: break
            if (s.flags and F_RST != 0) break
            if (s.seq != rcv) { send(F_ACK); continue }
            if (s.data.isNotEmpty()) { o.write(s.data); rcv += s.data.size; send(F_ACK) }
            if (s.flags and F_FIN != 0) { rcv++; send(F_ACK); break }
        }
        return o.toByteArray()
    }
}

private class Srv(val handler: (Socket) -> Unit) {
    val ss = ServerSocket(0, 50, InetAddress.getByAddress(LO4))
    val port get() = ss.localPort
    val accepted = AtomicInteger()
    init {
        Thread({
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (_: Exception) { break }
                accepted.incrementAndGet()
                Thread({ try { handler(s) } catch (_: Exception) {} finally { try { s.close() } catch (_: Exception) {} } }).also { it.isDaemon = true }.start()
            }
        }, "srv").also { it.isDaemon = true }.start()
    }
    fun close() = ss.close()
}

/** Geçerli görünümlü bir TLS ClientHello (tek kayıt, SNI + dolgu). */
internal fun testHello(sni: String, pad: Int = 120): ByteArray {
    val name = sni.toByteArray()
    val sniExt = ByteArray(4 + 5 + name.size)
    Packets.put16(sniExt, 0, 0); Packets.put16(sniExt, 2, 5 + name.size)
    Packets.put16(sniExt, 4, 3 + name.size); sniExt[6] = 0; Packets.put16(sniExt, 7, name.size)
    System.arraycopy(name, 0, sniExt, 9, name.size)
    val padExt = ByteArray(4 + pad); Packets.put16(padExt, 0, 21); Packets.put16(padExt, 2, pad)
    val ext = sniExt + padExt
    val body = ByteArrayOutputStream()
    body.write(byteArrayOf(3, 3)); body.write(ByteArray(32) { it.toByte() })
    body.write(0)                                              // oturum kimliği yok
    body.write(byteArrayOf(0, 2, 0x13, 0x01)); body.write(byteArrayOf(1, 0))
    body.write(byteArrayOf((ext.size ushr 8).toByte(), ext.size.toByte())); body.write(ext)
    val b = body.toByteArray()
    val hs = ByteArray(4 + b.size); hs[0] = 1; hs[1] = 0; Packets.put16(hs, 2, b.size); System.arraycopy(b, 0, hs, 4, b.size)
    val rec = ByteArray(5 + hs.size); rec[0] = 0x16; rec[1] = 3; rec[2] = 1; Packets.put16(rec, 3, hs.size); System.arraycopy(hs, 0, rec, 5, hs.size)
    return rec
}

private fun readFully(s: Socket, n: Int, ms: Int = 3000): ByteArray {
    s.soTimeout = ms
    val b = ByteArray(n); var o = 0
    while (o < n) { val r = s.getInputStream().read(b, o, n - o); if (r < 0) break; o += r }
    return b.copyOf(o)
}

fun runGatewayTests() {
    T.group("Ağ geçidi: çok noktaya / genel yayın ayrımı")
    fun ip4(a: Int, b: Int, c: Int, d: Int) = byteArrayOf(a.toByte(), b.toByte(), c.toByte(), d.toByte())
    T.check("224.0.0.251 (mDNS) ve 239.255.255.250 (SSDP) çok noktaya sayılır", isMulticastOrBroadcast(false, ip4(224, 0, 0, 251)) && isMulticastOrBroadcast(false, ip4(239, 255, 255, 250)))
    T.check("255.255.255.255 genel yayındır", isMulticastOrBroadcast(false, ip4(255, 255, 255, 255)))
    T.check("255.1.2.255 tam genel yayın değildir (eski koşul yanlışlıkla eliyordu)", !isMulticastOrBroadcast(false, ip4(255, 1, 2, 255)))
    T.check("sıradan adresler geçer: 1.1.1.1, 10.0.0.5, 192.168.1.255, 223.255.255.255", listOf(ip4(1, 1, 1, 1), ip4(10, 0, 0, 5), ip4(192, 168, 1, 255), ip4(223, 255, 255, 255)).none { isMulticastOrBroadcast(false, it) })
    val v6m = ByteArray(16).also { it[0] = 0xFF.toByte(); it[1] = 0x02; it[15] = 1 }
    val v6u = ByteArray(16).also { it[0] = 0x20; it[1] = 0x01; it[15] = 1 }
    T.check("IPv6: ff02::1 çok noktaya, 2001::1 sıradan", isMulticastOrBroadcast(true, v6m) && !isMulticastOrBroadcast(true, v6u))
    T.group("Ağ geçidi: paket yazıcı ve ayrıştırıcılar")
    run {
        val b = ByteArray(2048)
        val data = "merhaba".toByteArray()
        val n = Gw.tcp(b, false, CLI4, LO4, 1234, 80, 1, 2, F_ACK or F_PSH, 4000, data, 0, data.size, 1460)
        T.check("IPv4 TCP: IP ve TCP sağlama toplamı geçerli", Gw.checksumOk(b.copyOf(n), n) && n == 20 + 24 + 7)
        val n6 = Gw.tcp(b, true, SelfTest.CLIENT6, SelfTest.FAKE6, 1234, 80, 1, 2, F_ACK, 4000, null, 0, 0)
        T.check("IPv6 TCP: sağlama toplamı geçerli", Gw.checksumOk(b.copyOf(n6), n6) && n6 == 60)
        val u = Gw.udp(b, false, CLI4, LO4, 5000, 53, data, 0, data.size)
        T.check("IPv4 UDP: sağlama toplamı geçerli", Gw.checksumOk(b.copyOf(u), u) && u == 20 + 8 + 7)
        val u6 = Gw.udp(b, true, SelfTest.CLIENT6, SelfTest.FAKE6, 5000, 53, data, 0, data.size)
        T.check("IPv6 UDP: sağlama toplamı geçerli", Gw.checksumOk(b.copyOf(u6), u6))
        val q = ByteQueue(1000)
        q.add(ByteArray(600) { 1 }, 0, 600); q.drop(300); q.add(ByteArray(600) { 2 }, 0, 600)
        T.check("ByteQueue: sınır, baştan atma ve kopyalama", q.size == 900 && q.free == 100 && q.copy(299, ByteArray(2), 0, 2).let { true })
        val t = ByteArray(2); q.copy(299, t, 0, 2)
        T.check("ByteQueue: sıra korunur", t[0].toInt() == 1 && t[1].toInt() == 2)
    }

    T.group("DPI: SNI / Host ayrıştırma ve bölme yöntemleri")
    run {
        val h = testHello("blocked.example.org")
        val info = Dpi.Hello()
        T.check("TLS ClientHello sınıflanır", Dpi.classify(h, h.size) == Dpi.TLS && Dpi.tlsNeed(h, h.size) == h.size)
        T.check("SNI okunur", Dpi.parseHello(h, h.size, info) && info.host(h) == "blocked.example.org")
        T.check("eksik ClientHello'da SNI bulunamaz ama çökmez", !Dpi.parseHello(h, 40, info))
        T.check("bozuk girdilerde çökmez", (0 until 300).all { i -> val z = ByteArray(i) { (it * 31 + i).toByte() }; if (i > 0) z[0] = 0x16; Dpi.parseHello(z, z.size, info); true })
        var allSame = true; var multi = true
        for (p in 0 until Dpi.TLS_PLANS) {
            val parts = Dpi.split(Dpi.TLS, p, h, h.size)
            val joined = parts.fold(ByteArray(0)) { a, x -> a + x.data }
            if (p != 1 && p != 3 && p != 6 && p != 7) allSame = allSame && joined.contentEquals(h)
            multi = multi && parts.size >= 2
        }
        T.check("TLS yöntem 0 ve 2: birleşince bayt bayt aynı, birden çok parça", allSame && multi)
        val parts1 = Dpi.split(Dpi.TLS, 1, h, h.size)
        val j1 = parts1.fold(ByteArray(0)) { a, x -> a + x.data }
        val len1 = Packets.u16(j1, 3)
        val rec2 = 5 + len1
        T.check("TLS yöntem 1: iki geçerli kayıt, yükler birleşince özgün el sıkışma",
            j1[0].toInt() == 0x16 && j1[rec2].toInt() == 0x16 && 5 + len1 + 5 + Packets.u16(j1, rec2 + 3) == j1.size &&
                (j1.copyOfRange(5, rec2) + j1.copyOfRange(rec2 + 5, j1.size)).contentEquals(h.copyOfRange(5, h.size)))
        T.check("TLS yöntem 1: kayıt sınırı SNI içinde (DPI adı tek kayıtta göremez)",
            rec2 > info.also { Dpi.parseHello(h, h.size, it) }.sniOff && rec2 < info.sniOff + info.sniLen + 1)
        T.check("TLS yöntem 2 ve 3: acil veri bayrağı var", Dpi.split(Dpi.TLS, 2, h, h.size).any { it.oobAfter } && Dpi.split(Dpi.TLS, 3, h, h.size).any { it.oobAfter })

        val req = "GET /yol HTTP/1.1\r\nHost: Engelli.Ornek.com:8080\r\nUser-Agent: x\r\n\r\n".toByteArray()
        val hi = Dpi.HttpInfo()
        T.check("HTTP sınıflanır, Host okunur (küçük harf, port atılır)", Dpi.classify(req, req.size) == Dpi.HTTP && Dpi.parseHttp(req, req.size, hi) && Dpi.httpHost(req, hi) == "engelli.ornek.com" && hi.get)
        T.check("HTTP başlık sonu bulunur", Dpi.httpEnd(req, req.size) == req.size && Dpi.httpEnd(req, req.size - 2) < 0)
        for (p in 0 until Dpi.HTTP_PLANS) {
            val ps = Dpi.split(Dpi.HTTP, p, req, req.size)
            val j = String(ps.fold(ByteArray(0)) { a, x -> a + x.data }, Charsets.ISO_8859_1)
            val norm = j.replace("hOsT:", "Host:").replace("Host:\t", "Host: ").replace("HOST", "Host")
            T.check("HTTP yöntem $p: ${ps.size} parça, anlam aynı (Host başlığı hâlâ geçerli)", ps.size >= 2 && Dpi.httpHost(j.toByteArray(Charsets.ISO_8859_1), Dpi.HttpInfo().also { Dpi.parseHttp(j.toByteArray(Charsets.ISO_8859_1), j.length, it) }.let { Dpi.HttpInfo().also { x -> Dpi.parseHttp(j.toByteArray(Charsets.ISO_8859_1), j.length, x) } }) == "engelli.ornek.com" && norm.length >= req.size - 1)
        }
        T.check("bilinmeyen protokol sınıflanmaz", Dpi.classify("SSH-2.0".toByteArray(), 7) == Dpi.NONE && Dpi.classify(byteArrayOf(1, 2), 2) == Dpi.NONE)
        val pl = Dpi.Planner(cap = 3)
        pl.worked("a", Dpi.TLS, 2); pl.worked("b", Dpi.TLS, 1); pl.worked("c", Dpi.TLS, 1); pl.worked("d", Dpi.TLS, 3)
        T.check("Planner: ilk deneme TLS'te 1, HTTP'de 0; öğrenilen hatırlanır, kapasite aşılınca en eski atılır",
            pl.first("zzz", Dpi.TLS) == 1 && pl.first("zzz", Dpi.HTTP) == 0 && pl.first("d", Dpi.TLS) == 3 && pl.first("a", Dpi.TLS) == 1)
        T.check("Planner: TLS sırası 1 → 0 → 5 → 3 → 2 → 6 → 7 → 4 → son, HTTP sırası 0..6", pl.next(Dpi.TLS, 1) == 0 && pl.next(Dpi.TLS, 0) == 5 && pl.next(Dpi.TLS, 5) == 3 && pl.next(Dpi.TLS, 3) == 2 &&
            pl.next(Dpi.TLS, 2) == 6 && pl.next(Dpi.TLS, 6) == 7 && pl.next(Dpi.TLS, 7) == 4 && pl.next(Dpi.TLS, 4) < 0 && pl.next(Dpi.HTTP, 0) == 1 && pl.next(Dpi.HTTP, 6) < 0)
        val dis = Dpi.split(Dpi.TLS, 4, h, h.size)
        T.check("TLS yöntem 4 (disorder): ilk bayt düşük TTL'li, birleşince veri aynı", dis.size == 3 && dis[0].lowTtl && dis[0].data.size == 1 && !dis[1].lowTtl &&
            dis.fold(ByteArray(0)) { a, x -> a + x.data }.contentEquals(h))
        T.check("DoH ad listesi: alt alan dahil, benzer ad değil", Dpi.isDohHost("dns.google") && Dpi.isDohHost("mozilla.cloudflare-dns.com") && !Dpi.isDohHost("notdns.google") && !Dpi.isDohHost("example.com"))
    }

    T.group("Ağ geçidi: TCP aktarma (gerçek loopback soketleriyle)")
    run {
        val r = GRig()
        val echo = Srv { s -> val i = s.getInputStream(); val o = s.getOutputStream(); val b = ByteArray(4096); while (true) { val n = i.read(b); if (n < 0) break; o.write(b, 0, n); o.flush() } }
        val c = GCli(r, echo.port)
        val sa = c.connect()
        T.check("SYN'e SYN+ACK: ack ilerler, MSS seçeneği, sağlama toplamı geçerli", sa != null && sa.flags == (F_SYN or F_ACK) && sa.ack == 7001 && sa.mss in 536..1460 && sa.ok)
        c.write("merhaba dünya".toByteArray())
        val got = c.read("merhaba dünya".toByteArray().size)
        T.check("veri sunucuya gitti ve yankısı istemciye döndü", String(got) == "merhaba dünya")
        c.send(F_FIN or F_ACK); c.seq++
        val fin = c.read(1, 2500)
        T.check("istemci kapanınca sunucu kapanır ve FIN gelir", fin.isEmpty())
        Thread.sleep(300)
        c.send(F_ACK)
        T.check("akış sayısı düşer", run { var n = 0; while (n++ < 60 && r.gw.stats().tcpFlows != 0) Thread.sleep(100); r.gw.stats().tcpFlows == 0 })
        echo.close(); r.close()
    }
    run {
        val r = GRig()
        val dead = ServerSocket(0, 1, InetAddress.getByAddress(LO4)); val p = dead.localPort; dead.close()
        val c = GCli(r, p)
        c.send(F_SYN, mss = 1460)
        val s = c.next()
        T.check("kapalı porta bağlanma: istemci RST alır (bağlandı sanılmaz)", s != null && s.flags and F_RST != 0 && s.ack == 7001)
        T.check("bağlanma hatası sayılır", r.gw.stats().connectFail >= 1)
        // bilinmeyen akışa gelen veri RST ile karşılanır
        val c2 = GCli(r, p); c2.rcv = 5; c2.send(F_ACK or F_PSH, "x".toByteArray())
        val s2 = c2.next()
        T.check("bilinmeyen bağlantıya veri: RST", s2 != null && s2.flags and F_RST != 0)
        r.close()
    }
    run {
        val r = GRig()
        val big = ByteArray(400_000) { (it * 7 + it / 251).toByte() }
        val srv = Srv { s -> s.getOutputStream().write(big); s.getOutputStream().flush(); s.shutdownOutput(); Thread.sleep(500) }
        val c = GCli(r, srv.port)
        c.connect()
        val got = c.read(big.size, 10_000)
        T.check("400 KB indirme: sıra ve içerik bozulmadan geldi", got.size == big.size && got.contentEquals(big))
        srv.close(); r.close()
    }
    run {
        val r = GRig()
        val big = ByteArray(300_000) { (it * 13 + 5).toByte() }
        val recv = ByteArrayOutputStream()
        val done = java.util.concurrent.CountDownLatch(1)
        val srv = Srv { s -> val i = s.getInputStream(); val b = ByteArray(8192); while (true) { val n = i.read(b); if (n < 0) break; synchronized(recv) { recv.write(b, 0, n) } }; done.countDown() }
        val c = GCli(r, srv.port)
        c.connect()
        // pencereye uyarak gönder
        var sent = 0
        var una = c.seq
        val start = System.currentTimeMillis()
        var peer = 65535
        while (sent < big.size && System.currentTimeMillis() - start < 15_000) {
            val room = peer - (c.seq - una)
            if (room > 0) {
                val n = minOf(1400, big.size - sent, room)
                c.write(big.copyOfRange(sent, sent + n)); sent += n
            }
            while (true) {
                val s = c.next(if (room > 0) 1 else 200) ?: break
                if (s.flags and F_ACK != 0 && Gw.seqLe(una, s.ack)) { una = s.ack; peer = s.win }
            }
        }
        c.send(F_FIN or F_ACK); c.seq++
        T.check("300 KB yükleme pencere sınırına uyularak tamamlandı", sent == big.size && done.await(5, TimeUnit.SECONDS) && synchronized(recv) { recv.toByteArray().contentEquals(big) })
        srv.close(); r.close()
    }
    run {
        val r = GRig()
        val srv = Srv { s -> s.getOutputStream().write("220 hoş geldin\r\n".toByteArray()); s.getOutputStream().flush(); Thread.sleep(800) }
        val c = GCli(r, srv.port)
        c.connect()
        T.check("önce sunucunun konuştuğu protokol (SMTP benzeri) çalışır", String(c.read(18, 3000)).startsWith("220 hoş"))
        srv.close(); r.close()
    }
    run {
        // yitik segment: istemci bir veri segmentini 'kaybeder'; üç yinelenen ACK ile yeniden gönderilir
        val r = GRig()
        val data = ByteArray(6000) { (it % 251).toByte() }
        val srv = Srv { s -> s.getOutputStream().write(data); s.getOutputStream().flush(); Thread.sleep(2500) }
        val c = GCli(r, srv.port)
        c.connect()
        var lost = false; val o = ByteArrayOutputStream(); val end = System.currentTimeMillis() + 6000
        var lostSeq = 0; var segN = 0
        while (o.size() < data.size && System.currentTimeMillis() < end) {
            val s = c.next(1500) ?: break
            if (s.data.isEmpty()) continue
            if (!lost && segN++ == 2) { lost = true; lostSeq = s.seq; continue }                  // 3. veri segmentini düşür
            if (s.seq == c.rcv) { o.write(s.data); c.rcv += s.data.size }
            c.send(F_ACK)
        }
        T.check("kayıp segment yeniden gönderilir, akış eksiksiz tamamlanır (zamanlayıcı ya da yinelenen ACK)", lost && o.toByteArray().contentEquals(data), "lost=$lost lostSeq=$lostSeq got=${o.size()}")
        srv.close(); r.close()
    }

    T.group("Ağ geçidi: DPI atlatma ve otomatik yöntem seçimi")
    run {
        val r = GRig()
        r.gw.config.dpi = true
        r.gw.planner.worked("engelli.example.net", Dpi.TLS, 0)                    // yalnızca TCP bölme (kayıt bütün)
        val hello = testHello("engelli.example.net")
        val seen = LinkedBlockingQueue<ByteArray>()
        val srv = Srv { s -> val b = readFully(s, hello.size, 1500); seen.add(b); s.getOutputStream().write("SERVER-HELLO".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        val resp = c.read(12)
        val s0 = seen.poll(3, TimeUnit.SECONDS)
        T.check("DPI açık: ClientHello bölünerek gönderilir, sunucu baytları eksiksiz ve aynı sırada alır", String(resp) == "SERVER-HELLO" && s0 != null && s0.contentEquals(hello), "resp=${String(resp)} s0=${s0?.size} hello=${hello.size} st=${r.gw.stats()}")
        T.check("bölme sayılır, yeniden deneme gerekmedi", r.gw.stats().split == 1L && r.gw.stats().retried == 0L)
        srv.close(); r.close()
    }
    run {
        // Varsayılan ilk yöntem: TLS kaydı bölme (+ TCP bölme). Sunucu 5 bayt fazla (ikinci kaydın başlığı) alır; iki kaydın yükü birleşince özgün veri çıkar.
        val r = GRig()
        r.gw.config.dpi = true
        val hello = testHello("engelli.example.net")
        val seen = LinkedBlockingQueue<ByteArray>()
        val srv = Srv { s -> val b = readFully(s, hello.size + 5, 1500); seen.add(b); s.getOutputStream().write("SERVER-HELLO".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        val resp = c.read(12)
        val b = seen.poll(3, TimeUnit.SECONDS)
        var joined = ByteArray(0)
        if (b != null) {
            val l1 = Packets.u16(b, 3)
            joined = b.copyOfRange(0, 5 + l1) + b.copyOfRange(5 + l1 + 5, b.size)
            Packets.put16(joined, 3, l1 + Packets.u16(b, 5 + l1 + 3))
        }
        T.check("varsayılan ilk yöntem TLS kaydı bölme: iki kayıt, birleşince özgün ClientHello", String(resp) == "SERVER-HELLO" && b != null && joined.contentEquals(hello) && r.gw.stats().retried == 0L)
        srv.close(); r.close()
    }
    run {
        // Sahte sunucu: kayıt bölünmüşse (varsayılan ilk yöntem 1) bağlantıyı keser, bütün kaydı (yöntem 0) kabul eder.
        // Otomatik mod yöntem 0'a geçip öğrenmeli.
        val r = GRig()
        r.gw.config.dpi = true
        val hello = testHello("zor.example.net")
        val tries = AtomicInteger()
        val srv = Srv { s ->
            tries.incrementAndGet()
            val first = readFully(s, 5, 2000)
            val len = Packets.u16(first, 3)
            val body = readFully(s, minOf(len, hello.size), 1000)
            val whole = hello.size - 5 == len
            if (!whole) { s.close(); return@Srv }         // bu sahte sunucu bölünmüş kaydı kabul etmez (tam kayıt ister) → kapat
            s.getOutputStream().write("OK-BOLUNMUS".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300)
        }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        val resp = c.read(11, 8000)
        T.check("yöntem 1 kesilince otomatik olarak sıradaki yönteme geçilir ve cevap alınır", String(resp) == "OK-BOLUNMUS")
        T.check("yeniden deneme sayıldı, aynı istemci bağlantısı üzerinde", r.gw.stats().retried >= 1L && tries.get() >= 2)
        val before = tries.get()
        val c2 = GCli(r, srv.port); c2.connect(); c2.write(hello)
        val resp2 = c2.read(11, 8000)
        T.check("öğrenilen yöntem hatırlanır: ikinci bağlantı ilk denemede çalışır", String(resp2) == "OK-BOLUNMUS" && tries.get() == before + 1)
        srv.close(); r.close()
    }
    run {
        // hiç cevap vermeyen sunucu: tüm yöntemler tükenince istemci RST alır (sonsuz beklemez)
        val r = GRig()
        r.gw.config.dpi = true
        val srv = Srv { s -> Thread.sleep(30_000) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(testHello("sessiz.example.net"))
        val t0 = System.currentTimeMillis()
        var rst = false
        while (System.currentTimeMillis() - t0 < 20_000) { val s = c.next(1000) ?: continue; if (s.flags and F_RST != 0) { rst = true; break } }
        T.check("cevapsız sunucu: yöntemler tükenince bağlantı RST ile biter", rst)
        srv.close(); r.close()
    }
    run {
        // DPI kapalıyken veri olduğu gibi gider, hiç bölme/yeniden deneme yok
        val r = GRig()
        val hello = testHello("normal.example.net")
        val srv = Srv { s -> val b = readFully(s, hello.size, 1500); s.getOutputStream().write(b.copyOf(4)); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        T.check("DPI kapalı: aktarma düz, bölme yok", c.read(4).size == 4 && r.gw.stats().split == 0L)
        srv.close(); r.close()
    }
    run {
        // HTTP: Host bölünür ama sunucu isteği eksiksiz (anlamca aynı) alır
        val r = GRig()
        r.gw.config.dpi = true
        val req = "GET / HTTP/1.1\r\nHost: engelli.example.com\r\nConnection: close\r\n\r\n".toByteArray()
        val seen = LinkedBlockingQueue<String>()
        val srv = Srv { s -> val b = readFully(s, req.size, 1500); seen.add(String(b)); s.getOutputStream().write("HTTP/1.1 200 OK\r\n\r\n".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(req)
        val resp = String(c.read(19))
        val got = seen.poll(3, TimeUnit.SECONDS) ?: ""
        T.check("HTTP: bölünmüş istek sunucuya eksiksiz ulaşır, cevap döner", resp.startsWith("HTTP/1.1 200") && got.equals(String(req)) && r.gw.stats().split == 1L)
        srv.close(); r.close()
    }

    T.group("Ağ geçidi: reklam / izleyici engelleme (SNI, Host, düz DNS), QUIC")
    run {
        val r = GRig()
        val eng = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example", "izleyici.test"))
        r.gw.config.ads = eng
        val srv = Srv { s -> Thread.sleep(300); s.getOutputStream().write("ACIK".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(testHello("cdn.reklam.example"))
        var rst = false
        while (true) { val s = c.next(2500) ?: break; if (s.flags and F_RST != 0) { rst = true; break } }
        T.check("engelli SNI (alt alan adı dahil): bağlantı RST ile kesilir", rst && r.gw.stats().blockedHosts == 1L)
        val c2 = GCli(r, srv.port)
        c2.connect(); c2.write(testHello("guvenli.example.org"))
        T.check("engelli olmayan SNI: geçer", String(c2.read(4)) == "ACIK")
        val c3 = GCli(r, srv.port)
        c3.connect(); c3.write("GET /x HTTP/1.1\r\nHost: izleyici.test\r\n\r\n".toByteArray())
        var rst3 = false
        while (true) { val s = c3.next(2500) ?: break; if (s.flags and F_RST != 0) { rst3 = true; break } }
        T.check("engelli HTTP Host: bağlantı kesilir", rst3 && r.gw.stats().blockedHosts == 2L)
        r.gw.config.passthrough = true
        val c4 = GCli(r, srv.port); c4.connect(); c4.write(testHello("cdn.reklam.example"))
        T.check("acil durum (passthrough): engelleme ve bölme devre dışı", String(c4.read(4)) == "ACIK")
        srv.close(); r.close()
    }
    run {
        val r = GRig()
        val eng = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example"))
        r.gw.config.ads = eng
        val q = Dns.buildQuery(0x4242, "banner.reklam.example")
        val b = ByteArray(2048)
        val n = Gw.udp(b, false, CLI4, byteArrayOf(8, 8, 8, 8), 51000, 53, q, 0, q.size)
        r.gw.onPacket(b.copyOf(n), n)
        val reply = r.q.poll(2, TimeUnit.SECONDS)
        T.check("sistemin düz DNS sorgusu (herhangi bir sağlayıcıya) engellenir: yerelde cevaplanır",
            reply != null && Gw.checksumOk(reply, reply.size) && Packets.u16(reply, 20) == 53 && Packets.u16(reply, 22) == 51000 &&
                Packets.u16(reply, 28) == 0x4242 && r.gw.stats().dnsBlocked == 1L,
            "reply=${reply?.size} ck=${reply?.let { Gw.checksumOk(it, it.size) }} sp=${reply?.let { Packets.u16(it, 20) }} dp=${reply?.let { Packets.u16(it, 22) }} id=${reply?.let { Packets.u16(it, 28) }} st=${r.gw.stats().dnsBlocked}")
        r.gw.config.blockQuic = true
        val qd = ByteArray(100) { 1 }
        val n2 = Gw.udp(b, false, CLI4, LO4, 51001, 443, qd, 0, qd.size)
        r.gw.onPacket(b.copyOf(n2), n2)
        Thread.sleep(200)
        T.check("QUIC (UDP/443) açıkken düşürülür", r.gw.stats().quicDropped == 1L && r.gw.stats().udpFlows == 0)
        r.close()
    }

    T.group("Ağ geçidi: UDP aktarma")
    run {
        val r = GRig()
        val us = DatagramSocket(0, InetAddress.getByAddress(LO4))
        Thread({ try { val bb = ByteArray(2000); val p = DatagramPacket(bb, bb.size); repeat(2) { us.receive(p); us.send(DatagramPacket(bb, p.length, p.socketAddress)) } } catch (_: Exception) {} }).also { it.isDaemon = true }.start()
        val data = "udp-yankı".toByteArray()
        val b = ByteArray(2048)
        val n = Gw.udp(b, false, CLI4, LO4, 52000, us.localPort, data, 0, data.size)
        r.gw.onPacket(b.copyOf(n), n)
        val rep = r.q.poll(3, TimeUnit.SECONDS)
        T.check("UDP: giden datagram ulaştı, cevap doğru portlarla istemciye döndü",
            rep != null && Gw.checksumOk(rep, rep.size) && Packets.u16(rep, 20) == us.localPort && Packets.u16(rep, 22) == 52000 && String(rep, 28, rep.size - 28) == "udp-yankı")
        r.gw.onPacket(b.copyOf(n), n)
        T.check("aynı akış yeniden kullanılır (tek UDP akışı)", r.q.poll(3, TimeUnit.SECONDS) != null && r.gw.stats().udpFlows == 1)
        us.close(); r.close()
    }

    T.group("Ağ geçidi: IPv6 ve sağlamlık")
    run {
        val v6ok = try { ServerSocket(0, 5, InetAddress.getByName("::1")).close(); true } catch (_: Exception) { false }
        if (!v6ok) T.check("IPv6 loopback bu makinede yok: atlandı", true)
        else {
            val r = GRig()
            val ss = ServerSocket(0, 5, InetAddress.getByName("::1"))
            Thread({ try { val s = ss.accept(); val b = ByteArray(100); val n = s.getInputStream().read(b); s.getOutputStream().write(b, 0, n); s.getOutputStream().flush(); Thread.sleep(300) } catch (_: Exception) {} }).also { it.isDaemon = true }.start()
            val c = GCli(r, ss.localPort, v6 = true, dst = InetAddress.getByName("::1").address)
            val sa = c.connect()
            c.write("v6!".toByteArray())
            T.check("IPv6 TCP: el sıkışma ve yankı", sa != null && sa.flags == (F_SYN or F_ACK) && sa.ok && sa.mss <= Gw.MSS6 && String(c.read(3)) == "v6!")
            ss.close(); r.close()
        }
    }
    run {
        val r = GRig()
        val rnd = java.util.Random(7)
        repeat(3000) {
            val len = 20 + rnd.nextInt(120)
            val p = ByteArray(len).also { rnd.nextBytes(it) }
            p[0] = (if (rnd.nextBoolean()) 0x45 else 0x60).toByte()
            if (rnd.nextBoolean() && len > 9) p[9] = (if (rnd.nextBoolean()) 6 else 17).toByte()
            r.gw.onPacket(p, len)
        }
        Thread.sleep(500)
        val e = DatagramSocket(0, InetAddress.getByAddress(LO4)); e.close()
        T.check("3000 rastgele/bozuk paket: çökme yok, geçit çalışmaya devam eder", r.gw.stats().tcpFlows >= 0)
        val srv = Srv { s -> s.getOutputStream().write("hâlâ-canlı".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port); c.connect()
        T.check("bozuk paketlerden sonra normal bağlantı çalışır", String(c.read(11)).startsWith("hâlâ"))
        srv.close(); r.close()
        T.check("stop() sonrası paket kabul edilmez, çökmez", run { r.gw.onPacket(ByteArray(40), 40); true })
    }
    T.group("Ağ geçidi: DoH / DoT engeli, disorder (TTL), yayın paketleri")
    run {
        val r = GRig()
        r.gw.config.blockDoh = true
        val srv = Srv { s -> Thread.sleep(300); s.getOutputStream().write("ACIK".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(testHello("mozilla.cloudflare-dns.com"))
        var rst = false
        while (true) { val sg = c.next(2500) ?: break; if (sg.flags and F_RST != 0) { rst = true; break } }
        T.check("bilinen DoH sağlayıcısına TLS bağlantısı kesilir", rst && r.gw.stats().dohBlocked == 1L)
        val c2 = GCli(r, srv.port); c2.connect(); c2.write(testHello("guvenli.example.org"))
        T.check("diğer adlar etkilenmez", String(c2.read(4)) == "ACIK")
        val b = ByteArray(2048)
        val d = ByteArray(40) { 3 }
        val n = Gw.udp(b, false, CLI4, LO4, 52000, 853, d, 0, d.size)
        r.gw.onPacket(b.copyOf(n), n)
        Thread.sleep(200)
        T.check("UDP/853 (DoQ) düşürülür", r.gw.stats().dohBlocked == 2L && r.gw.stats().udpFlows == 0)
        val sy = ByteArray(80)
        val ns = Gw.tcp(sy, false, CLI4, LO4, 52001, 853, 1000, 0, Gw.SYN, 65535, null, 0, 0, 1460)
        r.gw.onPacket(sy.copyOf(ns), ns)
        val rep = r.q.poll(2, TimeUnit.SECONDS)
        T.check("TCP/853 (DoT) bağlantısı hemen reddedilir", rep != null && (rep[33].toInt() and Gw.RST) != 0 && r.gw.stats().dohBlocked == 3L)
        // IP ile (SNI olmadan) şifreli DNS: bilinen DoH sağlayıcı adresine 443'e bağlanma ve UDP/443 (DoH3) kesilir
        val sy2 = ByteArray(80)
        val doh = byteArrayOf(1, 1, 1, 1)
        val n2 = Gw.tcp(sy2, false, CLI4, doh, 52002, 443, 1000, 0, Gw.SYN, 65535, null, 0, 0, 1460)
        r.gw.onPacket(sy2.copyOf(n2), n2)
        val rep2 = r.q.poll(2, TimeUnit.SECONDS)
        T.check("TCP/443 → bilinen DoH adresi (1.1.1.1) hemen reddedilir", rep2 != null && (rep2[33].toInt() and Gw.RST) != 0 && r.gw.stats().dohBlocked == 4L)
        val du = ByteArray(40) { 4 }
        val nu = Gw.udp(b, false, CLI4, byteArrayOf(8, 8, 8, 8), 52003, 443, du, 0, du.size)
        r.gw.onPacket(b.copyOf(nu), nu)
        Thread.sleep(200)
        T.check("UDP/443 → bilinen DoH adresi (8.8.8.8, DoH3) düşürülür", r.gw.stats().dohBlocked == 5L && r.gw.stats().udpFlows == 0)
        r.gw.config.blockDoh = false
        val c3 = GCli(r, srv.port); c3.connect(); c3.write(testHello("dns.google"))
        T.check("ayar kapalıyken DoH adı da geçer", String(c3.read(4)) == "ACIK")
        srv.close(); r.close()
    }
    run {
        val calls = java.util.concurrent.CopyOnWriteArrayList<Int>()
        val r = GRig { _, ttl -> calls.add(ttl); true }
        r.gw.config.dpi = true
        val hello = testHello("engelli.ornek.com")
        r.gw.planner.worked("engelli.ornek.com", Dpi.TLS, 4)
        val got = LinkedBlockingQueue<ByteArray>()
        val srv = Srv { s -> got.add(readFully(s, hello.size)); s.getOutputStream().write("TAMAM".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        T.check("disorder: sunucuya veri eksiksiz ve sırayla ulaşır", got.poll(4, TimeUnit.SECONDS)?.contentEquals(hello) == true && String(c.read(5)) == "TAMAM")
        T.check("disorder: TTL önce 1, hemen sonra 64 yapılır", calls.toList() == listOf(1, 64), calls.toString())
        srv.close(); r.close()
    }
    run {
        val r = GRig()
        val b = ByteArray(2048)
        val d = ByteArray(30) { 5 }
        val n1 = Gw.udp(b, false, CLI4, byteArrayOf(-17, -1, -1, -6), 5353, 5353, d, 0, d.size)    // 239.255.255.250 (SSDP)
        r.gw.onPacket(b.copyOf(n1), n1)
        val n2 = Gw.udp(b, false, CLI4, byteArrayOf(-1, -1, -1, -1), 68, 67, d, 0, d.size)           // genel yayın
        r.gw.onPacket(b.copyOf(n2), n2)
        Thread.sleep(250)
        T.check("çok noktaya / genel yayın paketleri aktarılmaz", r.gw.stats().udpFlows == 0)
        r.close()
    }

    T.group("Ağ geçidi: mobil ağ (IPv6-only NAT64, ağ türüne göre DPI belleği)")
    run {
        // Ortamda IPv6 olmayabilir: NAT64 adresi, yerel IPv4 sunucuya çevrilerek denenir (akış mantığı aynı).
        // 127.0.0.1:port'ta kimse dinlemez (düz IPv4 reddedilir); "NAT64 adresi" 127.0.0.2'ye çevrilir ve orada bir sunucu vardır.
        val ss = ServerSocket(0, 5, InetAddress.getByAddress(byteArrayOf(127, 0, 0, 2)))
        Thread({ try { while (true) { val c = ss.accept(); Thread({ try { val i = c.getInputStream(); val o = c.getOutputStream(); val b = ByteArray(64); val n = i.read(b); o.write(b, 0, n); o.flush(); Thread.sleep(200) } catch (_: Exception) {} finally { try { c.close() } catch (_: Exception) {} } }).start() } } catch (_: Exception) {} }).also { it.isDaemon = true }.start()
        val map: (ByteArray, ByteArray) -> InetAddress = { _, _ -> InetAddress.getByAddress(byteArrayOf(127, 0, 0, 2)) }
        run {
            val r = GRig(); r.gw.config.noV4 = true; r.gw.config.nat64 = ByteArray(12); r.gw.config.nat64Addr = map
            val c = GCli(r, ss.localPort)
            val sa = c.connect(); c.write("MERHABA".toByteArray())
            T.check("yalnızca IPv6 ağ: IPv4 hedefe NAT64 adresiyle bağlanılır, veri gidip gelir", sa != null && sa.flags == (F_SYN or F_ACK) && String(c.read(7)) == "MERHABA")
            r.close()
        }
        run {
            val r = GRig(); r.gw.config.nat64 = ByteArray(12); r.gw.config.nat64Addr = map     // noV4 yok: önce IPv4 denenir (reddedilir), sonra NAT64
            val c = GCli(r, ss.localPort)
            val sa = c.connect(); c.write("TEKRAR".toByteArray())
            T.check("IPv4 reddedilirse NAT64 yedeği devreye girer", sa != null && sa.flags == (F_SYN or F_ACK) && String(c.read(6)) == "TEKRAR")
            r.close()
        }
        run {
            val r = GRig()                                                  // NAT64 bilgisi yok: bağlanamayan hedef RST alır (eski davranış)
            val c = GCli(r, ss.localPort)
            val sa = c.connect()
            T.check("NAT64 bilgisi yokken ulaşılamayan hedef hemen reddedilir (RST)", sa != null && (sa.flags and F_RST) != 0)
            r.close()
        }
        ss.close()
        val r = GRig()
        r.gw.config.dpi = true
        r.gw.planner.worked("site.example", Dpi.TLS, 4)
        r.gw.networkChanged(NetKind.MOBILE)
        T.check("mobil ağa geçince Wi-Fi'de öğrenilen yöntem uygulanmaz (ayrı bellek)", r.gw.planner.first("site.example", Dpi.TLS) == Dpi.TLS_ORDER[0])
        r.gw.planner.worked("site.example", Dpi.TLS, 0)
        r.gw.networkChanged(NetKind.WIFI)
        T.check("Wi-Fi'ye dönünce kendi belleği geri gelir", r.gw.planner.first("site.example", Dpi.TLS) == 4)
        r.gw.networkChanged(NetKind.NONE)
        T.check("ağ yokken bellek türü değişmez", r.gw.planner.first("site.example", Dpi.TLS) == 4)
        val fast = Dpi.Planner().also { it.noteRtt(80) }; val slow = Dpi.Planner(slow = true).also { it.noteRtt(80) }
        T.check("mobil bekleme süresi Wi-Fi'ninkinden uzundur (TLS ve HTTP)", slow.waitMs(Dpi.TLS) > fast.waitMs(Dpi.TLS) && slow.waitMs(Dpi.HTTP) > fast.waitMs(Dpi.HTTP) && slow.waitMs(Dpi.TLS) <= 3000)
        r.close()
    }

    run {
        // Ağ değişince tüm akışlar hemen kesilir (istemciye RST): uygulamalar yeni ağda anında yeniden bağlanır.
        val r = GRig()
        val echo = Srv { s -> val i = s.getInputStream(); val o = s.getOutputStream(); val b = ByteArray(256); while (true) { val n = i.read(b); if (n < 0) break; o.write(b, 0, n); o.flush() } }
        val c = GCli(r, echo.port)
        c.connect(); c.write("A".toByteArray())
        val ok = String(c.read(1)) == "A"
        val t0 = System.nanoTime()
        r.gw.networkReset()
        var rst = false
        while (System.nanoTime() - t0 < 3_000_000_000L) { val sg = c.next(200) ?: continue; if (sg.flags and F_RST != 0) { rst = true; break } }
        val ms = (System.nanoTime() - t0) / 1_000_000
        MobileBench.handoverResetMs = ms
        T.check("ağ değişimi: açık akış hemen RST ile kesilir (${ms} ms), sayaç artar", ok && rst && ms < 800 && r.gw.stats().netResets >= 1)
        val c2 = GCli(r, echo.port); c2.connect(); c2.write("B".toByteArray())
        T.check("sıfırlamadan sonra yeni bağlantılar sorunsuz açılır", String(c2.read(1)) == "B")
        echo.close(); r.close()
    }
    run {
        // SYN'i yanıtsız kalan (kabul kuyruğu dolu) sunucu: yedek deneme öbür adrese gider, 12 sn'lik bağlanma zaman aşımı beklenmez.
        val bh = ServerSocket(0, 1, InetAddress.getByAddress(LO4))                    // kuyruğu dolacak, hiç accept edilmeyecek
        val filler = ArrayList<Socket>()
        for (i in 0 until 12) { val f = Socket(); try { f.connect(java.net.InetSocketAddress(InetAddress.getByAddress(LO4), bh.localPort), 150); filler.add(f) } catch (_: Exception) { try { f.close() } catch (_: Exception) {}; break } }
        val saturated = filler.size < 12
        val good = try { ServerSocket(bh.localPort, 5, InetAddress.getByAddress(byteArrayOf(127, 0, 0, 2))) } catch (_: Exception) { null }
        if (saturated && good != null) {
            Thread({ try { while (true) { val c = good.accept(); Thread({ try { val i = c.getInputStream(); val o = c.getOutputStream(); val b = ByteArray(64); val n = i.read(b); o.write(b, 0, n); o.flush(); Thread.sleep(200) } catch (_: Exception) {} finally { try { c.close() } catch (_: Exception) {} } }).start() } } catch (_: Exception) {} }).also { it.isDaemon = true }.start()
            val map: (ByteArray, ByteArray) -> InetAddress = { _, _ -> InetAddress.getByAddress(byteArrayOf(127, 0, 0, 2)) }
            fun run1(hedge: Boolean, waitMs: Long): Long {
                val r = GRig(); r.gw.config.hedge = hedge; r.gw.config.hedgeDelayMs = 250; r.gw.config.nat64 = ByteArray(12); r.gw.config.nat64Addr = map
                val c = GCli(r, bh.localPort)
                val t0 = System.nanoTime()
                c.send(F_SYN, mss = 1460); c.seq++
                val sa = c.next(waitMs)
                var got = ""
                if (sa != null && sa.flags == (F_SYN or F_ACK)) {
                    c.rcv = sa.seq + 1; c.send(F_ACK)
                    c.write("MERHABA".toByteArray())
                    got = String(c.read(7, waitMs))
                }
                val ms = (System.nanoTime() - t0) / 1_000_000
                r.close()
                return if (got == "MERHABA") ms else -1L
            }
            val withHedge = run1(true, 5000)
            T.check("yedek bağlantı: yanıtsız hedefte öbür adres 250 ms sonra denenir, veri gelir ($withHedge ms)", withHedge in 1..2500)
            val without = run1(false, 20000)
            T.check("kontrol: yedek kapalıyken aynı durumda bağlanma zaman aşımı beklenir ($without ms)", without > 10_000)
            MobileBench.blackholeNewMs = withHedge; MobileBench.blackholeOldMs = without
        } else {
            println("    (bilgi) kabul kuyruğu doldurulamadı; yedek bağlantı sınaması atlandı")
        }
        for (f in filler) try { f.close() } catch (_: Exception) {}
        bh.close(); good?.close()
    }

}
