package app.dnshizli.selftest

import app.dnshizli.core.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Mobil ağ altyapısı ölçümü. Üç tür kanıt:
 *  - GERÇEK: gerçek soketlerle DNS yeniden deneme gecikmesi (kayıplı sahte sunucu), yanıtsız hedefte yedek bağlantı,
 *    ağ değişiminde akış sıfırlama süresi ([GatewayTests] içinde).
 *  - MODEL: operatör ağı davranışı (SYN kaybı, çekirdeğin 1/3/7 sn yeniden gönderimi) Monte Carlo ile; ilke kodu ([MobilePolicy]) gerçek.
 *  - VARSAYIM: uygulamaların takılı bağlantıyı bırakma süresi (30 sn).
 * Ortalama değil, KAYIPTAN DOĞAN BEKLEME ölçülür: gecikme − temel RTT. Ortalama gecikme kayıpsız durumlarda zaten RTT'dir;
 * kullanıcının hissettiği takılmalar kuyruktadır (p95/p99).
 */
internal object MobileBench {
    @Volatile var handoverResetMs = -1L
    @Volatile var blackholeNewMs = -1L
    @Volatile var blackholeOldMs = -1L
}

private class LossyDns(val lossPct: Int, val rttMs: Int, seed: Long) : AutoCloseable {
    val socket = DatagramSocket(0, InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1)))
    val addr = InetSocketAddress(InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1)), socket.localPort)
    private val rnd = Random(seed)
    private val pool = Executors.newScheduledThreadPool(2) { r -> Thread(r).also { it.isDaemon = true } }

    init {
        Thread({
            val buf = ByteArray(2048)
            val p = DatagramPacket(buf, buf.size)
            while (!socket.isClosed) {
                try { p.length = buf.size; socket.receive(p) } catch (_: Exception) { return@Thread }
                if (rnd.nextInt(100) < lossPct) continue                       // sorgu yolda kayboldu
                val q = buf.copyOf(p.length); val from = p.socketAddress
                val jitter = rnd.nextInt(maxOf(1, rttMs / 3))
                pool.schedule({
                    try {
                        val r = buildAnswer(q, q.size, aRecord(byteArrayOf(1, 2, 3, 4), 60), 1)
                        socket.send(DatagramPacket(r, r.size, from))
                    } catch (_: Exception) {}
                }, (rttMs + jitter).toLong(), TimeUnit.MILLISECONDS)
            }
        }, "lossy-dns").also { it.isDaemon = true }.start()
    }

    override fun close() { socket.close(); pool.shutdownNow() }
}

private fun queryPacket(id: Int, name: String, port: Int): ByteArray {
    val dns = Dns.buildQuery(id, name)
    val b = ByteArray(Packets.HDR + dns.size)
    b[0] = 0x45; Packets.put16(b, 2, b.size); Packets.put16(b, 6, 0x4000); b[8] = 64; b[9] = 17
    Packets.put32(b, 12, Packets.ip(10, 111, 222, 1)); Packets.put32(b, 16, Packets.ip(10, 111, 222, 3))
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, port); Packets.put16(b, 22, 53); Packets.put16(b, 24, 8 + dns.size)
    System.arraycopy(dns, 0, b, 28, dns.size)
    return b
}

private class Dist(val ms: DoubleArray) {
    val mean get() = ms.average()
    fun pct(p: Double): Double { val s = ms.sortedArray(); return s[((s.size - 1) * p).toInt()] }
    /** Temel RTT'nin üstündeki toplam bekleme. */
    fun excess(base: Double) = ms.sumOf { maxOf(0.0, it - base) }
}

/** Kayıplı sunucuya N sorgu; cevap gecikmeleri (cevapsızlar 4000 ms). */
private fun dnsRun(adaptive: Boolean, loss: Int, rtt: Int, n: Int): Dist {
    LossyDns(loss, rtt, 4242L).use { srv ->
        val sent = ConcurrentHashMap<Int, Long>()
        val lat = ConcurrentHashMap<Int, Double>()
        val fw = if (adaptive) DnsForwarder(listOf(srv.addr), { b, o, l ->
            if (l >= 30) { val id = Packets.u16(b, o + 28); sent[id]?.let { t0 -> lat.putIfAbsent(id, (System.nanoTime() - t0) / 1e6) } }
        })
        else DnsForwarder(listOf(srv.addr), { b, o, l ->
            if (l >= 30) { val id = Packets.u16(b, o + 28); sent[id]?.let { t0 -> lat.putIfAbsent(id, (System.nanoTime() - t0) / 1e6) } }
        }, retryAfterMs = MobilePolicy.OLD_DNS_RETRY_MS, sweepMs = MobilePolicy.OLD_DNS_SWEEP_MS)
        fw.start()
        try {
            for (i in 1..n) {
                val pkt = queryPacket(1000 + i, "q$i.mobil.test", 30000 + i)
                sent[1000 + i] = System.nanoTime()
                fw.onPacket(pkt, pkt.size)
                Thread.sleep(25)                                     // sorgular 25 ms arayla gelir (sayfa yüklenmesi gibi)
            }
            val end = System.currentTimeMillis() + 6000
            while (lat.size < n && System.currentTimeMillis() < end) Thread.sleep(50)
        } finally { fw.close() }
        return Dist(DoubleArray(n) { lat[1001 + it] ?: 4000.0 })
    }
}

/** Monte Carlo: TCP bağlanma süresi. Kayıp SYN'ler çekirdeğin 1, 3, 7 sn zamanlayıcısıyla yeniden gönderilir. */
private fun connectSim(hedge: Boolean, lossPct: Double, rttMs: Double, trials: Int, seed: Long): Dist {
    val rnd = Random(seed)
    val est = RttEstimator()
    fun rtt(): Double = rttMs * Math.exp(rnd.nextGaussian() * 0.35)             // log-normal dalgalanma
    fun attempt(startAt: Double): Double {                                       // bu deneme ne zaman bağlanır
        var t = startAt
        val sched = doubleArrayOf(0.0, 1000.0, 3000.0, 7000.0, 15000.0)
        for (k in sched.indices) {
            if (rnd.nextDouble() * 100 >= lossPct) return t + sched[k] + rtt()
        }
        return 1e9
    }
    val out = DoubleArray(trials)
    repeat(40) { est.sample(rtt()) }                                             // ağ bir süredir kullanılıyor: kestirici ısınmış
    for (i in 0 until trials) {
        val primary = attempt(0.0)
        val v = if (!hedge) primary else {
            val h = MobilePolicy.connectHedgeMs(est, slow = true).toDouble()
            if (primary - 0.0 <= h + 0.0 && primary < h + 1e-9) primary else minOf(primary, attempt(h))
        }
        out[i] = v
        if (v < 1e8 && out[i] < 600) est.sample(out[i])
    }
    return Dist(out)
}

private fun pctLess(old: Double, new: Double) = if (old <= 0.0) 0.0 else (old - new) / old * 100

fun runMobileTests() {
    T.group("Mobil: RTT kestirici ve süre ilkeleri")
    run {
        val e = RttEstimator()
        T.check("örneksiz kestirici: bilinmeyen değer döner", e.timeout(4.0, 20.0, 150, 1200, 400) == 400L && e.count() == 0)
        repeat(50) { e.sample(80.0) }
        val calm = e.timeout(4.0, 20.0, 150, 1200, 400)
        T.check("kararlı 80 ms: yeniden deneme ≈ 100–200 ms (sabit 1200 ms'nin çok altı)", calm in 150..200, "$calm")
        val j = RttEstimator(); val r = Random(1); repeat(200) { j.sample(80.0 * Math.exp(r.nextGaussian() * 0.5)) }
        val noisy = j.timeout(4.0, 20.0, 150, 1200, 400)
        T.check("dalgalı ağda süre uzar ama üst sınırı aşmaz", noisy > calm && noisy <= 1200, "$noisy")
        e.reset()
        T.check("sıfırlama (ağ değişimi) örnekleri siler", e.count() == 0 && e.srtt() == 0.0)
        val slow = RttEstimator().also { s -> repeat(30) { s.sample(1500.0) } }
        T.check("çok yavaş ağda (≈ 1,5 sn) yeniden deneme üst sınırda kalır", MobilePolicy.dnsRetryMs(slow) == 1200L)
        T.check("yedek bağlantı gecikmesi sınırlar içinde (100–1000 / mobil 150–1200)",
            MobilePolicy.connectHedgeMs(RttEstimator().also { it.sample(1.0) }, false) == 100L && MobilePolicy.connectHedgeMs(RttEstimator().also { it.sample(1.0) }, true) == 150L &&
                MobilePolicy.connectHedgeMs(slow, true) == 1200L)
        T.check("ilk aile bağlantı süresi 300–1500 ms arasında", MobilePolicy.firstFamilyMs(RttEstimator().also { it.sample(5.0) }) == 300L && MobilePolicy.firstFamilyMs(slow) == 1500L)
    }

    T.group("Mobil: ölçüm (eski ve yeni; gerçek soket + model)")
    run {
        // 1) DNS: %8 sorgu kaybı, 70 ms RTT (gerçek DnsForwarder, gerçek UDP)
        val oldD = dnsRun(false, 8, 70, 160)
        val newD = dnsRun(true, 8, 70, 160)
        val base = 70.0
        println("    DNS (gerçek soket, %8 kayıp, 70 ms RTT, 160 sorgu):")
        println("      eski  ort %.0f  p95 %.0f  p99 %.0f ms   kayıptan doğan bekleme %.1f sn".format(oldD.mean, oldD.pct(0.95), oldD.pct(0.99), oldD.excess(base * 1.4) / 1000))
        println("      yeni  ort %.0f  p95 %.0f  p99 %.0f ms   kayıptan doğan bekleme %.1f sn".format(newD.mean, newD.pct(0.95), newD.pct(0.99), newD.excess(base * 1.4) / 1000))
        val dnsExcess = pctLess(oldD.excess(base * 1.4), newD.excess(base * 1.4))
        println("      kayıptan doğan bekleme %%%.0f, p99 %%%.0f, ortalama %%%.0f azaldı".format(dnsExcess, pctLess(oldD.pct(0.99), newD.pct(0.99)), pctLess(oldD.mean, newD.mean)))
        T.check("DNS: kayıptan doğan bekleme en az %67 azalır", dnsExcess >= 67.0, "%.1f".format(dnsExcess))
        T.check("DNS: p99 en az %67 azalır", pctLess(oldD.pct(0.99), newD.pct(0.99)) >= 67.0, "%.0f → %.0f".format(oldD.pct(0.99), newD.pct(0.99)))
        T.check("DNS: hiçbir sorgu yeni yöntemle daha çok zaman aşımına uğramaz", newD.ms.count { it >= 4000.0 } <= oldD.ms.count { it >= 4000.0 })

        // 2) TCP bağlanma: %5 SYN kaybı, 80 ms RTT (model)
        val oc = connectSim(false, 5.0, 80.0, 40_000, 7)
        val nc = connectSim(true, 5.0, 80.0, 40_000, 7)
        val cb = 80.0 * 1.3
        println("    TCP bağlanma (model, %5 SYN kaybı, 80 ms RTT, 40 bin deneme):")
        println("      eski  ort %.0f  p95 %.0f  p99 %.0f ms".format(oc.mean, oc.pct(0.95), oc.pct(0.99)))
        println("      yeni  ort %.0f  p95 %.0f  p99 %.0f ms".format(nc.mean, nc.pct(0.95), nc.pct(0.99)))
        val connExcess = pctLess(oc.excess(cb), nc.excess(cb))
        println("      kayıptan doğan bekleme %%%.0f, p99 %%%.0f, ortalama %%%.0f azaldı".format(connExcess, pctLess(oc.pct(0.99), nc.pct(0.99)), pctLess(oc.mean, nc.mean)))
        T.check("TCP bağlanma: kayıptan doğan bekleme en az %67 azalır", connExcess >= 67.0, "%.1f".format(connExcess))
        T.check("TCP bağlanma: p99 en az %67 azalır", pctLess(oc.pct(0.99), nc.pct(0.99)) >= 67.0, "%.0f → %.0f".format(oc.pct(0.99), nc.pct(0.99)))

        // 3) Yanıtsız hedef (gerçek, GatewayTests'te ölçüldü)
        if (MobileBench.blackholeOldMs > 0 && MobileBench.blackholeNewMs > 0) {
            val g = pctLess(MobileBench.blackholeOldMs.toDouble(), MobileBench.blackholeNewMs.toDouble())
            println("    Yanıtsız hedef (gerçek soket): %d ms → %d ms (%%%.0f azaldı)".format(MobileBench.blackholeOldMs, MobileBench.blackholeNewMs, g))
            T.check("yanıtsız hedefte bağlanma süresi en az %67 azalır", g >= 67.0, "%.0f".format(g))
        }

        // 4) Ağ değişimi: akışlar takılı kalır (varsayım: uygulama 30 sn sonra pes eder) / yeni: RST + yeniden bağlanma
        if (MobileBench.handoverResetMs >= 0) {
            val assumedStall = 30_000.0
            val newStall = 500.0 + MobileBench.handoverResetMs + 150.0          // ağ izleme gecikmesi (0,5 sn) + sıfırlama + yeniden bağlanma (varsayım 150 ms)
            val g = pctLess(assumedStall, newStall)
            println("    Ağ değişimi: takılma ≈ %.0f ms (VARSAYIM: eskisinde uygulama zaman aşımı 30 sn) → ≈ %.0f ms (sıfırlama ölçülen %d ms) → %%%.0f azaldı".format(assumedStall, newStall, MobileBench.handoverResetMs, g))
            T.check("ağ değişiminde takılma süresi en az %67 azalır (eski süre varsayımdır)", g >= 67.0)
        }
    }
}
