package app.dnshizli.selftest

import app.dnshizli.core.*

/** Çökme günlüğü (gizlilik ve sınırlar) ve ayar sürüm taşıma adımları. */
fun runMaintenanceTests() {
    T.group("Çökme günlüğü")
    run {
        val frames = listOf(
            StackFrame("java.util.HashMap", 12),
            StackFrame("app.dnshizli.ui.Model", 412),
            StackFrame("app.dnshizli.ui.Widgets\$OrbBlock", 88),
            StackFrame("app.dnshizli.platform.DnsVpnService", 5),
            StackFrame("app.dnshizli.core.Catalog", 1),
        )
        val e = CrashLog.summarize("java.lang.IllegalStateException", frames, "main", "2026-10-08 20:30")
        T.check("kayıt türü, uygulama satırları ve iş parçacığını içerir", e == "2026-10-08 20:30 IllegalStateException @ Model:412 < Widgets\$OrbBlock:88 < DnsVpnService:5 (main)", e)
        T.check("en fazla 3 uygulama satırı", CrashLog.FRAMES == 3 && e.count { it == '<' } == 2)
        T.check("uygulama dışı satırlar kaydedilmez", !e.contains("HashMap") && !e.contains("Catalog"))
        T.check("uygulama satırı yoksa '?' yazılır", CrashLog.summarize("X", listOf(StackFrame("java.x.Y", 1)), "t", "T").contains("@ ? (t)"))
        T.check("paket adı kısaltılır, tam tür adı tutulmaz", !e.contains("java.lang"))

        val secret = CrashLog.summarize("java.net.UnknownHostException", listOf(StackFrame("app.dnshizli.core.Dns", 3)), "t", "T")
        T.check("hata mesajı (sunucu, IP) hiç yazılmaz", !secret.contains("1.1.1.1") && !secret.contains("example"))
        T.check("denetim karakteri ve satır sonu tek satıra indirilir", !CrashLog.summarize("A\nB", listOf(), "t\r\n", "T").contains('\n'))
        val long = CrashLog.summarize("X", listOf(StackFrame("app.dnshizli." + "a".repeat(500), 1)), "t", "T")
        T.check("uzun kayıt ${CrashLog.MAX_LINE} karakterde kırpılır", long.length <= CrashLog.MAX_LINE)

        val one = CrashLog.append(null, "A")
        T.check("ilk kayıt", CrashLog.entries(one) == listOf("A"))
        var raw: String? = null
        for (i in 1..8) raw = CrashLog.append(raw, "K$i")
        val list = CrashLog.entries(raw)
        T.check("en fazla ${CrashLog.KEEP} kayıt tutulur", list.size == CrashLog.KEEP)
        T.check("en yeni başta", list.first() == "K8" && list.last() == "K4")
        T.check("boş ve bozuk kayıtlı değer güvenle okunur", CrashLog.entries(null).isEmpty() && CrashLog.entries("\n\n  \n").isEmpty())
        T.check("eski tek kayıt biçimi de okunur", CrashLog.append("eski satır", "yeni") == "yeni\neski satır")
    }

    T.group("Ayar sürüm taşıma")
    run {
        T.check("sürüm alanı yoksa 1 kabul edilir", SettingsMigration.storedVersion(emptyMap()) == 1)
        T.check("bozuk sürüm 1 kabul edilir", SettingsMigration.storedVersion(mapOf("v" to "abc")) == 1 && SettingsMigration.storedVersion(mapOf("v" to "0")) == 1)
        val v1 = SettingsMigration.migrate(mutableMapOf<String, String?>("sortBySpeed" to "true"))
        T.check("sürüm 1: sortBySpeed → sortMode=speed", v1["sortMode"] == "speed" && v1["v"] == SettingsCodec.VERSION.toString())
        val v1off = SettingsMigration.migrate(mutableMapOf<String, String?>("sortBySpeed" to "false"))
        T.check("sürüm 1 kapalı: sortMode yazılmaz", v1off["sortMode"] == null)
        val keep = SettingsMigration.migrate(mutableMapOf<String, String?>("sortBySpeed" to "true", "sortMode" to "name"))
        T.check("yeni alan varsa eski değer onu ezmez", keep["sortMode"] == "name")
        val cur = mutableMapOf<String, String?>("v" to SettingsCodec.VERSION.toString(), "lang" to "en")
        T.check("güncel sürüm değişmez", SettingsMigration.migrate(cur) == mapOf("v" to SettingsCodec.VERSION.toString(), "lang" to "en"))
        val future = mutableMapOf<String, String?>("v" to "99", "lang" to "en")
        SettingsMigration.migrate(future)
        T.check("daha yeni sürüm (geri dönüş) olduğu gibi kalır", future["v"] == "99")
        val old = mapOf("sortBySpeed" to "true", "lang" to "en")
        T.check("decode eski kayıttan sıralamayı doğru okur", SettingsCodec.decode(old).sortMode == SortMode.SPEED)
        T.check("decode gidiş-dönüş: taşınmış değer kodlanıp geri okunur", SettingsCodec.decode(SettingsCodec.encode(SettingsCodec.decode(old))).sortMode == SortMode.SPEED)
        T.check("decode girdi haritasını değiştirmez", old.size == 2 && old["sortMode"] == null)
    }
}
