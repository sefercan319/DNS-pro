package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException

/**
 * Reklam / izleyici / zararlı alan adı engelleme: özet uyumu (Python aracıyla), ad düzenleme, liste dosyaları,
 * seviyeler ve öncelik, cevap üretimi, sarmalayıcı yönlendirici, ayarlar.
 */

private val assets = File("app/src/main/assets/filter")
private val fileSource = FilterSource { name -> File(assets, name).inputStream() }

private fun loadEngine(level: FilterLevel, allow: List<String> = emptyList(), block: List<String> = emptyList()): FilterEngine {
    FilterRuntime.source = fileSource
    FilterRuntime.reset()
    FilterRuntime.updateNow(level, allow, block)
    return FilterRuntime.engine!!
}

/** Alan adından DNS sorgusu (A) ve tür değiştirme. */
private fun dnsQuery(name: String, qtype: Int = 1, id: Int = 0x1234): ByteArray {
    val q = Dns.buildQuery(id, name)
    Packets.put16(q, q.size - 4, qtype)
    return q
}

private fun v4Pkt(dns: ByteArray, srcPort: Int = 40001): ByteArray {
    val b = ByteArray(Packets.HDR + dns.size)
    System.arraycopy(dns, 0, b, Packets.HDR, dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size); Packets.put16(b, 6, 0x4000); b[8] = 64; b[9] = 17
    Packets.put32(b, 12, Packets.ip(10, 111, 222, 1)); Packets.put32(b, 16, Packets.ip(10, 111, 222, 2))
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, srcPort); Packets.put16(b, 22, 53); Packets.put16(b, 24, 8 + dns.size)
    return b
}

private fun v6Pkt(dns: ByteArray, srcPort: Int = 40002): ByteArray {
    val b = ByteArray(Packets.HDR6 + dns.size)
    System.arraycopy(dns, 0, b, Packets.HDR6, dns.size)
    Packets.writeHeaders6(b, Ip.parse6(SelfTest.CLIENT_ADDR6)!!, Ip.parse6(SelfTest.FAKE_DNS6)!!, srcPort, 53, dns.size)
    return b
}

private class FakeInner : Forwarder {
    var got = 0
    override val proto: Proto get() = Proto.PLAIN
    override fun start() {}
    override fun onPacket(p: ByteArray, len: Int) { got++ }
    override fun stats() = Stats(queries = got.toLong(), forwarded = got.toLong())
    override fun resetNetwork(reason: String) {}
    override fun clearCache() {}
    override fun close() {}
}

fun runFilterTests() {
    println("\nEngelleme (reklam, izleyici, zararlı)\n")
    testFilterHash()
    testFilterNames()
    testFilterFiles()
    testFilterLevels()
    testFilterPriority()
    testImportedVsProtected()
    testFilterReply()
    testFilterForwarder()
    testFilterSettings()
    testFilterLive()
    testFilterUi()
    testFilterStrings()
}

private fun testFilterHash() {
    T.group("Engelleme: özet (Python aracıyla birebir)")
    // tools/build_filter.py ile hesaplanmış değerler
    T.check("doubleclick.net", FilterHash.hash("doubleclick.net") == 120233630452136L)
    T.check("example.com", FilterHash.hash("example.com") == 248243948190391L)
    T.check("a.b.c", FilterHash.hash("a.b.c") == 204046079641942L)
    T.check("www.google.com", FilterHash.hash("www.google.com") == 153964743827592L)
    T.check("özet 48 bite sığar ve eksi değildir", listOf("x.y", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.com", "a-b.c-d.e").all { FilterHash.hash(it) in 0L..0xFFFFFFFFFFFFL })
}

private fun testFilterNames() {
    T.group("Engelleme: alan adı düzenleme")
    val ok = mapOf(
        "Example.COM" to "example.com", " https://www.Ornek.com/yol?x=1#a " to "www.ornek.com", "*.ornek.com" to "ornek.com",
        ".ornek.com." to "ornek.com", "http://user:pw@a.b.com:8080/x" to "a.b.com", "ads_1.example-site.co" to "ads_1.example-site.co",
        "xn--80ak6aa92e.com" to "xn--80ak6aa92e.com",
    )
    for ((i, o) in ok) T.check("'$i' -> '$o'", FilterNames.normalize(i) == o, FilterNames.normalize(i).toString())
    val bad = listOf("", " ", "localhost", "com", "1.2.3.4", "999.1.1.1", "[::1]", "a..b.com", "-a.com", "a-.com", "a b.com", "çay.com", "x".repeat(64) + ".com")
    for (b in bad) T.check("geçersiz: '${b.take(20)}'", FilterNames.normalize(b) == null, FilterNames.normalize(b).toString())
    T.check("decode: yinelenenler ve geçersizler ayıklanır", FilterNames.decode("a.com, A.com,xx,b.com,,1.1.1.1") == listOf("a.com", "b.com"))
    T.check("encode/decode gidiş-dönüş", FilterNames.decode(FilterNames.encode(listOf("A.com", "b.org"))) == listOf("a.com", "b.org"))
    T.check("liste sınırı", FilterNames.decode((1..500).joinToString(",") { "s$it.com" }).size == FilterNames.MAX_LIST)
}

private fun testFilterFiles() {
    T.group("Engelleme: liste dosyaları")
    T.check("dosyalar var", listOf("basic.bin", "medium.bin", "strict.bin", "protected.txt", "KAYNAKLAR.txt").all { File(assets, it).isFile })
    val tiers = listOf("basic.bin", "medium.bin", "strict.bin").map { FilterTier.read(File(assets, it).inputStream()) }
    T.check("Basit en az 200 bin, Orta ve Sıkı en az 50 bin alan adı", tiers[0].size >= 200_000 && tiers[1].size >= 50_000 && tiers[2].size >= 100_000, tiers.map { it.size }.toString())
    for ((i, t) in tiers.withIndex()) {
        var sorted = true
        for (k in 1 until t.size) if (t.hashes[k] <= t.hashes[k - 1]) { sorted = false; break }
        T.check("katman $i sıralı ve tekrarsız", sorted)
    }
    val all = HashSet<Long>()
    var dup = 0
    for (t in tiers) for (h in t.hashes) if (!all.add(h)) dup++
    T.check("katmanlar birbirini yinelemez", dup == 0, "yinelenen=$dup")
    val raw = File(assets, "basic.bin").readBytes()
    fun bad(b: ByteArray): Boolean = try { FilterTier.read(ByteArrayInputStream(b)); false } catch (_: IOException) { true }
    T.check("kesik dosya reddedilir", bad(raw.copyOf(raw.size - 3)))
    T.check("bozuk başlık reddedilir", bad(raw.copyOf().also { it[0] = 'X'.code.toByte() }))
    T.check("fazlalık reddedilir", bad(raw + byteArrayOf(1, 2)))
    T.check("çok büyük sayı reddedilir", bad(byteArrayOf(68, 78, 70, 49, 0x7F, 0, 0, 0)))
    T.check("boş dosya reddedilir", bad(ByteArray(0)))
    val notes = File(assets, "KAYNAKLAR.txt").readText()
    T.check("kaynak ve lisans bildirimi var", notes.contains("StevenBlack") && notes.contains("blocklistproject") && notes.contains("MIT"))
}

private val POPULAR = ("google.com www.google.com gstatic.com googleapis.com youtube.com ytimg.com googlevideo.com gmail.com microsoft.com live.com " +
    "office.com windowsupdate.com apple.com icloud.com facebook.com instagram.com whatsapp.com whatsapp.net fbcdn.net twitter.com x.com t.co " +
    "tiktok.com amazon.com amazonaws.com cloudfront.net github.com githubusercontent.com cloudflare.com akamai.net fastly.net netflix.com " +
    "spotify.com wikipedia.org reddit.com yandex.com trendyol.com hepsiburada.com n11.com sahibinden.com turkcell.com.tr vodafone.com.tr " +
    "turktelekom.com.tr e-devlet.gov.tr turkiye.gov.tr garantibbva.com.tr isbank.com.tr ziraatbank.com.tr akbank.com yapikredi.com.tr " +
    "paypal.com stripe.com zoom.us discord.com telegram.org signal.org play.google.com android.com connectivitycheck.gstatic.com " +
    "captive.apple.com www.msftconnecttest.com firefox.com mozilla.org twimg.com linkedin.com pinterest.com ebay.com steampowered.com " +
    "epicgames.com outlook.com onedrive.com dropbox.com bing.com duckduckgo.com openai.com anthropic.com claude.ai github.io " +
    "dns.google one.one.one.one dns.quad9.net example.com example.org").split(' ')

private fun testFilterLevels() {
    T.group("Engelleme: seviyeler")
    val off = loadEngine(FilterLevel.OFF)
    val basic = loadEngine(FilterLevel.BASIC)
    val medium = loadEngine(FilterLevel.MEDIUM)
    val strict = loadEngine(FilterLevel.STRICT)
    T.check("Kapalı: hiçbir şey engellenmez", listOf("doubleclick.net", "googlesyndication.com").all { off.verdictOf(it) == FilterVerdict.PASS })
    val ads = listOf("doubleclick.net", "googlesyndication.com", "pagead2.googlesyndication.com", "adnxs.com", "ads.yahoo.com", "taboola.com", "criteo.com", "ads.tiktok.com")
    T.check("Basit: bilinen reklam alan adları engellenir", ads.all { basic.verdictOf(it) == FilterVerdict.LIST }, ads.filter { basic.verdictOf(it) != FilterVerdict.LIST }.toString())
    T.check("alt alan adı üst alan adı girdisiyle engellenir", basic.verdictOf("x.y.z.doubleclick.net") == FilterVerdict.LIST)
    T.check("benzer ad engellenmez (son ek eşleşmesi etiket sınırında)", basic.verdictOf("notdoubleclick.net") == FilterVerdict.PASS && basic.verdictOf("doubleclick.net.example.org") == FilterVerdict.PASS)
    T.check("büyük/küçük harf fark etmez", basic.verdictOf("DoubleClick.NET") == FilterVerdict.LIST)
    T.check("Orta: Basit'in hepsi ve fazlası", ads.all { medium.verdictOf(it) == FilterVerdict.LIST } && medium.verdictOf("sentry.io") == FilterVerdict.LIST)
    T.check("Basit, Orta'ya özgü adı engellemez", basic.verdictOf("sentry.io") == FilterVerdict.PASS)
    T.check("Sıkı: Orta'nın hepsini engeller", ads.all { strict.verdictOf(it) == FilterVerdict.LIST } && strict.verdictOf("sentry.io") == FilterVerdict.LIST)
    // Sıkı'ya özgü bir alan adı bulunabildi mi? (liste güncellenince değişebilir: katmanlar arası fark en az 1 gerçek ad)
    val strictOnly = FilterTier.read(File(assets, "strict.bin").inputStream())
    T.check("Sıkı katmanı Orta'dan ayrı bir küme", strictOnly.size > 0 && strictOnly.size != FilterTier.read(File(assets, "medium.bin").inputStream()).size)
    for ((lvl, e) in listOf("Basit" to basic, "Orta" to medium, "Sıkı" to strict)) {
        val hit = POPULAR.filter { e.verdictOf(it) != FilterVerdict.PASS }
        T.check("$lvl: tanınmış ${POPULAR.size} site engellenmez", hit.isEmpty(), hit.toString())
    }
    T.check("tek etiketli ad engellenmez", strict.verdictOf("localhost") == FilterVerdict.PASS && strict.verdictOf("com") == FilterVerdict.PASS)
    T.check("verdictOf geçersiz girdide geçirir", strict.verdictOf("") == FilterVerdict.PASS && strict.verdictOf("1.2.3.4") == FilterVerdict.PASS)
}

private fun testFilterPriority() {
    T.group("Engelleme: öncelik (izin > kullanıcı engeli > korunan > liste)")
    val e0 = loadEngine(FilterLevel.BASIC)
    T.check("ön koşul: doubleclick.net engelli", e0.verdictOf("doubleclick.net") == FilterVerdict.LIST)
    val a = loadEngine(FilterLevel.STRICT, allow = listOf("doubleclick.net"))
    T.check("izin listesi liste engelini kaldırır (alt alan adları dahil)", a.verdictOf("doubleclick.net") == FilterVerdict.PASS && a.verdictOf("stats.g.doubleclick.net") == FilterVerdict.PASS)
    val a2 = loadEngine(FilterLevel.BASIC, allow = listOf("stats.g.doubleclick.net"))
    T.check("alt alan adı izni yalnızca o ada uygulanır", a2.verdictOf("stats.g.doubleclick.net") == FilterVerdict.PASS && a2.verdictOf("doubleclick.net") == FilterVerdict.LIST)
    val b = loadEngine(FilterLevel.OFF, block = listOf("ornek-site.com"))
    T.check("kullanıcı engeli seviye kapalıyken de çalışır", b.verdictOf("ornek-site.com") == FilterVerdict.USER && b.verdictOf("a.ornek-site.com") == FilterVerdict.USER)
    T.check("kullanıcı engeli başka adı etkilemez", b.verdictOf("ornek-site.org") == FilterVerdict.PASS)
    val c = loadEngine(FilterLevel.BASIC, allow = listOf("x.com"), block = listOf("x.com"))
    T.check("izin, kullanıcı engelinden güçlüdür", c.verdictOf("x.com") == FilterVerdict.PASS)
    val d = loadEngine(FilterLevel.OFF, block = listOf("garantibbva.com.tr", "gov.tr", "connectivitycheck.gstatic.com"))
    T.check("kullanıcının açık engeli korunan adlardan güçlüdür", d.verdictOf("garantibbva.com.tr") == FilterVerdict.USER)
    val p = loadEngine(FilterLevel.STRICT)
    val prot = File(assets, "protected.txt").readLines().map { it.substringBefore('#').trim() }.filter { it.isNotEmpty() }
    T.check("korunan adlar ve alt alan adları her seviyede geçer (${prot.size} girdi)", prot.all { p.verdictOf(it) == FilterVerdict.PASS && p.verdictOf("x.$it") == FilterVerdict.PASS })
    T.check("korunan liste yeterince geniş", prot.size >= 40 && "gov.tr" in prot && "connectivitycheck.gstatic.com" in prot)
    val big = loadEngine(FilterLevel.STRICT, allow = (1..FilterNames.MAX_LIST).map { "a$it.com" })
    T.check("200 izinli adla da çalışır", big.verdictOf("a77.com") == FilterVerdict.PASS && big.verdictOf("doubleclick.net") == FilterVerdict.LIST)
}

private fun testImportedVsProtected() {
    T.group("Engelleme: içe aktarılan liste korunan adları engelleyemez")
    FilterRuntime.source = fileSource
    FilterRuntime.reset()
    FilterRuntime.setImported(listOf("connectivitycheck.gstatic.com", "x.garantibbva.com.tr", "benim-reklam.example.com", "time.android.com"))
    FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), listOf("elle-ekledigim.example.com", "time.cloudflare.com"))
    val e = FilterRuntime.engine!!
    T.check("içe aktarılan listedeki korunan adlar (ve alt alanları) geçer", e.verdictOf("connectivitycheck.gstatic.com") == FilterVerdict.PASS && e.verdictOf("x.garantibbva.com.tr") == FilterVerdict.PASS && e.verdictOf("time.android.com") == FilterVerdict.PASS)
    T.check("içe aktarılan listedeki sıradan ad engellenir", e.verdictOf("benim-reklam.example.com") == FilterVerdict.USER)
    T.check("elle eklenen engel korunan adı da engeller (açık tercih)", e.verdictOf("time.cloudflare.com") == FilterVerdict.USER && e.verdictOf("elle-ekledigim.example.com") == FilterVerdict.USER)
    FilterRuntime.reset()
}

private fun testFilterReply() {
    T.group("Engelleme: cevap üretimi")
    val e = loadEngine(FilterLevel.BASIC)
    val out = ByteArray(600)
    fun reply(name: String, qtype: Int): Pair<Int, ByteArray> {
        val q = dnsQuery(name, qtype, 0xBEEF)
        val qEnd = Dns.questionEnd(q, 0, q.size)
        val n = FilterEngine.buildBlocked(q, 0, qEnd, out, 10)
        return n to (if (n > 0) out.copyOfRange(10, 10 + n) else ByteArray(0))
    }
    val (na, ra) = reply("doubleclick.net", 1)
    val qA = dnsQuery("doubleclick.net", 1, 0xBEEF).size
    if (FilterEngine.NXDOMAIN_FOR_BLOCKED) {
        T.check("A: kimlik, QR/RD/RA, RCODE=3 (NXDOMAIN), soru 1, cevap 0, yetki 1", na == qA + 33 && Packets.u16(ra, 0) == 0xBEEF && Packets.u16(ra, 2) == 0x8183 && Packets.u16(ra, 4) == 1 && Packets.u16(ra, 6) == 0 && Packets.u16(ra, 8) == 1, "n=$na ${Packets.u16(ra, 2)}")
    } else {
        T.check("A: kimlik, QR/RD/RA, soru 1, cevap 1 (0.0.0.0)", na == qA + 16 && Packets.u16(ra, 0) == 0xBEEF && Packets.u16(ra, 2) == 0x8180 && Packets.u16(ra, 4) == 1 && Packets.u16(ra, 6) == 1, "n=$na ${Packets.u16(ra, 2)}")
    }
    T.check("A: engelleme cevabı olarak tanınır", Dns.isLocalBlock(ra, 0, ra.size))
    val q = dnsQuery("doubleclick.net", 1, 0xBEEF)
    T.check("soru bölümü aynen korunur", Dns.sameQuestion(q, 0, Dns.questionEnd(q, 0, q.size), ra, 0, ra.size))
    val (n6, r6) = reply("doubleclick.net", 28)
    if (FilterEngine.NXDOMAIN_FOR_BLOCKED) T.check("AAAA: NXDOMAIN, yanıt yok", n6 > 0 && (Packets.u16(r6, 2) and 0xF) == 3 && Packets.u16(r6, 6) == 0 && Dns.isLocalBlock(r6, 0, r6.size))
    else T.check("AAAA: :: (0.0.0.0 biçimi)", n6 > 0 && Packets.u16(r6, 6) == 1 && r6.copyOfRange(r6.size - 16, r6.size).all { it.toInt() == 0 } && Dns.isBlocked(r6, 0, r6.size))
    for ((t, nm) in listOf(15 to "MX", 16 to "TXT", 65 to "HTTPS", 64 to "SVCB", 255 to "ANY", 5 to "CNAME")) {
        val (n, r) = reply("doubleclick.net", t)
        T.check("$nm: cevapsız NOERROR (kayıt yok)", n > 0 && Packets.u16(r, 6) == 0 && (Packets.u16(r, 2) and 0xF) == 0 && n == Dns.questionEnd(q, 0, q.size))
    }
    val ch = dnsQuery("doubleclick.net", 1)
    Packets.put16(ch, ch.size - 2, 3)
    T.check("sınıfı IN olmayan sorgu için cevap üretilmez", FilterEngine.buildReply(ch, 0, ch.size, out, 0) == -1)
    T.check("tampon küçükse -1", FilterEngine.buildReply(q, 0, Dns.questionEnd(q, 0, q.size), ByteArray(20), 0) == -1)
    val rdOff = dnsQuery("doubleclick.net", 1).also { Packets.put16(it, 2, 0x0000) }
    val (_, rr) = run { val qe = Dns.questionEnd(rdOff, 0, rdOff.size); val n = FilterEngine.buildReply(rdOff, 0, qe, out, 0); n to out.copyOf(n) }
    T.check("RD bayrağı sorgudan kopyalanır (kapalıysa kapalı)", (Packets.u16(rr, 2) and 0x0100) == 0 && (Packets.u16(rr, 2) and 0x8000) != 0)
    // bozuk/sıradışı sorgular geçirilir
    val upper = Dns.buildQuery(1, "DOUBLEclick.NET")
    T.check("telde büyük harfli sorgu da engellenir", e.verdict(upper, 0, upper.size) == FilterVerdict.LIST && e.lastName() == "doubleclick.net")
    T.check("kısa/bozuk sorgu geçer", e.verdict(ByteArray(5), 0, 5) == FilterVerdict.PASS && e.verdict(upper, 0, 14) == FilterVerdict.PASS)
    val two = upper.copyOf().also { Packets.put16(it, 4, 2) }
    T.check("birden çok soru: geçer (içteki yönlendirici karar verir)", e.verdict(two, 0, two.size) == FilterVerdict.PASS)
    val ptr = upper.copyOf().also { it[12] = 0xC0.toByte() }
    T.check("soruda sıkıştırma işaretçisi: geçer", e.verdict(ptr, 0, ptr.size) == FilterVerdict.PASS)
    val nonAscii = Dns.buildQuery(1, "doubleclick.net").also { it[13] = 0xE7.toByte() }
    T.check("ASCII dışı bayt: geçer", e.verdict(nonAscii, 0, nonAscii.size) == FilterVerdict.PASS)
    val longName = ByteArray(12 + 300 + 5).also { Packets.put16(it, 4, 1); var i = 12; repeat(5) { _ -> it[i++] = 60; repeat(60) { _ -> it[i++] = 'a'.code.toByte() } } }
    T.check("çok uzun ad: geçer", e.verdict(longName, 0, longName.size) == FilterVerdict.PASS)
}

private fun testFilterForwarder() {
    T.group("Engelleme: sarmalayıcı yönlendirici")
    loadEngine(FilterLevel.BASIC, allow = listOf("izinli.example"), block = listOf("engelli.example"))
    val inner = FakeInner()
    val wrote = ArrayList<ByteArray>()
    val fw = FilteringForwarder(inner) { b, off, len -> wrote.add(b.copyOfRange(off, off + len)) }
    FilterLive.clear()
    fun v4(name: String, qtype: Int = 1, id: Int = 0x4321) = v4Pkt(dnsQuery(name, qtype, id))
    var p = v4("doubleclick.net")
    fw.onPacket(p, p.size)
    T.check("IPv4: engellenen sorgu içeri verilmez, cevap tünele yazılır", inner.got == 0 && wrote.size == 1)
    val r = wrote[0]
    T.check("IPv4 cevabı: geçerli IP, UDP, kaynak 53, hedef istemci portu", (r[0].toInt() and 0xF0) == 0x40 && (r[9].toInt() and 0xFF) == 17 &&
        Packets.u16(r, 20) == 53 && Packets.u16(r, 22) == 40001 && Packets.udpChecksumOk(r, 20, r.size - 20, Packets.i32(r, 12), Packets.i32(r, 16)))
    T.check("IPv4 cevabı: adresler yer değiştirmiş", Packets.i32(r, 12) == Packets.ip(10, 111, 222, 2) && Packets.i32(r, 16) == Packets.ip(10, 111, 222, 1))
    T.check("IPv4 cevabı: istemci kimliği ve engelleme cevabı", Packets.u16(r, Packets.HDR) == 0x4321 && Dns.isLocalBlock(r, Packets.HDR, r.size - Packets.HDR))
    p = v6Pkt(dnsQuery("doubleclick.net", 28, 0x7777))
    fw.onPacket(p, p.size)
    val r6 = wrote.last()
    T.check("IPv6: engellenen sorgunun cevabı IPv6 olarak yazılır", wrote.size == 2 && (r6[0].toInt() and 0xF0) == 0x60 && Packets.u16(r6, Packets.HDR6) == 0x7777 &&
        Packets.u16(r6, 40) == 53 && Packets.u16(r6, 42) == 40002 && Dns.isLocalBlock(r6, Packets.HDR6, r6.size - Packets.HDR6))
    p = v4("example.com"); fw.onPacket(p, p.size)
    T.check("engellenmeyen sorgu içeri verilir, yazılmaz", inner.got == 1 && wrote.size == 2)
    p = v4("izinli.example"); fw.onPacket(p, p.size)
    p = v4("sub.izinli.example"); fw.onPacket(p, p.size)
    T.check("izinli ad geçer", inner.got == 3)
    p = v4("engelli.example"); fw.onPacket(p, p.size)
    p = v4("alt.engelli.example", 15); fw.onPacket(p, p.size)
    T.check("kullanıcının engellediği ad (A ve MX) cevaplanır", inner.got == 3 && wrote.size == 4)
    val junk = byteArrayOf(1, 2, 3); fw.onPacket(junk, junk.size)
    val resp = v4("doubleclick.net").also { it[Packets.HDR + 2] = (it[Packets.HDR + 2].toInt() or 0x80).toByte() }
    fw.onPacket(resp, resp.size)
    T.check("bozuk paket ve cevap paketi içeri verilir (karar içtekinin)", inner.got == 5 && wrote.size == 4)
    val s = fw.stats()
    T.check("istatistik: engellenenler sorgu ve engellenen sayısına eklenir", s.blocked == 4L && s.queries == inner.got + 4L, "$s")
    T.check("canlı liste: bu oturumda engellenen adlar (ad, adet, kaynak)", FilterLive.blockedTotal == 4L &&
        FilterLive.recent().first { it.name == "doubleclick.net" }.count == 2 && FilterLive.recent().first { it.name == "alt.engelli.example" }.user)
    FilterRuntime.reset()
    p = v4("doubleclick.net"); fw.onPacket(p, p.size)
    T.check("motor yokken (liste yüklenmedi) her şey içeri verilir", inner.got == 6 && wrote.size == 4)
    loadEngine(FilterLevel.OFF)
    p = v4("doubleclick.net"); fw.onPacket(p, p.size)
    T.check("seviye kapalıyken içeri verilir", inner.got == 7)
    FilterRuntime.source = FilterSource { throw IOException("yok") }
    FilterRuntime.reset(); FilterRuntime.updateNow(FilterLevel.STRICT, emptyList(), listOf("engelli.example"))
    p = v4("doubleclick.net"); fw.onPacket(p, p.size)
    p = v4("engelli.example"); fw.onPacket(p, p.size)
    T.check("liste dosyası okunamazsa sessizce kapalı kalır; kullanıcı engeli çalışır", inner.got == 8 && wrote.size == 5)
    loadEngine(FilterLevel.OFF)
    // yazım: kapanış ve devralınan yöntemler
    fw.start(); fw.resetNetwork("x"); fw.clearCache(); fw.close()
    T.check("diğer yöntemler içtekine devredilir", fw.proto == Proto.PLAIN)
}

private fun testFilterSettings() {
    T.group("Engelleme: ayarlar")
    val d = AppSettings()
    T.check("varsayılan: kapalı, listeler boş", d.filterLevel == FilterLevel.OFF && d.filterAllow.isEmpty() && d.filterBlock.isEmpty())
    val s = AppSettings(filterLevel = FilterLevel.MEDIUM, filterAllow = listOf("a.com", "b.org"), filterBlock = listOf("c.net"))
    val back = SettingsCodec.decode(SettingsCodec.encode(s))
    T.check("kayıt gidiş-dönüş", back.filterLevel == FilterLevel.MEDIUM && back.filterAllow == listOf("a.com", "b.org") && back.filterBlock == listOf("c.net"))
    T.check("bozuk seviye varsayılana düşer", SettingsCodec.decode(mapOf("filterLevel" to "zzz")).filterLevel == FilterLevel.OFF)
    T.check("bozuk liste girdileri ayıklanır", SettingsCodec.decode(mapOf("filterAllow" to "ok.com,<script>,1.2.3.4,x")).filterAllow == listOf("ok.com"))
    val exp = SettingsCodec.export(s)
    T.check("dışa/içe aktarma filtre ayarlarını taşır", SettingsCodec.import(exp, AppSettings())?.let { it.filterLevel == FilterLevel.MEDIUM && it.filterAllow == listOf("a.com", "b.org") } == true)
    val changes = ImportReview.changes(AppSettings(filterLevel = FilterLevel.STRICT), AppSettings(filterLevel = FilterLevel.BASIC))
    T.check("içe aktarmada seviye düşerse uyarı", SensitiveChange.RULES in changes)
    T.check("içe aktarmada izin listesine ad eklenirse uyarı", SensitiveChange.RULES in ImportReview.changes(AppSettings(), AppSettings(filterAllow = listOf("a.com"))))
    T.check("seviye yükselirse uyarı yok", SensitiveChange.RULES !in ImportReview.changes(AppSettings(), AppSettings(filterLevel = FilterLevel.STRICT)))
    T.check("seviye kimlikleri benzersiz, byId gidiş-dönüş", FilterLevel.values().map { it.id }.toSet().size == 4 && FilterLevel.values().all { FilterLevel.byId(it.id) == it } && FilterLevel.byId("x") == null)
    T.check("seviyeler birikimli", FilterLevel.values().map { it.tiers } == listOf(0, 1, 2, 3))
}

private fun testFilterLive() {
    T.group("Engelleme: oturum listesi")
    FilterLive.clear()
    T.check("başlangıçta boş", FilterLive.recent().isEmpty() && FilterLive.blockedTotal == 0L)
    for (i in 1..60) FilterLive.note("s$i.example.com", false)
    T.check("en çok 40 ad, en yeni önde", FilterLive.recent().size == 40 && FilterLive.recent().first().name == "s60.example.com" && FilterLive.blockedTotal == 60L)
    FilterLive.note("s30.example.com", true)
    T.check("tekrar eden ad öne alınır ve sayılır", FilterLive.recent().first().name == "s30.example.com" && FilterLive.recent().first().count == 2)
    T.check("liste kopyası değiştirilemez (anlık görüntü)", run { val r = FilterLive.recent(); r.first().count = 99; FilterLive.recent().first().count == 2 })
    FilterLive.clear()
    T.check("temizlenir", FilterLive.recent().isEmpty() && FilterLive.blockedTotal == 0L)
    // "Geçmişi tut" kapalı: adlar listeye hiç alınmaz, sayaç artar; kapatılınca mevcut adlar silinir.
    FilterLive.note("a.example.com", false)
    FilterLive.keep(false)
    T.check("geçmiş kapatılınca liste hemen boşalır", FilterLive.recent().isEmpty())
    FilterLive.note("b.example.com", false)
    T.check("geçmiş kapalıyken ad saklanmaz ama sayaç artar", FilterLive.recent().isEmpty() && FilterLive.blockedTotal == 2L)
    FilterLive.keep(true)
    FilterLive.note("c.example.com", false)
    T.check("geçmiş açılınca adlar yeniden listelenir", FilterLive.recent().size == 1)
    FilterLive.clear()
}

private fun shown(r: Rig): List<String> = TextRecorder().also { r.scene.draw(it) }.runs.map { it.s }

private fun testFilterUi() {
    T.group("Engelleme: arayüz")
    FilterLive.clear()
    val r = Rig()
    r.scene.openMenu(); r.settle(900)
    T.check("menüde Engelleme satırı ve seviye değeri var", r.find(Strings.FILTER, exact = true) != null && shown(r).contains(Strings.OPT_FILTER[0]))
    r.scene.back(); r.settle(900)
    r.scene.openSection(Section.FILTER); r.settle(900)
    T.check("sayfada seviye seçici, kapalı notu, sayaç ve üç satır var",
        shown(r).contains(Strings.FILTER_LEVEL) && shown(r).any { Strings.FILTER_NOTES[0].startsWith(it.removeSuffix("…")) && it.length > 6 } &&
            r.find(Strings.FILTER_LAST) != null && r.find(Strings.FILTER_ALLOW) != null && r.find(Strings.FILTER_BLOCK) != null)
    r.tapText(Strings.FILTER_LEVEL + ": " + Strings.OPT_FILTER[2], settleMs = 900)
    T.check("Orta seçilince ayar kaydolur ve not değişir", r.model.settings.filterLevel == FilterLevel.MEDIUM && shown(r).any { Strings.FILTER_NOTES[2].startsWith(it.removeSuffix("…")) && it.length > 6 })

    // izin listesine ekleme
    r.tapText(Strings.FILTER_ALLOW, settleMs = 900)
    r.host.textAnswer = "https://www.Ornek.com/yol"
    r.tapText(Strings.FILTER_ADD, settleMs = 900)
    T.check("yazılan adres temizlenip izin listesine eklenir", r.model.settings.filterAllow == listOf("www.ornek.com"), r.model.settings.filterAllow.toString())
    T.check("engel listesinden çıkar, eklenen ad listede görünür", shown(r).contains("www.ornek.com"))
    r.host.textAnswer = null
    r.tapText("www.ornek.com", settleMs = 900)
    T.check("ada dokununca kaldırma sorusu çıkar, onaylanınca silinir", r.model.toast?.text == Strings.filterRemoveAsk("www.ornek.com") && r.model.settings.filterAllow.isNotEmpty())
    r.model.toast?.onAction?.invoke(); r.settle(300)
    T.check("onaydan sonra liste boş", r.model.settings.filterAllow.isEmpty())

    // model kuralları
    T.check("geçersiz ad reddedilir ve uyarı verir", !r.model.addFilterName(false, "yanlış ad") && r.model.toast?.text == Strings.FILTER_ERR && r.model.settings.filterBlock.isEmpty())
    T.check("IP adresi reddedilir", !r.model.addFilterName(false, "1.2.3.4"))
    T.check("kendi engel listesine eklenir", r.model.addFilterName(false, "reklam.example.org") && r.model.settings.filterBlock == listOf("reklam.example.org"))
    T.check("aynı ad izin listesine eklenince engelden çıkar", r.model.addFilterName(true, "reklam.example.org") && r.model.settings.filterBlock.isEmpty() && r.model.settings.filterAllow == listOf("reklam.example.org"))
    T.check("engele eklenince izinden çıkar", r.model.addFilterName(false, "reklam.example.org") && r.model.settings.filterAllow.isEmpty())
    r.model.update { it.copy(filterBlock = emptyList()) }
    for (i in 1..FilterNames.MAX_LIST) r.model.addFilterName(true, "s$i.example.com")
    T.check("izin listesi 200'de durur", r.model.settings.filterAllow.size == FilterNames.MAX_LIST && !r.model.addFilterName(true, "fazla.example.com") && r.model.toast?.text == Strings.FILTER_ERR_LIMIT)
    T.check("dolu listede var olan ad yine eklenebilir (taşınır)", r.model.addFilterName(true, "s1.example.com") && r.model.settings.filterAllow.size == FilterNames.MAX_LIST)
    r.model.update { it.copy(filterAllow = emptyList()) }

    // son engellenenler
    r.settle(300)
    FilterLive.clear()
    FilterLive.note("izleyici.example.net", false)
    FilterLive.note("benim.example.org", true)
    r.settle(900)
    r.tapText(Strings.FILTER_LAST, settleMs = 900)
    T.check("son engellenenler paneli adları gösterir", shown(r).contains("izleyici.example.net") && shown(r).contains("benim.example.org"))
    r.tapText("izleyici.example.net", settleMs = 900)
    T.check("ada dokununca izin listesine eklenir", r.model.settings.filterAllow == listOf("izleyici.example.net"))
    FilterLive.clear()
    r.tapText(Strings.FILTER_LAST, settleMs = 900)
    T.check("boşken açıklama görünür", shown(r).any { Strings.FILTER_RECENT_EMPTY.startsWith(it.removeSuffix("…")) && it.length > 8 })
}

private fun testFilterStrings() {
    T.group("Engelleme: metinler (12 dil)")
    val saved = L.lang
    try {
        for (lang in Lang.values()) {
            L.set(lang)
            val n = lang.code
            T.check("$n: 4 seviye adı, kısa ve farklı", Strings.OPT_FILTER.size == 4 && Strings.OPT_FILTER.all { it.length in 2..11 } && Strings.OPT_FILTER.toSet().size == 4, Strings.OPT_FILTER.toString())
            T.check("$n: 4 seviye notu 12..100 karakter", Strings.FILTER_NOTES.size == 4 && Strings.FILTER_NOTES.all { it.length in 12..100 }, Strings.FILTER_NOTES.map { it.length }.toString())
            T.check("$n: açıklama 60..420 karakter, NXDOMAIN ve izin yolunu anlatır", Strings.FILTER_INFO.length in 60..420, Strings.FILTER_INFO.length.toString())
            val short = listOf(Strings.FILTER, Strings.FILTER_LAST, Strings.FILTER_ALLOW, Strings.FILTER_BLOCK, Strings.FILTER_ADD, Strings.FILTER_REMOVE_BTN, Strings.FILTER_REMOVE)
            T.check("$n: başlıklar 2..32 karakter", short.all { it.length in 2..32 }, short.toString())
            val fn = listOf(Strings.filterAllowed("a.com"), Strings.filterBlocked("a.com"), Strings.filterRemoved("a.com"), Strings.filterRemoveAsk("a.com"))
            T.check("$n: ad içeren mesajlar adı taşır", fn.all { "a.com" in it && it.length < 90 }, fn.toString())
            val long = listOf(Strings.FILTER_RECENT_EMPTY, Strings.FILTER_RECENT_FOOT, Strings.FILTER_ALLOW_FOOT, Strings.FILTER_BLOCK_FOOT, Strings.FILTER_ALLOW_EMPTY, Strings.FILTER_BLOCK_EMPTY, Strings.FILTER_ERR, Strings.FILTER_ERR_LIMIT)
            T.check("$n: uzun metinler boş değil ve 10..200 karakter", long.all { it.length in 10..200 }, long.map { it.length }.toString())
            T.check("$n: ağdaki yer tutucu kalmamış", (short + long + fn + Strings.FILTER_NOTES + Strings.FILTER_INFO).none { "TODO" in it || "{" in it || "%s" in it })
        }
    } finally { L.set(saved) }
}
