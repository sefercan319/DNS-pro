package app.dnshizli.selftest

import app.dnshizli.core.UiStyle
import java.io.File
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element

/** Manifest denetimi: dışa açık bileşenler, izinler ve yedekleme/şifresiz trafik ayarları beklenenden farklıysa test kırılır. */
fun runManifestTests() {
    T.group("Manifest güvenlik denetimi")
    val f = listOf("app/src/main/AndroidManifest.xml", "../app/src/main/AndroidManifest.xml").map { File(it) }.firstOrNull { it.isFile }
    if (f == null) { T.check("manifest bulundu", false, "proje kökünden çalıştır"); return }
    val doc = DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }.newDocumentBuilder().parse(f)
    val ns = "http://schemas.android.com/apk/res/android"
    fun attr(e: Element, n: String): String? = e.getAttributeNS(ns, n).takeIf { it.isNotEmpty() }
    val app = doc.getElementsByTagName("application").item(0) as Element

    T.check("yedekleme kapalı (allowBackup=false)", attr(app, "allowBackup") == "false")
    T.check("hata ayıklanabilir bayrağı yok", attr(app, "debuggable") != "true")
    T.check("şifresiz HTTP trafiği izinli değil", attr(app, "usesCleartextTraffic") != "true" && attr(app, "networkSecurityConfig") != null)

    val perms = (0 until doc.getElementsByTagName("uses-permission").length).map { (doc.getElementsByTagName("uses-permission").item(it) as Element).getAttributeNS(ns, "name") }.toSet()
    val allowed = setOf(
        "android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE", "android.permission.FOREGROUND_SERVICE",
        "android.permission.FOREGROUND_SERVICE_SYSTEM_EXEMPTED", "android.permission.RECEIVE_BOOT_COMPLETED", "android.permission.POST_NOTIFICATIONS",
    )
    T.check("izinler yalnızca beklenenler", perms == allowed, (perms - allowed).toString() + " / eksik: " + (allowed - perms))

    fun comps(tag: String): List<Element> = (0 until doc.getElementsByTagName(tag).length).map { doc.getElementsByTagName(tag).item(it) as Element }
    val vpn = comps("service").firstOrNull { attr(it, "name")?.endsWith("DnsVpnService") == true }
    T.check("VPN servisi dışa kapalı ve sistem iznine bağlı", vpn != null && attr(vpn, "exported") == "false" && attr(vpn, "permission") == "android.permission.BIND_VPN_SERVICE")
    val exportedServices = comps("service").filter { attr(it, "exported") == "true" }.map { attr(it, "name") ?: "" }
    T.check("dışa açık servis yalnızca hızlı ayar kutucuğu (sistem izniyle)",
        exportedServices.size == 1 && exportedServices[0].endsWith("DnsTileService") &&
            comps("service").first { attr(it, "exported") == "true" }.let { attr(it, "permission") == "android.permission.BIND_QUICK_SETTINGS_TILE" }, exportedServices.toString())
    val exportedReceivers = comps("receiver").filter { attr(it, "exported") == "true" }.map { (attr(it, "name") ?: "").substringAfterLast('.') }.toSet()
    T.check("dışa açık alıcılar yalnızca widget ve açılış", exportedReceivers == setOf("DnsWidget", "BootReceiver"), exportedReceivers.toString())
    T.check("başka yetkisiz içerik sağlayıcı yok", comps("provider").isEmpty())
    val acts = comps("activity")
    T.check("tek gerçek etkinlik var ve başlatıcıdan açılır", acts.size == 1 && attr(acts[0], "exported") == "true")
    // her stilin kendi simgesi var: takma ad (Aqua ana etkinlik) ve üç vektör dosyası
    val aliases = comps("activity-alias").associate { (attr(it, "name") ?: "") to (attr(it, "icon") ?: "") }
    val resDir = File(f.parentFile, "res")
    val missing = UiStyle.values().filter { it != UiStyle.AQUA }.filter { st ->
        val n = st.id; val cls = ".platform.Icon" + n.replaceFirstChar { it.uppercase() }
        aliases[cls] != "@mipmap/ic_launcher_$n" || listOf("bg", "fg", "mono").any { !File(resDir, "drawable/ic_launcher_${it}_$n.xml").isFile } || !File(resDir, "mipmap-anydpi-v26/ic_launcher_$n.xml").isFile
    }
    T.check("her stilin simge takma adı ve çizimleri var (Liquid dâhil)", missing.isEmpty() && aliases.containsKey(".platform.IconLiquid"), missing.toString())
}
