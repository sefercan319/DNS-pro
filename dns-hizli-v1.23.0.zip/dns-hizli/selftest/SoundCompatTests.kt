package app.dnshizli.selftest

import app.dnshizli.core.*

/**
 * Ses uyumluluk katmanı: cihazın hangi yolda çalıştığını bulma, hatırlama ve yıkılmadan geçme davranışı.
 * Android'in kendisi burada yok; gerçek cihaz davranışı [SoundBackend] arkasında sahte bir motorla sınanır.
 */
fun runSoundCompatTests() {
    T.group("Ses uyumluluğu: yol seçimi, hatırlama ve dayanıklılık")
    run {
        val calls = ArrayList<SoundPath>()
        val fails = HashSet<SoundPath>()
        val throws = HashSet<SoundPath>()
        val remembered = ArrayList<SoundPath>()
        val logs = ArrayList<String>()
        val backend = object : SoundBackend {
            override fun play(path: SoundPath, e: Sfx, volume: Float): Boolean {
                calls.add(path)
                if (path in throws) throw IllegalStateException("cihaz")
                return path !in fails
            }
        }
        val c = SoundCompat(backend, null, { remembered.add(it) }, { logs.add(it) })

        T.check("ilk çalmada ilk yol denenir ve çalışırsa hatırlanır", c.play(Sfx.TAP, 0.5f) == SoundPath.STATIC_RELOAD && remembered == listOf(SoundPath.STATIC_RELOAD))
        calls.clear()
        c.play(Sfx.TAP, 0.5f)
        T.check("hatırlanan yol bir sonraki çalmada önce denenir", calls == listOf(SoundPath.STATIC_RELOAD) && remembered.size == 1)

        // Samsung benzeri: statik yol istisna atar, akış çalışır.
        throws.add(SoundPath.STATIC_RELOAD)
        calls.clear()
        val p = c.play(Sfx.TAP, 0.5f)
        T.check("istisna atan yol atlanır, sıradaki çalışır ve yeni yol hatırlanır", p == SoundPath.STREAM_SONIFICATION && c.best == p && remembered.last() == p)
        T.check("istisna günlüğe yazılır (tür adıyla, kişisel veri yok)", logs.any { it.contains("STATIC_RELOAD") && it.contains("IllegalStateException") })
        calls.clear()
        c.play(Sfx.TAP, 0.5f)
        T.check("yeni hatırlanan yol önce denenir (statik tekrar denenmez)", calls == listOf(SoundPath.STREAM_SONIFICATION))

        // Çalışan yol bir gün bozulursa (ör. sistem sesi kapandı) sıradakine kendiliğinden geçer.
        fails.add(SoundPath.STREAM_SONIFICATION)
        calls.clear()
        val p2 = c.play(Sfx.TAP, 0.5f)
        T.check("hatırlanan yol bozulursa sıradakine geçilir", p2 == SoundPath.STREAM_MEDIA && c.best == SoundPath.STREAM_MEDIA && calls.first() == SoundPath.STREAM_SONIFICATION)
        T.check("yol değişince günlüğe yazılır", logs.any { it == "ses yolu: STREAM_MEDIA" })
    }

    run {
        // Hiçbir yol çalmıyor: uygulama çökmez, sayaç artar, sonra sıfırlanır.
        val backend = object : SoundBackend {
            override fun play(path: SoundPath, e: Sfx, volume: Float): Boolean = throw RuntimeException("yok")
        }
        val logs = ArrayList<String>()
        val c = SoundCompat(backend, SoundPath.TONE, { }, { logs.add(it) })
        var threw = false
        var nulls = 0
        repeat(120) { if (c.play(Sfx.CONNECT, 0.8f) == null) nulls++ }
        T.check("hiçbir yol çalmazsa istisna çıkmaz ve sessizce vazgeçilir", !threw && nulls == 120)
        T.check("üst üste başarısızlık sayılır", c.failures == 120)
        T.check("başarısızlık günlüğü seyrek yazılır (taşmaz)", logs.count { it.contains("hiçbir ses yolu") } in 1..4)
    }

    run {
        // Başlangıçta kayıtlı yol varsa o önce denenir (uygulama yeniden açılınca).
        val calls = ArrayList<SoundPath>()
        val backend = object : SoundBackend {
            override fun play(path: SoundPath, e: Sfx, volume: Float): Boolean { calls.add(path); return true }
        }
        val c = SoundCompat(backend, SoundPath.STREAM_MEDIA, { }, { })
        c.play(Sfx.DONE, 0.3f)
        T.check("kayıtlı yol açılışta önce denenir", calls == listOf(SoundPath.STREAM_MEDIA))
        T.check("sıra dört yolun tümünü kapsar", SoundPath.values().size == 4)
    }
}
