# Sürüm notları

Ayrıntılı geliştirme tarihçesi ve kararlar: [DNS_HIZLI_TARIHCE.txt](DNS_HIZLI_TARIHCE.txt). En yeni sürüm en üstte.

## 1.23.0 (versionCode 40)

**Yeni**
- **Oblivious DoH (ODoH, RFC 9230)**, isteğe bağlı, varsayılan **kapalı** (☰ > DNS ayarları > Oblivious DoH: Kapalı / Yedekli / Sıkı). Sorgu hedef sunucunun anahtarıyla şifrelenip bir **röle** üzerinden gider: röle IP'nizi görür ama soruyu göremez, DNS sunucusu soruyu görür ama sizi göremez.
  - *Yedekli:* önce ODoH; kurulamazsa normal şifreli yöntemler (gizlilik düştü uyarısıyla) ve ODoH'a dönmek için arka planda yeniden deneme. *Sıkı:* yalnızca ODoH; kurulamazsa bağlanmaz, hiçbir yönteme düşmez.
  - ODoH seçili DNS sunucusundan bağımsızdır; uygulamanın kendi röle + hedef çiftlerini kullanır (2 röle × 3 hedef, her çiftte iki ayrı işletmeci; aynı işletmeci ya da alan adı eşleşmez, kurucu bunu reddeder).
- **Kendini onaran, çok katmanlı motor:** (1) yol seçimi: gecikme + hata puanı, devre kesici, üstel geri çekilme (2 sn → 2 dk, ±%20 sapma), yarı açık tek deneme, bayat yolların yoklanması; (2) anahtar yönetimi: tek uçuşlu alım, 6 saat taze, alınamazsa 7 güne kadar bayat anahtarla devam, 401'de hız sınırlı yenileme (anahtar dönmesi arıza sayılmaz); (3) adresler: son çalışan → ipucu → şifreli (DoT) ad çözümü, düz DNS hiç kullanılmaz; (4) bağlantı: aynı sorguda ölü röleden sonra başka röleye geçiş, sahte/bozuk cevap yolu uzun süre keser; (5) ağ değişince yol bilgisi sıfırlanır.
- Gizlilik ayrıntıları: her sorgu için taze HPKE anahtarı, DNS kimliği 0, düz metin 128 baytın katına doldurulur, cevaplar kimlik doğrulamalı; hedefin yapılandırması doğrudan (röleden değil) alınır, bu sırada hedef IP'nizi görür ama soru görmez.
- Kendi X25519 + HPKE (RFC 9180) gerçeklemesi (dış kütüphane yok); RFC 7748 / RFC 9180 vektörleriyle ve JDK ile 300 rastgele çapraz sınamayla doğrulandı.
- Araç: `tools/odoh_check.py` canlı röle/hedef denetimi.

**Dürüst sınırlar**
- ODoH yalnızca **DNS sağlayıcısından IP'nizi** saklar. Operatörünüz, Wi-Fi sahibi ve bağlandığınız siteler IP'nizi yine görür; röle trafik zamanını ve hacmini görür. Gizlilik, rölenin ve hedefin **anlaşmamasına** dayanır.
- Gerçek röle/hedeflerle **canlı uyumluluk bu ortamda denenemedi** (ağ yok); şifreleme RFC vektörleriyle ve bağımsız bir sunucu benzetimiyle sınandı. Röle/hedef IP ipuçları Ekim 2026 tarihlidir. Cihazda denenmedi: VPN servisi entegrasyonu, bildirimler, ağ değişimi.

**Test:** 6153 kontrol, 0 hata (212 yeni: şifreleme, yapılandırma, ileti biçimi, yol tahtası, anahtar önbelleği, katalog, adres defteri, ayarlar, uçtan uca benzetim).

## 1.22.0 (versionCode 39)

**Yeni**
- **Liquid Glass stili:** yarı saydam mavi-indigo cam, parlak beyaz kenar ışığı, cam anahtar damlası. Kendi dokunma efekti, ses paketi (parlak, dalgalanan cam tınısı) ve uygulama simgesi (cam küre içinde kalkan ve güç simgesi).
- **Her stile 4 yeni animasyon:** panel açılması, geri, seçim, yenileme. Sekiz mevcut paket için ayrı çizimler; Liquid Glass'ın 10 animasyonunun hepsi kendine özel. Toplam 10 paket × 10 animasyon.
- **Her ses paketine 2 yeni ses:** seçim ve yenileme. Seçenek, sunucu veya tema seçince seçim sesi; ölçüm ve bağlantı testi başlayınca yenileme sesi çalar.

**Değişti**
- Uygulama **güvenlik / ağ aracı** olarak konumlandırıldı: mağaza metni ve kısa açıklamalar (12 dil) "zararlı, kimlik avı ve izleyici alan adlarına karşı koruma" diline çevrildi.
- Stil, simge ve ses paketi açıklamaları 12 dilde güncellendi.

**Test:** 5941 kontrol, 0 hata. Cihazda doğrulanmadı: görünüm, ses beğenisi, yeni simgenin başlatıcıdaki görünümü.

## 1.21.9
- Gömülü **Public Suffix List**: "aynı site" kararı gerçek eTLD+1'e bakar (co.uk, com.tr, github.io…); sıcak yolda bellek ayırmaz.
- **Filtre belleği** ayarı: Otomatik / Hafif / Tam. Az belleği olan telefonda en büyük liste atlanır, bellek yetmezse çökmeden devam edilir.
- "Yalnızca seçilenler"de seçili uygulama yoksa koruma **başlamaz** (Android boş listeyi "hepsi" sayar); hata gösterilir.
- Play beyan taslağına kontrol listesi eklendi.

## 1.21.8
- Filtre listeleri akışla okunur (tam dosya ayrıca belleğe alınmaz), bellek yetmezse yedek yol.
- Özel son ek listesi, SecureForwarder yarışı, TcpDns port sarması düzeltmeleri, ayar önbelleği.

## 1.21.5 – 1.21.7
- Dış incelemelerden doğrulanan düzeltmeler: içe aktarılan listenin korunan adları geçemesi, tema örnek küresi önbelleği, CNAME sayacının atomik olması, ağ geçidi adres elemesi, regresyon testleri.

## 1.10 – 1.21
- Kendi kullanıcı alanı TCP/UDP aktarıcısı (ağ geçidi), DPI atlatma ve Reklam+ düğmeleri, mobil ağ politikası, ses uyumluluğu (Rahatsız Etmeyin), yeni hareket motoru, ses efektleri, stile özgü efektler, profiller, sessiz saatler.

## 1.9.x
- Dört seviyeli koruma/engelleme, izin ve engel listesi, kendini onarma, kendi TCP katmanımız, bildirim sistemi, gecikme grafiği, kendi liste içe/dışa aktarma, Aurora stili, IPv4 + IPv6.

## 1.1 – 1.8
- Özel DNS sunucuları ve 32'lik katalog, uygulama başına kapsam, stiller ve sayfa geçişleri, arka plan fotoğrafı, uygulama simgeleri, sorun giderici, sunucu arama, ☰ menü ve Hakkında, kişiselleştirme penceresi.
