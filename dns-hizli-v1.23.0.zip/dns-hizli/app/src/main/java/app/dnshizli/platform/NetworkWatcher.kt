package app.dnshizli.platform

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import app.dnshizli.core.NetFamilies
import app.dnshizli.core.NetInfo
import app.dnshizli.core.NetKind
import app.dnshizli.core.Rules

/**
 * Fiziksel ağlardaki (VPN hariç) değişiklikleri izler: Wi-Fi <-> mobil geçişi, ağın kaybolması, doğrulanması.
 * Değişiklik 0,5 sn beklenip tek olay olarak bildirilir ([onChanged], ana iş parçacığında). Sistem olay
 * üretmedikçe hiçbir şey çalışmaz: elle yoklama veya zamanlayıcı yoktur.
 */
class NetworkWatcher(context: Context, private val onChanged: (NetKind, Long) -> Unit) {
    private val appContext = context.applicationContext
    private val cm = appContext.getSystemService(ConnectivityManager::class.java)
    private val main = Handler(Looper.getMainLooper())

    // Aşağıdakilere yalnızca ana iş parçacığından dokunulur.
    private val nets = LinkedHashMap<Network, NetworkCapabilities>()
    private var lastSig: String? = null
    private var registered = false

    private val evaluate = Runnable { evaluateNow() }

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            nets[network] = caps
            schedule()
        }

        override fun onLost(network: Network) {
            nets.remove(network)
            schedule()
        }

        // Ağa IPv6 sonradan gelebilir (yönlendirici duyurusu): IP aileleri değişirse yeniden değerlendirilir.
        override fun onLinkPropertiesChanged(network: Network, linkProperties: android.net.LinkProperties) {
            schedule()
        }
    }

    fun start() {
        main.post {
            if (registered || cm == null) return@post
            nets.clear()
            lastSig = null
            try {
                val req = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                    .build()
                cm.registerNetworkCallback(req, callback, main)
                registered = true
                schedule()          // ilk değerlendirme başlangıç durumunu (taban çizgisini) belirler
            } catch (_: Exception) {
                // izin yok ya da sistem reddetti: ağ izleme olmadan devam
            }
        }
    }

    fun stop() {
        main.post {
            main.removeCallbacks(evaluate)
            if (registered) {
                try { cm?.unregisterNetworkCallback(callback) } catch (_: Exception) {}
                registered = false
            }
            nets.clear()
            lastSig = null
        }
    }

    private fun schedule() {
        main.removeCallbacks(evaluate)
        main.postDelayed(evaluate, DEBOUNCE_MS)
    }

    private fun evaluateNow() {
        val kind = Rules.pick(nets.values.map { info(it) })
        val sig = buildString {
            for ((n, c) in nets) {
                append(n.toString()).append(if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) "+" else "-").append(';')
            }
            append(kind).append(';').append(families(appContext))
        }
        if (sig == lastSig) return
        val baseline = lastSig == null
        lastSig = sig
        if (!baseline) onChanged(kind, handleOf(kind, nets))
    }

    companion object {
        private const val DEBOUNCE_MS = 500L

        /** [kind] türündeki (doğrulanmış olan önce) ağın sistem tanıtıcısı; yoksa ya da okunamazsa 0. Aynı ağda sabittir, ağ değişince değişir. */
        fun handleOf(kind: NetKind, list: Map<Network, NetworkCapabilities>): Long {
            var best = 0L
            var bestValidated = false
            for ((n, c) in list) {
                val match = when (kind) {
                    NetKind.WIFI -> c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                    NetKind.ETHERNET -> c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                    NetKind.MOBILE -> c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                    else -> true
                }
                if (!match) continue
                val v = c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                if (best == 0L || (v && !bestValidated)) {
                    best = try { n.networkHandle } catch (_: Throwable) { 0L }
                    bestValidated = v
                }
            }
            return best
        }

        /** Şu an etkin fiziksel ağın tanıtıcısı (tek seferlik okuma). */
        @Suppress("DEPRECATION")
        fun currentHandle(context: Context): Long {
            val cm = context.applicationContext.getSystemService(ConnectivityManager::class.java) ?: return 0L
            return try {
                val m = LinkedHashMap<Network, NetworkCapabilities>()
                for (n in cm.allNetworks) {
                    val c = cm.getNetworkCapabilities(n) ?: continue
                    if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) || !c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)) continue
                    m[n] = c
                }
                handleOf(Rules.pick(m.values.map { info(it) }), m)
            } catch (_: Exception) { 0L }
        }

        private fun info(c: NetworkCapabilities) = NetInfo(
            wifi = c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI),
            cellular = c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR),
            ethernet = c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET),
            validated = c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED),
        )

        private val PROBE4: java.net.InetAddress = java.net.InetAddress.getByAddress(byteArrayOf(8, 8, 8, 8))
        private val PROBE6: java.net.InetAddress = java.net.InetAddress.getByAddress(
            byteArrayOf(0x20, 0x01, 0x48, 0x60, 0x48, 0x60, 0, 0, 0, 0, 0, 0, 0, 0, 0x88.toByte(), 0x88.toByte()),
        )

        /**
         * Etkin ağın (VPN hariç) hangi IP ailelerini kullanabildiği: o aileye ait bir çıkış (varsayılan) yolu olması.
         * Ad çözümlemesi yapmaz; yalnızca ağ yollarına bakar. Okunamazsa ya da hiçbir yol yoksa [NetFamilies.UNKNOWN].
         */
        @Suppress("DEPRECATION")
        fun families(context: Context): NetFamilies {
            val cm = context.applicationContext.getSystemService(ConnectivityManager::class.java) ?: return NetFamilies.UNKNOWN
            return try {
                var v4 = false
                var v6 = false
                val active = cm.activeNetwork
                val list = ArrayList<Network>()
                val ac = active?.let { cm.getNetworkCapabilities(it) }
                if (active != null && ac != null && ac.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)) list.add(active)
                else for (n in cm.allNetworks) {
                    val c = cm.getNetworkCapabilities(n) ?: continue
                    if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) || !c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)) continue
                    list.add(n)
                }
                for (n in list) {
                    val lp = cm.getLinkProperties(n) ?: continue
                    for (r in lp.routes) {
                        if (r.matches(PROBE4)) v4 = true
                        if (r.matches(PROBE6)) v6 = true
                    }
                }
                if (!v4 && !v6) NetFamilies.UNKNOWN else NetFamilies(v4, v6)
            } catch (_: Exception) {
                NetFamilies.UNKNOWN
            }
        }

        private val WKP_NAT64 = byteArrayOf(0x00, 0x64, 0xFF.toByte(), 0x9B.toByte(), 0, 0, 0, 0, 0, 0, 0, 0)

        /**
         * IPv6-only (NAT64) ağda, IPv4 hedefler için kullanılacak 96 bitlik ön ek (12 bayt). Android 11+ ağın bildirdiği ön eki verir;
         * daha eskisinde ağ yalnızca IPv6 ise iyi bilinen 64:ff9b::/96 varsayılır. IPv6 yoksa ya da ağ çift yığınsa null.
         */
        @Suppress("DEPRECATION")
        fun nat64Prefix(context: Context, fam: NetFamilies): ByteArray? {
            if (!fam.v6) return null
            val cm = context.applicationContext.getSystemService(ConnectivityManager::class.java) ?: return null
            try {
                if (android.os.Build.VERSION.SDK_INT >= 30) {
                    for (n in cm.allNetworks) {
                        val c = cm.getNetworkCapabilities(n) ?: continue
                        if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) || !c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)) continue
                        val p = cm.getLinkProperties(n)?.nat64Prefix ?: continue
                        if (p.prefixLength == 96) return p.rawAddress.copyOf(12)
                    }
                }
            } catch (_: Exception) {}
            return if (fam.v6Only) WKP_NAT64.copyOf() else null
        }

        /** Şu an hangi tür ağın kullanıldığı (tek seferlik okuma; izleme gerektirmez). */
        @Suppress("DEPRECATION")
        fun currentKind(context: Context): NetKind {
            val cm = context.applicationContext.getSystemService(ConnectivityManager::class.java) ?: return NetKind.NONE
            return try {
                val list = ArrayList<NetInfo>()
                for (n in cm.allNetworks) {
                    val c = cm.getNetworkCapabilities(n) ?: continue
                    if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                    if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN).not()) continue
                    list.add(info(c))
                }
                Rules.pick(list)
            } catch (_: Exception) {
                NetKind.NONE
            }
        }
    }
}
