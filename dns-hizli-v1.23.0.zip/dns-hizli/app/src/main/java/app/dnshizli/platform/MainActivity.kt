package app.dnshizli.platform

import android.Manifest
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.content.res.Configuration
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher
import android.net.Uri
import app.dnshizli.R
import kotlin.math.max
import kotlin.math.min
import app.dnshizli.core.AppEntry
import app.dnshizli.core.AppScopes
import app.dnshizli.core.AppSettings
import app.dnshizli.core.NetCheck
import app.dnshizli.core.PrivateDns
import app.dnshizli.core.Sfx
import app.dnshizli.core.Voice
import app.dnshizli.core.ServerSearch
import app.dnshizli.core.UiStyle
import app.dnshizli.core.Catalog
import app.dnshizli.core.CustomDns
import app.dnshizli.core.DnsProbe
import app.dnshizli.core.Targets
import app.dnshizli.core.Journal
import app.dnshizli.core.L
import app.dnshizli.core.Latency
import app.dnshizli.core.OrbState
import app.dnshizli.core.Pic
import app.dnshizli.core.Proto
import app.dnshizli.core.SelfTestResult
import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.WpBlur
import app.dnshizli.ui.AppModel
import app.dnshizli.ui.Host
import app.dnshizli.ui.Scene
import app.dnshizli.ui.Strings
import app.dnshizli.ui.VpnUi
import java.util.concurrent.ExecutorService
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Tek ekranlı uygulamanın etkinliği: sahneyi kurar, Android'e özgü yetenekleri ([Host]) sağlar, VPN iznini ister,
 * kısayol/kutucuk niyetlerini işler. Ağır iş yoktur; VPN'in kendisi [DnsVpnService]'te çalışır.
 */
class MainActivity : Activity(), SceneView.Listener {

    private lateinit var prefs: PrefsStore
    private lateinit var model: AppModel
    private lateinit var scene: Scene
    private var view: SceneView? = null
    private val host = AndroidHost()
    private val main = Handler(Looper.getMainLooper())
    private val soundFx by lazy { SoundFx(applicationContext) }

    private var pendingServer: String? = null
    private var pendingModules: Triple<Boolean, Boolean, () -> Unit>? = null
    private var connectRequestedAt = 0L
    private var visible = false
    private var destroyedFlag = false
    private var pool: ExecutorService? = null
    private var backCallback: Any? = null
    private var backRegistered = false

    private val vpnListener: (VpnUi) -> Unit = { applyVpn(it) }
    private val testListener: (SelfTestResult) -> Unit = { if (!destroyedFlag) model.onTestResult(it) }
    private val pull = object : Runnable {
        override fun run() {
            pullStatus()
            main.removeCallbacks(this)          // pullStatus içinden de kurulmuş olabilir: tek zamanlayıcı kalsın
            if (visible && model.vpn.active) main.postDelayed(this, 1000)
        }
    }

    // ------------------------------------------------------------------ yaşam döngüsü

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsStore(this)
        val settings = prefs.loadSettings()
        App.applyLanguage(this, settings.lang)
        model = AppModel(host, settings, prefs.loadLatencies(), prefs.loadHistory())
        val metrics = PaintMetrics()
        scene = Scene(model, metrics)
        val v = SceneView(this, scene, model, AndroidGfx(metrics), this)
        view = v
        setContentView(v)
        setupEdgeToEdge(v)
        applyConfig()
        applyVpn(withPause(VpnStatus.snapshot()))
        // Kısayol/kutucuk eylemi yalnızca gerçekten yeni bir açılışta işlenir: süreç öldükten sonra yeniden kurulan ya da
        // "son kullanılanlar"dan açılan etkinlik eski niyeti taşır ve onu yeniden uygulamamalıdır.
        val launchedFromHistory = ((intent?.flags ?: 0) and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0
        handleIntent(intent, savedInstanceState == null && !launchedFromHistory)
        host.updateShortcuts(Catalog.all.filter { it.id in model.settings.favorites }.map { it.id })
        IconSwitcher.sync(this, model.settings.appIcon)
        // İlk açılışta bildirim izni sorulur (Android 13+): arayüz görününce, bir kez.
        main.postDelayed({ if (!destroyedFlag && !isFinishing) maybeAskNotifications() }, 800)
    }

    /** Süreç duraklatma sırasında yeniden başladıysa (servis çalışmıyor) bitiş zamanını depodan ekler. */
    private fun withPause(ui: VpnUi): VpnUi {
        if (ui.active || ui.pausedUntil != 0L) return ui
        val t = prefs.pausedUntil()
        return if (t > System.currentTimeMillis()) ui.copy(pausedUntil = t) else ui
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Açıkken gelen yeni niyet (kısayol, bildirim): eylemi işlenir, ama "açılınca bağlan" yeniden tetiklenmez.
        val action = intent.action
        if (action == DnsVpnService.ACTION_CONNECT || action == DnsVpnService.ACTION_DISCONNECT || action == DnsVpnService.ACTION_PAUSE) {
            handleIntent(intent, true)
        }
    }

    override fun onResume() {
        super.onResume()
        visible = true
        applyConfig()
        VpnStatus.addListener(vpnListener)
        VpnStatus.addTestListener(testListener)
        pullStatus()
        view?.resume()
        if (model.vpn.active) main.postDelayed(pull, 1000)
        model.onStart()
    }

    /** Seçilmiş ama henüz uygulanmamış başlatıcı simgesi (uygulamadan çıkınca uygulanır). */
    private var pendingIcon: UiStyle? = null

    override fun onStop() {
        super.onStop()
        val want = pendingIcon ?: return
        pendingIcon = null
        IconSwitcher.apply(applicationContext, want)
    }

    override fun onPause() {
        visible = false
        main.removeCallbacks(pull)
        VpnStatus.removeListener(vpnListener)
        VpnStatus.removeTestListener(testListener)
        view?.pause()
        super.onPause()
    }

    override fun onDestroy() {
        soundFx.shutdown()
        destroyedFlag = true
        main.removeCallbacksAndMessages(null)
        pool?.shutdownNow()
        unregisterBack()
        super.onDestroy()
    }

    /** Yazı boyutu, koyu/açık mod, yoğunluk, yön değişimleri etkinliği yeniden başlatmadan işlenir. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyConfig()
        view?.onDisplayChanged()
    }

    private fun applyConfig() {
        val cfg = resources.configuration
        // Android 13+: kullanıcı uygulama dilini sistem ayarlarından değiştirdiyse onu benimse.
        // (Sistemde açık bir seçim yoksa uygulama içi seçim geçerlidir ve sisteme yazılır.)
        // Android 13+: sistemin "uygulama dili" ayarı esastır (uygulama içi seçim de oraya yazılır).
        App.systemAppLocale(this)?.let { raw ->
            val sys = L.normalize(raw)
            val stored = model.settings.lang
            if (sys == L.AUTO && stored != L.AUTO && !prefs.localeSynced()) {
                // Android 13'e yükseltmeden önce seçilen dil sisteme hiç yazılmamış: sistemi ona göre ayarla, seçimi silme.
                App.syncSystemLocale(this, stored)
                prefs.setLocaleSynced()
            } else if (sys != stored) {
                model.update { it.copy(lang = sys) }
            }
        }
        model.setAccentSeed(host.systemAccent())
        val before = L.tx
        App.applyLanguage(this, model.settings.lang)
        if (L.tx !== before) { model.onLanguageChanged(); Notifier.ensureChannel(this) }
        scene.setFontScale(cfg.fontScale)
        scene.setSystemDark((cfg.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES)
        // Sistem animasyon ölçeği 0 (erişilebilirlik ya da pil tasarrufu) ise animasyonlar kapanır.
        scene.setSystemMotion(ValueAnimator.areAnimatorsEnabled())
        view?.requestFrame()
    }

    // ------------------------------------------------------------------ kenardan kenara, sistem çubukları

    @Suppress("DEPRECATION")
    private fun setupEdgeToEdge(v: SceneView) {
        val w = window
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false)
        } else {
            w.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        w.statusBarColor = Color.TRANSPARENT
        w.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = w.attributes
            lp.layoutInDisplayCutoutMode =
                if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            w.attributes = lp
        }
        v.setOnApplyWindowInsetsListener { _, insets ->
            val top: Int
            val bottom: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                top = i.top
                bottom = i.bottom
            } else {
                top = insets.systemWindowInsetTop
                bottom = insets.systemWindowInsetBottom
            }
            v.setInsets(top, bottom)
            insets
        }
    }

    /** Tema açıksa (açık zemin) koyu simgeler, koyuysa açık simgeler. */
    @Suppress("DEPRECATION")
    override fun onThemeDark(dark: Boolean) {
        val light = !dark
        if (Build.VERSION.SDK_INT >= 30) {
            val c = window.insetsController ?: return
            val mask = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            c.setSystemBarsAppearance(if (light) mask else 0, mask)
        } else {
            val d = window.decorView
            var f = d.systemUiVisibility
            f = if (light) f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            f = if (light) f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            d.systemUiVisibility = f
        }
    }

    // ------------------------------------------------------------------ geri

    /** Geri tuşu yalnızca alt panel/alt sayfa açıkken bizdedir; ana ekranda sistemin kendi davranışı (ve geri animasyonu) çalışır. */
    override fun onBackAvailable(can: Boolean) {
        if (Build.VERSION.SDK_INT >= 33) {
            if (can) registerBack() else unregisterBack()
        }
    }

    @SuppressLint("NewApi")
    private fun registerBack() {
        if (backRegistered || Build.VERSION.SDK_INT < 33) return
        val cb = (backCallback as? OnBackInvokedCallback) ?: OnBackInvokedCallback { scene.goBack() }.also { backCallback = it }
        onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb)
        backRegistered = true
    }

    @SuppressLint("NewApi")
    private fun unregisterBack() {
        if (!backRegistered || Build.VERSION.SDK_INT < 33) return
        (backCallback as? OnBackInvokedCallback)?.let { onBackInvokedDispatcher.unregisterOnBackInvokedCallback(it) }
        backRegistered = false
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (!scene.goBack()) super.onBackPressed()
    }

    // ------------------------------------------------------------------ VPN durumu

    /**
     * Servisten gelen durumu modele aktarır. Bağlanma isteği yeni verilmişken gelen eski "kapalı" bilgisi
     * (servis henüz başlamamıştır) yok sayılır; yoksa küre bağlanırken bir an kapalıya döner.
     */
    private fun applyVpn(ui: VpnUi) {
        if (ui.state == OrbState.OFF && model.vpn.state == OrbState.CONNECTING &&
            SystemClock.elapsedRealtime() - connectRequestedAt < CONNECT_GRACE_MS
        ) return
        val was = model.vpn.state
        model.onVpn(ui)
        if (ui.state == OrbState.ON && was != OrbState.ON) {
            if (visible) { main.removeCallbacks(pull); main.postDelayed(pull, 1000) }
            maybeAskNotifications()
        }
    }

    /**
     * Arayüz görünürken saniyede bir: canlı sayaçlar ve servisin yazdığı toplamlar. Servis kendi başına uyanmaz.
     * Servisin kendisinin değiştirdiği seçim (bildirimdeki "Sonraki", yedek sunucu) de alınır; böylece arayüz bir sonraki
     * kaydında onu eskisiyle ezmez.
     */
    private fun pullStatus() {
        val fresh = prefs.loadSettings()
        val cur = model.settings
        val next = cur.copy(
            wasActive = fresh.wasActive,
            totalQueries = fresh.totalQueries, totalHits = fresh.totalHits, totalBlocked = fresh.totalBlocked,
            totalSeconds = fresh.totalSeconds, daily = fresh.daily, totalAnswered = fresh.totalAnswered,
            totalLatencyMs = fresh.totalLatencyMs, bytesUp = fresh.bytesUp, bytesDown = fresh.bytesDown,
            usage = fresh.usage, sessions = fresh.sessions,
            lastServer = fresh.lastServer ?: cur.lastServer, recent = fresh.recent,
        )
        if (next != cur) model.replaceSettings(next)
        applyVpn(withPause(VpnStatus.snapshot()))
    }

    private fun maybeAskNotifications() {
        if (Build.VERSION.SDK_INT < 33 || prefs.askedNotifications()) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        prefs.setAskedNotifications()
        try { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ bağlan / kes

    private fun connect(serverId: String) {
        connectRequestedAt = SystemClock.elapsedRealtime()
        val consent = try { VpnService.prepare(this) } catch (_: Exception) { null }
        if (consent != null) {
            pendingServer = serverId
            try {
                startActivityForResult(consent, REQ_VPN)
            } catch (_: Exception) {
                pendingServer = null
                model.onVpn(VpnUi(OrbState.ERROR, null, 0, 0, 0, 0, Strings.ERR_PERMISSION))
            }
        } else {
            startVpn(serverId)
        }
    }

    private fun startModules(dpi: Boolean, ads: Boolean, onFail: () -> Unit) {
        try {
            startForegroundService(DnsVpnService.modulesIntent(this, dpi, ads))
        } catch (e: Exception) {
            Journal.add("modül komutu gönderilemedi: ${e.javaClass.simpleName}")
            onFail()
        }
    }

    private fun applyModules(dpi: Boolean, ads: Boolean, onFail: () -> Unit) {
        val consent = try { VpnService.prepare(this) } catch (_: Exception) { null }
        if (consent == null) { startModules(dpi, ads, onFail); return }
        pendingModules = Triple(dpi, ads, onFail)
        try {
            startActivityForResult(consent, REQ_VPN_MOD)
        } catch (_: Exception) {
            pendingModules = null
            onFail()
        }
    }

    /** [serverId] boşsa servis, ağ kuralına ya da son kullanılan sunucuya bakar. */
    private fun startVpn(serverId: String?) {
        try {
            startForegroundService(DnsVpnService.connectIntent(this, serverId))
        } catch (e: Exception) {
            Journal.add("servis başlatılamadı: ${e.javaClass.simpleName}")
            model.onVpn(VpnUi(OrbState.ERROR, null, 0, 0, 0, 0, Strings.ERR_UNKNOWN))
        }
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_WALLPAPER) { onWallpaperResult(resultCode, data); return }
        if (requestCode == REQ_TEXTFILE) { onTextFileResult(resultCode, data); return }
        if (requestCode == REQ_VPN_MOD) {
            val m = pendingModules
            pendingModules = null
            if (m == null) return
            if (resultCode == RESULT_OK) startModules(m.first, m.second, m.third)
            else { m.third(); model.toast(Strings.ERR_PERMISSION) }
            return
        }
        if (requestCode != REQ_VPN) return
        val id = pendingServer          // etkinlik izin penceresi açıkken yeniden yaratıldıysa boştur
        pendingServer = null
        if (resultCode == RESULT_OK) {
            startVpn(id)
        } else {
            // İzin verilmedi: küre bağlanıyor durumunda kalmasın.
            connectRequestedAt = 0
            model.onVpn(VpnUi())
            model.toast(Strings.ERR_PERMISSION)
        }
    }

    private var textFileCallback: ((String?) -> Unit)? = null

    /** Metin dosyası seçici döndü: içerik (en çok [HostsList.MAX_CHARS] karakter) arka planda okunur, sonuç arayüze verilir. */
    private fun onTextFileResult(resultCode: Int, data: Intent?) {
        val cb = textFileCallback
        textFileCallback = null
        if (resultCode != RESULT_OK || cb == null) return                    // vazgeçildi: sessiz
        val uri = data?.data
        if (uri == null) { runOnUiThread { cb(null) }; return }
        val resolver = contentResolver
        Thread({
            val text = try {
                resolver.openInputStream(uri)?.use { ins ->
                    // Karakter sınırı kadar okunur; devasa dosya belleği doldurmasın.
                    val max = app.dnshizli.core.HostsList.MAX_CHARS
                    val sb = StringBuilder()
                    ins.reader(Charsets.UTF_8).use { r ->
                        val buf = CharArray(8192)
                        while (sb.length < max) {
                            val n = r.read(buf, 0, minOf(buf.size, max - sb.length))
                            if (n < 0) break
                            sb.append(buf, 0, n)
                        }
                    }
                    sb.toString()
                }
            } catch (e: Exception) {
                Journal.add("liste dosyası okunamadı: ${e.javaClass.simpleName}")
                null
            }
            runOnUiThread { if (!isDestroyed) cb(text) }
        }, "dns-listfile").apply { isDaemon = true }.start()
    }

    /** Seçici döndü: fotoğraf arka planda hazırlanıp kaydedilir (UI donmaz), sonuç modele bildirilir. */
    private fun onWallpaperResult(resultCode: Int, data: Intent?) {
        if (resultCode != RESULT_OK) return                         // vazgeçildi: sessiz
        // Bazı seçiciler tek seçimi `data` yerine `clipData` içinde döndürür.
        val uri = data?.data ?: data?.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
        if (uri == null) { Journal.add("arka plan: seçiciden adres gelmedi"); model.onWallpaperPicked(false); return }
        val dm = resources.displayMetrics
        val aspect = min(dm.widthPixels, dm.heightPixels).toFloat() / max(dm.widthPixels, dm.heightPixels).toFloat()
        val app = applicationContext
        Thread({
            val ok = WallpaperStore.save(app, uri, aspect)
            runOnUiThread { if (!isDestroyed) model.onWallpaperPicked(ok) }
        }, "dns-wallpaper").apply { isDaemon = true }.start()
    }

    /**
     * Kısayol, kutucuk, widget ve bildirimden gelen niyetler, ve "uygulama açılınca bağlan" ayarı.
     *
     * Güven: uygulamanın kendi kısayolları ve PendingIntent'leri dışa kapalı [INTERNAL_ALIAS] takma adını kullanır;
     * başka bir uygulama yalnızca (dışa açık) ana etkinliği hedefleyebilir. Dışarıdan gelen "kes" isteği hemen uygulanmaz,
     * kullanıcıya sorulur; "bağlan" isteği zararsızdır (bağlantı yine kullanıcının gözü önünde, onayıyla kurulur).
     */
    private fun handleIntent(intent: Intent?, fresh: Boolean) {
        if (!fresh) { intent?.action = null; return }
        val trusted = intent?.component?.className == INTERNAL_ALIAS
        when (intent?.action) {
            DnsVpnService.ACTION_CONNECT -> {
                val id = if (trusted) intent.getStringExtra(DnsVpnService.EXTRA_SERVER)?.takeIf { Catalog.byId(it) != null } else null
                when {
                    id != null && model.connectedId() != id -> model.tapServer(id)
                    id == null && !model.vpn.active -> model.tapOrb()
                }
            }
            DnsVpnService.ACTION_DISCONNECT -> if (model.vpn.active) {
                if (trusted) model.disconnectNow()
                else model.toast(Strings.CONFIRM_DISCONNECT, Strings.DISCONNECT) { model.disconnectNow() }
            }
            DnsVpnService.ACTION_PAUSE -> if (trusted) {
                val m = intent.getIntExtra(DnsVpnService.EXTRA_MINUTES, Notifier.PAUSE_MIN).coerceIn(1, 24 * 60)
                if (model.vpn.active) model.pause(m) else model.toast(Strings.ONLY_CONNECTED)
            }
            else -> {
                val s = model.settings
                if (s.autoConnect && s.onboarded && !model.vpn.active) model.tapOrb()
            }
        }
        // Aynı niyet yeniden işlenmesin (ör. yön değişiminde).
        intent?.action = null
    }

    // ------------------------------------------------------------------ Host

    private inner class AndroidHost : Host {
        override fun connect(serverId: String) = this@MainActivity.connect(serverId)

        override fun applyModules(dpi: Boolean, ads: Boolean, onFail: () -> Unit) = this@MainActivity.applyModules(dpi, ads, onFail)

        override fun disconnectDns() {
            connectRequestedAt = 0
            sendToService(DnsVpnService.dnsOffIntent(this@MainActivity)) { model.onVpn(VpnUi()) }
        }

        override fun disconnect() {
            connectRequestedAt = 0
            sendToService(DnsVpnService.disconnectIntent(this@MainActivity)) { model.onVpn(VpnUi()) }
        }

        override fun pause(minutes: Int) {
            connectRequestedAt = 0
            sendToService(DnsVpnService.pauseIntent(this@MainActivity, minutes)) { model.onVpn(VpnUi()) }
        }

        override fun resume() {
            connectRequestedAt = SystemClock.elapsedRealtime()
            val consent = try { VpnService.prepare(this@MainActivity) } catch (_: Exception) { null }
            if (consent != null) { connect(model.selectedId()); return }
            sendToService(DnsVpnService.resumeIntent(this@MainActivity)) { model.onVpn(VpnUi()) }
        }

        override fun clearCache() {
            sendToService(DnsVpnService.clearCacheIntent(this@MainActivity)) {}
        }

        override fun runTest() {
            sendToService(DnsVpnService.testIntent(this@MainActivity)) {
                model.onTestResult(SelfTestResult(false, null, null, model.connectedId(), app.dnshizli.core.DnssecResult.UNKNOWN, app.dnshizli.core.AdBlockResult.UNKNOWN))
            }
        }

        override fun reapply() {
            if (model.vpn.active) sendToService(DnsVpnService.reapplyIntent(this@MainActivity)) {}
        }

        /** Favorilerden en çok iki tanesi uygulama simgesinin kısayollarına eklenir (üç sabit kısayolun yanına). */
        override fun updateShortcuts(serverIds: List<String>) {
            try {
                val sm = getSystemService(ShortcutManager::class.java) ?: return
                val list = serverIds.mapNotNull { Catalog.byId(it) }.take(MAX_DYNAMIC_SHORTCUTS).map { s ->
                    ShortcutInfo.Builder(this@MainActivity, "fav-" + s.id)
                        .setShortLabel(s.name.take(25))
                        .setLongLabel((Strings.CONNECT + ": " + s.name).take(40))
                        .setIcon(Icon.createWithResource(this@MainActivity, R.drawable.ic_shortcut))
                        .setIntent(Intent(DnsVpnService.ACTION_CONNECT).setClassName(this@MainActivity, INTERNAL_ALIAS)
                            .putExtra(DnsVpnService.EXTRA_SERVER, s.id))
                        .build()
                }
                sm.dynamicShortcuts = list
            } catch (_: Exception) {
                // kısayol kotası, eski başlatıcı: kısayolsuz devam
            }
        }

        override fun systemAccent(): Int? = if (Build.VERSION.SDK_INT >= 31) {
            try { resources.getColor(android.R.color.system_accent1_500, theme) } catch (_: Exception) { null }
        } else null

        override fun openBatterySettings() {
            val tries = listOf(
                Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")),
            )
            for (i in tries) { try { startActivity(i); return } catch (_: Exception) {} }
        }

        /** Android 9+: kullanıcı ya da sistem uygulamayı "arka planda kısıtlanmış" yaptıysa true. */
        override fun batteryRestricted(): Boolean? {
            if (Build.VERSION.SDK_INT < 28) return null
            return try {
                val am = getSystemService(ActivityManager::class.java) ?: return null
                am.isBackgroundRestricted
            } catch (_: Exception) { null }
        }

        private fun sendToService(i: Intent, onFail: () -> Unit) {
            // VPN izni yoksa servis önplana geçemez (Android 14+ systemExempted türü bunu ister) ve sistem uygulamayı
            // kapatır; izin yoksa zaten çalışan bir tünel de yoktur.
            val consent = try { VpnService.prepare(this@MainActivity) } catch (_: Exception) { null }
            if (consent != null) { onFail(); return }
            try {
                startForegroundService(i)
            } catch (e: Exception) {
                Journal.add("servis komutu gönderilemedi: ${e.javaClass.simpleName}")
                onFail()
            }
        }

        override fun measure(serverIds: List<String>) {
            val ex = pool ?: newProbePool().also { pool = it }
            val left = AtomicInteger(serverIds.size)
            // Ölçüm adresi: ağın kullandığı aile önce (yalnızca IPv6 ağda IPv6 adresi) — bkz. Targets.
            val net = NetworkWatcher.families(this@MainActivity)
            val mode = model.settings.ipMode
            for (id in serverIds) {
                val server = Catalog.byId(id)
                try {
                    val encrypted = model.settings.measureEncrypted
                    ex.execute {
                        // Yalnızca şifreli çalışan sunucular (özel eklenenler) ve "şifreli ölçüm" açıkken DoT destekleyenler DoT ile
                        // ölçülür (el sıkışma süresi sayılmaz); diğerleri düz DNS ile.
                        val r = try {
                            val dot = server?.tlsHost(Proto.DOT, 0)
                            val ip = server?.let { Targets.plain(it, mode, net).firstOrNull() ?: it.primary }
                            when {
                                server == null || ip == null -> null
                                dot != null && (encrypted || !server.plain) -> DnsProbe.probeTls(ip, dot)
                                server.plain -> DnsProbe.probe(ip)
                                else -> null
                            }
                        } catch (_: Exception) { null }
                        main.post {
                            if (destroyedFlag) return@post
                            model.onLatency(id, r?.best, r?.lossPct ?: 100)
                            if (left.decrementAndGet() == 0) model.onMeasureDone()
                        }
                    }
                } catch (_: Exception) {
                    // havuz kapanmış (etkinlik yok ediliyor)
                }
            }
        }

        /** En çok 4 iş parçacığı; boşta kalanlar 5 sn sonra kendiliğinden kapanır (ölçüm bitince bellekte iş parçacığı kalmaz). */
        private fun newProbePool(): ExecutorService =
            ThreadPoolExecutor(4, 4, 5L, TimeUnit.SECONDS, LinkedBlockingQueue()) { r ->
                Thread(r, "dns-probe").also { it.isDaemon = true }
            }.also { it.allowCoreThreadTimeOut(true) }

        override fun saveSettings(s: AppSettings) = prefs.saveSettings(s)

        override fun latencies(out: IntArray): Int = VpnStatus.latencies(out)

        override fun importedCount(): Int = prefs.importedCount()
        override fun loadImported(): List<String> = ImportedStore.load(applicationContext)
        override fun saveImported(names: List<String>): Boolean {
            if (!ImportedStore.save(applicationContext, names)) return false
            prefs.setImportedCount(names.size)
            FilterRuntime.setImported(names)
            return true
        }

        override fun pickTextFile(onDone: (String?) -> Unit) {
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            textFileCallback = onDone
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(pick, REQ_TEXTFILE)
            } catch (e: Exception) {
                textFileCallback = null
                Journal.add("liste seçici açılamadı: ${e.javaClass.simpleName}")
                onDone(null)
            }
        }

        override fun notificationsAllowed(): Boolean = try {
            val nm = getSystemService(android.app.NotificationManager::class.java)
            val enabled = nm?.areNotificationsEnabled() ?: true
            enabled && (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
        } catch (_: Exception) { true }

        override fun openNotificationSettings() {
            val i = Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName)
            try { startActivity(i) } catch (_: Exception) {
                try { startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
            }
        }

        /** Android 13+ sistem fotoğraf seçicisi (izin gerektirmez); eskilerde belge seçici. Yalnızca seçilen dosya verilir. */
        override fun pickWallpaper() {
            val document = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
            val first = if (Build.VERSION.SDK_INT >= 33) Intent(android.provider.MediaStore.ACTION_PICK_IMAGES) else document
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(first, REQ_WALLPAPER)
            } catch (_: Exception) {
                // Fotoğraf seçici yoksa (bazı özel sürümler) belge seçiciyle dene.
                try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(document, REQ_WALLPAPER)
                } catch (e: Exception) {
                    Journal.add("arka plan: seçici açılamadı: ${e.javaClass.simpleName}")
                    model.onWallpaperPicked(false)
                }
            }
        }

        override fun usePresetWallpaper(index: Int) {
            val dm = resources.displayMetrics
            val aspect = min(dm.widthPixels, dm.heightPixels).toFloat() / max(dm.widthPixels, dm.heightPixels).toFloat()
            val app = applicationContext
            Thread({
                val ok = WallpaperStore.savePreset(app, index, aspect)
                runOnUiThread { if (!isDestroyed) model.onWallpaperPicked(ok) }
            }, "dns-wallpaper").apply { isDaemon = true }.start()
        }

        override fun removeWallpaper() = WallpaperStore.delete(applicationContext)

        override fun loadWallpaper(blur: WpBlur, onDone: (Pic?) -> Unit) {
            val app = applicationContext
            Thread({
                val p = WallpaperStore.load(app, blur)
                val transient = p == null && WallpaperStore.lastLoadTransient
                // Bellek yetmediği için yüklenemediyse "fotoğraf yok" denmez: ayar silinmez, sonra yeniden denenir.
                runOnUiThread { if (isDestroyed) p?.release() else if (!transient) onDone(p) }
            }, "dns-wallpaper-load").apply { isDaemon = true }.start()
        }

        /** Başlatıcıda görünen uygulamalar (Android 11+ için manifestte yalnızca bu sorgu bildirilir; geniş paket izni yok). */
        override fun loadApps(onDone: (List<AppEntry>) -> Unit) {
            Thread({
                val list = try {
                    val pm = packageManager
                    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    val infos = if (Build.VERSION.SDK_INT >= 33) pm.queryIntentActivities(q, PackageManager.ResolveInfoFlags.of(0L))
                    else @Suppress("DEPRECATION") pm.queryIntentActivities(q, 0)
                    infos.mapNotNull { ri ->
                        val pkg = ri.activityInfo.packageName
                        if (pkg == packageName || !AppScopes.validPkg(pkg)) null else AppEntry(pkg, ri.loadLabel(pm).toString().trim().ifEmpty { pkg })
                    }.distinctBy { it.pkg }.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
                } catch (_: Throwable) { emptyList() }
                runOnUiThread { if (!isDestroyed) onDone(list) }
            }, "dns-apps").apply { isDaemon = true }.start()
        }

        override fun applyApps() {
            if (model.vpn.active || model.vpn.gwOnly) sendToService(DnsVpnService.rebuildIntent(this@MainActivity)) {}
        }

        override fun promptText(title: String, hint: String, initial: String, maxLen: Int, okLabel: String?, onDone: (String) -> Unit) {
            val act = this@MainActivity
            val pad = (20 * resources.displayMetrics.density).toInt()
            val field = EditText(act).apply {
                this.hint = hint
                setText(initial)
                setSelection(initial.length)
                isSingleLine = true
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                filters = arrayOf(android.text.InputFilter.LengthFilter(maxLen))
            }
            val box = LinearLayout(act).apply { setPadding(pad, pad / 2, pad, 0); addView(field, LinearLayout.LayoutParams(-1, -2)) }
            AlertDialog.Builder(act)
                .setTitle(title)
                .setView(box)
                .setPositiveButton(okLabel ?: Strings.SEARCH) { _, _ -> onDone(field.text.toString()) }
                .apply { if (okLabel == null) setNeutralButton(Strings.SEARCH_CLEAR) { _, _ -> onDone("") } }
                .setNegativeButton(Strings.CUSTOM_CANCEL, null)
                .show()
        }

        /** Telefon durumu: hepsi izin gerektirmeyen, hızlı okumalardır (ACCESS_NETWORK_STATE zaten var). */
        @Suppress("DEPRECATION")
        override fun networkCheck(): NetCheck {
            val permission = try { VpnService.prepare(this@MainActivity) == null } catch (_: Exception) { null }
            val cm = getSystemService(ConnectivityManager::class.java)
            val online = try {
                val caps = cm?.getNetworkCapabilities(cm.activeNetwork)
                caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            } catch (_: Exception) { null }
            val otherVpn = try {
                cm?.allNetworks?.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
            } catch (_: Exception) { null }
            val pdns = try {
                when (Settings.Global.getString(contentResolver, "private_dns_mode")) {
                    "off" -> PrivateDns.OFF
                    "opportunistic" -> PrivateDns.AUTO
                    "hostname" -> PrivateDns.STRICT
                    else -> null
                }
            } catch (_: Exception) { null }
            return NetCheck(permission, online, otherVpn, pdns)
        }

        override fun promptCustomServer(validate: (CustomDns.Draft) -> String?, initial: CustomDns.Draft?, onDone: (CustomDns.Draft) -> Unit) {
            val act = this@MainActivity
            val pad = (20 * resources.displayMetrics.density).toInt()
            fun field(hint: String) = EditText(act).apply {
                this.hint = hint
                isSingleLine = true
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            }
            val name = field(Strings.CUSTOM_F_NAME).apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS }
            val ip1 = field(Strings.CUSTOM_F_IP1)
            val ip2 = field(Strings.CUSTOM_F_IP2)
            val dot = field(Strings.CUSTOM_F_DOT)
            val doh = field(Strings.CUSTOM_F_DOH)
            if (initial != null) { name.setText(initial.name); ip1.setText(initial.ip1); ip2.setText(initial.ip2); dot.setText(initial.dot); doh.setText(initial.doh) }
            val error = TextView(act).apply { setTextColor(Color.rgb(0xC6, 0x28, 0x28)); visibility = View.GONE }
            val box = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(pad, pad / 2, pad, 0)
                addView(TextView(act).apply { text = Strings.CUSTOM_HINT })
                for (v in listOf(name, ip1, ip2, dot, doh)) addView(v)
                addView(error)
            }
            val dialog = AlertDialog.Builder(act)
                .setTitle(if (initial != null) Strings.CUSTOM_EDIT else Strings.CUSTOM_ADD)
                .setView(ScrollView(act).apply { addView(box) })
                .setPositiveButton(Strings.CUSTOM_SAVE, null)
                .setNegativeButton(Strings.CUSTOM_CANCEL, null)
                .create()
            dialog.setOnShowListener {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val d = CustomDns.Draft(name.text.toString(), ip1.text.toString(), ip2.text.toString(), dot.text.toString(), doh.text.toString())
                    val msg = validate(d)
                    if (msg != null) { error.text = msg; error.visibility = View.VISIBLE } else { dialog.dismiss(); onDone(d) }
                }
            }
            dialog.show()
        }
        override fun saveLatencies(m: Map<String, Latency>) = prefs.saveLatencies(m)
        override fun saveHistory(h: Map<String, List<Int?>>) = prefs.saveHistory(h)
        override fun resetTotals() = prefs.resetTotals()

        override fun readClipboard(): String? = try {
            val cm = getSystemService(ClipboardManager::class.java)
            cm?.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString()
        } catch (_: Exception) { null }

        private fun storeUrl(): String = "https://play.google.com/store/apps/details?id=$packageName"

        override fun shareApp() = shareText(Strings.shareAppText(storeUrl()))

        override fun rateApp() {
            val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
            try { startActivity(market) } catch (_: Exception) {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(storeUrl()))) } catch (_: Exception) {}
            }
        }

        override fun applyLanguage(setting: String) {
            App.applyLanguage(this@MainActivity, setting)
            App.syncSystemLocale(this@MainActivity, setting)
            prefs.setLocaleSynced()
            Notifier.ensureChannel(this@MainActivity)
            try { DnsWidget.updateAll(this@MainActivity, VpnStatus.snapshot()) } catch (_: Exception) {}
            updateShortcuts(Catalog.all.filter { it.id in model.settings.favorites }.map { it.id })
        }

        override fun copyText(text: String) {
            val cm = getSystemService(ClipboardManager::class.java) ?: return
            val clip = ClipData.newPlainText(Strings.APP, text)
            // Android 13+: pano önizlemesinde ve diğer uygulamalara "hassas" işaretlenir (ayar kodu sunucu kurallarını içerir).
            if (Build.VERSION.SDK_INT >= 33) {
                try {
                    clip.description.extras = android.os.PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
                } catch (_: Exception) {}
            }
            cm.setPrimaryClip(clip)
        }

        override fun shareText(text: String) {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            try { startActivity(Intent.createChooser(send, null)) } catch (_: Exception) {}
        }

        override fun haptic(strong: Boolean) {
            val v = view ?: return
            val kind = when {
                !strong -> HapticFeedbackConstants.VIRTUAL_KEY
                Build.VERSION.SDK_INT >= 30 -> HapticFeedbackConstants.CONFIRM
                else -> HapticFeedbackConstants.LONG_PRESS
            }
            v.performHapticFeedback(kind)
        }

        /** Vuruşlar arasında [gapMs] beklenerek art arda sistem dokunsal geri bildirimi (izin gerekmez). */
        override fun hapticPattern(pulses: Int, gapMs: Int, strong: Boolean) {
            val n = pulses.coerceIn(1, 4)
            haptic(strong)
            for (i in 1 until n) main.postDelayed({ haptic(strong) }, (i * gapMs).toLong())
        }

        override fun playSound(e: Sfx, voice: Voice, volume: Float) { soundFx.play(e, voice, volume) }

        override fun releaseSounds() { soundFx.release() }

        /**
         * Simgeyi hemen değiştirmek, şu an çalışan takma adı kapatmak demektir; bazı cihazlarda bu, açık uygulamayı
         * kapatır (VPN de düşer). Bu yüzden yalnızca not edilir ve uygulamadan çıkılınca ([onStop]) uygulanır.
         */
        override fun setAppIcon(style: UiStyle): Boolean { pendingIcon = style; return true }

        override fun openVpnSettings() {
            try { startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) } catch (_: Exception) {}
        }

        /** Tanılama raporu: sürüm, cihaz, önemli ayarlar (kişisel veri yok), son çökme özeti ve olay günlüğü. */
        override fun diagnostics(): String {
            val s = model.settings
            val head = "${Strings.APP} ${versionName()} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MANUFACTURER}\n" +
                "enc=${s.encryption.id} strict=${s.strictEncryption} cache=${s.cache.id} reconnect=${s.autoReconnect} backup=${s.backupServer ?: "-"} " +
                "lang=${s.lang} theme=${s.theme}\n"
            val crashes = prefs.crashes()
            val crash = if (crashes.isEmpty()) "" else "son çökmeler (en yeni önce):\n" + crashes.joinToString("\n") + "\n"
            return head + crash + Journal.log.dump()
        }

        override fun clearDiagnostics() { Journal.log.clear(); prefs.clearCrashes() }

        override fun versionName(): String = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
        } catch (_: Exception) { "1.0" }

        override fun now(): Long = System.currentTimeMillis()

        override fun requestFrame() { view?.requestFrame() }
    }

    companion object {
        private const val REQ_VPN = 1
        private const val REQ_VPN_MOD = 4
        private const val REQ_WALLPAPER = 2
        private const val REQ_NOTIF = 2
        private const val REQ_TEXTFILE = 3
        private const val CONNECT_GRACE_MS = 4000L
        private const val MAX_DYNAMIC_SHORTCUTS = 2

        /**
         * Dışa kapalı takma ad (activity-alias): uygulamanın kendi kısayolları, bildirimleri, widget'ı ve kutucuğu bunu
         * hedefler. Bu adla gelen niyetlere güvenilir; başka uygulamalar bu adı başlatamaz.
         */
        const val INTERNAL_ALIAS = "app.dnshizli.platform.InternalLaunch"
    }
}
