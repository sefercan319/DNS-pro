package app.dnshizli.core

/** Ekranda gösterilen sayı ve süre biçimleri. Birimler ve ayraçlar etkin dilden ([L.tx]) gelir. */
object Format {
    private fun pad2(n: Long): String = if (n < 10) "0$n" else "$n"

    /** 754 -> "12:34", 3725 -> "1:02:05". */
    fun clock(totalSec: Long): String {
        val s = totalSec.coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "$h:${pad2(m)}:${pad2(sec)}" else "${pad2(m)}:${pad2(sec)}"
    }

    /** Uzun süreler: 45 -> "45 sn", 600 -> "10 dk", 7500 -> "2 sa 5 dk", 200000 -> "2 gün 7 sa" (Türkçe örnek). */
    fun span(totalSec: Long): String {
        val t = L.tx
        val s = totalSec.coerceAtLeast(0)
        val d = s / 86400
        val h = (s % 86400) / 3600
        val m = (s % 3600) / 60
        return when {
            d > 0 -> if (h > 0) "$d ${t.dayU} $h ${t.hourU}" else "$d ${t.dayU}"
            h > 0 -> if (m > 0) "$h ${t.hourU} $m ${t.minU}" else "$h ${t.hourU}"
            m > 0 -> "$m ${t.minU}"
            else -> "$s ${t.secU}"
        }
    }

    /** 950 -> "950", 1250 -> "1,2 bin", 48000 -> "48 bin", 3400000 -> "3,4 mn" (Türkçe örnek). */
    fun count(n: Long): String {
        val t = L.tx
        val sep = t.decimalSep
        return when {
            n < 1000 -> "$n"
            n < 10_000 -> if ((n % 1000) / 100 == 0L) "${n / 1000}${t.thousand}" else "${n / 1000}$sep${(n % 1000) / 100}${t.thousand}"   // 1000 -> "1 bin" ("1,0 bin" değil)
            n < 1_000_000 -> "${n / 1000}${t.thousand}"
            n < 10_000_000 -> if ((n % 1_000_000) / 100_000 == 0L) "${n / 1_000_000}${t.million}" else "${n / 1_000_000}$sep${(n % 1_000_000) / 100_000}${t.million}"
            else -> "${n / 1_000_000}${t.million}"
        }
    }

    fun ms(n: Int): String = "$n " + L.tx.msU

    /** 900 -> "900 B", 1536 -> "1,5 KB", 3_400_000 -> "3,2 MB" (1024 tabanı; ayraç dile göre). */
    fun bytes(n: Long): String {
        val t = L.tx
        val u = t.byteUnits
        val v = n.coerceAtLeast(0)
        if (v < 1024) return "$v ${u[0]}"
        var unit = 0
        var x = v.toDouble()
        while (x >= 1024.0 && unit < u.size - 1) { x /= 1024.0; unit++ }
        val tenths = (x * 10 + 0.5).toLong()
        val text = if (tenths >= 100) "${(x + 0.5).toLong()}" else "${tenths / 10}${t.decimalSep}${tenths % 10}"
        return "$text ${u[unit]}"
    }

    /** Geçen süreyi "az önce", "5 dk önce", "3 sa önce", "2 gün önce" olarak yazar (Türkçe örnek). */
    fun ago(deltaMs: Long): String {
        val t = L.tx
        val s = deltaMs.coerceAtLeast(0) / 1000
        return when {
            s < 45 -> t.justNow
            s < 90 * 60 -> t.ago("${maxOf(1L, (s + 30) / 60)} ${t.minU}")
            s < 36 * 3600 -> t.ago("${(s + 1800) / 3600} ${t.hourU}")
            else -> t.ago("${(s + 43200) / 86400} ${t.dayU}")
        }
    }

    /** Saat:dakika ("15:42"), cihazın saat diliminde. */
    fun hm(epochMs: Long, tz: java.util.TimeZone = java.util.TimeZone.getDefault()): String {
        val c = java.util.Calendar.getInstance(tz)
        c.timeInMillis = epochMs
        return "${pad2(c.get(java.util.Calendar.HOUR_OF_DAY).toLong())}:${pad2(c.get(java.util.Calendar.MINUTE).toLong())}"
    }
}

/** Küçük, iş parçacığı güvenli halka tampon: son olayları saklar. Kullanıcı yardım ekranından kopyalayabilir. */
class DiagLog(private val capacity: Int = 120, private val clock: () -> Long = { System.currentTimeMillis() }) {
    private val lines = ArrayDeque<Pair<Long, String>>()

    @Synchronized
    fun add(msg: String) {
        if (lines.size >= capacity) lines.removeFirst()
        lines.addLast(clock() to msg)
    }

    @Synchronized
    fun size(): Int = lines.size

    @Synchronized
    fun clear() = lines.clear()

    /** Her satır: "SS:DD:SN mesaj" (cihazın yerel saatiyle), en eski üstte. */
    @Synchronized
    fun dump(): String {
        val fmt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ROOT)
        return lines.joinToString("\n") { (t, m) -> fmt.format(java.util.Date(t)) + " " + m }
    }
}

/** Uygulama genelinde tek günlük. Sorgu adı veya kişisel veri asla yazılmaz. */
object Journal {
    val log = DiagLog()
    fun add(msg: String) = log.add(msg)
}

enum class NetKind { WIFI, MOBILE, ETHERNET, OTHER, NONE }

data class NetInfo(val wifi: Boolean, val cellular: Boolean, val ethernet: Boolean, val validated: Boolean)

/** "Ağa göre DNS" kuralları. Saf fonksiyonlar: kolayca test edilir. */
object Rules {
    /** Bağlı fiziksel ağlardan hangisinin kullanıldığını seçer (doğrulanmış Wi-Fi > Ethernet > mobil). */
    fun pick(nets: List<NetInfo>): NetKind {
        val usable = nets.filter { it.validated }.ifEmpty { nets }
        return when {
            usable.any { it.wifi } -> NetKind.WIFI
            usable.any { it.ethernet } -> NetKind.ETHERNET
            usable.any { it.cellular } -> NetKind.MOBILE
            usable.isNotEmpty() -> NetKind.OTHER
            else -> NetKind.NONE
        }
    }

    /** Bu ağ türü için kullanıcı özel bir sunucu atamış mı? */
    fun ruleFor(s: AppSettings, kind: NetKind): String? = when (kind) {
        NetKind.WIFI -> s.wifiServer
        NetKind.MOBILE -> s.mobileServer
        else -> null
    }

    /** Bağlanılacak ilk sunucu: ağ kuralı, yoksa son kullanılan, yoksa varsayılan. */
    fun initialServer(s: AppSettings, kind: NetKind): String =
        ruleFor(s, kind) ?: s.lastServer ?: Catalog.DEFAULT_ID
}

sealed class CheckResult {
    data class Ok(val ms: Int) : CheckResult()
    object NoAnswer : CheckResult()

    /** Sunucunun TLS sertifikası doğrulanamadı: aradaki biri (ağ, güvenlik yazılımı) şifreli bağlantıya karışıyor olabilir. Beklemeden döner. */
    object Untrusted : CheckResult()
}

/**
 * Bağlantı testi: sistemin kendi çözümleyicisiyle bir ad çözdürür ([resolve]) ve bu sorgunun gerçekten
 * yönlendiriciden geçip cevaplandığını sayaçlardan doğrular. Böylece "Bağlı" yazısı yalnızca tünel
 * açıldı demek değil, DNS gerçekten çalışıyor demek olur.
 */
object ConnectionCheck {
    fun run(fw: Forwarder, resolve: () -> Unit, timeoutMs: Long = 4000): CheckResult {
        val before = fw.stats()
        val t0 = System.nanoTime()
        val worker = Thread({ try { resolve() } catch (_: Throwable) {} }, "dns-check")
        worker.isDaemon = true
        worker.start()
        while (true) {
            val now = fw.stats()
            val elapsed = (System.nanoTime() - t0) / 1_000_000
            if (now.answered > before.answered || now.cacheHits > before.cacheHits) {
                return CheckResult.Ok(elapsed.toInt())
            }
            // Sertifika reddi geçici bir ağ sorunu değildir: kalan süreyi beklemeden bildir (hızlı hata tespiti).
            if (now.tlsFailures > before.tlsFailures) return CheckResult.Untrusted
            // Yönlendirici sorguyu zaten pes ettiyse (tüm denemeler ve adresler tükendi) kalan süre beklenmez.
            if (now.timeouts > before.timeouts) return CheckResult.NoAnswer
            if (elapsed >= timeoutMs) return CheckResult.NoAnswer
            try { Thread.sleep(15) } catch (_: InterruptedException) { return CheckResult.NoAnswer }
        }
    }
}
