package app.dnshizli.core

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.Arrays
import java.util.concurrent.Executors

/**
 * Reklam, izleyici ve zararlı alan adı engelleme. Her şey cihazda yapılır: sorgunun alan adı gömülü listelerle
 * karşılaştırılır; listedeyse sahte "boş adres" cevabı (A: 0.0.0.0, AAAA: ::) hemen verilir ve sorgu hiçbir sunucuya gitmez.
 * Hiçbir alan adı diske yazılmaz ya da paylaşılmaz.
 */
enum class FilterLevel(val id: String, val tiers: Int) {
    OFF("off", 0), BASIC("basic", 1), MEDIUM("medium", 2), STRICT("strict", 3);

    companion object {
        fun byId(id: String?): FilterLevel? = values().firstOrNull { it.id == id }
    }
}

/** Alan adı özeti: FNV-1a (64 bit) + splitmix64 karıştırma, 48 bite kesilir. tools/build_filter.py ile birebir aynıdır. */
internal object FilterHash {
    private const val MASK = 0xFFFFFFFFFFFFL

    fun hash(b: ByteArray, off: Int, len: Int): Long {
        var x = -0x340d631b7bdddcdbL          // 0xcbf29ce484222325
        for (i in off until off + len) {
            x = x xor (b[i].toLong() and 0xFF)
            x *= 0x100000001b3L
        }
        x = (x xor (x ushr 30)) * -0x40a7b892e31b1a47L   // 0xbf58476d1ce4e5b9
        x = (x xor (x ushr 27)) * -0x6b2fb644ecceee15L   // 0x94d049bb133111eb
        x = x xor (x ushr 31)
        return x and MASK
    }

    fun hash(s: String): Long {
        val b = s.toByteArray(Charsets.ISO_8859_1)
        return hash(b, 0, b.size)
    }
}

/** Kullanıcının yazdığı alan adlarını denetler ve düzenler (izin ve engel listeleri). */
object FilterNames {
    const val MAX_LIST = 200

    private val LABEL = Regex("^[a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9_])?$")

    /**
     * "https://www.Ornek.com/yol", "*.ornek.com", ".ornek.com." gibi girdilerden temiz alan adını çıkarır
     * ("ornek.com" ya da "www.ornek.com"). Geçerli değilse null. En az iki etiket gerekir; IP adresi kabul edilmez.
     */
    fun normalize(input: String): String? {
        var s = input.trim().lowercase()
        val scheme = s.indexOf("://")
        if (scheme in 1..10) s = s.substring(scheme + 3)
        s = s.substringBefore('/').substringBefore('?').substringBefore('#')
        s = s.substringAfterLast('@')
        if (s.startsWith("[")) return null
        s = s.substringBefore(':')
        while (s.startsWith("*.") || s.startsWith(".")) s = s.removePrefix("*.").removePrefix(".")
        s = s.trimEnd('.')
        if (s.isEmpty() || s.length > 253) return null
        val parts = s.split('.')
        if (parts.size < 2) return null
        if (parts.all { p -> p.isNotEmpty() && p.all { it in '0'..'9' } }) return null
        return if (parts.all { LABEL.matches(it) }) s else null
    }

    /** Virgülle ayrılmış kayıttan temiz, tekrarsız liste. */
    fun decode(s: String?): List<String> {
        if (s.isNullOrBlank()) return emptyList()
        return s.split(',').mapNotNull { normalize(it) }.distinct().take(MAX_LIST)
    }

    fun encode(list: Collection<String>): String = list.mapNotNull { normalize(it) }.distinct().take(MAX_LIST).joinToString(",")
}

/** Sıralı, tekrarsız 48 bitlik özetlerden oluşan bir katman. */
class FilterTier(internal val hashes: LongArray) {
    val size: Int get() = hashes.size
    fun contains(h: Long): Boolean = hashes.isNotEmpty() && Arrays.binarySearch(hashes, h) >= 0

    companion object {
        val EMPTY = FilterTier(LongArray(0))
        private const val MAX_COUNT = 30_000_000

        /** "DNF1" + sayı (4 bayt) + fark kodlu (LEB128) sıralı özetler. Bozuk ya da kesik veri IOException fırlatır. */
        fun read(ins: InputStream): FilterTier {
            // Akışlı okuma: dosyanın tamamı ayrıca belleğe alınmaz (yalnızca 16 KB'lık tampon + sonuç dizisi).
            val r = ByteReader(ins)
            if (r.next() != 'D'.code || r.next() != 'N'.code || r.next() != 'F'.code || r.next() != '1'.code) throw IOException("filtre dosyası tanınmadı")
            var n = 0
            for (k in 0 until 4) { val c = r.next(); if (c < 0) throw IOException("filtre dosyası tanınmadı"); n = (n shl 8) or c }
            if (n < 0 || n > MAX_COUNT) throw IOException("filtre sayısı geçersiz")
            val out = LongArray(n)
            var prev = 0L
            for (i in 0 until n) {
                var v = 0L
                var shift = 0
                while (true) {
                    val c = r.next()
                    if (c < 0 || shift > 56) throw IOException("filtre dosyası kesik")
                    v = v or ((c and 0x7F).toLong() shl shift)
                    if (c and 0x80 == 0) break
                    shift += 7
                }
                prev += v
                out[i] = prev
            }
            if (r.next() >= 0) throw IOException("filtre dosyasında fazlalık")
            return FilterTier(out)
        }

        private class ByteReader(private val ins: InputStream) {
            private val buf = ByteArray(16384)
            private var pos = 0
            private var lim = 0
            fun next(): Int {
                if (pos >= lim) {
                    val n = ins.read(buf, 0, buf.size)
                    if (n <= 0) return -1
                    lim = n; pos = 0
                }
                return buf[pos++].toInt() and 0xFF
            }
        }
    }
}

/** Liste dosyalarının geldiği yer: Android'de varlıklar (assets), testlerde klasör. */
fun interface FilterSource {
    fun open(name: String): InputStream
}

/**
 * Bir sorgunun sonucu. [PASS]: engellenmez. [LIST]: seçili seviyenin listelerinde. [USER]: kullanıcının engel listesinde.
 */
object FilterVerdict {
    const val PASS = 0
    const val LIST = 1
    const val USER = 2
    /** Şifreli DNS'e geçişi kapattıran "kanarya" ad (ör. Firefox'un use-application-dns.net adı): "yok" (NXDOMAIN) cevabı verilir. */
    const val CANARY = 3
}

/**
 * Engelleme kararı. Öncelik: kullanıcı izin listesi > kullanıcı engel listesi > korunan adlar > seviye listeleri.
 * Bir alan adı ve onun tüm alt alan adları aynı kuralla eşleşir ("ornek.com" girdisi "a.b.ornek.com"u da kapsar).
 * Tek iş parçacığından kullanılır (tünel okuyucusu): ara tamponları paylaşır, ayırma yapmaz.
 */
class FilterEngine private constructor(
    private val tiers: List<FilterTier>,
    private val protectedSet: FilterTier,
    private val allowH: FilterTier,
    private val blockH: FilterTier,
) {
    constructor(tiers: List<FilterTier>, protectedSet: FilterTier, allow: Collection<String>, block: Collection<String>) :
        this(tiers, protectedSet, toTier(allow), toTier(block))

    /**
     * Aynı listeleri paylaşan ama KENDİ ara tamponlarına sahip yeni bir örnek (çok iş parçacıklı kullanım için: her cevap
     * alıcı iş parçacığı kendi kopyasını kullanır). Listeler salt okunurdur, kopyalanmaz.
     */
    fun fork(): FilterEngine = FilterEngine(tiers, protectedSet, allowH, blockH)

    val active: Boolean = tiers.any { it.size > 0 } || blockH.size > 0

    private val name = ByteArray(256)
    private var nameLen = 0
    private val qName = ByteArray(256)       // CNAME denetiminde sorulan adın kopyası (aynı site kontrolü için)
    private var qLen = 0
    private val starts = IntArray(128)
    private val hs = LongArray(128)

    /** Son [verdict] çağrısındaki sorgu adı (küçük harf, noktalı). Yalnızca engellenince yazmak için; ayırma yapmaz. */
    internal fun lastName(): String = String(name, 0, nameLen, Charsets.ISO_8859_1)

    /**
     * [q] içinde [qOff] konumundaki DNS sorgusunun (başlık dahil) ilk sorusunu denetler. Soru bozuksa, tek sorulu değilse ya da
     * ad ASCII dışıysa [FilterVerdict.PASS].
     */
    fun verdict(q: ByteArray, qOff: Int, end: Int): Int {
        if (!active && allowH.size == 0) return FilterVerdict.PASS
        if (end - qOff < Packets.DNS_HDR + 5 || Packets.u16(q, qOff + 4) != 1) return FilterVerdict.PASS
        if (!readName(q, qOff + Packets.DNS_HDR, end)) return FilterVerdict.PASS
        return verdictOfName()
    }

    /** Dışarıdan verilen ad için (ör. testler, "bu sitede çalışır mı?"). Ayırma yapar, hızlı yol için değildir. */
    fun verdictOf(domain: String): Int {
        val d = FilterNames.normalize(domain) ?: return FilterVerdict.PASS
        val b = d.toByteArray(Charsets.ISO_8859_1)
        System.arraycopy(b, 0, name, 0, b.size)
        nameLen = b.size
        return verdictOfName()
    }

    private fun readName(q: ByteArray, from: Int, end: Int): Boolean {
        var i = from
        var n = 0
        while (true) {
            if (i >= end) return false
            val l = q[i].toInt() and 0xFF
            if (l == 0) break
            if (l > 63 || (l and 0xC0) != 0 || i + 1 + l > end) return false
            if (n + l + 1 > name.size - 1) return false
            if (n > 0) name[n++] = '.'.code.toByte()
            for (k in 1..l) {
                val c = q[i + k].toInt() and 0xFF
                if (c >= 0x80 || c <= 0x20) return false
                name[n++] = (if (c in 'A'.code..'Z'.code) c + 32 else c).toByte()
            }
            i += 1 + l
        }
        nameLen = n
        return n > 0
    }

    private fun verdictOfName(): Int {
        // soldan sağa etiket başları; en az iki etiketli son ekler
        var cnt = 0
        starts[cnt++] = 0
        for (i in 0 until nameLen) if (name[i] == '.'.code.toByte() && cnt < starts.size) starts[cnt++] = i + 1
        // tek etiketli ad (ör. "localhost") engellenmez
        if (cnt < 2) return FilterVerdict.PASS
        var m = 0
        for (k in 0 until cnt - 1) hs[m++] = FilterHash.hash(name, starts[k], nameLen - starts[k])
        for (k in 0 until m) if (allowH.contains(hs[k])) return FilterVerdict.PASS
        if (isCanary()) return FilterVerdict.CANARY
        for (k in 0 until m) if (blockH.contains(hs[k])) return FilterVerdict.USER
        for (k in 0 until m) if (protectedSet.contains(hs[k])) return FilterVerdict.PASS
        for (ti in 0 until tiers.size) {                                  // dizinle gez: sıcak yolda yineleyici ayırma
            val t = tiers[ti]
            if (t.size > 0) for (k in 0 until m) if (t.contains(hs[k])) return FilterVerdict.LIST
        }
        return FilterVerdict.PASS
    }

    /** Ad tamponu bir kanarya ada ([CANARY_NAMES]) tam eşit mi? */
    private fun isCanary(): Boolean {
        for (ci in 0 until CANARY_NAMES.size) {
            val c = CANARY_NAMES[ci]
            if (c.size != nameLen) continue
            var same = true
            for (i in 0 until nameLen) if (name[i] != c[i]) { same = false; break }
            if (same) return true
        }
        return false
    }

    // ---- CNAME ile gizlenmiş izleyiciler

    /**
     * Bir DNS CEVABININ CNAME zinciri engelli bir adda mı bitiyor? ("Gizli izleyici": site kendi alt alan adını bir izleyici
     * sunucusuna CNAME ile yönlendirir; yalnızca sorulan adı denetleyen süzgeçler bunu göremez.)
     * Kullanıcı izin listesi her zaman üstündür: SORULAN ad ya da hedef izinliyse geçer. Cevap bozuksa [FilterVerdict.PASS].
     * [msg] içinde [base] konumundan [n] baytlık DNS mesajı; ayırma yapmaz (engelleme dışında).
     */
    fun cnameVerdict(msg: ByteArray, base: Int, n: Int): Int {
        if (!active || n < Packets.DNS_HDR + 5 || base < 0 || base + n > msg.size) return FilterVerdict.PASS
        val end = base + n
        val flags = Packets.u16(msg, base + 2)
        if ((flags and 0x8000) == 0 || (flags and 0x000F) != 0) return FilterVerdict.PASS      // cevap değil ya da hata
        if (Packets.u16(msg, base + 4) != 1) return FilterVerdict.PASS
        val an = Packets.u16(msg, base + 6)
        if (an < 2) return FilterVerdict.PASS                                                 // CNAME + en az bir kayıt
        // sorulan ad: kullanıcı izin listesinde mi
        if (!readWire(msg, base, base + Packets.DNS_HDR, end)) return FilterVerdict.PASS
        if (nameAllowed()) return FilterVerdict.PASS
        System.arraycopy(name, 0, qName, 0, nameLen); qLen = nameLen
        var p = Dns.skipName(msg, base + Packets.DNS_HDR, end)
        if (p < 0 || p + 4 > end) return FilterVerdict.PASS
        p += 4
        var steps = 0
        for (i in 0 until minOf(an, MAX_CNAME_RR)) {
            p = Dns.skipName(msg, p, end)
            if (p < 0 || p + 10 > end) return FilterVerdict.PASS
            val type = Packets.u16(msg, p)
            val rdLen = Packets.u16(msg, p + 8)
            val rd = p + 10
            if (rd + rdLen > end) return FilterVerdict.PASS
            if (type == 5 && ++steps <= MAX_CNAME_CHAIN) {
                if (readWire(msg, base, rd, end) && !sameSite()) {
                    val v = verdictOfName()
                    if (v == FilterVerdict.LIST || v == FilterVerdict.USER) return v
                }
            }
            p = rd + rdLen
        }
        return FilterVerdict.PASS
    }

    /**
     * Hedef ad ([name]) ile sorulan ad ([qName]) aynı siteye mi ait (son iki etiket aynı)? Öyleyse CNAME bir CDN ya da
     * site içi yönlendirmedir; izleyici zinciri değildir. Böylece sitenin kendi içerik sunucusu yanlışlıkla engellenmez.
     * Bu kontrol yalnızca yönlendirmeyi muaf tutar: hedef engelli bir ad ise ve sorgu farklı bir siteye aitse engellenir.
     */
    private fun sameSite(): Boolean {
        val a = lastTwoStart(qName, qLen)
        val b = lastTwoStart(name, nameLen)
        if (a < 0 || b < 0) return false
        val la = qLen - a; val lb = nameLen - b
        if (la != lb) return false
        for (i in 0 until la) if (qName[a + i] != name[b + i]) return false
        return true
    }

    /**
     * Sitenin kök adının (kayıt edilebilir alan adı) başlangıcı. Genelde son iki etiket ("site.com"); ama son etiket iki harfli bir ülke
     * uzantısı ve ondan önceki etiket yaygın bir ikinci düzey ad ise ("co", "com", "gov"...) son üç etiket ("site.co.uk", "site.com.tr").
     * Tam bir Public Suffix List değildir; en yaygın durumları kapsayan küçük bir sezgidir. Tek etiketli ya da boş adda -1.
     */
    private fun lastTwoStart(buf: ByteArray, len: Int): Int {
        var d1 = -1; var d2 = -1; var d3 = -1
        var i = len - 1
        while (i >= 0 && d3 < 0) {
            if (buf[i] == '.'.code.toByte()) { if (d1 < 0) d1 = i else if (d2 < 0) d2 = i else d3 = i }
            i--
        }
        if (d1 < 0) return if (len > 0) 0 else -1
        if (d2 < 0) return 0                                            // "site.com": adın tamamı
        val tldLen = len - d1 - 1
        val psl = PublicSuffix.registrableStart(buf, len)
        val start = if (psl != PublicSuffix.NOT_READY) maxOf(psl, 0)
            else if (tldLen == 2 && isSecondLevel(buf, d2 + 1, d1)) (if (d3 < 0) 0 else d3 + 1) else d2 + 1
        // Barındırma hizmetleri (github.io, blogspot.com.tr...) kendi başına bir "site" değil, kullanıcı alt alanları ayrı sitedir:
        // bu uzantıların bir etiket fazlası alınır ("a.github.io" ile "b.github.io" aynı site sayılmaz).
        if (start > 0 && isPrivateSuffix(buf, start, len)) {
            var j = start - 2
            while (j >= 0 && buf[j] != '.'.code.toByte()) j--
            return j + 1
        }
        return start
    }

    private fun isPrivateSuffix(buf: ByteArray, from: Int, to: Int): Boolean {
        val n = to - from
        for (w in PRIVATE_SUFFIX) {
            if (w.size != n) continue
            var ok = true
            for (k in 0 until n) if (buf[from + k] != w[k]) { ok = false; break }
            if (ok) return true
        }
        return false
    }

    private fun isSecondLevel(buf: ByteArray, from: Int, to: Int): Boolean {
        val n = to - from
        for (w in SECOND_LEVEL) {
            if (w.size != n) continue
            var ok = true
            for (k in 0 until n) if (buf[from + k] != w[k]) { ok = false; break }
            if (ok) return true
        }
        return false
    }

    /** Ad tamponundaki ad (ya da üst alan adı) kullanıcının izin listesinde mi? */
    private fun nameAllowed(): Boolean {
        if (allowH.size == 0) return false
        var cnt = 0
        starts[cnt++] = 0
        for (i in 0 until nameLen) if (name[i] == '.'.code.toByte() && cnt < starts.size) starts[cnt++] = i + 1
        for (k in 0 until cnt - 1) if (allowH.contains(FilterHash.hash(name, starts[k], nameLen - starts[k]))) return true
        return false
    }

    /**
     * Tel biçimindeki adı ([msg]'in [base] konumundan başlayan DNS mesajında, sıkıştırma işaretçileriyle) küçük harfli noktalı
     * olarak ad tamponuna okur. Döngüye giren işaretçiler, çok uzun adlar ve ASCII dışı baytlar reddedilir.
     */
    private fun readWire(msg: ByteArray, base: Int, from: Int, end: Int): Boolean {
        var i = from
        var n = 0
        var jumps = 0
        while (true) {
            if (i < base || i >= end) return false
            val l = msg[i].toInt() and 0xFF
            if (l == 0) break
            if ((l and 0xC0) == 0xC0) {
                if (i + 2 > end || ++jumps > 8) return false
                val ptr = ((l and 0x3F) shl 8) or (msg[i + 1].toInt() and 0xFF)
                i = base + ptr
                continue
            }
            if ((l and 0xC0) != 0 || l > 63 || i + 1 + l > end) return false
            if (n + l + 1 > name.size - 1) return false
            if (n > 0) name[n++] = '.'.code.toByte()
            for (k in 1..l) {
                val c = msg[i + k].toInt() and 0xFF
                if (c >= 0x80 || c <= 0x20) return false
                name[n++] = (if (c in 'A'.code..'Z'.code) c + 32 else c).toByte()
            }
            i += 1 + l
        }
        nameLen = n
        return n > 0
    }

    companion object {
        /** Bir cevapta en çok bakılan kayıt sayısı ve izlenen CNAME adımı (sınırlı iş: kötü niyetli uzun zincirlere karşı). */
        const val MAX_CNAME_RR = 16
        const val MAX_CNAME_CHAIN = 8

        /**
         * Kanarya adlar: bu adlara "yok" cevabı verilince tarayıcılar kendi şifreli DNS'ini (DoH) kapatır ve sistem DNS'ine döner
         * (Firefox: use-application-dns.net; Apple Özel Aktarma: mask.icloud.com, mask-h2.icloud.com). Böylece DNS süzgeci atlanmaz.
         */
        /** İki harfli ülke uzantısından önce gelen yaygın ikinci düzey adlar (co.uk, com.tr, gov.tr, com.au, co.jp ...). */
        private val SECOND_LEVEL: Array<ByteArray> = arrayOf("co", "com", "org", "net", "gov", "edu", "ac", "or", "ne", "go", "gob", "mil")
            .map { it.toByteArray(Charsets.ISO_8859_1) }.toTypedArray()

        /** Kullanıcıların alt alan aldığı yaygın barındırma uzantıları (Public Suffix List'in "özel" bölümünden küçük bir seçki). */
        private val PRIVATE_SUFFIX: Array<ByteArray> = arrayOf(
            "github.io", "gitlab.io", "blogspot.com", "blogspot.com.tr", "blogspot.co.uk", "herokuapp.com", "vercel.app", "netlify.app",
            "pages.dev", "workers.dev", "web.app", "firebaseapp.com", "appspot.com", "azurewebsites.net", "cloudfront.net",
            "wordpress.com", "myshopify.com", "wixsite.com", "weebly.com", "tumblr.com", "onrender.com", "fly.dev", "surge.sh",
            "glitch.me", "repl.co", "s3.amazonaws.com", "herokudns.com", "ngrok.io", "ngrok-free.app", "trycloudflare.com",
        ).map { it.toByteArray(Charsets.ISO_8859_1) }.toTypedArray()

        val CANARY_NAMES: Array<ByteArray> = arrayOf("use-application-dns.net", "mask.icloud.com", "mask-h2.icloud.com")
            .map { it.toByteArray(Charsets.ISO_8859_1) }.toTypedArray()

        internal fun toTier(list: Collection<String>): FilterTier {
            val a = list.mapNotNull { FilterNames.normalize(it) }.map { FilterHash.hash(it) }.distinct().toLongArray()
            a.sort()
            return FilterTier(a)
        }

        /** SOA kaydının boyu: kök adı (1) + tür/sınıf/TTL/uzunluk (10) + veri (22). */
        private const val SOA_LEN = 33

        /**
         * "Yok" (NXDOMAIN) cevabı: soru kopyalanır, RCODE=3, yetki bölümünde bir SOA kaydı taşır. SOA'nın minimum/TTL alanı
         * [TTL_SECONDS] olduğu için negatif önbellek en fazla o kadar tutar: kullanıcı izin verince ad hemen çözülür.
         * Boyunu döner; sığmıyorsa -1.
         */
        fun buildNxdomain(q: ByteArray, qOff: Int, qEnd: Int, out: ByteArray, outOff: Int): Int {
            val qLen = qEnd - qOff
            if (qLen < Packets.DNS_HDR + 5 || outOff + qLen + SOA_LEN > out.size) return -1
            System.arraycopy(q, qOff, out, outOff, qLen)
            val rd = Packets.u16(q, qOff + 2) and 0x0100
            Packets.put16(out, outOff + 2, 0x8000 or rd or 0x0080 or 3)
            Packets.put16(out, outOff + 4, 1)
            Packets.put16(out, outOff + 6, 0)
            Packets.put16(out, outOff + 8, 1)
            Packets.put16(out, outOff + 10, 0)
            var p = outOff + qLen
            out[p++] = 0                                   // sahip: kök
            Packets.put16(out, p, 6); p += 2               // SOA
            Packets.put16(out, p, 1); p += 2               // IN
            Packets.put32(out, p, TTL_SECONDS); p += 4
            Packets.put16(out, p, 22); p += 2
            out[p++] = 0; out[p++] = 0                     // mname, rname: kök
            Packets.put32(out, p, 1); p += 4               // seri
            Packets.put32(out, p, 3600); p += 4            // yenileme
            Packets.put32(out, p, 600); p += 4             // yeniden deneme
            Packets.put32(out, p, 86400); p += 4           // süre dolumu
            Packets.put32(out, p, TTL_SECONDS); p += 4     // minimum (negatif TTL)
            return p - outOff
        }

        /**
         * Engellenen bir ad için cevap: A ve AAAA sorgusuna NXDOMAIN ([buildNxdomain]); diğer türler için kayıtsız NOERROR
         * ([buildReply]). Eski "0.0.0.0" cevabı, tarayıcıların bu adresi zaman aşımına uğratmasına yol açıyordu.
         */
        fun buildBlocked(q: ByteArray, qOff: Int, qEnd: Int, out: ByteArray, outOff: Int): Int {
            if (qEnd - qOff < Packets.DNS_HDR + 5) return -1
            val qtype = Packets.u16(q, qEnd - 4)
            return if (NXDOMAIN_FOR_BLOCKED && (qtype == 1 || qtype == 28)) buildNxdomain(q, qOff, qEnd, out, outOff)
            else buildReply(q, qOff, qEnd, out, outOff)
        }

        /**
         * Engellenen A/AAAA sorgusuna NXDOMAIN mi (true), yoksa eski 0.0.0.0 / :: mi (false) dönsün. v1.18–v1.19'da NXDOMAIN'di;
         * tüm filtre seviyelerinde site çökmesi bildirildiği için geçici olarak kapatıldı. Kod ve testler korunur.
         */
        const val NXDOMAIN_FOR_BLOCKED = false

        /** Engelleme cevabının en uzun boyu (A: 16 ek bayt, AAAA: 28 ek bayt). */
        const val MAX_REPLY_EXTRA = 40

        /**
         * [q]: sorgu ([qOff] başlangıç, [qEnd] ilk sorunun sonu, [Dns.questionEnd]); [out]'a [outOff] konumundan başlayarak cevabı
         * yazar. A ve AAAA için boş adres, diğer türler için "kayıt yok" (NOERROR, cevapsız). Cevabın boyunu döner; sınıf IN
         * değilse ya da sığmıyorsa -1.
         */
        fun buildReply(q: ByteArray, qOff: Int, qEnd: Int, out: ByteArray, outOff: Int): Int {
            val qLen = qEnd - qOff
            if (qLen < Packets.DNS_HDR + 5) return -1
            val qtype = Packets.u16(q, qEnd - 4)
            val qclass = Packets.u16(q, qEnd - 2)
            if (qclass != 1) return -1
            val answer = if (qtype == 1) 16 else if (qtype == 28) 28 else 0
            if (outOff + qLen + answer > out.size) return -1
            // başlık: kimlik, bayraklar (QR, RD kopyalanır, RA), soru sayısı 1, cevap 0/1
            System.arraycopy(q, qOff, out, outOff, qLen)
            val rd = Packets.u16(q, qOff + 2) and 0x0100
            Packets.put16(out, outOff + 2, 0x8000 or rd or 0x0080)
            Packets.put16(out, outOff + 4, 1)
            Packets.put16(out, outOff + 6, if (answer > 0) 1 else 0)
            Packets.put16(out, outOff + 8, 0)
            Packets.put16(out, outOff + 10, 0)
            var p = outOff + qLen
            if (answer > 0) {
                Packets.put16(out, p, 0xC00C); p += 2                 // ad: sorudaki ada işaretçi
                Packets.put16(out, p, qtype); p += 2
                Packets.put16(out, p, 1); p += 2
                Packets.put32(out, p, TTL_SECONDS); p += 4
                val rdLen = if (qtype == 1) 4 else 16
                Packets.put16(out, p, rdLen); p += 2
                for (i in 0 until rdLen) out[p + i] = 0
                p += rdLen
            }
            return p - outOff
        }

        /** Engelleme cevaplarının TTL'si (sn): kısa, çünkü kullanıcı izin listesine ekleyince hemen etkisini görsün. */
        const val TTL_SECONDS = 30
    }
}

/**
 * Bu oturumda engellenen alan adlarının bellekteki, kısa bir listesi ("hangi site bozuldu?" için). Diske yazılmaz, günlüğe
 * ya da dışa aktarmaya girmez, bağlantı kesilince silinir.
 */
object FilterLive {
    class Item(val name: String, var count: Int, val user: Boolean)

    private const val MAX_ITEMS = 40
    private val items = ArrayList<Item>()
    @Volatile private var total = 0L

    val blockedTotal: Long get() = total

    /** "Geçmişi tut" kapalıysa alan adları hiç listeye alınmaz (yalnızca sayaç artar). */
    @Volatile var keepNames = true

    @Synchronized
    fun note(name: String, user: Boolean) {
        total++
        if (!keepNames) return
        val idx = items.indexOfFirst { it.name == name }
        if (idx >= 0) {
            val it = items.removeAt(idx)
            it.count++
            items.add(0, it)
            return
        }
        items.add(0, Item(name, 1, user))
        if (items.size > MAX_ITEMS) items.removeAt(items.size - 1)
    }

    /** En yeniden eskiye. */
    @Synchronized
    fun recent(): List<Item> = items.map { Item(it.name, it.count, it.user) }

    @Synchronized
    fun clear() {
        items.clear()
        total = 0
    }

    /** "Geçmişi tut" açılıp kapandığında: kapatılınca listedeki adlar hemen silinir (sayaç kalır). */
    @Synchronized
    fun keep(on: Boolean) {
        keepNames = on
        if (!on) items.clear()
    }
}

/**
 * Seçili seviyeye göre motoru kuran ve gerektiğinde değiştiren süreç geneli durum. Liste dosyaları arka planda yüklenir;
 * yükleninceye dek önceki motor (ya da hiçbiri) çalışır. Dosya okunamazsa engelleme sessizce kapalı kalır ve günlüğe yazılır.
 */
object FilterRuntime {
    @Volatile var source: FilterSource? = null
    @Volatile var engine: FilterEngine? = null
        private set

    /**
     * Ağ geçidi (SNI / Host / düz DNS süzgeci) için AYRI motor örneği: [FilterEngine] ara tamponlarını paylaştığı için tek
     * iş parçacığından kullanılır; geçit kendi iş parçacığında bunu kullanır. Seviyesi [setGateway] ile verilir (OFF = yok).
     */
    @Volatile var gatewayEngine: FilterEngine? = null
        private set
    @Volatile private var gwLevel: FilterLevel = FilterLevel.OFF

    /** Ağ geçidinin reklam engelleme seviyesi (gelişmiş reklam engelleme kapalıysa OFF). Motor bir sonraki [update]'te kurulur. */
    fun setGateway(level: FilterLevel) {
        val changed = synchronized(this) { val c = gwLevel != level; gwLevel = level; c && haveLast }
        if (changed) update(lastLevel, lastAllow, lastBlock)
    }

    private val loaded = arrayOfNulls<FilterTier>(3)

    /** Hafif filtre: en fazla 2 liste yüklenir (Sıkı → Orta). Ayardan gelir; değişirse motor yeniden kurulur. */
    @Volatile private var light = false

    /** Bellek yetmezse (OutOfMemoryError) yüklenebilen liste sayısı; sonraki kurulumlar bunu aşmaz. */
    @Volatile private var oomCap = 3

    fun setLight(on: Boolean) {
        val changed = synchronized(this) { val c = light != on; light = on; c && haveLast }
        if (changed) update(lastLevel, lastAllow, lastBlock)
    }
    private var protectedSet: FilterTier? = null
    private var gen = 0
    private val pool by lazy { Executors.newSingleThreadExecutor { r -> Thread(r, "filtre").also { it.isDaemon = true } } }

    /**
     * Kullanıcının içe aktardığı engel listesi ([HostsList]); el ile eklenen engel listesiyle birlikte uygulanır, izin listesi yine üstündür.
     * Diskte uygulamanın kendi klasöründe durur (ayarlara girmez); yüklenince [setImported] ile verilir.
     */
    @Volatile var imported: List<String> = emptyList()
        private set

    private var lastLevel: FilterLevel = FilterLevel.OFF
    private var lastAllow: Collection<String> = emptyList()
    private var lastBlock: Collection<String> = emptyList()
    private var haveLast = false

    /** İçe aktarılan listeyi değiştirir ve (ayarlar daha önce verildiyse) motoru yeniden kurar. */
    fun setImported(list: List<String>) {
        val args = synchronized(this) {
            imported = list
            if (haveLast) Triple(lastLevel, lastAllow, lastBlock) else null
        }
        if (args != null) update(args.first, args.second, args.third)
    }

    /** Ayar değişti (ya da servis başladı): motoru arka planda yeniden kurar. */
    fun update(level: FilterLevel, allow: Collection<String>, block: Collection<String>) {
        val my = synchronized(this) {
            lastLevel = level; lastAllow = allow; lastBlock = block; haveLast = true
            ++gen
        }
        try {
            pool.execute { build(my, level, allow, block) }
        } catch (_: Exception) {}
    }

    /** [update] ile aynı, ama bu iş parçacığında ve bitince döner (testler). */
    fun updateNow(level: FilterLevel, allow: Collection<String>, block: Collection<String>) {
        val my = synchronized(this) {
            lastLevel = level; lastAllow = allow; lastBlock = block; haveLast = true
            ++gen
        }
        build(my, level, allow, block, retry = false)
    }

    fun reset() {
        synchronized(this) { gen++; engine = null; gatewayEngine = null; gwLevel = FilterLevel.OFF; loaded.fill(null); oomCap = 3; light = false; protectedSet = null; imported = emptyList(); haveLast = false }
    }

    private var retries = 0

    /** [names] içinden korunan bir ada (ya da onun alt alan adına) denk gelenleri atar. */
    private fun dropProtected(names: List<String>, prot: FilterTier): List<String> {
        if (prot === FilterTier.EMPTY) return names
        return names.filter { raw ->
            val n = FilterNames.normalize(raw) ?: return@filter true
            var start = 0
            var hit = false
            while (start >= 0) {
                val suf = n.substring(start)
                if (suf.indexOf('.') >= 0 && prot.contains(FilterHash.hash(suf))) { hit = true; break }
                val d = n.indexOf('.', start)
                start = if (d < 0) -1 else d + 1
            }
            !hit
        }
    }

    private fun build(my: Int, level: FilterLevel, allow: Collection<String>, ownBlock: Collection<String>, retry: Boolean = true) {
        val src = source
        val extra = imported
        val gw = gwLevel
        var block: Collection<String> = ownBlock
        try {
            val tiers = ArrayList<FilterTier>(3)
            var prot = FilterTier.EMPTY
            if (src != null) {
                synchronized(this) { protectedSet?.let { prot = it } }
                if (prot === FilterTier.EMPTY) {
                    prot = readProtected(src)
                    synchronized(this) { protectedSet = prot }
                }
                if (!PublicSuffix.ready) try { src.open("psl.txt").use { PublicSuffix.install(it) } } catch (_: Exception) { /* sezgiye dönülür */ }
                val names = arrayOf("basic.bin", "medium.bin", "strict.bin")
                val cap = minOf(oomCap, if (light) 2 else 3)
                for (i in 0 until minOf(maxOf(level.tiers, gw.tiers), cap)) {
                    var t = synchronized(this) { loaded[i] }
                    if (t == null) {
                        try {
                            t = src.open(names[i]).use { FilterTier.read(it) }
                        } catch (_: OutOfMemoryError) {
                            // Bellek bu listeye yetmedi: çökmek yerine o ana dek yüklenenlerle (daha hafif seviye) sürülür.
                            synchronized(this) { oomCap = i }
                            Journal.add("filtre listesi belleğe sığmadı: $i liste ile sürüyor")
                            break
                        }
                        synchronized(this) { loaded[i] = t }
                    }
                    tiers.add(t)
                }
            }
            // Toplu içe aktarılan liste, korunan adları (bağlantı denetimi, saat, resmî/ödeme siteleri) engelleyemez: yanlışlıkla içinde
            // varsa atılır. Kullanıcının elle eklediği engeller bundan etkilenmez (açık tercih korunur).
            if (extra.isNotEmpty()) block = ownBlock + dropProtected(extra, prot)
            val e = FilterEngine(tiers.take(level.tiers), prot, allow, block)
            val ge = if (gw != FilterLevel.OFF) FilterEngine(tiers.take(gw.tiers), prot, allow, block) else null
            synchronized(this) { if (my == gen) { engine = e; gatewayEngine = ge }; retries = 0 }
        } catch (e: Exception) {
            Journal.add("filtre listesi okunamadı: ${e.javaClass.simpleName}")
            val fallback = FilterEngine(emptyList(), FilterTier.EMPTY, allow, if (extra.isEmpty()) ownBlock else ownBlock + extra)
            val gfallback = if (gw != FilterLevel.OFF) FilterEngine(emptyList(), FilterTier.EMPTY, allow, if (extra.isEmpty()) ownBlock else ownBlock + extra) else null
            synchronized(this) { if (my == gen) { engine = fallback; gatewayEngine = gfallback } }
            // Kendini onarma: okuma geçici bir nedenle (bellek, depolama) başarısız olduysa birkaç kez daha denenir;
            // o ana dek engelleme kapalı kalır (bağlantı bozulmaz).
            val again = retry && synchronized(this) { my == gen && retries < RETRY_MAX && ++retries > 0 }
            if (again) {
                Thread({
                    try { Thread.sleep(RETRY_MS * retries) } catch (_: InterruptedException) { return@Thread }
                    if (synchronized(this) { my == gen }) try { pool.execute { build(my, level, allow, ownBlock) } } catch (_: Exception) {}
                }, "filtre-tekrar").also { it.isDaemon = true }.start()
            }
        }
    }

    private const val RETRY_MAX = 3
    private const val RETRY_MS = 15_000L

    private fun readProtected(src: FilterSource): FilterTier {
        val text = src.open("protected.txt").use { it.readBytes().toString(Charsets.UTF_8) }
        val hs = text.lineSequence().map { it.substringBefore('#').trim() }
            .filter { it.isNotEmpty() }.mapNotNull { FilterNames.normalize(it) }.map { FilterHash.hash(it) }.distinct().toList().toLongArray()
        hs.sort()
        return FilterTier(hs)
    }
}

/**
 * Bir [Forwarder]'ı sarar: tünelden gelen sorgu engelleniyorsa cevabı kendisi üretip tünele yazar, değilse içteki
 * yönlendiriciye bırakır. Seviye kapalıysa (ve kullanıcı listeleri boşsa) yalnızca ad ayrıştırması maliyeti vardır.
 */
internal class FilteringForwarder(
    private val inner: Forwarder,
    private val writeToTun: (ByteArray, Int, Int) -> Unit,
) : Forwarder by inner {
    private val parsed = ParsedQuery()
    private val out = ByteArray(Packets.HDR6 + 512 + FilterEngine.MAX_REPLY_EXTRA)
    private val scratch = ByteArray(Packets.MTU)
    @Volatile private var filtered = 0L

    override fun onPacket(p: ByteArray, len: Int) {
        val e = FilterRuntime.engine
        if (e == null) { inner.onPacket(p, len); return }
        val q = parsed
        if (q.parse(p, len, MAX_QUERY)) {
            val v = e.verdict(p, q.dnsOff, q.dnsOff + q.dnsLen)
            if (v == FilterVerdict.CANARY) {
                // Kanarya ad: "yok" cevabı. Tarayıcı kendi şifreli DNS'ini kapatır; engellenen site sayılmaz, listeye girmez.
                val qEnd = Dns.questionEnd(p, q.dnsOff, q.dnsLen)
                val n = if (qEnd > 0) FilterEngine.buildNxdomain(p, q.dnsOff, qEnd, out, Packets.HDR) else -1
                if (n > 0) {
                    Packets.put16(out, Packets.HDR, q.clientId)
                    q.writeCached(out, scratch, n, writeToTun)
                    return
                }
            } else if (v != FilterVerdict.PASS) {
                val qEnd = Dns.questionEnd(p, q.dnsOff, q.dnsLen)
                if (qEnd > 0) {
                    val n = FilterEngine.buildBlocked(p, q.dnsOff, qEnd, out, Packets.HDR)
                    if (n > 0) {
                        Packets.put16(out, Packets.HDR, q.clientId)
                        filtered++
                        FilterLive.note(e.lastName(), v == FilterVerdict.USER)
                        q.writeCached(out, scratch, n, writeToTun)
                        return
                    }
                }
            }
        }
        inner.onPacket(p, len)
    }

    override fun stats(): Stats {
        val s = inner.stats()
        val f = filtered
        return if (f == 0L) s else s.copy(queries = s.queries + f, blocked = s.blocked + f)
    }

    private companion object {
        const val MAX_QUERY = DnsForwarder.MAX_DNS   // iç yönlendirici ile aynı: uzun sorgu süzgeci atlamasın
    }
}
