package app.dnshizli.core

/** Italiano. */
object TxIt : Tx() {
    override val lang = Lang.IT

    override val decimalSep = ','
    override val thousand = " mila"
    override val million = " mln"
    override fun percent(n: Int) = "$n%"
    override val dayU = "g"
    override val hourU = "h"
    override val minU = "min"
    override val secU = "s"
    override val justNow = "proprio ora"
    override fun ago(span: String) = "$span fa"

    override val OFF = "Non connesso"
    override val CONNECTING = "Connessione…"
    override val ON = "Connesso"
    override val ERROR = "Connessione non riuscita"
    override val PAUSED = "In pausa"
    override val HINT_OFF = "Tocca la sfera per connetterti"
    override val HINT_CONNECTING = "Potrebbe richiedere qualche secondo"
    override val HINT_ERROR = "Tocca per riprovare"
    override val HINT_PAUSED = "Tocca per riprendere subito"
    override val ERR_DEFAULT = "Impossibile connettersi"
    override fun selected(name: String) = "$name selezionato"
    override fun pausedUntil(time: String) = "Riprende alle $time"
    override fun blockedShort(n: String) = "$n bloccate"
    override fun queriesShort(n: String) = "$n richieste"
    override fun cacheShort(pct: String) = "$pct in cache"

    override val SERVERS = "Server"
    override val FILTER_ALL = "Tutti"
    override val FILTER_FAV = "Preferiti"
    override val FILTER_RECENT = "Recenti"
    override val EMPTY_FAV = "Ancora nessun preferito. Tocca la stella di un server."
    override val EMPTY_RECENT = "Non ti sei ancora connesso a nessun server."
    override val EMPTY_FILTER = "Nessun server in questa categoria."
    override val MEASURE = "Misura velocità"
    override val MEASURING = "Misurazione…"
    override val SORT = "Ordina per velocità"
    override val PULL_TO_MEASURE = "Trascina per misurare"
    override val RELEASE_TO_MEASURE = "Rilascia per misurare"
    override fun serversCount(n: Int) = "$n server"
    override fun showAllServers(n: Int) = "Mostra tutti ($n)"
    override val SHOW_LESS = "Mostra meno"
    override val TAG_FAST = "Veloci"
    override val TAG_PRIVACY = "Privacy"
    override val TAG_ADS = "Pubblicità"
    override val TAG_FAMILY = "Famiglia"
    override val TAG_SECURITY = "Sicurezza"
    override val VAR_OPEN = "Senza filtri"
    override val VAR_ADS = "Anti-pubblicità"
    override val VAR_SECURITY = "Sicurezza"
    override val VAR_FAMILY = "Famiglia"
    override val A11Y_CONNECTED = "connesso"
    override val A11Y_ENCRYPTED = "cifrato"
    override fun favA11y(name: String) = "$name preferito"

    override val COPIED = "Copiato negli appunti"
    override val DISCONNECTED = "Disconnesso"
    override val BACKUP = "Passato al server di riserva"
    override val NO_REPLY = "Nessun server ha risposto"
    override val MEASURE_FIRST = "Prima misura le velocità"
    override val CONNECT = "Connetti"
    override val UNDO = "Annulla"
    override fun fastest(name: String, ms: Int) = "Il più veloce: $name · $ms ms"
    override fun switched(name: String) = "Passaggio a $name"
    override fun hiddenToast(name: String) = "$name nascosto"

    override val PRIMARY = "Primario"
    override val SECONDARY = "Secondario"
    override val COPY = "Copia"
    override fun addressA11y(label: String, ip: String) = "Indirizzo $label: $ip"
    override val CONNECT_TO_THIS = "Connetti a questo server"
    override val SWITCH_TO_THIS = "Passa a questo server"
    override val CONNECTED_NOW = "Connesso ora"
    override val ADD_FAV = "Aggiungi ai preferiti"
    override val REMOVE_FAV = "Rimuovi dai preferiti"
    override val MEASURE_THIS = "Misura velocità"
    override val HIDE = "Nascondi dall'elenco"
    override val UNHIDE = "Mostra nell'elenco"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Ultima misura: nessuna risposta · $ago" else "Ultima misura: $ms ms · $ago"
    override val NEVER_MEASURED = "Non ancora misurato"
    override val ENC_SUPPORT = "DNS cifrato"
    override val ENC_NONE = "Non supportato"
    override val ENC_ONLY = "Accetta solo connessioni cifrate"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Migliore $best ms · mediana $median ms · perdita $lossPct%"
    override val HISTORY = "Storico misure"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: $n misure, nessuna risposta" else "$HISTORY: $n misure, mediana $median ms"

    override val QUICK_TITLE = "Scelta rapida"
    override val QUICK_FAVORITES = "Preferiti"
    override val QUICK_RECENT = "Usati di recente"
    override val PAUSE_FOR = "Metti in pausa"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} h" else "$n min"
    override val RESUME = "Riprendi"

    override val SETTINGS = "Impostazioni"
    override val MENU = "Menu"
    override val PERSONALIZE = "Personalizza"
    override val PZ_BACKGROUND = "Sfondo"
    override val PZ_AUTO = "Tema automatico"
    override val PZ_FEEL = "Vetro, testo e movimento"
    override val PZ_ACCESS = "Accessibilità ed energia"
    override val DNS_SETTINGS = "Impostazioni DNS"
    override val CONN_APPS = "Connessione e app"
    override val STATS_HISTORY = "Statistiche e cronologia"
    override val SEC_LOOK = "Aspetto"
    override val SEC_LIST = "Elenco server"
    override val SEC_DATA = "Dati"
    override val ABOUT = "Informazioni"
    override val LANGUAGE = "Lingua"
    override val LANG_AUTO = "Automatica (lingua di sistema)"
    override val THEME = "Tema"
    override val THEME_AUTO = "Automatico"
    override val THEME_AUTO_NOTE = "Automatico · segue chiaro/scuro di sistema"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Prato"
        "ocean" -> "Oceano"
        "sunset" -> "Tramonto"
        "lavender" -> "Lavanda"
        "coral" -> "Corallo"
        "mint" -> "Menta"
        "night" -> "Notte"
        "amoled" -> "Nero (AMOLED)"
        "sakura" -> "Sakura"
        "honey" -> "Honey"
        "aurora" -> "Aurora"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Tema: $name"
    override val THEME_SCHEDULE = "Tema notte a orario"
    override val THEME_SCHEDULE_NOTE = "In Automatico, Notte dalle 22:00 alle 07:00"
    override val GLASS = "Opacità del vetro"
    override val BUBBLES = "Bolle"
    override val STYLE = "Stile"
    override val STYLE_NOTES = listOf(
        "Vetro, lucido e con bolle: l'aspetto originale.",
        "Cielo, erba verde, gocce di vetro e pulsanti gel.",
        "Città, musica e giovinezza: grattacieli, altoparlante, anelli, stelle e raggi.",
        "Natura e tecnologia: Terra verde, pale eoliche, pannelli solari e foglie.",
        "Rosa e viola olografici, cuori cromati, bolle, scintille e finestre pixel.",
        "Luce turchese, verde e gialla, fascio luminoso e onde a rete trasparenti.",
        "Vetro blu-indaco traslucido con luce bianca sui bordi e riflessi rifratti.",
    )
    override val WALLPAPER = "Foto di sfondo"
    override val WP_OFF = "Nessuna"
    override val WP_ON = "Foto"
    override val WP_PICK = "Scegli una foto dalla galleria"
    override val WP_PICK_NOTE = "Resta sul telefono, non viene mai caricata. Il velo si rafforza da solo quando serve per mantenere leggibile il testo."
    override val WP_PRESETS = "Immagini incluse"
    override val WP_PRESETS_NOTE = "8 immagini incluse nell'app. Senza internet."
    override val WP_REMOVE = "Rimuovi la foto"
    override val WP_DIM = "Intensità del velo"
    override val WP_BLUR = "Sfocatura"
    override val OPT_WP_BLUR = listOf("No", "Leggera", "Forte")
    override val WP_SAVED = "Sfondo impostato"
    override val WP_FAILED = "Impossibile aprire la foto"
    override val WP_REMOVED = "Sfondo rimosso"
    override val APP_ICON = "Icona dell'app"
    override val ICON_NOTES = listOf(
        "Globo di vetro: l'icona originale.",
        "Una goccia di vetro su cielo ed erba.",
        "Città lime-turchese con raggi di sole e tasto di accensione.",
        "Terra verde lucida con una foglia che spunta.",
        "Un cuore cromato lucido su rosa e viola olografici.",
        "Globo di vetro su bagliore turchese-giallo e onde di luce.",
        "Una sfera di vetro satinato dal bordo luminoso su luce blu-indaco.",
    )
    override val ICON_SET = "L'icona cambia all'uscita"
    override val ICON_NOTE = "Se il collegamento nella schermata Home sparisce, aggiungi di nuovo l'app."
    override val ICON_FAILED = "Impossibile cambiare l'icona"
    override val HELP_WHY_TITLE = "Perché questa app?"
    override val HELP_WHY_BODY = "DNS Hızlı è piccola e semplice, fatta da una sola persona, senza una grande azienda alle spalle. Niente account né pubblicità: scegli tu il DNS, la cifratura, a quali app si applica e come appare."
    override val HELP_WHY_TAIL = "Forse non è migliore della concorrenza, ma funziona e vale la pena provarla."
    override val TROUBLE = "Risoluzione problemi"
    override val TROUBLE_RECHECK = "Ricontrolla"
    override val TROUBLE_ALL_OK = "Sembra tutto a posto. Se non si connette comunque, prova un altro server."
    override val TROUBLE_SOME = "Cose a cui prestare attenzione:"
    override val T_NET = "Internet"
    override val NET_OK = "connesso."
    override val NET_BAD = "assente o limitato. Controlla il Wi-Fi o i dati mobili."
    override val T_PERM = "Autorizzazione VPN"
    override val PERM_OK = "concessa."
    override val PERM_BAD = "non ancora concessa. Android la chiederà alla connessione; consenti."
    override val T_VPN = "Altra VPN"
    override val VPN_OK = "nessuna."
    override val VPN_BAD = "sembra attiva. Android consente una sola VPN alla volta; disattivala."
    override val T_DNS = "DNS privato di Android"
    override val PDNS_OK = "disattivato o automatico, nessun problema."
    override val PDNS_BAD = "è bloccato su un server e può aggirare il DNS di questa app. In Impostazioni > Rete > DNS privato scegli Automatico o Disattivato."
    override val SEARCH = "Cerca"
    override val SEARCH_HINT = "Nome o proprietario del server"
    override val SEARCH_CLEAR = "Cancella"
    override val SHARE_RESULTS = "Condividi i risultati delle misure"
    override val SHARE_RESULTS_HEAD = "Misure DNS Hızlı (dal più veloce)"
    override val NO_RESULTS = "Fai prima una misura"
    override val CUSTOM_EDIT = "Modifica"
    override fun customUpdated(name: String) = "$name aggiornato"
    override val KEEP_HISTORY = "Conserva la cronologia"
    override val KEEP_HISTORY_NOTE = "Se disattivato, server recenti, cronologia e misure non vengono registrati. I dati esistenti restano."
    override val MOTION = "Animazioni"
    override val TEXT_SIZE = "Dimensione testo"
    override val HIGH_CONTRAST = "Contrasto elevato"
    override val HIGH_CONTRAST_NOTE = "Vetro più opaco e testo più scuro"
    override val MINIMAL = "Vista essenziale"
    override val MINIMAL_NOTE = "Nasconde i filtri e la riga delle statistiche"
    override val LOW_POWER = "Risparmio energetico"
    override val LOW_POWER_NOTE = "Disattiva ogni movimento, preserva la batteria"
    override val HAPTICS = "Vibrazione"
    override val HAPTICS_NOTE = "Leggero riscontro al tocco"
    override val ENCRYPTION = "DNS cifrato"
    override val ENCRYPTION_NOTE = "Auto: prima DoT, poi DoH, infine DNS non cifrato"
    override val AUTO_CONNECT = "Connetti all'apertura"
    override val AUTO_CONNECT_NOTE = "All'apertura dell'app si connette all'ultimo server"
    override val CONNECT_ON_BOOT = "Connetti all'avvio"
    override val CONNECT_ON_BOOT_NOTE = "Si connette da solo dopo il riavvio del telefono"
    override val AUTO_FASTEST = "Connetti al più veloce"
    override val AUTO_FASTEST_NOTE = "La sfera sceglie il server più veloce dell'ultima misura"
    override val REFRESH_ON_NET = "Aggiorna al cambio di rete"
    override val REFRESH_ON_NET_NOTE = "Il DNS si aggiorna passando tra Wi-Fi e dati mobili"
    override val NOTIFY_DROP = "Avvisa se cade la connessione"
    override val NOTIFY_DROP_NOTE = "Notifica con pulsante per riconnettere in caso di caduta"
    override val NOTIFY_CONNECT = "Avvisa alla connessione"
    override val NOTIFY_CONNECT_NOTE = "Una breve notifica quando la connessione è attiva"
    override val NOTIFY_STOP = "Avvisa alla disconnessione"
    override val NOTIFY_STOP_NOTE = "Una breve notifica quando ti disconnetti"
    override val NOTIFY_TIMEOUT = "Avvisa se scade il tempo"
    override val NOTIFY_TIMEOUT_NOTE = "Notifica se il server DNS smette di rispondere"
    override val NOTIF_PERM = "Permesso notifiche di sistema"
    override val PERM_ALLOWED = "Consentito"
    override val PERM_BLOCKED = "No · correggi"
    override val NOTIF_CONNECTED_TITLE = "DNS connesso"
    override val NOTIF_STOPPED_TITLE = "DNS disconnesso"
    override val NOTIF_STOPPED_TEXT = "La protezione è spenta"
    override val NOTIF_TIMEOUT_TITLE = "Timeout DNS"
    override val FAIL_CLOSED = "Blocca il DNS se cade"
    override val FAIL_CLOSED_NOTE = "Se la connessione cade, le richieste DNS non finiscono all'operatore; falliscono finché non riconnette"
    override val FILTER_MEM = "Memoria del filtro"
    override val OPT_FILTER_MEM = listOf("Auto", "Leggero", "Completo")
    override val FILTER_MEM_NOTE = "Auto: senza elenco grande se poca memoria. Leggero: senza. Completo: con"
    override val ERR_NO_APPS = "Nessuna app scelta, la protezione non è partita. Scegli le app o passa a «Tutte le app»."
    override val NOTIF_SEALED = "DNS bloccato durante la riconnessione"
    override val ERR_SEALED = "Connessione non riuscita. Il DNS è bloccato per evitare perdite. Tocca Interrompi per liberarlo."
    override val SEALED_INFO = "DNS bloccato finché non torna la connessione"
    override val LATENCY_TITLE = "Latenza per richiesta"
    override val LATENCY_EMPTY = "Si vede in tempo reale a connessione attiva e con richieste in arrivo"
    override val FILTER_MINE = "La mia lista"
    override val MINE_PASTE = "Importa dagli appunti"
    override val MINE_PASTE_NOTE = "File hosts o un dominio per riga"
    override val MINE_FILE = "Importa da file"
    override val MINE_FILE_NOTE = "Un file .txt o hosts sul telefono"
    override val MINE_EXPORT = "Copia la mia lista di blocco"
    override val MINE_EXPORT_NOTE = "Negli appunti, in formato hosts"
    override val MINE_CLEAR = "Elimina la lista importata"
    override val MINE_FOOT = "Legge righe hosts (0.0.0.0 dominio), semplici elenchi di domini e regole ||dominio^. Fino a 50.000 nomi. La tua lista di autorizzazione vince sempre."
    override val MINE_NOTHING = "Nessun dominio valido trovato"
    override val MINE_CLIP_EMPTY = "Gli appunti sono vuoti"
    override val MINE_FILE_ERR = "Impossibile leggere il file"
    override val MINE_CLEARED = "Lista importata eliminata"
    override val MINE_CLEAR_ASK = "Eliminare la lista importata?"
    override val MINE_CUT = "Limite raggiunto, il resto è stato saltato"
    override fun notifTimeout(name: String) = "$name non risponde. Nuovo tentativo."
    override val MOD_DPI = "Aggira DPI"
    override val MOD_ADS = "Pubblicità+"
    override val MOD_DPI_SUB = "Apre i siti bloccati"
    override val MOD_ADS_SUB = "Blocca oltre il DNS"
    override val MOD_ON = "Attivo"
    override val MOD_OFF = "Spento"
    override val BLOCK_QUIC = "Blocca QUIC"
    override val BLOCK_QUIC_NOTE = "Le app tornano a TCP, così Aggira DPI e Pubblicità+ le coprono"
    override val GW_TRIPPED = "Problema di connessione rilevato: Aggira DPI e Pubblicità+ disattivati"
    override val MOD_FAILED = "Impossibile attivare. Permesso VPN negato o un'altra VPN è attiva."
    override fun gwOn(modules: String) = "Gateway attivo: $modules"
    override fun gwOnStats(modules: String, blocked: String) = "Gateway attivo: $modules · $blocked bloccati"
    override fun modOn(name: String) = "$name attivato"
    override fun modOff(name: String) = "$name disattivato"
    override fun modAdsCount(n: String) = "$n bloccati"
    override fun modDpiCount(n: String) = "$n connessioni divise"
    override fun latencyLine(avg: String, max: String, timeouts: Int) = "media $avg · max $max" + (if (timeouts > 0) " · $timeouts timeout" else "")
    override fun mineCount(n: Int) = "$n domini"
    override fun mineAdded(n: Int) = "$n domini aggiunti"
    override fun mineCopied(n: Int) = "$n domini copiati"
    override val CACHE = "Cache DNS"
    override val CLEAR_CACHE = "Svuota cache"
    override val CACHE_CLEARED = "Cache svuotata"
    override val ONLY_CONNECTED = "Disponibile quando connesso"
    override val RULE_WIFI = "Server per Wi-Fi"
    override val RULE_MOBILE = "Server per dati mobili"
    override val RULE_AUTO = "Automatico"
    override val RULE_AUTO_NOTE = "L'ultimo server usato"
    override val COMPACT = "Elenco compatto"
    override val COMPACT_NOTE = "Righe più corte, senza descrizione"
    override val HIDDEN = "Server nascosti"
    override val HIDDEN_NONE = "Nessuno"
    override val STAT_QUERIES = "Richieste totali"
    override val STAT_HITS = "Risposte dalla cache"
    override val STAT_BLOCKED = "Bloccate (stima)"
    override val STAT_TIME = "Tempo totale connesso"
    override val WEEK = "Ultimi 7 giorni"
    override fun weekA11y(total: String) = "$total richieste negli ultimi 7 giorni"
    override val WEEKDAYS = listOf("Lu", "Ma", "Me", "Gi", "Ve", "Sa", "Do")
    override val EXPORT = "Esporta impostazioni"
    override val IMPORT = "Importa impostazioni"
    override val EXPORTED = "Codice impostazioni copiato"
    override val IMPORTED = "Impostazioni caricate"
    override val IMPORT_BAD = "Negli appunti non c'è un codice impostazioni valido"
    override val RESET_SETTINGS = "Ripristina impostazioni"
    override val RESET_STATS = "Azzera statistiche"
    override val CONFIRM = "Sei sicuro?"
    override val RESET = "Ripristina"
    override val RESET_DONE = "Ripristinato"
    override val LOG = "Registro diagnostico"
    override val HELP = "Come funziona?"
    override val VPN_SETTINGS = "Impostazioni VPN di sistema"
    override val SHARE_APP = "Condividi l'app"
    override val RATE_APP = "Valuta l'app"
    override val FEEDBACK = "Invia feedback"
    override fun shareAppText(url: String) = "$APP ti collega ai DNS più noti con un tocco: $url"
    override val VERSION = "Versione"
    override val OPT_BUBBLES = listOf("No", "Poche", "Molte")
    override val OPT_MOTION = listOf("Tutte", "Ridotte", "No")
    override val OPT_CACHE = listOf("No", "Piccola", "Normale", "Grande")
    override val OPT_ENCRYPTION = listOf("Auto", "DoT", "DoH", "No")
    override val PLAIN_DNS = "DNS non cifrato"

    override val LOG_NOTE = "Si conservano solo gli eventi di connessione. Mai nomi delle richieste né dati personali."
    override val LOG_EMPTY = "Ancora nessuna voce."
    override val SHARE = "Condividi"
    override val CLEAR = "Cancella"
    override val CLEARED = "Cancellato"
    override val HELP_SECTIONS = listOf(
        "Cos'è il DNS?" to
            "Il DNS è il servizio che trasforma gli indirizzi internet (come example.com) in numeri comprensibili ai dispositivi. " +
            "Il DNS che usi può influire su velocità, privacy e contenuti bloccati.",
        "Cosa fa l'app?" to
            "Usa il server DNS scelto in tutte le app. Per farlo apre un'interfaccia VPN locale sul telefono, " +
            "ma il tuo traffico non passa da alcun server VPN. Solo le richieste DNS vanno al server scelto; " +
            "tutto il resto segue il percorso normale.",
        "DNS cifrato (DoT / DoH)" to
            "Con i server compatibili le richieste viaggiano cifrate: nessuno in rete (proprietario del Wi-Fi, operatore) vede " +
            "quali siti visiti né può alterare le risposte. In Automatico si prova prima DoT, poi DoH; se nessuno funziona, " +
            "si usa il DNS non cifrato. Vieni avvisato quando succede e l'app prova a tornare alla cifratura a ogni cambio di rete e ogni 10 minuti. " +
            "Con \"Cifratura rigorosa\" attiva, il DNS non cifrato non viene mai usato. La schermata principale mostra il metodo in uso.",
        "Test di connessione" to
            "☰ > Impostazioni DNS > Test di connessione invia vere richieste DNS attraverso il tunnel. Mostra che " +
            "il DNS risponde davvero dal server scelto, con che velocità, se il server convalida le firme DNSSEC " +
            "e se blocca un noto dominio pubblicitario.",
        "Privacy" to
            "Nessun account, nessuna raccolta di dati, nessuna pubblicità. L'app non salva i nomi delle richieste e non invia nulla di sua iniziativa. " +
            "Le tue richieste vanno solo al provider DNS scelto, secondo la sua informativa sulla privacy. " +
            "Il DNS cifrato (DoT/DoH) impedisce a chiunque sulla rete di leggere o alterare le tue richieste. Prima dell'invio l'app rimuove i dati aggiuntivi che potrebbero identificare il dispositivo (sottorete del client, cookie, ID dispositivo), riempie i messaggi per nasconderne la lunghezza e scarta i ticket di sessione TLS quando la rete cambia. " +
            "Per essere sinceri: senza un relay il provider DNS vede comunque il tuo indirizzo IP pubblico (deve pur risponderti), e un errore di certificato può indicare che qualcuno interferisce con la connessione. " +
            "Il registro diagnostico contiene solo eventi di connessione.",
        "Batteria e risorse" to
            "In background consuma pochissimo. A schermo spento non gira nessun ciclo; " +
            "lavora solo quando arriva una richiesta DNS. Le connessioni cifrate si chiudono da sole quando inattive.",
        "Da sapere" to
            "Android consente una sola VPN alla volta; con un'altra app VPN attiva questa non può connettersi. " +
            "Il \"DNS sicuro\" di alcuni browser e il \"DNS privato\" di Android impostato su un nome usano il proprio server " +
            "e possono aggirare questo reindirizzamento; basta lasciarli su \"Automatico\" o \"Disattivato\". " +
            "Tieni premuta la sfera per cambiare server al volo o mettere in pausa la connessione.",
    )

    override val NOTIF_CHANNEL = "Stato della connessione"
    override val NOTIF_CHANNEL_NOTE = "Mostrata mentre la connessione DNS è attiva"
    override val NOTIF_ALERT_CHANNEL = "Avvisi di connessione"
    override val NOTIF_CONNECTING = "Connessione…"
    override val NOTIF_STOP = "Disconnetti"
    override val NOTIF_NEXT = "Successivo"
    override val NOTIF_DROP_TITLE = "Connessione DNS persa"
    override val NOTIF_RECONNECT = "Riconnetti"
    override fun notifOn(name: String, proto: String) = "Connesso a $name · $proto"
    override fun notifPaused(time: String) = "In pausa · riprende alle $time"
    override val TILE_ON = "Connesso"
    override val TILE_OFF = "Disattivato"
    override val WIDGET_TAP = "Tocca: connetti / disconnetti"
    override val ERR_PERMISSION = "Autorizzazione VPN non concessa"
    override val ERR_ESTABLISH = "Impossibile aprire l'interfaccia VPN. Potrebbe esserci un'altra VPN attiva."
    override fun errNoReply(name: String) = "$name non ha risposto"
    override val PHONE_BYPASS = "Il telefono ignora il DNS (DNS privato?)"
    override fun errNoProto(name: String, proto: String) = "$name non supporta $proto"
    override val ERR_SOCKET = "Rete non raggiungibile"
    override fun errPrivateDns(host: String) = "Il DNS privato di Android è impostato su $host e aggira l'app. Imposta Impostazioni > Rete > DNS privato su Automatico o Disattivato."
    override val ERR_REVOKED = "Il sistema ha chiuso la connessione"
    override val ERR_TUNNEL = "Il tunnel si è chiuso inaspettatamente"
    override val ERR_UNKNOWN = "Si è verificato un errore imprevisto"

    override val CONSENT_TITLE = "Prima di connetterti"
    override val CONSENT_BODY = listOf(
        "$APP usa l'interfaccia VPN di Android per indirizzare le tue richieste DNS (i nomi dei siti che visiti) al server DNS scelto.",
        "Il tuo traffico non viene inviato a nessun server VPN; solo le richieste DNS vanno al provider scelto. Con i server compatibili " +
            "sono cifrate (DoT/DoH), altrimenti viaggiano in chiaro. Si applica l'informativa privacy del provider." +
            " Se attivi «$MOD_DPI» o «$MOD_ADS», tutto il traffico passa da un relay che gira solo nel telefono; non viene comunque inviato altrove.",
        "L'app non raccoglie dati personali, non salva i nomi delle richieste e non condivide nulla.",
        "Se continui, Android mostrerà una richiesta di connessione VPN; tocca \"OK\".",
    )
    override val CONSENT_OK = "Ho capito, continua"
    override val CLOSE = "Chiudi"
    override val BACK = "Indietro"

    // ---- 3. sürüm ----
    override val RESUMING = "Ripresa in corso…"
    override val DOWNGRADED = "Cifratura non riuscita, DNS non cifrato"
    override val UPGRADED = "Di nuovo su DNS cifrato"
    override val ODOH = "Oblivious DoH (ODoH)"
    override val OPT_ODOH = listOf("No", "Ripiego", "Rigido")
    override val ODOH_NOTE = "Il relay vede il tuo IP, non la domanda; il server la domanda, non te."
    override val DOWNGRADED_ODOH = "ODoH non disponibile, uso una normale connessione cifrata"
    override val NOTIF_ODOH_TITLE = "ODoH non è attivo"
    override fun notifOdoh(name: String) = "Relay ODoH non raggiungibili. Uso una connessione normale con $name; l'app continua a provare a tornare a ODoH."
    override val ERR_NO_ODOH = "Impossibile connettersi tramite ODoH: relay o destinazioni non rispondono"
    override val NOTIF_DOWNGRADE_TITLE = "Il DNS non è cifrato"
    override fun notifDowngrade(name: String) = "Impossibile stabilire una connessione cifrata con $name. È in uso il DNS non cifrato; l'app proverà a tornare alla cifratura."
    override fun backupUsed(failed: String, used: String) = "$failed non ha risposto, connesso a $used"
    override val NOTIF_RETRYING = "Connessione persa, nuovo tentativo…"
    override fun errNoEncrypted(name: String) = "Impossibile stabilire una connessione cifrata con $name"
    override fun errUntrusted(name: String) = "Impossibile verificare il certificato di $name; la rete o un software potrebbe interferire con le connessioni cifrate"
    override val APPLYING = "Applicazione della nuova impostazione"
    override val CONFIRM_DISCONNECT = "Disconnettere?"
    override val DISCONNECT = "Disconnetti"

    override val SEC_NOTIF = "Notifiche"
    override val STRICT_ENC = "Cifratura rigorosa"
    override val STRICT_ENC_NOTE = "Non ripiegare mai sul DNS non cifrato"
    override val IP_MODE = "Versione IP"
    override val IP_MODE_NOTE = "Si prova prima quella della tua rete; l'altra fa da riserva"
    override val OPT_IP_MODE = listOf("IPv4 + IPv6", "Solo IPv4")
    override val FILTER = "Blocco"
    override val FILTER_LEVEL = "Blocco di pubblicità e tracker"
    override val OPT_FILTER = listOf(
        "Off",
        "Base",
        "Medio",
        "Rigido",
    )
    override val FILTER_NOTES = listOf(
        "Non si blocca nulla.",
        "Siti noti di pubblicità, phishing e malware. Rischio di problemi molto basso.",
        "Base più altri tracker e analisi. Alcuni siti possono dare problemi.",
        "L'elenco più ampio, anche frodi, abusi e reindirizzamenti. Problemi frequenti.",
    )
    override val FILTER_INFO = "Il blocco avviene interamente sul telefono: se si chiede un sito dell'elenco, la risposta è NXDOMAIN, la richiesta non va a nessun server e nessun nome viene salvato. Funziona solo a connessione attiva. Il DNS sicuro proprio di un browser può aggirarlo. Se un sito non funziona, consentilo da Bloccati di recente."
    override val FILTER_LAST = "Bloccati di recente"
    override val FILTER_RECENT_NOTE = "Tocca: consenti"
    override val FILTER_RECENT_EMPTY = "Nulla di bloccato in questa sessione. I nomi appaiono qui a connessione attiva e con un livello scelto."
    override val FILTER_RECENT_FOOT = "Solo in memoria per questa sessione; mai salvato, cancellato alla disconnessione."
    override val FILTER_ALLOW = "Consentiti"
    override val FILTER_BLOCK = "Il mio elenco di blocco"
    override val FILTER_ADD = "Aggiungi…"
    override val FILTER_REMOVE = "Tocca: rimuovi"
    override val FILTER_ALLOW_ADD = "Dominio da consentire"
    override val FILTER_BLOCK_ADD = "Dominio da bloccare"
    override val FILTER_ERR = "Inserisci un dominio valido, es. esempio.it"
    override val FILTER_ERR_LIMIT = "Al massimo 200 domini"
    override val FILTER_ALLOW_EMPTY = "Nessun dominio consentito. Se un sito non funziona, aggiungilo qui."
    override val FILTER_BLOCK_EMPTY = "Il tuo elenco di blocco è vuoto."
    override val FILTER_ALLOW_FOOT = "Il dominio e tutti i sottodomini non vengono mai bloccati. Consentire vince su ogni elenco e sul tuo elenco di blocco."
    override val FILTER_BLOCK_FOOT = "Il dominio e tutti i sottodomini sono sempre bloccati (anche a livello Off)."
    override val FILTER_REMOVE_BTN = "Rimuovi"
    override fun filterAllowed(name: String) = "$name consentito"
    override fun filterBlocked(name: String) = "$name sarà bloccato"
    override fun filterRemoved(name: String) = "$name rimosso"
    override fun filterRemoveAsk(name: String) = "Rimuovere $name dall'elenco?"
    override val TEST_IPV6 = "Percorso IPv6"
    override val AUTO_RECONNECT = "Riconnetti automaticamente"
    override val AUTO_RECONNECT_NOTE = "Se la connessione cade, riprova dopo 5 s, 30 s e 2 min"
    override val BACKUP_SERVER = "Server di riserva"
    override val BACKUP_OFF = "Disattivato"
    override val BACKUP_OFF_NOTE = "Non si connette se il server scelto non risponde"
    override val BACKUP_FASTEST = "Il più veloce"
    override val BACKUP_FASTEST_NOTE = "L'altro server più veloce dell'ultima misura"
    override val CONFIRM_OFF = "Conferma la disconnessione"
    override val CONFIRM_OFF_NOTE = "Un tocco accidentale sulla sfera non disconnette"
    override val LOCK_HIDE = "Nascondi a schermo bloccato"
    override val LOCK_HIDE_NOTE = "Il nome del server non appare nella notifica a schermo bloccato"
    override val QUIET_NOTIF = "Notifica discreta"
    override val QUIET_NOTIF_NOTE = "Nessuna icona nella barra di stato, silenziosa"
    override val REMEMBER_FILTER = "Ricorda l'ultimo filtro"
    override val REMEMBER_FILTER_NOTE = "All'apertura dell'app torna l'ultimo filtro scelto"
    override val AUTO_MEASURE = "Misura all'avvio"
    override val AUTO_MEASURE_NOTE = "Misura da solo se l'ultima misura ha più di un giorno"
    override val MEASURE_ENC = "Misura cifrata"
    override val MEASURE_ENC_NOTE = "Misura la velocità via DoT, più vicina all'uso cifrato reale"
    override val OPT_SORT = listOf("Standard", "Velocità", "Nome")
    override fun sortA11y(mode: String) = "Ordine: $mode"
    override val AUTO_LIGHT = "Automatico: tema chiaro"
    override val AUTO_DARK = "Automatico: tema scuro"
    override val NIGHT_HOURS = "Ore notturne"
    override val FILTER_ENCRYPTED = "Cifrati"
    override val FILTER_UNFILTERED = "Senza filtri"

    override val TEST = "Testa la connessione"
    override val TEST_NOTE = "DNS, DNSSEC e blocco pubblicità"
    override val TESTING = "Test in corso…"
    override val TEST_TITLE = "Test di connessione"
    override val TEST_OK = "Il DNS funziona"
    override val TEST_FAIL = "Nessuna risposta"
    override val TEST_SERVER = "Server"
    override val TEST_METHOD = "Metodo"
    override val TEST_LATENCY = "Tempo di risposta"
    override val TEST_DNSSEC = "Convalida DNSSEC"
    override val TEST_ADS = "Blocco pubblicità"
    override val DNSSEC_YES = "Convalida attiva"
    override val DNSSEC_NO = "Nessuna convalida"
    override val ADS_YES = "Attivo"
    override val ADS_NO = "Non attivo"
    override val UNKNOWN = "Sconosciuto"
    override val TEST_EXPLAIN = "Le domande sono state inviate attraverso il tunnel, come farebbe un'app; le risposte sono arrivate dal server scelto."
    override val TEST_AGAIN = "Ripeti il test"

    override val RECOMMEND = "Trovami un server"
    override val RECOMMEND_NOTE = "Scegli l'obiettivo e ti colleghiamo al più veloce adatto"
    override val GOAL_SPEED = "Velocità"
    override val GOAL_SPEED_NOTE = "Il server più veloce secondo le tue misure"
    override val GOAL_PRIVACY_NOTE = "Nessun log, attento alla privacy"
    override val GOAL_ADS_NOTE = "Blocca pubblicità e tracker"
    override val GOAL_FAMILY_NOTE = "Blocca i contenuti per adulti"
    override val GOAL_SECURITY_NOTE = "Blocca siti dannosi e di phishing"
    override fun recommended(name: String) = "Consigliato: $name"

    override val PRIVATE_DNS = "Nome DNS privato"
    override val PRIVATE_DNS_NOTE = "Puoi incollarlo nell'impostazione DNS privato di Android. Il sistema userà questo server direttamente, aggirando quest'app."
    override val CLEAR_HISTORY = "Cancella storico misure"
    override val HISTORY_CLEARED = "Misure cancellate"

    override val GUARD = "Protezione continua"
    override val GUARD_NOTE = "VPN sempre attiva"
    override val GUARD_BODY = listOf(
        "Quando l'app non è connessa (spenta, in pausa o dopo una caduta), le tue richieste DNS vanno al server del tuo provider internet.",
        "Per evitarlo, attiva \"VPN sempre attiva\" per quest'app nelle impostazioni VPN di Android. Se è attivo anche \"Blocca connessioni senza VPN\", internet non funzionerà affatto finché l'app non è connessa: nulla trapela, ma mettere in pausa significa anche restare senza internet.",
        "Con la VPN sempre attiva, il sistema avvia l'app da solo all'accensione del telefono e dopo che si è fermata.",
    )
    override val GUARD_BUTTON = "Apri impostazioni VPN"
    override val BATTERY = "Impostazioni batteria"
    override val BATTERY_OK = "Senza limitazioni"
    override val BATTERY_LIMITED = "Potrebbe essere limitata"
    override val BATTERY_BODY = listOf(
        "Android di solito protegge le app VPN. Alcuni produttori (Xiaomi, Huawei, Oppo, Vivo, alcune versioni Samsung) però possono chiudere le app in background per risparmiare batteria.",
        "Se la connessione cade da sola, imposta l'uso della batteria di quest'app su \"Senza limitazioni\" o \"Non ottimizzata\"; su alcuni telefoni consenti anche l'\"Avvio automatico\".",
    )
    override val BATTERY_BUTTON = "Apri impostazioni batteria"

    override val STAT_AVG = "Tempo medio di risposta"
    override val STAT_SAVED = "Tempo risparmiato con la cache"
    override val STAT_TRAFFIC = "Traffico DNS"
    override val SESSIONS = "Storico connessioni"
    override val SESSIONS_NOTE = "Ultime 30 connessioni; i nomi delle richieste non sono mai salvati"
    override val SESSIONS_EMPTY = "Ancora nessuna connessione registrata."
    override val MOST_USED = "Più usati"
    override val TODAY = "Oggi"
    override val ORB_SHAPE = "Forma della sfera"
    override val ORB_SHAPE_EACH = "Forma per tema"
    override val ORB_SHAPE_NAMES = listOf("Sfera", "Triangolo", "Quadrato", "Esagono", "Stella", "Ottagono", "Pentagono", "Rettangolo", "Triangolo rovesciato", "Diamante", "Fiore", "Stella a sei punte")
    override val SHIELD_WORD = "Scudo"
    override val LIQUID_COLOR = "Colore del liquido"
    override val LIQUID_THEME = "Come il tema"
    override val COLOR_WORD = "Colore"
    override val LIQUID_NOTE = "Un colore scelto sostituisce la tinta di velocità; la velocità delle onde segue ancora il server."
    override val YESTERDAY = "Ieri"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Disconnesso da te"
        EndReason.PAUSE -> "In pausa"
        EndReason.SWITCH -> "Server cambiato"
        EndReason.DROP -> "Caduta"
        EndReason.REVOKED -> "Chiusa dal sistema"
        EndReason.FAILED -> "Nessuna risposta"
        EndReason.NETWORK -> "Rete cambiata"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries richieste"

    override val SOUND_MOTION = "Suono e movimento"
    override val SEC_SOUND = "Suono"
    override val SOUND_ON = "Effetti sonori"
    override val SOUND_ON_NOTE = "Suoni brevi e delicati al tocco e alla connessione. Silenziosi se il telefono è muto."
    override val SOUND_UI = "Suoni al tocco"
    override val SOUND_UI_NOTE = "Pulsanti, interruttori e cambi di pagina"
    override val SOUND_CONN = "Suoni di connessione"
    override val SOUND_CONN_NOTE = "Suoni distinti per connessione, disconnessione ed errori"
    override val SOUND_VOL = "Volume"
    override val SOUND_PACK = "Pacchetto sonoro"
    override val SOUND_TEST = "Prova il suono di connessione"
    override val QUIET_HOURS = "Ore silenziose"
    override val QUIET_NOTE = "Niente suoni né vibrazione in questa fascia"
    override val QUIET_RANGE = "Fascia delle ore silenziose"
    override val SEC_MOTION_FX = "Movimento ed effetti"
    override val ANIM_SPEED = "Velocità delle animazioni"
    override val TAP_FX = "Effetto al tocco"
    override val TAP_FX_NOTE = "Un piccolo effetto tipico dello stile dove tocchi"
    override val CELEBRATE = "Festeggiamento alla connessione"
    override val CELEBRATE_NOTE = "Uno spettacolo tipico dello stile attorno alla sfera quando ti connetti"
    override val HAPTIC_LEVEL = "Intensità della vibrazione"
    override val REMEMBER_MODS = "Ricorda i moduli"
    override val REMEMBER_MODS_NOTE = "Alla connessione, Aggira DPI e Pubblicità+ si attivano come li hai lasciati"
    override val PROFILES = "Profili"
    override val COPY_STATUS = "Copia il riepilogo dello stato"
    override val OPT_PACK = listOf("Auto", "Morbido", "Vetro", "Classico")
    override val SOUND_PACK_NOTE = "Auto: il suono dello stile in uso"
    override val PACK_SPACE = "Spazio"
    override val PACKS_NOTE = "I nuovi pacchetti (con Liquid Glass) portano suoni propri e dieci animazioni: tocco, interruttore, connessione, disconnessione, errore, fatto, pannello, indietro, selezione e aggiornamento."
    override val OPT_HAPTIC = listOf("Leggera", "Normale", "Forte")
    override val PROFILE_NAMES = listOf("Velocità", "Privacy", "Famiglia", "Protezione totale")
    override val PROFILE_NOTES = listOf("Server più veloce, cache ampia, nessun blocco", "Crittografia rigida, blocco dei tracker, Pubblicità+", "Server con filtro famiglia, blocco medio", "Blocco di pubblicità e tracker, Aggira DPI, Pubblicità+")
    override fun profileApplied(name: String) = "Profilo applicato: $name"

    override val WHATS_NEW = "Novità"
    override val WHATS_NEW_TOAST = "L'app è stata aggiornata"
    override val SHOW = "Mostra"
    override val WHATS_NEW_ITEMS = listOf(
        "Novità: Oblivious DoH (ODoH) facoltativo: un relay vede il tuo IP, il server DNS le domande, mai entrambi. ☰ > DNS.",
        "Novità: effetti sonori, un motore di animazione fluido riscritto, effetti al tocco tipici di ogni stile, profili, ore silenziose e altro. ☰ > Suono e movimento.",
        "Novità: pulsanti Aggira DPI e Pubblicità+. Funzionano con il DNS o da soli; entrambi spenti di default.",
        "Novità: importa la tua lista di blocco, notifiche di connessione, caduta e timeout, grafico della latenza e blocco del DNS se cade.",
        "Novità: l'elenco mostra prima 8 server (Mostra tutti / Mostra meno), Aggiungi DNS personalizzato in alto, barra di scorrimento sottile.",
        "Novità: blocco di pubblicità, tracker e malware (Off/Base/Medio/Rigido) con liste personali di consenso e blocco. ☰ > Blocco. Tutto sul telefono.",
        "Novità: stile Frutiger Aurora; Y2K ora olografico e Metro con città e musica. Scegli in ☰ > Personalizza > Stile.",
        "Novità: IPv4 e IPv6 insieme, rilevamento guasti più rapido; per la privacy vengono rimosse le tracce del dispositivo e nascoste le lunghezze.",
        "Novità: impostazioni divise per argomento. Nel menu ☰: DNS, Connessione e app, Notifiche, Elenco server, Statistiche e cronologia, Dati.",
        "Novità: finestra Personalizza (nel menu ☰): lingua, tema, stile, sfondo, icona, testo e accessibilità.",
        "Novità: menu ☰ nella schermata iniziale e una finestra Info (novità, aiuto, registro, condividi, versione).",
        "Correzione: ora funziona usare la tua foto o un'immagine inclusa come sfondo (la dimensione era letta male).",
        "Correzione: il test di connessione distingue un server guasto da un telefono che non usa il DNS, e avvisa.",
        "Correzione: stili Metro, Eco e Y2K ridisegnati; il cambio icona si applica quando esci dall'app.",
        "Novità: 8 sfondi inclusi (☰ → Personalizza → Foto di sfondo → Immagini incluse).",
        "Novità: risoluzione problemi, ricerca server, condivisione misure, modifica dei server personali e opzione senza cronologia.",
        "Icona dell'app: scegli tra cinque icone abbinate ai cinque stili.",
        "Foto di sfondo: usa una tua immagine come sfondo, con velo e sfocatura regolabili; il testo resta sempre leggibile.",
        "Cinque stili: Aqua (classico), Aero (cielo ed erba), Metro (riquadri piatti), Eco (natura) e Y2K rosa, ciascuno con animazioni proprie e transizioni più fluide.",
        "Scelta delle app: applica il DNS solo alle app scelte o escludine alcune.",
        "Aggiungi i tuoi server DNS (fino a 8), 10 nuovi server e una sezione info per ogni server: a cosa serve, proprietario, ping medio.",
        "Connessione più sicura: controlli extra contro risposte DNS false, avviso quando si ripiega sul DNS non cifrato, opzione di cifratura rigorosa e ritorno automatico alla cifratura.",
        "Test di connessione: verifica con un tocco che il DNS risponda dal server scelto, oltre a convalida DNSSEC e blocco pubblicità.",
        "Server di riserva e riconnessione automatica: l'app si ripristina da sola se il server scelto non risponde o la connessione cade.",
        "Storico connessioni, server più usati, tempo medio di risposta e traffico DNS.",
        "Nuovi filtri (Cifrati, Senza filtri), ordinamento per nome, \"Trovami un server\" e misura all'avvio.",
        "Contatori in tempo reale nella notifica, pulsante di pausa di 15 minuti, opzione per nascondere a schermo bloccato e notifica discreta.",
        "Tre nuovi temi (Sakura, Miele, Aurora), un tema dallo sfondo e scelta chiaro/scuro per il tema automatico.",
        "Quattro nuove lingue: indonesiano, vietnamita, polacco e ucraino.",
    )
    override fun importedWith(changes: String) = "Impostazioni caricate · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "cifratura indebolita"
        SensitiveChange.AUTO_START -> "connessione automatica attivata"
        SensitiveChange.RULES -> "regole dei server modificate"
        SensitiveChange.PRIVACY -> "impostazioni di privacy o avvisi allentate"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries richieste · $blocked bloccate"
    override val NOTIF_LOCKED = "Protezione DNS attiva"
    override val NOTIF_QUIET_CHANNEL = "Stato della connessione (discreta)"
    override fun widgetToday(queries: String) = "Oggi $queries richieste"
    override fun pauseAction(minutes: Int) = "Pausa ${minutes(minutes)}"


    override val CUSTOM_NOTE = "Server che hai aggiunto"
    override val CUSTOM_ADD = "Aggiungi DNS personalizzato"
    override val CUSTOM_F_NAME = "Nome"
    override val CUSTOM_F_IP1 = "Indirizzo IPv4 (es. 1.2.3.4)"
    override val CUSTOM_F_IP2 = "Secondo IPv4 (facoltativo)"
    override val CUSTOM_F_DOT = "Nome DoT (facoltativo)"
    override val CUSTOM_F_DOH = "Indirizzo DoH, https://… (facoltativo)"
    override val CUSTOM_SAVE = "Aggiungi"
    override val CUSTOM_CANCEL = "Annulla"
    override val CUSTOM_HINT = "Compila DoT o DoH per una connessione cifrata; se vuoto si usa il DNS non cifrato."
    override val CUSTOM_ERR_NAME = "Il nome deve avere 1–24 caratteri (senza | ; , =)"
    override val CUSTOM_ERR_IP = "Inserisci un indirizzo IPv4 valido (es. 1.2.3.4)"
    override val CUSTOM_ERR_DOT = "Il nome DoT deve essere un dominio valido"
    override val CUSTOM_ERR_DOH = "L'indirizzo DoH deve iniziare con https://"
    override val CUSTOM_ERR_LIMIT = "Puoi aggiungere al massimo 8 server personali"
    override fun customAdded(name: String) = "$name aggiunto"
    override val CUSTOM_DELETE = "Elimina questo server"
    override val CUSTOM_IN_USE = "Impossibile eliminare mentre è connesso"
    override fun customDeleted(name: String) = "$name eliminato"
    override val INFO_PURPOSE = "A cosa serve"
    override val INFO_OWNER = "Proprietario"
    override val INFO_AVG = "Ping medio"
    override fun avgPing(ms: Int, n: Int) = "$ms $msU · $n misurazioni"

    override val APPS = "App"
    override val APPS_ALL = "Tutte"
    override fun appsOnly(n: Int) = "Solo selezionate ($n)"
    override fun appsExcept(n: Int) = "Tutte tranne le selezionate ($n)"
    override val APPS_MODE = "Quali app usano questo DNS?"
    override val OPT_APPS = listOf("Tutte", "Selezionate", "Tutte tranne")
    override val APPS_NOTE = "Le app escluse usano il DNS del telefono. Funziona un solo server DNS alla volta; non se ne può scegliere uno per app."
    override val APPS_LOADING = "Caricamento app…"
    override val APPS_EMPTY = "Nessuna app trovata"
    override val APPS_NONE_SELECTED = "Nessuna app scelta: la protezione non si avvia. Scegli le app o passa a «Tutte le app»."
    override val APPS_APPLY = "Applica ora"
    override val APPS_PENDING = "La modifica ha effetto al rinnovo della connessione (cade per un paio di secondi)."

    override val NOTES = mapOf(
        "cloudflare" to "Veloce, attento alla privacy",
        "google" to "Stabile, molto diffuso",
        "quad9" to "Blocca i domini dannosi",
        "adguard" to "Blocca pubblicità e tracker",
        "controld" to "Senza filtri, veloce",
        "opendns" to "Cisco, protezione anti-phishing",
        "dnssb" to "Attento alla privacy, veloce",
        "dns4eu" to "DNS dell'UE, contro i malware",
        "uncensored" to "Nessun filtro né reindirizzamento",
        "quad9-open" to "Non blocca nulla",
        "adguard-open" to "Nessun blocco, attento alla privacy",
        "dns4eu-open" to "DNS dell'UE, senza filtri",
        "controld-ads" to "Pubblicità, tracker, malware",
        "dns4eu-ads" to "DNS dell'UE, pubblicità e malware",
        "cloudflare-security" to "Blocca i siti dannosi",
        "controld-malware" to "Blocca i siti dannosi",
        "cleanbrowsing-security" to "Phishing e siti dannosi",
        "cloudflare-family" to "Filtro malware e contenuti adulti",
        "opendns-family" to "Filtro contenuti per adulti",
        "adguard-family" to "Filtro pubblicità e contenuti adulti",
        "cleanbrowsing-family" to "Contenuti adulti, ricerca sicura",
        "dns4eu-child" to "DNS dell'UE, tutela dei minori",
        "controld-family" to "Filtro contenuti per adulti",
        "nextdns" to "Filtro configurabile, veloce",
        "cira-private" to "Canada, senza filtri, privacy",
        "cira-protected" to "Canada, blocca siti dannosi",
        "libredns" to "Indipendente, senza filtri",
        "switch" to "Svizzera, blocca siti dannosi",
        "wikimedia" to "DNS di Wikimedia, privacy",
        "digitale" to "No profit svizzero, senza filtri",
        "quad101" to "Taiwan, veloce",
        "alidns" to "Cina, veloce",
    )
}
