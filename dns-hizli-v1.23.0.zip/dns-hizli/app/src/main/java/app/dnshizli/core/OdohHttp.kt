package app.dnshizli.core

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLPeerUnverifiedException
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * Tek seferlik HTTPS GET (HTTP/1.1, `Connection: close`). Yalnızca hedefin `/.well-known/odohconfigs` yapılandırmasını almak için.
 * Sıkı sınırlar: toplam süre, gövde boyutu, başlık sayısı; yönlendirme izlenmez; sertifika [host] adına göre doğrulanır.
 * Adresler sırayla denenir; çalışan adres [onGood] ile bildirilir.
 */
object MiniHttps {
    const val MAX_BODY = 70_000
    private const val MAX_LINE = 8192
    private const val MAX_HEADERS = 64

    fun get(
        host: String,
        path: String,
        addrs: List<InetSocketAddress>,
        openSocket: (InetSocketAddress, Int) -> Socket,
        tls: SSLSocketFactory,
        verifier: HostnameVerifier = HttpsURLConnection.getDefaultHostnameVerifier(),
        connectMs: Int = 3000,
        totalMs: Long = 8000,
        now: () -> Long = { System.nanoTime() / 1_000_000 },
        onGood: (InetSocketAddress) -> Unit = {},
    ): ByteArray {
        if (addrs.isEmpty()) throw IOException("adres yok")
        val deadline = now() + totalMs
        var last: IOException? = null
        for (a in addrs) {
            if (now() >= deadline) break
            try {
                val body = getOne(host, path, a, openSocket, tls, verifier, connectMs, deadline, now)
                onGood(a)
                return body
            } catch (e: IOException) {
                last = e
                if (e is HttpStatusException && e.code in 400..499) throw e      // adresle ilgisiz: sunucu açıkça reddetti
            }
        }
        throw last ?: IOException("zaman aşımı")
    }

    class HttpStatusException(val code: Int) : IOException("HTTP $code")

    private fun getOne(
        host: String, path: String, addr: InetSocketAddress, openSocket: (InetSocketAddress, Int) -> Socket,
        tls: SSLSocketFactory, verifier: HostnameVerifier, connectMs: Int, deadline: Long, now: () -> Long,
    ): ByteArray {
        val remaining = (deadline - now()).coerceAtLeast(1)
        val raw = openSocket(addr, minOf(connectMs.toLong(), remaining).toInt())
        try {
            val left = (deadline - now()).coerceIn(1, 60_000).toInt()
            raw.soTimeout = left
            raw.tcpNoDelay = true
            val ssl = tls.createSocket(raw, host, addr.port, true) as SSLSocket
            val modern = ssl.supportedProtocols.filter { it == "TLSv1.3" || it == "TLSv1.2" }
            if (modern.isNotEmpty()) ssl.enabledProtocols = modern.toTypedArray()
            ssl.soTimeout = left
            ssl.startHandshake()
            if (!verifier.verify(host, ssl.session)) throw SSLPeerUnverifiedException("sertifika $host adına ait değil")
            val out = ssl.outputStream
            out.write(("GET $path HTTP/1.1\r\nHost: $host\r\nUser-Agent: Mozilla/5.0\r\nAccept: */*\r\nConnection: close\r\n\r\n")
                .toByteArray(Charsets.ISO_8859_1))
            out.flush()
            return readResponse(BufferedInputStream(ssl.inputStream, 4096), deadline, now)
        } finally {
            try { raw.close() } catch (_: Exception) {}
        }
    }

    internal fun readResponse(input: InputStream, deadline: Long, now: () -> Long): ByteArray {
        fun check() { if (now() > deadline) throw SocketTimeoutException("süre doldu") }
        fun line(): String? {
            val sb = StringBuilder(64)
            while (true) {
                check()
                val b = input.read()
                if (b < 0) return if (sb.isEmpty()) null else throw EOFException("satır kesildi")
                if (b == '\n'.code) { if (sb.isNotEmpty() && sb[sb.length - 1] == '\r') sb.setLength(sb.length - 1); return sb.toString() }
                if (sb.length > MAX_LINE) throw IOException("satır çok uzun")
                sb.append(b.toChar())
            }
        }
        val status = line() ?: throw EOFException("cevap yok")
        val parts = status.split(' ')
        if (parts.size < 2 || !parts[0].startsWith("HTTP/1.")) throw IOException("bozuk durum satırı")
        val code = parts[1].toIntOrNull() ?: throw IOException("bozuk durum satırı")
        var length = -1L
        var chunked = false
        var n = 0
        while (true) {
            val l = line() ?: throw EOFException("başlık kesildi")
            if (l.isEmpty()) break
            if (++n > MAX_HEADERS) throw IOException("çok fazla başlık")
            val c = l.indexOf(':')
            if (c <= 0) continue
            val name = l.substring(0, c).trim().lowercase()
            val value = l.substring(c + 1).trim()
            if (name == "content-length") length = if (value.isNotEmpty() && value.length <= 9 && value.all { it in '0'..'9' }) value.toLong() else -1
            else if (name == "transfer-encoding") chunked = value.lowercase().contains("chunked")
        }
        if (code != 200) throw HttpStatusException(code)
        val buf = ByteArrayOutputStream(1024)
        val tmp = ByteArray(2048)
        fun take(count: Long) {
            var left = count
            while (left > 0) {
                check()
                val r = input.read(tmp, 0, minOf(left, tmp.size.toLong()).toInt())
                if (r < 0) throw EOFException("gövde kesildi")
                if (buf.size() + r > MAX_BODY) throw IOException("gövde çok büyük")
                buf.write(tmp, 0, r)
                left -= r
            }
        }
        when {
            chunked -> while (true) {
                val hex = (line() ?: throw EOFException("parça kesildi")).substringBefore(';').trim()
                if (hex.isEmpty() || hex.length > 6 || !hex.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) throw IOException("bozuk parça")
                val size = hex.toInt(16)
                if (size == 0) break
                take(size.toLong())
                line()
            }
            length >= 0 -> { if (length > MAX_BODY) throw IOException("gövde çok büyük"); take(length) }
            else -> while (true) {                                   // Connection: close ile bitiş
                check()
                val r = input.read(tmp)
                if (r < 0) break
                if (buf.size() + r > MAX_BODY) throw IOException("gövde çok büyük")
                buf.write(tmp, 0, r)
            }
        }
        return buf.toByteArray()
    }
}

/**
 * Düğüm adreslerinin defteri. Sıra: son çalışan adres → ipucu adresleri → (gerekirse) şifreli çözümleme sonucu.
 * Çözümleme yalnızca bütün bilinen adresler başarısız olunca ve [resolveCooldownMs]'de en çok bir kez yapılır; sonuç [resolveTtlMs]
 * boyunca tutulur. Çalışan adres ağ değişince unutulmaz (aynı IP başka ağda da çalışır) ama [forgetGood] ile silinebilir.
 */
class OdohAddressBook(
    private val now: () -> Long,
    private val resolve: ((String) -> List<String>)? = null,
    private val resolveTtlMs: Long = 3600_000L,
    private val resolveCooldownMs: Long = 30_000L,
) {
    private class E {
        @Volatile var good: String? = null
        @Volatile var resolved: List<String> = emptyList()
        @Volatile var resolvedAt = Long.MIN_VALUE / 2
        @Volatile var lastResolve = Long.MIN_VALUE / 2
    }

    private val map = ConcurrentHashMap<String, E>()
    private fun e(host: String) = map.getOrPut(host) { E() }

    /** [node] için adres sırası (en çok [OdohNode.MAX_IPS] + çözümlenenler, yinelenen yok). */
    fun addresses(node: OdohNode, port: Int = 443, includeResolved: Boolean = false): List<InetSocketAddress> {
        val en = e(node.id)
        val out = LinkedHashSet<String>()
        en.good?.let { out.add(it) }
        out.addAll(node.ips.take(OdohNode.MAX_IPS))
        if (includeResolved) {
            val t = now()
            if (en.resolved.isEmpty() || t - en.resolvedAt > resolveTtlMs) refresh(node, en)
            out.addAll(en.resolved)
        } else if (en.resolved.isNotEmpty() && now() - en.resolvedAt <= resolveTtlMs) {
            out.addAll(en.resolved)
        }
        return out.mapNotNull { toAddr(it, port) }
    }

    private fun refresh(node: OdohNode, en: E) {
        val r = resolve ?: return
        val t = now()
        synchronized(en) {
            if (t - en.lastResolve < resolveCooldownMs) return
            en.lastResolve = t
            val got = try { r(node.host) } catch (_: Exception) { emptyList() }
            val clean = got.filter { Ip.parse(it) != null }.take(OdohNode.MAX_IPS)
            if (clean.isNotEmpty()) { en.resolved = clean; en.resolvedAt = now() }
        }
    }

    fun markGood(node: OdohNode, a: InetSocketAddress) { e(node.id).good = a.address.hostAddress }
    fun forgetGood() { for (v in map.values) v.good = null }
    fun lastGood(node: OdohNode): String? = map[node.id]?.good

    private fun toAddr(ip: String, port: Int): InetSocketAddress? {
        val b = Ip.parse(ip) ?: return null
        return try { InetSocketAddress(InetAddress.getByAddress(b), port) } catch (_: Exception) { null }
    }
}

/**
 * Şifreli (DoT) tek seferlik ad çözücü: ipucu adresleri bayatlayınca röle/hedef adlarının IPv4 adreslerini bulur.
 * Düz DNS kullanılmaz. Sunucular sırayla denenir; sertifika sunucu adına göre doğrulanır.
 */
class OdohBootstrap(
    private val servers: List<Pair<String, String>>,                 // (ip, sertifika adı)
    private val openSocket: (InetSocketAddress, Int) -> Socket,
    private val tls: () -> SSLSocketFactory,
    private val verifier: HostnameVerifier = HttpsURLConnection.getDefaultHostnameVerifier(),
    private val random: java.security.SecureRandom = java.security.SecureRandom(),
    private val timeoutMs: Int = 2500,
) {
    fun resolve(name: String): List<String> {
        for ((ip, cert) in servers) {
            val b = Ip.parse(ip) ?: continue
            try {
                val addr = InetSocketAddress(InetAddress.getByAddress(b), 853)
                val raw = openSocket(addr, timeoutMs)
                try {
                    raw.soTimeout = timeoutMs
                    val ssl = tls().createSocket(raw, cert, 853, true) as SSLSocket
                    val modern = ssl.supportedProtocols.filter { it == "TLSv1.3" || it == "TLSv1.2" }
                    if (modern.isNotEmpty()) ssl.enabledProtocols = modern.toTypedArray()
                    ssl.soTimeout = timeoutMs
                    ssl.startHandshake()
                    if (!verifier.verify(cert, ssl.session)) continue
                    val id = random.nextInt(65536)
                    val q = Dns.buildQuery(id, name)
                    val o = ssl.outputStream
                    o.write(byteArrayOf((q.size ushr 8).toByte(), q.size.toByte())); o.write(q); o.flush()
                    val inp = BufferedInputStream(ssl.inputStream, 2048)
                    val l0 = inp.read(); val l1 = inp.read()
                    if (l0 < 0 || l1 < 0) continue
                    val len = (l0 shl 8) or l1
                    if (len < Packets.DNS_HDR || len > 4096) continue
                    val r = ByteArray(len)
                    var got = 0
                    while (got < len) { val n = inp.read(r, got, len - got); if (n < 0) break; got += n }
                    if (got < len || Packets.u16(r, 0) != id) continue
                    if (!Dns.sameQuestion(q, 0, Dns.questionEnd(q, 0, q.size), r, 0, len)) continue
                    val a = Dns.aRecords(r, len).filter { okIp(it) }
                    if (a.isNotEmpty()) return a
                } finally {
                    try { raw.close() } catch (_: Exception) {}
                }
            } catch (_: IOException) {
            } catch (_: RuntimeException) {
            }
        }
        return emptyList()
    }

    private fun okIp(ip: String): Boolean {
        val p = ip.split('.')
        if (p.size != 4) return false
        val n = p.map { it.toIntOrNull() ?: return false }
        return Dns.isGlobalIpv4(n[0], n[1], n[2], n[3])
    }
}
