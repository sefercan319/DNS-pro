package app.dnshizli.core

import java.io.IOException
import java.security.SecureRandom

/** ODoH hata türleri: üst katman hangisine ne yapacağını bunlardan seçer (yeniden dene, anahtarı yenile, yolu kes). */
enum class OdohError {
    /** Yapılandırma dosyası bozuk ya da anlaşılamıyor. */
    BAD_CONFIG,
    /** Yapılandırmada desteklediğimiz takım (X25519 / HKDF-SHA256 / AES-128-GCM) yok. */
    NO_SUPPORTED_CONFIG,
    /** Hedef anahtarımızı tanımadı (HTTP 401): anahtar döndü, yapılandırma yenilenmeli. */
    KEY_REJECTED,
    /** Röle ya da hedef başka bir HTTP hatası verdi (400, 403, 5xx). */
    HTTP,
    /** Cevap bozuk: yapı, uzunluk ya da dolgu geçersiz. */
    BAD_RESPONSE,
    /** Cevabın kimlik doğrulaması tutmadı (bozulmuş ya da sahte cevap). */
    AUTH,
    /** Yapılandırma alınamadı. */
    CONFIG_FETCH,
}

class OdohException(val kind: OdohError, message: String, cause: Throwable? = null) : IOException(message, cause)

/** Sunucunun yayımladığı ObliviousDoHConfigContents. [contents] seri hâlidir ([keyId] bundan türer). */
class OdohConfig internal constructor(val contents: ByteArray, val publicKey: ByteArray) {
    /** key_id = Expand(Extract("", contents), "odoh key id", Nh) (RFC 9230 §6.1). */
    val keyId: ByteArray by lazy {
        Hkdf.expand(Hkdf.extract(null, contents), "odoh key id".toByteArray(Charsets.US_ASCII), Hkdf.NH)
    }
}

/**
 * ObliviousDoHConfigs ayrıştırıcısı (RFC 9230 §5). Yapısal bozukluk hata verir; desteklenmeyen sürüm ya da takım sessizce
 * atlanır (RFC: "istemci anlamadığı sürümleri yok sayar"). Üst sınırlar: toplam 64 KiB, en çok 16 yapılandırma.
 */
object OdohConfigs {
    const val MAX_BYTES = 65537
    const val MAX_CONFIGS = 16
    const val VERSION = 0x0001

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    /** Desteklenen yapılandırmalar, sunucunun tercih sırasıyla. Hiçbiri yoksa [OdohError.NO_SUPPORTED_CONFIG]. */
    fun parse(b: ByteArray, off: Int = 0, len: Int = b.size - off): List<OdohConfig> {
        if (off < 0 || len < 0 || off + len > b.size) throw OdohException(OdohError.BAD_CONFIG, "geçersiz aralık")
        if (len < 2 || len > MAX_BYTES) throw OdohException(OdohError.BAD_CONFIG, "yapılandırma uzunluğu geçersiz ($len)")
        val total = u16(b, off)
        if (total != len - 2) throw OdohException(OdohError.BAD_CONFIG, "yapılandırma uzunluk öneki uyuşmuyor")
        var p = off + 2
        val end = off + len
        val out = ArrayList<OdohConfig>(2)
        var seen = 0
        while (p < end) {
            if (end - p < 4) throw OdohException(OdohError.BAD_CONFIG, "kesik yapılandırma başlığı")
            val version = u16(b, p)
            val clen = u16(b, p + 2)
            p += 4
            if (clen > end - p) throw OdohException(OdohError.BAD_CONFIG, "yapılandırma gövdesi taşıyor")
            if (++seen > MAX_CONFIGS) throw OdohException(OdohError.BAD_CONFIG, "çok fazla yapılandırma")
            if (version == VERSION) parseContents(b, p, clen)?.let { out.add(it) }
            p += clen
        }
        if (out.isEmpty()) throw OdohException(OdohError.NO_SUPPORTED_CONFIG, "desteklenen yapılandırma yok")
        return out
    }

    private fun parseContents(b: ByteArray, off: Int, len: Int): OdohConfig? {
        if (len < 8) throw OdohException(OdohError.BAD_CONFIG, "kesik yapılandırma içeriği")
        val kem = u16(b, off); val kdf = u16(b, off + 2); val aead = u16(b, off + 4); val pkLen = u16(b, off + 6)
        if (pkLen != len - 8) throw OdohException(OdohError.BAD_CONFIG, "açık anahtar uzunluğu uyuşmuyor")
        if (kem != Hpke.KEM_ID || kdf != Hpke.KDF_ID || aead != Hpke.AEAD_ID || pkLen != Hpke.NPK) return null
        return OdohConfig(b.copyOfRange(off, off + len), b.copyOfRange(off + 8, off + len))
    }
}

/** Gönderilmiş bir sorgu: gövde ve cevabı açmak için gereken gizli bilgiler. Tek kullanımlıktır. */
class OdohQuery internal constructor(val wire: ByteArray, private val plain: ByteArray, private val secret: ByteArray) {
    /**
     * Cevabı çözer ve DNS mesajını döner. Cevap yapısı, uzunlukları, kimlik doğrulaması ve dolgu (hepsi sıfır olmalı) denetlenir;
     * bozuk her şey [OdohException] verir. Çağrıdan sonra gizli bilgiler silinir.
     */
    fun open(body: ByteArray, off: Int, len: Int): ByteArray {
        try {
            if (off < 0 || len < 0 || off + len > body.size) throw OdohException(OdohError.BAD_RESPONSE, "geçersiz aralık")
            val nl = Hpke.NK.coerceAtLeast(Hpke.NN)                       // max(Nn, Nk) = 16
            // tür(1) + nonce uzunluğu(2) + nonce + şifreli uzunluk(2) + şifreli (en az GCM etiketi)
            if (len < 1 + 2 + nl + 2 + Hpke.NT) throw OdohException(OdohError.BAD_RESPONSE, "cevap çok kısa")
            var p = off
            if ((body[p++].toInt() and 0xFF) != OdohClient.TYPE_RESPONSE) throw OdohException(OdohError.BAD_RESPONSE, "cevap türü yanlış")
            val n = ((body[p].toInt() and 0xFF) shl 8) or (body[p + 1].toInt() and 0xFF); p += 2
            if (n != nl) throw OdohException(OdohError.BAD_RESPONSE, "cevap nonce uzunluğu yanlış")
            val nonce = body.copyOfRange(p, p + nl); p += nl
            val cl = ((body[p].toInt() and 0xFF) shl 8) or (body[p + 1].toInt() and 0xFF); p += 2
            if (cl != off + len - p || cl < Hpke.NT) throw OdohException(OdohError.BAD_RESPONSE, "şifreli cevap uzunluğu yanlış")
            val ct = body.copyOfRange(p, p + cl)

            val salt = ByteArray(plain.size + 2 + nl)
            System.arraycopy(plain, 0, salt, 0, plain.size)
            salt[plain.size] = (nl ushr 8).toByte(); salt[plain.size + 1] = nl.toByte()
            System.arraycopy(nonce, 0, salt, plain.size + 2, nl)
            val prk = Hkdf.extract(salt, secret)
            val key = Hkdf.expand(prk, "odoh key".toByteArray(Charsets.US_ASCII), Hpke.NK)
            val gcmNonce = Hkdf.expand(prk, "odoh nonce".toByteArray(Charsets.US_ASCII), Hpke.NN)
            val aad = ByteArray(1 + 2 + nl)
            aad[0] = OdohClient.TYPE_RESPONSE.toByte(); aad[1] = (nl ushr 8).toByte(); aad[2] = nl.toByte()
            System.arraycopy(nonce, 0, aad, 3, nl)
            val pt = Hpke.aeadOpen(key, gcmNonce, aad, ct) ?: throw OdohException(OdohError.AUTH, "cevap doğrulanamadı")
            java.util.Arrays.fill(key, 0); java.util.Arrays.fill(prk, 0)
            return OdohClient.decodePlaintext(pt)
        } finally {
            java.util.Arrays.fill(secret, 0)
        }
    }
}

/**
 * ODoH istemci şifrelemesi (RFC 9230 §6, §8). Her sorgu için yeni bir HPKE bağlamı (taze geçici anahtar) kurulur: iki sorgu
 * şifreli metinlerinden ilişkilendirilemez. Dolgu: düz metin [DEFAULT_BLOCK] baytın katına tamamlanır.
 */
object OdohClient {
    const val TYPE_QUERY = 1
    const val TYPE_RESPONSE = 2
    const val MEDIA_TYPE = "application/oblivious-dns-message"
    const val DEFAULT_BLOCK = 128
    const val MAX_FIELD = 65535

    private val INFO_QUERY = "odoh query".toByteArray(Charsets.US_ASCII)
    private val LABEL_RESPONSE = "odoh response".toByteArray(Charsets.US_ASCII)

    fun seal(config: OdohConfig, dns: ByteArray, rng: SecureRandom, block: Int = DEFAULT_BLOCK): OdohQuery {
        if (dns.size < Packets.DNS_HDR || dns.size > MAX_FIELD - 4) throw OdohException(OdohError.BAD_RESPONSE, "DNS sorgusu boyutu geçersiz")
        val base = 2 + dns.size + 2
        val pad = if (block <= 1) 0 else (block - base % block) % block
        val plain = ByteArray(base + pad)
        plain[0] = (dns.size ushr 8).toByte(); plain[1] = dns.size.toByte()
        System.arraycopy(dns, 0, plain, 2, dns.size)
        plain[2 + dns.size] = (pad ushr 8).toByte(); plain[3 + dns.size] = pad.toByte()   // dolgu sıfırlarla zaten dolu

        val sender = Hpke.setupBaseS(config.publicKey, INFO_QUERY, rng)
            ?: throw OdohException(OdohError.BAD_CONFIG, "sunucu anahtarı geçersiz")
        val keyId = config.keyId
        val aad = ByteArray(1 + 2 + keyId.size)
        aad[0] = TYPE_QUERY.toByte(); aad[1] = (keyId.size ushr 8).toByte(); aad[2] = keyId.size.toByte()
        System.arraycopy(keyId, 0, aad, 3, keyId.size)
        val ct = sender.context.seal(aad, plain)
        val secret = sender.context.export(LABEL_RESPONSE, Hpke.NK)
        sender.context.wipe()

        val encLen = sender.enc.size + ct.size
        if (encLen > MAX_FIELD) throw OdohException(OdohError.BAD_RESPONSE, "sorgu çok büyük")
        val wire = ByteArray(1 + 2 + keyId.size + 2 + encLen)
        var p = 0
        wire[p++] = TYPE_QUERY.toByte()
        wire[p++] = (keyId.size ushr 8).toByte(); wire[p++] = keyId.size.toByte()
        System.arraycopy(keyId, 0, wire, p, keyId.size); p += keyId.size
        wire[p++] = (encLen ushr 8).toByte(); wire[p++] = encLen.toByte()
        System.arraycopy(sender.enc, 0, wire, p, sender.enc.size); p += sender.enc.size
        System.arraycopy(ct, 0, wire, p, ct.size)
        return OdohQuery(wire, plain, secret)
    }

    /** ObliviousDoHMessagePlaintext'i çözer: yapı tam tüketilmeli, dolgu sıfır olmalı (RFC 9230 §6.1, §7). */
    internal fun decodePlaintext(pt: ByteArray): ByteArray {
        if (pt.size < 4) throw OdohException(OdohError.BAD_RESPONSE, "düz metin çok kısa")
        val dl = ((pt[0].toInt() and 0xFF) shl 8) or (pt[1].toInt() and 0xFF)
        if (dl < Packets.DNS_HDR || 2 + dl + 2 > pt.size) throw OdohException(OdohError.BAD_RESPONSE, "DNS uzunluğu geçersiz")
        val pl = ((pt[2 + dl].toInt() and 0xFF) shl 8) or (pt[3 + dl].toInt() and 0xFF)
        if (4 + dl + pl != pt.size) throw OdohException(OdohError.BAD_RESPONSE, "dolgu uzunluğu uyuşmuyor")
        var acc = 0
        for (i in 4 + dl until pt.size) acc = acc or pt[i].toInt()
        if (acc != 0) throw OdohException(OdohError.BAD_RESPONSE, "dolgu sıfır değil")
        return pt.copyOfRange(2, 2 + dl)
    }

    /** Röle yolu: `<yol>?targethost=<ad>&targetpath=<yol>` (RFC 9230 §4.1); değerler yüzde-kodlanır. */
    fun relayPath(relayPath: String, targetHost: String, targetPath: String): String {
        val sep = if (relayPath.contains('?')) '&' else '?'
        return relayPath + sep + "targethost=" + pct(targetHost) + "&targetpath=" + pct(targetPath)
    }

    private fun pct(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (b in s.toByteArray(Charsets.UTF_8)) {
            val c = b.toInt() and 0xFF
            val safe = c in 'a'.code..'z'.code || c in 'A'.code..'Z'.code || c in '0'.code..'9'.code || c == '-'.code || c == '.'.code || c == '_'.code || c == '~'.code
            if (safe) sb.append(c.toChar()) else { sb.append('%'); sb.append("0123456789ABCDEF"[c ushr 4]); sb.append("0123456789ABCDEF"[c and 15]) }
        }
        return sb.toString()
    }
}
