package app.dnshizli.core

import kotlin.math.abs

/**
 * Mobil ağ altyapısı için ortak, saf (Android'siz) yapı taşları.
 *
 * Mobil ağlar Wi-Fi'den farklıdır: gecikme dalgalıdır, telsiz boştan etkine geçerken ilk pakete 100 ms (4G) ile birkaç saniye (3G)
 * eklenir, paket kaybı yüzde birkaç olabilir ve çekirdeğin sabit zamanlayıcıları (SYN yeniden gönderimi 1 sn, bizim eski sabit
 * DNS yeniden deneme süremiz 1,2 sn) bu kayıpların maliyetini büyütür. Çözüm: sabit süreler yerine ölçülen gecikmeden türetilen süreler
 * ([RttEstimator]) ve "kayıp varsa ikinci deneme erken başlasın" ilkesi (RFC 8305'teki gibi kademeli denemeler).
 *
 * Kaynaklar: RFC 6298 (RTO hesabı), RFC 8305 (Happy Eyeballs v2: deneme gecikmesi 250 ms, alt sınır 100 ms, üst sınır 2 sn),
 * High Performance Browser Networking (telsiz durum geçişleri: 4G ≈ 100 ms, 3G 0,5–2,5 sn; operatör NAT süresi 5–30 dk).
 */
class RttEstimator {
    private var srtt = 0.0
    private var rttvar = 0.0
    private var n = 0

    @Synchronized fun sample(ms: Double) {
        val x = ms.coerceIn(0.5, 30_000.0)
        if (n == 0) { srtt = x; rttvar = x / 2 } else {
            rttvar = 0.75 * rttvar + 0.25 * abs(srtt - x)
            srtt = 0.875 * srtt + 0.125 * x
        }
        n++
    }

    @Synchronized fun count(): Int = n
    @Synchronized fun srtt(): Double = srtt
    @Synchronized fun rttvar(): Double = rttvar
    @Synchronized fun reset() { srtt = 0.0; rttvar = 0.0; n = 0 }

    /** srtt + [k]·rttvar + [extraMs], [minMs]..[maxMs] arası; hiç örnek yoksa [unknownMs]. */
    @Synchronized fun timeout(k: Double, extraMs: Double, minMs: Long, maxMs: Long, unknownMs: Long): Long {
        if (n == 0) return unknownMs
        return (srtt + k * rttvar + extraMs).toLong().coerceIn(minMs, maxMs)
    }
}

/** Sabit kurallı süre ilkeleri (eski değerlerle birlikte, ölçüm ve testler için). */
object MobilePolicy {
    /** Eski sabit değerler (v1.14 ve öncesi). */
    const val OLD_DNS_RETRY_MS = 1200L
    const val OLD_DNS_SWEEP_MS = 400L
    const val OLD_FIRST_FAMILY_MS = 1500L
    const val OLD_SYN_RETRY_MS = 1000L          // Linux çekirdeği: ilk SYN yeniden gönderimi

    /** UDP DNS ilk yeniden deneme gecikmesi. */
    fun dnsRetryMs(est: RttEstimator): Long = est.timeout(4.0, 20.0, 150L, 1200L, 400L)

    /** TCP bağlantısında ikinci (yedek) denemenin başlama gecikmesi. */
    fun connectHedgeMs(est: RttEstimator, slow: Boolean): Long =
        est.timeout(2.0, 40.0, if (slow) 150L else 100L, if (slow) 1200L else 1000L, 300L)

    /** Şifreli DNS: iki IP ailesi varken ilk aileye tanınan TCP bağlantı süresi. */
    fun firstFamilyMs(est: RttEstimator): Long = est.timeout(4.0, 100.0, 300L, OLD_FIRST_FAMILY_MS, 600L)
}
