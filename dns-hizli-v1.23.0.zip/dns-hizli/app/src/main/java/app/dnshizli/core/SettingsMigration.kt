package app.dnshizli.core

/**
 * Kayıtlı ayarları bugünkü biçime taşır. Her sürüm geçişi (n → n+1) bir adımdır ve tabloda yer alır.
 *
 * Yeni bir alan değiştirildiğinde: [SettingsCodec.VERSION] artırılır ve [steps] tablosuna o geçişi yapan bir adım eklenir.
 * Eski değerler silinmez ya da ezilmez; adım yalnızca yeni biçimi üretir. Bilinmeyen (daha yeni) sürüm değerleri olduğu gibi kalır.
 */
object SettingsMigration {

    /** Sürüm n'den n+1'e geçiş adımları. Anahtar: n. */
    private val steps: Map<Int, (MutableMap<String, String?>) -> Unit> = mapOf(
        // Sürüm 1: sıralama tek bir açık/kapalı değerdi ("sortBySpeed"); sürüm 2 ile "sortMode" oldu.
        1 to { m ->
            if (m["sortMode"] == null && m["sortBySpeed"] == "true") m["sortMode"] = SortMode.SPEED.id
        },
    )

    /** Kayıtlı sürüm yoksa ya da bozuksa sürüm 1 kabul edilir (en eski biçim). */
    fun storedVersion(m: Map<String, String?>): Int = m["v"]?.toIntOrNull()?.takeIf { it >= 1 } ?: 1

    /**
     * [m]'i (yerinde) güncel biçime taşır ve taşınmış haliyle döndürür. Sürüm daha yeniyse hiçbir şeye dokunmaz.
     * @return taşınmadan önceki sürüm.
     */
    fun migrate(m: MutableMap<String, String?>): MutableMap<String, String?> {
        val from = storedVersion(m)
        if (from >= SettingsCodec.VERSION) return m
        for (v in from until SettingsCodec.VERSION) steps[v]?.invoke(m)
        m["v"] = SettingsCodec.VERSION.toString()
        return m
    }
}
