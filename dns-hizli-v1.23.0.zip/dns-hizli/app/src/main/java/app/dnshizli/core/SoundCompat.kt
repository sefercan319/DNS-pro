package app.dnshizli.core

/**
 * Ses çalma yolları, en çok tercih edilenden en uyumluya. Aynı efekt, cihaz/ROM'a göre farklı bir yolla çalabilir:
 *  - [STATIC_RELOAD]: tek bellek tamponu, durdur + yeniden yükle + çal (en hızlı, gecikmesi en az).
 *  - [STREAM_SONIFICATION]: her çalmada akış; tampon/başlatma farklarına karşı daha toleranslı.
 *  - [STREAM_MEDIA]: medya kullanım türü; bazı ROM'lar "dokunma sesi" kullanımını tamamen kısıyor.
 *  - [TONE]: sistemin kendi bip sesi (sentezlenmiş ses çalınamazsa son çare; sesin tınısı değişir ama duyulur).
 */
enum class SoundPath { STATIC_RELOAD, STREAM_SONIFICATION, STREAM_MEDIA, TONE }

/** Android tarafının çalma işlemi. [play] true dönerse çalma başlatıldı demektir; hata fırlatabilir (sarmalanır). */
interface SoundBackend {
    fun play(path: SoundPath, e: Sfx, volume: Float): Boolean
}

/**
 * Hangi yolun çalıştığını hatırlayan ve başarısız olunca sıradakine geçen seçici. Saf mantık: Android'den bağımsızdır.
 * - Son çalışan yol önce denenir; o da olmazsa sırayla diğerleri. Sıra bittiyse sessizce vazgeçilir (uygulama asla çökmez).
 * - Çalışan yol değişince [remember] çağrılır (kalıcı kayıt için) ve günlüğe yazılır (tanılama raporunda görünür).
 * - Her hata tek satırla günlüğe yazılır: yalnızca yol adı ve istisna türü; hiçbir kişisel veri yok.
 */
class SoundCompat(
    private val backend: SoundBackend,
    initial: SoundPath?,
    private val remember: (SoundPath) -> Unit,
    private val log: (String) -> Unit,
) {
    @Volatile var best: SoundPath? = initial
        private set
    /** Üst üste başarısız çalma sayısı (tanılama için). */
    @Volatile var failures = 0
        private set

    /** Efekti çalar. Çalan yolu döner; hiçbiri çalamazsa null. */
    fun play(e: Sfx, volume: Float): SoundPath? {
        val all = SoundPath.values()
        val first = best ?: SoundPath.STATIC_RELOAD
        val start = all.indexOf(first)
        for (k in all.indices) {
            val p = all[(start + k) % all.size]
            val ok = try {
                backend.play(p, e, volume)
            } catch (ex: Throwable) {
                log("ses yolu ${p.name} hata: ${ex.javaClass.simpleName}")
                false
            }
            if (ok) {
                failures = 0
                if (best != p) {
                    best = p
                    try { remember(p) } catch (_: Throwable) {}
                    log("ses yolu: ${p.name}")
                }
                return p
            }
        }
        failures++
        if (failures == 1 || failures % 50 == 0) log("hiçbir ses yolu çalamadı (üst üste $failures)")
        return null
    }
}
