package app.dnshizli.platform

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.ToneGenerator
import android.os.Handler
import android.os.HandlerThread
import app.dnshizli.core.Journal
import app.dnshizli.core.Sfx
import app.dnshizli.core.SoundBackend
import app.dnshizli.core.SoundCompat
import app.dnshizli.core.SoundPath
import app.dnshizli.core.Synth
import app.dnshizli.core.Voice
import java.util.concurrent.atomic.AtomicInteger

/**
 * Sentezlenmiş ses efektlerini çalar. Dosya yoktur: [Synth] sesleri üretir. Cihazlar (ve ROM'lar) ses API'sini farklı uygular:
 * bazılarında statik tampon yeniden yüklemesi istisna atar, bazılarında "dokunma sesi" kullanımı kısılıdır. Bu yüzden çalma
 * [SoundCompat] üzerinden dört yoldan biriyle yapılır; çalışan yol kalıcı olarak hatırlanır ve bozulursa sıradakine geçilir.
 *
 * Tüm ses işi ayrı bir iş parçacığında yapılır: ana iş parçacığında sayfa geçişini takıyordu. Bekleyen çalma sayısı sınırlıdır.
 */
class SoundFx(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("dnshizli_sound", Context.MODE_PRIVATE)
    private val worker = HandlerThread("dns-sound").also { it.isDaemon = true; it.start() }
    private val handler = Handler(worker.looper)
    private val pending = AtomicInteger()
    private val am = context.applicationContext.getSystemService(AudioManager::class.java)
    @Volatile private var diagSent = false

    // yalnızca [worker] iş parçacığı kullanır
    private val pcmCache = HashMap<Sfx, ShortArray>()
    private val statics = HashMap<Sfx, AudioTrack>()
    private val streams = ArrayList<AudioTrack>()
    private var voice: Voice = Voice.values()[0]
    private var voiceSet = false
    private var tone: ToneGenerator? = null
    private var toneVol = -1

    private val compat = SoundCompat(
        backend = Backend(),
        initial = readSaved(),
        remember = { p -> try { prefs.edit().putString(KEY, p.name).apply() } catch (_: Exception) {} },
        log = { Journal.add(it) },
    )

    private fun readSaved(): SoundPath? = try {
        prefs.getString(KEY, null)?.let { s -> SoundPath.values().firstOrNull { it.name == s } }
    } catch (_: Exception) { null }

    /** Ana iş parçacığından çağrılır; hemen döner. */
    fun play(e: Sfx, v: Voice, volume: Float) {
        if (pending.incrementAndGet() > MAX_PENDING) { pending.decrementAndGet(); return }   // artır-sonra-denetle: yarışsız sınır
        val queued = handler.post {
            try { playNow(e, v, volume) } finally { pending.decrementAndGet() }
        }
        if (!queued) pending.decrementAndGet()
    }

    private fun playNow(e: Sfx, v: Voice, volume: Float) {
        try {
            if (!voiceSet || voice != v) { releaseNow(); voice = v; voiceSet = true }
            compat.play(e, volume.coerceIn(0f, 1f))
        } catch (ex: Throwable) {
            Journal.add("ses: beklenmeyen hata ${ex.javaClass.simpleName}")
        }
    }

    /** Çalma sırasındaki işlerden sonra çalışır (sıra korunur); ana iş parçacığını bekletmez. */
    fun release() { handler.post { releaseNow() } }

    /** Etkinlik yok olurken: bekleyen işler bitince sesleri bırakır ve iş parçacığını kapatır. */
    fun shutdown() { handler.post { releaseNow(); try { tone?.release() } catch (_: Exception) {}; worker.quitSafely() } }

    private fun releaseNow() {
        for (t in statics.values) safe { t.release() }
        statics.clear()
        for (t in streams) safe { t.release() }
        streams.clear()
        pcmCache.clear()
    }

    private fun pcm(e: Sfx): ShortArray = pcmCache.getOrPut(e) { Synth.render(e, voice).also { peakLog(e, it) } }

    /** Sentezlenen sesin tepe genliği: sessizse (hepsi sıfır) sorun sentezde demektir. Her efekt için bir kez yazılır. */
    private val peaked = HashSet<Sfx>()
    private fun peakLog(e: Sfx, d: ShortArray) {
        if (!peaked.add(e)) return
        var peak = 0
        for (x in d) { val a = kotlin.math.abs(x.toInt()); if (a > peak) peak = a }
        Journal.add("ses tanı: ${e.name} örnek=${d.size} tepe=$peak")
    }

    /** Sistem ses durumu: sistem/medya seviyesi, sessize alma, zil modu. Her oturumda bir kez, ilk başarılı çalmada yazılır. */
    private fun diagOnce(t: AudioTrack?) {
        if (diagSent) return
        diagSent = true
        try {
            val m = am ?: run { Journal.add("ses tanı: AudioManager yok"); return }
            val sys = m.getStreamVolume(AudioManager.STREAM_SYSTEM)
            val sysMax = m.getStreamMaxVolume(AudioManager.STREAM_SYSTEM)
            val med = m.getStreamVolume(AudioManager.STREAM_MUSIC)
            val medMax = m.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val sysMute = try { m.isStreamMute(AudioManager.STREAM_SYSTEM) } catch (_: Exception) { false }
            val musicMute = try { m.isStreamMute(AudioManager.STREAM_MUSIC) } catch (_: Exception) { false }
            val dev = try { t?.routedDevice?.type ?: -1 } catch (_: Exception) { -2 }
            Journal.add("ses tanı: sistem=$sys/$sysMax sessiz=$sysMute, medya=$med/$medMax sessiz=$musicMute, zil=${m.ringerMode}, çıkış=$dev")
        } catch (ex: Exception) {
            Journal.add("ses tanı hatası: ${ex.javaClass.simpleName}")
        }
    }

    private fun audio(usage: Int, content: Int) = AudioAttributes.Builder().setUsage(usage).setContentType(content).build()

    private fun format() = AudioFormat.Builder()
        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
        .setSampleRate(Synth.RATE)
        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
        .build()

    private inner class Backend : SoundBackend {
        override fun play(path: SoundPath, e: Sfx, volume: Float): Boolean = when (path) {
            SoundPath.STATIC_RELOAD -> playStatic(e, volume)
            SoundPath.STREAM_SONIFICATION -> playStream(e, volume, AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            SoundPath.STREAM_MEDIA -> playStream(e, volume, AudioAttributes.USAGE_MEDIA)
            SoundPath.TONE -> playTone(volume)
        }

        /**
         * Statik tampon. Başa sarmak için yalnızca durdurup yeniden yüklemek kullanılır (setPlaybackHeadPosition bazı cihazlarda
         * istisna atar; eski sürümde bu istisna play() çağrısını atlatıp sessizliğe yol açıyordu). Her adım ayrı kontrol edilir.
         */
        private fun playStatic(e: Sfx, volume: Float): Boolean {
            val t: AudioTrack = statics[e]?.takeIf { it.state == AudioTrack.STATE_INITIALIZED } ?: buildStatic(e) ?: return false
            if (t.playState == AudioTrack.PLAYSTATE_PLAYING) safe { t.stop() }
            val rl = t.reloadStaticData()
            if (rl != AudioTrack.SUCCESS) { Journal.add("statik: yeniden yükleme $rl"); dropStatic(e); return false }
            t.setVolume(volume)
            t.play()
            val ok = t.playState == AudioTrack.PLAYSTATE_PLAYING
            if (!ok) Journal.add("statik: play sonrası durum ${t.playState}")
            else diagOnce(t)
            return ok
        }

        private fun buildStatic(e: Sfx): AudioTrack? {
            val data = pcm(e)
            val t = try {
                AudioTrack.Builder()
                    .setAudioAttributes(audio(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION, AudioAttributes.CONTENT_TYPE_SONIFICATION))
                    .setAudioFormat(format())
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
            } catch (_: Exception) { return null }
            if (t.state != AudioTrack.STATE_INITIALIZED || t.write(data, 0, data.size) != data.size) { safe { t.release() }; return null }
            statics[e] = t
            return t
        }

        private fun dropStatic(e: Sfx) {
            statics.remove(e)?.let { t -> safe { t.release() } }
        }

        /** Her çalmada yeni akış: en uyumlu yol. Kullanılan bellek, çalma bitince serbest bırakılır. */
        private fun playStream(e: Sfx, volume: Float, usage: Int): Boolean {
            val data = pcm(e)
            val t = AudioTrack.Builder()
                .setAudioAttributes(audio(usage, AudioAttributes.CONTENT_TYPE_SONIFICATION))
                .setAudioFormat(format())
                .setBufferSizeInBytes(maxOf(data.size * 2, minBuffer()))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            if (t.state != AudioTrack.STATE_INITIALIZED) { safe { t.release() }; return false }
            streams.add(t)
            t.setVolume(volume)
            t.play()
            if (t.playState != AudioTrack.PLAYSTATE_PLAYING) { Journal.add("akış: play sonrası durum ${t.playState}"); finishStream(t); return false }
            val n = t.write(data, 0, data.size)
            if (n <= 0) { Journal.add("akış: yazma $n"); finishStream(t); return false }
            diagOnce(t)
            val ms = data.size * 1000L / Synth.RATE + 150L
            handler.postDelayed({ finishStream(t) }, ms)
            return true
        }

        private fun finishStream(t: AudioTrack) {
            streams.remove(t)
            safe { t.stop() }
            safe { t.release() }
        }

        /** Son çare: sistemin bip sesi. Sentezlenmiş tını yok, ama yanıt verildiği duyulur. */
        private fun playTone(volume: Float): Boolean {
            val vol = (volume * 100).toInt().coerceIn(1, 100)
            var g = tone
            if (g == null || toneVol != vol) {             // ses seviyesi yalnızca oluştururken verilir: değişince yeniden kurulur
                safe { g?.release() }
                g = ToneGenerator(AudioManager.STREAM_MUSIC, vol)
                tone = g; toneVol = vol
            }
            return g.startTone(ToneGenerator.TONE_PROP_BEEP, 90)
        }
    }

    private fun minBuffer(): Int = try {
        AudioTrack.getMinBufferSize(Synth.RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(0)
    } catch (_: Exception) { 0 }

    private inline fun safe(block: () -> Unit) { try { block() } catch (_: Exception) {} }

    private companion object {
        const val MAX_PENDING = 4
        const val KEY = "path"
    }
}
