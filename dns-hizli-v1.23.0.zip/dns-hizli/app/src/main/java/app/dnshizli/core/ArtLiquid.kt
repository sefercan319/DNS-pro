package app.dnshizli.core

import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Liquid Glass: bulanık mavi-mor ışık lekeleri üzerinde kalın, yarı saydam cam. Kartların ve düğmelerin üst-sol kenarında
 * parlak beyaz ışık çizgisi, alt-sağında ince ters yansıma vardır; cam arkasındaki ışığı hafifçe renklendirir.
 * Hareket: akışkan, yaylı; zemin lekeleri yavaşça kayar (yalnızca hareket açıkken). Renk teması hafifçe karışır.
 */
class LiquidArt(theme: AeroTheme, glass: Float) : AeroArt(theme, glass) {
    override val style: UiStyle get() = UiStyle.LIQUID
    override val particleMode: ParticleMode get() = ParticleMode.NONE
    override val liveSky: Boolean get() = true
    override val motion: StyleMotion = StyleMotion(PageMotion.FADE_SCALE, 0.42f, 0.04f, 0.55f, depth = 0.8f, tilt = 3f, up = SpringSpec.SOFT, toggle = SpringSpec.SOFT, fx = FxKind.GLASS)

    private val blue = 0xFF3D8BFF.toInt()
    private val indigo = 0xFF6A5CFF.toInt()
    private val ice = 0xFFA9DCFF.toInt()

    private class Scene(val w: Float, val h: Float, art: LiquidArt) {
        private val dk = art.dark
        private val th = art.theme
        val base = if (dk)
            Fill.linear(0f, 0f, 0f, h, Rgb.lerp(0xFF050B24.toInt(), th.skyTop, 0.12f), Rgb.lerp(0xFF0B1646.toInt(), th.skyMid, 0.12f), Rgb.lerp(0xFF1B1560.toInt(), th.skyBottom, 0.10f), 0.55f)
        else
            Fill.linear(0f, 0f, 0f, h, Rgb.lerp(0xFFBFD9FF.toInt(), th.skyTop, 0.18f), Rgb.lerp(0xFF8FB4FF.toInt(), th.skyMid, 0.18f), Rgb.lerp(0xFFB9A8FF.toInt(), th.skyBottom, 0.16f), 0.6f)
        val blobA = Fill.radial(w * 0.22f, h * 0.20f, w * 0.75f, Rgb.alpha(art.blue, if (dk) 0.55f else 0.70f), Rgb.alpha(art.blue, 0f))
        val blobB = Fill.radial(w * 0.85f, h * 0.55f, w * 0.80f, Rgb.alpha(art.indigo, if (dk) 0.55f else 0.60f), Rgb.alpha(art.indigo, 0f))
        val blobC = Fill.radial(w * 0.30f, h * 0.92f, w * 0.85f, Rgb.alpha(art.ice, if (dk) 0.30f else 0.75f), Rgb.alpha(art.ice, 0f))
        val sheen = Fill.linear(0f, 0f, w, h * 0.5f, Rgb.alpha(Rgb.WHITE, if (dk) 0.10f else 0.35f), Rgb.alpha(Rgb.WHITE, 0f), Rgb.alpha(Rgb.WHITE, 0f), 0.6f)
    }

    private var scene: Scene? = null

    private fun scene(w: Float, h: Float): Scene {
        var s = scene
        if (s == null || s.w != w || s.h != h) { s = Scene(w, h, this); scene = s }
        return s
    }

    override fun sky(g: Gfx, w: Float, h: Float) = skyFrame(g, w, h, false, 0f)

    override fun skyFrame(g: Gfx, w: Float, h: Float, live: Boolean, time: Float) {
        val s = scene(w, h)
        val t = if (live) time else 0f
        g.paint(s.base); g.rect(0f, 0f, w, h)
        g.save(); g.translate(sin(t * 0.21f) * w * 0.05f, cos(t * 0.17f) * h * 0.02f)
        g.paint(s.blobA); g.rect(-w * 0.1f, -h * 0.1f, w * 1.1f, h * 1.1f)
        g.restore()
        g.save(); g.translate(cos(t * 0.19f) * w * 0.05f, sin(t * 0.23f) * h * 0.02f)
        g.paint(s.blobB); g.rect(-w * 0.1f, -h * 0.1f, w * 1.1f, h * 1.1f)
        g.restore()
        g.paint(s.blobC); g.rect(0f, 0f, w, h)
        g.paint(s.sheen); g.rect(0f, 0f, w, h)
    }

    override fun bubble(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float) {}
    override fun particle(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float, phase: Float) {}

    // ------------------------------------------------------------------ Liquid Glass: kalın saydam cam

    /** Cam kart: saydam gövde, üst-sol parlak kenar, alt-sağ ince yansıma, seçiliyken renkli ışıma. */
    override fun card(g: Gfx, l: Float, t: Float, r: Float, b: Float, rad: Float, selected: Float, press: Float, strong: Float, shadow: Float) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        val rr = min(rad + 4f, min(w, h) / 2f)
        g.save(); g.translate(l, t)
        if (shadow > 0f) { g.paint(Rgb.alpha(if (dark) 0xFF000018.toInt() else 0xFF2A3F8F.toInt(), (if (dark) 0.35f else 0.14f) * shadow)); g.roundRect(0f, 4f, w, h + 4f, rr) }
        if (selected > 0f) { g.paint(Rgb.alpha(theme.accentLight, 0.30f * selected)); g.roundRect(-3f, -3f, w + 3f, h + 3f, rr + 3f) }
        g.paint(Rgb.alpha(if (dark) 0xFF8FB4FF.toInt() else Rgb.WHITE, (0.14f + 0.40f * strong + 0.10f * press).coerceIn(0f, 1f))); g.roundRect(0f, 0f, w, h, rr)
        g.paint(Rgb.alpha(theme.accent, 0.10f + 0.14f * selected + 0.10f * press)); g.roundRect(0f, 0f, w, h, rr)
        g.strokeWidth(1.2f); g.paint(Rgb.alpha(Rgb.WHITE, if (dark) 0.30f else 0.70f)); g.strokeRoundRect(0.6f, 0.6f, w - 0.6f, h - 0.6f, max(0f, rr - 0.6f))
        // parlak kenar: üstte uzun beyaz çizgi, solda kısa
        g.paint(Rgb.alpha(Rgb.WHITE, 0.85f)); g.roundRect(rr, 1.2f, w - rr * 0.8f, 2.6f, 1.3f)
        g.paint(Rgb.alpha(Rgb.WHITE, 0.45f)); g.roundRect(1.2f, rr, 2.4f, h - rr, 1.2f)
        g.paint(Rgb.alpha(theme.accentLight, 0.45f)); g.roundRect(rr, h - 3.2f, w - rr, h - 1.6f, 0.8f)
        g.restore()
    }

    /** Cam anahtar: saydam yuva, açıkken mavi ışıma; tutamaç kalın cam damla (beyaz parıltılı). */
    override fun switch(g: Gfx, l: Float, t: Float, w: Float, h: Float, on: Float, press: Float) {
        val k = on.coerceIn(0f, 1f)
        g.save(); g.translate(l, t)
        if (k > 0.01f) { g.paint(Rgb.alpha(theme.accentLight, 0.40f * k)); g.roundRect(-3f, -3f, w + 3f, h + 3f, h / 2f + 3f) }
        g.paint(Rgb.lerp(if (dark) 0xFF26345F.toInt() else 0xFFC9D8F5.toInt(), theme.accent, k)); g.roundRect(0f, 0f, w, h, h / 2f)
        g.strokeWidth(1.2f); g.paint(Rgb.alpha(Rgb.WHITE, 0.65f)); g.strokeRoundRect(0.6f, 0.6f, w - 0.6f, h - 0.6f, h / 2f - 0.6f)
        val cx = h / 2f + (w - h) * k
        val rad = h / 2f - 1.5f + press * 1.5f
        g.paint(Rgb.alpha(Rgb.WHITE, 0.50f)); g.circle(cx, h / 2f, rad + 1.2f)
        g.paint(Rgb.alpha(Rgb.WHITE, 0.92f)); g.circle(cx, h / 2f, rad - 1f)
        g.paint(Rgb.alpha(theme.accentLight, 0.45f)); g.circle(cx + rad * 0.15f, h / 2f + rad * 0.25f, rad * 0.5f)
        g.paint(Rgb.WHITE); g.circle(cx - rad * 0.35f, h / 2f - rad * 0.4f, rad * 0.22f)
        g.restore()
    }
}
