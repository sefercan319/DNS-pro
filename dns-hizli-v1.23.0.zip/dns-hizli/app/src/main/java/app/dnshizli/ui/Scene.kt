package app.dnshizli.ui

import app.dnshizli.core.AeroArt
import app.dnshizli.core.AeroTheme
import app.dnshizli.core.ArtFactory
import app.dnshizli.core.BubbleField
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Easing
import app.dnshizli.core.FxKind
import app.dnshizli.core.FxSlot
import app.dnshizli.core.PackFx
import app.dnshizli.core.Sfx
import app.dnshizli.core.StyleFx
import app.dnshizli.core.Gfx
import app.dnshizli.core.PageMotion
import app.dnshizli.core.ParticleMode
import app.dnshizli.core.WpBlur
import app.dnshizli.core.WallpaperMath
import app.dnshizli.core.Pic
import app.dnshizli.core.Rgb
import app.dnshizli.core.TextMetrics
import app.dnshizli.core.Themes
import kotlin.math.abs
import kotlin.math.sin

/** Gökyüzü zemini ve yükselen kabarcıklar. */
class SkyNode : Node() {
    private val field = BubbleField(11L)
    private var count = -1

    private var mode = ParticleMode.RISE
    private var want = 0

    private fun apply() {
        val n = if (mode == ParticleMode.NONE) 0 else if (mode == ParticleMode.TWINKLE) want * 2 else want
        if (n != count) { count = n; field.setCount(n) }
    }

    fun setCount(n: Int) { want = n; apply() }

    /** Stil değişince parçacık davranışı da değişir. */
    fun setMode(m: ParticleMode) {
        if (m == mode) return
        mode = m
        field.setMode(if (m == ParticleMode.NONE) ParticleMode.RISE else m)
        apply()
    }

    fun update(dt: Float) { field.update(dt, 1f) }

    // ------------------------------------------------------------------ arka plan fotoğrafı

    private var pic: Pic? = null
    private val fade = Anim(1f)
    private var srcKey = 0L
    private var srcL = 0f
    private var srcT = 0f
    private var srcR = 0f
    private var srcB = 0f

    /** Fotoğraf gösteriliyor mu (gökyüzü sahnesi altta kalır; ayrıca süs kareleri gerekmez). */
    val hasPic: Boolean get() { val p = pic; return p != null && !p.isReleased }

    /** Perdenin çözümlenmesi için fotoğrafın parlaklık dilimleri; fotoğraf yoksa null. */
    val picLuma: FloatArray? get() = pic?.let { floatArrayOf(it.lumaLo, it.lumaHi) }

    /** Yeni fotoğraf (ya da null). Eski fotoğrafın belleği geri verilir; yenisi yumuşakça belirir. */
    fun setPic(p: Pic?, fadeSec: Float) {
        val old = pic
        pic = p
        srcKey = 0L
        if (old != null && old !== p) old.release()
        if (p != null && fadeSec > 0f) { fade.set(0f); fade.go(1f, fadeSec, Ease.OUT) } else fade.set(1f)
    }

    /** @return fotoğraf belirme animasyonu sürüyorsa true. */
    fun tick(dt: Float): Boolean = fade.step(dt)

    override fun draw(g: Gfx, env: Env) {
        val art = env.art
        art.clock = env.time
        val p = pic
        if (p == null || p.isReleased || fade.value < 1f) art.skyFrame(g, env.width, env.height, env.ambient, env.time)
        if (p != null && !p.isReleased) drawPic(g, env, p)
        val items = field.items
        for (i in 0 until items.size) { val b = items[i]; art.particle(g, b.x * env.width + sin(b.phase) * b.sway, b.y * env.height, b.r, b.alpha * 0.9f, b.phase) }
    }

    private fun drawPic(g: Gfx, env: Env, p: Pic) {
        val w = env.width
        val h = env.height
        val key = (w.toInt().toLong() shl 40) xor (h.toInt().toLong() shl 20) xor (p.w.toLong() shl 8) xor p.h.toLong()
        if (key != srcKey) {
            val r = WallpaperMath.cover(p.w, p.h, w, h)
            srcL = r[0]; srcT = r[1]; srcR = r[2]; srcB = r[3]; srcKey = key
        }
        val s = env.model.settings
        val a = WallpaperMath.veil(env.theme.dark, p.lumaLo, p.lumaHi, s.wpDim, s.highContrast)
        g.save()
        g.alpha(fade.value)
        g.image(p, srcL, srcT, srcR, srcB, 0f, 0f, w, h)
        g.paint(Rgb.alpha(WallpaperMath.veilColor(env.theme), a))
        g.rect(0f, 0f, w, h)
        g.restore()
    }
}

/**
 * Tüm arayüzün kökü: sayfa yığını, alt panel, bildirim, gökyüzü, tema geçişi, dokunma ve kaydırma yönlendirmesi.
 * Android'e bağlı değildir. Ev sahibi (SceneView) yalnızca şunları yapar: [resize], [tick] + [draw], [touch], [back]
 * ve erişilebilirlik için [a11yItems]. Böylece aynı kod JVM testlerinde ve önizleme görsellerinde çalışır.
 */
class Scene(val model: AppModel, metrics: TextMetrics) : Nav {
    val env = Env(model, metrics)

    private val sky = SkyNode()
    private val pages = ArrayList<Node>()
    private var sheet: Sheet? = null
    private var sheetIsConsent = false
    private val toast = ToastNode()
    private var seenToast = 0

    // sayfa geçişi
    private val trans = Anim(1f)
    private var leaving: Node? = null
    private var entering: Node? = null
    private var popping = false

    // tema geçişi
    private var themeFrom: AeroTheme = Themes.aqua
    private var themeTo: AeroTheme = Themes.aqua
    private val morph = Anim(1f)
    private var systemDark = false
    private var systemMotion = true

    private var lastNow = -1L
    private var started = false

    // dil, yazı boyutu, yüksek kontrast, saatli gece, "neler yeni"
    private var seenLang = model.langSeq
    private var seenWhatsNew = model.whatsNewSeq
    private var systemFs = 1f
    private var hcFor: AeroTheme? = null
    private var hcTheme: AeroTheme? = null
    private var nightMinute = -1L
    private var nightNow = false
    private var nightHours: app.dnshizli.core.NightHours? = null

    var width = 0f
        private set
    var height = 0f
        private set

    init {
        pages.add(HomePage(model, this))
        syncSettings(true)
        env.theme = effective(themeTo)
        env.art = ArtFactory.create(model.settings.style, env.theme, if (model.settings.highContrast) 1f else model.settings.glass)
        sky.setMode(env.art.particleMode)
        (pages.last() as ScrollPage).startReveal(env)
    }

    /** Dil değişince: yığındaki sayfaları aynı sırayla yeniden kurar (metinler yapım anında okunur). */
    private fun rebuildPages() {
        val old = ArrayList(pages)
        pages.clear()
        for (p in old) {
            pages.add(when (p) {
                is MenuPage -> MenuPage(this)
                is PersonalizePage -> PersonalizePage(model, this)
                is AboutPage -> AboutPage(model, this)
                is SectionPage -> SectionPage(model, this, p.section)
                is LogPage -> LogPage(model, this)
                is HelpPage -> HelpPage(this)
                is SessionsPage -> SessionsPage(model, this)
                is WhatsNewPage -> WhatsNewPage(this)
                is AppsPage -> AppsPage(model, this)
                else -> HomePage(model, this)
            })
        }
        leaving = null; entering = null; popping = false
        trans.set(1f)
        sheet = null; sheetIsConsent = false
        if (width > 0f) layoutAll()
    }

    // ------------------------------------------------------------------ yapılandırma

    fun setSystemDark(v: Boolean) { systemDark = v; syncSettings(false) }

    /** Sistem animasyon ölçeği 0 ise (erişilebilirlik) false verin. */
    fun setSystemMotion(v: Boolean) { systemMotion = v; syncSettings(false) }

    /** Sistemin yazı ölçeği. Uygulama içi "Yazı boyutu" ile çarpılır; sonuç 0,9..1,3 aralığında kalır. */
    fun setFontScale(f: Float) {
        systemFs = f
        applyFontScale()
    }

    private fun applyFontScale() {
        val v = (systemFs * model.settings.textScale.factor).coerceIn(MIN_FS, MAX_FS)
        if (v == env.fs) return
        env.fs = v
        if (width > 0f) layoutAll()
    }

    fun resize(w: Float, h: Float, insetTop: Float, insetBottom: Float) {
        width = w; height = h
        env.width = w; env.height = h
        env.insetTop = insetTop; env.insetBottom = insetBottom
        layoutAll()
    }

    private fun layoutAll() {
        for (p in pages) { p.x = 0f; p.y = 0f; p.layout(env, width); p.h = height }
        sheet?.layoutSheet(env)
        toast.screenW = width; toast.screenH = height
        toast.relayout(env)
    }

    private fun syncSettings(initial: Boolean) {
        val s = model.settings
        val sysOk = systemMotion
        val eff = s.effectiveMotion
        env.motion = if (sysOk) eff.scale else 0f
        env.speed = s.animSpeed
        env.ambient = sysOk && eff.scale > 0f
        sky.setCount(s.effectiveBubbles.count)
        applyFontScale()
        val dark = if (s.themeSchedule && s.theme == Themes.AUTO_ID) scheduleNight() else systemDark
        val target = Themes.resolve(s.theme, dark, s.autoLight, s.autoDark, model.accentSeed)
        model.shownThemeId = target.id
        if (target.id != themeTo.id) {
            themeFrom = if (initial) target else env.theme
            themeTo = target
            if (initial || env.motion <= 0f) { morph.set(1f); env.theme = target }
            else { morph.set(0f); morph.go(1f, env.dur(0.6f), Ease.IN_OUT) }
        }
        if (initial) env.theme = effective(target)
        refreshArt()
        env.art.orbShape = model.orbShapeFor(model.shownThemeId)     // hangi sayfa açık olursa olsun şekil güncel kalır
        env.art.liquidColor = model.liquidColorArgb
        syncWallpaper()
    }

    private var wpKey = Long.MIN_VALUE
    private var wpLoad = 0

    /** Arka plan fotoğrafı ayarı (var/yok, yeni dosya, bulanıklık) değişince yeniden yükler. */
    private fun syncWallpaper() {
        val s = model.settings
        val key = (if (s.wallpaper) 1L shl 40 else 0L) or (s.wpRev.toLong() shl 4) or s.wpBlur.ordinal.toLong()
        if (key == wpKey) return
        wpKey = key
        val seq = ++wpLoad
        if (!s.wallpaper) { sky.setPic(null, 0f); return }
        model.host.loadWallpaper(s.wpBlur) { p ->
            if (seq != wpLoad) { p?.release(); return@loadWallpaper }     // daha yeni bir istek var
            if (p == null) { if (model.settings.wallpaper) model.onWallpaperMissing() }
            else { sky.setPic(p, env.dur(0.5f)); model.host.requestFrame() }
        }
    }

    /** Saatli gece: saat bilgisi dakikada bir okunur (her karede takvim nesnesi üretmemek için). */
    private fun scheduleNight(): Boolean {
        val minute = model.host.now() / 60_000L
        val hours = model.settings.nightHours
        if (minute != nightMinute || hours !== nightHours) {
            nightMinute = minute; nightHours = hours
            nightNow = hours.isNight(model.host.localHour())
        }
        return nightNow
    }

    /** Yüksek kontrast açıksa temanın kontrastlı hali (aynı tema için önbellekten). */
    private fun effective(t: AeroTheme): AeroTheme {
        if (!model.settings.highContrast) return t
        if (hcFor !== t) { hcFor = t; hcTheme = t.highContrast() }
        return hcTheme!!
    }

    private fun refreshArt() {
        val glass = if (model.settings.highContrast) 1f else model.settings.glass
        if (env.art.glass != glass || env.art.theme !== env.theme || env.art.style != model.settings.style) {
            val styleChanged = env.art.style != model.settings.style
            env.art = ArtFactory.create(model.settings.style, env.theme, glass)
            sky.setMode(env.art.particleMode)
            sky.setCount(model.settings.effectiveBubbles.count)
            if (styleChanged && width > 0f) { layoutAll(); revealTop() }   // başlık boyutu değişir; yeni stil kendini gösterir
        }
    }

    // ------------------------------------------------------------------ dokunma efektleri (stile özgü)

    private val fxX = FloatArray(FX_SLOTS)
    private val fxY = FloatArray(FX_SLOTS)
    private val fxAge = FloatArray(FX_SLOTS) { Float.MAX_VALUE }

    // Ses paketi animasyonları (yalnızca animasyonlu paketlerde): her biri yuva, merkez, boyut ve yaş taşır.
    private val pxSlot = arrayOfNulls<FxSlot>(PFX_SLOTS)
    private val pxX = FloatArray(PFX_SLOTS)
    private val pxY = FloatArray(PFX_SLOTS)
    private val pxS = FloatArray(PFX_SLOTS)
    private val pxAge = FloatArray(PFX_SLOTS) { Float.MAX_VALUE }
    private var lastTapX = 0f
    private var lastTapY = 0f
    private var seenPackFx = model.packFxSeq

    private fun spawnPack(slot: FxSlot, x: Float, y: Float, s: Float) {
        var k = 0
        for (i in 1 until PFX_SLOTS) if (pxAge[i] > pxAge[k]) k = i
        pxSlot[k] = slot; pxX[k] = x; pxY[k] = y; pxS[k] = s; pxAge[k] = 0f
    }

    /** Model'in bildirdiği bir olayın animasyonunu başlatır (ayarlara ve hareket düzeyine saygı gösterir). */
    private fun packEvent(slot: FxSlot) {
        if (env.motion <= 0f) return
        val st = model.settings
        if (slot.atOrb) {
            if (!st.celebrate) return
            val r = if (env.orbValid) env.orbR else minOf(width, height) * 0.22f
            val cx = if (env.orbValid) env.orbX else width / 2f
            val cy = if (env.orbValid) env.orbY else height * 0.4f
            spawnPack(slot, cx, cy, r * 1.8f)
        } else {
            if (!st.tapFx) return
            // Aynı dokunuşun küçük dokunuş animasyonu varsa anahtar animasyonu onun yerini alır.
            for (i in 0 until PFX_SLOTS) if (pxSlot[i] == FxSlot.TAP && pxAge[i] < 0.12f && pxAge[i] < FxSlot.TAP.sec) pxAge[i] = Float.MAX_VALUE
            spawnPack(slot, lastTapX, lastTapY, env.sz(44f))
        }
    }

    private fun spawnFx(x: Float, y: Float) {
        lastTapX = x; lastTapY = y
        if (model.settings.soundPack.animated) {
            if (model.settings.tapFx && env.motion > 0f) spawnPack(FxSlot.TAP, x, y, env.sz(44f))
            return
        }
        if (!model.settings.tapFx || env.motion <= 0f || env.art.motion.fx == FxKind.NONE) return
        var slot = 0
        for (i in 1 until FX_SLOTS) if (fxAge[i] > fxAge[slot]) slot = i      // en eskisinin yerine
        fxX[slot] = x; fxY[slot] = y; fxAge[slot] = 0f
    }

    private fun tickFx(dt: Float): Boolean {
        var any = false
        if (model.packFxSeq != seenPackFx) {
            seenPackFx = model.packFxSeq
            if (model.settings.soundPack.animated) packEvent(model.packFxSlot)
        }
        for (i in 0 until PFX_SLOTS) {
            val sl = pxSlot[i] ?: continue
            if (pxAge[i] >= sl.sec) continue
            pxAge[i] += dt * env.speed
            if (pxAge[i] < sl.sec) any = true
        }
        if (env.celeAge < StyleFx.CELEBRATE_SEC) {
            env.celeAge += dt * env.speed
            if (env.celeAge < StyleFx.CELEBRATE_SEC) any = true
        }
        for (i in 0 until FX_SLOTS) {
            if (fxAge[i] >= StyleFx.TAP_SEC) continue
            fxAge[i] += dt * env.speed
            if (fxAge[i] < StyleFx.TAP_SEC) any = true
        }
        return any
    }

    private fun drawFx(g: Gfx) {
        val pack = model.settings.soundPack
        if (pack.animated) {
            for (i in 0 until PFX_SLOTS) {
                val sl = pxSlot[i] ?: continue
                if (pxAge[i] >= sl.sec) continue
                PackFx.draw(pack, sl, g, env.theme, pxX[i], pxY[i], pxS[i], pxAge[i] / sl.sec)
            }
            return
        }
        val kind = env.art.motion.fx
        if (env.celeAge < StyleFx.CELEBRATE_SEC) StyleFx.celebrate(kind, g, env.theme, env.celeX, env.celeY, env.celeR, env.celeAge / StyleFx.CELEBRATE_SEC)
        for (i in 0 until FX_SLOTS) {
            val a = fxAge[i]
            if (a >= StyleFx.TAP_SEC) continue
            StyleFx.tap(kind, g, env.theme, fxX[i], fxY[i], a / StyleFx.TAP_SEC)
        }
    }

    // ------------------------------------------------------------------ zaman

    /**
     * Bir kare ilerlet. @return bir sonraki kareye kadar önerilen gecikme (ms): 16 = etkileşimli animasyon,
     * 33 = yalnızca süs animasyonu, -1 = hiç kare gerekmiyor (ekran durağan).
     */
    fun tick(nowMs: Long): Long {
        val dt = if (lastNow < 0) 0.016f else ((nowMs - lastNow) / 1000f).coerceIn(0.001f, 0.05f)
        lastNow = nowMs
        started = true
        env.time += dt

        syncSettings(false)
        model.watchdog()

        // dil değişti: tüm sayfaları yeni dilde yeniden kur
        if (model.langSeq != seenLang) { seenLang = model.langSeq; rebuildPages() }
        if (model.whatsNewSeq != seenWhatsNew) { seenWhatsNew = model.whatsNewSeq; if (pages.last() !is WhatsNewPage) openWhatsNew() }

        // tema geçişi
        var active = morph.step(dt)
        val base = if (morph.value >= 1f || !morph.active && themeFrom.id == themeTo.id) themeTo
            else AeroTheme.lerp(themeFrom, themeTo, morph.value)
        env.theme = effective(base)
        refreshArt()

        // modelden gelen olaylar
        if (model.toastSeq != seenToast) { seenToast = model.toastSeq; model.toast?.let { toast.show(env, it) } }
        if (model.consentOpen && sheet == null) openConsent()
        if (!model.consentOpen && sheetIsConsent) sheet?.close(env)

        // sayfa geçişi
        if (trans.step(dt)) active = true
        else if (popping && leaving != null) { pages.remove(leaving); leaving = null; entering = null; popping = false }
        else if (!trans.active) { leaving = null; entering = null }

        // sayfalar
        val top = pages.last()
        if (top.tick(dt, env)) active = true
        val other = if (leaving != null && leaving !== top) leaving else if (entering != null && entering !== top) entering else null
        if (other != null && other.tick(dt, env)) active = true

        // alt panel
        val sh = sheet
        if (sh != null) {
            if (sh.tick(dt, env)) active = true
            if (sh.finished) { sheet = null; sheetIsConsent = false }
        }
        if (toast.tick(dt, env)) active = true
        if (scrollingNow()) active = true
        if (tickFx(dt)) active = true

        // gökyüzü
        if (env.ambient) sky.update(dt)
        if (sky.tick(dt)) active = true

        checkLongPress(nowMs)

        if (active || pressed != null) return 16
        if (toast.active) return 33   // bildirimin kapanma geri sayımı (hareket kapalıyken de sürer)
        if (env.ambient && (ambientActive() || bubblesVisible() || (env.art.liveSky && !sky.hasPic))) return 33
        return -1
    }

    /** Arka plan fotoğrafı şu an sahnede mi (test ve kare isteği için). */
    val wallpaperShown: Boolean get() = sky.hasPic

    /** Bir bildirim görünüyor (ya da kapanıyor) mu? */
    val toastActive: Boolean get() = toast.active

    private fun bubblesVisible(): Boolean = model.settings.effectiveBubbles.count > 0 && env.art.particleMode != ParticleMode.NONE

    private fun ambientActive(): Boolean {
        if (pages.last().ambient(env)) return true
        val o = if (leaving != null) leaving else entering
        return o != null && o.ambient(env)
    }

    private fun scrollingNow(): Boolean = scrolling != null

    // ------------------------------------------------------------------ çizim

    fun draw(g: Gfx) {
        sky.draw(g, env)
        val top = pages.last()
        if (!trans.active || (leaving == null && entering == null)) {
            top.draw(g, env)
        } else {
            // q: yeni sayfanın giriş ilerlemesi (geri gidişte tersine); eski sayfa q'ya göre çıkar
            val p = trans.value
            val q = if (popping) 1f - p else p
            val newer = if (!popping) top else (leaving ?: top)
            val older = if (!popping) (leaving ?: pages[pages.size - 2]) else (entering ?: pages[pages.size - 2])
            val m = env.art.motion
            when (m.page) {
                PageMotion.SLIDE -> {
                    // yeni sayfa sağdan kayarak girer, eskisi hafifçe sola çekilip solar
                    // eski sayfa hızla solar, yeni sayfa hızla dolar: geçiş boyunca arkada ana ekran görünüp kalmaz
                    drawPage(g, older, 1f - Easing.clamp01(q * 1.7f), -28f * q)
                    drawPage(g, newer, Easing.clamp01(q * 2.2f), (1f - q) * (width * 0.20f))
                }
                PageMotion.FADE_SCALE -> {
                    drawPage(g, older, 1f - Easing.clamp01(q * 1.8f), 0f, 1f + 0.04f * q)
                    drawPage(g, newer, Easing.clamp01(q * 2.2f), 0f, 0.94f + 0.06f * Easing.outBack(q, 0.9f))
                }
                PageMotion.TURNSTILE -> {
                    // sayfa sol kenarında dönermiş gibi: yatayda daralıp açılır
                    drawPage(g, older, 1f - Easing.clamp01(q * 1.8f), -10f * q, 1f - 0.30f * q, 1f, 0f)
                    drawPage(g, newer, Easing.clamp01(q * 2.2f), (1f - q) * width * 0.08f, 0.62f + 0.38f * Easing.outCubic(q), 1f, 0f)
                }
                PageMotion.POP -> {
                    drawPage(g, older, 1f - Easing.clamp01(q * 1.8f), 0f, 1f + 0.05f * q)
                    drawPage(g, newer, Easing.clamp01(q * 2.2f), 0f, 0.82f + 0.18f * Easing.outBack(q, 1.0f + 1.4f * m.spring))
                }
            }
        }
        sheet?.draw(g, env)
        drawFx(g)
        if (toast.active) { g.save(); g.translate(toast.x, toast.y); toast.draw(g, env); g.restore() }
    }

    private fun drawPage(g: Gfx, n: Node, alpha: Float, dx: Float, sx: Float = 1f, sy: Float = sx, pivotX: Float = width / 2f) {
        g.save()
        g.alpha(Easing.clamp01(alpha))
        g.translate(dx, 0f)
        if (sx != 1f || sy != 1f) {
            val py = height / 2f
            g.translate(pivotX, py); g.scale(sx, sy); g.translate(-pivotX, -py)
        }
        n.draw(g, env)
        g.restore()
    }

    // ------------------------------------------------------------------ gezinti

    private fun top(): Node = pages.last()

    private fun push(p: Node) {
        model.sfx(Sfx.SHEET)
        p.x = 0f; p.y = 0f
        p.layout(env, width); p.h = height
        val from = pages.last()
        pages.add(p)
        if (env.motion <= 0f) return
        leaving = from
        entering = p
        popping = false
        trans.set(0f)
        trans.go(1f, env.dur(env.art.motion.pageSec), Ease.STANDARD)
        if (p is ScrollPage) p.startReveal(env)
    }

    override fun openMenu() { if (!transitioning()) push(MenuPage(this)) }
    override fun openPersonalize() { if (!transitioning()) push(PersonalizePage(model, this)) }
    override fun openLiquidColor() { if (!transitioning()) push(LiquidColorPage(model, this)) }
    override fun openSection(section: Section) { if (!transitioning()) push(SectionPage(model, this, section)) }
    override fun openAbout() { if (!transitioning()) push(AboutPage(model, this)) }
    override fun openLog() { if (!transitioning()) push(LogPage(model, this)) }
    override fun openHelp() { if (!transitioning()) push(HelpPage(this)) }
    override fun openSessions() { if (!transitioning()) push(SessionsPage(model, this)) }
    override fun openWhatsNew() { if (!transitioning()) push(WhatsNewPage(this)) }
    override fun openApps() { if (!transitioning()) push(AppsPage(model, this)) }

    override fun back() { goBack(); model.host.requestFrame() }

    /** Geri: önce alt panel, sonra sayfa. @return olay tüketildiyse true; false ise etkinlik kapanmalı. */
    fun goBack(): Boolean {
        model.sfx(Sfx.BACK)
        // Ekran durağanken de geri animasyonu başlasın (kare planlanmıyor olabilir).
        model.host.requestFrame()
        val sh = sheet
        if (sh != null) {
            if (!sh.closing) { if (sheetIsConsent) model.dismissConsent(); sh.close(env) }
            return true
        }
        if (transitioning()) return true
        if (pages.size > 1) {
            if (env.motion <= 0f) { pages.removeAt(pages.size - 1); return true }
            leaving = pages.last()
            entering = pages[pages.size - 2]
            popping = true
            trans.set(0f)
            trans.go(1f, env.dur(env.art.motion.pageSec - 0.04f), Ease.STANDARD)
            (pages[pages.size - 2] as? ScrollPage)?.let { it.startReveal(env) }
            return true
        }
        return false
    }

    fun transitioning(): Boolean = trans.active

    /** Yeni stil seçilince en üstteki sayfanın satırları yeniden belirir (stilin kendini göstermesi için). */
    private fun revealTop() { (pages.lastOrNull() as? ScrollPage)?.startReveal(env) }

    /**
     * Geri tuşu bir şey tüketecek mi (alt panel açık, alt sayfadayız ya da geçiş sürüyor)? [goBack] ile aynı kural.
     * false ise etkinlik sistemin kendi geri davranışına (uygulamadan çıkış) bırakılır.
     */
    val canGoBack: Boolean get() = sheet != null || pages.size > 1 || trans.active

    val pageCount: Int get() = pages.size

    /** En üstteki sayfa (test ve a11y için). */
    val currentPage: Node get() = pages.last()

    val hasSheet: Boolean get() = sheet != null

    private fun showSheet(content: Column, consent: Boolean) {
        sheet?.let { if (!it.closing) it.close(env) }
        val s = Sheet(content) { if (consent) model.dismissConsent(); closeSheet() }
        if (!consent) model.sfx(Sfx.SHEET)
        sheet = s
        sheetIsConsent = consent
        s.layoutSheet(env)
        s.show(env)
        // Sheet kapanış animasyonu sürerken yenisi açılırsa eskisi yok edilir.
    }

    fun closeSheet() { sheet?.close(env) }

    override fun openDetails(server: DnsServer) {
        showSheet(DetailsContent(server, model) { closeSheet() }, false)
    }

    override fun openChoice(title: String, current: String?, onPick: (String?) -> Unit) {
        showSheet(ChoiceContent(title, current, onPick) { closeSheet() }, false)
    }

    override fun openOptions(title: String, options: List<Option>, empty: String, footer: String, onPick: (String?) -> Unit) {
        showSheet(OptionsContent(title, options, empty, footer, onPick) { closeSheet() }, false)
    }

    override fun openQuickPick() {
        if (!model.settings.onboarded) return
        showSheet(QuickContent(model, { closeSheet() }) { openTest() }, false)
    }

    override fun openTest() {
        model.testConnection()
        if (model.testing) showSheet(TestContent(model) { closeSheet() }, false)
    }

    override fun openRecommend() {
        showSheet(RecommendContent(model) { closeSheet() }, false)
    }

    override fun openInfo(title: String, paragraphs: List<String>, button: String?, action: (() -> Unit)?) {
        showSheet(InfoContent(title, paragraphs, button, action) { closeSheet() }, false)
    }

    private fun openConsent() {
        showSheet(ConsentContent(model) { model.dismissConsent(); closeSheet() }, true)
    }

    // ------------------------------------------------------------------ dokunma

    private var pressed: Node? = null
    private var chain: List<Scrollable> = emptyList()
    private var scrolling: Scrollable? = null
    private var downX = 0f
    private var downY = 0f
    private var lastPos = 0f
    private var downT = 0L
    private var longFired = false
    private var moved = false
    private var dragDecided = false
    private val vtT = FloatArray(8)
    private val vtP = FloatArray(8)
    private var vtN = 0
    private var t0 = -1L

    private fun vtAdd(tMs: Long, p: Float) {
        if (t0 < 0) t0 = tMs
        val t = (tMs - t0) / 1000f
        if (vtN == vtT.size) {
            for (i in 1 until vtN) { vtT[i - 1] = vtT[i]; vtP[i - 1] = vtP[i] }
            vtN--
        }
        vtT[vtN] = t; vtP[vtN] = p; vtN++
    }

    private fun vtVelocity(): Float {
        if (vtN < 2) return 0f
        val last = vtN - 1
        var first = last
        while (first > 0 && vtT[last] - vtT[first - 1] < 0.12f) first--
        val dt = vtT[last] - vtT[first]
        if (dt < 0.004f) return 0f
        return (vtP[last] - vtP[first]) / dt
    }

    private fun layer(): Node = sheet ?: top()

    private fun hitAt(x: Float, y: Float): Node? {
        if (toast.active) toast.hit(x - toast.x, y - toast.y)?.let { return it }
        return layer().hit(x, y)
    }

    /** Dokunma olayı. [action]: [DOWN], [MOVE], [UP], [CANCEL]. Koordinatlar dp, [tMs] olay zamanı. */
    fun touch(action: Int, x: Float, y: Float, tMs: Long) {
        when (action) {
            DOWN -> onDown(x, y, tMs)
            MOVE -> onMove(x, y, tMs)
            UP -> onUp(x, y, tMs)
            else -> onCancelTouch()
        }
    }

    private fun onDown(x: Float, y: Float, tMs: Long) {
        onCancelTouch()
        if (transitioning()) return
        val deep = layer().hitScrollable(x, y)
        val list = ArrayList<Scrollable>(2)
        var n: Node? = deep
        while (n != null) { if (n is Scrollable) list.add(n); n = n.parent }
        chain = list
        var wasMoving = false
        for (s in list) if (s.stopScroll()) wasMoving = true
        // Kayan listeye dokunmak yalnızca durdurur; parmak kalkınca bir satıra basılmış sayılmaz.
        val t = if (wasMoving) null else hitAt(x, y)
        pressed = t
        downX = x; downY = y; downT = tMs
        longFired = false; moved = false; dragDecided = false
        vtN = 0; t0 = -1L
        t?.onDown(x - t.absX(), y - t.absY(), env)
        model.host.requestFrame()
    }

    private fun onMove(x: Float, y: Float, tMs: Long) {
        val sc = scrolling
        if (sc != null) {
            sc.dragBy(y - lastPos)
            lastPos = y
            vtAdd(tMs, y)
            model.host.requestFrame()
            return
        }
        var p = pressed
        val dx = x - downX
        val dy = y - downY
        if (p != null && p.dragCapture && p.dragActive) {
            // Topuz tutuldu: yön belli olana kadar küçük oynamalar sürüklemedir. Hareket dikeyse sayfa kayar
            // (kaydırırken parmak kaydırıcının topuzuna denk gelse bile sayfa takılmaz).
            if (dragDecided || (abs(dx) <= SLOP && abs(dy) <= SLOP) || abs(dx) >= abs(dy)) {
                if (abs(dx) > SLOP || abs(dy) > SLOP) dragDecided = true
                p.onDrag(x - p.absX(), y - p.absY(), env)
                model.host.requestFrame()
                return
            }
            p.onCancel(env)
            pressed = null
            p = null
        }
        if (abs(dx) > SLOP || abs(dy) > SLOP) {
            moved = true
            val horiz = abs(dx) > abs(dy)
            if (p != null && p.dragCapture && horiz) {
                p.onDragStart(x - p.absX(), y - p.absY(), env)
                p.onDrag(x - p.absX(), y - p.absY(), env)
                model.host.requestFrame()
                return
            }
            val s = if (horiz) null else chain.firstOrNull { it.canScroll }
            if (s != null) {
                p?.onCancel(env)
                pressed = null
                scrolling = s
                val sign = if (y >= downY) 1f else -1f
                lastPos = downY + sign * SLOP
                s.dragBy(y - lastPos)
                lastPos = y
                vtN = 0; t0 = -1L
                vtAdd(tMs, y)
            } else if (p != null && !p.contains(x - p.absX(), y - p.absY())) {
                p.onCancel(env)
                pressed = null
            }
        }
        model.host.requestFrame()
    }

    private fun onUp(x: Float, y: Float, tMs: Long) {
        val sc = scrolling
        if (sc != null) {
            vtAdd(tMs, y)   // parmak son konumunda durduysa hız sıfıra iner (durup bırakınca fırlatma olmaz)
            sc.flingBy(vtVelocity())
            scrolling = null
            model.host.requestFrame()
            return
        }
        val p = pressed
        pressed = null
        if (p != null) {
            val lx = x - p.absX()
            val ly = y - p.absY()
            val inside = p.contains(lx, ly)
            val tapped = inside && !longFired
            p.onUp(lx, ly, tapped, env)
            if (tapped && p.tappable) spawnFx(x, y)
        }
        model.host.requestFrame()
    }

    private fun onCancelTouch() {
        pressed?.onCancel(env)
        pressed = null
        scrolling = null
    }

    private fun checkLongPress(nowMs: Long) {
        val p = pressed ?: return
        if (longFired || moved || !p.longPressable) return
        if (nowMs - downT >= LONG_MS) {
            longFired = true
            p.onLongPress(env)
        }
    }

    // ------------------------------------------------------------------ erişilebilirlik

    /** Ekranda görünen, etiketli düğümler (yukarıdan aşağıya, soldan sağa). */
    fun a11yItems(): List<A11yItem> {
        val out = ArrayList<A11yItem>()
        if (sheet != null && !sheet!!.closing) {
            sheet!!.collectA11y(out, 0f, 0f, 0f, height)
        } else {
            top().collectA11y(out, 0f, 0f, 0f, height)
        }
        if (toast.active) toast.collectA11y(out, toast.x, toast.y, 0f, height)
        out.sortWith(compareBy<A11yItem>({ (it.t / 6f).toInt() }, { it.l }))
        return out
    }

    private fun findScroll(n: Node): ScrollView? {
        if (!n.visible) return null
        if (n is ScrollView) return n
        for (k in n.children) findScroll(k)?.let { return it }
        return null
    }

    private fun a11yScrollView(): ScrollView? {
        val sh = sheet
        return findScroll(if (sh != null && !sh.closing) sh else top())
    }

    /** TalkBack'in ileri/geri kaydır eylemi mümkün mü? */
    fun a11yCanScroll(forward: Boolean): Boolean {
        val sv = a11yScrollView() ?: return false
        return if (forward) sv.offset < sv.maxOffset - 0.5f else sv.offset > 0.5f
    }

    /** Görünür alanın yaklaşık %80'i kadar kaydırır. @return konum değiştiyse true. */
    fun a11yScroll(forward: Boolean): Boolean {
        val sv = a11yScrollView() ?: return false
        val before = sv.offset
        sv.scrollTo(before + (if (forward) 1f else -1f) * sv.h * 0.8f)
        model.host.requestFrame()
        return sv.offset != before
    }

    fun a11yClick(item: A11yItem) { item.node.a11yClick(env); model.host.requestFrame() }
    fun a11yLongClick(item: A11yItem): Boolean { val r = item.node.onLongPress(env); model.host.requestFrame(); return r }
    fun a11yAdjust(item: A11yItem, dir: Int) { item.node.a11yAdjust(dir, env); model.host.requestFrame() }

    companion object {
        private const val FX_SLOTS = 4
        private const val PFX_SLOTS = 6
        const val DOWN = 0
        const val MOVE = 1
        const val UP = 2
        const val CANCEL = 3
        const val SLOP = 8f
        const val LONG_MS = 450L
        const val MIN_FS = 0.9f
        const val MAX_FS = 1.3f
    }
}
