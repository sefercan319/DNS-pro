package app.dnshizli.core

import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/**
 * Hedef sunucuların ODoH açık anahtarı (yapılandırma) önbelleği.
 *
 *  - Taze süre [ttlMs] (varsayılan 6 saat; RFC anahtarların günlük döndürülmesini önerir). Süre dolunca ilk sorgu yeniler.
 *  - Aynı hedef için aynı anda tek alım yapılır (tek uçuş): dört şerit birden gelse de ağa tek istek gider, ötekiler bekler.
 *  - Alım başarısızsa ve elde bayat ama [staleMaxMs]'den genç bir yapılandırma varsa o kullanılır (anahtar döndüyse hedef 401
 *    verir ve [reject] zorunlu yenileme ister). Hiç yapılandırma yoksa hata verilir.
 *  - Hatalı alımdan sonra [failBackoffMs] boyunca aynı hedefe yeniden alım denenmez (hedef çökükken ağ dövülmez).
 *  - Zorunlu yenileme ([reject]) hedef başına en sık [minForceMs]'de bir yapılır: kötü niyetli ya da bozuk bir röle sürekli
 *    "401" döndürerek bizi hedefe yapılandırma isteği yağdırmaya zorlayamaz.
 * Saat ve alım işlevi dışarıdan verilir: testler gerçek ağa ve zamana bağlı değildir.
 */
class OdohKeyring(
    private val fetch: (targetHost: String) -> ByteArray,
    private val now: () -> Long,
    private val ttlMs: Long = 6 * 3600_000L,
    private val staleMaxMs: Long = 7 * 24 * 3600_000L,
    private val failBackoffMs: Long = 15_000L,
    private val minForceMs: Long = 30_000L,
) {
    private class Entry {
        @Volatile var configs: List<OdohConfig> = emptyList()
        @Volatile var fetchedAt = Long.MIN_VALUE / 2
        @Volatile var lastAttempt = Long.MIN_VALUE / 2
        @Volatile var failUntil = Long.MIN_VALUE / 2
        @Volatile var needsRefresh = false
        @Volatile var lastError: OdohException? = null
    }

    private val entries = ConcurrentHashMap<String, Entry>()
    @Volatile var fetches = 0L; private set

    private fun entry(host: String) = entries.getOrPut(host) { Entry() }

    private fun fresh(e: Entry, t: Long): Boolean = e.configs.isNotEmpty() && t - e.fetchedAt < ttlMs && !(e.needsRefresh && t - e.lastAttempt >= minForceMs)

    /** [targetHost]'un şu an kullanılacak yapılandırması (sunucunun tercih ettiği ilk desteklenen). Gerekirse alır. */
    fun current(targetHost: String): OdohConfig {
        val e = entry(targetHost)
        if (fresh(e, now())) return e.configs[0]
        synchronized(e) {
            val t = now()
            if (fresh(e, t)) return e.configs[0]
            val have = e.configs.isNotEmpty() && t - e.fetchedAt <= staleMaxMs
            if (t < e.failUntil) {                                    // yakın zamanda başarısız: dövme
                if (have) return e.configs[0]
                throw e.lastError ?: OdohException(OdohError.CONFIG_FETCH, "yapılandırma alınamadı")
            }
            e.lastAttempt = t
            try {
                fetches++
                val parsed = OdohConfigs.parse(fetch(targetHost))
                e.configs = parsed
                e.fetchedAt = now()
                e.needsRefresh = false
                e.lastError = null
                return parsed[0]
            } catch (ex: OdohException) {
                e.failUntil = now() + failBackoffMs
                e.lastError = ex
                if (have) return e.configs[0]
                throw ex
            } catch (ex: IOException) {
                val wrapped = OdohException(OdohError.CONFIG_FETCH, "yapılandırma alınamadı: ${ex.javaClass.simpleName}", ex)
                e.failUntil = now() + failBackoffMs
                e.lastError = wrapped
                if (have) return e.configs[0]
                throw wrapped
            }
        }
    }

    /** Hedef anahtarımızı tanımadı (401): bir sonraki [current] çağrısı (hız sınırı içinde) yapılandırmayı yeniler. */
    fun reject(targetHost: String, keyId: ByteArray?) {
        val e = entries[targetHost] ?: return
        // Başka bir şerit çoktan yeniledi ve anahtar değiştiyse bu geç gelen bir 401'dir: yeniden zorlama.
        val cur = e.configs.firstOrNull()
        if (keyId != null && cur != null && !cur.keyId.contentEquals(keyId)) return
        e.needsRefresh = true
    }

    /** Yapılandırmayı önceden ısıtır (arka planda); hata yutulur. */
    fun warm(targetHost: String) { try { current(targetHost) } catch (_: IOException) {} }

    fun cachedKeyId(targetHost: String): ByteArray? = entries[targetHost]?.configs?.firstOrNull()?.keyId
    fun forget() { entries.clear() }
}
