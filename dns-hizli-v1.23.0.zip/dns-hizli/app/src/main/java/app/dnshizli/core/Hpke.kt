package app.dnshizli.core

import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * X25519 (RFC 7748). Android 8'den itibaren (minSdk 26) sistemde hazır X25519 yoktur (Android 13'e kadar), bu yüzden burada
 * kendimiz yazdık: TweetNaCl'ın 16 × 16 bitlik uzuvlu, dallanmasız ("sabit zamanlı": gizli bit hiçbir koşulu ya da dizi
 * indisini belirlemez) hesabı. Doğruluğu testlerde JDK'nın kendi XDH gerçeklemesiyle ve RFC 7748 / RFC 9180 vektörleriyle denenir.
 */
object X25519 {
    const val SIZE = 32

    private val NINE = ByteArray(SIZE).also { it[0] = 9 }
    private val C121665 = LongArray(16).also { it[0] = 0xDB41; it[1] = 1 }

    /** Rastgele özel anahtar (32 bayt; sıkıştırma ölçekte yapılır). */
    fun generatePrivate(rng: SecureRandom): ByteArray = ByteArray(SIZE).also { rng.nextBytes(it) }

    fun publicKey(priv: ByteArray): ByteArray {
        require(priv.size == SIZE) { "özel anahtar 32 bayt olmalı" }
        return scalarMult(priv, NINE)
    }

    /** Ortak sır; karşı taraf düşük mertebeli bir nokta gönderdiyse (sonuç tümüyle sıfır) null. */
    fun shared(priv: ByteArray, pub: ByteArray): ByteArray? {
        require(priv.size == SIZE && pub.size == SIZE) { "anahtarlar 32 bayt olmalı" }
        val out = scalarMult(priv, pub)
        var acc = 0
        for (b in out) acc = acc or b.toInt()
        return if (acc == 0) null else out
    }

    private fun car(o: LongArray) {
        for (i in 0 until 16) {
            o[i] += 1L shl 16
            val c = o[i] shr 16
            val next = if (i < 15) i + 1 else 0
            o[next] += c - 1 + (if (i == 15) 37 * (c - 1) else 0L)
            o[i] -= c shl 16
        }
    }

    private fun sel(p: LongArray, q: LongArray, b: Long) {
        val c = (b - 1).inv()
        for (i in 0 until 16) {
            val t = c and (p[i] xor q[i])
            p[i] = p[i] xor t
            q[i] = q[i] xor t
        }
    }

    private fun pack(o: ByteArray, n: LongArray) {
        val t = n.copyOf()
        val m = LongArray(16)
        car(t); car(t); car(t)
        for (j in 0 until 2) {
            m[0] = t[0] - 0xffed
            for (i in 1 until 15) {
                m[i] = t[i] - 0xffff - ((m[i - 1] shr 16) and 1)
                m[i - 1] = m[i - 1] and 0xffff
            }
            m[15] = t[15] - 0x7fff - ((m[14] shr 16) and 1)
            val b = (m[15] shr 16) and 1
            m[14] = m[14] and 0xffff
            sel(t, m, 1 - b)
        }
        for (i in 0 until 16) {
            o[2 * i] = (t[i] and 0xff).toByte()
            o[2 * i + 1] = (t[i] shr 8).toByte()
        }
    }

    private fun unpack(o: LongArray, n: ByteArray) {
        for (i in 0 until 16) o[i] = (n[2 * i].toLong() and 0xff) + ((n[2 * i + 1].toLong() and 0xff) shl 8)
        o[15] = o[15] and 0x7fff
    }

    private fun add(o: LongArray, a: LongArray, b: LongArray) { for (i in 0 until 16) o[i] = a[i] + b[i] }
    private fun sub(o: LongArray, a: LongArray, b: LongArray) { for (i in 0 until 16) o[i] = a[i] - b[i] }

    private fun mul(o: LongArray, a: LongArray, b: LongArray) {
        val t = LongArray(31)
        for (i in 0 until 16) for (j in 0 until 16) t[i + j] += a[i] * b[j]
        for (i in 0 until 15) t[i] += 38 * t[i + 16]
        for (i in 0 until 16) o[i] = t[i]
        car(o); car(o)
    }

    private fun sqr(o: LongArray, a: LongArray) = mul(o, a, a)

    private fun inv(o: LongArray, i: LongArray) {
        val c = i.copyOf()
        for (a in 253 downTo 0) {
            sqr(c, c)
            if (a != 2 && a != 4) mul(c, c, i)
        }
        for (a in 0 until 16) o[a] = c[a]
    }

    private fun scalarMult(n: ByteArray, p: ByteArray): ByteArray {
        val z = n.copyOf()
        z[31] = ((n[31].toInt() and 127) or 64).toByte()
        z[0] = (z[0].toInt() and 248).toByte()
        val x = LongArray(16)
        unpack(x, p)
        val a = LongArray(16); val b = x.copyOf(); val c = LongArray(16); val d = LongArray(16)
        val e = LongArray(16); val f = LongArray(16)
        a[0] = 1; d[0] = 1
        for (i in 254 downTo 0) {
            val r = ((z[i ushr 3].toInt() ushr (i and 7)) and 1).toLong()
            sel(a, b, r); sel(c, d, r)
            add(e, a, c); sub(a, a, c); add(c, b, d); sub(b, b, d)
            sqr(d, e); sqr(f, a); mul(a, c, a); mul(c, b, e)
            add(e, a, c); sub(a, a, c); sqr(b, a); sub(c, d, f)
            mul(a, c, C121665); add(a, a, d); mul(c, c, a); mul(a, d, f)
            mul(d, b, x); sqr(b, e)
            sel(a, b, r); sel(c, d, r)
        }
        val ci = LongArray(16)
        inv(ci, c)
        val out = LongArray(16)
        mul(out, a, ci)
        val q = ByteArray(SIZE)
        pack(q, out)
        java.util.Arrays.fill(z, 0)
        return q
    }
}

/** HKDF (RFC 5869) üstünde HMAC-SHA256. */
object Hkdf {
    const val NH = 32
    private const val ALG = "HmacSHA256"

    fun extract(salt: ByteArray?, ikm: ByteArray): ByteArray {
        val mac = Mac.getInstance(ALG)
        mac.init(SecretKeySpec(if (salt == null || salt.isEmpty()) ByteArray(NH) else salt, ALG))
        return mac.doFinal(ikm)
    }

    fun expand(prk: ByteArray, info: ByteArray, len: Int): ByteArray {
        require(len in 0..255 * NH) { "çıktı uzunluğu sınır dışı" }
        val mac = Mac.getInstance(ALG)
        mac.init(SecretKeySpec(prk, ALG))
        val out = ByteArray(len)
        var t = ByteArray(0)
        var off = 0
        var ctr = 1
        while (off < len) {
            mac.update(t); mac.update(info); mac.update(ctr.toByte())
            t = mac.doFinal()
            val n = minOf(t.size, len - off)
            System.arraycopy(t, 0, out, off, n)
            off += n
            ctr++
        }
        return out
    }
}

/** HPKE bağlamı (RFC 9180, temel kip): sıralı Seal/Open ve dışa aktarım. */
class HpkeContext internal constructor(
    private val key: ByteArray,
    private val baseNonce: ByteArray,
    private val exporterSecret: ByteArray,
    private val suiteId: ByteArray,
) {
    private var seq = 0L

    private fun nonce(): ByteArray {
        val n = baseNonce.copyOf()
        var s = seq
        var i = n.size - 1
        while (i >= 0 && s != 0L) { n[i] = (n[i].toInt() xor (s and 0xFF).toInt()).toByte(); s = s ushr 8; i-- }
        return n
    }

    fun seal(aad: ByteArray, pt: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce()))
        c.updateAAD(aad)
        val out = c.doFinal(pt)
        seq++
        return out
    }

    /** Çözer; kimlik doğrulaması tutmazsa null. */
    fun open(aad: ByteArray, ct: ByteArray): ByteArray? {
        if (ct.size < Hpke.NT) return null
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce()))
            c.updateAAD(aad)
            val out = c.doFinal(ct)
            seq++
            out
        } catch (_: GeneralSecurityException) {
            null
        }
    }

    /** RFC 9180 §5.3: bağlama bağlı, dışarı verilebilir türetilmiş sır. */
    fun export(exporterContext: ByteArray, len: Int): ByteArray =
        Hpke.labeledExpand(suiteId, exporterSecret, "sec", exporterContext, len)

    fun wipe() {
        java.util.Arrays.fill(key, 0); java.util.Arrays.fill(exporterSecret, 0); java.util.Arrays.fill(baseNonce, 0)
    }
}

class HpkeSender(val enc: ByteArray, val context: HpkeContext)

/**
 * HPKE (RFC 9180), yalnızca ODoH'un zorunlu takımı: DHKEM(X25519, HKDF-SHA256) + HKDF-SHA256 + AES-128-GCM, temel kip.
 * Başka takım yoktur: özellik azlığı hata yüzeyini küçültür; desteklenmeyen takımlı yapılandırmalar atlanır.
 */
object Hpke {
    const val KEM_ID = 0x0020
    const val KDF_ID = 0x0001
    const val AEAD_ID = 0x0001
    const val NK = 16
    const val NN = 12
    const val NT = 16
    const val NH = 32
    const val NPK = 32

    private val V1 = "HPKE-v1".toByteArray(Charsets.US_ASCII)
    private fun i2(v: Int) = byteArrayOf((v ushr 8).toByte(), v.toByte())
    private fun cat(vararg p: ByteArray): ByteArray {
        var n = 0; for (a in p) n += a.size
        val o = ByteArray(n); var k = 0
        for (a in p) { System.arraycopy(a, 0, o, k, a.size); k += a.size }
        return o
    }

    private val KEM_SUITE = cat("KEM".toByteArray(Charsets.US_ASCII), i2(KEM_ID))
    private val HPKE_SUITE = cat("HPKE".toByteArray(Charsets.US_ASCII), i2(KEM_ID), i2(KDF_ID), i2(AEAD_ID))

    internal fun labeledExtract(suite: ByteArray, salt: ByteArray?, label: String, ikm: ByteArray): ByteArray =
        Hkdf.extract(salt, cat(V1, suite, label.toByteArray(Charsets.US_ASCII), ikm))

    internal fun labeledExpand(suite: ByteArray, prk: ByteArray, label: String, info: ByteArray, len: Int): ByteArray =
        Hkdf.expand(prk, cat(i2(len), V1, suite, label.toByteArray(Charsets.US_ASCII), info), len)

    private fun extractAndExpand(dh: ByteArray, kemContext: ByteArray): ByteArray {
        val prk = labeledExtract(KEM_SUITE, null, "eae_prk", dh)
        return labeledExpand(KEM_SUITE, prk, "shared_secret", kemContext, NH)
    }

    private fun keySchedule(sharedSecret: ByteArray, info: ByteArray): HpkeContext {
        val pskIdHash = labeledExtract(HPKE_SUITE, null, "psk_id_hash", ByteArray(0))
        val infoHash = labeledExtract(HPKE_SUITE, null, "info_hash", info)
        val ksContext = cat(byteArrayOf(0), pskIdHash, infoHash)             // kip 0x00 (temel)
        val secret = labeledExtract(HPKE_SUITE, sharedSecret, "secret", ByteArray(0))
        val key = labeledExpand(HPKE_SUITE, secret, "key", ksContext, NK)
        val baseNonce = labeledExpand(HPKE_SUITE, secret, "base_nonce", ksContext, NN)
        val exp = labeledExpand(HPKE_SUITE, secret, "exp", ksContext, NH)
        return HpkeContext(key, baseNonce, exp, HPKE_SUITE)
    }

    /** Bağlamdan bağımsız AES-128-GCM (ODoH yanıtı HPKE bağlamını değil, kendi türettiği anahtarı kullanır). */
    fun aeadSeal(key: ByteArray, nonce: ByteArray, aad: ByteArray, pt: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        c.updateAAD(aad)
        return c.doFinal(pt)
    }

    /** Çözer; kimlik doğrulaması tutmazsa null. */
    fun aeadOpen(key: ByteArray, nonce: ByteArray, aad: ByteArray, ct: ByteArray): ByteArray? {
        if (ct.size < NT) return null
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
            c.updateAAD(aad)
            c.doFinal(ct)
        } catch (_: GeneralSecurityException) {
            null
        }
    }

    /**
     * Gönderici kurulumu. [ephemeralPrivate] yalnızca testler içindir (RFC vektörleri); üretimde her çağrıda yeni rastgele anahtar
     * üretilir. Alıcı anahtarı geçersizse (düşük mertebeli nokta) null.
     */
    fun setupBaseS(pkR: ByteArray, info: ByteArray, rng: SecureRandom, ephemeralPrivate: ByteArray? = null): HpkeSender? {
        if (pkR.size != NPK) return null
        val skE = ephemeralPrivate ?: X25519.generatePrivate(rng)
        val pkE = X25519.publicKey(skE)
        val dh = X25519.shared(skE, pkR) ?: return null
        val shared = extractAndExpand(dh, cat(pkE, pkR))
        java.util.Arrays.fill(dh, 0)
        if (ephemeralPrivate == null) java.util.Arrays.fill(skE, 0)
        return HpkeSender(pkE, keySchedule(shared, info))
    }

    /** Alıcı kurulumu (hedef taraf; testlerdeki sunucu simülatörü kullanır). Geçersiz [enc] ise null. */
    fun setupBaseR(enc: ByteArray, skR: ByteArray, info: ByteArray): HpkeContext? {
        if (enc.size != NPK) return null
        val dh = X25519.shared(skR, enc) ?: return null
        val pkR = X25519.publicKey(skR)
        val shared = extractAndExpand(dh, cat(enc, pkR))
        java.util.Arrays.fill(dh, 0)
        return keySchedule(shared, info)
    }
}
