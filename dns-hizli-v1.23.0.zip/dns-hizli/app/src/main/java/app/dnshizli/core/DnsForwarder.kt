package app.dnshizli.core

import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

data class Stats(
    val queries: Long = 0,
    val cacheHits: Long = 0,
    val forwarded: Long = 0,
    val answered: Long = 0,
    val retries: Long = 0,
    val timeouts: Long = 0,
    val dropped: Long = 0,
    val resets: Long = 0,
    val latencySumMs: Long = 0,
    /** Birincil sunucu cevap vermeyince yedeğe kalıcı geçiş sayısı. */
    val failovers: Long = 0,
    /** Şu an yedek (ikinci) sunucu birincil olarak kullanılıyor mu? */
    val backup: Boolean = false,
    /** Engelleme cevabı olduğu tahmin edilen cevaplar (0.0.0.0 / :: ya da "engellendi" hata kodu). */
    val blocked: Long = 0,
    /** Sunucuya gönderilen / sunucudan alınan DNS verisi (bayt; şifreleme ve başlıklar hariç). */
    val bytesUp: Long = 0,
    val bytesDown: Long = 0,
    /** Aynı anda bekleyen özdeş bir sorguya eklenen (ağa ayrıca gönderilmeyen) sorgular. */
    val merged: Long = 0,
    /** Kimliği tuttuğu halde soru bölümü uyuşmadığı için atılan (sahte ya da bozuk) cevaplar. */
    val rejected: Long = 0,
    /** Şifreli bağlantıda sertifika/ad doğrulaması başarısız olan denemeler (araya girme ya da yanlış sunucu belirtisi). */
    val tlsFailures: Long = 0,
) {
    /** Ağdan gelen cevapların ortalama süresi (ms). Hiç cevap yoksa 0. */
    val avgMs: Int get() = if (answered == 0L) 0 else (latencySumMs / answered).toInt()

    /** Önbellekten karşılanan sorguların yüzdesi. */
    val hitPercent: Int get() = if (queries == 0L) 0 else (cacheHits * 100 / queries).toInt()
}

/**
 * Tünelden gelen DNS sorgularını bir sunucuya ileten bileşen. İki uygulaması vardır:
 * düz DNS için [DnsForwarder] (UDP/53) ve şifreli DNS için [SecureForwarder] (DoT / DoH).
 * Servis yalnızca bu arayüzü görür.
 */
interface Forwarder : AutoCloseable {
    val proto: Proto
    fun start()

    /** Tünelden okunan ham IP paketi. Tek bir iş parçacığından (tünel okuyucu) çağrılmalıdır. */
    fun onPacket(p: ByteArray, len: Int)
    fun stats(): Stats

    /** Ağ değişti: bağlantıları yenile, önbelleği boşalt, yeniden birincil sunucuyla başla. */
    fun resetNetwork(reason: String = "ağ değişti")
    fun clearCache()

    /**
     * Son sorguların cevap süreleri (ms), eskiden yeniye, [out]'a yazılır; zaman aşımına uğrayan sorgu [LatencyRing.TIMEOUT]
     * (-1) olarak girer. Alan adı tutulmaz. Kaç değer yazıldığını döner (desteklemeyen yönlendirici 0).
     */
    fun latencies(out: IntArray): Int = 0
}

/** Tünelden gelen bir DNS sorgusunun ayrıştırılmış hali (kaynak/hedef adres ve port, istemci kimliği). IPv4 ya da IPv6. */
internal class ParsedQuery {
    var clientIp = 0
    var serverIp = 0
    var clientPort = 0
    var serverPort = 0
    var clientId = 0
    var dnsOff = 0
    var dnsLen = 0

    /** IPv6 paketi mi? Öyleyse adresler [client6] / [server6] içindedir ([clientIp] / [serverIp] kullanılmaz). */
    var isV6 = false
    val client6 = ByteArray(16)
    val server6 = ByteArray(16)

    /** Paket geçerli bir DNS sorgusuysa (IPv4 ya da IPv6) alanları doldurup true döner. Nesne ayırmaz. */
    fun parse(p: ByteArray, len: Int, maxDns: Int): Boolean {
        if (len > 0 && ((p[0].toInt() and 0xF0) shr 4) == 6) return parse6(p, len, maxDns)
        val ihl = Packets.queryHeaderLen(p, len)
        if (ihl < 0) return false
        val off = ihl + Packets.UDP_HDR
        val dl = Packets.dnsLength(p, ihl)
        if (dl < Packets.DNS_HDR || dl > maxDns) return false
        if ((p[off + 2].toInt() and 0x80) != 0) return false        // sorgu değil (QR=1)
        isV6 = false
        clientIp = Packets.i32(p, 12)
        serverIp = Packets.i32(p, 16)
        clientPort = Packets.u16(p, ihl)
        serverPort = Packets.u16(p, ihl + 2)
        clientId = Packets.u16(p, off)
        dnsOff = off
        dnsLen = dl
        return true
    }

    private fun parse6(p: ByteArray, len: Int, maxDns: Int): Boolean {
        val ihl = Packets.queryHeaderLen6(p, len)
        if (ihl < 0) return false
        val off = ihl + Packets.UDP_HDR
        val dl = Packets.dnsLength6(p)
        if (dl < Packets.DNS_HDR || dl > maxDns || off + dl > len) return false
        if ((p[off + 2].toInt() and 0x80) != 0) return false
        isV6 = true
        System.arraycopy(p, 8, client6, 0, 16)
        System.arraycopy(p, 24, server6, 0, 16)
        clientPort = Packets.u16(p, ihl)
        serverPort = Packets.u16(p, ihl + 2)
        clientId = Packets.u16(p, off)
        dnsOff = off
        dnsLen = dl
        return true
    }

    /** Önbellekten hazırlanan cevabı ([out]: DNS verisi [Packets.HDR] konumunda, istemci kimliği yazılmış) istemciye yazar. */
    fun writeCached(out: ByteArray, scratch: ByteArray, n: Int, write: (ByteArray, Int, Int) -> Unit) {
        if (isV6) Packets.writeReply6(out, scratch, Packets.nextIdent(), server6, client6, serverPort, clientPort, n, write)
        else Packets.writeReply(out, scratch, Packets.nextIdent(), serverIp, clientIp, serverPort, clientPort, n, write)
    }

    /** Cevap bekleyen istemci kaydı (adresler kopyalanır; [ParsedQuery] yeniden kullanılır). */
    fun waiter(): Waiter =
        if (isV6) Waiter(0, 0, clientPort, serverPort, clientId, client6.copyOf(), server6.copyOf())
        else Waiter(clientIp, serverIp, clientPort, serverPort, clientId)
}

/**
 * Cevabı bekleyen bir istemci (aynı soruyu soran birden çok istemci tek sorguya eklenebilir). IPv4 istemcilerde adresler
 * [clientIp] / [serverIp]; IPv6 istemcilerde [client6] / [server6] doludur.
 */
internal class Waiter(
    val clientIp: Int, val serverIp: Int, val clientPort: Int, val serverPort: Int, val clientId: Int,
    val client6: ByteArray? = null, val server6: ByteArray? = null,
) {
    /**
     * Cevabı bu istemciye gönderir. [out]: DNS cevabı [Packets.HDR] konumunda hazır; istemcinin kimliği oraya yazılır.
     * [out] IPv6'da hiç değiştirilmez (başlıklar [scratch]'ta kurulur); IPv4'te baştaki başlık alanına yazılır.
     */
    fun deliver(out: ByteArray, scratch: ByteArray, len: Int, write: (ByteArray, Int, Int) -> Unit) {
        Packets.put16(out, Packets.HDR, clientId)
        val c6 = client6
        val s6 = server6
        if (c6 != null && s6 != null) {
            Packets.writeReply6(out, scratch, Packets.nextIdent(), s6, c6, serverPort, clientPort, len, write)
        } else {
            Packets.writeReply(out, scratch, Packets.nextIdent(), serverIp, clientIp, serverPort, clientPort, len, write)
        }
    }
}

/**
 * Tünelden gelen DNS sorgularını seçilen sunucuya düz DNS (UDP/53) ile iletir. Android'e bağlı değildir.
 *
 * Kaynak tüketimini düşük tutan tasarım:
 *  - Az sayıda UDP soketi ([SLOTS] "yuva"; sorgu başına soket/thread yok). Her yuvanın tek bir alıcı thread'i vardır.
 *  - Sorgu id'leri yeniden yazılır; cevap id ile eşleştirilir.
 *  - Zaman aşımı kontrolü sadece bekleyen sorgu varken uyanır, boştayken hiç CPU harcanmaz.
 *  - Küçük LRU önbellek, tekrar eden sorgular ağa çıkmaz. Aynı anda bekleyen ÖZDEŞ sorgular tek sorguya birleşir.
 *  - Sıcak yolda tampon yeniden kullanılır; sorgu başına sadece küçük bir kayıt nesnesi ve anahtar metni oluşur.
 *
 * Sahte cevaplara karşı (RFC 5452):
 *  - Kimlik [SecureRandom] ile rastgele; cevabın kaynak adresi ve portu sunucununki olmalı.
 *  - Cevabın soru bölümü (ad, tür, sınıf) sorununkiyle aynı olmalı ([Dns.sameQuestion]); değilse atılır.
 *  - Kaynak portu sabit kalmaz: her yuva [rotateAfter] sorgudan sonra, üzerinde bekleyen sorgu kalmayınca yeni bir
 *    soket (yeni rastgele port) açar. Diğer yuva bu sırada trafiği taşır; böylece yoğun trafikte de port değişir.
 *
 * Sağlamlık:
 *  - [resetNetwork]: ağ değişince (Wi-Fi <-> mobil) soketleri yeniler, önbelleği boşaltır, bekleyen
 *    sorguları yeni soketlerden yeniden gönderir.
 *  - Alım hatası üst üste tekrarlarsa yuvanın soketi kendiliğinden yenilenir.
 *  - Yedek geçişi: birincil sunucu üst üste [FAILOVER_AFTER] sorguda zamanında cevap vermez ve ikincisi verirse,
 *    sonraki sorgular doğrudan ikinciye gider. Ağ değişince birincile dönülür.
 *  - Bozuk, kesik, sahte kaynaklı paketler sessizce atılır. Alım tamponuna sığmayan cevap "kesildi" (TC)
 *    işaretiyle iletilir ve önbelleğe alınmaz.
 *
 * [onPacket] tek bir thread'den (tünel okuyucu) çağrılmalıdır.
 */
class DnsForwarder(
    private val upstreams: List<InetSocketAddress>,
    private val writeToTun: (ByteArray, Int, Int) -> Unit,
    private val protect: (DatagramSocket) -> Boolean = { true },
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000 },
    /** İlk yeniden deneme gecikmesi. [ADAPTIVE] (varsayılan): ölçülen cevap süresinden ([MobilePolicy.dnsRetryMs]); testler sabit değer verebilir. */
    private val retryAfterMs: Long = ADAPTIVE,
    private val giveUpAfterMs: Long = 4000,
    private val sweepMs: Long = 50,
    cacheEntries: Int = 256,
    private val threadFactory: (Runnable, String) -> Thread =
        { r, name -> Thread(r, name).apply { isDaemon = true } },
    private val log: (String) -> Unit = {},
    /** Bir yuvanın kaç sorgudan sonra yeni bir kaynak portuna geçeceği. */
    private val rotateAfter: Int = ROTATE_AFTER,
) : Forwarder {

    override val proto: Proto get() = Proto.PLAIN

    /** Bir UDP soketi ve onun alıcı thread'i. Soket yenilenince [gen] artar. */
    private class Slot(val index: Int) {
        @Volatile var socket: DatagramSocket? = null
        @Volatile var gen = 0
        @Volatile var draining = false
        val inflight = AtomicInteger()
        val uses = AtomicInteger()
        var thread: Thread? = null
    }

    private class Pending(
        val key: String,
        val query: ByteArray,      // upstream id'si yazılmış DNS verisi (yeniden deneme için)
        val qEnd: Int,             // soru bölümünün sonu (cevap doğrulaması); -1: denetlenemez
        val addedOpt: Boolean,     // OPT kaydını biz ekledik: cevaptaki OPT istemciye verilmez
        val firstSentAt: Long,
        val slot: Slot,
        first: Waiter,
        @Volatile var firstIdx: Int,   // ilk gönderildiği sunucu (yeniden deneme diğerine gider)
    ) {
        @Volatile var sentAt: Long = firstSentAt
        @Volatile var attempt = 0
        val waiters = ArrayList<Waiter>(1).also { it.add(first) }   // [this] kilidiyle korunur
        var done = false                                          // [this] kilidiyle korunur
    }

    init {
        require(upstreams.isNotEmpty()) { "en az bir DNS sunucusu gerekli" }
    }

    private val slots = Array(SLOTS) { Slot(it) }
    private val slotLock = Any()
    @Volatile private var primaryIdx = 0
    private val streak = AtomicInteger()
    private val pending = ConcurrentHashMap<Int, Pending>()
    private val byKey = ConcurrentHashMap<String, Pending>()
    private val cache = DnsCache(cacheEntries, nowMs)
    private val random = SecureRandom()
    private val sweepScheduled = AtomicBoolean(false)
    private val scheduler: ScheduledExecutorService =
        Executors.newSingleThreadScheduledExecutor { r -> threadFactory(r, "dns-sweep") }
    @Volatile private var started = false
    @Volatile private var closed = false
    @Volatile private var lastTimeoutLog = 0L

    // yalnızca onPacket thread'i kullanır
    private val tunBuf = ByteArray(Packets.HDR6 + MAX_DNS)
    private val tunScratch = ByteArray(Packets.MTU)

    private val queries = AtomicLong()
    private val cacheHits = AtomicLong()
    private val forwarded = AtomicLong()
    private val answered = AtomicLong()
    private val retries = AtomicLong()
    private val timeouts = AtomicLong()
    private val dropped = AtomicLong()
    private val resets = AtomicLong()
    private val latencySum = AtomicLong()
    private val failovers = AtomicLong()
    private val blocked = AtomicLong()
    private val bytesUp = AtomicLong()
    private val bytesDown = AtomicLong()
    private val merged = AtomicLong()
    private val rejected = AtomicLong()
    private val ring = LatencyRing()
    private val rttEst = RttEstimator()
    private val parsed = ParsedQuery()

    override fun start() {
        check(!started) { "zaten başlatıldı" }
        started = true
        try {
            for (sl in slots) {
                sl.socket = newSocket()
                sl.thread = threadFactory(Runnable { receiveLoop(sl) }, "dns-recv-" + sl.index).also { it.start() }
            }
        } catch (e: Throwable) {
            close()   // kısmen açılmış soketler ve iş parçacıkları sızmasın
            throw e
        }
    }

    override fun stats() = Stats(
        queries.get(), cacheHits.get(), forwarded.get(), answered.get(), retries.get(),
        timeouts.get(), dropped.get(), resets.get(), latencySum.get(), failovers.get(), primaryIdx != 0, blocked.get(),
        bytesUp.get(), bytesDown.get(), merged.get(), rejected.get(),
    )

    override fun latencies(out: IntArray): Int = ring.copyTo(out)

    internal fun pendingCount() = pending.size
    internal fun localPort() = slots[0].socket?.localPort ?: -1
    internal fun localPorts(): List<Int> = slots.map { it.socket?.localPort ?: -1 }

    override fun clearCache() = cache.clear()

    /**
     * Ağ değişti (ör. Wi-Fi'den mobil veriye geçildi): eski soketler artık yanlış ağa bağlı olabilir.
     * Soketleri yeniler, önbelleği boşaltır (cevaplar ağa göre değişebilir) ve bekleyen
     * sorguları yeni soketlerden bir kez daha gönderir. Herhangi bir thread'den çağrılabilir.
     */
    override fun resetNetwork(reason: String) {
        if (closed || !started) return
        // Her yuva ayrı denenir: biri başarısız olsa bile (eski soketi yerinde kalır) ötekiler yenilenir ve sıfırlama tamamlanır.
        var renewed = 0
        synchronized(slotLock) {
            for (sl in slots) {
                try { rebind(sl); renewed++ } catch (e: IOException) { log("soket yenilenemedi: ${e.message}") }
            }
        }
        if (renewed == 0) return
        log("soket yenilendi ($reason, $renewed/${slots.size})")
        cache.clear()
        rttEst.reset()                       // yeni ağın gecikmesi eskisinden çok farklı olabilir
        primaryIdx = 0                       // yeni ağda önce yine birincil denenir
        streak.set(0)
        val now = nowMs()
        for (e in pending.values) {
            e.sentAt = now
            e.attempt = 0
            e.firstIdx = 0
            send(e.slot, e.query, upstreams[0])
        }
        resets.incrementAndGet()
        if (pending.isNotEmpty()) scheduleSweep()
    }

    private fun newSocket(): DatagramSocket {
        val s = DatagramSocket()
        if (!protect(s)) {
            s.close()
            throw IOException("protect() başarısız: soket tünel dışında tutulamadı")
        }
        try { s.receiveBufferSize = 64 * 1024 } catch (_: Exception) {}
        return s
    }

    /** [slotLock] altında: yuvaya yeni soket (yeni kaynak portu) takar, eskisini kapatır. */
    private fun rebind(sl: Slot) {
        if (closed) return
        val fresh = newSocket()
        val old = sl.socket
        sl.socket = fresh
        sl.gen++
        sl.uses.set(0)
        sl.draining = false
        try { old?.close() } catch (_: Exception) {}
    }

    /** Boşalan ve süresi dolan yuvanın portunu değiştirir. Üzerinde bekleyen sorgu varsa dokunmaz. */
    private fun rotate(sl: Slot) {
        synchronized(slotLock) {
            if (closed || !sl.draining || sl.inflight.get() > 0) return
            try { rebind(sl) } catch (_: IOException) { sl.draining = false; sl.uses.set(0) }
        }
    }

    private fun otherDraining(sl: Slot): Boolean {
        for (o in slots) if (o !== sl && o.draining) return true
        return false
    }

    /** Yeni sorgu için yuva: süresi dolmamış yuvalar arasından rastgele; hepsi boşalmayı bekliyorsa en az yüklü olan. */
    private fun pickSlot(): Slot {
        val a = slots[random.nextInt(SLOTS)]
        if (!a.draining) return a
        for (sl in slots) if (!sl.draining) return sl
        var best = slots[0]
        for (sl in slots) if (sl.inflight.get() < best.inflight.get()) best = sl
        return best
    }

    /** Tünelden okunan ham IP paketi. [p] çağrıdan sonra yeniden kullanılabilir; burada saklanmaz. */
    override fun onPacket(p: ByteArray, len: Int) {
        if (closed) return
        val q = parsed
        if (!q.parse(p, len, MAX_DNS)) return
        queries.incrementAndGet()
        val dnsOff = q.dnsOff
        val dnsLen = q.dnsLen
        val key = String(p, dnsOff + 2, dnsLen - 2, Charsets.ISO_8859_1)

        // 1) önbellek
        val n = cache.get(key, q.clientId, tunBuf, Packets.HDR)
        if (n > 0) {
            cacheHits.incrementAndGet()
            if (Dns.isBlocked(tunBuf, Packets.HDR, n)) blocked.incrementAndGet()
            q.writeCached(tunBuf, tunScratch, n, writeToTun)
            return
        }

        val waiter = q.waiter()

        // 2) aynı soru zaten yolda: istemciyi o sorguya ekle (istemcinin yeniden denemeleri ağa çıkmaz)
        val same = byKey[key]
        if (same != null) {
            synchronized(same) {
                if (!same.done && same.waiters.size < MAX_WAITERS) {
                    same.waiters.add(waiter)
                    merged.incrementAndGet()
                    return
                }
            }
        }

        // 3) yeni sorgu: upstream'e gönder
        if (pending.size >= MAX_PENDING) {
            dropped.incrementAndGet()
            return
        }
        // Gizlilik: istemciye ait EDNS seçenekleri (alt ağ, çerez, kimlik) atılır; "alt ağı iletme" işareti konur.
        val san = Dns.sanitizeQuery(p, dnsOff, dnsLen, pad = false, absentPayload = 512)
        if (san == null) { dropped.incrementAndGet(); return }
        val query = san.query
        val qEnd = Dns.questionEnd(query, 0, query.size)
        val first = primaryIdx
        val slot = pickSlot()
        val entry = Pending(key, query, qEnd, san.addedOpt, nowMs(), slot, waiter, first)
        var upId: Int
        do {
            upId = random.nextInt(65536)
        } while (pending.putIfAbsent(upId, entry) != null)
        Packets.put16(query, 0, upId)
        byKey[key] = entry
        slot.inflight.incrementAndGet()
        // Süresi dolan yuva yeni soru almaz ve boşalınca portunu değiştirir. Aynı anda yalnızca BİR yuva boşalmaya
        // alınır: diğeri trafiği taşırken bu yuva birkaç milisaniyede boşalır (yoğun trafikte de port değişir).
        if (slot.uses.incrementAndGet() >= rotateAfter && !otherDraining(slot)) slot.draining = true

        forwarded.incrementAndGet()
        bytesUp.addAndGet(query.size.toLong())
        // Gönderim hemen başarısızsa (ör. o IP ailesinin yolu yok) beklemeden öbür adrese gönderilir.
        if (!send(slot, query, upstreams[first]) && upstreams.size > 1) send(slot, query, upstreams[(first + 1) % upstreams.size])
        scheduleSweep()
    }

    /** Sorguyu gönderir. Hemen başarısız olursa (ör. IPv6 yolu yok: "ağa ulaşılamıyor") false döner. */
    private fun send(sl: Slot, data: ByteArray, to: InetSocketAddress): Boolean {
        val s = sl.socket ?: return false
        return try {
            s.send(DatagramPacket(data, data.size, to))
            true
        } catch (_: IOException) {
            // ağ yok olabilir ya da soket o an yenileniyor; zaman aşımı kontrolü ikinci denemeyi yapar
            false
        }
    }

    /** Sorgu bitti (cevap, zaman aşımı): kayıtlardan düş, yuvası boşaldıysa portunu değiştir. */
    private fun finish(e: Pending) {
        byKey.remove(e.key, e)
        val sl = e.slot
        if (sl.inflight.decrementAndGet() <= 0 && sl.draining) rotate(sl)
    }

    private fun receiveLoop(sl: Slot) {
        val buf = ByteArray(MAX_REPLY)
        val out = ByteArray(Packets.HDR6 + MAX_REPLY)
        val scratch = ByteArray(Packets.MTU)
        val pkt = DatagramPacket(buf, buf.size)
        var failures = 0
        while (!closed) {
            val s = sl.socket ?: return
            val gen = sl.gen
            try {
                pkt.length = buf.size
                s.receive(pkt)
                failures = 0
            } catch (e: IOException) {
                if (closed) return
                if (gen != sl.gen) continue                       // yeni soket takıldı, hemen dön
                failures++
                if (failures >= 5) {
                    failures = 0
                    try { synchronized(slotLock) { if (gen == sl.gen) rebind(sl) } } catch (_: IOException) {}
                    log("soket yenilendi (alım hatası: ${e.javaClass.simpleName})")
                }
                try { Thread.sleep(minOf(100L * (failures + 1), 1000L)) } catch (_: InterruptedException) { return }
                continue
            }
            var len = pkt.length
            if (len < Packets.DNS_HDR) continue
            val from = upstreamIndex(pkt)
            if (from < 0) continue                               // sahte kaynak
            val id = Packets.u16(buf, 0)
            val entry = pending[id] ?: continue
            if (!Dns.sameQuestion(entry.query, 0, entry.qEnd, buf, 0, len)) {
                rejected.incrementAndGet()                       // kimlik tuttu ama soru farklı: sahte ya da bozuk
                continue
            }
            if (!pending.remove(id, entry)) continue

            val truncated = len >= buf.size
            if (truncated) Dns.setTruncated(buf, 0) else len = CnameGuard.guard(buf, 0, len)      // gizli izleyici (CNAME) engeli
            answered.incrementAndGet()
            if (upstreams.size > 1) noteAnswer(entry, from)
            val took = maxOf(0L, nowMs() - entry.firstSentAt)
            if (entry.attempt == 0) rttEst.sample(took.toDouble())      // Karn: yeniden denenen sorgunun süresi güvenilir örnek değil
            latencySum.addAndGet(took)
            ring.add(took.coerceAtMost(LatencyRing.MAX_MS.toLong()).toInt())
            bytesDown.addAndGet(len.toLong())

            if (Dns.isBlocked(buf, len)) blocked.incrementAndGet()
            // İstemci EDNS istemediği halde biz OPT eklediysek cevaptaki OPT atılır (önbelleğe de böyle girer).
            val rlen = if (entry.addedOpt && !truncated) Dns.stripOpt(buf, 0, len) else len
            if (!truncated) {
                val ttl = Dns.cacheTtl(buf, rlen)
                if (ttl > 0) cache.put(entry.key, buf, rlen, ttl)
            }

            synchronized(entry) {
                entry.done = true
                for (w in entry.waiters) {
                    System.arraycopy(buf, 0, out, Packets.HDR, rlen)
                    w.deliver(out, scratch, rlen, writeToTun)      // istemcinin id'sini geri koyar
                }
            }
            finish(entry)
        }
    }

    /** Paketin geldiği sunucunun [upstreams] içindeki sırası; hiçbiri değilse -1 (sahte kaynak). */
    private fun upstreamIndex(pkt: DatagramPacket): Int {
        for (i in upstreams.indices) {
            val u = upstreams[i]
            if (u.port == pkt.port && u.address == pkt.address) return i
        }
        return -1
    }

    /**
     * Cevabın hangi sunucudan geldiğine bakar. Birincil sunucuya gönderilen sorgu ona değil diğerine
     * (yeniden denemeye) cevaplandıysa sayaç artar; üst üste [FAILOVER_AFTER] kez olursa yedek birincil olur.
     * Birincilden gelen her cevap sayacı sıfırlar, bu yüzden tek seferlik yavaşlık geçişe yol açmaz.
     */
    private fun noteAnswer(entry: Pending, from: Int) {
        val primary = primaryIdx
        if (from == entry.firstIdx) {
            if (from == primary) streak.set(0)
        } else if (entry.firstIdx == primary) {
            if (streak.incrementAndGet() >= FAILOVER_AFTER) {
                streak.set(0)
                primaryIdx = from
                failovers.incrementAndGet()
                log("yedek sunucuya geçildi")
            }
        }
    }

    /** Sadece bekleyen sorgu varken çalışır; boştayken hiç uyanmaz. */
    private fun scheduleSweep() {
        if (closed) return
        if (sweepScheduled.compareAndSet(false, true)) {
            try {
                scheduler.schedule({ sweep() }, sweepMs, TimeUnit.MILLISECONDS)
            } catch (_: RejectedExecutionException) {
                sweepScheduled.set(false)
            }
        }
    }

    private fun sweep() {
        sweepScheduled.set(false)
        val now = nowMs()
        val retryAt = if (retryAfterMs >= 0) retryAfterMs else MobilePolicy.dnsRetryMs(rttEst)
        val it = pending.entries.iterator()
        while (it.hasNext()) {
            val ent = it.next()
            val e = ent.value
            val age = now - e.sentAt
            if (age >= giveUpAfterMs) {
                // Anahtar + değerle sil: bu arada cevap gelip kimlik yeniden kullanıldıysa yeni girdiye dokunma, iki kez bitirme.
                if (!pending.remove(ent.key, e)) continue
                synchronized(e) { e.done = true }
                finish(e)
                timeouts.incrementAndGet()
                ring.add(LatencyRing.TIMEOUT)
                if (now - lastTimeoutLog > 5000) {
                    lastTimeoutLog = now
                    log("zaman aşımı (toplam ${timeouts.get()})")
                }
            } else if (e.attempt == 0 && age >= retryAt) {
                e.attempt = 1
                retries.incrementAndGet()
                // İlk gönderilenin dışındaki sunucuya, tek sunucu varsa aynısına bir kez daha dene.
                send(e.slot, e.query, upstreams[(e.firstIdx + 1) % upstreams.size])
            } else if (e.attempt == 1 && retryAfterMs < 0 && age >= retryAt * 3) {
                e.attempt = 2                  // uyarlanır kipte üçüncü deneme: ilk sunucuya geri dön (art arda kayıplara karşı)
                retries.incrementAndGet()
                send(e.slot, e.query, upstreams[e.firstIdx])
            }
        }
        if (pending.isNotEmpty()) scheduleSweep()
    }

    override fun close() {
        if (closed) return
        closed = true
        synchronized(slotLock) { for (sl in slots) try { sl.socket?.close() } catch (_: Exception) {} }
        scheduler.shutdownNow()
        for (sl in slots) sl.thread?.interrupt()
        pending.clear()
        byKey.clear()
        cache.clear()
    }

    companion object {
        /** Tünelden gelen DNS sorgusunun üst sınırı (UDP). */
        const val MAX_DNS = 4096

        /** Sunucudan kabul edilen en büyük cevap; daha büyüğü "kesildi" (TC) olarak iletilir. */
        const val MAX_REPLY = 16384

        /** Tek IP paketine sığan en büyük cevap (MTU 1500 - IPv4/UDP başlıkları); büyükleri parçalanır. */
        const val MAX_REPLY_ONE_PACKET = Packets.MTU - Packets.HDR

        /** Sel koruması: aynı anda bekleyebilecek en fazla sorgu. */
        const val MAX_PENDING = 1024

        /** Bekleyen tek sorguya eklenebilecek en fazla istemci. */
        const val MAX_WAITERS = 16

        /** Yedek sunucuya geçmek için birincilin üst üste kaç sorguda cevapsız kalması gerektiği. */
        const val FAILOVER_AFTER = 2

        /** Soket (kaynak portu) yuvası sayısı ve kaç sorguda bir port değiştiği. */
        const val SLOTS = 2
        const val ROTATE_AFTER = 64

        /** [retryAfterMs] için "ölçülen cevap süresinden türet". */
        const val ADAPTIVE = -1L
    }
}
