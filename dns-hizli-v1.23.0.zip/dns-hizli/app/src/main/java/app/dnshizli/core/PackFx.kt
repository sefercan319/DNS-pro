package app.dnshizli.core

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

/** Ses paketi animasyonlarının tetikleyicileri: her animasyonlu paketin her biri için ayrı bir animasyonu vardır (10 × 10 = 100). */
enum class FxSlot(val sec: Float, val atOrb: Boolean = false) {
    /** Ekrana dokunma (küçük). */ TAP(0.60f),
    /** Anahtar açma/kapama. */ TOGGLE(0.75f),
    /** Bağlanma kutlaması (büyük, küre merkezinde). */ CONNECT(1.30f, true),
    /** Bağlantı kesilmesi. */ DISCONNECT(1.05f, true),
    /** Hata. */ ERROR(0.95f, true),
    /** Bir işlemin tamamlanması (ör. test bitti). */ DONE(1.15f, true),
    /** Alt panel / sayfa açıldı (küçük). */ SHEET(0.70f),
    /** Geri dönüldü (küçük). */ BACK(0.60f),
    /** Bir seçenek ya da satır seçildi (küçük). */ SELECT(0.75f),
    /** Yenileme ya da ölçüm başladı (küre çevresinde). */ REFRESH(1.10f, true);
}

/**
 * Yeni ses paketlerinin animasyonları ([SoundPack.AQUA] … [SoundPack.SPACE], her biri için [FxSlot]'ların altısı).
 * Hepsi kod ile çizilir, önceden hazırlanmış yollar ve sabit tablolarla: kare başına bellek ayırmaz, rastgelelik kullanmaz
 * (aynı olay her zaman aynı görünür, test edilebilir). [x],[y] merkez, [s] boyut (dokunmada ≈44, kürede ≈1,8·yarıçap),
 * [t] 0..1 ilerleme. Renkler temadan bağımsız paket renkleridir; temanın vurgusu yalnızca Aqua paketinde karışır.
 */
object PackFx {
    private const val PI_F = 3.1415927f
    private const val TAU = 6.2831855f
    private val PAL0 = intArrayOf(M_BLUE, M_ORANGE, M_GREEN, M_YELLOW)
    private val PAL1 = intArrayOf(Y_LIME, Y_PINK, Y_ICE)
    private val PAL2 = intArrayOf(Y_PINK, Y_LIME, Y_ICE, Y_CHROME, Y_PINK)
    private val PAL3 = intArrayOf(Y_ICE, Y_PINK)
    private val PAL4 = intArrayOf(Y_PINK, Y_LIME, Y_ICE, Rgb.WHITE, Y_PINK, Y_LIME)
    private val PAL5 = intArrayOf(A_GREEN, A_TEAL, A_VIOLET, A_PINK)
    private val PAL7 = intArrayOf(L_BLUE, L_INDIGO, L_ICE, Rgb.WHITE)
    private val PAL6 = intArrayOf(R_YEL, R_RED, R_GRN, R_BLU)

    // Paket renkleri
    private const val ERR = 0xFFFF5252.toInt()
    private const val SKY = 0xFF7FDBFF.toInt(); private const val LIME = 0xFF9CE86B.toInt(); private const val SUN = 0xFFFFE066.toInt()
    private const val M_BLUE = 0xFF00A4EF.toInt(); private const val M_ORANGE = 0xFFF25022.toInt()
    private const val M_GREEN = 0xFF7FBA00.toInt(); private const val M_YELLOW = 0xFFFFB900.toInt()
    private const val E_GREEN = 0xFF4CAF50.toInt(); private const val E_LIGHT = 0xFF8BC34A.toInt(); private const val E_BROWN = 0xFF8D6E63.toInt()
    private const val E_FLY = 0xFFFFEB3B.toInt(); private const val E_PETAL = 0xFFF8BBD0.toInt()
    private const val Y_CHROME = 0xFFCFD8DC.toInt(); private const val Y_ICE = 0xFF80DEEA.toInt(); private const val Y_LIME = 0xFFC6FF00.toInt(); private const val Y_PINK = 0xFFFF4081.toInt()
    private const val A_GREEN = 0xFF69F0AE.toInt(); private const val A_TEAL = 0xFF18FFFF.toInt(); private const val A_VIOLET = 0xFFB388FF.toInt(); private const val A_PINK = 0xFFFF80AB.toInt()
    private const val R_YEL = 0xFFFFD54F.toInt(); private const val R_RED = 0xFFEF5350.toInt(); private const val R_GRN = 0xFF66BB6A.toInt(); private const val R_BLU = 0xFF42A5F5.toInt()
    private const val L_BLUE = 0xFF5AA8FF.toInt(); private const val L_INDIGO = 0xFF7B7CFF.toInt(); private const val L_ICE = 0xFFB8E4FF.toInt()
    private const val S_CYAN = 0xFF4DD0E1.toInt(); private const val S_ORANGE = 0xFFFFAB40.toInt(); private const val S_VIOLET = 0xFF7C4DFF.toInt()

    // Ortak şekiller
    private val star4 = GPath().apply {
        moveTo(0f, -1f); quadTo(0.12f, -0.12f, 1f, 0f); quadTo(0.12f, 0.12f, 0f, 1f)
        quadTo(-0.12f, 0.12f, -1f, 0f); quadTo(-0.12f, -0.12f, 0f, -1f); close()
    }
    private val leafP = GPath().apply {
        moveTo(0f, -1f); cubicTo(0.95f, -0.45f, 0.95f, 0.45f, 0f, 1f); cubicTo(-0.95f, 0.45f, -0.95f, -0.45f, 0f, -1f); close()
    }
    private val dropP = GPath().apply {
        moveTo(0f, -1f); cubicTo(0.2f, -0.5f, 0.8f, 0f, 0.8f, 0.4f); cubicTo(0.8f, 0.85f, 0.4f, 1f, 0f, 1f)
        cubicTo(-0.4f, 1f, -0.8f, 0.85f, -0.8f, 0.4f); cubicTo(-0.8f, 0f, -0.2f, -0.5f, 0f, -1f); close()
    }
    private val tmp = GPath()

    private fun cl(v: Float): Float = if (v < 0f) 0f else if (v > 1f) 1f else v
    private fun fr(v: Float): Float = v - floor(v)
    private fun col(c: Int, a: Float): Int = Rgb.alpha(c, cl(a))
    private fun rd(deg: Float): Float = deg * PI_F / 180f
    /** [a]..[b] aralığında 0..1 ilerleme. */
    private fun win(t: Float, a: Float, b: Float): Float = cl((t - a) / (b - a))

    private fun shape(g: Gfx, p: GPath, x: Float, y: Float, sx: Float, sy: Float, deg: Float, color: Int) {
        g.save(); g.translate(x, y); g.rotate(deg); g.scale(sx, sy); g.paint(color); g.path(p); g.restore()
    }
    private fun spark(g: Gfx, x: Float, y: Float, s: Float, deg: Float, color: Int) = shape(g, star4, x, y, s, s, deg, color)
    private fun ring(g: Gfx, x: Float, y: Float, r: Float, w: Float, color: Int) { g.strokeWidth(w); g.paint(color); g.strokeCircle(x, y, r) }
    private fun disc(g: Gfx, x: Float, y: Float, r: Float, color: Int) { g.paint(color); g.circle(x, y, r) }
    private fun seg(g: Gfx, x0: Float, y0: Float, x1: Float, y1: Float, w: Float, color: Int) { g.strokeWidth(w); g.paint(color); g.line(x0, y0, x1, y1) }
    private fun sq(g: Gfx, x: Float, y: Float, half: Float, color: Int) { g.paint(color); g.rect(x - half, y - half, x + half, y + half) }
    private fun bubble(g: Gfx, x: Float, y: Float, r: Float, a: Float) {
        disc(g, x, y, r, col(Rgb.WHITE, 0.16f * a)); ring(g, x, y, r, 1.2f, col(Rgb.WHITE, 0.8f * a))
        disc(g, x - r * 0.35f, y - r * 0.35f, r * 0.22f, col(Rgb.WHITE, 0.9f * a))
    }


    /** Yarım çember/yay: [a0] derece başlar, [sweep] derece süpürür (bellek ayırmaz, parçalı çizgi). */
    private fun arc(g: Gfx, x: Float, y: Float, r: Float, a0: Float, sweep: Float, w: Float, color: Int) {
        val n = 14
        var px = x + cos(rd(a0)) * r; var py = y + sin(rd(a0)) * r
        for (i in 1..n) {
            val a = rd(a0 + sweep * i / n); val nx = x + cos(a) * r; val ny = y + sin(a) * r
            seg(g, px, py, nx, ny, w, color); px = nx; py = ny
        }
    }
    /** Giderek çizilen onay işareti; [p] 0..1. */
    private fun tick(g: Gfx, x: Float, y: Float, s: Float, p: Float, w: Float, color: Int) {
        val a = win(p, 0f, 0.4f); val b = win(p, 0.4f, 1f)
        val x0 = x - s * 0.5f; val y0 = y; val x1 = x - s * 0.15f; val y1 = y + s * 0.38f; val x2 = x + s * 0.55f; val y2 = y - s * 0.4f
        if (a > 0f) seg(g, x0, y0, x0 + (x1 - x0) * a, y0 + (y1 - y0) * a, w, color)
        if (b > 0f) seg(g, x1, y1, x1 + (x2 - x1) * b, y1 + (y2 - y1) * b, w, color)
    }

    /** Bir animasyonu çizer. [pack] animasyonlu değilse ya da [t] aralık dışındaysa hiçbir şey çizmez. */
    fun draw(pack: SoundPack, slot: FxSlot, g: Gfx, th: AeroTheme, x: Float, y: Float, s: Float, t: Float) {
        if (!pack.animated || t <= 0f || t >= 1f) return
        g.save()
        when (pack) {
            SoundPack.AQUA -> aqua(slot, g, th, x, y, s, t)
            SoundPack.AERO -> aero(slot, g, x, y, s, t)
            SoundPack.METRO -> metro(slot, g, x, y, s, t)
            SoundPack.ECO -> eco(slot, g, x, y, s, t)
            SoundPack.Y2K -> y2k(slot, g, x, y, s, t)
            SoundPack.AURORA -> aurora(slot, g, x, y, s, t)
            SoundPack.RETRO -> retro(slot, g, x, y, s, t)
            SoundPack.SPACE -> space(slot, g, x, y, s, t)
            SoundPack.LIQUID -> liquid(slot, g, x, y, s, t)
            else -> {}
        }
        g.restore()
    }

    // ------------------------------------------------------------------ Aqua: su

    private fun aqua(slot: FxSlot, g: Gfx, th: AeroTheme, x: Float, y: Float, s: Float, t: Float) {
        val e = Easing.outCubic(t); val f = 1f - t
        when (slot) {
            FxSlot.TAP -> {   // damla düşer, halka açılır
                val fall = win(t, 0f, 0.32f)
                if (t < 0.34f) shape(g, dropP, x, y - s * 0.9f * (1f - fall * fall), s * 0.10f, s * 0.14f, 0f, col(th.accentLight, 1f))
                val u = win(t, 0.30f, 1f)
                if (u > 0f) {
                    ring(g, x, y, s * (0.12f + 0.72f * Easing.outCubic(u)), 2.6f * (1f - u) + 0.6f, col(th.accent, 1f - u))
                    ring(g, x, y, s * (0.05f + 0.45f * Easing.outCubic(u)), 1.4f, col(Rgb.WHITE, 0.8f * (1f - u)))
                }
            }
            FxSlot.TOGGLE -> {   // üç kabarcık yükselir
                for (i in 0 until 3) {
                    val u = win(t, i * 0.08f, 1f)
                    if (u <= 0f) continue
                    val bx = x + (i - 1) * s * 0.32f + sin(u * 9f + i * 2f) * s * 0.06f
                    bubble(g, bx, y - s * 1.15f * Easing.outCubic(u), s * (0.10f + 0.04f * i) * (1f - 0.3f * u), 1f - u * u)
                }
            }
            FxSlot.CONNECT -> {   // taç şeklinde sıçrama
                for (i in 0 until 3) {
                    val u = win(t, i * 0.12f, 1f)
                    if (u <= 0f) continue
                    ring(g, x, y, s * (0.3f + 0.75f * Easing.outCubic(u)), 3f * (1f - u) + 0.8f, col(if (i == 1) th.accentLight else th.accent, 1f - u))
                }
                for (i in 0 until 14) {
                    val ang = rd(-90f + (i - 6.5f) * 11.5f)
                    val v = s * (0.85f + 0.4f * fr(i * 0.618f))
                    val px = x + cos(ang) * v * t * 0.9f
                    val py = y + sin(ang) * v * t * 0.9f + s * 0.9f * t * t
                    shape(g, dropP, px, py, s * 0.05f * (1f - 0.4f * t), s * 0.075f * (1f - 0.4f * t), rd(i * 11.5f - 75f) + t * 90f, col(if (i % 2 == 0) th.accentLight else Rgb.WHITE, 1f - t * t))
                }
            }
            FxSlot.DISCONNECT -> {   // girdap: damlalar merkeze döner
                ring(g, x, y, s * (1f - 0.85f * e), 2.4f * f + 0.6f, col(th.accent, f))
                for (i in 0 until 10) {
                    val ang = rd(i * 36f + t * 540f)
                    val rr = s * (0.95f * (1f - e) + 0.05f)
                    shape(g, dropP, x + cos(ang) * rr, y + sin(ang) * rr, s * 0.06f * (1f - 0.5f * t), s * 0.09f * (1f - 0.5f * t), i * 36f + t * 540f + 90f, col(if (i % 3 == 0) Rgb.WHITE else th.accentLight, 1f - t * t))
                }
            }
            FxSlot.ERROR -> {   // titreyen kırmızı halkalar
                val sh = sin(t * 38f) * s * 0.05f * f
                for (i in 0 until 2) {
                    val u = win(t, i * 0.3f, 0.6f + i * 0.3f)
                    if (u <= 0f) continue
                    g.save(); g.translate(x + sh, y); g.scale(1f + 0.25f * (if (i == 0) 1f else -1f) * sin(u * PI_F), 1f); ring(g, 0f, 0f, s * (0.25f + 0.6f * Easing.outCubic(u)), 3f * (1f - u) + 1f, col(ERR, 1f - u)); g.restore()
                }
                for (i in 0 until 3) seg(g, x - s * 0.35f + sh * (i + 1), y + (i - 1) * s * 0.12f, x + s * 0.35f + sh * (i + 1), y + (i - 1) * s * 0.12f, 2.2f, col(ERR, 0.7f * f))
            }
            FxSlot.DONE -> {   // kabarcıklar yükselir ve patlar
                for (i in 0 until 8) {
                    val a0 = i * 0.07f
                    val u = win(t, a0, a0 + 0.7f)
                    if (u <= 0f) continue
                    val bx = x + (i - 3.5f) * s * 0.17f + sin(u * 7f + i) * s * 0.05f
                    val by = y - s * (0.2f + 0.7f * Easing.outCubic(u)) + s * 0.4f
                    val rr = s * (0.09f + 0.04f * fr(i * 0.37f))
                    if (u < 0.78f) bubble(g, bx, by, rr, 1f)
                    else {
                        val p = (u - 0.78f) / 0.22f
                        for (k in 0 until 6) { val ang = rd(k * 60f); seg(g, bx + cos(ang) * rr * (1f + p), by + sin(ang) * rr * (1f + p), bx + cos(ang) * rr * (1.6f + 1.4f * p), by + sin(ang) * rr * (1.6f + 1.4f * p), 1.4f, col(Rgb.WHITE, 1f - p)) }
                    }
                }
                ring(g, x, y + s * 0.3f, s * (0.2f + 0.8f * e), 1.6f, col(th.accentLight, 0.6f * f))
            }
            FxSlot.SHEET -> {   // dipten kabarcık perdesi yükselir
                for (i in 0 until 5) { val u = win(t, i * 0.06f, 1f); if (u > 0f) bubble(g, x + (i - 2) * s * 0.28f + sin(u * 8f + i) * s * 0.05f, y + s * 0.5f - s * 1.1f * Easing.outCubic(u), s * (0.07f + 0.02f * (i % 3)), 1f - u * u) }
                ring(g, x, y + s * 0.5f, s * (0.2f + 0.8f * e), 1.6f, col(th.accentLight, 0.7f * f))
            }
            FxSlot.BACK -> {   // dalga sola kayar
                for (i in 0 until 3) { val u = win(t, i * 0.1f, 1f); if (u > 0f) ring(g, x - s * 0.7f * Easing.outCubic(u), y, s * (0.5f - 0.3f * u), 2.2f * (1f - u) + 0.5f, col(if (i == 1) th.accentLight else th.accent, 1f - u)) }
                disc(g, x - s * 0.7f * e, y, s * 0.06f, col(Rgb.WHITE, f))
            }
            FxSlot.SELECT -> {   // kabarcığın içinde onay
                bubble(g, x, y, s * (0.3f + 0.1f * sin(PI_F * t)), 1f - win(t, 0.7f, 1f))
                tick(g, x, y, s * 0.3f, win(t, 0.1f, 0.6f), 2.6f, col(th.accent, 1f - win(t, 0.7f, 1f)))
            }
            FxSlot.REFRESH -> {   // damlalar küre çevresinde döner
                for (i in 0 until 8) { val a = rd(i * 45f + e * 300f); val r = s * (0.6f + 0.25f * e); shape(g, dropP, x + cos(a) * r, y + sin(a) * r, s * 0.045f, s * 0.07f, i * 45f + e * 300f + 90f, col(if (i % 2 == 0) th.accentLight else Rgb.WHITE, 1f - t * t)) }
                ring(g, x, y, s * (0.45f + 0.4f * e), 2f * f + 0.5f, col(th.accent, 0.8f * f))
            }
        }
    }

    // ------------------------------------------------------------------ Frutiger Aero: cam, gökyüzü, güneş

    private fun aero(slot: FxSlot, g: Gfx, x: Float, y: Float, s: Float, t: Float) {
        val e = Easing.outCubic(t); val f = 1f - t
        when (slot) {
            FxSlot.TAP -> {   // cam parıltısı
                val pop = sin(PI_F * cl(t * 1.1f))
                spark(g, x, y, s * 0.55f * pop, 15f + t * 40f, col(Rgb.WHITE, f + 0.2f))
                spark(g, x + s * 0.28f, y - s * 0.22f, s * 0.26f * pop, 45f - t * 60f, col(SKY, f))
                ring(g, x, y, s * (0.2f + 0.7f * e), 1.8f * f + 0.5f, col(SKY, 0.9f * f))
            }
            FxSlot.TOGGLE -> {   // yukarı süzülen ışık huzmesi
                val h = s * 1.3f * e
                for (i in 0 until 3) { val w = s * (0.07f + 0.05f * i); g.paint(col(SKY, (0.34f - 0.09f * i) * f)); g.rect(x - w, y - h, x + w, y) }
                disc(g, x, y, s * (0.16f + 0.1f * e), col(Rgb.WHITE, 0.6f * f))
                for (i in 0 until 4) bubble(g, x + (i - 1.5f) * s * 0.16f, y - h * (0.4f + 0.18f * i), s * 0.06f, f)
            }
            FxSlot.CONNECT -> {   // gün doğuşu
                disc(g, x, y, s * 0.55f * win(t, 0f, 0.25f) + s * 0.1f, col(Rgb.WHITE, 0.55f * (1f - win(t, 0.15f, 0.45f))))
                disc(g, x, y, s * (0.25f + 0.25f * e), col(SUN, 0.55f * f))
                for (i in 0 until 12) {
                    val ang = rd(i * 30f + t * 60f)
                    val r0 = s * (0.35f + 0.1f * e); val r1 = s * (0.5f + 0.75f * e)
                    seg(g, x + cos(ang) * r0, y + sin(ang) * r0, x + cos(ang) * r1, y + sin(ang) * r1, 3f * f + 0.6f, col(if (i % 2 == 0) SUN else Rgb.WHITE, 0.9f * f))
                }
                ring(g, x, y, s * (0.5f + 0.5f * e), 2.2f * f + 0.5f, col(SKY, f))
                for (i in 0 until 6) { val u = win(t, i * 0.05f, 1f); if (u > 0f) bubble(g, x + (i - 2.5f) * s * 0.3f, y + s * 0.4f - s * 1.1f * Easing.outCubic(u), s * (0.07f + 0.02f * (i % 3)), 1f - u) }
            }
            FxSlot.DISCONNECT -> {   // bulut kabarması
                for (i in 0 until 6) {
                    val ang = rd(i * 60f + 20f)
                    val d = s * 0.5f * e
                    disc(g, x + cos(ang) * d, y + sin(ang) * d + s * 0.35f * t * t, s * (0.18f + 0.2f * e), col(Rgb.WHITE, 0.45f * f))
                }
                disc(g, x, y + s * 0.2f * t, s * (0.25f + 0.25f * e), col(SKY, 0.3f * f))
                ring(g, x, y, s * (0.4f + 0.6f * e), 1.6f, col(SKY, 0.6f * f))
            }
            FxSlot.ERROR -> {   // cam çatlağı
                val len = Easing.outQuint(win(t, 0f, 0.5f))
                for (i in 0 until 7) {
                    val a0 = rd(i * 51.4f + 10f)
                    var px = x; var py = y
                    for (k in 1..3) {
                        val ang = a0 + (if ((i + k) % 2 == 0) 0.22f else -0.22f) * (if (k == 1) 0f else 1f)
                        val nx = px + cos(ang) * s * 0.28f * len; val ny = py + sin(ang) * s * 0.28f * len
                        seg(g, px, py, nx, ny, 2.2f - 0.5f * k, col(Rgb.WHITE, (1f - t) * 0.95f)); px = nx; py = ny
                    }
                }
                ring(g, x, y, s * (0.2f + 0.7f * e), 2.4f * f + 0.6f, col(0xFFFF8A65.toInt(), 0.9f * f))
            }
            FxSlot.DONE -> {   // parıltı yağmuru
                for (i in 0 until 14) {
                    val u = win(t, (i % 7) * 0.06f, 0.6f + (i % 7) * 0.06f)
                    if (u <= 0f) continue
                    val px = x + (i - 6.5f) * s * 0.14f + sin(u * 6f + i) * s * 0.04f
                    val py = y - s * 0.9f + s * 1.8f * Easing.outCubic(u) * 0.9f
                    spark(g, px, py, s * 0.12f * (0.6f + 0.4f * fr(i * 0.37f)) * sin(PI_F * u), i * 25f + u * 120f, col(if (i % 3 == 0) LIME else if (i % 3 == 1) SKY else Rgb.WHITE, 1f))
                }
            }
            FxSlot.SHEET -> {   // gökyüzü perdesi açılır, ışın saçılır
                for (i in 0 until 7) { val a = rd(-90f + (i - 3) * 22f); seg(g, x, y + s * 0.4f, x + cos(a) * s * 0.9f * e, y + s * 0.4f + sin(a) * s * 0.9f * e, 2f * f + 0.6f, col(SUN, 0.85f * f)) }
                disc(g, x, y + s * 0.4f, s * 0.14f * (1f - 0.4f * t), col(Rgb.WHITE, f))
            }
            FxSlot.BACK -> {   // bulut sola süzülür
                for (i in 0 until 3) { val u = win(t, i * 0.08f, 1f); if (u > 0f) { val cx = x + s * 0.5f - s * 1.1f * u; disc(g, cx, y + (i - 1) * s * 0.18f, s * (0.16f - 0.03f * i), col(Rgb.WHITE, 0.75f * (1f - u))); disc(g, cx + s * 0.12f, y + (i - 1) * s * 0.18f + s * 0.03f, s * 0.11f, col(SKY, 0.7f * (1f - u))) } }
            }
            FxSlot.SELECT -> {   // güneş parlaması ve onay
                spark(g, x, y, s * 0.55f * sin(PI_F * win(t, 0f, 0.7f)), t * 60f, col(SUN, 1f))
                tick(g, x, y, s * 0.28f, win(t, 0.15f, 0.6f), 2.6f, col(LIME, 1f - win(t, 0.7f, 1f)))
            }
            FxSlot.REFRESH -> {   // güneş halkası döner
                for (i in 0 until 10) { val a = rd(i * 36f + e * 240f); val r = s * (0.55f + 0.3f * e); spark(g, x + cos(a) * r, y + sin(a) * r, s * 0.1f * (1f - 0.5f * t), i * 36f, col(if (i % 2 == 0) SUN else SKY, 1f - t * t)) }
                ring(g, x, y, s * (0.4f + 0.5f * e), 2f * f + 0.5f, col(Rgb.WHITE, 0.8f * f))
            }
        }
    }

    // ------------------------------------------------------------------ Metro: düz karolar

    private fun metro(slot: FxSlot, g: Gfx, x: Float, y: Float, s: Float, t: Float) {
        val e = Easing.outCubic(t); val f = 1f - t
        val tiles = PAL0
        when (slot) {
            FxSlot.TAP -> {   // karo darbesi
                val h = s * (0.2f + 0.7f * e)
                sq(g, x, y, h, col(M_BLUE, 0.22f * f))
                g.strokeWidth(2.6f); g.paint(col(M_BLUE, f)); g.strokeRoundRect(x - h, y - h, x + h, y + h, 0f)
                for (i in 0 until 4) sq(g, x + (if (i % 2 == 0) -1f else 1f) * h, y + (if (i < 2) -1f else 1f) * h, s * 0.045f, col(M_ORANGE, f))
            }
            FxSlot.TOGGLE -> {   // kayan çubuklar
                for (i in 0 until 2) {
                    val u = win(t, i * 0.14f, 0.8f + i * 0.14f)
                    if (u <= 0f) continue
                    val cx = x - s * 1.3f + s * 2.6f * Easing.inOutCubic(u)
                    g.paint(col(if (i == 0) M_GREEN else M_ORANGE, 1f - u * u)); g.rect(cx - s * 0.5f, y + (i - 0.5f) * s * 0.24f - s * 0.06f, cx + s * 0.5f, y + (i - 0.5f) * s * 0.24f + s * 0.06f)
                    sq(g, cx + s * 0.62f, y + (i - 0.5f) * s * 0.24f, s * 0.06f, col(M_BLUE, 1f - u * u))
                }
            }
            FxSlot.CONNECT -> {   // 3x3 karo çevrilir
                val cell = s * 0.5f
                for (j in 0 until 3) for (i in 0 until 3) {
                    val u = win(t, (i + j) * 0.07f, 0.45f + (i + j) * 0.07f)
                    val sx = abs(cos(PI_F * u))
                    val a = if (t > 0.75f) (1f - t) / 0.25f else 1f
                    g.save(); g.translate(x + (i - 1) * cell * 1.08f, y + (j - 1) * cell * 1.08f); g.scale(maxOf(sx, 0.04f), 1f)
                    g.paint(col(tiles[(i + j * 3) % 4], a * (if (u <= 0f) 0f else 1f))); g.rect(-cell * 0.46f, -cell * 0.46f, cell * 0.46f, cell * 0.46f)
                    g.restore()
                }
            }
            FxSlot.DISCONNECT -> {   // karolar merkeze çöker
                for (i in 0 until 4) {
                    val cx = (if (i % 2 == 0) -1f else 1f) * s * 0.85f * (1f - e)
                    val cy = (if (i < 2) -1f else 1f) * s * 0.85f * (1f - e)
                    sq(g, x + cx, y + cy, s * 0.17f * (1f - 0.6f * t), col(tiles[i], 1f - t * t))
                }
                sq(g, x, y, s * 0.12f * win(t, 0.6f, 0.85f) * (1f - win(t, 0.85f, 1f)), col(Rgb.WHITE, 1f))
            }
            FxSlot.ERROR -> {   // bloklar sarsılır
                val sh = sin(t * 32f) * s * 0.22f * f
                for (i in 0 until 3) {
                    g.paint(col(M_ORANGE, 0.95f * f)); g.rect(x - s * 0.5f + sh * (if (i == 1) -1f else 1f), y + (i - 1) * s * 0.2f - s * 0.07f, x + s * 0.5f + sh * (if (i == 1) -1f else 1f), y + (i - 1) * s * 0.2f + s * 0.07f)
                }
                if (fr(t * 4f) < 0.5f) { g.strokeWidth(2.4f); g.paint(col(M_ORANGE, f)); g.strokeRoundRect(x - s * 0.7f, y - s * 0.7f, x + s * 0.7f, y + s * 0.7f, 0f) }
            }
            FxSlot.DONE -> {   // onay karosu
                val k = Easing.outBack(win(t, 0f, 0.4f), 1.6f)
                val a = 1f - win(t, 0.8f, 1f)
                sq(g, x, y, s * 0.55f * k, col(M_GREEN, a))
                val p = win(t, 0.25f, 0.65f)
                val x0 = x - s * 0.25f; val y0 = y; val x1 = x - s * 0.05f; val y1 = y + s * 0.22f; val x2 = x + s * 0.3f; val y2 = y - s * 0.2f
                if (p > 0f) {
                    val p1 = cl(p * 2f); val p2 = cl(p * 2f - 1f)
                    g.strokeWidth(5f); g.paint(col(Rgb.WHITE, a))
                    g.line(x0, y0, x0 + (x1 - x0) * p1, y0 + (y1 - y0) * p1)
                    if (p2 > 0f) g.line(x1, y1, x1 + (x2 - x1) * p2, y1 + (y2 - y1) * p2)
                }
            }
            FxSlot.SHEET -> {   // karolar sağdan kayarak dizilir
                for (i in 0 until 4) { val u = Easing.outCubic(win(t, i * 0.08f, 0.6f)); val a = 1f - win(t, 0.7f, 1f); sq(g, x + s * 0.6f * (1f - u) + (i % 2) * s * 0.0f, y + (i - 1.5f) * s * 0.3f, s * 0.12f, col(PAL0[i], a * u)) }
            }
            FxSlot.BACK -> {   // karolar sola çekilir
                for (i in 0 until 4) { val u = win(t, i * 0.07f, 0.85f); sq(g, x - s * 0.7f * u * u, y + (i - 1.5f) * s * 0.3f, s * 0.12f * (1f - 0.5f * u), col(PAL0[i], 1f - u)) }
            }
            FxSlot.SELECT -> {   // karo çevrilir
                val flip = cos(PI_F * win(t, 0f, 0.5f)); val hw = s * 0.3f * (if (flip < 0f) -flip else flip)
                g.paint(col(if (t < 0.25f) M_BLUE else M_GREEN, 1f - win(t, 0.75f, 1f))); g.rect(x - hw, y - s * 0.3f, x + hw, y + s * 0.3f)
                tick(g, x, y, s * 0.22f, win(t, 0.4f, 0.8f), 3f, col(Rgb.WHITE, 1f - win(t, 0.8f, 1f)))
            }
            FxSlot.REFRESH -> {   // dört karo kare çevresinde dönüş
                for (i in 0 until 4) { val a = rd(i * 90f + 45f + Easing.inOutCubic(t) * 360f); val r = s * 0.62f; sq(g, x + cos(a) * r, y + sin(a) * r, s * 0.11f, col(PAL0[i], 1f - win(t, 0.75f, 1f))) }
                ring(g, x, y, s * 0.3f * sin(PI_F * t), 2f, col(Rgb.WHITE, 0.7f * f))
            }
        }
    }

    // ------------------------------------------------------------------ Frutiger Eco: doğa

    private fun eco(slot: FxSlot, g: Gfx, x: Float, y: Float, s: Float, t: Float) {
        val e = Easing.outCubic(t); val f = 1f - t
        when (slot) {
            FxSlot.TAP -> {   // filiz
                val k = Easing.outBack(win(t, 0f, 0.5f), 1.5f)
                val a = 1f - win(t, 0.7f, 1f)
                val top = y - s * 0.7f * k
                seg(g, x, y, x, top, 2.6f, col(E_GREEN, a))
                shape(g, leafP, x + s * 0.12f * k, top + s * 0.04f, s * 0.07f * k, s * 0.17f * k, 55f, col(E_LIGHT, a))
                shape(g, leafP, x - s * 0.11f * k, top + s * 0.08f, s * 0.06f * k, s * 0.14f * k, -55f, col(E_GREEN, a))
                ring(g, x, y, s * (0.1f + 0.35f * e), 1.4f, col(E_LIGHT, 0.7f * f))
            }
            FxSlot.TOGGLE -> {   // yaprak taç yapraklar saçılır
                for (i in 0 until 5) {
                    val ang = rd(i * 72f - 90f + t * 40f)
                    shape(g, leafP, x + cos(ang) * s * 0.9f * e, y + sin(ang) * s * 0.9f * e, s * 0.1f * (1f - 0.3f * t), s * 0.2f * (1f - 0.3f * t), i * 72f + t * 200f, col(E_PETAL, 1f - t * t))
                }
                disc(g, x, y, s * 0.1f * f, col(E_FLY, f))
            }
            FxSlot.CONNECT -> {   // sarmaşık büyür
                val grow = Easing.outCubic(win(t, 0f, 0.7f))
                val a = 1f - win(t, 0.8f, 1f)
                val n = 12
                var px = x; var py = y + s * 0.6f
                for (i in 1..n) {
                    val u = i / n.toFloat()
                    if (u > grow) break
                    val nx = x + sin(i * 0.7f + t * 3f) * s * 0.12f * u
                    val ny = y + s * 0.6f - s * 1.7f * u
                    seg(g, px, py, nx, ny, 3f - 1.2f * u, col(E_GREEN, a))
                    if (i % 3 == 0) {
                        val side = if ((i / 3) % 2 == 0) 1f else -1f
                        val lg = cl((grow - u) * 4f + 0.2f)
                        shape(g, leafP, nx + side * s * 0.1f, ny, s * 0.07f * lg, s * 0.15f * lg, side * 60f, col(if (i % 2 == 0) E_LIGHT else E_GREEN, a))
                    }
                    px = nx; py = ny
                }
                for (i in 0 until 8) {
                    val ang = i * 0.785f + t * 3f
                    val d = s * (0.5f + 0.25f * sin(i * 1.7f + t * 5f))
                    val fx = x + cos(ang) * d; val fy = y + sin(ang) * d * 0.7f - s * 0.1f
                    disc(g, fx, fy, s * 0.07f, col(E_FLY, 0.25f * a)); disc(g, fx, fy, s * 0.025f, col(E_FLY, a))
                }
                ring(g, x, y + s * 0.6f, s * (0.2f + 0.7f * e), 2f * f + 0.5f, col(E_LIGHT, 0.8f * f))
            }
            FxSlot.DISCONNECT -> {   // düşen yapraklar
                for (i in 0 until 8) {
                    val u = win(t, (i % 4) * 0.05f, 0.85f + (i % 4) * 0.05f)
                    if (u <= 0f) continue
                    val ang = rd(i * 45f)
                    val px = x + cos(ang) * s * 0.5f + sin(u * 6f + i) * s * 0.12f
                    val py = y + sin(ang) * s * 0.35f - s * 0.2f + s * 1.1f * u * u
                    shape(g, leafP, px, py, s * 0.08f, s * 0.17f, i * 45f + u * 280f * (if (i % 2 == 0) 1f else -1f), col(if (i % 3 == 0) E_BROWN else if (i % 3 == 1) E_LIGHT else E_GREEN, 1f - u * u))
                }
            }
            FxSlot.ERROR -> {   // solan bitki
                val grow = Easing.outCubic(win(t, 0f, 0.35f))
                val droop = win(t, 0.25f, 0.8f)
                val a = 1f - win(t, 0.8f, 1f)
                var px = x; var py = y + s * 0.5f
                for (i in 1..8) {
                    val u = i / 8f
                    if (u > grow) break
                    val nx = x + droop * s * 0.5f * u * u
                    val ny = y + s * 0.5f - s * 0.85f * u + droop * s * 0.4f * u * u * u
                    seg(g, px, py, nx, ny, 2.8f - u, col(if (droop > 0.5f) E_BROWN else E_GREEN, a)); px = nx; py = ny
                }
                shape(g, leafP, px, py + s * 0.04f + droop * s * 0.5f * droop, s * 0.1f, s * 0.2f, 160f * droop, col(E_BROWN, a))
                for (i in 0 until 6) { val u = win(t, 0.3f + i * 0.04f, 1f); if (u > 0f) disc(g, x + (i - 2.5f) * s * 0.14f, y + s * 0.5f + s * 0.35f * u, s * 0.03f, col(E_BROWN, 0.8f * (1f - u))) }
            }
            FxSlot.DONE -> {   // ateş böcekleri
                val a = 1f - win(t, 0.8f, 1f)
                for (i in 0 until 10) {
                    val ph = i * 0.63f
                    val fx = x + sin(ph + t * 5f) * s * (0.35f + 0.55f * fr(i * 0.381f))
                    val fy = y + sin(ph * 1.7f + t * 4f + 1f) * s * (0.25f + 0.45f * fr(i * 0.727f)) - s * 0.3f * e
                    val pulse = 0.55f + 0.45f * sin(t * 14f + i)
                    disc(g, fx, fy, s * 0.09f, col(E_FLY, 0.22f * a * pulse)); disc(g, fx, fy, s * 0.03f, col(Rgb.WHITE, a * pulse))
                }
            }
            FxSlot.SHEET -> {   // yapraklar yükselip açılır
                for (i in 0 until 5) { val u = win(t, i * 0.06f, 1f); if (u > 0f) shape(g, leafP, x + (i - 2) * s * 0.26f, y + s * 0.5f - s * 0.9f * Easing.outCubic(u), s * 0.07f, s * 0.15f, (i - 2) * 22f * u, col(if (i % 2 == 0) E_GREEN else E_LIGHT, 1f - u * u)) }
            }
            FxSlot.BACK -> {   // yaprak sola savrulur
                for (i in 0 until 3) { val u = win(t, i * 0.1f, 1f); if (u > 0f) shape(g, leafP, x + s * 0.4f - s * 1.0f * u, y + sin(u * 7f + i) * s * 0.15f + (i - 1) * s * 0.15f, s * 0.07f, s * 0.14f, -90f + u * 200f, col(if (i == 1) E_BROWN else E_LIGHT, 1f - u)) }
            }
            FxSlot.SELECT -> {   // filiz büyür
                seg(g, x, y + s * 0.4f, x, y + s * 0.4f - s * 0.6f * e, 2.4f, col(E_GREEN, 1f - win(t, 0.75f, 1f)))
                val u = win(t, 0.3f, 0.9f)
                shape(g, leafP, x - s * 0.14f * u, y - s * 0.1f, s * 0.08f * u, s * 0.17f * u, -50f, col(E_LIGHT, 1f - win(t, 0.8f, 1f)))
                shape(g, leafP, x + s * 0.14f * u, y - s * 0.1f, s * 0.08f * u, s * 0.17f * u, 50f, col(E_GREEN, 1f - win(t, 0.8f, 1f)))
            }
            FxSlot.REFRESH -> {   // yapraklar çember çizer, ateşböceği yanar
                for (i in 0 until 8) { val a = rd(i * 45f + e * 270f); val r = s * (0.55f + 0.25f * e); shape(g, leafP, x + cos(a) * r, y + sin(a) * r, s * 0.06f, s * 0.12f, i * 45f + e * 270f + 90f, col(if (i % 2 == 0) E_GREEN else E_LIGHT, 1f - t * t)) }
                disc(g, x + cos(rd(t * 700f)) * s * 0.2f, y + sin(rd(t * 500f)) * s * 0.2f, s * 0.05f, col(E_FLY, 0.9f * f))
            }
        }
    }

    // ------------------------------------------------------------------ Y2K: krom ve buz

    private fun y2k(slot: FxSlot, g: Gfx, x: Float, y: Float, s: Float, t: Float) {
        val e = Easing.outCubic(t); val f = 1f - t
        when (slot) {
            FxSlot.TAP -> {   // krom yıldız
                val pop = sin(PI_F * cl(t * 1.05f))
                spark(g, x, y, s * 0.7f * pop, t * 90f, col(Rgb.WHITE, 1f))
                spark(g, x, y, s * 0.45f * pop, 45f - t * 90f, col(Y_CHROME, 0.95f))
                ring(g, x, y, s * (0.2f + 0.75f * e), 1.6f * f + 0.4f, col(Y_ICE, 0.9f * f))
            }
            FxSlot.TOGGLE -> {   // yörünge noktaları
                ring(g, x, y, s * 0.6f, 1f, col(Y_ICE, 0.45f * f))
                val colors = PAL1
                for (i in 0 until 3) {
                    val ang = rd(t * 420f + i * 120f)
                    disc(g, x + cos(ang) * s * 0.6f, y + sin(ang) * s * 0.6f * 0.8f, s * 0.09f * (1f - 0.4f * t), col(colors[i], 1f - t * t))
                }
            }
            FxSlot.CONNECT -> {   // mercek parlaması
                val len = s * (0.2f + 2.4f * e)
                g.paint(col(Rgb.WHITE, f)); g.roundRect(x - len, y - 2f, x + len, y + 2f, 2f)
                g.paint(col(Y_ICE, 0.5f * f)); g.roundRect(x - len * 0.7f, y - 5f, x + len * 0.7f, y + 5f, 5f)
                val cols = PAL2
                for (i in 0 until 5) {
                    val px = x + (i - 2f) * s * 0.55f * e
                    disc(g, px, y, s * (0.07f + 0.05f * (i % 3)), col(cols[i], 0.4f * f))
                    ring(g, px, y, s * (0.1f + 0.06f * (i % 3)), 1.2f, col(Rgb.WHITE, 0.6f * f))
                }
                for (i in 0 until 8) { val ang = rd(i * 45f + t * 50f); seg(g, x + cos(ang) * s * 0.25f, y + sin(ang) * s * 0.25f, x + cos(ang) * s * (0.4f + 0.7f * e), y + sin(ang) * s * (0.4f + 0.7f * e), 2f, col(Rgb.WHITE, 0.8f * f)) }
                ring(g, x, y, s * (0.3f + 0.7f * e), 3f * f + 0.6f, col(Y_CHROME, f))
                spark(g, x, y, s * 0.5f * sin(PI_F * cl(t * 1.2f)), t * 60f, col(Rgb.WHITE, 1f))
            }
            FxSlot.DISCONNECT -> {   // parazit taraması
                val colors = PAL3
                for (i in 0 until 6) {
                    val dx = sin(t * 38f + i * 1.7f) * s * 0.25f * f
                    val yy = y + (i - 2.5f) * s * 0.17f
                    val w = s * (0.5f + 0.5f * fr(i * 0.618f)) * (1f - 0.5f * e)
                    g.paint(col(colors[i % 2], 0.85f * f)); g.rect(x - w + dx + e * s * (if (i % 2 == 0) 0.6f else -0.6f), yy - s * 0.035f, x + w + dx + e * s * (if (i % 2 == 0) 0.6f else -0.6f), yy + s * 0.035f)
                }
                g.paint(col(Rgb.WHITE, 0.6f * f)); g.rect(x - s * 0.9f, y - 1f, x + s * 0.9f, y + 1f)
            }
            FxSlot.ERROR -> {   // RGB ayrışması
                val j = sin(t * 52f) * s * 0.07f * f
                val r0 = s * (0.45f + 0.4f * e)
                ring(g, x - j, y, r0, 3f * f + 1f, col(Y_PINK, 0.9f * f))
                ring(g, x + j, y, r0, 3f * f + 1f, col(Y_ICE, 0.9f * f))
                ring(g, x, y + j, r0, 2f * f + 0.6f, col(Rgb.WHITE, 0.7f * f))
                for (i in 0 until 4) {
                    val bx = x + (fr(i * 0.37f) - 0.5f) * s * 1.4f + j * 3f; val by = y + (fr(i * 0.71f) - 0.5f) * s * 1.2f
                    if (fr(t * 6f + i * 0.3f) < 0.6f) { g.paint(col(if (i % 2 == 0) Y_PINK else Y_ICE, 0.8f * f)); g.rect(bx, by, bx + s * 0.16f, by + s * 0.05f) }
                }
            }
            FxSlot.DONE -> {   // halka büzülür, pastel parıltılar saçılır
                val c = Easing.outCubic(win(t, 0f, 0.4f))
                if (t < 0.5f) ring(g, x, y, s * (1f - 0.6f * c), 3.5f * (1f - win(t, 0f, 0.5f)) + 0.6f, col(Y_CHROME, 1f - win(t, 0.3f, 0.5f)))
                val u = win(t, 0.35f, 1f)
                val pc = PAL4
                for (i in 0 until 6) {
                    val ang = rd(i * 60f + 15f)
                    spark(g, x + cos(ang) * s * 0.9f * Easing.outCubic(u), y + sin(ang) * s * 0.9f * Easing.outCubic(u), s * 0.2f * sin(PI_F * u), u * 180f, col(pc[i], 1f))
                }
            }
            FxSlot.SHEET -> {   // krom çizgi yükselir, yıldızlar saçılır
                seg(g, x - s * 0.6f * e, y + s * 0.4f, x + s * 0.6f * e, y + s * 0.4f, 3f * f + 0.8f, col(Y_CHROME, f))
                for (i in 0 until 4) { val u = win(t, 0.1f + i * 0.07f, 1f); if (u > 0f) spark(g, x + (i - 1.5f) * s * 0.3f, y + s * 0.4f - s * 0.8f * u, s * 0.13f, u * 120f, col(PAL1[i % 3], 1f - u)) }
            }
            FxSlot.BACK -> {   // krom ok sola
                for (i in 0 until 3) { val u = win(t, i * 0.08f, 1f); val cx = x + s * 0.3f - s * 0.9f * u; val a = col(PAL3[i % 2], 1f - u); seg(g, cx + s * 0.15f, y - s * 0.2f, cx, y, 2.6f, a); seg(g, cx, y, cx + s * 0.15f, y + s * 0.2f, 2.6f, a) }
            }
            FxSlot.SELECT -> {   // buz kristali parlar
                spark(g, x, y, s * 0.5f * sin(PI_F * t), t * 90f, col(Y_ICE, 1f)); spark(g, x, y, s * 0.3f * sin(PI_F * t), -t * 90f, col(Rgb.WHITE, 1f))
                tick(g, x, y, s * 0.22f, win(t, 0.2f, 0.65f), 2.4f, col(Y_LIME, 1f - win(t, 0.75f, 1f)))
            }
            FxSlot.REFRESH -> {   // krom halka dönerken yıldızlar
                for (i in 0 until 6) { val a = rd(i * 60f + e * 360f); val r = s * 0.7f; spark(g, x + cos(a) * r, y + sin(a) * r, s * 0.14f * (1f - 0.4f * t), t * 180f, col(PAL2[i % 5], 1f - t * t)) }
                ring(g, x, y, s * (0.3f + 0.5f * e), 3f * f + 0.6f, col(Y_CHROME, 0.9f * f))
            }
        }
    }

    // ------------------------------------------------------------------ Aurora: ışık perdeleri

    private fun aurora(slot: FxSlot, g: Gfx, x: Float, y: Float, s: Float, t: Float) {
        val e = Easing.outCubic(t); val f = 1f - t
        val cols = PAL5
        when (slot) {
            FxSlot.TAP -> {   // yumuşak çiçeklenme
                for (k in 0 until 4) disc(g, x, y, s * (0.15f + 0.22f * k) * (0.5f + e), col(if (k % 2 == 0) A_TEAL else A_GREEN, 0.2f * f / (k + 1) * 2f))
                spark(g, x, y, s * 0.3f * sin(PI_F * t), t * 70f, col(Rgb.WHITE, f + 0.1f))
            }
            FxSlot.TOGGLE -> {   // şerit
                val head = win(t, 0f, 0.6f)
                var px = x - s * 0.7f; var py = y
                for (i in 1..14) {
                    val u = i / 14f
                    if (u > head) break
                    val nx = x - s * 0.7f + s * 1.4f * u
                    val ny = y + sin(u * 9f + t * 8f) * s * 0.18f
                    seg(g, px, py, nx, ny, 3.4f, col(cols[(i / 4) % 3], (0.9f - 0.5f * (head - u)) * (1f - win(t, 0.6f, 1f))))
                    px = nx; py = ny
                }
            }
            FxSlot.CONNECT -> {   // kutup ışığı perdeleri
                val a = 1f - win(t, 0.75f, 1f)
                val bottom = y + s * 0.7f
                for (i in 0 until 7) {
                    val cx = x + (i - 3f) * s * 0.28f
                    val h = (s * 0.9f * e + sin(i * 0.9f + t * 6f) * s * 0.22f) * win(t, i * 0.02f, 0.5f)
                    for (k in 0 until 3) {
                        val w = s * (0.12f - 0.03f * k)
                        g.paint(col(cols[i % 3], (0.14f + 0.12f * k) * a)); g.rect(cx - w, bottom - h * (1f - 0.3f * k), cx + w, bottom)
                    }
                }
                for (i in 0 until 12) {
                    val sx = x + (fr(i * 0.618f) - 0.5f) * s * 2.2f; val sy = y - s * 0.9f + fr(i * 0.381f) * s * 1.2f
                    spark(g, sx, sy, s * 0.06f * (0.5f + 0.5f * sin(t * 12f + i)), 0f, col(Rgb.WHITE, a))
                }
            }
            FxSlot.DISCONNECT -> {   // sönen dalgalar
                for (i in 0 until 4) {
                    val u = win(t, i * 0.15f, 1f)
                    if (u <= 0f) continue
                    g.save(); g.translate(x, y + s * 0.2f * u); g.scale(1f, 0.45f)
                    ring(g, 0f, 0f, s * (0.2f + 0.9f * Easing.outCubic(u)), 3f * (1f - u) + 0.6f, col(if (i % 2 == 0) A_VIOLET else A_PINK, 1f - u))
                    g.restore()
                }
                disc(g, x, y, s * 0.2f * f, col(A_VIOLET, 0.5f * f))
            }
            FxSlot.ERROR -> {   // kızıl titreşim
                val flick = 0.5f + 0.5f * sin(t * 40f)
                val sh = sin(t * 26f) * s * 0.06f * f
                val bottom = y + s * 0.6f
                for (i in 0 until 5) {
                    val cx = x + (i - 2f) * s * 0.3f + sh
                    val h = s * (0.5f + 0.25f * sin(i * 1.3f + t * 9f)) * win(t, 0f, 0.2f)
                    for (k in 0 until 3) { val w = s * (0.1f - 0.025f * k); g.paint(col(if (i % 2 == 0) ERR else A_PINK, (0.16f + 0.12f * k) * flick * f * 1.4f)); g.rect(cx - w, bottom - h * (1f - 0.3f * k), cx + w, bottom) }
                }
            }
            FxSlot.DONE -> {   // yıldız yağmuru
                for (i in 0 until 9) {
                    val u = win(t, i * 0.05f, 0.65f + i * 0.05f)
                    if (u <= 0f) continue
                    val px = x - s * 0.9f + (i % 9) * s * 0.22f + s * 0.4f * Easing.outCubic(u)
                    val py = y - s * 0.9f + s * 1.5f * Easing.outCubic(u)
                    seg(g, px, py, px - s * 0.14f, py - s * 0.24f, 2f, col(cols[i % 4], 0.8f * (1f - u)))
                    spark(g, px, py, s * 0.1f * sin(PI_F * u), u * 90f, col(Rgb.WHITE, 1f))
                }
            }
            FxSlot.SHEET -> {   // ışık perdesi yukarı açılır
                for (i in 0 until 5) { val u = win(t, i * 0.05f, 0.9f); val xx = x + (i - 2) * s * 0.2f; seg(g, xx, y + s * 0.5f, xx + sin(u * 5f + i) * s * 0.08f, y + s * 0.5f - s * 1.0f * Easing.outCubic(u), 5f * f + 1f, col(PAL5[i % 4], 0.6f * (1f - u * u))) }
            }
            FxSlot.BACK -> {   // perde sola çekilir
                for (i in 0 until 4) { val u = win(t, i * 0.06f, 1f); val xx = x + s * 0.4f - s * 0.9f * u; seg(g, xx, y - s * 0.4f, xx + s * 0.05f, y + s * 0.4f, 4f * (1f - u) + 0.8f, col(PAL5[i], 0.7f * (1f - u))) }
            }
            FxSlot.SELECT -> {   // ışık dalgası ve onay
                for (i in 0 until 2) { val u = win(t, i * 0.15f, 1f); if (u > 0f) ring(g, x, y, s * (0.15f + 0.6f * Easing.outCubic(u)), 3f * (1f - u) + 0.6f, col(PAL5[i * 2], 0.8f * (1f - u))) }
                tick(g, x, y, s * 0.26f, win(t, 0.1f, 0.6f), 2.6f, col(A_GREEN, 1f - win(t, 0.75f, 1f)))
            }
            FxSlot.REFRESH -> {   // renkli yaylar küre çevresinde döner
                for (i in 0 until 4) arc(g, x, y, s * (0.5f + 0.12f * i), i * 90f + e * 400f * (if (i % 2 == 0) 1f else -1f), 110f, 4f * f + 1f, col(PAL5[i], 0.85f * f))
            }
        }
    }

    // ------------------------------------------------------------------ Retro: 8 bit

    private fun retro(slot: FxSlot, g: Gfx, x: Float, y: Float, s: Float, t: Float) {
        val q = s * 0.09f
        fun snap(v: Float): Float = floor(v / q + 0.5f) * q
        val blink = if (t > 0.7f) (if (fr(t * 10f) < 0.5f) 1f else 0f) else 1f
        val pal = PAL6
        val e = Easing.outCubic(t)
        when (slot) {
            FxSlot.TAP -> {   // piksel patlaması
                for (i in 0 until 8) {
                    val ang = rd(i * 45f)
                    sq(g, snap(x + cos(ang) * s * 0.9f * e), snap(y + sin(ang) * s * 0.9f * e), q * 0.5f, col(pal[i % 4], blink))
                }
                sq(g, snap(x), snap(y), q * 0.5f * (1f - t), col(Rgb.WHITE, blink))
            }
            FxSlot.TOGGLE -> {   // dönen jeton
                val jy = y - s * 1.0f * 4f * t * (1f - t)
                val sx = maxOf(abs(cos(t * PI_F * 6f)), 0.12f)
                g.save(); g.translate(snap(x), snap(jy)); g.scale(sx, 1f)
                g.paint(col(R_YEL, blink)); g.rect(-q * 1.5f, -q * 2.5f, q * 1.5f, q * 2.5f); g.rect(-q * 2.5f, -q * 1.5f, q * 2.5f, q * 1.5f)
                g.paint(col(0xFFFFF59D.toInt(), blink)); g.rect(-q * 0.5f, -q * 1.5f, q * 0.5f, q * 1.5f)
                g.restore()
            }
            FxSlot.CONNECT -> {   // piksel havai fişek
                val rise = win(t, 0f, 0.35f)
                if (t < 0.35f) {
                    val ry = y + s * 0.8f - s * 1.2f * Easing.outCubic(rise)
                    sq(g, snap(x), snap(ry), q * 0.6f, col(Rgb.WHITE, 1f))
                    for (k in 1..3) sq(g, snap(x), snap(ry + k * q * 1.6f), q * 0.4f, col(R_YEL, 1f - k * 0.3f))
                } else {
                    val u = win(t, 0.35f, 1f)
                    val cy = y - s * 0.4f
                    for (ringI in 0 until 3) for (i in 0 until 8) {
                        val ang = rd(i * 45f + ringI * 22f)
                        val d = s * (0.3f + 0.35f * ringI) * Easing.outCubic(u)
                        val px = snap(x + cos(ang) * d); val py = snap(cy + sin(ang) * d + s * 0.5f * u * u * (ringI + 1) * 0.4f)
                        sq(g, px, py, q * 0.5f, col(pal[(i + ringI) % 4], if (u > 0.75f) (if (fr(u * 12f) < 0.5f) 1f else 0f) else 1f))
                    }
                }
            }
            FxSlot.DISCONNECT -> {   // piksel dağılması
                val cell = q * 1.7f
                for (j in 0 until 6) for (i in 0 until 6) {
                    val thr = ((i * 7 + j * 13) % 36) / 36f * 0.7f + 0.1f
                    if (t > thr + 0.15f) continue
                    val fall = if (t > thr) (t - thr) / 0.15f else 0f
                    sq(g, snap(x + (i - 2.5f) * cell), snap(y + (j - 2.5f) * cell + fall * s * 0.4f), cell * 0.45f, col(if ((i + j) % 2 == 0) R_BLU else Rgb.WHITE, 1f - fall))
                }
            }
            FxSlot.ERROR -> {   // piksel X
                if (fr(t * 3f) < 0.65f) {
                    for (k in -2..2) {
                        sq(g, snap(x + k * q * 1.8f), snap(y + k * q * 1.8f), q * 0.75f, col(R_RED, 1f))
                        sq(g, snap(x + k * q * 1.8f), snap(y - k * q * 1.8f), q * 0.75f, col(R_RED, 1f))
                    }
                }
                for (i in 0 until 4) sq(g, snap(x + (if (i % 2 == 0) -1f else 1f) * s * 0.75f), snap(y + (if (i < 2) -1f else 1f) * s * 0.75f), q * 0.5f, col(R_YEL, 1f - t))
            }
            FxSlot.DONE -> {   // seviye atlama
                for (i in 0 until 3) {
                    val u = win(t, i * 0.12f, 0.7f + i * 0.12f)
                    if (u <= 0f) continue
                    val sx = x + (i - 1) * s * 0.55f; val sy = y - s * 0.9f * Easing.outCubic(u) + s * 0.3f
                    val a = 1f - win(u, 0.7f, 1f)
                    sq(g, snap(sx), snap(sy), q * 0.5f, col(if (i == 1) Rgb.WHITE else R_YEL, a))
                    for (k in 0 until 4) sq(g, snap(sx + (if (k % 2 == 0) (if (k < 2) -1f else 1f) else 0f) * q * 1.2f), snap(sy + (if (k % 2 == 1) (if (k < 2) -1f else 1f) else 0f) * q * 1.2f), q * 0.5f, col(R_YEL, a))
                }
                for (i in 0 until 5) {
                    val u = win(t, 0.1f + i * 0.05f, 0.8f)
                    if (u > 0f) sq(g, snap(x + (i - 2f) * q * 2f), snap(y + s * 0.6f - s * 0.6f * u), q * 0.6f, col(R_GRN, 1f - u))
                }
            }
            FxSlot.SHEET -> {   // piksel merdiveni yükselir
                for (i in 0 until 5) { val u = win(t, i * 0.07f, 0.8f); if (u > 0f) sq(g, snap(x + (i - 2) * q * 2f), snap(y + s * 0.5f - q * 2f * i * u), q * 0.8f, col(PAL6[i % 4], 1f - win(t, 0.7f, 1f))) }
            }
            FxSlot.BACK -> {   // piksel ok sola
                for (i in 0 until 4) { val u = win(t, i * 0.06f, 0.9f); sq(g, snap(x + s * 0.4f - s * 0.9f * u), snap(y + (i - 1.5f) * q * 2f), q * 0.7f, col(PAL6[i], 1f - u)) }
            }
            FxSlot.SELECT -> {   // piksel onay işareti
                val a = 1f - win(t, 0.75f, 1f); val k = (win(t, 0f, 0.5f) * 5f).toInt()
                for (i in 0 until k) { val px = if (i < 2) -2 + i else -1 + (i - 1); val py = if (i < 2) i else 2 - (i - 1) * 1; sq(g, snap(x + px * q * 1.6f), snap(y + py * q * 1.6f), q * 0.7f, col(R_GRN, a)) }
                if (fr(t * 6f) < 0.6f) sq(g, snap(x), snap(y - s * 0.5f), q * 0.5f, col(R_YEL, a))
            }
            FxSlot.REFRESH -> {   // dönen piksel halka
                for (i in 0 until 8) { val a = rd(i * 45f + snap(e * 360f)); sq(g, snap(x + cos(a) * s * 0.65f), snap(y + sin(a) * s * 0.65f), q * (if (i == (t * 8f).toInt() % 8) 1.2f else 0.7f), col(PAL6[i % 4], 1f - win(t, 0.7f, 1f))) }
            }
        }
    }

    // ------------------------------------------------------------------ Uzay

    private fun space(slot: FxSlot, g: Gfx, x: Float, y: Float, s: Float, t: Float) {
        val e = Easing.outCubic(t); val f = 1f - t
        when (slot) {
            FxSlot.TAP -> {   // sonar
                for (i in 0 until 2) { val u = win(t, i * 0.2f, 1f); if (u > 0f) ring(g, x, y, s * (0.1f + 0.85f * Easing.outCubic(u)), 2.2f * (1f - u) + 0.5f, col(S_CYAN, 1f - u)) }
                val ang = rd(t * 300f - 90f)
                seg(g, x, y, x + cos(ang) * s * 0.8f, y + sin(ang) * s * 0.8f, 1.6f, col(S_CYAN, 0.7f * f))
                disc(g, x, y, s * 0.05f, col(Rgb.WHITE, f))
            }
            FxSlot.TOGGLE -> {   // kuyruklu yıldız
                val hx = x - s * 1.0f + s * 2.0f * e; val hy = y - s * 0.3f + s * 0.3f * e
                for (k in 8 downTo 1) {
                    val u = k * 0.045f
                    disc(g, hx - s * 2.0f * u * 1.0f * (1f - 0.2f * e), hy - s * 0.3f * u, s * 0.08f * (1f - k / 9f), col(S_ORANGE, 0.5f * (1f - k / 9f) * f))
                }
                disc(g, hx, hy, s * 0.11f, col(S_ORANGE, 0.35f * f)); disc(g, hx, hy, s * 0.06f, col(Rgb.WHITE, f))
            }
            FxSlot.CONNECT -> {   // ışık hızına geçiş
                val a = 1f - win(t, 0.7f, 1f)
                for (i in 0 until 28) {
                    val ang = rd(i * 12.857f + (i % 2) * 3f)
                    val r0 = s * (0.12f + 0.9f * fr(i * 0.618f) * e * e)
                    val r1 = r0 + s * (0.05f + 0.9f * e * e) * (0.5f + 0.5f * fr(i * 0.31f))
                    seg(g, x + cos(ang) * r0, y + sin(ang) * r0, x + cos(ang) * r1, y + sin(ang) * r1, 1.6f + (i % 3) * 0.5f, col(if (i % 3 == 0) S_CYAN else Rgb.WHITE, a))
                }
                disc(g, x, y, s * 0.5f * (1f - win(t, 0f, 0.4f)), col(Rgb.WHITE, 0.8f * (1f - win(t, 0f, 0.4f))))
                ring(g, x, y, s * (0.2f + 0.9f * e), 2.6f * f + 0.6f, col(S_VIOLET, 0.9f * f))
            }
            FxSlot.DISCONNECT -> {   // kapanış
                for (i in 0 until 4) { val rr = s * (0.25f * (i + 1)) * (1f - 0.85f * e); ring(g, x, y, rr, 2f, col(S_CYAN, f * (1f - i * 0.18f))) }
                val flat = win(t, 0.55f, 0.85f)
                g.paint(col(Rgb.WHITE, 0.9f * (1f - win(t, 0.85f, 1f)))); g.rect(x - s * 0.7f * (1f - flat) - 2f, y - s * 0.05f * (1f - flat) - 1f, x + s * 0.7f * (1f - flat) + 2f, y + s * 0.05f * (1f - flat) + 1f)
            }
            FxSlot.ERROR -> {   // kırmızı alarm
                val pulse = 1f + 0.12f * sin(t * 30f)
                val a = if (fr(t * 3f) < 0.7f) f + 0.1f else 0.25f * f
                g.save(); g.translate(x, y); g.scale(pulse, pulse)
                g.strokeWidth(3.4f); g.paint(col(ERR, a))
                g.line(0f, -s * 0.6f, s * 0.55f, s * 0.4f); g.line(s * 0.55f, s * 0.4f, -s * 0.55f, s * 0.4f); g.line(-s * 0.55f, s * 0.4f, 0f, -s * 0.6f)
                g.line(0f, -s * 0.2f, 0f, s * 0.12f); disc(g, 0f, s * 0.25f, s * 0.035f, col(ERR, a))
                g.restore()
                ring(g, x, y, s * (0.5f + 0.5f * e), 2f * f + 0.5f, col(ERR, 0.6f * f))
            }
            FxSlot.DONE -> {   // yörünge tamamlandı
                g.save(); g.translate(x, y); g.rotate(-20f)
                tmp.reset()
                for (i in 0..40) { val ang = i / 40f * TAU; val px = cos(ang) * s * 0.9f; val py = sin(ang) * s * 0.4f; if (i == 0) tmp.moveTo(px, py) else tmp.lineTo(px, py) }
                tmp.close()
                g.strokeWidth(1.4f); g.paint(col(S_CYAN, 0.55f * f)); g.strokePath(tmp)
                val u = Easing.inOutCubic(win(t, 0f, 0.75f))
                val ang = u * TAU - 1.5708f
                for (k in 6 downTo 1) { val a2 = ang - k * 0.12f; disc(g, cos(a2) * s * 0.9f, sin(a2) * s * 0.4f, s * 0.045f * (1f - k / 7f), col(S_ORANGE, 0.5f * (1f - k / 7f) * f)) }
                disc(g, cos(ang) * s * 0.9f, sin(ang) * s * 0.4f, s * 0.07f, col(Rgb.WHITE, f + 0.2f))
                g.restore()
                val fl = win(t, 0.7f, 1f)
                if (fl > 0f) { spark(g, x, y, s * 0.4f * sin(PI_F * fl), fl * 90f, col(Rgb.WHITE, 1f)); ring(g, x, y, s * 0.9f * fl, 2f * (1f - fl) + 0.5f, col(S_VIOLET, 1f - fl)) }
            }
            FxSlot.SHEET -> {   // yıldızlar yükselir
                for (i in 0 until 6) { val u = win(t, i * 0.05f, 1f); if (u > 0f) spark(g, x + (i - 2.5f) * s * 0.2f, y + s * 0.5f - s * (0.7f + 0.3f * fr(i * 0.618f)) * Easing.outCubic(u), s * 0.08f, u * 90f, col(if (i % 2 == 0) Rgb.WHITE else S_CYAN, 1f - u)) }
            }
            FxSlot.BACK -> {   // geri itici izi
                val hx = x + s * 0.5f - s * 1.0f * e
                for (k in 6 downTo 1) disc(g, hx + s * 0.12f * k, y, s * 0.06f * (1f - k / 7f), col(S_ORANGE, 0.5f * (1f - k / 7f) * f))
                disc(g, hx, y, s * 0.07f, col(Rgb.WHITE, f))
            }
            FxSlot.SELECT -> {   // radar kilidi
                ring(g, x, y, s * (0.7f - 0.4f * e), 1.8f, col(S_CYAN, f)); ring(g, x, y, s * 0.15f, 1.4f, col(Rgb.WHITE, f))
                for (i in 0 until 4) { val a = rd(i * 90f); seg(g, x + cos(a) * s * 0.3f, y + sin(a) * s * 0.3f, x + cos(a) * s * (0.55f - 0.2f * e), y + sin(a) * s * (0.55f - 0.2f * e), 1.8f, col(S_ORANGE, f)) }
            }
            FxSlot.REFRESH -> {   // yörünge taraması
                arc(g, x, y, s * 0.8f, e * 540f - 90f, 120f, 3f, col(S_CYAN, 0.9f * f)); arc(g, x, y, s * 0.55f, -e * 360f, 90f, 2f, col(S_VIOLET, 0.9f * f))
                disc(g, x + cos(rd(e * 540f + 30f)) * s * 0.8f, y + sin(rd(e * 540f + 30f)) * s * 0.8f, s * 0.06f, col(Rgb.WHITE, f))
            }
        }
    }

    // ------------------------------------------------------------------ Liquid Glass: yarı saydam cam, beyaz parıltı

    /** Cam mercek: yarı saydam dolgu, ince kenar ve sol üstte beyaz parıltı yayı. */
    private fun lens(g: Gfx, x: Float, y: Float, r: Float, a: Float, tint: Int) {
        if (r <= 0.5f || a <= 0f) return
        disc(g, x, y, r, col(tint, 0.20f * a)); ring(g, x, y, r, 1.4f, col(Rgb.WHITE, 0.55f * a))
        arc(g, x, y, r * 0.78f, 200f, 70f, 2.4f, col(Rgb.WHITE, 0.95f * a))
        disc(g, x - r * 0.38f, y - r * 0.42f, r * 0.10f, col(Rgb.WHITE, 0.9f * a))
    }

    private fun liquid(slot: FxSlot, g: Gfx, x: Float, y: Float, s: Float, t: Float) {
        val e = Easing.outCubic(t); val f = 1f - t
        when (slot) {
            FxSlot.TAP -> {   // cam damla yayılır
                lens(g, x, y, s * (0.10f + 0.40f * e), f, L_BLUE)
                val u = win(t, 0.2f, 1f)
                if (u > 0f) ring(g, x, y, s * (0.2f + 0.7f * Easing.outCubic(u)), 1.8f * (1f - u) + 0.5f, col(L_ICE, 0.8f * (1f - u)))
            }
            FxSlot.TOGGLE -> {   // iki cam damla birleşir
                val k = Easing.inOutCubic(win(t, 0f, 0.6f)); val d = s * 0.4f * (1f - k)
                lens(g, x - d, y, s * 0.24f, 1f - win(t, 0.7f, 1f), L_BLUE); lens(g, x + d, y, s * 0.24f, 1f - win(t, 0.7f, 1f), L_INDIGO)
                if (k > 0.8f) lens(g, x, y, s * (0.3f + 0.3f * win(t, 0.6f, 1f)), 1f - win(t, 0.6f, 1f), L_ICE)
            }
            FxSlot.CONNECT -> {   // cam halkalar dışa açılır, parıltı süpürür
                for (i in 0 until 3) { val u = win(t, i * 0.12f, 1f); if (u > 0f) { ring(g, x, y, s * (0.3f + 0.8f * Easing.outCubic(u)), 3.4f * (1f - u) + 0.8f, col(PAL7[i], 0.9f * (1f - u))); ring(g, x, y, s * (0.28f + 0.8f * Easing.outCubic(u)), 1.2f, col(Rgb.WHITE, 0.7f * (1f - u))) } }
                lens(g, x, y, s * (0.25f + 0.35f * e), f, L_BLUE)
                arc(g, x, y, s * 0.7f, t * 720f - 60f, 60f, 3f, col(Rgb.WHITE, 0.9f * f))
                for (i in 0 until 10) { val a = rd(i * 36f + 10f); val v = s * (0.5f + 0.7f * e); disc(g, x + cos(a) * v, y + sin(a) * v, s * 0.04f * f + 0.6f, col(L_ICE, f)) }
            }
            FxSlot.DISCONNECT -> {   // cam küre büzülüp söner
                val r = s * (0.7f - 0.55f * e)
                lens(g, x, y, r, 1f - win(t, 0.7f, 1f), L_INDIGO)
                for (i in 0 until 2) ring(g, x, y, s * (0.9f - 0.5f * e) + i * s * 0.12f, 1.6f, col(L_ICE, 0.6f * f * (1f - i * 0.4f)))
            }
            FxSlot.ERROR -> {   // kırmızı camsı titreşim
                val a = if (fr(t * 3f) < 0.7f) f + 0.1f else 0.25f * f
                val sh = sin(t * 40f) * s * 0.04f * f
                lens(g, x + sh, y, s * 0.55f, a, ERR)
                g.strokeWidth(3.4f); g.paint(col(Rgb.WHITE, a)); g.line(x + sh, y - s * 0.22f, x + sh, y + s * 0.06f); disc(g, x + sh, y + s * 0.2f, s * 0.04f, col(Rgb.WHITE, a))
                ring(g, x, y, s * (0.55f + 0.45f * e), 2f * f + 0.5f, col(ERR, 0.6f * f))
            }
            FxSlot.DONE -> {   // cam onay damlası
                lens(g, x, y, s * (0.15f + 0.45f * Easing.outBack(win(t, 0f, 0.5f))), 1f - win(t, 0.8f, 1f), L_BLUE)
                tick(g, x, y, s * 0.3f, win(t, 0.2f, 0.65f), 4f, col(Rgb.WHITE, 1f - win(t, 0.8f, 1f)))
                val fl = win(t, 0.6f, 1f)
                if (fl > 0f) { spark(g, x + s * 0.5f, y - s * 0.5f, s * 0.2f * sin(PI_F * fl), fl * 90f, col(Rgb.WHITE, 1f)); ring(g, x, y, s * (0.6f + 0.4f * fl), 2f * (1f - fl) + 0.4f, col(L_ICE, 1f - fl)) }
            }
            FxSlot.SHEET -> {   // cam panel aşağıdan süzülür
                val u = Easing.outCubic(win(t, 0f, 0.7f)); val a = 1f - win(t, 0.7f, 1f)
                val yy = y + s * 0.5f * (1f - u)
                g.paint(col(L_BLUE, 0.22f * a)); g.rect(x - s * 0.6f, yy - s * 0.25f, x + s * 0.6f, yy + s * 0.25f)
                seg(g, x - s * 0.6f, yy - s * 0.25f, x + s * 0.6f, yy - s * 0.25f, 2f, col(Rgb.WHITE, 0.9f * a))
                seg(g, x - s * 0.45f, yy - s * 0.17f, x - s * 0.1f, yy - s * 0.17f, 2.4f, col(Rgb.WHITE, 0.8f * a))
            }
            FxSlot.BACK -> {   // cam damla sola kayar, iz bırakır
                val hx = x + s * 0.5f - s * 1.0f * e
                for (k in 5 downTo 1) disc(g, hx + s * 0.13f * k, y, s * 0.12f * (1f - k / 6f), col(L_ICE, 0.45f * (1f - k / 6f) * f))
                lens(g, hx, y, s * 0.2f, f, L_BLUE)
            }
            FxSlot.SELECT -> {   // mercek büyüme ve onay
                val pop = sin(PI_F * win(t, 0f, 0.6f))
                lens(g, x, y, s * (0.2f + 0.2f * pop), 1f - win(t, 0.75f, 1f), L_INDIGO)
                tick(g, x, y, s * 0.2f, win(t, 0.15f, 0.55f), 2.8f, col(Rgb.WHITE, 1f - win(t, 0.75f, 1f)))
            }
            FxSlot.REFRESH -> {   // cam yaylar döner, küçük mercekler yörüngede
                arc(g, x, y, s * 0.75f, e * 500f, 100f, 3.4f, col(L_ICE, 0.9f * f)); arc(g, x, y, s * 0.55f, -e * 380f + 90f, 80f, 2.4f, col(L_INDIGO, 0.9f * f))
                for (i in 0 until 3) { val a = rd(e * 500f + i * 120f); lens(g, x + cos(a) * s * 0.75f, y + sin(a) * s * 0.75f, s * 0.09f, f, L_BLUE) }
            }
        }
    }
}
