package app.dnshizli.core

/**
 * DPI atlatma: bir bağlantının İLK uçuşunu (TLS ClientHello ya da HTTP isteği) ayrıştırır ve ağdaki derin paket denetimi
 * (DPI) cihazları şaşırsın diye parçalara böler. Hepsi sıradan soketlerle yapılabilen (kök gerektirmeyen) yöntemlerdir;
 * sahte paket / düşük TTL / bozuk sağlama toplamı gibi ham soket gerektirenler bilerek yoktur.
 *
 * Yöntemler (TLS): 0 = bayt 1'de ve SNI ortasında TCP bölme; 1 = ClientHello'yu iki TLS kaydına böl (+ TCP bölme);
 * 2 = SNI ortasında bölme + araya 1 bayt acil (OOB) veri (sunucu atar, DPI akışa katar); 3 = 1+2 birlikte.
 * Yöntemler (HTTP): 0 = Host başlığının içinde bölme; 1 = "hOsT" harf karışımı + bölme; 2 = iki nokta sonrası sekme + bölme;
 * 3 = metot içinde bölme + harf karışımı.
 * Hepsi sunucuya göre anlamca aynı veriyi taşır. Otomatik mod, çalışmayan yöntemde bir sonrakine geçer ([Planner]).
 */
internal object Dpi {
    const val NONE = 0
    const val TLS = 1
    const val HTTP = 2

    const val TLS_PLANS = 8
    const val HTTP_PLANS = 7

    /** TLS yöntemlerinin deneme sırası (bkz. [Planner]). 5 = mikro parçalama, 6 = üç kayıt, 7 = kayıt bölme + düşük TTL. */
    val TLS_ORDER = intArrayOf(1, 0, 5, 3, 2, 6, 7, 4)

    /** Eski (v1.12 ve öncesi) yöntem kümesi: yalnızca karşılaştırma / ölçüm içindir ([TLS_ORDER_OLD] ile aynı sırayla). */
    val TLS_ORDER_OLD = intArrayOf(1, 0, 3, 2, 4)
    const val HTTP_PLANS_OLD = 4

    /** DNS'i atlatan bilinen DoH sağlayıcı adları (Reklam+ DNS açıkken engeller: tarayıcı sistem DNS'ine döner). Alt alan adları da kapsanır. */
    private val DOH_HOSTS = listOf(
        // Google, Cloudflare, Quad9, OpenDNS
        "dns.google", "dns.google.com", "cloudflare-dns.com", "one.one.one.one", "dns.cloudflare.com", "1dot1dot1dot1.cloudflare-dns.com",
        "dns.quad9.net", "dns9.quad9.net", "dns10.quad9.net", "dns11.quad9.net", "dns12.quad9.net",
        "doh.opendns.com", "dns.opendns.com", "doh.familyshield.opendns.com",
        // AdGuard, NextDNS, DNS.SB, CleanBrowsing, ControlD, Mullvad
        "dns.adguard.com", "dns.adguard-dns.com", "dns-family.adguard.com", "dns-unfiltered.adguard.com", "family.adguard-dns.com", "unfiltered.adguard-dns.com",
        "dns.nextdns.io", "doh.dns.sb", "dns.sb", "doh.cleanbrowsing.org", "dns.controld.com", "freedns.controld.com", "doh.mullvad.net", "dns.mullvad.net",
        // diğer kamu / kâr amacı gütmeyen sağlayıcılar
        "doh.libredns.gr", "dns.alidns.com", "doh.pub", "dot.pub", "dns.twnic.tw", "doh.applied-privacy.net", "dns.digitale-gesellschaft.ch", "dnsforge.de",
        "doh.dnslify.com", "dns0.eu", "dns.switch.ch", "doh.ffmuc.net", "doh.tiarap.org", "jp.tiar.app", "doh.li", "dns.containerpi.com", "dns.rubyfish.cn",
        "blahdns.com", "dns.therifleman.name", "wikimedia-dns.org", "doh.xfinity.com", "dns.bebasid.com", "doh.360.cn",
    )

    /** [host] bilinen bir DoH sağlayıcısı mı (kendisi ya da alt alanı)? */
    fun isDohHost(host: String): Boolean = DOH_HOSTS.any { host == it || host.endsWith(".$it") }

    /** Bilinen DoH/DoT sağlayıcılarının IPv4 adresleri: SNI olmadan (ya da IP ile) HTTPS'e bağlanan uygulamalar için. */
    private val DOH_V4 = intArrayOf(
        Packets.ip(8, 8, 8, 8), Packets.ip(8, 8, 4, 4), Packets.ip(1, 1, 1, 1), Packets.ip(1, 0, 0, 1), Packets.ip(1, 1, 1, 2), Packets.ip(1, 0, 0, 2),
        Packets.ip(1, 1, 1, 3), Packets.ip(1, 0, 0, 3), Packets.ip(9, 9, 9, 9), Packets.ip(149, 112, 112, 112), Packets.ip(9, 9, 9, 10), Packets.ip(149, 112, 112, 10),
        Packets.ip(9, 9, 9, 11), Packets.ip(149, 112, 112, 11), Packets.ip(208, 67, 222, 222), Packets.ip(208, 67, 220, 220), Packets.ip(208, 67, 222, 123), Packets.ip(208, 67, 220, 123),
        Packets.ip(94, 140, 14, 14), Packets.ip(94, 140, 15, 15), Packets.ip(94, 140, 14, 140), Packets.ip(94, 140, 14, 141), Packets.ip(94, 140, 14, 15), Packets.ip(94, 140, 15, 16),
        Packets.ip(185, 228, 168, 9), Packets.ip(185, 228, 169, 9), Packets.ip(185, 228, 168, 168), Packets.ip(185, 228, 169, 168), Packets.ip(76, 76, 2, 0), Packets.ip(76, 76, 10, 0),
        Packets.ip(185, 222, 222, 222), Packets.ip(45, 11, 45, 11), Packets.ip(194, 242, 2, 2), Packets.ip(194, 242, 2, 3), Packets.ip(193, 110, 81, 0), Packets.ip(185, 253, 5, 0),
    )

    /** Aynı sağlayıcıların IPv6 adresleri (sabit değerler; ad çözümlemesi yapılmaz). */
    private val DOH_V6: List<ByteArray> = listOf(
        "2001:4860:4860::8888", "2001:4860:4860::8844", "2606:4700:4700::1111", "2606:4700:4700::1001", "2606:4700:4700::1112", "2606:4700:4700::1002",
        "2606:4700:4700::1113", "2606:4700:4700::1003", "2620:fe::fe", "2620:fe::9", "2620:fe::10", "2620:fe::fe:10", "2620:fe::11", "2620:fe::fe:11",
        "2620:119:35::35", "2620:119:53::53", "2a10:50c0::ad1:ff", "2a10:50c0::ad2:ff", "2a0d:2a00:1::2", "2a0d:2a00:2::2", "2606:1a40::", "2606:1a40:1::",
    ).map { java.net.InetAddress.getByName(it).address }

    /** [addr] (4 ya da 16 bayt) bilinen bir DoH/DoT sağlayıcı adresi mi? */
    fun isDohAddress(addr: ByteArray): Boolean {
        if (addr.size == 4) { val x = Packets.i32(addr, 0); for (a in DOH_V4) if (a == x) return true; return false }
        if (addr.size != 16) return false
        for (a in DOH_V6) if (a.contentEquals(addr)) return true
        return false
    }

    class Hello {
        var sniOff = -1          // SNI adının [b] içindeki konumu
        var sniLen = 0
        var recLen = 0           // ilk TLS kaydının yük uzunluğu
        var ech = false          // Encrypted ClientHello var: SNI gerçek ad değil olabilir
        fun host(b: ByteArray): String? =
            if (sniOff >= 0 && sniLen > 0) String(b, sniOff, sniLen, Charsets.ISO_8859_1).lowercase() else null
    }

    /** İlk baytlara bakıp TLS / HTTP / bilinmiyor ayırır. Karar için en az 3 bayt gerekir. */
    fun classify(b: ByteArray, len: Int): Int {
        if (len < 3) return NONE
        if (b[0].toInt() == 0x16 && b[1].toInt() == 3 && (b[2].toInt() and 0xFF) <= 4) return TLS
        val m = METHODS.any { m -> len >= m.length && m.indices.all { b[it].toInt() == m[it].code } }
        return if (m) HTTP else NONE
    }

    private val METHODS = listOf("GET ", "POST ", "HEAD ", "PUT ", "DELETE ", "OPTIONS ", "PATCH ", "CONNECT ")

    /** TLS: ilk kaydın tamamı için gereken toplam bayt (5 + yük). Başlık eksikse -1. */
    fun tlsNeed(b: ByteArray, len: Int): Int = if (len < 5) -1 else 5 + Packets.u16(b, 3)

    /** HTTP: başlıkların bittiği konum (\r\n\r\n sonrası) ya da -1. */
    fun httpEnd(b: ByteArray, len: Int): Int {
        var i = 3
        while (i < len) {
            if (b[i].toInt() == '\n'.code && b[i - 1].toInt() == '\r'.code && b[i - 2].toInt() == '\n'.code && b[i - 3].toInt() == '\r'.code) return i + 1
            i++
        }
        return -1
    }

    /** ClientHello'dan SNI'yı çıkarır. Bozuk/eksik ise false. */
    fun parseHello(b: ByteArray, len: Int, h: Hello): Boolean {
        h.sniOff = -1; h.sniLen = 0; h.ech = false
        if (len < 44 || b[0].toInt() != 0x16 || b[5].toInt() != 1) return false
        h.recLen = Packets.u16(b, 3)
        val end = minOf(len, 5 + h.recLen)
        var p = 5 + 4 + 2 + 32                         // kayıt başlığı, el sıkışma başlığı, sürüm, rastgele
        if (p + 1 > end) return false
        p += 1 + (b[p].toInt() and 0xFF)               // oturum kimliği
        if (p + 2 > end) return false
        p += 2 + Packets.u16(b, p)                     // şifre takımları
        if (p + 1 > end) return false
        p += 1 + (b[p].toInt() and 0xFF)               // sıkıştırma
        if (p + 2 > end) return false
        val extEnd = minOf(end, p + 2 + Packets.u16(b, p))
        p += 2
        while (p + 4 <= extEnd) {
            val t = Packets.u16(b, p)
            val l = Packets.u16(b, p + 2)
            val body = p + 4
            if (body + l > extEnd) return h.sniOff >= 0
            if (t == 0 && l >= 5) {
                val nl = Packets.u16(b, body + 3)
                if (b[body + 2].toInt() == 0 && nl > 0 && body + 5 + nl <= body + l) { h.sniOff = body + 5; h.sniLen = nl }
            } else if (t == 0xFE0D) h.ech = true
            p = body + l
        }
        return h.sniOff >= 0
    }

    /** HTTP isteğinde Host değerinin konumu ve uzunluğu (başlık adının başlangıcı [hdrOff] ile). */
    class HttpInfo { var hdrOff = -1; var valOff = -1; var valLen = 0; var get = false }

    fun parseHttp(b: ByteArray, len: Int, h: HttpInfo): Boolean {
        h.hdrOff = -1; h.valOff = -1; h.valLen = 0
        h.get = len >= 4 && (startsWith(b, "GET ") || startsWith(b, "HEAD"))
        var i = 0
        while (i < len) {
            val e = lineEnd(b, i, len)
            if (e < 0) break
            if (e - i >= 5 && lower(b[i]) == 'h' && lower(b[i + 1]) == 'o' && lower(b[i + 2]) == 's' && lower(b[i + 3]) == 't' && b[i + 4].toInt() == ':'.code) {
                var v = i + 5
                while (v < e && (b[v].toInt() == ' '.code || b[v].toInt() == '\t'.code)) v++
                var ve = e
                while (ve > v && (b[ve - 1].toInt() == ' '.code || b[ve - 1].toInt() == '\t'.code)) ve--
                h.hdrOff = i; h.valOff = v; h.valLen = ve - v
                return h.valLen > 0
            }
            i = e + 2
        }
        return false
    }

    fun httpHost(b: ByteArray, h: HttpInfo): String? {
        if (h.valOff < 0) return null
        val s = String(b, h.valOff, h.valLen, Charsets.ISO_8859_1).lowercase()
        return s.substringBefore(':').trim().ifEmpty { null }
    }

    private fun startsWith(b: ByteArray, s: String): Boolean = s.indices.all { b[it].toInt() == s[it].code }
    private fun lower(x: Byte): Char = (x.toInt() or 0x20).toChar()
    private fun lineEnd(b: ByteArray, from: Int, len: Int): Int {
        var i = from
        while (i + 1 < len) { if (b[i].toInt() == '\r'.code && b[i + 1].toInt() == '\n'.code) return i; i++ }
        return -1
    }

    /** Sunucuya sırayla yazılacak bir parça; [oobAfter] doğruysa arkasından 1 bayt acil veri gönderilir. */
    class Part(val data: ByteArray, val oobAfter: Boolean = false, val lowTtl: Boolean = false)

    private fun slice(b: ByteArray, from: Int, to: Int): ByteArray = b.copyOfRange(from, to)

    /**
     * [plan] numaralı yönteme göre ilk uçuşu parçalara böler. Veri tek parçaysa (bölünemiyorsa) tek elemanlı dizi döner.
     * [n] ilk uçuşun uzunluğudur (b'nin tamamı olmayabilir).
     */
    fun split(kind: Int, plan: Int, b: ByteArray, n0: Int): List<Part> {
        val n = n0.coerceIn(0, b.size)
        if (n == 0) return emptyList()
        val raw = when (kind) {
            TLS -> splitTls(plan, b, n)
            HTTP -> splitHttp(plan, b, n)
            else -> listOf(Part(slice(b, 0, n)))
        }
        // güvenlik ağı: boş parça asla yazılmaz (bozuk girdide bölme noktaları çakışabilir)
        return if (raw.any { it.data.isEmpty() }) raw.filter { it.data.isNotEmpty() }.ifEmpty { listOf(Part(slice(b, 0, n))) } else raw
    }

    private fun splitTls(plan: Int, b: ByteArray, n: Int): List<Part> {
        if (n < 8) return listOf(Part(slice(b, 0, n)))
        val h = Hello()
        val ok = parseHello(b, n, h)
        val mid = if (ok) h.sniOff + h.sniLen / 2 else n / 2
        val cut = mid.coerceIn(2, n - 1)
        return when (plan) {
            0 -> listOf(Part(slice(b, 0, 1)), Part(slice(b, 1, cut)), Part(slice(b, cut, n)))
            1 -> tlsRecordParts(b, n, cut)
            2 -> listOf(Part(slice(b, 0, cut), oobAfter = true), Part(slice(b, cut, n)))
            // 4 = "disorder": ilk bayt çok düşük TTL ile gider (DPI'a ya da sunucuya ulaşmaz), çekirdek biraz sonra normal TTL ile
            // yeniden yollar; DPI akışı sırasız görür. TTL ayarlanamazsa yalnızca 0 numaralı bölme gibi davranır.
            4 -> listOf(Part(slice(b, 0, 1), lowTtl = true), Part(slice(b, 1, cut)), Part(slice(b, cut, n)))
            // 5 = mikro parçalama: kayıt başlığı bayt bayt, SNI küçük dilimlerle; her dilim ayrı TCP parçası (en çok 16).
            5 -> microParts(b, n, if (ok) h.sniOff else cut, if (ok) h.sniLen else 0)
            // 6 = üç TLS kaydı: [el sıkışma başlığı] [SNI'nın ilk yarısına dek] [kalan]; DPI'ın kayıt birleştirme sınırını aşar.
            6 -> tlsThreeRecords(b, n, cut)
            // 7 = kayıt bölme + ilk kayıt düşük TTL ile (çekirdek yeniden yollayana dek DPI akışta boşluk görür).
            7 -> {
                val x = tlsRecordParts(b, n, cut)
                if (x.size >= 3) listOf(Part(x[0].data + x[1].data, lowTtl = true), x[2]) else listOf(Part(slice(b, 0, cut), lowTtl = true), Part(slice(b, cut, n)))
            }
            else -> {
                val x = tlsRecordParts(b, n, cut)
                if (x.size >= 3) listOf(x[0], Part(x[1].data, oobAfter = true), x[2]) else listOf(Part(slice(b, 0, cut), oobAfter = true), Part(slice(b, cut, n)))
            }
        }
    }

    // --- TLS kaydı bölme

    /**
     * ClientHello'yu [cut] noktasında iki TLS kaydına bölüp üç TCP parçası verir: [0,1) [1, kayıt1 sonu) [kayıt2].
     * Birleşik akış geçerli iki ardışık el sıkışma kaydıdır; sunucu parçalı kaydı birleştirir (RFC 8446 §5.1).
     */
    fun tlsRecordParts(b: ByteArray, n: Int, cut: Int): List<Part> {
        val recEnd = 5 + Packets.u16(b, 3)
        if (n < recEnd || cut <= 5 || cut >= recEnd) return listOf(Part(slice(b, 0, 1)), Part(slice(b, 1, n)))
        val first = ByteArray(cut)                       // kayıt 1: başlık + yükün ilk kısmı
        System.arraycopy(b, 0, first, 0, cut)
        Packets.put16(first, 3, cut - 5)
        val second = ByteArray(5 + (recEnd - cut) + (n - recEnd))   // kayıt 2: yeni başlık + kalan yük (+ varsa sonrası)
        System.arraycopy(b, 0, second, 0, 3)
        Packets.put16(second, 3, recEnd - cut)
        System.arraycopy(b, cut, second, 5, n - cut)
        return listOf(Part(slice(first, 0, 1)), Part(slice(first, 1, first.size)), Part(second))
    }

    /** Akış aynı kalır; yalnızca TCP parça sınırları değişir (kayıt başlığı + SNI boyunca küçük dilimler). */
    private fun microParts(b: ByteArray, n: Int, sniOff: Int, sniLen: Int): List<Part> {
        val cuts = java.util.TreeSet<Int>()
        for (i in 1..5) cuts.add(i)                                   // kayıt başlığı bayt bayt
        if (sniLen > 0) {
            val step = maxOf(2, sniLen / 5)
            var c = sniOff - 1
            while (c < sniOff + sniLen + 1) { cuts.add(c); c += step }
        } else cuts.add(n / 2)
        val pts = cuts.filter { it in 1 until n }.toMutableList()
        while (pts.size > 15) pts.removeAt(pts.size / 2)
        val out = ArrayList<Part>(pts.size + 1)
        var prev = 0
        for (c in pts) { if (c > prev) { out.add(Part(slice(b, prev, c))); prev = c } }
        out.add(Part(slice(b, prev, n)))
        return out
    }

    /** ClientHello'yu üç geçerli TLS kaydına böler (RFC 8446 §5.1: el sıkışma iletisi birden çok kayda bölünebilir). */
    fun tlsThreeRecords(b: ByteArray, n: Int, cut: Int): List<Part> {
        val recEnd = 5 + Packets.u16(b, 3)
        val c1 = 5 + 4                                                // el sıkışma başlığı (tip + 3 bayt uzunluk) ilk kayıtta
        if (n < recEnd || cut <= c1 + 1 || cut >= recEnd) return tlsRecordParts(b, n, cut)
        val out = java.io.ByteArrayOutputStream(n + 10)
        fun rec(from: Int, to: Int) {
            out.write(b[0].toInt()); out.write(b[1].toInt()); out.write(b[2].toInt())
            out.write((to - from) shr 8); out.write(to - from)
            out.write(b, from, to - from)
        }
        rec(5, c1); val l1 = out.size()
        rec(c1, cut); val l2 = out.size()
        rec(cut, recEnd)
        if (n > recEnd) out.write(b, recEnd, n - recEnd)
        val all = out.toByteArray()
        return listOf(Part(slice(all, 0, 1)), Part(slice(all, 1, l1)), Part(slice(all, l1, l2)), Part(slice(all, l2, all.size)))
    }

    private fun splitHttp(plan: Int, b: ByteArray, n: Int): List<Part> {
        val h = HttpInfo()
        val ok = parseHttp(b, n, h)
        val d = b.copyOfRange(0, n)
        if (!ok) return listOf(Part(d))
        val cut: Int
        when (plan) {
            0 -> cut = h.hdrOff + 2
            1 -> { mixCase(d, h.hdrOff); cut = h.hdrOff + 2 }
            2 -> {
                // "Host:" ile değer arasına sekme: çoğu sunucu başlık değerindeki boşluğu yok sayar.
                val x = ByteArray(n + 1)
                System.arraycopy(d, 0, x, 0, h.hdrOff + 5)
                x[h.hdrOff + 5] = '\t'.code.toByte()
                System.arraycopy(d, h.hdrOff + 5, x, h.hdrOff + 6, n - h.hdrOff - 5)
                val c = (h.hdrOff + 2).coerceAtMost(x.size - 1)
                return listOf(Part(slice(x, 0, c)), Part(slice(x, c, x.size)))
            }
            3 -> { mixCase(d, h.hdrOff); cut = 2 }
            // 4 = en başa boş satır (RFC 9112 §2.2: sunucu istek satırından önceki boş satırı yok sayar) + Host içinde bölme.
            4 -> {
                val x = ByteArray(n + 2)
                x[0] = '\r'.code.toByte(); x[1] = '\n'.code.toByte()
                System.arraycopy(d, 0, x, 2, n)
                val c = h.hdrOff + 4
                return listOf(Part(slice(x, 0, c)), Part(slice(x, c, x.size)))
            }
            // 5 = Host başlığını sona taşı + ":" sonrası fazladan boşluk; "Ho|st" ortasından böl. Başlık sırası anlam taşımaz (RFC 9110 §5.3).
            5 -> {
                val he = httpEnd(d, n)
                val le = lineEnd(d, h.hdrOff, n)
                if (he < 0 || le < 0 || he < le + 4) { cut = h.hdrOff + 2 }
                else {
                    val hostLine = d.copyOfRange(h.hdrOff, le)
                    val sb = java.io.ByteArrayOutputStream(n + 4)
                    sb.write(d, 0, h.hdrOff)                          // istek satırı + önceki başlıklar
                    sb.write(d, le + 2, he - 2 - (le + 2))            // sonraki başlıklar (son boş satır hariç)
                    val hostAt = sb.size()
                    sb.write(hostLine, 0, 5); sb.write(' '.code); sb.write(' '.code); sb.write(hostLine, 5, hostLine.size - 5)
                    sb.write('\r'.code); sb.write('\n'.code); sb.write('\r'.code); sb.write('\n'.code)
                    sb.write(d, he, n - he)                           // gövde varsa
                    val x = sb.toByteArray()
                    val c = hostAt + 2
                    return listOf(Part(slice(x, 0, c)), Part(slice(x, c, x.size)))
                }
            }
            // 6 = çoklu bölme: metodun içinde, Host adının içinde ve değerin ortasında (+ harf karışımı).
            else -> {
                mixCase(d, h.hdrOff)
                val pts = java.util.TreeSet<Int>(listOf(2.coerceAtMost(n - 1), h.hdrOff + 2, h.valOff + h.valLen / 2))
                val out = ArrayList<Part>()
                var prev = 0
                for (c in pts) { if (c in (prev + 1) until n) { out.add(Part(slice(d, prev, c))); prev = c } }
                out.add(Part(slice(d, prev, n)))
                return out
            }
        }
        val c = cut.coerceIn(1, n - 1)
        return listOf(Part(slice(d, 0, c)), Part(slice(d, c, n)))
    }

    private fun mixCase(d: ByteArray, off: Int) {
        d[off] = 'h'.code.toByte(); d[off + 1] = 'O'.code.toByte(); d[off + 2] = 's'.code.toByte(); d[off + 3] = 'T'.code.toByte()
    }

    /**
     * Hedef başına çalışan yöntemi hatırlar (en çok [cap] hedef, en eski atılır). Yöntem çalışmazsa sıradakine geçilir.
     * İlk deneme: o hedef için öğrenilen yöntem; yoksa AĞ ÖNCELİĞİ (bu ağda son zamanlarda en çok işe yarayan yöntem, oylar zamanla
     * sönümlenir); o da yoksa TLS'te 1, HTTP'de 0. Böylece aynı ağdaki yeni sitelerde baştan doğru yöntemle başlanır.
     * Bekleme süresi sabit değil, bağlantı süresinden (RTT) türetilir: [waitMs].
     */
    class Planner(private val cap: Int = 512, private val slow: Boolean = false) {
        private val ok = object : LinkedHashMap<String, Int>(64, 0.75f, true) {
            override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Int>?) = size > cap
        }
        private val votes = Array(3) { DoubleArray(16) }          // [tür][yöntem]
        private var rtt = 0.0
        private val est = RttEstimator()

        private fun prior(kind: Int): Int {
            val def = if (kind == TLS) TLS_ORDER[0] else 0
            val v = votes[kind]
            var best = def
            for (i in 0 until (if (kind == TLS) TLS_PLANS else HTTP_PLANS)) if (v[i] > v[best] * 1.5 + 0.5) best = i
            return best
        }

        @Synchronized fun first(key: String, kind: Int = HTTP): Int = ok[key] ?: prior(kind)
        @Synchronized fun worked(key: String, kind: Int, plan: Int) {
            ok[key] = plan
            val v = votes[kind]
            for (i in v.indices) v[i] *= 0.95
            v[plan.coerceIn(0, 15)] += 1.0
        }
        @Synchronized fun forget() { ok.clear(); for (v in votes) v.fill(0.0); rtt = 0.0; est.reset() }

        /** Bağlantıda yedek (ikinci) denemenin başlama gecikmesi, bu ağın ölçülen bağlantı süresinden ([MobilePolicy.connectHedgeMs]). */
        fun hedgeMs(): Long = MobilePolicy.connectHedgeMs(est, slow)

        /** Bağlantı kurma süresi (ms) örneği; üstel ortalama. */
        @Synchronized fun noteRtt(ms: Long) { val x = ms.coerceIn(1, 3000).toDouble(); rtt = if (rtt == 0.0) x else rtt * 0.8 + x * 0.2; est.sample(x) }

        /** Yanıt gelmezse yeniden denemeden önce beklenecek süre: yavaş ağda uzun, hızlı ağda kısa (eski sabit: TLS 2000 / HTTP 5000 ms). */
        @Synchronized fun waitMs(kind: Int): Long {
            val r = rtt
            if (slow) return if (kind == TLS) (if (r == 0.0) 2200L else (6 * r + 800).toLong().coerceIn(1500L, 3000L))
            else (if (r == 0.0) 4000L else (8 * r + 1500).toLong().coerceIn(2500L, 6000L))
            return if (kind == TLS) (if (r == 0.0) 1500L else (4 * r + 500).toLong().coerceIn(900L, 2000L))
            else (if (r == 0.0) 3000L else (6 * r + 1000).toLong().coerceIn(1500L, 5000L))
        }

        fun next(kind: Int, plan: Int): Int {
            if (kind == TLS) {
                val i = TLS_ORDER.indexOf(plan)
                return if (i >= 0 && i + 1 < TLS_ORDER.size) TLS_ORDER[i + 1] else -1
            }
            return if (plan + 1 < HTTP_PLANS) plan + 1 else -1
        }
    }
}
