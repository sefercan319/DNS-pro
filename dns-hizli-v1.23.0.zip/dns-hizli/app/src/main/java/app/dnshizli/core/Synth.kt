package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin

/** Ses olayları. İlk beşi arayüz sesidir, ötekiler bağlantı sesidir ([isConnection]). */
enum class Sfx(val isConnection: Boolean) {
    TAP(false), TOGGLE_ON(false), TOGGLE_OFF(false), BACK(false), SHEET(false),
    CONNECT(true), DISCONNECT(true), ERROR(true), DONE(true),
    /** Bir seçenek, sunucu ya da satır seçildi. */
    SELECT(false),
    /** Bir yenileme ya da ölçüm başladı. */
    REFRESH(false),
}

/** Ses tınısı (enstrüman). Hepsi kodla sentezlenir; dosya ya da ek boyut yoktur. */
enum class Voice {
    BUBBLE, GLASS, CLICK, WOOD, PIXEL, AIR,
    /** Yeni paketlerin tınıları ([SoundPack.AQUA] … [SoundPack.SPACE]); her birinin kendi melodileri vardır. */
    DROP, CHIME, BLIP, KALIMBA, CHROME, PAD, CHIP, SONAR,
    /** Liquid Glass: yumuşak, parlak cam damlası; hafif dalgalanan tını. */
    LUMEN;

    /** Eski altı tını ortak melodileri paylaşır; yenilerin kendi tabloları vardır. */
    val hasOwnMelodies: Boolean get() = ordinal >= DROP.ordinal
}

/**
 * Ses efekti sentezleyici. Saf Kotlin: Android'e dokunmaz, bu yüzden bilgisayarda sınanır. Çıktı 16 bit mono PCM'dir;
 * tepe genliği olaya göre sabitlenmiştir (arayüz sesleri kısık, bağlantı sesleri biraz daha belirgin), uçları sıfıra
 * iner (tıkırtı yok), en çok [MAX_SEC] sürer. Ses seviyesi çalma anında verilir; bu yüzden aynı dizi yeniden kullanılır.
 */
object Synth {
    const val RATE = 22050
    const val MAX_SEC = 0.9f

    /** Ayarlardaki paket ve görünüm stilinden tınıyı seç. */
    fun voiceFor(pack: SoundPack, style: UiStyle): Voice = when (pack) {
        SoundPack.SOFT -> Voice.WOOD
        SoundPack.GLASS -> Voice.GLASS
        SoundPack.CLASSIC -> Voice.CLICK
        SoundPack.AQUA -> Voice.DROP
        SoundPack.AERO -> Voice.CHIME
        SoundPack.METRO -> Voice.BLIP
        SoundPack.ECO -> Voice.KALIMBA
        SoundPack.Y2K -> Voice.CHROME
        SoundPack.AURORA -> Voice.PAD
        SoundPack.RETRO -> Voice.CHIP
        SoundPack.SPACE -> Voice.SONAR
        SoundPack.LIQUID -> Voice.LUMEN
        SoundPack.AUTO -> when (style) {
            UiStyle.AQUA -> Voice.BUBBLE
            UiStyle.AERO -> Voice.GLASS
            UiStyle.METRO -> Voice.CLICK
            UiStyle.ECO -> Voice.WOOD
            UiStyle.Y2K -> Voice.PIXEL
            UiStyle.AURORA -> Voice.AIR
            UiStyle.LIQUID -> Voice.LUMEN
        }
    }

    /** Bir nota: [hz] frekans, [at] başlangıç (sn), [len] süre (sn), [gain] bağıl ses. */
    private class Note(val hz: Float, val at: Float, val len: Float, val gain: Float = 1f)

    private fun n(hz: Float, at: Float, len: Float, gain: Float = 1f) = Note(hz, at, len, gain)

    // Notalar (Hz)
    private const val G4 = 392f; private const val A4 = 440f; private const val C5 = 523.25f; private const val E5 = 659.25f
    private const val F4 = 349.23f
    private const val G5 = 783.99f; private const val C6 = 1046.5f; private const val E6 = 1318.5f; private const val G6 = 1568f

    /** "C5@0+.12*0.8" = nota adı@başlangıç+süre*ses; boşlukla ayrılır. Sıra: [Sfx] sırası (11 olay). */
    private val MELODIES: Map<Voice, Array<String>> = mapOf(
        // Aqua: su damlaları; D majör pentatonik, yankılı
        Voice.DROP to arrayOf(
            "A5@0+.05", "E5@0+.05 A5@.06+.09", "A5@0+.05 E5@.06+.09", "E5@0+.07*.9", "B4@0+.05*.8 E5@.05+.07",
            "D5@0+.1 F#5@.09+.1 A5@.18+.1 D6@.27+.14 A5@.40+.20*.7", "A5@0+.1 F#5@.08+.1 D5@.16+.1 A4@.24+.2*.8",
            "A4@0+.13 E4@.11+.28", "F#6@0+.08*.8 D6@.07+.08*.7 A6@.14+.2",
            "F#5@0+.05 A5@.05+.07", "D5@0+.06 A5@.06+.06 F#5@.12+.06 D6@.18+.16*.8"),
        // Frutiger Aero: cam çanlar; C majör pentatonik, yükselen süpürme
        Voice.CHIME to arrayOf(
            "E6@0+.05*.8", "G5@0+.05 C6@.05+.09", "C6@0+.05 G5@.05+.09", "G5@0+.07*.8", "E5@0+.05*.7 A5@.04+.07",
            "C5@0+.1 E5@.07+.1 G5@.14+.1 C6@.21+.1 E6@.28+.1 G6@.35+.3", "G6@0+.08 E6@.06+.08 C6@.12+.1 G5@.18+.26*.8",
            "D5@0+.13 B4@.11+.28", "G6@0+.07*.8 C7@.06+.24",
            "G5@0+.05 E6@.05+.08*.8", "C5@0+.06 G5@.06+.06 E5@.12+.06 C6@.18+.18*.8"),
        // Metro: sıkı, düz bipler
        Voice.BLIP to arrayOf(
            "A5@0+.03", "E5@0+.035 A5@.045+.05", "A5@0+.035 E5@.045+.05", "E5@0+.05", "A4@0+.03 E5@.035+.04",
            "A4@0+.06 E5@.07+.06 A5@.14+.06 E6@.21+.18", "E6@0+.06 A5@.07+.06 E5@.14+.16",
            "D5@0+.07 D5@.09+.07 G#4@.18+.2", "E6@0+.05 A6@.06+.14",
            "E5@0+.03 C#6@.035+.05", "A4@0+.04 C#5@.045+.04 E5@.09+.04 A5@.135+.1"),
        // Frutiger Eco: kalimba; G majör pentatonik
        Voice.KALIMBA to arrayOf(
            "D6@0+.05", "B5@0+.05 E6@.06+.09", "E6@0+.05 B5@.06+.09", "B5@0+.07", "G5@0+.05*.8 B5@.05+.07",
            "G5@0+.1 B5@.09+.1 D6@.18+.1 G6@.27+.1 B6@.36+.28", "D6@0+.1 B5@.09+.1 G5@.18+.1 D5@.27+.26*.8",
            "G4@0+.12 C#5@.1+.28", "D6@0+.08*.8 G6@.07+.08*.9 B6@.14+.24",
            "B5@0+.05 D6@.05+.08", "G5@0+.06 D5@.06+.06 B5@.12+.06 G6@.18+.2*.8"),
        // Y2K: krom FM çanlar; büyük atlamalı, Lidyen
        Voice.CHROME to arrayOf(
            "C6@0+.04", "G5@0+.04 D6@.045+.07", "D6@0+.04 G5@.045+.07", "A5@0+.06", "F#5@0+.04 C6@.04+.06",
            "C5@0+.08 G5@.07+.08 D6@.14+.08 F#6@.21+.08 C7@.28+.3", "C7@0+.07 F#6@.06+.07 D6@.12+.07 G5@.18+.07 C5@.24+.22",
            "B4@0+.1 F4@.09+.1 B3@.18+.26", "C7@0+.05 G6@.05+.05 D7@.10+.22",
            "D6@0+.04 A6@.045+.07", "G5@0+.05 C6@.05+.05 F#6@.10+.05 D7@.15+.2*.8"),
        // Aurora: ağır ve geniş pad; majör yedili akorlar
        Voice.PAD to arrayOf(
            "E5@0+.06*.7", "B4@0+.08 E5@.07+.1", "E5@0+.08 B4@.07+.1", "B4@0+.1*.8", "G4@0+.07*.7 B4@.05+.09",
            "E4@0+.3 B4@.1+.3 G5@.2+.3 D6@.3+.35", "D6@0+.28 G5@.1+.28 B4@.2+.28 E4@.3+.36",
            "D4@0+.28 G#4@.05+.34", "B5@0+.2 E6@.08+.26 G6@.16+.3",
            "G4@0+.07*.7 D5@.06+.1", "B4@0+.12 E5@.07+.12 G5@.14+.14 B5@.21+.2*.8"),
        // Retro: 8 bit, hızlı arpej ve jeton sesi
        Voice.CHIP to arrayOf(
            "E6@0+.035", "C6@0+.04 G6@.04+.06", "G6@0+.04 C6@.04+.06", "C6@0+.05", "G5@0+.03 C6@.03+.04",
            "C5@0+.07 E5@.07+.07 G5@.14+.07 C6@.21+.07 E6@.28+.07 G6@.35+.18", "G6@0+.07 E6@.07+.07 C6@.14+.07 G5@.21+.07 C5@.28+.18",
            "E4@0+.09 C4@.1+.09 A3@.2+.18", "B5@0+.06 E6@.06+.26",
            "G5@0+.03 C6@.035+.05", "C6@0+.04 G5@.04+.04 E6@.08+.04 C7@.12+.12"),
        // Uzay: sonar ve yankı; A tabanlı, beşli aralıklar
        Voice.SONAR to arrayOf(
            "A5@0+.04*.8", "E5@0+.05 B5@.06+.09", "B5@0+.05 E5@.06+.09", "E5@0+.07", "B4@0+.04 E5@.04+.06",
            "A3@0+.1 E4@.08+.1 A4@.16+.1 E5@.24+.1 A5@.32+.1 E6@.40+.22", "E6@0+.1 A5@.08+.1 E5@.16+.1 A4@.24+.1 E4@.32+.2",
            "A4@0+.12 D#4@.1+.3", "A5@0+.08 E6@.08+.24",
            "B4@0+.04 E5@.05+.06", "E4@0+.07 B4@.06+.07 E5@.12+.07 B5@.18+.2"),
        // Liquid Glass: yumuşak cam damlaları; E lidyen, parlak ve havadar, bağlantılarda uzun yankı
        Voice.LUMEN to arrayOf(
            "B5@0+.05*.9", "E5@0+.05 B5@.06+.09", "B5@0+.05 E5@.06+.09", "F#5@0+.07*.85", "C#5@0+.05*.8 G#5@.05+.07",
            "E5@0+.1 G#5@.08+.1 B5@.16+.1 F#6@.24+.1 B6@.32+.28", "B6@0+.09 F#6@.07+.09 B5@.14+.1 E5@.21+.26*.8",
            "G#4@0+.12 D5@.1+.28", "E6@0+.07*.8 B6@.07+.2",
            "G#5@0+.05 D#6@.05+.08", "E5@0+.06 B5@.06+.06 G#5@.12+.06 E6@.18+.2*.8"),
    )

    private val melodyCache = HashMap<Voice, Array<List<Note>>>()

    private fun hzOf(name: String): Float {
        val letter = name[0]
        var i = 1
        var semi = when (letter) { 'C' -> 0; 'D' -> 2; 'E' -> 4; 'F' -> 5; 'G' -> 7; 'A' -> 9; else -> 11 }
        if (name[i] == '#') { semi++; i++ } else if (name[i] == 'b') { semi--; i++ }
        val octave = name.substring(i).toInt()
        val midi = 12 * (octave + 1) + semi
        return (440.0 * Math.pow(2.0, (midi - 69) / 12.0)).toFloat()
    }

    private fun parse(s: String): List<Note> = s.split(' ').map { tok ->
        val at = tok.indexOf('@')
        val plus = tok.indexOf('+')
        val star = tok.indexOf('*')
        val end = if (star >= 0) star else tok.length
        Note(hzOf(tok.substring(0, at)), tok.substring(at + 1, plus).toFloat(), tok.substring(plus + 1, end).toFloat(), if (star >= 0) tok.substring(star + 1).toFloat() else 1f)
    }

    @Synchronized
    private fun notes(e: Sfx, v: Voice): List<Note> {
        if (!v.hasOwnMelodies) return notes(e)
        val arr = melodyCache.getOrPut(v) { Array(Sfx.values().size) { parse(MELODIES.getValue(v)[it]) } }
        return arr[e.ordinal]
    }

    private fun notes(e: Sfx): List<Note> = when (e) {
        Sfx.TAP -> listOf(n(C6, 0f, 0.05f))
        Sfx.TOGGLE_ON -> listOf(n(G5, 0f, 0.05f), n(C6, 0.05f, 0.08f))
        Sfx.TOGGLE_OFF -> listOf(n(C6, 0f, 0.05f), n(G5, 0.05f, 0.08f))
        Sfx.BACK -> listOf(n(G5, 0f, 0.07f, 0.9f))
        Sfx.SHEET -> listOf(n(E5, 0f, 0.05f, 0.8f), n(G5, 0.04f, 0.07f))
        Sfx.CONNECT -> listOf(n(C5, 0f, 0.12f), n(E5, 0.085f, 0.12f), n(G5, 0.17f, 0.14f), n(C6, 0.255f, 0.40f))
        Sfx.DISCONNECT -> listOf(n(G5, 0f, 0.10f), n(E5, 0.075f, 0.10f), n(C5, 0.15f, 0.26f))
        Sfx.ERROR -> listOf(n(A4, 0f, 0.13f), n(F4, 0.11f, 0.30f))
        Sfx.DONE -> listOf(n(E6, 0f, 0.09f, 0.8f), n(G6, 0.075f, 0.22f))
        Sfx.SELECT -> listOf(n(G5, 0f, 0.04f), n(E6, 0.04f, 0.07f, 0.8f))
        Sfx.REFRESH -> listOf(n(C5, 0f, 0.05f), n(G5, 0.05f, 0.05f), n(E5, 0.10f, 0.05f), n(C6, 0.15f, 0.14f))
    }

    /** Olay başına hedef tepe genliği (0..1). */
    private fun peak(e: Sfx): Float = if (e.isConnection) 0.80f else 0.55f

    /** [e] olayını [v] tınısıyla üret. Aynı girdi her zaman aynı diziyi verir. */
    fun render(e: Sfx, v: Voice): ShortArray {
        val list = notes(e, v)
        var end = 0f
        for (nt in list) end = maxOf(end, nt.at + nt.len + tail(v))
        if (e.isConnection) end += echoDelay(v) * 1.5f
        val total = (minOf(end, MAX_SEC) * RATE).toInt().coerceAtLeast(64)
        val buf = FloatArray(total)
        for (nt in list) voiceNote(buf, v, nt)
        if (e.isConnection) echo(buf, v)
        // 1 kutuplu alçak geçiren: sertliği alır (kulak yormasın). PIXEL ve CLICK biraz daha parlak kalır.
        val a = when (v) { Voice.PIXEL -> 0.55f; Voice.CLICK -> 0.6f; Voice.BLIP -> 0.6f; Voice.CHIP -> 0.7f; Voice.CHROME -> 0.75f; else -> 0.8f }
        var y = 0f
        for (i in buf.indices) { y += a * (buf[i] - y); buf[i] = y }
        // tepe sabitle
        var mx = 0f
        for (x in buf) mx = maxOf(mx, abs(x))
        val k = if (mx > 1e-6f) peak(e) / mx else 0f
        // uçlarda yumuşak giriş (2 ms) ve çıkış (son %12, en az 6 ms)
        val fin = (0.002f * RATE).toInt().coerceAtLeast(1)
        val fout = maxOf((0.006f * RATE).toInt(), (total * 0.12f).toInt()).coerceAtMost(total)
        val out = ShortArray(total)
        for (i in 0 until total) {
            var g = k
            if (i < fin) g *= i.toFloat() / fin
            if (i >= total - fout) g *= (total - 1 - i).toFloat() / fout
            out[i] = (buf[i] * g * 32767f).toInt().coerceIn(-32767, 32767).toShort()
        }
        return out
    }

    /** Notanın bittikten sonra kalan sönüm payı (sn). */
    private fun tail(v: Voice): Float = when (v) {
        Voice.GLASS -> 0.13f; Voice.AIR -> 0.14f; Voice.WOOD -> 0.07f; Voice.BUBBLE -> 0.05f; Voice.CLICK -> 0.02f; Voice.PIXEL -> 0.03f
        Voice.DROP -> 0.08f; Voice.CHIME -> 0.12f; Voice.BLIP -> 0.03f; Voice.KALIMBA -> 0.12f; Voice.CHROME -> 0.14f
        Voice.PAD -> 0.12f; Voice.CHIP -> 0.02f; Voice.SONAR -> 0.1f; Voice.LUMEN -> 0.13f
    }

    /** Yankı (tek geri beslemeli gecikme): yalnızca Aqua, Uzay ve Liquid Glass paketlerinin bağlantı seslerinde. */
    private fun echoDelay(v: Voice): Float = when (v) { Voice.DROP -> 0.12f; Voice.SONAR -> 0.17f; Voice.LUMEN -> 0.15f; else -> 0f }

    private fun echo(buf: FloatArray, v: Voice) {
        val d = (echoDelay(v) * RATE).toInt()
        if (d <= 0) return
        val g = if (v == Voice.SONAR) 0.4f else if (v == Voice.LUMEN) 0.35f else 0.3f
        for (i in d until buf.size) buf[i] += g * buf[i - d]
    }

    private fun voiceNote(buf: FloatArray, v: Voice, nt: Note) {
        val start = (nt.at * RATE).toInt()
        val len = ((nt.len + tail(v)) * RATE).toInt()
        val tau = when (v) {
            Voice.GLASS -> 0.075f; Voice.AIR -> 0.12f; Voice.WOOD -> 0.035f; Voice.BUBBLE -> 0.04f; Voice.CLICK -> 0.012f; Voice.PIXEL -> 0.05f
            Voice.DROP -> 0.06f; Voice.CHIME -> 0.16f; Voice.BLIP -> 0.035f; Voice.KALIMBA -> 0.12f; Voice.CHROME -> 0.10f
            Voice.PAD -> 0.40f; Voice.CHIP -> 1f; Voice.SONAR -> 0.14f; Voice.LUMEN -> 0.13f
        }
        val atk = when (v) { Voice.AIR -> 0.014f; Voice.GLASS -> 0.002f; Voice.PAD -> 0.02f; Voice.KALIMBA -> 0.004f; else -> 0.003f }
        val twoPi = 2f * PI.toFloat()
        var phase = 0f
        var phase2 = 0f
        var phase3 = 0f
        for (i in 0 until len) {
            val idx = start + i
            if (idx >= buf.size) break
            val t = i.toFloat() / RATE
            var env = (if (t < atk) t / atk else 1f) * exp(-t / tau)
            if (v == Voice.CHIP) {
                // NES benzeri basamaklı (12 kademe) doğrusal sönüm
                val lin = (1f - t / (nt.len + tail(v))).coerceAtLeast(0f)
                env = (if (t < atk) t / atk else 1f) * (kotlin.math.floor(lin * 12f) / 12f)
            }
            if (v.hasOwnMelodies) env *= minOf(1f, (len - i).toFloat() / (0.008f * RATE))   // nota sonunda tıkırtı olmasın
            // BUBBLE: perde ilk 40 ms'de ×1,5'e süzülür ("blup")
            val f = when (v) {
                Voice.BUBBLE -> nt.hz * (1f + 0.5f * (1f - exp(-t / 0.018f)))
                Voice.DROP -> nt.hz * (1f + 0.6f * exp(-t / 0.02f))                       // damla: hızla ince sese iner
                Voice.BLIP -> nt.hz * (1f + 0.12f * exp(-t / 0.01f))
                Voice.SONAR -> nt.hz * (1f + 0.12f * exp(-t / 0.03f)) * (1f + 0.004f * sin(twoPi * 6f * t))
                Voice.LUMEN -> nt.hz * (1f + 0.35f * exp(-t / 0.025f)) * (1f + 0.003f * sin(twoPi * 5.5f * t))   // cam damlası: yukarıdan iner, hafif dalgalanır
                else -> nt.hz
            }
            phase += (2f * PI.toFloat()) * f / RATE
            val s = when (v) {
                Voice.BUBBLE -> sin(phase)
                Voice.GLASS -> {
                    phase2 += (2f * PI.toFloat()) * f * 2.76f / RATE
                    sin(phase) + 0.35f * sin(phase2) * exp(-t / 0.03f) + 0.12f * sin(phase * 5.4f) * exp(-t / 0.015f)
                }
                Voice.CLICK -> {
                    val click = if (i < 40) (if ((i * 7 + 3) % 4 < 2) 0.9f else -0.9f) * (1f - i / 40f) else 0f   // sabit "gürültü" kırıntısı
                    0.6f * sin(phase * 0.5f) + 0.5f * click
                }
                Voice.WOOD -> sin(phase) + 0.45f * sin(phase * 4f) * exp(-t / 0.012f)
                Voice.PIXEL -> {
                    val p = phase / (2f * PI.toFloat())
                    val fr = p - kotlin.math.floor(p)
                    (if (fr < 0.25f) 1.5f else -0.5f) * 0.6f
                }
                Voice.AIR -> {
                    phase2 += (2f * PI.toFloat()) * (f + 3f) / RATE
                    0.6f * sin(phase) + 0.6f * sin(phase2)
                }
                Voice.DROP -> sin(phase) + 0.2f * sin(phase * 2f) * exp(-t / 0.03f)
                Voice.CHIME -> {
                    phase2 += twoPi * f * 2.76f / RATE
                    phase3 += twoPi * f * 1.004f / RATE
                    sin(phase) + 0.5f * sin(phase3) + 0.3f * sin(phase2) * exp(-t / 0.05f) + 0.1f * sin(phase * 5.4f) * exp(-t / 0.02f)
                }
                Voice.BLIP -> {
                    val fr = phase / twoPi - kotlin.math.floor(phase / twoPi)
                    0.6f * sin(phase) + 0.35f * (if (fr < 0.5f) 1f else -1f)
                }
                Voice.KALIMBA -> sin(phase) + 0.25f * sin(phase * 2f) * exp(-t / 0.05f) + 0.12f * sin(phase * 5.4f) * exp(-t / 0.02f)
                Voice.CHROME -> sin(phase + 3.2f * exp(-t / 0.07f) * sin(phase * 3.5f))
                Voice.PAD -> {
                    phase2 += twoPi * f * 1.006f / RATE
                    val trem = 1f + 0.08f * sin(twoPi * 5f * t)
                    0.5f * trem * (sin(phase) + 0.5f * sin(phase * 2f) + 0.33f * sin(phase * 3f) + 0.25f * sin(phase * 4f) +
                        sin(phase2) + 0.5f * sin(phase2 * 2f) + 0.33f * sin(phase2 * 3f))
                }
                Voice.CHIP -> {
                    val fr = phase / twoPi - kotlin.math.floor(phase / twoPi)
                    val sq = if (fr < 0.25f) 1.5f else -0.5f      // %25 darbe, ortalaması sıfır (DC yok)
                    kotlin.math.round(sq * 0.6f * 8f) / 8f
                }
                Voice.SONAR -> sin(phase) + 0.15f * sin(phase * 2f)
                Voice.LUMEN -> {
                    phase2 += twoPi * f * 3.01f / RATE
                    phase3 += twoPi * f * 1.003f / RATE
                    0.7f * sin(phase) + 0.45f * sin(phase3) + 0.22f * sin(phase2) * exp(-t / 0.06f)
                }
            }
            buf[idx] += s * env * nt.gain
        }
    }
}
