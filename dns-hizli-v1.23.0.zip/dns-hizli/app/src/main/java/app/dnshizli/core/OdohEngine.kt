package app.dnshizli.core

import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom
import java.util.Random
import java.util.concurrent.atomic.AtomicLong
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocketFactory

/** Hazırlanmış bir ODoH sorgusu: hangi yoldan gidecek, röleye ne gönderilecek, cevap nasıl açılacak. */
class OdohRequest internal constructor(
    val path: Int,
    val relay: Int,
    val target: Int,
    val targetHost: String,
    /** Röleye gidecek HTTP yolu (`?targethost=…&targetpath=…` dahil). */
    val relayPath: String,
    val query: OdohQuery,
    val keyId: ByteArray,
)

/**
 * ODoH motoru: (röle, hedef) yollarını, hedef anahtarlarını ve adresleri bir arada yönetir. Ağdan bağımsızdır; ağ işleri
 * (yapılandırma alımı, soket) dışarıdan verilir, böylece tamamı yerel bir benzetimle sınanır.
 *
 * Katmanlar:
 *  1. Yol seçimi ([OdohPathBoard]): gecikme + hata puanı, devre kesici, üstel geri çekilme, keşif.
 *  2. Anahtar yönetimi ([OdohKeyring]): tek uçuşlu alım, bayat anahtarla devam, 401'de hız sınırlı yenileme.
 *  3. Adres yönetimi ([OdohAddressBook]): son çalışan adres → ipucu → şifreli çözümleme.
 *  4. Bağımsızlık: röle ve hedef aynı işleten/alan adından olamaz (kurucu denetler).
 */
class OdohEngine(
    val relays: List<OdohNode>,
    val targets: List<OdohNode>,
    private val now: () -> Long,
    private val rng: SecureRandom,
    fetchConfig: (OdohNode) -> ByteArray,
    val book: OdohAddressBook,
    pairs: List<OdohPathSpec> = OdohCatalog.pairs(relays, targets),
    rnd: Random = Random(0x0D0A7),
    ttlMs: Long = 6 * 3600_000L,
) {
    val paths: List<OdohPathSpec> = pairs

    init {
        require(paths.isNotEmpty()) { "bağımsız röle/hedef çifti yok" }
        require(paths.size <= 63) { "çok fazla yol" }
        for (p in paths) {
            require(p.relay in relays.indices && p.target in targets.indices) { "geçersiz yol" }
            require(OdohCatalog.independent(relays[p.relay], targets[p.target])) { "röle ve hedef bağımsız değil" }
        }
    }

    val board = OdohPathBoard(paths.size, now, rnd)
    private val byHost: Map<String, OdohNode> = targets.associateBy { it.host }
    val keyring = OdohKeyring({ host -> fetchConfig(byHost[host] ?: throw IOException("bilinmeyen hedef")) }, now, ttlMs = ttlMs)

    private val okCount = AtomicLong()
    private val failCount = AtomicLong()
    private val keyRefreshes = AtomicLong()
    @Volatile var lastPath = -1; private set
    @Volatile var lastRttMs = 0L; private set
    @Volatile var lastError: String? = null; private set

    fun relayOf(path: Int) = paths[path].relay
    fun targetOf(path: Int) = paths[path].target
    fun describe(path: Int) = relays[paths[path].relay].name + " → " + targets[paths[path].target].name

    /** [SecureForwarder] için röle hedefleri (adres yer tutucudur; gerçek adresleri [relayAddresses] verir). */
    fun relayTargets(): List<SecureTarget> = relays.map { r ->
        SecureTarget(book.addresses(r).firstOrNull() ?: InetSocketAddress.createUnresolved(r.host, 443), r.host, r.path)
    }

    fun choose(avoid: Long = 0L): Int = board.choose(avoid)

    /**
     * [path] bu sorguda [e] hatasıyla başarısız oldu: yeniden denemede kaçınılacak yolların maskesi. Bağlantı/TLS/zaman aşımı gibi
     * röle düzeyindeki hatalar o röleden geçen tüm yolları, yapılandırma alım hatası o hedefin tüm yollarını, diğerleri yalnız o
     * yolu dışlar (ölü bir röleden sonra ikinci denemenin aynı röledeki başka bir yola gitmesi önlenir).
     */
    fun avoidAfter(mask: Long, path: Int, e: Throwable): Long {
        var m = mask or (1L shl path)
        val relayLevel = e !is OdohException
        val targetLevel = e is OdohException && e.kind == OdohError.CONFIG_FETCH
        if (relayLevel || targetLevel) {
            for (i in paths.indices) {
                if (relayLevel && paths[i].relay == paths[path].relay) m = m or (1L shl i)
                if (targetLevel && paths[i].target == paths[path].target) m = m or (1L shl i)
            }
        }
        return m
    }

    /** [dns] sorgusunu [path] yolu için şifreler. Hedef anahtarı yoksa alınır; alınamazsa [OdohException]. */
    fun begin(path: Int, dns: ByteArray): OdohRequest {
        val p = paths[path]
        val t = targets[p.target]
        val cfg = keyring.current(t.host)
        val q = OdohClient.seal(cfg, dns, rng)
        val rp = OdohClient.relayPath(relays[p.relay].path, t.host, t.path)
        return OdohRequest(path, p.relay, p.target, t.host, rp, q, cfg.keyId)
    }

    fun success(req: OdohRequest, rttMs: Long) {
        board.success(req.path, rttMs)
        okCount.incrementAndGet()
        lastPath = req.path
        lastRttMs = rttMs
    }

    /** Yol başarısız oldu. Anahtar reddi (401) yolun suçu değildir: [keyRejected] ile bildirilir. */
    fun failure(path: Int, e: Throwable) {
        val fatal = e is OdohException && e.kind == OdohError.AUTH
        board.failure(path, fatal)
        failCount.incrementAndGet()
        lastError = e.javaClass.simpleName + (if (e is OdohException) ":" + e.kind.name else "")
    }

    fun keyRejected(req: OdohRequest) {
        keyring.reject(req.targetHost, req.keyId)
        keyRefreshes.incrementAndGet()
    }

    /** Röle adresleri: son çalışan → ipucu; [more] ise şifreli çözümlemeyle bulunanlar da. */
    fun relayAddresses(relay: Int, more: Boolean = false): List<InetSocketAddress> = book.addresses(relays[relay], 443, more)
    fun relayConnected(relay: Int, a: InetSocketAddress) = book.markGood(relays[relay], a)

    /** Ağ değişti. */
    fun resetNetwork() { board.reset() }

    /** En iyi yolun hedef anahtarını önceden alır (arka plan iş parçacığında çağrılır). */
    fun warm() {
        try { keyring.current(targets[paths[board.choose()].target].host) } catch (_: IOException) {}
    }

    class Status(val ok: Long, val failed: Long, val keyRefreshes: Long, val allOpen: Boolean, val lastPath: String?, val lastRttMs: Long, val lastError: String?)

    fun status() = Status(okCount.get(), failCount.get(), keyRefreshes.get(), board.allOpen(), if (lastPath >= 0) describe(lastPath) else null, lastRttMs, lastError)

    companion object {
        /** Hedefin `/.well-known/odohconfigs` yapılandırmasını doğrudan (röleden değil) HTTPS ile alan işlev. */
        fun httpsFetcher(
            book: OdohAddressBook,
            openSocket: (InetSocketAddress, Int) -> Socket,
            tls: () -> SSLSocketFactory,
            verifier: HostnameVerifier = HttpsURLConnection.getDefaultHostnameVerifier(),
            connectMs: Int = 3000,
            totalMs: Long = 8000,
        ): (OdohNode) -> ByteArray = { node ->
            val path = "/.well-known/odohconfigs"
            try {
                MiniHttps.get(node.host, path, book.addresses(node, 443, false), openSocket, tls(), verifier, connectMs, totalMs, onGood = { book.markGood(node, it) })
            } catch (e: MiniHttps.HttpStatusException) {
                throw e
            } catch (e: IOException) {
                // bilinen adreslerin hiçbiri çalışmadı: şifreli çözümlemeyle yeni adresleri dene
                val more = book.addresses(node, 443, true)
                if (more.isEmpty()) throw e
                MiniHttps.get(node.host, path, more, openSocket, tls(), verifier, connectMs, totalMs, onGood = { book.markGood(node, it) })
            }
        }
    }
}
