package app.dnshizli.core

/**
 * Yerel çökme günlüğü. Kayıtlar yalnızca cihazda kalır; hiçbir yere gönderilmez ve tanılama raporunda kullanıcı tarafından görülür.
 *
 * Gizlilik: hata MESAJI kaydedilmez (sunucu adı, IP ya da kullanıcı verisi içerebilir). Yalnızca hata türü, zaman, iş parçacığı
 * adı ve uygulamanın kendi kodundaki en fazla [FRAMES] satır tutulur. Kayıt tek satırdır; uzun metinler kırpılır.
 */
object CrashLog {
    /** Tutulan en fazla kayıt sayısı; en yeni başta. */
    const val KEEP = 5
    /** Tek bir kaydın en fazla karakter sayısı. */
    const val MAX_LINE = 240
    /** Bir kayıtta yer alan uygulama satırı sayısı. */
    const val FRAMES = 3
    private const val PACKAGE = "app.dnshizli"

    /**
     * Bir istisnayı tek satırlık kayda çevirir. [timeText] biçimlendirilmiş zamandır (çağıran verir; test için deterministik).
     * Örnek: "2026-10-08 20:30 IllegalStateException @ Model:412 < Widgets:88 (main)".
     */
    fun summarize(type: String, frames: List<StackFrame>, thread: String, timeText: String): String {
        val app = frames.filter { it.className.startsWith(PACKAGE) }.take(FRAMES)
            .joinToString(" < ") { it.className.substringAfterLast('.') + ":" + it.line }
        val where = app.ifEmpty { "?" }
        return clean("$timeText ${type.substringAfterLast('.')} @ $where ($thread)")
    }

    /** Yeni kaydı başa ekler, en fazla [KEEP] kayıt tutar. [raw] önceki kayıtların kayıtlı biçimi. */
    fun append(raw: String?, entry: String): String {
        val list = (listOf(clean(entry)) + entries(raw)).take(KEEP)
        return list.joinToString("\n")
    }

    /** Kayıtlı biçimi listeye çevirir (en yeni başta). Boş satırlar atılır. */
    fun entries(raw: String?): List<String> =
        raw?.split('\n')?.map { clean(it) }?.filter { it.isNotBlank() }?.take(KEEP) ?: emptyList()

    /** Satır sonlarını ve denetim karakterlerini temizler, uzunluğu sınırlar. */
    private fun clean(s: String): String {
        val one = s.map { if (it.isISOControl()) ' ' else it }.joinToString("").trim()
        return if (one.length > MAX_LINE) one.take(MAX_LINE - 1) + "…" else one
    }
}

/** Yığın satırının sadeleştirilmiş hali (test edilebilir olsun diye Java'dan bağımsız). */
data class StackFrame(val className: String, val line: Int)
