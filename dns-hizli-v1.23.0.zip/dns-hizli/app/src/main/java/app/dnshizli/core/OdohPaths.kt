package app.dnshizli.core

import java.util.Random

/**
 * ODoH yollarının (röle + hedef çifti) sağlık tahtası: her yol için gecikme ortalaması, üst üste hata sayısı ve devre kesici.
 *
 * Devre kesici: bir yol üst üste [OPEN_AFTER] kez başarısız olursa "açılır" (seçilmez); bekleme süresi her yeni hatada
 * ikiye katlanır ([BASE_BACKOFF_MS] .. [MAX_BACKOFF_MS], ±%20 sapmayla: tüm istemciler aynı anda yeniden denemesin).
 * Süre dolunca yol "yarı açık" olur: tek bir deneme sorgusu geçebilir ([PROBE_MS] içinde sonuç gelmezse yeni deneme serbest);
 * başarılıysa kapanır, başarısızsa bekleme uzayarak yeniden açılır. Kimlik doğrulaması tutmayan cevap (sahte/bozuk) yolu hemen
 * ve uzun süreliğine keser. Hepsi açıksa bekleme süresi en kısa dolacak yol seçilir: hiçbir zaman "seçilecek yol yok" hâli olmaz.
 *
 * Seçim: puan = gecikme ortalaması × (1 + 0,5 × üst üste hata); en düşük puan. Bu sorguda zaten başarısız olan yollar ([choose]'un
 * `avoid` maskesi) sona atılır. Her [EXPLORE_EVERY]. seçimde, [STALE_MS]'den uzun süredir denenmeyen yollardan en bayat
 * olanı denenir (kenara düşen yollar toparlansın, yedek yolların gecikme bilgisi güncel kalsın); yalnızca seçilebilir yollar arasındadır.
 * Tamamen deterministiktir (saat ve rastgelelik dışarıdan verilir) ve iş parçacığı güvenlidir.
 */
class OdohPathBoard(
    val size: Int,
    private val now: () -> Long,
    private val rnd: Random = Random(0x0D0A7),
) {
    private class P {
        var ewma = Double.NaN
        var fails = 0
        var openUntil = 0L
        var probingUntil = 0L
        var lastOk = Long.MIN_VALUE / 2
        var lastTry = Long.MIN_VALUE / 2
        var total = 0L
        var failed = 0L
        var trips = 0
    }

    private val ps = Array(size) { P() }
    private var picks = 0

    init { require(size > 0) { "en az bir yol gerekli" } }

    /** Bu yol şu an seçilebilir mi (kapalı devre ya da yarı açık ve deneme serbest)? */
    private fun usable(p: P, t: Long): Boolean = p.openUntil <= t && (p.fails < OPEN_AFTER || p.probingUntil <= t)

    private fun score(p: P, avoid: Boolean, i: Int): Double {
        val base = if (p.ewma.isNaN()) UNKNOWN_MS else p.ewma
        return base * (1.0 + 0.5 * p.fails) + (if (avoid) AVOID_PENALTY else 0.0) + i * 1e-6      // eşitlikte küçük indis
    }

    /** Sıradaki sorgunun yolu. [avoid]: bu sorguda zaten başarısız olan yolların bit maskesi (yol i → 1L shl i); sona atılırlar. */
    @Synchronized fun choose(avoid: Long = 0L): Int {
        val t = now()
        var best = -1
        var bestScore = Double.MAX_VALUE
        for (i in 0 until size) {
            val p = ps[i]
            if (!usable(p, t)) continue
            val s = score(p, size > 1 && size <= 63 && (avoid ushr i) and 1L != 0L, i)
            if (s < bestScore) { best = i; bestScore = s }
        }
        if (best < 0) {
            // hepsi açık: en yakın zamanda dolacak olanı yarı açık denemeye çek
            var soon = 0
            for (i in 1 until size) if (ps[i].openUntil < ps[soon].openUntil) soon = i
            best = soon
        }
        picks++
        if (picks % EXPLORE_EVERY == 0) {
            // Keşif: seçilebilir yollar arasında en uzun süredir denenmeyen (ve bayatlamış) olan bir kez denenir. Böylece
            // geçici bir hatadan sonra kenara düşen ya da hiç denenmemiş yollar da sonunda toparlanır / gecikmeleri güncellenir.
            var stale = -1
            var oldest = STALE_MS
            for (i in 0 until size) {
                if (i == best || (size <= 63 && (avoid ushr i) and 1L != 0L) || !usable(ps[i], t)) continue
                val age = t - ps[i].lastTry
                if (age > oldest) { oldest = age; stale = i }
            }
            if (stale >= 0) best = stale
        }
        val p = ps[best]
        p.lastTry = t
        if (p.fails >= OPEN_AFTER) p.probingUntil = t + PROBE_MS          // yarı açık: tek deneme
        return best
    }

    @Synchronized fun success(i: Int, rttMs: Long) {
        val p = ps[i]
        val r = rttMs.coerceIn(1, 60_000).toDouble()
        p.ewma = if (p.ewma.isNaN()) r else 0.2 * r + 0.8 * p.ewma
        p.fails = 0; p.trips = 0
        p.openUntil = 0; p.probingUntil = 0
        p.lastOk = now()
        p.total++
    }

    /** [fatal]: kimlik doğrulaması tutmayan cevap gibi, yolu bir an önce kesmesi gereken hata. */
    @Synchronized fun failure(i: Int, fatal: Boolean = false) {
        val p = ps[i]
        val t = now()
        p.fails++; p.failed++; p.total++
        p.probingUntil = 0
        if (fatal || p.fails >= OPEN_AFTER) {
            p.trips++
            val shift = (p.trips - 1).coerceAtMost(10)
            var wait = (BASE_BACKOFF_MS shl shift).coerceAtMost(MAX_BACKOFF_MS)
            if (fatal) wait = maxOf(wait, FATAL_BACKOFF_MS)
            val jitter = 0.8 + 0.4 * rnd.nextDouble()
            p.openUntil = t + (wait * jitter).toLong()
        }
    }

    /** Ağ değişti: eski ağdaki hatalar geçersizdir; gecikme bilgisi de yeni ağda anlamsızdır. */
    @Synchronized fun reset() {
        for (p in ps) { p.ewma = Double.NaN; p.fails = 0; p.openUntil = 0; p.probingUntil = 0; p.trips = 0; p.lastTry = Long.MIN_VALUE / 2 }
    }

    /** Hiçbir yol seçilebilir değil mi? (Üst katman "gizlilik yedeğe düştü" kararını buna göre verir.) */
    @Synchronized fun allOpen(): Boolean {
        val t = now()
        return ps.none { it.openUntil <= t }
    }

    /** Son [withinMs] içinde en az bir yoldan cevap geldi mi? */
    @Synchronized fun anyOkWithin(withinMs: Long): Boolean {
        val t = now()
        return ps.any { t - it.lastOk <= withinMs }
    }

    class Info(val index: Int, val rttMs: Double, val fails: Int, val open: Boolean, val total: Long, val failed: Long)

    @Synchronized fun snapshot(): List<Info> {
        val t = now()
        return ps.mapIndexed { i, p -> Info(i, p.ewma, p.fails, p.openUntil > t, p.total, p.failed) }
    }

    companion object {
        const val OPEN_AFTER = 2
        const val BASE_BACKOFF_MS = 2_000L
        const val MAX_BACKOFF_MS = 120_000L
        const val FATAL_BACKOFF_MS = 60_000L
        const val PROBE_MS = 6_000L
        const val UNKNOWN_MS = 400.0
        const val AVOID_PENALTY = 100_000.0
        const val EXPLORE_EVERY = 25
        const val STALE_MS = 120_000L
    }
}
