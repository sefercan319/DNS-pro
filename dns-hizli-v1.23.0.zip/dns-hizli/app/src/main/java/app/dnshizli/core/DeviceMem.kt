package app.dnshizli.core

/** Filtre belleği ayarı: büyük engel listesinin yüklenip yüklenmeyeceği. Sıra, arayüzdeki seçenek sırasıdır. */
enum class FilterMem(val id: String) { AUTO("auto"), LIGHT("light"), FULL("full") }

/** Cihazın bellek durumu (uygulama açılırken [App] doldurur; testlerde elle verilir). */
object DeviceMem {
    /** Java yığın sınırı bu değerin (MB) altındaysa ya da cihaz "düşük RAM" ise az bellekli sayılır. */
    const val LOW_HEAP_MB = 192

    @Volatile var lowRam = false
}

/** Bu ayarla en büyük liste atlanmalı mı? Otomatikte cihaz az bellekliyse evet. */
fun AppSettings.lightEffective(): Boolean = when (filterMem) {
    FilterMem.LIGHT -> true
    FilterMem.FULL -> false
    FilterMem.AUTO -> DeviceMem.lowRam
}
