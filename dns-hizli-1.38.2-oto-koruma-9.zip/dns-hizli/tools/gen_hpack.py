import sys
sys.path.insert(0, '/usr/local/lib/python3.13/dist-packages')
from hpack import huffman_constants as h
from hpack.table import HeaderTable
codes = h.REQUEST_CODES; lens = h.REQUEST_CODES_LENGTH
assert len(codes) == 257 and len(lens) == 257
st = HeaderTable.STATIC_TABLE
assert len(st) == 61, len(st)
out = []
out.append("package app.dnshizli.core\n")
out.append("// Bu dosya tools/gen_hpack.py ile RFC 7541 Ek A (statik tablo) ve Ek B (Huffman) verisinden üretilmiştir. Elle düzenlemeyin.\n")
out.append("internal object HpackData {")
out.append("    /** Huffman kodları (257 sembol; 256 = EOS). */")
out.append("    val HUFF_CODE = intArrayOf(" + ", ".join("0x%x" % c for c in codes) + ")")
out.append("    val HUFF_BITS = intArrayOf(" + ", ".join(str(l) for l in lens) + ")")
out.append("    /** Statik tablo, 1 tabanlı: STATIC_NAME[i], STATIC_VALUE[i] (i = 1..61). */")
names = [n.decode() for n, v in st]
vals = [v.decode() for n, v in st]
def q(s): return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'
out.append("    val STATIC_NAME = arrayOf(\"\", " + ", ".join(q(n) for n in names) + ")")
out.append("    val STATIC_VALUE = arrayOf(\"\", " + ", ".join(q(v) for v in vals) + ")")
out.append("}")
open(sys.argv[1], 'w').write("\n".join(out) + "\n")
print("ok", names[:3], names[-1])
