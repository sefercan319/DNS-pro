# Filtre listeleri: otomatik güncelleme kurulumu

Uygulama, engelleme listelerini bir yayın adresinden imzalı olarak indirir. Kurulum bir kez yapılır.

## Neden

Bazı siteler reklamı her gün yeni bir alan adından verir. Bu adlar kaynak listelere (EasyList vb.) birkaç saat içinde girer;
uygulamaya ulaşmaları için listelerin telefonda da sık yenilenmesi gerekir. Bu kurulumdan sonra:

- GitHub her gün listeleri yeniden üretir, imzalar ve depo içindeki "listeler" yayınına koyar.
- Uygulama Wi-Fi'deyken 12 saatte bir, mobil veride 3 günde bir yeni yayını denetler, imzayı doğrular ve listeleri değiştirir.
- Kodda hiçbir şeyi elle değiştirmen gerekmez: açık anahtar ve yayın adresi derleme sırasında GitHub'dan gelir.

## 1. Anahtar çifti (telefonda Termux ya da GitHub Codespaces)

Termux'ta önce: `pkg install openssl-tool`

    openssl ecparam -name prime256v1 -genkey -noout -out liste-anahtar.pem
    cat liste-anahtar.pem
    openssl ec -in liste-anahtar.pem -pubout -outform DER | base64 -w0

## 2. GitHub gizli değerleri

Depoda *Settings → Secrets and variables → Actions → New repository secret*:

| Ad | Değer |
|----|-------|
| `LIST_SIGNING_KEY` | `cat liste-anahtar.pem` çıktısının tamamı (BEGIN/END satırları dahil). **Özel anahtardır**; kimseyle paylaşma, depoya koyma. |
| `LIST_PUBLIC_KEY` | son komutun çıktısı (tek satır base64). Açık anahtardır; APK derlenirken uygulamaya gömülür. |

Özel anahtarı kaybedersen yeni anahtar üretip iki değeri de güncellemen ve uygulamanın yeni sürümünü yayınlaman gerekir.

## 3. İlk yayın ve derleme

1. *Actions → "Filtre listelerini yayınla" → Run workflow*: ilk "listeler" yayını oluşur (sonra her gün kendiliğinden çalışır).
2. APK ya da AAB'yi her zamanki gibi derle. `LIST_PUBLIC_KEY` tanımlı olduğu için güncelleme açık derlenir; yayın adresi
   deponun kendi adresidir (`https://github.com/<sahip>/<depo>/releases/download/listeler/`).

`LIST_PUBLIC_KEY` tanımlı değilse uygulama hiçbir indirme yapmaz (güvenli varsayılan). Yayın iptal edilen durumlar: liste boyu
100 KB'ın altındaysa, imza anahtarı yoksa.

## Eski yöntem (elle)

İstersen `platform/ListUpdater.kt` içindeki `PUBLIC_KEY_B64` ve `BASE_URL_FALLBACK` alanlarını elle de doldurabilirsin;
derleme ortamından gelen değerler önceliklidir.
