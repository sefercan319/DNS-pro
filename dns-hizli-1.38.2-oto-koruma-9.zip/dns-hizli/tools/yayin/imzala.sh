#!/usr/bin/env bash
# Filtre listelerini manifestle birlikte hazırlar ve manifesti imzalar (ECDSA P-256, SHA-256).
# Girdi : app/src/main/assets/filter/{basic,medium,strict}.bin (tools/build_filter.py üretir)
# Ortam : LIST_SIGNING_KEY = özel anahtar PEM içeriği (GitHub Secret; depoya ASLA konmaz)
# Çıktı : dist/manifest.txt, dist/manifest.sig, dist/*.bin
set -euo pipefail

SRC="app/src/main/assets/filter"
OUT="dist"
LISTS=(basic.bin medium.bin strict.bin)

: "${LIST_SIGNING_KEY:?LIST_SIGNING_KEY tanımlı değil}"
rm -rf "$OUT" && mkdir -p "$OUT"

for f in "${LISTS[@]}"; do
  cp "$SRC/$f" "$OUT/$f"
  # Boş ya da küçük bir liste yayınlanmaz: tüm kullanıcılarda engellemeyi kapatır (uygulamadaki MIN_FILE ile aynı eşik).
  size=$(stat -c %s "$OUT/$f")
  if [ "$size" -lt 100000 ]; then echo "::error::$f çok küçük ($size bayt), yayın iptal"; exit 1; fi
done

VERSION=$(date -u +%s)
{
  echo "DNSHIZLI-LISTE 1"
  echo "surum=$VERSION"
  echo "tarih=$(date -u +%F)"
  for f in "${LISTS[@]}"; do
    echo "$f $(sha256sum "$OUT/$f" | cut -d' ' -f1) $(stat -c %s "$OUT/$f")"
  done
} > "$OUT/manifest.txt"

KEY="$(mktemp)"
trap 'rm -f "$KEY"' EXIT
printf '%s\n' "$LIST_SIGNING_KEY" > "$KEY"
openssl dgst -sha256 -sign "$KEY" -out "$OUT/manifest.sig" "$OUT/manifest.txt"
echo "Yayın hazır: sürüm $VERSION"
