import app.dnshizli.core.Hpke
import app.dnshizli.core.X25519
import java.io.File
import java.security.SecureRandom

fun d(s: String): ByteArray = if (s == "-") ByteArray(0) else s.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
fun e(b: ByteArray): String = if (b.isEmpty()) "-" else b.joinToString("") { "%02x".format(it) }

fun main(args: Array<String>) {
    val rows = File(args[0]).readLines().filter { it.isNotBlank() }
    val out = StringBuilder()
    var fails = 0
    val info0 = "[yön 1] pyhpke gönderici -> Kotlin alıcı"
    for ((i, line) in rows.withIndex()) {
        val f = line.split(" ")
        val skR = d(f[0]); val pkR = d(f[1]); val info = d(f[2]); val aad = d(f[3]); val pt = d(f[4])
        val aad2 = d(f[5]); val pt2 = d(f[6]); val enc = d(f[7]); val ct1 = d(f[8]); val ct2 = d(f[9])
        val exp = d(f[10]); val skE = d(f[11]); val pkE = d(f[12])
        // Yön 1
        val ctx = Hpke.setupBaseR(enc, skR, info)
        val ok1 = ctx != null &&
            ctx.open(aad, ct1)?.contentEquals(pt) == true &&
            ctx.open(aad2, ct2)?.contentEquals(pt2) == true &&
            ctx.export("odoh test".toByteArray(), 32).contentEquals(exp)
        if (!ok1) { fails++; System.err.println("yön1 satır $i BAŞARISIZ") }
        // Yön 2: Kotlin gönderici, deterministik efemer anahtar
        val s = Hpke.setupBaseS(pkR, info, SecureRandom(), skE)
        if (s == null) { fails++; System.err.println("yön2 satır $i kurulum null"); continue }
        if (!s.enc.contentEquals(pkE)) { fails++; System.err.println("yön2 satır $i enc != pkE") }
        val c1 = s.context.seal(aad, pt)
        val c2 = s.context.seal(aad2, pt2)
        val ex2 = s.context.export("odoh test".toByteArray(), 32)
        out.append(listOf(e(s.enc), e(c1), e(c2), e(ex2)).joinToString(" ")).append('\n')
    }
    File(args[1]).writeText(out.toString())
    println("$info0: ${rows.size} vektör, Kotlin tarafı başarısız: $fails")
    if (fails > 0) kotlin.system.exitProcess(1)
}
