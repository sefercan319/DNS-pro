# Bağımsız referans (pyhpke, RFC 9180). Girdi/çıktı vektörleri üretir.
import json, os, sys
from pyhpke import CipherSuite, KEMId, KDFId, AEADId

suite = CipherSuite.new(KEMId.DHKEM_X25519_HKDF_SHA256, KDFId.HKDF_SHA256, AEADId.AES128_GCM)
kem = suite.kem
N = int(sys.argv[1]) if len(sys.argv) > 1 else 50
cases = []
for i in range(N):
    skr_b = os.urandom(32)
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
    from cryptography.hazmat.primitives import serialization as S
    pkr_b = X25519PrivateKey.from_private_bytes(skr_b).public_key().public_bytes(S.Encoding.Raw, S.PublicFormat.Raw)
    pkr = kem.deserialize_public_key(pkr_b)
    info = os.urandom(i % 33)
    aad = os.urandom((i * 7) % 40)
    pt = os.urandom((i * 13) % 200)
    enc, ctx = suite.create_sender_context(pkr, info)
    ct1 = ctx.seal(pt, aad)
    aad2 = os.urandom(5)
    pt2 = os.urandom(17)
    ct2 = ctx.seal(pt2, aad2)                       # ikinci mesaj (seq = 1)
    exp = ctx.export(b"odoh test", 32)
    # Dir2 için Kotlin'in kullanacağı deterministik gönderici anahtarı
    ske_b = os.urandom(32)
    ske_pub = X25519PrivateKey.from_private_bytes(ske_b).public_key().public_bytes(S.Encoding.Raw, S.PublicFormat.Raw)
    cases.append(dict(skR=skr_b.hex(), pkR=pkr_b.hex(), info=info.hex(), aad=aad.hex(), pt=pt.hex(),
                      aad2=aad2.hex(), pt2=pt2.hex(), enc=enc.hex(), ct1=ct1.hex(), ct2=ct2.hex(),
                      exp=exp.hex(), skE=ske_b.hex(), pkE=ske_pub.hex()))
json.dump(cases, open("/tmp/hpkeref/work/cases.json", "w"), indent=1)
print("üretildi:", len(cases))
