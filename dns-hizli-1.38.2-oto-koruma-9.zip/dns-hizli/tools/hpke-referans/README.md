# HPKE referans vektörleri

`selftest/HpkeVectors.kt` dosyası bu araçlarla üretildi. Bağımsız referans: Python `pyhpke` (RFC 9180).

1. `pip install pyhpke cryptography`
2. `python3 gen.py 50` → `cases.json` üretir (rastgele anahtarlar, iki yönde de kontrol için).
3. Kotlin tarafını derleyip çalıştır (Hpke.kt ile birlikte): `Interop.kt` girdi satırlarını okuyup Kotlin'in çıktılarını yazar.
4. Çıktıyı pyhpke alıcısıyla doğrula (yön 2).

Not: Bu araçlar yalnızca vektör üretmek ve doğrulamak içindir; uygulamanın parçası değildir.
