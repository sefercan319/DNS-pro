# Google Play mağaza metni — taslak (v1.29.1)

Play Console → *Mağaza girişi*. Varsayılan dil **İngilizce** (uygulamanın kaynak dili de İngilizce); diğer diller *Çeviri ekle* ile girilir.
Sınırlar: ad 30, kısa açıklama 80, tam açıklama 4000 karakter (hepsi kontrol edildi). Köşeli yerleri doldur.

## Ad ve kısa açıklama (12 dil)

| Dil | Ad | Kısa açıklama |
|---|---|---|
| English (varsayılan) | DNS Fast: DNS Changer | Encrypted DNS settings tool. Helps you choose a DNS provider. |
| Türkçe | DNS Hızlı | Şifreli DNS ayar aracı. Bir DNS sağlayıcısı seçmenize yardım eder. |
| Deutsch | DNS Hızlı | Verschlüsselte DNS-Einstellungen. Hilft bei der Wahl eines DNS-Anbieters. |
| Español | DNS Hızlı | Herramienta de ajustes DNS cifrados. Ayuda a elegir un proveedor DNS. |
| Français | DNS Hızlı | Réglages DNS chiffrés. Aide à choisir un fournisseur DNS. |
| Português | DNS Hızlı | Ajustes de DNS criptografado. Ajuda a escolher um provedor DNS. |
| Русский | DNS Hızlı | Настройка зашифрованного DNS. Помогает выбрать DNS-провайдера. |
| Italiano | DNS Hızlı | Impostazioni DNS cifrate. Aiuta a scegliere un provider DNS. |
| Bahasa Indonesia | DNS Hızlı | Pengaturan DNS terenkripsi. Membantu memilih penyedia DNS. |
| Tiếng Việt | DNS Hızlı | Cài đặt DNS mã hóa. Giúp chọn nhà cung cấp DNS. |
| Polski | DNS Hızlı | Ustawienia szyfrowanego DNS. Pomaga wybrać dostawcę DNS. |
| Українська | DNS Hızlı | Налаштування зашифрованого DNS. Допомагає обрати DNS-провайдера. |

> Ad Türkçe'de marka adıdır ("DNS Hızlı"). İngilizce adda aranabilirlik için açıklayıcı sürüm kullanıldı; markayı tek tutmak istersen "DNS Hızlı" yazabilirsin.

## Tam açıklama — English (varsayılan)

DNS Fast is a DNS settings tool: it sends your DNS queries, over encrypted connections (DNS-over-TLS / DNS-over-HTTPS) where the provider supports them, to a public DNS provider you choose. It can also filter queries using block lists. Filtering is best-effort and does not block everything. Provider names are for information only, not endorsements; each provider's own privacy policy applies.

Tap the orb to connect. Tap another server to switch without dropping the connection. That is all it takes.

WHAT YOU GET
• A list of ready-made public DNS providers (see each provider's own policy) and up to 8 of your own
• Encrypted DNS where supported: DNS-over-TLS and DNS-over-HTTPS, IPv4 and IPv6
• Filtering with four levels (Off / Basic / Medium / Strict) based on third-party block lists, your own allow and block lists, a counter and a list of recently blocked names. Lists ship inside the app, matching runs on your phone, and signed list updates can be downloaded (see Privacy). Lists may be incomplete or out of date
• Self-repair: if the server stops answering, the app refreshes the connection, switches to your backup server or rebuilds the tunnel by itself
• Speed tests, backup server, pause for 5 / 15 / 60 minutes
• Choose which apps use the DNS: all, only selected, or all except selected
• Separate Wi-Fi and mobile servers, connect on start, widget, quick-settings tile
• Connection test: checks whether DNS answers and whether DNSSEC validation works
• Troubleshooter that tells you why it cannot connect (another VPN, Private DNS, permission, no internet)
• Export and import your settings, optional no-history mode

DESIGN
• Glassy, fluid interface drawn from scratch, in eight styles (Aqua, Aero, Metro, Eco, Y2K, Aurora, Liquid Glass, Duru), each with its own sounds, animations and app icon, and 48 colour themes
• Your own photo as background, automatic or timed dark mode, low-power mode, high contrast, text size, TalkBack support
• 12 languages: Türkçe, English, Deutsch, Español, Français, Português, Русский, Italiano, Bahasa Indonesia, Tiếng Việt, Polski, Українська

LIGHT
• No loop runs while the screen is off, small size, no third-party libraries

PRIVACY
• No account. The app shows no advertising and contains no analytics SDK. Query names are not stored, and nothing is sent to the developer
• Block lists are refreshed from a fixed HTTPS address (GitHub) and only used if their digital signature checks out; no personal or device data is sent in that request, but the host can see your IP address. Details are in the privacy policy
• Your DNS queries go to the DNS provider you choose, encrypted by default. If you turn encryption off, plain DNS is used. The provider's own privacy policy applies

OUR PROMISE
We do not claim to be the best ad blocker or DNS filter. Our motto: we are not the best, but we get the job done. Where we fall short, we say so.

HOW THE VPN INTERFACE IS USED (Android VpnService)
DNS Fast uses Android's VPN interface locally, only to send DNS queries to the server you picked. It is not a remote VPN service: your traffic is never sent to any VPN server. By default only DNS queries use the interface and everything else continues on its normal route. Two optional switches, both off by default ("DPI bypass" and "Ads+"), route the phone's internet traffic through the app on the device itself so it can split packets or block ad hosts by name; that traffic goes straight to its destination and is never inspected beyond the host name, never stored and never sent to us. The app explains this on first launch and asks for Android's VPN permission.

GOOD TO KNOW
• Android allows one VPN at a time, so the app cannot connect while another VPN app is on.
• Some browsers' "secure DNS" setting and Android's Private DNS pinned to a host name use their own server and can bypass this app. "Automatic" or "Off" is enough.
• With encryption off, some networks (carrier, school, company) may redirect DNS traffic.

## Tam açıklama — Türkçe

DNS Hızlı bir DNS ayar aracıdır: DNS sorgularını, sağlayıcı destekliyorsa şifreli bağlantıdan (DNS-over-TLS / DNS-over-HTTPS), seçtiğin herkese açık DNS sağlayıcısına iletir. Engel listeleriyle sorgu süzmesi de yapabilir. Süzme en iyi çaba esaslıdır, her şeyi engelleyeceğini garanti etmez. Sağlayıcı adları ve açıklamaları yalnızca bilgi amaçlıdır; onay anlamına gelmez, her sağlayıcının kendi gizlilik politikası geçerlidir. Herkese açık DNS sağlayıcıları tek listede, tek dokunuşla seçilir.

Küreye dokun, bağlan. Başka bir sunucuya dokun, bağlantı kopmadan geç. Hepsi bu.

NELER VAR
• Hazır herkese açık DNS sağlayıcıları ve kendi eklediğin en fazla 8 sunucu
• Şifreli DNS (destekleyen sağlayıcılarda): DNS-over-TLS ve DNS-over-HTTPS, IPv4 ve IPv6
• Üçüncü taraf engel listelerine dayalı süzme: dört seviye (Kapalı / Basit / Orta / Sıkı), kendi izin ve engel listeni ekleme, sayaç ve son engellenen adlar. Listeler eksik ya da güncel olmayabilir; eşleştirme telefonda yapılır (bkz. Gizlilik)
• Yeniden bağlanma: sunucu cevap vermezse bağlantıyı yenilemeyi, yedeğe geçmeyi ya da tüneli yeniden kurmayı dener
• Hız ölçümü ve geçmiş grafiği, yedek sunucu, otomatik yeniden bağlanma, 5 / 15 / 60 dk duraklatma
• DNS'in hangi uygulamalara uygulanacağını seç: hepsi, yalnızca seçilenler ya da seçilenler hariç
• Wi-Fi ve mobil veri için ayrı sunucu, widget, hızlı ayarlar kutucuğu
• Bağlantı testi: DNS yanıt veriyor mu, DNSSEC doğrulaması çalışıyor mu
• Bağlanamazsan nedeni söyleyen sorun giderici
• Ayarları dışa / içe aktarma

TASARIM
• Cam, akışkan arayüz: sekiz stil (Aqua, Aero, Metro, Eco, Y2K, Aurora, Liquid Glass, Duru; her birinin kendi sesi, animasyonu ve simgesi var) ve 48 renk teması
• Kendi fotoğrafın arka plan, koyu mod, düşük güç modu, yüksek kontrast, yazı boyutu, TalkBack desteği
• 12 dil: Türkçe, English, Deutsch, Español, Français, Português, Русский, Italiano, Bahasa Indonesia, Tiếng Việt, Polski, Українська

BİZ KİMİZ, NE SÖZ VERİYORUZ
En iyi reklam engelleyici ya da DNS filtresi olduğumuzu iddia etmiyoruz. Mottomuz: en iyi değiliz ama işimizi görürüz. Eksik kaldığımız yerleri açıkça söylüyoruz.

HAFİF
• Ekran kapalıyken döngü yok, küçük boyut, harici kütüphane yok

GİZLİLİK
• Hesap yok. Uygulamada reklam yok ve analitik kütüphanesi yok. Sorgu adları kaydedilmez, geliştiriciye hiçbir şey gönderilmez
• Engelleme listeleri sabit bir HTTPS adresinden (GitHub) yenilenir ve yalnızca dijital imzası doğrulanırsa kullanılır; bu istekte kişisel ya da cihaz verisi gönderilmez, ancak sunucu IP adresini görebilir. Ayrıntı gizlilik politikasında
• DNS sorguların seçtiğin sağlayıcıya varsayılan olarak şifreli gider. Şifrelemeyi kapatırsan düz DNS kullanılır. Sağlayıcının kendi gizlilik politikası geçerlidir

VPN ARAYÜZÜNÜN KULLANIMI (Android VpnService)
DNS Hızlı, Android'in VPN arayüzünü yerelde, DNS sorgularını seçtiğin sunucuya iletmek için kullanır. Uzak bir VPN hizmeti değildir: trafiğin hiçbir VPN sunucusuna gönderilmez. Varsayılan olarak yalnızca DNS sorguları arayüzden geçer, geri kalan her şey normal yolundan devam eder. Varsayılan olarak kapalı iki isteğe bağlı düğme ("DPI atlatma" ve "Reklam+") telefonun internet trafiğini cihazın içinde uygulamadan geçirir; amaç paketleri bölmek ya da reklam sunucularını adıyla engellemektir. Bu trafik doğrudan hedefine gider; saklanmaz, bize gönderilmez. Uygulama bunu ilk açılışta anlatır.

BİLMEN GEREKENLER
• Android aynı anda tek VPN'e izin verir; başka bir VPN uygulaması açıkken bu uygulama bağlanamaz.
• Tarayıcının "güvenli DNS" ya da Android "Özel DNS" ayarı bu uygulamayı atlayabilir; bu uygulamanın çalışması için "Otomatik" ya da "Kapalı" seçmeniz gerekebilir.
• Şifreleme kapalıyken bazı ağlar (operatör, okul, şirket) DNS trafiğini kendi sunucusuna yönlendirebilir.

> Diğer 10 dilde tam açıklama: uygulamanın kendi dil dosyalarından çeviri yapılabilir; yetkin bir kişiye okutmadan yayınlama. Başlangıçta yalnızca ad + kısa açıklama + İngilizce tam metin yeterlidir.

## Yenilikler (sürüm notu, en çok 500 karakter)
English:
• With Ads+ on, apps that ask a fixed DNS server (like 8.8.8.8) are now sent to your chosen DNS and filter
• DNS over TCP is filtered too
• Ads+ no longer misses sites that hide their name with ECH
• Blocked names can no longer slip through odd queries
• Sturdier filter, signed list updates, Duru style, 48 themes, 28 backgrounds

Türkçe:
• Reklam+ açıkken kendi DNS sunucusuna (8.8.8.8 gibi) soran uygulamalar artık seçtiğin DNS'e ve süzgece yönlenir
• TCP üzerinden DNS de süzülür
• Reklam+, adını ECH ile gizleyen sitelerde de çalışır
• Engelli adlar tuhaf sorgularla sızamaz
• Daha sağlam filtre, imzalı liste güncellemesi, Duru stili, 48 tema, 28 arka plan

## Kategori ve etiketler
Kategori: Araçlar. Etiketler: ağ, DNS, hız, gizlilik.

## İletişim
E-posta: [e-posta adresin] · Gizlilik politikası URL: [yayınladığın adres]

## Görseller
- Simge: `ikon-512.png` (512×512)
- Öne çıkan görsel: `one-cikan-gorsel-1024x500.png` (1024×500)
- Ekran görüntüleri: **kendi telefonundan** al (en az 2, tercihen 4–8): bağlı ana ekran, sunucu listesi, engelleme sayfası, ayarlar/temalar. `previews/` çizim önizlemesidir, mağazada gerçek ekran görüntüsü kullan.

Play Console beyanları (veri güvenliği, VPN, önplan hizmeti) için `store/play_beyanlari.md`.
