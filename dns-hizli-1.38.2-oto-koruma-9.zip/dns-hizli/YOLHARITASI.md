# Yol haritası

## Yapıldı
- Aşama 15 (v1.9.7): IPv4 + IPv6, gizlilik sertleştirmesi, DNS hata düzeltmeleri.
- Aşama 16 (v1.9.8): Y2K ve Metro yeniden çizildi, Frutiger Aurora eklendi (6 stil).
- Aşama 17 (v1.9.9): reklam, izleyici ve zararlı site engelleme (4 seviye, izin ve engel listesi, son engellenenler, sayaç).
- Aşama 18 (v1.9.10): ilk 8 sunucu + Tümünü göster / Daha az göster, Özel DNS ekle üstte, ince kaydırma çubuğu.
- Aşama 19 (v1.9.11): kalite ve güvenlik denetimi; sunucu değişiminde kesintisiz sınama, uzun yeniden deneme, olumsuz önbellek, AAB iş akışı.
- Aşama 24 (v1.11.0): ses efektleri (6 tını × 9 olay, kodla sentez), baştan yazılan animasyon motoru (yay fiziği), her stile özgü dokunma efekti ve bağlanma kutlaması, ☰ → Ses ve hareket sayfası, profiller, sessiz saatler, titreşim desenleri, modülleri hatırla. Ses çalma ve efektler telefonda denenmedi.
- Aşama 23 (v1.10.0): iki büyük özellik: **DPI atlatma** ve **Reklam+** (gelişmiş reklam engelleme), ana ekranda iki bağımsız büyük kart; küre (DNS) ile birlikte üçü aynı anda çalışabilir. Altında sıfırdan yazılmış kullanıcı alanı TCP/UDP aktarıcısı. Telefonda denenmedi.
- Aşama 22 (v1.9.14): altyapı en yeniye taşındı (AGP 9.4, Gradle 9.8, JDK 25, Kotlin 2.4.20, eylemler son sürüm); kendi engelleme listeni içe/dışa aktar, bildirim sistemi (bağlandı/koptu/zaman aşımı/durdu) + ilk açılışta izin, sorgu gecikme grafiği, kapalı kalırsa dur.
- Aşama 21 (v1.9.13): kendi TCP katmanımız (DNS-over-TCP): "kesildi" sonrası TCP yeniden denemeleri karşılanır.
- Aşama 20 (v1.9.12): kendini onarma (kademeli), manifest denetim testi, mağaza metni 12 dil + Play beyanları.

## Sıradaki
1. **Arayüz düzeltmeleri:** bildirilen yeni hatalar (kalan arayüz sorunları).
2. **Telefonda deneme:** v1.9.11 servis değişiklikleri (sunucu değişimi, yeniden deneme) gerçek telefonda sınanmalı.
3. Kalan: benzersiz applicationId, kendi yayın anahtarın. (Yukarı akışa TCP, yani düz UDP yukarı akışta 1232 baytı aşan cevaplar, DPI başlığındaki genel TCP aktarmayla gelecek.)
4. Play Store: metin ve beyanlar hazır (`store/`); sende kalan: benzersiz kimlik, kendi anahtar, gizlilik politikası adresi, gerçek ekran görüntüleri, 14 gün test.
5. (İsteğe bağlı, düşük öncelik) `selftest/` testlerini Gradle'a bağlama (`src/test` ya da `sourceSets`), Android Studio ve CI'dan çalışsın diye. Şimdilik `run-tests.sh` yeterli.

## Eklenecekler (istek üzerine)
- **Sahte paket (TCP_MD5SIG), deneysel:** Shroudly 2.5.6'nın Linux hilesi. Bağlantıya MD5 imza seçeneği eklenir; sunucu eşleşen anahtarı olmadığı için sahte paketi kendisi atar, DPI ise içeriği okur. Sonra çekirdeğin yeniden iletimi gerçek veriyi taşır (`vmsplice` ile verilen sayfa, yeniden iletimden önce gerçek veriyle değiştirilir). Durum tutan DPI'lara (İran/Çin tipi) karşı.
  Bilinmeyenler (önce telefonda ölçülmeli): (1) NDK/JNI gerekir (Kotlin `Os` sınıfı bu yapıyı ayarlayamaz), (2) Android çekirdeğinde `CONFIG_TCP_MD5SIG` açık mı, (3) uygulama sandbox'ı (seccomp/SELinux) `setsockopt` ve `vmsplice`'a izin veriyor mu, (4) Türkiye DPI'ında faydası belirsiz.
  Plan: önce yalnızca "bu cihazda destekleniyor mu" sınayan küçük test sürümü (varsayılan kapalı, tanılama raporuna tek satır); sonuç olumluysa sıra listesinde EN SONA (`TLS_ORDER` sonu) eklenir. Ayrıntı: SURUM_NOTLARI.md 1.34.0. (Araştırma raporuna göre NDK gerektiren her şey gibi 16 KB sayfa boyutlu yeni çekirdeklerde de ayrıca sınanmalı.)
- **ECH (1.36.0'da anahtar eklendi):** gerçek ECH erişim sınaması API 37 sınıfları (compileSdk 36'da yok) ve Android 17 cihaz ister; DoQ/DoH3 ve QUIC Initial yeniden kurma 1.38.0'da yapıldı; sıradakiler: QUIC Retry ve 0-RTT desteği, anahtar güncelleme, sağlayıcı QUIC bayraklarının gerçek ağda doğrulanması, çift paketli (Kyber) QUIC ClientHello. Sahte paket 1.37.0'da sendfile ile yapıldı (MD5/NDK gerekmedi); cihazda sınanması ve TTL'in ağa göre otomatik seçilmesi (autottl) sıradaki iş.
- **Sıradaki adaylar (1.35.0 araştırmasından, yapılmadı):** yöntem zincirleme (planlayıcıyı tek yöntemden küçük kombinasyonlara genişletme, Outline `tls|tlsfrag:1` modeli), Android 17'de ECH/DoH erişim testi (cihaz gerekir), liste biçimini joker (wildcard) biçime ve sıkıştırılmış trie'ye taşıma (HaGeZi/OISD lisansı doğrulanmadan gömülmez), uzaktan imzalı engel sayfası IP listesi.

## Gelecek planı (uzun, ayrı ana başlık)
- **DPI atlatma:** kendi yerel kodumuzla (dış kütüphane gömmeden), cihazda çalışır, kademeli ve deneysel, varsayılan kapalı.
  Aşamalar: (a) modüler tünel mimarisi ve "tüm trafiği geçir" anahtarı, (b) kendi TCP aktarma katmanımız (DNS için sunucu tarafı TCP Aşama 21'de yazıldı; genel aktarma onun üzerine kurulur), (c) atlatma yöntemleri
  ve gerçek telefonda deneme. DNS ve DPI ileride tek uygulamada birleşir.
- **Röle (IP gizleme):** sağlayıcının IP'nizi görmemesi için; güvenilir röle seçenekleri araştırılarak.

## Android 17 (API 37) hazırlığı

Şu an hedef SDK 36'dır; Android 17 cihazlarda sistem uygulamaya eski davranışları uygular, uygulama açılır ve çalışır. Hedefi 37'ye
çıkarmadan önce şunlar ele alınmalıdır (kaynak: developer.android.com/about/versions/17/behavior-changes-17):

- **Yerel ağ izni (`ACCESS_LOCAL_NETWORK`, hedef 37'de zorunlu):** ağ geçidi açıkken uygulamanın kendi soketleriyle yerel ağa (192.168.x,
  10.x…) çıkan akışlar ve yerel yönlendirici DNS'i bu izne bağlanır. Bildirim + çalışma zamanı isteği ve reddedilince zarif düşüş gerekir.
- **ECH varsayılan açık:** Dpi, ClientHello'daki ECH uzantısını zaten tanır (`Hello.ech`); gerçek SNI görünmediğinden Reklam+ bu bağlantıda
  ad bazlı karar veremez. Ağ güvenlik yapılandırmasında `<domainEncryption>` ile uygulamanın kendi bağlantıları için mod seçilebilir.
- **Sertifika Şeffaflığı (CT) varsayılan açık:** DoH/ODoH sunucu sertifikaları CT uyumlu olmalıdır; özel DoH sunucularında deneyin.
- **Arka plan ses sertleştirmesi:** arka plandan çalınan sesler sessizce başarısız olur (çökme yok); kutucuk/widget ses geri bildirimi etkilenebilir.
- **Bellek sınırı (tüm uygulamalar):** önceki süreç bellek sınırıyla sonlandırıldıysa günlüğe "önceki süreç: …" satırı yazılır.
- **RemoteViews bellek sınırı** (widget'ta bitmap yok, etkilenmez) ve büyük ekranda yön/yeniden boyutlandırma muafiyetinin kalkması.
