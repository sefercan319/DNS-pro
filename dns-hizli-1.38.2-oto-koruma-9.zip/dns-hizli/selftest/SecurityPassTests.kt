package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayInputStream
import java.io.IOException
import java.security.KeyPairGenerator
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec

/**
 * 1.30.0 güvenlik geçişi: HTTP çerçeveleme kuralları (DoH/ODoH/yapılandırma alımı ortak), ODoH sorgusunun tek kullanımlık
 * olması ve gizli malzemenin silinmesi, liste güncelleme manifesti ve anahtar eğrisi, Reklam+ için istek satırı hedefi.
 */
fun runSecurityPassTests() {
    println("\n1.30.0 güvenlik geçişi testleri\n")
    httpRulesTests()
    miniHttpsStrictTests()
    odohSingleUseTests()
    listUpdateStrictTests()
    requestTargetTests()
}

private fun fails(f: () -> Unit): Boolean = try { f(); false } catch (_: IOException) { true }

private fun httpRulesTests() {
    T.group("HTTP kuralları: durum satırı")
    T.check("HTTP/1.1 200 OK", HttpRules.statusCode("HTTP/1.1 200 OK") == 200)
    T.check("sebep metni olmadan", HttpRules.statusCode("HTTP/1.1 204") == 204)
    T.check("HTTP/1.0 kabul", HttpRules.statusCode("HTTP/1.0 404 Not Found") == 404)
    T.check("HTTP/2 durum satırı reddedilir", fails { HttpRules.statusCode("HTTP/2 200") })
    T.check("iki basamaklı kod reddedilir", fails { HttpRules.statusCode("HTTP/1.1 20 OK") })
    T.check("dört basamaklı kod reddedilir", fails { HttpRules.statusCode("HTTP/1.1 2000 OK") })
    T.check("işaretli kod reddedilir", fails { HttpRules.statusCode("HTTP/1.1 +20 OK") })
    T.check("çift boşluk reddedilir", fails { HttpRules.statusCode("HTTP/1.1  200 OK") })
    T.check("600 reddedilir", fails { HttpRules.statusCode("HTTP/1.1 600 X") })
    T.check("ara cevaplar: 100/103 atlanır, 101 atlanmaz", HttpRules.isInterim(100) && HttpRules.isInterim(103) && !HttpRules.isInterim(101))

    T.group("HTTP kuralları: başlıklar")
    T.check("olağan başlık", HttpRules.header("Content-Type: application/dns-message") == ("content-type" to "application/dns-message"))
    T.check("değerin başındaki/sonundaki boşluk atılır", HttpRules.header("X-A:   b  ") == ("x-a" to "b"))
    T.check("ad ile ':' arasında boşluk reddedilir", fails { HttpRules.header("Content-Length : 5") })
    T.check("katlanmış başlık (obs-fold) reddedilir", fails { HttpRules.header(" devam satırı") })
    T.check("sekmeyle katlanmış başlık reddedilir", fails { HttpRules.header("\tdevam") })
    T.check("iki noktasız satır reddedilir", fails { HttpRules.header("bozuk satir") })
    T.check("adı boş satır reddedilir", fails { HttpRules.header(": deger") })
    T.check("değerde denetim karakteri reddedilir", fails { HttpRules.header("X-A: a\u0000b") })
    T.check("değerde 0x80+ bayt (obs-text) kabul", HttpRules.header("X-A: aéb").second == "aéb")

    T.group("HTTP kuralları: aktarım kodlaması ve uzunluk")
    T.check("chunked", HttpRules.chunked("chunked") && HttpRules.chunked(" Chunked "))
    T.check("identity uzunluk kullanır", !HttpRules.chunked("identity"))
    T.check("gzip reddedilir (çözülemez)", fails { HttpRules.chunked("gzip") })
    T.check("'gzip, chunked' reddedilir", fails { HttpRules.chunked("gzip, chunked") })
    T.check("'chunked, chunked' reddedilir", fails { HttpRules.chunked("chunked, chunked") })
    T.check("içerik uzunluğu 0", HttpRules.contentLength("0") == 0)
    T.check("'12, 12' reddedilir", fails { HttpRules.contentLength("12, 12") })
    T.check("10 basamak reddedilir", fails { HttpRules.contentLength("1234567890") })
    T.check("parça boyu uzantılı", HttpRules.chunkSize("1a;ext=1") == 26)
    T.check("parça boyu '0x10' reddedilir", fails { HttpRules.chunkSize("0x10") })
    T.check("parça boyu negatif reddedilir", fails { HttpRules.chunkSize("-1") })
    T.check("parça sonu boş satır kabul", !fails { HttpRules.chunkEnd("") })
    T.check("parça sonu dolu satır reddedilir", fails { HttpRules.chunkEnd("XYZ") })
    T.check("parça sonu kesik reddedilir", fails { HttpRules.chunkEnd(null) })
}

private fun miniHttpsStrictTests() {
    fun resp(text: String): Result<ByteArray> =
        runCatching { MiniHttps.readResponse(ByteArrayInputStream(text.toByteArray(Charsets.ISO_8859_1)), 10_000L, { 0L }) {} }
    T.group("Yapılandırma alımı: sıkı HTTP çerçeveleme")
    T.check("100 Continue atlanır, asıl cevap okunur",
        resp("HTTP/1.1 100 Continue\r\n\r\nHTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok").getOrNull()?.toString(Charsets.ISO_8859_1) == "ok")
    T.check("103 Early Hints başlıklarıyla atlanır",
        resp("HTTP/1.1 103 Early Hints\r\nLink: </a>; rel=preload\r\n\r\nHTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok").getOrNull()?.size == 2)
    T.check("sonsuz ara cevap dizisi sınırlanır", resp("HTTP/1.1 100 Continue\r\n\r\n".repeat(10) + "HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n").isFailure)
    T.check("101 protokol değişimi asıl cevap sayılmaz (200 değil)",
        (resp("HTTP/1.1 101 Switching Protocols\r\n\r\n").exceptionOrNull() as? MiniHttps.HttpStatusException)?.code == 101)
    T.check("parça verisinden sonra CRLF yerine veri gelirse reddedilir",
        resp("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nokXX\r\n0\r\n\r\n").isFailure)
    T.check("gzip aktarım kodlaması reddedilir", resp("HTTP/1.1 200 OK\r\nTransfer-Encoding: gzip\r\n\r\nxx").isFailure)
    T.check("'gzip, chunked' reddedilir (eskiden chunked sanılıyordu)",
        resp("HTTP/1.1 200 OK\r\nTransfer-Encoding: gzip, chunked\r\n\r\n2\r\nok\r\n0\r\n\r\n").isFailure)
    T.check("iki Transfer-Encoding başlığı reddedilir",
        resp("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nok\r\n0\r\n\r\n").isFailure)
    T.check("'Content-Length : 2' (boşluklu ad) reddedilir", resp("HTTP/1.1 200 OK\r\nContent-Length : 2\r\n\r\nok").isFailure)
    T.check("katlanmış başlık reddedilir", resp("HTTP/1.1 200 OK\r\nContent-Length: 2\r\n x\r\n\r\nok").isFailure)
    T.check("identity + uzunluk birlikte reddedilir (çelişen çerçeveleme)",
        resp("HTTP/1.1 200 OK\r\nTransfer-Encoding: identity\r\nContent-Length: 2\r\n\r\nok").isFailure)
    T.check("geçerli chunked hâlâ okunur",
        resp("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n2;x=y\r\nok\r\n1\r\n!\r\n0\r\n\r\n").getOrNull()?.toString(Charsets.ISO_8859_1) == "ok!")
}

/** Kotlin özel alanını yansımayla okur (testte gizli malzemenin silindiğini görmek için). */
private fun field(o: Any, name: String): ByteArray =
    o.javaClass.getDeclaredField(name).also { it.isAccessible = true }.get(o) as ByteArray

private fun odohSingleUseTests() {
    T.group("ODoH: sorgu tek kullanımlık, gizli malzeme silinir")
    val rng = SecureRandom()
    val sk = ByteArray(32).also { rng.nextBytes(it) }
    val pk = X25519.publicKey(sk)
    val cfg = OdohConfigs.parse(odohConfigBytes(pk))[0]
    val dns = Dns.buildQuery(0, "tek.example.com")

    run {
        val q = OdohClient.seal(cfg, dns, rng)
        val o = SimTarget.Companion.open(sk, cfg.keyId, q.wire)
        T.check("sunucu benzetimi sorguyu açar", o != null)
        if (o == null) return@run
        val resp = SimTarget.Companion.respond(o, dns)
        T.check("ilk açış başarılı", q.open(resp, 0, resp.size).contentEquals(dns))
        T.check("ilk açıştan sonra dışa aktarılan sır sıfır", field(q, "secret").all { it.toInt() == 0 })
        T.check("ilk açıştan sonra sorgunun düz metni sıfır", field(q, "plain").all { it.toInt() == 0 })
        var kind: OdohError? = null
        try { q.open(resp, 0, resp.size) } catch (e: OdohException) { kind = e.kind }
        T.check("aynı cevabı ikinci kez açmak reddedilir (tekrar oynatma)", kind == OdohError.BAD_RESPONSE)
    }
    run {
        val q = OdohClient.seal(cfg, dns, rng)
        val o = SimTarget.Companion.open(sk, cfg.keyId, q.wire)!!
        val resp = SimTarget.Companion.respond(o, dns)
        val bad = resp.copyOf().also { it[it.size - 1] = (it[it.size - 1].toInt() xor 1).toByte() }
        var kind: OdohError? = null
        try { q.open(bad, 0, bad.size) } catch (e: OdohException) { kind = e.kind }
        T.check("bozulmuş cevap AUTH hatası verir", kind == OdohError.AUTH)
        T.check("doğrulama başarısız olsa da sır silinir", field(q, "secret").all { it.toInt() == 0 })
        T.check("doğrulama başarısız olsa da düz metin silinir", field(q, "plain").all { it.toInt() == 0 })
        var after: OdohError? = null
        try { q.open(resp, 0, resp.size) } catch (e: OdohException) { after = e.kind }
        T.check("başarısız açıştan sonra gerçek cevap da kabul edilmez (sorgu harcandı)", after == OdohError.BAD_RESPONSE)
    }
    run {
        // Bozuk yapıda (kısa cevap) bile sorgu harcanır: aynı sorgu tekrar tekrar deneme tahtası olarak kullanılamaz.
        val q = OdohClient.seal(cfg, dns, rng)
        var k1: OdohError? = null
        try { q.open(ByteArray(5), 0, 5) } catch (e: OdohException) { k1 = e.kind }
        T.check("kısa cevap BAD_RESPONSE", k1 == OdohError.BAD_RESPONSE)
        T.check("kısa cevapta da sır silinir", field(q, "secret").all { it.toInt() == 0 })
    }
    run {
        // HPKE ara sırlarının silinmesi şifrelemeyi bozmamalı: RFC 5869 A.1 vektörü ve gönder-al turu.
        val prk = Hkdf.extract("000102030405060708090a0b0c".chunked(2).map { it.toInt(16).toByte() }.toByteArray(),
            ByteArray(22) { 0x0b })
        val okm = Hkdf.expand(prk, "f0f1f2f3f4f5f6f7f8f9".chunked(2).map { it.toInt(16).toByte() }.toByteArray(), 42)
        val hex = okm.joinToString("") { "%02x".format(it) }
        T.check("HKDF RFC 5869 A.1 vektörü (blok silme sonrası)",
            hex == "3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf34007208d5b887185865")
        val s = Hpke.setupBaseS(pk, "bilgi".toByteArray(), rng)!!
        val r = Hpke.setupBaseR(s.enc, sk, "bilgi".toByteArray())!!
        val ct = s.context.seal(byteArrayOf(1), "merhaba".toByteArray())
        T.check("HPKE gönder/al turu (ara sır silme sonrası)", r.open(byteArrayOf(1), ct)?.toString(Charsets.UTF_8) == "merhaba")
    }
}

private fun listUpdateStrictTests() {
    T.group("Liste güncelleme: manifest ve anahtar sertliği")
    val h = "a".repeat(64)
    fun man(vararg extra: String) = (listOf(ListUpdate.FORMAT) + extra.toList() +
        ListUpdate.UPDATABLE.map { "$it $h 200000" }).joinToString("\n").toByteArray()
    T.check("geçerli manifest okunur", ListUpdate.parse(man("surum=5"))?.version == 5L)
    T.check("iki sürüm satırı reddedilir", ListUpdate.parse(man("surum=5", "surum=9")) == null)
    T.check("'+5' sürümü reddedilir", ListUpdate.parse(man("surum=+5")) == null)
    T.check("boş sürüm reddedilir", ListUpdate.parse(man("surum=")) == null)
    T.check("çok uzun sürüm reddedilir", ListUpdate.parse(man("surum=" + "9".repeat(19))) == null)

    fun keyDer(curve: String): ByteArray =
        KeyPairGenerator.getInstance("EC").apply { initialize(ECGenParameterSpec(curve)) }.generateKeyPair().public.encoded
    T.check("P-256 anahtarı kabul", ListUpdate.publicKey(keyDer("secp256r1")) != null)
    T.check("P-384 anahtarı reddedilir (beklenmeyen eğri)", ListUpdate.publicKey(keyDer("secp384r1")) == null)
    val rsa = KeyPairGenerator.getInstance("RSA").apply { initialize(1024) }.generateKeyPair().public.encoded
    T.check("RSA anahtarı reddedilir", ListUpdate.publicKey(rsa) == null)
    T.check("bozuk anahtar reddedilir", ListUpdate.publicKey(ByteArray(10)) == null)
}

private fun requestTargetTests() {
    fun t(s: String): String? { val b = s.toByteArray(Charsets.ISO_8859_1); return Dpi.requestTargetHost(b, b.size) }
    T.group("Reklam+: istek satırı hedefi (mutlak biçim / CONNECT)")
    T.check("köken biçimli istekte hedef yok", t("GET /a HTTP/1.1\r\nHost: x.com\r\n\r\n") == null)
    T.check("mutlak biçim: ad alınır (Host farklı olsa da)", t("GET http://ads.example.com/x HTTP/1.1\r\nHost: ok.com\r\n\r\n") == "ads.example.com")
    T.check("port atılır", t("GET http://ads.example.com:8080/x HTTP/1.1\r\n\r\n") == "ads.example.com")
    T.check("büyük harf şema", t("GET HTTP://ADS.Example.COM/ HTTP/1.1\r\n\r\n") == "ads.example.com")
    T.check("https şeması", t("GET https://ads.example.com/ HTTP/1.1\r\n\r\n") == "ads.example.com")
    T.check("kullanıcı bilgisi atlatması: '@' sonrası gerçek ad", t("GET http://ok.com@ads.example.com/ HTTP/1.1\r\n\r\n") == "ads.example.com")
    T.check("sorgu dizisi", t("GET http://ads.example.com?a=b HTTP/1.1\r\n\r\n") == "ads.example.com")
    T.check("IPv6 değişmezi", t("GET http://[2001:db8::1]:8080/ HTTP/1.1\r\n\r\n") == "2001:db8::1")
    T.check("CONNECT yetki biçimi", t("CONNECT ads.example.com:443 HTTP/1.1\r\nHost: ads.example.com:443\r\n\r\n") == "ads.example.com")
    T.check("baştaki boş satırlar atlanır", t("\r\nGET http://ads.example.com/ HTTP/1.1\r\n\r\n") == "ads.example.com")
    T.check("satır sonu gelmemiş istek de okunur", t("GET http://ads.example.com/uzun-yol") == null || t("GET http://ads.example.com/uzun-yol") == "ads.example.com")
    T.check("boş girdi", t("") == null)
    T.check("şema var ama ad yok", t("GET http:/// HTTP/1.1\r\n\r\n") == null)

    T.group("Reklam+: istek satırı hedefi süzgeçte")
    val eng = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("ads.example.com"))
    val first = "GET http://ads.example.com/p HTTP/1.1\r\nHost: izinli.example.org\r\n\r\n".toByteArray(Charsets.ISO_8859_1)
    val info = Dpi.HttpInfo()
    val host = if (Dpi.parseHttp(first, first.size, info)) Dpi.httpHost(first, info) else null
    val target = Dpi.requestTargetHost(first, first.size)
    T.check("Host başlığı izinli ad", host == "izinli.example.org" && eng.verdictOf(host) == FilterVerdict.PASS)
    T.check("istek satırı hedefi engelli ad olarak yakalanır", target != null && eng.verdictOf(target) != FilterVerdict.PASS)
}
