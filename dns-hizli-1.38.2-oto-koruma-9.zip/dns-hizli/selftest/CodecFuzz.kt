package app.dnshizli.selftest

import app.dnshizli.core.*
import kotlin.random.Random

/** Ayar kodlayıcı: rastgele (basit alanlar) ayar -> kodla -> çöz aynı ayarı vermeli; dışa/içe aktarma da aynı görünüm alanlarını taşımalı. */
fun runCodecFuzz() {
    T.group("Ayar kodlayıcı: rastgele gidiş-dönüş")
    val rnd = Random(42)
    val ctor = AppSettings::class.constructors.first()
    var bad = 0; var first = ""
    var importBad = 0; var importFirst = ""
    repeat(400) {
        var s = AppSettings()
        val args = HashMap<kotlin.reflect.KParameter, Any?>()
        for (p in ctor.parameters) {
            val cls = p.type.classifier as? kotlin.reflect.KClass<*> ?: continue
            val v: Any? = when {
                cls == Boolean::class -> rnd.nextBoolean()
                cls == Float::class -> when (p.name) {
                    "glass", "soundVolume" -> rnd.nextInt(0, 101) / 100f
                    "wpDim" -> WallpaperMath.DIM_MIN + rnd.nextInt(0, 11) / 10f * (WallpaperMath.DIM_MAX - WallpaperMath.DIM_MIN)
                    "animSpeed" -> (Math.round((AppSettings.SPEED_MIN + rnd.nextFloat() * (AppSettings.SPEED_MAX - AppSettings.SPEED_MIN)) * 20f) / 20f).coerceIn(AppSettings.SPEED_MIN, AppSettings.SPEED_MAX)
                    else -> null
                }
                cls.java.isEnum -> cls.java.enumConstants[rnd.nextInt(cls.java.enumConstants.size)]
                else -> null
            }
            if (v != null) args[p] = v
        }
        s = ctor.callBy(args)
        val back = SettingsCodec.decode(SettingsCodec.encode(s))
        if (back != s && bad == 0) {
            for (p in ctor.parameters) { val a = AppSettings::class.members.first { it.name == p.name }.call(s); val b = AppSettings::class.members.first { it.name == p.name }.call(back); if (a != b) { first = "${p.name}: $a -> $b"; break } }
        }
        if (back != s) bad++
        // Dışa/içe aktarma: görünüm alanları (Look) aynen gelmeli
        val imp = SettingsCodec.import(SettingsCodec.export(s), AppSettings())
        if (imp == null || Look.changedCount(imp) != Look.changedCount(s) || imp.glass != s.glass || imp.motion != s.motion) { importBad++; if (importFirst.isEmpty()) importFirst = "changed ${imp?.let { Look.changedCount(it) }} vs ${Look.changedCount(s)}" }
    }
    T.check("400 rastgele ayar kodlayıp çözülünce aynı", bad == 0, "bozuk=$bad ilk: $first")
    T.check("400 rastgele ayar dışa/içe aktarılınca görünüm aynı", importBad == 0, "bozuk=$importBad $importFirst")
}
