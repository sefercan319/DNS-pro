package app.dnshizli.selftest

import java.io.File

/**
 * Yayın imzalama ve depo hijyeni: yayın derlemesi asla debug anahtarıyla imzalanmamalı, gizli anahtarlar depoya girmemeli,
 * bağımlılık güncellemeleri açık olmalı. Dosyalar depo kökünden ya da selftest klasöründen okunur.
 */
fun runSupplyChainTests() {
    fun find(vararg p: String): File? = p.map { File(it) }.firstOrNull { it.isFile }

    T.group("Yayın imzalama: debug anahtarına geri dönüş yok")
    run {
        val gradle = find("app/build.gradle.kts", "../app/build.gradle.kts")?.readText()
        T.check("app/build.gradle.kts okunabiliyor", gradle != null)
        if (gradle != null) {
            val release = gradle.substringAfter("release {", "").substringBefore("buildFeatures")
            T.check("release derlemesi yalnızca 'release' imza yapılandırmasını kullanır",
                release.contains("signingConfigs.getByName(\"release\")") && !release.contains("getByName(\"debug\")"))
            T.check("release imza satırı yalnızca anahtar dosyası varken eklenir (yoksa imzasız, debug'a düşmez)",
                release.contains("if (keystoreProps.isNotEmpty()) signingConfig"))
            T.check("debug anahtarı yalnızca debug yapılandırmasında geçer",
                gradle.substringAfter("getByName(\"debug\") {", "").substringBefore("}").contains("debug.keystore"))
        }
    }

    T.group("Depo hijyeni: gizli anahtarlar dışarıda")
    run {
        val ignore = find(".gitignore", "../.gitignore")?.readLines()?.map { it.trim() } ?: emptyList()
        T.check(".gitignore yayın anahtar dosyasını dışarıda tutar", "/keystore.properties" in ignore)
        T.check(".gitignore *.jks ve *.keystore dosyalarını dışarıda tutar", "*.jks" in ignore && "*.keystore" in ignore)
        T.check(".gitignore yerel SDK yolunu dışarıda tutar", "/local.properties" in ignore || "local.properties" in ignore)
    }

    T.group("Bağımlılık güncellemeleri (Dependabot)")
    run {
        val dep = find(".github/dependabot.yml", "../.github/dependabot.yml")?.readText()
        T.check("dependabot.yml mevcut", dep != null)
        if (dep != null) {
            T.check("Gradle bağımlılıkları izleniyor", dep.contains("package-ecosystem: \"gradle\""))
            T.check("GitHub Actions sürümleri izleniyor", dep.contains("package-ecosystem: \"github-actions\""))
        }
    }
}
