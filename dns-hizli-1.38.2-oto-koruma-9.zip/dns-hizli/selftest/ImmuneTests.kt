package app.dnshizli.selftest

import app.dnshizli.core.*

/** Keşif kapalı (nextInt hep en büyük değeri verir): seçimler yalnızca öğrenilmiş verimliliğe göre yapılır. */
private class NoExplore : java.util.Random() {
    override fun nextInt(bound: Int): Int = bound - 1
}

private const val MIN = 60_000L

fun runImmuneTests() {
    T.group("Güvenlik vanası: kendiliğinden geri açma takvimi")
    T.check("ilk kesinti 5 dk", GwRecovery.waitMs(1) == 5 * 60_000L)
    T.check("ikinci 15 dk, üçüncü 45 dk", GwRecovery.waitMs(2) == 15 * 60_000L && GwRecovery.waitMs(3) == 45 * 60_000L)
    T.check("üst sınır 60 dk", GwRecovery.waitMs(4) == 60 * 60_000L && GwRecovery.waitMs(50) == 60 * 60_000L)
    T.check("geçersiz sayı çökmez", GwRecovery.waitMs(0) == 5 * 60_000L && GwRecovery.waitMs(-3) == 5 * 60_000L)
    T.group("Otomatik koruma (Immune): kademeli önlem, öğrenme, rahatlama")
    run {
        // 1) eşik altı olay önlem almaz
        val a = Immune(NoExplore())
        a.report(Threat.SPOOF, 1.0, 0)
        T.check("eşik altında önlem yok", a.tick(MIN).isEmpty() && a.active().isEmpty())

        // 2) eşik aşılınca tek önlem; bekleme süresinde ikincisi yok
        val b = Immune(NoExplore())
        b.report(Threat.SPOOF, 9.0, 0)
        val c1 = b.tick(MIN)
        T.check("eşik aşılınca TEK önlem (ilk sıradaki: REFRESH)", c1.size == 1 && c1[0].threat == Threat.SPOOF && c1[0].act == Act.REFRESH && c1[0].on)
        b.report(Threat.SPOOF, 9.0, MIN + 10)
        T.check("bekleme süresi dolmadan ikinci önlem eklenmez", b.tick(MIN + 20_000).isEmpty())

        // 3) ÖĞRENME: REFRESH işe yaramaz (olaylar sürer), ENCRYPT işe yarar (olaylar biter)
        fun episode(imm: Immune): Pair<List<Act>, Int> {
            val seq = ArrayList<Act>()
            var attack = true
            var t = 0L
            for (minute in 1..40) {
                t = minute * MIN
                if (attack) imm.report(Threat.SPOOF, 9.0, t - 1000)
                for (ch in imm.tick(t)) {
                    if (ch.threat == Threat.SPOOF && ch.on) { seq.add(ch.act); if (ch.act == Act.ENCRYPT) attack = false }
                }
            }
            return Pair(seq, if (attack) 1 else 0)
        }
        val learner = Immune(NoExplore())
        val (seq1, still) = episode(learner)
        T.check("ilk saldırıda sıra: REFRESH → ENCRYPT, saldırı biter", seq1.take(2) == listOf(Act.REFRESH, Act.ENCRYPT) && still == 0, seq1.toString())
        T.check("verimlilik öğrenildi: ENCRYPT > REFRESH", learner.efficacy(Threat.SPOOF, Act.ENCRYPT) > learner.efficacy(Threat.SPOOF, Act.REFRESH),
            "enc=${learner.efficacy(Threat.SPOOF, Act.ENCRYPT)} ref=${learner.efficacy(Threat.SPOOF, Act.REFRESH)}")
        val mem = learner.encode()
        val fresh = Immune(NoExplore()); fresh.decode(mem)
        val (seq2, _) = episode(fresh)
        T.check("kayıtlı bellekle yeni oturumda ilk seçim ENCRYPT (öğrenilen)", seq2.firstOrNull() == Act.ENCRYPT, "bellek=$mem seq=$seq2")

        // 4) sürekli önlem işe yaramazsa geri alınır
        val f = Immune(NoExplore())
        val log = ArrayList<Immune.Change>()
        for (minute in 1..10) { f.report(Threat.FLOOD, 1.5, minute * MIN - 1000); log += f.tick(minute * MIN) }
        T.check("FLOOD: FLOW_SOFT açılır", log.any { it.act == Act.FLOW_SOFT && it.on })
        T.check("etkisiz kalan sürekli önlem geri alınır (FLOW_SOFT kapanır)", log.any { it.act == Act.FLOW_SOFT && !it.on }, log.toString())

        // 5) sakin dönemde önlemler tek tek geri alınır
        val r = Immune(NoExplore())
        r.report(Threat.AD_LEAK, 9.0, 0)
        val on = r.tick(MIN)
        T.check("AD_LEAK: DOH_BLOCK açılır, etkin", on.any { it.act == Act.DOH_BLOCK && it.on } && Act.DOH_BLOCK in r.active())
        val off = ArrayList<Immune.Change>()
        var tt = MIN
        while (tt < 40 * MIN) { tt += MIN; off += r.tick(tt) }
        T.check("QUIET_MS boyunca olay yoksa önlem geri alınır, etkin küme boşalır", off.any { it.act == Act.DOH_BLOCK && !it.on } && r.active().isEmpty())

        // 6) keşif: %15 olasılıkla aday rastgele seçilir (en azından bazen sıra dışı)
        var offOrder = 0
        for (seed in 1..200) {
            val e = Immune(java.util.Random(seed.toLong()))
            e.report(Threat.SPOOF, 9.0, 0)
            val ch = e.tick(MIN)
            if (ch.isNotEmpty() && ch[0].act != Act.REFRESH) offOrder++
        }
        T.check("keşif: seçimlerin bir kısmı sıra dışı (ama çoğu değil)", offOrder in 5..70, "sıra dışı=$offOrder/200")

        // 7) saldırı bitince eşik altı kalır: yeniden tetiklenmez
        val q = Immune(NoExplore())
        q.report(Threat.BAD_SERVER, 7.0, 0)
        val first = q.tick(MIN)
        T.check("BAD_SERVER: ilk önlem BACKUP", first.size == 1 && first[0].act == Act.BACKUP)
        T.check("olay gelmeyince yeni önlem eklenmez", (2..8).all { q.tick(it * MIN).none { c -> c.on } })

        // 8) dayanıklılık: bozuk bellek, aşırı olay, NaN
        val z = Immune(NoExplore())
        z.decode("SPOOF:REFRESH=abc;;=;X:Y=1;SPOOF:ENCRYPT=9;FLOOD:BACKUP=0.5;" + "A".repeat(10))
        T.check("bozuk bellek girdisi atlanır, geçerli değer 0..1'e kırpılır", z.efficacy(Threat.SPOOF, Act.ENCRYPT) == 1.0 && z.efficacy(Threat.FLOOD, Act.BACKUP) == Immune.PRIOR)
        z.decode("x".repeat(5000))
        repeat(2000) { z.report(Threat.FLOOD, 1e9, it.toLong()) }
        z.report(Threat.FLOOD, Double.NaN, 5); z.report(Threat.FLOOD, -3.0, 5)
        T.check("aşırı/NaN olayda çökmez, olay sayısı sınırlı", z.score(Threat.FLOOD, 2000) <= Immune.MAX_EVENTS * Immune.MAX_WEIGHT)
    }
    T.group("Otomatik koruma (Immune): yan etki freni, devre kesici, taban, kalıcılık, onarım")
    run {
        // Yan etki: AD_LEAK'e DOH_BLOCK açılır, tehdit biter AMA kullanıcı sorunları patlar → önlem geri alınır ve yasaklanır
        val a = Immune(NoExplore())
        a.report(Threat.AD_LEAK, 9.0, 0)
        val on = a.tick(MIN)
        T.check("yan etki: önlem önce açılır", on.any { it.act == Act.DOH_BLOCK && it.on })
        var undone = false
        for (m in 2..8) {
            val t = m * MIN
            a.harm(2.0, t - 1000)                                       // önlemden sonra kullanıcı sorunları
            if (a.tick(t).any { it.act == Act.DOH_BLOCK && !it.on }) undone = true
        }
        T.check("tehdit bitse de zarar veren önlem geri alınır", undone && Act.DOH_BLOCK !in a.active())
        T.check("geri alınan önlem yasaklanır", a.banned(Threat.AD_LEAK, Act.DOH_BLOCK, 8 * MIN))
        T.check("yan etki cezası verimliliği düşürür", a.efficacy(Threat.AD_LEAK, Act.DOH_BLOCK) < 0.35, a.efficacy(Threat.AD_LEAK, Act.DOH_BLOCK).toString())

        // Devre kesici: etkisiz sürekli önlem yasaklanır; süre tekrarda uzar; yasakken seçilmez
        val b = Immune(NoExplore())
        val seen = ArrayList<Pair<Long, Act>>()
        for (m in 1..120) {
            val t = m * MIN
            b.report(Threat.FLOOD, 1.5, t - 1000)
            for (c in b.tick(t)) if (c.on) seen.add(Pair(t, c.act))
        }
        val soft = seen.filter { it.second == Act.FLOW_SOFT }.map { it.first }
        T.check("yasak süresince aynı önlem yeniden denenmez (salınım koruması)", soft.size in 1..4 && soft.zipWithNext().all { (x, y) -> y - x >= 10 * MIN }, soft.toString())
        T.check("yasak süresi tekrarda uzar", soft.size < 3 || (soft[2] - soft[1]) > (soft[1] - soft[0]), soft.toString())

        // Uyarlamalı taban: sürekli düşük gürültü eşiği yükseltir
        val n = Immune(NoExplore())
        val base0 = n.threshold(Threat.SPOOF)
        for (m in 1..60) { n.report(Threat.SPOOF, 1.0, m * MIN - 1000); n.tick(m * MIN) }
        T.check("gürültülü ağda eşik yükselir (ama en çok 2 kat)", n.threshold(Threat.SPOOF) > base0 && n.threshold(Threat.SPOOF) <= base0 * 2.0 + 1e-9,
            "${n.threshold(Threat.SPOOF)} / $base0")
        T.check("gürültü eşiğin altında kaldığı için önlem alınmadı", n.applied(Threat.SPOOF).isEmpty())

        // Küresel sınır: iki tehdit aynı anda → önce en acil, ikincisi sonraki turda
        val g = Immune(NoExplore())
        g.report(Threat.SPOOF, 9.0, 0); g.report(Threat.FLOOD, 9.0, 0)
        val first = g.tick(MIN)
        T.check("aynı turda tek müdahale, en acil olan (FLOOD)", first.size == 1 && first[0].threat == Threat.FLOOD, first.toString())
        g.report(Threat.SPOOF, 9.0, MIN + 30_000)
        val second = g.tick(2 * MIN)
        T.check("ikinci tehdit sonraki turda ele alınır", second.any { it.threat == Threat.SPOOF && it.on }, second.toString())

        // Beta öğrenme: eski bilgi unutulur
        val l = Immune(NoExplore())
        l.decode("SPOOF:REFRESH=0.00:20.00")
        val bad = l.efficacy(Threat.SPOOF, Act.REFRESH)
        T.check("eski kayıt biçimi (tek değer) okunur", Immune().also { it.decode("SPOOF:REFRESH=0.9") }.efficacy(Threat.SPOOF, Act.REFRESH) > 0.85)
        T.check("kötü ölçülen önlem düşük verimli", bad < 0.1, bad.toString())

        // Kalıcılık: açık önlemler ve yasaklar yeniden başlatmada geri gelir
        val p = Immune(NoExplore())
        p.report(Threat.AD_LEAK, 9.0, 0); p.tick(MIN)
        val saved = p.encodeAll(MIN)
        val q = Immune(NoExplore())
        val restored = q.decodeAll(saved, 5 * MIN)
        T.check("açık önlem geri yüklenir", restored.any { it.act == Act.DOH_BLOCK && it.on } && Act.DOH_BLOCK in q.active(), saved)
        val relax = ArrayList<Immune.Change>()
        var tt = 5 * MIN
        while (tt < 30 * MIN) { tt += MIN; relax += q.tick(tt) }
        T.check("geri yüklenen önlem sakin dönemde geri alınır", relax.any { it.act == Act.DOH_BLOCK && !it.on } && q.active().isEmpty())
        T.check("bozuk durum metni çökertmez", Immune().decodeAll("A.X.Y;B.a;|A.AD_LEAK.NOPE;B.SPOOF.REFRESH.abc.1;" + "z".repeat(9000), 0).isEmpty() &&
            Immune().decodeAll("x|A.SPOOF.REFRESH", 0).isEmpty())
        val bb = Immune(NoExplore())
        bb.report(Threat.FLOOD, 1.5, 0)
        for (m in 1..10) { bb.report(Threat.FLOOD, 1.5, m * MIN - 1000); bb.tick(m * MIN) }
        val withBan = bb.encodeAll(10 * MIN)
        val rb = Immune(NoExplore()); rb.decodeAll(withBan, 0)
        T.check("yasak kalan süreyle geri yüklenir", rb.banned(Threat.FLOOD, Act.FLOW_SOFT, 1000) == bb.banned(Threat.FLOOD, Act.FLOW_SOFT, 10 * MIN + 1000), withBan)

        // Kendini onarma: gelecek zamanlı olay, saat geri sarması, sayaç bozulması
        val h = Immune(NoExplore())
        h.report(Threat.SPOOF, 5.0, 10 * MIN)                          // şimdi 1. dakika: olay geleceğe ait
        h.decode("SPOOF:ENCRYPT=1.00:0.00")
        val fixed = h.selfCheck(MIN)
        T.check("geleceğe ait olay onarılır", fixed >= 1 && h.score(Threat.SPOOF, MIN) == 0.0 && h.repairs >= 1)
        val c = Immune(NoExplore())
        c.report(Threat.SPOOF, 9.0, 50 * MIN); c.tick(50 * MIN)
        val after = c.tick(2 * MIN)                                    // saat geri sarıldı
        T.check("saat geri sarılınca durum temizlenir, çökmez", c.repairs >= 1 && after.none { it.on })

        // Çok sayıda rastgele işlemde değişmezler korunur (kaba dayanıklılık)
        val rnd = java.util.Random(7)
        val f = Immune(java.util.Random(3))
        var ok = true
        var now = 0L
        repeat(3000) {
            now += rnd.nextInt(120_000).toLong()
            val t = Threat.values()[rnd.nextInt(Threat.values().size)]
            when (rnd.nextInt(4)) {
                0 -> f.report(t, rnd.nextDouble() * 12, now)
                1 -> f.harm(rnd.nextDouble() * 5, now)
                2 -> f.tick(now) { rnd.nextInt(5) != 0 }
                else -> if (rnd.nextInt(50) == 0) f.decode(f.encode())
            }
            for (th in Threat.values()) { val ap = f.applied(th); if (ap.toSet().size != ap.size || ap.any { it !in th.ladder }) ok = false }
        }
        T.check("3000 rastgele işlemde tekrar/geçersiz önlem yok, kayıt geri okunur", ok && Immune().also { it.decode(f.encode()) }.encode().length <= f.encode().length + 8)
    }
    T.group("Otomatik koruma (Immune): benzetim — yanlış alarm ve salınım oranı")
    run {
        fun poisson(r: java.util.Random, lambda: Double): Int { var k = 0; var p = 1.0; val l = Math.exp(-lambda); do { k++; p *= r.nextDouble() } while (p > l); return k - 1 }
        // Sakin ama gürültülü bir ağ: ara sıra tek hatalar, ara sıra kısa süreli ağ kesintisi, ara sıra tek dakikalık akış patlaması
        var totalOn = 0; var runsWithAny = 0; val by = HashMap<String, Int>()
        for (seed in 1..40) {
            val r = java.util.Random(seed.toLong()); val im = Immune(java.util.Random(seed + 1000L))
            var ons = 0
            for (m in 1..1440) {
                val t = m * MIN
                repeat(poisson(r, 0.08)) { im.report(Threat.SPOOF, 1.0, t - 500) }
                repeat(poisson(r, 0.04)) { im.report(Threat.BAD_SERVER, 1.0, t - 500) }
                if (r.nextInt(100) < 4) im.report(Threat.NET_BLOCK, 1.0, t - 500)
                if (r.nextInt(100) < 1) im.report(Threat.FLOOD, 1.2, t - 500)
                if (r.nextInt(100) < 4) im.harm(1.0, t - 500)
                for (c in im.tick(t)) if (c.on) { ons++; by.merge(c.threat.name + ":" + c.act.name, 1, Int::plus) }
            }
            totalOn += ons; if (ons > 0) runsWithAny++
        }
        println("  SIM dağılım: $by"); println("  SIM sakin: günde ortalama önlem=${totalOn / 40.0}, en az bir önlem alan koşu=$runsWithAny/40")
        T.check("sakin ama gürültülü ağda günde ortalama 1'den az gereksiz önlem", totalOn / 40.0 < 1.0, "ortalama=${totalOn / 40.0}")
    }
    T.group("Otomatik koruma (Immune): benzetim — saldırıya tepki süresi ve ağ değişimi")
    run {
        // Gerçek saldırı: sürekli yüksek hızlı sahte cevaplar → birkaç dakika içinde ilk önlem
        val lat = ArrayList<Int>()
        for (seed in 1..30) {
            val r = java.util.Random(seed.toLong()); val im = Immune(java.util.Random(seed + 7L))
            var first = -1
            for (m in 1..60) {
                val t = m * MIN
                if (m >= 10) im.report(Threat.SPOOF, 2.0 + r.nextInt(3), t - 500)      // dakikada 2–4 sahte cevap
                if (im.tick(t).any { it.on } && first < 0) first = m - 10
            }
            lat.add(first)
        }
        println("  SIM tepki süresi (dk): $lat")
        T.check("orta şiddetli sürekli saldırıda her koşuda ≤4 dakikada önlem", lat.all { it in 0..4 }, lat.toString())

        // Kısa tek seferlik patlama (ör. bir dakikalık hata dalgası) önlem aldırmaz
        val sp = Immune(NoExplore())
        sp.report(Threat.BAD_SERVER, 5.0, MIN - 500)
        T.check("tek dakikalık orta patlama önlem almaz", (1..30).all { sp.tick(it * MIN).none { c -> c.on } })

        // Ağ değişimi: eski ağın kanıtları ve önlemleri bırakılır
        val ch = Immune(NoExplore())
        ch.setScope("wifi")
        ch.report(Threat.AD_LEAK, 9.0, 0)
        val on = ch.tick(MIN)
        T.check("Wi-Fi'da önlem açıldı", on.any { it.act == Act.DOH_BLOCK && it.on })
        ch.setScope("mobil")
        val off = ch.tick(2 * MIN)
        T.check("ağ değişince önlem geri alınır, kanıtlar silinir", off.any { it.act == Act.DOH_BLOCK && !it.on } && ch.active().isEmpty() && ch.score(Threat.AD_LEAK, 2 * MIN) == 0.0)
        val first = Immune(NoExplore()); first.setScope("wifi"); first.decodeAll("|A.AD_LEAK.DOH_BLOCK", MIN)
        first.setScope("wifi")
        T.check("aynı ağda yeniden atama bir şey bozmaz", first.active().contains(Act.DOH_BLOCK))
    }
    T.group("Otomatik koruma (Immune): zorlu benzetimler")
    run {
        fun poisson(r: java.util.Random, lambda: Double): Int { var k = 0; var p = 1.0; val l = Math.exp(-lambda); do { k++; p *= r.nextDouble() } while (p > l); return k - 1 }
        // A) kötü ağ: gürültü 8 kat
        var totA = 0
        for (seed in 1..30) {
            val r = java.util.Random(seed.toLong()); val im = Immune(java.util.Random(seed + 5L))
            for (m in 1..1440) {
                val t = m * MIN
                repeat(poisson(r, 0.64)) { im.report(Threat.SPOOF, 1.0, t - 500) }
                repeat(poisson(r, 0.32)) { im.report(Threat.BAD_SERVER, 1.0, t - 500) }
                if (r.nextInt(100) < 30) im.report(Threat.NET_BLOCK, 1.0, t - 500)
                if (r.nextInt(100) < 8) im.report(Threat.FLOOD, 1.2, t - 500)
                if (r.nextInt(100) < 30) im.harm(1.0, t - 500)
                totA += im.tick(t).count { it.on }
            }
        }
        println("  SIM A kötü ağ: günde ortalama önlem=${totA / 30.0}"); T.check("çok gürültülü (8 kat) ağda günde ortalama ≤1 gereksiz önlem", totA / 30.0 <= 1.0, "${totA / 30.0}")
        // B) kesintili saldırı: 5 dk saldırı, 10 dk sakin, tekrar; sürekli önlemlerin açılış-kapanış sayısı
        var flips = 0; var onsB = 0
        for (seed in 1..20) {
            val r = java.util.Random(seed.toLong()); val im = Immune(java.util.Random(seed + 9L))
            for (m in 1..720) {
                val t = m * MIN
                if (m % 15 < 5 && Act.DOH_BLOCK !in im.active()) im.report(Threat.AD_LEAK, 6.0, t - 500)       // önlem açıkken sızıntı olmaz
                for (c in im.tick(t)) { if (c.on) onsB++ else flips++ }
            }
        }
        println("  SIM B kesintili saldırı (12 saat): açma=${onsB / 20.0} kapama=${flips / 20.0}"); T.check("kesintili saldırıda önlem salınmaz (12 saatte ≤8 açılış)", onsB / 20.0 <= 8.0, "${onsB / 20.0}")
        // C) hiçbir önlemin çözmediği sürekli saldırı: 6 saat boyunca toplam değişiklik sayısı
        var totC = 0
        for (seed in 1..20) {
            val im = Immune(java.util.Random(seed.toLong()))
            for (m in 1..360) { val t = m * MIN; im.report(Threat.SPOOF, 9.0, t - 500); totC += im.tick(t).size }
        }
        println("  SIM C çözümsüz saldırı (6 saat): değişiklik=${totC / 20.0}"); T.check("çözümsüz saldırıda değişiklik sayısı sınırlı (6 saatte ≤8)", totC / 20.0 <= 8.0, "${totC / 20.0}")
        // D) yavaş artan saldırı: dakikada 0.3'ten 6'ya
        val lat = ArrayList<Int>()
        for (seed in 1..20) {
            val im = Immune(java.util.Random(seed.toLong())); var first = -1
            for (m in 1..120) { val t = m * MIN; im.report(Threat.SPOOF, 0.3 + m * 0.05, t - 500); if (im.tick(t).any { it.on } && first < 0) first = m }
            lat.add(first)
        }
        println("  SIM D yavaş artış: ilk önlem dk=$lat"); T.check("yavaş artan saldırı 45. dakikadan önce yakalanır", lat.all { it in 1..45 }, lat.toString())
    }
    T.group("Otomatik koruma (Immune): zarar verme emniyetleri (bekleme, kesinti bütçesi)")
    run {
        // açılış beklemesi: tünel yeni kuruldu → şiddetli olmayan saldırıda bile önlem alınmaz, bekleme bitince alınır
        val h = Immune(NoExplore())
        h.hold(0, 3 * MIN)
        h.report(Threat.AD_LEAK, 9.0, 0)
        T.check("açılış beklemesinde önlem alınmaz", h.tick(MIN).none { it.on } && h.tick(2 * MIN).none { it.on })
        h.report(Threat.AD_LEAK, 9.0, 3 * MIN)
        T.check("bekleme bitince önlem alınır", (3..6).any { m -> h.report(Threat.AD_LEAK, 9.0, m * MIN); h.tick(m * MIN).any { it.on } })

        // kesinti bütçesi: hiçbir şeyin çözmediği 4 saatlik saldırıda saatte ≤3 sunucu/bağlantı değişikliği
        var worst = 0
        for (seed in 1..20) {
            val im = Immune(java.util.Random(seed.toLong()))
            val times = ArrayList<Long>()
            for (m in 1..240) {
                val t = m * MIN
                im.report(Threat.SPOOF, 9.0, t - 500); im.report(Threat.BAD_SERVER, 9.0, t - 500); im.report(Threat.NET_BLOCK, 9.0, t - 500)
                for (c in im.tick(t)) if (c.on && !c.act.sticky) times.add(t)
            }
            for (t0 in times) worst = maxOf(worst, times.count { it >= t0 && it < t0 + 60 * MIN })
        }
        println("  SIM kesinti bütçesi: en kötü saatlik kesintili önlem sayısı=$worst")
        T.check("sürekli saldırıda saatte en çok 3 kesintili önlem (sunucu/yönlendirici değiştirme)", worst <= Immune.MAX_DISRUPTIVE_PER_HOUR, "en kötü=$worst")
    }
    T.group("Otomatik koruma ayarı: varsayılan açık, kayıtta ve dışa aktarmada korunur")
    run {
        // Uygulanabilirlik: uygulanamayan önlem (ör. zaten şifreli) seçilmez, sıradaki alınır
        val a = Immune(NoExplore())
        a.report(Threat.SPOOF, 9.0, 0)
        val c = a.tick(MIN) { it != Act.REFRESH && it != Act.ENCRYPT }
        T.check("uygulanamayan önlemler atlanır: BACKUP seçilir", c.size == 1 && c[0].act == Act.BACKUP, c.toString())
        val n = Immune(NoExplore())
        n.report(Threat.SPOOF, 9.0, 0)
        T.check("hiç uygulanabilir önlem yoksa değişiklik yok", n.tick(MIN) { false }.isEmpty() && n.applied(Threat.SPOOF).isEmpty())

        // Bağlam: Wi-Fi'da ENCRYPT işe yarar öğrenilir; mobilde bu bilgi yok ama genel değer ona yön verir
        val w = Immune(NoExplore())
        w.setScope("wifi")
        var attack = true
        for (m in 1..40) {
            val t = m * MIN
            if (attack) w.report(Threat.SPOOF, 9.0, t - 1000)
            for (ch in w.tick(t)) if (ch.on && ch.act == Act.ENCRYPT) attack = false
        }
        val mem = w.encode()
        T.check("bağlam öneki saklanır", mem.contains("wifi/SPOOF:ENCRYPT="), mem)
        val r = Immune(NoExplore()); r.decode(mem)
        r.setScope("wifi")
        val wifiV = r.efficacy(Threat.SPOOF, Act.ENCRYPT)
        r.setScope("mobil")
        T.check("bağlamda ölçüm yoksa genel değer kullanılır", r.efficacy(Threat.SPOOF, Act.ENCRYPT) == r.run { setScope(""); efficacy(Threat.SPOOF, Act.ENCRYPT) })
        T.check("wifi değeri yüksek", wifiV > Immune.PRIOR, wifiV.toString())
        val bad = Immune(); bad.decode("Wi Fi/SPOOF:ENCRYPT=0.9;/SPOOF:ENCRYPT=0.9;abcdefghijklmnop/SPOOF:ENCRYPT=0.9")
        T.check("geçersiz bağlam adı atlanır", bad.encode().isEmpty())
        bad.setScope("BÜYÜK"); bad.report(Threat.FLOOD, 9.0, 0)
        T.check("geçersiz bağlam ayarı bağlamsıza döner", bad.tick(MIN).size == 1)
    }

    run {
        T.check("varsayılan açık", AppSettings().autoShield)
        T.check("kapalı değer kayıtta korunur", !SettingsCodec.decode(SettingsCodec.encode(AppSettings(autoShield = false))).autoShield)
        T.check("açık değer kayıtta korunur", SettingsCodec.decode(SettingsCodec.encode(AppSettings(autoShield = true))).autoShield)
        T.check("dışa/içe aktarmada korunur", SettingsCodec.import(SettingsCodec.export(AppSettings(autoShield = false)), AppSettings())?.autoShield == false)
        T.check("metinler her dilde dolu", listOf<Tx>(TxTr, TxEn, TxDe, TxEs, TxFr, TxId, TxIt, TxPl, TxPt, TxRu, TxUk, TxVi).all { it.AUTO_SHIELD.isNotBlank() && it.AUTO_SHIELD_NOTE.length > 30 })
    }
}
