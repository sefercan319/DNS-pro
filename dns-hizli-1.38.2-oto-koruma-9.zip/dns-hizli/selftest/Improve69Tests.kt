package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

// 1.33.0: Kişiselleştirme ve diğer sekmelerdeki iyileştirmeler ile güvenlik temizliği.

private fun scrollTop(rig: Rig) {
    val page = rig.scene.currentPage as ScrollPage
    var last = -1f
    repeat(40) { if (page.scrollOffset <= 0f || page.scrollOffset == last) return@repeat; last = page.scrollOffset; rig.drag(180f, rig.h * 0.3f, rig.h * 0.3f + 260f, 8) }
}

/** Sayfayı baştan sona kaydırarak görünen tüm öğeleri toplar (okumak içindir: sonunda sayfa en alttadır). */
private fun pageItems(rig: Rig): List<A11yItem> {
    val page = rig.scene.currentPage as ScrollPage
    var last: Float
    scrollTop(rig)
    val seen = LinkedHashMap<String, A11yItem>()
    last = -1f
    repeat(40) {
        for (i in rig.items()) seen.putIfAbsent(i.info.label + "|" + i.info.role, i)
        if (page.scrollOffset == last) return seen.values.toList()
        last = page.scrollOffset
        rig.drag(180f, rig.h * 0.7f, rig.h * 0.7f - 220f, 8)
    }
    return seen.values.toList()
}
private fun hasRow(rig: Rig, label: String) = pageItems(rig).any { it.info.label.startsWith(label) }
private fun openSec(rig: Rig, sec: Section) { rig.scene.openSection(sec); rig.settle(900) }
private fun openPersonalize(rig: Rig) { rig.scene.openPersonalize(); rig.settle(900) }
private fun isFold(i: A11yItem, name: String) = i.info.label == name && i.info.role == Role.BUTTON && i.info.checked != null
/** Ekrandaki bölüm başlığı (dokunmak için); görünmüyorsa sayfa baştan sona taranır (yalnızca okumak için). */
private fun foldTitle(rig: Rig, name: String): A11yItem = rig.items().firstOrNull { isFold(it, name) } ?: pageItems(rig).first { isFold(it, name) }

fun runImprove69Tests() {
    T.group("1.33 çekirdek: hazır görünümler (Sade, Dengeli, Canlı, Pil dostu, Okunaklı)")
    run {
        val ps = LookPreset.values()
        T.check("beş hazır görünüm", ps.size == 5 && ps.map { it.name } == listOf("CALM", "BALANCED", "VIVID", "BATTERY", "READABLE"))
        T.check("hiçbir iki görünüm aynı cam/hareket/hız üçlüsünü taşımaz", ps.map { Triple(it.glass, it.motion, it.speed) }.toSet().size == ps.size)
        val base = AppSettings()
        for (p in ps) T.check("${p.name}: uygulanınca tanınır", Look.match(Look.apply(base, p)) == p)
        val b = Look.apply(base, LookPreset.BATTERY)
        T.check("Pil dostu: hareket kapalı, cam az, hız düşük", b.motion == Motion.OFF && b.glass == 0.20f && b.animSpeed == 0.8f && b.textScale == base.textScale)
        for ((from, want) in listOf(TextScale.SMALL to TextScale.LARGE, TextScale.NORMAL to TextScale.LARGE, TextScale.LARGE to TextScale.LARGE, TextScale.XLARGE to TextScale.XLARGE)) {
            val r = Look.apply(base.copy(textScale = from), LookPreset.READABLE)
            T.check("Okunaklı: yazı $from → $want (daha büyüğü küçültülmez)", r.textScale == want && r.glass == 0.90f && r.motion == Motion.REDUCED)
        }
        val s0 = base.copy(textScale = TextScale.SMALL, encryption = Encryption.DOH, filterLevel = FilterLevel.STRICT, autoConnect = true)
        val s1 = Look.apply(s0, LookPreset.READABLE)
        T.check("hazır görünüm DNS, filtre, bağlantı ayarlarına dokunmaz", s1.encryption == Encryption.DOH && s1.filterLevel == FilterLevel.STRICT && s1.autoConnect)
        T.check("geri al (copyLook) yazı boyutunu da geri getirir", Look.copyLook(s0, s1).textScale == TextScale.SMALL && Look.copyLook(s0, s1).glass == s0.glass)
        for (l in Lang.values()) {
            val tx = L.of(l)
            T.check("${l.code}: hazır görünüm adları ve notları beş tane, dolu, benzersiz", tx.OPT_PRESET.size == 5 && tx.PRESET_NOTES.size == 5 && tx.OPT_PRESET.toSet().size == 5 && (tx.OPT_PRESET + tx.PRESET_NOTES).all { it.isNotBlank() })
            T.check("${l.code}: yeni metinler dolu", listOf(tx.PZ_FOLDED, tx.PZ_UNFOLDED, tx.PZ_PRESET_CUSTOM, tx.FX_OFF_NOTE, tx.PRESET_FOOT).all { it.isNotBlank() } && tx.PZ_FOLDED != tx.PZ_UNFOLDED)
        }
    }

    T.group("1.33 çekirdek: katlanan bölümlerin kaydı (PzFolds)")
    run {
        T.check("boş ve null temiz", PzFolds.sanitize("") == "" && PzFolds.sanitize(null) == "")
        T.check("bilinmeyen anahtar atılır, sıra sabitlenir, tekrar silinir", PzFolds.sanitize("lang, evil ,theme,theme,<script>") == "theme,lang")
        T.check("aşırı uzun kayıt tamamen atılır", PzFolds.sanitize("theme,".repeat(100)) == "")
        T.check("büyük/küçük harf ayrımı: 'THEME' geçersiz", PzFolds.sanitize("THEME") == "")
        var raw = ""
        raw = PzFolds.toggle(raw, "feel"); T.check("kapat", raw == "feel" && PzFolds.isClosed(raw, "feel") && !PzFolds.isClosed(raw, "theme"))
        raw = PzFolds.toggle(raw, "theme"); T.check("ikinci bölüm kapanınca sıra sabit", raw == "theme,feel")
        raw = PzFolds.toggle(raw, "feel"); T.check("aç", raw == "theme")
        T.check("toggle iki kez özdeş", PzFolds.toggle(PzFolds.toggle("access", "bg"), "bg") == "bg,access".let { "access" }.let { PzFolds.sanitize("access") })
        T.check("bilinmeyen anahtar toggle ile eklenmez", PzFolds.toggle("", "xyz") == "")
        T.check("toggleAll: hepsi açıkken hepsini kapatır", PzFolds.toggleAll("").split(',').toSet() == PzFolds.KEYS.toSet())
        T.check("toggleAll: biri kapalıyken hepsini açar", PzFolds.toggleAll("bg") == "")
        T.check("toggleAll: hepsi kapalıyken hepsini açar", PzFolds.toggleAll(PzFolds.KEYS.joinToString(",")) == "")
        T.check("closedCount", PzFolds.closedCount("theme,lang") == 2 && PzFolds.closedCount("") == 0)
        // Kayıt: ayar olarak saklanır ama dışa aktarılmaz ve içe aktarmayla gelmez
        val st = AppSettings(pzClosed = "bg,feel")
        val enc = SettingsCodec.encode(st)
        T.check("kodlanır ve geri okunur", SettingsCodec.decode(enc).pzClosed == "bg,feel")
        T.check("bozuk kayıt varsayılana (hepsi açık) düşer", SettingsCodec.decode(mapOf("pzClosed" to "zzz\u0000,them\ne")).pzClosed == "")
        val exported = SettingsCodec.export(st)
        T.check("dışa aktarma dosyasında yok", !exported.contains("pzClosed"))
        val imp = SettingsCodec.import("pzClosed=theme\ntheme=aqua\n", AppSettings(pzClosed = "bg"))
        T.check("içe aktarma yerel katlama durumunu ezmez", imp == null || imp.pzClosed == "bg")
    }

    T.group("1.33 çekirdek: PzFolds rastgele girdi")
    run {
        val rnd = java.util.Random(7)
        val atoms = listOf("theme", "shape", "bg", "feel", "access", "device", "lang", ",", ",", " ", "x", "\n", "THEME", "\u0000", "a,b")
        var bad = 0
        repeat(3000) {
            val raw = (0 until rnd.nextInt(14)).joinToString("") { atoms[rnd.nextInt(atoms.size)] }
            val a1 = PzFolds.sanitize(raw)
            val ok = PzFolds.sanitize(a1) == a1 && a1.split(',').filter { it.isNotEmpty() }.all { it in PzFolds.KEYS } && PzFolds.sanitize(PzFolds.toggle(PzFolds.toggle(a1, "feel"), "feel")) == a1 &&
                SettingsCodec.decode(SettingsCodec.encode(AppSettings(pzClosed = a1))).pzClosed == a1
            if (!ok) bad++
        }
        T.check("3000 rastgele kayıt: temizleme kararlı, yalnızca bilinen anahtarlar, kodlama gidiş-dönüş", bad == 0, "bozuk=$bad")
    }

    T.group("1.33 güvenlik: dış metinlerin temizliği (TextSafe)")
    run {
        T.check("satır sonu ve sekme boşluğa döner, ardışık boşluk teke iner", TextSafe.line("a\nb\t\tc   d", 50) == "a b c d")
        T.check("sağdan sola geçiş (U+202E) ve sıfır genişlikli karakterler silinir", TextSafe.line("Pix‮el​ 9﻿", 50) == "Pixel 9")
        T.check("kontrol karakterleri silinir", TextSafe.line("x\u0000y\u0007z\u007F\u0085", 50) == "xyz")
        T.check("uzunluk sınırlanır", TextSafe.line("a".repeat(500), 40).length == 40)
        T.check("ikili karakter ortasından kesilmez", TextSafe.line("ab😀", 3).none { Character.isHighSurrogate(it) })
        T.check("null ve boş güvenli", TextSafe.line(null, 10) == "" && TextSafe.line("", 10) == "" && TextSafe.line("abc", 0) == "")
        T.check("uçlardaki boşluklar kırpılır", TextSafe.line("   x  ", 10) == "x")
        T.check("DiagReport.clean da gizli karakterleri siler", DiagReport.clean("a‮b​c\nd") == "abcd")

        val evil = DeviceInfo(manufacturer = "sam\nsung", brand = "Evil‮", model = "SM-X\r\nSistem: sahte", display = "d".repeat(1000), fingerprint = "f".repeat(5000), tags = "t\u0000",
            sdk = 99999, ramMb = Int.MAX_VALUE, heapMb = -5, refreshHz = 0,
            props = (0 until 500).associate { "ro.k$it" to "v\n".repeat(100) } + ("ro.product.marketname" to "Galaxy\n[Fake]‮ 9"))
        val s = DeviceProfiler.sanitize(evil)
        T.check("temizlenmiş bilgide satır sonu ve gizli karakter yok", listOf(s.manufacturer, s.brand, s.model, s.display, s.fingerprint, s.tags).all { v -> v.none { TextSafe.isHidden(it) } })
        T.check("uzunluklar ve sayılar sınırlı", s.display.length <= 160 && s.fingerprint.length <= 300 && s.sdk <= 200 && s.ramMb <= 1_000_000 && s.heapMb == 0 && s.refreshHz >= 1 && s.props.size <= 64)
        val prof = DeviceProfiler.detect(evil)
        T.check("tanınan cihaz adı tek satır ve temiz", prof.name.none { TextSafe.isHidden(it) || it == '\n' } && prof.name.length <= 100, prof.name)
        T.check("tanılama satırı tek satır", !prof.diagLine.contains('\n') && !prof.systemLabel.contains('\n'))
        val pp = DeviceProfiler.parseProp("[ro.test]: [a\nb‮c]")
        T.check("parseProp değeri temizler", pp != null && pp.second == "abc".let { "a bc" }.let { pp.second } && pp.second.none { TextSafe.isHidden(it) }, pp?.second ?: "null")
        T.check("parseProp aşırı uzun satırı reddeder", DeviceProfiler.parseProp("[a.b]: [" + "x".repeat(500) + "]") == null)
        T.check("parseProp bozuk satırlar null", DeviceProfiler.parseProp("") == null && DeviceProfiler.parseProp("[]: [x]") == null && DeviceProfiler.parseProp("[ab]: [x") == null)
        // Rastgele bayt dizileri hiçbir zaman çökertmez ve gizli karakter üretmez
        val rnd = java.util.Random(42)
        var bad = 0
        repeat(2000) {
            val n = rnd.nextInt(60)
            val sb = StringBuilder()
            repeat(n) { sb.append(rnd.nextInt(0x3000).toChar()) }
            val out = TextSafe.line(sb.toString(), 30)
            if (out.length > 30 || out.any { TextSafe.isHidden(it) } || out.startsWith(" ") || out.endsWith(" ") || out.contains("  ")) bad++
        }
        T.check("2000 rastgele metin: sınır, gizli karakter, boşluk kuralları tutar", bad == 0, "bozuk=$bad")
    }

    T.group("1.33 Kişiselleştirme: önizleme, katlama, hazır görünüm")
    run {
        val rig = Rig(Rig.base())
        openPersonalize(rig)
        val prev = rig.items().first { it.info.role == Role.BUTTON && it.info.label.startsWith(Strings.PRESET + ": ") }
        T.check("önizleme düğme olarak okunur", prev.info.label.length > Strings.PRESET.length + 2)
        rig.tapItem(prev, 700)
        T.check("önizlemeye dokununca hazır görünümler açılır (5 seçenek)", Strings.OPT_PRESET.all { o -> rig.items().any { it.info.label.startsWith(o) } })
        T.check("hazır görünüm penceresi açıklama altbilgisi taşır", rig.find(Strings.PRESET_FOOT.take(30)) != null)
        rig.tapText(Strings.OPT_PRESET[LookPreset.BATTERY.ordinal], settleMs = 900)
        T.check("uygulanan hazır görünümün adı mesajda yazar", rig.model.toast?.text == Strings.PRESET_DONE + ": " + Strings.OPT_PRESET[LookPreset.BATTERY.ordinal], rig.model.toast?.text ?: "null")
        T.check("Pil dostu uygulanır", Look.match(rig.model.settings) == LookPreset.BATTERY && rig.model.settings.motion == Motion.OFF)
        T.check("geri al önerilir", rig.model.toast?.action == Strings.UNDO)
        rig.model.toast?.onAction?.invoke(); rig.settle(300)
        T.check("geri al hazır görünümü kaldırır", Look.match(rig.model.settings) != LookPreset.BATTERY)

        // Özel değer: hiçbir hazır görünüme uymayınca "Özel ayar" yazılır
        rig.model.update { it.copy(glass = 0.47f) }; rig.settle(300)
        val row = pageItems(rig).first { it.info.label == Strings.PRESET && it.info.role == Role.BUTTON }
        T.check("hazır görünüme uymayınca satırın değeri 'Özel ayar'", row.info.value == Strings.PZ_PRESET_CUSTOM, row.info.value ?: "null")
        rig.model.update { Look.apply(it, LookPreset.VIVID) }; rig.settle(300)
        T.check("uyunca hazır görünümün adı yazılır", pageItems(rig).first { it.info.label == Strings.PRESET }.info.value == Strings.OPT_PRESET[LookPreset.VIVID.ordinal])
    }
    run {
        val rig = Rig(Rig.base())
        openPersonalize(rig)
        val t = foldTitle(rig, Strings.SEC_THEME_COLOR)
        T.check("tema bölümü açık; açıkken özet okunmaz", t.info.checked == true && t.info.value == null)
        rig.tapItem(t, 700)
        T.check("kapatınca ayar kaydedilir", rig.model.settings.pzClosed == "theme" && rig.host.saved?.pzClosed == "theme")
        val t2 = foldTitle(rig, Strings.SEC_THEME_COLOR)
        T.check("kapalı bölümün özeti (seçili tema) okunur", t2.info.checked == false && t2.info.value == (Themes.byId("aqua")?.name ?: ""), t2.info.value ?: "null")
        T.check("kapalı bölümün satırları görünmez", rig.items().none { it.info.label.startsWith(Strings.AUTO_LIGHT) })
        // Sayfayı kapatıp yeniden aç: durum hatırlanır
        rig.scene.goBack(); rig.settle(900)
        openPersonalize(rig)
        T.check("sayfa yeniden açılınca bölüm hâlâ kapalı", foldTitle(rig, Strings.SEC_THEME_COLOR).info.checked == false)
        // Yeni model (uygulama yeniden açıldı): kayıttan gelir
        val rig2 = Rig(Rig.base().copy(pzClosed = "feel,access"))
        openPersonalize(rig2)
        T.check("kayıtlı kapalı bölümler yeni oturumda da kapalı", foldTitle(rig2, Strings.PZ_FEEL).info.checked == false && foldTitle(rig2, Strings.PZ_ACCESS).info.checked == false && foldTitle(rig2, Strings.SEC_SHAPE).info.checked == true)
        T.check("Hissediş bölümünün özeti: hazır görünüm değilse 'Özel ayar'", foldTitle(rig2, Strings.PZ_FEEL).info.value in listOf(Strings.PZ_PRESET_CUSTOM) + Strings.OPT_PRESET, foldTitle(rig2, Strings.PZ_FEEL).info.value ?: "null")
        // Erişilebilirlik özeti: açık seçenek sayısı
        rig2.model.update { it.copy(highContrast = true, minimal = true) }; rig2.settle(300)
        T.check("Erişilebilirlik özeti '3/4' ya da '2/3'", foldTitle(rig2, Strings.PZ_ACCESS).info.value in listOf("3/4", "2/3") && foldTitle(rig2, Strings.PZ_ACCESS).info.value != null)
        rig2.host.vibrator = false
    }
    run {
        // Uzun basış: hepsini kapat / aç
        val rig = Rig(Rig.base())
        openPersonalize(rig)
        val t = foldTitle(rig, Strings.SEC_THEME_COLOR)
        T.check("başlık uzun basışı destekler (erişilebilirlik)", t.info.longClick)
        rig.longPress((t.l + t.r) / 2f, (t.t + t.b) / 2f)
        T.check("uzun basış hepsini kapatır ve haber verir", PzFolds.closedCount(rig.model.settings.pzClosed) == PzFolds.KEYS.size && rig.model.toast?.text == Strings.PZ_FOLDED, "kapalı=${rig.model.settings.pzClosed} toast=${rig.model.toast?.text} t=${t.t}..${t.b}")
        val t2 = foldTitle(rig, Strings.SEC_THEME_COLOR)
        rig.longPress((t2.l + t2.r) / 2f, (t2.t + t2.b) / 2f)
        T.check("tekrar uzun basış hepsini açar", rig.model.settings.pzClosed == "" && rig.model.toast?.text == Strings.PZ_UNFOLDED)
    }
    run {
        // Altta kalan bölüm açılınca ekrana kaydırılır
        val rig = Rig(Rig.base().copy(pzClosed = PzFolds.KEYS.joinToString(",")), w = 360, h = 480)
        openPersonalize(rig)
        val page = rig.scene.currentPage as ScrollPage
        val before = page.scrollOffset
        rig.tapItem(foldTitle(rig, Strings.PZ_FEEL), 800)
        T.check("açılan bölümün ilk satırı görünür kalır", rig.items().any { it.info.label == Strings.PRESET && it.info.role == Role.BUTTON })
        T.check("gerekirse sayfa kaydı (offset ≥ önceki)", page.scrollOffset >= before)
        T.check("bölüm başlığı hâlâ ekranda", rig.items().any { it.info.label == Strings.PZ_FEEL })
    }
    run {
        // Önizleme: hareket kapalıyken kare istemez
        val rig = Rig(Rig.base().copy(motion = Motion.OFF))
        openPersonalize(rig)
        rig.settle(600)
        T.check("hareket kapalıyken sayfa dinlenir (süs animasyonu kare istemez)", rig.tick1() == -1L, "${rig.lastDelay}")
        rig.model.update { it.copy(motion = Motion.FULL, lowPower = true) }; rig.settle(600)
        T.check("düşük güçte de önizleme kare istemez", rig.tick1() == -1L, "${rig.lastDelay}")
    }

    T.group("1.33 sekmeler: yalnızca ilgili olunca görünen satırlar")
    run {
        // DNS
        val rig = Rig(Rig.base().copy(encryption = Encryption.AUTO, cache = CacheLevel.NORMAL))
        openSec(rig, Section.DNS)
        T.check("Otomatik şifrelemede Katı şifreleme görünür", hasRow(rig, Strings.STRICT_ENC))
        for (e in listOf(Encryption.DOT, Encryption.DOH, Encryption.OFF)) {
            rig.model.update { it.copy(encryption = e) }; rig.settle(300)
            T.check("$e: Katı şifreleme gizli", !hasRow(rig, Strings.STRICT_ENC))
        }
        T.check("Önbellek açıkken Önbelleği temizle görünür", hasRow(rig, Strings.CLEAR_CACHE))
        rig.model.update { it.copy(cache = CacheLevel.OFF) }; rig.settle(300)
        T.check("Önbellek kapalıyken Önbelleği temizle gizli", !hasRow(rig, Strings.CLEAR_CACHE))
    }
    run {
        // Filtre
        val rig = Rig(Rig.base().copy(filterLevel = FilterLevel.OFF))
        openSec(rig, Section.FILTER)
        T.check("Süzgeç kapalı: bellek, son engellenenler, geçenler gizli", !hasRow(rig, Strings.FILTER_MEM) && !hasRow(rig, Strings.FILTER_LAST) && !hasRow(rig, Strings.FILTER_PASSED))
        T.check("Süzgeç kapalı: izin/engel listeleri ve site tanısı kalır", hasRow(rig, Strings.FILTER_ALLOW) && hasRow(rig, Strings.FILTER_BLOCK) && hasRow(rig, Strings.SITE_DIAG))
        rig.model.update { it.copy(filterLevel = FilterLevel.MEDIUM) }; rig.settle(300)
        T.check("Süzgeç açık: hepsi görünür", hasRow(rig, Strings.FILTER_MEM) && hasRow(rig, Strings.FILTER_LAST) && hasRow(rig, Strings.FILTER_PASSED))
    }
    run {
        // Bildirimler: izin
        val rig = Rig(Rig.base())
        rig.host.notifAllowed = false
        openSec(rig, Section.NOTIFICATIONS)
        var its = pageItems(rig)
        T.check("izin kapalı: izin satırı tek, değeri 'kapalı'", its.count { it.info.label == Strings.NOTIF_PERM } == 1 && its.first { it.info.label == Strings.NOTIF_PERM }.info.value == Strings.PERM_BLOCKED)
        T.check("izin kapalı: izin satırı en üstte (anahtarlardan önce)", its.indexOfFirst { it.info.label == Strings.NOTIF_PERM } < its.indexOfFirst { it.info.role == Role.SWITCH })
        rig.host.notifAllowed = true
        rig.scene.goBack(); rig.settle(900); openSec(rig, Section.NOTIFICATIONS)
        its = pageItems(rig)
        T.check("izin açık: izin satırı tek, en altta, değeri 'açık'", its.count { it.info.label == Strings.NOTIF_PERM } == 1 && its.first { it.info.label == Strings.NOTIF_PERM }.info.value == Strings.PERM_ALLOWED &&
            its.indexOfFirst { it.info.label == Strings.NOTIF_PERM } > its.indexOfLast { it.info.role == Role.SWITCH })
        rig.tapText(Strings.NOTIF_PERM, exact = true, settleMs = 300)
        T.check("izin satırı sistem ayarını açar", rig.host.calls.any { it.contains("notif") })
    }
    run {
        // Liste, İstatistik
        val rig = Rig(Rig.base())
        openSec(rig, Section.LIST)
        T.check("otomatik ölçüm kapalı: Şifreli ölçüm gizli", !hasRow(rig, Strings.MEASURE_ENC))
        rig.model.update { it.copy(autoMeasure = true) }; rig.settle(300)
        T.check("otomatik ölçüm açık: Şifreli ölçüm görünür", hasRow(rig, Strings.MEASURE_ENC))
        rig.scene.goBack(); rig.settle(900)

        val st = Rig(Rig.base().copy(totals = UsageTotals()), latencies = emptyMap())
        openSec(st, Section.STATS)
        T.check("veri yokken: Sıfırla, Paylaş, Geçmiş, Tasarruf gizli", listOf(Strings.RESET_STATS, Strings.SHARE_RESULTS, Strings.SESSIONS, Strings.STAT_SAVED).none { hasRow(st, it) })
        T.check("veri yokken: Geçmişi temizle gizli, Geçmişi tut kalır", !hasRow(st, Strings.CLEAR_HISTORY) && hasRow(st, Strings.KEEP_HISTORY))
        st.model.latencies["cloudflare"] = Latency(20, st.host.now); st.settle(300)
        T.check("ölçüm varken Geçmişi temizle görünür", hasRow(st, Strings.CLEAR_HISTORY))
        // Geçmişi temizle onay ister
        st.model.latencies["cloudflare"] = Latency(20, st.host.now)
        scrollTop(st)
        st.tapText(Strings.CLEAR_HISTORY, settleMs = 400)
        T.check("Geçmişi temizle hemen silmez, onay ister", st.model.latencies.isNotEmpty() && st.model.toast?.text == Strings.CONFIRM && st.model.toast?.action == Strings.RESET, "toast=${st.model.toast?.text}/${st.model.toast?.action} n=${st.model.latencies.size}")
        st.model.toast?.onAction?.invoke()
        T.check("onaylanınca temizler", st.model.latencies.isEmpty() && st.model.toast?.text == Strings.HISTORY_CLEARED)

        T.check("veri yokken boş haftalık grafik gizli", pageItems(st).none { it.info.label.contains(Strings.WEEK) && it.info.role == Role.TEXT })
        val full = Rig(Rig.base().copy(sessions = "x", daily = "20260101=5"))
        openSec(full, Section.STATS)
        T.check("veri varken: Sıfırla, Paylaş, Geçmiş görünür", hasRow(full, Strings.RESET_STATS) && hasRow(full, Strings.SHARE_RESULTS) && hasRow(full, Strings.SESSIONS))
        // Bilgi satırı uzun basışı panoya kopyalar
        scrollTop(full)
        val q = full.items().first { it.info.label.startsWith(Strings.STAT_QUERIES) }
        T.check("bilgi satırı uzun basış destekler", q.info.longClick)
        full.longPress((q.l + q.r) / 2f, (q.t + q.b) / 2f)
        T.check("uzun basış 'başlık: değer' kopyalar", full.host.clipboard?.startsWith(Strings.STAT_QUERIES + ": ") == true, full.host.clipboard ?: "null")
    }
    run {
        // Ses ve hareket
        val rig = Rig(Rig.base().copy(soundOn = true))
        openSec(rig, Section.SOUND)
        var its = pageItems(rig)
        T.check("ses açık: tüm ses satırları görünür", listOf(Strings.SOUND_PART, Strings.SOUND_UI, Strings.SOUND_CONN, Strings.SOUND_VOL, Strings.SOUND_PACK, Strings.SOUND_TEST).all { l -> its.any { it.info.label.startsWith(l) } } &&
            its.any { it.info.label == "${Strings.SOUND_OUT}: ${Strings.OPT_SOUND_OUT[0]}" })
        rig.model.update { it.copy(soundOn = false) }; rig.settle(300)
        its = pageItems(rig)
        T.check("ses kapalı: düzey, çıkış, olay anahtarları ve ses seçimi gizli", listOf(Strings.SOUND_PART, Strings.SOUND_UI, Strings.SOUND_CONN, Strings.SOUND_VOL).none { l -> its.any { it.info.label.startsWith(l) } } &&
            its.none { it.info.label.startsWith(Strings.SOUND_OUT) })
        T.check("ses kapalı: ana anahtar, paket seçimi ve Dene kalır (paket animasyonu sesten bağımsız)", listOf(Strings.SOUND_ON, Strings.SOUND_PACK, Strings.SOUND_TEST).all { l -> its.any { it.info.label.startsWith(l) } })
        // Sessiz saatler aralığı
        T.check("sessiz saatler kapalı: aralık gizli", its.none { it.info.label.startsWith(Strings.QUIET_RANGE) })
        rig.model.update { it.copy(quietHours = true) }; rig.settle(300)
        T.check("sessiz saatler açık: aralık görünür", pageItems(rig).any { it.info.label.startsWith(Strings.QUIET_RANGE) })
    }
    run {
        val rig = Rig(Rig.base().copy(motion = Motion.OFF, haptics = true))
        openSec(rig, Section.SOUND)
        var its = pageItems(rig)
        T.check("hareket kapalı: animasyon ayarları gizli, açıklama görünür", listOf(Strings.ANIM_SPEED, Strings.TAP_FX, Strings.FX_VARIANT, Strings.CELEBRATE).none { l -> its.any { it.info.label.startsWith(l) } } && its.any { it.info.label == Strings.FX_OFF_NOTE })
        T.check("hareket kapalı: titreşim şiddeti kalır (titreşim açık)", its.any { it.info.label.startsWith(Strings.HAPTIC_LEVEL) })
        rig.model.update { it.copy(motion = Motion.FULL) }; rig.settle(300)
        its = pageItems(rig)
        T.check("hareket açık: animasyon ayarları görünür, açıklama yok", listOf(Strings.ANIM_SPEED, Strings.TAP_FX, Strings.FX_VARIANT, Strings.CELEBRATE).all { l -> its.any { it.info.label.startsWith(l) } } && its.none { it.info.label == Strings.FX_OFF_NOTE })
        rig.model.update { it.copy(haptics = false) }; rig.settle(300)
        T.check("titreşim kapalı: titreşim şiddeti gizli", pageItems(rig).none { it.info.label.startsWith(Strings.HAPTIC_LEVEL) })
        rig.model.update { it.copy(haptics = true) }; rig.settle(300)
        // Titreşim yok: şiddet satırı hiç görünmez (eskiden yalnızca Kişiselleştirme gizliyordu)
        val nv = Rig(Rig.base().copy(haptics = true)); nv.host.vibrator = false
        openSec(nv, Section.SOUND)
        T.check("titreşimsiz cihazda titreşim şiddeti satırı yok", pageItems(nv).none { it.info.label.startsWith(Strings.HAPTIC_LEVEL) })
        // Hareket kapalı + titreşimsiz: animasyon kartı da yok (boş kart boşluk bırakmaz)
        val none = Rig(Rig.base().copy(motion = Motion.OFF)); none.host.vibrator = false
        openSec(none, Section.SOUND)
        T.check("boş kart çizilmez", pageItems(none).none { it.info.label.startsWith(Strings.HAPTIC_LEVEL) || it.info.label.startsWith(Strings.TAP_FX) })
    }
    run {
        // Seçimde örnek: ses çıkışı değişince Dene çalışır; titreşim şiddeti seçilince örnek titreşim verir
        val rig = Rig(Rig.base().copy(soundOn = true, haptics = true, hapticLevel = HapticLevel.LIGHT))
        openSec(rig, Section.SOUND)
        fun previews() = rig.host.sounds.count { it.first == Sfx.CONNECT }
        val s0 = previews()
        rig.tapText("${Strings.SOUND_OUT}: ${Strings.OPT_SOUND_OUT[1]}", exact = true, settleMs = 400)
        T.check("ses çıkışı değişince örnek (bağlanma sesi) çalar", previews() == s0 + 1, "${previews() - s0}")
        val s1 = previews()
        rig.tapText("${Strings.SOUND_OUT}: ${Strings.OPT_SOUND_OUT[1]}", exact = true, settleMs = 400)
        T.check("aynı seçeneğe tekrar dokununca örnek çalmaz", previews() == s1)
        val p0 = rig.host.patterns.size
        rig.tapText("${Strings.HAPTIC_LEVEL}: ${Strings.OPT_HAPTIC[2]}", exact = true, settleMs = 400)
        T.check("titreşim şiddeti seçilince örnek titreşim verir", rig.host.patterns.size > p0 && rig.model.settings.hapticLevel == HapticLevel.values()[2])
    }
    run {
        // Ses düzeyi kaydırıcısı: parmak kalkınca örnek ses; erişilebilirlik ayarı da çalar
        val rig = Rig(Rig.base().copy(soundOn = true, soundVolume = 0.5f))
        openSec(rig, Section.SOUND)
        val s0 = rig.host.sounds.count { it.first == Sfx.CONNECT }
        rig.scene.a11yAdjust(rig.need(Strings.SOUND_VOL), +1)
        rig.settle(300)
        T.check("ses düzeyi erişilebilirlikle ayarlanınca örnek çalar", rig.host.sounds.count { it.first == Sfx.CONNECT } == s0 + 1 && rig.model.settings.soundVolume == 0.55f, "${rig.model.settings.soundVolume}")
    }
    run {
        // Menü değerleri
        val rig = Rig(Rig.base().copy(theme = "aqua"))
        rig.scene.openMenu(); rig.settle(900)
        val its = rig.items()
        val pz = its.first { it.info.label == Strings.PERSONALIZE }
        T.check("menü: Kişiselleştirme satırının değeri seçili tema", pz.info.value == (Themes.byId("aqua")?.name ?: ""), pz.info.value ?: "null")
        T.check("menü: İstatistikler satırında sorgu sayısı", its.first { it.info.label == Strings.STATS_HISTORY }.info.value == Format.count(48_210))
        T.check("menü: Hakkında satırında sürüm", its.first { it.info.label == Strings.ABOUT }.info.value == rig.host.versionName())
        T.check("menü: Ses ve hareket satırı varsayılan pakette boş", its.first { it.info.label == Strings.SOUND_MOTION }.info.value == null)
        rig.model.update { it.copy(soundPack = SoundPack.values().first { p -> p != SoundPack.AUTO }) }; rig.settle(300)
        T.check("menü: Ses ve hareket satırında seçili paketin adı", rig.items().first { it.info.label == Strings.SOUND_MOTION }.info.value == Strings.packName(rig.model.settings.soundPack))
        rig.model.update { it.copy(soundOn = false) }; rig.settle(300)
        T.check("menü: ses kapalıyken değer boş", rig.items().first { it.info.label == Strings.SOUND_MOTION }.info.value == null)
        val empty = Rig(Rig.base().copy(totals = UsageTotals()))
        empty.scene.openMenu(); empty.settle(900)
        T.check("menü: sorgu yokken İstatistikler değeri boş", empty.items().first { it.info.label == Strings.STATS_HISTORY }.info.value == null)
        T.check("menü: bildirim izni açıkken değer boş", rig.items().first { it.info.label == Strings.SEC_NOTIF }.info.value == null)
        rig.host.notifAllowed = false
        rig.scene.back(); rig.settle(900); rig.scene.openMenu(); rig.settle(900)
        T.check("menü: bildirim izni kapalıysa değer 'kapalı'", rig.items().first { it.info.label == Strings.SEC_NOTIF }.info.value == Strings.PERM_BLOCKED)
        T.check("menü: Bağlantı ve uygulamalar varsayılan kapsamda boş", rig.items().first { it.info.label == Strings.CONN_APPS }.info.value == null)
        rig.model.update { it.copy(appScope = AppScope.ONLY, apps = setOf("a.b", "c.d")) }; rig.settle(300)
        T.check("menü: seçili uygulamalar yazılır", rig.items().first { it.info.label == Strings.CONN_APPS }.info.value == Strings.appsOnly(2))
    }

    T.group("1.33 bileşenler: not satırları, başlıklar, kaydırıcı adımı")
    run {
        // Büyük yazıda Kişiselleştirme/Bağlantı notları kesilmez ("…" ile biten not yok)
        for (fs in floatArrayOf(1f, 1.3f)) {
            val rig = Rig(Rig.base(), 320, 700, fontScale = fs)
            for (sec in listOf(Section.CONNECTION, Section.NOTIFICATIONS, Section.SOUND)) {
                rig.scene.openSection(sec); rig.settle(900)
                val page = rig.scene.currentPage as ScrollPage
                val cut = ArrayList<String>()
                repeat(30) {
                    val rec = TextRecorder().also { rig.scene.draw(it) }
                    for (r in rec.runs) if (r.s.endsWith("…") && r.s.length > 24 && r.b > 60f) cut.add(r.s.take(30))
                    val before = page.scrollOffset
                    rig.drag(160f, 600f, 300f, 8)
                    if (page.scrollOffset == before) return@repeat
                }
                T.check("${sec.name} x$fs: uzun notlarda kesik satır yok", cut.isEmpty(), cut.distinct().take(3).joinToString(" | "))
                rig.scene.goBack(); rig.settle(900)
            }
        }
        // Kaydırıcı adımı: %5 ızgara
        val rig = Rig(Rig.base().copy(glass = 0.30f))
        openPersonalize(rig)
        repeat(3) { rig.scene.a11yAdjust(rig.need(Strings.GLASS), +1) }
        T.check("kaydırıcı 3 adımda tam %45", rig.model.settings.glass == 0.45f, "${rig.model.settings.glass}")
        repeat(30) { rig.scene.a11yAdjust(rig.need(Strings.GLASS), -1) }
        T.check("alt sınır 0 (negatif ya da kayan sayı yok)", rig.model.settings.glass == 0f)
    }
}
