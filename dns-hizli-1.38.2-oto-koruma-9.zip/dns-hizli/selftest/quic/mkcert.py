import datetime,sys
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import ec,rsa
kind=sys.argv[1]
key=ec.generate_private_key(ec.SECP256R1()) if kind=="ec" else rsa.generate_private_key(65537,2048)
name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,"localhost")])
now=datetime.datetime.now(datetime.timezone.utc)
cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number())
 .not_valid_before(now-datetime.timedelta(days=1)).not_valid_after(now+datetime.timedelta(days=30))
 .add_extension(x509.SubjectAlternativeName([x509.DNSName("localhost"),x509.DNSName("*.wild.test")]),critical=False)
 .sign(key,hashes.SHA256()))
open(f"{kind}.crt","wb").write(cert.public_bytes(serialization.Encoding.PEM))
open(f"{kind}.key","wb").write(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
