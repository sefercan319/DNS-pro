import asyncio,random,sys
listen,target,loss,seed=int(sys.argv[1]),int(sys.argv[2]),float(sys.argv[3]),int(sys.argv[4])
random.seed(seed)
class R(asyncio.DatagramProtocol):
    def connection_made(s,t): s.t=t; s.client=None; s.up=None
    def datagram_received(s,d,a):
        if random.random()<loss: return
        if a[1]!=target:
            s.client=a
            async def fwd():
                if s.up is None:
                    loop=asyncio.get_running_loop()
                    s.up,_=await loop.create_datagram_endpoint(lambda: U(s),remote_addr=("127.0.0.1",target))
                s.up.sendto(d)
            asyncio.ensure_future(fwd())
class U(asyncio.DatagramProtocol):
    def __init__(s,r): s.r=r
    def datagram_received(s,d,a):
        if random.random()<loss: return
        if s.r.client: s.r.t.sendto(d,s.r.client)
async def main():
    loop=asyncio.get_running_loop()
    await loop.create_datagram_endpoint(R,local_addr=("127.0.0.1",listen))
    await asyncio.sleep(3600)
asyncio.run(main())
