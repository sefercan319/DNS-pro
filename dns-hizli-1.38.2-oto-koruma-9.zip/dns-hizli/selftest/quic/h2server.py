#!/usr/bin/env python3
"""DNS Hızlı DoH testleri için gerçek bir HTTP/2 (h2 kütüphanesi) sunucusu.
Kullanım: h2server.py SERTİFİKA_ÖNEKİ PORT both|h1
  both: ALPN "h2" ve "http/1.1" (istemci h2 seçer). h1: yalnızca "http/1.1" (istemci HTTP/1.1'e döner).
Her POST gövdesine A kaydı (1.2.3.4) ile cevap verir. Hazır olunca READY yazar. Yalnızca testler için."""
import socket, ssl, sys, threading
import h2.config, h2.connection, h2.events

cert, port, mode = sys.argv[1], int(sys.argv[2]), sys.argv[3]
ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ctx.load_cert_chain(cert + ".crt", cert + ".key")
ctx.set_alpn_protocols(["h2", "http/1.1"] if mode == "both" else ["http/1.1"])

def answer(q):
    i = 12
    while q[i] != 0:
        i += 1 + q[i]
    end = i + 5
    return b"\x00\x00\x81\x80" + q[4:6] + b"\x00\x01\x00\x00\x00\x00" + q[12:end] + b"\xc0\x0c\x00\x01\x00\x01\x00\x00\x00\x3c\x00\x04\x01\x02\x03\x04"

def serve_h2(s):
    c = h2.connection.H2Connection(config=h2.config.H2Configuration(client_side=False))
    c.initiate_connection()
    s.sendall(c.data_to_send())
    bodies = {}
    while True:
        data = s.recv(65535)
        if not data:
            return
        for ev in c.receive_data(data):
            if isinstance(ev, h2.events.RequestReceived):
                bodies[ev.stream_id] = b""
            elif isinstance(ev, h2.events.DataReceived):
                bodies[ev.stream_id] = bodies.get(ev.stream_id, b"") + ev.data
                c.acknowledge_received_data(ev.flow_controlled_length, ev.stream_id)
            elif isinstance(ev, h2.events.StreamEnded):
                q = bodies.pop(ev.stream_id, b"")
                r = answer(q)
                c.send_headers(ev.stream_id, [(b":status", b"200"), (b"content-type", b"application/dns-message"),
                                              (b"content-length", str(len(r)).encode())])
                c.send_data(ev.stream_id, r, end_stream=True)
        out = c.data_to_send()
        if out:
            s.sendall(out)

def serve_h1(s):
    buf = b""
    while True:
        while b"\r\n\r\n" not in buf:
            d = s.recv(65535)
            if not d:
                return
            buf += d
        head, buf = buf.split(b"\r\n\r\n", 1)
        n = 0
        for line in head.split(b"\r\n"):
            if line.lower().startswith(b"content-length:"):
                n = int(line.split(b":", 1)[1])
        while len(buf) < n:
            d = s.recv(65535)
            if not d:
                return
            buf += d
        q, buf = buf[:n], buf[n:]
        r = answer(q)
        s.sendall(b"HTTP/1.1 200 OK\r\nContent-Type: application/dns-message\r\nContent-Length: %d\r\n\r\n" % len(r) + r)

def handle(raw):
    try:
        s = ctx.wrap_socket(raw, server_side=True)
    except Exception:
        raw.close()
        return
    try:
        if s.selected_alpn_protocol() == "h2":
            serve_h2(s)
        else:
            serve_h1(s)
    except Exception:
        pass
    finally:
        s.close()

ls = socket.socket()
ls.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
ls.bind(("127.0.0.1", port))
ls.listen(32)
print("READY", flush=True)
while True:
    raw, _ = ls.accept()
    threading.Thread(target=handle, args=(raw,), daemon=True).start()
