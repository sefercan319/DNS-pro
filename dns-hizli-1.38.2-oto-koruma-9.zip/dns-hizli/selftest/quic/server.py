#!/usr/bin/env python3
"""DNS Hızlı QUIC testleri için gerçek bir QUIC sunucusu (aioquic): DoQ (RFC 9250) ya da DoH3.
Kullanım: server.py doq|h3 SERTİFİKA_ÖNEKİ PORT [big]
Her soruya A kaydı döner: DoQ -> 1.2.3.4, DoH3 -> 5.6.7.8. "big": cevaba 3000 bayt dolgu ekler (çok paketli cevap).
Hazır olunca stdout'a READY yazar. Yalnızca testler içindir."""
import asyncio, struct, sys
from aioquic.asyncio import QuicConnectionProtocol, serve
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.events import ProtocolNegotiated, StreamDataReceived

mode, cert, port = sys.argv[1], sys.argv[2], int(sys.argv[3])
big = len(sys.argv) > 4 and sys.argv[4] == "big"

def answer(q, ip):
    i = 12
    while q[i] != 0:
        i += 1 + q[i]
    end = i + 5
    r = b"\x00\x00\x81\x80" + q[4:6] + b"\x00\x01\x00\x00\x00\x00" + q[12:end] + b"\xc0\x0c\x00\x01\x00\x01\x00\x00\x00\x3c\x00\x04" + ip
    return r + (b"\x00" * 3000 if big else b"")

class Doq(QuicConnectionProtocol):
    def __init__(self, *a, **k):
        super().__init__(*a, **k); self.buf = {}
    def quic_event_received(self, ev):
        if isinstance(ev, StreamDataReceived):
            b = self.buf.get(ev.stream_id, b"") + ev.data; self.buf[ev.stream_id] = b
            if ev.end_stream:
                n = struct.unpack(">H", b[:2])[0]
                r = answer(b[2:2 + n], b"\x01\x02\x03\x04")
                self._quic.send_stream_data(ev.stream_id, struct.pack(">H", len(r)) + r, end_stream=True)
                self.transmit()

if mode == "h3":
    from aioquic.h3.connection import H3Connection
    from aioquic.h3.events import DataReceived, HeadersReceived
    class H3(QuicConnectionProtocol):
        def __init__(self, *a, **k):
            super().__init__(*a, **k); self.h3 = None; self.req = {}
        def quic_event_received(self, ev):
            if isinstance(ev, ProtocolNegotiated): self.h3 = H3Connection(self._quic)
            if self.h3 is None: return
            for e in self.h3.handle_event(ev):
                if isinstance(e, HeadersReceived): self.req[e.stream_id] = {"h": dict(e.headers), "d": b""}
                if isinstance(e, DataReceived):
                    self.req[e.stream_id]["d"] += e.data
                    if e.stream_ended:
                        h = self.req[e.stream_id]["h"]
                        ok = h.get(b":method") == b"POST" and h.get(b":path") == b"/dns-query" and h.get(b"content-type") == b"application/dns-message" and h.get(b":scheme") == b"https"
                        self.h3.send_headers(e.stream_id, [(b":status", b"200" if ok else b"400"), (b"content-type", b"application/dns-message")])
                        self.h3.send_data(e.stream_id, answer(self.req[e.stream_id]["d"], b"\x05\x06\x07\x08") if ok else b"", end_stream=True)
                        self.transmit()

async def main():
    cfg = QuicConfiguration(is_client=False, alpn_protocols=["h3" if mode == "h3" else "doq"])
    cfg.load_cert_chain(cert + ".crt", cert + ".key")
    await serve("127.0.0.1", port, configuration=cfg, create_protocol=H3 if mode == "h3" else Doq)
    print("READY", flush=True)
    await asyncio.sleep(3600)

asyncio.run(main())
