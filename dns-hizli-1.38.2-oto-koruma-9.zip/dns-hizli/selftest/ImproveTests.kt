package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

/**
 * 1.31: TLS şifre denetimi (TlsPolicy), liste içe aktarmada yeni biçimler ve istisnalar, ortak son ek koruması.
 * (Servis ağı, DPI ve arayüz denetimleri kendi dosyalarında.)
 */
fun runImproveTests() {
    testTlsPolicy()
    testHostsFormats()
    testHostsExceptions()
    testPublicSuffixGuard()
    testImproveFormat()
    testImproveModel()
    testImproveUi()
    testImproveStrings()
}

private fun testTlsPolicy() {
    T.group("TLS politikası: sürüm ve şifre takımı denetimi")
    T.check("TLS 1.3 AES-GCM kabul", TlsPolicy.acceptable("TLSv1.3", "TLS_AES_128_GCM_SHA256") && TlsPolicy.acceptable("TLSv1.3", "TLS_AES_256_GCM_SHA384"))
    T.check("TLS 1.3 ChaCha20 kabul", TlsPolicy.acceptable("TLSv1.3", "TLS_CHACHA20_POLY1305_SHA256"))
    T.check("TLS 1.2 ECDHE-GCM/ChaCha kabul",
        TlsPolicy.acceptable("TLSv1.2", "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256") &&
        TlsPolicy.acceptable("TLSv1.2", "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256"))
    T.check("eski sürümler reddedilir", listOf("TLSv1.1", "TLSv1", "SSLv3", "SSLv2", "", null).none { TlsPolicy.acceptable(it, "TLS_AES_128_GCM_SHA256") })
    T.check("statik RSA anahtar değişimi reddedilir (ileri gizlilik yok)", !TlsPolicy.acceptable("TLSv1.2", "TLS_RSA_WITH_AES_128_GCM_SHA256"))
    T.check("statik DH/ECDH reddedilir", !TlsPolicy.acceptable("TLSv1.2", "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256") && !TlsPolicy.acceptable("TLSv1.2", "TLS_DH_RSA_WITH_AES_128_GCM_SHA256"))
    T.check("RC4, 3DES, DES, NULL, EXPORT, anonim reddedilir",
        listOf("TLS_ECDHE_RSA_WITH_RC4_128_SHA", "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA", "TLS_DHE_RSA_WITH_DES_CBC_SHA",
            "TLS_ECDHE_RSA_WITH_NULL_SHA", "TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA", "TLS_ECDH_anon_WITH_AES_128_CBC_SHA").none { TlsPolicy.acceptable("TLSv1.2", it) })
    T.check("bilinmeyen/boş takım reddedilir", !TlsPolicy.acceptable("TLSv1.2", null) && !TlsPolicy.acceptable("TLSv1.2", "") && !TlsPolicy.acceptable("TLSv1.3", "TLS_FOO_WITH_BAR"))
    T.check("küçük harfli ad da denetlenir", !TlsPolicy.acceptable("TLSv1.2", "tls_ecdhe_rsa_with_rc4_128_sha"))
    T.check("check nedeni verir, kabulde null", TlsPolicy.check("TLSv1.1", "x")?.contains("TLS") == true && TlsPolicy.check("TLSv1.3", "TLS_AES_128_GCM_SHA256") == null)
    val thrown = try { TlsPolicy.require("TLSv1.2", "TLS_RSA_WITH_AES_256_CBC_SHA"); null } catch (e: javax.net.ssl.SSLPeerUnverifiedException) { e }
    T.check("require reddedileni güven hatası olarak fırlatır", thrown != null)
    T.check("require kabulde sessizdir", try { TlsPolicy.require("TLSv1.3", "TLS_AES_256_GCM_SHA384"); true } catch (_: Exception) { false })
}

private fun testHostsFormats() {
    T.group("Liste içe aktarma: dnsmasq, Unbound, RPZ ve AdBlock seçenekleri")
    val r = HostsList.parse("""
        address=/dm1.example.com/0.0.0.0
        address=/dm2.example.com/dm3.example.com/::
        address=/dm4.example.com/
        address=/yonlendir.example.com/10.1.2.3
        server=/dm5.example.com/
        server=/dm6.example.com/1.1.1.1
        local=/dm7.example.com/
        local-zone: "ub1.example.com." always_nxdomain
        local-zone: "ub2.example.com" always_null
        local-zone: "ub3.example.com." transparent
        local-zone: "ub4.example.com." static
        rpz1.example.com CNAME .
        rpz2.example.com CNAME *.
        ||ab1.example.com^${'$'}important
        ||ab2.example.com^${'$'}third-party,important
        ||ab3.example.com^${'$'}script
        ||ab4.example.com^${'$'}3p
        ||ab5.example.com^${'$'}image,third-party
        ||ab6.example.com^${'$'}all
    """.trimIndent())
    val n = r.names.toSet()
    T.check("dnsmasq address=/…/0.0.0.0 ve :: kabul", "dm1.example.com" in n && "dm2.example.com" in n && "dm3.example.com" in n)
    T.check("dnsmasq adressiz (NXDOMAIN) kabul", "dm4.example.com" in n)
    T.check("dnsmasq başka IP'ye yönlendirme alınmaz", "yonlendir.example.com" !in n)
    T.check("server=/ad/ (üst sunucusuz) ve local=/ad/ kabul, server=/ad/ip alınmaz", "dm5.example.com" in n && "dm7.example.com" in n && "dm6.example.com" !in n)
    T.check("Unbound engelleyici türler kabul (noktalı/noktasız)", "ub1.example.com" in n && "ub2.example.com" in n)
    T.check("Unbound transparent/static alınmaz", "ub3.example.com" !in n && "ub4.example.com" !in n)
    T.check("RPZ CNAME . kabul, CNAME *. alınmaz", "rpz1.example.com" in n && "rpz2.example.com" !in n)
    T.check("zararsız AdBlock seçenekleri (important, third-party, 3p, all) kabul", listOf("ab1", "ab2", "ab4", "ab6").all { "$it.example.com" in n })
    T.check("kısıtlayıcı seçenekler (script, image) alınmaz", "ab3.example.com" !in n && "ab5.example.com" !in n)
    T.check("atlananlar sayılır", r.skipped >= 7, r.skipped.toString())
    T.check("sonuç sıralı ve tekrarsız", r.names == r.names.sorted() && r.names.size == n.size)
    // gürültü: çökmemeli
    val rnd = java.util.Random(31)
    val alphabet = "address=/local-zone: \"always_nxdomain\"CNAME.@|^\$,server\n\t0123456789abc.xyz"
    var ok = true
    try { for (k in 0 until 3000) { val sb = StringBuilder(); repeat(rnd.nextInt(80)) { sb.append(alphabet[rnd.nextInt(alphabet.length)]) }; HostsList.parse(sb.toString()) } }
    catch (_: Throwable) { ok = false }
    T.check("rastgele gürültü ayrıştırıcıyı çökertmez", ok)
}

private fun testHostsExceptions() {
    T.group("Liste içe aktarma: @@ istisnaları")
    val r = HostsList.parse("""
        ||reklam.example.com^
        ||izleyici.example.com^
        ||cdn.example.net^
        ||diger.example.org^
        @@||izleyici.example.com^
        @@||example.net^
        @@||baska.example.org^${'$'}important
        @@||diger.example.org^${'$'}script
        @@/regex/
    """.trimIndent())
    val n = r.names.toSet()
    T.check("istisna verilen ad listeden çıkar", "izleyici.example.com" !in n)
    T.check("üst alan istisnası alt alanları da çıkarır", "cdn.example.net" !in n)
    T.check("ilgisiz adlar kalır", "reklam.example.com" in n && "diger.example.org" in n)
    T.check("yalnızca istisna olan seçenekli satır etkisizdir (kısıtlayıcı seçenek)", "diger.example.org" in n)
    T.check("çıkarılan sayı bildirilir", r.excepted == 2, r.excepted.toString())
    T.check("istisna etiket sınırında eşleşir (örnek.com, notexample.com'u çıkarmaz)",
        HostsList.parse("||notexample.com^\n||x.example.com^\n@@||example.com^").names == listOf("notexample.com"))
    T.check("yalnız istisna: boş sonuç", HostsList.parse("@@||a.example.com^").names.isEmpty())
}

private fun testPublicSuffixGuard() {
    T.group("Ortak son ek koruması (co.uk, com.tr…)")
    val was = PublicSuffix.ready
    try {
        // Liste yüklü değilken sezgi
        PublicSuffix.clear()
        T.check("sezgi: com.tr, co.uk, gov.au son ek", FilterNames.isPublicSuffix("com.tr") && FilterNames.isPublicSuffix("co.uk") && FilterNames.isPublicSuffix("gov.au"))
        T.check("sezgi: sıradan alan adları son ek değil", !FilterNames.isPublicSuffix("ornek.com") && !FilterNames.isPublicSuffix("magaza.com.tr") && !FilterNames.isPublicSuffix("example.org"))
        val f = java.io.File("app/src/main/assets/filter/psl.txt")
        if (f.exists()) {
            f.inputStream().use { PublicSuffix.install(it) }
            T.check("PSL: ICANN son ekleri", FilterNames.isPublicSuffix("com.tr") && FilterNames.isPublicSuffix("co.uk") && FilterNames.isPublicSuffix("org.uk") && FilterNames.isPublicSuffix("k12.ca.us"))
            T.check("PSL: joker kuralı (*.ck) altındaki ad son ek", FilterNames.isPublicSuffix("foo.ck"))
            T.check("PSL: istisna (www.ck) sıradan alan adı", !FilterNames.isPublicSuffix("www.ck"))
            T.check("PSL: özel bölüm (github.io, blogspot.com) engellenebilir kalır", !FilterNames.isPublicSuffix("github.io") && !FilterNames.isPublicSuffix("blogspot.com"))
            T.check("PSL: sıradan alan adları son ek değil", !FilterNames.isPublicSuffix("ornek.com") && !FilterNames.isPublicSuffix("magaza.com.tr") && !FilterNames.isPublicSuffix("a.b.example.org"))
            T.check("PSL: büyük harf ve sondaki nokta", FilterNames.isPublicSuffix("CO.UK.") && PublicSuffix.isIcannSuffix("co.uk") == true)
        }
        PublicSuffix.clear()
        T.check("liste yokken isIcannSuffix bilinmiyor (null)", PublicSuffix.isIcannSuffix("co.uk") == null)

        // içe aktarma
        val r = HostsList.parse("0.0.0.0 com.tr\n0.0.0.0 co.uk\n0.0.0.0 reklam.com.tr\n||org.uk^\n")
        T.check("içe aktarma: son ekler atlanır, gerçek ad alınır", r.names == listOf("reklam.com.tr") && r.skipped >= 3, r.names.toString() + " " + r.skipped)

        // model
        val rig = Rig()
        T.check("model: com.tr engel listesine eklenmez, nedeni açıkça söylenir", !rig.model.addFilterName(false, "com.tr") && rig.model.toast?.text == Strings.FILTER_ERR_SUFFIX && rig.model.settings.filterBlock.isEmpty())
        T.check("model: co.uk izin listesine de eklenmez", !rig.model.addFilterName(true, "co.uk") && rig.model.settings.filterAllow.isEmpty())
        T.check("model: magaza.com.tr eklenir", rig.model.addFilterName(false, "magaza.com.tr") && rig.model.settings.filterBlock == listOf("magaza.com.tr"))
    } finally {
        if (!was) PublicSuffix.clear()
    }
}

private fun recorded(r: Rig): List<String> = TextRecorder().also { r.scene.draw(it) }.runs.map { it.s }

private fun testImproveFormat() {
    T.group("Arayüz: alan adı kısaltma, yüzde, sıralama")
    val long = "cok-uzun-alt-alan.izleyici.reklam.example.com"
    val e = TextFit.ellipsizeStart(FixedMetrics, long, 200f, 16f, true)
    T.check("uzun ad baştan kısalır, sondaki alan adı korunur", e.startsWith("…") && e.endsWith("example.com") && FixedMetrics.textWidth(e, 16f, true) <= 200f, e)
    T.check("sığan ad değişmez, boş ad boş kalır", TextFit.ellipsizeStart(FixedMetrics, "a.com", 200f, 16f, true) == "a.com" && TextFit.ellipsizeStart(FixedMetrics, "", 10f, 16f, true) == "")
    T.check("hiç sığmıyorsa yalnızca …", TextFit.ellipsizeStart(FixedMetrics, long, 3f, 16f, true) == "…")
    val rnd = java.util.Random(5)
    var ok = true
    repeat(400) {
        val sb = StringBuilder(); repeat(1 + rnd.nextInt(8)) { sb.append("abcdefghij".substring(0, 1 + rnd.nextInt(9))).append('.') }
        val name = sb.toString() + "com"
        val maxW = rnd.nextInt(260).toFloat()
        val r = TextFit.ellipsizeStart(FixedMetrics, name, maxW, 16f, true)
        if (FixedMetrics.textWidth(r, 16f, true) > maxW && r != "…") ok = false
        if (r != name && !r.startsWith("…")) ok = false
        if (r != name && r != "…" && !name.endsWith(r.substring(1))) ok = false
    }
    T.check("rastgele adlar: genişliği aşmaz, sonek aynen korunur", ok)
    T.check("pay: yok → boş, %1 altı → <%1, normal → yüzde", Format.share(0, 100) == "" && Format.share(5, 0) == "" &&
        Format.share(1, 1000) == "<" + Strings.percent(1) && Format.share(50, 100) == Strings.percent(50) && Format.share(500, 100) == Strings.percent(100))
    T.check("sayı ve pay birlikte", Format.countWithShare(300, 2000) == Format.count(300) + " · " + Strings.percent(15) && Format.countWithShare(0, 2000) == Format.count(0))
    T.check("liste sıralaması: aynı sitenin alt alanları yan yana",
        FilterNames.sorted(listOf("www.b.com", "a.com", "ads.b.com", "b.com", "Z.org")) == listOf("a.com", "b.com", "ads.b.com", "www.b.com", "Z.org"))
}

private fun testImproveModel() {
    T.group("Arayüz modeli: geri al, kopyala, içe aktarma notları")
    run {
        val r = Rig()
        T.check("geçersiz ad: genel uyarı", !r.model.addFilterName(false, "yanlış ad") && r.model.toast?.text == Strings.FILTER_ERR)
        T.check("ortak son ek: ayrı ve açık uyarı", !r.model.addFilterName(true, "co.uk") && r.model.toast?.text == Strings.FILTER_ERR_SUFFIX && Strings.FILTER_ERR_SUFFIX != Strings.FILTER_ERR)
        r.model.addFilterName(false, "a.example.com")
        r.model.addFilterName(true, "a.example.com")
        T.check("izin verince geri al düğmesi çıkar", r.model.toast?.action == Strings.UNDO && r.model.settings.filterAllow == listOf("a.example.com") && r.model.settings.filterBlock.isEmpty())
        r.model.toast?.onAction?.invoke()
        T.check("geri al: iki liste de eski haline döner", r.model.settings.filterAllow.isEmpty() && r.model.settings.filterBlock == listOf("a.example.com"))
        r.model.addFilterName(false, "b.example.com")
        r.model.toast?.onAction?.invoke()
        T.check("engellemeyi geri al", r.model.settings.filterBlock == listOf("a.example.com"))
        T.check("toplu engelle: geri alınabilir", r.model.addFilterBlocks(listOf("x1.example.com", "x2.example.com", "x1.example.com")) &&
            r.model.settings.filterBlock.size == 3 && r.model.toast?.action == Strings.UNDO)
        r.model.toast?.onAction?.invoke()
        T.check("toplu engellemeyi geri al", r.model.settings.filterBlock == listOf("a.example.com"))
        T.check("yalnız ortak son ek verilirse toplu engel reddedilir ve açıklanır", !r.model.addFilterBlocks(listOf("com.tr", "co.uk")) && r.model.toast?.text == Strings.FILTER_ERR_SUFFIX)
        T.check("boş toplu engel sessiz reddedilir", !r.model.addFilterBlocks(emptyList()))
        r.model.copyNames(listOf("a.example.com", "b.example.com"))
        T.check("adlar satır satır panoya kopyalanır", r.host.clipboard == "a.example.com\nb.example.com" && r.model.toast?.text == Strings.mineCopied(2))
        r.model.copyNames(emptyList())
        T.check("boş liste kopyalanmaz", r.model.toast?.text == Strings.MINE_NOTHING)
    }
    run {
        val r = Rig()
        r.host.clipboard = "||a.example.com^\n||b.example.com^\n@@||b.example.com^\n"
        r.model.importFromClipboard()
        val t = r.model.toast
        T.check("içe aktarma: eklenen sayısı ve istisna notu", t != null && t.text.contains(Strings.mineAdded(1)) && t.text.contains(Strings.mineExcepted(1)), t?.text ?: "")
        T.check("içe aktarma geri alınabilir", t?.action == Strings.UNDO && r.host.imported == listOf("a.example.com") && r.model.importedCount == 1)
        t?.onAction?.invoke()
        T.check("geri al: önceki liste döner", r.host.imported.isEmpty() && r.model.importedCount == 0)
        r.host.clipboard = "||a.example.com^"
        r.model.importFromClipboard()
        r.host.clipboard = "||a.example.com^"
        r.model.importFromClipboard()
        T.check("yeni ad eklenmediyse geri al düğmesi yok", r.model.toast?.text == Strings.mineAdded(0) && r.model.toast?.action == null && r.model.importedCount == 1, r.model.toast?.text ?: "")
        r.host.importSaveOk = true
    }
}

private fun testImproveUi() {
    T.group("Arayüz: seçenek panelleri, menü, istatistik, filtre sayfası")
    FilterLive.clear()
    val base = Rig.base().copy(filterLevel = FilterLevel.MEDIUM, totals = UsageTotals(queries = 2000, blocked = 300))
    run {
        val r = Rig(base)
        r.scene.openMenu(); r.settle(900)
        T.check("menüde Engelleme satırı düzeyi ve toplam engeli gösterir", recorded(r).contains(Strings.OPT_FILTER[FilterLevel.MEDIUM.ordinal] + " · " + Format.count(300)), recorded(r).toString())
        val off = Rig(base.copy(filterLevel = FilterLevel.OFF))
        off.scene.openMenu(); off.settle(900)
        T.check("düzey kapalıyken yalnızca düzey yazar", recorded(off).contains(Strings.OPT_FILTER[0]) && recorded(off).none { it.startsWith(Strings.OPT_FILTER[0] + " ·") })
    }
    run {
        val r = Rig(base)
        r.scene.openSection(Section.STATS); r.settle(900)
        T.check("istatistikte engellenen sayısı yüzdesiyle yazar", recorded(r).contains(Format.countWithShare(300, 2000)), recorded(r).toString())
    }
    run {
        val r = Rig(base)
        r.scene.openSection(Section.FILTER); r.settle(900)
        T.check("filtre sayfasında 'site neden açılmıyor' kısayolu var", r.find(Strings.SITE_DIAG) != null || r.reveal(Strings.SITE_DIAG) != null)
    }
    run {
        // son engellenenler: sayaç rozeti, eylem satırı (radyo değil), kopyalama
        FilterLive.clear()
        repeat(3) { FilterLive.note("ads.example.net", false) }
        FilterLive.note("benim.example.org", true)
        val r = Rig(base)
        r.scene.openSection(Section.FILTER); r.settle(900)
        r.tapText(Strings.FILTER_LAST, settleMs = 900)
        val seen = recorded(r)
        T.check("son engellenenler: tekrar sayısı rozeti (3×), tek seferlik rozetsiz", seen.contains("3×") && seen.none { it == "1×" }, seen.toString())
        val row = r.find("ads.example.net")
        T.check("eylem satırı: seçili/seçili değil denmez, rozet okunur", row != null && row.info.checked == null && row.info.label.contains("3×"), row?.info?.label ?: "")
        T.check("Kopyala satırı sonda", r.find(Strings.COPY + ", ") != null)
        r.tapText(Strings.COPY + ", ", settleMs = 600)
        T.check("kopyalanan: en yeniden eskiye adlar", r.host.clipboard == "benim.example.org\nads.example.net", r.host.clipboard ?: "")
        r.tapText(Strings.FILTER_LAST, settleMs = 900)
        r.tapText("ads.example.net", settleMs = 900)
        T.check("ada dokununca izin verilir ve geri al sunulur", r.model.settings.filterAllow == listOf("ads.example.net") && r.model.toast?.action == Strings.UNDO)
        r.model.toast?.onAction?.invoke(); r.settle(300)
        T.check("geri al izni kaldırır", r.model.settings.filterAllow.isEmpty())
        FilterLive.clear()
    }
    run {
        // son izin verilenler: en sık görülen şüpheli en üstte
        FilterLive.clear()
        FilterLive.notePassed("haber.example.org")
        FilterLive.notePassed("ads.izleme-sitesi.com")
        repeat(3) { FilterLive.notePassed("0017c6c37c.com") }
        val r = Rig(base)
        r.scene.openSection(Section.FILTER); r.settle(900)
        r.tapText(Strings.FILTER_PASSED, settleMs = 900)
        val seen = recorded(r)
        val i1 = seen.indexOf("0017c6c37c.com"); val i2 = seen.indexOf("ads.izleme-sitesi.com"); val i3 = seen.indexOf("haber.example.org")
        T.check("şüpheliler sıklığa göre, sonra diğerleri", i1 in 0 until i2 && i2 < i3, "$i1 $i2 $i3")
        T.check("rozet: 3×", seen.contains("3×"))
        T.check("eylem simgesi: radyo yok (seçili bilgisi boş)", r.find("haber.example.org")?.info?.checked == null)
        FilterLive.clear()
    }
    run {
        // kendi engel listem: alfabetik (site gruplu), "Ekle…" satırında doluluk, uzun ad baştan kısalır
        val r = Rig(base)
        for (n in listOf("z.example.com", "a.example.com", "www.a.example.com")) r.model.addFilterName(false, n)
        r.model.addFilterName(false, "bu-cok-uzun-bir-alt-alan-adi.takip-agi.reklam-sunucusu.example.com")
        r.scene.openSection(Section.FILTER); r.settle(900)
        r.tapText(Strings.FILTER_BLOCK, exact = true, settleMs = 900)
        val seen = recorded(r)
        val ia = seen.indexOf("a.example.com"); val iw = seen.indexOf("www.a.example.com"); val iz = seen.indexOf("z.example.com")
        T.check("liste sıralı: a < www.a < z", ia >= 0 && ia < iw && iw < iz, "$ia $iw $iz")
        T.check("'Ekle…' satırında doluluk (4/200)", seen.contains("4/${FilterNames.MAX_LIST}"), seen.toString())
        T.check("uzun ad baştan kısalır: …ile biten sonek görünür", seen.any { it.startsWith("…") && it.endsWith("example.com") }, seen.toString())
        val add = r.find(Strings.FILTER_ADD)
        T.check("'Ekle…' bir eylem satırı", add != null && add.info.checked == null)
    }
    run {
        // radyo satırları eskisi gibi çalışır
        val r = Rig(base)
        r.scene.openOptions("Seç", listOf(Option("a", "Birinci", "", true), Option("b", "İkinci", "")), "", "") {}
        r.settle(900)
        T.check("seçim satırı: seçili/seçili değil bilgisi korunur", r.find("Birinci")?.info?.checked == true && r.find("İkinci")?.info?.checked == false)
    }
}

private fun testImproveStrings() {
    T.group("Yeni metinler (12 dil)")
    val saved = L.lang
    try {
        for (lang in Lang.values()) {
            L.set(lang)
            val n = lang.code
            T.check("$n: ortak son ek uyarısı 20..140 karakter, genel uyarıdan farklı", Strings.FILTER_ERR_SUFFIX.length in 20..140 && Strings.FILTER_ERR_SUFFIX != Strings.FILTER_ERR, Strings.FILTER_ERR_SUFFIX)
            T.check("$n: istisna notu sayıyı taşır", Strings.mineExcepted(37).contains("37") && Strings.mineExcepted(37).length in 8..90, Strings.mineExcepted(37))
            T.check("$n: içe aktarma notu yeni biçimleri anar (RPZ, dnsmasq, Unbound)", listOf("RPZ", "dnsmasq", "Unbound", "@@").all { it in Strings.MINE_FOOT } && Strings.MINE_FOOT.length in 80..260, Strings.MINE_FOOT.length.toString())
            T.check("$n: yer tutucu kalmamış", listOf(Strings.FILTER_ERR_SUFFIX, Strings.mineExcepted(3), Strings.MINE_FOOT).none { "TODO" in it || "{" in it || "%s" in it })
        }
    } finally { L.set(saved) }
}
