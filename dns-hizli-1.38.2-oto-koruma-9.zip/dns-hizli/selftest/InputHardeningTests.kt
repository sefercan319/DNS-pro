package app.dnshizli.selftest

import app.dnshizli.core.*
import java.security.SecureRandom
import app.dnshizli.core.X25519

/**
 * Dış ve kalıcı girdilere karşı dayanıklılık: rastgele ve mutasyona uğramış girdilerle tüm çözücüler denenir.
 * Beklenen: hiçbir çözücü beklenmeyen bir istisna fırlatmaz (OdohException gibi tanımlı hatalar hariç), sonuç hep geçerli bir değerdir.
 */
fun runInputHardeningTests() {
    val rnd = java.util.Random(20261011L)
    val alphabet = "abcxyz019.-_*:/|,;=\\n\t \u0000\u00e7\u0131\u00f6\u20ac@[]{}\"'" + "\u00ff"
    fun rstr(max: Int = 200): String {
        val n = rnd.nextInt(max)
        return String(CharArray(n) { alphabet[rnd.nextInt(alphabet.length)] })
    }
    fun mutate(s: String): String {
        if (s.isEmpty()) return rstr(8)
        val c = s.toCharArray()
        repeat(1 + rnd.nextInt(4)) { c[rnd.nextInt(c.size)] = alphabet[rnd.nextInt(alphabet.length)] }
        return String(c)
    }

    fun sweep(name: String, iters: Int, seeds: List<String>, f: (String) -> Unit) {
        var bad = 0
        var first: Throwable? = null
        for (i in 0 until iters) {
            val input = if (seeds.isNotEmpty() && i % 2 == 0) mutate(seeds[rnd.nextInt(seeds.size)]) else rstr()
            try { f(input) } catch (t: Throwable) { bad++; if (first == null) first = t }
        }
        T.check("$name: $iters girdide beklenmeyen istisna yok", bad == 0,
            if (bad == 0) "" else "$bad istisna, ilki: ${first?.javaClass?.name}: ${first?.message}")
    }

    T.group("Dayanıklılık: kalıcı kayıt çözücüleri (rastgele ve mutasyonlu girdi)")
    run {
        sweep("Ağa göre DPI belleği", 3000, listOf("MOBILE|28601=3:2;WIFI|=1:-1")) { PlanMemory().decode(it) }
        sweep("Filtre listesi", 3000, listOf("a.com,b.org,c.net")) { FilterNames.decode(it) }
        sweep("Uygulama kümesi", 3000, listOf("app.one,app.two")) { AppScopes.decode(it) }
        sweep("Sunucu gecikmeleri", 3000, listOf("cloudflare=12,quad9=40")) { LatencyCodec.decode(it) }
        sweep("Sunucu sıralama kayıtları", 3000, listOf("cloudflare=1,2,null")) { LatencyHistory.decode(it) }
        sweep("Özel DNS sunucuları", 3000, listOf("1.1.1.1|one.one.one.one")) { CustomDns.decode(it) }
        sweep("Sunucu görünümü (orb)", 3000, listOf("cloudflare=1")) { OrbShapes.decode(it) }
        sweep("Oturum listesi", 3000, listOf("1,MOBILE,100,200,ok,5|")) { SessionLog.decode(it) }
        sweep("Kullanım süreleri", 3000, listOf("1=5;2=9")) { UsageStats.decode(it) }
        sweep("Base64 çözücü (ayar bayt alanları)", 3000, listOf("AAECAw==")) { Base64Mini.decode(it) }
        sweep("Günlük istatistik kayıtları", 3000, listOf("20261011=5,20261012=9")) { DailyStats.decode(it) }
    }

    T.group("Dayanıklılık: dışarıdan yapıştırılan veri (engelleme listesi, IP, ODoH yapılandırması)")
    run {
        sweep("Engelleme listesi (hosts) ayrıştırma", 3000, listOf("0.0.0.0 ads.example.com\n# yorum")) { HostsList.parse(it) }
        sweep("IP adresi ayrıştırma", 5000, listOf("192.168.1.1", "2001:db8::1")) { Ip.parse(it) }

        var odohBad = 0
        var first: Throwable? = null
        var parsedOk = 0
        for (i in 0 until 3000) {
            val b = ByteArray(rnd.nextInt(200)).also { rnd.nextBytes(it) }
            try {
                OdohConfigs.parse(b).size.let { parsedOk += if (it >= 0) 1 else 0 }
            } catch (_: OdohException) {
            } catch (t: Throwable) { odohBad++; if (first == null) first = t }
        }
        T.check("ODoH yapılandırma: 3000 rastgele baytta yalnızca OdohException", odohBad == 0,
            if (odohBad == 0) "" else "istisna: ${first?.javaClass?.name}: ${first?.message}")
    }

    T.group("Dayanıklılık: ODoH sorgu tarafı (rastgele cevap gövdeleri)")
    run {
        val pk = ByteArray(32) { (it * 7 + 3).toByte() }
        val cfg = OdohConfig(ByteArray(40) { it.toByte() }, pk)
        val q = OdohClient.seal(cfg, ByteArray(40) { 1 }, SecureRandom())
        var bad = 0
        var accepted = 0
        var first: Throwable? = null
        for (i in 0 until 4000) {
            val body = if (i % 2 == 0) ByteArray(rnd.nextInt(300)).also { rnd.nextBytes(it) } else ByteArray(rnd.nextInt(300) + 40).also { rnd.nextBytes(it); it[0] = 2 }
            try {
                q.open(body, 0, body.size)
                accepted++
            } catch (_: OdohException) {
            } catch (t: Throwable) { bad++; if (first == null) first = t }
        }
        T.check("ODoH cevap: 4000 rastgele gövdede yalnızca OdohException (kabul yok: $accepted)", bad == 0,
            if (bad == 0) "" else "istisna: ${first?.javaClass?.name}: ${first?.message}")
        T.check("rastgele gövde kimlik doğrulamadan geçmez", accepted == 0)
    }
}

/** ODoH sorgu bağlama: cevap yalnızca kendi sorgusuna aittir; başka sorguda, değiştirilmiş ya da kopyalanmış cevap açılmaz. */
fun runOdohBindingTests() {
    T.group("ODoH: cevap sorguya bağlıdır (tekrar, karıştırma, değiştirme)")
    run {
        val rng = SecureRandom()
        val sk = ByteArray(32).also { rng.nextBytes(it) }
        val pk = X25519.publicKey(sk)
        val cfg = OdohConfig(ByteArray(40) { (it * 3 + 1).toByte() }, pk)
        val dnsA = ByteArray(30) { 1 }
        val dnsB = ByteArray(30) { 2 }
        val qA = OdohClient.seal(cfg, dnsA, rng)
        val qB = OdohClient.seal(cfg, dnsB, rng)
        val oA = SimTarget.Companion.open(sk, cfg.keyId, qA.wire)
        val oB = SimTarget.Companion.open(sk, cfg.keyId, qB.wire)
        T.check("sunucu benzetimi her iki sorguyu açabiliyor", oA != null && oB != null)
        if (oA == null || oB == null) return@run

        val respA = SimTarget.Companion.respond(oA, dnsA)
        T.check("kendi sorgusunun cevabı açılır", qA.open(respA, 0, respA.size).contentEquals(dnsA))

        var crossAccepted = false
        try { crossAccepted = qB.open(respA, 0, respA.size).let { true } } catch (_: OdohException) { crossAccepted = false }
        T.check("A'nın cevabı B sorgusu için açılmaz (tekrar/karıştırma reddi)", !crossAccepted)

        val respB = SimTarget.Companion.respond(oB, dnsB)
        var swapAccepted = false
        try { qA.open(respB, 0, respB.size); swapAccepted = true } catch (_: OdohException) {}
        T.check("B'nin cevabı A sorgusu için açılmaz", !swapAccepted)

        var flipAccepted = false
        val flipped = respA.copyOf().also { it[it.size - 1] = (it[it.size - 1].toInt() xor 1).toByte() }
        try { qA.open(flipped, 0, flipped.size); flipAccepted = true } catch (_: OdohException) {}
        T.check("cevabın son baytı değişirse reddedilir", !flipAccepted)
    }
}
