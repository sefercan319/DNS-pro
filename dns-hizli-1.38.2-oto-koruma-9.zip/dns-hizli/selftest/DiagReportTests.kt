package app.dnshizli.selftest

import app.dnshizli.core.DiagInput
import app.dnshizli.core.DiagReport

private fun sample(model: String = "Samsung SM-S911B", failClosed: Boolean = false, netKind: String = "WIFI") = DiagInput(
    appVersion = "1.27.0", versionCode = 44, androidSdk = 36, deviceModel = model, netKind = netKind,
    vpnActive = true, encryption = "AUTO", odoh = "OFF", ipMode = "BOTH", failClosed = failClosed,
    strictEncryption = false, filterMem = "AUTO", problems = 0, crashCount = 0, lastCrash = null,
)

/** Tanılama raporu: gizlilik kuralları (alan adı, IP, kullanıcı tanımlayıcısı yok) ve biçim sınırları. */
fun runDiagReportTests() {
    T.group("Tanılama raporu: gizlilik")
    run {
        val text = DiagReport.build(sample())
        T.check("tipik rapor alan adı, IP ya da '@' içermez", !DiagReport.containsSensitive(text), text)
        T.check("sürüm numarası (1.27.0) alan adı sanılmaz", text.contains("Sürüm: 1.27.0 (44)"))
        T.check("başlık alan adı sanılmaz", text.lineSequence().first() == "DNS Hızlı tanılama raporu")

        val evil = DiagReport.build(sample(model = "evil.example.com 10.0.0.1 user@mail.org"))
        T.check("cihaz adına gömülmüş alan adı/IP/e-posta rapora çıkmaz", !DiagReport.containsSensitive(evil), evil)
        T.check("kötü cihaz adı yine de rapor satırı olarak kalır", evil.contains("Cihaz: "))

        val ipv6 = DiagReport.build(sample(netKind = "2001:db8::1"))
        T.check("ağ türü alanına IPv6 yazılsa bile sızmaz", !DiagReport.containsSensitive(ipv6), ipv6)
    }

    T.group("Tanılama raporu: temizleme ve biçim")
    run {
        T.check("kontrol karakterleri silinir (boşluğa çevrilmez)", DiagReport.clean("a\nb\tc\u0000d") == "abcd", DiagReport.clean("a\nb\tc\u0000d"))
        T.check("'@' işareti silinir", !DiagReport.clean("x@y").contains('@'))
        T.check("alan adı benzeri değer '?' ile değiştirilir", DiagReport.clean("sunucu ornek.com") == "sunucu ?")
        T.check("alan uzunluğu 60 ile sınırlı", DiagReport.clean("a".repeat(500)).length == 60)
        val long = DiagReport.build(sample(model = "x".repeat(10000)))
        T.check("rapor toplam boyutu ${DiagReport.MAX} ile sınırlı", long.length <= DiagReport.MAX)

        val fc = DiagReport.build(sample(failClosed = true))
        T.check("bağlantı kesilince engelle açık olarak yazılır", fc.contains("Bağlantı kesilince engelle: açık"))
        T.check("tünel durumu yazılır", DiagReport.build(sample()).contains("Tünel: açık"))
        T.check("rapor 15 satır: başlık + 14 alan", DiagReport.build(sample()).lines().size == 15)
        T.check("çökme yoksa 'Son çökme: yok' yazılır", DiagReport.build(sample()).contains("Son çökme: yok"))
        val crashed = DiagReport.build(DiagInput(sample().appVersion, 44, 36, "Model", "WIFI", true, "AUTO", "OFF", "BOTH", false, false, "AUTO", 0, 2,
            "java.lang.IllegalStateException evil.example.com"))
        T.check("çökme sayısı ve özeti yazılır, alan adı çökme özetinde de çıkmaz",
            crashed.contains("Kayıtlı çökme: 2") && !DiagReport.containsSensitive(crashed), crashed)
        T.check("sorun sayısı negatif olamaz", DiagReport.build(sample().let {
            DiagInput(it.appVersion, it.versionCode, it.androidSdk, it.deviceModel, it.netKind, it.vpnActive, it.encryption,
                it.odoh, it.ipMode, it.failClosed, it.strictEncryption, it.filterMem, problems = -5,
                crashCount = 0, lastCrash = null)
        }).contains("Sorun sayısı: 0"))
    }
}
