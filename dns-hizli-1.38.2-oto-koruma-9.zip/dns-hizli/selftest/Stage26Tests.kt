package app.dnshizli.selftest

import app.dnshizli.core.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Üst sunucu taklidi (UDP/53): sorunun ad harflerini kaydeder ve A 1.2.3.4 ile yanıtlar.
 * "echo": harfleri aynen yankılar (0x20 ile uyumlu sunucu). "lower": yanıtta harfleri küçültür (harf yansıtmayan bozuk sunucu).
 */
private class CaseSrv(private val mode: String) : AutoCloseable {
    private val loop = InetAddress.getByName("127.0.0.1")
    private val socket = DatagramSocket(0, loop)
    val seen = CopyOnWriteArrayList<String>()
    @Volatile private var running = true
    val addr: InetSocketAddress get() = InetSocketAddress(loop, socket.localPort)

    init {
        Thread {
            val buf = ByteArray(1500)
            val pk = DatagramPacket(buf, buf.size)
            while (running) {
                try { socket.receive(pk) } catch (_: Exception) { break }
                val q = buf.copyOf(pk.length)
                val qEnd = Dns.questionEnd(q, 0, q.size)
                if (qEnd < 12 + 5) continue
                seen.add(String(q, 12, qEnd - 16, Charsets.ISO_8859_1))
                val r = answer(q, qEnd)
                try { socket.send(DatagramPacket(r, r.size, pk.socketAddress)) } catch (_: Exception) {}
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun answer(q: ByteArray, qEnd: Int): ByteArray {
        val rr = byteArrayOf(0xC0.toByte(), 12, 0, 1, 0, 1, 0, 0, 0, 60, 0, 4, 1, 2, 3, 4)
        val out = ByteArray(qEnd + rr.size)
        System.arraycopy(q, 0, out, 0, qEnd)
        System.arraycopy(rr, 0, out, qEnd, rr.size)
        Packets.put16(out, 2, 0x8180); Packets.put16(out, 4, 1); Packets.put16(out, 6, 1); Packets.put16(out, 8, 0); Packets.put16(out, 10, 0)
        if (mode == "lower") for (i in 12 until qEnd - 4) { val b = out[i].toInt(); if (b in 0x41..0x5A) out[i] = (b + 32).toByte() }
        return out
    }

    override fun close() { running = false; socket.close() }
}

/** Yönlendiriciye verilen IPv4/UDP sorgusu (tünelden gelen biçim). */
private fun ipQuery(id: Int, name: String): ByteArray {
    val dns = Dns.buildQuery(id, name)
    val b = ByteArray(Packets.HDR + dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size); Packets.put16(b, 6, 0x4000)
    b[8] = 64; b[9] = 17
    Packets.put32(b, 12, 0x0A000002); Packets.put32(b, 16, 0x0A000001)
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, 40001); Packets.put16(b, 22, 53); Packets.put16(b, 24, 8 + dns.size)
    System.arraycopy(dns, 0, b, 28, dns.size)
    return b
}

private fun lastIpOf(ip: ByteArray): String = (ip.size - 4 until ip.size).joinToString(".") { (ip[it].toInt() and 0xFF).toString() }

/** Yanıtın DNS bölümü (IPv4/UDP başlığından sonra). */
private fun dnsOf(ip: ByteArray): ByteArray = ip.copyOfRange(28, ip.size)

/** Tünele yazılan DNS cevabı: IPv4/UDP (kaynak port 53), [name] için A kayıtları [ips]. */
private fun replyPacket(name: String, ips: List<ByteArray>): ByteArray {
    val q = Dns.buildQuery(0x1234, name)                    // başlık + soru
    val ans = java.io.ByteArrayOutputStream()
    for (ip in ips) { ans.write(byteArrayOf(0xC0.toByte(), 0x0C, 0, 1, 0, 1, 0, 0, 0, 60, 0, 4)); ans.write(ip) }
    val dns = q.copyOf() + ans.toByteArray()
    Packets.put16(dns, 2, 0x8180); Packets.put16(dns, 6, ips.size)
    val b = ByteArray(Packets.HDR + dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size)
    b[8] = 64; b[9] = 17
    Packets.put32(b, 12, 0x0A000001); Packets.put32(b, 16, 0x0A000002)
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, 53); Packets.put16(b, 22, 40001); Packets.put16(b, 24, 8 + dns.size)
    System.arraycopy(dns, 0, b, 28, dns.size)
    return b
}

fun runStage26Tests() {
    T.group("HTTP/2 başlık çözümü (yalnızca :status)")
    run {
        fun st(vararg b: Int) = Http2Client.statusOf(ByteArray(b.size) { b[it].toByte() })
        T.check("indeksli :status 200 (0x88)", st(0x88) == 200)
        T.check("indeksli :status 404 (0x8d)", st(0x8d) == 404)
        T.check("literal ad (:status, indeks 8) düz değer 503", st(0x48, 3, 0x35, 0x30, 0x33) == 503)
        T.check("başka başlıklar atlanır: content-type (31) + abc, sonra 200", st(0x5F, 3, 0x61, 0x62, 0x63, 0x88) == 200)
        T.check("Huffman kodlu :status değeri çözülür (200)", st(0x48, 0x82, 0x10, 0x01) == 200)
        T.check("başlık bloğu yoksa -1", st() == -1)
        T.check("boş dinamik tabloya dizin (62) reddedilir", try { st(0xBE); false } catch (_: java.io.IOException) { true })
        T.check("aşırı büyük HPACK tamsayısı reddedilir", try { st(0x0F, 0xFF.toInt(), 0xFF.toInt(), 0xFF.toInt(), 0x7F); false } catch (_: java.io.IOException) { true })
        T.check("kesik dizgi reddedilir", try { st(0x48, 9, 0x35); false } catch (_: java.io.IOException) { true })
    }
    T.group("HPACK tam çözümü (Huffman, dinamik tablo, tablo boyutu) — python hpack ile üretilmiş vektörler")
    run {
        fun hex(s: String): ByteArray = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        fun fields(d: HpackDecoder, s: String): Map<String, String> = d.decode(hex(s)).associate { it.name to it.value }
        val d = HpackDecoder()
        val b0 = fields(d, "885f901d75d0620d263d4c495216a4a840e62f768692a42c92a13f5888a47e561cc581c07f")
        T.check("B0: :status 200, content-type, server, cache-control çözülür (Huffman)",
            b0[":status"] == "200" && b0["content-type"] == "application/dns-message" && b0["server"] == "dns-test" && b0["cache-control"] == "max-age=60", b0.toString())
        val b1 = fields(d, "88c0bf4085f2b26c190b851c64582267")
        T.check("B1: dinamik tablodan (önceki blok) alanlar geri okunur", b1["server"] == "dns-test" && b1["x-trace"] == "abc-123" && b1["content-type"] == "application/dns-message")
        val b2 = fields(d, "48836c0cff5f87497ca58ae819aa75816f")
        T.check("B2: 503 ve retry-after (düz değil, Huffman)", b2[":status"] == "503" && b2["content-type"] == "text/plain" && b2["retry-after"] == "5", b2.toString())
        val b3 = fields(d, "3f61885f901d75d0620d263d4c495216a4a840e62f768692a42c92a13f")
        T.check("B3: tablo boyutu güncellemesi (128) sonrası çözüm doğru", b3[":status"] == "200" && b3["server"] == "dns-test")
        T.check("tablo boyutu üst sınırı aşılırsa reddedilir (5000 > 4096)",
            try { HpackDecoder().decode(hex("3fe926")); false } catch (_: java.io.IOException) { true })
        T.check("Huffman dolgusu bozuksa (0 bitleri) reddedilir",
            try { HpackDecoder().decode(hex("0001618100")) ; false } catch (_: java.io.IOException) { true })
        val push = fields(HpackDecoder(), "82448462bb513f874185f2ba4a84ff")
        T.check("PUSH_PROMISE blok çözülür (tablo eşitliği için)", push[":method"] == "GET" && push[":path"] == "/push" && push[":authority"] == "x.test", push.toString())
    }
    T.group("HTTP/2 istemcisi: push reddi, 1xx atlama, tam yanıt (boru üzerinden sahte sunucu)")
    run {
        fun frame(type: Int, flags: Int, sid: Int, p: ByteArray): ByteArray {
            val h = ByteArray(9)
            h[0] = (p.size shr 16).toByte(); h[1] = (p.size shr 8).toByte(); h[2] = p.size.toByte()
            h[3] = type.toByte(); h[4] = flags.toByte()
            h[5] = (sid shr 24).toByte(); h[6] = (sid shr 16).toByte(); h[7] = (sid shr 8).toByte(); h[8] = sid.toByte()
            return h + p
        }
        fun hex(s: String): ByteArray = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        val b0 = hex("885f901d75d0620d263d4c495216a4a840e62f768692a42c92a13f5888a47e561cc581c07f")
        val push = hex("82448462bb513f874185f2ba4a84ff")
        val body = byteArrayOf(0, 0, 0x81.toByte(), 0x80.toByte())
        val srvOut = java.io.PipedOutputStream()
        val cliIn = java.io.PipedInputStream(srvOut, 65536)
        val cliOut = java.io.ByteArrayOutputStream()
        val cli = Http2Client(cliIn, cliOut, "x.test") { System.nanoTime() / 1_000_000 }
        cli.start()
        val base = cliOut.size()
        var res: Http2Client.Response? = null
        var err: String? = null
        val th = Thread { try { res = cli.post("/dns-query", "application/dns-message", byteArrayOf(1, 2, 3), 5000) } catch (e: Exception) { err = e.message } }
        th.start()
        val until = System.nanoTime() + 5_000_000_000L
        while (cliOut.size() <= base && System.nanoTime() < until) Thread.sleep(5)     // istek yazıldı: akış kayıtlı
        srvOut.write(frame(Http2Client.TYPE_SETTINGS, 0, 0, ByteArray(0)))
        srvOut.write(frame(Http2Client.TYPE_PUSH_PROMISE, Http2Client.FLAG_END_HEADERS, 1, byteArrayOf(0, 0, 0, 2) + push))
        srvOut.write(frame(Http2Client.TYPE_HEADERS, Http2Client.FLAG_END_HEADERS, 1, byteArrayOf(0x48, 0x03, 0x31, 0x30, 0x30)))   // 100 Continue (atlanmalı)
        srvOut.write(frame(Http2Client.TYPE_HEADERS, Http2Client.FLAG_END_HEADERS, 1, b0))
        srvOut.write(frame(Http2Client.TYPE_DATA, Http2Client.FLAG_END_STREAM, 1, body))
        th.join(6000)
        val r = res
        T.check("sahte sunucu: push ve yanıt içeren bağlantıda cevap alınır", r != null && r.status == 200 && r.body.size == 4, "err=$err")
        val rst = cliOut.toByteArray().let { bs ->
            val pat = byteArrayOf(0, 0, 4, 3, 0, 0, 0, 0, 2, 0, 0, 0, 8)     // RST_STREAM(2, CANCEL)
            (0..bs.size - pat.size).any { i -> pat.indices.all { bs[i + it] == pat[it] } }
        }
        T.check("push akışı RST_STREAM(CANCEL) ile reddedilir, bağlantı açık", rst && cli.alive)
        cli.close()
    }
    T.group("HTTP/2 istemcisi: paylaşılan bağlantıda eşzamanlı sorgular (akış kimliği sırası, akış hatası yalıtımı)")
    run {
        fun frame(type: Int, flags: Int, sid: Int, p: ByteArray): ByteArray {
            val h = ByteArray(9)
            h[0] = (p.size shr 16).toByte(); h[1] = (p.size shr 8).toByte(); h[2] = p.size.toByte()
            h[3] = type.toByte(); h[4] = flags.toByte()
            h[5] = (sid shr 24).toByte(); h[6] = (sid shr 16).toByte(); h[7] = (sid shr 8).toByte(); h[8] = sid.toByte()
            return h + p
        }
        fun hex(s: String): ByteArray = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        val b0 = hex("885f901d75d0620d263d4c495216a4a840e62f768692a42c92a13f5888a47e561cc581c07f")      // :status 200 + content-type
        val body = byteArrayOf(0, 0, 0x81.toByte(), 0x80.toByte())
        val ss = java.net.ServerSocket(0, 50, java.net.InetAddress.getLoopbackAddress())
        val violations = java.util.concurrent.atomic.AtomicInteger()
        val rstAt = 7                                           // bu kimlikli akış sunucuca iptal edilir
        val srvThread = Thread {
            try {
                ss.accept().use { c ->
                    val inp = java.io.DataInputStream(c.getInputStream()); val out = c.getOutputStream()
                    inp.readFully(ByteArray(24))                // preface
                    out.write(frame(Http2Client.TYPE_SETTINGS, 0, 0, ByteArray(0))); out.flush()
                    var last = 0
                    val hdr = ByteArray(9)
                    while (true) {
                        inp.readFully(hdr)
                        val len = ((hdr[0].toInt() and 0xFF) shl 16) or ((hdr[1].toInt() and 0xFF) shl 8) or (hdr[2].toInt() and 0xFF)
                        val type = hdr[3].toInt() and 0xFF
                        val sid = ((hdr[5].toInt() and 0x7F) shl 24) or ((hdr[6].toInt() and 0xFF) shl 16) or ((hdr[7].toInt() and 0xFF) shl 8) or (hdr[8].toInt() and 0xFF)
                        inp.readFully(ByteArray(len))
                        if (type == Http2Client.TYPE_HEADERS) {
                            if (sid <= last) { violations.incrementAndGet(); return@use }       // katı sunucu: PROTOCOL_ERROR → bağlantıyı keser
                            last = sid
                            synchronized(out) {
                                if (sid == rstAt) out.write(frame(Http2Client.TYPE_RST_STREAM, 0, sid, byteArrayOf(0, 0, 0, 8)))
                                else { out.write(frame(Http2Client.TYPE_HEADERS, Http2Client.FLAG_END_HEADERS, sid, b0)); out.write(frame(Http2Client.TYPE_DATA, Http2Client.FLAG_END_STREAM, sid, body)) }
                                out.flush()
                            }
                        }
                    }
                }
            } catch (_: Exception) {}
        }.also { it.isDaemon = true; it.start() }
        val sock = java.net.Socket(java.net.InetAddress.getLoopbackAddress(), ss.localPort)
        val cli = Http2Client(sock.getInputStream(), sock.getOutputStream(), "x.test") { System.nanoTime() / 1_000_000 }
        cli.start()
        val ok = java.util.concurrent.atomic.AtomicInteger()
        val streamErrs = java.util.concurrent.atomic.AtomicInteger()
        val other = java.util.concurrent.atomic.AtomicInteger()
        val ths = (1..8).map { Thread { repeat(25) {
            try { cli.post("/dns-query", "application/dns-message", byteArrayOf(1, 2, 3), 5000); ok.incrementAndGet() }
            catch (e: H2StreamError) { streamErrs.incrementAndGet() }
            catch (e: Exception) { other.incrementAndGet() }
        } }.also { t -> t.start() } }
        ths.forEach { it.join(20_000) }
        T.check("200 eşzamanlı istekte akış kimlikleri tele artan sırayla gider (katı sunucu ihlal görmez)", violations.get() == 0, "ihlal=${violations.get()} ok=${ok.get()} akışHatası=${streamErrs.get()} diğer=${other.get()}")
        T.check("sunucunun iptal ettiği tek akış yalnızca o isteği düşürür, bağlantı ve öteki 199 istek sağlam", streamErrs.get() == 1 && ok.get() == 199 && other.get() == 0 && cli.alive, "ok=${ok.get()} akışHatası=${streamErrs.get()} diğer=${other.get()} canlı=${cli.alive}")
        cli.close(); sock.close(); ss.close()
    }
    T.group("HTTP/2 istemcisi: GOAWAY ile nazik kapanış (eldeki istek tamamlanır, yenisi alınmaz)")
    run {
        fun frame(type: Int, flags: Int, sid: Int, p: ByteArray): ByteArray {
            val h = ByteArray(9)
            h[0] = (p.size shr 16).toByte(); h[1] = (p.size shr 8).toByte(); h[2] = p.size.toByte()
            h[3] = type.toByte(); h[4] = flags.toByte()
            h[5] = (sid shr 24).toByte(); h[6] = (sid shr 16).toByte(); h[7] = (sid shr 8).toByte(); h[8] = sid.toByte()
            return h + p
        }
        fun hex(s: String): ByteArray = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        val b0 = hex("885f901d75d0620d263d4c495216a4a840e62f768692a42c92a13f5888a47e561cc581c07f")
        val ss = java.net.ServerSocket(0, 5, java.net.InetAddress.getLoopbackAddress())
        Thread {
            try {
                ss.accept().use { c ->
                    val inp = java.io.DataInputStream(c.getInputStream()); val out = c.getOutputStream()
                    inp.readFully(ByteArray(24))
                    out.write(frame(Http2Client.TYPE_SETTINGS, 0, 0, ByteArray(0))); out.flush()
                    val hdr = ByteArray(9)
                    while (true) {
                        inp.readFully(hdr)
                        val len = ((hdr[0].toInt() and 0xFF) shl 16) or ((hdr[1].toInt() and 0xFF) shl 8) or (hdr[2].toInt() and 0xFF)
                        val type = hdr[3].toInt() and 0xFF
                        val sid = ((hdr[5].toInt() and 0x7F) shl 24) or ((hdr[6].toInt() and 0xFF) shl 16) or ((hdr[7].toInt() and 0xFF) shl 8) or (hdr[8].toInt() and 0xFF)
                        inp.readFully(ByteArray(len))
                        if (type == Http2Client.TYPE_HEADERS && sid == 1) {
                            out.write(frame(Http2Client.TYPE_GOAWAY, 0, 0, byteArrayOf(0, 0, 0, 1, 0, 0, 0, 0)))      // son akış 1, NO_ERROR
                            Thread.sleep(150)                                                                          // cevap GOAWAY'dan SONRA gelir
                            out.write(frame(Http2Client.TYPE_HEADERS, Http2Client.FLAG_END_HEADERS, 1, b0))
                            out.write(frame(Http2Client.TYPE_DATA, Http2Client.FLAG_END_STREAM, 1, byteArrayOf(0, 0, 0x81.toByte(), 0x80.toByte())))
                            out.flush()
                        }
                    }
                }
            } catch (_: Exception) {}
        }.also { it.isDaemon = true; it.start() }
        val sock = java.net.Socket(java.net.InetAddress.getLoopbackAddress(), ss.localPort)
        val cli = Http2Client(sock.getInputStream(), sock.getOutputStream(), "x.test") { System.nanoTime() / 1_000_000 }
        cli.start()
        val r = try { cli.post("/dns-query", "application/dns-message", byteArrayOf(1, 2, 3), 5000) } catch (e: Exception) { null }
        T.check("GOAWAY'dan sonra gelen cevap yine teslim edilir (eldeki istek düşmez)", r != null && r.status == 200 && r.body.size == 4)
        T.check("GOAWAY alan bağlantı yeni istek için kullanılabilir sayılmaz", !cli.usable(System.nanoTime() / 1_000_000))
        val second = try { cli.post("/dns-query", "application/dns-message", byteArrayOf(1, 2, 3), 1000); null } catch (e: java.io.IOException) { e }
        T.check("kapanmakta olan bağlantıya yeni istek reddedilir (hızlı hata, yeniden denenir)", second != null && second !is java.net.SocketTimeoutException)
        cli.close(); sock.close(); ss.close()
    }
    T.group("0x20: sorgu adı rastgele büyük/küçük harfle gider, cevap birebir eşleşir")
    run {
        val name = "abcdefghijklmnopqrstuvwxyz.example"
        val srv = CaseSrv("echo")
        val tun = LinkedBlockingQueue<ByteArray>()
        val fw = DnsForwarder(listOf(srv.addr), { b, o, l -> tun.add(b.copyOfRange(o, o + l)) }, retryAfterMs = 300, giveUpAfterMs = 2000, sweepMs = 50).also { it.start() }
        val orig = Dns.buildQuery(0x5151, name)
        val q = ipQuery(0x5151, name)
        fw.onPacket(q, q.size)
        val rep = tun.poll(3, TimeUnit.SECONDS)?.let { dnsOf(it) }
        T.check("0x20'li sorgu sunucudan cevaplanır", rep != null && Packets.u16(rep, 2) and 0x8000 != 0 && Packets.u16(rep, 6) == 1)
        T.check("sunucuya giden ad harfleri karışık (rastgele) gönderilmiş", srv.seen.isNotEmpty() && srv.seen.any { it != it.lowercase() })
        T.check("istemciye dönen soru özgün harflerle (küçük) geri yazılmış", rep != null && rep.size > orig.size && (12 until orig.size).all { rep[it] == orig[it] })
        fw.close(); srv.close()
    }
    T.group("0x20: harfleri yansıtmayan sunucuda 0x20 uyarlamalı olarak kapanır")
    run {
        val srv = CaseSrv("lower")
        val tun = LinkedBlockingQueue<ByteArray>()
        val fw = DnsForwarder(listOf(srv.addr), { b, o, l -> tun.add(b.copyOfRange(o, o + l)) }, retryAfterMs = 100, giveUpAfterMs = 350, sweepMs = 40).also { it.start() }
        // Harf farkı gelen her cevap reddedilir: bu sorular cevapsız kalır (sunucu harfleri yansıtmıyor).
        for (i in 1..10) { val p = ipQuery(0x6000 + i, "kapali$i.example"); fw.onPacket(p, p.size); Thread.sleep(60) }
        Thread.sleep(500)
        tun.clear()                                          // zaman aşımı yanıtları (SERVFAIL) artık ilgisiz
        val before = srv.seen.size
        val p = ipQuery(0x6100, "sonraki.example")
        fw.onPacket(p, p.size)
        var rep: ByteArray? = null
        val end = System.nanoTime() + 3_000_000_000L
        while (rep == null && System.nanoTime() < end) {
            val r = tun.poll(100, TimeUnit.MILLISECONDS) ?: continue
            if (Packets.u16(r, 28) == 0x6100) rep = r
        }
        T.check("0x20 kapandıktan sonra sorgu cevaplanır (DNS kesilmez)", rep != null && lastIpOf(rep) == "1.2.3.4")
        val sonra = srv.seen.drop(before)
        T.check("0x20 kapanınca sonraki sorular özgün harflerle gider", sonra.isNotEmpty() && sonra.all { it == it.lowercase() }, sonra.toString().take(200))
        fw.close(); srv.close()
    }
    T.group("Birleşik DPI planı (13) ve QUIC Initial'dan SNI okuma")
    run {
        val hello = QuicVectors.bytes(QuicVectors.HELLO)
        val rec = ByteArray(5 + hello.size)
        rec[0] = 0x16; rec[1] = 3; rec[2] = 1; rec[3] = (hello.size shr 8).toByte(); rec[4] = hello.size.toByte()
        System.arraycopy(hello, 0, rec, 5, hello.size)
        val h = Dpi.Hello()
        Dpi.parseHello(rec, rec.size, h)
        val parts = Dpi.split(Dpi.TLS, 13, rec, rec.size)
        T.check("plan 13: iki parça (ilk kayıt sahte kopyalı, kalan ikinci kayıt)", parts.size == 2 && parts[0].fake != null, "boyut=${parts.size}")
        if (parts.size == 2) {
            val sniEnd = h.sniOff + h.sniLen
            T.check("plan 13: ilk parça SNI'nın sonuna kadar (tam ad içinde)", parts[0].data.size == sniEnd, "boyut=${parts[0].data.size} sniEnd=$sniEnd")
            val real = parts[0].data + parts[1].data
            val r1 = Packets.u16(real, 3)
            T.check("plan 13: gerçek akış geçerli iki TLS kaydı (1. kayıt uzunluğu SNI sonuna dek)", real[0].toInt() == 0x16 && r1 == sniEnd - 5 && real[r1 + 5].toInt() == 0x16)
            val fake = parts[0].fake!!
            val fh = Dpi.Hello()
            T.check("plan 13: sahte kopyada SNI değişti (discord.com değil), boyut aynı",
                Dpi.parseHello(fake, fake.size, fh) && String(fake, fh.sniOff, fh.sniLen) != "discord.com" && fake.size == parts[0].data.size)
        }
        T.check("TLS sırası 13'ü içerir", Dpi.TLS_ORDER.contains(13) && Dpi.TLS_ORDER.size == Dpi.TLS_PLANS)
        val ini = QuicVectors.bytes(QuicVectors.INITIAL)
        T.check("QuicInitial.peekSni: Initial paketinden SNI okunur (discord.com)", QuicInitial.peekSni(ini, 0, ini.size) == "discord.com")
        T.check("QuicInitial.peekSni: bozuk paket null", QuicInitial.peekSni(ByteArray(1200), 0, 1200) == null)
    }
    T.group("Otomatik TTL (HopProbe): ikili arama, TTL seçimi, önbellek")
    run {
        var ok = true
        for (h in 1..32) {
            var calls = 0
            val r = HopProbe.search { ttl -> calls++; if (ttl >= h) 1 else 0 }
            if (r != h || calls > 6) { ok = false; break }
        }
        T.check("her hop sayısı (1..32) en çok 6 denemede bulunur", ok)
        T.check("32'de bile ulaşılamıyorsa -1", HopProbe.search { 0 } == -1)
        T.check("belirsiz deneme (-1) aramayı bırakır", HopProbe.search { ttl -> if (ttl == 32) 1 else -1 } == -1)
        T.check("TTL: 14 hop → 12 (üst sınır), 9 → 8, 4 → 3", HopProbe.ttlFor(14) == 12 && HopProbe.ttlFor(9) == 8 && HopProbe.ttlFor(4) == 3)
        T.check("TTL: sunucu çok yakınsa (≤2 hop) 0 = sahte paket yok; ölçülmemişse -1", HopProbe.ttlFor(2) == 0 && HopProbe.ttlFor(1) == 0 && HopProbe.ttlFor(0) == -1)
        val calls = java.util.concurrent.atomic.AtomicInteger()
        val hp = HopProbe(reach = { _, _, ttl -> calls.incrementAndGet(); if (ttl >= 7) 1 else 0 }, run = { it.run() }, nowMs = { 1000L })
        val ip = byteArrayOf(93.toByte(), 184.toByte(), 216.toByte(), 34)
        T.check("ölçülmeden hops 0", hp.hops(ip) == 0)
        hp.request(ip, 443)
        T.check("ölçüm sonrası hops 7", hp.hops(ip) == 7)
        val before = calls.get()
        hp.request(ip, 443)
        T.check("ölçülmüş hedef yeniden ölçülmez", calls.get() == before)
        var now = 1000L
        val fail = HopProbe(reach = { _, _, _ -> 0 }, run = { it.run() }, nowMs = { now })
        val ip2 = byteArrayOf(1, 2, 3, 4)
        fail.request(ip2, 443)
        T.check("ulaşılamayan hedefte hops 0 kalır", fail.hops(ip2) == 0)
        val c0 = java.util.concurrent.atomic.AtomicInteger()
        val fail2 = HopProbe(reach = { _, _, _ -> c0.incrementAndGet(); 0 }, run = { it.run() }, nowMs = { now })
        fail2.request(ip2, 443); val a = c0.get(); fail2.request(ip2, 443)
        T.check("başarısız ölçüm hemen yinelenmez (10 dk bekleme)", c0.get() == a)
        now += HopProbe.RETRY_MS + 1
        fail2.request(ip2, 443)
        T.check("bekleme dolunca yeniden denenir", c0.get() > a)
    }
    T.group("IP→ad belleği (IpNames): DNS cevabından öğrenme, ortak IP güvenliği")
    run {
        IpNames.clear()
        val engine = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("ads.example.com"))
        val adIp = byteArrayOf(203.toByte(), 0, 113, 10)
        IpNames.learn(replyPacket("ads.example.com", listOf(adIp)).let { it }, 0, replyPacket("ads.example.com", listOf(adIp)).size)
        T.check("A kaydı soru adıyla eşlenir", IpNames.namesOf(adIp) == listOf("ads.example.com"))
        T.check("tüm adlar engelliyse IP engelli", IpNames.blocked(adIp, engine) == "ads.example.com")
        val shared = byteArrayOf(203.toByte(), 0, 113, 20)
        for (nm in listOf("ads.example.com", "guzel.example.org")) { val r = replyPacket(nm, listOf(shared)); IpNames.learn(r, 0, r.size) }
        T.check("ortak IP: temiz bir ad da varsa engellenmez", IpNames.namesOf(shared).size == 2 && IpNames.blocked(shared, engine) == null)
        val sink = replyPacket("ads.example.com", listOf(byteArrayOf(0, 0, 0, 0), byteArrayOf(127, 0, 0, 1), byteArrayOf(192.toByte(), 168.toByte(), 1, 5)))
        val before = IpNames.size()
        IpNames.learn(sink, 0, sink.size)
        T.check("sinkhole ve yerel adresler öğrenilmez", IpNames.size() == before)
        T.check("bilinmeyen IP engellenmez", IpNames.blocked(byteArrayOf(198.toByte(), 51, 100, 1), engine) == null)
        val garbage = ByteArray(80) { (it * 7).toByte() }
        IpNames.learn(garbage, 0, garbage.size)
        IpNames.learn(ByteArray(10), 0, 10)
        val trunc = replyPacket("ads.example.com", listOf(byteArrayOf(5, 6, 7, 8)))
        IpNames.learn(trunc, 0, trunc.size - 2)
        T.check("bozuk/kesik paket hata vermez", true)
        IpNames.clear()
    }

    T.group("TLS parmak izi (JA3): hesap, GREASE, bellek sınırı")
    run {
        val fp = TlsFingerprint.ja3(testHello("a.example.com"), testHello("a.example.com").size)
        T.check("bilinen vektör: 771,4865,0-21,, → MD5", fp == "fefcc846e1acd82a01d51839b7cd96e1", fp ?: "null")
        T.check("farklı SNI aynı parmak izi (ad parmak izine girmez)",
            TlsFingerprint.ja3(testHello("zzz.example.org", 120), testHello("zzz.example.org", 120).size) == fp)

        // el yapımı ClientHello: GREASE şifre/uzantı + eğriler + nokta biçimleri, SNI yok
        fun u16(v: Int) = byteArrayOf((v shr 8).toByte(), v.toByte())
        val groups = u16(10) + u16(8) + u16(6) + u16(0x0A0A) + u16(29) + u16(23)
        val points = u16(11) + u16(2) + byteArrayOf(1, 0)
        val ext = u16(0x1A1A) + u16(0) + groups + points
        val body = byteArrayOf(3, 3) + ByteArray(32) + byteArrayOf(0) + u16(6) + u16(0x2A2A) + u16(0x1301) + u16(0xC02B) + byteArrayOf(1, 0) + u16(ext.size) + ext
        val hs = byteArrayOf(1, 0, (body.size shr 8).toByte(), body.size.toByte()) + body
        val rec = byteArrayOf(0x16, 3, 1) + u16(hs.size) + hs
        T.check("GREASE atılır, eğriler ve nokta biçimleri yazılır",
            TlsFingerprint.ja3String(rec, rec.size) == "771,4865-49195,10-11,29-23,0", TlsFingerprint.ja3String(rec, rec.size) ?: "null")
        T.check("kesik/bozuk girdide çökmez, null döner",
            (0 until rec.size).all { n -> TlsFingerprint.ja3String(rec, n); true } && TlsFingerprint.ja3(rec, 20) == null &&
                TlsFingerprint.ja3(ByteArray(100), 100) == null)
        TlsFingerprint.clear()
        repeat(200) { TlsFingerprint.observe("fp$it") }
        TlsFingerprint.observe("fp199")
        T.check("gözlem belleği sınırlı, sayaç artar", TlsFingerprint.tracked() <= 64 && TlsFingerprint.count("fp199") == 2)
        TlsFingerprint.clear()
        T.check("varsayılan: gözlem açık, engel kümesi boş", GwConfig().ja3 && GwConfig().ja3Deny.isEmpty())
    }
}
