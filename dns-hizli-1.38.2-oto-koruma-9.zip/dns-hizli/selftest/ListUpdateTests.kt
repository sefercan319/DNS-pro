package app.dnshizli.selftest

import app.dnshizli.core.FilterEngine
import app.dnshizli.core.FilterLevel
import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.FilterSource
import app.dnshizli.core.FilterVerdict
import app.dnshizli.core.ListStore
import app.dnshizli.core.ListUpdate
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.spec.ECGenParameterSpec

private fun signWith(kp: KeyPair, data: ByteArray): ByteArray =
    Signature.getInstance("SHA256withECDSA").run { initSign(kp.private); update(data); sign() }

private fun manifestText(version: Long, names: List<String>, bytes: ByteArray): ByteArray {
    val sb = StringBuilder("DNSHIZLI-LISTE 1\n").append("surum=$version\n")
    for (n in names) sb.append("$n ${ListUpdate.sha256Hex(bytes)} ${bytes.size}\n")
    return sb.toString().toByteArray(Charsets.UTF_8)
}

/** Liste güncellemesi: imza, manifest biçimi, özet/boy, sürüm geri dönüşü ve bozuk önbellekte paket yedeği. */
fun runListUpdateTests() {
    val good = KeyPairGenerator.getInstance("EC").run { initialize(ECGenParameterSpec("secp256r1")); generateKeyPair() }
    val other = KeyPairGenerator.getInstance("EC").run { initialize(ECGenParameterSpec("secp256r1")); generateKeyPair() }
    val payload = ByteArray(200_000) { (it * 7).toByte() }
    val all = ListUpdate.UPDATABLE
    val manifest = manifestText(5, all, payload)
    val sig = signWith(good, manifest)

    T.group("Liste güncelleme: imza doğrulama")
    run {
        T.check("doğru anahtar ve imza kabul edilir", ListUpdate.verifySignature(manifest, sig, good.public))
        val tampered = manifest.copyOf().also { it[it.size - 3] = (it[it.size - 3] + 1).toByte() }
        T.check("değiştirilmiş manifest reddedilir", !ListUpdate.verifySignature(tampered, sig, good.public))
        T.check("başka anahtarla imza reddedilir", !ListUpdate.verifySignature(manifest, sig, other.public))
        T.check("bozuk imza reddedilir", !ListUpdate.verifySignature(manifest, ByteArray(70) { 1 }, good.public))
        T.check("açık anahtar boşsa (güncelleme kapalı) anahtar üretilmez", ListUpdate.publicKey(ByteArray(0)) == null)
        T.check("bozuk açık anahtar reddedilir", ListUpdate.publicKey(ByteArray(40) { 3 }) == null)
    }

    T.group("Liste güncelleme: manifest biçimi")
    run {
        val m = ListUpdate.parse(manifest)
        T.check("geçerli manifest okunur (3 liste, sürüm 5)", m != null && m.entries.size == 3 && m.version == 5L)
        T.check("biçim satırı yanlışsa reddedilir", ListUpdate.parse("YANLIS\n".toByteArray()) == null)
        T.check("boş manifest reddedilir", ListUpdate.parse(ByteArray(0)) == null)
        T.check("eksik liste reddedilir", ListUpdate.parse(manifestText(5, all.take(2), payload)) == null)
        T.check("bilinmeyen dosya (psl.txt) reddedilir", ListUpdate.parse(manifestText(5, all + "psl.txt", payload)) == null)
        T.check("korunan liste (protected.txt) güncellenebilir listede değil", "protected.txt" !in ListUpdate.UPDATABLE)
        T.check("sürüm 0 reddedilir", ListUpdate.parse(manifestText(0, all, payload)) == null)
        val badHash = "DNSHIZLI-LISTE 1\nsurum=5\n" + all.joinToString("") { "$it ${"z".repeat(64)} 10\n" }
        T.check("geçersiz özet biçimi reddedilir", ListUpdate.parse(badHash.toByteArray()) == null)
        val huge = "DNSHIZLI-LISTE 1\nsurum=5\n" + all.joinToString("") { "$it ${"a".repeat(64)} ${ListUpdate.MAX_FILE + 1}\n" }
        T.check("sınırı aşan boy reddedilir", ListUpdate.parse(huge.toByteArray()) == null)
        val dup = "DNSHIZLI-LISTE 1\nsurum=5\n" + "basic.bin ${"a".repeat(64)} 10\n".repeat(2) + "medium.bin ${"a".repeat(64)} 10\nstrict.bin ${"a".repeat(64)} 10\n"
        T.check("yinelenen liste girdisi reddedilir", ListUpdate.parse(dup.toByteArray()) == null)
        val tiny = "DNSHIZLI-LISTE 1\nsurum=5\n" + all.joinToString("") { "$it ${"a".repeat(64)} 10\n" }
        T.check("boş/küçük liste yayını reddedilir (tüm kullanıcılarda engellemeyi kapatmasın)", ListUpdate.parse(tiny.toByteArray()) == null)
        T.check("çok büyük manifest reddedilir", ListUpdate.parse(ByteArray(ListUpdate.MAX_MANIFEST + 1) { 65 }) == null)
    }

    T.group("Liste güncelleme: dosya özeti ve sürüm geri dönüşü")
    run {
        val e = ListUpdate.parse(manifest)!!.entries[0]
        val e2 = ListUpdate.Entry(e.name, e.sha256, e.bytes)
        T.check("özeti ve boyu tutan dosya kabul edilir", ListUpdate.matches(payload, e2))
        val flipped = payload.copyOf().also { it[500] = (it[500] + 1).toByte() }
        T.check("tek bayt değişen dosya reddedilir", !ListUpdate.matches(flipped, e2))
        T.check("kısa dosya reddedilir", !ListUpdate.matches(payload.copyOf(999), e2))
        val m5 = ListUpdate.parse(manifest)!!
        T.check("kurulu sürümden yeni manifest kabul edilir", ListUpdate.isNewer(4, m5))
        T.check("aynı sürüm yeniden uygulanmaz", !ListUpdate.isNewer(5, m5))
        T.check("eski imzalı sürüme geri dönüş (rollback) reddedilir", !ListUpdate.isNewer(6, m5))
    }

    T.group("Liste güncelleme: bozuk önbellekte paket yedeği (motor)")
    run {
        val assets = File("app/src/main/assets/filter")
        val packaged = FilterSource { name -> File(assets, name).inputStream() }
        // Önbellekteki basic.bin bozuk (rastgele bayt): okuma başarısız olmalı, ama motor tüm engellemeyi kaybetmemeli.
        val corrupt = FilterSource { name ->
            if (name == "basic.bin") ByteArrayInputStream(ByteArray(64) { 9 }) else File(assets, name).inputStream()
        }
        val probes = listOf("doubleclick.net", "googlesyndication.com", "adnxs.com", "criteo.com")
        try {
            FilterRuntime.fallbackSource = packaged
            FilterRuntime.source = packaged
            FilterRuntime.updateNow(FilterLevel.BASIC, emptyList(), emptyList())
            val healthy = probes.map { FilterRuntime.engine!!.verdictOf(it) }

            FilterRuntime.source = corrupt
            FilterRuntime.reloadListsNow()
            val recovered = probes.map { FilterRuntime.engine!!.verdictOf(it) }
            T.check("bozuk önbellek varken paketteki listeyle aynı kararlar verilir", recovered == healthy, "$recovered / $healthy")
            T.check("bozuk önbellek varken en az bir reklam alan adı hâlâ engellenir",
                recovered.any { it == FilterVerdict.LIST })

            FilterRuntime.fallbackSource = null
            FilterRuntime.source = corrupt
            FilterRuntime.reloadListsNow()
            val noFallback = FilterRuntime.engine!!.verdictOf("doubleclick.net")
            T.check("yedek yoksa bozuk liste hiçbir şeyi engellemez (güvenli başarısızlık, çökme yok)", noFallback == FilterVerdict.PASS)
        } finally {
            FilterRuntime.fallbackSource = null
            FilterRuntime.source = packaged
            FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), emptyList())
        }
    }
}

/** Liste dosyalarının güvenli yerine konması ([ListStore]): kesinti noktaları, yol geçişi, önbellek sürüm kuralı (v1.29). */
fun runListStoreTests() {
    T.group("Liste güncellemesi: güvenli yerine koyma (ListStore)")
    fun tmp(): File = java.nio.file.Files.createTempDirectory("liste-test").toFile()
    fun set(tag: Byte) = ListUpdate.UPDATABLE.associateWith { ByteArray(1000) { tag } }
    fun readTag(root: File, name: String): Int? = File(ListStore.dir(root), name).takeIf { it.isFile }?.readBytes()?.firstOrNull()?.toInt()
    fun tags(root: File) = ListUpdate.UPDATABLE.map { readTag(root, it) }.toSet()

    val a = tmp()
    T.check("ilk kurulum: üç dosya yerinde, geçici dizin kalmaz", ListStore.install(a, set(1)) && tags(a) == setOf(1) &&
        !File(a, ListStore.STAGE).exists() && !File(a, ListStore.BACKUP).exists())
    T.check("güncelleme: hepsi yeni sürüme geçer, yedek silinir", ListStore.install(a, set(2)) && tags(a) == setOf(2) && !File(a, ListStore.BACKUP).exists())

    // yol geçişi / geçersiz küme: hiçbir şey değişmez
    T.check("yol geçişi içeren ad reddedilir, kurulu liste korunur", !ListStore.install(a, mapOf("../kacis.bin" to ByteArray(10))) && tags(a) == setOf(2) && !File(a.parentFile, "kacis.bin").exists())
    T.check("bilinmeyen ad ve boş küme reddedilir", !ListStore.install(a, mapOf("psl.txt" to ByteArray(10))) && !ListStore.install(a, emptyMap()) && tags(a) == setOf(2))

    // kesinti: adım 2 ile 3 arasında (kurulu dizin yok, yedek ve yarım yeni var) → eski geri gelir
    val b = tmp()
    ListStore.install(b, set(5))
    File(b, ListStore.DIR).renameTo(File(b, ListStore.BACKUP))
    File(b, ListStore.STAGE).mkdirs(); File(File(b, ListStore.STAGE), "basic.bin").writeBytes(ByteArray(10) { 9 })
    ListStore.recover(b)
    T.check("adım 2-3 arası kesinti: eski sürüm geri gelir, yarım yeni silinir", tags(b) == setOf(5) && !File(b, ListStore.STAGE).exists() && !File(b, ListStore.BACKUP).exists())

    // kesinti: adım 3'ten sonra (yeni yerinde, yedek artığı var) → yeni kalır, yedek silinir
    val c = tmp()
    ListStore.install(c, set(6))
    File(File(c, ListStore.DIR).path).renameTo(File(c, "gecici"))
    File(c, ListStore.BACKUP).mkdirs(); File(File(c, ListStore.BACKUP), "basic.bin").writeBytes(ByteArray(10) { 1 })
    File(c, "gecici").renameTo(File(c, ListStore.DIR))
    ListStore.recover(c)
    T.check("adım 3 sonrası kesinti: yeni sürüm kalır, yedek artığı silinir", tags(c) == setOf(6) && !File(c, ListStore.BACKUP).exists())

    // kesinti: yarım yazılmış yeni dizin, kurulu liste sağlam → kurulu kalır
    val d = tmp()
    ListStore.install(d, set(7))
    File(d, ListStore.STAGE).mkdirs(); File(File(d, ListStore.STAGE), "basic.bin").writeBytes(ByteArray(3))
    ListStore.recover(d)
    T.check("yarım yazılmış yeni dizin silinir, kurulu liste dokunulmaz", tags(d) == setOf(7) && !File(d, ListStore.STAGE).exists())

    // yazma başarısız: hazırlık dizini bir DOSYA ise oluşturulamaz → false, kurulu liste korunur
    val e = tmp()
    ListStore.install(e, set(8))
    File(e, ListStore.STAGE).writeBytes(ByteArray(1))
    val ok = ListStore.install(e, set(9))
    // recover() hazırlık yolundaki dosyayı da temizler; başarılı olması da, başarısız olup eskiyi korumak da kabul: karışık olmamalı
    T.check("engelli hazırlık yolu: ya tam yeni ya tam eski, asla karışık değil", (ok && tags(e) == setOf(9)) || (!ok && tags(e) == setOf(8)))

    // var olmayan kök
    val f = File(tmp(), "alt/dizin")
    T.check("var olmayan kök dizini oluşturulur", ListStore.install(f, set(3)) && tags(f) == setOf(3))
    T.check("kurulu dizin yokken recover zararsız", run { ListStore.recover(File(tmp(), "yok")); true })

    // önbellek yalnızca aynı uygulama sürümüyle kullanılır
    T.check("önbellek: aynı sürümde kullanılır", ListStore.cacheUsable(45, 45))
    T.check("önbellek: uygulama güncellenince yok sayılır", !ListStore.cacheUsable(45, 46) && !ListStore.cacheUsable(46, 45))
    T.check("önbellek: hiç kaydedilmemişse (0) ya da geçersiz sürümde yok sayılır", !ListStore.cacheUsable(0, 45) && !ListStore.cacheUsable(0, 0) && !ListStore.cacheUsable(-1, -1))
    listOf(a, b, c, d, e, f.parentFile.parentFile).forEach { it.deleteRecursively() }
}
