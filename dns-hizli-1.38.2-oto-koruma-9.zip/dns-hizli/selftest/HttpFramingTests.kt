package app.dnshizli.selftest

import app.dnshizli.core.MiniHttps
import java.io.ByteArrayInputStream

/** HTTP çerçeveleme sertliği (ODoH yapılandırma/cevap alıcısı): bozuk ya da çelişen uzunluk ve çakışan çerçeveleme reddedilir. */
fun runHttpFramingTests() {
    fun resp(head: String, body: String = ""): Result<ByteArray> =
        runCatching { MiniHttps.readResponse(ByteArrayInputStream((head + body).toByteArray(Charsets.ISO_8859_1)), 10_000L, { 0L }) {} }

    T.group("HTTP çerçeveleme: içerik uzunluğu ve çakışmalar")
    run {
        val ok = resp("HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\n", "hello")
        T.check("geçerli içerik uzunluğu okunur", ok.getOrNull()?.toString(Charsets.ISO_8859_1) == "hello")

        val same = resp("HTTP/1.1 200 OK\r\nContent-Length: 5\r\nContent-Length: 5\r\n\r\n", "hello")
        T.check("aynı değerde iki içerik uzunluğu kabul edilir", same.getOrNull()?.toString(Charsets.ISO_8859_1) == "hello")

        val diff = resp("HTTP/1.1 200 OK\r\nContent-Length: 5\r\nContent-Length: 7\r\n\r\n", "hellooo")
        T.check("çelişen iki içerik uzunluğu reddedilir", diff.isFailure)

        val bad = resp("HTTP/1.1 200 OK\r\nContent-Length: abc\r\n\r\nhello")
        T.check("bozuk içerik uzunluğu sessizce 'kapanana kadar oku'ya düşmez (reddedilir)", bad.isFailure)

        val neg = resp("HTTP/1.1 200 OK\r\nContent-Length: -5\r\n\r\nhello")
        T.check("negatif içerik uzunluğu reddedilir", neg.isFailure)

        val plus = resp("HTTP/1.1 200 OK\r\nContent-Length: +5\r\n\r\nhello")
        T.check("işaretli içerik uzunluğu reddedilir", plus.isFailure)
    }

    T.group("HTTP çerçeveleme: Transfer-Encoding ile Content-Length çakışması")
    run {
        val both = resp("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nContent-Length: 5\r\n\r\n5\r\nhello\r\n0\r\n\r\n")
        T.check("chunked + Content-Length birlikte reddedilir", both.isFailure)

        val chunk = resp("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n5\r\nhello\r\n0\r\n\r\n")
        T.check("yalnız chunked gövde okunur", chunk.getOrNull()?.toString(Charsets.ISO_8859_1) == "hello")
    }

    T.group("HTTP çerçeveleme: durum kodu")
    run {
        val nf = resp("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n")
        T.check("404 hâlâ HttpStatusException (yeniden denenmez sınıfı)", (nf.exceptionOrNull() as? MiniHttps.HttpStatusException)?.code == 404)
    }
}
