package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException

/**
 * Reklam / izleyici / zararlı alan adı engelleme: özet uyumu (Python aracıyla), ad düzenleme, liste dosyaları,
 * seviyeler ve öncelik, cevap üretimi, sarmalayıcı yönlendirici, ayarlar.
 */

private val assets = File("app/src/main/assets/filter")
private val fileSource = FilterSource { name -> File(assets, name).inputStream() }

private fun loadEngine(level: FilterLevel, allow: List<String> = emptyList(), block: List<String> = emptyList()): FilterEngine {
    FilterRuntime.source = fileSource
    FilterRuntime.reset()
    FilterRuntime.updateNow(level, allow, block)
    return FilterRuntime.engine!!
}

/** Alan adından DNS sorgusu (A) ve tür değiştirme. */
private fun dnsQuery(name: String, qtype: Int = 1, id: Int = 0x1234): ByteArray {
    val q = Dns.buildQuery(id, name)
    Packets.put16(q, q.size - 4, qtype)
    return q
}

private fun v4Pkt(dns: ByteArray, srcPort: Int = 40001): ByteArray {
    val b = ByteArray(Packets.HDR + dns.size)
    System.arraycopy(dns, 0, b, Packets.HDR, dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size); Packets.put16(b, 6, 0x4000); b[8] = 64; b[9] = 17
    Packets.put32(b, 12, Packets.ip(10, 111, 222, 1)); Packets.put32(b, 16, Packets.ip(10, 111, 222, 2))
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, srcPort); Packets.put16(b, 22, 53); Packets.put16(b, 24, 8 + dns.size)
    return b
}

private fun v6Pkt(dns: ByteArray, srcPort: Int = 40002): ByteArray {
    val b = ByteArray(Packets.HDR6 + dns.size)
    System.arraycopy(dns, 0, b, Packets.HDR6, dns.size)
    Packets.writeHeaders6(b, Ip.parse6(SelfTest.CLIENT_ADDR6)!!, Ip.parse6(SelfTest.FAKE_DNS6)!!, srcPort, 53, dns.size)
    return b
}

private class FakeInner : Forwarder {
    var got = 0
    override val proto: Proto get() = Proto.PLAIN
    override fun start() {}
    override fun onPacket(p: ByteArray, len: Int) { got++ }
    override fun stats() = Stats(queries = got.toLong(), forwarded = got.toLong())
    override fun resetNetwork(reason: String) {}
    override fun clearCache() {}
    override fun close() {}
}

fun runFilterTests() {
    println("\nEngelleme (reklam, izleyici, zararlı)\n")
    testFilterHash()
    testFilterNames()
    testFilterFiles()
    testFilterLevels()
    testFilterPriority()
    testImportedVsProtected()
    testFilterReply()
    testFilterMalformed()
    testFilterFailClosed()
    testFilterForwarder()
    testFilterSettings()
    testFilterLive()
    testFilterUi()
    testFilterStrings()
}

private fun testFilterHash() {
    T.group("Engelleme: özet (Python aracıyla birebir)")
    // tools/build_filter.py ile hesaplanmış değerler
    T.check("doubleclick.net", FilterHash.hash("doubleclick.net") == 120233630452136L)
    T.check("example.com", FilterHash.hash("example.com") == 248243948190391L)
    T.check("a.b.c", FilterHash.hash("a.b.c") == 204046079641942L)
    T.check("www.google.com", FilterHash.hash("www.google.com") == 153964743827592L)
    T.check("özet 48 bite sığar ve eksi değildir", listOf("x.y", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.com", "a-b.c-d.e").all { FilterHash.hash(it) in 0L..0xFFFFFFFFFFFFL })
}

private fun testFilterNames() {
    T.group("Engelleme: alan adı düzenleme")
    val ok = mapOf(
        "Example.COM" to "example.com", " https://www.Ornek.com/yol?x=1#a " to "www.ornek.com", "*.ornek.com" to "ornek.com",
        ".ornek.com." to "ornek.com", "http://user:pw@a.b.com:8080/x" to "a.b.com", "ads_1.example-site.co" to "ads_1.example-site.co",
        "xn--80ak6aa92e.com" to "xn--80ak6aa92e.com",
    )
    for ((i, o) in ok) T.check("'$i' -> '$o'", FilterNames.normalize(i) == o, FilterNames.normalize(i).toString())
    val bad = listOf("", " ", "localhost", "com", "1.2.3.4", "999.1.1.1", "[::1]", "a..b.com", "-a.com", "a-.com", "a b.com", "x".repeat(64) + ".com")
    for (b in bad) T.check("geçersiz: '${b.take(20)}'", FilterNames.normalize(b) == null, FilterNames.normalize(b).toString())
    T.check("decode: yinelenenler ve geçersizler ayıklanır", FilterNames.decode("a.com, A.com,xx,b.com,,1.1.1.1") == listOf("a.com", "b.com"))
    T.check("encode/decode gidiş-dönüş", FilterNames.decode(FilterNames.encode(listOf("A.com", "b.org"))) == listOf("a.com", "b.org"))
    T.check("liste sınırı", FilterNames.decode((1..500).joinToString(",") { "s$it.com" }).size == FilterNames.MAX_LIST)
}

/** Sıkı (kovalı) katman ile düz dizinin cevapları birebir aynı olmalı: gerçek listede, sınır değerlerde ve rastgele özetlerde. */
private fun testCompactTier() {
    T.group("Engelleme: sıkı katman (kova dizini) doğruluğu")
    val real = FilterTier.read(File(assets, "basic.bin").inputStream().buffered())
    val hs = real.hashes
    T.check("büyük katman sıkı biçimde: ad başına ~4 bayt", real.bytes < real.size * 5L, "bayt=${real.bytes} ad=${real.size}")
    T.check("geri açılan özetler sıralı ve dosyadakilerle aynı sayıda", hs.size == real.size && (1 until hs.size).all { hs[it] > hs[it - 1] })
    T.check("listedeki her özet bulunur", hs.all { real.contains(it) })
    val set = java.util.HashSet<Long>(hs.size * 2); for (h in hs) set.add(h)
    val rnd = java.util.Random(11)
    var wrong = 0
    repeat(400_000) {
        val h = rnd.nextLong() and 0xFFFFFFFFFFFFL
        if (real.contains(h) != set.contains(h)) wrong++
    }
    T.check("rastgele 400 bin özette yanlış cevap yok", wrong == 0, "yanlış=$wrong")
    var near = 0
    for (h in hs.copyOfRange(0, 50_000)) for (d in longArrayOf(-1, 1, 1L shl 32, -(1L shl 32))) { val x = h + d; if (x in 0..0xFFFFFFFFFFFFL && real.contains(x) != set.contains(x)) near++ }
    T.check("komşu özetlerde (±1, kova sınırları) yanlış cevap yok", near == 0, "yanlış=$near")
    T.check("48 biti aşan ve negatif değerler bulunmaz", !real.contains(1L shl 48) && !real.contains(-1L) && !real.contains(Long.MIN_VALUE))
    // Uç değerler: kovanın ilk/son öğesi, en küçük ve en büyük özet, işaret biti ayarlı alt yarı.
    val edge = longArrayOf(0L, 1L, 0x7FFFFFFFL, 0x80000000L, 0xFFFFFFFFL, 0x1_0000_0000L, 0xFFFF_0000_0000L, 0xFFFF_FFFF_FFFFL)
    val big = (edge + LongArray(120_000) { (it.toLong() * 2_345_624_805L) and 0xFFFFFFFFFFFFL }).distinct().sorted().toLongArray()
    val t = FilterTier(big)
    T.check("uç değerler: sıkı katman tümünü bulur", big.all { t.contains(it) } && t.bytes < big.size * 8L)
    T.check("uç değerler: komşular bulunmaz", edge.filter { it + 1 !in big }.all { !t.contains(it + 1) || it + 1 > 0xFFFFFFFFFFFFL })
    T.check("küçük katman düz dizide kalır ve aynı cevabı verir", FilterTier(longArrayOf(5, 9, 77)).let { it.contains(9) && !it.contains(8) && it.bytes == 24L })
    // Ön eleme bitleri olan motor (büyük listeler) ile olmayan motor (aynı adlar küçük parçalar halinde) aynı kararı vermeli.
    val listed = (0 until 120_000).map { "ad$it.izci${it % 977}.example" }
    val bigTier = FilterTier(listed.map { FilterHash.hash(it) }.distinct().sorted().toLongArray())
    val withPre = FilterEngine(listOf(bigTier), FilterTier.EMPTY, emptyList(), emptyList())
    val parts = listed.chunked(30_000).map { ch -> FilterTier(ch.map { FilterHash.hash(it) }.distinct().sorted().toLongArray()) }
    val noPre = FilterEngine(parts.take(1), FilterTier.EMPTY, emptyList(), emptyList())
    val probe = listed.filterIndexed { i, _ -> i % 37 == 0 }.flatMap { listOf(it, "alt.$it", it.substringAfter('.')) } +
        (0 until 20_000).map { "x$it.temiz${it % 50}.org" }
    var diff = 0
    val pos = HashMap<String, Int>(listed.size * 2).also { m -> listed.forEachIndexed { i, n -> m[n] = i } }
    for (n in probe) {
        val base = if (n.startsWith("alt.")) n.removePrefix("alt.") else n
        val at = pos[n] ?: pos[base] ?: -1
        val inFirst = at in 0 until 30_000
        val a = withPre.verdictOf(n)
        val expectBig = if (at >= 0) FilterVerdict.LIST else FilterVerdict.PASS
        if (a != expectBig) diff++
        if (inFirst && noPre.verdictOf(n) != FilterVerdict.LIST) diff++
    }
    T.check("ön elemeli motor, listedeki adları ve alt adlarını bulur, diğerlerini geçirir", diff == 0, "fark=$diff")

    val corrupt = ByteArray(8 + 8).also { b -> "DNF1".forEachIndexed { i, c -> b[i] = c.code.toByte() }; b[7] = 1; for (k in 8 until 15) b[k] = 0xFF.toByte(); b[15] = 0x7F }
    T.check("48 biti aşan özet içeren dosya reddedilir", try { FilterTier.read(ByteArrayInputStream(corrupt)); false } catch (_: IOException) { true })
}

private fun testFilterFiles() {
    testCompactTier()
    T.group("Engelleme: liste dosyaları")
    T.check("dosyalar var", listOf("basic.bin", "medium.bin", "strict.bin", "protected.txt", "KAYNAKLAR.txt").all { File(assets, it).isFile })
    val tiers = listOf("basic.bin", "medium.bin", "strict.bin").map { FilterTier.read(File(assets, it).inputStream()) }
    T.check("Basit en az 200 bin, Orta ve Sıkı en az 50 bin alan adı", tiers[0].size >= 200_000 && tiers[1].size >= 50_000 && tiers[2].size >= 100_000, tiers.map { it.size }.toString())
    for ((i, t) in tiers.withIndex()) {
        var sorted = true
        val hs = t.hashes
        for (k in 1 until t.size) if (hs[k] <= hs[k - 1]) { sorted = false; break }
        T.check("katman $i sıralı ve tekrarsız", sorted)
    }
    val all = HashSet<Long>()
    var dup = 0
    for (t in tiers) for (h in t.hashes) if (!all.add(h)) dup++
    T.check("katmanlar birbirini yinelemez", dup == 0, "yinelenen=$dup")
    val raw = File(assets, "basic.bin").readBytes()
    fun bad(b: ByteArray): Boolean = try { FilterTier.read(ByteArrayInputStream(b)); false } catch (_: IOException) { true }
    T.check("kesik dosya reddedilir", bad(raw.copyOf(raw.size - 3)))
    T.check("bozuk başlık reddedilir", bad(raw.copyOf().also { it[0] = 'X'.code.toByte() }))
    T.check("fazlalık reddedilir", bad(raw + byteArrayOf(1, 2)))
    T.check("çok büyük sayı reddedilir", bad(byteArrayOf(68, 78, 70, 49, 0x7F, 0, 0, 0)))
    T.check("boş dosya reddedilir", bad(ByteArray(0)))
    val notes = File(assets, "KAYNAKLAR.txt").readText()
    T.check("kaynak ve lisans bildirimi var", notes.contains("StevenBlack") && notes.contains("blocklistproject") && notes.contains("MIT"))
}

private val POPULAR = ("google.com www.google.com gstatic.com googleapis.com youtube.com ytimg.com googlevideo.com gmail.com microsoft.com live.com " +
    "office.com windowsupdate.com apple.com icloud.com facebook.com instagram.com whatsapp.com whatsapp.net fbcdn.net twitter.com x.com t.co " +
    "tiktok.com amazon.com amazonaws.com cloudfront.net github.com githubusercontent.com cloudflare.com akamai.net fastly.net netflix.com " +
    "spotify.com wikipedia.org reddit.com yandex.com trendyol.com hepsiburada.com n11.com sahibinden.com turkcell.com.tr vodafone.com.tr " +
    "turktelekom.com.tr e-devlet.gov.tr turkiye.gov.tr garantibbva.com.tr isbank.com.tr ziraatbank.com.tr akbank.com yapikredi.com.tr " +
    "paypal.com stripe.com zoom.us discord.com telegram.org signal.org play.google.com android.com connectivitycheck.gstatic.com " +
    "captive.apple.com www.msftconnecttest.com firefox.com mozilla.org twimg.com linkedin.com pinterest.com ebay.com steampowered.com " +
    "epicgames.com outlook.com onedrive.com dropbox.com bing.com duckduckgo.com openai.com anthropic.com claude.ai github.io " +
    "dns.google one.one.one.one dns.quad9.net example.com example.org").split(' ')

private fun testFilterLevels() {
    T.group("Engelleme: seviyeler")
    val off = loadEngine(FilterLevel.OFF)
    val basic = loadEngine(FilterLevel.BASIC)
    val medium = loadEngine(FilterLevel.MEDIUM)
    val strict = loadEngine(FilterLevel.STRICT)
    T.check("Kapalı: hiçbir şey engellenmez", listOf("doubleclick.net", "googlesyndication.com").all { off.verdictOf(it) == FilterVerdict.PASS })
    val ads = listOf("doubleclick.net", "googlesyndication.com", "pagead2.googlesyndication.com", "adnxs.com", "ads.yahoo.com", "taboola.com", "criteo.com", "ads.tiktok.com")
    T.check("Basit: bilinen reklam alan adları engellenir", ads.all { basic.verdictOf(it) == FilterVerdict.LIST }, ads.filter { basic.verdictOf(it) != FilterVerdict.LIST }.toString())
    T.check("alt alan adı üst alan adı girdisiyle engellenir", basic.verdictOf("x.y.z.doubleclick.net") == FilterVerdict.LIST)
    T.check("benzer ad engellenmez (son ek eşleşmesi etiket sınırında)", basic.verdictOf("notdoubleclick.net") == FilterVerdict.PASS && basic.verdictOf("doubleclick.net.example.org") == FilterVerdict.PASS)
    T.check("büyük/küçük harf fark etmez", basic.verdictOf("DoubleClick.NET") == FilterVerdict.LIST)
    T.check("Orta: Basit'in hepsi ve fazlası", ads.all { medium.verdictOf(it) == FilterVerdict.LIST } && medium.verdictOf("sentry.io") == FilterVerdict.LIST)
    T.check("Basit, Orta'ya özgü adı engellemez", basic.verdictOf("sentry.io") == FilterVerdict.PASS)
    T.check("Sıkı: Orta'nın hepsini engeller", ads.all { strict.verdictOf(it) == FilterVerdict.LIST } && strict.verdictOf("sentry.io") == FilterVerdict.LIST)
    // Sıkı'ya özgü bir alan adı bulunabildi mi? (liste güncellenince değişebilir: katmanlar arası fark en az 1 gerçek ad)
    val strictOnly = FilterTier.read(File(assets, "strict.bin").inputStream())
    T.check("Sıkı katmanı Orta'dan ayrı bir küme", strictOnly.size > 0 && strictOnly.size != FilterTier.read(File(assets, "medium.bin").inputStream()).size)
    for ((lvl, e) in listOf("Basit" to basic, "Orta" to medium, "Sıkı" to strict)) {
        // Şifreli DNS sağlayıcı adları (dns.google…) "tarayıcının DNS atlatmasını engelle" ayarıyla bilerek engellenir.
        val hit = POPULAR.filter { e.verdictOf(it) != FilterVerdict.PASS && !Dpi.isDohHost(it) }
        T.check("$lvl: tanınmış ${POPULAR.size} site engellenmez", hit.isEmpty(), hit.toString())
    }
    T.check("tarayıcı DNS atlatma koruması: şifreli DNS sağlayıcı adları engellenir",
        listOf("dns.google", "chrome.cloudflare-dns.com", "mozilla.cloudflare-dns.com", "dns.quad9.net", "doh.opendns.com", "dns.nextdns.io").all { basic.verdictOf(it) == FilterVerdict.LIST })
    FilterRuntime.setDohGuard(false)
    val noGuard = loadEngine(FilterLevel.BASIC)
    T.check("koruma kapatılınca sağlayıcı adları geçer", listOf("dns.google", "chrome.cloudflare-dns.com", "dns.quad9.net").all { noGuard.verdictOf(it) == FilterVerdict.PASS })
    T.check("kullanıcı izin listesi korumadan önce gelir", run { FilterRuntime.setDohGuard(true); loadEngine(FilterLevel.BASIC, allow = listOf("dns.google")).verdictOf("dns.google") == FilterVerdict.PASS })
    T.check("Kapalı seviyede sağlayıcı adları engellenmez", loadEngine(FilterLevel.OFF).verdictOf("dns.google") == FilterVerdict.PASS)
    T.check("tek etiketli ad engellenmez", strict.verdictOf("localhost") == FilterVerdict.PASS && strict.verdictOf("com") == FilterVerdict.PASS)
    T.check("verdictOf geçersiz girdide geçirir", strict.verdictOf("") == FilterVerdict.PASS && strict.verdictOf("1.2.3.4") == FilterVerdict.PASS)
}

private fun testFilterPriority() {
    T.group("Engelleme: öncelik (izin > kullanıcı engeli > korunan > liste)")
    val e0 = loadEngine(FilterLevel.BASIC)
    T.check("ön koşul: doubleclick.net engelli", e0.verdictOf("doubleclick.net") == FilterVerdict.LIST)
    val a = loadEngine(FilterLevel.STRICT, allow = listOf("doubleclick.net"))
    T.check("izin listesi liste engelini kaldırır (alt alan adları dahil)", a.verdictOf("doubleclick.net") == FilterVerdict.PASS && a.verdictOf("stats.g.doubleclick.net") == FilterVerdict.PASS)
    val a2 = loadEngine(FilterLevel.BASIC, allow = listOf("stats.g.doubleclick.net"))
    T.check("alt alan adı izni yalnızca o ada uygulanır", a2.verdictOf("stats.g.doubleclick.net") == FilterVerdict.PASS && a2.verdictOf("doubleclick.net") == FilterVerdict.LIST)
    val b = loadEngine(FilterLevel.OFF, block = listOf("ornek-site.com"))
    T.check("kullanıcı engeli seviye kapalıyken de çalışır", b.verdictOf("ornek-site.com") == FilterVerdict.USER && b.verdictOf("a.ornek-site.com") == FilterVerdict.USER)
    T.check("kullanıcı engeli başka adı etkilemez", b.verdictOf("ornek-site.org") == FilterVerdict.PASS)
    val c = loadEngine(FilterLevel.BASIC, allow = listOf("x.com"), block = listOf("x.com"))
    T.check("izin, kullanıcı engelinden güçlüdür", c.verdictOf("x.com") == FilterVerdict.PASS)
    val d = loadEngine(FilterLevel.OFF, block = listOf("garantibbva.com.tr", "gov.tr", "connectivitycheck.gstatic.com"))
    T.check("kullanıcının açık engeli korunan adlardan güçlüdür", d.verdictOf("garantibbva.com.tr") == FilterVerdict.USER)
    val p = loadEngine(FilterLevel.STRICT)
    val prot = File(assets, "protected.txt").readLines().map { it.substringBefore('#').trim() }.filter { it.isNotEmpty() }
    T.check("korunan adlar ve alt alan adları her seviyede geçer (${prot.size} girdi)", prot.all { p.verdictOf(it) == FilterVerdict.PASS && p.verdictOf("x.$it") == FilterVerdict.PASS })
    T.check("korunan liste yeterince geniş", prot.size >= 40 && "gov.tr" in prot && "connectivitycheck.gstatic.com" in prot)
    val big = loadEngine(FilterLevel.STRICT, allow = (1..FilterNames.MAX_LIST).map { "a$it.com" })
    T.check("200 izinli adla da çalışır", big.verdictOf("a77.com") == FilterVerdict.PASS && big.verdictOf("doubleclick.net") == FilterVerdict.LIST)
}

private fun testImportedVsProtected() {
    T.group("Engelleme: içe aktarılan liste korunan adları engelleyemez")
    FilterRuntime.source = fileSource
    FilterRuntime.reset()
    FilterRuntime.setImported(listOf("connectivitycheck.gstatic.com", "x.garantibbva.com.tr", "benim-reklam.example.com", "time.android.com"))
    FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), listOf("elle-ekledigim.example.com", "time.cloudflare.com"))
    val e = FilterRuntime.engine!!
    T.check("içe aktarılan listedeki korunan adlar (ve alt alanları) geçer", e.verdictOf("connectivitycheck.gstatic.com") == FilterVerdict.PASS && e.verdictOf("x.garantibbva.com.tr") == FilterVerdict.PASS && e.verdictOf("time.android.com") == FilterVerdict.PASS)
    T.check("içe aktarılan listedeki sıradan ad engellenir", e.verdictOf("benim-reklam.example.com") == FilterVerdict.USER)
    T.check("elle eklenen engel korunan adı da engeller (açık tercih)", e.verdictOf("time.cloudflare.com") == FilterVerdict.USER && e.verdictOf("elle-ekledigim.example.com") == FilterVerdict.USER)
    FilterRuntime.reset()
}

private fun testFilterReply() {
    T.group("Engelleme: cevap üretimi")
    val e = loadEngine(FilterLevel.BASIC)
    val out = ByteArray(600)
    fun reply(name: String, qtype: Int): Pair<Int, ByteArray> {
        val q = dnsQuery(name, qtype, 0xBEEF)
        val qEnd = Dns.questionEnd(q, 0, q.size)
        val n = FilterEngine.buildBlocked(q, 0, qEnd, out, 10)
        return n to (if (n > 0) out.copyOfRange(10, 10 + n) else ByteArray(0))
    }
    val (na, ra) = reply("doubleclick.net", 1)
    val qA = dnsQuery("doubleclick.net", 1, 0xBEEF).size
    if (FilterEngine.NXDOMAIN_FOR_BLOCKED) {
        T.check("A: kimlik, QR/RD/RA, RCODE=3 (NXDOMAIN), soru 1, cevap 0, yetki 1", na == qA + 33 && Packets.u16(ra, 0) == 0xBEEF && Packets.u16(ra, 2) == 0x8183 && Packets.u16(ra, 4) == 1 && Packets.u16(ra, 6) == 0 && Packets.u16(ra, 8) == 1, "n=$na ${Packets.u16(ra, 2)}")
    } else {
        T.check("A: kimlik, QR/RD/RA, soru 1, cevap 1 (0.0.0.0)", na == qA + 16 && Packets.u16(ra, 0) == 0xBEEF && Packets.u16(ra, 2) == 0x8180 && Packets.u16(ra, 4) == 1 && Packets.u16(ra, 6) == 1, "n=$na ${Packets.u16(ra, 2)}")
    }
    T.check("A: engelleme cevabı olarak tanınır", Dns.isLocalBlock(ra, 0, ra.size))
    val q = dnsQuery("doubleclick.net", 1, 0xBEEF)
    T.check("soru bölümü aynen korunur", Dns.sameQuestion(q, 0, Dns.questionEnd(q, 0, q.size), ra, 0, ra.size))
    val (n6, r6) = reply("doubleclick.net", 28)
    if (FilterEngine.NXDOMAIN_FOR_BLOCKED) T.check("AAAA: NXDOMAIN, yanıt yok", n6 > 0 && (Packets.u16(r6, 2) and 0xF) == 3 && Packets.u16(r6, 6) == 0 && Dns.isLocalBlock(r6, 0, r6.size))
    else T.check("AAAA: :: (0.0.0.0 biçimi)", n6 > 0 && Packets.u16(r6, 6) == 1 && r6.copyOfRange(r6.size - 16, r6.size).all { it.toInt() == 0 } && Dns.isBlocked(r6, 0, r6.size))
    for ((t, nm) in listOf(15 to "MX", 16 to "TXT", 65 to "HTTPS", 64 to "SVCB", 255 to "ANY", 5 to "CNAME")) {
        val (n, r) = reply("doubleclick.net", t)
        T.check("$nm: cevapsız NOERROR (kayıt yok)", n > 0 && Packets.u16(r, 6) == 0 && (Packets.u16(r, 2) and 0xF) == 0 && n == Dns.questionEnd(q, 0, q.size))
    }
    val ch = dnsQuery("doubleclick.net", 1)
    Packets.put16(ch, ch.size - 2, 3)
    T.check("sınıfı IN olmayan sorgu için cevap üretilmez", FilterEngine.buildReply(ch, 0, ch.size, out, 0) == -1)
    T.check("tampon küçükse -1", FilterEngine.buildReply(q, 0, Dns.questionEnd(q, 0, q.size), ByteArray(20), 0) == -1)
    val rdOff = dnsQuery("doubleclick.net", 1).also { Packets.put16(it, 2, 0x0000) }
    val (_, rr) = run { val qe = Dns.questionEnd(rdOff, 0, rdOff.size); val n = FilterEngine.buildReply(rdOff, 0, qe, out, 0); n to out.copyOf(n) }
    T.check("RD bayrağı sorgudan kopyalanır (kapalıysa kapalı)", (Packets.u16(rr, 2) and 0x0100) == 0 && (Packets.u16(rr, 2) and 0x8000) != 0)
    // bozuk/sıradışı sorgular geçirilir
    val upper = Dns.buildQuery(1, "DOUBLEclick.NET")
    T.check("telde büyük harfli sorgu da engellenir", e.verdict(upper, 0, upper.size) == FilterVerdict.LIST && e.lastName() == "doubleclick.net")
    T.check("kısa/bozuk sorgu geçer", e.verdict(ByteArray(5), 0, 5) == FilterVerdict.PASS && e.verdict(upper, 0, 14) == FilterVerdict.PASS)
    val two = upper.copyOf().also { Packets.put16(it, 4, 2) }
    T.check("birden çok soru: verdict geçer, ama isMalformed yakalar (bkz. 'biçimi bozuk sorgular')", e.verdict(two, 0, two.size) == FilterVerdict.PASS && e.isMalformed(two, 0, two.size))
    val ptr = upper.copyOf().also { it[12] = 0xC0.toByte() }
    T.check("soruda sıkıştırma işaretçisi: verdict geçer, isMalformed yakalar", e.verdict(ptr, 0, ptr.size) == FilterVerdict.PASS && e.isMalformed(ptr, 0, ptr.size))
    val nonAscii = Dns.buildQuery(1, "doubleclick.net").also { it[13] = 0xE7.toByte() }
    T.check("engelli adın kendisi değil, tek harfi ASCII dışı (başka ad): geçer ama bozuk sayılmaz", e.verdict(nonAscii, 0, nonAscii.size) == FilterVerdict.PASS && !e.isMalformed(nonAscii, 0, nonAscii.size))
    val longName = ByteArray(12 + 300 + 5).also { Packets.put16(it, 4, 1); var i = 12; repeat(5) { _ -> it[i++] = 60; repeat(60) { _ -> it[i++] = 'a'.code.toByte() } } }
    T.check("çok uzun ad: verdict geçer, isMalformed yakalar", e.verdict(longName, 0, longName.size) == FilterVerdict.PASS && e.isMalformed(longName, 0, longName.size))
}

/** Süzgeç atlatma yolları: ASCII dışı/denetim baytlı etiketler, çoklu soru, işaretçili ad (v1.29). */
private fun testFilterMalformed() {
    T.group("Engelleme: ayrıksı etiket baytları ve biçimi bozuk sorgular")
    val e = loadEngine(FilterLevel.BASIC)
    // 1) engelli ana alan adının altındaki etiket her bayt değerini taşıyabilir; engelden kaçmamalı
    for ((nm, b) in listOf("0xE7" to 0xE7, "0x80" to 0x80, "0xFF" to 0xFF, "0x01" to 0x01, "0x20 (boşluk)" to 0x20, "0x00" to 0x00, "0x2E (nokta)" to 0x2E, "0x7F" to 0x7F)) {
        val w = Dns.buildQuery(1, "x.doubleclick.net").also { it[13] = b.toByte() }
        T.check("engelli alan adının altında $nm baytlı etiket engellenir", e.verdict(w, 0, w.size) == FilterVerdict.LIST && !e.isMalformed(w, 0, w.size))
        T.check("$nm: günlüğe giden ad yazdırılabilir ASCII", e.lastName().all { it.code in 0x21..0x7E } && e.lastName().endsWith("doubleclick.net"), e.lastName())
    }
    // 2) etiketi ASCII dışı olan ama engelli alan adı altında OLMAYAN ad engellenmez (yanlış engelleme yok)
    val other = Dns.buildQuery(1, "x.example.com").also { it[13] = 0xE7.toByte() }
    T.check("engelli olmayan alan adının altında ASCII dışı etiket geçer", e.verdict(other, 0, other.size) == FilterVerdict.PASS)
    // 2b) Reklam+ (SNI/Host): sıkı alan adı denetimini geçemeyen ama engelli ana alan adının altındaki adlar da yakalanır
    for (nm in listOf("-x.doubleclick.net", "x-.doubleclick.net", "a+b.doubleclick.net", "a!.DoubleClick.NET", "X_Y.doubleclick.net:443",
        "a\u0001b.doubleclick.net", "çç.doubleclick.net.", "-.doubleclick.net")) {
        T.check("SNI/Host '${nm.replace('\u0001', '?')}': engellenir", e.verdictOf(nm) == FilterVerdict.LIST)
    }
    T.check("SNI/Host: engelli olmayan adlar geçer (gevşek yol yanlış engellemez)", listOf("-x.example.com", "a+b.example.org", "-.example.com").all { e.verdictOf(it) == FilterVerdict.PASS })
    T.check("SNI/Host: boş etiket, IP, tek etiket, köşeli IPv6, çok uzun ad geçer (hata yok)",
        listOf("a..doubleclick.net", "1.2.3.4", "localhost", "[2001:db8::1]:443", "a".repeat(300) + ".doubleclick.net", "", "   ", ".", "..").all { e.verdictOf(it) == FilterVerdict.PASS })
    T.check("kullanıcı girdisi sıkı kalır: normalize hâlâ geçersiz adları reddeder", FilterNames.normalize("-x.doubleclick.net") == null && FilterNames.normalize("a+b.example.com") == null)
    // 3) CNAME cevabında ASCII dışı etiketli hedef de engelli alan adına varıyorsa yakalanır
    val cname = run {
        val q = Dns.buildQuery(1, "site.example.com")
        val qEnd = Dns.questionEnd(q, 0, q.size)
        val tgt = byteArrayOf(2, 0xE7.toByte(), 'x'.code.toByte(), 11) + "doubleclick".toByteArray() + byteArrayOf(3) + "net".toByteArray() + byteArrayOf(0)
        val msg = ByteArray(qEnd + 12 + 10 + tgt.size + 16)
        System.arraycopy(q, 0, msg, 0, qEnd)
        Packets.put16(msg, 2, 0x8180); Packets.put16(msg, 4, 1); Packets.put16(msg, 6, 2)
        var p = qEnd
        msg[p++] = 0xC0.toByte(); msg[p++] = 12                       // sahip: soru adı
        Packets.put16(msg, p, 5); p += 2; Packets.put16(msg, p, 1); p += 2; Packets.put32(msg, p, 60); p += 4
        Packets.put16(msg, p, tgt.size); p += 2
        System.arraycopy(tgt, 0, msg, p, tgt.size); val tgtAt = p; p += tgt.size
        msg[p++] = 0xC0.toByte(); msg[p++] = tgtAt.toByte()           // ikinci kayıt sahibi: hedef
        Packets.put16(msg, p, 1); p += 2; Packets.put16(msg, p, 1); p += 2; Packets.put32(msg, p, 60); p += 4
        Packets.put16(msg, p, 4); p += 2; msg[p++] = 1; msg[p++] = 2; msg[p++] = 3; msg[p++] = 4
        msg.copyOf(p)
    }
    T.check("CNAME hedefi engelli alan adının altında (ASCII dışı etiketle): gizli izleyici yakalanır", e.cnameVerdict(cname, 0, cname.size) != FilterVerdict.PASS)

    // 4) biçimi bozuk sorgular
    val good = Dns.buildQuery(1, "example.com")
    T.check("düzgün sorgu bozuk sayılmaz", !e.isMalformed(good, 0, good.size))
    val two = good.copyOf().also { Packets.put16(it, 4, 2) }
    val zero = good.copyOf().also { Packets.put16(it, 4, 0) }
    val ptr = good.copyOf().also { it[12] = 0xC0.toByte() }
    val res = good.copyOf().also { it[12] = 0x80.toByte() }               // ayrılmış etiket türü
    val cut = good.copyOf(16)
    T.check("iki soru, sıfır soru, işaretçi, ayrılmış etiket, kesik soru: bozuk", listOf(two, zero, ptr, res, cut).all { e.isMalformed(it, 0, it.size) })
    val notify = two.copyOf().also { Packets.put16(it, 2, 0x2000) }        // opcode 4 (NOTIFY): dokunulmaz
    T.check("sorgu dışı işlem kodu bozuk sayılmaz (olduğu gibi geçer)", !e.isMalformed(notify, 0, notify.size))
    val off = loadEngine(FilterLevel.OFF)
    T.check("süzgeç kapalıyken hiçbir sorgu bozuk sayılmaz", !off.isMalformed(two, 0, two.size) && !off.isMalformed(ptr, 0, ptr.size))
    val fe = FilterEngine.buildFormerr(good, 0, ByteArray(40), 5)
    T.check("buildFormerr: 12 bayt, QR+RA, RCODE=1, sayılar sıfır, RD korunur", fe == 12)
    val fr = ByteArray(40).also { FilterEngine.buildFormerr(good, 0, it, 5) }
    T.check("buildFormerr alanları", Packets.u16(fr, 5 + 2) == (0x8000 or 0x0100 or 0x0080 or 1) && (1..5).all { Packets.u16(fr, 5 + 2 * (it + 1)) == 0 })
    T.check("buildFormerr: tampon küçükse -1", FilterEngine.buildFormerr(good, 0, ByteArray(10), 5) == -1)

    // 5) sarmalayıcı: bozuk sorgu içeri verilmez, istemciye FORMERR yazılır; geçerli sorgu etkilenmez
    loadEngine(FilterLevel.BASIC)
    val inner = FakeInner()
    val wrote = ArrayList<ByteArray>()
    val fw = FilteringForwarder(inner) { b, o, l -> wrote.add(b.copyOfRange(o, o + l)) }
    for ((nm, bad) in listOf("iki soru" to two, "sıfır soru" to zero, "işaretçi" to ptr, "ayrılmış etiket" to res)) {
        val before = wrote.size
        val pk = v4Pkt(bad.copyOf().also { Packets.put16(it, 0, 0x5151) })
        fw.onPacket(pk, pk.size)
        val r = wrote.lastOrNull()
        T.check("$nm: içeri verilmez, FORMERR yazılır", inner.got == 0 && wrote.size == before + 1 && r != null && (r[0].toInt() and 0xF0) == 0x40 &&
            Packets.u16(r, Packets.HDR) == 0x5151 && (Packets.u16(r, Packets.HDR + 2) and 0xF) == 1 && (Packets.u16(r, Packets.HDR + 2) and 0x8000) != 0)
    }
    val p6 = v6Pkt(two.copyOf().also { Packets.put16(it, 0, 0x6262) })
    fw.onPacket(p6, p6.size)
    val r6 = wrote.last()
    T.check("IPv6: iki soru da FORMERR olarak IPv6 yazılır", inner.got == 0 && (r6[0].toInt() and 0xF0) == 0x60 && Packets.u16(r6, Packets.HDR6) == 0x6262 && (Packets.u16(r6, Packets.HDR6 + 2) and 0xF) == 1)
    val ok = v4Pkt(Dns.buildQuery(0x1111, "example.com"))
    fw.onPacket(ok, ok.size)
    T.check("geçerli sorgu etkilenmez, içeri verilir", inner.got == 1 && wrote.size == 5)
    val weirdBlocked = v4Pkt(Dns.buildQuery(0x2222, "x.doubleclick.net").also { it[13] = 0xE7.toByte() })
    fw.onPacket(weirdBlocked, weirdBlocked.size)
    T.check("engelli alan adı altındaki ASCII dışı etiketli sorgu içeri verilmez, engelleme cevabı yazılır", inner.got == 1 && wrote.size == 6 && Dns.isLocalBlock(wrote.last(), Packets.HDR, wrote.last().size - Packets.HDR))
    // 6) ağdan gelen ad arayüze yazılmadan temizlenir
    T.check("clean: olağan ad aynen döner (ayırma yok)", FilterLive.clean("ads.doubleclick.net").let { it == "ads.doubleclick.net" })
    T.check("clean: denetim ve yönlendirme karakterleri '?' olur", FilterLive.clean("a\u0001‮b​.x.com") == "a??b?.x.com")
    T.check("clean: 253 karakterle sınırlanır", FilterLive.clean("a".repeat(5000)).length == 253 && FilterLive.clean("é".repeat(400)).length == 253)
    FilterLive.clear(); FilterLive.keep(true)
    FilterLive.note("kotu‮ad.example.com", false)
    T.check("günlüğe temizlenmiş ad girer", FilterLive.recent().first().name == "kotu?ad.example.com")
    FilterLive.clear()
    FilterRuntime.reset()
}

private fun testFilterFailClosed() {
    T.group("Engelleme: kök ad, IN dışı sınıf (reddedildi), HTTPS/ECH kaydı, ağ geçidi yardımcıları")
    val e = loadEngine(FilterLevel.BASIC)
    // kök ad sorgusu ("."): geçerli, bozuk sayılmaz, içeri verilir
    val root = ByteArray(Packets.DNS_HDR + 1 + 4)
    Packets.put16(root, 0, 0x5151); Packets.put16(root, 2, 0x0100); Packets.put16(root, 4, 1); Packets.put16(root, Packets.DNS_HDR + 1, 2); Packets.put16(root, Packets.DNS_HDR + 3, 1)
    T.check("kök ad sorgusu bozuk sayılmaz ve engellenmez", !e.isMalformed(root, 0, root.size) && e.verdict(root, 0, root.size) == FilterVerdict.PASS)
    val inner = FakeInner()
    val wrote = ArrayList<ByteArray>()
    val fw = FilteringForwarder(inner) { b, o, l -> wrote.add(b.copyOfRange(o, o + l)) }
    var p = v4Pkt(root); fw.onPacket(p, p.size)
    T.check("kök ad sorgusu üst sunucuya iletilir (FORMERR verilmez)", inner.got == 1 && wrote.isEmpty())
    // engelli ad + IN dışı sınıf: cevap kurulamaz → REFUSED, ASLA iletilmez
    for ((nm, cls) in listOf("CHAOS" to 3, "HESIOD" to 4, "NONE" to 254, "ANY" to 255)) {
        val q = dnsQuery("doubleclick.net", 1, 0x3131).also { Packets.put16(it, it.size - 2, cls) }
        p = v4Pkt(q); fw.onPacket(p, p.size)
        val r = wrote.lastOrNull()
        T.check("engelli ad, sınıf $nm: üst sunucuya gitmez, 'reddedildi' (RCODE 5) döner, kimlik korunur",
            inner.got == 1 && r != null && (Packets.u16(r, Packets.HDR + 2) and 0xF) == 5 && Packets.u16(r, Packets.HDR) == 0x3131 && Packets.u16(r, Packets.HDR + 4) == 0,
            "got=${inner.got} r=${r?.size}")
    }
    val b1 = FilterEngine.buildRefused(dnsQuery("a.b"), 0, ByteArray(64), 4)
    T.check("buildRefused: yalnızca başlık (12 bayt)", b1 == Packets.DNS_HDR)
    // HTTPS / SVCB: yalnızca Reklam+ (ağ geçidi motoru) açıkken "kayıt yok"
    T.check("Reklam+ kapalıyken HTTPS kaydı düşürülmez", !FilterRuntime.dropHttpsRr)
    p = v4Pkt(dnsQuery("example.com", 65, 0x6565)); fw.onPacket(p, p.size)
    T.check("Reklam+ kapalı: HTTPS sorgusu iletilir", inner.got == 2)
    FilterRuntime.reset(); FilterRuntime.setGateway(FilterLevel.MEDIUM)
    FilterRuntime.updateNow(FilterLevel.BASIC, emptyList(), emptyList())
    T.check("Reklam+ açık: dropHttpsRr", FilterRuntime.dropHttpsRr)
    val before = inner.got
    for (t in listOf(65, 64)) {
        p = v4Pkt(dnsQuery("example.com", t, 0x6566)); fw.onPacket(p, p.size)
        val r = wrote.last()
        T.check("Reklam+ açık: tür $t sorgusu iletilmez; 'kayıt yok' (NOERROR, cevap yok), kimlik korunur",
            inner.got == before && (Packets.u16(r, Packets.HDR + 2) and 0xF) == 0 && Packets.u16(r, Packets.HDR + 6) == 0 && Packets.u16(r, Packets.HDR) == 0x6566 && Packets.u16(r, Packets.HDR + 4) == 1)
    }
    p = v4Pkt(dnsQuery("example.com", 1, 0x6567)); fw.onPacket(p, p.size)
    p = v4Pkt(dnsQuery("example.com", 28, 0x6568)); fw.onPacket(p, p.size)
    T.check("Reklam+ açık: A ve AAAA sorguları yine iletilir", inner.got == before + 2)
    // süzgeç kapalı (motor yok) olsa bile HTTPS kaydı Reklam+ açıkken düşer
    FilterRuntime.reset(); FilterRuntime.setGateway(FilterLevel.MEDIUM)
    FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), emptyList())
    val n0 = wrote.size
    p = v4Pkt(dnsQuery("example.com", 65, 0x6569)); fw.onPacket(p, p.size)
    T.check("DNS süzgeci kapalıyken de (Reklam+ açıksa) HTTPS kaydı düşer", wrote.size == n0 + 1 && FilterRuntime.dropHttpsRr)
    FilterRuntime.reset()
    // ağ geçidi: hangi düz DNS sorguları seçilen DNS'e yönlenir
    fun udp4(dst: ByteArray, dns: ByteArray, sport: Int = 40000, dport: Int = 53): ByteArray {
        val b = ByteArray(Packets.HDR + dns.size)
        System.arraycopy(dns, 0, b, Packets.HDR, dns.size)
        b[0] = 0x45; Packets.put16(b, 2, b.size); Packets.put16(b, 6, 0x4000); b[8] = 64; b[9] = 17
        Packets.put32(b, 12, Packets.ip(10, 111, 222, 1)); System.arraycopy(dst, 0, b, 16, 4)
        Packets.put16(b, 10, Packets.checksum(b, 0, 20))
        Packets.put16(b, 20, sport); Packets.put16(b, 22, dport); Packets.put16(b, 24, 8 + dns.size)
        return b
    }
    val dq = dnsQuery("example.com")
    fun a4(a: Int, b: Int, c: Int, d: Int) = byteArrayOf(a.toByte(), b.toByte(), c.toByte(), d.toByte())
    fun pub(a: ByteArray, dns: ByteArray = dq, dport: Int = 53) = udp4(a, dns, dport = dport).let { Gw.isPublicPlainDns(it, it.size) }
    T.check("yönlendirme: 8.8.8.8:53 ve 1.1.1.1:53 seçilen DNS'e yönlenir", pub(a4(8, 8, 8, 8)) && pub(a4(1, 1, 1, 1)))
    T.check("yönlendirme: yerel/özel hedefler yönlenmez (192.168.x, 10.x, 172.16-31, 169.254, 127, 100.64/10, çok noktaya)",
        listOf(a4(192, 168, 1, 1), a4(10, 0, 0, 1), a4(172, 16, 0, 1), a4(172, 31, 255, 1),
            a4(169, 254, 1, 1), a4(127, 0, 0, 53), a4(100, 64, 0, 1), a4(224, 0, 0, 251), a4(0, 0, 0, 0)).none { pub(it) })
    T.check("yönlendirme: 172.15 ve 172.32 genel adrestir", pub(a4(172, 15, 0, 1)) && pub(a4(172, 32, 0, 1)))
    T.check("yönlendirme: UDP/53 dışı portlar, cevap paketleri ve kesik paketler yönlenmez",
        !pub(a4(8, 8, 8, 8), dport = 5353) && !pub(a4(8, 8, 8, 8), dq.copyOf().also { it[2] = (it[2].toInt() or 0x80).toByte() }) &&
            !Gw.isPublicPlainDns(udp4(a4(8, 8, 8, 8), dq).copyOf(30), 30) && !Gw.isPublicPlainDns(ByteArray(0), 0) && !Gw.isPublicPlainDns(byteArrayOf(0x45), 1))
    val tcpLike = udp4(a4(8, 8, 8, 8), dq).also { it[9] = 6 }
    T.check("yönlendirme: TCP yönlenmez", !Gw.isPublicPlainDns(tcpLike, tcpLike.size))
    val v6 = v6Pkt(dq)
    System.arraycopy(Ip.parse6("2001:4860:4860::8888")!!, 0, v6, 24, 16)
    T.check("yönlendirme IPv6: 2001:4860:4860::8888 yönlenir", Gw.isPublicPlainDns(v6, v6.size))
    for ((nm, a) in listOf("fe80::1" to "fe80::1", "fd00::1" to "fd00::1", "::1" to "::1", "ff02::fb" to "ff02::fb", "::" to "::")) {
        val x = v6Pkt(dq); System.arraycopy(Ip.parse6(a)!!, 0, x, 24, 16)
        T.check("yönlendirme IPv6: $nm yönlenmez", !Gw.isPublicPlainDns(x, x.size))
    }
    // IPv6 uzantı başlıklı UDP/53 sorgusu şifreli yoldan kaçamaz: "genel düz DNS" sayılır (forwarder düşürür, ağ geçidi soyup çıkarmaz)
    run {
        val ext = ByteArray(v6.size + 8)
        System.arraycopy(v6, 0, ext, 0, 40)
        ext[40] = 17; ext[41] = 0
        System.arraycopy(v6, 40, ext, 48, v6.size - 40)
        ext[6] = 60
        Packets.put16(ext, 4, Packets.u16(v6, 4) + 8)
        T.check("yönlendirme IPv6: hedef-seçenekleri başlıklı UDP/53 de yakalanır", Gw.isPublicPlainDns(ext, ext.size))
        val loc = ext.copyOf(); System.arraycopy(Ip.parse6("fe80::1")!!, 0, loc, 24, 16)
        T.check("yönlendirme IPv6: uzantı başlıklı yerel hedef yönlenmez", !Gw.isPublicPlainDns(loc, loc.size))
        val other = ext.copyOf(); Packets.put16(other, 50, 5353)
        T.check("yönlendirme IPv6: uzantı başlıklı UDP/53 dışı yakalanmaz", !Gw.isPublicPlainDns(other, other.size))
    }
    // ClientHello iki TLS kaydına bölünmüş: SNI ikinci kayıtta
    run {
        val sni = "gizli.example".toByteArray()
        val ext = ByteArray(4 + 5 + sni.size)
        Packets.put16(ext, 0, 0); Packets.put16(ext, 2, 5 + sni.size); Packets.put16(ext, 4, 3 + sni.size)
        ext[6] = 0; Packets.put16(ext, 7, sni.size); System.arraycopy(sni, 0, ext, 9, sni.size)
        val body = java.io.ByteArrayOutputStream()
        body.write(byteArrayOf(3, 3)); body.write(ByteArray(32)); body.write(0)
        body.write(byteArrayOf(0, 2, 0x13, 1)); body.write(byteArrayOf(1, 0))
        body.write(byteArrayOf((ext.size shr 8).toByte(), ext.size.toByte())); body.write(ext)
        val hs = byteArrayOf(1, 0, (body.size() shr 8).toByte(), body.size().toByte()) + body.toByteArray()
        val cut = 50                                        // SNI'dan önce
        fun rec(x: ByteArray) = byteArrayOf(0x16, 3, 1, (x.size shr 8).toByte(), x.size.toByte()) + x
        val two = rec(hs.copyOfRange(0, cut)) + rec(hs.copyOfRange(cut, hs.size))
        val one = rec(hs.copyOfRange(0, cut))
        val r1 = 5 + cut
        T.check("TLS bölünmüş ClientHello: ilk kayıt yetmez, tamamı beklenir", Dpi.tlsNeed(two, r1) == -1 && Dpi.tlsNeed(two, r1 + 3) == -1 && Dpi.tlsNeed(two, two.size) == two.size)
        val m = Dpi.mergedHello(two, two.size)
        val h = Dpi.Hello()
        T.check("TLS bölünmüş ClientHello: SNI birleştirilmiş kayıttan okunur", m != null && Dpi.parseHello(m, m.size, h) && h.host(m) == "gizli.example")
        val h1 = Dpi.Hello()
        T.check("TLS bölünmüş ClientHello: ilk kayıt tek başına SNI vermez (eski açık)", !Dpi.parseHello(one, one.size, h1))
        val whole = rec(hs)
        T.check("TLS tek kayıtlı ClientHello: davranış değişmez", Dpi.tlsNeed(whole, whole.size) == whole.size && Dpi.mergedHello(whole, whole.size) == null)
        // Gemini #2: el sıkışma başlığının kendisi kayıt sınırında bölünmüş (ilk kayıt 2 bayt)
        val tiny = rec(hs.copyOfRange(0, 2)) + rec(hs.copyOfRange(2, hs.size))
        val mt = Dpi.mergedHello(tiny, tiny.size)
        val ht = Dpi.Hello()
        T.check("TLS 2 baytlık ilk kayıt: tamamı beklenir, SNI okunur",
            Dpi.tlsNeed(tiny, 7) == -1 && Dpi.tlsNeed(tiny, tiny.size) == tiny.size && mt != null && Dpi.parseHello(mt, mt.size, ht) && ht.host(mt) == "gizli.example")
        // Gemini #2: ServerNameList'te önce başka tür, sonra host_name
        val nm = "liste.example".toByteArray()
        val list = byteArrayOf(1, 0, 1, 9) + byteArrayOf(0, (nm.size shr 8).toByte(), nm.size.toByte()) + nm
        val ext2 = ByteArray(4 + 2 + list.size)
        Packets.put16(ext2, 0, 0); Packets.put16(ext2, 2, 2 + list.size); Packets.put16(ext2, 4, list.size); System.arraycopy(list, 0, ext2, 6, list.size)
        val body2 = java.io.ByteArrayOutputStream()
        body2.write(byteArrayOf(3, 3)); body2.write(ByteArray(32)); body2.write(0)
        body2.write(byteArrayOf(0, 2, 0x13, 1)); body2.write(byteArrayOf(1, 0))
        body2.write(byteArrayOf((ext2.size shr 8).toByte(), ext2.size.toByte())); body2.write(ext2)
        val hs2 = byteArrayOf(1, 0, (body2.size() shr 8).toByte(), body2.size().toByte()) + body2.toByteArray()
        val w2 = rec(hs2)
        val h2 = Dpi.Hello()
        T.check("TLS SNI listesinde ilk giriş host_name değilse sonrakine bakılır", Dpi.parseHello(w2, w2.size, h2) && h2.host(w2) == "liste.example")
    }
    // HTTP Host: başlıklar bittikten sonraki gövdede "Host:" satırı Host sayılmaz
    val noHost = "POST /x HTTP/1.0\r\nContent-Length: 12\r\n\r\nHost: evil.example\r\n".toByteArray()
    val hi = Dpi.HttpInfo()
    T.check("HTTP: gövdedeki 'Host:' satırı Host başlığı sayılmaz", !Dpi.parseHttp(noHost, noHost.size, hi) && hi.valOff < 0)
    val withHost = "GET / HTTP/1.1\r\nHost: Gercek.example:8080\r\nX: y\r\n\r\n".toByteArray()
    T.check("HTTP: gerçek Host başlığı okunur", Dpi.parseHttp(withHost, withHost.size, hi) && Dpi.httpHost(withHost, hi) == "gercek.example")
}

private fun testFilterForwarder() {
    T.group("Engelleme: sarmalayıcı yönlendirici")
    loadEngine(FilterLevel.BASIC, allow = listOf("izinli.example"), block = listOf("engelli.example"))
    val inner = FakeInner()
    val wrote = ArrayList<ByteArray>()
    val fw = FilteringForwarder(inner) { b, off, len -> wrote.add(b.copyOfRange(off, off + len)) }
    FilterLive.clear()
    fun v4(name: String, qtype: Int = 1, id: Int = 0x4321) = v4Pkt(dnsQuery(name, qtype, id))
    var p = v4("doubleclick.net")
    fw.onPacket(p, p.size)
    T.check("IPv4: engellenen sorgu içeri verilmez, cevap tünele yazılır", inner.got == 0 && wrote.size == 1)
    val r = wrote[0]
    T.check("IPv4 cevabı: geçerli IP, UDP, kaynak 53, hedef istemci portu", (r[0].toInt() and 0xF0) == 0x40 && (r[9].toInt() and 0xFF) == 17 &&
        Packets.u16(r, 20) == 53 && Packets.u16(r, 22) == 40001 && Packets.udpChecksumOk(r, 20, r.size - 20, Packets.i32(r, 12), Packets.i32(r, 16)))
    T.check("IPv4 cevabı: adresler yer değiştirmiş", Packets.i32(r, 12) == Packets.ip(10, 111, 222, 2) && Packets.i32(r, 16) == Packets.ip(10, 111, 222, 1))
    T.check("IPv4 cevabı: istemci kimliği ve engelleme cevabı", Packets.u16(r, Packets.HDR) == 0x4321 && Dns.isLocalBlock(r, Packets.HDR, r.size - Packets.HDR))
    p = v6Pkt(dnsQuery("doubleclick.net", 28, 0x7777))
    fw.onPacket(p, p.size)
    val r6 = wrote.last()
    T.check("IPv6: engellenen sorgunun cevabı IPv6 olarak yazılır", wrote.size == 2 && (r6[0].toInt() and 0xF0) == 0x60 && Packets.u16(r6, Packets.HDR6) == 0x7777 &&
        Packets.u16(r6, 40) == 53 && Packets.u16(r6, 42) == 40002 && Dns.isLocalBlock(r6, Packets.HDR6, r6.size - Packets.HDR6))
    p = v4("example.com"); fw.onPacket(p, p.size)
    T.check("engellenmeyen sorgu içeri verilir, yazılmaz", inner.got == 1 && wrote.size == 2)
    p = v4("izinli.example"); fw.onPacket(p, p.size)
    p = v4("sub.izinli.example"); fw.onPacket(p, p.size)
    T.check("izinli ad geçer", inner.got == 3)
    p = v4("engelli.example"); fw.onPacket(p, p.size)
    p = v4("alt.engelli.example", 15); fw.onPacket(p, p.size)
    T.check("kullanıcının engellediği ad (A ve MX) cevaplanır", inner.got == 3 && wrote.size == 4)
    val junk = byteArrayOf(1, 2, 3); fw.onPacket(junk, junk.size)
    val resp = v4("doubleclick.net").also { it[Packets.HDR + 2] = (it[Packets.HDR + 2].toInt() or 0x80).toByte() }
    fw.onPacket(resp, resp.size)
    T.check("bozuk paket ve cevap paketi içeri verilir (karar içtekinin)", inner.got == 5 && wrote.size == 4)
    val s = fw.stats()
    T.check("istatistik: engellenenler sorgu ve engellenen sayısına eklenir", s.blocked == 4L && s.queries == inner.got + 4L, "$s")
    T.check("canlı liste: bu oturumda engellenen adlar (ad, adet, kaynak)", FilterLive.blockedTotal == 4L &&
        FilterLive.recent().first { it.name == "doubleclick.net" }.count == 2 && FilterLive.recent().first { it.name == "alt.engelli.example" }.user)
    FilterRuntime.reset()
    p = v4("doubleclick.net"); fw.onPacket(p, p.size)
    T.check("motor yokken (liste yüklenmedi) her şey içeri verilir", inner.got == 6 && wrote.size == 4)
    loadEngine(FilterLevel.OFF)
    p = v4("doubleclick.net"); fw.onPacket(p, p.size)
    T.check("seviye kapalıyken içeri verilir", inner.got == 7)
    FilterRuntime.source = FilterSource { throw IOException("yok") }
    FilterRuntime.reset(); FilterRuntime.updateNow(FilterLevel.STRICT, emptyList(), listOf("engelli.example"))
    p = v4("doubleclick.net"); fw.onPacket(p, p.size)
    p = v4("engelli.example"); fw.onPacket(p, p.size)
    T.check("liste dosyası okunamazsa sessizce kapalı kalır; kullanıcı engeli çalışır", inner.got == 8 && wrote.size == 5)
    loadEngine(FilterLevel.OFF)
    // yazım: kapanış ve devralınan yöntemler
    fw.start(); fw.resetNetwork("x"); fw.clearCache(); fw.close()
    T.check("diğer yöntemler içtekine devredilir", fw.proto == Proto.PLAIN)
}

private fun testFilterSettings() {
    T.group("Engelleme: ayarlar")
    val d = AppSettings()
    T.check("varsayılan: kapalı, listeler boş", d.filterLevel == FilterLevel.OFF && d.filterAllow.isEmpty() && d.filterBlock.isEmpty())
    val s = AppSettings(filterLevel = FilterLevel.MEDIUM, filterAllow = listOf("a.com", "b.org"), filterBlock = listOf("c.net"))
    val back = SettingsCodec.decode(SettingsCodec.encode(s))
    T.check("kayıt gidiş-dönüş", back.filterLevel == FilterLevel.MEDIUM && back.filterAllow == listOf("a.com", "b.org") && back.filterBlock == listOf("c.net"))
    T.check("bozuk seviye varsayılana düşer", SettingsCodec.decode(mapOf("filterLevel" to "zzz")).filterLevel == FilterLevel.OFF)
    T.check("bozuk liste girdileri ayıklanır", SettingsCodec.decode(mapOf("filterAllow" to "ok.com,<script>,1.2.3.4,x")).filterAllow == listOf("ok.com"))
    val exp = SettingsCodec.export(s)
    T.check("dışa/içe aktarma filtre ayarlarını taşır", SettingsCodec.import(exp, AppSettings())?.let { it.filterLevel == FilterLevel.MEDIUM && it.filterAllow == listOf("a.com", "b.org") } == true)
    val changes = ImportReview.changes(AppSettings(filterLevel = FilterLevel.STRICT), AppSettings(filterLevel = FilterLevel.BASIC))
    T.check("içe aktarmada seviye düşerse uyarı", SensitiveChange.RULES in changes)
    T.check("içe aktarmada izin listesine ad eklenirse uyarı", SensitiveChange.RULES in ImportReview.changes(AppSettings(), AppSettings(filterAllow = listOf("a.com"))))
    T.check("seviye yükselirse uyarı yok", SensitiveChange.RULES !in ImportReview.changes(AppSettings(), AppSettings(filterLevel = FilterLevel.STRICT)))
    T.check("seviye kimlikleri benzersiz, byId gidiş-dönüş", FilterLevel.values().map { it.id }.toSet().size == 4 && FilterLevel.values().all { FilterLevel.byId(it.id) == it } && FilterLevel.byId("x") == null)
    T.check("seviyeler birikimli", FilterLevel.values().map { it.tiers } == listOf(0, 1, 2, 3))
}

private fun testFilterLive() {
    T.group("Engelleme: oturum listesi")
    FilterLive.clear()
    T.check("başlangıçta boş", FilterLive.recent().isEmpty() && FilterLive.blockedTotal == 0L)
    for (i in 1..60) FilterLive.note("s$i.example.com", false)
    T.check("en çok 40 ad, en yeni önde", FilterLive.recent().size == 40 && FilterLive.recent().first().name == "s60.example.com" && FilterLive.blockedTotal == 60L)
    FilterLive.note("s30.example.com", true)
    T.check("tekrar eden ad öne alınır ve sayılır", FilterLive.recent().first().name == "s30.example.com" && FilterLive.recent().first().count == 2)
    T.check("liste kopyası değiştirilemez (anlık görüntü)", run { val r = FilterLive.recent(); r.first().count = 99; FilterLive.recent().first().count == 2 })
    FilterLive.clear()
    T.check("temizlenir", FilterLive.recent().isEmpty() && FilterLive.blockedTotal == 0L)
    // "Geçmişi tut" kapalı: adlar listeye hiç alınmaz, sayaç artar; kapatılınca mevcut adlar silinir.
    FilterLive.note("a.example.com", false)
    FilterLive.keep(false)
    T.check("geçmiş kapatılınca liste hemen boşalır", FilterLive.recent().isEmpty())
    FilterLive.note("b.example.com", false)
    T.check("geçmiş kapalıyken ad saklanmaz ama sayaç artar", FilterLive.recent().isEmpty() && FilterLive.blockedTotal == 2L)
    FilterLive.keep(true)
    FilterLive.note("c.example.com", false)
    T.check("geçmiş açılınca adlar yeniden listelenir", FilterLive.recent().size == 1)
    FilterLive.clear()
}

private fun shown(r: Rig): List<String> = TextRecorder().also { r.scene.draw(it) }.runs.map { it.s }

private fun testFilterUi() {
    T.group("Engelleme: arayüz")
    FilterLive.clear()
    val r = Rig()
    r.scene.openMenu(); r.settle(900)
    T.check("menüde Engelleme satırı ve seviye değeri var", r.find(Strings.FILTER, exact = true) != null && shown(r).contains(Strings.OPT_FILTER[0]))
    r.scene.back(); r.settle(900)
    r.scene.openSection(Section.FILTER); r.settle(900)
    T.check("sayfada seviye seçici, kapalı notu, sayaç ve üç satır var",
        shown(r).contains(Strings.FILTER_LEVEL) && shown(r).any { Strings.FILTER_NOTES[0].startsWith(it.removeSuffix("…")) && it.length > 6 } &&
            r.find(Strings.FILTER_LAST) != null && r.find(Strings.FILTER_ALLOW) != null && r.find(Strings.FILTER_BLOCK) != null)
    r.tapText(Strings.FILTER_LEVEL + ": " + Strings.OPT_FILTER[2], settleMs = 900)
    T.check("Orta seçilince ayar kaydolur ve not değişir", r.model.settings.filterLevel == FilterLevel.MEDIUM && shown(r).any { Strings.FILTER_NOTES[2].startsWith(it.removeSuffix("…")) && it.length > 6 })

    // izin listesine ekleme
    r.tapText(Strings.FILTER_ALLOW, settleMs = 900)
    r.host.textAnswer = "https://www.Ornek.com/yol"
    r.tapText(Strings.FILTER_ADD, settleMs = 900)
    T.check("yazılan adres temizlenip izin listesine eklenir", r.model.settings.filterAllow == listOf("www.ornek.com"), r.model.settings.filterAllow.toString())
    T.check("engel listesinden çıkar, eklenen ad listede görünür", shown(r).contains("www.ornek.com"))
    r.host.textAnswer = null
    r.tapText("www.ornek.com", settleMs = 900)
    T.check("ada dokununca kaldırma sorusu çıkar, onaylanınca silinir", r.model.toast?.text == Strings.filterRemoveAsk("www.ornek.com") && r.model.settings.filterAllow.isNotEmpty())
    r.model.toast?.onAction?.invoke(); r.settle(300)
    T.check("onaydan sonra liste boş", r.model.settings.filterAllow.isEmpty())

    // model kuralları
    T.check("geçersiz ad reddedilir ve uyarı verir", !r.model.addFilterName(false, "yanlış ad") && r.model.toast?.text == Strings.FILTER_ERR && r.model.settings.filterBlock.isEmpty())
    T.check("IP adresi reddedilir", !r.model.addFilterName(false, "1.2.3.4"))
    T.check("kendi engel listesine eklenir", r.model.addFilterName(false, "reklam.example.org") && r.model.settings.filterBlock == listOf("reklam.example.org"))
    T.check("aynı ad izin listesine eklenince engelden çıkar", r.model.addFilterName(true, "reklam.example.org") && r.model.settings.filterBlock.isEmpty() && r.model.settings.filterAllow == listOf("reklam.example.org"))
    T.check("engele eklenince izinden çıkar", r.model.addFilterName(false, "reklam.example.org") && r.model.settings.filterAllow.isEmpty())
    r.model.update { it.copy(filterBlock = emptyList()) }
    for (i in 1..FilterNames.MAX_LIST) r.model.addFilterName(true, "s$i.example.com")
    T.check("izin listesi 200'de durur", r.model.settings.filterAllow.size == FilterNames.MAX_LIST && !r.model.addFilterName(true, "fazla.example.com") && r.model.toast?.text == Strings.FILTER_ERR_LIMIT)
    T.check("dolu listede var olan ad yine eklenebilir (taşınır)", r.model.addFilterName(true, "s1.example.com") && r.model.settings.filterAllow.size == FilterNames.MAX_LIST)
    r.model.update { it.copy(filterAllow = emptyList()) }

    // son engellenenler
    r.settle(300)
    FilterLive.clear()
    FilterLive.note("izleyici.example.net", false)
    FilterLive.note("benim.example.org", true)
    r.settle(900)
    r.tapText(Strings.FILTER_LAST, settleMs = 900)
    T.check("son engellenenler paneli adları gösterir", shown(r).contains("izleyici.example.net") && shown(r).contains("benim.example.org"))
    r.tapText("izleyici.example.net", settleMs = 900)
    T.check("ada dokununca izin listesine eklenir", r.model.settings.filterAllow == listOf("izleyici.example.net"))
    FilterLive.clear()
    r.tapText(Strings.FILTER_LAST, settleMs = 900)
    T.check("boşken açıklama görünür", shown(r).any { Strings.FILTER_RECENT_EMPTY.startsWith(it.removeSuffix("…")) && it.length > 8 })
    r.scene.back(); r.settle(900)

    // son izin verilenler: şüpheliler başta, hepsini tek dokunuşla engelleme
    FilterLive.clear()
    FilterLive.notePassed("haber.example.org")
    FilterLive.notePassed("0017c6c37c.com")
    FilterLive.notePassed("ads.izleme-sitesi.com")
    r.settle(900)
    r.tapText(Strings.FILTER_PASSED, settleMs = 900)
    val seen = shown(r)
    T.check("son izin verilenler: şüpheliler ve 'hepsini engelle' görünür",
        seen.contains("0017c6c37c.com") && seen.contains("ads.izleme-sitesi.com") && seen.contains("haber.example.org") &&
            seen.any { Strings.FILTER_BLOCK_SUSPECTS.startsWith(it.removeSuffix("…")) && it.length > 6 }, seen.take(30).toString())
    val iSus = seen.indexOf("ads.izleme-sitesi.com"); val iOk = seen.indexOf("haber.example.org")
    T.check("şüpheliler listenin başında", iSus in 0 until iOk, "$iSus / $iOk")
    r.tapText(Strings.FILTER_BLOCK_SUSPECTS, settleMs = 900)
    T.check("'hepsini engelle' yalnızca şüphelileri kendi engel listesine ekler",
        r.model.settings.filterBlock.containsAll(listOf("0017c6c37c.com", "ads.izleme-sitesi.com")) && "haber.example.org" !in r.model.settings.filterBlock,
        r.model.settings.filterBlock.toString())
    T.check("engellenenler son izin verilenlerden çıkar", FilterLive.recentPassed().map { it.name } == listOf("haber.example.org"))
    FilterLive.clear()
}

private fun testFilterStrings() {
    T.group("Engelleme: metinler (12 dil)")
    val saved = L.lang
    try {
        for (lang in Lang.values()) {
            L.set(lang)
            val n = lang.code
            T.check("$n: 4 seviye adı, kısa ve farklı", Strings.OPT_FILTER.size == 4 && Strings.OPT_FILTER.all { it.length in 2..11 } && Strings.OPT_FILTER.toSet().size == 4, Strings.OPT_FILTER.toString())
            T.check("$n: 4 seviye notu 12..100 karakter", Strings.FILTER_NOTES.size == 4 && Strings.FILTER_NOTES.all { it.length in 12..100 }, Strings.FILTER_NOTES.map { it.length }.toString())
            T.check("$n: açıklama 60..420 karakter, NXDOMAIN ve izin yolunu anlatır", Strings.FILTER_INFO.length in 60..420, Strings.FILTER_INFO.length.toString())
            val short = listOf(Strings.FILTER, Strings.FILTER_LAST, Strings.FILTER_ALLOW, Strings.FILTER_BLOCK, Strings.FILTER_ADD, Strings.FILTER_REMOVE_BTN, Strings.FILTER_REMOVE)
            T.check("$n: başlıklar 2..32 karakter", short.all { it.length in 2..32 }, short.toString())
            val fn = listOf(Strings.filterAllowed("a.com"), Strings.filterBlocked("a.com"), Strings.filterRemoved("a.com"), Strings.filterRemoveAsk("a.com"))
            T.check("$n: ad içeren mesajlar adı taşır", fn.all { "a.com" in it && it.length < 90 }, fn.toString())
            val long = listOf(Strings.FILTER_RECENT_EMPTY, Strings.FILTER_RECENT_FOOT, Strings.FILTER_ALLOW_FOOT, Strings.FILTER_BLOCK_FOOT, Strings.FILTER_ALLOW_EMPTY, Strings.FILTER_BLOCK_EMPTY, Strings.FILTER_ERR, Strings.FILTER_ERR_LIMIT)
            T.check("$n: uzun metinler boş değil ve 10..200 karakter", long.all { it.length in 10..200 }, long.map { it.length }.toString())
            T.check("$n: ağdaki yer tutucu kalmamış", (short + long + fn + Strings.FILTER_NOTES + Strings.FILTER_INFO).none { "TODO" in it || "{" in it || "%s" in it })
        }
    } finally { L.set(saved) }
}

/** Türkçe ve diğer IDN alan adları: kullanıcı "örnek.com" yazabilmeli; DNS için punycode'a çevrilmeli. */
fun runIdnNormalizeTests() {
    T.group("Engelleme: IDN alan adları (Türkçe karakterler)")
    run {
        T.check("örnek.com → xn--rnek-4qa.com", FilterNames.normalize("örnek.com") == "xn--rnek-4qa.com", "${FilterNames.normalize("örnek.com")}")
        T.check("büyük harf Türkçe: İSTANBUL.com.tr geçerli (nokta ve harf)", FilterNames.normalize("İSTANBUL.com.tr") != null, "${FilterNames.normalize("İSTANBUL.com.tr")}")
        T.check("ASCII alan adı değişmez", FilterNames.normalize("WWW.Ornek.COM") == "www.ornek.com")
        T.check("URL içindeki IDN de çözülür", FilterNames.normalize("https://örnek.com/yol") == "xn--rnek-4qa.com")
        T.check("geçersiz IDN (boş etiket) reddedilir", FilterNames.normalize("örnek..com") == null)
    }
}
