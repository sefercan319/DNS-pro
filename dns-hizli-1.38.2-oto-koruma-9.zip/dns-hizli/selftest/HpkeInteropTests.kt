package app.dnshizli.selftest

import app.dnshizli.core.Hpke
import java.security.SecureRandom

private fun hx(s: String): ByteArray = if (s.isEmpty()) ByteArray(0) else s.chunked(2).map { it.toInt(16).toByte() }.toByteArray()

/** Vektör alanları (HpkeVectors.YON1 satırı): 0 skR, 1 pkR, 2 info, 3 aad, 4 pt, 5 aad2, 6 pt2, 7 enc, 8 ct1, 9 ct2, 10 exp, 11 skE, 12 pkE. */
private fun vec(row: Array<String>, i: Int): ByteArray = hx(row[i])

/**
 * HPKE: bağımsız referans (pyhpke, RFC 9180) ile çapraz doğrulama, nonce/anahtar kuralları ve bozuk girdi fuzzing'i.
 * Yön 1: pyhpke gönderir, Kotlin alır. Yön 2: Kotlin gönderir (sabit efemer), çıktı pyhpke beklentisiyle karşılaştırılır.
 */
fun runHpkeInteropTests() {
    T.group("HPKE: pyhpke ile çapraz doğrulama (yön 1: pyhpke → Kotlin)")
    run {
        var ok = 0
        for (row in HpkeVectors.YON1) {
            val ctx = Hpke.setupBaseR(vec(row, 7), vec(row, 0), vec(row, 2))
            val good = ctx != null &&
                ctx.open(vec(row, 3), vec(row, 8))?.contentEquals(vec(row, 4)) == true &&
                ctx.open(vec(row, 5), vec(row, 9))?.contentEquals(vec(row, 6)) == true &&
                ctx.export("odoh test".toByteArray(), 32).contentEquals(vec(row, 10))
            if (good) ok++
        }
        T.check("${HpkeVectors.YON1.size} vektörün tümünde Kotlin alıcı açar ve dışa aktarım eşleşir",
            ok == HpkeVectors.YON1.size, "$ok/${HpkeVectors.YON1.size}")
    }

    T.group("HPKE: pyhpke ile çapraz doğrulama (yön 2: Kotlin → pyhpke beklentisi)")
    run {
        var ok = 0
        for (i in HpkeVectors.YON2.indices) {
            val row = HpkeVectors.YON1[i]
            val exp2 = HpkeVectors.YON2[i]
            val s = Hpke.setupBaseS(vec(row, 1), vec(row, 2), SecureRandom(), vec(row, 11))
            if (s != null &&
                s.enc.contentEquals(vec(row, 12)) &&
                s.enc.contentEquals(hx(exp2[0])) &&
                s.context.seal(vec(row, 3), vec(row, 4)).contentEquals(hx(exp2[1])) &&
                s.context.seal(vec(row, 5), vec(row, 6)).contentEquals(hx(exp2[2])) &&
                s.context.export("odoh test".toByteArray(), 32).contentEquals(hx(exp2[3]))) ok++
        }
        T.check("${HpkeVectors.YON2.size} vektörde sabit efemer ile çıktı pyhpke beklentisiyle aynı",
            ok == HpkeVectors.YON2.size, "$ok/${HpkeVectors.YON2.size}")
    }

    T.group("HPKE: anahtar ve nonce kuralları")
    run {
        val row = HpkeVectors.YON1[0]
        val skR = vec(row, 0); val pkR = vec(row, 1); val info = vec(row, 2); val pt = vec(row, 4)
        val s1 = Hpke.setupBaseS(pkR, info, SecureRandom())!!
        val s2 = Hpke.setupBaseS(pkR, info, SecureRandom())!!
        T.check("her gönderici kurulumunda yeni efemer anahtar (enc tekrarlanmaz)", !s1.enc.contentEquals(s2.enc))

        val a = s1.context.seal(ByteArray(0), pt)
        val b = s1.context.seal(ByteArray(0), pt)
        T.check("aynı düz metin ardışık şifrelenince farklı çıktı (nonce ilerliyor)", !a.contentEquals(b))

        val seen = HashSet<String>()
        val c2 = Hpke.setupBaseS(pkR, info, SecureRandom())!!.context
        var dup = false
        for (i in 0 until 3000) {
            val ct = c2.seal(ByteArray(0), ByteArray(8))
            if (!seen.add(ct.joinToString("") { "%02x".format(it) })) { dup = true; break }
        }
        T.check("3000 ardışık şifreleme hepsi farklı (nonce tekrarı yok)", !dup)

        val sender = Hpke.setupBaseS(pkR, info, SecureRandom())!!
        val m1 = sender.context.seal(ByteArray(0), pt)
        val m2 = sender.context.seal(ByteArray(0), pt)
        val rx = Hpke.setupBaseR(sender.enc, skR, info)!!
        T.check("sıra dışı mesaj (m2 önce) reddedilir", rx.open(ByteArray(0), m2) == null)
        T.check("sıra dışı reddinden sonra m1 hâlâ açılır (durum bozulmadı)",
            rx.open(ByteArray(0), m1)?.contentEquals(pt) == true)
    }

    T.group("HPKE: bozuk girdi fuzzing (bit çevirme, kırpma, uzatma)")
    run {
        val row = HpkeVectors.YON1[1]
        val aad = vec(row, 3); val pt = vec(row, 4); val ct1 = vec(row, 8)
        val rx = Hpke.setupBaseR(vec(row, 7), vec(row, 0), vec(row, 2))!!
        val rnd = java.util.Random(42)
        var exceptions = 0
        var accepted = 0
        var tried = 0
        for (i in 0 until 4000) {
            val input: ByteArray = when (rnd.nextInt(3)) {
                0 -> ct1.copyOf().also { p -> val k = rnd.nextInt(p.size); p[k] = (p[k].toInt() xor (1 shl rnd.nextInt(8))).toByte() }
                1 -> ct1.copyOf(rnd.nextInt(ct1.size))
                else -> ct1 + ByteArray(rnd.nextInt(8) + 1) { rnd.nextInt(256).toByte() }
            }
            if (input.contentEquals(ct1)) continue   // değişmemiş girdi fuzz değildir
            tried++
            try {
                if (rx.open(aad, input) != null) accepted++
            } catch (_: Throwable) {
                exceptions++
            }
        }
        T.check("$tried bozuk girdide hiçbir istisna sızmaz", exceptions == 0, "istisna: $exceptions")
        T.check("bozuk girdiler kabul edilmez", accepted == 0, "kabul: $accepted")
        T.check("fuzzing sonrası geçerli mesaj hâlâ açılır (alıcı durumu korunur)",
            rx.open(aad, ct1)?.contentEquals(pt) == true)
    }
}

/** Eşzamanlılık: aynı HPKE bağlamı birden çok iş parçacığından kullanılsa bile her şifreleme farklı nonce kullanmalı. */
fun runHpkeConcurrencyTests() {
    T.group("HPKE: eşzamanlı kullanım (nonce tekrarı olmamalı)")
    run {
        val row = HpkeVectors.YON1[0]
        val s = Hpke.setupBaseS(vec(row, 1), vec(row, 2), SecureRandom())!!
        val ctx = s.context
        val threads = 4
        val per = 1000
        val seen = java.util.Collections.newSetFromMap(java.util.concurrent.ConcurrentHashMap<String, Boolean>())
        val pool = java.util.concurrent.Executors.newFixedThreadPool(threads)
        val futures = (0 until threads).map {
            pool.submit {
                repeat(per) {
                    // Boş düz metin: çıktı yalnızca etiket (nonce'a bağlı), nonce tekrarı varsa aynı çıktı görünür.
                    seen.add(ctx.seal(ByteArray(0), ByteArray(0)).joinToString("") { b -> "%02x".format(b) })
                }
            }
        }
        futures.forEach { it.get() }
        pool.shutdown()
        T.check("$threads iş parçacığı × $per şifreleme: hepsi farklı nonce ile (çakışma yok)",
            seen.size == threads * per, "benzersiz: ${seen.size}/${threads * per}")
    }
}
