package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.core.OemCompat.Family as F

/** Üretici uyumluluk katmanı: üretici tanıma ve pil / otomatik başlatma ekranı sırası. */
fun runCompatTests() {
    T.group("Uyumluluk: üretici tanıma ve pil ekranları")

    T.check("Xiaomi, Redmi ve POCO aynı aile", OemCompat.family("Xiaomi", "Redmi") == F.XIAOMI && OemCompat.family("Xiaomi", "POCO") == F.XIAOMI && OemCompat.family("", "poco") == F.XIAOMI)
    T.check("Honor, Huawei'den ayrı tanınır", OemCompat.family("HONOR", "HONOR") == F.HONOR && OemCompat.family("HUAWEI", "HUAWEI") == F.HUAWEI)
    T.check("OnePlus, Oppo'dan önce tanınır; Realme Oppo ailesinde", OemCompat.family("OnePlus", "OnePlus") == F.ONEPLUS && OemCompat.family("realme", "realme") == F.OPPO)
    T.check("Vivo / iQOO, Tecno / Infinix", OemCompat.family("vivo", "iQOO") == F.VIVO && OemCompat.family("TECNO MOBILE LIMITED", "TECNO") == F.TRANSSION && OemCompat.family("INFINIX MOBILITY LIMITED", "Infinix") == F.TRANSSION)
    T.check("Nothing / CMF ve Casper tanınır, agresif değil", OemCompat.family("Nothing", "Nothing") == F.NOTHING && OemCompat.family("Nothing", "CMF") == F.NOTHING &&
        OemCompat.family("CASPER BILGISAYAR", "Casper") == F.CASPER && !F.NOTHING.aggressive && !F.CASPER.aggressive)
    T.check("Eski Honor (üretici HUAWEI, marka HONOR) Honor sayılır; Black Shark Xiaomi ailesinde",
        OemCompat.family("HUAWEI", "HONOR") == F.HONOR && OemCompat.family("blackshark", "Black Shark") == F.XIAOMI)
    T.check("Samsung önce Cihaz bakımı pil ekranını, sonra uygulama ayrıntılarını dener",
        OemCompat.batteryTargets(F.SAMSUNG).first() is OemCompat.Target.Component && OemCompat.Target.AppDetails in OemCompat.batteryTargets(F.SAMSUNG))
    T.check("Motorola/Lenovo, Sony, ZTE/nubia/RedMagic, General Mobile, Reeder tanınır",
        OemCompat.family("motorola", "motorola") == F.MOTOROLA && OemCompat.family("LENOVO", "Lenovo") == F.MOTOROLA && OemCompat.family("Sony", "Sony") == F.SONY &&
            OemCompat.family("nubia", "nubia") == F.NUBIA && OemCompat.family("ZTE", "ZTE") == F.NUBIA && OemCompat.family("nubia", "REDMAGIC") == F.NUBIA &&
            OemCompat.family("General Mobile", "GM") == F.GENERAL_MOBILE && OemCompat.family("Reeder", "Reeder") == F.REEDER && F.NUBIA.aggressive)
    T.check("özel ROM tanınır (LineageOS, GrapheneOS, /e/OS, crDroid, test-keys); resmi sistem tanınmaz",
        OemCompat.isCustomRom("lineage_dipper-userdebug 14", "", "release-keys") && OemCompat.isCustomRom("", "google/sailfish/graphene", "release-keys") &&
            OemCompat.isCustomRom("TQ3A.230901", "", "test-keys") && OemCompat.isCustomRom("crDroid", "", null) &&
            !OemCompat.isCustomRom("UP1A.231005.007", "google/husky/husky:14/UP1A:user/release-keys", "release-keys") &&
            !OemCompat.isCustomRom("HyperOS 1.0.2", "Xiaomi/aurora/aurora:14/UKQ1:user/release-keys", "release-keys"))
    T.check("özel ROM'da cihaz üreticisi yok sayılır; resmi sistemde üretici kalır",
        OemCompat.familyFor("Xiaomi", "POCO", "lineage_x", "", "release-keys") == F.CUSTOM_ROM && OemCompat.familyFor("Xiaomi", "POCO", "HyperOS", "Xiaomi/x:14/user", "release-keys") == F.XIAOMI)
    T.check("Samsung ve Google agresif değil, bilinmeyen üretici OTHER", OemCompat.family("samsung", "samsung") == F.SAMSUNG && !F.SAMSUNG.aggressive && OemCompat.family("Google", "google") == F.GOOGLE && OemCompat.family(null, null) == F.OTHER)
    T.check("agresif aileler işaretli", listOf(F.XIAOMI, F.HUAWEI, F.HONOR, F.OPPO, F.VIVO, F.ONEPLUS, F.TRANSSION).all { it.aggressive })
    for (f in F.values()) {
        val t = OemCompat.batteryTargets(f)
        T.check("${f.name}: liste standart ekranlarla biter, yineleme yok", t.isNotEmpty() && t.last() !is OemCompat.Target.Component &&
            OemCompat.Target.BatteryList in t && OemCompat.Target.AppDetails in t && t.toSet().size == t.size)
        T.check("${f.name}: üretici ekranı adları geçerli Java adları", t.filterIsInstance<OemCompat.Target.Component>().all {
            it.pkg.matches(Regex("[a-z][a-z0-9_]*(\\.[a-z0-9_]+)+")) && it.cls.matches(Regex("[a-z][a-z0-9_]*(\\.[A-Za-z0-9_]+)+")) })
        if (f.aggressive) T.check("${f.name}: agresif üreticide ilk ekran standart pil listesi değil", t.first() != OemCompat.Target.BatteryList)
    }
    T.check("Xiaomi: önce uygulamaya özel PowerKeeper (pil kısıtı), ardından uygulama ayrıntıları (otomatik başlatma)",
        OemCompat.batteryTargets(F.XIAOMI).let { t -> (t.first() as? OemCompat.Target.Component)?.let { it.pkg == "com.miui.powerkeeper" && it.withApp } == true && t[1] == OemCompat.Target.AppDetails })
    T.check("Google / bilinmeyen: standart pil listesi önce", OemCompat.batteryTargets(F.OTHER) == listOf(OemCompat.Target.BatteryList, OemCompat.Target.AppDetails))
}
