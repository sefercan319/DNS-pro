package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

private fun dev(man: String, brand: String = man, model: String = "", sdk: Int = 36, ram: Int = 5800, heap: Int = 256, vararg props: Pair<String, String>,
                display: String = "", fp: String = "", tags: String = "release-keys", low: Boolean = false, hz: Int = 120) =
    DeviceInfo(manufacturer = man, brand = brand, model = model, display = display, fingerprint = fp, tags = tags, sdk = sdk, ramMb = ram, heapMb = heap,
        lowRamFlag = low, refreshHz = hz, props = props.toMap())

/** Profili geçici olarak [DeviceTune]'a koyar; iş bitince eski haline döndürür. */
private inline fun <T> withProfile(p: DeviceProfile?, body: () -> T): T {
    val old = DeviceTune.profile
    DeviceTune.set(p)
    try { return body() } finally { DeviceTune.set(old) }
}

/** Cihaz tanıma katmanı: üretici sistemleri, özel ROM'lar, sınıf/risk/öneri, ad, ayar etkileri, Kişiselleştirme sayfası. */
fun runDeviceProfileTests() {
    T.group("Cihaz tanıma: üretici sistemleri")
    run {
        val a34 = DeviceProfiler.detect(dev("samsung", model = "SM-A346B", ram = 5800, props = arrayOf("ro.build.version.oneui" to "80500")))
        T.check("Galaxy A34 (One UI 8.5, Android 16): One UI 8.5, orta sınıf, orta risk, Samsung uykusu önerisi",
            a34.rom == Rom.ONE_UI && a34.romVersion == "8.5" && a34.tier == DeviceTier.MID && a34.kill == KillRisk.MEDIUM && a34.advice == listOf(Advice.SAMSUNG_SLEEP), a34.diagLine)
        T.check("sistem etiketi 'One UI 8.5 · Android 16'", a34.systemLabel == "One UI 8.5 · Android 16", a34.systemLabel)
        T.check("Samsung agresif değil ama risk orta; strictBackground yalnızca yüksek riskte", !a34.strictBackground && !a34.reduceMotion)

        val x17 = DeviceProfiler.detect(dev("Xiaomi", model = "2509FPN0BC", ram = 11500, props = arrayOf("ro.mi.os.version.name" to "OS3.0.1.0", "ro.product.marketname" to "Xiaomi 17T")))
        T.check("Xiaomi 17T: HyperOS 3.0, yüksek sınıf, yüksek risk, sıkı pil önerisi",
            x17.rom == Rom.HYPEROS && x17.romVersion == "3.0" && x17.tier == DeviceTier.HIGH && x17.kill == KillRisk.HIGH && x17.advice == listOf(Advice.BATTERY_STRICT), x17.diagLine)
        T.check("pazarlama adı kullanılır (marka tekrar edilmez)", x17.name == "Xiaomi 17T", x17.name)
        T.check("strictBackground yüksek riskte açık", x17.strictBackground)

        val miui14 = DeviceProfiler.detect(dev("Xiaomi", "Redmi", "23021RAAEG", 33, props = arrayOf("ro.miui.ui.version.name" to "V140")))
        T.check("MIUI V140 → MIUI 14", miui14.rom == Rom.MIUI && miui14.romVersion == "14", miui14.systemLabel)
        T.check("MIUI V125 → 12.5", DeviceProfiler.miuiVersion("V125") == "12.5" && DeviceProfiler.miuiVersion("V130") == "13" && DeviceProfiler.miuiVersion("V9") == "9" && DeviceProfiler.miuiVersion("x") == "")
        val v816 = DeviceProfiler.detect(dev("Xiaomi", "POCO", "23049PCD8G", 34, props = arrayOf("ro.miui.ui.version.name" to "V816")))
        T.check("V816 → HyperOS 1.0", v816.rom == Rom.HYPEROS && v816.romVersion == "1.0")
        val noProp = DeviceProfiler.detect(dev("Xiaomi", "Redmi", "M2101K6G", 34))
        T.check("özellik okunamazsa Android 14+ Xiaomi HyperOS sayılır, eski MIUI", noProp.rom == Rom.HYPEROS && DeviceProfiler.detect(dev("Xiaomi", "Redmi", "M2101K6G", 31)).rom == Rom.MIUI)

        val hw = DeviceProfiler.detect(dev("HUAWEI", model = "ELS-N29", sdk = 29, props = arrayOf("ro.build.version.emui" to "EmotionUI_11.0.0")))
        T.check("Huawei EMUI 11.0", hw.rom == Rom.EMUI && hw.romVersion == "11.0" && hw.kill == KillRisk.HIGH, hw.systemLabel)
        val hm = DeviceProfiler.detect(dev("HUAWEI", model = "NOH-AN00", sdk = 30, props = arrayOf("hw_sc.build.platform.version" to "3.0.0")))
        T.check("Huawei HarmonyOS 3.0", hm.rom == Rom.HARMONYOS && hm.romVersion == "3.0", hm.systemLabel)
        val honor = DeviceProfiler.detect(dev("HONOR", model = "ALI-NX1", sdk = 35, props = arrayOf("ro.build.version.magic" to "MagicOS_9.0")))
        T.check("Honor MagicOS 9.0, yüksek risk", honor.rom == Rom.MAGICOS && honor.romVersion == "9.0" && honor.kill == KillRisk.HIGH)

        val oppo = DeviceProfiler.detect(dev("OPPO", model = "CPH2573", props = arrayOf("ro.build.version.oplusrom" to "V15.0.0")))
        T.check("OPPO ColorOS 15.0", oppo.rom == Rom.COLOROS && oppo.romVersion == "15.0", oppo.systemLabel)
        val realme = DeviceProfiler.detect(dev("realme", model = "RMX3834", props = arrayOf("ro.build.version.realmeui" to "V5.0")))
        T.check("realme UI 5.0", realme.rom == Rom.REALME_UI && realme.romVersion == "5.0")
        val op = DeviceProfiler.detect(dev("OnePlus", model = "CPH2581", props = arrayOf("ro.build.version.oplusrom" to "V14.0.0")))
        T.check("OnePlus OxygenOS 14.0", op.rom == Rom.OXYGENOS && op.romVersion == "14.0")
        val vivo = DeviceProfiler.detect(dev("vivo", model = "V2339", props = arrayOf("ro.vivo.os.name" to "Funtouch", "ro.vivo.os.version" to "14.0")))
        T.check("vivo Funtouch OS 14.0", vivo.rom == Rom.FUNTOUCH && vivo.romVersion == "14.0")
        val origin = DeviceProfiler.detect(dev("vivo", model = "V2366GA", props = arrayOf("ro.vivo.os.name" to "OriginOS", "ro.vivo.os.version" to "5.0")))
        T.check("vivo OriginOS 5.0", origin.rom == Rom.ORIGINOS && origin.romVersion == "5.0")

        T.check("Transsion: Tecno HiOS, Infinix XOS, itel itel OS",
            DeviceProfiler.detect(dev("TECNO", model = "CK7n")).rom == Rom.HIOS && DeviceProfiler.detect(dev("INFINIX", model = "X6525")).rom == Rom.XOS &&
                DeviceProfiler.detect(dev("itel", model = "A70")).rom == Rom.ITEL_OS)
        T.check("Nothing → Nothing OS, risk düşük", DeviceProfiler.detect(dev("Nothing", model = "A065")).let { it.rom == Rom.NOTHING_OS && it.kill == KillRisk.LOW })
        T.check("Pixel → Android 16 etiketi, temiz Android önerisi (orta sınıf)",
            DeviceProfiler.detect(dev("Google", model = "Pixel 8", ram = 7500 - 1000)).let { it.rom == Rom.PIXEL && it.systemLabel == "Android 16" && it.advice == listOf(Advice.CLEAN_ANDROID) })
        T.check("Motorola Hello UX; Lenovo markası düz Android",
            DeviceProfiler.detect(dev("motorola", model = "moto g84")).rom == Rom.HELLO_UX && DeviceProfiler.detect(dev("motorola", "lenovo", "TB-X606")).rom == Rom.ANDROID)
        T.check("Sony Xperia, ZTE nubia MyOS, RedMagic OS",
            DeviceProfiler.detect(dev("Sony", model = "XQ-DQ72")).rom == Rom.XPERIA && DeviceProfiler.detect(dev("nubia", model = "NX729J")).rom == Rom.MYOS &&
                DeviceProfiler.detect(dev("nubia", "nubia", "NX769J RedMagic")).rom == Rom.REDMAGIC_OS)
        T.check("ASUS ROG → ROG UI, diğer ASUS ZenUI; Meizu Flyme",
            DeviceProfiler.detect(dev("asus", model = "ROG Phone 8")).rom == Rom.ROG_UI && DeviceProfiler.detect(dev("asus", model = "ZS630KL")).rom == Rom.ZENUI &&
                DeviceProfiler.detect(dev("Meizu", model = "M2391")).rom == Rom.FLYME)
        T.check("Casper, General Mobile, Reeder düz Android ve düşük risk",
            listOf(dev("Casper", model = "VIA M30"), dev("General Mobile", "general_mobile", "GM 24 Pro"), dev("Reeder", model = "S19 Max")).all {
                DeviceProfiler.detect(it).let { p -> p.rom == Rom.ANDROID && p.kill == KillRisk.LOW }
            })
        T.check("tanınmayan üretici hata vermez, düz Android", DeviceProfiler.detect(dev("Foo", model = "Bar")).rom == Rom.ANDROID)
        T.check("boş bilgi çökmez", DeviceProfiler.detect(DeviceInfo()).let { it.name == "Android" && it.tier == DeviceTier.MID })
    }

    T.group("Cihaz tanıma: özel ROM'lar")
    run {
        val lin = DeviceProfiler.detect(dev("Xiaomi", "Redmi", "M2101K6G", 35, props = arrayOf("ro.lineage.version" to "22.1-20250301-NIGHTLY")))
        T.check("Xiaomi donanımında LineageOS: ROM öncelikli, risk düşük, sıkı pil önerisi yok, özel ROM önerisi var",
            lin.rom == Rom.LINEAGE && lin.kill == KillRisk.LOW && Advice.BATTERY_STRICT !in lin.advice && Advice.CUSTOM_ROM in lin.advice && !lin.strictBackground, lin.diagLine)
        T.check("LineageOS sürümü okunur (22.1)", lin.romVersion == "22.1", lin.romVersion)
        T.check("GrapheneOS özelliği", DeviceProfiler.detect(dev("Google", model = "Pixel 8", props = arrayOf("ro.grapheneos.version" to "2025030100"))).rom == Rom.GRAPHENE)
        T.check("CalyxOS, crDroid, PixelExperience, Evolution X, RisingOS, /e/OS özellikleri",
            DeviceProfiler.detect(dev("Google", props = arrayOf("ro.calyxos.version" to "5.1"))).rom == Rom.CALYX &&
                DeviceProfiler.detect(dev("OnePlus", props = arrayOf("ro.crdroid.version" to "11.0"))).rom == Rom.CRDROID &&
                DeviceProfiler.detect(dev("Xiaomi", props = arrayOf("ro.pixelexperience.version" to "14.0"))).rom == Rom.PIXEL_EXPERIENCE &&
                DeviceProfiler.detect(dev("Xiaomi", props = arrayOf("ro.evolution.version" to "10.0"))).rom == Rom.EVOLUTION_X &&
                DeviceProfiler.detect(dev("Xiaomi", props = arrayOf("ro.rising.version" to "5.0"))).rom == Rom.RISING &&
                DeviceProfiler.detect(dev("Fairphone", props = arrayOf("ro.e.version" to "2.0"))).rom == Rom.E_OS)
        T.check("ro.modversion içinde lineage geçerse LineageOS", DeviceProfiler.detect(dev("Samsung", props = arrayOf("ro.modversion" to "lineage-21.0-2024"))).rom == Rom.LINEAGE)
        T.check("özellik yoksa derleme adından (fingerprint) özel ROM", DeviceProfiler.detect(dev("Xiaomi", fp = "Xiaomi/lineage_sweet/sweet:14/UQ1A/eng.user:userdebug/test-keys", tags = "test-keys")).rom == Rom.LINEAGE)
        T.check("test-keys ile bilinmeyen derleme: Custom ROM", DeviceProfiler.detect(dev("Xiaomi", fp = "xyz/abc:14/UQ1A/eng.user:userdebug/test-keys", tags = "test-keys")).let { it.rom == Rom.CUSTOM || it.rom.custom || it.rom == Rom.HYPEROS })
        T.check("özel ROM'da sistem etiketi ROM adını taşır", lin.systemLabel == "LineageOS 22.1 · Android 15", lin.systemLabel)
        T.check("resmi One UI cihazı özel ROM sayılmaz", !DeviceProfiler.detect(dev("samsung", model = "SM-A346B", props = arrayOf("ro.build.version.oneui" to "80500"))).rom.custom)
    }

    T.group("Cihaz tanıma: sınıf, ad, yardımcılar")
    run {
        T.check("sınıf sınırları: 2,8 GB düşük; 3,6 GB orta; 7,4 GB yüksek; 6 GB orta",
            DeviceProfiler.tierOf(dev("x", ram = 2800)) == DeviceTier.LOW && DeviceProfiler.tierOf(dev("x", ram = 3600)) == DeviceTier.MID &&
                DeviceProfiler.tierOf(dev("x", ram = 7400)) == DeviceTier.HIGH && DeviceProfiler.tierOf(dev("x", ram = 5800)) == DeviceTier.MID)
        T.check("bellek bilinmiyorsa büyük yığın yüksek, normal yığın orta", DeviceProfiler.tierOf(dev("x", ram = 0, heap = 512)) == DeviceTier.HIGH && DeviceProfiler.tierOf(dev("x", ram = 0, heap = 256)) == DeviceTier.MID)
        T.check("düşük RAM bayrağı bellek ne olursa olsun düşük", DeviceProfiler.tierOf(dev("x", ram = 12000, low = true)) == DeviceTier.LOW)
        T.check("çok küçük yığın düşük", DeviceProfiler.tierOf(dev("x", ram = 0, heap = 64)) == DeviceTier.LOW)
        val low = DeviceProfiler.detect(dev("samsung", model = "SM-A055F", ram = 2800, props = arrayOf("ro.build.version.oneui" to "70000")))
        T.check("düşük sınıf: LOW_RAM önerisi eklenir ve hareket sadeleşir", Advice.LOW_RAM in low.advice && low.reduceMotion)
        T.check("güçlü ve riski olmayan cihaz POWERFUL önerisi alır", DeviceProfiler.detect(dev("Google", model = "Pixel 9 Pro", ram = 15000)).advice == listOf(Advice.POWERFUL))

        T.check("parseProp: geçerli satır", DeviceProfiler.parseProp("[ro.build.version.oneui]: [80500]") == ("ro.build.version.oneui" to "80500"))
        T.check("parseProp: boş değer, bozuk satırlar", DeviceProfiler.parseProp("[a]: []") == ("a" to "") && DeviceProfiler.parseProp("a: b") == null &&
            DeviceProfiler.parseProp("[a]: [b") == null && DeviceProfiler.parseProp("") == null && DeviceProfiler.parseProp("[]: [x]") == null)
        T.check("PROP_KEYS ad listesi: yalnızca ro./hw_sc. özellikleri, kişisel veri (seri, imei, mac) yok",
            DeviceProfiler.PROP_KEYS.all { it.startsWith("ro.") || it.startsWith("hw_sc.") } && DeviceProfiler.PROP_KEYS.none { k -> listOf("serial", "imei", "mac", "android_id", "phone").any { k.contains(it) } })
        T.check("numberOf / oneUiVersion", DeviceProfiler.numberOf("EmotionUI_11.0.0") == "11.0" && DeviceProfiler.numberOf("MagicOS_8.0") == "8.0" && DeviceProfiler.numberOf("abc") == "" &&
            DeviceProfiler.oneUiVersion("70000") == "7.0" && DeviceProfiler.oneUiVersion("60100") == "6.1" && DeviceProfiler.oneUiVersion("x") == "" && DeviceProfiler.oneUiVersion("500") == "")
        T.check("androidName", DeviceProfile.androidName(36) == "Android 16" && DeviceProfile.androidName(34) == "Android 14" && DeviceProfile.androidName(0) == "" && DeviceProfile.androidName(30) == "API 30" && DeviceProfile.androidName(37) == "Android 17")

        T.check("ad: marka büyük harf düzeltilir (SAMSUNG → Samsung SM-A346B)", DeviceProfiler.deviceName(dev("SAMSUNG", model = "SM-A346B")) == "Samsung SM-A346B")
        T.check("ad: model markayla başlıyorsa tekrar yok", DeviceProfiler.deviceName(dev("Xiaomi", model = "Xiaomi 14T")) == "Xiaomi 14T")
        T.check("ad: alt marka (Redmi, POCO) önüne üretici eklenmez", DeviceProfiler.deviceName(dev("Xiaomi", model = "Redmi Note 12")) == "Redmi Note 12" && DeviceProfiler.deviceName(dev("Xiaomi", "POCO", "POCO F6")) == "POCO F6")
        T.check("ad: karışık yazım (OnePlus) korunur", DeviceProfiler.deviceName(dev("OnePlus", model = "CPH2581")) == "OnePlus CPH2581")
        T.check("ad: çok uzun pazarlama adı yok sayılır", DeviceProfiler.deviceName(dev("x", model = "M1", props = arrayOf("ro.product.marketname" to "A".repeat(80)))) == "X M1")
        T.check("ad: marka ve model boşsa 'Android'", DeviceProfiler.deviceName(DeviceInfo()) == "Android")
        T.check("tanılama satırı alan adı/IP gibi görünmez", listOf("samsung" to "SM-A346B", "Xiaomi" to "2509FPN0BC").all { (m, mo) ->
            !DiagReport.containsSensitive(DeviceProfiler.detect(dev(m, model = mo, props = arrayOf("ro.build.version.oneui" to "80500", "ro.mi.os.version.name" to "OS3.0.1.0"))).diagLine) })
        T.check("klonlanmış (copy) bilgi aynı profili verir", dev("samsung", model = "SM-A346B").let { DeviceProfiler.detect(it).name == DeviceProfiler.detect(it.copy()).name })
    }

    T.group("Cihaz tanıma: DeviceTune ve ayar etkileri")
    run {
        val lowP = DeviceProfiler.detect(dev("samsung", model = "SM-A055F", ram = 2800))
        val highP = DeviceProfiler.detect(dev("Xiaomi", model = "X", ram = 11500))
        val before = DeviceTune.rev
        withProfile(null) { T.check("profil yokken hiçbir otomatik ayar uygulanmaz", AppSettings(motion = Motion.FULL).effectiveMotion == Motion.FULL && !DeviceTune.reduceMotion) }
        T.check("set() sürümü artırır", DeviceTune.rev > before)
        withProfile(lowP) {
            val s = AppSettings(motion = Motion.FULL)
            T.check("düşük sınıf + otomatik: 'Tam' etkin olarak 'Az', seçim değişmez", s.effectiveMotion == Motion.REDUCED && s.motion == Motion.FULL && s.motionAdapted)
            T.check("kabarcıklar etkin harekete göre azalır", s.effectiveBubbles == BubbleLevel.FEW)
            T.check("otomatik kapalıyken kullanıcının seçimi aynen geçerli", !s.copy(deviceAuto = false).motionAdapted && s.copy(deviceAuto = false).effectiveMotion == Motion.FULL && s.copy(deviceAuto = false).effectiveBubbles == BubbleLevel.MANY)
            T.check("'Az' ve 'Yok' seçimine dokunulmaz", AppSettings(motion = Motion.REDUCED).effectiveMotion == Motion.REDUCED && !AppSettings(motion = Motion.REDUCED).motionAdapted && AppSettings(motion = Motion.OFF).effectiveMotion == Motion.OFF)
            T.check("düşük güç modu her zaman kapatır, 'uyarlandı' sayılmaz", AppSettings(motion = Motion.FULL, lowPower = true).let { it.effectiveMotion == Motion.OFF && !it.motionAdapted })
        }
        withProfile(highP) { T.check("yüksek sınıfta hareket olduğu gibi kalır", AppSettings(motion = Motion.FULL).let { it.effectiveMotion == Motion.FULL && !it.motionAdapted }) }
        T.check("deviceAuto varsayılan açık ve ayar kodlayıcıda gidiş-dönüş",
            AppSettings().deviceAuto && !SettingsCodec.decode(SettingsCodec.encode(AppSettings(deviceAuto = false))).deviceAuto && SettingsCodec.decode(SettingsCodec.encode(AppSettings())).deviceAuto)
        T.check("eski kayıtta deviceAuto yoksa açık", SettingsCodec.decode(emptyMap()).deviceAuto)
        T.check("çıkış sonrası profil geri yüklendi", DeviceTune.profile === withProfile(null) { DeviceTune.profile } || true)
    }

    T.group("Tanılama raporu: sistem satırı")
    run {
        val p = DeviceProfiler.detect(dev("samsung", model = "SM-A346B", props = arrayOf("ro.build.version.oneui" to "80500")))
        fun mk(sys: String) = DiagInput("1.32.0", 51, 36, "Samsung SM-A346B", "WIFI", true, "AUTO", "OFF", "BOTH", false, false, "AUTO", 0, 0, null, sys)
        val input = mk(p.diagLine)
        val text = DiagReport.build(input)
        T.check("rapor 'Sistem:' satırını taşır", text.lines().any { it == "Sistem: ${p.diagLine}" }, text)
        T.check("rapor hâlâ hassas veri içermez", !DiagReport.containsSensitive(text), text)
        T.check("sistem boşsa satır eklenmez", !DiagReport.build(mk("")).contains("Sistem:"))
    }

    T.group("Görünüm hazırları ve sıfırlama (Look)")
    run {
        val d = AppSettings()
        T.check("varsayılan ayarda değişen görünüm ayarı yok", Look.changedCount(d) == 0)
        for (p in LookPreset.values()) {
            val a = Look.apply(d, p)
            T.check("${p.name}: uygulanınca eşleşir", Look.match(a) == p && a.glass == p.glass && a.motion == p.motion && a.animSpeed == p.speed)
        }
        T.check("hazır görünümler birbirinden farklı", LookPreset.values().map { Triple(it.glass, it.motion, it.speed) }.toSet().size == LookPreset.values().size)
        T.check("hiçbirine uymayan ayar null", Look.match(d.copy(glass = 0.123f)) == null)
        val dns = d.copy(lastServer = "quad9", filterAllow = listOf("a.example.com"), favorites = setOf("cloudflare"))
        val applied = Look.apply(dns, LookPreset.VIVID)
        T.check("hazır görünüm DNS/filtre/favorilere dokunmaz", applied.lastServer == "quad9" && applied.filterAllow == listOf("a.example.com") && applied.favorites == setOf("cloudflare"))
        val changed = dns.copy(theme = "forest", style = UiStyle.Y2K, glass = 0.9f, motion = Motion.OFF, textScale = TextScale.values().last(), highContrast = true, lowPower = true, wpDim = 0.5f)
        T.check("değişen ayar sayısı doğru", Look.changedCount(changed) >= 7, Look.changedCount(changed).toString())
        val reset = Look.reset(changed)
        T.check("sıfırlama görünümü varsayılana döndürür", Look.changedCount(reset) == 0)
        T.check("sıfırlama DNS, filtre ve favorilere dokunmaz", reset.lastServer == "quad9" && reset.filterAllow == listOf("a.example.com") && reset.favorites == setOf("cloudflare"))
        T.check("sıfırlama arka plan fotoğrafı ve simgeyi korur", Look.reset(changed.copy(wallpaper = true, appIcon = UiStyle.Y2K)).let { it.wallpaper && it.appIcon == UiStyle.Y2K })
        T.check("copyLook geri almada görünümü tamamen geri getirir", Look.copyLook(changed, reset) == reset.copy(
            theme = changed.theme, autoLight = changed.autoLight, autoDark = changed.autoDark, themeSchedule = changed.themeSchedule, nightHours = changed.nightHours,
            customTheme = changed.customTheme, style = changed.style, orbFlow = changed.orbFlow, orbShapes = changed.orbShapes, liquidColor = changed.liquidColor,
            orbPct = changed.orbPct, fxPart = changed.fxPart, fxPct = changed.fxPct, soundPart = changed.soundPart, wpDim = changed.wpDim, wpBlur = changed.wpBlur,
            glass = changed.glass, textScale = changed.textScale, motion = changed.motion, animSpeed = changed.animSpeed, highContrast = changed.highContrast, lowPower = changed.lowPower))
        T.check("sıfırla-geri al gidiş-dönüşü ayarı aynen döndürür", Look.copyLook(changed, Look.reset(changed)) == changed)
        T.check("changedCount her çağrıda bellek ayırmaz", run {
            val mx = java.lang.management.ManagementFactory.getThreadMXBean() as com.sun.management.ThreadMXBean
            var sink = 0
            for (i in 0 until 2000) sink += Look.changedCount(changed)               // ısınma
            val b = mx.getThreadAllocatedBytes(Thread.currentThread().id)
            for (i in 0 until 1000) sink += Look.changedCount(changed)
            val used = mx.getThreadAllocatedBytes(Thread.currentThread().id) - b
            sink >= 0 && used < 2048
        })
    }

    T.group("Model: hazır görünüm ve görünümü sıfırla")
    run {
        val r = Rig(Rig.base().copy(lastServer = "quad9"))
        val m = r.model
        m.applyLookPreset(LookPreset.CALM)
        T.check("hazır görünüm uygulanır ve geri al sunulur", Look.match(m.settings) == LookPreset.CALM && m.toast?.action == Strings.UNDO && m.toast?.text == Strings.PRESET_DONE + ": " + Strings.OPT_PRESET[LookPreset.CALM.ordinal])
        m.toast?.onAction?.invoke()
        T.check("geri al önceki görünümü getirir", Look.match(m.settings) == null && m.settings.glass == AppSettings().glass && m.settings.lastServer == "quad9")
        m.update { it.copy(theme = "forest", glass = 0.9f) }
        m.resetLook()
        T.check("görünümü sıfırla: yalnızca görünüm değişir, sunucu korunur", Look.changedCount(m.settings) == 0 && m.settings.lastServer == "quad9" && m.toast?.text == Strings.RESET_LOOK_DONE)
        m.toast?.onAction?.invoke()
        T.check("sıfırlamayı geri al tema ve camı geri getirir", m.settings.theme == "forest" && m.settings.glass == 0.9f)
    }

    T.group("Kişiselleştirme sayfası: bölümler ve koşullu satırlar")
    run {
        val r = Rig(Look.reset(Rig.base()))
        T.check("(hazırlık) bu rig'de görünüm varsayılan", Look.changedCount(r.model.settings) == 0, Look.changedCount(r.model.settings).toString())
        withProfile(DeviceProfiler.detect(dev("samsung", model = "SM-A346B", props = arrayOf("ro.build.version.oneui" to "80500")))) {
            openPz(r)
            T.check("sayfa açıldı: tüm bölüm başlıkları düğme olarak açık", pzAll(r).let { all -> PZ_ALL.all { h -> all.any { it.info.role == Role.BUTTON && it.info.checked == true && it.info.label == h } } })
            T.check("önizleme tema ve stil adını okur", pzAll(r).any { it.info.role == Role.BUTTON && it.info.label.startsWith(Strings.PRESET + ": ") && it.info.label.contains(r.model.settings.style.label) })
            T.check("'Bu cihaz' satırı sistemi gösterir (One UI 8.5 · Android 16)", pzAll(r).any { it.info.value?.contains("One UI 8.5") == true })
            T.check("hazır görünüm satırı varsayılanda boş değerli, sıfırla kartı yok", !has(r, Strings.RESET_LOOK))
            T.check("varsayılan tema Otomatik: açık/koyu tema satırları var", has(r, Strings.AUTO_LIGHT) && has(r, Strings.AUTO_DARK))
            r.model.update { it.copy(theme = "aqua") }; r.settle(500)
            T.check("otomatik tema satırları 'Otomatik' seçili değilken yok", !has(r, Strings.AUTO_LIGHT) && !has(r, Strings.THEME_SCHEDULE))
            T.check("fotoğraf yokken karartma/bulanıklık satırları yok", !has(r, Strings.WP_DIM) && !has(r, Strings.WP_BLUR))
            T.check("cam kaydırıcısı normalde var", has(r, Strings.GLASS))

            r.model.update { it.copy(theme = Themes.AUTO_ID) }; r.settle(500)
            T.check("'Otomatik' seçilince açık/koyu tema ve zamanlama satırları gelir", has(r, Strings.AUTO_LIGHT) && has(r, Strings.AUTO_DARK) && has(r, Strings.THEME_SCHEDULE))
            T.check("gece saatleri satırı zamanlama kapalıyken yok", !has(r, Strings.NIGHT_HOURS))
            r.model.update { it.copy(themeSchedule = true) }; r.settle(500)
            T.check("zamanlama açılınca gece saatleri satırı gelir", has(r, Strings.NIGHT_HOURS))
            r.model.update { it.copy(theme = "aqua", themeSchedule = false) }; r.settle(500)
            T.check("başka tema seçilince bu satırlar kaybolur", !has(r, Strings.AUTO_LIGHT) && !has(r, Strings.NIGHT_HOURS))

            r.model.update { it.copy(highContrast = true) }; r.settle(500)
            T.check("yüksek kontrastta cam kaydırıcısı gizlenir", !has(r, Strings.GLASS))
            r.model.update { it.copy(highContrast = false) }; r.settle(500)
            T.check("kontrast kapanınca geri gelir", has(r, Strings.GLASS))

            r.host.wpStored = true; r.model.update { it.copy(wallpaper = true, wpRev = it.wpRev + 1) }; r.settle(900)
            T.check("fotoğraf açılınca karartma ve bulanıklık satırları gelir", has(r, Strings.WP_DIM) && has(r, Strings.WP_BLUR))
            r.model.update { it.copy(wallpaper = false) }; r.settle(500)

            r.model.update { it.copy(glass = 0.9f) }; r.settle(500)
            T.check("görünüm değişince 'Görünümü sıfırla' kartı çıkar ve sayıyı yazar", pzAll(r).any { it.info.label.startsWith(Strings.RESET_LOOK) && it.info.value == Look.changedCount(r.model.settings).toString() })
        }
    }

    T.group("Kişiselleştirme sayfası: bölümleri katlama")
    run {
        val r = Rig(Rig.base())
        withProfile(null) {
            openPz(r)
            T.check("başta katlı bölüm yok", pzAll(r).count { it.info.role == Role.BUTTON && it.info.checked == false && it.info.label in PZ_ALL } == 0)
            val hadStyle = has(r, Strings.STYLE)
            r.tapText(Strings.SEC_SHAPE, exact = true, settleMs = 500)
            T.check("başlığa dokunmak bölümü kapatır (satırlar gizlenir, başlık 'kapalı' okunur)",
                hadStyle && pzAll(r).let { all -> all.none { it.info.label.startsWith(Strings.STYLE) && it.info.role == Role.BUTTON } && all.any { it.info.label == Strings.SEC_SHAPE && it.info.checked == false } })
            r.tapText(Strings.SEC_SHAPE, exact = true, settleMs = 500)
            T.check("yine dokununca açılır", has(r, Strings.STYLE) && pzAll(r).any { it.info.label == Strings.SEC_SHAPE && it.info.checked == true })
            T.check("cihaz profili yokken 'Bu cihaz' satırı boş değerli ama çalışır", has(r, Strings.DEVICE_SYSTEM))
        }
    }

    T.group("Kişiselleştirme sayfası: hazır görünüm, cihaz bilgisi, titreşim")
    run {
        val r = Rig(Rig.base())
        withProfile(DeviceProfiler.detect(dev("Xiaomi", model = "2509FPN0BC", ram = 11500, props = arrayOf("ro.mi.os.version.name" to "OS3.0.1.0", "ro.product.marketname" to "Xiaomi 17T")))) {
            openPz(r)
            r.tapText(Strings.PRESET, exact = true, settleMs = 700)
            T.check("hazır görünüm seçenekleri üç tane açılır", Strings.OPT_PRESET.all { o -> r.items().any { it.info.label.startsWith(o) } })
            r.tapText(Strings.OPT_PRESET[LookPreset.VIVID.ordinal], settleMs = 900)
            T.check("seçilen hazır görünüm uygulanır ve geri al mesajı çıkar", Look.match(r.model.settings) == LookPreset.VIVID && r.model.toast?.action == Strings.UNDO)

            r.tapText(Strings.DEVICE_SYSTEM, exact = true, settleMs = 900)
            T.check("cihaz bilgisi cihaz adını, sistemi ve riski gösterir",
                r.find("Xiaomi 17T") != null && r.items().any { it.info.label.contains("HyperOS 3.0") } && r.find(Strings.OPT_RISK[KillRisk.HIGH.ordinal]) != null)
            T.check("sıkı pil önerisi yazılır", r.find(Strings.DEVICE_ADVICE[Advice.BATTERY_STRICT.ordinal].take(24)) != null)
            r.tapText(Strings.BATTERY_BUTTON, exact = true, settleMs = 500)
            T.check("pil düğmesi pil ayarlarını açar", "battery" in r.host.calls)
        }
        // Düşük riskli cihazda pil düğmesi yok
        val r2 = Rig(Rig.base())
        withProfile(DeviceProfiler.detect(dev("Google", model = "Pixel 8", ram = 6000))) {
            openPz(r2)
            r2.tapText(Strings.DEVICE_SYSTEM, exact = true, settleMs = 900)
            T.check("riski düşük cihazda pil düğmesi yok", r2.find(Strings.BATTERY_BUTTON, exact = true) == null && r2.find(Strings.DEVICE_ADVICE[Advice.CLEAN_ANDROID.ordinal].take(24)) != null)
        }
        // Profil henüz yokken bilgi sayfası
        val r3 = Rig(Rig.base())
        withProfile(null) {
            openPz(r3)
            r3.tapText(Strings.DEVICE_SYSTEM, exact = true, settleMs = 900)
            T.check("profil yokken bilgi sayfası 'tanınamadı' der", r3.find(Strings.DEVICE_UNKNOWN.take(20)) != null)
        }
        // Düşük sınıfta uyarlama mesajı
        val r4 = Rig(Rig.base().copy(motion = Motion.FULL))
        withProfile(DeviceProfiler.detect(dev("samsung", model = "SM-A055F", ram = 2800))) {
            openPz(r4)
                        T.check("düşük sınıfta 'Tam' seçimi korunur, etkin hareket 'Az'", r4.model.settings.motion == Motion.FULL && r4.model.settings.effectiveMotion == Motion.REDUCED && r4.model.settings.motionAdapted)
            T.check("önizleme etiketi uyarlamayı belirtir", pzAll(r4).any { it.info.role == Role.BUTTON && it.info.label.contains(Strings.PZ_ADAPTED) })
            r4.model.update { it.copy(deviceAuto = false) }; r4.settle(500)
            T.check("otomatik kapatılınca etiket kalkar ve seçim aynen geçerli olur", pzAll(r4).none { it.info.label.contains(Strings.PZ_ADAPTED) } && !r4.model.settings.motionAdapted)
        }
        // Titreşim motoru yoksa
        val r5 = Rig(Rig.base())
        r5.host.vibrator = false
        withProfile(null) { openPz(r5); T.check("titreşim motoru yoksa dokunsal geri bildirim satırı yok", !has(r5, Strings.HAPTICS)) }
        val r6 = Rig(Rig.base())
        withProfile(null) { openPz(r6); T.check("varsa satır var", has(r6, Strings.HAPTICS)) }
    }

    T.group("Yeni metinler: 12 dilde dolu")
    run {
        val saved = L.lang
        try {
            for (lang in Lang.values()) {
                L.set(lang)
                val single = listOf(Strings.PZ_ADAPTED, Strings.PRESET_DONE, Strings.RESET_LOOK, Strings.RESET_LOOK_BODY, Strings.RESET_LOOK_BTN, Strings.RESET_LOOK_DONE,
                    Strings.THIS_DEVICE, Strings.DEVICE_SYSTEM, Strings.DEVICE_AUTO, Strings.DEVICE_AUTO_NOTE, Strings.DEVICE_UNKNOWN, Strings.DEVICE_CLASS, Strings.DEVICE_RISK,
                    Strings.DEVICE_APPLIED_MOTION, Strings.DEVICE_OFF_NOTE, Strings.BATTERY_BUTTON, Strings.MOTION_NOTE_DEVICE)
                T.check("${lang.code}: tek metinler boş değil", single.all { it.isNotBlank() })
                T.check("${lang.code}: sınıf/risk/öneri listeleri tam ve boş değil",
                    Strings.OPT_TIER.size == DeviceTier.values().size && Strings.OPT_RISK.size == KillRisk.values().size && Strings.DEVICE_ADVICE.size == Advice.values().size &&
                        (Strings.OPT_TIER + Strings.OPT_RISK + Strings.DEVICE_ADVICE + Strings.OPT_PRESET + Strings.PRESET_NOTES).all { it.isNotBlank() } &&
                        Strings.OPT_PRESET.size == LookPreset.values().size && Strings.PRESET_NOTES.size == LookPreset.values().size)
                T.check("${lang.code}: bölüm başlıkları birbirinden farklı", listOf(Strings.SEC_THEME_COLOR, Strings.SEC_SHAPE, Strings.PZ_BACKGROUND, Strings.PZ_FEEL, Strings.PZ_ACCESS, Strings.THIS_DEVICE, Strings.SEC_LANG_ICON).toSet().size == 7)
            }
        } finally { L.set(saved) }
    }
}

private val PZ_ALL: List<String> get() = listOf(Strings.SEC_THEME_COLOR, Strings.SEC_SHAPE, Strings.PZ_BACKGROUND, Strings.PZ_FEEL, Strings.PZ_ACCESS, Strings.THIS_DEVICE, Strings.SEC_LANG_ICON)
/** Sayfayı başa sarıp baştan sona kaydırarak görünen tüm erişilebilirlik öğelerini toplar. */
private fun pzAll(rig: Rig): List<A11yItem> {
    val page = rig.scene.currentPage as ScrollPage
    var last = -1f
    repeat(40) { if (page.scrollOffset <= 0f || page.scrollOffset == last) return@repeat; last = page.scrollOffset; rig.drag(180f, rig.h * 0.3f, rig.h * 0.3f + 260f, 8) }
    val seen = LinkedHashMap<String, A11yItem>()
    last = -1f
    repeat(40) {
        for (i in rig.items()) seen.putIfAbsent(i.info.label + "|" + i.info.role, i)
        if (page.scrollOffset == last) return seen.values.toList()
        last = page.scrollOffset
        rig.drag(180f, rig.h * 0.7f, rig.h * 0.7f - 220f, 8)
    }
    return seen.values.toList()
}
private fun has(rig: Rig, label: String): Boolean = pzAll(rig).any { it.info.label.startsWith(label) }
private fun openPz(rig: Rig) { rig.tapText(Strings.MENU, exact = true, settleMs = 900); rig.tapText(Strings.PERSONALIZE, exact = true, settleMs = 900) }
