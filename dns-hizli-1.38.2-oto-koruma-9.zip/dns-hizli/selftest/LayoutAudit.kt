package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

/** Çizilen yazıları toplar: ekrandan taşan ve "…" ile kısaltılan yazıları bulmak için. */
private class TextCapture(val w: Float) : CountingGfx() {
    val out = ArrayList<String>()
    val cut = LinkedHashSet<String>()
    override fun text(s: String, x: Float, baseline: Float, size: Float, bold: Boolean, align: Int) {
        super.text(s, x, baseline, size, bold, align)
        val tw = textWidth(s, size, bold)
        val l = when (align) { app.dnshizli.core.ALIGN_LEFT -> x; app.dnshizli.core.ALIGN_RIGHT -> x - tw; else -> x - tw / 2f }
        if (l < -1f || l + tw > w + 1f) out.add("${s.take(30)} [${l.toInt()}..${(l + tw).toInt()}]")
        if (s.endsWith("…") || s.endsWith("...")) cut.add(s.take(40) + "@" + x.toInt() + "," + baseline.toInt() + "/" + size.toInt())
    }
}

/**
 * Yerleşim denetimi: her ayar sayfası x 12 dil x büyük yazı x dar ekran. Etkileşimli öğeler ekrandan taşmaz, dokunma hedefi yeterince
 * büyüktür (>= 44), iki etkileşimli öğe üst üste binmez.
 */
private fun checkScreen(tag: String, rig: Rig, w: Int, verbose: Boolean, lang: String, scale: Float) {
    val seen = LinkedHashMap<String, A11yItem>()
    val cap = TextCapture(w.toFloat())
    val page = rig.scene.currentPage as? ScrollPage
    var last = -1f
    repeat(60) {
        for (i in rig.items()) { val k = i.info.label + "|" + i.info.role; val o = seen[k]; if (o == null || (i.b - i.t) > (o.b - o.t)) seen[k] = i }
        cap.reset(); rig.draw(cap)
        if (page == null || page.scrollOffset == last) return@repeat
        last = page.scrollOffset
        rig.drag(rig.w / 2f, rig.h * 0.7f, rig.h * 0.7f - 220f, 8)
    }
    val inter = seen.values.filter { it.info.role == Role.BUTTON || it.info.role == Role.SWITCH || it.info.role == Role.SLIDER }
    val over = inter.filter { it.l < -0.5f || it.r > w + 0.5f }
    T.check("[$tag] taşma yok", over.isEmpty(), over.take(3).joinToString { "${it.info.label.take(24)}@${it.l.toInt()}..${it.r.toInt()}" })
    T.check("[$tag] yazı ekrandan taşmaz", cap.out.isEmpty(), cap.out.take(3).joinToString())
    val isSheet = tag in setOf("ayrıntı", "test", "öneri", "bilgi-sayfası")   // panel içeriği kaydırılamadan kırpılır: alttaki satır yarım görünür
    val small = if (isSheet) emptyList() else inter.filter { (it.b - it.t) >= 20f && (it.b - it.t + 2f * it.node.hitSlop) < 43.5f && it.info.role != Role.SLIDER && !it.info.label.startsWith(Strings.BACK) }
    T.check("[$tag] dokunma hedefi >= 43", small.isEmpty(), small.take(3).joinToString { "${it.info.label.take(24)} h=${(it.b - it.t).toInt()}+${(2f * it.node.hitSlop).toInt()}" })
    if (verbose && cap.cut.isNotEmpty()) println("  ? kısaltılan [$lang $tag x$scale]: " + cap.cut.take(8).joinToString(" | "))
}

fun runLayoutAudit() {
    val pages: List<Pair<String, () -> String>> = listOf<Pair<String, () -> String>>("PERSONALIZE" to { Strings.PERSONALIZE }, "DNS_SETTINGS" to { Strings.DNS_SETTINGS }, "FILTER" to { Strings.FILTER }, "CONN_APPS" to { Strings.CONN_APPS }, "SEC_NOTIF" to { Strings.SEC_NOTIF }, "SEC_LIST" to { Strings.SEC_LIST }, "STATS_HISTORY" to { Strings.STATS_HISTORY }, "SEC_DATA" to { Strings.SEC_DATA }, "SOUND_MOTION" to { Strings.SOUND_MOTION }, "ABOUT" to { Strings.ABOUT })
    val saved = L.lang
    val verbose = System.getenv("AUDIT_VERBOSE") != null
    val onlyLang = System.getenv("AUDIT_LANG")
    try {
        for (lang in Lang.values()) {
            if (onlyLang != null && lang.code != onlyLang) continue
            L.set(lang)
            for ((scale, w) in listOf(1.0f to 360, 1.3f to 320)) {
                T.group("Yerleşim: ${lang.code}, yazı x$scale, ${w}dp")
                fun fresh(): Rig { val r = Rig(Rig.base(), w = w, fontScale = scale); r.model.setLanguage(lang.code); r.settle(600); return r }
                for ((pgName, pgGet) in pages) {
                    val rig = fresh()
                    rig.tapText(Strings.MENU, exact = true, settleMs = 900)
                    val entry = pgGet()
                    val it0 = rig.items().firstOrNull { it.info.label.startsWith(entry) } ?: rig.reveal(entry)
                    if (it0 == null) { T.check("$pgName bulundu", false, entry); continue }
                    rig.tapItem(it0, 900)
                    checkScreen(entry, rig, w, verbose, lang.code, scale)
                }
                // Ana ekran (bağlı ve bağlı değil), sunucu ayrıntısı, tanılama ve diğer sayfalar
                run { val r = fresh(); checkScreen("ana", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.connectOk(); checkScreen("ana-bağlı", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.scene.openDetails(Catalog.byId("quad9")!!); r.settle(900); checkScreen("ayrıntı", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.scene.openTest(); r.settle(900); checkScreen("test", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.scene.openRecommend(); r.settle(900); checkScreen("öneri", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.scene.openMenu(); r.settle(900); r.scene.openAbout(); r.settle(900); r.scene.openHelp(); r.settle(900); checkScreen("yardım", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.scene.openMenu(); r.settle(900); r.scene.openAbout(); r.settle(900); r.scene.openWhatsNew(); r.settle(900); checkScreen("yenilikler", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.scene.openMenu(); r.settle(900); r.scene.openAbout(); r.settle(900); r.scene.openLog(); r.settle(900); checkScreen("günlük", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.scene.openMenu(); r.settle(900); r.scene.openSection(Section.STATS); r.settle(900); r.scene.openSessions(); r.settle(900); checkScreen("oturumlar", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.scene.openMenu(); r.settle(900); r.scene.openSection(Section.CONNECTION); r.settle(900); r.scene.openApps(); r.settle(900); checkScreen("uygulamalar", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.scene.openMenu(); r.settle(900); r.scene.openPersonalize(); r.settle(900); r.scene.openLiquidColor(); r.settle(900); checkScreen("sıvı rengi", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.scene.openMenu(); r.settle(900); r.scene.openPersonalize(); r.settle(900); r.scene.openCustomStyle(); r.settle(900); checkScreen("kendi stilim", r, w, verbose, lang.code, scale) }
                // 1.33: koşullu satırların açık/kapalı durumları ve katlanmış sayfa
                run { val r = fresh(); r.model.update { it.copy(pzClosed = PzFolds.KEYS.joinToString(",")) }; r.settle(300); r.scene.openMenu(); r.settle(900); r.scene.openPersonalize(); r.settle(900); checkScreen("kişiselleştirme-kapalı", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.model.update { it.copy(theme = Themes.AUTO_ID, themeSchedule = true, wallpaper = true, lowPower = true) }; r.settle(300); r.scene.openMenu(); r.settle(900); r.scene.openPersonalize(); r.settle(900); checkScreen("kişiselleştirme-tüm-satırlar", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.model.update { it.copy(soundOn = false, motion = Motion.OFF) }; r.settle(300); r.scene.openMenu(); r.settle(900); r.scene.openSection(Section.SOUND); r.settle(900); checkScreen("ses-kapalı", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.host.notifAllowed = false; r.scene.openMenu(); r.settle(900); r.scene.openSection(Section.NOTIFICATIONS); r.settle(900); checkScreen("bildirim-izin-kapalı", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.model.update { it.copy(filterLevel = FilterLevel.MEDIUM, autoMeasure = true, encryption = Encryption.AUTO) }; r.settle(300); r.scene.openMenu(); r.settle(900); r.scene.openSection(Section.FILTER); r.settle(900); checkScreen("filtre-açık", r, w, verbose, lang.code, scale) }
                run { val r = fresh(); r.scene.openInfo(Strings.TROUBLE, List(6) { Strings.HELP_WHY_BODY }, Strings.TROUBLE_RECHECK) {}; r.settle(900); checkScreen("bilgi-sayfası", r, w, verbose, lang.code, scale) }
            }
        }
    } finally { L.set(saved) }
}
