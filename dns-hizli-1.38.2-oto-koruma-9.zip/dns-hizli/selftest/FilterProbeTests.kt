package app.dnshizli.selftest

import app.dnshizli.core.FilterLevel
import app.dnshizli.core.FilterNames
import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.FilterVerdict

/** Engelleme eşleştirme kuralları: alt alan, büyük harf, sonda nokta, ad sonu karışıklığı, izin önceliği, çok etiketli adlar. */
fun runFilterProbeTests() {
    T.group("Engelleme: eşleştirme kuralları (sınır durumları)")
    run {
        FilterRuntime.updateNow(FilterLevel.OFF, listOf("izin.ads.com"), listOf("ads.com"))
        val e = FilterRuntime.engine!!
        fun v(s: String) = e.verdictOf(s)
        T.check("kullanıcı engeli alt alanı engeller (x.ads.com)", v("x.ads.com") == FilterVerdict.USER, "${v("x.ads.com")}")
        T.check("büyük harf ve sonda nokta aynı sonucu verir (ADS.COM.)", v("ADS.COM.") == FilterVerdict.USER, "${v("ADS.COM.")}")
        T.check("ek alan adı sonek karışıklığı yapmaz (ads.com.evil.net)", v("ads.com.evil.net") == FilterVerdict.PASS, "${v("ads.com.evil.net")}")
        T.check("etiket sınırı: notads.com engellenmez", v("notads.com") == FilterVerdict.PASS, "${v("notads.com")}")
        T.check("izin, engelin alt alanında önceliklidir (izin.ads.com)", v("izin.ads.com") == FilterVerdict.PASS, "${v("izin.ads.com")}")
        T.check("izin listesi alt alanı da kapsar (a.izin.ads.com)", v("a.izin.ads.com") == FilterVerdict.PASS, "${v("a.izin.ads.com")}")
        T.check("tek etiketli ad engellenmez (ads)", v("ads") == FilterVerdict.PASS)

        // Geçerli uzunlukta (≤253 bayt) çok etiketli ad: sonek sonda kalmalı.
        val deep = (List(120) { "a" } + listOf("x", "ads", "com")).joinToString(".")
        T.check("DNS sınırında (≤253) 123 etiketli adın sonundaki engel yakalanır",
            deep.length <= 253 && v(deep) == FilterVerdict.USER, "uzunluk ${deep.length}, ${v(deep)}")
        val deepMax = (List(123) { "q" }).joinToString(".") + ".ads.com"
        T.check("en çok etiketli geçerli ad (≤253) için engel yakalanır",
            deepMax.length <= 253 && v(deepMax) == FilterVerdict.USER, "uzunluk ${deepMax.length}, ${v(deepMax)}")

        // 253 bayttan uzun ad geçersizdir: normalize reddeder, sonuç PASS.
        val tooLong = (List(130) { "q" }).joinToString(".") + ".ads.com"
        T.check("253 bayttan uzun ad geçersiz sayılır (normalize boş döner)", FilterNames.normalize(tooLong) == null)
        T.check("geçersiz uzun ad PASS döner (taşma yok)", v(tooLong) == FilterVerdict.PASS, "${v(tooLong)}")
    }
}
