package app.dnshizli.selftest

import app.dnshizli.core.Dpi
import app.dnshizli.core.NetKind
import app.dnshizli.core.PlanMemory
import app.dnshizli.core.FilterVerdict
import app.dnshizli.core.SiteCause
import app.dnshizli.core.AppSettings
import app.dnshizli.core.FilterNames
import app.dnshizli.core.SettingsCodec
import app.dnshizli.core.YouTubeAds
import app.dnshizli.core.SiteCheck

/** Ağa göre kalıcı DPI yöntem belleği ve planlayıcıya tohum. */
fun runPlanTests() {
    T.group("Ağa göre DPI belleği")
    run {
        T.check("anahtar: tür + operatör, özel karakterler temizlenir",
            PlanMemory.key(NetKind.MOBILE, "28601") == "MOBILE|28601" && PlanMemory.key(NetKind.WIFI, "a b\u0000x") == "WIFI|abx")
        T.check("anahtar uzunluğu sınırlı (24)", PlanMemory.key(NetKind.MOBILE, "1".repeat(100)).length <= "MOBILE|".length + 24)
        val m = PlanMemory()
        var changes = 0
        m.onChange = { changes++ }
        m.put("MOBILE|28601", Dpi.TLS, 3)
        T.check("kayıt: TLS yöntemi okunur, HTTP bilinmiyor", m.get("MOBILE|28601") == (3 to -1))
        m.put("MOBILE|28601", Dpi.TLS, 3)
        T.check("aynı yöntem tekrar yazılırsa kayıt değişmez (kalıcı yazım yok)", changes == 1)
        m.put("MOBILE|28601", Dpi.HTTP, 2)
        T.check("HTTP yöntemi ayrı tutulur", m.get("MOBILE|28601") == (3 to 2) && changes == 2)
        T.check("bilinmeyen ağ: kayıt yok", m.get("WIFI|") == null)
        val text = m.encode()
        val back = PlanMemory()
        back.decode(text)
        T.check("kodlama gidiş-dönüş aynı kayıtları verir", back.get("MOBILE|28601") == (3 to 2) && back.encode() == text)
        val bad = PlanMemory()
        bad.decode("BOZUK;MOBILE|1=99,1;WIFI|=x,y;wifi|a=1,1;WIFI|ok=2,1")
        T.check("bozuk ve aralık dışı satırlar atlanır, geçerli kalan okunur",
            bad.get("MOBILE|1") == (-1 to 1) && bad.get("WIFI|ok") == (2 to 1) && bad.get("wifi|a") == null && bad.get("BOZUK") == null)
        val capped = PlanMemory(cap = 16)
        for (i in 0 until 20) capped.put("MOBILE|$i", Dpi.TLS, 1)
        T.check("kayıt sayısı sınırlı (en eski düşer)", capped.encode().split(';').size == 16 && capped.get("MOBILE|0") == null && capped.get("MOBILE|19") == (1 to -1))
        T.check("geçersiz anahtarlar kabul edilmez", !PlanMemory.validKey("mobile|1") && !PlanMemory.validKey("MOBILE|" + "a".repeat(25)) && PlanMemory.validKey("MOBILE|28601"))
    }

    T.group("Planlayıcı: öğrenilmiş tohum")
    run {
        val p = Dpi.Planner()
        T.check("tohum yokken varsayılan ilk yöntem", p.first("h1", Dpi.TLS) == Dpi.TLS_ORDER[0])
        p.seed(Dpi.TLS, 5)
        T.check("tohum verilince yeni alan adları o yöntemle başlar", p.first("h2", Dpi.TLS) == 5)
        T.check("tohum HTTP'yi etkilemez", p.first("h2", Dpi.HTTP) == 0)
        p.seed(Dpi.TLS, -1)
        T.check("tohum kaldırılınca varsayılana dönülür", p.first("h3", Dpi.TLS) == Dpi.TLS_ORDER[0])
        p.seed(Dpi.TLS, 4)
        p.forget()
        T.check("sıfırlamada tohum da silinir", p.first("h4", Dpi.TLS) == Dpi.TLS_ORDER[0])
    }

    T.group("Planlayıcı: tükenen hedef belleği ve yeni yöntem sırası")
    run {
        val p = Dpi.Planner()
        T.check("başlangıçta hiçbir hedef tükenmiş değil", !p.isExhausted("x.example", 1000))
        p.exhaust("x.example", 1000)
        T.check("tükenen hedef süre dolana dek tükenmiş sayılır", p.isExhausted("x.example", 1000 + Dpi.EXHAUST_MS - 1))
        T.check("başka hedef etkilenmez", !p.isExhausted("y.example", 1000))
        T.check("süre dolunca bellek temizlenir", !p.isExhausted("x.example", 1000 + Dpi.EXHAUST_MS) && !p.isExhausted("x.example", 1000))
        p.exhaust("z.example", 5); p.forget()
        T.check("sıfırlama tükenme belleğini de siler", !p.isExhausted("z.example", 6))
        val cap = Dpi.Planner()
        for (i in 0 until 400) cap.exhaust("h$i", 0)
        T.check("tükenme belleği sınırlı (en eskiler düşer)", !cap.isExhausted("h0", 1) && cap.isExhausted("h399", 1))
        T.check("TLS sırası her yöntemi tam bir kez içerir", Dpi.TLS_ORDER.sorted() == (0 until Dpi.TLS_PLANS).toList())
        var cur = Dpi.TLS_ORDER[0]; var steps = 1
        while (p.next(Dpi.TLS, cur) >= 0) { cur = p.next(Dpi.TLS, cur); steps++ }
        T.check("TLS zinciri tüm yöntemleri gezip biter", steps == Dpi.TLS_PLANS)
        var h = 0; var hs = 1
        while (p.next(Dpi.HTTP, h) >= 0) { h = p.next(Dpi.HTTP, h); hs++ }
        T.check("HTTP zinciri tüm yöntemleri gezip biter", hs == Dpi.HTTP_PLANS)
        val hello = testHello("alt.alan.ornek.com")
        val parts = Dpi.split(Dpi.TLS, 8, hello, hello.size)
        val firstChunk = String(parts.take(2).fold(ByteArray(0)) { a, x -> a + x.data }, Charsets.ISO_8859_1)
        T.check("yöntem 8: ilk kayıt SNI'yı son noktada keser (alt.alan.ornek | .com)", firstChunk.contains("alt.alan.ornek") && !firstChunk.contains("alt.alan.ornek.com"))
        T.check("yöntem 9 ve 10: yalnızca son parça gecikmeli", Dpi.split(Dpi.TLS, 9, hello, hello.size).let { l -> l.last().delayMs == Dpi.DELAY_MS && l.dropLast(1).all { it.delayMs == 0 } } &&
            Dpi.split(Dpi.TLS, 10, hello, hello.size).let { l -> l.last().delayMs == Dpi.DELAY_MS && l.dropLast(1).all { it.delayMs == 0 } })
        T.check("gecikmesiz yöntemlerde hiçbir parça gecikmeli değil", (0..8).all { pl -> Dpi.split(Dpi.TLS, pl, hello, hello.size).all { it.delayMs == 0 } })
    }
}

/** "Site neden açılmıyor?" teşhisi (saf mantık). */
fun runSiteCheckTests() {
    T.group("Site teşhisi")
    run {
        val bad = SiteCheck.diagnose(null, true, -1, false, false)
        T.check("geçersiz ad: giriş hatası", bad.cause == SiteCause.BAD_NAME && bad.name == null)
        T.check("bağlantı kapalıyken önce bu söylenir", SiteCheck.diagnose("a.com", false, FilterVerdict.LIST, false, false).cause == SiteCause.VPN_OFF)
        T.check("kullanıcı engeli listeden önce gelir", SiteCheck.diagnose("a.com", true, FilterVerdict.USER, false, false).cause == SiteCause.USER_BLOCK)
        T.check("reklam listesi engeli", SiteCheck.diagnose("ads.a.com", true, FilterVerdict.LIST, false, false).cause == SiteCause.LIST_BLOCK)
        T.check("kanarya ad açıklanır", SiteCheck.diagnose("use-application-dns.net", true, FilterVerdict.CANARY, false, false).cause == SiteCause.CANARY)
        T.check("şifreli DNS sağlayıcısı kapatılıyorsa söylenir", SiteCheck.diagnose("dns.google", true, FilterVerdict.PASS, false, true).cause == SiteCause.DOH_BLOCK)
        T.check("şifreli DNS engeli kapalıysa sağlayıcı normal", SiteCheck.diagnose("dns.google", true, FilterVerdict.PASS, false, false).cause == SiteCause.NOT_OURS)
        T.check("izin verilmiş ve engellenmeyen ad", SiteCheck.diagnose("b.com", true, FilterVerdict.PASS, true, false).cause == SiteCause.ALLOWED)
        T.check("hiçbiri değilse sorun bizden değil", SiteCheck.diagnose("c.com", true, FilterVerdict.PASS, false, false).cause == SiteCause.NOT_OURS)
        T.check("motor yoksa (-1) engel yok sayılır", SiteCheck.diagnose("d.com", true, -1, false, false).cause == SiteCause.NOT_OURS)
    }
}

/** YouTube reklam listesi: içerik sunucuları asla engellenmez; yalnızca kişisel sürüm ve açıkken eklenir. */
fun runYouTubeAdsTests() {
    T.group("YouTube reklam listesi")
    run {
        val content = listOf("googlevideo.com", "youtube.com", "www.youtube.com", "youtubei.googleapis.com", "i.ytimg.com")
        T.check("listede içerik sunucusu yok (videolar açılmaya devam eder)",
            YouTubeAds.HOSTS.none { h -> content.any { c -> h == c || h.endsWith(".$c") || h.contains("googlevideo") || h.contains("youtubei") } })
        T.check("listedeki adlar geçerli alan adı biçiminde", YouTubeAds.HOSTS.all { FilterNames.normalize(it) == it })
        val base = AppSettings(filterBlock = listOf("a.com"))
        T.check("varsayılan kapalı: liste değişmez", YouTubeAds.blockFor(base, true) == listOf("a.com") && !AppSettings().youtubeAds)
        val on = base.copy(youtubeAds = true)
        T.check("açık ve kişisel: YouTube adları eklenir, kullanıcı listesi korunur", YouTubeAds.blockFor(on, true) == listOf("a.com") + YouTubeAds.HOSTS)
        T.check("açık olsa da Play sürümünde (kişisel değil) eklenmez", YouTubeAds.blockFor(on, false) == listOf("a.com"))
        T.check("ayar dışa aktarmada gidiş-dönüş korunur", SettingsCodec.decode(SettingsCodec.encode(on)).youtubeAds)
    }
}
