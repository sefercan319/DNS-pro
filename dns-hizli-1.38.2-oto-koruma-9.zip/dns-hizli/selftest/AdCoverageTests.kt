package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File

/**
 * Reklam engeli kapsamı (1.30.0): yeni kaynaklar (GoodbyeAds, turk-adlist, AdGuard CNAME izleyicileri), derleme anında
 * çıkarılan kırıcı girdiler, korunan bildirim altyapısı ve "son izin verilenler" listesi.
 */
fun runAdCoverageTests() {
    val dir = File("app/src/main/assets/filter")
    val tiers = listOf("basic.bin", "medium.bin", "strict.bin").map { FilterTier.read(File(dir, it).inputStream().buffered()) }
    val prot = FilterEngine.toTier(File(dir, "protected.txt").readLines().map { it.substringBefore('#').trim() }.filter { it.isNotEmpty() })
    val lv = (1..3).map { FilterEngine(tiers.take(it), prot, emptyList(), emptyList()) }
    fun blocked(level: Int, n: String) = lv[level].verdictOf(n) != FilterVerdict.PASS

    T.group("Reklam kapsamı: Türkçe sitelerin reklam sunucuları Basit seviyede")
    val turk = listOf("ad1.tmgrup.com.tr", "ad5.tmgrup.com.tr", "ads-rouge.haber7.com", "adplus.yaani.com.tr", "hepsiads-bff.hepsiburada.com",
        "ad.hepsiburada.com", "ads.yenimedya.net", "ads.ihaberadserver.com", "ptreklam.com", "reklamstore.com", "admatic.com.tr", "medyaklik.com")
    for (n in turk) T.check("engellenir: $n", blocked(0, n))

    T.group("Reklam kapsamı: mobil reklam SDK'ları ve ağları Basit seviyede")
    val mobile = listOf("googleads.g.doubleclick.net", "pagead2.googlesyndication.com", "a.applovin.com", "auction.unityads.unity3d.com",
        "outcome-ssp.supersonicads.com", "api.vungle.com", "live.chartboost.com", "sdkm.w.inmobi.com", "analytics.rayjump.com",
        "api16-access-sg.pangle.io", "an.yandex.ru", "api.ad.xiaomi.com", "ads.samsung.com", "app.adjust.com", "app-measurement.com")
    for (n in mobile) T.check("engellenir: $n", blocked(0, n))

    T.group("Reklam kapsamı: açılır pencere / yönlendirme ve yabancı reklam ağları Basit seviyede")
    val popup = listOf("popads.net", "propellerads.com", "onclickads.net", "adsterra.com", "exoclick.com", "a-ads.com", "hilltopads.net",
        "clickadu.com", "galaksion.com", "adcash.com", "ad-maven.com", "popcash.net", "revenuehits.com", "juicyads.com", "trafficjunky.com",
        "trafficstars.com", "monetag.com", "richads.com", "zeropark.com", "mgid.com", "adskeeper.com", "revcontent.com", "taboola.com",
        "outbrain.com", "adnxs.com", "criteo.com", "pubmatic.com", "rubiconproject.com", "openx.net", "amazon-adsystem.com", "media.net")
    for (n in popup) T.check("engellenir: $n", blocked(0, n))

    T.group("Reklam kapsamı: hiçbir seviyede bozulmaması gerekenler")
    val must = listOf("google.com", "www.youtube.com", "i.ytimg.com", "rr3---sn-4g5e6nsz.googlevideo.com", "youtubei.googleapis.com",
        "fcm.googleapis.com", "fcmtoken.googleapis.com", "firebaseinstallations.googleapis.com", "mtalk.google.com", "api.onesignal.com",
        "web.whatsapp.com", "mmg.whatsapp.net", "www.instagram.com", "scontent.cdninstagram.com", "pbs.twimg.com",
        "www.trendyol.com", "cdn.dsmcdn.com", "www.hepsiburada.com", "www.sahibinden.com", "www.sabah.com.tr", "isbh.tmgrup.com.tr",
        "www.hurriyet.com.tr", "www.sozcu.com.tr", "ae01.alicdn.com", "ssl.p.jwpcdn.com", "code.createjs.com", "a1.mzstatic.com",
        "www.turkiye.gov.tr", "www.garantibbva.com.tr", "www.trtizle.com", "iplocation-api.wp.trt.com.tr", "www.netflix.com", "open.spotify.com")
    for (n in must) T.check("geçer (her seviyede): $n", (0..2).none { blocked(it, n) }, (0..2).map { blocked(it, n) }.toString())

    T.group("Reklam kapsamı: CNAME gizli izleyicileri Orta seviyede")
    // AdGuard listesindeki gizlenmiş izleyici hedefleri (birinci taraf gibi görünen alt alan adlarının CNAME hedefleri)
    T.check("Orta en az bir CNAME izleyici hedefini kapsıyor", listOf("eulerian.net", "at-o.net", "omtrdc.net", "wizaly.com", "dnsdelegation.io", "a.tribalfusion.com").any { blocked(1, it) })

    T.group("Reklam kapsamı: kaynak ve lisans bildirimi")
    val notes = File(dir, "KAYNAKLAR.txt").readText()
    T.check("GoodbyeAds (MIT) bildirimi", notes.contains("GoodbyeAds") && notes.contains("Jerry Joseph"))
    T.check("turk-adlist (CC BY-SA 3.0) bildirimi ve aynı lisansla paylaşım notu", notes.contains("turk-adlist") && notes.contains("CC BY-SA 3.0") && notes.contains("aynı lisansla"))
    T.check("AdGuard CNAME (MIT) bildirimi", notes.contains("cname-trackers") && notes.contains("Adguard Software Ltd"))
    T.check("EasyList/EasyPrivacy (CC BY-SA 3.0) bildirimi ve atıf", notes.contains("The EasyList authors") && notes.contains("easylist.to") && notes.contains("EasyPrivacy"))
    T.check("Basit katman büyüdü (en az 450 bin ad)", tiers[0].size >= 450_000, tiers[0].size.toString())

    T.group("Son izin verilenler: yalnızca bellekte, sınırlı, kullanıcıya engelleme için")
    FilterLive.keep(true); FilterLive.clear()
    FilterLive.notePassed("cdn.example.com"); FilterLive.notePassed("ads.example.net"); FilterLive.notePassed("cdn.example.com")
    val p = FilterLive.recentPassed()
    T.check("en yeni başta, tekrar eden ad başa taşınır ve sayılır", p.map { it.name } == listOf("cdn.example.com", "ads.example.net") && p[0].count == 2)
    FilterLive.notePassed("1.0.168.192.in-addr.arpa"); FilterLive.notePassed("localhost"); FilterLive.notePassed("printer.local")
    T.check("ters arama, tek etiketli ve .local adlar alınmaz", FilterLive.recentPassed().size == 2)
    FilterLive.notePassed("kotu\u0001ad.example.com")
    T.check("görünmez karakterler '?' olur", FilterLive.recentPassed()[0].name == "kotu?ad.example.com")
    for (i in 0 until 100) FilterLive.notePassed("a$i.example.org")
    T.check("en çok 60 ad tutulur", FilterLive.recentPassed().size == 60)
    FilterLive.forgetPassed("a99.example.org")
    T.check("engellenen ad listeden çıkar", FilterLive.recentPassed().none { it.name == "a99.example.org" })
    FilterLive.keep(false)
    T.check("'Geçmişi tut' kapatılınca liste silinir", FilterLive.recentPassed().isEmpty())
    FilterLive.notePassed("x.example.com")
    T.check("'Geçmişi tut' kapalıyken ad tutulmaz", FilterLive.recentPassed().isEmpty())
    FilterLive.keep(true); FilterLive.notePassed("y.example.com"); FilterLive.clear()
    T.check("bağlantı kesilince (clear) silinir", FilterLive.recentPassed().isEmpty())

    T.group("Son izin verilenler: süzgeç yolu")
    val eng = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("ads.example.com"))
    val qPass = Dns.buildQuery(1, "site.example.org")
    T.check("geçen sorgu adı okunur", eng.verdict(qPass, 0, qPass.size) == FilterVerdict.PASS && eng.lastNameRead && eng.lastName() == "site.example.org")
    val bad = qPass.copyOf().also { Packets.put16(it, 4, 0) }
    eng.verdict(bad, 0, bad.size)
    T.check("ad okunamayan sorguda önceki ad kullanılmaz", !eng.lastNameRead)

    T.group("Şüpheli ad işaretleme (yalnızca öne çıkarır, engellemez)")
    val sus = listOf("0017c6c37c.com", "ads.ornekhaber.com", "popunder.example.net", "krmwbimfpndwui.top", "x7k2m9qp.com",
        "track.example.cfd", "cdn-ads.izleme-sitesi.com", "reklam.ornek.com.tr", "go.smartlink-offers.xyz", "adserver.film.org")
    for (n in sus) T.check("şüpheli: $n", AdSuspect.isSuspect(n), AdSuspect.score(n).toString())
    val fine = listOf("www.google.com", "www.youtube.com", "rr3---sn-4g5e6nsz.googlevideo.com", "i.ytimg.com", "www.trendyol.com",
        "cdn.dsmcdn.com", "www.hepsiburada.com", "www.sahibinden.com", "eksisozluk.com", "www.webtekno.com", "web.whatsapp.com",
        "scontent.cdninstagram.com", "pbs.twimg.com", "www.netflix.com", "open.spotify.com", "www.turkiye.gov.tr",
        "www.garantibbva.com.tr", "fcm.googleapis.com", "cdnjs.cloudflare.com", "github.com", "www.wikipedia.org",
        "www.sabah.com.tr", "www.hurriyet.com.tr", "www.ntv.com.tr", "www.amazon.com.tr", "m.media-amazon.com")
    for (n in fine) T.check("şüpheli değil: $n", !AdSuspect.isSuspect(n), AdSuspect.score(n).toString())

    T.group("Sıkı seviye: riskli uzantılar")
    val strictT = FilterEngine(tiers, prot, emptyList(), emptyList(), riskyTlds = true)
    T.check("riskli uzantılı adlar engellenir", listOf("x7k2.cfd", "a.b.cyou", "go.offers.icu", "promo.sbs").all { strictT.verdictOf(it) == FilterVerdict.LIST })
    T.check("yaygın uzantılar etkilenmez", listOf("ornek.com", "ornek.com.tr", "ornek.org", "ornek.net", "ornek.io", "ornek.xyz").all { strictT.verdictOf(it) == FilterVerdict.PASS })
    T.check("Basit/Orta'da riskli uzantı kuralı yok", lv[0].verdictOf("x7k2.cfd") == FilterVerdict.PASS && lv[1].verdictOf("x7k2.cfd") == FilterVerdict.PASS)
    val allowT = FilterEngine(tiers, prot, listOf("benimsitem.cfd"), emptyList(), riskyTlds = true)
    T.check("izin listesi riskli uzantıdan önce gelir", allowT.verdictOf("www.benimsitem.cfd") == FilterVerdict.PASS && allowT.verdictOf("baska.cfd") == FilterVerdict.LIST)
    T.check("tek etiketli ad (uzantının kendisi) engellenmez", strictT.verdictOf("cfd") == FilterVerdict.PASS)
    FilterRuntime.source = FilterSource { name -> File(dir, name).inputStream() }
    FilterRuntime.reset(); FilterRuntime.updateNow(FilterLevel.STRICT, emptyList(), emptyList())
    T.check("çalışma zamanında Sıkı seçilince kural etkin", FilterRuntime.engine?.verdictOf("x7k2.cfd") == FilterVerdict.LIST)
    FilterRuntime.reset(); FilterRuntime.updateNow(FilterLevel.MEDIUM, emptyList(), emptyList())
    T.check("Orta seçilince kural kapalı", FilterRuntime.engine?.verdictOf("x7k2.cfd") == FilterVerdict.PASS)
    FilterRuntime.reset()
}
