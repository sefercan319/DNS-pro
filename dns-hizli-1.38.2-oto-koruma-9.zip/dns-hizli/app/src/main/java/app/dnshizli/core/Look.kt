package app.dnshizli.core

/** Hazır görünümler: cam, hareket ve hız tek dokunuşla birlikte ayarlanır. */
enum class LookPreset(val glass: Float, val motion: Motion, val speed: Float, val minText: TextScale? = null) {
    CALM(0.30f, Motion.REDUCED, 0.8f),
    BALANCED(0.55f, Motion.REDUCED, 1f),
    VIVID(0.80f, Motion.FULL, 1f),
    /** Pil dostu: neredeyse opak cam, hareket yok. */
    BATTERY(0.20f, Motion.OFF, 0.8f),
    /** Okunaklı: yoğun cam (arka plan yazıyı bozmaz), az hareket, en az "Büyük" yazı. Daha büyük seçilmiş yazıyı küçültmez. */
    READABLE(0.90f, Motion.REDUCED, 0.8f, TextScale.LARGE),
}

/**
 * Kişiselleştirme sayfasındaki katlanabilir bölümlerin kapalı olanları: "theme,shape,..." biçiminde, her zaman bilinen
 * anahtarlarla ve sabit sırada. Bozuk ya da bilinmeyen kayıt sessizce temizlenir (hepsi açık).
 */
object PzFolds {
    val KEYS = listOf("theme", "shape", "bg", "feel", "access", "device", "lang")

    fun sanitize(raw: String?): String {
        if (raw.isNullOrEmpty() || raw.length > 200) return ""
        val set = raw.split(',').map { it.trim() }.toHashSet()
        return KEYS.filter { it in set }.joinToString(",")
    }

    /** Bellek ayırmaz (her karede sorulur): anahtarlardan hiçbiri ötekinin parçası değildir. */
    fun isClosed(raw: String, key: String): Boolean = raw.contains(key)

    /** [key] kapalıysa açar, açıksa kapatır. */
    fun toggle(raw: String, key: String): String {
        val set = raw.split(',').filter { it.isNotEmpty() }.toHashSet()
        if (!set.remove(key)) set.add(key)
        return KEYS.filter { it in set }.joinToString(",")
    }

    fun closedCount(raw: String): Int = KEYS.count { isClosed(raw, it) }

    /** Hepsi açıksa hepsini kapatır; en az biri kapalıysa hepsini açar. */
    fun toggleAll(raw: String): String = if (closedCount(raw) == 0) KEYS.joinToString(",") else ""
}

/**
 * Görünüm ayarlarının toplu işlemleri (saf mantık). "Görünüm": tema, stil, küre, arka plan, cam, yazı boyutu, hareket.
 * DNS, filtre, ağ, geçmiş ve kullanım ayarlarına dokunulmaz.
 */
object Look {
    fun apply(s: AppSettings, p: LookPreset): AppSettings {
        val t = p.minText
        val scale = if (t != null && s.textScale.factor < t.factor) t else s.textScale
        return s.copy(glass = p.glass, motion = p.motion, animSpeed = p.speed, textScale = scale)
    }

    /** [s] tam olarak hangi hazır görünüme uyuyor (hiçbirine uymuyorsa null)? */
    fun match(s: AppSettings): LookPreset? = LookPreset.values().firstOrNull { it.glass == s.glass && it.motion == s.motion && it.speed == s.animSpeed }

    /** [from]'daki görünüm alanlarını [to]'ya yazar; diğer tüm ayarlar [to]'da kalır. */
    fun copyLook(from: AppSettings, to: AppSettings): AppSettings = to.copy(
        theme = from.theme, autoLight = from.autoLight, autoDark = from.autoDark, themeSchedule = from.themeSchedule, nightHours = from.nightHours,
        customTheme = from.customTheme, style = from.style, orbFlow = from.orbFlow, orbShapes = from.orbShapes, liquidColor = from.liquidColor,
        orbPct = from.orbPct, fxPart = from.fxPart, fxPct = from.fxPct, soundPart = from.soundPart,
        wpDim = from.wpDim, wpBlur = from.wpBlur,
        glass = from.glass, textScale = from.textScale, motion = from.motion, animSpeed = from.animSpeed,
        highContrast = from.highContrast, lowPower = from.lowPower,
    )

    /** Görünüm alanlarını varsayılana döndürür. Fotoğraf, uygulama simgesi ve diğer ayarlar korunur. */
    fun reset(s: AppSettings): AppSettings = copyLook(DEFAULTS, s)

    private val DEFAULTS = AppSettings()

    /** Görünüm alanlarından kaçı varsayılandan farklı? Her karede sorulabilir: bellek ayırmaz. */
    fun changedCount(s: AppSettings): Int {
        val d = DEFAULTS
        var n = 0
        if (s.theme != d.theme) n++
        if (s.autoLight != d.autoLight) n++
        if (s.autoDark != d.autoDark) n++
        if (s.themeSchedule != d.themeSchedule) n++
        if (s.nightHours != d.nightHours) n++
        if (s.customTheme != d.customTheme) n++
        if (s.style != d.style) n++
        if (s.orbFlow != d.orbFlow) n++
        if (s.orbShapes != d.orbShapes) n++
        if (s.liquidColor != d.liquidColor) n++
        if (s.orbPct != d.orbPct) n++
        if (s.fxPart != d.fxPart) n++
        if (s.fxPct != d.fxPct) n++
        if (s.soundPart != d.soundPart) n++
        if (s.wpDim != d.wpDim) n++
        if (s.wpBlur != d.wpBlur) n++
        if (s.glass != d.glass) n++
        if (s.textScale != d.textScale) n++
        if (s.motion != d.motion) n++
        if (s.animSpeed != d.animSpeed) n++
        if (s.highContrast != d.highContrast) n++
        if (s.lowPower != d.lowPower) n++
        return n
    }
}
