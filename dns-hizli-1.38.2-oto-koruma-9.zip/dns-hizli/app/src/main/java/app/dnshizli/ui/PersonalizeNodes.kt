package app.dnshizli.ui

import app.dnshizli.core.ALIGN_LEFT
import app.dnshizli.core.ALIGN_RIGHT
import app.dnshizli.core.DeviceTune
import app.dnshizli.core.Gfx
import app.dnshizli.core.Icon
import app.dnshizli.core.Icons
import app.dnshizli.core.Look
import app.dnshizli.core.Rgb
import app.dnshizli.core.TextFit
import app.dnshizli.core.Themes

/**
 * Kişiselleştirme sayfasının tepesindeki canlı önizleme: seçili tema, stil ve küre şekliyle çalışan küçük bir küre, yanında
 * temanın adı, stilin adı (hazır görünüme uyuyorsa onun adı) ve cihaza göre hareket sadeleştirildiyse bunu söyleyen etiket.
 * Sayfadaki her ayar değişince kendiliğinden güncellenir; yazı boyutuna uyar. Dokununca hazır görünümler penceresi açılır.
 */
class LookPreview(private val model: AppModel, private val onTap: () -> Unit = {}) : PressNode() {
    private var title = ""
    private var sub = ""
    private var chip = ""
    private var seen = -1
    private var laidW = -1f
    private var laidFs = 0f
    private var laidRev = -1

    override fun layout(env: Env, maxW: Float) { w = maxW; h = 112f; refresh(env) }

    private fun themeLabel(id: String): String = if (id == Themes.AUTO_ID) Strings.THEME_AUTO else (Themes.byId(id)?.name ?: Strings.themeName(id))

    private fun refresh(env: Env) {
        seen = model.version; laidW = w; laidFs = env.fs; laidRev = DeviceTune.rev
        val s = model.settings
        val shown = themeLabel(model.shownThemeId)
        val raw = if (s.theme == Themes.AUTO_ID) Strings.THEME_AUTO + " · " + shown else shown
        val avail = w - 112f - 40f
        title = TextFit.ellipsize(env.metrics, raw, avail, env.sz(18f), true)
        val preset = Look.match(s)?.let { Strings.OPT_PRESET[it.ordinal] }
        val subRaw = s.style.label + (if (preset != null) " · $preset" else "")
        sub = TextFit.ellipsize(env.metrics, subRaw, avail, env.sz(14f), false)
        // Küre neden durgun? Cihaza göre sadeleşme ya da düşük güç modu etiketlenir.
        val chipRaw = if (s.motionAdapted) Strings.PZ_ADAPTED else if (s.lowPower) Strings.LOW_POWER else ""
        chip = if (chipRaw.isEmpty()) "" else TextFit.ellipsize(env.metrics, chipRaw, avail, env.sz(12f), true)
    }

    // Süs animasyonu: kare hızını ambient'e (33 ms) çeker; sahne dinlenince durur.
    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version || laidW != w || laidFs != env.fs || laidRev != DeviceTune.rev) refresh(env)
        return false
    }
    // Hareket kapalıysa (ya da düşük güçte) önizleme kürsü durur: boşuna kare çizilmez.
    override fun ambient(env: Env): Boolean = env.ambient && env.motion > 0f

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(); onTap() }
    }

    override fun draw(g: Gfx, env: Env) {
        if (seen != model.version || laidW != w || laidFs != env.fs || laidRev != DeviceTune.rev) refresh(env)
        val art = env.art
        g.save()
        pressScale(g, w / 2f, h / 2f, 0.02f)
        art.card(g, 0f, 0f, w, h, M.CARD_R)
        art.orbShape = model.orbShapeFor(model.shownThemeId)
        art.liquidColor = model.liquidColorArgb
        art.liquidTintAmt = 0f
        art.orb(g, 16f + 40f, h / 2f, 34f, 0.66f, if (env.motion > 0f) env.time * 1.5f else 0f, 0f, 0f, 0f)
        val x = 112f
        val t = env.sz(18f)
        val sm = env.sz(14f)
        val lines = if (chip.isEmpty()) 2 else 3
        val gap = 6f
        val total = t + gap + sm + (if (chip.isEmpty()) 0f else gap + env.sz(12f))
        var y = (h - total) / 2f
        g.paint(env.theme.text)
        g.text(title, x, y + t * 0.85f, t, true, ALIGN_LEFT)
        y += t + gap
        g.paint(env.theme.textSoft)
        g.text(sub, x, y + sm * 0.85f, sm, false, ALIGN_LEFT)
        if (lines == 3) {
            y += sm + gap
            g.paint(env.theme.accent)
            g.text(chip, x, y + env.sz(12f) * 0.85f, env.sz(12f), true, ALIGN_LEFT)
        }
        // Dokununca hazır görünümler açılır: sağdaki ok bunu söyler.
        Icons.draw(g, Icon.CHEVRON, w - 24f, h / 2f, 18f, env.theme.textSoft, 2f)
        g.restore()
    }

    override fun a11y(): A11y = A11y(Strings.PRESET + ": " + listOf(title, sub, chip).filter { it.isNotEmpty() }.joinToString(". "), Role.BUTTON)
}

/**
 * Katlanabilir bölüm başlığı: dokununca altındaki kart açılır/kapanır. Ok, açıkken aşağıyı gösterir. Durum sayfada tutulur
 * ([isOpen], [onToggle]); erişilebilirlikte düğme olarak, açık/kapalı durumuyla okunur.
 *
 * Kapalıyken sağda bölümün özeti görünür ([summary], ör. seçili tema); özet ve başlık sığmazsa özet kısalır, uzun başlık
 * 2 satıra sarılır. Uzun basış tüm bölümleri açar ya da kapatır ([onToggleAll]).
 */
class FoldTitle(
    private val text: String,
    private val isOpen: () -> Boolean,
    private val onToggle: () -> Unit,
    private val summary: (() -> String)? = null,
    private val onToggleAll: (() -> Unit)? = null,
) : PressNode() {
    private val rot = Anim(if (isOpen()) 1f else 0f)
    private var lines: List<String> = listOf(text)
    private var sumShown = ""
    private var laid = false
    private var laidW = -1f
    private var laidFs = 0f
    private var laidOpen = true

    override val longPressable: Boolean get() = onToggleAll != null
    override fun onLongPress(env: Env): Boolean { onToggleAll?.invoke(); return onToggleAll != null }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        relay(env)
        if (!laid) { laid = true; rot.set(if (isOpen()) 1f else 0f) }      // yeniden yerleşimde dönüş animasyonu sıçramasın
    }

    private fun relay(env: Env) {
        laidW = w; laidFs = env.fs; laidOpen = isOpen()
        val fs = env.sz(13f)
        val total = w - 8f - 40f                                   // solda 8, sağda ok için 40
        var avail = total
        sumShown = ""
        val raw = if (!laidOpen) summary?.invoke().orEmpty() else ""
        if (raw.isNotEmpty()) {
            sumShown = TextFit.ellipsize(env.metrics, raw, total * 0.45f, fs, false)
            avail = total - env.metrics.textWidth(sumShown, fs, false) - 12f
        }
        val wrapped = TextFit.wrap(env.metrics, text, avail, fs, true)
        lines = if (wrapped.size <= 2) wrapped else listOf(wrapped[0], TextFit.ellipsize(env.metrics, wrapped[1] + " …", avail, fs, true))
        h = maxOf(M.MIN_TAP, lines.size * fs * 1.25f + 22f)
    }

    override fun tick(dt: Float, env: Env): Boolean {
        val tgt = if (isOpen()) 1f else 0f
        if (rot.target != tgt) { if (env.motion <= 0f) rot.set(tgt) else rot.go(tgt, env.dur(0.18f)) }
        return rot.step(dt) or super.tick(dt, env)
    }

    override fun draw(g: Gfx, env: Env) {
        val fs = env.sz(13f)
        val lh = fs * 1.25f
        val first = h / 2f - (lines.size - 1) * lh / 2f
        g.paint(Rgb.lerp(env.theme.textSoft, env.theme.text, press.value))
        for (i in 0 until lines.size) g.text(lines[i], 8f, first + i * lh + fs * 0.35f + 2f, fs, true, ALIGN_LEFT)
        if (sumShown.isNotEmpty()) {
            g.paint(env.theme.textSoft)
            g.text(sumShown, w - 40f, first + fs * 0.35f + 2f, fs, false, ALIGN_RIGHT)
        }
        g.save()
        g.translate(w - 22f, h / 2f)
        g.rotate(90f * rot.value)
        Icons.draw(g, Icon.CHEVRON, 0f, 0f, 16f, env.theme.textSoft, 2f)
        g.restore()
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(false, app.dnshizli.core.Sfx.SELECT); onToggle() }
    }

    override fun a11y(): A11y {
        val open = isOpen()
        return A11y(text, Role.BUTTON, checked = open, value = if (open) null else summary?.invoke()?.ifEmpty { null }, longClick = onToggleAll != null)
    }
}
