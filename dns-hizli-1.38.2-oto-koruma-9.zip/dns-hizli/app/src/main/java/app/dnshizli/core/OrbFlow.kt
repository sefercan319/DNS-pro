package app.dnshizli.core

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Küre sıvısının 10 hareket biçimi. [offset] normalize yüzey yüksekliğini (-1..1) verir: [u] 0..1 genişlik konumu,
 * [cycles] dalga sayısı (çizici verir), [phase] zamana bağlı evre (radyan). Hepsi saf ve deterministiktir.
 * [CALM] özgün sinüs dalgasıdır: varsayılan görünüm değişmez.
 */
enum class OrbFlow(val id: String, val pace: Float, val gain: Float) {
    /** Özgün sinüs: hız 1, genlik 1. Varsayılan görünüm bu değerlerle değişmez. */
    CALM("calm", 1f, 1f),
    TIDE("tide", 0.7f, 1.2f),
    RIPPLE("ripple", 2.2f, 0.9f),
    SWELL("swell", 1f, 1.3f),
    TWIN("twin", 1.2f, 1.1f),
    TRIANGLE("triangle", 1f, 1.2f),
    SOFT_SQUARE("soft_square", 1.4f, 1.3f),
    BOIL("boil", 2.6f, 0.9f),
    SPIRAL("spiral", 1f, 1.2f),
    STILL("still", 0.6f, 1.6f);

    /**
     * Normalize yüzey yüksekliği (-1..1). [u] 0..1 genişlik konumu, [cycles] dalga sayısı, [phase] zaman evresi (radyan).
     * Evre [pace] ile ölçeklenir; genlik çağıranda [gain] ile çarpılır.
     */
    fun offset(u: Float, cycles: Float, phase: Float): Float {
        val tau = TAU
        val ph = phase * pace
        return when (this) {
            CALM -> sin(tau * cycles * u + ph)
            TIDE -> 0.7f * sin(tau * cycles * 0.6f * u + ph * 0.5f) + 0.3f * sin(tau * cycles * 1.4f * u + ph * 1.2f)
            RIPPLE -> sin(tau * cycles * 2.2f * u + ph * 1.6f) * (0.6f + 0.4f * kotlin.math.cos(tau * u))
            SWELL -> sin(tau * cycles * u + ph) * (0.55f + 0.45f * sin(ph * 0.4f + 1f))
            TWIN -> 0.5f * sin(tau * cycles * u + ph) + 0.5f * sin(tau * cycles * u - ph * 1.3f + 1f)
            TRIANGLE -> {
                val f = cycles * u + ph / tau
                val t = f - kotlin.math.floor(f)
                1f - 4f * abs(t - 0.5f)
            }
            SOFT_SQUARE -> tanh(2.2f * sin(tau * cycles * u + ph)) / TANH_22
            BOIL -> 0.6f * sin(tau * cycles * 4f * u + ph * 3f) + 0.4f * sin(tau * cycles * 7f * u - ph * 2.1f)
            SPIRAL -> sin(tau * cycles * u * (1f + 0.35f * sin(ph * 0.3f)) + ph)
            // Tam genlik: eskiden yalnızca ±0,35 idi, bu yüzden neredeyse hareketsiz görünüyordu.
            STILL -> 0.8f * sin(tau * cycles * 0.7f * u + ph * 0.5f) + 0.2f * sin(tau * cycles * 1.9f * u - ph * 0.8f)
        }
    }

    companion object {
        private const val TAU = 6.2831855f
        private val TANH_22 = tanh(2.2f)

        fun byId(id: String?): OrbFlow? = values().firstOrNull { it.id == id }
    }
}

/**
 * Sıvı hareketine ek olarak küre dokunma/kutlama efektlerinin 4 yeni varyantı ([StyleFx]). Her tasarım stili için ayrı
 * seçilir. 0 = stilin özgün efekti (varsayılan), 1..4 = yeni varyantlar. Ayarda "stil=varyant;…" olarak tutulur.
 */
object FxVariants {
    const val COUNT = 9
    private const val MAX_ENTRIES = 16

    fun decode(s: String?): Map<UiStyle, Int> {
        if (s.isNullOrBlank()) return emptyMap()
        val out = LinkedHashMap<UiStyle, Int>()
        for (part in s.split(';')) {
            val eq = part.indexOf('=')
            if (eq <= 0) continue
            val style = UiStyle.byId(part.substring(0, eq)) ?: continue
            val v = part.substring(eq + 1).toIntOrNull() ?: continue
            if (v in 1 until COUNT && out.size < MAX_ENTRIES) out[style] = v
        }
        return out
    }

    fun encode(m: Map<UiStyle, Int>): String =
        m.entries.filter { it.value in 1 until COUNT }.take(MAX_ENTRIES).sortedBy { it.key.ordinal }
            .joinToString(";") { it.key.id + "=" + it.value }

    fun get(s: String?, style: UiStyle): Int = decode(s)[style] ?: 0

    /** [style] için varyantı [v] yapar; varsayılan (0) kaydı siler. */
    fun with(s: String, style: UiStyle, v: Int): String {
        val m = LinkedHashMap(decode(s))
        if (v in 1 until COUNT) m[style] = v else m.remove(style)
        return encode(m)
    }
}
