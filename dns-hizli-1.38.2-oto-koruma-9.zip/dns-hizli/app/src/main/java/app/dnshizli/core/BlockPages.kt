package app.dnshizli.core

/**
 * Sansürcülerin gerçek adres yerine verdiği adresler: ülkelerin engel sayfaları ve Çin'in güvenlik duvarının enjekte ettiği sahte
 * havuz. Bu adreslerden birini gösteren düz DNS cevabı, nereden gelirse gelsin sahtedir.
 *
 * Kaynak: OONI'nin herkese açık engelleme parmak izleri (github.com/ooni/blocking-fingerprints); derleme olarak Shroudly 2.5.6'nın
 * `electron/censor-fingerprints.js` dosyasından alındı (MIT, (c) 2026 Codeshare Technology Ltd). Bilerek ALINMAYANLAR: ortak bulut
 * adresleri (AWS, Google Cloud, DigitalOcean, Vultr, Hetzner, Cloudflare; yarın gerçek bir siteye atanabilirler, bu yüzden listedeki
 * tek Hetzner adresi de dışarıda bırakıldı) ve DNS süzme hizmetlerinin (AdGuard, OpenDNS, CleanBrowsing…) engel sayfaları: kullanıcı
 * o hizmeti kendisi seçtiyse engellenen siteyi onun gösterdiği sayfa kadar "engelli" saymak doğru olandır, cevabı atmak değil.
 * Özel ve ayrılmış adresler zaten başka yerde reddedilir.
 *
 * Yalnızca düz DNS (UDP/53) cevaplarında bakılır: şifreli DNS'te (DoT/DoH/ODoH) cevabı ağ değiştiremez.
 * Liste zamanla eskir; gerçek bir siteye ait bir adres yanlışlıkla listede kalırsa o site düz DNS'te açılmaz.
 * Arama bellek ayırmaz (ikili arama).
 */
object BlockPages {
    private val TABLE = mapOf(
        "AU" to (
            "101.167.166.53 101.167.164.53 202.136.99.184"),
        "BY" to (
            "134.17.0.7"),
        "CA" to (
            "67.43.226.22 173.209.39.114 64.59.135.158 206.248.146.244"),
        "CN" to (
            "8.7.198.45 37.61.54.158 46.82.174.68 78.16.49.15 93.46.8.89 159.106.121.75  " +
            "203.98.7.65 59.24.3.173"),
        "CO" to (
            "190.85.224.131"),
        "CZ" to (
            "78.128.216.33 80.250.8.1"),
        "GB" to (
            "90.255.255.14"),
        "ID" to (
            "180.131.146.7 202.3.219.209 116.206.10.31 36.86.63.185 114.121.254.4 180.214.232.61  " +
            "202.62.29.1 103.47.132.195 202.52.141.98 150.107.140.200 103.14.16.18 113.197.108.236  " +
            "202.65.113.54 103.195.19.54 103.10.120.3 27.123.220.197 103.108.159.238 103.126.10.252  " +
            "103.142.60.250 103.19.56.2 103.70.68.68 103.83.96.242 114.129.22.33 114.129.23.9  " +
            "114.6.128.8 150.107.151.151 158.140.186.3 202.152.4.67 202.165.36.253 202.169.44.80  " +
            "202.50.202.50 202.56.160.131 202.56.160.132 203.99.130.131 203.119.13.75 203.119.13.76  " +
            "203.160.56.38 220.247.168.195 58.147.184.141 58.147.185.131 202.73.99.3 49.128.177.13  " +
            "101.255.1.226 101.255.0.226 139.255.196.196 103.154.123.132 112.215.37.181 114.4.66.127  " +
            "118.98.96.151 118.97.116.27 210.210.178.70 103.88.170.170 36.86.63.182 27.54.116.70  " +
            "103.94.168.168 115.178.182.58 202.62.8.233 202.3.218.137 202.62.8.232 119.18.152.218  " +
            "110.50.83.31 103.170.115.114 202.137.1.74 202.162.209.133 43.225.64.187 202.57.25.3  " +
            "202.89.117.64 103.189.63.245 103.173.230.24 103.181.142.196 103.173.75.28 103.151.222.227  " +
            "103.155.197.107 103.157.116.4"),
        "IN" to (
            "103.59.214.106 49.205.171.201 202.83.21.14 49.207.46.62 103.206.163.150 49.44.79.236  " +
            "59.185.3.14 202.83.21.15 202.83.24.75 218.248.112.60 202.164.51.25 123.176.40.68  " +
            "106.51.113.17 123.176.40.69 49.207.46.38 123.176.40.67 49.205.75.6"),
        "IT" to (
            "217.175.53.72 83.224.65.74"),
        "KH" to (
            "36.37.242.94"),
        "MM" to (
            "59.153.90.11 103.105.174.6 176.103.130.135"),
        "MN" to (
            "218.100.84.78"),
        "MY" to (
            "175.139.142.25"),
        "PH" to (
            "121.1.49.100"),
        "PK" to (
            "203.82.48.83 203.82.48.86"),
        "PL" to (
            "145.237.235.240 195.187.6.33 195.187.6.34 195.187.6.35 78.133.250.166 195.116.107.98"),
        "RU" to (
            "159.255.26.69 193.58.251.1 193.58.251.11 93.158.134.250 217.148.54.171 185.37.129.10  " +
            "46.175.31.250 83.69.208.124 212.1.226.59 37.44.40.254 87.241.223.133 5.3.3.17  " +
            "62.33.207.196 62.33.207.197 188.186.146.208 188.186.154.79 188.186.146.207 188.186.154.88  " +
            "81.200.2.238 171.25.175.70 195.128.72.3 95.167.13.50 95.167.13.51 188.19.132.154  " +
            "188.19.132.155 85.142.29.248"),
        "SG" to (
            "202.156.3.53 202.166.118.162 103.7.201.57"),
        "TH" to (
            "125.26.170.3 180.180.255.130"),
        "TR" to (
            "195.175.254.2 193.192.98.41 193.192.98.42 193.192.98.43 193.192.98.45 193.192.98.46  " +
            "193.192.98.47 193.192.98.48 193.192.98.49"),
        "VN" to (
            "125.212.224.108 103.192.236.94"),
    )

    private val SORTED: IntArray
    private val COUNTRY = HashMap<Int, String>()

    init {
        val all = ArrayList<Int>()
        for ((cc, line) in TABLE) for (s in line.trim().split(Regex("\\s+"))) {
            val v = parse(s)
            if (v != null && COUNTRY.put(v, cc) == null) all.add(v)
        }
        all.sort()
        SORTED = all.toIntArray()
    }

    /** "a.b.c.d" -> Int; geçersizse null. */
    internal fun parse(s: String): Int? {
        val p = s.split('.')
        if (p.size != 4) return null
        var v = 0
        for (x in p) {
            val n = x.toIntOrNull() ?: return null
            if (n !in 0..255) return null
            v = (v shl 8) or n
        }
        return v
    }

    val size: Int get() = SORTED.size

    fun isBlockPage(ip: Int): Boolean = java.util.Arrays.binarySearch(SORTED, ip) >= 0

    /** [ip] bilinen bir engel sayfasıysa ülke kodu (örn. "TR"), değilse null. */
    fun countryOf(ip: Int): String? = if (isBlockPage(ip)) COUNTRY[ip] else null

    /**
     * [b] içindeki [base]'ten başlayan [n] baytlık DNS CEVABININ cevap bölümünde (yalnızca orası) bilinen bir engel sayfası
     * adresi taşıyan A kaydı var mı? Bozuk paket için false. Nesne ayırmaz.
     */
    fun inAnswer(b: ByteArray, base: Int, n: Int): Boolean {
        if (n < Packets.DNS_HDR || base < 0 || base + n > b.size) return false
        val end = base + n
        if ((Packets.u16(b, base + 2) and 0x8000) == 0) return false
        val qd = Packets.u16(b, base + 4)
        val an = Packets.u16(b, base + 6)
        if (an == 0) return false
        var p = base + Packets.DNS_HDR
        for (i in 0 until qd) {
            p = Dns.skipName(b, p, end)
            if (p < 0 || p + 4 > end) return false
            p += 4
        }
        for (i in 0 until an) {
            p = Dns.skipName(b, p, end)
            if (p < 0 || p + 10 > end) return false
            val type = Packets.u16(b, p)
            val rdLen = Packets.u16(b, p + 8)
            val rd = p + 10
            if (rd + rdLen > end) return false
            if (type == 1 && rdLen == 4) {
                val ip = ((b[rd].toInt() and 0xFF) shl 24) or ((b[rd + 1].toInt() and 0xFF) shl 16) or
                    ((b[rd + 2].toInt() and 0xFF) shl 8) or (b[rd + 3].toInt() and 0xFF)
                if (isBlockPage(ip)) return true
            }
            p = rd + rdLen
        }
        return false
    }
}
