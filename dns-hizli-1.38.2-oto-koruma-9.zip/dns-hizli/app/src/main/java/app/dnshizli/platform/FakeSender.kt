package app.dnshizli.platform

import android.os.ParcelFileDescriptor
import android.system.ErrnoException
import android.system.Int64Ref
import android.system.Os
import java.io.File
import java.io.RandomAccessFile
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * Sahte ClientHello gönderimi (ByeDPI "fake" tekniği, ham yuva gerektirmeden).
 *
 * Fikir: sahte baytlar bir dosya sayfasına yazılır, sayfa `sendfile` ile yuvaya gönderilir (çekirdek sayfayı KOPYALAMADAN kuyruğa
 * bağlar). Çağıran TTL'i düşürmüştür, paket DPI'a ulaşır ama sunucuya varmadan ölür. Hemen ardından sayfa GERÇEK baytlarla ezilir:
 * sunucu hiç onaylamadığından çekirdek aynı sıra numaralarını yeniden iletir ve bu kez gerçek veri gider.
 *
 * Her bağlantı kendi sayfasını kullanır ([SLOTS] adet, halka); yeniden iletim bitmeden sayfa başkasına verilmesin diye sayfa sayısı büyük.
 * Çekirdek sayfayı kopyalarsa (bazı sürücüler) yeniden iletim SAHTE baytı taşırdı; bu yüzden sonuç yalnızca öğrenen planlayıcıya bağlıdır:
 * bağlantı başarısız olursa yöntem elenir. Platform desteklemezse [send] -1 döner ve Gateway düz bölmeye düşer.
 */
class FakeSender(private val file: File) {
    private var raf: RandomAccessFile? = null
    private var map: MappedByteBuffer? = null
    private var broken = false
    private var next = 0

    private fun open(): Boolean {
        if (map != null) return true
        if (broken) return false
        return try {
            file.delete()
            val r = RandomAccessFile(file, "rw")
            r.setLength((SLOTS * SLOT).toLong())
            map = r.channel.map(FileChannel.MapMode.READ_WRITE, 0, (SLOTS * SLOT).toLong())
            raf = r
            true
        } catch (_: Throwable) { broken = true; false }
    }

    /** [fake] ile [real] aynı uzunlukta olmalı. Çekirdeğe kuyruğa alınan bayt sayısı; desteklenmiyorsa -1. */
    @Synchronized
    fun send(sock: java.net.Socket, fake: ByteArray, real: ByteArray): Int {
        if (fake.isEmpty() || fake.size != real.size || fake.size > SLOT || !open()) return -1
        val m = map ?: return -1
        val fd = raf?.fd ?: return -1
        val off = next * SLOT
        next = (next + 1) % SLOTS
        val w = m.duplicate()
        w.position(off); w.put(fake)
        var sent = -1
        var pfd: ParcelFileDescriptor? = null
        try {
            pfd = ParcelFileDescriptor.fromSocket(sock)
            val o = Int64Ref(off.toLong())
            sent = Os.sendfile(pfd.fileDescriptor, fd, o, fake.size.toLong()).toInt()
        } catch (e: ErrnoException) {
            sent = -1
        } catch (_: Throwable) {
            sent = -1
            broken = true
        } finally {
            // Her durumda sayfa gerçek baytlarla ezilir: yeniden iletim sahte veri taşımasın.
            try { val z = m.duplicate(); z.position(off); z.put(real) } catch (_: Throwable) {}
            try { pfd?.close() } catch (_: Throwable) {}
        }
        return sent
    }

    /**
     * Sayfa dosyasını siler. Dosyada son bağlantıların GERÇEK ClientHello'ları (SNI = gezilen adlar) kalır; servis durunca ya da tünel
     * kapanınca diskte iz bırakmasın diye önce sıfırlanır, sonra silinir.
     */
    @Synchronized
    fun close() {
        try { map?.let { m -> val z = m.duplicate(); z.position(0); z.put(ByteArray(minOf(z.remaining(), SLOTS * SLOT))) } } catch (_: Throwable) {}
        map = null
        try { raf?.close() } catch (_: Throwable) {}
        raf = null
        try { file.delete() } catch (_: Throwable) {}
        broken = false
    }

    companion object {
        const val SLOT = 4096
        const val SLOTS = 256
    }
}
