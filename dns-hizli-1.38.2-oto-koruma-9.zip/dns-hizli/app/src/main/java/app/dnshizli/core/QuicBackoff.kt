package app.dnshizli.core

/**
 * QUIC (DoQ/DoH3) bu ağda yanıt vermediyse bir süre planlardan çıkarılır. UDP'yi engelleyen ağlarda QUIC her bağlanışta yeniden
 * denenip kullanıcıyı bekletmesin; ağ değişince ([reset]) yeniden denenir. Saf mantık: saat dışarıdan verilir.
 */
class QuicBackoff(private val nowMs: () -> Long, private val holdMs: Long = HOLD_MS) {
    @Volatile private var until = 0L

    val skipping: Boolean get() = nowMs() < until

    fun failed() { until = nowMs() + holdMs }

    fun reset() { until = 0L }

    /** Atlama sürerken QUIC yöntemleri çıkarılır; geriye hiçbir yöntem kalmıyorsa plan olduğu gibi döner (hiç bağlanamamaktan iyidir). */
    fun filter(plan: List<Proto>): List<Proto> =
        if (skipping) plan.filter { it != Proto.DOQ && it != Proto.DOH3 }.ifEmpty { plan } else plan

    companion object {
        const val HOLD_MS = 10 * 60_000L
        fun isQuic(p: Proto) = p == Proto.DOQ || p == Proto.DOH3
    }
}
