package app.dnshizli.core

/**
 * Cihaz tanıma: telefonun üreticisini, SİSTEMİNİ (One UI, HyperOS, MIUI, HarmonyOS, MagicOS, ColorOS, OxygenOS, Funtouch, Nothing OS,
 * LineageOS, GrapheneOS…), bellek sınıfını ve arka planda uygulama kapatma eğilimini bulur; uygulama buna göre kendini ayarlar.
 * Saf mantıktır (Android'den bağımsız): platform tarafı yalnızca ham değerleri ([DeviceInfo]) toplar, kararlar burada verilir ve
 * JVM testlerinde sınanır.
 *
 * Tanıma ÖNCE sistem özelliklerine (getprop), sonra üretici/marka/derleme adına bakar; özellik okunamazsa (kısıtlı cihaz) üretici
 * bilgisine düşer. Hiçbir adım bir şey yüklemez, ağ kullanmaz, kişisel veri okumaz.
 */
data class DeviceInfo(
    val manufacturer: String = "",
    val brand: String = "",
    val model: String = "",
    val display: String = "",
    val fingerprint: String = "",
    val tags: String = "",
    val sdk: Int = 0,
    /** Toplam bellek (MB); bilinmiyorsa 0. */
    val ramMb: Int = 0,
    /** Uygulamaya verilen Java yığın sınırı (MB); bilinmiyorsa 0. */
    val heapMb: Int = 0,
    val lowRamFlag: Boolean = false,
    /** Ekran yenileme hızı (Hz). */
    val refreshHz: Int = 60,
    /** İlgilendiğimiz sistem özellikleri (getprop); okunamadıysa boş. */
    val props: Map<String, String> = emptyMap(),
)

enum class DeviceTier { LOW, MID, HIGH }

/** Sistemin arka plandaki uygulamayı (ve onunla koruma tünelini) kapatma eğilimi. */
enum class KillRisk { LOW, MEDIUM, HIGH }

/** Kullanıcıya gösterilen öneri başlıkları; metinleri dil dosyalarındadır ([Tx.deviceAdvice]). */
enum class Advice { BATTERY_STRICT, SAMSUNG_SLEEP, LOW_RAM, CUSTOM_ROM, CLEAN_ANDROID, POWERFUL }

/** Sistem (ROM) adları özel addır, çevrilmez. */
enum class Rom(val label: String, val custom: Boolean = false) {
    ONE_UI("One UI"), HYPEROS("HyperOS"), MIUI("MIUI"), HARMONYOS("HarmonyOS"), EMUI("EMUI"), MAGICOS("MagicOS"),
    COLOROS("ColorOS"), OXYGENOS("OxygenOS"), REALME_UI("realme UI"), FUNTOUCH("Funtouch OS"), ORIGINOS("OriginOS"),
    HIOS("HiOS"), XOS("XOS"), ITEL_OS("itel OS"), FLYME("Flyme"), ZENUI("ZenUI"), ROG_UI("ROG UI"),
    NOTHING_OS("Nothing OS"), HELLO_UX("Hello UX"), MYOS("MyOS"), REDMAGIC_OS("RedMagic OS"), XPERIA("Xperia"),
    PIXEL("Android"), ANDROID("Android"),
    LINEAGE("LineageOS", true), GRAPHENE("GrapheneOS", true), CALYX("CalyxOS", true), E_OS("/e/OS", true), CRDROID("crDroid", true),
    PIXEL_EXPERIENCE("PixelExperience", true), EVOLUTION_X("Evolution X", true), RISING("RisingOS", true), CUSTOM("Custom ROM", true),
}

class DeviceProfile(
    val info: DeviceInfo,
    val family: OemCompat.Family,
    val rom: Rom,
    /** Sistem sürümü ("8.5", "2.0"…); bilinmiyorsa boş. */
    val romVersion: String,
    val tier: DeviceTier,
    val kill: KillRisk,
    val advice: List<Advice>,
    /** Cihaz adı: pazarlama adı biliniyorsa o, yoksa "Marka MODEL". */
    val name: String,
) {
    /** "One UI 8.5 · Android 16" */
    val systemLabel: String
        get() {
            val os = if (romVersion.isEmpty()) rom.label else "${rom.label} $romVersion"
            val and = androidName(info.sdk)
            return when {
                rom == Rom.PIXEL || rom == Rom.ANDROID -> and.ifEmpty { os }
                and.isEmpty() -> os
                else -> "$os · $and"
            }
        }

    /** Tanılama raporu satırı: "One UI 8.5 · Android 16 · sınıf MID · kapatma riski MEDIUM · 120 Hz". */
    val diagLine: String get() = "$systemLabel · sınıf ${tier.name} · kapatma riski ${kill.name} · ${info.refreshHz} Hz"

    /** Düşük sınıf cihazda hareket otomatik sadeleştirilir ("Tam" → "Az"). */
    val reduceMotion: Boolean get() = tier == DeviceTier.LOW

    /** Üretici bilinen bir ekranı olan agresif sistem mi (pil/otomatik başlatma rehberi önerilir)? */
    val strictBackground: Boolean get() = kill == KillRisk.HIGH

    companion object {
        fun androidName(sdk: Int): String = when {
            sdk >= 37 -> "Android 17"
            sdk == 36 -> "Android 16"
            sdk == 35 -> "Android 15"
            sdk == 34 -> "Android 14"
            sdk == 33 -> "Android 13"
            sdk in 1..32 -> "API $sdk"
            else -> ""
        }
    }
}

object DeviceProfiler {
    /** Okunacak sistem özelliklerinin adları (platform yalnızca bunları toplar; gerisi atılır). */
    val PROP_KEYS: Set<String> = setOf(
        "ro.build.version.oneui", "ro.build.version.sem",
        "ro.mi.os.version.name", "ro.mi.os.version.code", "ro.miui.ui.version.name", "ro.miui.ui.version.code",
        "ro.build.version.emui", "hw_sc.build.platform.version", "ro.build.version.magic",
        "ro.build.version.oplusrom", "ro.build.version.opporom", "ro.build.version.realmeui", "ro.oxygen.version",
        "ro.vivo.os.name", "ro.vivo.os.version", "ro.vivo.product.version",
        "ro.lineage.version", "ro.lineage.build.version", "ro.modversion", "ro.calyxos.version", "ro.crdroid.version",
        "ro.pixelexperience.version", "ro.evolution.version", "ro.evolution.build.version", "ro.rising.version", "ro.risingos.version",
        "ro.e.version", "ro.grapheneos.version",
        "ro.product.marketname", "ro.config.marketing_name", "ro.vendor.oplus.market.name", "ro.vivo.market.name", "ro.product.odm.marketname",
    )

    /** Pazarlama adı için denenen özellikler (ilk dolu olan). */
    private val MARKET_KEYS = listOf(
        "ro.product.marketname", "ro.config.marketing_name", "ro.vendor.oplus.market.name", "ro.vivo.market.name", "ro.product.odm.marketname",
    )

    /**
     * Sistemden okunan metinleri güvenli hâle getirir ([TextSafe]): kontrol ve yön değiştirici karakterler silinir, uzunluklar
     * sınırlanır, en çok [MAX_PROPS] özellik tutulur. Cihaz adı ekrana ve paylaşılan tanılama raporuna girdiği için şart.
     */
    fun sanitize(i: DeviceInfo): DeviceInfo {
        val props = LinkedHashMap<String, String>()
        for ((k, v) in i.props) {
            if (props.size >= MAX_PROPS) break
            val key = TextSafe.line(k, 80)
            if (key.isNotEmpty()) props[key] = TextSafe.line(v, 120)
        }
        return i.copy(
            manufacturer = TextSafe.line(i.manufacturer, 60), brand = TextSafe.line(i.brand, 60), model = TextSafe.line(i.model, 80),
            display = TextSafe.line(i.display, 160), fingerprint = TextSafe.line(i.fingerprint, 300), tags = TextSafe.line(i.tags, 80),
            sdk = i.sdk.coerceIn(0, 200), ramMb = i.ramMb.coerceIn(0, 1_000_000), heapMb = i.heapMb.coerceIn(0, 100_000),
            refreshHz = i.refreshHz.coerceIn(1, 1000), props = props,
        )
    }

    private const val MAX_PROPS = 64

    fun detect(raw: DeviceInfo): DeviceProfile {
        val i = sanitize(raw)
        val fam = OemCompat.familyFor(i.manufacturer, i.brand, i.display, i.fingerprint, i.tags)
        val (rom, ver) = detectRom(i, fam)
        val tier = tierOf(i)
        val kill = killRisk(fam, rom)
        val advice = adviceFor(rom, tier, kill, fam)
        return DeviceProfile(i, fam, rom, ver, tier, kill, advice, deviceName(i))
    }

    /** `getprop` satırı: "[ro.build.version.oneui]: [80500]" → ("ro.build.version.oneui", "80500"); biçime uymayan satır null. */
    fun parseProp(line: String): Pair<String, String>? {
        if (!line.startsWith("[")) return null
        val k = line.indexOf("]: [")
        if (k < 2 || !line.endsWith("]")) return null
        if (line.length > 400) return null
        return TextSafe.line(line.substring(1, k), 80) to TextSafe.line(line.substring(k + 4, line.length - 1), 120)
    }

    // ------------------------------------------------------------------ sistem (ROM)

    private fun detectRom(i: DeviceInfo, fam: OemCompat.Family): Pair<Rom, String> {
        fun p(k: String): String = i.props[k]?.trim().orEmpty()
        val low = "${i.display} ${i.fingerprint}".lowercase()

        // 1) Özel ROM'lar: kendi sürüm özellikleri varsa kesin; yoksa derleme adından.
        p("ro.lineage.version").ifEmpty { p("ro.lineage.build.version") }.let { if (it.isNotEmpty()) return Rom.LINEAGE to numberOf(it) }
        if (p("ro.modversion").lowercase().contains("lineage")) return Rom.LINEAGE to numberOf(p("ro.modversion"))
        if (p("ro.calyxos.version").isNotEmpty() || low.contains("calyx")) return Rom.CALYX to numberOf(p("ro.calyxos.version"))
        if (p("ro.grapheneos.version").isNotEmpty() || low.contains("graphene")) return Rom.GRAPHENE to ""
        if (p("ro.crdroid.version").isNotEmpty() || low.contains("crdroid")) return Rom.CRDROID to numberOf(p("ro.crdroid.version"))
        if (p("ro.pixelexperience.version").isNotEmpty() || low.contains("pixelexperience") || low.contains("pixel_experience")) return Rom.PIXEL_EXPERIENCE to numberOf(p("ro.pixelexperience.version"))
        p("ro.evolution.version").ifEmpty { p("ro.evolution.build.version") }.let { if (it.isNotEmpty() || low.contains("evolution_x") || low.contains("evolutionx")) return Rom.EVOLUTION_X to numberOf(it) }
        p("ro.rising.version").ifEmpty { p("ro.risingos.version") }.let { if (it.isNotEmpty() || low.contains("risingos")) return Rom.RISING to numberOf(it) }
        if (p("ro.e.version").isNotEmpty() || low.contains("/e/os") || low.contains("e_os")) return Rom.E_OS to numberOf(p("ro.e.version"))
        if (fam == OemCompat.Family.CUSTOM_ROM) return customName(low)

        // 2) Üretici sistemleri: önce sürüm özelliği (kesin), yoksa üreticiden.
        return when (fam) {
            OemCompat.Family.SAMSUNG -> Rom.ONE_UI to oneUiVersion(p("ro.build.version.oneui"))
            OemCompat.Family.XIAOMI -> {
                val hos = p("ro.mi.os.version.name")
                val miui = p("ro.miui.ui.version.name")
                when {
                    hos.isNotEmpty() -> Rom.HYPEROS to numberOf(hos)
                    miui == "V816" -> Rom.HYPEROS to "1.0"               // HyperOS 1.0 eski MIUI özelliğini V816 olarak bildirir
                    miui.isNotEmpty() -> Rom.MIUI to miuiVersion(miui)
                    i.sdk >= 34 -> Rom.HYPEROS to ""                      // Android 14+ Xiaomi cihazlar HyperOS'tur
                    else -> Rom.MIUI to ""
                }
            }
            OemCompat.Family.HUAWEI -> {
                val harmony = p("hw_sc.build.platform.version")
                if (harmony.isNotEmpty()) Rom.HARMONYOS to numberOf(harmony)
                else Rom.EMUI to numberOf(p("ro.build.version.emui"))
            }
            OemCompat.Family.HONOR -> Rom.MAGICOS to numberOf(p("ro.build.version.magic"))
            OemCompat.Family.OPPO -> {
                val real = p("ro.build.version.realmeui")
                val b = i.brand.lowercase() + " " + i.manufacturer.lowercase()
                if (real.isNotEmpty() || b.contains("realme")) Rom.REALME_UI to numberOf(real)
                else Rom.COLOROS to numberOf(p("ro.build.version.oplusrom").ifEmpty { p("ro.build.version.opporom") })
            }
            OemCompat.Family.ONEPLUS -> Rom.OXYGENOS to numberOf(p("ro.build.version.oplusrom").ifEmpty { p("ro.oxygen.version") })
            OemCompat.Family.VIVO -> {
                val n = p("ro.vivo.os.name").lowercase()
                val v = numberOf(p("ro.vivo.os.version").ifEmpty { p("ro.vivo.product.version") })
                if (n.contains("origin")) Rom.ORIGINOS to v else Rom.FUNTOUCH to v
            }
            OemCompat.Family.TRANSSION -> {
                val b = (i.brand + " " + i.manufacturer).lowercase()
                when {
                    b.contains("infinix") -> Rom.XOS to ""
                    b.contains("itel") -> Rom.ITEL_OS to ""
                    else -> Rom.HIOS to ""
                }
            }
            OemCompat.Family.MEIZU -> Rom.FLYME to ""
            OemCompat.Family.ASUS -> if (i.model.uppercase().contains("ROG")) Rom.ROG_UI to "" else Rom.ZENUI to ""
            OemCompat.Family.NOTHING -> Rom.NOTHING_OS to ""
            OemCompat.Family.MOTOROLA -> if ((i.brand + i.manufacturer).lowercase().contains("lenovo")) Rom.ANDROID to "" else Rom.HELLO_UX to ""
            OemCompat.Family.NUBIA -> if ((i.brand + i.manufacturer + i.model).lowercase().contains("redmagic")) Rom.REDMAGIC_OS to "" else Rom.MYOS to ""
            OemCompat.Family.SONY -> Rom.XPERIA to ""
            OemCompat.Family.GOOGLE -> Rom.PIXEL to ""
            OemCompat.Family.CASPER, OemCompat.Family.GENERAL_MOBILE, OemCompat.Family.REEDER, OemCompat.Family.OTHER -> Rom.ANDROID to ""
            OemCompat.Family.CUSTOM_ROM -> Rom.CUSTOM to ""
        }
    }

    private fun customName(low: String): Pair<Rom, String> = if (low.contains("lineage")) Rom.LINEAGE to "" else Rom.CUSTOM to ""

    /** "One UI" sürümü: 80500 → "8.5", 70000 → "7.0", 60100 → "6.1". Okunamazsa boş. */
    fun oneUiVersion(raw: String): String {
        val v = raw.trim().toIntOrNull() ?: return ""
        if (v < 10000) return ""
        return "${v / 10000}.${(v % 10000) / 100}"
    }

    /** MIUI sürümü: "V125" → "12.5", "V140" → "14". */
    fun miuiVersion(raw: String): String {
        val n = raw.trim().removePrefix("V").removePrefix("v").toIntOrNull() ?: return ""
        if (n < 100) return n.toString()
        val major = n / 10; val minor = n % 10
        return if (minor == 0) "$major" else "$major.$minor"
    }

    /** Metindeki ilk sayı ("EmotionUI_11.0.0" → "11.0", "MagicOS_8.0" → "8.0", "OS2.0.5" → "2.0"); yoksa boş. */
    fun numberOf(s: String): String {
        val m = NUM.find(s) ?: return ""
        return m.value
    }
    private val NUM = Regex("""\d+(\.\d+)?""")

    // ------------------------------------------------------------------ sınıf, risk, öneri

    fun tierOf(i: DeviceInfo): DeviceTier {
        if (i.lowRamFlag) return DeviceTier.LOW
        if (i.heapMb in 1 until DeviceMem.LOW_HEAP_MB) return DeviceTier.LOW
        // Bildirilen toplam bellek, satış adındakinden ~%8-12 azdır: 3 GB ≈ 2,8 GB, 4 GB ≈ 3,6 GB, 8 GB ≈ 7,4 GB.
        if (i.ramMb in 1 until 3300) return DeviceTier.LOW
        if (i.ramMb >= 7000) return DeviceTier.HIGH
        if (i.ramMb == 0 && i.heapMb >= 384) return DeviceTier.HIGH
        return DeviceTier.MID
    }

    fun killRisk(fam: OemCompat.Family, rom: Rom): KillRisk = when {
        rom.custom || fam == OemCompat.Family.CUSTOM_ROM -> KillRisk.LOW
        fam.aggressive -> KillRisk.HIGH
        fam == OemCompat.Family.SAMSUNG -> KillRisk.MEDIUM
        else -> KillRisk.LOW
    }

    private fun adviceFor(rom: Rom, tier: DeviceTier, kill: KillRisk, fam: OemCompat.Family): List<Advice> {
        val out = ArrayList<Advice>(3)
        when (kill) {
            KillRisk.HIGH -> out.add(Advice.BATTERY_STRICT)
            KillRisk.MEDIUM -> out.add(Advice.SAMSUNG_SLEEP)
            KillRisk.LOW -> {}
        }
        if (rom.custom) out.add(Advice.CUSTOM_ROM)
        if (tier == DeviceTier.LOW) out.add(Advice.LOW_RAM)
        if (out.isEmpty()) out.add(if (tier == DeviceTier.HIGH) Advice.POWERFUL else Advice.CLEAN_ANDROID)
        return out
    }

    // ------------------------------------------------------------------ ad

    fun deviceName(i: DeviceInfo): String {
        for (k in MARKET_KEYS) {
            val v = i.props[k]?.trim().orEmpty()
            if (v.isNotEmpty() && v.length <= 40) return withBrand(i, v)
        }
        val model = i.model.trim()
        if (model.isEmpty()) return titleCase(i.brand.ifEmpty { i.manufacturer }).ifEmpty { "Android" }
        return withBrand(i, model)
    }

    private fun withBrand(i: DeviceInfo, model: String): String {
        val brand = titleCase(i.brand.ifEmpty { i.manufacturer })
        if (brand.isEmpty() || model.lowercase().startsWith(brand.lowercase())) return model
        // Marka yarısı "xiaomi" iken model "Redmi Note 12" gibi kendi markasını taşıyabilir: tekrar etme.
        val first = model.substringBefore(' ').lowercase()
        if (first in KNOWN_SUBBRANDS) return model
        return "$brand $model"
    }

    private val KNOWN_SUBBRANDS = setOf("redmi", "poco", "galaxy", "pixel", "xperia", "honor", "realme", "oneplus", "iqoo", "nothing", "cmf", "moto", "reno", "find")

    private fun titleCase(s: String): String {
        val t = s.trim()
        if (t.isEmpty()) return ""
        // Tümü büyük ya da küçük harfse ("SAMSUNG", "xiaomi") baş harf büyütülür; karışık yazım ("OnePlus", "nubia") korunur.
        return if (t == t.uppercase() || t == t.lowercase()) t.lowercase().replaceFirstChar { it.uppercase() } else t
    }
}

/**
 * Bu cihazın tanınmış profili. Uygulama açılırken [DeviceProbe] (platform) doldurur; testlerde elle verilir. Arayüz ve etkin ayar
 * hesapları buradan okur. Profil yokken (henüz okunmadı) hiçbir otomatik ayar uygulanmaz.
 */
object DeviceTune {
    @Volatile var profile: DeviceProfile? = null
        private set

    /** Profil her değiştiğinde artar: sayfalar satır değerlerini yeniler. */
    @Volatile var rev = 0
        private set

    fun set(p: DeviceProfile?) { profile = p; rev++ }

    /** Düşük sınıf cihazda hareketin otomatik sadeleşip sadeleşmeyeceği (ayar açıksa). */
    val reduceMotion: Boolean get() = profile?.reduceMotion == true
}
