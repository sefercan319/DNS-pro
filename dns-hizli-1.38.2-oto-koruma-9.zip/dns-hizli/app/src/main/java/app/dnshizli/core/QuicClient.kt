package app.dnshizli.core

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.security.KeyStore
import java.security.SecureRandom
import java.util.TreeMap
import java.util.TreeSet
import javax.crypto.Cipher
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/**
 * Küçük, yalnızca istemci QUIC v1 (RFC 9000/9001/9002) uygulaması: DNS-over-QUIC (RFC 9250) ve DNS-over-HTTP/3 için yeterlisi.
 *
 * Yapılanlar: Initial/Handshake/1-RTT paket koruması (AES-128-GCM, AES-ECB başlık koruması), ACK üretimi ve işlenmesi, CRYPTO ve STREAM
 * çerçeveleri, sıra dışı gelen parçaların birleştirilmesi, bağlantı/akış akış denetimi (MAX_DATA yenilenir), basit kayıp telafisi
 * (zamanlayıcıyla aynı çerçevelerin yeniden gönderimi, üstel bekleme), PATH_CHALLENGE yanıtı, CONNECTION_CLOSE.
 * Yapılmayanlar: Retry, sürüm pazarlığı, 0-RTT, anahtar güncelleme, bağlantı taşıma, ECN, tıkanıklık denetimi (istekler küçüktür).
 * Bunlardan biri olursa bağlantı hatayla kapanır; çağıran yenisini açar.
 *
 * Tek kilit ([lock]) hem durumu hem gönderimi korur; alıcı iş parçacığı soketi okur ve zamanlayıcıyı sürer. Ağ erişimi [openUdp] ile
 * dışarıdan verilir (Android'de VpnService.protect edilmiş yuva).
 */
class QuicClient(
    private val host: String,
    private val remote: InetSocketAddress,
    private val alpn: String,
    private val openUdp: (InetSocketAddress) -> DatagramSocket,
    private val trust: X509TrustManager = systemTrust(),
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000 },
    private val log: (String) -> Unit = {},
) : AutoCloseable {

    private class Space {
        var rx: QuicInitial.Keys? = null
        var tx: QuicInitial.Keys? = null
        var largestRx = -1L
        val rxPns = TreeSet<Long>()
        var ackNeeded = false
        var nextPn = 0L
        var cryptoTx = 0L
        var cryptoRxOff = 0L
        val cryptoRx = TreeMap<Long, ByteArray>()
        val sent = LinkedHashMap<Long, Sent>()
    }

    private class Sent(val t: Long, val frames: List<ByteArray>, val tries: Int)

    class Stream(val id: Long) {
        internal val rx = TreeMap<Long, ByteArray>()
        internal val data = ByteArrayOutputStream()
        internal var consumed = 0L
        internal var finAt = -1L
        internal var txOff = 0L
        internal var reset = false
        val complete: Boolean get() = finAt >= 0 && consumed == finAt
        fun bytes(): ByteArray = data.toByteArray()
        val received: Int get() = data.size()
    }

    @Suppress("PLATFORM_CLASS_MAPPED_TO_KOTLIN")
    private val lock = java.lang.Object()
    @Suppress("PLATFORM_CLASS_MAPPED_TO_KOTLIN")
    private fun lwait(ms: Long) { (lock as java.lang.Object).wait(ms) }
    @Suppress("PLATFORM_CLASS_MAPPED_TO_KOTLIN")
    private fun lnotify() { (lock as java.lang.Object).notifyAll() }
    private val rng = SecureRandom()
    private val spaces = Array(3) { Space() }
    private val scid = ByteArray(8).also { rng.nextBytes(it) }
    private var dcid = ByteArray(8).also { rng.nextBytes(it) }
    private val odcid = dcid.copyOf()
    private var serverCidSet = false
    private var sock: DatagramSocket? = null
    private var thread: Thread? = null
    private var tls: QuicTls? = null
    private val streams = HashMap<Long, Stream>()
    private var nextBidi = 0L
    private var nextUni = 0L

    @Volatile var established = false; private set
    @Volatile var failure: Throwable? = null; private set
    @Volatile private var closed = false
    private var finishedSent = false
    private var lastRx = 0L

    // eş sınırları (taşıma parametreleri)
    private var peerMaxData = 0L
    private var peerMaxStreamData = 0L
    private var peerMaxStreamsBidi = 0L
    private var peerMaxStreamsUni = 0L
    private var sentData = 0L
    // bizim sınırlarımız
    private var advMaxData = INIT_MAX_DATA
    private var recvData = 0L
    // RTT
    private var srtt = 0.0
    private var rto = 300L

    val isOpen: Boolean get() = established && !closed && failure == null
    /**
     * Yeni sorgu için güvenle kullanılabilir mi? Açık olmalı ve son [STALE_MS] içinde sunucudan bir şey gelmiş olmalı: sunucular boşta bağlantıyı
     * (genelde 30 sn) sessizce atar; böyle bir bağlantıya yazılan ilk soru cevap süresi dolana dek asılı kalırdı. Bayat bağlantı yerine yenisi kurulur.
     */
    val usable: Boolean get() = isOpen && nowMs() - lastRx < STALE_MS
    /** Bu bağlantıda yeni akış açılabilir mi (eşin akış sınırı)? */
    fun canOpenBidi(): Boolean = synchronized(lock) { nextBidi < peerMaxStreamsBidi }
    val lastActivity: Long get() = lastRx

    // ------------------------------------------------------------------ el sıkışma

    private fun transportParams(): ByteArray {
        val o = ByteArrayOutputStream()
        fun p(id: Int, v: Long) { putVar(o, id.toLong()); val t = varBytes(v); putVar(o, t.size.toLong()); o.write(t) }
        p(0x01, 30_000)                    // max_idle_timeout
        p(0x03, 1452)                      // max_udp_payload_size
        p(0x04, INIT_MAX_DATA)             // initial_max_data
        p(0x05, STREAM_WINDOW)             // initial_max_stream_data_bidi_local (bizim açtığımız akışlar)
        p(0x06, STREAM_WINDOW)             // bidi_remote
        p(0x07, STREAM_WINDOW)             // uni
        p(0x08, 0)                         // initial_max_streams_bidi: sunucu bize akış açmaz
        p(0x09, 16)                        // initial_max_streams_uni (HTTP/3 denetim akışları)
        putVar(o, 0x0c); putVar(o, 0)      // disable_active_migration
        putVar(o, 0x0f); putVar(o, scid.size.toLong()); o.write(scid)   // initial_source_connection_id
        return o.toByteArray()
    }

    /** Bağlantıyı kurar ve el sıkışmanın bitmesini bekler. Başarısızsa [IOException]. */
    fun connect(timeoutMs: Int) {
        val t0 = nowMs()
        synchronized(lock) {
            if (sock != null) throw IllegalStateException("zaten başlatıldı")
            val s = openUdp(remote)
            s.soTimeout = TICK_MS
            sock = s
            lastRx = t0
            val ik = QuicInitial.clientKeys(odcid)
            spaces[0].tx = ik
            spaces[0].rx = serverInitialKeys(odcid)
            val t = QuicTls(host, alpn, transportParams(), trust, rng)
            tls = t
            val ch = t.clientHello()
            sendCrypto(0, ch)
            thread = Thread({ rxLoop() }, "quic-rx").also { it.isDaemon = true; it.start() }
            while (!established && failure == null && !closed) {
                val left = timeoutMs - (nowMs() - t0)
                if (left <= 0) { failLocked(IOException("QUIC el sıkışması zaman aşımı")); break }
                lwait(left)
            }
            failure?.let { closeSocket(); throw if (it is IOException) it else IOException(it.message, it) }
        }
    }

    private fun serverInitialKeys(dcid: ByteArray): QuicInitial.Keys {
        val initial = QuicInitial.hmac(SALT_V1, dcid)
        val ss = QuicInitial.expandLabel(initial, "server in", 32)
        return QuicInitial.Keys(QuicInitial.expandLabel(ss, "quic key", 16), QuicInitial.expandLabel(ss, "quic iv", 12), QuicInitial.expandLabel(ss, "quic hp", 16))
    }

    private fun keysFrom(secret: ByteArray) =
        QuicInitial.Keys(QuicInitial.expandLabel(secret, "quic key", 16), QuicInitial.expandLabel(secret, "quic iv", 12), QuicInitial.expandLabel(secret, "quic hp", 16))

    // ------------------------------------------------------------------ gönderim

    private fun putVar(o: ByteArrayOutputStream, v: Long) { o.write(varBytes(v)) }

    private fun frameCrypto(off: Long, d: ByteArray, from: Int, to: Int): ByteArray {
        val o = ByteArrayOutputStream(to - from + 16)
        o.write(0x06); putVar(o, off); putVar(o, (to - from).toLong()); o.write(d, from, to - from)
        return o.toByteArray()
    }

    /** CRYPTO baytlarını [lvl] seviyesinde göndermeye alır (parçalar ≤ [CHUNK]). Initial içeren datagram 1200 bayta tamamlanır. */
    private fun sendCrypto(lvl: Int, data: ByteArray) {
        val sp = spaces[lvl]
        var p = 0
        while (p < data.size) {
            val n = minOf(CHUNK, data.size - p)
            val fr = frameCrypto(sp.cryptoTx, data, p, p + n)
            sp.cryptoTx += n; p += n
            sendDatagram(listOf(lvl to listOf(fr)))
        }
    }

    private fun ackFrame(sp: Space): ByteArray? {
        if (sp.rxPns.isEmpty()) return null
        val pns = sp.rxPns.descendingSet().iterator()
        val ranges = ArrayList<LongArray>()
        var hi = pns.next(); var lo = hi
        while (pns.hasNext() && ranges.size < 24) {
            val x = pns.next()
            if (x == lo - 1) lo = x else { ranges.add(longArrayOf(lo, hi)); hi = x; lo = x }
        }
        ranges.add(longArrayOf(lo, hi))
        val o = ByteArrayOutputStream()
        o.write(0x02)
        putVar(o, ranges[0][1]); putVar(o, 0); putVar(o, (ranges.size - 1).toLong()); putVar(o, ranges[0][1] - ranges[0][0])
        for (i in 1 until ranges.size) {
            putVar(o, ranges[i - 1][0] - ranges[i][1] - 2); putVar(o, ranges[i][1] - ranges[i][0])
        }
        return o.toByteArray()
    }

    /**
     * Bir datagram kurar ve yollar: her (seviye, çerçeveler) bir paket olur (bitişik paketler). Bekleyen ACK ilgili seviyenin paketine eklenir.
     * Çerçeveler ACK dışındaysa paket "ack tetikleyici" sayılır ve yeniden gönderim için kaydedilir. Initial içeriyorsa datagram ≥ 1200 bayt olur.
     */
    private fun sendDatagram(parts: List<Pair<Int, List<ByteArray>>>, retry: Int = 0) {
        val s = sock ?: return
        if (closed) return
        val hasInitial = parts.any { it.first == 0 && spaces[0].tx != null }
        val out = ByteArrayOutputStream(1252)
        for ((idx, pr) in parts.withIndex()) {
            val lvl = pr.first
            val sp = spaces[lvl]
            if (sp.tx == null) continue
            val frames = ArrayList<ByteArray>()
            val ack = if (sp.ackNeeded) ackFrame(sp) else null
            if (ack != null) { frames.add(ack); sp.ackNeeded = false }
            frames.addAll(pr.second)
            if (frames.isEmpty()) continue
            val elicit = pr.second.isNotEmpty()
            val last = idx == parts.size - 1
            val pad = if (hasInitial && last) maxOf(0, 1200 - out.size()) else 0
            val pn = sp.nextPn++
            out.write(buildPacket(lvl, pn, frames, pad))
            if (elicit) sp.sent[pn] = Sent(nowMs(), pr.second, retry)
        }
        if (out.size() == 0) return
        try { val b = out.toByteArray(); s.send(DatagramPacket(b, b.size)) } catch (e: IOException) { failLocked(e) }
    }

    private fun sendFrames(lvl: Int, frames: List<ByteArray>) = sendDatagram(listOf(lvl to frames))

    private fun buildPacket(lvl: Int, pn: Long, frames: List<ByteArray>, padTo: Int): ByteArray {
        val sp = spaces[lvl]
        val k = sp.tx!!
        var plen = frames.sumOf { it.size }
        val short = lvl == 2
        val hdr = ByteArrayOutputStream(64)
        // başlık (paket numarası dahil, 4 bayt)
        if (short) {
            hdr.write(0x43)                                             // 0 1 0 0 0 0 1 1: kısa başlık, anahtar evresi 0, pn uzunluğu 4
            hdr.write(dcid)
        } else {
            hdr.write(0xC0 or ((if (lvl == 0) 0 else 2) shl 4) or 3)
            hdr.write(byteArrayOf(0, 0, 0, 1))
            hdr.write(dcid.size); hdr.write(dcid)
            hdr.write(scid.size); hdr.write(scid)
            if (lvl == 0) hdr.write(0)                                  // belirteç uzunluğu 0
        }
        val fixed = hdr.size() + (if (short) 0 else 2) + 4 + 16
        var padLen = 0
        if (padTo > 0 && fixed + plen < padTo) padLen = padTo - fixed - plen
        if (plen + padLen < 4) padLen = 4 - plen               // başlık koruması örneği için en az 4 bayt
        plen += padLen
        if (!short) { val l = 4 + plen + 16; hdr.write(0x40 or (l shr 8)); hdr.write(l and 0xFF) }
        val pnOff = hdr.size()
        hdr.write((pn shr 24).toInt()); hdr.write((pn shr 16).toInt()); hdr.write((pn shr 8).toInt()); hdr.write(pn.toInt())
        val header = hdr.toByteArray()
        val plain = ByteArray(plen)
        var p = 0
        for (f in frames) { System.arraycopy(f, 0, plain, p, f.size); p += f.size }
        val ct = QuicInitial.gcm(Cipher.ENCRYPT_MODE, k, pn, header, plain, 0, plain.size)
        val pkt = ByteArray(header.size + ct.size)
        System.arraycopy(header, 0, pkt, 0, header.size)
        System.arraycopy(ct, 0, pkt, header.size, ct.size)
        val mask = QuicInitial.aesEcb(k.hp, pkt.copyOfRange(pnOff + 4, pnOff + 20))
        pkt[0] = (pkt[0].toInt() xor (mask[0].toInt() and (if (short) 0x1F else 0x0F))).toByte()
        for (i in 0 until 4) pkt[pnOff + i] = (pkt[pnOff + i].toInt() xor mask[1 + i].toInt()).toByte()
        return pkt
    }

    // ------------------------------------------------------------------ alım

    private fun rxLoop() {
        val buf = ByteArray(2048)
        val pkt = DatagramPacket(buf, buf.size)
        val s = sock ?: return
        var cur = -1
        while (!closed) {
            try {
                // Havada paket varken (ya da el sıkışma sürerken) sık, boştayken seyrek uyanılır: boşta bağlantı saniyede ~66 kez uyanıp pili yemesin.
                // Bekleyen bir istek varsa zamanlayıcıyı onu bekleyen iş parçacığı da sürer ([await]).
                val want = synchronized(lock) { if (!established || spaces.any { it.sent.isNotEmpty() }) TICK_MS else IDLE_POLL_MS }
                if (want != cur) { s.soTimeout = want; cur = want }
                pkt.setData(buf, 0, buf.size)
                s.receive(pkt)
                synchronized(lock) {
                    if (closed) return
                    try { datagram(buf, pkt.length) } catch (e: QuicTlsException) { failLocked(IOException("TLS: ${e.message}", e)) } catch (e: IOException) { failLocked(e) } catch (_: RuntimeException) { /* bozuk datagram: atılır */ }
                    afterRx()
                }
            } catch (_: java.net.SocketTimeoutException) {
                synchronized(lock) { if (!closed) tick() }
            } catch (e: IOException) {
                synchronized(lock) { if (!closed) failLocked(e) }
                return
            } catch (e: Exception) {
                synchronized(lock) { if (!closed) failLocked(IOException("QUIC iç hata: ${e.javaClass.simpleName}", e)) }
                return
            }
        }
    }

    private fun afterRx() {
        // bekleyen ACK'ler
        for (lvl in 0..2) if (spaces[lvl].ackNeeded && spaces[lvl].tx != null) sendAckOnly(lvl)
        if (established && recvData > advMaxData / 2) {
            advMaxData += INIT_MAX_DATA
            val o = ByteArrayOutputStream(); o.write(0x10); putVar(o, advMaxData)
            sendFrames(2, listOf(o.toByteArray()))
        }
        if (!closed) tick()
        lnotify()
    }

    private fun sendAckOnly(lvl: Int) {
        val sp = spaces[lvl]
        val ack = ackFrame(sp) ?: return
        sp.ackNeeded = false
        val pn = sp.nextPn++
        val b = buildPacket(lvl, pn, listOf(ack), if (lvl == 0) 1200 else 0)
        try { sock?.send(DatagramPacket(b, b.size)) } catch (e: IOException) { failLocked(e) }
    }

    private fun datagram(d: ByteArray, len: Int) {
        var off = 0
        while (off < len) {
            val first = d[off].toInt() and 0xFF
            if (first and 0x80 != 0) {
                if (off + 7 > len) return
                val ver = ((d[off + 1].toInt() and 0xFF) shl 24) or ((d[off + 2].toInt() and 0xFF) shl 16) or ((d[off + 3].toInt() and 0xFF) shl 8) or (d[off + 4].toInt() and 0xFF)
                val type = (first shr 4) and 3
                var p = off + 5
                val dl = d[p++].toInt() and 0xFF; if (dl > 20 || p + dl > len) return
                val dc = d.copyOfRange(p, p + dl)
                p += dl
                if (p >= len) return
                val sl = d[p++].toInt() and 0xFF; if (sl > 20 || p + sl > len) return
                val sc = d.copyOfRange(p, p + sl); p += sl
                if (ver == 0) {
                    // Sürüm pazarlığı kimlik doğrulamasızdır: yalnızca kimliklerimizi yansıtıyor ve v1'i listelemiyorsa geçerlidir (aksi halde yol dışı bir
                    // saldırgan sahte paketle bağlantıyı düşürebilirdi).
                    if (!dc.contentEquals(scid) || !sc.contentEquals(odcid)) return
                    var q = p
                    while (q + 4 <= len) { if (readU32(d, q) == 1L) return; q += 4 }
                    throw IOException("sunucu QUIC v1 desteklemiyor (sürüm pazarlığı)")
                }
                if (ver != 1) return
                if (type == 3) {
                    // Retry: bütünlük etiketi (RFC 9001 §5.8) doğrulanmadan sayılmaz; doğruysa desteklenmediği için hızla başarısız olunur.
                    if (!dc.contentEquals(scid)) return
                    val tagOff = len - 16
                    if (tagOff <= p) return
                    val aad = ByteArrayOutputStream(); aad.write(odcid.size); aad.write(odcid); aad.write(d, off, tagOff - off)
                    val ok = try { QuicInitial.gcm(Cipher.DECRYPT_MODE, RETRY_KEYS, 0, aad.toByteArray(), d, tagOff, 16); true } catch (_: Exception) { false }
                    if (ok) throw IOException("sunucu Retry gönderdi (desteklenmiyor)")
                    return
                }
                if (type == 0) { val tl = QuicInitial.readVar(d, p, len); if (tl < 0) return; p += QuicInitial.varLen(d[p].toInt() and 0xFF) + tl.toInt() }
                val l = QuicInitial.readVar(d, p, len); if (l < 0) return
                p += QuicInitial.varLen(d[p].toInt() and 0xFF)
                if (p + l > len) return
                val end = p + l.toInt()
                if (type == 0 || type == 2) packet(if (type == 0) 0 else 1, d, off, p, end, sc)
                off = end
            } else {
                // Kısa başlık: hedef kimliği bizim kaynak kimliğimiz olmalı (başkasına ait/sahte paket çözme denemesine bile girmez).
                if (off + 1 + scid.size > len) return
                for (i in scid.indices) if (d[off + 1 + i] != scid[i]) return
                packet(2, d, off, off + 1 + scid.size, len, null)
                return
            }
        }
    }

    private fun readU32(d: ByteArray, p: Int): Long =
        ((d[p].toLong() and 0xFF) shl 24) or ((d[p + 1].toLong() and 0xFF) shl 16) or ((d[p + 2].toLong() and 0xFF) shl 8) or (d[p + 3].toLong() and 0xFF)

    private fun packet(lvl: Int, d: ByteArray, off: Int, pnOff: Int, end: Int, sc: ByteArray?) {
        val sp = spaces[lvl]
        val k = sp.rx ?: return
        if (pnOff + 20 > end) return
        // Sunucu kimliği el sıkışma boyunca sabittir (RFC 9000 §7.2): ilk çözülen pakettten sonra farklı kimlikli uzun başlıklı paketler atılır.
        if (sc != null && serverCidSet && !sc.contentEquals(dcid)) return
        val mask = QuicInitial.aesEcb(k.hp, d.copyOfRange(pnOff + 4, pnOff + 20))
        val short = lvl == 2
        val first = (d[off].toInt() and 0xFF) xor (mask[0].toInt() and (if (short) 0x1F else 0x0F))
        val pnLen = (first and 3) + 1
        var trunc = 0L
        val hdr = d.copyOfRange(off, pnOff + pnLen)
        hdr[0] = first.toByte()
        for (i in 0 until pnLen) {
            val x = (d[pnOff + i].toInt() xor mask[1 + i].toInt()) and 0xFF
            hdr[pnOff - off + i] = x.toByte(); trunc = (trunc shl 8) or x.toLong()
        }
        val win = 1L shl (pnLen * 8)
        val expected = sp.largestRx + 1
        var pn = (expected and (win - 1).inv()) or trunc
        if (pn <= expected - win / 2 && pn < (1L shl 62) - win) pn += win else if (pn > expected + win / 2 && pn >= win) pn -= win
        val plain = try { QuicInitial.gcm(Cipher.DECRYPT_MODE, k, pn, hdr, d, pnOff + pnLen, end - pnOff - pnLen) } catch (_: Exception) { return }
        lastRx = nowMs()                                      // yalnızca kimliği doğrulanmış (çözülebilen) paket bağlantıyı canlı tutar
        if (!serverCidSet && sc != null) {
            // Initial anahtarları herkesçe türetilebildiğinden Initial'daki SCID yalnızca geçicidir; kalıcı hâle ancak Handshake paketi
            // (ECDHE ile türeyen anahtar) çözülünce gelir. Sahte bir Initial ilk SCID'yi zehirleyemez.
            dcid = sc
            if (lvl >= 1) serverCidSet = true
        }
        if (sp.rxPns.size >= 256 && pn < sp.rxPns.first()) return      // pencerenin altındaki eski numara: yeniden oynatma sayılır
        if (pn > sp.largestRx) sp.largestRx = pn
        val dup = !sp.rxPns.add(pn)
        if (sp.rxPns.size > 256) sp.rxPns.pollFirst()
        if (dup) return
        frames(lvl, plain, sc)
        if (lvl == 1 && (spaces[0].tx != null || spaces[0].rx != null)) {       // Handshake alındı: Initial anahtarları atılır (herkesin türetebildiği anahtarla paket kabul edilmesin)
            spaces[0].tx = null; spaces[0].rx = null; spaces[0].sent.clear()
        }
    }

    private fun frames(lvl: Int, b: ByteArray, sc: ByteArray?) {
        val sp = spaces[lvl]
        var p = 0
        fun v(): Long {
            val x = QuicInitial.readVar(b, p, b.size); if (x < 0) throw IOException("bozuk çerçeve")
            p += QuicInitial.varLen(b[p].toInt() and 0xFF); return x
        }
        fun vi(): Int { val x = v(); if (x > 1_000_000L) throw IOException("bozuk uzunluk"); return x.toInt() }
        var elicit = false
        while (p < b.size) {
            val t = b[p++].toInt() and 0xFF
            // Initial/Handshake paketlerinde yalnızca PADDING, PING, ACK, CRYPTO ve taşıma CONNECTION_CLOSE olabilir (RFC 9000 §12.4). Initial anahtarı
            // herkesçe türetilebildiğinden, öteki çerçeveler (ör. sahte STREAM cevabı) yok sayılır.
            if (lvl < 2 && !(t <= 0x03 || t == 0x06 || t == 0x1c)) return
            when {
                t == 0x00 -> {}
                t == 0x01 -> elicit = true
                t == 0x02 || t == 0x03 -> {
                    val largest = v(); val delay = v(); val cnt = v(); val firstR = v()
                    var hi = largest; var lo = largest - firstR
                    ackRange(sp, lo, hi, largest)
                    for (i in 0 until cnt) { val gap = v(); val len = v(); hi = lo - gap - 2; lo = hi - len; ackRange(sp, lo, hi, largest) }
                    if (t == 0x03) { v(); v(); v() }
                }
                t == 0x06 -> {
                    elicit = true
                    val o = v(); val l = vi()
                    if (p + l > b.size) throw IOException("bozuk CRYPTO")
                    onCrypto(lvl, o, b.copyOfRange(p, p + l)); p += l
                }
                t == 0x04 -> { elicit = true; val id = v(); v(); v(); streams[id]?.reset = true }       // RESET_STREAM
                t == 0x05 -> { elicit = true; v(); v() }                                                   // STOP_SENDING
                t == 0x07 -> { elicit = true; val l = vi(); if (p + l > b.size) throw IOException("bozuk NEW_TOKEN"); p += l }   // NEW_TOKEN
                t in 0x08..0x0f -> {
                    elicit = true
                    val id = v()
                    val o = if (t and 4 != 0) v() else 0L
                    val l = if (t and 2 != 0) vi() else b.size - p
                    if (p + l > b.size) throw IOException("bozuk STREAM")
                    onStream(id, o, b.copyOfRange(p, p + l), t and 1 != 0); p += l
                }
                t == 0x10 -> { elicit = true; peerMaxData = maxOf(peerMaxData, v()) }
                t == 0x11 -> { elicit = true; val id = v(); val m = v(); if (id and 3L == 0L || id and 3L == 2L) peerMaxStreamData = maxOf(peerMaxStreamData, m) }
                t == 0x12 -> { elicit = true; peerMaxStreamsBidi = maxOf(peerMaxStreamsBidi, v()) }
                t == 0x13 -> { elicit = true; peerMaxStreamsUni = maxOf(peerMaxStreamsUni, v()) }
                t == 0x14 || t == 0x16 || t == 0x17 -> { elicit = true; v() }
                t == 0x15 -> { elicit = true; v(); v() }
                t == 0x18 -> { elicit = true; v(); v(); if (p >= b.size) throw IOException("bozuk NEW_CONNECTION_ID"); val l = b[p++].toInt() and 0xFF; p += l + 16 }   // NEW_CONNECTION_ID
                t == 0x19 -> { elicit = true; v() }
                t == 0x1a -> {
                    elicit = true
                    if (p + 8 > b.size) throw IOException("bozuk PATH_CHALLENGE")
                    val o = ByteArrayOutputStream(); o.write(0x1b); o.write(b, p, 8); p += 8
                    sendFrames(lvl, listOf(o.toByteArray()))
                }
                t == 0x1b -> { elicit = true; p += 8 }
                t == 0x1c || t == 0x1d -> {
                    val code = v(); if (t == 0x1c) v(); val rl = vi(); p += rl
                    failLocked(IOException("sunucu bağlantıyı kapattı (kod $code)")); return
                }
                t == 0x1e -> {
                    elicit = true; handshakeDone = true
                    spaces[1].rx = null; spaces[1].tx = null; spaces[1].sent.clear()       // el sıkışma onaylandı: Handshake anahtarları atılır
                }
                else -> throw IOException("bilinmeyen çerçeve 0x${t.toString(16)}")
            }
        }
        if (elicit) sp.ackNeeded = true
    }

    private var handshakeDone = false

    private fun ackRange(sp: Space, lo: Long, hi: Long, largest: Long) {
        if (hi < lo) return
        val it = sp.sent.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            if (e.key < lo || e.key > hi) continue
            it.remove()
            if (e.key == largest) {
                val rtt = (nowMs() - e.value.t).toDouble().coerceAtLeast(1.0)
                srtt = if (srtt == 0.0) rtt else srtt * 0.875 + rtt * 0.125
                rto = (srtt * 2.5).toLong().coerceIn(60, 1500)
            }
        }
    }

    private fun onCrypto(lvl: Int, off: Long, data: ByteArray) {
        if (lvl > 1) return
        val sp = spaces[lvl]
        if (off + data.size <= sp.cryptoRxOff) return
        if (off + data.size > MAX_CRYPTO || sp.cryptoRx.size > 64) throw QuicTlsException("CRYPTO sınırı aşıldı")
        sp.cryptoRx[off] = data
        val out = ByteArrayOutputStream()
        while (true) {
            val e = sp.cryptoRx.floorEntry(sp.cryptoRxOff) ?: break
            val start = e.key; val d = e.value
            if (start + d.size <= sp.cryptoRxOff) { sp.cryptoRx.remove(start); continue }
            val skip = (sp.cryptoRxOff - start).toInt()
            out.write(d, skip, d.size - skip)
            sp.cryptoRxOff = start + d.size
            sp.cryptoRx.remove(start)
        }
        if (out.size() == 0) return
        val t = tls ?: return
        try { t.feed(lvl, out.toByteArray()) } catch (e: RuntimeException) { throw QuicTlsException("bozuk el sıkışma iletisi") }
        if (spaces[1].rx == null && t.hsServer != null) {
            spaces[1].rx = keysFrom(t.hsServer!!); spaces[1].tx = keysFrom(t.hsClient!!)
        }
        if (t.done && !finishedSent) {
            finishedSent = true
            spaces[2].rx = keysFrom(t.appServer!!); spaces[2].tx = keysFrom(t.appClient!!)
            applyPeerParams(t.peerParams!!)
            sendCrypto(1, t.clientFinished!!)
            established = true
            lnotify()
        }
    }

    private fun applyPeerParams(b: ByteArray) {
        var p = 0
        fun v(): Long { val x = QuicInitial.readVar(b, p, b.size); if (x < 0) throw QuicTlsException("bozuk taşıma parametresi"); p += QuicInitial.varLen(b[p].toInt() and 0xFF); return x }
        var okOdcid = false; var okIscid = false
        while (p < b.size) {
            val id = v(); val l = v().toInt()
            if (l < 0 || p + l > b.size) throw QuicTlsException("bozuk taşıma parametresi")
            val start = p
            fun value(): Long = if (l > 0) QuicInitial.readVar(b, start, start + l).coerceAtLeast(0) else 0L
            when (id) {
                0x00L -> okOdcid = b.copyOfRange(start, start + l).contentEquals(odcid)
                0x0fL -> okIscid = serverCidSet && b.copyOfRange(start, start + l).contentEquals(dcid)
                0x04L -> peerMaxData = value()
                0x06L -> peerMaxStreamData = value()
                0x07L -> {}
                0x08L -> peerMaxStreamsBidi = value()
                0x09L -> peerMaxStreamsUni = value()
                0x10L, 0x0dL -> {}
            }
            p = start + l
        }
        if (!okOdcid) throw QuicTlsException("original_destination_connection_id uyuşmadı")
        if (!okIscid) throw QuicTlsException("initial_source_connection_id uyuşmadı")
    }

    private fun onStream(id: Long, off: Long, data: ByteArray, fin: Boolean) {
        recvData += data.size
        val s = streams[id] ?: return                       // bizim açmadığımız akışlar (sunucu tek yönlü akışları) yok sayılır
        if (off < 0 || off + data.size > MAX_RESPONSE) { failLocked(IOException("cevap çok büyük")); return }   // ilan edilen akış penceresi aşıldı: sıra dışı tampon da sınırsız büyümesin
        if (fin) s.finAt = off + data.size
        if (data.isNotEmpty() && off + data.size > s.consumed) {
            if (s.rx.size >= MAX_RX_FRAGMENTS && !s.rx.containsKey(off)) { failLocked(IOException("çok fazla parçalı akış verisi")); return }
            s.rx[off] = data
        }
        while (true) {
            val e = s.rx.floorEntry(s.consumed) ?: break
            val d = e.value; val start = e.key
            if (start + d.size <= s.consumed) { s.rx.remove(start); continue }
            val skip = (s.consumed - start).toInt()
            s.data.write(d, skip, d.size - skip)
            s.consumed = start + d.size
            s.rx.remove(start)
            if (s.data.size() > MAX_RESPONSE) { failLocked(IOException("cevap çok büyük")); return }
        }
    }

    /** Yalnızca testler: çerçeve ayrıştırıcıya doğrudan şifresiz yük verir (ağ ve anahtar gerekmez). */
    internal fun debugFrames(lvl: Int, plain: ByteArray) = synchronized(lock) { frames(lvl, plain, null) }

    /** Yalnızca testler: sunucudan veri alabilecek bir akış kaydeder. */
    internal fun debugStream(id: Long): Stream = synchronized(lock) { Stream(id).also { streams[id] = it } }

    /** Yalnızca testler: akış tablosunun boyutu. */
    internal fun debugStreamCount(): Int = synchronized(lock) { streams.size }

    // ------------------------------------------------------------------ zamanlayıcı

    private fun tick() {
        val now = nowMs()
        if (now - lastRx > IDLE_MS) { failLocked(IOException("QUIC bağlantısı boşta zaman aşımı")); return }
        for (lvl in 0..2) {
            val sp = spaces[lvl]
            if (sp.tx == null || sp.sent.isEmpty()) continue
            val e = sp.sent.entries.first()
            val s = e.value
            if (now - s.t < rto * (1L shl minOf(s.tries, 6))) continue
            if (s.tries >= MAX_TRIES) { failLocked(IOException("QUIC paketleri onaylanmadı")); return }
            sp.sent.remove(e.key)
            sendDatagram(listOf(lvl to s.frames), s.tries + 1)
        }
    }

    // ------------------------------------------------------------------ akışlar

    /** Yeni istemci çift yönlü akışı açar. */
    fun openBidi(): Stream = synchronized(lock) {
        if (!isOpen) throw IOException("QUIC bağlantısı açık değil")
        if (nextBidi >= peerMaxStreamsBidi) throw IOException("akış sınırı doldu")
        val s = Stream(nextBidi * 4); nextBidi++
        streams[s.id] = s; s
    }

    /** Yeni istemci tek yönlü akışı açar (HTTP/3 denetim akışları). */
    fun openUni(): Stream = synchronized(lock) {
        if (!isOpen) throw IOException("QUIC bağlantısı açık değil")
        if (nextUni >= peerMaxStreamsUni) throw IOException("tek yönlü akış sınırı doldu")
        val s = Stream(nextUni * 4 + 2); nextUni++
        streams[s.id] = s; s
    }

    /** [data]'yı akışa yazar (isteğe bağlı kapanış). Akış denetimi sınırı aşılırsa IOException. */
    fun send(s: Stream, data: ByteArray, fin: Boolean) = synchronized(lock) {
        if (!isOpen) throw IOException("QUIC bağlantısı açık değil")
        if (s.txOff + data.size > peerMaxStreamData || sentData + data.size > peerMaxData) throw IOException("akış denetimi sınırı")
        var p = 0
        do {
            val n = minOf(CHUNK, data.size - p)
            val o = ByteArrayOutputStream(n + 16)
            val last = p + n >= data.size
            o.write(0x08 or 0x04 or 0x02 or (if (fin && last) 1 else 0))
            putVar(o, s.id); putVar(o, s.txOff); putVar(o, n.toLong()); o.write(data, p, n)
            s.txOff += n; sentData += n; p += n
            sendFrames(2, listOf(o.toByteArray()))
        } while (p < data.size)
    }

    /** Akışın cevabı (karşı taraf kapatana dek) gelene kadar bekler; zaman aşımında IOException. */
    fun await(s: Stream, timeoutMs: Int): ByteArray = synchronized(lock) {
        val t0 = nowMs()
        try {
            while (!s.complete) {
                if (s.reset) throw IOException("sunucu akışı sıfırladı")
                failure?.let { throw if (it is IOException) it else IOException(it.message, it) }
                if (closed) throw IOException("QUIC bağlantısı kapandı")
                val left = timeoutMs - (nowMs() - t0)
                if (left <= 0) throw IOException("QUIC cevabı zaman aşımı")
                lwait(minOf(left, TICK_MS * 2L))
                if (!closed && !s.complete) tick()          // yeniden gönderim zamanlayıcısı: rx iş parçacığı boşta seyrek uyandığı için burada da sürülür
            }
            s.bytes()
        } finally {
            streams.remove(s.id)          // zaman aşımı/sıfırlama da akışı bırakır: tablo sızıntısı olmasın
        }
    }

    /** DNS-over-QUIC tarzı tek istek: yeni akış, veri + kapanış, cevap. */
    fun request(data: ByteArray, timeoutMs: Int): ByteArray {
        val s = openBidi()
        send(s, data, true)
        return await(s, timeoutMs)
    }

    // ------------------------------------------------------------------ kapanış

    private fun failLocked(e: Throwable) {
        if (failure == null) failure = e
        if (!closed) { closed = true; closeSocket() }
        lnotify()
    }

    private fun closeSocket() {
        try { sock?.close() } catch (_: Exception) {}
    }

    override fun close() {
        synchronized(lock) {
            if (closed) return
            // en iyi çaba: CONNECTION_CLOSE (uygulama, hata 0)
            if (established) {
                val o = ByteArrayOutputStream(); o.write(0x1d); putVar(o, 0); putVar(o, 0)
                try { sendDatagram(listOf(2 to listOf(o.toByteArray()))) } catch (_: Exception) {}
            }
            closed = true
            closeSocket()
            lnotify()
        }
    }

    companion object {
        private val SALT_V1 = ByteArray(20).also { val h = "38762cf7f55934b34d179ae6a4c80cadccbb7f0a"; for (i in 0 until 20) it[i] = h.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
        const val INIT_MAX_DATA = 1_048_576L
        const val STREAM_WINDOW = 262_144L
        const val CHUNK = 1000
        const val TICK_MS = 15
        const val IDLE_POLL_MS = 250
        const val IDLE_MS = 40_000L
        const val STALE_MS = 20_000L
        const val MAX_TRIES = 7
        const val MAX_RESPONSE = 65_536 * 2
        const val MAX_RX_FRAGMENTS = 64
        const val MAX_CRYPTO = 131_072
        private fun hex(h: String) = ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        /** RFC 9001 §5.8: Retry bütünlük etiketi için sabit anahtar ve nonce. */
        private val RETRY_KEYS = QuicInitial.Keys(hex("be0c690b9f66575a1d766b54e368c84e"), hex("461599d35d632bf2239825bb"), ByteArray(16))

        fun varBytes(v: Long): ByteArray = when {
            v < 64 -> byteArrayOf(v.toByte())
            v < 16384 -> byteArrayOf((0x40 or (v shr 8).toInt()).toByte(), v.toByte())
            v < (1L shl 30) -> byteArrayOf((0x80 or (v shr 24).toInt()).toByte(), (v shr 16).toByte(), (v shr 8).toByte(), v.toByte())
            else -> byteArrayOf((0xC0 or (v shr 56).toInt()).toByte(), (v shr 48).toByte(), (v shr 40).toByte(), (v shr 32).toByte(), (v shr 24).toByte(), (v shr 16).toByte(), (v shr 8).toByte(), v.toByte())
        }

        /** Sistem güven deposu. */
        fun systemTrust(): X509TrustManager {
            val f = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
            f.init(null as KeyStore?)
            return f.trustManagers.filterIsInstance<X509TrustManager>().first()
        }
    }
}
