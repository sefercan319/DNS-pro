package app.dnshizli.core

/**
 * Sunucudan gelen TLS kayıtlarının sınırlarını izler (yalnızca 5 baytlık başlıklar okunur, içerik saklanmaz).
 * Bozuk ya da TLS olmayan akışta [lost] olur ve izleme sessizce biter.
 */
class TlsTrack {
    private var have = 0
    private val hdr = ByteArray(5)
    private var left = 0
    var lost = false; private set

    fun follow(b: ByteArray, off: Int, n: Int) {
        var p = off
        var rest = n
        while (rest > 0 && !lost) {
            if (left == 0) {
                val take = minOf(5 - have, rest)
                System.arraycopy(b, p, hdr, have, take)
                have += take; p += take; rest -= take
                if (have == 5) {
                    have = 0
                    val type = hdr[0].toInt() and 0xFF
                    if (type < 20 || type > 24 || hdr[1].toInt() != 3) { lost = true; return }
                    left = ((hdr[3].toInt() and 0xFF) shl 8) or (hdr[4].toInt() and 0xFF)
                    if (left == 0) { lost = true; return }          // boş kayıt: TLS'te geçersiz, izlemeyi bırak
                }
            } else {
                val take = minOf(left, rest)
                left -= take; p += take; rest -= take
            }
        }
    }

    /** Bir kaydın ortasında mıyız (başlık ya da gövde yarım)? */
    val midRecord: Boolean get() = !lost && (left > 0 || have > 0)
}

/**
 * Bağlantı kurulduktan SONRAKİ kesintiyi anlar: bazı filtreler (İran'ın durum izleyen filtresi, Rusya'nın 16 KB dondurması)
 * el sıkışmayı geçirir, sayfayı keser. Uygulama için bu boş sayfadır; el sıkışma denetimi ise "başarı" görür.
 * Üç belirti, yalnızca TLS'te ve sunucudan [MAX_BYTES]'tan az veri gelmişken izlenir:
 *  - [Cut.STALL]: sunucu bir TLS kaydının ORTASINDA [STALL_MS] susar (gerçek sunucu kayıt ortasında saniyelerce durmaz).
 *  - [Cut.RESET]: "sunucu" bağlantıyı sıfırlar (bekleyen iş varken).
 *  - [Cut.NOREPLY]: istek gitti, [NOREPLY_MS] boyunca hiçbir şey gelmedi. En zayıfı (uzun bekleyen istek buna benzer).
 * Her bağlantı en çok bir kez bildirir; karar tek belirtiye değil, [Dpi.Planner.cut]'ta birkaç belirtiye bağlıdır.
 * Saf mantıktır: saat dışarıdan verilir, bellek yalnızca bağlantı başına bu nesnedir.
 */
class CutWatch(startMs: Long, private val stallMs: Long = STALL_MS, private val noreplyMs: Long = NOREPLY_MS) {
    enum class Cut { NONE, STALL, RESET, NOREPLY }

    private val track = TlsTrack()
    private var down = 0L
    private var lastDown = startMs
    private var waiting = 0L
    private var pending = 0
    private var reported = false

    /** Sunucudan [n] bayt geldi. */
    fun down(b: ByteArray, off: Int, n: Int, t: Long) {
        if (n <= 0) return
        down += n; lastDown = t; waiting = 0L; pending = 0
        if (down <= MAX_BYTES) track.follow(b, off, n)
    }

    /**
     * İstemci sunucuya [n] bayt yazdı. Yalnızca gerçek bir istek sayılacak kadar veri ([REQUEST_MIN]) birikince "cevap bekleniyor"
     * olur: el sıkışmanın istemci bitişi (~80 bayt) ve tarayıcının önceden açtığı boşta bağlantılar cevap beklemez, yoksa
     * her biri 15 sn sonra sahte kesinti sayılırdı.
     */
    fun up(t: Long, n: Int) {
        if (n <= 0) return
        pending += n
        if (waiting == 0L && pending >= REQUEST_MIN) waiting = t
    }

    private fun active() = !reported && down < MAX_BYTES

    /** Zamanlayıcı yoklaması: sessizlik belirtilerine bakar. Her bağlantı için en çok bir kez NONE dışı döner. */
    fun poll(t: Long): Cut {
        if (!active()) return Cut.NONE
        if (track.midRecord && t - lastDown >= stallMs) { reported = true; return Cut.STALL }
        if (waiting != 0L && t - waiting >= noreplyMs) { reported = true; return Cut.NOREPLY }
        return Cut.NONE
    }

    /**
     * Bağlantı hata ile (sıfırlama) koptu. Yalnızca havada iş varken kesinti sayılır: cevabı beklenen istek, parça parça
     * gelen kayıt. İş bittikten sonraki sıfırlama sıradan canlı tutma kapanışıdır (Microsoft, Instagram, Discord yapar).
     */
    fun reset(): Cut {
        if (!active()) return Cut.NONE
        if (waiting != 0L || track.midRecord) { reported = true; return Cut.RESET }
        return Cut.NONE
    }

    /** Test ve tanılama için: sunucudan şimdiye dek gelen bayt. */
    val bytesDown: Long get() = down

    companion object {
        const val MAX_BYTES = 64 * 1024L
        const val STALL_MS = 8_000L
        const val NOREPLY_MS = 15_000L
        const val REQUEST_MIN = 300
    }
}
