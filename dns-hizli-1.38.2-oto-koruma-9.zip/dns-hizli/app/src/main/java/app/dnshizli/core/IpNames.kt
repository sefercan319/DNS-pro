package app.dnshizli.core

/**
 * IP → alan adı belleği. Kendi çözücümüzün (tüm sağlayıcılar) tünele yazdığı DNS cevaplarındaki A/AAAA adresleri, sorulan adla
 * eşlenir. Ağ geçidi, adı görünmeyen bağlantılarda (SNI/Host yok: IP'ye doğrudan bağlanan ya da düz TCP/UDP kullanan reklam SDK'ları)
 * hedef IP'nin hangi adlara ait olduğuna bakarak Reklam+ süzgecini uygulayabilir.
 *
 * Yanlış engellemeyi önlemek için bir IP, yalnızca ona eşlenen BÜTÜN adlar süzgeçten engelli çıkarsa engellenir: aynı IP'yi (ortak CDN)
 * temiz bir ad da kullanıyorsa bağlantı geçer. Engelleme (sinkhole) cevabındaki adresler (0.0.0.0, 127.x, ::) ve yerel adresler
 * belleğe alınmaz.
 */
internal object IpNames {
    private const val MAX_IPS = 1024
    private const val MAX_NAMES_PER_IP = 4
    private const val MAX_ANSWERS = 32

    private val map = object : LinkedHashMap<String, ArrayList<String>>(256, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, ArrayList<String>>?) = size > MAX_IPS
    }

    @Synchronized fun clear() = map.clear()
    @Synchronized fun size(): Int = map.size

    @Synchronized fun note(ip: ByteArray, name: String) {
        if (sinkhole(ip) || name.isEmpty()) return
        val l = map.getOrPut(String(ip, Charsets.ISO_8859_1)) { ArrayList(2) }
        if (name in l) return
        if (l.size >= MAX_NAMES_PER_IP) l.removeAt(0)
        l.add(name)
    }

    /** [ip]'ye eşlenen adlar (en eski önce); yoksa boş. */
    @Synchronized fun namesOf(ip: ByteArray): List<String> = map[String(ip, Charsets.ISO_8859_1)]?.toList() ?: emptyList()

    /**
     * [ip]'ye eşlenmiş adların HEPSİ [engine] tarafından engelleniyorsa onlardan biri, aksi halde (ad yok ya da en az biri temiz) null.
     * [engine] ağ geçidine özel örnektir; yalnızca ağ geçidi iş parçacığından çağrılmalıdır.
     */
    fun blocked(ip: ByteArray, engine: FilterEngine): String? {
        val names = namesOf(ip)
        if (names.isEmpty()) return null
        var first: String? = null
        for (n in names) {
            if (engine.verdictOf(n) == FilterVerdict.PASS) return null
            if (first == null) first = n
        }
        return first
    }

    /**
     * Tünele yazılan bir IP paketinden (IPv4/IPv6 + UDP + DNS cevabı) adresleri öğrenir. DNS cevabı değilse, bozuksa ya da cevap
     * yoksa hiçbir şey yapmaz; hata fırlatmaz.
     */
    fun learn(b: ByteArray, off: Int, len: Int) {
        try { learn0(b, off, len) } catch (_: Exception) {}
    }

    private fun learn0(b: ByteArray, off: Int, len: Int) {
        if (len < 20 + 8 + Packets.DNS_HDR || off < 0 || off + len > b.size) return
        val end = off + len
        val ver = (b[off].toInt() and 0xFF) ushr 4
        val udp: Int
        if (ver == 4) {
            if ((b[off + 9].toInt() and 0xFF) != 17) return
            udp = off + (b[off].toInt() and 0x0F) * 4
        } else if (ver == 6) {
            if ((b[off + 6].toInt() and 0xFF) != 17) return
            udp = off + 40
        } else return
        val dns = udp + 8
        if (dns + Packets.DNS_HDR > end || Packets.u16(b, udp) != 53) return                      // kaynak portu 53: sunucu cevabı
        val flags = Packets.u16(b, dns + 2)
        if (flags and 0x8000 == 0 || flags and 0x000F != 0) return                              // cevap değil / hata kodu var
        if (Packets.u16(b, dns + 4) != 1) return
        val an = minOf(Packets.u16(b, dns + 6), MAX_ANSWERS)
        if (an == 0) return
        // soru adı (sıkıştırmasız), sonra tür+sınıf
        val sb = StringBuilder()
        var p = dns + Packets.DNS_HDR
        while (true) {
            if (p >= end) return
            val l = b[p].toInt() and 0xFF
            if (l == 0) { p++; break }
            if (l and 0xC0 != 0 || p + 1 + l > end || sb.length + l > 253) return
            if (sb.isNotEmpty()) sb.append('.')
            for (i in 1..l) sb.append((b[p + i].toInt() and 0xFF).toChar().lowercaseChar())
            p += 1 + l
        }
        p += 4
        val name = sb.toString()
        for (i in 0 until an) {
            p = Dns.skipName(b, p, end)
            if (p < 0 || p + 10 > end) return
            val type = Packets.u16(b, p)
            val rdlen = Packets.u16(b, p + 8)
            p += 10
            if (p + rdlen > end) return
            if (type == 1 && rdlen == 4) note(b.copyOfRange(p, p + 4), name)
            else if (type == 28 && rdlen == 16) note(b.copyOfRange(p, p + 16), name)
            p += rdlen
        }
    }

    private fun sinkhole(ip: ByteArray): Boolean {
        if (ip.size == 4) {
            val a = ip[0].toInt() and 0xFF
            return a == 0 || a == 127 || Dpi.isLocalAddress(ip)
        }
        if (ip.size == 16) {
            var zero = true
            for (i in 0 until 15) if (ip[i].toInt() != 0) { zero = false; break }
            return (zero && (ip[15].toInt() == 0 || ip[15].toInt() == 1)) || Dpi.isLocalAddress(ip)
        }
        return true
    }
}
