package app.dnshizli.platform

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

/**
 * Android 17 (API 37) yerel ağ izni. targetSdk 37 ve üstünde yerel ağdaki cihazlara erişim [PERMISSION] olmadan engellenir;
 * 36 ve altında izin sistemce örtük verilir (bu yüzden istek yalnızca gerekince yapılır). Yerel ağdaki DNS sunucusuna 53. port
 * üzerinden erişim muaftır. Sabit bir ad kullanılır: derleme SDK'sı 36 olduğundan Manifest sabiti burada yoktur.
 */
object LocalNetPermission {
    const val PERMISSION = "android.permission.ACCESS_LOCAL_NETWORK"
    private const val API_17 = 37

    /** Bu uygulama izni çalışma zamanında istemek zorunda mı? (Cihaz Android 17+ ve hedef SDK 37+.) */
    fun required(ctx: Context): Boolean =
        Build.VERSION.SDK_INT >= API_17 && ctx.applicationInfo.targetSdkVersion >= API_17

    /** Yerel ağ erişimi şu an serbest mi? İzin gerekmiyorsa her zaman evet. */
    fun granted(ctx: Context): Boolean =
        !required(ctx) || ctx.checkSelfPermission(PERMISSION) == PackageManager.PERMISSION_GRANTED
}
