package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Duru: sakin ve sade. Açık nane tonlu bir gökyüzü, altta yavaşça kıpırdayan saydam bir su bandı; kartlar düz, ince kenarlı ve
 * hafif saydamdır (parlak cam efekti yok), anahtarlar sade. Az hareket, az çizim: pil ve okunaklılık için. Tek vurgu rengi:
 * seçili renk temasının vurgusu. Hareket: kısa, yumuşak geçişler; bağlanınca suya düşen damlanın halkası (RING).
 */
class DuruArt(theme: AeroTheme, glass: Float) : AeroArt(theme, glass) {
    override val style: UiStyle get() = UiStyle.DURU
    override val particleMode: ParticleMode get() = ParticleMode.NONE
    override val liveSky: Boolean get() = true
    override val motion: StyleMotion = StyleMotion(PageMotion.DRIFT, 0.34f, 0.025f, 0f, depth = 0.35f, down = SpringSpec.SOFT, up = SpringSpec.SOFT, toggle = SpringSpec.SOFT, fx = FxKind.WISP)

    private val mint = 0xFF63CDBB.toInt()
    private val teal = 0xFF2E8C7E.toInt()

    private class Scene(val w: Float, val h: Float, art: DuruArt) {
        private val dk = art.dark
        private val th = art.theme
        val base = if (dk)
            Fill.linear(0f, 0f, 0f, h, Rgb.lerp(0xFF101614.toInt(), th.skyTop, 0.08f), Rgb.lerp(0xFF141C19.toInt(), th.skyMid, 0.08f), Rgb.lerp(0xFF18241F.toInt(), th.skyBottom, 0.08f), 0.55f)
        else
            Fill.linear(0f, 0f, 0f, h, Rgb.lerp(0xFFF4FAF7.toInt(), th.skyTop, 0.10f), Rgb.lerp(0xFFDDEFE9.toInt(), th.skyMid, 0.10f), Rgb.lerp(0xFFC3E3DA.toInt(), th.skyBottom, 0.10f), 0.60f)
        val glow = Fill.radial(w * 0.85f, h * 0.06f, w * 0.80f, Rgb.alpha(Rgb.WHITE, if (dk) 0.06f else 0.55f), Rgb.alpha(Rgb.WHITE, 0f))
        val waterTop = h * 0.80f
        val water = Fill.linear(0f, waterTop, 0f, h, Rgb.alpha(art.mint, if (dk) 0.10f else 0.30f), Rgb.alpha(art.teal, if (dk) 0.18f else 0.34f), Rgb.alpha(art.teal, if (dk) 0.26f else 0.46f), 0.5f)
    }

    private var scene: Scene? = null

    private fun scene(w: Float, h: Float): Scene {
        var s = scene
        if (s == null || s.w != w || s.h != h) { s = Scene(w, h, this); scene = s }
        return s
    }

    override fun sky(g: Gfx, w: Float, h: Float) = skyFrame(g, w, h, false, 0f)

    override fun skyFrame(g: Gfx, w: Float, h: Float, live: Boolean, time: Float) {
        val s = scene(w, h)
        val t = if (live) time else 0f
        g.paint(s.base); g.rect(0f, 0f, w, h)
        g.paint(s.glow); g.rect(0f, 0f, w, h)
        // su bandı: üst kenarı çok hafif dalgalanır; parlak bir ince çizgi yüzeyi belirtir
        val bob = sin(t * 0.7f) * h * 0.004f
        g.paint(s.water); g.rect(0f, s.waterTop + bob, w, h)
        g.paint(Rgb.alpha(Rgb.WHITE, if (dark) 0.14f else 0.65f)); g.rect(0f, s.waterTop + bob, w, s.waterTop + bob + max(1f, h * 0.0016f))
    }

    override fun bubble(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float) {}
    override fun particle(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float, phase: Float) {}

    // ------------------------------------------------------------------ Duru: düz, ince kenarlı, hafif saydam yüzeyler

    /** Kart: hafif saydam düz yüzey, ince kenar, çok yumuşak gölge; seçiliyken vurgu renginde ince çerçeve. */
    override fun card(g: Gfx, l: Float, t: Float, r: Float, b: Float, rad: Float, selected: Float, press: Float, strong: Float, shadow: Float) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        val rr = min(rad * 0.55f, min(w, h) / 2f)
        g.save(); g.translate(l, t)
        g.paint(Rgb.alpha(if (dark) 0xFF1F2C27.toInt() else Rgb.WHITE, (0.55f + 0.35f * strong + 0.08f * press).coerceIn(0f, 1f))); g.roundRect(0f, 0f, w, h, rr)
        if (selected > 0f || press > 0f) { g.paint(Rgb.alpha(theme.accent, 0.08f * selected + 0.07f * press)); g.roundRect(0f, 0f, w, h, rr) }
        g.strokeWidth(1f); g.paint(Rgb.alpha(if (dark) 0xFFFFFFFF.toInt() else 0xFF2E8C7E.toInt(), if (dark) 0.14f else 0.22f)); g.strokeRoundRect(0.5f, 0.5f, w - 0.5f, h - 0.5f, max(0f, rr - 0.5f))
        if (selected > 0.01f) { g.strokeWidth(1.6f); g.paint(Rgb.alpha(theme.accent, 0.85f * selected)); g.strokeRoundRect(0.8f, 0.8f, w - 0.8f, h - 0.8f, max(0f, rr - 0.8f)) }
        g.restore()
    }

    /** Anahtar: sade hap yuva, açıkken vurgu rengi; tutamaç düz beyaz daire. */
    override fun switch(g: Gfx, l: Float, t: Float, w: Float, h: Float, on: Float, press: Float) {
        val k = on.coerceIn(0f, 1f)
        g.save(); g.translate(l, t)
        g.paint(Rgb.lerp(if (dark) 0xFF2C3A35.toInt() else 0xFFC6DDD6.toInt(), theme.accent, k)); g.roundRect(0f, 0f, w, h, h / 2f)
        val cx = h / 2f + (w - h) * k
        val rad = h / 2f - 2.5f + press * 1.2f
        g.paint(Rgb.alpha(0xFF000000.toInt(), 0.14f)); g.circle(cx, h / 2f + 1f, rad)
        g.paint(Rgb.WHITE); g.circle(cx, h / 2f, rad)
        g.restore()
    }

    // ------------------------------------------------------------------ Duru: tamamen düz bileşenler (cam, parlama, gölge yok)

    private val wavePath = GPath()
    private val err = 0xFFD64545.toInt()

    /** Dolu düğme: düz vurgu rengi, köşeler yumuşak dikdörtgen (hap değil), gölge ve parlama yok. */
    override fun pill(g: Gfx, l: Float, t: Float, r: Float, b: Float, press: Float, shadow: Float) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        val rr = min(h * 0.34f, 14f)
        g.paint(Rgb.lerp(theme.control, theme.controlDeep, 0.30f + 0.25f * press)); g.roundRect(l, t, r, b, rr)
    }

    /** Ana düğme: düz daire; sıvı yerine alttan yükselen sakin su düzeyi. Cam, parlama ve baloncuk yok. */
    override fun orb(g: Gfx, cx: Float, cy: Float, r: Float, level: Float, phase: Float, glow: Float, error: Float, press: Float) {
        if (orbShape != OrbShape.CIRCLE) { super.orb(g, cx, cy, r, level, phase, glow, error, press); return }
        val lv = level.coerceIn(0f, 1f)
        val base = if (liquidColor != 0) liquidColor else theme.control
        val fillC = Rgb.lerp(base, err, error.coerceIn(0f, 1f))
        val deep = Rgb.lerp(if (liquidColor != 0) Rgb.lerp(liquidColor, 0xFF000000.toInt(), 0.25f) else theme.controlDeep, err, error.coerceIn(0f, 1f))
        // bağlıyken yavaşça nefes alan tek ince halka
        if (glow > 0.01f) {
            val k = 0.5f + 0.5f * sin(phase * 0.5f)
            g.strokeWidth(1.4f); g.paint(Rgb.alpha(fillC, 0.55f * glow * (1f - 0.5f * k))); g.strokeCircle(cx, cy, r * (1.10f + 0.08f * k))
        }
        g.paint(Rgb.alpha(if (dark) 0xFF1F2C27.toInt() else Rgb.WHITE, if (dark) 0.85f else 0.80f)); g.circle(cx, cy, r)
        if (lv > 0.012f) {
            val yLevel = cy + r - 2f * r * lv
            val amp = 2.4f * min(1f, min(lv * 5f, (1f - lv) * 5f))
            g.save(); g.clipCircle(cx, cy, r - 1f)
            val p = wavePath.reset()
            val n = 20
            val x0 = cx - r
            val x1 = cx + r
            // Eski dalga sin(phase + i·0,55) ile aynı dalga boyu: CALM hareketi bu biçimde özgün görünümü korur.
            val cyc = 0.55f * n / TAU_F
            p.moveTo(x0, cy + r + 2f)
            for (i in 0..n) {
                val x = x0 + (x1 - x0) * i / n
                p.lineTo(x, yLevel + amp * orbFlow.gain * orbGain * orbFlow.offset(i.toFloat() / n, cyc, phase))
            }
            p.lineTo(x1, cy + r + 2f); p.close()
            g.paint(fillC); g.path(p)
            g.restore()
        }
        g.strokeWidth(1.6f); g.paint(Rgb.alpha(deep, 0.75f)); g.strokeCircle(cx, cy, r - 0.8f)
        if (press > 0f) { g.paint(Rgb.alpha(deep, 0.14f * press)); g.circle(cx, cy, r) }
        val mix = Easing.clamp01((lv - 0.38f) / 0.20f)
        val off = if (dark) theme.accentLight else theme.controlDeep
        val isz = r * 0.56f
        Icons.draw(g, Icon.POWER, cx, cy + r * 0.04f, isz, Rgb.lerp(off, Rgb.WHITE, mix), 2.2f)
    }

    /** Satır başı simge: düz, yumuşak köşeli kare, vurgu renginin hafif tonu. */
    override fun iconDisc(g: Gfx, cx: Float, cy: Float, r: Float) {
        g.paint(Rgb.alpha(theme.accent, if (dark) 0.22f else 0.16f)); g.roundRect(cx - r, cy - r, cx + r, cy + r, r * 0.42f)
    }

    override fun badge(g: Gfx, cx: Float, cy: Float, r: Float) {
        g.paint(theme.control); g.circle(cx, cy, r)
        Icons.draw(g, Icon.CHECK, cx, cy, r * 1.3f, Rgb.WHITE, 2.4f)
    }

    /** Segmentli seçici: düz iz, seçili parça düz dolu. */
    override fun segmented(g: Gfx, l: Float, t: Float, r: Float, b: Float, n: Int, pos: Float) {
        val w = r - l
        val h = b - t
        val rr = min(h * 0.34f, 14f)
        g.paint(Rgb.alpha(if (dark) 0xFFFFFFFF.toInt() else 0xFF2E8C7E.toInt(), if (dark) 0.10f else 0.10f)); g.roundRect(l, t, r, b, rr)
        val inset = 3f
        val sw = (w - inset * 2f) / n
        val x = l + inset + sw * pos.coerceIn(0f, (n - 1).toFloat())
        pill(g, x, t + inset, x + sw, b - inset, 0f, 0f)
    }

    /** Üst çubuk: düz, tek ince alt çizgi. */
    override fun bar(g: Gfx, w: Float, h: Float, a: Float, skyH: Float) {
        if (a <= 0.01f) return
        g.save(); g.alpha(a)
        g.paint(Rgb.alpha(if (dark) 0xFF141C19.toInt() else 0xFFEAF5F1.toInt(), 0.96f)); g.rect(0f, 0f, w, h)
        g.paint(Rgb.alpha(if (dark) 0xFFFFFFFF.toInt() else 0xFF2E8C7E.toInt(), if (dark) 0.14f else 0.20f)); g.rect(0f, h - 1f, w, h)
        g.restore()
    }
}

private const val TAU_F = 6.2831855f
