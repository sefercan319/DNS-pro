package app.dnshizli.platform

import android.app.ActivityManager
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Display
import app.dnshizli.core.DeviceInfo
import app.dnshizli.core.DeviceMem
import app.dnshizli.core.DeviceProfiler
import app.dnshizli.core.DeviceTune
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/**
 * Bu telefonu tanır ([DeviceProfiler]) ve sonucu [DeviceTune]'a yazar. İki adım:
 *  1) Hızlı (eşzamanlı, birkaç mikrosaniye): Build alanları + bellek + ekran. Bellek sınıfına bağlı kararlar (hareket) bununla verilir.
 *  2) Arka planda, bir kez: sistem özellikleri (getprop) okunur; One UI / HyperOS gibi sistem adı ve sürümü, pazarlama adı kesinleşir.
 *     Okunamazsa (kısıtlı cihaz) 1. adımın sonucu kalır; hiçbir şey bozulmaz.
 * Ağ kullanmaz, kişisel veri okumaz; arka plan iş parçacığı en düşük öncelikte çalışır ve işini bitirince sona erer.
 */
object DeviceProbe {
    @Volatile private var started = false

    fun start(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        val base = try { baseInfo(app) } catch (_: Throwable) { DeviceInfo() }
        DeviceMem.lowRam = DeviceMem.lowRam || base.lowRamFlag
        DeviceTune.set(DeviceProfiler.detect(base))
        val t = Thread({
            try {
                val props = readProps()
                if (props.isNotEmpty()) DeviceTune.set(DeviceProfiler.detect(base.copy(props = props)))
            } catch (_: Throwable) { /* kısıtlı cihaz: hızlı adımın sonucu kalır */ }
        }, "dns-device")
        t.isDaemon = true
        t.priority = Thread.MIN_PRIORITY
        t.start()
    }

    private fun baseInfo(ctx: Context): DeviceInfo {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        var ram = 0
        if (am != null) {
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            ram = (mi.totalMem / (1024 * 1024)).toInt()
        }
        var hz = 60
        try {
            val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
            val d = dm?.getDisplay(Display.DEFAULT_DISPLAY)
            if (d != null) hz = Math.round(d.refreshRate).coerceIn(30, 240)
        } catch (_: Throwable) {}
        return DeviceInfo(
            manufacturer = Build.MANUFACTURER.orEmpty(), brand = Build.BRAND.orEmpty(), model = Build.MODEL.orEmpty(),
            display = Build.DISPLAY.orEmpty(), fingerprint = Build.FINGERPRINT.orEmpty(), tags = Build.TAGS.orEmpty(),
            sdk = Build.VERSION.SDK_INT, ramMb = ram,
            heapMb = am?.memoryClass ?: 0,
            lowRamFlag = am?.isLowRamDevice == true,
            refreshHz = hz,
        )
    }

    /** `getprop` çıktısından yalnızca ilgilendiğimiz özellikleri alır ("[anahtar]: [değer]"). En çok 3 sn, en çok 512 KB okunur. */
    private fun readProps(): Map<String, String> {
        val out = HashMap<String, String>()
        val p = ProcessBuilder("/system/bin/getprop").redirectErrorStream(true).start()
        try {
            BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).use { r ->
                var budget = 512 * 1024
                while (budget > 0) {
                    val line = r.readLine() ?: break
                    budget -= line.length + 1
                    val parsed = DeviceProfiler.parseProp(line) ?: continue
                    if (parsed.first in DeviceProfiler.PROP_KEYS && parsed.second.isNotEmpty()) out[parsed.first] = parsed.second.take(80)
                }
            }
            p.waitFor(3, TimeUnit.SECONDS)
        } finally {
            p.destroy()
        }
        return out
    }
}
