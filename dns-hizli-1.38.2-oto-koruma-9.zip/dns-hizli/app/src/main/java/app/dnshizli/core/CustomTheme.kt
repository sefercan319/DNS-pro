package app.dnshizli.core

/**
 * Özel tema: kullanıcı bir gökyüzü ve bir vurgu rengi kümesi seçer; metin ve yüzey renkleri koyuluğa göre türetilir.
 * Kayıt biçimi "gökyüzü,vurgu" (ör. "4,1"). Geçersiz ya da boş kayıt ilk kümelere ([DEFAULT]) düşer. Her kombinasyon
 * WCAG okunabilirlik testinden geçer (bkz. NewVisualTests).
 */
object CustomPalette {
    class Sky(val top: Int, val mid: Int, val bottom: Int, val dark: Boolean)
    class Accent(val accent: Int, val light: Int, val deep: Int, val control: Int, val controlDeep: Int)

    /** 4 açık, 4 koyu gökyüzü. */
    val skies: List<Sky> = listOf(
        Sky(0xFFF8E7.toInt(), 0xFFE0B0.toInt(), 0xF7B98A.toInt(), false),   // 0 Sabah
        Sky(0xE6F7FF.toInt(), 0xB5E4FA.toInt(), 0x7FC7EE.toInt(), false),   // 1 Deniz
        Sky(0xEAFBEF.toInt(), 0xBFEFCB.toInt(), 0x8ED8A4.toInt(), false),   // 2 Yeşil
        Sky(0xFFF0F7.toInt(), 0xFFCFE3.toInt(), 0xF5A6C8.toInt(), false),   // 3 Pembe
        Sky(0x0A1024, 0x1B2A5C, 0x12366B, true),                             // 4 Gece yarısı
        Sky(0x0A1A14, 0x102A20, 0x14402F, true),                             // 5 Ormanaltı
        Sky(0x121212, 0x23272F, 0x2F3640, true),                             // 6 Kömür
        Sky(0x1E0B12, 0x4A1B2E, 0x6E2A3E, true),                             // 7 Kızıl şafak
    )

    /** 6 vurgu: düğme dolgusu beyaz yazıyla okunur kadar koyu tutulur. */
    val accents: List<Accent> = listOf(
        Accent(0x2DD4BF, 0xA6FFF2.toInt(), 0x0F9C8F, 0x0E7F78, 0x0A625C),   // 0 Turkuaz
        Accent(0x2B9DF5, 0x6FE0FF, 0x1B62C9, 0x1B62C9, 0x154CA3),            // 1 Mavi
        Accent(0x9B6BF2, 0xD2B8FF.toInt(), 0x6D45D6, 0x6B43D1, 0x5532B0),    // 2 Mor
        Accent(0xF26A8A, 0xFFB8C8.toInt(), 0xC93D65.toInt(), 0xA8244E, 0x861C3F), // 3 Gül
        Accent(0xFF8A5B, 0xFFC9A8.toInt(), 0xE0683F, 0xB3502B, 0x92401F),    // 4 Turuncu
        Accent(0x3DCC5A, 0xB4F76A.toInt(), 0x1E9A4A, 0x18813F, 0x0F6A32),    // 5 Yeşil
    )

    val DEFAULT_SKY = 0
    val DEFAULT_ACCENT = 0

    fun encode(sky: Int, accent: Int): String = "$sky,$accent"

    /** (gökyüzü, vurgu) çiftini çözer; geçersizse null. */
    fun decode(s: String?): Pair<Int, Int>? {
        if (s.isNullOrBlank()) return null
        val p = s.split(',')
        if (p.size != 2) return null
        val a = p[0].trim().toIntOrNull() ?: return null
        val b = p[1].trim().toIntOrNull() ?: return null
        if (a !in skies.indices || b !in accents.indices) return null
        return a to b
    }

    /** Kayıtlı metni geçerli biçime getirir (geçersizse varsayılan çift). */
    fun normalize(s: String?): String {
        val (a, b) = decode(s) ?: (DEFAULT_SKY to DEFAULT_ACCENT)
        return encode(a, b)
    }

    private var lastKey: String? = null
    private var lastTheme: AeroTheme? = null

    /** Kayda göre tema. Aynı kayıt için aynı nesne döner (her karede yeniden kurulmaz). */
    @Synchronized
    fun theme(spec: String?): AeroTheme {
        val key = normalize(spec)
        lastTheme?.let { if (lastKey == key) return it }
        val (si, ai) = decode(key)!!
        val t = build(skies[si], accents[ai])
        lastKey = key; lastTheme = t
        return t
    }

    fun build(sky: Sky, acc: Accent): AeroTheme {
        fun c(rgb: Int) = rgb or (0xFF shl 24)
        val d = sky.dark
        return AeroTheme(
            id = Themes.CUSTOM_ID, dark = d,
            skyTop = c(sky.top), skyMid = c(sky.mid), skyBottom = c(sky.bottom),
            accentLight = c(acc.light), accent = c(acc.accent), accentDeep = c(acc.deep),
            control = c(acc.control), controlDeep = c(acc.controlDeep),
            glow = c(acc.light),
            text = if (d) c(0xE9F2FF) else c(0x1E2A33),
            textSoft = if (d) c(0xDCE8F5) else c(0x3A4A55),
            link = if (d) c(0xD2EEFF) else c(0x0E4C6E),
            tint = if (d) c(0xE4F2FF) else Rgb.WHITE,
            shadow = if (d) c(0x000000) else c(acc.controlDeep),
        )
    }
}
