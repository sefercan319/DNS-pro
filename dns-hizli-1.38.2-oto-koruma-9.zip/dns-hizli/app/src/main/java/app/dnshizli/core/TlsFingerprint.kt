package app.dnshizli.core

/**
 * ClientHello parmak izi (JA3 yöntemi): TLS sürümü, şifre listesi, uzantı listesi, eğriler ve nokta biçimleri birleştirilip MD5'lenir
 * (GREASE değerleri atılır). Aynı istemci kitaplığı (ör. bir reklam SDK'sının ağ yığını) hangi sunucuya bağlanırsa bağlansın aynı
 * parmak izini üretir; böylece ad görünmeyen bağlantılarda ek ipucu olur.
 *
 * GİZLİLİK: parmak izi yalnızca bellekte, kısa süreli hesaplanır; diske yazılmaz, cihazdan çıkmaz, IP ya da ad ile ilişkilendirilmez.
 * [observe] yalnızca parmak izi → sayaç tutar (sınırlı, son kullanılan önce), karar vermez. Engelleme yalnızca [deny] kümesine
 * elle eklenen parmak izleri için ve yalnızca adı hiç görünmeyen TLS bağlantılarında uygulanır; küme varsayılan olarak boştur.
 */
internal object TlsFingerprint {
    private const val MAX_TRACKED = 64

    private val counts = object : LinkedHashMap<String, Int>(32, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Int>?) = size > MAX_TRACKED
    }

    @Synchronized fun observe(fp: String) { counts[fp] = (counts[fp] ?: 0) + 1 }
    @Synchronized fun count(fp: String): Int = counts[fp] ?: 0
    @Synchronized fun tracked(): Int = counts.size
    @Synchronized fun clear() = counts.clear()

    private fun grease(v: Int) = (v and 0x0F0F) == 0x0A0A && (v shr 8) == (v and 0xFF)

    /** TLS kaydından (tip 0x16 + ClientHello) JA3 dizgisi; bozuk ya da eksikse null. */
    fun ja3String(b: ByteArray, len: Int): String? {
        try {
            if (len > b.size || len < 44 || b[0].toInt() != 0x16 || b[5].toInt() != 1) return null
            var p = 9                                                   // el sıkışma başlığı sonrası (5 kayıt + 4 başlık)
            val ver = u16(b, p, len) ?: return null; p += 2 + 32
            p += 1 + (u8(b, p, len) ?: return null)                    // oturum kimliği
            val csLen = u16(b, p, len) ?: return null; p += 2
            if (csLen % 2 != 0 || p + csLen > len) return null
            val ciphers = ArrayList<Int>()
            var q = p
            while (q < p + csLen) { val c = u16(b, q, len)!!; if (!grease(c)) ciphers.add(c); q += 2 }
            p += csLen
            p += 1 + (u8(b, p, len) ?: return null)                    // sıkıştırma
            val extLen = u16(b, p, len) ?: return null; p += 2
            val end = minOf(p + extLen, len)
            val exts = ArrayList<Int>(); val curves = ArrayList<Int>(); val points = ArrayList<Int>()
            while (p + 4 <= end) {
                val t = u16(b, p, len)!!; val l = u16(b, p + 2, len)!!; p += 4
                if (p + l > end) break
                if (!grease(t)) exts.add(t)
                if (t == 10 && l >= 2) {
                    var r = p + 2
                    while (r + 2 <= p + l) { val c = u16(b, r, len)!!; if (!grease(c)) curves.add(c); r += 2 }
                } else if (t == 11 && l >= 1) {
                    for (r in p + 1 until minOf(p + l, p + 1 + (b[p].toInt() and 0xFF))) points.add(b[r].toInt() and 0xFF)
                }
                p += l
            }
            if (ciphers.isEmpty()) return null
            return "$ver,${ciphers.joinToString("-")},${exts.joinToString("-")},${curves.joinToString("-")},${points.joinToString("-")}"
        } catch (_: Exception) { return null }
    }

    /** JA3 özeti (MD5, 32 onaltılı hane) ya da null. */
    fun ja3(b: ByteArray, len: Int): String? {
        val s = ja3String(b, len) ?: return null
        val d = java.security.MessageDigest.getInstance("MD5").digest(s.toByteArray(Charsets.US_ASCII))
        return d.joinToString("") { "%02x".format(it.toInt() and 0xFF) }
    }

    private fun u8(b: ByteArray, p: Int, len: Int): Int? = if (p in 0 until len) b[p].toInt() and 0xFF else null
    private fun u16(b: ByteArray, p: Int, len: Int): Int? = if (p >= 0 && p + 2 <= len) ((b[p].toInt() and 0xFF) shl 8) or (b[p + 1].toInt() and 0xFF) else null
}
