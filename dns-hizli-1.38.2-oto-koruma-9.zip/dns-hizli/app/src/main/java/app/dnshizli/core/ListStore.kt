package app.dnshizli.core

import java.io.File

/**
 * İndirilen liste dosyalarının diskte güvenli yerine konması (Android'siz; JVM'de test edilir).
 *
 * Tüm liste kümesi tek bir dizin olarak değiştirilir; dizin yeniden adlandırma tek adımdır, böylece yarım kalmış bir güncelleme
 * (uygulama ölür, disk dolar, telefon kapanır) eski ve yeni sürümden dosyaların karışmasına yol açamaz:
 *
 *  1. yeni dosyalar `liste.yeni/` içine yazılır (kurulu liste dokunulmaz),
 *  2. `liste/` → `liste.eski/`,
 *  3. `liste.yeni/` → `liste/`,
 *  4. `liste.eski/` silinir.
 *
 * Adım 2 ile 3 arasında kesilirse [recover] eskiyi geri koyar; adım 3'ten sonra kesilirse yeni sürüm yerindedir.
 * Okuyucular `liste/` altında dosya bulamazsa paketteki sürüme düşer (bkz. [FilterRuntime]); dizin hiç "yarım" görünmez.
 */
internal object ListStore {
    const val DIR = "liste"
    const val STAGE = "liste.yeni"
    const val BACKUP = "liste.eski"

    /** Kurulu listelerin dizini (yoksa oluşturulmaz). */
    fun dir(root: File): File = File(root, DIR)

    /**
     * Yarım kalmış bir yerine koymayı toparlar. Kurulu dizin yok ama yedek varsa yedek geri konur; yarım yazılmış yeni dizin ve
     * (kurulu dizin yerindeyse) artık gereksiz yedek silinir.
     */
    @Synchronized
    fun recover(root: File) {
        val cur = File(root, DIR)
        val old = File(root, BACKUP)
        if (!cur.exists() && old.exists()) old.renameTo(cur)
        deleteTree(File(root, STAGE))
        if (cur.exists()) deleteTree(old)
    }

    /**
     * [data] içindeki dosyaların hepsini (ad → içerik) tek adımda yerine koyar. Başarısızlıkta kurulu liste olduğu gibi kalır ve
     * false döner. Dosya adları yalnızca [ListUpdate.UPDATABLE] içinden olabilir (yol geçişi yok).
     */
    @Synchronized
    fun install(root: File, data: Map<String, ByteArray>): Boolean {
        val cur = File(root, DIR)
        val stage = File(root, STAGE)
        val old = File(root, BACKUP)
        try {
            if (data.isEmpty() || data.keys.any { it !in ListUpdate.UPDATABLE }) return false
            recover(root)
            if (!root.isDirectory && !root.mkdirs()) return false
            if (!stage.mkdirs()) return false
            for ((name, bytes) in data) File(stage, name).writeBytes(bytes)
            if (cur.exists() && !cur.renameTo(old)) { deleteTree(stage); return false }
            if (!stage.renameTo(cur)) {
                if (old.exists()) old.renameTo(cur)       // geri al
                deleteTree(stage)
                return false
            }
            deleteTree(old)
            return true
        } catch (_: Exception) {
            deleteTree(stage)
            if (!cur.exists() && old.exists()) old.renameTo(cur)
            return false
        }
    }

    /**
     * Önbellek, yalnızca bu uygulama sürümüyle indirilmişse kullanılır. Uygulama güncellenince paketteki listeler önbellekten daha
     * yeni olabilir; eski önbellek yeni paketi geçersiz kılıp korumayı sessizce eskitmesin diye sürüm değişince önbellek yok sayılır
     * ve güncelleme hemen yeniden denenir.
     */
    fun cacheUsable(cachedForApp: Int, currentApp: Int): Boolean = currentApp > 0 && cachedForApp == currentApp

    private fun deleteTree(f: File) {
        if (!f.exists()) return
        f.listFiles()?.forEach { if (it.isDirectory) deleteTree(it) else it.delete() }
        f.delete()
    }
}
