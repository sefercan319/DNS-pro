package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Stile özgü dokunma ve bağlanma kutlaması efektleri. Hepsi önceden hazırlanmış yollarla ve sabit parçacık tablosuyla
 * çizilir: kare başına bellek ayırmaz, rastgelelik kullanmaz (aynı dokunuş her zaman aynı görünür, test edilebilir).
 * Koordinatlar çağıranın yerel koordinatlarındadır; [t] 0..1 efekt ilerlemesidir.
 */
object StyleFx {
    /** Dokunma efektinin süresi (sn). */
    const val TAP_SEC = 0.55f

    /** Bağlanma kutlamasının süresi (sn). */
    const val CELEBRATE_SEC = 1.15f

    private const val GOLDEN = 2.3999631f      // altın açı (rad): parçacıklar eşit dağılır
    private val PASTEL = intArrayOf(0xFFFF7EB6.toInt(), 0xFFB388FF.toInt(), 0xFF7FDBFF.toInt(), 0xFFFFE066.toInt())

    private val leaf = GPath().apply {
        moveTo(0f, -1f); cubicTo(0.95f, -0.45f, 0.95f, 0.45f, 0f, 1f); cubicTo(-0.95f, 0.45f, -0.95f, -0.45f, 0f, -1f); close()
    }
    private val star = GPath().apply {
        moveTo(0f, -1f); quadTo(0.10f, -0.10f, 1f, 0f); quadTo(0.10f, 0.10f, 0f, 1f)
        quadTo(-0.10f, 0.10f, -1f, 0f); quadTo(-0.10f, -0.10f, 0f, -1f); close()
    }

    private val shard = GPath().apply {
        moveTo(0f, -1f); lineTo(0.7f, 0.8f); lineTo(-0.6f, 0.5f); close()
    }

    /** Küçük dokunma efekti: [x],[y] dokunulan nokta. */
    fun tap(kind: FxKind, g: Gfx, theme: AeroTheme, x: Float, y: Float, t: Float, variant: Int = 0, scale: Float = 1f) {
        if (kind == FxKind.NONE || t <= 0f || t >= 1f) return
        burst(kind, g, theme, x, y, t, 44f * scale, 8, false, variant)
        // Çift vuruş (varyant 3): ikinci darbe birincinin çeyrek sonrasında başlar.
        if (variant == 3 && t > 0.25f) burst(kind, g, theme, x, y, (t - 0.25f) / 0.75f, 44f * scale, 8, false, 0)
    }

    /** Büyük kutlama: [x],[y] merkez, [r] küre yarıçapı. */
    fun celebrate(kind: FxKind, g: Gfx, theme: AeroTheme, x: Float, y: Float, r: Float, t: Float, variant: Int = 0, scale: Float = 1f) {
        if (kind == FxKind.NONE || t <= 0f || t >= 1f) return
        burst(kind, g, theme, x, y, t, r * 1.8f * scale, 16, true, variant)
        if (variant == 3 && t > 0.25f) burst(kind, g, theme, x, y, (t - 0.25f) / 0.75f, r * 1.8f * scale, 16, true, 0)
    }

    private fun frac(v: Float): Float = v - kotlin.math.floor(v)

    /**
     * Stilin efekti. [variant]: 0 özgün; 1 yoğun (iki kat parçacık, biraz küçük); 2 dönen (tüm efekt merkez etrafında döner);
     * 3 çift vuruş (sarmalayıcıda ikinci darbe); 4 içe çekilen (büyükten küçüğe büzülür).
     */
    private fun burst(kind: FxKind, g: Gfx, th: AeroTheme, x: Float, y: Float, t: Float, size0: Float, count0: Int, big: Boolean, variant: Int = 0) {
        val rem = 1f - t
        val fade = rem * rem
        val ease = Easing.outCubic(t)
        val count = when (variant) { 1 -> count0 * 2; 8 -> count0 * 3 / 2; else -> count0 }
        val size = when (variant) {
            1 -> size0 * 0.85f
            4 -> size0 * (1.6f - 1.1f * ease)
            7 -> size0 * (0.5f + 0.9f * ease)     // büyüyen: küçük başlar, tam boyuta açılır
            8 -> size0 * (1.1f - 0.5f * t)         // hızlı: baştan büyük, hızla incelir
            else -> size0
        }
        g.save()
        if (variant == 2) { g.translate(x, y); g.rotate(t * 200f); g.translate(-x, -y) }
        if (variant == 5) { g.translate(x, y); g.rotate(-18f + 12f * kotlin.math.sin(t * 6.2831855f)); g.translate(-x, -y) }   // eğik, hafif sallanır
        if (variant == 6) { g.translate(x, y); g.scale(-1f, 1f); g.translate(-x, -y) }                                          // ayna: yatay yansıma
        when (kind) {
            FxKind.RING -> {
                for (i in 0 until (if (big) 3 else 2)) {
                    val u = Easing.clamp01((t - i * 0.14f) / (1f - i * 0.14f))
                    if (u <= 0f) continue
                    val rr = size * (0.25f + 0.85f * Easing.outCubic(u))
                    val a = 1f - u
                    g.paint(Rgb.alpha(th.accentLight, (a * 0.40f).coerceIn(0f, 1f))); g.circle(x, y, rr)
                    g.paint(Rgb.alpha(th.accent, (a * 0.95f).coerceIn(0f, 1f))); g.strokeWidth(3.2f * a + 1f); g.strokeCircle(x, y, rr)
                    g.paint(Rgb.alpha(Rgb.WHITE, (a * 0.8f).coerceIn(0f, 1f))); g.strokeWidth(1.2f); g.strokeCircle(x, y, rr - 2.5f)
                }
            }
            FxKind.DROP -> {
                val u = ease
                g.paint(Rgb.alpha(th.accent, (fade * 0.9f).coerceIn(0f, 1f))); g.strokeWidth(2.6f * fade + 0.8f); g.strokeCircle(x, y, size * 0.5f * u)
                for (i in 0 until count) {
                    val ang = -PI.toFloat() / 2f + (frac(i * 0.37f) - 0.5f) * 2.4f
                    val sp = 0.55f + 0.45f * frac(i * 0.618f)
                    val px = x + cos(ang) * size * sp * u * 1.1f
                    val py = y + sin(ang) * size * sp * u * 1.1f + size * 0.9f * t * t
                    val rr = size * (if (big) 0.11f else 0.10f) * (1f - 0.5f * t) * (0.7f + 0.5f * frac(i * 0.31f))
                    val a = 1f - t * t
                    g.paint(Rgb.alpha(Rgb.WHITE, (a).coerceIn(0f, 1f))); g.circle(px, py, rr)
                    g.paint(Rgb.alpha(th.accentDeep, (a).coerceIn(0f, 1f))); g.strokeWidth(1.4f); g.strokeCircle(px, py, rr)
                    g.paint(Rgb.alpha(th.accentLight, (a * 0.9f).coerceIn(0f, 1f))); g.circle(px + rr * 0.15f, py + rr * 0.2f, rr * 0.45f)
                }
            }
            FxKind.SLICE -> {
                val n = if (big) 3 else 1
                for (i in 0 until n) {
                    val u = Easing.clamp01((t - i * 0.12f) / (1f - i * 0.12f))
                    if (u <= 0f) continue
                    val half = size * (0.2f + 0.8f * Easing.outQuint(u)) * (if (big) 0.8f else 0.7f)
                    val a = 1f - u
                    g.paint(Rgb.alpha(th.accent, (a * 0.34f).coerceIn(0f, 1f))); g.rect(x - half, y - half, x + half, y + half)
                    g.paint(Rgb.alpha(th.accentDeep, (a * 0.95f).coerceIn(0f, 1f))); g.strokeWidth(2.5f)
                    g.line(x - half, y - half, x + half, y - half); g.line(x - half, y + half, x + half, y + half)
                }
            }
            FxKind.LEAF -> {
                for (i in 0 until count) {
                    val ang = i * GOLDEN
                    val sp = 0.5f + 0.5f * frac(i * 0.618f)
                    val sway = sin(t * 7f + i) * size * 0.07f
                    val px = x + cos(ang) * size * sp * ease + sway
                    val py = y + sin(ang) * size * sp * ease - size * 0.45f * t
                    val s = size * (if (big) 0.24f else 0.22f) * (0.6f + 0.5f * frac(i * 0.43f)) * (1f - 0.25f * t)
                    g.save(); g.translate(px, py); g.rotate(i * 51f + t * 220f * (if (i % 2 == 0) 1f else -1f)); g.scale(s * 0.55f, s)
                    g.paint(Rgb.alpha(if (i % 3 == 0) th.accentLight else th.accent, (1f - t * t).coerceIn(0f, 1f))); g.path(leaf)
                    g.restore()
                }
            }
            FxKind.SPARK -> {
                for (i in 0 until count) {
                    val ang = i * GOLDEN
                    val sp = 0.45f + 0.55f * frac(i * 0.618f)
                    val px = x + cos(ang) * size * sp * ease
                    val py = y + sin(ang) * size * sp * ease
                    val pop = sin(PI.toFloat() * Easing.clamp01(t * 1.05f))
                    val s = size * (if (big) 0.26f else 0.24f) * (0.55f + 0.6f * frac(i * 0.29f)) * pop
                    g.save(); g.translate(px, py); g.rotate(t * 160f * (if (i % 2 == 0) 1f else -1f)); g.scale(s, s)
                    g.paint(Rgb.alpha(PASTEL[i % PASTEL.size], (1f - t * t).coerceIn(0f, 1f))); g.path(star)
                    g.restore()
                }
                g.paint(Rgb.alpha(Rgb.WHITE, (fade * 0.5f).coerceIn(0f, 1f))); g.strokeWidth(2f); g.strokeCircle(x, y, size * 0.4f * ease)
            }
            FxKind.SWEEP -> {
                for (i in 0 until 3) {
                    g.paint(Rgb.alpha(th.accentLight, (fade * (0.34f - i * 0.09f)).coerceIn(0f, 1f))); g.circle(x, y, size * (0.35f + 0.3f * i) * (0.4f + ease))
                }
                val len = size * (if (big) 2.4f else 1.6f) * ease
                g.paint(Rgb.alpha(th.accentDeep, (fade * 0.8f).coerceIn(0f, 1f))); g.roundRect(x - len, y - 3f, x + len, y + 3f, 3f)
                g.paint(Rgb.alpha(Rgb.WHITE, (fade).coerceIn(0f, 1f))); g.roundRect(x - len * 0.9f, y - 1.6f, x + len * 0.9f, y + 1.6f, 1.6f)
                if (big) {
                    for (i in 0 until 6) {
                        val ang = i * (PI.toFloat() / 3f) + t * 0.6f
                        val d0 = size * 0.5f * ease
                        val d1 = size * (0.5f + 0.7f * ease)
                        g.paint(Rgb.alpha(Rgb.WHITE, (fade).coerceIn(0f, 1f))); g.strokeWidth(3f)
                        g.line(x + cos(ang) * d0, y + sin(ang) * d0, x + cos(ang) * d1, y + sin(ang) * d1)
                    }
                }
            }
            FxKind.GLASS -> {
                // cam mercek: yarı saydam disk, beyaz kenar ve sol üst parıltı; çevresinde küçük cam damlalar
                val rr = size * (0.15f + 0.45f * ease)
                g.paint(Rgb.alpha(th.accentLight, (fade * 0.28f).coerceIn(0f, 1f))); g.circle(x, y, rr)
                g.paint(Rgb.alpha(Rgb.WHITE, (fade * 0.85f).coerceIn(0f, 1f))); g.strokeWidth(1.6f); g.strokeCircle(x, y, rr)
                g.paint(Rgb.alpha(Rgb.WHITE, (fade).coerceIn(0f, 1f))); g.circle(x - rr * 0.36f, y - rr * 0.4f, rr * 0.11f + 0.6f)
                for (i in 0 until count) {
                    val ang = i * GOLDEN
                    val sp = 0.55f + 0.45f * frac(i * 0.618f)
                    val px = x + cos(ang) * size * sp * ease
                    val py = y + sin(ang) * size * sp * ease
                    val d = size * 0.07f * (0.6f + 0.6f * frac(i * 0.29f)) * (1f - 0.5f * t)
                    g.paint(Rgb.alpha(th.accentLight, (fade * 0.5f).coerceIn(0f, 1f))); g.circle(px, py, d)
                    g.paint(Rgb.alpha(Rgb.WHITE, (fade).coerceIn(0f, 1f))); g.strokeWidth(1.2f); g.strokeCircle(px, py, d)
                }
            }
            FxKind.WISP -> {
                // tek ince halka yavaşça açılıp solar; kutlamada üstüne birkaç yaprak usulca süzülür
                g.paint(Rgb.alpha(th.accent, (fade * 0.55f).coerceIn(0f, 1f))); g.strokeWidth(1.2f); g.strokeCircle(x, y, size * (0.20f + 0.55f * ease))
                if (big) {
                    for (i in 0 until 5) {
                        val u = Easing.clamp01((t - i * 0.05f) / (1f - i * 0.05f))
                        if (u <= 0f) continue
                        val ang = (i - 2) * 0.55f
                        val px = x + sin(ang + u * 2.2f) * size * 0.45f * (0.6f + 0.1f * i)
                        val py = y - size * 0.55f + size * 1.05f * u
                        val a = (sin(PI.toFloat() * u)).coerceIn(0f, 1f) * 0.75f
                        g.save(); g.translate(px, py); g.rotate(-40f + 80f * u + i * 30f); g.scale(size * 0.07f, size * 0.13f)
                        g.paint(Rgb.alpha(th.accent, a)); g.path(leaf); g.restore()
                    }
                }
            }
            FxKind.ORBIT -> {
                // yörünge: küçük toplar eğik bir yolda döner; yönü biçime göre değişir
                val n = (count / 2).coerceAtLeast(3)
                val dir = if (variant % 2 == 1) -1f else 1f
                val rad = size * (0.25f + 0.75f * ease)
                g.paint(Rgb.alpha(th.accentLight, Easing.clamp01(fade * 0.35f))); g.strokeWidth(1.2f); g.strokeCircle(x, y, rad)
                for (i in 0 until n) {
                    val ang = i * (2f * PI.toFloat() / n) + dir * t * 6f
                    val px = x + cos(ang) * rad
                    val py = y + sin(ang) * rad * 0.55f
                    val d = size * (if (big) 0.10f else 0.09f) * (1f - 0.5f * t)
                    g.paint(Rgb.alpha(if (i % 2 == 0) th.accent else th.accentLight, Easing.clamp01(fade)))
                    g.circle(px, py, d)
                    g.paint(Rgb.alpha(Rgb.WHITE, Easing.clamp01(fade * 0.8f))); g.circle(px - d * 0.3f, py - d * 0.3f, d * 0.35f)
                }
            }
            FxKind.PETAL -> {
                // taç yaprağı: yapraklar merkezden açılır; çift biçim hızlı döner
                val n = (count / 2).coerceAtLeast(4)
                val len = size * 0.75f * ease
                val spin = if (variant == 2) t * 120f else t * 30f
                for (i in 0 until n) {
                    g.save(); g.translate(x, y); g.rotate(i * 360f / n + spin)
                    g.translate(0f, -len * 0.5f); g.scale(len * 0.22f, len * 0.5f)
                    g.paint(Rgb.alpha(if (i % 2 == 0) th.accentLight else th.accent, Easing.clamp01(fade)))
                    g.path(leaf)
                    g.restore()
                }
                g.paint(Rgb.alpha(Rgb.WHITE, Easing.clamp01(fade))); g.circle(x, y, size * 0.07f * (1f + ease))
            }
            FxKind.BUBBLE -> {
                // kabarcıklar yükselir, büyüyüp solar; her birinin hızı ve yatay konumu farklıdır
                for (i in 0 until count) {
                    val sp = 0.4f + 0.6f * frac(i * 0.618f)
                    val px = x + (frac(i * 0.37f) - 0.5f) * size * 0.9f + sin(t * 6f + i * 1.7f) * size * 0.18f
                    val py = y + size * 0.3f - size * 1.2f * sp * ease
                    val r = size * (0.05f + 0.07f * frac(i * 0.29f)) * (1f - 0.3f * t)
                    g.paint(Rgb.alpha(Rgb.WHITE, Easing.clamp01(fade * 0.3f))); g.circle(px, py, r)
                    g.paint(Rgb.alpha(th.accent, Easing.clamp01(fade * 0.9f))); g.strokeWidth(1.2f); g.strokeCircle(px, py, r)
                    g.paint(Rgb.alpha(Rgb.WHITE, Easing.clamp01(fade))); g.circle(px - r * 0.35f, py - r * 0.35f, r * 0.22f)
                }
            }
            FxKind.BOLT -> {
                // şimşek: yukarıdan çıkan zikzak çizgiler; kutlamada daha çok dal
                val n = (count / 4).coerceAtLeast(2)
                val len = size * 1.1f * ease
                g.strokeWidth(2.2f * fade + 0.6f)
                for (i in 0 until n) {
                    val ang = -PI.toFloat() / 2f + (i - (n - 1) / 2f) * 0.55f
                    var px = x + cos(ang) * size * 0.1f
                    var py = y + sin(ang) * size * 0.1f
                    g.paint(Rgb.alpha(if (i % 2 == 0) th.accentLight else Rgb.WHITE, Easing.clamp01(fade)))
                    for (k in 1..4) {
                        val s = k / 4f
                        val jit = (frac(i * 0.37f + k * 0.61f) - 0.5f) * size * 0.25f
                        val nx = x + cos(ang) * (size * 0.1f + len * s) + jit
                        val ny = y + sin(ang) * (size * 0.1f + len * s)
                        g.line(px, py, nx, ny)
                        px = nx; py = ny
                    }
                }
            }
            FxKind.CRYSTAL -> {
                // kar tanesi: altı kol merkezden büyür, her kolda iki dal çıkar
                val rot = if (variant % 2 == 1) -t * 90f else t * 90f
                val len = size * 0.9f * ease
                g.strokeWidth(1.6f * fade + 0.6f)
                for (a in 0 until 6) {
                    g.save(); g.translate(x, y); g.rotate(a * 60f + rot)
                    g.paint(Rgb.alpha(if (a % 2 == 0) Rgb.WHITE else th.accentLight, Easing.clamp01(fade)))
                    g.line(0f, 0f, 0f, -len)
                    for (b in 1..2) {
                        val d = len * 0.35f * b
                        val bl = len * 0.3f * (1f - 0.3f * b)
                        g.line(0f, -d, bl, -d - bl)
                        g.line(0f, -d, -bl, -d - bl)
                    }
                    g.restore()
                }
            }
            FxKind.FIREFLY -> {
                // ateşböcekleri: dağınık noktalar rastgele gibi süzülür ve yanıp söner (deterministik)
                for (i in 0 until count) {
                    val r = size * (0.3f + 0.7f * frac(i * 0.618f)) * ease
                    val ang = i * GOLDEN + t * (1.5f + frac(i * 0.37f))
                    val px = x + cos(ang) * r
                    val py = y + sin(ang * 1.3f) * r * 0.8f - size * 0.1f * t
                    val blink = 0.5f + 0.5f * sin(t * 14f + i * 2.1f)
                    val a = sin(PI.toFloat() * t) * blink
                    g.paint(Rgb.alpha(th.accentLight, Easing.clamp01(a * 0.45f))); g.circle(px, py, size * 0.16f)
                    g.paint(Rgb.alpha(Rgb.WHITE, Easing.clamp01(a))); g.circle(px, py, size * 0.035f)
                }
            }
            FxKind.SPIRAL -> {
                // sarmal: merkezden dışa doğru açılan çizgi; çift biçim ters yönde sarar
                val dir = if (variant % 2 == 1) -1f else 1f
                val steps = 28
                for (arm in 0 until (if (big) 2 else 1)) {
                    val base = arm * PI.toFloat()
                    g.paint(Rgb.alpha(if (arm == 0) th.accent else th.accentLight, Easing.clamp01(fade)))
                    g.strokeWidth(2.4f * fade + 0.6f)
                    var px = x
                    var py = y
                    for (k in 1..steps) {
                        val s = k / steps.toFloat()
                        val r = size * 1.2f * s * ease
                        val ang = base + dir * s * 4.5f + dir * t * 6f
                        val nx = x + cos(ang) * r
                        val ny = y + sin(ang) * r
                        g.line(px, py, nx, ny)
                        px = nx; py = ny
                    }
                }
            }
            FxKind.RAY -> {
                // ışınlar: güneş patlaması gibi radyal çizgiler; uzunlukları düzensizdir
                val n = count.coerceAtLeast(6)
                val r0 = size * 0.2f * (0.5f + ease)
                val r1 = size * (0.5f + 0.9f * ease)
                g.strokeWidth(2.6f * fade + 0.6f)
                for (i in 0 until n) {
                    val ang = i * (2f * PI.toFloat() / n) + (if (variant == 2) t * 2f else 0f)
                    val len = r1 * (0.6f + 0.4f * frac(i * 0.37f))
                    g.paint(Rgb.alpha(if (i % 2 == 0) th.accentDeep else th.accentLight, Easing.clamp01(fade)))
                    g.line(x + cos(ang) * r0, y + sin(ang) * r0, x + cos(ang) * len, y + sin(ang) * len)
                }
            }
            FxKind.SHATTER -> {
                // kırılma: kısa beyaz bir parlama, ardından parçalar dışa savrulup döner ve düşer
                val flash = Easing.clamp01(1f - t * 3f)
                if (flash > 0f) { g.paint(Rgb.alpha(Rgb.WHITE, flash * 0.6f)); g.circle(x, y, size * 0.25f * (1f + t)) }
                for (i in 0 until count) {
                    val ang = i * GOLDEN
                    val sp = 0.6f + 0.4f * frac(i * 0.618f)
                    val d = size * sp * ease * 1.2f
                    val px = x + cos(ang) * d
                    val py = y + sin(ang) * d + size * 0.6f * t * t
                    val s = size * (if (big) 0.16f else 0.14f) * (1f - 0.6f * t) * (0.7f + 0.5f * frac(i * 0.29f))
                    g.save(); g.translate(px, py); g.rotate(i * 47f + t * 260f); g.scale(s, s)
                    g.paint(Rgb.alpha(if (i % 2 == 0) th.accent else th.accentLight, Easing.clamp01(fade)))
                    g.path(shard)
                    g.restore()
                }
            }
            FxKind.PIXEL -> {
                // piksel ızgarası: hücreler merkezden dışa doğru sırayla açılıp kapanır
                val grid = if (big) 5 else 3
                val cell = size * 0.2f
                val half = grid / 2
                for (cy in 0 until grid) for (cx in 0 until grid) {
                    val dx = cx - half
                    val dy = cy - half
                    val d = (abs(dx) + abs(dy)).toFloat()
                    val u = Easing.clamp01((t - d * 0.07f) / 0.6f)
                    if (u <= 0f) continue
                    val pulse = sin(PI.toFloat() * u)
                    val hw = cell * 0.45f * pulse * (if (variant == 4) 1f - 0.5f * u else 1f)
                    val px = x + dx * cell
                    val py = y + dy * cell
                    g.paint(Rgb.alpha(if ((cx + cy) % 2 == 0) th.accent else th.accentLight, Easing.clamp01(pulse * 0.9f)))
                    g.rect(px - hw, py - hw, px + hw, py + hw)
                }
            }
            FxKind.NONE -> {}
        }
        // Kutlamada her stil, merkezden yayılan ince bir şok halkası da alır.
        if (big && kind != FxKind.RING && kind != FxKind.WISP) {
            g.paint(Rgb.alpha(th.accent, (fade * 0.8f).coerceIn(0f, 1f))); g.strokeWidth(2.5f); g.strokeCircle(x, y, size * 0.62f * ease)
        }
        g.restore()
    }
}
