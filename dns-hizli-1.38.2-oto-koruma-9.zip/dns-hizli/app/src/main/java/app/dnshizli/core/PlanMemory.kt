package app.dnshizli.core

/**
 * Ağa göre kalıcı DPI yöntem belleği: "ağ anahtarı" (ağ türü + mobilde operatör kodu) → o ağda son çalışan TLS ve HTTP yöntemi.
 * Uygulama yeniden açıldığında ya da aynı operatöre geri dönüldüğünde denemeler doğrudan çalışan yöntemle başlar.
 * Yalnızca telefonda tutulur; anahtar ağ kimliği (SSID/BSSID) içermez, yalnızca tür ve operatör kodudur.
 * Bir yöntem artık çalışmazsa planlayıcı sıradaki yönteme geçer ve yeni çalışan kayda geçer: bellek kendini düzeltir.
 */
class PlanMemory(private val cap: Int = 16) {
    private class Rec(var tls: Int, var http: Int)

    private val map = object : LinkedHashMap<String, Rec>(16, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Rec>?) = size > cap
    }

    /** Değişiklik olduğunda çağrılır (kalıcı kayıt için); her başarıda değil, yalnızca yöntem değiştiğinde. */
    @Volatile var onChange: ((String) -> Unit)? = null

    /** Bu ağ için öğrenilmiş (tls, http) yöntemleri; bilinmeyen tür -1. Hiç kayıt yoksa null. */
    @Synchronized fun get(key: String): Pair<Int, Int>? = map[key]?.let { it.tls to it.http }

    @Synchronized fun put(key: String, kind: Int, plan: Int) {
        val r = map[key] ?: Rec(-1, -1).also { map[key] = it }
        val old = if (kind == Dpi.TLS) r.tls else r.http
        if (old == plan) return
        if (kind == Dpi.TLS) r.tls = plan else r.http = plan
        val text = encodeLocked()
        onChange?.invoke(text)
    }

    @Synchronized fun encode(): String = encodeLocked()

    private fun encodeLocked(): String =
        map.entries.joinToString(";") { "${it.key}=${it.value.tls},${it.value.http}" }

    /** Kayıtlı metni okur; bozuk ya da tanınmayan satırlar atlanır, aralık dışı yöntemler -1 olur. */
    @Synchronized fun decode(s: String?) {
        map.clear()
        if (s.isNullOrBlank()) return
        for (part in s.split(';')) {
            val eq = part.indexOf('=')
            if (eq <= 0) continue
            val key = part.substring(0, eq)
            if (!validKey(key)) continue
            val nums = part.substring(eq + 1).split(',')
            if (nums.size != 2) continue
            val t = nums[0].toIntOrNull() ?: continue
            val h = nums[1].toIntOrNull() ?: continue
            map[key] = Rec(t.takeIf { it in 0 until Dpi.TLS_PLANS } ?: -1, h.takeIf { it in 0 until Dpi.HTTP_PLANS } ?: -1)
        }
    }

    companion object {
        private val KEY_OK = Regex("[A-Z]{2,12}\\|[A-Za-z0-9-]{0,24}")

        fun validKey(k: String): Boolean = KEY_OK.matches(k)

        /** Ağ anahtarı: tür adı + etiket (mobilde operatör kodu, diğer türlerde boş). */
        fun key(kind: NetKind, label: String): String = kind.name + "|" + label.filter { it.isLetterOrDigit() || it == '-' }.take(24)
    }
}
