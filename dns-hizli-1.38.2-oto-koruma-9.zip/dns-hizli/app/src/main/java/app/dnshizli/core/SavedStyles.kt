package app.dnshizli.core

/**
 * Kayıtlı kendi stillerim. Bir kayıt; gökyüzü, vurgu, sıvı hareketi, animasyon ve ses parçası ile iki kaydırıcının
 * anlık görüntüsüdür. Metin biçimi: "gökyüzü,vurgu/hareket/animasyon/ses/animasyonYüzdesi/sıvıYüzdesi" (alanlar "/").
 * Ad tutulmaz: kayıt sırasıyla "Stil 1", "Stil 2" diye gösterilir (klavye gerektirmez).
 */
object SavedStyles {
    const val MAX = 6
    const val FX_MIN = 50
    const val FX_MAX = 150
    const val ORB_MIN = 50
    const val ORB_MAX = 170

    /** Bir kaydın çözümlenmiş hâli; geçersiz alanlar [parse] içinde reddedilir. */
    data class Parts(val customTheme: String, val orbFlow: OrbFlow, val fxPart: Int, val soundPart: Int, val fxPct: Int, val orbPct: Int)

    fun snapshot(s: AppSettings): String = listOf(
        CustomPalette.normalize(s.customTheme), s.orbFlow.id, s.fxPart, s.soundPart, s.fxPct, s.orbPct,
    ).joinToString("/")

    /**
     * Yuva listesini kodlu metinden okur. Geçersiz kayıtlar "" olur; sondaki boş yuvalar atılır (kanonik biçim), böylece
     * boş liste ile hiç kayıt olmayan ayar aynı kodlanır.
     */
    fun slots(raw: String?): List<String>? {
        if (raw == null) return null
        return raw.split(";").take(MAX).map { if (parse(it) != null) it else "" }.dropLastWhile { it.isEmpty() }
    }

    /** Kanonik biçim: sondaki boş yuvalar atılır. */
    fun canon(list: List<String>): List<String> = list.dropLastWhile { it.isEmpty() }

    fun parse(spec: String): Parts? {
        val f = spec.split("/")
        if (f.size != 6) return null   // boş yuva ("") burada reddedilir
        val theme = CustomPalette.decode(f[0]) ?: return null
        val flow = OrbFlow.byId(f[1]) ?: return null
        val fx = f[2].toIntOrNull()?.takeIf { it == -1 || FxParts.valid(it) } ?: return null
        val snd = f[3].toIntOrNull()?.takeIf { it == -1 || it in 0 until SoundParts.COUNT } ?: return null
        val fxPct = f[4].toIntOrNull()?.takeIf { it in FX_MIN..FX_MAX } ?: return null
        val orbPct = f[5].toIntOrNull()?.takeIf { it in ORB_MIN..ORB_MAX } ?: return null
        return Parts(CustomPalette.encode(theme.first, theme.second), flow, fx, snd, fxPct, orbPct)
    }

    /** Kaydı ayarlara uygular: yalnızca kendi stilim alanlarına dokunur. */
    fun apply(s: AppSettings, p: Parts): AppSettings = s.copy(
        customTheme = p.customTheme, orbFlow = p.orbFlow, fxPart = p.fxPart, soundPart = p.soundPart,
        fxPct = p.fxPct, orbPct = p.orbPct,
    )
}
