package app.dnshizli.core

/**
 * Üretici uyumluluğu: bazı Android sürümleri (özellikle Çinli üreticilerin arayüzleri) arka plandaki uygulamaları pil için
 * kapatır, telefon açılınca uygulamanın başlamasını ("otomatik başlatma") engeller. Bunun ayarı her üreticide başka bir
 * ekrandadır. Bu nesne üreticiyi tanır ve denenecek ekranları sırayla verir; saf mantıktır (Android'den bağımsız, sınanabilir).
 *
 * Ekran adları üreticilerin yıllardır değişmeyen, herkesçe bilinen ayar ekranlarıdır (bkz. dontkillmyapp.com). Hiçbiri izin
 * gerektirmez; açılamazsa (sürüm değişmiş, ekran yok) sıradakine geçilir ve en sonda Android'in standart ekranları denenir.
 */
object OemCompat {
    enum class Family(val aggressive: Boolean) {
        XIAOMI(true), HUAWEI(true), HONOR(true), OPPO(true), VIVO(true), ONEPLUS(true), TRANSSION(true), MEIZU(true), ASUS(true),
        SAMSUNG(false), NOTHING(false), CASPER(false), GOOGLE(false),
        NUBIA(true),                                                      // ZTE, nubia, RedMagic
        MOTOROLA(false), SONY(false), GENERAL_MOBILE(false), REEDER(false),
        CUSTOM_ROM(false),                                                // LineageOS, GrapheneOS, CalyxOS, /e/OS, crDroid…
        OTHER(false),
    }

    sealed class Target {
        /** Android'in uygulama ayrıntıları ekranı (Xiaomi ve Samsung'da pil + otomatik başlatma buradadır). */
        object AppDetails : Target()
        /** Android'in "pil optimizasyonu" listesi. */
        object BatteryList : Target()
        /**
         * Üreticiye özgü ekran. [withApp] doğruysa ekran hangi uygulamayı yöneteceğini ister: açarken `package_name` ve
         * `package_label` eklenir (Xiaomi "Pil tasarrufu uygulama ayarı" gibi).
         */
        data class Component(val pkg: String, val cls: String, val withApp: Boolean = false) : Target()
    }

    fun family(manufacturer: String?, brand: String?): Family {
        val m = (manufacturer ?: "").lowercase().trim()
        val b = (brand ?: "").lowercase().trim()
        fun any(vararg k: String) = k.any { m.contains(it) || b.contains(it) }
        return when {
            any("xiaomi", "redmi", "poco", "blackshark") -> Family.XIAOMI
            any("honor") -> Family.HONOR                                 // Honor, Huawei'den önce: bağımsız şirket, ayrı paket
            any("huawei") -> Family.HUAWEI
            any("oneplus") -> Family.ONEPLUS
            any("oppo", "realme") -> Family.OPPO
            any("vivo", "iqoo") -> Family.VIVO
            any("tecno", "infinix", "itel", "transsion") -> Family.TRANSSION
            any("meizu") -> Family.MEIZU
            any("asus") -> Family.ASUS
            any("samsung") -> Family.SAMSUNG
            any("nubia", "redmagic", "zte") -> Family.NUBIA
            any("motorola", "lenovo") -> Family.MOTOROLA
            any("sony") -> Family.SONY
            any("general mobile", "generalmobile") -> Family.GENERAL_MOBILE
            any("reeder") -> Family.REEDER
            any("nothing", "cmf") -> Family.NOTHING                      // Nothing OS (CMF alt markası dahil): neredeyse saf Android
            any("casper") -> Family.CASPER                               // Casper VIA: neredeyse saf Android
            any("google") -> Family.GOOGLE
            else -> Family.OTHER
        }
    }

    /** Derleme parmak izinde/adında bilinen özel ROM adları. */
    private val ROMS = listOf(
        "lineage", "graphene", "calyx", "crdroid", "evolution_x", "evolutionx", "pixelexperience", "pixel_experience", "paranoid", "arrowos",
        "havoc", "derpfest", "iode", "/e/os", "e_os", "aosp_", "omnirom", "resurrection", "pixelos", "risingos", "voltage", "bliss",
    )

    /** Cihaz üreticisinin sistemi mi, topluluk (özel) ROM mu? Özel ROM'da üretici ekranları (MIUI, One UI…) yoktur. */
    fun isCustomRom(display: String?, fingerprint: String?, tags: String?): Boolean {
        val t = "${display ?: ""} ${fingerprint ?: ""}".lowercase()
        return ROMS.any { t.contains(it) } || (tags ?: "").lowercase().contains("test-keys")
    }

    /** Üretici + ROM: özel ROM'da üretici ailesi yok sayılır (cihaz Xiaomi olsa da MIUI ekranları yoktur). */
    fun familyFor(manufacturer: String?, brand: String?, display: String?, fingerprint: String?, tags: String?): Family =
        if (isCustomRom(display, fingerprint, tags)) Family.CUSTOM_ROM else family(manufacturer, brand)

    private val COLOROS = listOf(
        Target.Component("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
        Target.Component("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"),
        Target.Component("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
    )

    /** Pil/otomatik başlatma için denenecek ekranlar, en uygundan başlayarak. Hep standart ekranlarla biter. */
    fun batteryTargets(f: Family): List<Target> {
        val oem: List<Target> = when (f) {
            // MIUI/HyperOS: uygulama ayrıntılarında hem "Otomatik başlatma" hem "Pil tasarrufu" vardır.
            // Önce bu uygulamanın "Pil tasarrufu" ekranı (Kısıtlama yok), olmazsa uygulama ayrıntıları ve otomatik başlatma listesi.
            Family.XIAOMI -> listOf(
                Target.Component("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity", withApp = true),
                Target.AppDetails,
                Target.Component("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
            )
            Family.HUAWEI -> listOf(
                Target.Component("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
                Target.Component("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.HwPowerManagerActivity"),
                Target.Component("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"),
            )
            // Honor: yeni cihazlar kendi paketini, MagicOS 3 öncesi (Huawei'den ayrılmadan önceki) cihazlar Huawei paketini kullanır.
            Family.HONOR -> listOf(
                Target.Component("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
                Target.Component("com.hihonor.systemmanager", "com.hihonor.systemmanager.optimize.process.ProtectActivity"),
                Target.Component("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            )
            Family.OPPO -> COLOROS
            Family.ONEPLUS -> listOf(Target.Component("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity")) + COLOROS
            Family.VIVO -> listOf(
                Target.Component("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
                Target.Component("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"),
            )
            Family.TRANSSION -> listOf(Target.Component("com.transsion.phonemaster", "com.cyin.himgr.autostart.AutoStartActivity"))
            Family.MEIZU -> listOf(Target.Component("com.meizu.safe", "com.meizu.safe.permission.SmartBGActivity"))
            Family.ASUS -> listOf(Target.Component("com.asus.mobilemanager", "com.asus.mobilemanager.powersaver.PowerSaverSettings"))
            // One UI: uygulama ayrıntıları → Pil → "Kısıtlanmamış" en kısa yoldur ("uyuyan uygulamalar"dan da çıkarır).
            // Önce Cihaz bakımı'nın pil ekranı ("uyuyan uygulamalar" / "hiç uyumayan uygulamalar" buradadır; paket adı One UI sürümüne göre değişir).
            Family.SAMSUNG -> listOf(
                Target.Component("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"),
                Target.Component("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"),
                Target.AppDetails,
            )
            // Nothing OS ve Casper VIA neredeyse saf Android: standart pil optimizasyonu listesi ve uygulama ayrıntıları yeter.
            // ZTE / nubia / RedMagic: kendi arayüzlerinde ekran adları sürüme göre değişir; uygulama ayrıntıları en güvenli yoldur.
            Family.NUBIA -> listOf(Target.AppDetails)
            // Saf (ya da saf'a yakın) Android: standart pil optimizasyonu listesi ve uygulama ayrıntıları yeter.
            Family.NOTHING, Family.CASPER, Family.GOOGLE, Family.MOTOROLA, Family.SONY, Family.GENERAL_MOBILE, Family.REEDER,
            Family.CUSTOM_ROM, Family.OTHER -> emptyList()
        }
        val tail = if (Target.AppDetails in oem) listOf(Target.BatteryList) else listOf(Target.BatteryList, Target.AppDetails)
        return oem + tail
    }
}
