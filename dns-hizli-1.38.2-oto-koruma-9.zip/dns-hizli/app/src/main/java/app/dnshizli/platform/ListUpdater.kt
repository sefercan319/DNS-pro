package app.dnshizli.platform

import android.content.Context
import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.ListStore
import app.dnshizli.core.ListUpdate
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.HttpsURLConnection

/**
 * Engelleme listelerini arka planda, imzalı olarak günceller.
 *
 * Akış: manifest + imzası indirilir → imza gömülü açık anahtarla doğrulanır → sürüm kurulu sürümden yeni olmalı →
 * her liste indirilir, boyu ve özeti manifestle eşleşmeli → hepsi tamam olunca tek adımda yerine konur ([ListStore]:
 * dizin değişimi, yarım kalan güncelleme eski ve yeni dosyaları karıştırmaz) → motor yeniden kurulur. Herhangi bir adımda hata
 * olursa mevcut listeler olduğu gibi kalır.
 *
 * Uygulama sürümü değişince indirilmiş önbellek yok sayılır (paketteki listeler daha yeni olabilir) ve güncelleme hemen
 * yeniden denenir; önbellek yalnızca kendi uygulama sürümüyle indirilmişse okunur.
 *
 * Gizlilik: yalnızca HTTPS ile sabit adreslerden dosya çekilir. Kimlik, cihaz ya da kullanım bilgisi gönderilmez
 * (istek başlıkları varsayılandır). Sunucu tarafında IP adresi görülebilir; bu GİZLILIK.md'de belirtilir.
 */
object ListUpdater {
    /**
     * Yayın adresi (GitHub Releases, "listeler" etiketi). Derleme ortamından gelir ([app.dnshizli.BuildConfig.LIST_BASE_URL]:
     * GitHub Actions'ta deponun kendi adresi); boşsa aşağıdaki sabit kullanılır.
     */
    private const val BASE_URL_FALLBACK = "https://github.com/OWNER/REPO/releases/download/listeler/"
    val BASE_URL: String get() = app.dnshizli.BuildConfig.LIST_BASE_URL.ifEmpty { BASE_URL_FALLBACK }

    /**
     * Manifest imzasını doğrulayan ECDSA P-256 açık anahtarı (X.509 DER, base64). BOŞ BIRAKILIRSA GÜNCELLEME KAPALIDIR.
     * Anahtar üretimi ve yayın kurulumu: tools/yayin/README.md
     */
    const val PUBLIC_KEY_B64 = ""

    /** Derleme ortamından gelen anahtar ([app.dnshizli.BuildConfig.LIST_PUBLIC_KEY], GitHub gizli değeri) öncelikli. */
    private val keyB64: String get() = app.dnshizli.BuildConfig.LIST_PUBLIC_KEY.ifEmpty { PUBLIC_KEY_B64 }

    private const val PREFS = "liste_guncelleme"
    private const val KEY_VERSION = "surum"
    private const val KEY_CHECKED = "son_kontrol"
    private const val KEY_APP = "uygulama_surumu"
    /**
     * Denetim sıklığı: dönen reklam/yönlendirme adları listelere birkaç saat içinde girer, yayın her gün yenilenir.
     * Kotasız ağda (Wi-Fi) 12 saatte bir, ölçülü ağda (mobil veri) 3 günde bir denenir: listeler birkaç MB'tır.
     */
    private const val CHECK_UNMETERED_MS = 12L * 60 * 60_000
    private const val CHECK_METERED_MS = 72L * 60 * 60_000
    private const val TIMEOUT_MS = 15_000

    /** Tek bir dosyanın toplam indirme süresi: damla damla veri yollayan bir sunucu arka plan işini sonsuza dek tutamaz. */
    private const val TOTAL_MS = 90_000L
    private const val SIG_MAX = 512

    private val running = AtomicBoolean(false)
    @Volatile private var recovered = false

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun installedVersion(ctx: Context): Long = prefs(ctx).getLong(KEY_VERSION, 0L)

    /**
     * Kaynak: bu uygulama sürümüyle indirilmiş ve güncellenebilen bir liste varsa önbellekten, yoksa paketten okunur. Önbellek
     * dosyası bozuksa motor [FilterRuntime] içinde paketteki sürüme düşer.
     */
    fun open(ctx: Context, name: String): InputStream {
        if (name in ListUpdate.UPDATABLE && cacheUsable(ctx)) {
            val f = File(ListStore.dir(ctx.filesDir), name)
            if (f.isFile) return FileInputStream(f)
        }
        return ctx.assets.open("filter/$name")
    }

    private fun cacheUsable(ctx: Context): Boolean {
        if (!recovered) { ListStore.recover(ctx.filesDir); recovered = true }
        return ListStore.cacheUsable(prefs(ctx).getInt(KEY_APP, 0), app.dnshizli.BuildConfig.VERSION_CODE)
    }

    /** Açılışta çağrılır: son denemeden bu yana bir gün geçtiyse ve açık anahtar tanımlıysa arka planda dener. */
    fun maybeUpdate(ctx: Context) {
        if (ListUpdate.publicKey(decodeKey()) == null) return
        val p = prefs(ctx)
        if (p.getInt(KEY_APP, 0) != app.dnshizli.BuildConfig.VERSION_CODE) {
            // Uygulama güncellendi (ya da ilk açılış): önbellek yok sayılır; sürüm ve sıklık sınırı sıfırlanır, hemen denenir.
            p.edit().putLong(KEY_VERSION, 0L).putLong(KEY_CHECKED, 0L).apply()
        }
        val last = p.getLong(KEY_CHECKED, 0L)
        val now = System.currentTimeMillis()
        val every = if (metered(ctx)) CHECK_METERED_MS else CHECK_UNMETERED_MS
        if (last in 1..now && now - last < every) return
        Thread({ runCatching { updateNow(ctx) } }, "liste-guncelleme").also { it.isDaemon = true }.start()
    }

    /** Güncellemeyi hemen dener. Yeni bir sürüm uygulandıysa true. Aynı anda tek güncelleme çalışır. */
    fun updateNow(ctx: Context): Boolean {
        val key = ListUpdate.publicKey(decodeKey()) ?: return false
        if (!running.compareAndSet(false, true)) return false
        try {
            return update(ctx, key)
        } finally {
            running.set(false)
        }
    }

    private fun update(ctx: Context, key: java.security.PublicKey): Boolean {
        val p = prefs(ctx)
        val manifest = fetch("manifest.txt", ListUpdate.MAX_MANIFEST) ?: return false
        val sig = fetch("manifest.sig", SIG_MAX) ?: return false
        // Sıklık sınırı yalnızca sunucuya gerçekten ulaşılınca işler: çevrimdışıyken yapılan başarısız deneme 12 saat ya da 3 gün
        // boyunca yeni denemeyi engellemesin.
        p.edit().putLong(KEY_CHECKED, System.currentTimeMillis()).apply()
        if (!ListUpdate.verifySignature(manifest, sig, key)) return false
        val m = ListUpdate.parse(manifest) ?: return false
        if (!ListUpdate.isNewer(installedVersion(ctx), m)) return false

        // Önce hepsini belleğe al ve doğrula: tek bir dosya bile uyuşmazsa hiçbir şey yerine konmaz.
        val data = LinkedHashMap<String, ByteArray>()
        for (e in m.entries) {
            val bytes = fetch(e.name, ListUpdate.MAX_FILE.toInt()) ?: return false
            if (!ListUpdate.matches(bytes, e)) return false
            data[e.name] = bytes
        }

        if (!ListStore.install(ctx.filesDir, data)) return false
        p.edit().putLong(KEY_VERSION, m.version).putInt(KEY_APP, app.dnshizli.BuildConfig.VERSION_CODE).apply()
        FilterRuntime.reloadLists()
        return true
    }

    /** Sabit bir yayın adresinden en çok [max] bayt okur. Hata, HTTP hatası, süre ya da sınır aşımında null. */
    private fun fetch(name: String, max: Int): ByteArray? {
        if (!BASE_URL.startsWith("https://")) return null
        val conn = URL(BASE_URL + name).openConnection() as? HttpsURLConnection ?: return null
        return try {
            conn.connectTimeout = TIMEOUT_MS
            conn.readTimeout = TIMEOUT_MS
            conn.instanceFollowRedirects = false             // yönlendirmeyi elle, yalnızca izinli https adreslerine izleriz
            conn.useCaches = false
            conn.setRequestProperty("Accept", "application/octet-stream")
            var c: HttpsURLConnection = conn
            var hops = 0
            while (c.responseCode in intArrayOf(301, 302, 303, 307, 308)) {
                if (++hops > 4) return null
                val loc = c.getHeaderField("Location") ?: return null
                val next = try { URL(c.url, loc) } catch (_: Exception) { return null }
                if (next.protocol != "https" || !redirectHostOk(next.host)) return null
                if (c !== conn) c.disconnect()
                c = next.openConnection() as? HttpsURLConnection ?: return null
                c.connectTimeout = TIMEOUT_MS
                c.readTimeout = TIMEOUT_MS
                c.instanceFollowRedirects = false
                c.useCaches = false
                c.setRequestProperty("Accept", "application/octet-stream")
            }
            if (c.responseCode != HttpURLConnection.HTTP_OK) { if (c !== conn) c.disconnect(); return null }
            val deadline = System.nanoTime() + TOTAL_MS * 1_000_000L
            try { c.inputStream.use { readCapped(it, max, deadline) } } finally { if (c !== conn) c.disconnect() }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    /**
     * Yönlendirme yalnızca yayın adresinin kendi alan adına ya da GitHub'ın dosya dağıtım adlarına izlenir. (İçerik zaten imza
     * ve özetle doğrulanır; bu, istemciyi beklenmedik bir sunucuya götürülmekten de korur.)
     */
    private fun redirectHostOk(host: String): Boolean {
        val h = host.lowercase()
        val base = try { URL(BASE_URL).host.lowercase() } catch (_: Exception) { "" }
        return h == base || h == "github.com" || h.endsWith(".githubusercontent.com") || h.endsWith(".github.com")
    }

    private fun readCapped(input: InputStream, max: Int, deadlineNanos: Long): ByteArray? {
        val out = ByteArrayOutputStream(64 * 1024)
        val buf = ByteArray(16 * 1024)
        while (true) {
            if (System.nanoTime() - deadlineNanos > 0L) return null
            val n = input.read(buf)
            if (n < 0) break
            if (out.size() + n > max) return null
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    /** Etkin ağ ölçülü mü (mobil veri, kotalı Wi-Fi)? Bilinmiyorsa ölçülü sayılır (veri harcanmasın). */
    private fun metered(ctx: Context): Boolean = try {
        val cm = ctx.getSystemService(android.net.ConnectivityManager::class.java)
        cm == null || cm.isActiveNetworkMetered
    } catch (_: Exception) {
        true
    }

    private fun decodeKey(): ByteArray =
        if (keyB64.isEmpty()) ByteArray(0) else try {
            java.util.Base64.getDecoder().decode(keyB64)
        } catch (_: IllegalArgumentException) {
            ByteArray(0)
        }
}
