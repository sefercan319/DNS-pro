package app.dnshizli.core

/**
 * Güvenlik vanası (ağ geçidi bağlantı kuramıyor → modüller kapanır) sonrası kendiliğinden geri açma takvimi.
 * Her ardışık kesintide bekleme 3 katına çıkar (5, 15, 45 dk), en çok 60 dk: geçici ağ sorunu reklam engelini ve DPI atlatmayı
 * kalıcı kapatmaz, gerçekten bozuk bir ağda da sürekli açılıp kapanıp pil/kesinti yaratmaz.
 */
object GwRecovery {
    const val BASE_MS = 5 * 60_000L
    const val MAX_MS = 60 * 60_000L

    /** [tripCount]: bu dahil ardışık vana sayısı (1 = ilk kesinti). */
    fun waitMs(tripCount: Int): Long {
        var w = BASE_MS
        for (i in 1 until tripCount.coerceAtLeast(1)) w = minOf(w * 3, MAX_MS)
        return w
    }
}
