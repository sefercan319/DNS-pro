package app.dnshizli.core

/**
 * Animasyon parçaları: 18 efekt türü ([FxKind], NONE hariç) × 9 biçim ([FxVariants]). Parça [i] = tür (i / 9) ve biçim
 * (i % 9). Kendi stilim menüsünde stilin kendi animasyonunun yerine seçilir; -1 = stilin kendi animasyonu.
 * Türler eklenirken sona eklenir: eski kayıtlardaki parça dizinleri aynı türü göstermeye devam eder.
 */
object FxParts {
    const val VARIANTS = 9
    val KINDS: List<FxKind> = FxKind.values().filter { it != FxKind.NONE }
    val COUNT: Int = KINDS.size * VARIANTS

    fun valid(i: Int): Boolean = i in 0 until COUNT
    fun kind(i: Int): FxKind = KINDS[i / VARIANTS]
    fun variant(i: Int): Int = i % VARIANTS

    /** Tür ve biçimden parça dizini. */
    fun index(kind: FxKind, variant: Int): Int = KINDS.indexOf(kind) * VARIANTS + variant.coerceIn(0, VARIANTS - 1)
}
