package app.dnshizli.core

/**
 * Dışarıdan gelen kısa metinlerin (cihaz adı, sistem özellikleri, tanılama alanları) ekrana ve paylaşılan rapora girmeden
 * önce temizlenmesi. Kontrol karakterleri satır sonu/sekme gibi şeyleri taşıyıp raporda sahte satır açabilir; yön değiştirici
 * ve görünmez karakterler ise yazının nasıl okunduğunu gizlice değiştirir (ör. U+202E sağdan sola geçiş).
 */
object TextSafe {
    /** Görünmez, yön değiştiren ya da kontrol amaçlı karakter mi? Boşluk sayılmaz. */
    fun isHidden(c: Char): Boolean {
        val k = c.code
        return k < 0x20 || k == 0x7F || k in 0x80..0x9F ||
            k in 0x200B..0x200F || k in 0x202A..0x202E || k in 0x2060..0x2064 || k in 0x2066..0x206F || k == 0xFEFF || k == 0xFFFC || k == 0xFFFD
    }

    /**
     * Tek satırlık, güvenli metin: sekme ve satır sonları boşluğa döner, gizli karakterler silinir, ardışık boşluklar tek olur,
     * uç boşluklar kırpılır ve en çok [max] karakter kalır (ikili karakterin ortasından kesilmez).
     */
    fun line(s: String?, max: Int): String {
        if (s.isNullOrEmpty() || max <= 0) return ""
        val sb = StringBuilder(minOf(s.length, max + 1))
        var lastSpace = true
        for (c in s) {
            if (sb.length >= max) break
            val sp = c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == ' ' || c == ' ' || c == ' '
            if (sp) { if (!lastSpace) { sb.append(' '); lastSpace = true }; continue }
            if (isHidden(c)) continue
            sb.append(c); lastSpace = false
        }
        while (sb.isNotEmpty() && sb[sb.length - 1] == ' ') sb.setLength(sb.length - 1)
        if (sb.isNotEmpty() && Character.isHighSurrogate(sb[sb.length - 1])) sb.setLength(sb.length - 1)
        return sb.toString()
    }
}
