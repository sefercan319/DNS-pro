package app.dnshizli.ui

import app.dnshizli.core.CustomPalette
import app.dnshizli.core.ALIGN_CENTER
import app.dnshizli.core.ALIGN_LEFT
import app.dnshizli.core.ALIGN_RIGHT
import app.dnshizli.core.AppSettings
import app.dnshizli.core.Easing
import app.dnshizli.core.Gfx
import app.dnshizli.core.Icon
import app.dnshizli.core.Icons
import app.dnshizli.core.Rgb
import app.dnshizli.core.Sfx
import app.dnshizli.core.TextFit
import app.dnshizli.core.AeroTheme
import app.dnshizli.core.Themes
import kotlin.math.abs
import kotlin.math.roundToInt

/** Başlıklı bölümün cam kartı: satırları alt alta dizer, aralarına ince çizgi koyar. */
class SettingsCard : Node() {
    override fun layout(env: Env, maxW: Float) {
        w = maxW
        var cy = 0f
        for (k in kids) {
            if (!k.visible) continue
            k.layout(env, maxW)
            k.x = 0f
            k.y = cy
            cy += k.h
        }
        h = cy
    }

    override fun draw(g: Gfx, env: Env) {
        env.art.card(g, 0f, 0f, w, h, M.CARD_R)
        drawKids(g, env)
        g.paint(Rgb.alpha(Rgb.WHITE, if (env.theme.dark) 0.14f else 0.55f))
        var prev: Node? = null
        var i = 0
        while (i < kids.size) {
            val k = kids[i++]
            if (!k.visible) continue
            if (prev != null) { val yy = prev.y + prev.h; g.rect(16f, yy - 0.5f, w - 16f, yy + 0.5f) }
            prev = k
        }
    }
}

/** Bölüm başlığı (küçük, yumuşak renkli). */
class SectionTitle(text: String) : Node() {
    // Uzun çeviri ya da büyük yazıda başlık kesilmez: en çok 2 satıra sarılır.
    private val label = Label(text, 13f, bold = true, ink = Ink.SOFT, maxLines = 2)
    override fun layout(env: Env, maxW: Float) {
        label.layout(env, maxW - 16f)
        label.x = 8f; label.y = 10f
        w = maxW
        h = label.h + 18f
    }
    override fun draw(g: Gfx, env: Env) { g.save(); g.translate(label.x, label.y); label.draw(g, env); g.restore() }
    override fun a11y(): A11y = A11y(label.text, Role.HEADING)
}

/** Satır içi basılma vurgusu: köşeleri yuvarlak, kartın kenarına taşmaz. */
private fun pressGlow(g: Gfx, env: Env, w: Float, h: Float, v: Float) {
    if (v <= 0.01f) return
    g.save(); g.alpha(v)
    g.paint(Rgb.alpha(env.theme.accent, 0.16f))
    g.roundRect(6f, 4f, w - 6f, h - 4f, 16f)
    g.restore()
}

/** Başlık + (varsa) açıklama (en çok 2 satır) + sağda anahtar. Satırın her yerine dokunmak anahtarı çevirir. */
class ToggleRow(
    private val title: String,
    private val note: String?,
    private val get: (AppSettings) -> Boolean,
    private val set: (AppSettings, Boolean) -> AppSettings,
) : PressNode() {
    private val on = Anim(0f)
    private var titleLines: List<String> = emptyList()
    private var noteLines: List<String> = emptyList()
    private var laidW = -1f
    private var laidFs = 0f

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        relay(env)
        on.set(if (get(env.model.settings)) 1f else 0f)
    }

    /** En çok [max] satıra sarar; sığmayan son satır "…" ile kısalır (büyük yazı boyutunda da taşmaz). */
    private fun wrapN(env: Env, text: String, avail: Float, size: Float, bold: Boolean, max: Int): List<String> {
        val l = TextFit.wrap(env.metrics, text, avail, size, bold)
        if (l.size <= max) return l
        val out = ArrayList<String>(max)
        for (i in 0 until max - 1) out.add(l[i])
        out.add(TextFit.ellipsize(env.metrics, l[max - 1] + " …", avail, size, bold))
        return out
    }

    private fun relay(env: Env) {
        val avail = w - 16f - 52f - 16f - 12f
        val t = env.sz(16f)
        val s = env.sz(13f)
        titleLines = wrapN(env, title, avail, t, true, 2)
        // Büyük yazı boyutunda not daha çok satıra yayılır (4 satır yetmez, son satır kesilirdi).
        noteLines = if (note == null) emptyList() else wrapN(env, note, avail, s, false, if (env.fs > 1.1f) 6 else 4)
        h = if (noteLines.isEmpty() && titleLines.size == 1) 58f
        else 16f + t * 0.95f + (titleLines.size - 1) * t * 1.25f + (if (noteLines.isEmpty()) 0f else 8f + noteLines.size * s * 1.32f) + 14f
        laidW = w
        laidFs = env.fs
    }

    override fun tick(dt: Float, env: Env): Boolean {
        val tgt = if (get(env.model.settings)) 1f else 0f
        if (on.target != tgt) { if (env.motion <= 0f) on.set(tgt) else on.springTo(tgt, env.art.motion.toggle, env.speed) }
        return on.step(dt) or super.tick(dt, env)
    }

    override fun draw(g: Gfx, env: Env) {
        if (laidW != w || laidFs != env.fs) relay(env)
        pressGlow(g, env, w, h, press.value)
        val t = env.sz(16f)
        val s = env.sz(13f)
        g.paint(env.theme.text)
        if (noteLines.isEmpty() && titleLines.size == 1) {
            g.text(titleLines[0], 16f, centerBaseline(h / 2f, t), t, true, ALIGN_LEFT)
        } else {
            val tb = 16f + t * 0.95f
            for (i in 0 until titleLines.size) g.text(titleLines[i], 16f, tb + i * t * 1.25f, t, true, ALIGN_LEFT)
            val last = tb + (titleLines.size - 1) * t * 1.25f
            g.paint(env.theme.textSoft)
            for (i in 0 until noteLines.size) g.text(noteLines[i], 16f, last + 8f + (i + 1) * s * 1.32f - s * 0.25f, s, false, ALIGN_LEFT)
        }
        env.art.switch(g, w - 16f - 52f, (h - 30f) / 2f, 52f, 30f, on.value.coerceIn(0f, 1f), press.value)
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) {
            val turningOn = !get(env.model.settings)
            env.tap(true, if (turningOn) Sfx.TOGGLE_ON else Sfx.TOGGLE_OFF)
            env.model.update { set(it, !get(it)) }
        }
    }

    override fun a11y(): A11y = A11y(title + (note?.let { ", $it" } ?: ""), Role.SWITCH, checked = on.target > 0.5f)
}

/** Başlık + değer + altında kaydırıcı. */
class SliderRow(
    private val title: String,
    private val get: (AppSettings) -> Float,
    private val set: (AppSettings, Float) -> AppSettings,
    private val valueText: (AppSettings) -> String,
    /** Parmak kalkınca (sürükleme ya da dokunma bitince) bir kez çağrılır; ör. ses düzeyi için örnek ses çalmak. */
    private val onRelease: ((AppModel) -> Unit)? = null,
) : Node() {
    private val v = Anim(0f)
    private val knobPress = Anim(0f)
    private var dragging = false
    override val tappable: Boolean get() = true
    override val dragCapture: Boolean get() = true
    override val dragActive: Boolean get() = dragging

    private var envRef: Env? = null
    private var lastValue = ""
    private var seenVersion = -1
    private var titleShown = title
    private var fitW = -1f
    private var fitFs = 0f

    override fun layout(env: Env, maxW: Float) { envRef = env; w = maxW; h = 84f; v.set(get(env.model.settings)); seenVersion = -1; syncText(env) }

    private fun syncText(env: Env) {
        if (seenVersion != env.model.version || fitW != w || fitFs != env.fs) {
            seenVersion = env.model.version
            lastValue = valueText(env.model.settings)
            // Başlık değerin üstüne binmesin (büyük yazı, uzun çeviri): önce değer yer alır, başlık kalanına sığacak biçimde kısalır.
            fitW = w; fitFs = env.fs
            val vw = env.metrics.textWidth(lastValue, env.sz(14f), false)
            titleShown = TextFit.ellipsize(env.metrics, title, w - 32f - vw - 12f, env.sz(16f), true)
        }
    }

    private val trackL = 16f
    private fun trackW() = w - 32f
    private fun valueAt(lx: Float): Float = Easing.clamp01((lx - trackL - 12f) / (trackW() - 24f))

    override fun contains(lx: Float, ly: Float): Boolean = lx >= 0f && lx <= w && ly >= 36f && ly <= h

    private var detent = -1

    private fun apply(lx: Float, env: Env) {
        val nv = valueAt(lx)
        v.set(nv)
        // Her %10'luk basamakta (ve uçlarda) hafif titreşim: kaydırıcı sürüklenirken "tık" hissedilir.
        val d = (nv * 10f + 0.5f).toInt()
        if (d != detent) {
            if (detent >= 0 && env.model.settings.haptics) env.model.host.haptic(false)
            detent = d
        }
        env.model.update { set(it, nv) }
    }

    private fun knobX(): Float = trackL + 12f + (trackW() - 24f) * v.value

    /**
     * Topuz tutulduysa sürükleme hemen başlar. Parça üzerine dokunulursa değer yalnızca dokunma bitince
     * (kısa dokunuş) ya da yatay sürükleme başlayınca değişir; böylece sayfayı kaydırırken değer kazara oynamaz.
     */
    override fun onDown(lx: Float, ly: Float, env: Env) {
        detent = (v.value * 10f + 0.5f).toInt()
        dragging = abs(lx - knobX()) <= 28f
        if (dragging) knobPress.go(1f, env.dur(0.1f))
    }
    override fun onDragStart(lx: Float, ly: Float, env: Env) { dragging = true; knobPress.go(1f, env.dur(0.1f)) }
    override fun onDrag(lx: Float, ly: Float, env: Env) { if (dragging) apply(lx, env) }
    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        val wasDrag = dragging
        dragging = false
        knobPress.go(0f, env.dur(0.25f))
        if (tap && !wasDrag) apply(lx, env)
        if (wasDrag || tap) onRelease?.invoke(env.model)
    }
    override fun onCancel(env: Env) { dragging = false; knobPress.go(0f, env.dur(0.25f)) }
    override fun a11yClick(env: Env) {}

    override fun tick(dt: Float, env: Env): Boolean {
        syncText(env)
        if (!dragging) { val g = get(env.model.settings); if (abs(g - v.value) > 0.001f) v.go(g, env.dur(0.2f)) }
        return v.step(dt) or knobPress.step(dt)
    }

    override fun draw(g: Gfx, env: Env) {
        val t = env.sz(16f)
        g.paint(env.theme.text)
        syncText(env)
        g.text(titleShown, 16f, 34f, t, true, ALIGN_LEFT)
        g.paint(env.theme.textSoft)
        g.text(lastValue, w - 16f, 34f, env.sz(14f), false, ALIGN_RIGHT)
        env.art.slider(g, trackL, 62f, trackW(), v.value, knobPress.value)
        // Tutulurken değer topuzun üstünde balon olarak görünür (parmak altında kalan sayıyı gizlemez).
        val kp = knobPress.value
        if (kp > 0.05f && lastValue.isNotEmpty()) {
            val fs = env.sz(13f)
            val bw = env.metrics.textWidth(lastValue, fs, true) + 20f
            val bh = fs + 14f
            val bx = (knobX() - bw / 2f).coerceIn(4f, w - bw - 4f)
            val by = 40f - kp * 6f
            g.save()
            g.alpha(Easing.clamp01(kp))
            env.art.card(g, bx, by - bh, bw, bh, bh / 2f, strong = 0.9f, shadow = 0.8f)
            g.paint(env.theme.text)
            g.text(lastValue, bx + bw / 2f, centerBaseline(by - bh / 2f, fs), fs, true, ALIGN_CENTER)
            g.restore()
        }
    }

    override fun a11y(): A11y = A11y(title, Role.SLIDER, value = envRef?.let { valueText(it.model.settings) } ?: lastValue)
    override fun a11yAdjust(dir: Int, env: Env) {
        // %5'lik basamaklar: 0,1 + 0,1 + 0,1 gibi toplamlar 0,3000001'e kaymaz; değer her adımda ızgaraya oturur.
        val nv = Easing.clamp01(Math.round((get(env.model.settings) + 0.05f * dir) * 20f) / 20f)
        v.set(nv)
        env.model.update { set(it, nv) }
        onRelease?.invoke(env.model)
    }
}

/** Başlık + altında segmentli seçici. Her seçenek ayrıca erişilebilir bir düğümdür. */
class SegmentRow(
    private val title: String,
    private val options: List<String>,
    private val get: (AppSettings) -> Int,
    private val set: (AppSettings, Int) -> AppSettings,
    /** İsteğe bağlı açıklama: seçicinin altında, en çok 2 satır. */
    private val note: String? = null,
    /** Seçime göre değişen açıklama; verilirse [note] yerine bu kullanılır. */
    private val noteFn: ((AppSettings) -> String)? = null,
    /** Seçim değişince (ayar yazıldıktan sonra) bir kez çağrılır; ör. titreşim ya da ses çıkışı için örnek vermek. */
    private val after: ((AppModel) -> Unit)? = null,
) : Node() {
    private var noteLines: List<String> = emptyList()
    private var titleShown = title
    private val pos = Anim(0f)

    private inner class Hit(val index: Int) : Node() {
        override val tappable: Boolean get() = true
        override val hitSlop: Float get() = 3f
        override fun draw(g: Gfx, env: Env) {}
        override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
            if (tap) {
                env.tap(false, app.dnshizli.core.Sfx.SELECT)
                val changed = current != index
                env.model.update { set(it, index) }
                if (changed) after?.invoke(env.model)
            }
        }
        override fun a11y(): A11y = A11y("$title: ${options[index]}", Role.BUTTON, checked = current == index)
    }

    private var current = 0
    private val hits = options.indices.map { add(Hit(it)) }
    private var shown: List<String> = options
    private val sizes = FloatArray(options.size)
    private var shownFor = -1f
    private var shownFs = 0f
    private var shownTx: Any? = null
    private val segL = 16f
    private val segT = 46f
    private val segH = M.MIN_TAP
    private var cols = options.size
    private var rows = 1
    private var cellW = 0f

    /** Seçenek [i]'nin satırı ve sütunu. Sığmayan etiketler (büyük yazı, dar ekran, uzun çeviri) iki satıra ya da alt alta dizilir. */
    private fun rowOf(i: Int) = i / cols
    private fun colOf(i: Int) = i % cols
    private fun rowTop(r: Int) = segT + r * (segH + 6f)

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        titleShown = TextFit.ellipsize(env.metrics, title, w - 32f, env.sz(16f), true)
        // Tek satırda her etiket en çok %20 küçülerek sığıyor mu? Sığmıyorsa dizilim değişir: "Kü…" gibi kesik seçenek kalmaz.
        val fs = env.sz(14f)
        cols = options.size
        val oneRow = (w - 32f) / options.size - 10f
        if (options.any { env.metrics.textWidth(it, fs * 0.8f, true) > oneRow } && options.size > 1) {
            cols = if (options.size <= 3) 1 else (options.size + 1) / 2
        }
        rows = (options.size + cols - 1) / cols
        cellW = (w - 32f) / cols
        h = segT + rows * segH + (rows - 1) * 6f + 14f
        val shownNote = (noteFn?.invoke(env.model.settings) ?: note)?.takeIf { it.isNotBlank() }
        noteLines = emptyList()
        if (shownNote != null) {
            val ns = env.sz(13f)
            val l = TextFit.wrap(env.metrics, shownNote, w - 32f, ns, false)
            noteLines = if (l.size > 2) listOf(l[0], TextFit.ellipsize(env.metrics, l[1] + " …", w - 32f, ns, false)) else l
            h += noteLines.size * ns * 1.32f + 2f
        }
        for ((i, k) in hits.withIndex()) { k.x = segL + colOf(i) * cellW; k.y = rowTop(rowOf(i)); k.w = cellW; k.h = segH }
        current = get(env.model.settings)
        pos.set(current.toFloat())
        shownFor = -1f
    }

    override fun tick(dt: Float, env: Env): Boolean {
        current = get(env.model.settings)
        val tgt = current.toFloat()
        if (pos.target != tgt) pos.go(tgt, env.dur(0.26f))
        return pos.step(dt)
    }

    override fun draw(g: Gfx, env: Env) {
        val t = env.sz(16f)
        g.paint(env.theme.text)
        g.text(titleShown, 16f, 32f, t, true, ALIGN_LEFT)
        for (r in 0 until rows) {
            val inRow = minOf(cols, options.size - r * cols)
            val top = rowTop(r)
            val right = segL + inRow * cellW
            if (rows == 1) env.art.segmented(g, segL, top, right, top + segH, inRow, pos.value)
            else {
                // Her satırın kendi izi var; seçim düğmesi yalnızca kendi satırındayken görünür (animasyonda satırlar arası kayarken kesilir).
                g.save()
                g.clipRect(segL - 2f, top - 2f, right + 2f, top + segH + 2f)
                env.art.segmented(g, segL, top, right, top + segH, inRow, pos.value - r * cols)
                g.restore()
            }
        }
        val fs = env.sz(14f)
        if (shownFor != w || shownFs != env.fs || shownTx !== app.dnshizli.core.L.tx) {
            shownFor = w; shownFs = env.fs; shownTx = app.dnshizli.core.L.tx
            // Sığmayan seçenek önce biraz küçülür (en çok %20), yine sığmazsa "…" ile kısalır.
            val avail = cellW - 10f
            shown = options.mapIndexed { i, o ->
                val tw = env.metrics.textWidth(o, fs, true)
                // %1 pay: ondalık yuvarlama sınırda tam sığan yazıyı gereksiz "…" ile kesmesin.
                val size = if (tw <= avail) fs else maxOf(fs * 0.8f, fs * avail / tw * 0.99f)
                sizes[i] = size
                TextFit.ellipsize(env.metrics, o, avail, size, true)
            }
        }
        for (i in options.indices) {
            val near = 1f - Easing.clamp01(abs(pos.value - i))
            g.paint(Rgb.lerp(env.theme.text, Rgb.WHITE, near))
            g.text(shown[i], segL + cellW * (colOf(i) + 0.5f), centerBaseline(rowTop(rowOf(i)) + segH / 2f, sizes[i]), sizes[i], near > 0.5f, ALIGN_CENTER)
        }
        if (noteLines.isNotEmpty()) {
            val ns = env.sz(13f)
            val base = rowTop(rows - 1) + segH
            g.paint(env.theme.textSoft)
            for (i in noteLines.indices) g.text(noteLines[i], 16f, base + 8f + (i + 1) * ns * 1.32f - ns * 0.25f, ns, false, ALIGN_LEFT)
        }
    }
}

/** Tek bir tema örneği (küre). */
class SwatchButton(var theme: AeroTheme?, private val name: String, private val onPick: () -> Unit) : PressNode() {
    private val sel = Anim(0f)
    var radius = 17f
    private var slop = 4f
    override fun layout(env: Env, maxW: Float) {
        w = radius * 2f + 10f; h = w
        slop = maxOf(4f, (M.MIN_TAP - w) / 2f)   // dar ekranda da en az 44 dp'lik dokunma alanı
    }
    override val hitSlop: Float get() = slop
    fun setSelected(v: Boolean, env: Env?, animate: Boolean) {
        val tgt = if (v) 1f else 0f
        if (sel.target == tgt && !sel.active) return
        sel.go(tgt, if (animate && env != null) env.dur(0.25f) else 0f)
    }
    val isSelected: Boolean get() = sel.target > 0.5f
    override fun tick(dt: Float, env: Env): Boolean = sel.step(dt) or super.tick(dt, env)
    override fun draw(g: Gfx, env: Env) {
        g.save()
        pressScale(g, w / 2f, h / 2f, 0.1f)
        env.art.swatch(g, w / 2f, h / 2f, radius, theme, sel.value)
        g.restore()
    }
    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) { super.onUp(lx, ly, tap, env); if (tap) { env.tap(false, app.dnshizli.core.Sfx.SELECT); onPick() } }
    override fun a11y(): A11y = A11y(Strings.themeA11y(name), Role.BUTTON, checked = isSelected)
}

/**
 * Tema seçici, üç etiketli grupta: Özel (Otomatik, varsa duvar kağıdı teması, Özel), Açık temalar, Koyu temalar. Her grup kendi
 * satırlarına dizilir; sıra sayısı genişliğe göre seçilir (her örnek en az ~46 dp yer bulur, dar ekranda daha çok satır).
 * Seçili temanın adı sağ üstte ("Otomatik" seçiliyken o an gösterilen tema da yazılır).
 */
class SwatchRow : Node() {
    private class Group(val caption: () -> String, val items: ArrayList<Pair<String, SwatchButton>> = ArrayList()) { var captionY = 0f }

    private val special = Group({ Strings.GROUP_SPECIAL })
    private val light = Group({ Strings.GROUP_LIGHT })
    private val dark = Group({ Strings.GROUP_DARK })
    private val groups = listOf(special, light, dark)
    private val items: List<Pair<String, SwatchButton>> get() = groups.flatMap { it.items }
    private var shownName = ""
    private var built = false

    private var envRef: Env? = null
    private fun pick(id: String) { envRef?.model?.update { it.copy(theme = id) } }

    private fun build(env: Env) {
        built = true
        special.items.add(Themes.AUTO_ID to SwatchButton(null, Strings.THEME_AUTO) { pick(Themes.AUTO_ID) })
        val seed = env.model.accentSeed
        if (seed != null) {
            val t = Themes.dynamic(seed, false)
            special.items.add(Themes.DYNAMIC_ID to SwatchButton(t, Strings.themeName(Themes.DYNAMIC_ID)) { pick(Themes.DYNAMIC_ID) })
        }
        for (t in Themes.all) (if (t.dark) dark else light).items.add(t.id to SwatchButton(t, t.name) { pick(t.id) })
        special.items.add(Themes.CUSTOM_ID to SwatchButton(CustomPalette.theme(env.model.settings.customTheme), Strings.themeName(Themes.CUSTOM_ID)) { pick(Themes.CUSTOM_ID) })
        for ((_, b) in items) add(b)
    }

    override fun layout(env: Env, maxW: Float) {
        envRef = env
        if (!built) build(env)
        w = maxW
        val fit = maxOf(4, ((w - 32f) / 46f).toInt())
        var y = 44f
        val cap = env.sz(12f)
        for (grp in groups) {
            val n = grp.items.size
            if (n == 0) continue
            grp.captionY = y + cap + 6f
            y += cap + 14f
            val rows = (n + fit - 1) / fit
            val perRow = (n + rows - 1) / rows
            val spacing = (w - 32f) / perRow
            val r = minOf(17f, spacing / 2f - 5f)
            val rowH = r * 2f + 10f + 8f
            for ((i, p) in grp.items.withIndex()) {
                val b = p.second
                if (p.first == Themes.CUSTOM_ID) b.theme = CustomPalette.theme(env.model.settings.customTheme)   // ayar değişince güncel
                b.radius = r
                b.layout(env, maxW)
                val row = i / perRow
                val col = i % perRow
                b.x = 16f + spacing * (col + 0.5f) - b.w / 2f
                b.y = y + row * rowH
            }
            y += rows * rowH + 4f
        }
        h = y + 6f
        sync(env, false)
    }

    private fun sync(env: Env, animate: Boolean) {
        val cur = env.model.settings.theme
        for ((id, b) in items) b.setSelected(id == cur, env, animate)
        shownName = when (cur) {
            Themes.AUTO_ID -> Strings.THEME_AUTO + " · " + (Themes.byId(env.model.shownThemeId)?.name ?: Strings.themeName(env.model.shownThemeId))
            Themes.DYNAMIC_ID -> Strings.themeName(cur)
            else -> Themes.byId(cur)?.name ?: Strings.themeName(cur)
        }
    }

    private var seen = -1
    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != env.model.version) { seen = env.model.version; sync(env, true) }
        return tickKids(dt, env)
    }

    override fun draw(g: Gfx, env: Env) {
        val t = env.sz(16f)
        g.paint(env.theme.text)
        g.text(Strings.THEME, 16f, 32f, t, true, ALIGN_LEFT)
        g.paint(env.theme.textSoft)
        val avail = w - 32f - env.metrics.textWidth(Strings.THEME, t, true) - 12f
        g.text(TextFit.ellipsize(env.metrics, shownName, avail, env.sz(13f), false), w - 16f, 32f, env.sz(13f), false, ALIGN_RIGHT)
        val cap = env.sz(12f)
        for (grp in groups) {
            if (grp.items.isEmpty()) continue
            g.paint(env.theme.textSoft)
            g.text(grp.caption(), 18f, grp.captionY, cap, true, ALIGN_LEFT)
        }
        drawKids(g, env)
    }
}

/**
 * Son 7 günün sorgu sayıları: cam kart içinde yuvarlak uçlu çubuklar, altında gün adları. Bugün vurgulanır.
 * Veriyi ayarlardaki günlük sayılardan ([AppSettings.daily]) okur.
 */
class WeekChart : Node() {
    private var seen = -1
    private var days: List<Triple<Int, Int, Long>> = emptyList()
    private var maxV = 1L
    private var total = 0L
    private var totalText = "0"

    override fun layout(env: Env, maxW: Float) { w = maxW; h = 132f; seen = -1 }

    private fun refresh(env: Env) {
        if (seen == env.model.version) return
        seen = env.model.version
        days = app.dnshizli.core.DailyStats.lastWeek(env.model.settings.daily, env.model.host.now())
        maxV = maxOf(1L, days.maxOfOrNull { it.third } ?: 1L)
        total = days.sumOf { it.third }
        totalText = app.dnshizli.core.Format.count(total)
    }

    override fun tick(dt: Float, env: Env): Boolean { refresh(env); return false }

    override fun draw(g: Gfx, env: Env) {
        refresh(env)
        val t = env.sz(15f)
        g.paint(env.theme.text)
        g.text(Strings.WEEK, 16f, 28f, t, false, ALIGN_LEFT)
        g.paint(env.theme.textSoft)
        g.text(totalText, w - 16f, 28f, t, true, ALIGN_RIGHT)
        val n = days.size
        if (n == 0) return
        val left = 22f
        val right = w - 22f
        val top = 42f
        val bottom = h - 30f
        val slot = (right - left) / n
        val bw = minOf(18f, slot * 0.5f)
        val labelS = env.sz(11.5f)
        for (i in 0 until n) {
            val d = days[i]
            val cx = left + slot * (i + 0.5f)
            val frac = d.third.toFloat() / maxV.toFloat()
            val bh = maxOf(4f, (bottom - top) * frac)
            val today = i == n - 1
            g.paint(Rgb.alpha(env.theme.accent, if (today) 0.95f else 0.55f))
            g.roundRect(cx - bw / 2f, bottom - bh, cx + bw / 2f, bottom, bw / 2f)
            g.paint(if (today) env.theme.text else env.theme.textSoft)
            g.text(Strings.WEEKDAYS[d.second], cx, h - 10f, labelS, today, ALIGN_CENTER)
        }
    }

    override fun a11y(): A11y = A11y(Strings.weekA11y(totalText), Role.TEXT)
}

/**
 * Sorgu başına gecikme grafiği: son 60 sorgunun cevap süresi çubuk olarak (en yenisi sağda). Zaman aşımına uğrayanlar kırmızı
 * dolu şerit olur. Yalnızca bağlıyken ve sorgu geldikçe dolar; veri bellekte kısa bir halkadır (alan adı tutulmaz).
 * Bağlıyken yarım saniyede bir yenilenir; süs animasyonları kapalıysa sayfa yeniden çizilince yenilenir.
 */
class LatencyChart : Node() {
    private var lastRefresh = 0L
    private var line = ""
    private var scaleText = ""
    private var scale = 50
    private var shown = 0
    private var emptyLines: List<String> = emptyList()
    private var laidFs = 0f
    private var laidW = -1f

    override fun layout(env: Env, maxW: Float) { w = maxW; h = 156f; lastRefresh = 0L; laidW = -1f }

    private fun relay(env: Env) {
        laidW = w; laidFs = env.fs
        emptyLines = TextFit.wrap(env.metrics, Strings.LATENCY_EMPTY, w - 40f, env.sz(13f), false).take(3)
    }

    private fun refresh(env: Env) {
        if (laidW != w || laidFs != env.fs) relay(env)
        val now = env.model.host.now()
        if (lastRefresh != 0L && now - lastRefresh in 0..REFRESH_MS) return
        lastRefresh = now
        val m = env.model
        m.refreshLatencies()
        val n = m.latencyCount
        shown = minOf(n, BARS)
        val s = app.dnshizli.core.LatencySummary.of(m.latencySamples, n)
        line = if (n == 0) "" else Strings.latencyLine(app.dnshizli.core.Format.ms(s.avgMs), app.dnshizli.core.Format.ms(s.maxMs), s.timeouts)
        scale = s.maxMs.coerceIn(50, 1000)
        scaleText = app.dnshizli.core.Format.ms(scale)
    }

    override fun tick(dt: Float, env: Env): Boolean { refresh(env); return false }

    override fun ambient(env: Env): Boolean = env.ambient && env.model.vpn.state == app.dnshizli.core.OrbState.ON

    override fun draw(g: Gfx, env: Env) {
        refresh(env)
        val t = env.sz(15f)
        g.paint(env.theme.text)
        g.text(Strings.LATENCY_TITLE, 16f, 28f, t, false, ALIGN_LEFT)
        val left = 16f
        val right = w - 16f
        val top = 70f
        val bottom = h - 16f
        if (shown == 0) {
            g.paint(env.theme.textSoft)
            val s = env.sz(13f)
            var y = (top + bottom) / 2f - (emptyLines.size - 1) * s * 0.7f + s * 0.35f
            for (l in emptyLines) { g.text(l, w / 2f, y, s, false, ALIGN_CENTER); y += s * 1.4f }
            return
        }
        g.paint(env.theme.textSoft)
        g.text(line, 16f, 50f, env.sz(12.5f), false, ALIGN_LEFT)
        g.text(scaleText, right, 50f, env.sz(11f), false, ALIGN_RIGHT)
        g.paint(Rgb.alpha(env.theme.textSoft, 0.35f))
        g.rect(left, bottom, right, bottom + 1f)
        val m = env.model
        val slot = (right - left) / BARS
        val bw = maxOf(1.5f, slot * 0.62f)
        val first = m.latencyCount - shown
        for (i in 0 until shown) {
            val v = m.latencySamples[first + i]
            val x1 = right - slot * (shown - i - 1) - (slot - bw) / 2f
            val x0 = x1 - bw
            if (v == app.dnshizli.core.LatencyRing.TIMEOUT) {
                g.paint(TIMEOUT_COLOR)
                g.rect(x0, top, x1, bottom)
                continue
            }
            val frac = minOf(v, scale).toFloat() / scale.toFloat()
            val bh = maxOf(2f, (bottom - top) * frac)
            g.paint(if (v > SLOW_MS) Rgb.alpha(SLOW_COLOR, 0.95f) else Rgb.alpha(env.theme.accent, 0.85f))
            g.roundRect(x0, bottom - bh, x1, bottom, minOf(bw / 2f, 2.5f))
        }
    }

    override fun a11y(): A11y = A11y(Strings.LATENCY_TITLE + (if (line.isEmpty()) "" else ". $line"), Role.TEXT)

    private companion object {
        const val BARS = 60
        const val REFRESH_MS = 500L
        const val SLOW_MS = 250
        val TIMEOUT_COLOR = Rgb.argb(110, 225, 70, 60)
        val SLOW_COLOR = Rgb.argb(255, 235, 160, 40)
    }
}

/**
 * Dokununca bir şey açan satır: başlık, sağda değer ve ok.
 *
 * Başlık ve değer tek satıra sığmazsa başlık hiçbir zaman kısaltılmaz: değer başlığın altına inip satır yükselir;
 * başlığın kendisi de sığmazsa en çok 2 satıra sarılır. Değer ayar değişince değiştiği için sayfa, model değişince
 * yerleşimi yeniler (bkz. [SectionPage], [PersonalizePage]).
 */
class NavRow(
    private val title: String,
    private val value: ((AppSettings) -> String)? = null,
    private val icon: Icon? = null,
    private val onTap: () -> Unit,
) : PressNode() {
    // Yazılar yalnızca yerleşimde ve model/genişlik değişince hesaplanır: her karede bellek ayırmaz.
    private var seen = -1
    private var laidW = -1f
    private var laidFs = 0f
    private var titleLines: List<String> = emptyList()
    private var shownValue = ""
    private var valueBelow = false

    override fun layout(env: Env, maxW: Float) { w = maxW; relay(env) }

    private fun relay(env: Env) {
        seen = env.model.version; laidW = w; laidFs = env.fs
        val t = env.sz(16f)
        val vs = env.sz(14f)
        val tx = if (icon != null) 52f else 16f
        val avail = w - tx - 40f
        // Başlık: tek satıra sığmıyorsa en çok 2 satır
        val wrapped = TextFit.wrap(env.metrics, title, avail, t, true)
        titleLines = if (wrapped.size <= 2) wrapped
        else listOf(wrapped[0], TextFit.ellipsize(env.metrics, wrapped[1] + " …", avail, t, true))
        // Değer: başlıkla yan yana sığıyorsa sağda, sığmıyorsa başlığın altında
        valueBelow = false
        shownValue = ""
        if (value != null) {
            val raw = value.invoke(env.model.settings)
            if (raw.isNotEmpty()) {
                val vw = env.metrics.textWidth(raw, vs, false)
                if (titleLines.size == 1 && env.metrics.textWidth(titleLines[0], t, true) + 12f + vw <= avail) {
                    shownValue = raw
                } else {
                    valueBelow = true
                    shownValue = TextFit.ellipsize(env.metrics, raw, avail, vs, false)
                }
            }
        }
        h = if (titleLines.size == 1 && !valueBelow) 60f
        else 16f + t * 0.95f + (titleLines.size - 1) * t * 1.25f + (if (valueBelow) 6f + vs * 1.3f else 0f) + 14f
    }

    private fun refresh(env: Env) {
        if (seen == env.model.version && laidW == w && laidFs == env.fs) return
        relay(env)
    }

    override fun tick(dt: Float, env: Env): Boolean { refresh(env); return super.tick(dt, env) }

    override fun draw(g: Gfx, env: Env) {
        refresh(env)
        pressGlow(g, env, w, h, press.value)
        val t = env.sz(16f)
        val vs = env.sz(14f)
        var tx = 16f
        if (icon != null) { Icons.draw(g, icon, 16f + 11f, h / 2f, 22f, env.art.ink, 2f); tx = 52f }
        Icons.draw(g, Icon.CHEVRON, w - 24f, h / 2f, 18f, env.theme.textSoft, 2f)
        g.paint(env.theme.text)
        if (titleLines.size == 1 && !valueBelow) {
            g.text(titleLines[0], tx, centerBaseline(h / 2f, t), t, true, ALIGN_LEFT)
            if (shownValue.isNotEmpty()) {
                g.paint(env.theme.textSoft)
                g.text(shownValue, w - 40f, centerBaseline(h / 2f, vs), vs, false, ALIGN_RIGHT)
            }
        } else {
            val tb = 16f + t * 0.95f
            for (i in 0 until titleLines.size) g.text(titleLines[i], tx, tb + i * t * 1.25f, t, true, ALIGN_LEFT)
            if (valueBelow) {
                val last = tb + (titleLines.size - 1) * t * 1.25f
                g.paint(env.theme.textSoft)
                g.text(shownValue, tx, last + 6f + vs * 1.05f, vs, false, ALIGN_LEFT)
            }
        }
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(); onTap() }
    }

    override fun a11y(): A11y = A11y(title, Role.BUTTON, value = shownValue.ifEmpty { null })
}

/** Dokunulmayan bilgi satırı: başlık solda, değer sağda; başlık sığmazsa 2 satıra sarılır. */
class InfoRow(private val title: String, private val value: (AppSettings) -> String) : Node() {
    private var lastValue = ""
    private var rawValue = ""

    // Uzun basınca "başlık: değer" panoya kopyalanır (sayıları paylaşmak ya da not almak için).
    override val tappable: Boolean get() = true
    override val longPressable: Boolean get() = true
    override fun onLongPress(env: Env): Boolean {
        if (rawValue.isEmpty()) return false
        env.model.copy("$title: $rawValue")
        return true
    }
    private var titleLines: List<String> = listOf(title)
    private var seenVersion = -1
    private var laidW = -1f
    private var laidFs = 0f

    override fun layout(env: Env, maxW: Float) { w = maxW; relay(env) }

    private fun relay(env: Env) {
        seenVersion = env.model.version; laidW = w; laidFs = env.fs
        val t = env.sz(15f)
        // Uzun değer başlığı ezmesin: değer genişliğin en çok %55'ini alır, fazlası "…" ile kısalır.
        rawValue = value(env.model.settings)
        lastValue = TextFit.ellipsize(env.metrics, rawValue, w * 0.55f, t, true)
        val vw = env.metrics.textWidth(lastValue, t, true)
        val avail = w - 32f - vw - 12f
        val wrapped = TextFit.wrap(env.metrics, title, avail, t, false)
        titleLines = if (wrapped.size <= 2) wrapped else listOf(wrapped[0], TextFit.ellipsize(env.metrics, wrapped[1] + " …", avail, t, false))
        h = if (titleLines.size <= 1) 50f else 16f + t * 0.95f + (titleLines.size - 1) * t * 1.25f + 14f
    }

    private fun refresh(env: Env) {
        if (seenVersion == env.model.version && laidW == w && laidFs == env.fs) return
        relay(env)
    }

    override fun tick(dt: Float, env: Env): Boolean { refresh(env); return false }

    override fun draw(g: Gfx, env: Env) {
        refresh(env)
        val t = env.sz(15f)
        g.paint(env.theme.text)
        if (titleLines.size <= 1) {
            g.text(titleLines.firstOrNull() ?: "", 16f, centerBaseline(h / 2f, t), t, false, ALIGN_LEFT)
            g.paint(env.theme.textSoft)
            g.text(lastValue, w - 16f, centerBaseline(h / 2f, t), t, true, ALIGN_RIGHT)
        } else {
            val tb = 16f + t * 0.95f
            for (i in 0 until titleLines.size) g.text(titleLines[i], 16f, tb + i * t * 1.25f, t, false, ALIGN_LEFT)
            g.paint(env.theme.textSoft)
            g.text(lastValue, w - 16f, centerBaseline(h / 2f, t), t, true, ALIGN_RIGHT)
        }
    }

    override fun a11y(): A11y = A11y("$title: $rawValue", Role.TEXT, longClick = true)
}
