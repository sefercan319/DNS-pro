package app.dnshizli.core

import javax.net.ssl.SSLPeerUnverifiedException

/**
 * El sıkışma bittikten sonra pazarlık edilen TLS sürümünü ve şifre takımını denetler (savunma derinliği). Soket zaten yalnızca
 * TLS 1.2/1.3'e açılır; yine de sunucunun ya da araya girenin seçtiği sonuç doğrulanır ve şunlardan biri çıkarsa bağlantı
 * kurulmaz (sertifika hatası gibi "güven hatası" sayılır):
 *  - TLS 1.2/1.3 dışı sürüm,
 *  - ileri gizlilik vermeyen anahtar değişimi (statik RSA `TLS_RSA_…`, statik DH/ECDH): kaydedilen DNS trafiği sunucu anahtarı
 *    ele geçirilince sonradan çözülebilirdi,
 *  - kırık ya da boş algoritmalar (NULL, anonim, EXPORT, RC4, DES/3DES, RC2, IDEA, SEED, MD5),
 *  - TLS 1.3'te AES-GCM/ChaCha20/CCM dışı takım.
 * Gerçek sağlayıcılar (Cloudflare, Google, Quad9, AdGuard…) ECDHE + AEAD ya da TLS 1.3 seçer; bu denetim onları etkilemez.
 */
internal object TlsPolicy {
    private val BROKEN = listOf("_NULL_", "_ANON_", "EXPORT", "_RC4_", "_DES_", "_DES40_", "_3DES_", "_RC2_", "_IDEA_", "_SEED_", "_MD5")

    /** Kabul edilmiyorsa nedeni (kısa metin), kabulse null. */
    fun check(protocol: String?, suite: String?): String? {
        if (protocol != "TLSv1.3" && protocol != "TLSv1.2") return "TLS sürümü: ${protocol ?: "bilinmiyor"}"
        val s = suite?.uppercase(java.util.Locale.ROOT)
        if (s.isNullOrEmpty()) return "şifre takımı bilinmiyor"
        for (w in BROKEN) if (w in s) return "zayıf şifre takımı: $suite"
        if (protocol == "TLSv1.3") {
            return if (s.startsWith("TLS_AES_") || s.startsWith("TLS_CHACHA20_")) null else "beklenmeyen TLS 1.3 takımı: $suite"
        }
        // TLS 1.2: ileri gizlilik (ECDHE/DHE) şart
        if (s.startsWith("TLS_RSA_") || s.startsWith("SSL_RSA_") || s.startsWith("TLS_DH_") || s.startsWith("TLS_ECDH_")) return "ileri gizlilik yok: $suite"
        return null
    }

    fun acceptable(protocol: String?, suite: String?): Boolean = check(protocol, suite) == null

    /** [check] reddederse güven hatası fırlatır ([SSLPeerUnverifiedException]: sertifika hatası gibi sayılır, yedek sunucuya geçilir). */
    fun require(protocol: String?, suite: String?) {
        check(protocol, suite)?.let { throw SSLPeerUnverifiedException(it) }
    }
}
