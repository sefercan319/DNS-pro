package app.dnshizli.core

/**
 * Yalnızca kişisel sürümün isteğe bağlı YouTube reklam listesi (varsayılan kapalı).
 * Kapsam DNS'tir: bilinen reklam ve reklam ölçüm alan adları engellenir. İçerik sunucuları (googlevideo.com, youtubei.googleapis.com,
 * youtube.com) ASLA listede olmaz: bunlar engellenirse videolar açılmaz. Reklam videoları içerikle aynı yoldan gelebildiği için
 * bu liste kısmidir; bazı reklamlar geçer. Oynatıcı içi reklamlar DNS ile kaldırılamaz.
 */
object YouTubeAds {
    val HOSTS: List<String> = listOf(
        "pagead2.googlesyndication.com", "googleads.g.doubleclick.net", "ad.doubleclick.net", "static.doubleclick.net",
    )

    /** Motora verilecek kullanıcı engel listesi: yalnızca kişisel sürümde ve kullanıcı açtıysa YouTube adları eklenir. */
    fun blockFor(s: AppSettings, personal: Boolean): List<String> =
        if (personal && s.youtubeAds) s.filterBlock + HOSTS else s.filterBlock
}
