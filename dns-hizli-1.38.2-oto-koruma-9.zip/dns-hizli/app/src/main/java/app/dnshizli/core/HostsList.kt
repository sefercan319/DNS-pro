package app.dnshizli.core

/**
 * Kullanıcının kendi engel listesini içe/dışa aktarma. Yaygın biçimler okunur:
 *  - hosts: `0.0.0.0 reklam.example.com` ya da `127.0.0.1 a.example b.example` (yalnızca engelleme adresleri: 0.0.0.0, 127.0.0.1, ::, ::1, 0)
 *  - düz liste: satır başına bir alan adı (`reklam.example.com`, `*.example.com`, `https://example.com/yol` da olur)
 *  - AdBlock kuralı: `||reklam.example.com^`. Alan adı düzeyinde anlamı değişmeyen seçenekler (`$important`, `$third-party`, `$3p`,
 *    `$all`) kabul edilir; kapsamı daraltan seçenekler (`$script`, `$domain=…`, `$popup` …) alan adının tamamını engellemek
 *    kuralı aşırı genişleteceği için atlanır.
 *  - AdBlock istisnası: `@@||site.example.com^` aynı listedeki o adı ve alt adlarını engellemeden çıkarır (kural yazarı bilerek
 *    izin vermiştir; yok sayılsaydı site bozulurdu).
 *  - dnsmasq / AdGuard Home: `address=/reklam.example.com/0.0.0.0` (birden çok ad, boş adres = engel), `server=/reklam.example.com/`
 *  - Unbound: `local-zone: "reklam.example.com" always_nxdomain` (always_null, always_refuse, refuse da olur)
 *  - RPZ: `reklam.example.com CNAME .` (NXDOMAIN)
 * `#` ve `!` ile başlayan satırlar ve satır sonu açıklamaları yok sayılır. Başka bir IP'ye yönlendiren hosts satırları
 * (ör. `192.168.1.5 yazici.lan`) engelleme olmadığı için atlanır. Ortak son ekler ([FilterNames.isPublicSuffix]: `co.uk`,
 * `com.tr`) bütün siteleri kapsayacağından alınmaz. Her şey bellekte yapılır; hiçbir yere gönderilmez.
 */
object HostsList {
    /** Kendi listemizde tutulan en çok alan adı. */
    const val MAX_IMPORTED = 50_000

    /** Dışa aktarmada panoya yazılan en çok alan adı (Android'in pano/aktarım sınırı yüzünden). */
    const val MAX_EXPORT = 8_000

    /** Okunacak en büyük metin (karakter). Daha büyük dosyalar kesilir ve [Result.cut] işaretlenir. */
    const val MAX_CHARS = 4_000_000

    class Result(
        /** Temiz, tekrarsız, sıralı alan adları ([MAX_IMPORTED]'a kadar). */
        val names: List<String>,
        /** Okunamayan ya da blok olmayan (başka IP'ye giden, geçersiz) satırlar. */
        val skipped: Int,
        /** Liste ya da metin sınıra takıldı, fazlası alınmadı. */
        val cut: Boolean,
        /** `@@||alan^` istisnaları nedeniyle listeden çıkarılan ad sayısı. */
        val excepted: Int = 0,
    )

    private val BLOCK_IPS = setOf("0.0.0.0", "127.0.0.1", "::", "::1", "0", "0:0:0:0:0:0:0:0", "0:0:0:0:0:0:0:1")
    private val SKIP_NAMES = setOf(
        "localhost", "local", "broadcasthost", "ip6-localhost", "ip6-loopback", "ip6-localnet", "ip6-mcastprefix",
        "ip6-allnodes", "ip6-allrouters", "ip6-allhosts", "0.0.0.0",
    )

    /** Alan adı düzeyinde anlamı değişmeyen AdBlock seçenekleri. */
    private val HARMLESS_OPTIONS = setOf("important", "third-party", "3p", "all")
    private val UNBOUND_BLOCK = setOf("always_nxdomain", "always_null", "always_refuse", "refuse", "deny", "always_deny")

    /** `a,b,c` biçimli AdBlock seçenekleri hepsi zararsız mı? */
    private fun optionsHarmless(opts: String): Boolean =
        opts.split(',').all { it.trim().lowercase() in HARMLESS_OPTIONS }

    fun parse(text: String): Result {
        val set = LinkedHashSet<String>()
        val allowed = ArrayList<String>()
        var skipped = 0
        var cut = false
        val src = if (text.length > MAX_CHARS) { cut = true; text.substring(0, MAX_CHARS) } else text
        for (raw in src.lineSequence()) {
            if (set.size >= MAX_IMPORTED) { cut = true; break }
            var line = raw.trim()
            if (line.isEmpty() || line.startsWith("#") || line.startsWith("!") || line.startsWith("[")) continue
            val hash = line.indexOf('#')
            if (hash > 0) line = line.substring(0, hash).trim()
            if (line.isEmpty()) continue
            val found = ArrayList<String>(2)
            if (line.startsWith("@@")) {
                // İstisna: yalnızca "@@||alan^" (zararsız seçeneklerle); gerisi alan adı düzeyinde anlamlandırılamaz.
                val rule = line.substring(2)
                if (!rule.startsWith("||")) { skipped++; continue }
                val body = rule.substring(2)
                val opt = body.indexOf('$')
                if (opt >= 0 && !optionsHarmless(body.substring(opt + 1))) { skipped++; continue }
                val head = (if (opt >= 0) body.substring(0, opt) else body).substringBefore('^')
                val d = FilterNames.normalize(head)
                if (d == null || '/' in head || '*' in head.removePrefix("*.")) { skipped++; continue }
                if (allowed.size < MAX_IMPORTED) allowed.add(d)
                continue
            }
            if (line.startsWith("||")) {
                val rule = line.substring(2)
                val opt = rule.indexOf('$')
                if (opt >= 0 && !optionsHarmless(rule.substring(opt + 1))) { skipped++; continue }
                val head = (if (opt >= 0) rule.substring(0, opt) else rule).substringBefore('^')
                val d = FilterNames.normalize(head)
                if (d == null || '/' in head) { skipped++; continue }
                found.add(d)
            } else if (line.startsWith("address=/") || line.startsWith("server=/") || line.startsWith("local=/")) {
                // dnsmasq: address=/a.com/b.com/0.0.0.0 (adresin yerinde bir şey yoksa NXDOMAIN), server=/a.com/ (üst sunucusuz)
                val isAddress = line.startsWith("address=/")
                val parts = line.substringAfter('/').split('/')
                val tail = parts.last().trim().lowercase()
                if (isAddress && tail.isNotEmpty() && tail !in BLOCK_IPS) { skipped++; continue }
                if (!isAddress && tail.isNotEmpty()) { skipped++; continue }       // server=/a.com/1.1.1.1: yönlendirme, engel değil
                val names = parts.dropLast(1).filter { it.isNotBlank() }
                if (names.isEmpty()) { skipped++; continue }
                for (n in names) { val d = FilterNames.normalize(n); if (d == null) skipped++ else found.add(d) }
            } else if (line.startsWith("local-zone:")) {
                // Unbound: local-zone: "a.example.com." always_nxdomain
                val rest = line.removePrefix("local-zone:").trim()
                val q = rest.indexOf('"')
                val q2 = if (q >= 0) rest.indexOf('"', q + 1) else -1
                if (q < 0 || q2 < 0) { skipped++; continue }
                val kind = rest.substring(q2 + 1).trim().lowercase()
                if (kind !in UNBOUND_BLOCK) { skipped++; continue }
                val d = FilterNames.normalize(rest.substring(q + 1, q2))
                if (d == null) skipped++ else found.add(d)
            } else {
                val parts = line.split(' ', '\t').filter { it.isNotEmpty() }
                val first = parts[0].lowercase()
                val ipLike = first.contains(':') && !first.contains('.') || first.all { it in '0'..'9' || it == '.' }
                if (ipLike && parts.size >= 2) {
                    if (first !in BLOCK_IPS) { skipped++; continue }
                    for (i in 1 until parts.size) {
                        val n = parts[i]
                        if (n.lowercase() in SKIP_NAMES) continue
                        val d = FilterNames.normalize(n)
                        if (d == null) skipped++ else found.add(d)
                    }
                } else if (parts.size == 3 && parts[1].equals("CNAME", ignoreCase = true) && parts[2] == ".") {
                    // RPZ: "ad.example.com CNAME ." = NXDOMAIN
                    val d = FilterNames.normalize(parts[0])
                    if (d == null) skipped++ else found.add(d)
                } else if (parts.size == 1) {
                    if (first in SKIP_NAMES) continue
                    val d = FilterNames.normalize(parts[0])
                    if (d == null) skipped++ else found.add(d)
                } else {
                    skipped++
                    continue
                }
            }
            for (d in found) {
                if (set.size >= MAX_IMPORTED) { cut = true; break }
                if (FilterNames.isPublicSuffix(d)) { skipped++; continue }          // "co.uk" gibi: bütün siteleri kapsar
                set.add(d)
            }
        }
        var excepted = 0
        if (allowed.isNotEmpty() && set.isNotEmpty()) {
            val ex = HashSet(allowed)
            val it = set.iterator()
            while (it.hasNext()) {
                val n = it.next()
                if (coveredBy(n, ex)) { it.remove(); excepted++ }
            }
        }
        return Result(set.sorted(), skipped, cut, excepted)
    }

    /** [name] kendisi ya da bir üst alan adı [domains] içinde mi? */
    private fun coveredBy(name: String, domains: Set<String>): Boolean {
        var s = name
        while (true) {
            if (s in domains) return true
            val dot = s.indexOf('.')
            if (dot < 0) return false
            s = s.substring(dot + 1)
        }
    }

    /** Birleştirilmiş liste: önce el ile eklenenler, sonra içe aktarılanlar; tekrarsız. [MAX_IMPORTED] aşılmaz. */
    fun merge(existing: List<String>, added: List<String>): List<String> {
        val set = LinkedHashSet<String>(existing)
        for (a in added) { if (set.size >= MAX_IMPORTED) break; set.add(a) }
        return set.sorted()
    }

    /** hosts biçimi: her satır `0.0.0.0 alanadı`. En çok [MAX_EXPORT] satır. */
    fun export(names: List<String>): String {
        val sb = StringBuilder(names.size.coerceAtMost(MAX_EXPORT) * 28 + 64)
        sb.append("# DNS Hızlı\n")
        var n = 0
        for (d in names) {
            if (n >= MAX_EXPORT) break
            sb.append("0.0.0.0 ").append(d).append('\n')
            n++
        }
        return sb.toString()
    }
}
