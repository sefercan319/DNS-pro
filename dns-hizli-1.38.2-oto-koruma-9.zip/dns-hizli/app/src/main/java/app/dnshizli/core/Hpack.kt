package app.dnshizli.core

import java.io.ByteArrayOutputStream
import java.io.IOException

/**
 * HPACK başlık çözücüsü (RFC 7541), HTTP/2 yanıtları için: statik tablo, dinamik tablo, Huffman dizgileri ve tablo boyutu
 * güncellemeleri tam olarak desteklenir. Her HTTP/2 bağlantısının kendi çözücüsü vardır; dinamik tablo bağlantı boyunca
 * korunur, bu yüzden başlık blokları alındıkları sırayla ([decode]) çözülmelidir.
 *
 * Kodlayıcı tarafı yoktur: istekler düz (dinamik tabloya yazmayan) literal alanlarla gönderilir.
 */
internal class HpackDecoder(private val capacity: Int = DEFAULT_TABLE_SIZE, private val maxListBytes: Int = MAX_LIST_BYTES) {

    class Field(val name: String, val value: String)

    private val dynNames = ArrayList<String>()     // 0 = en yeni
    private val dynValues = ArrayList<String>()
    private var dynSize = 0
    private var tableMax = capacity                  // sunucunun istediği güncel üst sınır (≤ capacity)

    /** Bir başlık bloğunu çözer. Bozuk ya da sınırı aşan blok [IOException] fırlatır (bağlantı hatası). */
    fun decode(b: ByteArray): List<Field> {
        val out = ArrayList<Field>()
        val pos = IntArray(1)
        var listBytes = 0L
        var sawField = false
        while (pos[0] < b.size) {
            val f = b[pos[0]].toInt() and 0xFF
            val field: Field?
            when {
                f and 0x80 != 0 -> {                                        // indeksli alan (§6.1)
                    val i = int(b, pos, 7)
                    if (i == 0) throw IOException("HPACK: indeks 0")
                    field = entry(i)
                    sawField = true
                }
                f and 0x40 != 0 -> {                                        // ekleyerek literal (§6.2.1)
                    val nf = literal(b, pos, 6)
                    add(nf.name, nf.value)
                    field = nf; sawField = true
                }
                f and 0x20 != 0 -> {                                        // tablo boyutu güncellemesi (§6.3)
                    if (sawField) throw IOException("HPACK: geç tablo boyutu güncellemesi")
                    val n = int(b, pos, 5)
                    if (n > capacity) throw IOException("HPACK: tablo boyutu izin verilenden büyük")
                    tableMax = n
                    evict()
                    field = null
                }
                else -> {                                                   // ekleme yapmayan literal (§6.2.2, §6.2.3)
                    field = literal(b, pos, 4)
                    sawField = true
                }
            }
            if (field != null) {
                listBytes += field.name.length + field.value.length + 32
                if (listBytes > maxListBytes) throw IOException("HPACK: başlık listesi çok büyük")
                out.add(field)
            }
        }
        return out
    }

    private fun literal(b: ByteArray, pos: IntArray, prefix: Int): Field {
        val idx = int(b, pos, prefix)
        val name = if (idx == 0) str(b, pos) else entry(idx).name
        val value = str(b, pos)
        return Field(name, value)
    }

    private fun entry(i: Int): Field {
        if (i <= STATIC_LAST) return Field(HpackData.STATIC_NAME[i], HpackData.STATIC_VALUE[i])
        val d = i - STATIC_LAST - 1
        if (d >= dynNames.size) throw IOException("HPACK: geçersiz dinamik tablo dizini")
        return Field(dynNames[d], dynValues[d])
    }

    private fun add(name: String, value: String) {
        val size = name.length + value.length + 32
        if (size > tableMax) {                      // tabloya sığmayan giriş tabloyu boşaltır (§4.4)
            dynNames.clear(); dynValues.clear(); dynSize = 0
            return
        }
        dynNames.add(0, name); dynValues.add(0, value); dynSize += size
        evict()
    }

    private fun evict() {
        while (dynSize > tableMax && dynNames.isNotEmpty()) {
            val last = dynNames.size - 1
            dynSize -= dynNames[last].length + dynValues[last].length + 32
            dynNames.removeAt(last); dynValues.removeAt(last)
        }
    }

    private fun str(b: ByteArray, pos: IntArray): String {
        if (pos[0] >= b.size) throw IOException("HPACK: eksik dizgi")
        val huff = b[pos[0]].toInt() and 0x80 != 0
        val n = int(b, pos, 7)
        if (n > maxListBytes || pos[0] + n > b.size) throw IOException("HPACK: dizgi sınırı")
        val start = pos[0]
        pos[0] += n
        return if (huff) String(HuffmanDecoder.decode(b, start, n), Charsets.ISO_8859_1)
        else String(b, start, n, Charsets.ISO_8859_1)
    }

    companion object {
        const val DEFAULT_TABLE_SIZE = 4096
        const val MAX_LIST_BYTES = 16384
        private const val STATIC_LAST = 61

        /** Önekli tamsayı (RFC 7541 §5.1); 2^24'ü aşan değerler reddedilir. */
        internal fun int(b: ByteArray, pos: IntArray, prefix: Int): Int {
            if (pos[0] >= b.size) throw IOException("HPACK: eksik tamsayı")
            val max = (1 shl prefix) - 1
            var v = (b[pos[0]++].toInt() and max).toLong()
            if (v < max) return v.toInt()
            var m = 0
            while (true) {
                if (pos[0] >= b.size || m > 21) throw IOException("HPACK: bozuk tamsayı")
                val x = b[pos[0]++].toInt() and 0xFF
                v += (x and 0x7F).toLong() shl m
                m += 7
                if (v > (1L shl 24)) throw IOException("HPACK: tamsayı çok büyük")
                if (x and 0x80 == 0) return v.toInt()
            }
        }
    }
}

/**
 * Huffman çözücüsü (RFC 7541 Ek B). Kodlar [HpackData]'dan gelir; ikili ağaç bir kez kurulur. Doldurma kuralları: en fazla
 * 7 bit ve hepsi 1 (EOS'un öneki); EOS sembolü dizgi içinde hata sayılır.
 */
internal object HuffmanDecoder {
    private val child: IntArray = IntArray(2 * (257 * 31 + 1)) { -1 }   // iç düğüm: >0 dizin; yaprak: -(sembol+2)

    init {
        var count = 1
        for (s in 0 until 257) {
            val code = HpackData.HUFF_CODE[s]
            val bits = HpackData.HUFF_BITS[s]
            var node = 0
            for (k in bits - 1 downTo 0) {
                val idx = node * 2 + ((code ushr k) and 1)
                if (k == 0) child[idx] = -(s + 2)
                else {
                    if (child[idx] == -1) child[idx] = count++
                    node = child[idx]
                }
            }
        }
    }

    fun decode(b: ByteArray, off: Int, len: Int): ByteArray {
        val out = ByteArrayOutputStream(len * 2 + 4)
        var node = 0
        var depth = 0                // son sembolden beri okunan bit sayısı
        var allOnes = true           // o bitlerin hepsi 1 mi
        for (i in off until off + len) {
            val byte = b[i].toInt() and 0xFF
            for (k in 7 downTo 0) {
                val bit = (byte ushr k) and 1
                val nx = child[node * 2 + bit]
                if (nx == -1) throw IOException("HPACK: bozuk Huffman kodu")
                depth++
                if (bit == 0) allOnes = false
                if (nx < 0) {
                    val s = -nx - 2
                    if (s == 256) throw IOException("HPACK: Huffman içinde EOS")
                    out.write(s)
                    node = 0; depth = 0; allOnes = true
                } else node = nx
            }
        }
        if (depth > 7 || (depth > 0 && !allOnes)) throw IOException("HPACK: geçersiz Huffman doldurması")
        return out.toByteArray()
    }
}
