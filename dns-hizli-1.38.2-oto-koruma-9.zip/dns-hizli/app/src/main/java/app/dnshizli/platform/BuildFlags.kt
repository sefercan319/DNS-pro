package app.dnshizli.platform

/** Derleme bayrakları. PERSONAL: gradle -Ppersonal=true ile derlenen kişisel sürüm (Play sürümünde false). */
object BuildFlags {
    val PERSONAL: Boolean get() = app.dnshizli.BuildConfig.PERSONAL
}
