package app.dnshizli.core

import java.io.IOException
import java.net.DatagramSocket
import java.net.Socket

/**
 * Uygulamanın kendi ağ işlerinin (hız ölçümü gibi) VPN tünelinin dışında kalmasını sağlayan köprü.
 *
 * Neden: uygulamanın kendi trafiği her zaman tünelin kapsamındadır. Yalnızca-DNS kipinde tünele sadece sahte DNS adresi
 * yönlendirilir, ölçüm soketleri doğrudan ağdan çıkar. Ağ geçidi (DPI atlatma, Reklam+) açıkken ise yol 0.0.0.0/0 olur:
 * korumasız bir ölçüm soketi tünele girer, düz DNS sorguları geçit tarafından yakalanıp seçili sunucuya (ve önbelleğine)
 * yönlendirilir, 853. port bağlantıları ise engellenir. Sonuç: sahte 0-1 ms süreler ya da "yanıt yok".
 *
 * Servis çalışırken [protectTcp]/[protectUdp] `VpnService.protect` çağrısına bağlanır; servis yokken boştur ve soketler
 * olduğu gibi kullanılır (JVM testleri dahil).
 */
object SocketGuard {
    @Volatile var protectTcp: ((Socket) -> Boolean)? = null
    @Volatile var protectUdp: ((DatagramSocket) -> Boolean)? = null

    /** UDP soketini tünel dışında tutmaya çalışır. Başarısızlık sessizce yok sayılır (ölçüm yine de denenir). */
    fun udp(s: DatagramSocket) {
        val p = protectUdp ?: return
        try { p(s) } catch (_: Exception) {}
    }

    /**
     * Henüz bağlanmamış TCP soketini tünel dışında tutmaya çalışır. Bağlanmamış bir Socket'in dosya tanıtıcısı yoktur;
     * bu yüzden önce yerel bir adrese bağlanır (bind), sonra korunur. Hedefe bağlanmak çağıranın işidir.
     */
    fun tcp(s: Socket) {
        val p = protectTcp ?: return
        try { s.bind(null) } catch (_: IOException) {}
        try { p(s) } catch (_: Exception) {}
    }
}
