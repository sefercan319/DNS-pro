package app.dnshizli.core

/**
 * UDP akışlarının İLK paketinden önce gönderilen düşük TTL'li sahte paketler (Xray "noises" / zapret UDP "fake" fikri; ham soket
 * gerekmez, çünkü UDP'de TTL gönderim anında okunur). Paket DPI cihazına ulaşır ve onu akışın başında şaşırtır; TTL düşük olduğu için
 * sunucuya varmadan ölür. Sunucuya varsa bile içerik rastgele baytlardır, geçerli bir paket değildir.
 *
 * Yalnızca parmak izi alınabilen iki akışa uygulanır: Discord ses "IP keşfi" (74 bayt, tür 1, uzunluk 70; UDP 50000-65535) ve
 * RFC 5389 STUN bağlama isteği (UDP 3478, 19302-19309). Başka hiçbir UDP paketine dokunulmaz.
 */
object UdpDecoy {
    const val COUNT = 4
    const val TTL = 4

    /** Bu paket (hedef port [port], [len] baytlık yük [b]'nin [off]'undan) sahte paket almalı mı? Bellek ayırmaz. */
    fun applies(port: Int, b: ByteArray, off: Int, len: Int): Boolean {
        if (off < 0 || len < 20 || off + len > b.size) return false
        if (port in 50000..65535 && len == 74 &&
            b[off].toInt() == 0 && b[off + 1].toInt() == 1 && b[off + 2].toInt() == 0 && (b[off + 3].toInt() and 0xFF) == 70) return true
        if (port == 3478 || port in 19302..19309) {
            // STUN: ilk iki bit 0, tür 0x0001 (bağlama isteği), uzunluk 4'ün katı ve pakete sığar, sihirli çerez 0x2112A442.
            val t = ((b[off].toInt() and 0xFF) shl 8) or (b[off + 1].toInt() and 0xFF)
            val l = ((b[off + 2].toInt() and 0xFF) shl 8) or (b[off + 3].toInt() and 0xFF)
            val cookie = ((b[off + 4].toInt() and 0xFF) shl 24) or ((b[off + 5].toInt() and 0xFF) shl 16) or
                ((b[off + 6].toInt() and 0xFF) shl 8) or (b[off + 7].toInt() and 0xFF)
            return t == 0x0001 && l % 4 == 0 && l + 20 == len && cookie == 0x2112A442
        }
        return false
    }
}
