package app.dnshizli.core

/**
 * Sunucuya kaç sıçrama (hop) uzaklıkta olunduğunu ölçer; sahte paketlerin (Dpi.FAKE_TTL) TTL'ini buna göre seçmek için
 * ("auto-TTL", zapret/ByeDPI fikri). Sabit TTL, sunucu yakınsa sahte paketi sunucuya ulaştırıp bağlantıyı bozar, DPI cihazı
 * uzaksa sahte paket ona hiç varmaz.
 *
 * Ölçüm paket okumaz: hedefe TTL = k ile bir TCP bağlantısı denenir. SYN hedefe ulaşırsa (bağlanır ya da RST döner) hop sayısı ≤ k,
 * ulaşamazsa zaman aşımı olur. İkili aramayla birkaç denemede sonuç çıkar. Ölçüm arka planda, hedef başına bir kez yapılır; sonuç
 * gelene dek (ve ölçülemeyen hedeflerde) eski sabit TTL kullanılır.
 *
 * [reach]: (adres, port, ttl) → 1 ulaştı, 0 ulaşamadı (zaman aşımı), -1 belirsiz (ağ yok, soket hatası). Platform sağlar.
 */
internal class HopProbe(
    private val reach: (ByteArray, Int, Int) -> Int,
    private val run: (Runnable) -> Unit = { Thread(it, "hop-olcum").apply { isDaemon = true }.start() },
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000L },
) {
    private val known = object : LinkedHashMap<String, Int>(64, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Int>?) = size > MAX_ENTRIES
    }
    private val retryAt = HashMap<String, Long>()
    private val pending = HashSet<String>()

    private fun key(ip: ByteArray) = String(ip, Charsets.ISO_8859_1)

    /** Ölçülmüş hop sayısı; ölçülmemişse ya da ölçülemediyse 0. */
    @Synchronized fun hops(ip: ByteArray): Int = known[key(ip)] ?: 0

    /** Hedef için ölçüm başlatır (zaten ölçülmüş, sürüyor ya da yakın zamanda başarısız olduysa hiçbir şey yapmaz). */
    fun request(ip: ByteArray, port: Int) {
        val k = key(ip)
        synchronized(this) {
            if (known.containsKey(k) || pending.contains(k) || pending.size >= MAX_PARALLEL) return
            if ((retryAt[k] ?: 0L) > nowMs()) return
            pending.add(k)
        }
        run(Runnable {
            val h = try { search { ttl -> reach(ip, port, ttl) } } catch (_: Exception) { -1 }
            synchronized(this) {
                pending.remove(k)
                if (h > 0) known[k] = h
                else { retryAt[k] = nowMs() + RETRY_MS; if (retryAt.size > MAX_ENTRIES) retryAt.clear() }
            }
        })
    }

    /** Yalnızca test için: bir sonucu doğrudan yerleştirir. */
    @Synchronized internal fun put(ip: ByteArray, hops: Int) { known[key(ip)] = hops }

    companion object {
        const val MAX_TTL = 32
        const val MAX_ENTRIES = 256
        const val MAX_PARALLEL = 2
        const val RETRY_MS = 10 * 60_000L

        /**
         * İkili arama: hedefe ulaşan en küçük TTL. [MAX_TTL]'de bile ulaşılamıyorsa ya da bir deneme belirsizse -1.
         * En çok 6 deneme; her başarısız deneme bir zaman aşımı sürer, bu yüzden arka planda çalıştırılır.
         */
        internal fun search(reach: (Int) -> Int): Int {
            if (reach(MAX_TTL) != 1) return -1
            var lo = 1
            var hi = MAX_TTL
            while (lo < hi) {
                val mid = (lo + hi) ushr 1
                val r = reach(mid)
                if (r < 0) return -1
                if (r == 1) hi = mid else lo = mid + 1
            }
            return hi
        }

        /**
         * Hop sayısına göre sahte paket TTL'i: sunucudan bir sıçrama önce (DPI'ın büyük olasılıkla arkasında, sunucunun önünde),
         * en çok 12. Dönen 0: sunucu çok yakın, hiçbir TTL güvenli değil (sahte paket gönderilmez). [hops] ölçülmemişse (≤ 0) -1.
         */
        fun ttlFor(hops: Int): Int {
            if (hops <= 0) return -1
            val t = minOf(hops - 1, 12)
            return if (t < MIN_FAKE_TTL) 0 else t
        }

        const val MIN_FAKE_TTL = 2
    }
}
