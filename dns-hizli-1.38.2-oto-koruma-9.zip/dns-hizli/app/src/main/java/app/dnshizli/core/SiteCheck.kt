package app.dnshizli.core

/** "Site neden açılmıyor?" teşhisinin en olası nedeni. */
enum class SiteCause { BAD_NAME, VPN_OFF, USER_BLOCK, LIST_BLOCK, CANARY, DOH_BLOCK, ALLOWED, NOT_OURS }

/** Teşhis sonucu: neden ve (varsa) düzeltmek için izin verilecek alan adı. */
class SiteReport(val cause: SiteCause, val name: String?)

object SiteCheck {
    /**
     * Sıra önemlidir: önce girdi, sonra bağlantı, sonra filtre kararı, en son "bizden değil".
     * [name]: normalize edilmiş alan adı (null = geçersiz). [verdict]: [FilterEngine] kararı ([FilterVerdict]); motor yoksa -1.
     * [blockDoh]: şifreli DNS sağlayıcılarının ağ geçidince kapatıldığı durum.
     */
    fun diagnose(name: String?, vpnOn: Boolean, verdict: Int, allowedByUser: Boolean, blockDoh: Boolean): SiteReport {
        if (name == null) return SiteReport(SiteCause.BAD_NAME, null)
        if (!vpnOn) return SiteReport(SiteCause.VPN_OFF, name)
        if (verdict == FilterVerdict.USER) return SiteReport(SiteCause.USER_BLOCK, name)
        if (verdict == FilterVerdict.LIST) return SiteReport(SiteCause.LIST_BLOCK, name)
        if (verdict == FilterVerdict.CANARY) return SiteReport(SiteCause.CANARY, name)
        if (blockDoh && Dpi.isDohHost(name)) return SiteReport(SiteCause.DOH_BLOCK, name)
        if (allowedByUser) return SiteReport(SiteCause.ALLOWED, name)
        return SiteReport(SiteCause.NOT_OURS, name)
    }
}
