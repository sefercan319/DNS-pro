package app.dnshizli.ui

import app.dnshizli.core.*
import kotlin.math.roundToInt

/**
 * Kendi stilim: her parçayı ayrı seçersin. Görünüm (gökyüzü, vurgu, sıvı hareketi ve dalga yüksekliği), hareket
 * (animasyon türü, biçimi ve büyüklüğü: 18 × 9), ses (tını, dizi ve perde: 16 × 12 × 2), kayıtlar (altı yuva) ve
 * araçlar (karıştır, dinle, sıfırla). Seçilen parça stilin kendi animasyonunun ya da sesinin yerine geçer.
 */
class CustomStylePage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.CUSTOM_STYLE, true, nav) {
    init {
        col.add(SectionTitle(Strings.CUSTOM_SECTION_LOOK))
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.CUSTOM_SKY, { Strings.customSkyName(skyOf(it)) }) { openSky() })
            c.add(NavRow(Strings.CUSTOM_ACCENT, { Strings.customAccentName(accentOf(it)) }) { openAccent() })
            c.add(NavRow(Strings.ORB_FLOW, { Strings.orbFlowName(it.orbFlow) }) { openFlow() })
            c.add(SliderRow(Strings.ORB_AMOUNT,
                { (it.orbPct - SavedStyles.ORB_MIN) / (SavedStyles.ORB_MAX - SavedStyles.ORB_MIN).toFloat() },
                { s, v -> s.copy(orbPct = SavedStyles.ORB_MIN + (v * (SavedStyles.ORB_MAX - SavedStyles.ORB_MIN)).roundToInt()) },
                { Strings.percent(it.orbPct) }))
        })
        col.add(SectionTitle(Strings.CUSTOM_SECTION_MOTION))
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.FX_KIND, { if (it.fxPart < 0) Strings.FX_PART_AUTO else Strings.fxKindName(FxParts.kind(it.fxPart)) }) { openFxKind() })
            c.add(NavRow(Strings.FX_FORM, { if (it.fxPart < 0) "—" else Strings.fxVariantName(FxParts.variant(it.fxPart)) }) { openFxForm() })
            c.add(SliderRow(Strings.FX_SIZE,
                { (it.fxPct - SavedStyles.FX_MIN) / (SavedStyles.FX_MAX - SavedStyles.FX_MIN).toFloat() },
                { s, v -> s.copy(fxPct = SavedStyles.FX_MIN + (v * (SavedStyles.FX_MAX - SavedStyles.FX_MIN)).roundToInt()) },
                { Strings.percent(it.fxPct) }))
        })
        col.add(SectionTitle(Strings.CUSTOM_SECTION_SOUND))
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.SOUND_VOICE, { if (it.soundPart < 0) Strings.SOUND_PART_AUTO else Strings.voiceName(SoundParts.voice(it.soundPart)) }) { openSoundVoicePicker(model, nav) })
            c.add(NavRow(Strings.SOUND_CONTOUR, { if (it.soundPart < 0) "—" else Strings.contourName(SoundParts.contour(it.soundPart)) + " · " + Strings.registerName(SoundParts.register(it.soundPart)) }) { openSoundContourPicker(model, nav) })
        })
        col.add(SectionTitle(Strings.CUSTOM_SECTION_SAVED))
        col.add(SettingsCard().also { c ->
            // Boş yuvaya dokununca mevcut ayarlar kaydedilir; dolu yuvada uygula ya da sil seçilir.
            for (slot in 0 until SavedStyles.MAX) {
                c.add(NavRow(Strings.customSlotName(slot), { savedSummary(it, slot) }) { onSlot(slot) })
            }
        })
        col.add(SectionTitle(Strings.CUSTOM_SECTION_TOOLS))
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.CUSTOM_SHUFFLE, null, Icon.REFRESH) { shuffleParts(model) })
            c.add(NavRow(Strings.CUSTOM_LISTEN, null) { model.previewSound() })
            c.add(NavRow(Strings.CUSTOM_RESET, null) { resetParts(model) })
        })
        finish()
    }

    private fun skyOf(s: AppSettings) = CustomPalette.decode(s.customTheme)?.first ?: CustomPalette.DEFAULT_SKY
    private fun accentOf(s: AppSettings) = CustomPalette.decode(s.customTheme)?.second ?: CustomPalette.DEFAULT_ACCENT

    private fun savedSummary(s: AppSettings, slot: Int): String {
        val p = s.savedStyles.getOrNull(slot)?.let { SavedStyles.parse(it) } ?: return Strings.CUSTOM_SLOT_EMPTY
        return Strings.customSkyName(CustomPalette.decode(p.customTheme)?.first ?: 0) + " · " + Strings.orbFlowName(p.orbFlow)
    }

    /** Boş yuvaya mevcut ayarları kaydeder; dolu yuvada uygula ya da sil seçilir. */
    private fun onSlot(slot: Int) {
        val filled = model.settings.savedStyles.getOrNull(slot)?.let { SavedStyles.parse(it) } != null
        if (!filled) { model.saveOwnStyle(slot); return }
        val opts = listOf(Option("apply", Strings.STYLE_APPLY, "", false), Option("delete", Strings.STYLE_DELETE, "", false))
        nav.openOptions(Strings.customSlotName(slot), opts) { id ->
            when (id) {
                "apply" -> model.applyOwnStyle(slot)
                "delete" -> model.deleteOwnStyle(slot)
            }
        }
    }

    private fun openSky() {
        val cur = skyOf(model.settings)
        val acc = accentOf(model.settings)
        val opts = CustomPalette.skies.indices.map { Option(it.toString(), Strings.customSkyName(it), "", it == cur) }
        nav.openOptions(Strings.CUSTOM_SKY, opts) { id -> id?.toIntOrNull()?.let { model.setCustomTheme(it, acc) } }
    }

    private fun openAccent() {
        val sky = skyOf(model.settings)
        val cur = accentOf(model.settings)
        val opts = CustomPalette.accents.indices.map { Option(it.toString(), Strings.customAccentName(it), "", it == cur) }
        nav.openOptions(Strings.CUSTOM_ACCENT, opts) { id -> id?.toIntOrNull()?.let { model.setCustomTheme(sky, it) } }
    }

    private fun openFlow() {
        val cur = model.settings.orbFlow
        val opts = OrbFlow.values().map { Option(it.id, Strings.orbFlowName(it), "", it == cur) }
        nav.openOptions(Strings.ORB_FLOW, opts) { id -> OrbFlow.byId(id)?.let { model.setOrbFlow(it) } }
    }

    /** Tür seçimi: biçim korunur (yoksa 0). "Stilin kendi animasyonu" parçayı kaldırır. */
    private fun openFxKind() {
        val cur = model.settings.fxPart
        val curKind = if (cur >= 0) FxParts.kind(cur) else null
        val opts = listOf(Option("-1", Strings.FX_PART_AUTO, "", cur < 0)) +
            FxParts.KINDS.map { Option(it.name, Strings.fxKindName(it), "", it == curKind) }
        nav.openOptions(Strings.FX_KIND, opts, footer = Strings.CUSTOM_STYLE_NOTE) { id ->
            if (id == "-1") model.setFxPart(-1)
            else FxKind.values().firstOrNull { it.name == id }?.let { k ->
                model.setFxPart(FxParts.index(k, if (cur >= 0) FxParts.variant(cur) else 0))
            }
        }
    }

    /** Biçim seçimi: tür korunur; tür yoksa halka türü kullanılır. */
    private fun openFxForm() {
        val cur = model.settings.fxPart
        val kind = if (cur >= 0) FxParts.kind(cur) else FxKind.RING
        val curV = if (cur >= 0) FxParts.variant(cur) else -1
        val opts = (0 until FxParts.VARIANTS).map { Option(it.toString(), Strings.fxVariantName(it), "", it == curV) }
        nav.openOptions(Strings.FX_FORM, opts) { id ->
            id?.toIntOrNull()?.let { model.setFxPart(FxParts.index(kind, it)) }
        }
    }
}

/** Tını seçimi: dizi ve perde korunur (yoksa ilk dizi, normal perde). Ses bölümü de bunu kullanır. */
fun openSoundVoicePicker(model: AppModel, nav: Nav) {
    val cur = model.settings.soundPart
    val curV = if (cur >= 0) SoundParts.voiceIndex(cur) else -1
    val opts = listOf(Option("-1", Strings.SOUND_PART_AUTO, "", cur < 0)) +
        SoundParts.VOICES.mapIndexed { i, v -> Option(i.toString(), Strings.voiceName(v), "", i == curV) }
    nav.openOptions(Strings.SOUND_VOICE, opts, footer = Strings.CUSTOM_STYLE_NOTE) { id ->
        if (id == "-1") { model.update { it.copy(soundPart = -1) }; return@openOptions }
        val v = id?.toIntOrNull() ?: return@openOptions
        val c = if (cur >= 0) SoundParts.contour(cur) else 0
        val r = if (cur >= 0) SoundParts.register(cur) else 0
        setSound(model, SoundParts.index(v, c, r))
    }
}

/** Dizi ve perde seçimi: tını korunur (yoksa ilk tını). */
fun openSoundContourPicker(model: AppModel, nav: Nav) {
    val cur = model.settings.soundPart
    val v = if (cur >= 0) SoundParts.voiceIndex(cur) else 0
    val opts = mutableListOf<Option>()
    for (c in 0 until SoundParts.CONTOURS) for (r in 0 until SoundParts.REGISTERS) {
        val id = c * SoundParts.REGISTERS + r
        val selected = cur >= 0 && SoundParts.contour(cur) == c && SoundParts.register(cur) == r
        opts.add(Option(id.toString(), Strings.contourName(c) + " · " + Strings.registerName(r), "", selected))
    }
    nav.openOptions(Strings.SOUND_CONTOUR, opts, footer = Strings.CUSTOM_STYLE_NOTE) { id ->
        val k = id?.toIntOrNull() ?: return@openOptions
        setSound(model, SoundParts.index(v, k / SoundParts.REGISTERS, k % SoundParts.REGISTERS))
    }
}

private fun setSound(model: AppModel, i: Int) {
    model.update { it.copy(soundPart = i) }
    model.previewSound()
}

/** Parçaları rastgele karıştırır (görünüm, animasyon, ses). Önizleme sesi çalınır. */
fun shuffleParts(model: AppModel) {
    val r = kotlin.random.Random.Default
    model.update {
        it.copy(
            fxPart = r.nextInt(FxParts.COUNT),
            soundPart = r.nextInt(SoundParts.COUNT),
            orbFlow = OrbFlow.values()[r.nextInt(OrbFlow.values().size)],
        )
    }
    model.previewSound()
}

/** Stilin varsayılanlarına döner: görünüm, animasyon ve ses parçaları otomatik olur; kaydırıcılar %100. */
fun resetParts(model: AppModel) {
    model.update { it.copy(customTheme = "0,0", orbFlow = OrbFlow.CALM, fxPart = -1, soundPart = -1, fxPct = 100, orbPct = 100) }
}
