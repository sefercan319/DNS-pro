package app.dnshizli.core

import java.io.InputStream
import java.util.Arrays

/**
 * Public Suffix List (publicsuffix.org, Mozilla, MPL 2.0) üzerinden "kayıt edilebilir alan adı" (eTLD+1) bulma.
 *
 * Neden: "aynı site" kararı (CNAME muafiyeti) son iki etikete bakınca co.uk, com.tr, github.io gibi uzantılarda yanlış sonuç veriyordu.
 * Hem ICANN hem ÖZEL (private) bölüm kullanılır; böylece "a.github.io" ile "b.github.io" ayrı site sayılır.
 * Liste `assets/filter/psl.txt` içindedir ([tools/build_psl.py] ile üretilir); okunamazsa [FilterEngine] küçük sezgisine döner.
 *
 * Sıcak yolda (cevaptaki her CNAME) çalıştığı için nesne ayırmaz: kurallar 64 bitlik özetlerin sıralı dizisi olarak tutulur ve
 * sorgulanan ad bayt bayt özetlenir (çakışma olasılığı ~10^-14).
 */
object PublicSuffix {
    /** [registrableStart] liste yüklü değilken döner. */
    const val NOT_READY = -2

    /** [icann]/[icannWild]: yalnızca ICANN bölümündeki kurallar ("#PRIVATE" ayracından önceki). */
    private class Data(val rules: LongArray, val wild: LongArray, val except: LongArray, val icann: LongArray, val icannWild: LongArray)

    @Volatile private var data: Data? = null

    val ready: Boolean get() = data != null

    fun clear() { data = null }

    private fun hash(buf: ByteArray, from: Int, to: Int): Long {
        var h = -0x340d631b7bdddcdbL                           // FNV-1a ofseti
        for (i in from until to) {
            var c = buf[i].toInt() and 0xFF
            if (c in 'A'.code..'Z'.code) c += 32                // büyük/küçük harf fark etmez
            h = (h xor c.toLong()) * 0x100000001b3L
        }
        h = h xor (h ushr 33); h *= -0xae502812aa7333L; h = h xor (h ushr 29)
        return h
    }

    private fun has(a: LongArray, h: Long): Boolean = Arrays.binarySearch(a, h) >= 0

    /** psl.txt: satır başına kural, "!" istisna, "*." joker, "#PRIVATE" bölüm ayracı. Bozuk satırlar atlanır. */
    fun install(ins: InputStream) {
        val rules = ArrayList<Long>(10_000)
        val wild = ArrayList<Long>(512)
        val except = ArrayList<Long>(64)
        val icann = ArrayList<Long>(7_000)
        val icannWild = ArrayList<Long>(256)
        var inPrivate = false
        ins.bufferedReader(Charsets.US_ASCII).forEachLine { raw ->
            val l = raw.trim()
            if (l == "#PRIVATE") inPrivate = true
            if (l.isEmpty() || l[0] == '#') return@forEachLine
            val body = when {
                l[0] == '!' -> l.substring(1)
                l.startsWith("*.") -> l.substring(2)
                else -> l
            }
            val b = body.toByteArray(Charsets.US_ASCII)
            val h = hash(b, 0, b.size)
            when {
                l[0] == '!' -> except.add(h)
                l.startsWith("*.") -> { wild.add(h); if (!inPrivate) icannWild.add(h) }
                else -> { rules.add(h); if (!inPrivate) icann.add(h) }
            }
        }
        if (rules.size < 100) throw java.io.IOException("psl listesi çok küçük")
        data = Data(
            rules.toLongArray().also { it.sort() }, wild.toLongArray().also { it.sort() }, except.toLongArray().also { it.sort() },
            icann.toLongArray().also { it.sort() }, icannWild.toLongArray().also { it.sort() },
        )
    }

    /**
     * [name] (küçük harfli, noktalı) ICANN bölümündeki ortak bir son ek mi (ör. "co.uk", "com.tr", "kobe.jp" altındaki joker)?
     * Böyle bir ad listeye eklenirse bütün siteleri kapsar. Özel bölümdeki ("github.io", "blogspot.com") adlar sayılmaz: onlar
     * bilerek engellenebilen barındırma hizmetleridir. Liste yüklü değilse null (bilinmiyor).
     */
    fun isIcannSuffix(name: String): Boolean? {
        val d = data ?: return null
        val b = name.toByteArray(Charsets.US_ASCII)
        val h = hash(b, 0, b.size)
        if (has(d.except, h)) return false                     // "www.ck" gibi istisna: sıradan alan adı
        if (has(d.icann, h)) return true
        val dot = name.indexOf('.')
        if (dot > 0 && dot + 1 < name.length) {
            val pb = name.substring(dot + 1).toByteArray(Charsets.US_ASCII)
            if (has(d.icannWild, hash(pb, 0, pb.size))) return true     // "*.ck" için "foo.ck"
        }
        return false
    }

    /**
     * [buf]'ın ilk [len] baytındaki alan adının kayıt edilebilir kısmının (eTLD+1) başlangıç konumu.
     * Ad tek başına bir genel sonek ise ya da tek etiketliyse 0 (adın tamamı). Boş adda -1. Liste yüklü değilse [NOT_READY].
     */
    fun registrableStart(buf: ByteArray, len: Int): Int {
        val d = data ?: return NOT_READY
        var end = len
        if (end > 0 && buf[end - 1] == '.'.code.toByte()) end--
        if (end <= 0) return -1
        // etiket sayısı
        var n = 1
        for (i in 0 until end) if (buf[i] == '.'.code.toByte()) n++
        if (n == 1) return 0
        // i. etiketin başlangıcı: sondan geriye doğru gezilir; her adımda o ana dek olan sonek özetlenir
        var suffixLabels = 1                                   // hiçbir kural eşleşmezse varsayılan kural "*"
        var labelsSeen = 0
        var start = end
        var nextStart = end                                    // bir sonraki (daha kısa) sonekin başlangıcı
        var excepted = false
        var i = end
        var registrable = 0
        // sondan başa: her etiket başlangıcında sonek = buf[start, end)
        while (i >= 0) {
            if (i == 0 || buf[i - 1] == '.'.code.toByte()) {
                val from = i
                labelsSeen++
                val h = hash(buf, from, end)
                if (has(d.except, h)) { suffixLabels = labelsSeen - 1; excepted = true; break }
                if (has(d.rules, h) && labelsSeen > suffixLabels) suffixLabels = labelsSeen
                // joker: bu sonek "*.X" için X ise, bir etiket fazlası da sonektir
                if (labelsSeen < n && has(d.wild, h) && labelsSeen + 1 > suffixLabels) suffixLabels = labelsSeen + 1
                nextStart = from
            }
            i--
        }
        if (!excepted) { /* döngü tamamlandı */ }
        if (n <= suffixLabels) return 0
        // adın sondan (suffixLabels + 1). etiketinin başlangıcı
        var seen = 0
        var j = end
        while (j >= 0) {
            if (j == 0 || buf[j - 1] == '.'.code.toByte()) {
                seen++
                if (seen == suffixLabels + 1) { registrable = j; break }
            }
            j--
        }
        return registrable
    }
}
