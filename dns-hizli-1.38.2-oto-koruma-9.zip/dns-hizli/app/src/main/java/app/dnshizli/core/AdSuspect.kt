package app.dnshizli.core

/**
 * "Son izin verilenler" listesinde reklam/yönlendirme sunucusuna BENZEYEN adları öne çıkarır. Engellemez: yalnızca
 * kullanıcıya hangisini engelleyeceğini gösterir (kararı kullanıcı verir). Bu yüzden ara sıra yanlış işaretleme zararsızdır;
 * yine de yaygın siteler işaretlenmesin diye kurallar dar tutuldu (ölçüm: tools/ analizinde ilk 10 bin sitenin ~%0,5'i).
 *
 * İpuçları (puanlar toplanır, [THRESHOLD] ve üstü "şüpheli"):
 *  - Etiket parçalarında reklam/izleme sözcükleri: ads, adserver, banner, popunder, track, trk, pixel, redirect, affiliate… (+3)
 *  - Kayıtlı adın onaltılık rastgele dizi olması (ör. 0017c6c37c.com) (+3)
 *  - Uzun sessiz harf dizisi (ör. krmwbimfpndw) (+2), harf-rakam karışımı (ör. 1jutu5nnx) (+2)
 *  - Kötüye kullanımı yüksek, yaygın sitelerde neredeyse hiç görülmeyen uzantılar (.cfd, .cyou, .icu, .sbs…) (+2),
 *    reklam ağlarında sık ama meşru kullanımı da olan uzantılar (.top, .xyz, .online, .site…) (+1)
 *  - 20+ harfli tek sözcük öbeği (dönen yönlendirme adlarına özgü: "launchingonsetwhirlwind") (+1)
 * Ad cihazdan çıkmaz; hesap tamamen yereldir.
 */
object AdSuspect {
    const val THRESHOLD = 3

    private val WORDS = setOf(
        "ad", "ads", "adv", "advert", "adverts", "advertising", "adserver", "adservice", "adsrv", "adserv", "adtech", "adnet",
        "banner", "banners", "pop", "popup", "popups", "popunder", "popads", "track", "tracker", "tracking", "trk", "trck",
        "pixel", "pixels", "beacon", "click", "clicks", "clk", "redirect", "redir", "rdr", "aff", "affiliate", "affiliates",
        "promo", "promos", "push", "pushnotify", "notify", "analytics", "metrics", "telemetry", "stats", "counter", "hit", "hits",
        "bet", "casino", "reklam", "reklamlar", "sponsor", "sponsored", "smartlink", "offerwall", "monetize", "monetization",
    )

    /** Kötüye kullanımı yüksek, ilk 200 bin sitede neredeyse hiç görülmeyen uzantılar. */
    internal val RISKY_TLDS = setOf(
        "cfd", "cyou", "icu", "sbs", "rest", "quest", "monster", "buzz", "bond", "autos", "boats", "beauty", "hair", "makeup",
        "skin", "homes", "yachts", "mom", "cam",
    )
    private val COMMON_ABUSED_TLDS = setOf("top", "xyz", "online", "site", "space", "click", "website", "pw", "bid", "win", "loan", "work")
    private val VOWELS = "aeiouy"

    fun isSuspect(name: String): Boolean = score(name) >= THRESHOLD

    fun score(raw: String): Int {
        val name = raw.lowercase().trimEnd('.')
        val labels = name.split('.')
        if (labels.size < 2 || labels.any { it.isEmpty() }) return 0
        var s = 0
        val tld = labels.last()
        // kayıtlı ad: "x.com.tr" gibi iki parçalı soneklerde bir önceki etiket
        val sldIdx = if (labels.size >= 3 && labels[labels.size - 2] in SECOND_LEVEL && tld.length == 2) labels.size - 3 else labels.size - 2
        val sld = labels[sldIdx]

        var word = false
        for (i in 0 until labels.size - 1) {
            for (tok in labels[i].split('-', '_')) {
                val t = tok.trimEnd { it.isDigit() }.trimStart { it.isDigit() }
                if (t in WORDS) { word = true; break }
            }
            if (word) break
        }
        if (word) s += 3

        val digits = sld.count { it.isDigit() }
        val letters = sld.count { it in 'a'..'z' }
        if (sld.length >= 8 && sld.all { it in '0'..'9' || it in 'a'..'f' } && digits >= 2 && letters >= 2) s += 3
        else {
            if (maxConsonants(sld) >= 6) s += 2
            if (sld.length >= 8 && digits >= 3 && letters >= 3 && MIXED.containsMatchIn(sld)) {
                // harf-rakam-harf geçişi birden çoksa (ör. x7k2m9) rastgele üretilmiş ad olasılığı yüksek
                s += if (ALTERNATING.containsMatchIn(sld)) 3 else 2
            }
        }
        if (tld in RISKY_TLDS) s += 2 else if (tld in COMMON_ABUSED_TLDS) s += 1
        if (letters >= 20 && letters == sld.length) s += 1
        return s
    }

    private val MIXED = Regex("[a-z][0-9]+[a-z]")
    private val ALTERNATING = Regex("[a-z][0-9][a-z]+[0-9][a-z]")
    private val SECOND_LEVEL = setOf("com", "net", "org", "co", "gen", "web", "biz", "info", "gov", "edu", "ac", "bel", "k12")

    private fun maxConsonants(s: String): Int {
        var m = 0; var c = 0
        for (ch in s) {
            if (ch in 'a'..'z' && ch !in VOWELS) { c++; if (c > m) m = c } else c = 0
        }
        return m
    }
}
