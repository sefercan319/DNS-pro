package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File
import kotlin.math.abs
import kotlin.math.ln

/** sizma66: küre fiziği (logaritmik yakınlaşma, kesintisiz süzülme, pencereli savurma hızı), hızlı maske basma, imzasız liste reddi. */
internal fun runRound42Tests() {
    zoomTests()
    flingTests()
    rasterTests()
    listTests()
}

private fun zoomTests() {
    T.group("sizma66: küre: yakınlaşma akıcılığı")
    // 1 → 8 yumuşak yakınlaşma: her kat (1→2, 2→4, 4→8) yaklaşık aynı sürede geçilmeli
    val c = GlobeCamera(0.0, 0.0, 1.0)
    c.zoomBy(1.0)
    val f = GlobeCamera::class.java.getDeclaredField("zoomTarget").apply { isAccessible = true }
    f.setDouble(c, 8.0)
    val dt = 1.0 / 120; var t = 0.0; val cross = DoubleArray(3) { -1.0 }
    while (t < 2.0) { c.tick(dt, false); t += dt; for (i in 0..2) if (cross[i] < 0 && c.zoom >= 2.0 * (1 shl i) * 0.999) cross[i] = t }
    val d1 = cross[0]; val d2 = cross[1] - cross[0]
    T.check("ilk kat ile ikinci kat arasındaki süre oranı dengeli (logaritmik; doğrusal ölçekte ilk kat çok kısa olurdu)", d1 > 0 && d2 > 0 && d2 / d1 in 0.6..1.8,
        "%.3f / %.3f".format(d1, d2))
    T.check("hedefe ulaşır", abs(c.zoom - 8.0) < 0.01)
    // Bırakınca süzülme hızı = parmağın hızı (sarsıntı yok)
    val p = GlobeCamera(0.0, 0.0, 2.0)
    repeat(12) { p.zoomAt(Math.exp(0.02), 0.0, 0.0, 200.0, 1.0 / 120) }      // ~2.4 ln/sn
    val vFinger = 0.02 * 120
    val z0 = p.zoom
    p.endDrag(0.0)
    p.tick(1.0 / 240, false)
    val vRelease = ln(p.zoom / z0) * 240
    T.check("bırakma anında yakınlaşma hızı kesintisiz (parmak ${"%.2f".format(vFinger)}, süzülme ${"%.2f".format(vRelease)} ln/sn)", abs(vRelease - vFinger) / vFinger < 0.35)
}

private fun flingTests() {
    T.group("sizma66: küre: savurma hızı")
    val c = GlobeCamera(0.0, 0.0, 1.0)
    c.beginDrag()
    val r = 200.0
    repeat(10) { c.dragBy(4.0, 0.0, r, 1.0 / 120) }     // sabit hız: 4 dp / 8,3 ms
    c.dragBy(40.0, 0.0, r, 0.002)                        // gecikmiş tek olay: kısa aralıkta büyük sıçrama
    c.endDrag(0.0)
    val wY = GlobeCamera::class.java.getDeclaredField("wY").apply { isAccessible = true }.getDouble(c)
    val expect = (4.0 / r) * 120
    T.check("tek sıçrayan olay savurma hızını katlamaz (beklenen ~${"%.1f".format(expect)}, ölçülen ${"%.1f".format(wY)} rad/sn)", wY > 0 && wY < expect * 3.2)
    val c2 = GlobeCamera(0.0, 0.0, 1.0)
    c2.beginDrag(); repeat(12) { c2.dragBy(3.0, 0.0, r, 1.0 / 60) }; c2.endDrag(0.0)
    val w2 = GlobeCamera::class.java.getDeclaredField("wY").apply { isAccessible = true }.getDouble(c2)
    T.check("düzenli sürüklemede hız doğru ölçülür", abs(w2 - (3.0 / r) * 60) / ((3.0 / r) * 60) < 0.1, "%.3f".format(w2))
    val c3 = GlobeCamera(0.0, 0.0, 1.0)
    c3.beginDrag(); repeat(8) { c3.dragBy(5.0, 0.0, r, 1.0 / 60) }; c3.endDrag(0.2)
    val w3 = GlobeCamera::class.java.getDeclaredField("wY").apply { isAccessible = true }.getDouble(c3)
    T.check("durup kaldırılan parmak savurmaz", w3 == 0.0)
}

private fun rasterTests() {
    T.group("sizma66: küre: maske basma")
    val w = 400; val h = 300; val px = 3f
    val pts = FloatArray(2 * 500) { i -> if (i % 2 == 0) 5f + (i / 2 % 25) * 4.7f else 5f + (i / 50) * 4.3f }
    val out = ByteArray(w * h)
    GlobeRaster.dots(pts, 500, 0.6f, px, out, w, h)
    // damga sonucu ile doğrudan hesap (karekök) farkı küçük olmalı
    var maxErr = 0; var sum = 0L
    for (y in 0 until h) for (x in 0 until w) {
        var best = 0f
        for (i in 0 until 500) {
            val dx = x + 0.5f - pts[2 * i] * px; val dy = y + 0.5f - pts[2 * i + 1] * px
            val c = (0.6f * px + 0.5f - kotlin.math.sqrt(dx * dx + dy * dy)).coerceIn(0f, 1f)
            if (c > best) best = c
        }
        val e = abs((out[y * w + x].toInt() and 0xFF) - (best * 255).toInt()); if (e > maxErr) maxErr = e; sum += e
    }
    T.check("damgalı basma doğrudan hesapla aynı görünür (ortalama hata ${"%.2f".format(sum.toDouble() / (w * h))}/255)", sum.toDouble() / (w * h) < 1.5 && maxErr < 140, "en çok $maxErr")
    T.check("ekran dışına taşan nokta güvenli kırpılır", run { GlobeRaster.dots(floatArrayOf(-1f, -1f, 140f, 105f, 1000f, 1000f), 3, 2f, px, out, w, h); true })
}

private fun listTests() {
    T.group("sizma66: engelli site listesi: imzasız dosya reddi")
    val src = File("app/src/main/java/app/dnshizli/platform/ListUpdater.kt").readText()
    T.check("anahtar varken imzasız ya da imzası tutmayan dosya yüklenmez", src.contains("key == null -> BlockedSites.parse(bytes)") &&
        src.contains("sf.isFile && sf.length() <= SIG_MAX -> BlockedSites.verified(bytes, sf.readBytes(), key)") && src.contains("else -> null"))
}
