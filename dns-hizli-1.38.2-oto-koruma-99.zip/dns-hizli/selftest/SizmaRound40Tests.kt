package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.GlobeNode
import app.dnshizli.ui.Strings
import java.io.File

/**
 * sizma64: DNS tek başına açıkken yüksek ms (şifreli bağlantının boşta kapanıp her seferinde yeniden kurulması) — sıcak tutma;
 * DNS iş parçacıklarına öncelik; küre yakınlaştırırken takılma — hareket sırasında hafif çizim ve eski karenin ölçeklenmesi.
 */
internal fun runRound40Tests() {
    keepaliveTests()
    prioTests()
    globeMotionTests()
}

private fun keepaliveTests() {
    T.group("sizma64: şifreli DNS: kısa aralarda bağlantı sıcak kalır")
    for (doh in listOf(false, true)) {
        val name = if (doh) "DoH" else "DoT"
        // Sıcak tutma YOK: boşta kapanır, sonraki soru yeni TLS el sıkışması bekler.
        FakeTlsDns(doh).use { srv ->
            SecHarness(if (doh) Proto.DOH else Proto.DOT, listOf(srv.target), idleMs = 400).use { h ->
                h.send(1, "a.example.com"); h.reply()
                Thread.sleep(900)
                h.send(2, "b.example.com"); h.reply()
                T.check("$name, sıcak tutma kapalı: 0,9 sn arayla iki soru iki ayrı bağlantı (her biri el sıkışması)", srv.accepted.get() == 2, "${srv.accepted.get()}")
            }
        }
        FakeTlsDns(doh).use { srv ->
            SecHarness(if (doh) Proto.DOH else Proto.DOT, listOf(srv.target), idleMs = 400, keepaliveMs = 250, warmWindowMs = 2_500).use { h ->
                h.send(1, "a.example.com"); h.reply()
                Thread.sleep(900)
                val t0 = System.nanoTime()
                h.send(2, "b.example.com"); val r = h.reply()
                val warmMs = (System.nanoTime() - t0) / 1e6
                T.check("$name, sıcak tutma açık: aynı bağlantı kullanılır (yeni el sıkışması yok), cevap doğru (${"%.1f".format(warmMs)} ms)",
                    srv.accepted.get() == 1 && r != null && checkReply(r, 2) == null && h.fw.keepaliveCount() >= 1, "bağlantı=${srv.accepted.get()} canlı tutma=${h.fw.keepaliveCount()}")
                T.check("$name: sıcak tutma soruları ad taşımaz (.invalid), sayaçlara/gecikme grafiğine girmez", srv.received.drop(1).filter { qname(it) != "b.example.com" }.all { qname(it) == SecureForwarder.KEEPALIVE_NAME } &&
                    h.fw.stats().answered == 2L)
                Thread.sleep(3_600)
                T.check("$name: pencere dolunca (son sorudan 2,5 sn) bağlantı kapanır, telefon boştayken trafik yok", waitUntil(3000) { h.fw.laneCount() == 0 && h.fw.openConnections() == 0 },
                    "şerit=${h.fw.laneCount()} bağlantı=${h.fw.openConnections()}")
                val k = h.fw.keepaliveCount(); Thread.sleep(800)
                T.check("$name: pencere bitince sıcak tutma sorusu gitmez", h.fw.keepaliveCount() == k)
            }
        }
    }
    FakeTlsDns(false).use { srv ->
        SecHarness(Proto.DOT, listOf(srv.target), idleMs = 400, keepaliveMs = 250, warmWindowMs = 2_500).use { h ->
            h.send(1, "a.example.com"); h.reply()
            srv.closeAllConnections()
            Thread.sleep(700)
            h.send(2, "b.example.com"); val r = h.reply()
            T.check("sunucu bağlantıyı kapatırsa sıcak tutma kendiliğinden bırakır, sonraki soru yine cevaplanır", r != null && checkReply(r, 2) == null)
        }
    }
    T.check("varsayılanlar: 9 sn'de bir, son sorudan 2 dk boyunca", SecureForwarder.KEEPALIVE_MS == 9_000L && SecureForwarder.WARM_WINDOW_MS == 120_000L)
}

private fun prioTests() {
    T.group("sizma64: DNS iş parçacıklarına öncelik")
    T.check("DNS bir kademe önde, ağ geçidi normal", ThreadPrio.dns == Thread.NORM_PRIORITY + 2 && ThreadPrio.gateway == Thread.NORM_PRIORITY)
    T.check("DNS iş parçacığı önceliği uygulanır", ThreadPrio.dnsThread(Runnable {}, "x").let { it.priority == ThreadPrio.dns && it.isDaemon })
    val src = listOf("core/DnsForwarder.kt", "core/SecureForwarder.kt").map { File("app/src/main/java/app/dnshizli/$it").readText() }
    T.check("düz ve şifreli DNS yönlendiricileri öncelikli iş parçacığı kullanır", src.all { it.contains("ThreadPrio.dnsThread(r, name)") })
    T.check("tünel okuyucu öncelikli, ağ geçidi normal", File("app/src/main/java/app/dnshizli/platform/Tunnel.kt").readText().contains("ThreadPrio.trySet(it, app.dnshizli.core.ThreadPrio.dns)") &&
        File("app/src/main/java/app/dnshizli/core/Gateway.kt").readText().contains("ThreadPrio.trySet(it, ThreadPrio.gateway)"))
}

private fun findGlobeNode(n: app.dnshizli.ui.Node): GlobeNode? = (n as? GlobeNode) ?: n.children.firstNotNullOfOrNull { findGlobeNode(it) }

private fun globeMotionTests() {
    T.group("sizma64: küre: yakınlaştırırken akıcılık")
    GlobeLand.map
    GlobeNode.syncShading = true; GlobeNode.syncBuild = true
    val rig = Rig(Rig.base())
    rig.tapText(Strings.GLOBE, settleMs = 900)
    val g = findGlobeNode(rig.scene.currentPage!!)!!
    class Rec : CountingGfx() { var round = 0; var square = 0; var clips = 0; var dotsCalls = 0; var lineCalls = 0; var scaled = false
        override fun dots(xy: FloatArray, n: Int, r: Float, square: Boolean) { dotsCalls++; if (square) this.square += n else round += n }
        override fun clipPath(p: GPath) { clips++ }
        override fun lines(xy: FloatArray, n: Int) { lineCalls++ }
        override fun scale(sx: Float, sy: Float) { scaled = true; super.scale(sx, sy) } }
    g.camera.focus(Math.toRadians(41.0), Math.toRadians(29.0)); g.camera.zoomBy(3.0)
    rig.settle(600)
    val rest = Rec(); g.draw(rest, rig.scene.env)
    T.check("dururken tam kalite: yuvarlak noktalar, kara şekliyle kırpma, sınır ışıması", !g.inMotion && !g.lastLight && rest.round > 0 && rest.clips == 1 && rest.lineCalls >= 3, "yuvarlak=${rest.round} kırpma=${rest.clips} çizgi=${rest.lineCalls}")
    g.camera.zoomStep()                                        // yumuşak yakınlaşma başlar
    rig.settle(16)
    val mov = Rec(); g.draw(mov, rig.scene.env)
    T.check("yakınlaşırken hafif çizim: kare noktalar, tek düzey, kırpma yok, ışıma yok", g.inMotion && g.lastLight && mov.round == 0 && mov.square > 0 && mov.clips == 0 && mov.dotsCalls == 1 && mov.lineCalls == rest.lineCalls - 1,
        "kare=${mov.square} yuvarlak=${mov.round} kırpma=${mov.clips} nokta çağrısı=${mov.dotsCalls}")
    rig.settle(3000)
    val back = Rec(); g.draw(back, rig.scene.env)
    T.check("durunca tam kaliteye döner", !g.inMotion && back.round > 0 && back.square == 0 && (back.clips == 1 || g.camera.zoom < GlobeNode.CLIP_ZOOM))
    // Arka plan kurucu: kare yetişmeden önce eski kare yeni yakınlığa ölçeklenir.
    GlobeNode.syncBuild = false
    val rig2 = Rig(Rig.base()); rig2.tapText(Strings.GLOBE, settleMs = 900)
    val g2 = findGlobeNode(rig2.scene.currentPage!!)!!
    g2.draw(Rec(), rig2.scene.env); rig2.settle(300); g2.draw(Rec(), rig2.scene.env)
    g2.camera.zoomBy(1.25)
    val sc = Rec(); g2.draw(sc, rig2.scene.env)
    T.check("yakınlık değişip yeni kare henüz kurulmamışken eski kare ölçeklenir (büyüklük parmağı izler)", g2.lastScale in 1.2f..1.3f && sc.scaled, "${g2.lastScale}")
    // Arka plan kurucusu yük altında birkaç kare sürebilir: kare gelene dek (en çok 5 sn) çizilir.
    val until = System.currentTimeMillis() + 5000
    while (System.currentTimeMillis() < until) { g2.draw(Rec(), rig2.scene.env); if (g2.lastScale == 1f) break; Thread.sleep(20) }
    T.check("yeni kare gelince ölçek kalkar", g2.lastScale == 1f, "${g2.lastScale}")
    GlobeNode.syncShading = false
}
