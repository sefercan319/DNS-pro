package app.dnshizli.selftest
import app.dnshizli.core.*
import app.dnshizli.ui.GlobeNode
internal fun globeBench() {
    val map = GlobeLand.map
    val bld = GlobeFrame.Builder(map); val fr = GlobeFrame(); val mm = FloatArray(9)
    val base = 160f   // dp (sahne dp ile çizer)
    fun key(c: GlobeCamera, r: Float) = GlobeFrame.Key(c.lon0, c.lat0, c.zoom, 360f, 440f, base, GlobeLand.minLevel(r), c.zoom >= GlobeNode.CLIP_ZOOM, GlobeHalftone.levelFor(r).first, -1, persp = c.persp.toFloat(), scale = r)
    repeat(200) { val c = GlobeCamera(Math.toRadians(30.0 + it), Math.toRadians(35.0)); c.matrix(mm); bld.build(fr, key(c, base), mm, 180f, 220f) }
    var z = 1.0
    println("zoom  kurulum_ms  nokta  köşe  sınır  kıyı  dolguNokta")
    while (z <= 12.0) {
        val c = GlobeCamera(Math.toRadians(39.0), Math.toRadians(35.0), z); c.matrix(mm)
        val r = base * z.toFloat()
        val t0 = System.nanoTime(); repeat(10) { bld.build(fr, key(c, r), mm, 180f, 220f) }
        val ms = (System.nanoTime() - t0) / 1e6 / 10
        var fillPts = 0; for (i in 0 until 4) fillPts += fr.groupPath[i].let { p -> var n = 0; p.visit(object : PathSink { override fun move(x: Float, y: Float) { n++ }; override fun line(x: Float, y: Float) { n++ }; override fun quad(cx: Float, cy: Float, x: Float, y: Float) { n++ }; override fun cubic(c1x: Float, c1y: Float, c2x: Float, c2y: Float, x: Float, y: Float) { n++ }; override fun close() {} }); n }
        var landPts = 0; fr.landPath.visit(object : PathSink { override fun move(x: Float, y: Float) { landPts++ }; override fun line(x: Float, y: Float) { landPts++ }; override fun quad(cx: Float, cy: Float, x: Float, y: Float) {}; override fun cubic(c1x: Float, c1y: Float, c2x: Float, c2y: Float, x: Float, y: Float) {}; override fun close() {} })
        println("%5.2f  %8.2f  %6d  %6d  %5d  %5d  %6d  clipYol=%d".format(z, ms, fr.dots.n, fr.vertices, fr.borderN, fr.coastN, fillPts, landPts))
        z *= 1.35
    }
}
