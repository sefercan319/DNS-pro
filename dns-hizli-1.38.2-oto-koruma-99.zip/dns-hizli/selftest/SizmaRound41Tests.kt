package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.GlobeNode
import app.dnshizli.ui.Strings
import java.io.File

/** sizma65: küre noktalı dokusu tek parça (maske), TLS sıkılaştırma, ana ekran ms'i. */
internal fun runRound41Tests() {
    globeMaskTests()
    tlsTests()
    msTests()
}

private fun findG(n: app.dnshizli.ui.Node): GlobeNode? = (n as? GlobeNode) ?: n.children.firstNotNullOfOrNull { findG(it) }

/** Aynı Java2D çizici, ama maske desteği yok (eski yol: noktalar tek tek). */
private class NoMask(private val d: AwtGfx) : Gfx by d { override val canMask: Boolean get() = false }

private fun globeMaskTests() {
    T.group("sizma65: küre: noktalı doku tek parça")
    GlobeLand.map
    GlobeNode.syncShading = true; GlobeNode.syncBuild = true
    val rig = Rig(Rig.base(), 360, 780)
    rig.tapText(Strings.GLOBE, settleMs = 900)
    val g = findG(rig.scene.currentPage!!)!!
    g.camera.focus(Math.toRadians(41.0), Math.toRadians(29.0)); g.camera.zoomBy(3.3); rig.settle(600)
    val a = AwtCanvas(360, 780); g.draw(a.gfx, rig.scene.env)
    val usedMask = g.lastMask
    val b = AwtCanvas(360, 780); g.draw(NoMask(b.gfx), rig.scene.env)
    val usedDots = !g.lastMask
    var diff = 0L; var big = 0
    for (y in 0 until a.image.height) for (x in 0 until a.image.width) {
        val p = a.image.getRGB(x, y); val q = b.image.getRGB(x, y)
        var d = 0; for (s in intArrayOf(0, 8, 16)) d += kotlin.math.abs(((p shr s) and 0xFF) - ((q shr s) and 0xFF))
        diff += d; if (d > 120) big++
    }
    val px = a.image.width * a.image.height
    val mean = diff.toDouble() / px / 3
    a.savePng("build/onizleme/kure-tek-parca.png"); b.savePng("build/onizleme/kure-tek-tek.png")
    a.dispose(); b.dispose()
    T.check("tek görüntü yolu kullanılır; desteklemeyen çizicide eski yol", usedMask && usedDots)
    T.check("görünüm aynı: ortalama piksel farkı < 1,5/255, belirgin farklı piksel < %0,5 (ölçülen ${"%.2f".format(mean)}, ${"%.3f".format(big * 100.0 / px)}%)",
        mean < 1.5 && big * 200 < px, "${"%.2f".format(mean)} / $big")
    class Cnt : CountingGfx() { var dotsCalls = 0; var masks = 0; var updates = 0
        override val canMask: Boolean get() = true
        override val pixelScale: Float get() = 3f
        override fun makeMask(w: Int, h: Int): Pic? = Pic(w, h, Any(), 0f, 1f)
        override fun updateMask(p: Pic, a: ByteArray) { updates++ }
        override fun mask(p: Pic, l: Float, t: Float, r: Float, b: Float) { masks++ }
        override fun dots(xy: FloatArray, n: Int, r: Float, square: Boolean) { dotsCalls++ } }
    val c1 = Cnt(); g.draw(c1, rig.scene.env); val c2 = Cnt(); g.draw(c2, rig.scene.env)
    T.check("ekrana tek görüntü: nokta çağrısı yok, maske bir kez yüklenir, kare değişmedikçe yeniden yüklenmez",
        c1.dotsCalls == 0 && c1.masks >= 1 && c1.updates >= 1 && c2.updates == 0, "nokta=${c1.dotsCalls} maske=${c1.masks} yükleme=${c1.updates}/${c2.updates}")
    // arka plan maliyeti: en yoğun düzeyde (≈95 bin nokta) telefon çözünürlüğünde (×3)
    val map = GlobeLand.map
    val bld = GlobeFrame.Builder(map); val fr = GlobeFrame(); val mm = FloatArray(9)
    val cam = GlobeCamera(Math.toRadians(39.0), Math.toRadians(35.0), 3.32); cam.matrix(mm)
    val r = 160f * 3.32f; val lvl = GlobeHalftone.levelFor(r).first
    val sp = (Math.PI / (GlobeHalftone.BASE_RINGS shl lvl) * r).toFloat()
    val k = GlobeFrame.Key(cam.lon0, cam.lat0, cam.zoom, 360f, 440f, 160f, GlobeLand.minLevel(r), true, lvl, -1, persp = cam.persp.toFloat(), scale = r, px = 3f, dotR = sp * GlobeNode.HALFTONE_R)
    repeat(5) { bld.build(fr, k, mm, 180f, 220f) }
    val t0 = System.nanoTime(); repeat(10) { bld.build(fr, k, mm, 180f, 220f) }
    val ms = (System.nanoTime() - t0) / 1e6 / 10
    println("    küre: ${fr.dots.n} nokta, maske ${fr.maskW}×${fr.maskH}, kurulum + basma ${"%.1f".format(ms)} ms (arka plan)")
    T.check("en yoğun karede kurulum + maskeye basma arka planda < 40 ms (JVM; ${"%.1f".format(ms)} ms)", fr.dots.n > 50_000 && fr.maskW % 4 == 0 && ms < 40.0)
    T.check("maske boyutu ekran pikseli kadar (dp × yoğunluk)", fr.maskW >= 1080 && fr.maskH >= 1320 && fr.mask.size == fr.maskW * fr.maskH)
    GlobeNode.syncShading = false; GlobeNode.syncBuild = false
}

private fun tlsTests() {
    T.group("sizma65: TLS sıkılaştırma")
    T.check("TLS 1.2'de CBC (AEAD olmayan) takımlar reddedilir", listOf("TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA", "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384", "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256")
        .none { TlsPolicy.acceptable("TLSv1.2", it) })
    T.check("TLS 1.2 ECDHE + GCM/ChaCha20/CCM kabul", listOf("TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384", "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256", "TLS_ECDHE_ECDSA_WITH_AES_128_CCM")
        .all { TlsPolicy.acceptable("TLSv1.2", it) })
    val sock = javax.net.ssl.SSLContext.getDefault().socketFactory.createSocket() as javax.net.ssl.SSLSocket
    TlsPolicy.harden(sock)
    T.check("soket yalnızca TLS 1.2/1.3 ve güçlü takımları teklif eder", sock.enabledProtocols.all { it == "TLSv1.2" || it == "TLSv1.3" } && sock.enabledCipherSuites.isNotEmpty() &&
        sock.enabledCipherSuites.all { cs -> TlsPolicy.acceptable(if (cs.startsWith("TLS_AES_") || cs.startsWith("TLS_CHACHA20_")) "TLSv1.3" else "TLSv1.2", cs) } &&
        sock.enabledCipherSuites.none { it.contains("CBC") || it.contains("_RSA_WITH_") && !it.contains("ECDHE") && !it.contains("DHE") })
    sock.close()
    val dir = "app/src/main/java/app/dnshizli/core/"
    T.check("tüm TLS istemcileri sıkılaştırılmış soket kullanır (şifreli DNS, ODoH, ölçüm, gizli tünel)",
        listOf("SecureForwarder.kt", "OdohHttp.kt", "DnsProbe.kt", "StealthLink.kt").all { File(dir + it).readText().contains("TlsPolicy.harden(") })
    val mitm = File(dir + "MitmProxy.kt").readText()
    T.check("tarayıcı kipi: hem tarayıcı tarafı hem site tarafı aynı kurala bağlı; site zayıfsa reddedilir",
        mitm.contains("TlsPolicy.harden(client)") && mitm.contains("TlsPolicy.harden(os)") && mitm.contains("TlsPolicy.require(os.session.protocol, os.session.cipherSuite)"))
}

private fun msTests() {
    T.group("sizma65: ana ekran ms: sunucu gecikmesi")
    // Önbellekte olmayan adların bir kısmını sunucu internette arar (100-300 ms); ağ gecikmesi alt çeyrekten okunur.
    val v = IntArray(30) { i -> if (i % 3 == 0) 220 + i else 28 + (i % 5) }
    T.check("alt çeyrek: sunucunun kendi araması (çözümleme) sayıyı şişirmez", LatencySummary.typicalMs(v, v.size) in 28..32 && LatencySummary.recentMs(v, v.size) in 28..40,
        "${LatencySummary.typicalMs(v, v.size)} / ${LatencySummary.recentMs(v, v.size)}")
    val slow = IntArray(30) { 400 + it }
    T.check("ağ gerçekten yavaşsa yavaş görünür", LatencySummary.typicalMs(slow, slow.size) >= 400)
    T.check("örnek yoksa 0; zaman aşımı sayılmaz", LatencySummary.typicalMs(IntArray(0), 0) == 0 && LatencySummary.typicalMs(intArrayOf(LatencyRing.TIMEOUT, 50), 2) == 50)
    T.check("servis ana ekrana alt çeyreği verir", File("app/src/main/java/app/dnshizli/platform/DnsVpnService.kt").readText().contains("LatencySummary.typicalMs(buf, n)"))
}
