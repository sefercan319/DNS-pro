package app.dnshizli.ui

import app.dnshizli.core.ALIGN_CENTER
import app.dnshizli.core.Catalog
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Gfx
import app.dnshizli.core.GlobeCamera
import app.dnshizli.core.Fill
import app.dnshizli.core.GlobeLand
import app.dnshizli.core.Pic
import app.dnshizli.core.GPath
import app.dnshizli.core.GlobeShading
import app.dnshizli.core.GlobeHalftone
import app.dnshizli.core.GlobeFrame
import app.dnshizli.core.GlobeLook
import app.dnshizli.core.GlobeSites
import app.dnshizli.core.Rgb
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Sunucu küresi: sürükleyerek döndür, iki parmakla (ya da çift dokunarak) yakınlaştır, noktaya dokununca o sağlayıcının
 * sunucuları altta listelenir; listeden dokununca bağlanır. Anycast sağlayıcılar merkezlerinde halka ile, tek konumlular dolu nokta ile.
 */
class GlobePage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.GLOBE, true, nav) {
    private val globe = GlobeNode(model) { onPick(it) }
    private val hint = Label(Strings.GLOBE_HINT, 13f, ink = Ink.SOFT, align = ALIGN_CENTER, maxLines = 2)
    private val title = Label("", 18f, bold = true, maxLines = 1, shrink = true)
    private val place = Label("", 13f, ink = Ink.SOFT, maxLines = 2)
    private val rows = Column(gap = M.ROW_GAP)
    private val unknownHead = Label(Strings.GLOBE_UNKNOWN, 15f, bold = true)
    private val unknown = Column(gap = M.ROW_GAP)
    private val rowCache = HashMap<String, ServerRow>()
    private var seen = -1
    private var picked: String? = null

    init {
        col.add(globe)
        col.add(hint)
        col.add(title)
        col.add(place)
        col.add(rows)
        col.add(unknownHead)
        col.add(unknown)
        finish()
        GlobeLand.warm()
        // Başlangıçta bağlı/seçili sunucunun markası seçili gelir.
        Catalog.byId(model.selectedId())?.let { s -> if (GlobeSites.of(s) != null) picked = s.brand }
        picked?.let { b -> GlobeSites.siteOfBrand(b)?.let { globe.camera.focus(Math.toRadians(it.lat), Math.toRadians(it.lon)) } }
    }

    private fun row(s: DnsServer) = rowCache.getOrPut(s.id) { ServerRow(s) { nav.openDetails(it) } }

    private fun onPick(brand: String?) {
        picked = brand; seen = -1
        brand?.let { GlobeSites.siteOfBrand(it) }?.let { globe.camera.flyTo(Math.toRadians(it.lat), Math.toRadians(it.lon)) }
    }

    val selectedBrand: String? get() = picked

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version || globe.selected != picked) {
            seen = model.version
            globe.selected = picked
            val visible = model.visibleServers()
            rows.removeAll()
            val b = picked
            if (b != null) {
                val site = GlobeSites.siteOfBrand(b)
                title.text = b
                place.text = site?.let { Strings.globePlace(it.place) + " · " + (if (it.anycast) Strings.GLOBE_ANYCAST else Strings.GLOBE_UNICAST) } ?: ""
                for (s in visible) if (s.brand == b && GlobeSites.of(s) != null) rows.add(row(s))
            } else { title.text = Strings.GLOBE_PICK; place.text = "" }
            unknown.removeAll()
            for (s in visible) if (GlobeSites.of(s) == null) unknown.add(row(s))
            unknownHead.visible = unknown.children.isNotEmpty()
            relayoutContent(env)
        }
        return super.tick(dt, env)
    }
}

class GlobeNode(private val model: AppModel, private val onPick: (String?) -> Unit) : Node(), Pinchable {
    val camera = GlobeCamera()
    var selected: String? = null
    private val p = GlobeCamera.P()
    private var lastX = 0f; private var lastY = 0f; private var lastT = 0f
    private var downX = 0f; private var downY = 0f
    private var active = false
    private var lastTapAt = -10f
    private var clock = 0f
    private var lastPinchT = -10f
    private var brands: List<String> = emptyList()
    private var lats = DoubleArray(0); private var lons = DoubleArray(0)
    private var brandsVersion = -1
    private val m = FloatArray(9)
    private val ll = DoubleArray(2)
    private class Label3(val text: String, val x: Float, val top: Float, val prio: Int)
    private val labelReq = ArrayList<Label3>()
    private val placed = ArrayList<FloatArray>()
    private var seg = FloatArray(4096)
    private var segN = 0

    // Kare geometrisi: iki kare (çizilen + kurulan). Kurulum arka plandaki iş parçacığında; arayüz yalnız çizer.
    private var front: GlobeFrame? = null
    private var back = GlobeFrame()
    private var builder: GlobeFrame.Builder? = null
    private var wanted: GlobeFrame.Key? = null
    private var dotLevel = -1; private var prevLevel = -1; private var dotFade = 1f
    /**
     * Kamera hareket ediyor mu (sürükleme, kıstırma, savrulma, yumuşak yakınlaşma)? Hareket sırasında çizim hafifler: yarım ton tek düzeyde,
     * kare uçlu (yuvarlak uçlu nokta çizimi on binlerce küçük daire demektir), kara şekliyle kırpma ve sınır ışıması yok. Kamera durunca
     * [RICH_AFTER_SEC] içinde tam kaliteye dönülür; durağan görüntü eskisiyle birebir aynıdır.
     */
    var inMotion = false; private set
    private var restSec = 1f
    private var maskPic: Pic? = null
    private var maskPic2: Pic? = null
    private var upFrame: GlobeFrame? = null
    private var upVer = -1
    /** Son çizimde noktalı doku tek görüntü (maske) olarak mı çizildi. */
    var lastMask = false; private set

    /** Karenin maskelerini görüntüye yükler (yalnızca kare değişince); boyut değişince görüntüler yeniden oluşturulur. */
    private fun uploadMasks(g: Gfx, f: GlobeFrame): Pic? {
        var p = maskPic
        if (p == null || p.w != f.maskW || p.h != f.maskH) {
            p?.release(); maskPic2?.release(); maskPic2 = null
            p = g.makeMask(f.maskW, f.maskH) ?: return null
            maskPic = p; upFrame = null
        }
        if (f.hasMask2 && maskPic2 == null) { maskPic2 = g.makeMask(f.maskW, f.maskH); upFrame = null }
        if (f !== upFrame || f.maskVer != upVer) {
            g.updateMask(p, f.mask)
            if (f.hasMask2) maskPic2?.let { g.updateMask(it, f.mask2) }
            upFrame = f; upVer = f.maskVer
        }
        return p
    }

    /** Son çizimde hafif yol mu kullanıldı (testler ve ölçüm için). */
    var lastLight = false; private set
    /** Son çizimde eski kare yeni yakınlığa ölçeklendi mi (oran; 1 = hayır). */
    var lastScale = 1f; private set
    private fun spacingOf(k: Int, r: Float): Float = (Math.PI / (GlobeHalftone.BASE_RINGS shl k) * r).toFloat()

    // Işık katmanları (dönüşten bağımsız; görünüm/stil değişince arka planda yeniden)
    private var shadingLook: GlobeLook? = null
    @Volatile private var shadeResult: Pair<GlobeLook, GlobeShading>? = null
    private var shadePending: GlobeLook? = null
    /** Son tick'ten beri çizildi mi (bkz. [tick]). */
    private var drawnSinceTick = false
    private var picTop: Pic? = null; private var picSpec: Pic? = null

    /** Son çizimin istatistikleri (test ve ayar için). */
    val lastDots: Int get() = front?.let { it.dots.n + it.dots2.n } ?: 0
    val lastVertices: Int get() = front?.vertices ?: 0
    val lastBorderSegs: Int get() = front?.borderN ?: 0
    val lastProjected: Int get() = front?.projected ?: 0
    /** Son kurulan karenin süresi (ns). */
    val lastBuildNs: Long get() = front?.buildNs ?: 0L
    /** Kamera değişmediği için yeniden kurulmadan çizilen kare sayısı. */
    var framesReused = 0; private set

    override val dragCapture: Boolean get() = true
    override val dragActive: Boolean get() = active
    override val dragAll: Boolean get() = true
    override val tappable: Boolean get() = true

    private val cx get() = w / 2f
    private val cy get() = h / 2f
    /** Yakınlaştırma 1'deki yarıçap (atmosfer halesi sığsın diye kenardan pay). */
    private val baseRadius: Float get() = minOf(w, h) / 2f / (1f + GlobeShading.H) - 6f
    /** Kürenin ekrandaki (ufuk) yarıçapı: yakınlaştırmada değişmez, küre hep tam daire kalır. */
    val radius: Float get() = baseRadius
    /** Ekran merkezindeki ölçek (dp/radyan): yakınlaştırmayla büyür (perspektif). */
    val centerScale: Float get() = baseRadius * camera.zoom.toFloat()

    override fun layout(env: Env, maxW: Float) { w = maxW; h = minOf(maxW, 440f) }

    private fun syncBrands() {
        if (brandsVersion == model.version) return
        brandsVersion = model.version
        brands = GlobeSites.brands(model.visibleServers())
        lats = DoubleArray(brands.size) { GlobeSites.siteOfBrand(brands[it])!!.lat }
        lons = DoubleArray(brands.size) { GlobeSites.siteOfBrand(brands[it])!!.lon }
    }

    /** Noktanın ekran konumu (yerel dp); arka yüzdeyse null. Test ve dokunma için. */
    fun screenOf(brand: String): Pair<Float, Float>? {
        val s = GlobeSites.siteOfBrand(brand) ?: return null
        camera.project(Math.toRadians(s.lat), Math.toRadians(s.lon), p)
        if (p.z <= 0.05) return null
        return (cx + radius * p.x.toFloat()) to (cy - radius * p.y.toFloat())
    }

    override fun tick(dt: Float, env: Env): Boolean {
        clock += dt
        val moving = camera.tick(dt.toDouble(), env.ambient && env.motion > 0f)
        // Kendiliğinden yavaş dönüş (ortam süsü) hareket sayılmaz ([GlobeCamera.tick] onu döndürmez): kullanıcının sürüklemesi,
        // kıstırması, savrulma ve yumuşak yakınlaşma sayılır.
        val userMove = active || moving
        if (userMove) restSec = 0f else if (restSec < RICH_AFTER_SEC) restSec += dt
        val wasMotion = inMotion
        inMotion = restSec < RICH_AFTER_SEC
        val richBack = wasMotion && !inMotion             // durunca bir kare daha: tam kaliteli çizim
        val fading = dotFade < 1f
        if (fading) dotFade = if (env.motion <= 0f) 1f else minOf(1f, dotFade + dt / 0.28f)
        // Arka plandaki iş (ışık katmanı, kare kurulumu) yalnızca çizimde teslim alınır. Düğüm çizilmiyorsa (sayfa kaydırılıp ekran
        // dışında kaldı, üstü kapandı) beklerken kare istenmez: aksi halde teslim alınamayan iş için sonsuza dek 60 fps kare istenirdi.
        val drew = drawnSinceTick
        drawnSinceTick = false
        val shadeWait = drew && shadePending != null && shadingLook !== shadePending
        // istenen kare henüz çizilmediyse (arka planda kuruluyor) kare istemeye devam
        val building = drew && wanted != null && front?.key != wanted
        val labelOn = tapLabel != null
        if (labelOn) { tapAge += dt; if (tapAge > TAP_LABEL_SEC) tapLabel = null }
        return moving || active || fading || shadeWait || building || labelOn || richBack || inMotion || !GlobeLand.ready
    }

    override fun ambient(env: Env): Boolean = env.ambient && env.motion > 0f

    override fun onDown(lx: Float, ly: Float, env: Env) {
        active = true
        downX = lx; downY = ly; lastX = lx; lastY = ly; lastT = clock
        camera.beginDrag()
    }

    override fun onDrag(lx: Float, ly: Float, env: Env) {
        val dt = (clock - lastT).toDouble()
        if (lx == lastX && ly == lastY) return
        camera.dragBy((lx - lastX).toDouble(), (ly - lastY).toDouble(), centerScale.toDouble(), if (dt > 0) dt else 1.0 / 60)
        lastX = lx; lastY = ly; lastT = clock
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        active = false
        camera.endDrag((clock - lastT).toDouble())
        val moved = (lx - downX) * (lx - downX) + (ly - downY) * (ly - downY) > 100f
        if (!tap || moved) return
        // Çift dokunma: dokunulan noktaya uçarak bir kademe yakınlaş
        if (clock - lastTapAt < 0.3f) {
            val r = radius.toDouble()
            if (camera.unproject((lx - cx) / r, (cy - ly) / r, ll)) camera.zoomStepAt(ll[0], ll[1]) else camera.zoomStep()
            lastTapAt = -10f; return
        }
        lastTapAt = clock
        syncBrands()
        val i = camera.pick(lx.toDouble(), ly.toDouble(), cx.toDouble(), cy.toDouble(), radius.toDouble(), lats, lons, 28.0)
        if (i >= 0) { env.tap(); onPick(brands[i]); tapLabel = null; return }
        // karaya dokunma: ülkenin adı dokunulan yerde kısa süre görünür
        val r = radius.toDouble()
        if (GlobeLand.ready && camera.unproject((lx - cx) / r, (cy - ly) / r, ll)) {
            val c = GlobeLand.map.countryAt(Math.toDegrees(ll[0]), Math.toDegrees(ll[1]))
            if (c >= 0) { tapLabel = countryName(c); tapLat = ll[0]; tapLon = ll[1]; tapAge = 0f } else tapLabel = null
        }
    }

    /** Ülkenin uygulama dilindeki adı (cihazın ülke adları tablosundan; kodsuz bölgede Natural Earth adı). */
    fun countryName(c: Int): String {
        val map = GlobeLand.map
        val code = map.numeric.getOrElse(c) { 0 }
        return (if (code > 0) model.host.countryName(code, app.dnshizli.core.L.lang.code) else null) ?: map.names[c]
    }

    /** Dokunulan ülkenin adı (görünüyorsa). */
    var tapLabel: String? = null; private set
    private var tapLat = 0.0; private var tapLon = 0.0; private var tapAge = 0f

    override fun onCancel(env: Env) { active = false; camera.endDrag(1.0) }

    override fun onPinch(f: Float, cx: Float, cy: Float, env: Env) {
        val dt = (clock - lastPinchT).toDouble(); lastPinchT = clock
        camera.zoomAt(f.toDouble(), (cx - this.cx).toDouble(), (cy - this.cy).toDouble(), baseRadius.toDouble(), if (dt in 0.001..0.2) dt else 0.0)
    }

    private fun addSeg(x0: Float, y0: Float, x1: Float, y1: Float) {
        if (4 * segN + 4 > seg.size) seg = seg.copyOf(seg.size * 2)
        seg[4 * segN] = x0; seg[4 * segN + 1] = y0; seg[4 * segN + 2] = x1; seg[4 * segN + 3] = y1; segN++
    }

    /** Dünya vektörleri [xyz] üzerindeki çoklu çizgilerin görünen parçaları (ızgara), [mm] kamerası ve [pp] perspektifiyle. */
    private fun polyline(xyz: FloatArray, start: Int, end: Int, r: Float, mm: FloatArray, pp: Float) {
        var px = 0f; var py = 0f; var pv = false
        val ks = sqrt(1f - pp * pp)
        for (k in start until end) {
            val wx = xyz[3 * k]; val wy = xyz[3 * k + 1]; val wz = xyz[3 * k + 2]
            val z = mm[6] * wx + mm[7] * wy + mm[8] * wz
            val sc = r * ks / (1f - pp * z)
            val x = cx + sc * (mm[0] * wx + mm[1] * wy + mm[2] * wz)
            val y = cy - sc * (mm[3] * wx + mm[4] * wy + mm[5] * wz)
            val v = z > pp + 0.01f * (1f - pp)
            if (v && pv) addSeg(px, py, x, y)
            px = x; py = y; pv = v
        }
    }

    /**
     * Işık katmanları: dönüşten bağımsız, görünüm (tema × stil) değişince arka planda yeniden hesaplanır; hazır olana dek
     * yaklaşık gradyan ışık çizilir. Görüntü bir kez platform görüntüsüne çevrilir.
     */
    private fun ensureShading(g: Gfx, look: GlobeLook) {
        if (look.flat || shadingLook === look) return
        val ready = shadeResult
        if (ready != null && ready.first === look) {
            val sh = ready.second
            picTop?.release(); picSpec?.release()
            picTop = g.makePic(sh.top, SHADE_PX, SHADE_PX)
            picSpec = if (look.specular > 0f) g.makePic(sh.spec, SHADE_PX, SHADE_PX) else null
            shadingLook = look; shadeResult = null
            return
        }
        if (shadePending === look) return
        shadePending = look
        if (syncShading) { shadeResult = look to GlobeShading(SHADE_PX, look); ensureShading(g, look); return }
        Thread({
            val sh = GlobeShading(SHADE_PX, look)
            shadeResult = look to sh             // tick hazır olana dek kare istemeye devam eder (çapraz iş parçacığı çağrısı yok)
        }, "kure-isik").apply { isDaemon = true }.start()
    }

    private fun layer(g: Gfx, pic: Pic?, r: Float) {
        val p = pic ?: return
        val R = r * (1f + GlobeShading.H)
        g.image(p, 0f, 0f, p.w.toFloat(), p.h.toFloat(), cx - R, cy - R, cx + R, cy + R)
    }

    /**
     * Çizilecek kare: istenen ([k]) kare hazırsa o; değilse arka planda kurulmaya gönderilir ve bir önceki kare çizilir
     * (bir kare gecikme, görüntü aynı). İlk kare ve [syncBuild] (test/önizleme) eşzamanlı kurulur.
     */
    private fun frameFor(map: GlobeLand.VecMap, k: GlobeFrame.Key): GlobeFrame {
        wanted = k
        val worker = if (syncBuild) null else GlobeFrame.worker(map)
        worker?.take(this)?.let { done -> if (done.key != null) { val old = front; front = done; back = old ?: GlobeFrame() } else back = done }
        val f = front
        if (f != null && f.key == k) { framesReused++; return f }
        if (f == null || worker == null) {
            val b = back
            (builder ?: GlobeFrame.Builder(map).also { builder = it }).build(b, k, m, cx, cy)
            back = f ?: GlobeFrame(); front = b
            return b
        }
        worker.submit(this, back, k, m, cx, cy)        // meşgulse sonraki karede yeniden denenir
        return f
    }

    override fun draw(g: Gfx, env: Env) {
        drawnSinceTick = true
        syncBrands()
        val look = GlobeLook.of(env.theme, env.art.style)
        ensureShading(g, look)
        camera.matrix(m)
        val map = if (GlobeLand.ready) GlobeLand.map else null
        var f: GlobeFrame? = null
        if (map != null) {
            val r0 = centerScale
            // Izgara düzeyi: ekranda aralık 0,88–2,3 katı dışına çıkınca bir sonrakine geçilir, iki düzey kısa sürede (zamanla) karışır.
            val want = GlobeHalftone.levelFor(r0).first
            if (dotLevel < 0) dotLevel = want
            else if (want != dotLevel) {
                val sp = spacingOf(dotLevel, r0)
                if (sp < GlobeHalftone.MIN_SPACING * 0.88f || sp > GlobeHalftone.MIN_SPACING * 2.3f) { prevLevel = dotLevel; dotLevel = want; dotFade = 0f }
            }
            val blend = dotFade < 1f && prevLevel >= 0 && !inMotion
            // Uzak görünümde kırpma yok (kaba maske noktaları kıyıya yakın tutar); yakında kesin kırpma.
            val clip = camera.zoom >= CLIP_ZOOM
            // Noktalı doku tek parça: noktalar arka planda maskeye basılır, ekrana tek görüntü çizilir (kare uçlu stiller eski yolda).
            val px = if (g.canMask && !look.square) g.pixelScale else 0f
            val key = GlobeFrame.Key(camera.lon0, camera.lat0, camera.zoom, w, h, radius, GlobeLand.minLevel(r0), clip, dotLevel, if (blend) prevLevel else -1,
                m[0], m[1], m[3], camera.persp.toFloat(), r0,
                px, if (px > 0f) spacingOf(dotLevel, r0) * HALFTONE_R else 0f, if (px > 0f && blend) spacingOf(prevLevel, r0) * HALFTONE_R else 0f)
            f = frameFor(map, key)
        }
        // Çizim, çizilen karenin kamerasıyla (harita, ışık, ızgara ve sunucu noktaları aynı anı gösterir)
        val r = f?.r ?: radius
        val mm = f?.m ?: m
        val pp = f?.key?.persp ?: camera.persp.toFloat()
        g.save()
        g.clipRect(0f, 0f, w, h)
        // Yeni yakınlık için kare arka planda kurulurken eski kare parmağı izleyecek oranda ölçeklenir: büyüklük her karede güncel,
        // ayrıntı bir kare sonra yetişir (takılma yerine akıcı büyüme). Yalnızca yakınlık değişirken ve makul oranda.
        val fk = f?.key
        val sc = if (fk != null && fk.scale > 0f && fk.zoom != camera.zoom) (centerScale / fk.scale) else 1f
        lastScale = if (sc in 0.5f..2f && kotlin.math.abs(sc - 1f) > 0.002f) sc else 1f
        if (lastScale != 1f) { g.translate(cx, cy); g.scale(lastScale, lastScale); g.translate(-cx, -cy) }
        val light = inMotion
        lastLight = light
        // okyanus
        g.paint(if (look.flat) Rgb.lerp(look.oceanLit, look.oceanDeep, 0.55f) else Rgb.lerp(look.oceanLit, look.oceanDeep, 0.3f))
        g.circle(cx, cy, r)
        // enlem/boylam ızgarası
        if (Rgb.a(look.grid) > 0) {
            segN = 0
            val gl = GRID
            for (k in 0 until gl.count) polyline(gl.xyz, gl.start[k], gl.start[k + 1], r, mm, pp)
            g.paint(look.grid); g.strokeWidth(0.8f); g.lines(seg, segN)
        }
        // okyanus parlaması (kara mat: karadan önce)
        if (shadingLook === look) layer(g, picSpec, r)
        if (f != null) {
            val k = f.key!!
            val zoom = k.zoom.toFloat()
            // ülke dolguları (komşular farklı ton)
            for (i in 0 until 4) { if (f.groupPath[i].isEmpty) continue; g.paint(look.fill[i]); g.path(f.groupPath[i]) }
            // noktalı doku
            if (k.dotLevel >= 0) {
                val clipNow = k.clip && !light
                if (clipNow) { g.save(); g.clipPath(f.landPath) }
                g.paint(look.halftone)
                val blend = k.prevLevel >= 0 && !light
                val pic = if (k.px > 0f && f.maskW > 0 && g.canMask) uploadMasks(g, f) else null
                if (pic != null) {
                    lastMask = true
                    val dw = f.maskW / k.px; val dh = f.maskH / k.px
                    g.save(); g.alpha(if (blend) dotFade else 1f); g.mask(pic, 0f, 0f, dw, dh); g.restore()
                    val p2 = maskPic2
                    if (blend && f.hasMask2 && p2 != null) { g.save(); g.alpha(1f - dotFade); g.mask(p2, 0f, 0f, dw, dh); g.restore() }
                } else {
                    lastMask = false
                    g.save(); g.alpha(if (blend) dotFade else 1f); g.dots(f.dots.a, f.dots.n, spacingOf(k.dotLevel, k.scale) * HALFTONE_R, look.square || light); g.restore()
                    if (blend) { g.save(); g.alpha(1f - dotFade); g.dots(f.dots2.a, f.dots2.n, spacingOf(k.prevLevel, k.scale) * HALFTONE_R, look.square); g.restore() }
                }
                if (clipNow) g.restore()
            }
            // kıyılar
            g.paint(look.coast); g.strokeWidth((0.7f + 0.08f * zoom).coerceAtMost(1.5f)); g.lines(f.coastSeg, f.coastN)
            // ülke sınırları: geniş ışıma + ince çekirdek
            val bw = (1.1f + 0.12f * zoom).coerceAtMost(2.2f)
            if (!look.flat && !light) { g.paint(Rgb.alpha(look.border, 0.2f)); g.strokeWidth(bw * 2.4f); g.lines(f.borderSeg, f.borderN) }
            g.paint(Rgb.alpha(look.border, 0.95f)); g.strokeWidth(bw); g.lines(f.borderSeg, f.borderN)
        }
        // ışık: gölge (çarpma) ve atmosfer saçılması tek görüntüde; hazır değilse yumuşak gradyan
        if (!look.flat) {
            if (picTop != null && shadingLook === look) layer(g, picTop, r)
            else fallbackLight(g, look, r)
        } else { g.strokeWidth(2f); g.paint(env.theme.accent); g.strokeCircle(cx, cy, r) }
        drawMarkers(g, env, r, mm, pp)
        drawTapLabel(g, env, r, mm, pp)
        g.restore()
    }

    /** Dokunulan ülkenin adı: dokunulan yere iğne gibi tutturulur (küre dönünce onu izler), son yarım saniyede söner. */
    private fun drawTapLabel(g: Gfx, env: Env, r: Float, mm: FloatArray, pp: Float) {
        val text = tapLabel ?: return
        val wx = (cos(tapLat) * cos(tapLon)).toFloat(); val wy = (cos(tapLat) * sin(tapLon)).toFloat(); val wz = sin(tapLat).toFloat()
        val vz = mm[6] * wx + mm[7] * wy + mm[8] * wz
        if (vz <= pp) return
        val sc = r * sqrt(1f - pp * pp) / (1f - pp * vz)
        val x = cx + sc * (mm[0] * wx + mm[1] * wy + mm[2] * wz); val y = cy - sc * (mm[3] * wx + mm[4] * wy + mm[5] * wz)
        val a = ((TAP_LABEL_SEC - tapAge) / 0.5f).coerceIn(0f, 1f) * (tapAge / 0.12f).coerceIn(0f, 1f)
        val fs = env.sz(13f)
        val tw = env.metrics.textWidth(text, fs, true)
        val l = (x - tw / 2 - 8f).coerceIn(4f, w - tw - 20f); val t = y - fs - 18f
        g.save(); g.alpha(a)
        g.paint(Rgb.alpha(0xFF000000.toInt(), 0.62f)); g.roundRect(l, t, l + tw + 16f, t + fs + 10f, 8f)
        g.paint(Rgb.WHITE); g.circle(x, y, 2.6f)
        g.text(text, l + 8f + tw / 2, t + fs + 2f, fs, true, ALIGN_CENTER)
        g.restore()
    }

    private fun fallbackLight(g: Gfx, look: GlobeLook, r: Float) {
        val hx = cx + LX * r * 0.62f; val hy = cy - LY * r * 0.62f
        val night = 0xFF000814.toInt()
        g.save(); g.clipCircle(cx, cy, r)
        g.paint(Fill.Radial(hx, hy, r * 1.8f, intArrayOf(Rgb.alpha(night, 0f), Rgb.alpha(night, 0f), Rgb.alpha(night, look.shade * 0.9f)), floatArrayOf(0f, 0.45f, 1f)))
        g.circle(cx, cy, r)
        g.restore()
        g.strokeWidth(1f); g.paint(Rgb.alpha(Rgb.WHITE, 0.28f)); g.strokeCircle(cx, cy, r)
    }

    /** Sunucu noktaları, çizilen karenin kamerasıyla ([mm], perspektif [pp]) izdüşürülür: harita ile noktalar aynı anı gösterir. */
    private fun drawMarkers(g: Gfx, env: Env, r: Float, mm: FloatArray, pp: Float) {
        val ks = sqrt(1f - pp * pp)
        val connected = Catalog.byId(model.selectedId())?.brand
        val on = model.vpn.active
        for (k in brands.indices) {
            val la = Math.toRadians(lats[k]); val lo = Math.toRadians(lons[k])
            val wx = (cos(la) * cos(lo)).toFloat(); val wy = (cos(la) * sin(lo)).toFloat(); val wz = sin(la).toFloat()
            val vz = mm[6] * wx + mm[7] * wy + mm[8] * wz
            val pz = (vz - pp) / (1f - pp)                     // ufukta 0, merkezde 1
            if (pz <= 0.05f) continue
            val sc = r * ks / (1f - pp * vz)
            val x = cx + sc * (mm[0] * wx + mm[1] * wy + mm[2] * wz); val y = cy - sc * (mm[3] * wx + mm[4] * wy + mm[5] * wz)
            val b = brands[k]
            val anycast = GlobeSites.siteOfBrand(b)!!.anycast
            val sel = b == selected
            val live = on && b == connected
            val col = if (live) 0xFF3DDC84.toInt() else if (sel) env.theme.link else 0xFFFFD166.toInt()
            val rr = if (sel) 8f else 5.5f
            val edge = (0.4f + 0.6f * pz).coerceIn(0f, 1f)
            g.save(); g.alpha(edge)
            if (live) { val pulse = (clock % 1.6f) / 1.6f; g.paint(Rgb.alpha(col, 0.5f * (1 - pulse))); g.circle(x, y, rr + 14f * pulse) }
            g.paint(Fill.radial(x, y, rr * 2.6f, Rgb.alpha(col, 0.45f), Rgb.alpha(col, 0f))); g.circle(x, y, rr * 2.6f)
            g.paint(Rgb.alpha(0xFF000000.toInt(), 0.4f)); g.circle(x, y + 1f, rr + 1.5f)
            if (anycast) { g.strokeWidth(2.4f); g.paint(col); g.strokeCircle(x, y, rr); g.circle(x, y, rr * 0.38f) }
            else { g.paint(col); g.circle(x, y, rr) }
            g.restore()
            // yakın planda tüm görünen sağlayıcıların adı (seçili/bağlı önce; çakışan etiket atlanır)
            if (sel || live || camera.zoom >= LABEL_ZOOM) labelReq.add(Label3(b, x, y - rr, if (sel || live) 0 else 1))
        }
        labelReq.sortBy { it.prio }
        placed.clear()
        val fs = env.sz(12f)
        for (lb in labelReq) {
            val tw = env.metrics.textWidth(lb.text, fs, true)
            val l = lb.x - tw / 2 - 6f; val t = lb.top - fs - 10f; val rr2 = lb.x + tw / 2 + 6f; val bt = lb.top - 3f
            if (placed.any { it[0] < rr2 && l < it[2] && it[1] < bt && t < it[3] }) continue
            placed.add(floatArrayOf(l, t, rr2, bt))
            g.paint(Rgb.alpha(0xFF000000.toInt(), 0.6f)); g.roundRect(l, t, rr2, bt, 6f)
            g.paint(Rgb.WHITE); g.text(lb.text, lb.x, lb.top - 7f, fs, true, ALIGN_CENTER)
        }
        labelReq.clear()
    }

    override fun a11y(): A11y = A11y(Strings.GLOBE + ": " + (selected ?: Strings.GLOBE_PICK) + (tapLabel?.let { " · $it" } ?: ""), Role.TEXT)

    companion object {
        /** Işık katmanlarının çözünürlüğü (piksel). */
        const val SHADE_PX = 512
        const val LABEL_ZOOM = 3.0
        /** Dokunulan ülke adının ekranda kalma süresi (sn). */
        const val TAP_LABEL_SEC = 2.6f
        /** Bu yakınlaştırmadan sonra yarım ton kara yoluyla kesin kırpılır. */
        const val CLIP_ZOOM = 2.0
        /** Kamera durduktan bu kadar sonra tam kaliteli çizime dönülür (sn). */
        const val RICH_AFTER_SEC = 0.12f
        /** Test/önizleme: ışık katmanlarını çizim sırasında eşzamanlı hesapla. */
        @JvmStatic var syncShading = false
        /** Test/önizleme: kare geometrisini arka plan yerine çizim sırasında kur (belirlenimci). */
        @JvmStatic var syncBuild = false
        /** Yarım ton noktasının yarıçapı / ızgara aralığı. */
        const val HALFTONE_R = 0.3f
        val LX = GlobeShading.LX; val LY = GlobeShading.LY

        /** Enlem/boylam ızgarası (30°), 4°'lik adımlarla dünya vektörleri. */
        val GRID: GlobeLand.Lines by lazy {
            val xyz = ArrayList<Float>(); val st = ArrayList<Int>()
            fun pt(la: Double, lo: Double) { val a = Math.toRadians(la); val o = Math.toRadians(lo); xyz.add((cos(a) * cos(o)).toFloat()); xyz.add((cos(a) * sin(o)).toFloat()); xyz.add(sin(a).toFloat()) }
            for (la in -60..60 step 30) { st.add(xyz.size / 3); for (lo in -180..180 step 4) pt(la.toDouble(), lo.toDouble()) }
            for (lo in -180 until 180 step 30) { st.add(xyz.size / 3); for (la in -80..80 step 4) pt(la.toDouble(), lo.toDouble()) }
            st.add(xyz.size / 3)
            GlobeLand.Lines(xyz.toFloatArray(), st.toIntArray())
        }
    }
}
