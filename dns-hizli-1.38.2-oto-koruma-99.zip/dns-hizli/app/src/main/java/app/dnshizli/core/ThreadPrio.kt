package app.dnshizli.core

/**
 * İş parçacığı öncelikleri. DNS cevabı küçük ama her şey onu bekler (sayfa, uygulama, video başlamadan önce ad çözülür); ağ geçidi ise
 * tüm trafiği taşır ve yoğun anda (video, indirme, DPI) işlemciyi uzun süre meşgul eder. İşlemci yetmeyince ikisi aynı önceliktense
 * DNS cevapları geçidin arkasında sıra bekler ve ms fırlar. DNS iş parçacıkları bir kademe önde çalışır; geçit normal kalır.
 *
 * Android'de Java önceliği çekirdek "nice" değerine çevrilir (5 → 0, 7 → -4); DNS'in yaptığı iş az olduğu için başkasını aç bırakmaz.
 * Masaüstü JVM varsayılan olarak öncelikleri yok sayar (testler etkilenmez).
 */
object ThreadPrio {
    /** DNS yönlendiricisi (cevap okuma, şifreli şeritler, zamanlayıcı) ve tünel okuyucu. */
    @Volatile var dns = Thread.NORM_PRIORITY + 2
    /** Ağ geçidi (tüm trafik). */
    @Volatile var gateway = Thread.NORM_PRIORITY

    fun dnsThread(r: Runnable, name: String): Thread = Thread(r, name).apply { isDaemon = true; trySet(this, dns) }

    fun trySet(t: Thread, p: Int) { try { t.priority = p.coerceIn(Thread.MIN_PRIORITY, Thread.MAX_PRIORITY) } catch (_: Exception) {} }
}
