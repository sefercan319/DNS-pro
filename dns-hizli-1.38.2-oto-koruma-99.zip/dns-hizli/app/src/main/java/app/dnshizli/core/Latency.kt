package app.dnshizli.core

/**
 * Son sorguların cevap süreleri için küçük, bellekteki halka (sorgu başına gecikme grafiği). Yalnızca süre tutulur; alan adı,
 * adres ya da zaman damgası yoktur. Diske yazılmaz, bağlantı kesilince (yönlendirici kapanınca) kaybolur.
 * Birden çok iş parçacığı yazabilir; okuma kopya alır. Ayırma yapmaz.
 */
class LatencyRing(capacity: Int = CAPACITY) {
    private val cap = capacity.coerceAtLeast(1)
    private val ring = IntArray(cap)
    private var next = 0
    private var count = 0

    /** [ms] ağdan gelen bir cevabın süresi; [TIMEOUT] zaman aşımına uğrayan bir sorgu. */
    @Synchronized
    fun add(ms: Int) {
        ring[next] = if (ms == TIMEOUT) TIMEOUT else ms.coerceIn(0, MAX_MS)
        next = (next + 1) % cap
        if (count < cap) count++
    }

    /** Eskiden yeniye, en çok [out] boyu kadar (en yeniler) kopyalar; yazılan sayıyı döner. */
    @Synchronized
    fun copyTo(out: IntArray): Int {
        val n = minOf(count, out.size)
        val start = (next - n + cap * 2) % cap
        for (i in 0 until n) out[i] = ring[(start + i) % cap]
        return n
    }

    @Synchronized
    fun size(): Int = count

    @Synchronized
    fun clear() { next = 0; count = 0 }

    companion object {
        const val CAPACITY = 120
        const val TIMEOUT = -1

        /** Bir cevap süresi bundan uzun görünmez (ms). */
        const val MAX_MS = 60_000
    }
}

/** Grafiğin özeti: ölçülen sorgular üzerinden. Zaman aşımları ortalamaya ve en büyük değere girmez. */
class LatencySummary(val answered: Int, val timeouts: Int, val avgMs: Int, val maxMs: Int, val lastMs: Int) {
    companion object {
        fun of(v: IntArray, n: Int): LatencySummary {
            var a = 0
            var t = 0
            var sum = 0L
            var mx = 0
            var last = -1
            for (i in 0 until n) {
                val x = v[i]
                if (x == LatencyRing.TIMEOUT) { t++; last = -1; continue }
                a++
                sum += x
                if (x > mx) mx = x
                last = x
            }
            return LatencySummary(a, t, if (a == 0) 0 else (sum / a).toInt(), mx, last)
        }

        /** [recentMs]'in baktığı en yeni cevap sayısı. */
        const val RECENT = 30

        /**
         * Ana ekrandaki ms: son [RECENT] cevabın ortancası (zaman aşımları sayılmaz). Bağlanıştan beri birikimli ortalama, ilk anların
         * yüksek süreleriyle (boş önbellek, şifreli bağlantının açılışı, bütün uygulamaların aynı anda sorması) saatlerce şişik kalırdı;
         * ortanca tek tük yavaş cevaba da kapılmaz. Cevap yoksa 0.
         */
        /**
         * Ana ekrandaki ms: son [RECENT] cevabın ALT ÇEYREĞİ. Önbellekte olmayan bir adı DNS sunucusu çoğu zaman kendisi de internette
         * arar (100–300 ms); bu sunucunun çözümleme süresidir, bağlantının hızı değil. Ortanca bu aramalarla şişip sunucu listesindeki
         * ölçümden (sunucunun önbelleğindeki adla) çok yüksek görünüyordu. Alt çeyrek bağlantının gerçek gidiş-dönüşünü gösterir; ağ
         * gerçekten yavaşsa o da yükselir. Cevap yoksa 0.
         */
        fun typicalMs(v: IntArray, n: Int): Int {
            val tmp = IntArray(RECENT)
            var k = 0
            var i = minOf(n, v.size) - 1
            while (i >= 0 && k < RECENT) { val x = v[i]; if (x != LatencyRing.TIMEOUT) tmp[k++] = x; i-- }
            if (k == 0) return 0
            java.util.Arrays.sort(tmp, 0, k)
            return tmp[(k - 1) / 4]
        }

        fun recentMs(v: IntArray, n: Int): Int {
            val tmp = IntArray(RECENT)
            var k = 0
            var i = minOf(n, v.size) - 1
            while (i >= 0 && k < RECENT) { val x = v[i]; if (x != LatencyRing.TIMEOUT) tmp[k++] = x; i-- }
            if (k == 0) return 0
            java.util.Arrays.sort(tmp, 0, k)
            return if (k % 2 == 1) tmp[k / 2] else (tmp[k / 2 - 1] + tmp[k / 2]) / 2
        }
    }
}
