package app.dnshizli.core

import java.io.BufferedInputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager

/**
 * Stealth: WireGuard paketleri TLS içinde, WebSocket ikili çerçeveleriyle kendi aktarıcımıza ("dhs-sunucu", tools/stealth) gider.
 * DPI sıradan bir HTTPS bağlantısı görür; UDP'nin kısıtlandığı ya da WireGuard imzasının engellendiği ağlarda da çalışır.
 *  - Sunucu sertifikası CA ile değil, SPKI özetiyle SABİTLENİR ([pin]): alan adı gerekmez, araya giren sahte sertifika reddedilir.
 *  - Gizli yol ([path]) bilinmeden aktarıcı sıradan nginx 404'ü verir (etkin yoklama aktarıcıyı ayırt edemez).
 *  - SNI isteğe bağlıdır ([sni]); IP'ye bağlanırken boş bırakılırsa SNI gönderilmez.
 */
class StealthCfg(
    val host: String, val port: Int, val sni: String?, val path: String, val pin: ByteArray, val pq: Boolean = false,
    /** Aktarıcının kalıcı ML-KEM anahtarının SHA-256 özeti: varsa kuantum sonrası SUNUCU KİMLİĞİ doğrulanır (PQ2, [PqPsk.exchange2]). */
    val pqPin: ByteArray? = null,
) {
    override fun toString() = "$host:$port"
}

object Ws {
    private const val GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
    const val OP_BINARY = 0x2
    const val OP_CLOSE = 0x8
    const val OP_PING = 0x9
    const val OP_PONG = 0xA
    const val MAX_PAYLOAD = 65535
    const val MAX_HEAD = 4096
    private const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"

    fun accept(key: String): String =
        java.util.Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-1").digest((key + GUID).toByteArray(Charsets.US_ASCII)))

    fun newKey(rng: SecureRandom): String = java.util.Base64.getEncoder().encodeToString(ByteArray(16).also { rng.nextBytes(it) })

    fun request(host: String, path: String, key: String): ByteArray = (
        "GET $path HTTP/1.1\r\nHost: $host\r\nUser-Agent: $UA\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n" +
            "Sec-WebSocket-Key: $key\r\nSec-WebSocket-Version: 13\r\n\r\n").toByteArray(Charsets.US_ASCII)

    /** Sunucu cevap başlığı (boş satır dahil değil) 101 + doğru Accept mi? */
    fun responseOk(head: String, key: String): Boolean {
        val lines = head.split("\r\n")
        val st = lines.firstOrNull() ?: return false
        if (!st.startsWith("HTTP/1.1 101")) return false
        var up = false; var conn = false; var acc = false
        for (l in lines.drop(1)) {
            val c = l.indexOf(':'); if (c <= 0) continue
            val k = l.substring(0, c).trim().lowercase(); val v = l.substring(c + 1).trim()
            when (k) {
                "upgrade" -> up = v.equals("websocket", true)
                "connection" -> conn = v.split(',').any { it.trim().equals("upgrade", true) }
                "sec-websocket-accept" -> acc = v == accept(key)
            }
        }
        return up && conn && acc
    }

    /** İstemci çerçevesi (maskeli, tek parça). */
    fun frame(op: Int, p: ByteArray, off: Int, len: Int, mask: ByteArray): ByteArray {
        require(len in 0..MAX_PAYLOAD)
        val h = if (len < 126) 2 else 4
        val out = ByteArray(h + 4 + len)
        out[0] = (0x80 or op).toByte()
        if (len < 126) out[1] = (0x80 or len).toByte()
        else { out[1] = (0x80 or 126).toByte(); out[2] = (len ushr 8).toByte(); out[3] = len.toByte() }
        System.arraycopy(mask, 0, out, h, 4)
        for (i in 0 until len) out[h + 4 + i] = (p[off + i].toInt() xor mask[i and 3].toInt()).toByte()
        return out
    }

    class Frame(val op: Int, val len: Int)

    /** Sunucu çerçevesini [buf]'a okur: maskesiz, tek parça, ayrılmış bitler sıfır olmalı; değilse IOException. Akış bittiyse null. */
    fun read(inp: InputStream, buf: ByteArray): Frame? {
        val b0 = inp.read(); if (b0 < 0) return null
        val b1 = inp.read(); if (b1 < 0) throw EOFException()
        if (b0 and 0x70 != 0 || b0 and 0x80 == 0 || b1 and 0x80 != 0) throw IOException("ws: geçersiz çerçeve başlığı")
        val op = b0 and 0x0F
        var n = b1 and 0x7F
        if (n == 127) throw IOException("ws: çerçeve çok büyük")
        if (n == 126) { val a = inp.read(); val b = inp.read(); if (b < 0) throw EOFException(); n = (a shl 8) or b; if (n < 126) throw IOException("ws: kısa kodlama") }
        if (op >= 0x8 && n > 125) throw IOException("ws: denetim çerçevesi büyük")
        if (op != OP_BINARY && op != OP_CLOSE && op != OP_PING && op != OP_PONG) throw IOException("ws: beklenmeyen tür $op")
        if (n > buf.size) throw IOException("ws: tampon küçük")
        var got = 0
        while (got < n) { val r = inp.read(buf, got, n - got); if (r < 0) throw EOFException(); got += r }
        return Frame(op, n)
    }
}

/** Sunucu sertifikasının SPKI SHA-256 özeti [pin] ile aynı olmalı; zincirin geri kalanına ve CA'ya bakılmaz (sabitleme). */
class PinTrust(private val pin: ByteArray) : X509TrustManager {
    override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) = throw CertificateException("istemci doğrulaması yok")
    override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        val leaf = chain?.firstOrNull() ?: throw CertificateException("sertifika yok")
        val h = MessageDigest.getInstance("SHA-256").digest(leaf.publicKey.encoded)
        if (!MessageDigest.isEqual(h, pin)) throw CertificateException("Stealth: sunucu sertifikası sabitlenen özetle uyuşmuyor")
    }
    override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
}

/** Kurulmuş Stealth bağlantısı. [send] birden çok iş parçacığından çağrılabilir; [receive] tek okuyucudan. */
class StealthSession internal constructor(private val sock: SSLSocket, private val inp: InputStream, private val out: OutputStream, private val rng: SecureRandom) : AutoCloseable {
    private companion object { const val SHAPED: Byte = 0xF5.toByte() }
    private val wlock = Any()
    private val mask = ByteArray(4)

    fun send(p: ByteArray, off: Int = 0, len: Int = p.size) = write(Ws.OP_BINARY, p, off, len)

    private fun write(op: Int, p: ByteArray, off: Int, len: Int) = synchronized(wlock) {
        rng.nextBytes(mask)
        out.write(Ws.frame(op, p, off, len, mask)); out.flush()
    }

    /** Bir sonraki veri çerçevesini [buf]'a okur, uzunluğu döner; bağlantı kapandıysa -1. Ping'e kendisi cevap verir. */
    fun receive(buf: ByteArray): Int {
        while (true) {
            val f = Ws.read(inp, buf) ?: return -1
            when (f.op) {
                Ws.OP_BINARY -> {
                    // Aktarıcının trafik gizleme çerçevesi: 0xF5 ‖ asıl uzunluk (2) ‖ WireGuard iletisi ‖ dolgu; uzunluk 0 = örtü
                    if (f.len >= 3 && buf[0] == SHAPED) {
                        val n = ((buf[1].toInt() and 0xFF) shl 8) or (buf[2].toInt() and 0xFF)
                        if (n == 0) { coverReceived++; continue }
                        if (n > f.len - 3) throw java.io.IOException("ws: bozuk dolgulu çerçeve")
                        System.arraycopy(buf, 3, buf, 0, n)
                        return n
                    }
                    return f.len
                }
                Ws.OP_PING -> write(Ws.OP_PONG, buf, 0, f.len)
                Ws.OP_CLOSE -> { try { write(Ws.OP_CLOSE, buf, 0, 0) } catch (_: IOException) {}; return -1 }
                else -> {}
            }
        }
    }

    /** Aktarıcıdan gelen örtü çerçevesi sayısı (trafik gizleme). */
    @Volatile var coverReceived = 0L; private set

    /** Aktarıcıdan sunucu → telefon yönünde dolgu ve örtü ister ([Shaper.Level.code]); eski aktarıcı bunu WireGuard'a iletir, o da atar. */
    fun requestShaping(levelCode: Int) = send(byteArrayOf(0xF4.toByte(), 'S'.code.toByte(), 'H'.code.toByte(), 'P'.code.toByte(), '1'.code.toByte(), levelCode.toByte()))

    /** Okuma zaman aşımı (ms; 0 = sınırsız). Denetim iletisi beklerken kullanılır. */
    fun setReadTimeout(ms: Int) { sock.soTimeout = ms }

    override fun close() { try { sock.close() } catch (_: Exception) {} }
}

object StealthClient {
    /**
     * [connect] korunan (tünele girmeyen) ham TCP soketini kurar. TLS el sıkışması sabitlemeyle doğrulanır, sonra WebSocket yükseltmesi.
     * Herhangi bir adım başarısızsa IOException (soket kapatılır).
     */
    fun open(cfg: StealthCfg, addr: InetSocketAddress, connect: (InetSocketAddress) -> Socket, rng: SecureRandom = SecureRandom(), timeoutMs: Int = 10_000): StealthSession {
        val raw = connect(addr)
        try {
            raw.soTimeout = timeoutMs
            raw.tcpNoDelay = true
            val ctx = SSLContext.getInstance("TLS").apply { init(null, arrayOf(PinTrust(cfg.pin)), rng) }
            val s = ctx.socketFactory.createSocket(raw, cfg.sni ?: addr.address.hostAddress, addr.port, true) as SSLSocket
            val params = s.sslParameters
            params.serverNames = cfg.sni?.let { listOf(SNIHostName(it)) } ?: emptyList()
            params.applicationProtocols = arrayOf("http/1.1")
            params.protocols = s.supportedProtocols.filter { it == "TLSv1.3" || it == "TLSv1.2" }.toTypedArray()
            s.sslParameters = params
            TlsPolicy.harden(s)
            s.startHandshake()
            TlsPolicy.require(s.session.protocol, s.session.cipherSuite)
            val out = s.outputStream
            val inp = BufferedInputStream(s.inputStream, 16 * 1024)
            val key = Ws.newKey(rng)
            out.write(Ws.request(cfg.sni ?: cfg.host, cfg.path, key)); out.flush()
            val head = readHead(inp)
            if (!Ws.responseOk(head, key)) throw IOException("Stealth: aktarıcı yükseltmeyi reddetti (${head.substringBefore("\r\n").take(40)})")
            s.soTimeout = 0
            return StealthSession(s, inp, out, rng)
        } catch (e: Exception) {
            try { raw.close() } catch (_: Exception) {}
            throw e as? IOException ?: IOException(e)
        }
    }

    internal fun readHead(inp: InputStream): String {
        val sb = StringBuilder()
        while (true) {
            val c = inp.read(); if (c < 0) throw EOFException("Stealth: cevap yarım")
            sb.append(c.toChar())
            if (sb.length > Ws.MAX_HEAD) throw IOException("Stealth: cevap başlığı çok uzun")
            if (sb.endsWith("\r\n\r\n")) return sb.substring(0, sb.length - 4)
        }
    }
}
