package app.dnshizli.core

import kotlin.math.sqrt

/**
 * Sunucu küresinin bir karelik geometrisi: ülke dolgu yolları, kara yolu (kırpma), noktalı doku, kıyı ve sınır çizgileri —
 * hepsi ekran koordinatında, kurulduğu kameraya göre ([m], [cx], [cy], [r]). Kurulum ([Builder]) ana iş parçacığından ayrı
 * yürür ([Worker]); arayüz her karede en son biten kareyi çizer (görüntü aynı, ana iş parçacığı yalnız çizer).
 */
class GlobeFrame {
    /** Kurulum girdisi; aynı girdi aynı kareyi verir. */
    data class Key(
        val lon0: Double, val lat0: Double, val zoom: Double, val w: Float, val h: Float, val r: Float,
        val kmin: Int, val clip: Boolean, val dotLevel: Int, val prevLevel: Int,
        /** Yönelimin kalan serbestliği (yuvarlanma) için matristen üç öğe; perspektif katsayısı; merkez ölçeği (dp/rad). */
        val m0: Float = 0f, val m1: Float = 0f, val m3: Float = 0f, val persp: Float = 0f, val scale: Float = r,
        /**
         * Noktalı doku tek parça: > 0 ise noktalar arka planda bu çözünürlükte (dp başına piksel) bir kapsama maskesine basılır
         * ([mask], [mask2]); yarıçaplar dp. 0: maske yok (eski yol: noktalar tek tek çizilir).
         */
        val px: Float = 0f, val dotR: Float = 0f, val dotR2: Float = 0f,
    )

    var key: Key? = null
    val m = FloatArray(9)
    var cx = 0f; var cy = 0f; var r = 0f
    val groupPath = Array(4) { GPath() }
    val landPath = GPath()
    val dots = GlobeHalftone.Buf()
    val dots2 = GlobeHalftone.Buf()
    var coastSeg = FloatArray(4096); var coastN = 0
    var borderSeg = FloatArray(4096); var borderN = 0
    var vertices = 0
    var projected = 0
    /** Kurulum süresi (ns). */
    var buildNs = 0L
    /** Noktalı dokunun maskesi ([Key.px] > 0 ise): [maskW] (4'ün katı) × [maskH] bayt; [mask2] eski düzey (geçiş). Her kurulumda [maskVer] artar. */
    var mask = ByteArray(0); var mask2 = ByteArray(0)
    var maskW = 0; var maskH = 0; var maskVer = 0
    var hasMask2 = false

    /** Kurucu: karelerden bağımsız geçici tamponlar (tek iş parçacığından kullanılır). */
    class Builder(private val map: GlobeLand.VecMap) {
        private val arcThr = IntArray(map.arcCount)
        private val needed = BooleanArray(map.arcCount)
        private val ringVis = BooleanArray(map.ringCount)
        private val projOff = IntArray(map.arcCount + 1)
        private var projX = FloatArray(16384); private var projY = FloatArray(16384); private var projZ = FloatArray(16384); private var projV = IntArray(16384)
        private var ring = FloatArray(4096)
        private var visCos = 0f; private var visSin = 1f

        /** [f]'yi [k] ve kamera matrisi [mat] için kurar. */
        fun build(f: GlobeFrame, k: Key, mat: FloatArray, cx: Float, cy: Float) {
            val t0 = System.nanoTime()
            System.arraycopy(mat, 0, f.m, 0, 9)
            f.cx = cx; f.cy = cy; f.r = k.r
            project(f, k)
            fills(f, k.clip)
            f.dots.clear(); f.dots2.clear()
            if (k.dotLevel >= 0) GlobeHalftone.generate(k.dotLevel, f.m, k.lat0, k.lon0, cx, cy, k.r, k.w, k.h, map, f.dots, persp = k.persp)
            if (k.prevLevel >= 0) GlobeHalftone.generate(k.prevLevel, f.m, k.lat0, k.lon0, cx, cy, k.r, k.w, k.h, map, f.dots2, persp = k.persp)
            strokes(f, k, GlobeLand.COAST)
            strokes(f, k, GlobeLand.BORDER)
            rasterize(f, k)
            f.key = k
            f.buildNs = System.nanoTime() - t0
        }

        /** Noktalar maskeye basılır (arka plan iş parçacığı): ekranda binlerce şekil yerine tek görüntü çizilir. */
        private fun rasterize(f: GlobeFrame, k: Key) {
            f.hasMask2 = false
            if (k.px <= 0f || k.dotLevel < 0) { f.maskW = 0; f.maskH = 0; return }
            val w = (((k.w * k.px).toInt() + 1 + 3) / 4) * 4
            val h = (k.h * k.px).toInt() + 1
            if (f.mask.size != w * h) f.mask = ByteArray(w * h)
            f.maskW = w; f.maskH = h
            GlobeRaster.dots(f.dots.a, f.dots.n, k.dotR, k.px, f.mask, w, h)
            if (k.prevLevel >= 0) {
                if (f.mask2.size != w * h) f.mask2 = ByteArray(w * h)
                GlobeRaster.dots(f.dots2.a, f.dots2.n, k.dotR2, k.px, f.mask2, w, h)
                f.hasMask2 = true
            }
            f.maskVer++
        }

        private fun capVisible(d: Float, cr: Float, sr: Float): Boolean = cr <= -0.999f || d > visCos * cr - visSin * sr

        /**
         * Görünür halkalar seçilir, onların yayları (ve görünür kıyı/sınır yayları) bir kez izdüşürülür. Görünen yaylar tam
         * ayrıntıda, ufkun ardındakiler kaba düzeyde (halkalar kapansın diye). Ufkun ardındaki köşeler ufuk çemberine bastırılır
         * (dolgu için); [projZ] ufka göre derinliği tutar (> 0 görünür; çizgiler için).
         */
        private fun project(f: GlobeFrame, k: Key) {
            val m = f.m; val r = k.r; val cx = f.cx; val cy = f.cy
            val n = map.arcCount
            val vx = m[6]; val vy = m[7]; val vz = m[8]
            // görünen başlık: ufuk (perspektifte açısal yarıçap acos(P)); küre ekrana hep tam sığar
            val pp = k.persp
            visCos = pp; visSin = sqrt(1f - pp * pp)
            for (a in 0 until n) {
                val vis = capVisible(map.capX[a] * vx + map.capY[a] * vy + map.capZ[a] * vz, map.capCos[a], map.capSin[a])
                arcThr[a] = if (vis) k.kmin else COARSE
                needed[a] = vis
            }
            for (q in 0 until map.ringCount) {
                val vis = capVisible(map.ringCapX[q] * vx + map.ringCapY[q] * vy + map.ringCapZ[q] * vz, map.ringCapCos[q], map.ringCapSin[q])
                ringVis[q] = vis
                if (vis) for (rr in map.refStart[q] until map.refStart[q + 1]) { val ref = map.refs[rr]; needed[if (ref >= 0) ref else ref.inv()] = true }
            }
            val xyz = map.xyz
            val m0 = m[0]; val m1 = m[1]; val m2 = m[2]; val m3 = m[3]; val m4 = m[4]; val m5 = m[5]; val m6 = m[6]; val m7 = m[7]; val m8 = m[8]
            val ks = sqrt(1f - pp * pp)
            var o = 0
            for (a in 0 until n) {
                projOff[a] = o
                if (!needed[a]) continue
                val L = arcThr[a]; val st = map.lvStart[L]; val vs = map.lvVerts[L]
                val from = st[a]; val to = st[a + 1]
                if (o + (to - from) > projX.size) { val cap = maxOf(projX.size * 2, o + (to - from)); projX = projX.copyOf(cap); projY = projY.copyOf(cap); projZ = projZ.copyOf(cap); projV = projV.copyOf(cap) }
                for (i in from until to) {
                    val v = vs[i]
                    val wx = xyz[3 * v]; val wy = xyz[3 * v + 1]; val wz = xyz[3 * v + 2]
                    var x = m0 * wx + m1 * wy + m2 * wz
                    var y = m3 * wx + m4 * wy + m5 * wz
                    val z = m6 * wx + m7 * wy + m8 * wz
                    // ufkun ardındaki köşeler ufuk dairesine bastırılır (dolgu kapansın); önündekiler perspektifle
                    if (z <= pp) { val l = sqrt(x * x + y * y).coerceAtLeast(1e-6f); x /= l; y /= l }
                    else { val sc = ks / (1f - pp * z); x *= sc; y *= sc }
                    projX[o] = cx + r * x; projY[o] = cy - r * y; projZ[o] = z - pp; projV[o] = v; o++
                }
            }
            projOff[n] = o
            f.projected = o
        }

        /** Görünür ülke halkalarından grup yolları (ve gerekirse kırpma için tüm kara yolu). */
        private fun fills(f: GlobeFrame, withLand: Boolean) {
            for (gp in f.groupPath) gp.reset()
            f.landPath.reset()
            var verts = 0
            for (c in 0 until map.countryCount) {
                val gp = f.groupPath[map.group[c] and 3]
                for (q in map.ringStart[c] until map.ringStart[c + 1]) {
                    if (!ringVis[q]) continue
                    var n = 0; var front = false
                    for (rr in map.refStart[q] until map.refStart[q + 1]) {
                        val ref = map.refs[rr]; val a = if (ref >= 0) ref else ref.inv()
                        val s = projOff[a]; val e = projOff[a + 1]
                        if (2 * (n + e - s) > ring.size) ring = ring.copyOf(maxOf(ring.size * 2, 2 * (n + e - s)))
                        if (ref >= 0) for (i in s until e) { ring[2 * n] = projX[i]; ring[2 * n + 1] = projY[i]; if (projZ[i] > 0f) front = true; n++ }
                        else for (i in e - 1 downTo s) { ring[2 * n] = projX[i]; ring[2 * n + 1] = projY[i]; if (projZ[i] > 0f) front = true; n++ }
                    }
                    if (!front || n < 3) continue
                    verts += n
                    gp.moveTo(ring[0], ring[1]); for (i in 1 until n) gp.lineTo(ring[2 * i], ring[2 * i + 1]); gp.close()
                    if (withLand) { val lp = f.landPath; lp.moveTo(ring[0], ring[1]); for (i in 1 until n) lp.lineTo(ring[2 * i], ring[2 * i + 1]); lp.close() }
                }
            }
            f.vertices = verts
        }

        /** Kıyı ya da sınır yaylarının görünen, ekranda kalan parçaları. */
        private fun strokes(f: GlobeFrame, k: Key, kind: Int) {
            var buf = if (kind == GlobeLand.COAST) f.coastSeg else f.borderSeg
            var n = 0
            val xyz = map.xyz
            val pad = 8f; val w = k.w; val h = k.h
            for (a in 0 until map.arcCount) {
                if (map.kind[a].toInt() != kind || arcThr[a] == COARSE || !needed[a]) continue
                val s = projOff[a]; val e = projOff[a + 1]
                var pSeam = false
                for (i in s until e) {
                    val v = projV[i]
                    // 180. boylam / Güney Kutbu kesimi boyunca uzanan parça gerçek kıyı değil: çizilmez
                    val seam = GlobeLand.isSeam(xyz[3 * v], xyz[3 * v + 1], xyz[3 * v + 2])
                    if (i > s && projZ[i] > 0f && projZ[i - 1] > 0f && !(seam && pSeam)) {
                        val x0 = projX[i - 1]; val y0 = projY[i - 1]; val x1 = projX[i]; val y1 = projY[i]
                        val off = (x0 < -pad && x1 < -pad) || (x0 > w + pad && x1 > w + pad) || (y0 < -pad && y1 < -pad) || (y0 > h + pad && y1 > h + pad)
                        if (!off) {
                            if (4 * n + 4 > buf.size) buf = buf.copyOf(buf.size * 2)
                            buf[4 * n] = x0; buf[4 * n + 1] = y0; buf[4 * n + 2] = x1; buf[4 * n + 3] = y1; n++
                        }
                    }
                    pSeam = seam
                }
            }
            if (kind == GlobeLand.COAST) { f.coastSeg = buf; f.coastN = n } else { f.borderSeg = buf; f.borderN = n }
        }
    }

    /**
     * Arka plan kurucusu: tek iş parçacığı, bir iş. [submit] meşgulken reddeder; biten kare [take] ile sahibince bir kez alınır.
     * Arayüz iş parçacığına çağrı yapmaz (bitti mi diye kare başında bakılır).
     */
    class Worker(map: GlobeLand.VecMap) {
        private val builder = Builder(map)
        private val lock = Object()
        private var job: Triple<GlobeFrame, Key, FloatArray>? = null
        private var jobOwner: Any? = null
        private var jobCx = 0f; private var jobCy = 0f
        private var done: GlobeFrame? = null
        private var doneOwner: Any? = null
        @Volatile var busy = false; private set

        init { Thread({ loop() }, "kure-kare").apply { isDaemon = true; start() } }

        /** [owner] için [f]'yi kurmaya başlar; meşgulse ya da sahibinin alınmamış karesi varsa false. Başka sahibin unutulmuş karesi atılır. */
        fun submit(owner: Any, f: GlobeFrame, k: Key, mat: FloatArray, cx: Float, cy: Float): Boolean {
            synchronized(lock) {
                if (busy) return false
                if (done != null) { if (doneOwner === owner) return false; done = null; doneOwner = null }
                job = Triple(f, k, mat.copyOf()); jobOwner = owner; jobCx = cx; jobCy = cy; busy = true
                lock.notifyAll()
            }
            return true
        }

        /** [owner]'ın biten karesi (yoksa null); bir kez döner. */
        fun take(owner: Any): GlobeFrame? = synchronized(lock) { if (doneOwner !== owner) null else { val d = done; done = null; doneOwner = null; d } }

        /** [owner] için iş sürüyor ya da alınmayı bekliyor mu. */
        fun pending(owner: Any): Boolean = synchronized(lock) { (busy && jobOwner === owner) || doneOwner === owner }

        private fun loop() {
            while (true) {
                val j: Triple<GlobeFrame, Key, FloatArray>; val o: Any?; val x: Float; val y: Float
                synchronized(lock) {
                    while (job == null) lock.wait()
                    j = job!!; o = jobOwner; x = jobCx; y = jobCy
                }
                try { builder.build(j.first, j.second, j.third, x, y) } catch (_: Throwable) { j.first.key = null }
                synchronized(lock) { job = null; jobOwner = null; done = j.first; doneOwner = o; busy = false }
            }
        }
    }

    companion object {
        /** Tüm küre sayfalarının paylaştığı tek arka plan kurucusu (uygulama boyunca bir iş parçacığı). */
        @Volatile private var shared: Worker? = null
        fun worker(map: GlobeLand.VecMap): Worker = shared ?: synchronized(this) { shared ?: Worker(map).also { shared = it } }

        /** Ufkun ardındaki yaylarda kullanılan kaba düzey (halkalar kapansın diye). */
        const val COARSE = 5
    }
}

/**
 * Noktaları kapsama maskesine basma (yumuşak kenarlı daireler; Android'in kenar yumuşatmalı nokta çizimiyle aynı görünüm).
 * Hız: her nokta için karekök hesaplamak yerine yarıçap başına 4×4 alt piksel konumu için önceden hesaplanmış "damga"lar
 * kullanılır (konum hatası ≤ 1/8 piksel, gözle ayırt edilmez); nokta başına yalnızca küçük bir dizi kopyalanır (en büyüğü alınır).
 */
object GlobeRaster {
    private const val SUB = 4
    private class Stamps(val r: Float, val k: Int, val a: Array<ByteArray>)
    @Volatile private var last: Stamps? = null

    /** Yarıçap [r] (piksel) için 16 damga; aynı yarıçapta yeniden kullanılır (değişmez nesne: iş parçacıkları arası güvenli). */
    private fun stampsFor(r: Float): Stamps {
        last?.let { if (it.r == r) return it }
        val reach = r + 0.5f
        val half = kotlin.math.ceil(reach).toInt()
        val k = 2 * half + 2
        val arr = Array(SUB * SUB) { ph ->
            val qx = ((ph % SUB) + 0.5f) / SUB; val qy = ((ph / SUB) + 0.5f) / SUB
            val cx = half + qx; val cy = half + qy
            ByteArray(k * k) { j ->
                val dx = (j % k) + 0.5f - cx; val dy = (j / k) + 0.5f - cy
                val d = kotlin.math.sqrt(dx * dx + dy * dy)
                ((reach - d).coerceIn(0f, 1f) * 255f).toInt().toByte()
            }
        }
        return Stamps(r, k, arr).also { last = it }
    }

    /** [xy] (dp) içindeki [n] noktayı, yarıçapı [rDp] (dp) daireler olarak [out] maskesine (genişlik [w], yükseklik [h], piksel = dp × [px]) basar. */
    fun dots(xy: FloatArray, n: Int, rDp: Float, px: Float, out: ByteArray, w: Int, h: Int) {
        java.util.Arrays.fill(out, 0, w * h, 0)
        val r = rDp * px
        if (r <= 0f || n <= 0) return
        val sp = stampsFor(r); val st = sp.a; val k = sp.k
        val half = kotlin.math.ceil(r + 0.5f).toInt()
        for (i in 0 until n) {
            val cx = xy[2 * i] * px; val cy = xy[2 * i + 1] * px
            val fx = kotlin.math.floor(cx); val fy = kotlin.math.floor(cy)
            val ox = fx.toInt() - half; val oy = fy.toInt() - half
            if (ox >= w || oy >= h || ox + k <= 0 || oy + k <= 0) continue
            val ph = minOf(SUB - 1, ((cy - fy) * SUB).toInt()) * SUB + minOf(SUB - 1, ((cx - fx) * SUB).toInt())
            val s = st[ph]
            val j0 = maxOf(0, -oy); val j1 = minOf(k, h - oy)
            val i0 = maxOf(0, -ox); val i1 = minOf(k, w - ox)
            for (j in j0 until j1) {
                var o = (oy + j) * w + ox + i0
                var q = j * k + i0
                for (ii in i0 until i1) {
                    val c = s[q].toInt() and 0xFF
                    if (c != 0 && c > (out[o].toInt() and 0xFF)) out[o] = c.toByte()
                    o++; q++
                }
            }
        }
    }
}
