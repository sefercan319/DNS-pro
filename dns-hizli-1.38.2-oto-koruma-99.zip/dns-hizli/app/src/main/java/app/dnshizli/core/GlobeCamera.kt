package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Küre kamerası. Saf matematik: arayüzden bağımsız sınanır.
 *  - Yönelim serbest bir dönme matrisidir ([matrix]: dünya → görünüm): küre her yöne, kutupların üstünden de döndürülebilir.
 *    [lon0]/[lat0] ekran merkezindeki noktadır (türetilmiş).
 *  - İzdüşüm yakın taraf perspektifidir (uydu görünümü): küre ekranda hep aynı yarıçaplı tam bir daire olarak kalır;
 *    yakınlaştırma ([zoom] 1..[MAX_ZOOM]) kamerayı yüzeye yaklaştırır, merkez [zoom] kat büyür, kenara doğru küre eğriliğiyle
 *    sıkışır, ufuk daralır — küre düz haritaya dönmez. zoom = 1'de dik izdüşüm.
 *  - Sürükleme küreyi parmakla birlikte döndürür (iz topu); bırakınca atalet sürer (parmak durup kalkarsa savrulmaz).
 *  - Yakınlaştırma parmakların altındaki noktayı yerinde tutar; çift dokunma ve seçim yumuşak uçuşla ([flyTo]) gelir.
 *  - Boşta yavaşça kendiliğinden döner (hareket açıksa).
 */
class GlobeCamera(lon0: Double = Math.toRadians(30.0), lat0: Double = Math.toRadians(30.0), var zoom: Double = 1.0) {
    /** Dünya → görünüm dönmesi (satır düzeninde 3×3). */
    private val rot = DoubleArray(9)
    private var wX = 0.0                 // atalet: görünüm X ekseni etrafında (rad/sn)
    private var wY = 0.0                 // görünüm Y ekseni etrafında
    private var idle = 0.0
    /** Yumuşak yakınlaştırmanın hedefi (çift dokunma, uçuş); iki parmak doğrudan [zoom]'u değiştirir. */
    var zoomTarget = zoom; private set
    private var fly: DoubleArray? = null  // uçuş hedefi (dönme matrisi)
    private var fvX = 0.0; private var fvY = 0.0; private var fvZ = 0.0
    /** İki parmak sürüyor mu; yakınlaştırma hızı (ln zoom / sn) bırakınca süzülme için. */
    var pinching = false; private set
    private var vZoom = 0.0
    var dragging = false; private set
    // tekrar kullanılan geçici diziler (kare başına bellek ayırma yok)
    private val tmpR = DoubleArray(9); private val tmpM = DoubleArray(9); private val tmpE = DoubleArray(3)

    init { northUp(lat0, lon0, rot) }

    /** Ekran merkezindeki noktanın boylamı / enlemi (radyan). */
    val lon0: Double get() = atan2(rot[7], rot[6])
    val lat0: Double get() = asin(rot[8].coerceIn(-1.0, 1.0))

    /** Perspektif katsayısı P = 1/D (D: kamera uzaklığı, küre yarıçapı biriminde); 0 = dik izdüşüm. Görünür: z > P. */
    val persp: Double get() = perspOf(zoom)

    /** İzdüşüm sonucu: ekran x, y (merkezli; ufuk dairesi yarıçapı 1) ve derinlik z (ufukta 0, merkezde 1; > 0 görünür). */
    class P { var x = 0.0; var y = 0.0; var z = 0.0 }

    fun project(lat: Double, lon: Double, out: P): P = projectSc(sin(lat), cos(lat), lon, out)

    fun projectSc(sinLat: Double, cosLat: Double, lon: Double, out: P): P {
        val wx = cosLat * cos(lon); val wy = cosLat * sin(lon); val wz = sinLat
        val x = rot[0] * wx + rot[1] * wy + rot[2] * wz
        val y = rot[3] * wx + rot[4] * wy + rot[5] * wz
        val z = rot[6] * wx + rot[7] * wy + rot[8] * wz
        val p = persp
        val s = sqrt(1 - p * p) / (1 - p * z)
        out.x = x * s; out.y = y * s; out.z = (z - p) / (1 - p)
        return out
    }

    /** Görünüm dönmesi (dünya → görünüm) [m]'ye yazılır; izdüşüm: s = √(1−P²)/(1−P·z), ekran = (x·s, y·s), görünür z > P. */
    fun matrix(m: FloatArray) { for (i in 0 until 9) m[i] = rot[i].toFloat() }

    /** Ekran noktası (merkezli, ufuk yarıçapı 1; y yukarı) kürenin görünen yüzündeyse enlem/boylamı (radyan) [out]'a yazar. */
    fun unproject(x: Double, y: Double, out: DoubleArray): Boolean {
        val p = persp
        val vx: Double; val vy: Double; val vz: Double
        if (p < 1e-9) {
            val q = x * x + y * y
            if (q >= 1.0) return false
            vx = x; vy = y; vz = sqrt(1 - q)
        } else {
            // kamera (0, 0, D)'den ışın: yön (x/F, y/F, −1), F = √(D²−1)
            val d = 1 / p; val f = sqrt(d * d - 1)
            val a = x / f; val b = y / f
            val k = a * a + b * b + 1
            val disc = d * d - k * (d * d - 1)
            if (disc < 0) return false
            val t = (d - sqrt(disc)) / k
            vx = t * a; vy = t * b; vz = d - t
        }
        // dünya = rotᵀ · görünüm
        val wx = rot[0] * vx + rot[3] * vy + rot[6] * vz
        val wy = rot[1] * vx + rot[4] * vy + rot[7] * vz
        val wz = rot[2] * vx + rot[5] * vy + rot[8] * vz
        out[0] = asin(wz.coerceIn(-1.0, 1.0)); out[1] = atan2(wy, wx)
        return true
    }

    // Savurma hızı için son sürükleme örnekleri: (zaman, toplam açı X, toplam açı Y); halka. Tek olayın hızı titrek, pencere düzgün.
    private val sT = DoubleArray(SAMPLES); private val sX = DoubleArray(SAMPLES); private val sY = DoubleArray(SAMPLES)
    private var sN = 0; private var sClock = 0.0; private var cumX = 0.0; private var cumY = 0.0

    fun beginDrag() { dragging = true; wX = 0.0; wY = 0.0; idle = 0.0; fly = null; sN = 0; sClock = 0.0; cumX = 0.0; cumY = 0.0; sample() }

    private fun sample() { val i = sN % SAMPLES; sT[i] = sClock; sX[i] = cumX; sY[i] = cumY; sN++ }

    /**
     * Bırakma anındaki açısal hız: son [VEL_WINDOW] sn'deki toplam dönme / geçen süre (en eski örnekten bugüne). Tek bir kısa ya da
     * gecikmiş dokunma olayı hızı sıçratmaz; parmağın gerçek ortalama hızı savrulur.
     */
    private fun releaseVelocity(): Boolean {
        val n = minOf(sN, SAMPLES)
        if (n < 2) return false
        val last = (sN - 1) % SAMPLES
        var first = last
        for (k in 1 until n) {
            val i = ((sN - 1 - k) % SAMPLES + SAMPLES) % SAMPLES
            if (sT[last] - sT[i] > VEL_WINDOW) break
            first = i
        }
        val span = sT[last] - sT[first]
        if (span < 0.012) return false
        wX = (sX[last] - sX[first]) / span; wY = (sY[last] - sY[first]) / span
        return true
    }

    /** Ekran pikseli (dp) cinsinden sürükleme; [r] merkezdeki ölçek (dp/radyan). [dtSec] hız tahmini için. */
    fun dragBy(dx: Double, dy: Double, r: Double, dtSec: Double) {
        val ay = dx / r; val ax = dy / r
        rotateView(ax, ay, 0.0)
        cumX += ax; cumY += ay
        if (dtSec > 0.0) { sClock += dtSec; sample() }
        if (dtSec > 0.0) {
            // Kısa aralıklar hızı abartmasın: ağırlık aralıkla orantılı (60 Hz'de ~0.35)
            val k = (dtSec / 0.045).coerceIn(0.15, 0.8)
            wX = (1 - k) * wX + k * (ax / dtSec); wY = (1 - k) * wY + k * (ay / dtSec)
        }
    }

    /** [heldSec]: son hareketten bırakmaya kadar geçen süre; parmak durup kalktıysa atalet yok. */
    fun endDrag(heldSec: Double = 0.0) {
        dragging = false; idle = 0.0
        if (pinching) {
            pinching = false
            // Bırakınca kısa süzülme (parmaklar durmadıysa), sonra sınırların içine yay gibi döner.
            // Süzülme mesafesi = hız / yumuşatma oranı: bırakma anında yakınlaşma hızı kesintisiz devam eder (sarsıntı yok).
            val glide = if (heldSec <= STILL_SEC) vZoom.coerceIn(-6.0, 6.0) / ZOOM_RATE else 0.0
            zoomTarget = (zoom * exp(glide)).coerceIn(1.0, MAX_ZOOM); vZoom = 0.0
        }
        if (heldSec > STILL_SEC) { wX = 0.0; wY = 0.0 } else releaseVelocity()
        val sp = sqrt(wX * wX + wY * wY)
        if (sp > MAX_SPEED) { wX *= MAX_SPEED / sp; wY *= MAX_SPEED / sp }
    }

    fun zoomBy(f: Double) { zoom = (zoom * f).coerceIn(1.0, MAX_ZOOM); zoomTarget = zoom; idle = 0.0 }

    /**
     * İki parmak: [f] kat yakınlaştırır, parmakların ortası ([ux], [uy]: merkezden dp, y aşağı) altındaki nokta yerinde kalır.
     * [r1]: ekrandaki küre (ufuk) yarıçapı (dp).
     */
    fun zoomAt(f: Double, ux: Double, uy: Double, r1: Double, dtSec: Double = 0.0) {
        val ll = DoubleArray(2)
        val hit = unproject(ux / r1, -uy / r1, ll)
        pinching = true; idle = 0.0
        // Sınır dışında lastik: aşan kısım dirençle büyür (bırakınca geri döner).
        val lo = 0.0; val hi = ln(MAX_ZOOM)
        var lz = ln(zoom); val step = ln(f)
        val outside = (lz >= hi && step > 0) || (lz <= lo && step < 0)
        lz += if (outside) step * 0.3 else step
        zoom = exp(lz.coerceIn(lo - OVER_ZOOM, hi + OVER_ZOOM)); zoomTarget = zoom
        if (dtSec > 0) vZoom = 0.6 * vZoom + 0.4 * (step / dtSec)
        fly = null
        if (hit) keepUnder(ll[0], ll[1], ux / r1, -uy / r1)
    }

    /** [lat]/[lon]'u ekranda ([tx], [ty]; ufuk yarıçapı 1) konumuna getirecek şekilde küreyi küçük adımlarla döndürür. */
    private fun keepUnder(lat: Double, lon: Double, tx: Double, ty: Double) {
        val p = P()
        repeat(10) {
            project(lat, lon, p)
            val ex = tx - p.x; val ey = ty - p.y
            if (abs(ex) < 1e-6 && abs(ey) < 1e-6) return
            // merkezdeki ölçek ≈ zoom (ufuk yarıçapı birimi): ekran farkı → açı
            val sc = maxOf(zoom, 1.0)
            rotateView(-ey / sc, ex / sc, 0.0)
        }
    }

    /** Çift dokunma: 1 → 2 → 4 → 1 (yumuşak geçiş; hedef [zoomTarget]). */
    fun zoomStep() { zoomTarget = when { zoomTarget < 1.9 -> 2.0; zoomTarget < 3.9 -> 4.0; else -> 1.0 }; idle = 0.0 }

    /** Çift dokunma bir noktaya: o noktaya uçar ve bir kademe yakınlaşır. */
    fun zoomStepAt(lat: Double, lon: Double) { zoomStep(); if (zoomTarget > 1.0) flyTo(lat, lon) }

    /** [lat]/[lon]'u kuzey yukarıda merkeze getirir (anında). */
    fun focus(lat: Double, lon: Double) { northUp(lat, lon, rot); wX = 0.0; wY = 0.0; idle = 0.0; fly = null }

    /**
     * [lat]/[lon]'u kuzey yukarıda merkeze yumuşakça getirir (en kısa dönmeyle). Savrulan kürenin hızı uçuşa devredilir:
     * hedefe doğru kıvrılır, sıçramaz.
     */
    fun flyTo(lat: Double, lon: Double) {
        if (fly == null) { fvX = wX; fvY = wY; fvZ = 0.0 }
        fly = DoubleArray(9).also { northUp(lat, lon, it) }; wX = 0.0; wY = 0.0; idle = 0.0
    }

    val flying: Boolean get() = fly != null

    /** Atalet, uçuş, yumuşak yakınlaştırma ve boşta dönme. Kullanıcı kaynaklı hareket sürüyorsa true (boşta dönme hariç). */
    fun tick(dt: Double, autoSpin: Boolean): Boolean {
        if (dragging) return true
        var moving = false
        if (abs(zoom - zoomTarget) > 1e-3) {
            // Logaritmik ölçekte yumuşatma: her kat (1→2, 6→12) aynı sürede geçilir; doğrusal ölçekte büyük yakınlıkta
            // başta fırlayıp sonda sürünürdü.
            val lt = ln(zoomTarget)
            zoom = exp(lt + (ln(zoom) - lt) * exp(-dt * ZOOM_RATE))
            moving = true; idle = 0.0
        } else zoom = zoomTarget
        val target = fly
        if (target != null) {
            // kritik sönümlü yay (dönme vektörü uzayında): yumuşak kalkış ve iniş, aşma yok; büyük adımlar alt adımlara bölünür
            var left = dt
            val e = tmpE
            while (left > 0 && fly != null) {
                val h = minOf(left, 1.0 / 120); left -= h
                errorTo(target, e)
                fvX += (FLY_W * FLY_W * e[0] - 2 * FLY_W * fvX) * h
                fvY += (FLY_W * FLY_W * e[1] - 2 * FLY_W * fvY) * h
                fvZ += (FLY_W * FLY_W * e[2] - 2 * FLY_W * fvZ) * h
                rotateView(fvX * h, fvY * h, fvZ * h)
                if (abs(e[0]) + abs(e[1]) + abs(e[2]) < 1e-5 && abs(fvX) + abs(fvY) + abs(fvZ) < 1e-3) { System.arraycopy(target, 0, rot, 0, 9); fly = null; fvX = 0.0; fvY = 0.0; fvZ = 0.0 }
            }
            moving = true; idle = 0.0
        } else if (abs(wX) > 1e-3 || abs(wY) > 1e-3) {
            rotateView(wX * dt, wY * dt, 0.0)
            val k = exp(-dt * FRICTION); wX *= k; wY *= k
            moving = true; idle = 0.0
        } else { wX = 0.0; wY = 0.0; idle += dt }
        if (autoSpin && idle > IDLE_SPIN_AFTER && zoom < 1.5) {
            // dönmeye yumuşak başla (ani sıçrama yok); kuzey–güney ekseni etrafında
            val ramp = ((idle - IDLE_SPIN_AFTER) / 1.5).coerceIn(0.0, 1.0)
            spinWorld(SPIN * ramp * dt)          // süs animasyonu: "hareket" sayılmaz (sahne 30 fps süs kipinde çizer, 60 fps istemez)
        }
        return moving
    }

    /** Görünür noktalardan ekran konumu (merkez cx, cy; ufuk yarıçapı r) [x],[y]'ye en yakın olanın sırası; [maxDist] içinde yoksa -1. */
    fun pick(x: Double, y: Double, cx: Double, cy: Double, r: Double, lats: DoubleArray, lons: DoubleArray, maxDist: Double): Int {
        val p = P(); var best = -1; var bd = maxDist * maxDist
        for (i in lats.indices) {
            project(Math.toRadians(lats[i]), Math.toRadians(lons[i]), p)
            if (p.z <= 0.05) continue
            val dx = cx + r * p.x - x; val dy = cy - r * p.y - y
            val d = dx * dx + dy * dy
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    // ------------------------------------------------------------------ dönme yardımcıları

    /** Görünüm eksenleri etrafında küçük dönme (dönme vektörü (ax, ay, az), radyan): rot ← R(v) · rot. */
    private fun rotateView(ax: Double, ay: Double, az: Double) {
        rodrigues(ax, ay, az, tmpR)
        mul(tmpR, rot, tmpM, rot)
        orthonormalize(rot)
    }

    /** Dünya kuzey–güney ekseni etrafında dönme: rot ← rot · Rz(a) (merkez boylamı a kadar batıya kayar). */
    private fun spinWorld(a: Double) {
        val c = cos(a); val s = sin(a)
        for (row in 0 until 3) {
            val x = rot[3 * row]; val y = rot[3 * row + 1]
            rot[3 * row] = x * c + y * s; rot[3 * row + 1] = -x * s + y * c
        }
    }

    /** Hedef yönelime göre hata (görünüm uzayında dönme vektörü): R_hedef · rotᵀ'nin eksen-açısı. */
    private fun errorTo(t: DoubleArray, out: DoubleArray) {
        val m = tmpM
        for (i in 0 until 3) for (j in 0 until 3) { var s = 0.0; for (k in 0 until 3) s += t[3 * i + k] * rot[3 * j + k]; m[3 * i + j] = s }
        val tr = (m[0] + m[4] + m[8] - 1) / 2
        val ang = kotlin.math.acos(tr.coerceIn(-1.0, 1.0))
        var x = m[7] - m[5]; var y = m[2] - m[6]; var z = m[3] - m[1]
        val l = sqrt(x * x + y * y + z * z)
        if (ang < 1e-9) { out[0] = 0.0; out[1] = 0.0; out[2] = 0.0; return }
        if (l < 1e-9) {
            // ~180°: eksen köşegenden
            x = sqrt(((m[0] + 1) / 2).coerceAtLeast(0.0)); y = sqrt(((m[4] + 1) / 2).coerceAtLeast(0.0)); z = sqrt(((m[8] + 1) / 2).coerceAtLeast(0.0))
            out[0] = x * ang; out[1] = y * ang; out[2] = z * ang; return
        }
        out[0] = x / l * ang; out[1] = y / l * ang; out[2] = z / l * ang
    }

    companion object {
        const val MAX_ZOOM = 12.0
        /** Yakınlaştırma lastiğinin en çok aşımı (ln zoom). */
        const val OVER_ZOOM = 0.3
        const val FLY_W = 7.0
        const val SPIN = 0.06                // rad/sn
        const val IDLE_SPIN_AFTER = 4.0      // sn
        const val FRICTION = 2.6             // atalet sönümü (1/sn)
        const val MAX_SPEED = 9.0            // rad/sn: sert savurmada küre fırıl fırıl dönmesin
        const val STILL_SEC = 0.08           // bu kadar durup kaldırılan parmak savurmaz
        const val ZOOM_RATE = 9.0
        /** Savurma hızı penceresi (sn) ve örnek halkası. */
        const val VEL_WINDOW = 0.1
        const val SAMPLES = 16

        /**
         * Yakınlaştırmadan perspektif: merkez büyütmesi Z = √((D+1)/(D−1)) olacak kamera uzaklığı D = (Z²+1)/(Z²−1);
         * P = 1/D = (Z²−1)/(Z²+1). Z = 1 → P = 0 (dik); Z = 12 → ufuk yarıçapı ~9,5°.
         */
        fun perspOf(zoom: Double): Double { val z2 = zoom * zoom; return ((z2 - 1) / (z2 + 1)).coerceIn(0.0, 0.999) }

        fun wrap(a: Double): Double { var v = a % (2 * PI); if (v > PI) v -= 2 * PI; if (v < -PI) v += 2 * PI; return v }

        /** Kuzey yukarıda, (lat, lon) merkezde yönelim. */
        fun northUp(lat: Double, lon: Double, m: DoubleArray) {
            val sl = sin(lon); val cl = cos(lon); val s0 = sin(lat); val c0 = cos(lat)
            m[0] = -sl; m[1] = cl; m[2] = 0.0
            m[3] = -s0 * cl; m[4] = -s0 * sl; m[5] = c0
            m[6] = c0 * cl; m[7] = c0 * sl; m[8] = s0
        }

        private fun rodrigues(ax: Double, ay: Double, az: Double, r: DoubleArray) {
            val th = sqrt(ax * ax + ay * ay + az * az)
            if (th < 1e-15) { r.fill(0.0); r[0] = 1.0; r[4] = 1.0; r[8] = 1.0; return }
            val x = ax / th; val y = ay / th; val z = az / th
            val c = cos(th); val s = sin(th); val t = 1 - c
            r[0] = t * x * x + c; r[1] = t * x * y - s * z; r[2] = t * x * z + s * y
            r[3] = t * x * y + s * z; r[4] = t * y * y + c; r[5] = t * y * z - s * x
            r[6] = t * x * z - s * y; r[7] = t * y * z + s * x; r[8] = t * z * z + c
        }

        /** out = a · b ([tmp] ara bellek; [out] [b] ile aynı olabilir). */
        private fun mul(a: DoubleArray, b: DoubleArray, tmp: DoubleArray, out: DoubleArray) {
            for (i in 0 until 3) for (j in 0 until 3) tmp[3 * i + j] = a[3 * i] * b[j] + a[3 * i + 1] * b[3 + j] + a[3 * i + 2] * b[6 + j]
            System.arraycopy(tmp, 0, out, 0, 9)
        }

        /** Sayısal kaymayı önlemek için satırları dikleştirir (Gram–Schmidt). */
        private fun orthonormalize(m: DoubleArray) {
            fun n(i: Int) { val l = sqrt(m[3 * i] * m[3 * i] + m[3 * i + 1] * m[3 * i + 1] + m[3 * i + 2] * m[3 * i + 2]); m[3 * i] /= l; m[3 * i + 1] /= l; m[3 * i + 2] /= l }
            n(2)
            val d = m[3] * m[6] + m[4] * m[7] + m[5] * m[8]
            m[3] -= d * m[6]; m[4] -= d * m[7]; m[5] -= d * m[8]; n(1)
            // satır 0 = satır 1 × satır 2
            m[0] = m[4] * m[8] - m[5] * m[7]; m[1] = m[5] * m[6] - m[3] * m[8]; m[2] = m[3] * m[7] - m[4] * m[6]
        }
    }
}
