package app.dnshizli.platform

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import app.dnshizli.core.ALIGN_CENTER
import app.dnshizli.core.ALIGN_RIGHT
import app.dnshizli.core.Fill
import app.dnshizli.core.GPath
import app.dnshizli.core.Gfx
import app.dnshizli.core.PathSink
import app.dnshizli.core.Pic
import app.dnshizli.core.TextMetrics

/** Yazı tipleri. Sistemin kendi sans-serif ailesi kullanılır: ek yazı tipi dosyası yok, bellek yükü yok. */
internal object Fonts {
    val regular: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)

    /** Kalın yazı: 28+ sürümlerde yarı kalın (600), eskilerde "medium". */
    val bold: Typeface =
        if (Build.VERSION.SDK_INT >= 28) Typeface.create(regular, 600, false)
        else Typeface.create("sans-serif-medium", Typeface.NORMAL)

    fun face(bold: Boolean): Typeface = if (bold) this.bold else regular
}

/**
 * Yazı ölçümü (dp birimi). Sahne yerleşimi bunu kullanır, [AndroidGfx] de aynı yazı tipi ve ayarlarla çizer;
 * böylece ölçülen genişlik ile çizilen genişlik aynıdır. Doğrusal (doğrusal-metrik) yazı açık: ölçü, çizim
 * ölçeğinden (yoğunluk) bağımsız kalır.
 */
class PaintMetrics : TextMetrics {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG or Paint.LINEAR_TEXT_FLAG)

    override fun textWidth(s: String, size: Float, bold: Boolean): Float {
        if (s.isEmpty()) return 0f
        paint.typeface = Fonts.face(bold)
        paint.textSize = size
        return paint.measureText(s)
    }
}

/**
 * [Gfx] arayüzünün Android Canvas karşılığı. Koordinatlar dp'dir: [begin] tuvale yoğunluk ölçeğini uygular.
 *
 * Kare başına bellek ayırmaz: Paint, Path ve gradyan nesneleri bir kez üretilip önbelleğe alınır
 * ([Fill.native], [GPath.native]); saydamlık yığını ve boya durumu alanlarda tutulur.
 */
class AndroidGfx(private val metrics: PaintMetrics) : Gfx {
    private var canvas: Canvas? = null
    private var base = 0

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG or Paint.LINEAR_TEXT_FLAG)
    private val scratch = Path()
    private val pathBuilder = PathBuilder()

    private var color = 0
    private var px = 1f
    private var shader: Shader? = null

    private var alpha = 1f
    private var alphaStack = FloatArray(32)
    private var depth = 0

    /** Bir kare çizmeye başla. [density]: dp başına piksel. */
    fun begin(c: Canvas, density: Float) {
        canvas = c
        px = density
        base = c.save()
        c.scale(density, density)
        alpha = 1f
        depth = 0
        color = 0
        shader = null
    }

    fun end() {
        canvas?.restoreToCount(base)
        canvas = null
    }

    // ------------------------------------------------------------------ durum

    override fun save() {
        val c = canvas ?: return
        if (depth == alphaStack.size) alphaStack = alphaStack.copyOf(depth * 2)
        alphaStack[depth++] = alpha
        c.save()
    }

    override fun restore() {
        val c = canvas ?: return
        if (depth == 0) return
        alpha = alphaStack[--depth]
        c.restore()
    }

    override fun translate(dx: Float, dy: Float) { canvas?.translate(dx, dy) }
    override fun scale(sx: Float, sy: Float) { canvas?.scale(sx, sy) }
    override fun rotate(deg: Float) { canvas?.rotate(deg) }
    override fun alpha(a: Float) { alpha *= a.coerceIn(0f, 1f) }

    override fun clipRect(l: Float, t: Float, r: Float, b: Float) { canvas?.clipRect(l, t, r, b) }

    override fun clipRoundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) {
        val c = canvas ?: return
        val k = rad.coerceIn(0f, minOf((r - l) / 2f, (b - t) / 2f).coerceAtLeast(0f))
        scratch.rewind()
        scratch.addRoundRect(l, t, r, b, k, k, Path.Direction.CW)
        c.clipPath(scratch)
    }

    override fun clipCircle(cx: Float, cy: Float, r: Float) {
        val c = canvas ?: return
        scratch.rewind()
        scratch.addCircle(cx, cy, maxOf(r, 0f), Path.Direction.CW)
        c.clipPath(scratch)
    }

    override fun clipPath(p: GPath) {
        val c = canvas ?: return
        if (!p.isEmpty) c.clipPath(nativePath(p))
    }

    // ------------------------------------------------------------------ görüntü

    private val imgPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val imgSrc = Rect()
    private val imgDst = RectF()

    override fun image(p: Pic, sl: Float, st: Float, sr: Float, sb: Float, dl: Float, dt: Float, dr: Float, db: Float) {
        val c = canvas ?: return
        val bmp = p.handle as? Bitmap ?: return
        if (bmp.isRecycled) return
        imgSrc.set(sl.toInt().coerceIn(0, bmp.width - 1), st.toInt().coerceIn(0, bmp.height - 1),
            Math.ceil(sr.toDouble()).toInt().coerceIn(1, bmp.width), Math.ceil(sb.toDouble()).toInt().coerceIn(1, bmp.height))
        imgDst.set(dl, dt, dr, db)
        imgPaint.alpha = (alpha * 255f + 0.5f).toInt().coerceIn(0, 255)
        c.drawBitmap(bmp, imgSrc, imgDst, imgPaint)
    }

    // ------------------------------------------------------------------ boya

    override fun paint(color: Int) {
        this.color = color
        this.shader = null
    }

    override fun paint(fill: Fill) {
        var sh = fill.native as? Shader
        if (sh == null) {
            sh = makeShader(fill)
            fill.native = sh
        }
        if (sh == null) {
            // Geçersiz gradyan (ör. yarıçap 0): ilk renkle düz boya (JVM önizlemesiyle aynı kural).
            this.color = when (fill) {
                is Fill.Linear -> fill.colors[0]
                is Fill.Radial -> fill.colors[0]
            }
            this.shader = null
        } else {
            this.shader = sh
        }
    }

    private fun makeShader(f: Fill): Shader? = when (f) {
        is Fill.Linear ->
            if (f.x0 == f.x1 && f.y0 == f.y1) null
            else LinearGradient(f.x0, f.y0, f.x1, f.y1, f.colors, f.stops, Shader.TileMode.CLAMP)
        is Fill.Radial ->
            if (f.r <= 0f) null
            else RadialGradient(f.cx, f.cy, f.r, f.colors, f.stops, Shader.TileMode.CLAMP)
    }

    override fun strokeWidth(w: Float) { strokePaint.strokeWidth = w }

    /** Geçerli boyayı ve toplam saydamlığı [p]'ye uygular. @return çizilecek bir şey yoksa false. */
    private fun apply(p: Paint): Boolean {
        val sh = shader
        p.shader = sh
        val a: Int
        if (sh != null) {
            p.color = Color.WHITE
            a = (alpha * 255f + 0.5f).toInt()
        } else {
            p.color = color
            a = (((color ushr 24) and 0xFF) * alpha + 0.5f).toInt()
        }
        if (a <= 0) return false
        p.alpha = a.coerceAtMost(255)
        return true
    }

    // ------------------------------------------------------------------ şekiller

    override fun rect(l: Float, t: Float, r: Float, b: Float) {
        val c = canvas ?: return
        if (apply(fillPaint)) c.drawRect(l, t, r, b, fillPaint)
    }

    override fun roundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) {
        val c = canvas ?: return
        val k = rad.coerceIn(0f, minOf((r - l) / 2f, (b - t) / 2f).coerceAtLeast(0f))
        if (apply(fillPaint)) c.drawRoundRect(l, t, r, b, k, k, fillPaint)
    }

    override fun circle(cx: Float, cy: Float, r: Float) {
        val c = canvas ?: return
        if (r > 0f && apply(fillPaint)) c.drawCircle(cx, cy, r, fillPaint)
    }

    override fun oval(l: Float, t: Float, r: Float, b: Float) {
        val c = canvas ?: return
        if (apply(fillPaint)) c.drawOval(l, t, r, b, fillPaint)
    }

    override fun path(p: GPath) {
        val c = canvas ?: return
        if (!p.isEmpty && apply(fillPaint)) c.drawPath(nativePath(p), fillPaint)
    }

    override fun strokeRoundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) {
        val c = canvas ?: return
        val k = rad.coerceIn(0f, minOf((r - l) / 2f, (b - t) / 2f).coerceAtLeast(0f))
        if (apply(strokePaint)) c.drawRoundRect(l, t, r, b, k, k, strokePaint)
    }

    override fun strokeCircle(cx: Float, cy: Float, r: Float) {
        val c = canvas ?: return
        if (r > 0f && apply(strokePaint)) c.drawCircle(cx, cy, r, strokePaint)
    }

    override fun strokePath(p: GPath) {
        val c = canvas ?: return
        if (!p.isEmpty && apply(strokePaint)) c.drawPath(nativePath(p), strokePaint)
    }

    override fun line(x0: Float, y0: Float, x1: Float, y1: Float) {
        val c = canvas ?: return
        if (apply(strokePaint)) c.drawLine(x0, y0, x1, y1, strokePaint)
    }

    override fun makePic(argb: IntArray, w: Int, h: Int): app.dnshizli.core.Pic? {
        val bmp = Bitmap.createBitmap(argb, w, h, Bitmap.Config.ARGB_8888)
        return app.dnshizli.core.Pic(w, h, bmp, 0f, 1f) { if (!bmp.isRecycled) bmp.recycle() }
    }

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    // ------------------------------------------------------------------ maske (tek görüntü)

    private val maskPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val maskDst = RectF()
    override val canMask: Boolean get() = true
    override val pixelScale: Float get() = px

    override fun makeMask(w: Int, h: Int): app.dnshizli.core.Pic? {
        if (w <= 0 || h <= 0) return null
        val bmp = try { Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8) } catch (_: Throwable) { return null }
        return app.dnshizli.core.Pic(w, h, bmp, 0f, 1f) { if (!bmp.isRecycled) bmp.recycle() }
    }

    override fun updateMask(p: app.dnshizli.core.Pic, a: ByteArray) {
        val bmp = p.handle as? Bitmap ?: return
        if (bmp.isRecycled || a.size < bmp.rowBytes * bmp.height) return
        bmp.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(a, 0, bmp.rowBytes * bmp.height))
    }

    override fun mask(p: app.dnshizli.core.Pic, l: Float, t: Float, r: Float, b: Float) {
        val c = canvas ?: return
        val bmp = p.handle as? Bitmap ?: return
        if (bmp.isRecycled || !apply(maskPaint)) return          // ALPHA_8 görüntü boyanın rengiyle çizilir
        maskDst.set(l, t, r, b)
        c.drawBitmap(bmp, null, maskDst, maskPaint)
    }

    override fun dots(xy: FloatArray, n: Int, r: Float, square: Boolean) {
        val c = canvas ?: return
        if (n <= 0 || r <= 0f || !apply(dotPaint)) return
        dotPaint.strokeWidth = 2f * r
        dotPaint.strokeCap = if (square) Paint.Cap.SQUARE else Paint.Cap.ROUND
        c.drawPoints(xy, 0, 2 * n, dotPaint)
    }

    override fun lines(xy: FloatArray, n: Int) {
        val c = canvas ?: return
        if (n > 0 && apply(strokePaint)) c.drawLines(xy, 0, 4 * n, strokePaint)
    }

    // ------------------------------------------------------------------ yazı

    override fun text(s: String, x: Float, baseline: Float, size: Float, bold: Boolean, align: Int) {
        val c = canvas ?: return
        if (s.isEmpty()) return
        val p = textPaint
        p.typeface = Fonts.face(bold)
        p.textSize = size
        p.textAlign = when (align) {
            ALIGN_CENTER -> Paint.Align.CENTER
            ALIGN_RIGHT -> Paint.Align.RIGHT
            else -> Paint.Align.LEFT
        }
        if (apply(p)) c.drawText(s, x, baseline, p)
    }

    override fun textWidth(s: String, size: Float, bold: Boolean): Float = metrics.textWidth(s, size, bold)

    // ------------------------------------------------------------------ yol önbelleği

    private fun nativePath(g: GPath): Path {
        var p = g.native as? Path
        if (p == null) {
            p = Path()
            g.native = p
            g.nativeVersion = -1
        }
        if (g.nativeVersion != g.version) {
            p.rewind()
            pathBuilder.target = p
            g.visit(pathBuilder)
            pathBuilder.target = null
            g.nativeVersion = g.version
        }
        return p
    }

    private class PathBuilder : PathSink {
        var target: Path? = null
        override fun move(x: Float, y: Float) { target?.moveTo(x, y) }
        override fun line(x: Float, y: Float) { target?.lineTo(x, y) }
        override fun quad(cx: Float, cy: Float, x: Float, y: Float) { target?.quadTo(cx, cy, x, y) }
        override fun cubic(c1x: Float, c1y: Float, c2x: Float, c2y: Float, x: Float, y: Float) { target?.cubicTo(c1x, c1y, c2x, c2y, x, y) }
        override fun close() { target?.close() }
    }
}
