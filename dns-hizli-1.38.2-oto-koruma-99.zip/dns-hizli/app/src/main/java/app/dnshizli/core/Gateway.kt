package app.dnshizli.core

import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.DatagramChannel
import java.nio.channels.SelectionKey
import java.nio.channels.Selector
import java.nio.channels.SocketChannel
import java.security.SecureRandom
import java.util.Random
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** Ağ geçidinin canlı ayarları (iş parçacığından bağımsız değişebilir). */
class GwConfig {
    /** TLS/HTTP ilk uçuşunu bölerek DPI'yı atlat. */
    @Volatile var dpi = false
    /** QUIC'i (UDP/443) düşür: uygulamalar TCP'ye döner, böylece SNI/DPI yöntemleri onları da kapsar. */
    @Volatile var blockQuic = false
    /**
     * Seçici QUIC düşürme: TCP'de ilk yöntem engele takılıp başka yöntem işe yaradıysa o sunucu adresine giden QUIC (UDP/443) düşürülür;
     * tarayıcı TCP'ye döner ve çalışan DPI yöntemi onu da kapsar. Diğer sitelerde QUIC'in hızı korunur. Yalnızca DPI açıkken etkilidir.
     */
    @Volatile var quicSelective = true
    /** DPI yalnızca [BlockedSites] listesindeki ya da bu ağda atlatma gerektirdiği görülmüş ([Gateway.bypassSeen]) sitelere uygulanır. Liste boşsa etkisizdir. */
    @Volatile var dpiListedOnly = false
    /** Tarayıcı kipi (deneysel, açık onayla): kural listesindeki sitelerin TLS'i yerel vekile yönlendirilir ([MitmProxy]). null = kapalı. */
    @Volatile var mitm: MitmHook? = null
    /** Discord ses / STUN akışlarının ilk paketinden önce düşük TTL'li sahte paketler ([UdpDecoy]); yalnızca [dpi] açıkken. */
    @Volatile var udpDecoy = false
    /**
     * QUIC (UDP/443) bağlantılarının ilk Initial paketini DPI'a karşı değiştirir ([QuicInitial]): ClientHello çerçeveleri ters sırada yazılır
     * ve (TTL ayarlanabiliyorsa) önce düşük TTL'li sahte bir Initial gider. [blockQuic] açıksa QUIC zaten düşürüldüğü için etkisizdir.
     */
    @Volatile var quicSplit = false
    /** [quicSplit]in uygulandığı sunucu portu (testler değiştirir). */
    @Volatile var quicPort = 443
    /** Bağlantı kurulduktan sonraki kesinti belirtilerinin süreleri ([CutWatch]); testler kısaltır. */
    @Volatile var cutStallMs = CutWatch.STALL_MS
    @Volatile var cutNoreplyMs = CutWatch.NOREPLY_MS
    /**
     * Reklam+ açıkken QUIC de düşürülür ([blockQuic] kapalı olsa bile). QUIC'in ilk paketi şifreli olduğundan site adı
     * okunamaz: QUIC ile gelen reklam ve izleyici bağlantılarını Reklam+ hiç görmezdi. QUIC olmayınca
     * tarayıcı ve uygulamalar kendiliğinden TCP/TLS'e döner; orada ad görünür ve engellenir.
     */
    @Volatile var quicWithAds = true
    /** Sahte paketlerin TTL'i sunucuya olan hop sayısından seçilir ([HopProbe]); ölçülemezse [Dpi.FAKE_TTL]. */
    @Volatile var autoTtl = true
    /** Saniyede kabul edilen en çok yeni akış (TCP SYN + yeni UDP akışı; kısa patlamada 2 katına izin verilir). 0 = sınırsız. Otomatik koruma ([Immune]) ayarlar. */
    @Volatile var flowBudget = 0
    /** Adı görünmeyen bağlantılarda hedef IP'nin DNS cevaplarından bilinen adlarına bakılır ([IpNames]); yalnızca Reklam+ motoru varken. */
    @Volatile var ipNames = true
    /** TLS parmak izi (JA3) gözlemi: yalnızca bellekte sayar. [ja3Deny] içindeki parmak izleri, adı görünmeyen TLS bağlantılarında kesilir (varsayılan boş). */
    @Volatile var ja3 = true
    @Volatile var ja3Deny: Set<String> = emptySet()
    /** DNS'i atlatan şifreli DNS'i (TCP/UDP 853 ve bilinen DoH adları) engelle: uygulamalar sistem DNS'ine döner. */
    @Volatile var blockDoh = false
    /** Aynı anda açık TCP / UDP akış sınırı (cihaz sınıfına göre [Compat] ayarlar). */
    @Volatile var maxTcp = 1500
    @Volatile var maxUdp = 400
    /** Tablo dolunca yeni akışa yer açmak için tahliye edilebilen akışın en az boşta kalma süresi (ms): sessiz bağlantılarla tabloyu dolduran uygulama başkalarını kilitleyemesin. */
    @Volatile var evictIdleMs = 10_000L
    /** UDP / TCP akışlarının boşta kalma süreleri (ms); [Compat] ağ türüne ve cihaza göre ayarlar. */
    @Volatile var udpIdleMs = 30_000L
    @Volatile var tcpIdleMs = 15 * 60_000L
    /** Reklam/izleyici engelleme için motor (ağ geçidine ÖZEL örnek; tünel okuyucusuyla paylaşılmaz). null = kapalı. */
    @Volatile var ads: FilterEngine? = null
    /** [ads] boşsa buradan alınır (motor arka planda kurulduğundan her seferinde güncel olanı verir). */
    @Volatile var adsSource: (() -> FilterEngine?)? = null
    fun engine(): FilterEngine? = ads ?: adsSource?.invoke()
    /** Uygulama bazlı "sıkı" kip için en sıkı seviyeli motor ([AppAds]); yoksa null (sıkı kipteki uygulamalar genel motoru kullanır). */
    @Volatile var strictSource: (() -> FilterEngine?)? = null
    /** Sistemin düz DNS sorguları (UDP/53) da süzülsün mü? (DNS düğmesi kapalıyken de reklam engellensin.) */
    @Volatile var adsDns = true
    /** HTTPS/SVCB (tür 65/64) sorgularına "kayıt yok" de: ECH anahtarı gelmesin, tarayıcı düz TLS'e dönsün (Reklam+ gerçek adı görebilsin). */
    @Volatile var dropHttps = false
    /** true ise yeni bağlantılar yalnızca aktarılır: bölme, engelleme, hiçbir şey yapılmaz (acil durum). */
    @Volatile var passthrough = false
    /** IPv6-only (NAT64) ağ için 96 bitlik ön ek (12 bayt); null = bilinmiyor. IPv4 hedefler ön ek + adres olarak da denenir. */
    @Volatile var nat64: ByteArray? = null
        set(v) { field = v; AddrClass.networkNat64 = v?.takeIf { it.size == 12 }?.copyOf() }   // yeniden bağlama ve yerel hedef de bu öneki tanısın
    /** Ağda IPv4 çıkış yolu yok (yalnızca IPv6): IPv4 hedefler önce [nat64] ile bağlanır, olmazsa düz IPv4 denenir. */
    @Volatile var noV4 = false
    /** Ön ek + IPv4 → NAT64 adresi. Varsayılan düz birleştirme; testler değiştirebilir (ortamda IPv6 olmayabilir). */
    /** Bağlantı kurulurken SYN yanıtsız kalırsa kısa süre sonra paralel ikinci deneme (RFC 8305 benzeri). Kayıplı mobil ağlarda 1 sn'lik çekirdek zamanlayıcısını beklemez. */
    @Volatile var hedge = true
    /** Yerel/özel hedeflere de DPI bölmesi uygula (varsayılan kapalı: modem, NAS gibi yerel cihazlar DPI'ın arkasında değildir). Testler loopback'e bağlandığından açar. */
    @Volatile var dpiOnLocal = false
    /** Ağa göre kalıcı DPI yöntem belleği (null = yalnızca oturum içi). */
    @Volatile var planMemory: PlanMemory? = null
    /** >= 0 ise yedek denemenin gecikmesi (ms) sabitlenir (testler); aksi halde ağın ölçülen bağlantı süresinden. */
    @Volatile var hedgeDelayMs = -1L
    @Volatile var nat64Addr: (ByteArray, ByteArray) -> InetAddress = { p, v -> InetAddress.getByAddress(p + v) }
}

data class GwStats(
    val tcpFlows: Int, val udpFlows: Int,
    val opened: Long, val connectFail: Long, val recentOk: Int, val recentFail: Int,
    val blockedHosts: Long, val split: Long, val retried: Long, val quicDropped: Long, val dnsBlocked: Long,
    val bytesUp: Long, val bytesDown: Long, val dohBlocked: Long = 0L,
    val hedged: Long = 0L, val hedgeWon: Long = 0L, val netResets: Long = 0L,
    /** DPI cihazının enjekte ettiği düz metin cevaplar (TLS'e TLS kaydı olmayan ilk cevap) nedeniyle yöntem değiştirilen bağlantılar. */
    val injected: Long = 0L,
    /** Tüm yöntemleri tükenmiş bir hedefe kısa süre içinde gelen ve yöntem gezilmeden düz aktarılan bağlantılar ([Dpi.EXHAUST_MS]). */
    val exhaustSkipped: Long = 0L,
    /** Bağlantı kurulduktan sonra kesilen TLS bağlantıları ([CutWatch]) ve bunlardan yöntemi değiştirilen hedefler. */
    val cuts: Long = 0L, val cutSwitched: Long = 0L,
    /** Gönderilen UDP sahte paketleri ([UdpDecoy]). */
    val udpDecoys: Long = 0L,
    /** Düşük TTL'li sahte ClientHello gönderilen bağlantılar (yöntem 12). */
    val fakes: Long = 0L,
    /** Initial paketi yeniden kurulan QUIC bağlantıları ve bunlara önce gönderilen sahte Initial'lar ([QuicInitial]). */
    val quicSplits: Long = 0L, val quicFakes: Long = 0L,
    /**
     * Son dakikada DPI yöntemi uygulanan TLS bağlantılarının sonucu: [recentDpiOk] sunucudan TLS cevabı alınan, [recentDpiFail] tüm
     * yöntemleri tükenip kesilen bağlantılar. Yalnızca TCP bağlantısının açılmasına bakan [recentOk]'in göremediği "bağlantı açılıyor ama
     * el sıkışma hep bozuluyor" durumunu ayırt eder (DPI yöntemi ağda her siteyi bozuyorsa).
     */
    val recentDpiOk: Int = 0, val recentDpiFail: Int = 0,
    /** Beklenmeyen iç hatalar ([Gateway.internalErrors]); sağlıklı çalışmada 0. */
    val internalErrors: Long = 0L,
    /** Uygulama güvenlik duvarının kestiği bağlantılar ([AppFirewall]). */
    val fwBlocked: Long = 0L,
)

/**
 * Tünel içindeki TÜM trafiği (DNS dışında) gerçek ağa aktaran kullanıcı alanı geçidi. Sıfırdan yazıldı, dış kütüphane yok.
 * Android'e bağlı değildir: soketler [protectTcp]/[protectUdp] ile (VpnService.protect) işaretlenir, testlerde gerçek
 * loopback soketleri kullanılır.
 *
 * Tasarım:
 *  - Tek iş parçacığı ("gw-io") her şeyi yapar: tünelden gelen paketler [onPacket] ile kuyruğa konur, seçici
 *    (Selector) hem sokete hem zamanlayıcıya bakar. Kilit yoktur.
 *  - TCP: istemci (telefondaki uygulama) ile bu geçit arasında kendi TCP durum makinemiz vardır; sunucu tarafı gerçek bir
 *    SocketChannel'dır. SYN+ACK, ancak sunucuya bağlanılınca gönderilir (bağlanamayan hedef hemen RST alır; IPv6 → IPv4
 *    geri dönüşü bozulmaz). Pencere ölçeği yok (65535), SACK yok; üç yinelenen ACK + zamanlayıcı ile yeniden gönderim.
 *  - İlk uçuş (TLS ClientHello / HTTP isteği) toplanır, SNI/Host okunur; reklam motoru engelliyorsa bağlantı RST ile
 *    kesilir, DPI açıksa [Dpi] ile bölünerek yazılır. Cevap gelmezse (zaman aşımı/RST) AYNI istemci bağlantısı üzerinde
 *    sunucuya yeni bir bağlantı açılıp sıradaki yöntemle yeniden denenir ([Dpi.Planner]).
 *  - UDP: akış başına bir DatagramChannel; boşta 30 sn sonra kapanır.
 */
internal class Gateway(
    private val out: (ByteArray, Int, Int) -> Unit,
    private val protectTcp: (java.net.Socket) -> Boolean = { true },
    private val protectUdp: (java.net.DatagramSocket) -> Boolean = { true },
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000L },
    private val random: Random = SecureRandom(),
    /** Yuvanın IP TTL'ini ayarlar ("disorder" yöntemi). Başarısızsa false: yöntem düz bölmeye düşer. */
    private val setTtl: (java.net.Socket, Int) -> Boolean = { _, _ -> false },
    /** UDP yuvasının IP TTL'ini ayarlar ([UdpDecoy]). Başarısızsa false: sahte paket hiç gönderilmez. */
    private val setUdpTtl: (java.net.DatagramSocket, Int) -> Boolean = { _, _ -> false },
    /**
     * Sahte ClientHello ([Dpi.Part.fake]): (yuva, sahte, gerçek) → çekirdeğe kuyruğa alınan bayt sayısı; -1 = desteklenmiyor / başarısız.
     * Çağıran TTL'i önceden düşürmüştür. Uygulama, dönmeden önce kuyruktaki sayfayı GERÇEK baytlarla değiştirmelidir.
     */
    private val fakeSend: ((java.net.Socket, ByteArray, ByteArray) -> Int)? = null,
    /** Sunucuya hop ölçümü için: (adres, port, ttl) → 1 ulaştı, 0 ulaşmadı, -1 belirsiz ([HopProbe]). null = ölçüm yok, sabit TTL. */
    hopReach: ((ByteArray, Int, Int) -> Int)? = null,
    /** Tüm TCP kuyruklarının toplam bellek tavanı (bayt); testler küçük bir değerle tavanın davranışını sınar. */
    memBudget: Int = MEM_BUDGET,
) {
    val config = GwConfig()

    internal val hopProbe: HopProbe? = hopReach?.let { HopProbe(it, nowMs = nowMs) }

    /** Sahte paket TTL'i: ölçülmüş hop sayısına göre; ölçülmediyse [Dpi.FAKE_TTL]. 0 = sunucu çok yakın, sahte paket gönderilmez. */
    private fun fakeTtlFor(addr: ByteArray): Int {
        if (!config.autoTtl) return Dpi.FAKE_TTL
        val t = HopProbe.ttlFor(hopProbe?.hops(addr) ?: 0)
        return if (t < 0) Dpi.FAKE_TTL else t
    }

    /** Ortak kuyruk belleği (yalnızca gw-io iş parçacığı değiştirir). */
    internal val mem = MemBudget(memBudget)

    // DPI yöntem belleği ağ türüne göre ayrı tutulur: Wi-Fi'de öğrenilen yöntem mobil operatörde işe yaramayabilir (ve tersi).
    // Mobilde bekleme süreleri daha cömert ([Dpi.Planner.slow]): telsiz uyanması ve dalgalı gecikme yanlış "yanıt yok"a yol açmasın.
    private val planners = arrayOf(Dpi.Planner(), Dpi.Planner(slow = true), Dpi.Planner(), Dpi.Planner(), Dpi.Planner())   // NetKind sırası
    @Volatile private var plannerIdx = 0
    val planner: Dpi.Planner get() = planners[plannerIdx]

    /** Etkin ağ türü değişti (ör. Wi-Fi ↔ mobil): o türün kendi yöntem belleğine geçilir. [NetKind.NONE]'da değişmez. */
    @Volatile private var netKey = ""

    /** Etkin ağ değişti: [label] mobilde operatör kodu (boş olabilir). Bu ağın öğrenilmiş yöntemleri varsa planlayıcıya tohum olur. */
    fun networkChanged(kind: NetKind, label: String = "") {
        if (kind == NetKind.NONE) return
        plannerIdx = kind.ordinal
        netKey = PlanMemory.key(kind, label)
        val p = planners[plannerIdx]
        val known = config.planMemory?.get(netKey)
        p.seed(Dpi.TLS, known?.first ?: -1)
        p.seed(Dpi.HTTP, known?.second ?: -1)
        config.planMemory?.let { p.siteImport(it.sites(netKey)) }          // bu ağda daha önce öğrenilen site yöntemleri (özet anahtarlı, ad yok)
        Journal.info("DPI", "ağ değişti: ${kind.name}, öğrenilmiş yöntem ${known?.first ?: -1}, site belleği ${config.planMemory?.sites(netKey)?.size ?: 0}")
    }

    /** Bu ağın DPI yöntem tablosu (tanılama raporu): "TLS 1: 12 kazanç, 0 başarısız, ort 140 ms". Denenmiş yöntem yoksa boş. */
    private val listedSkipped = AtomicLong()
    private val mitmCount = AtomicLong()
    internal fun mitmCount() = mitmCount.get()
    internal fun listedSkipped() = listedSkipped.get()

    /** [dpiListedOnly] açıkken bu hedefe DPI uygulanır mı? Liste boşsa evet (aksi halde DPI hiç çalışmazdı); adı listedeyse ya da adres daha önce atlatma gerektirdiyse evet. */
    private fun dpiWanted(host: String?, server: ByteArray): Boolean =
        !BlockedSites.any() || (host != null && BlockedSites.matches(host)) || bypassSeen(server)

    fun dpiTable(): List<String> = planner.methodStats().map {
        (if (it.kind == Dpi.TLS) "TLS " else "HTTP ") + it.plan + ": " + it.wins + " kazanç, " + it.fails + " başarısız" +
            (if (it.avgMs > 0) ", ort " + it.avgMs + " ms" else "") + (if (it.demoted) ", atlanıyor" else "")
    }

    /** Tanılama için DPI yan sayaçları (enjekte engel cevapları, seçici QUIC, SNI'siz DoT yok burada: yalnızca ağ geçidi). */
    fun dpiExtras(): List<String> = listOf(
        "enjekte engel cevabı reddi: ${injected.get()}, QUIC düşürülen: ${quicDropped.get()}, işaretli sunucu adresi: ${bypassIps.size}, listeden muaf: ${listedSkipped.get()}, engelli liste: ${BlockedSites.size()} ad"
    )

    private val dpiLogAt = LongArray(16)
    private var exhaustLogAt = 0L

    private val selector: Selector = Selector.open()
    private val inbox = ConcurrentLinkedQueue<ByteArray>()
    private val inboxCount = AtomicInteger()
    private val fresh = ConcurrentLinkedQueue<ByteArray>()
    private val freshCount = AtomicInteger()
    /** Yeni bağlantı kuyruğu dolu olduğu için atılan SYN'ler (istemci yeniden dener). */
    internal val synShed = java.util.concurrent.atomic.AtomicLong()
    private val wakePending = AtomicBoolean(false)
    @Volatile private var running = false
    private var thread: Thread? = null

    private val tcp4 = HashMap<Long, TcpFlow>()
    private val tcp6 = HashMap<String, TcpFlow>()
    private val udp4 = HashMap<Long, UdpFlow>()
    private val udp6 = HashMap<String, UdpFlow>()
    private val flowsTcp = AtomicInteger()
    private val flowsUdp = AtomicInteger()

    private val outBuf = ByteArray(2048)

    /**
     * Beklenmeyen iç hatalar (NullPointer, IndexOutOfBounds, StackOverflow...). Ağ hataları (IOException) beklenen durumdur ve sayılmaz.
     * Bir akıştaki hata yalnızca o akışı kapatır; döngü ve öteki akışlar etkilenmez. Sayaç tanılama özetinde görünür.
     */
    private val internalErrors = AtomicLong()
    @Volatile private var lastErrLogAt = 0L
    @Volatile private var lastErr = ""
    internal fun internalErrors() = internalErrors.get()
    /** Son iç hatanın özeti (tür, ileti, ilk çerçeve); hata ayıklama ve testler için. */
    internal fun lastInternalError() = lastErr

    private fun internalError(where: String, e: Throwable) {
        if (e is java.io.IOException || e is java.nio.channels.CancelledKeyException) return
        internalErrors.incrementAndGet()
        lastErr = "$where: ${e.javaClass.simpleName} ${e.message ?: ""} @ ${e.stackTrace.firstOrNull() ?: "?"}"
        val now = nowMs()
        if (now - lastErrLogAt >= 1000L) { lastErrLogAt = now; Journal.warn("GW", "iç hata ($lastErr)") }
    }

    /**
     * Tünele bir paket yazar ([outBuf]'ın ilk [n] baytı). Yazma hatası (kapanmış tünel, taşıyıcının atacağı her istisna) durum makinesini
     * bozmaz: paket kaybolmuş sayılır (TCP yeniden iletir), akış yine de kapanabilir. Aksi halde RST yazarken atılan bir hata
     * [TcpFlow.shutdown]'ı atlatır ve akış tabloda, soketiyle birlikte sonsuza dek açık kalırdı.
     */
    private fun emit(n: Int) {
        try { out(outBuf, 0, n) } catch (e: Throwable) { internalError("tünel yazma", e) }
    }
    private val readBuf = ByteBuffer.allocate(16 * 1024)
    private val dnsOut = ByteArray(Packets.HDR + 512 + FilterEngine.MAX_REPLY_EXTRA)
    /** [dnsAnswer] engelleme cevabı ürettiyse engellenen ad (çağıran uygulamaya yazar); aksi halde null. Yalnızca geçit iş parçacığından. */
    private var lastDnsBlocked: String? = null

    /** Bu bağlantı için reklam motoru: uygulama kipine göre genel / muaf (null) / sıkı ([AppAds.pick]). */
    private fun adsFor(cfg: GwConfig, proto: Int, src: ByteArray, sport: Int, dst: ByteArray, dport: Int): FilterEngine? =
        AppAds.pick(cfg.engine(), cfg.strictSource?.invoke(), proto, src, sport, dst, dport)

    private val opened = AtomicLong(); private val connectFail = AtomicLong()
    private val flowsShed = AtomicLong()
    private var flowTokens = 0.0
    private var flowTokenAt = 0L

    /** Yeni akış sayısı sınırlayıcısı (jeton kovası). Yalnızca ağ geçidi iş parçacığından çağrılır. [GwConfig.flowBudget] 0 ise hep kabul. */
    private fun admitFlow(): Boolean {
        val rate = config.flowBudget
        if (rate <= 0) return true
        val now = nowMs()
        val burst = rate * 2.0
        if (flowTokenAt == 0L) { flowTokens = burst; flowTokenAt = now }
        flowTokens = minOf(burst, flowTokens + (now - flowTokenAt) * rate / 1000.0)
        flowTokenAt = now
        if (flowTokens < 1.0) { flowsShed.incrementAndGet(); return false }
        flowTokens -= 1.0
        return true
    }

    /** Hız sınırı yüzünden reddedilen yeni akışların toplamı (tanılama). */
    fun shedFlows(): Long = flowsShed.get()
    private val incompleteBlocked = AtomicLong()
    private var incompleteLogAt = 0L
    private var evictLogAt = 0L
    private val blockedHosts = AtomicLong(); private val splitCount = AtomicLong(); private val retried = AtomicLong(); private val injected = AtomicLong(); private val exhaustSkipped = AtomicLong()
    /** TCP'de engel yöntemi gerektiren sunucu adresleri (adres özeti → son görülme ms). Sınırlı; adres açık saklanmaz. */
    private val bypassIps = java.util.concurrent.ConcurrentHashMap<Long, Long>()
    private fun ipHash(b: ByteArray): Long { var h = -3750763034362895579L; for (x in b) h = (h xor (x.toLong() and 0xFF)) * 1099511628211L; return h }
    internal fun noteBypass(server: ByteArray) {
        if (bypassIps.size >= BYPASS_MAX) bypassIps.clear()
        bypassIps[ipHash(server)] = nowMs()
    }
    private fun bypassSeen(dst: ByteArray): Boolean {
        if (bypassIps.isEmpty()) return false
        val h = ipHash(dst)
        val t = bypassIps[h] ?: return false
        if (nowMs() - t > BYPASS_TTL_MS) { bypassIps.remove(h); return false }
        return true
    }
    private val quicDropped = AtomicLong(); private val dnsBlocked = AtomicLong(); private val dohBlocked = AtomicLong()
    private val fwBlocked = AtomicLong()
    private val bytesUp = AtomicLong(); private val bytesDown = AtomicLong()
    private val hedged = AtomicLong(); private val hedgeWon = AtomicLong(); private val netResets = AtomicLong()
    private val hedgesInFlight = AtomicInteger()
    private val cuts = AtomicLong(); private val cutSwitched = AtomicLong(); private val udpDecoys = AtomicLong(); private val fakes = AtomicLong(); private val quicSplits = AtomicLong(); private val quicFakes = AtomicLong()
    private val resetPending = AtomicBoolean(false)
    private var nextHedgeAt = Long.MAX_VALUE            // yalnızca gw-io iş parçacığı: bekleyen en yakın yedek deneme zamanı

    /**
     * Fiziksel ağ değişti (Wi-Fi ↔ mobil, başka Wi-Fi, ağ gidip geldi): eski ağa bağlı sunucu soketleri sessizce ölür ve
     * uygulamalar dakikalarca (TCP yeniden iletim süresi) takılı kalır. Tüm akışlar hemen kesilir (istemciye RST); uygulamalar
     * yeni ağda anında yeniden bağlanır. Herhangi bir iş parçacığından çağrılabilir.
     */
    fun networkReset() {
        resetPending.set(true)
        if (wakePending.compareAndSet(false, true)) selector.wakeup()
    }

    private fun doNetworkReset() {
        // Sayaç, RST'ler gönderilmeden ÖNCE artar: istemci RST'yi gördüğünde sayaç da zaten güncel olur.
        val flows = ArrayList(tcp4.values) + ArrayList(tcp6.values)
        netResets.addAndGet((flows.size + udp4.size + udp6.size).toLong())
        for (f in flows) try { f.netReset() } catch (e: Throwable) { internalError("ağ sıfırlama", e); f.failSafe() }
        for (u in ArrayList(udp4.values) + ArrayList(udp6.values)) try { u.close() } catch (e: Throwable) { internalError("ağ sıfırlama (udp)", e) }
    }
    @Volatile private var recentOk = 0
    @Volatile private var recentFail = 0
    @Volatile private var recentDpiOk = 0
    @Volatile private var recentDpiFail = 0
    private var windowStart = 0L
    private var lastTick = 0L

    fun start() {
        if (running) return
        running = true
        windowStart = nowMs()
        thread = Thread({ loop() }, "gw-io").also { it.isDaemon = true; ThreadPrio.trySet(it, ThreadPrio.gateway); it.start() }
    }

    /** İş parçacığını durdurur ve tüm akışları kapatır (RST göndermez: tünel zaten kapanıyor). */
    fun stop() {
        running = false
        try { selector.wakeup() } catch (_: Exception) {}
        val t = thread
        if (t != null && t !== Thread.currentThread()) try { t.join(1500) } catch (_: InterruptedException) {}
        for (f in ArrayList(tcp4.values) + ArrayList(tcp6.values)) f.closeChannel()
        for (f in ArrayList(udp4.values) + ArrayList(udp6.values)) f.closeChannel()
        tcp4.clear(); tcp6.clear(); udp4.clear(); udp6.clear()
        try { selector.close() } catch (_: Exception) {}
    }

    fun stats(): GwStats = GwStats(
        flowsTcp.get(), flowsUdp.get(), opened.get(), connectFail.get(), recentOk, recentFail,
        blockedHosts.get(), splitCount.get(), retried.get(), quicDropped.get(), dnsBlocked.get(), bytesUp.get(), bytesDown.get(), dohBlocked.get(),
        hedged.get(), hedgeWon.get(), netResets.get(), injected.get(), exhaustSkipped.get(), cuts.get(), cutSwitched.get(), udpDecoys.get(), fakes.get(), quicSplits.get(), quicFakes.get(), recentDpiOk, recentDpiFail,
        internalErrors.get(), fwBlocked.get(),
    )

    /** Tünel okuyucusundan gelen bir IP paketi (DNS adresine gidenler buraya verilmez). Hızlıdır: yalnızca kuyruğa koyar. */
    fun onPacket(p: ByteArray, len: Int) {
        if (!running || len < 20) return
        // Yeni bağlantı açılışları (yalın SYN) ayrı, küçük bir kuyrukta: SYN seli ya da sayfa açılışındaki bağlantı patlaması, süren
        // bağlantıların (video, indirme, oyun) paketlerini kuyrukta bekletmez. Kuyruk dolunca yalnızca SYN atılır; istemci yeniden dener.
        if (isPureSyn(p, len)) {
            if (freshCount.get() >= FRESH_MAX) { synShed.incrementAndGet(); return }
            fresh.add(p.copyOf(len))
            freshCount.incrementAndGet()
        } else {
            if (inboxCount.get() >= INBOX_MAX) return                   // aşırı yük: paket atılır, istemci yeniden gönderir
            inbox.add(p.copyOf(len))
            inboxCount.incrementAndGet()
        }
        if (wakePending.compareAndSet(false, true)) selector.wakeup()
    }

    /** Yeni bağlantı isteği mi (SYN var, ACK yok)? IPv4/IPv6 doğrudan TCP; uzantı başlıklı ya da parçalı paketler "hayır" (ana kuyruğa). */
    internal fun isPureSyn(b: ByteArray, len: Int): Boolean {
        val l4: Int = when ((b[0].toInt() ushr 4) and 0xF) {
            4 -> { if ((b[9].toInt() and 0xFF) != 6 || (Packets.u16(b, 6) and 0x1FFF) != 0) return false; (b[0].toInt() and 0x0F) * 4 }
            6 -> { if (len < 40 || (b[6].toInt() and 0xFF) != 6) return false; 40 }
            else -> return false
        }
        if (len < l4 + 14) return false
        val f = b[l4 + 13].toInt() and 0xFF
        return (f and 0x02) != 0 && (f and 0x10) == 0
    }

    // ------------------------------------------------------------------ ana döngü

    private fun loop() {
        var streak = 0
        while (running) {
            try {
                var wait = if (tcp4.isEmpty() && tcp6.isEmpty() && udp4.isEmpty() && udp6.isEmpty()) IDLE_WAIT_MS else TICK_MS
                // Yedek bağlantı zamanı yaklaşıyorsa tam o ana uyan (200 ms'lik zamanlayıcıyı beklemez).
                if (nextHedgeAt != Long.MAX_VALUE) wait = minOf(wait, maxOf(1L, nextHedgeAt - nowMs()))
                selector.select(wait)
                wakePending.set(false)
                if (!running) break
                if (resetPending.compareAndSet(true, false)) doNetworkReset()
                // Önce süren bağlantıların paketleri, sonra (sınırlı sayıda) yeni bağlantı istekleri.
                var p = inbox.poll()
                var n = 0
                while (p != null) {
                    inboxCount.decrementAndGet()
                    try { handlePacket(p) } catch (e: Throwable) { internalError("paket", e) }
                    if (++n >= 512) break
                    p = inbox.poll()
                }
                var m = 0
                while (m < FRESH_PER_ROUND) {
                    val q = fresh.poll() ?: break
                    freshCount.decrementAndGet()
                    try { handlePacket(q) } catch (e: Throwable) { internalError("paket", e) }
                    m++
                }
                val keys = selector.selectedKeys()
                if (keys.isNotEmpty()) {
                    val it = keys.iterator()
                    while (it.hasNext()) {
                        val k = it.next(); it.remove()
                        val h = k.attachment()
                        try {
                            if (k.isValid) when (h) { is TcpFlow -> h.onKey(k); is UdpFlow -> h.onKey(k) }
                        } catch (e: Throwable) {
                            internalError("anahtar", e)
                            when (h) { is TcpFlow -> h.failSafe(); is UdpFlow -> try { h.close() } catch (_: Throwable) {} }
                        }
                    }
                }
                val now = nowMs()
                for (f in tcp4.values) f.flushAck()
                for (f in tcp6.values) f.flushAck()
                if (now - lastTick >= TICK_MS || now >= nextHedgeAt) { lastTick = now; nextHedgeAt = Long.MAX_VALUE; tick(now) }
                if ((inboxCount.get() > 0 || freshCount.get() > 0) && wakePending.compareAndSet(false, true)) selector.wakeup()
                streak = 0
            } catch (_: java.nio.channels.ClosedSelectorException) {
                break
            } catch (e: Throwable) {
                // Döngü hiçbir hatayla (StackOverflowError, OutOfMemoryError dahil) ölmesin: ölürse VPN açık görünür ama hiçbir şey akmaz.
                // Kalıcı bir hata (bozuk seçici) işlemciyi %100 yememeli: art arda hatada kısa bekleme.
                internalError("döngü", e)
                if (++streak > 8) try { Thread.sleep(20) } catch (_: InterruptedException) {}
            }
        }
    }

    private fun tick(now: Long) {
        if (now - windowStart >= 60_000) { windowStart = now; recentOk = 0; recentFail = 0; recentDpiOk = 0; recentDpiFail = 0 }
        sweep(tcp4, now); sweep(tcp6, now)
        val u = ArrayList<UdpFlow>()
        udp4.values.forEach { if (now - it.last > config.udpIdleMs) u.add(it) }
        udp6.values.forEach { if (now - it.last > config.udpIdleMs) u.add(it) }
        for (f in u) f.close()
    }

    private fun <K> sweep(m: HashMap<K, TcpFlow>, now: Long) {
        if (m.isEmpty()) return
        for (f in ArrayList(m.values)) try { f.tick(now) } catch (e: Throwable) { internalError("zamanlayıcı", e); f.failSafe() }
    }

    // ------------------------------------------------------------------ paket ayrıştırma

    private fun handlePacket(p: ByteArray) {
        val len = p.size
        val v6: Boolean
        val ip: Int
        val proto: Int
        val total: Int
        when ((p[0].toInt() ushr 4) and 0xF) {
            4 -> {
                v6 = false
                ip = (p[0].toInt() and 0xF) * 4
                if (ip < 20 || len < ip + 8) return
                if ((Packets.u16(p, 6) and 0x3FFF) != 0) return           // parçalı IP: desteklenmez
                proto = p[9].toInt() and 0xFF
                total = minOf(Packets.u16(p, 2), len)
            }
            6 -> {
                if (len < 48) return
                v6 = true
                val t6 = Gw.ipv6Transport(p, len)                         // uzantı başlıkları atlanır (parçalama düşer)
                if (t6 < 0) return
                ip = t6 and 0xFFFF
                proto = t6 ushr 16
                total = minOf(40 + Packets.u16(p, 4), len)
            }
            else -> return
        }
        if (total < ip + 8) return
        val src = if (v6) p.copyOfRange(8, 24) else p.copyOfRange(12, 16)
        val dst = if (v6) p.copyOfRange(24, 40) else p.copyOfRange(16, 20)
        // Çok noktaya / genel yayın (mDNS, SSDP, DHCP yayını...) aktarılmaz: tünele yanlışlıkla girdiyse sessizce atılır.
        if (isMulticastOrBroadcast(v6, dst)) return
        when (proto) {
            Gw.TCP -> if (total >= ip + 20) onTcp(p, ip, total, v6, src, dst)
            Gw.UDP -> onUdp(p, ip, total, v6, src, dst)
            else -> {}                                                    // ICMP vb.: aktarılmaz
        }
    }

    private fun key4(dst: ByteArray, dport: Int, sport: Int): Long =
        ((Packets.i32(dst, 0).toLong() and 0xFFFFFFFFL) shl 32) or (dport.toLong() shl 16) or sport.toLong()

    private fun key6(dst: ByteArray, dport: Int, sport: Int): String =
        String(dst, Charsets.ISO_8859_1) + dport.toChar() + sport.toChar()

    // ------------------------------------------------------------------ TCP

    private fun onTcp(p: ByteArray, t: Int, total: Int, v6: Boolean, src: ByteArray, dst: ByteArray) {
        val sport = Packets.u16(p, t); val dport = Packets.u16(p, t + 2)
        val seq = Packets.i32(p, t + 4); val ack = Packets.i32(p, t + 8)
        val doff = (p[t + 12].toInt() and 0xF0) ushr 2
        val flags = p[t + 13].toInt() and 0xFF
        val win = Packets.u16(p, t + 14)
        if (doff < 20 || t + doff > total) return
        val pay = t + doff
        val dLen = total - pay
        var f = if (v6) tcp6[key6(dst, dport, sport)] else tcp4[key4(dst, dport, sport)]
        if (flags and Gw.SYN != 0 && flags and Gw.ACK == 0) {
            if (f != null && f.state == CONNECTING && f.rcvNxt == seq + 1) return        // yinelenen SYN: bağlantı sürüyor
            if (f != null && f.state != CLOSED && f.rcvNxt == seq + 1) { f.resendSynAck(); return }
            if (f != null) { f.abort(false); forget(f) }
            if (flowsTcp.get() >= config.maxTcp) reapClosed()
            if (flowsTcp.get() >= config.maxTcp) evictTcp()
            if (flowsTcp.get() >= config.maxTcp) { reset(v6, src, dst, sport, dport, seq, ack, flags, dLen); return }
            if ((dport == 853 || (dport == 443 && Dpi.isDohAddress(dst))) && config.blockDoh && !config.passthrough) { dohBlocked.incrementAndGet(); reset(v6, src, dst, sport, dport, seq, ack, flags, dLen); return }
            // Uygulama güvenlik duvarı: engelli uygulamanın bağlantısı hemen RST alır ("bağlantı reddedildi"; beklemez).
            if (AppFirewall.armed && AppFirewall.blocked(6, src, sport, dst, dport)) { fwBlocked.incrementAndGet(); reset(v6, src, dst, sport, dport, seq, ack, flags, dLen); return }
            if (!admitFlow()) { reset(v6, src, dst, sport, dport, seq, ack, flags, dLen); return }
            val mss = peerMss(p, t + 20, pay)
            f = TcpFlow(v6, src, dst, sport, dport, seq, mss)
            f.fwGen = AppFirewall.gen
            if (v6) tcp6[key6(dst, dport, sport)] = f else tcp4[key4(dst, dport, sport)] = f
            flowsTcp.incrementAndGet()
            try { f.connect() } catch (e: Throwable) { internalError("bağlan", e); f.failSafe() }
            return
        }
        if (f == null || f.state == CLOSED) {
            if (flags and Gw.RST == 0) reset(v6, src, dst, sport, dport, seq, ack, flags, dLen)
            return
        }
        // Kural ya da ağ değişti: süren akış yeniden denetlenir; artık engelliyse kesilir (uygulamaya RST).
        if (AppFirewall.armed && f.fwGen != AppFirewall.gen) {
            f.fwGen = AppFirewall.gen
            if (AppFirewall.blocked(6, src, sport, dst, dport)) {
                fwBlocked.incrementAndGet()
                if (f.state != ESTAB) reset(v6, src, dst, sport, dport, seq, ack, flags, dLen)
                f.abort(true); forget(f); return
            }
        }
        // Akış başına yalıtım: bu akışın bir segmentindeki beklenmeyen hata yalnızca onu kapatır (istemciye RST), tablo ve sayaç tutarlı kalır.
        try { f.onSegment(seq, ack, flags, win, p, pay, dLen) } catch (e: Throwable) { internalError("segment", e); f.failSafe() }
    }

    private fun peerMss(p: ByteArray, from: Int, to: Int): Int {
        var i = from
        while (i < to) {
            val k = p[i].toInt() and 0xFF
            if (k == 0) break
            if (k == 1) { i++; continue }
            if (i + 1 >= to) break
            val l = p[i + 1].toInt() and 0xFF
            if (l < 2) break
            if (k == 2 && l == 4 && i + 4 <= to) return Packets.u16(p, i + 2)
            i += l
        }
        return 536
    }

    /** Bilinmeyen bağlantıya RST (RFC 793 §3.4): istemci hemen vazgeçsin. */
    private fun reset(v6: Boolean, client: ByteArray, server: ByteArray, cport: Int, sport: Int, seq: Int, ack: Int, flags: Int, dLen: Int) {
        val n = if (flags and Gw.ACK != 0)
            Gw.tcp(outBuf, v6, server, client, sport, cport, ack, 0, Gw.RST, 0, null, 0, 0)
        else {
            val a = seq + dLen + (if (flags and Gw.SYN != 0) 1 else 0) + (if (flags and Gw.FIN != 0) 1 else 0)
            Gw.tcp(outBuf, v6, server, client, sport, cport, 0, a, Gw.RST or Gw.ACK, 0, null, 0, 0)
        }
        emit(n)
    }

    /** Tablo dolunca kapanmış ama bekleme süresindeki (LINGER) bağlantıları hemen at: yeni bağlantı bunlar yüzünden reddedilmesin. */
    private fun reapClosed() {
        for (f in ArrayList(tcp4.values) + ArrayList(tcp6.values)) if (f.state == CLOSED) forget(f)
    }

    /**
     * Tablo dolu: yeni akışa yer açmak için boşta bir akışı tahliye eder (RST gider; uygulama bağlantının öldüğünü öğrenir). Yoksa tablo,
     * hiç veri almayan sessiz bağlantılarla (yerel bir uygulama ya da bozuk bir SDK) doldurulup tüm öteki uygulamalar [GwConfig.tcpIdleMs]
     * (15 dk) boyunca kilitlenebilirdi. Seçim: en az [GwConfig.evictIdleMs] boşta kalmış olanlar arasında önce HİÇ veri almamış olanlar,
     * sonra en eski. Son zamanlarda veri alışverişi yapan akışlara dokunulmaz. Tahliye edilecek akış yoksa false.
     */
    private fun evictTcp(): Boolean {
        val now = nowMs()
        val minIdle = config.evictIdleMs
        var victim: TcpFlow? = null
        var best = -1L
        fun consider(f: TcpFlow) {
            if (f.state == CLOSED) return
            val idle = now - f.last
            if (idle < minIdle) return
            val score = idle + (if (!f.gotData) 1_000_000_000L else 0L)
            if (score > best) { best = score; victim = f }
        }
        for (f in tcp4.values) consider(f)
        for (f in tcp6.values) consider(f)
        val v = victim ?: return false
        if (v.state == CONNECTING) v.netReset() else v.abort(true)
        forget(v)
        flowsShed.incrementAndGet()
        if (now - evictLogAt > 30_000L) { evictLogAt = now; Journal.warn("GW", "akış tablosu doldu: boşta bir akış tahliye edildi") }
        return true
    }

    /** [evictTcp]'nin UDP karşılığı: en uzun süredir sessiz UDP akışını kapatır. */
    private fun evictUdp(): Boolean {
        val now = nowMs()
        var victim: UdpFlow? = null
        var best = -1L
        for (f in udp4.values) { val idle = now - f.last; if (idle >= config.evictIdleMs && idle > best) { best = idle; victim = f } }
        for (f in udp6.values) { val idle = now - f.last; if (idle >= config.evictIdleMs && idle > best) { best = idle; victim = f } }
        val v = victim ?: return false
        v.close()
        flowsShed.incrementAndGet()
        return true
    }

    private fun forget(f: TcpFlow) {
        // Sayaç yalnızca akış tablodan GERÇEKTEN çıkarsa düşer: aynı akış iki yoldan unutulursa (iptal + zaman aşımı) sayaç eksiye kaymasın;
        // eksik sayaç MAX_TCP sınırını işlevsiz bırakırdı.
        val removed = if (!f.v6) tcp4.remove(key4(f.server, f.sport, f.cport), f) else tcp6.remove(key6(f.server, f.sport, f.cport), f)
        if (removed) flowsTcp.decrementAndGet()
    }

    /**
     * Tek bir istemci TCP bağlantısı + sunucuya giden gerçek soket. [client]/[server] istemci ve uzak adrestir;
     * [cport] telefondaki uygulamanın, [sport] uzak sunucunun portudur.
     */
    private inner class TcpFlow(
        val v6: Boolean, val client: ByteArray, val server: ByteArray, val cport: Int, val sport: Int,
        isn: Int, clientMss: Int,
    ) {
        var state = CONNECTING
        val iss = random.nextInt()
        var sndUna = iss + 1
        var sndNxt = iss + 1
        var rcvNxt = isn + 1
        var peerWnd = 65535
        var lastWin = -1
        var dup = 0
        var synAcked = false
        val mss = minOf(clientMss.coerceAtLeast(100), if (v6) Gw.MSS6 else Gw.MSS4)

        val sndBuf = ByteQueue(SND_CAP, mem)
        val toUp = ByteQueue(UP_CAP, mem)
        var finSent = false; var finAcked = false
        var clientFin = false; var upEof = false; var upShut = false
        var needAck = false
        var rto = RTO_INIT; var rtoAt = 0L; var tries = 0
        var created = nowMs(); var last = created
        var closedAt = 0L
        var synAckAt = 0L; var synAckTries = 0
        /** Uygulama güvenlik duvarı denetiminin kuşağı ([AppFirewall.gen]); değişince akış yeniden denetlenir. */
        var fwGen = 0

        var ch: SocketChannel? = null
        var key: SelectionKey? = null
        var connected = false
        var readBlocked = false

        // ilk uçuş / DPI
        var phase = PRE
        var first = ByteArray(0)
        var firstLen = 0
        var firstDeadline = 0L
        var firstHardAt = 0L                    // tanınmış ama eksik ilk uçuşun en geç bu ana dek tamamlanması gerekir (yavaş damlatma)
        var kind = Dpi.NONE
        var plan = -1
        private var sentAt = 0L             // ilk uçuşun (bu denemede) yazıldığı an: ilk cevaba kadar süre ölçülür
        private var triedMask = 0          // bu bağlantıda denenip başarısız olan yöntemler (bit maskesi); başarıda planlayıcıya verilir
        var hostKey = ""
        var mitmHost: String? = null            // tarayıcı kipinde bu akışın TLS'i yerel vekile gider
        private var mitmFellBack = false         // vekile bağlanılamadı: bir kez doğrudan hedefe dönüldü
        var awaitDeadline = 0L
        var connStart = 0L
        var useNat = false
        var natTried = false
        var ch2: SocketChannel? = null           // yedek (hedge) bağlantı denemesi
        var key2: SelectionKey? = null
        var hedgeAt = 0L; var hedgeNat = false; var connStart2 = 0L; var hedgeTried = false
        var gotData = false
        /** Cevap alındıktan sonra bağlantı kesintisini izler (yalnızca bölme uygulanan TLS bağlantılarında). */
        var cw: CutWatch? = null
        val parts = ArrayDeque<Dpi.Part>()
        var partOff = 0
        var oobPending = false
        var pauseUntil = 0L                      // gecikmeli parça (Dpi.Part.delayMs) bu ana dek bekler; 0 = beklemiyor

        // ---- sunucu tarafı bağlantı

        fun connect() {
            openUpstream()
        }

        private fun openUpstream() {
            try {
                val c = SocketChannel.open()
                ch = c
                c.configureBlocking(false)
                val mh = config.mitm
                val mHost = mitmHost
                val viaProxy = mh != null && mHost != null           // yerel vekile bağlantı: tünel dışı yol gerekmez (protect loopback'i bozabilir)
                if (!viaProxy && !protectTcp(c.socket())) throw IOException("protect")
                try { c.socket().tcpNoDelay = true; c.socket().keepAlive = true } catch (_: Exception) {}
                connected = false
                connStart = nowMs()
                if (!natTried && server.size == 4 && config.noV4 && config.nat64 != null) useNat = true
                val dest: InetSocketAddress
                if (viaProxy) {
                    val lo = InetAddress.getLoopbackAddress()
                    c.socket().bind(InetSocketAddress(lo, 0))        // yerel port önceden bilinir: vekil gerçek hedefi bu porttan eşler
                    mh!!.expect(c.socket().localPort, mHost!!, upstreamAddr(), sport)
                    dest = InetSocketAddress(lo, mh.port())
                } else dest = InetSocketAddress(upstreamAddr(), sport)
                val done = c.connect(dest)
                key = c.register(selector, if (done) SelectionKey.OP_READ else SelectionKey.OP_CONNECT, this)
                hedgeTried = false
                hedgeAt = if (!done && config.hedge && !viaProxy) nowMs() + (if (config.hedgeDelayMs >= 0) config.hedgeDelayMs else planner.hedgeMs()) else 0L
                if (hedgeAt != 0L && hedgeAt < nextHedgeAt) nextHedgeAt = hedgeAt
                if (done) onConnected()
                else if (state == CONNECTING) synAckAt = nowMs() + CONNECT_MS
            } catch (e: Exception) {
                connectFailed()
            }
        }

        /** Sunucu adresi; NAT64 kipindeyse ön ek + IPv4 (yalnızca IPv6 olan mobil ağlar). */
        private fun upstreamAddr(): InetAddress {
            val p = config.nat64
            return if (useNat && p != null && p.size == 12 && server.size == 4) config.nat64Addr(p, server) else InetAddress.getByAddress(server)
        }

        /** Asıl deneme yanıtsızken ikinci bir bağlantı açar (varsa öbür adres ailesine); ilk bağlanan kazanır. */
        private fun startHedge() {
            hedgeAt = 0L; hedgeTried = true
            if (ch2 != null || connected || hedgesInFlight.get() >= MAX_HEDGES) return
            val c = try { SocketChannel.open() } catch (_: Exception) { return }
            var adopted = false                      // c, ch2 olarak atandıktan sonra sahibi akıştır; öncesinde hata olursa burada kapatılır
            try {
                c.configureBlocking(false)
                if (!protectTcp(c.socket())) { c.close(); return }
                try { c.socket().tcpNoDelay = true; c.socket().keepAlive = true } catch (_: Exception) {}
                val p = config.nat64
                val canAlt = server.size == 4 && p != null && p.size == 12
                hedgeNat = if (canAlt) !useNat else useNat
                val addr = if (hedgeNat && p != null) config.nat64Addr(p, server) else InetAddress.getByAddress(server)
                connStart2 = nowMs()
                val done = c.connect(InetSocketAddress(addr, sport))
                ch2 = c; adopted = true
                hedgesInFlight.incrementAndGet()     // ch2 atanır atanmaz: dropHedge() ile sayaç her durumda dengeli kalır (register hata verse bile)
                key2 = c.register(selector, if (done) SelectionKey.OP_READ else SelectionKey.OP_CONNECT, this)
                hedged.incrementAndGet()
                if (done) promoteHedge()
            } catch (_: Exception) {
                if (!adopted) try { c.close() } catch (_: Exception) {}
                dropHedge()
            }
        }

        /** Yedek bağlantı asılın yerini alır (ilk bağlanan yedekse). */
        private fun promoteHedge() {
            val c2 = ch2 ?: return
            val k2 = key2
            try { key?.cancel() } catch (_: Exception) {}
            try { ch?.close() } catch (_: Exception) {}
            ch = c2; key = k2; ch2 = null; key2 = null
            hedgesInFlight.decrementAndGet(); hedgeWon.incrementAndGet()
            useNat = hedgeNat; connStart = connStart2; hedgeAt = 0L
            onConnected()
        }

        private fun dropHedge() {
            hedgeAt = 0L
            val had = ch2 != null
            try { key2?.cancel() } catch (_: Exception) {}
            try { ch2?.close() } catch (_: Exception) {}
            ch2 = null; key2 = null
            if (had) hedgesInFlight.decrementAndGet()
        }

        /** Ağ değişti: bu akış hemen kesilir (istemciye RST), uygulama yeni ağda yeniden bağlanır. */
        fun netReset() {
            if (state == CLOSED) return
            if (state == CONNECTING) {
                val n = Gw.tcp(outBuf, v6, server, client, sport, cport, 0, rcvNxt, Gw.RST or Gw.ACK, 0, null, 0, 0)
                emit(n)
                shutdown()
            } else abort(true)
        }

        private fun connectFailed() {
            // Asıl deneme düştü ama yedek sürüyor: yedek asıl olur, hata sayılmaz.
            if (ch2 != null && !connected) {
                try { key?.cancel() } catch (_: Exception) {}
                try { ch?.close() } catch (_: Exception) {}
                ch = ch2; key = key2; ch2 = null; key2 = null
                hedgesInFlight.decrementAndGet()
                useNat = hedgeNat; connStart = connStart2
                if (state == CONNECTING) synAckAt = nowMs() + CONNECT_MS
                return
            }
            // Tarayıcı kipi: yerel vekile bağlanılamadı (vekil kapandı / port reddetti). Kaydı sil ve bir kez doğrudan hedefe dene: sayfa açılır
            // (yalnızca kozmetik süzgeç uygulanmaz); aksi halde vekil yokken o sitenin tüm bağlantıları kesilirdi.
            if (mitmHost != null && !mitmFellBack && (state == CONNECTING || (phase == AWAIT && !gotData))) {
                mitmFellBack = true
                try { config.mitm?.unexpect(ch?.socket()?.localPort ?: 0) } catch (_: Exception) {}
                mitmHost = null
                closeChannel()
                openUpstream()
                return
            }
            // IPv4 ile NAT64 arasında bir kez geçiş: ağın IPv4/IPv6 durumu tahminimizden farklı olabilir.
            if (!natTried && server.size == 4 && config.nat64 != null && (state == CONNECTING || (phase == AWAIT && !gotData))) {
                natTried = true; useNat = !useNat
                closeChannel()
                openUpstream()
                return
            }
            connectFail.incrementAndGet(); recentFail++
            if (state == CONNECTING) {
                // SYN'e RST: uygulama hemen "bağlantı reddedildi" görür
                val n = Gw.tcp(outBuf, v6, server, client, sport, cport, 0, rcvNxt, Gw.RST or Gw.ACK, 0, null, 0, 0)
                emit(n)
                shutdown()
            } else if (phase == AWAIT && !gotData) retryOrFail() else abort(true)
        }

        private fun onConnected() {
            connected = true
            if (sentAt > 0L) sentAt = nowMs()            // süre bağlantı kurulduktan sonra ölçülür (bağlanma süresi yöntemin değil ağın)
            if (connStart != 0L && !gotData) planner.noteRtt(nowMs() - connStart)
            try { key?.interestOps(SelectionKey.OP_READ) } catch (_: Exception) {}
            if (state == CONNECTING) {
                recentOk++; opened.incrementAndGet()
                state = ESTAB
                synAckAt = nowMs() + 1000; synAckTries = 0
                sendSynAck()
            } else {
                // yeniden deneme bağlantısı: ilk uçuşu sıradaki yöntemle yaz
                writeFirst()
            }
        }

        fun resendSynAck() { if (!synAcked) sendSynAck() }

        private fun sendSynAck() {
            val n = Gw.tcp(outBuf, v6, server, client, sport, cport, iss, rcvNxt, Gw.SYN or Gw.ACK, window(), null, 0, 0, mss)
            emit(n)
        }

        fun onKey(k: SelectionKey) {
            val kc = k.channel()
            if (kc != null && kc === ch2) {
                if (k.isConnectable) {
                    try { if (kc is SocketChannel && kc.finishConnect()) promoteHedge() } catch (_: Exception) { dropHedge() }
                }
                return
            }
            val c = ch ?: return
            if (kc !== c) return
            if (k.isConnectable) {
                try { if (c.finishConnect()) { dropHedge(); onConnected() } else return } catch (_: Exception) { connectFailed(); return }
            }
            if (k.isValid && k.isWritable) flushUp()
            if (k.isValid && k.isReadable) readUp()
        }

        // ---- istemciden gelen segment

        fun onSegment(seq: Int, ack: Int, flags: Int, win: Int, p: ByteArray, off: Int, dLen: Int) {
            last = nowMs()
            if (flags and Gw.RST != 0) {
                if (Gw.seqLe(rcvNxt - 1, seq) && Gw.seqLt(seq, rcvNxt + 65536)) abort(false)
                return
            }
            if (state == CONNECTING) return
            if (flags and Gw.SYN != 0) { resendSynAck(); return }
            if (flags and Gw.ACK == 0) return
            if (!synAcked) {
                if (ack == iss + 1) synAcked = true else return
            }
            processAck(ack, win, dLen == 0 && flags and (Gw.FIN or Gw.SYN) == 0)
            var o = off; var l = dLen; var s = seq
            if (l > 0) {
                if (Gw.seqLt(s, rcvNxt)) {
                    val skip = rcvNxt - s
                    if (skip >= l) { l = 0; sendAck() } else { o += skip; l -= skip; s = rcvNxt }
                }
                if (l > 0) {
                    if (s != rcvNxt) { sendAck(); l = 0 }
                    else {
                        val acc = acceptClient(p, o, l)
                        rcvNxt += acc
                        needAck = true
                        if (acc < l) {
                            // Pencere doldu: kalanı istemci yeniden gönderir (FIN de bekler). Ama sunucudan gelmiş, istemciye
                            // gitmeyi bekleyen veri yine gönderilir: aksi halde iki yön birbirini bekleyip kilitlenebilirdi.
                            if (state != CLOSED) pump()
                            return
                        }
                    }
                }
            }
            if (flags and Gw.FIN != 0) {
                if (seq + dLen == rcvNxt && !clientFin) {
                    clientFin = true; rcvNxt++; needAck = true
                    if (phase == PRE || phase == COLLECT) startFirst(true)
                    flushUp()
                } else if (clientFin && seq + dLen + 1 == rcvNxt) needAck = true
            }
            if (state != CLOSED) pump()
            checkDone()
        }

        private fun processAck(ack: Int, win: Int, pure: Boolean) {
            val winChanged = win != lastWin
            lastWin = win
            peerWnd = win
            if (Gw.seqLt(sndUna, ack) && Gw.seqLe(ack, sndNxt)) {
                var n = ack - sndUna
                if (finSent && ack == sndNxt) { finAcked = true; n -= 1 }
                sndBuf.drop(n)
                sndUna = ack
                dup = 0; tries = 0; rto = RTO_INIT
                rtoAt = if (sndUna != sndNxt) nowMs() + rto else 0L
                if (readBlocked && sndBuf.size < SND_CAP / 2) { readBlocked = false; setInterest() }
            } else if (ack == sndUna && pure && sndNxt != sndUna && !winChanged) {
                if (++dup >= 3) { dup = 0; retransmit() }      // sayaç sıfırlanır: yeniden iletim de kaybolursa bir sonraki 3 kopya yine tetikler
            }
        }

        /** İstemci verisini işler: ilk uçuş toplanır, sonrası sunucuya kuyruğa girer. Kabul edilen bayt sayısı döner. */
        private fun acceptClient(p: ByteArray, off: Int, len: Int): Int {
            bytesUp.addAndGet(len.toLong())
            when (phase) {
                PRE, COLLECT -> {
                    val n = minOf(len, FIRST_MAX - firstLen)
                    if (n <= 0) { startFirst(true); return acceptClient(p, off, len) }
                    if (first.size < firstLen + n) first = first.copyOf(maxOf(2048, minOf(FIRST_MAX, (firstLen + n) * 2)))
                    System.arraycopy(p, off, first, firstLen, n)
                    firstLen += n
                    if (phase == PRE) { phase = COLLECT; firstDeadline = nowMs() + FIRST_WAIT_MS; firstHardAt = nowMs() + FIRST_HARD_MS }
                    startFirst(false)
                    return n
                }
                AWAIT -> {
                    // İstemci cevap gelmeden yeniden veri yolladı: yeniden deneme artık güvenli değil, olduğu gibi akıt.
                    val n = toUp.add(p, off, len)
                    phase = RELAY
                    flushUp()
                    return n
                }
                else -> {
                    if (scanOn && !scanDns(config, p, off, len)) { abort(true); return len }
                    val n = toUp.add(p, off, len)
                    flushUp()
                    return n
                }
            }
        }

        private var scanOn = false
        private var scanBuf: ByteArray? = null
        private var scanLen = 0

        /**
         * TCP/53 akışında istemci yönündeki uzunluk önekli DNS sorularını tek tek süzer. Engellenecek ya da biçimi bozuk
         * bir soru görülürse false (bağlantı kesilir): ilk soru temiz diye sonrakiler denetimsiz geçemez.
         */
        private fun scanDns(cfg: GwConfig, p: ByteArray, off: Int, len: Int): Boolean {
            val b = scanBuf ?: ByteArray(2 + DnsForwarder.MAX_DNS).also { scanBuf = it }
            var i = 0
            while (i < len) {
                val n = minOf(len - i, b.size - scanLen)
                if (n <= 0) return false
                System.arraycopy(p, off + i, b, scanLen, n)
                scanLen += n; i += n
                var pos = 0
                while (scanLen - pos >= 2) {
                    val ql = Packets.u16(b, pos)
                    if (ql < Packets.DNS_HDR || ql > DnsForwarder.MAX_DNS) return false
                    if (scanLen - pos < 2 + ql) break
                    if (dnsAnswer(flowAds, cfg.dropHttps, b, pos + 2, ql, dnsOut, Packets.HDR, true) > 0) { lastDnsBlocked?.let { AppAds.blocked(6, client, cport, server, sport, it) }; return false }
                    pos += 2 + ql
                }
                if (pos > 0) { System.arraycopy(b, pos, b, 0, scanLen - pos); scanLen -= pos }
            }
            return true
        }

        // ---- ilk uçuş

        /**
         * Süzülen DNS-over-TCP akışı mı (sabit sunucuya TCP/53, ad süzgeci açık)? Evetse ilk baytlar TLS/HTTP diye SINIFLANMAZ: DNS'in 2 baytlık
         * uzunluk önekini ve kimliğini isteyen taraf seçer (ör. 0x16 0x03 0x01.. ya da "GE"+"T "); sınıflansaydı sorgu süzgeci atlardı.
         */
        private fun dnsTcpFiltered(): Boolean = sport == 53 && !config.passthrough && config.adsDns

        private fun classifyFirst(): Int = if (dnsTcpFiltered()) Dpi.NONE else Dpi.classify(first, firstLen)

        /** DNS-over-TCP ilk uçuşu henüz tam bir soru değil mi (uzunluk öneki ya da gövde eksik)? */
        private fun dnsIncomplete(): Boolean {
            if (!dnsTcpFiltered() || firstLen == 0) return false
            if (firstLen < 2) return true
            val want = 2 + Packets.u16(first, 0)
            return want <= 2 + 4096 && firstLen < want
        }

        /** Yeterli bayt toplandıysa (ya da [force]) karar verir ve sunucuya yazar. */
        fun startFirst(force: Boolean) {
            if (phase != COLLECT && phase != PRE) return
            if (firstLen == 0 && !force) return
            val k = classifyFirst()
            var need = -1
            when (k) {
                Dpi.TLS -> need = Dpi.tlsNeed(first, firstLen)
                Dpi.HTTP -> need = Dpi.httpEnd(first, firstLen)
                else -> {
                    if (firstLen < 3 && !force) return
                    if (!force && Dpi.mayBecomeHttp(first, firstLen)) return        // "GE" + "T /..." gibi bölünmüş yöntem: daha fazla bayt gelene dek bekle
                    // DNS-over-TCP (sabit sunucuya TCP/53): uzunluk önekli soru tam gelene dek beklenir, süzgeç eksik soruyu göremez.
                    if (sport == 53 && !force && firstLen >= 2) {
                        val want = 2 + Packets.u16(first, 0)
                        if (want <= 2 + 4096 && firstLen < want) return
                    }
                }
            }
            if (!force && k != Dpi.NONE && (need < 0 || firstLen < need)) return    // eksik: bekle
            // Zorunlu karar (zaman aşımı / tampon doldu) ama TLS/HTTP ilk uçuşu EKSİK: ad henüz görülmedi. Süzgeç etkinse bu "yavaş damlatma"
            // ya da dev başlık ile engelli adı gizleme denemesidir (SNI/Host sonradan gelir ve denetimsiz geçerdi): bağlantı kesilir.
            if (force && !clientFin && (k != Dpi.NONE && (need < 0 || firstLen < need) || k == Dpi.NONE && Dpi.mayBecomeHttp(first, firstLen) || dnsIncomplete()) && inspecting()) {
                incompleteBlocked.incrementAndGet()
                if (nowMs() - incompleteLogAt > 30_000L) { incompleteLogAt = nowMs(); Journal.warn("GW", "ilk uçuş tamamlanmadı (yavaş damlatma / dev başlık): bağlantı kesildi") }
                abort(true)
                return
            }
            kind = k
            decide(if (need in 1..firstLen) need else firstLen)
        }

        /** Bu akışta ad denetimi (süzgeç, DoH engeli, tarayıcı kipi) yapılıyor mu? Evetse ilk uçuş eksikken karar verilmez. */
        private fun inspecting(): Boolean {
            val cfg = config
            if (cfg.passthrough) return false
            return adsFor(cfg, 6, client, cport, server, sport) != null || cfg.blockDoh || cfg.mitm != null
        }

        /** [tick]: ilk uçuş toplanıyor ve süre doldu. Tanınmış ama eksik uçuşta, denetim varsa, sert süreye dek beklenir. */
        private fun firstTimeout(now: Long) {
            val k = classifyFirst()
            val incomplete = dnsIncomplete() || when (k) {
                Dpi.TLS -> Dpi.tlsNeed(first, firstLen).let { it < 0 || firstLen < it }
                Dpi.HTTP -> Dpi.httpEnd(first, firstLen).let { it < 0 || firstLen < it }
                else -> Dpi.mayBecomeHttp(first, firstLen)
            }
            if (incomplete && now < firstHardAt && inspecting()) return
            startFirst(true)
        }

        /** Bu akış için uygulama kipine göre seçilmiş reklam motoru ([decide] doldurur; [scanDns] sonraki sorularda da kullanır). */
        private var flowAds: FilterEngine? = null

        private fun decide(flight: Int) {
            val cfg = config
            flowAds = adsFor(cfg, 6, client, cport, server, sport)
            var host: String? = null
            var target: String? = null           // HTTP: istek satırındaki mutlak hedefin / CONNECT'in adı (Host'tan farklı olabilir)
            var otherHosts: List<String> = emptyList()   // HTTP: yinelenen / katlanmış Host başlıklarındaki ek adlar (sunucu hangisini seçerse seçsin denetlenir)
            val http = Dpi.HttpInfo()
            if (kind == Dpi.TLS) {
                val h = Dpi.Hello()
                // ClientHello birden çok kayda bölünmüşse SNI ikinci kayıtta olabilir: kayıtlar birleştirilip okunur.
                val merged = Dpi.mergedHello(first, firstLen)
                val src = merged ?: first
                val srcLen = merged?.size ?: firstLen
                if (Dpi.parseHello(src, srcLen, h)) host = h.host(src)
                if (!cfg.passthrough && cfg.ja3) {
                    val fp = TlsFingerprint.ja3(src, srcLen)
                    if (fp != null) {
                        TlsFingerprint.observe(fp)
                        if (host == null && fp in cfg.ja3Deny && !Dpi.isLocalAddress(server)) {
                            blockedHosts.incrementAndGet()
                            abort(true)
                            return
                        }
                    }
                }
            } else if (kind == Dpi.HTTP) {
                if (Dpi.parseHttp(first, firstLen, http)) host = Dpi.httpHost(first, http)
                target = Dpi.requestTargetHost(first, firstLen)
                otherHosts = Dpi.allHttpHosts(first, firstLen).filter { it != host && it != target }
                if (host == null) host = target
            }
            hostKey = host ?: ((InetAddress.getByAddress(server).hostAddress ?: "") + ":" + sport)
            if (!cfg.passthrough && sport == 53 && kind == Dpi.NONE && cfg.adsDns) {
                if (answerDnsOverTcp(cfg)) return
                // İlk soru geçti; aynı uçuştaki ve sonradan aynı bağlantıdan gelen (ardışık/pipelined) sorular da süzülür.
                scanOn = true
                if (!scanDns(cfg, first, 0, firstLen)) { abort(true); return }
            }
            if (!cfg.passthrough) {
                val ads = flowAds
                // Host ve istek satırı hedefinden HERHANGİ biri engelliyse bağlantı kesilir (sunucu hangisini kullanırsa kullansın).
                var hit: String? = null
                var hitVerdict = FilterVerdict.PASS
                if (ads != null) for (nm in listOfNotNull(host, target) + otherHosts) {
                    val vv = ads.verdictOf(nm)
                    if (vv != FilterVerdict.PASS) { hit = nm; hitVerdict = vv; break }
                }
                if (hit != null) {
                    blockedHosts.incrementAndGet()
                    if (hitVerdict != FilterVerdict.CANARY) { FilterLive.note(hit, hitVerdict == FilterVerdict.USER); AppAds.blocked(6, client, cport, server, sport, hit) }
                    abort(true)
                    return
                }
                if (ads != null && host != null && kind != Dpi.NONE && FilterLive.keepNames) FilterLive.notePassed(host)
            }
            if (!cfg.passthrough && cfg.blockDoh && (host != null && Dpi.isDohHost(host) || target != null && Dpi.isDohHost(target) || otherHosts.any { Dpi.isDohHost(it) })) {
                dohBlocked.incrementAndGet()
                abort(true)
                return
            }
            if (!cfg.passthrough && cfg.ipNames && host == null && target == null && kind == Dpi.NONE && !Dpi.isLocalAddress(server)) {
                // Ad görünmüyor: hedef IP'ye DNS cevaplarında eşlenen adlar hep engelliyse bağlantı kesilir.
                val e = flowAds
                val nm = if (e != null) IpNames.blocked(server, e) else null
                if (nm != null) {
                    blockedHosts.incrementAndGet()
                    FilterLive.note(nm, false)
                    AppAds.blocked(6, client, cport, server, sport, nm)
                    abort(true)
                    return
                }
            }
            val mh = cfg.mitm
            if (mh != null && !cfg.passthrough && kind == Dpi.TLS && host != null && (cfg.dpiOnLocal || !Dpi.isLocalAddress(server)) && mh.wants(host, client, cport, server, sport)) {
                mitmHost = host
                mitmCount.incrementAndGet()
                plan = -1; phase = RELAY; awaitDeadline = 0L
                closeChannel()                      // henüz bir şey yazılmadı: gerçek sunucuya açılan bağlantı bırakılır, yerel vekile yeni bağlantı açılır
                openUpstream()
                return
            }
            var canSplit = cfg.dpi && !cfg.passthrough && kind != Dpi.NONE && (cfg.dpiOnLocal || !Dpi.isLocalAddress(server))
            if (canSplit && cfg.dpiListedOnly && !dpiWanted(host, server)) { canSplit = false; listedSkipped.incrementAndGet() }
            if (canSplit && cfg.autoTtl && kind == Dpi.TLS) hopProbe?.request(server, sport)
            // Tüm yöntemleri az önce tükenmiş hedef: 11 yöntemi (her biri saniyeler) yeniden gezmek yerine düz aktar; süre dolunca yeniden denenir.
            if (canSplit && planner.isExhausted(hostKey, nowMs(), kind)) { canSplit = false; exhaustSkipped.incrementAndGet() }
            val retriable = canSplit && flight == firstLen && (kind == Dpi.TLS || http.get)
            // Denenemeyen uçuşta (POST…) yalnızca kanıtlanmış ya da en güvenli yöntem kullanılır; kurtarma şansı yoktur.
            plan = if (!canSplit) -1 else if (retriable) planner.first(hostKey, kind) else planner.firstSafe(hostKey, kind)
            phase = if (retriable) AWAIT else RELAY
            awaitDeadline = nowMs() + planner.waitMs(kind)
            writeFirst()
        }

        /**
         * TCP/53 üzerinden sabit bir sunucuya giden DNS sorusu süzgece takılırsa cevabı biz yazarız ve bağlantıyı kapatırız
         * (sorgu üst sunucuya hiç gitmez). Eksik, çok büyük ya da geçirilecek soruda false: akış olduğu gibi aktarılır.
         */
        private fun answerDnsOverTcp(cfg: GwConfig): Boolean {
            if (firstLen < 2 + Packets.DNS_HDR + 5) return false
            val ql = Packets.u16(first, 0)
            if (ql < Packets.DNS_HDR + 5 || ql > DnsForwarder.MAX_DNS || firstLen < 2 + ql) return false
            val n = dnsAnswer(flowAds, cfg.dropHttps, first, 2, ql, dnsOut, Packets.HDR, true)
            if (n <= 0) return false
            lastDnsBlocked?.let { AppAds.blocked(6, client, cport, server, sport, it) }
            dnsOut[Packets.HDR] = first[2]; dnsOut[Packets.HDR + 1] = first[3]
            val msg = ByteArray(2 + n)
            Packets.put16(msg, 0, n)
            System.arraycopy(dnsOut, Packets.HDR, msg, 2, n)
            sndBuf.add(msg, 0, msg.size)
            first = ByteArray(0); firstLen = 0
            phase = RELAY
            closeChannel()                      // sunucuya hiçbir şey gitmez
            upEof = true                        // cevaptan sonra FIN
            pump()
            return true
        }

        private fun writeFirst() {
            parts.clear(); partOff = 0; pauseUntil = 0L
            sentAt = nowMs()
            if (plan >= 0 && kind != Dpi.NONE) {
                val list = Dpi.split(kind, plan, first, firstLen)
                if (list.size > 1) splitCount.incrementAndGet()
                parts.addAll(list)
                for (p in list) awaitDeadline += p.delayMs          // bekleyen parçalar yanıt süresinden sayılmaz
            } else parts.add(Dpi.Part(first.copyOf(firstLen)))
            if (phase == RELAY) { first = ByteArray(0); }
            flushUp()
        }

        /** Bir kesinti belirtisi görüldü: puanı planlayıcıya yaz, yöntem değiştiyse say. Bağlantının kendisine dokunulmaz. */
        private fun noteCut(c: CutWatch.Cut) {
            if (c == CutWatch.Cut.NONE) return
            cuts.incrementAndGet()
            val nxt = planner.cut(hostKey, kind, plan, if (c == CutWatch.Cut.STALL) 2 else 1, nowMs())
            if (nxt >= 0) { cutSwitched.incrementAndGet(); Journal.warn("DPI", "kesinti belirtisi: hedefin yöntemi $plan → $nxt") }
        }

        private fun retryOrFail() {
            val nxt = if (plan >= 0) planner.next(kind, plan) else -1
            if (nxt < 0) {
                planner.failed(hostKey, kind); planner.exhaust(hostKey, nowMs(), kind); if (kind == Dpi.TLS && plan >= 0) recentDpiFail++
                if (kind == Dpi.TLS && plan >= 0 && nowMs() - exhaustLogAt > 30_000L) { exhaustLogAt = nowMs(); Journal.warn("DPI", "tüm TLS yöntemleri tükendi: hedef ${Dpi.EXHAUST_MS / 1000} sn düz aktarılır") }
                abort(true); return
            }
            retried.incrementAndGet()
            if (plan in 0..15) triedMask = triedMask or (1 shl plan)
            plan = nxt
            closeChannel()
            parts.clear(); oobPending = false; pauseUntil = 0L
            awaitDeadline = nowMs() + planner.waitMs(kind)
            openUpstream()
        }

        // ---- sunucuya yazma / okuma

        fun flushUp() {
            val c = ch ?: return
            if (!connected) return
            try {
                while (parts.isNotEmpty()) {
                    val part = parts.first()
                    if (part.delayMs > 0 && partOff == 0) {
                        // Gecikmeli parça: süre dolana dek bekle (sonraki parçalar ve veri de bekler; sıra bozulmaz). tick() süre dolunca yeniden çağırır.
                        val now = nowMs()
                        if (pauseUntil == 0L) pauseUntil = now + part.delayMs
                        if (now < pauseUntil) { if (pauseUntil < nextHedgeAt) nextHedgeAt = pauseUntil; setInterest(); return }
                        pauseUntil = 0L
                        parts[0] = Dpi.Part(part.data, part.oobAfter, part.lowTtl, 0, part.fake)
                    }
                    if (part.fake != null && partOff == 0 && fakeSend != null) {
                        // Sahte ClientHello: yalnızca TTL gerçekten düşürülebildiyse gönderilir; her durumda TTL geri alınır.
                        parts[0] = Dpi.Part(part.data, part.oobAfter, part.lowTtl)      // tekrar denenmesin
                        val ft = fakeTtlFor(server)
                        if (ft > 0 && setTtl(c.socket(), ft)) {
                            val sent = try { fakeSend(c.socket(), part.fake, part.data) } catch (_: Exception) { -1 } finally { setTtl(c.socket(), 64) }
                            if (sent > 0) { partOff = sent.coerceAtMost(part.data.size); fakes.incrementAndGet() }
                        }
                    }
                    val bb = ByteBuffer.wrap(part.data, partOff, part.data.size - partOff)
                    // "disorder": ilk parça çok düşük TTL ile çıkar; hemen ardından TTL normale döner (yeniden iletim normal gider).
                    val low = part.lowTtl && partOff == 0 && setTtl(c.socket(), 1)
                    val w = try { c.write(bb) } finally { if (low) setTtl(c.socket(), 64) }
                    partOff += w
                    if (partOff < part.data.size) { setInterest(); return }
                    if (part.oobAfter) {
                        try { c.socket().sendUrgentData(0) } catch (_: Exception) { /* bu platformda yok: yalnızca bölme */ }
                    }
                    parts.removeFirst(); partOff = 0
                }
                if (phase != AWAIT) {
                    while (!toUp.isEmpty) {
                        val bb = ByteBuffer.wrap(toUp.array(), toUp.start(), toUp.size)
                        val w = c.write(bb)
                        if (w <= 0) { setInterest(); return }
                        toUp.drop(w)
                        cw?.up(nowMs(), w)
                        needAck = true
                    }
                }
                if (clientFin && toUp.isEmpty && parts.isEmpty() && !upShut && phase != AWAIT && phase != COLLECT && phase != PRE) {
                    upShut = true
                    try { c.socket().shutdownOutput() } catch (_: Exception) {}
                }
                setInterest()
            } catch (e: IOException) {
                if (phase == AWAIT && !gotData) retryOrFail() else abort(true)
            }
        }

        private fun setInterest() {
            val k = key ?: return
            if (!k.isValid) return
            var ops = 0
            if (!connected) ops = SelectionKey.OP_CONNECT
            else {
                if (!upEof && !readBlocked) ops = ops or SelectionKey.OP_READ
                if (pauseUntil == 0L && (parts.isNotEmpty() || (!toUp.isEmpty && phase != AWAIT))) ops = ops or SelectionKey.OP_WRITE
            }
            try { if (k.interestOps() != ops) k.interestOps(ops) } catch (_: Exception) {}
        }

        private fun readUp() {
            val c = ch ?: return
            var loops = 0
            while (loops++ < 4) {
                val room = sndBuf.free
                if (room <= 0) { readBlocked = true; setInterest(); return }
                readBuf.clear()
                readBuf.limit(minOf(readBuf.capacity(), room))
                val n = try { c.read(readBuf) } catch (e: IOException) {
                    if (phase == AWAIT && !gotData) retryOrFail()
                    else {
                        // Kesinti: yalnızca sıfırlama ("Connection reset…") ve yalnızca havada iş varken; zaman aşımı/ağ hatası değil.
                        val w = cw
                        if (w != null && (e.message ?: "").contains("reset", ignoreCase = true)) noteCut(w.reset())
                        abort(true)
                    }
                    return
                }
                if (n < 0) {
                    if (phase == AWAIT && !gotData) { retryOrFail(); return }
                    upEof = true
                    setInterest()
                    pump(); checkDone()
                    return
                }
                if (n == 0) break
                if (!gotData) {
                    // TLS'e cevap TLS kaydı değilse (düz metin engel sayfası) DPI cihazı araya girmiştir: bu bir başarı sayılmaz,
                    // sıradaki yöntem denenir. Son yöntemde cevap olduğu gibi aktarılır (düz metin konuşan gerçek bir sunucu olabilir).
                    if (phase == AWAIT && kind == Dpi.TLS && !Dpi.looksLikeTlsReply(readBuf.array(), n) && planner.next(kind, plan) >= 0) {
                        injected.incrementAndGet()
                        retryOrFail()
                        return
                    }
                    // Düz HTTP'ye gelen yönlendirme bilinen bir engel sayfasına gidiyorsa (enjekte edilmiş) başarı sayılmaz.
                    if (phase == AWAIT && kind == Dpi.HTTP && plan >= 0 && Dpi.looksLikeBlockRedirect(readBuf.array(), n) && planner.next(kind, plan) >= 0) {
                        injected.incrementAndGet()
                        retryOrFail()
                        return
                    }
                    gotData = true
                    if (phase == AWAIT) {
                        if (kind == Dpi.TLS && plan >= 0) cw = CutWatch(nowMs(), config.cutStallMs, config.cutNoreplyMs)
                        if (kind == Dpi.TLS && plan >= 0) recentDpiOk++
                        val took = if (sentAt > 0L) nowMs() - sentAt else -1L
                        planner.worked(hostKey, kind, plan, triedMask, took)
                        if (kind == Dpi.TLS && plan >= 0 && triedMask != 0) noteBypass(server)
                        config.planMemory?.put(netKey, kind, plan)
                        if (kind == Dpi.TLS && plan >= 0) config.planMemory?.putSite(netKey, Dpi.siteKey(hostKey), plan)
                        if (kind == Dpi.TLS && plan in 0 until 16 && triedMask != 0 && nowMs() - dpiLogAt[plan] > 60_000L) {
                            dpiLogAt[plan] = nowMs()
                            Journal.info("DPI", "yöntem $plan çalıştı (önce ${Integer.bitCount(triedMask)} yöntem başarısız), ilk cevap $took ms")
                        }
                        phase = RELAY
                        first = ByteArray(0)
                        flushUp()
                    } else if (phase == PRE || phase == COLLECT) {
                        // sunucu önce konuştu (SMTP, SSH...): toplananı olduğu gibi akıt
                        startFirst(true)
                    }
                }
                bytesDown.addAndGet(n.toLong())
                cw?.down(readBuf.array(), 0, n, nowMs())
                sndBuf.add(readBuf.array(), 0, n)
                last = nowMs()
                if (n < readBuf.limit()) break
            }
            pump()
        }

        // ---- istemciye gönderme

        fun pump() {
            if (!synAcked || state != ESTAB) return
            var guard = 0
            while (guard++ < 64) {
                if (finSent) break
                val inflight = sndNxt - sndUna
                val unsent = sndBuf.size - inflight
                val wnd = peerWnd - inflight
                if (unsent > 0 && wnd > 0) {
                    val seg = minOf(mss, unsent, wnd)
                    val n = segment(sndNxt, inflight, seg, Gw.ACK or (if (seg == unsent) Gw.PSH else 0))
                    emit(n)
                    sndNxt += seg
                    if (rtoAt == 0L) rtoAt = nowMs() + rto
                    needAck = false
                } else if (unsent == 0 && upEof && !finSent) {
                    val n = Gw.tcp(outBuf, v6, server, client, sport, cport, sndNxt, rcvNxt, Gw.FIN or Gw.ACK, window(), null, 0, 0)
                    emit(n)
                    finSent = true; sndNxt++
                    if (rtoAt == 0L) rtoAt = nowMs() + rto
                    needAck = false
                } else break
            }
        }

        private fun segment(seq: Int, from: Int, len: Int, flags: Int): Int {
            val tmp = segTmp
            sndBuf.copy(from, tmp, 0, len)
            return Gw.tcp(outBuf, v6, server, client, sport, cport, seq, rcvNxt, flags, window(), tmp, 0, len)
        }

        private val segTmp = ByteArray(1500)

        private fun retransmit() {
            if (state != ESTAB || !synAcked) return
            val inflightData = (sndNxt - sndUna) - (if (finSent && !finAcked) 1 else 0)
            if (inflightData > 0) {
                val seg = minOf(mss, inflightData)
                emit(segment(sndUna, 0, seg, Gw.ACK))
            } else if (finSent && !finAcked) {
                emit(Gw.tcp(outBuf, v6, server, client, sport, cport, sndNxt - 1, rcvNxt, Gw.FIN or Gw.ACK, window(), null, 0, 0))
            }
        }

        /** Son duyurulan pencere 0 muydu? (Ortak bellek boşalınca istemciye pencere güncellemesi gönderilir.) */
        private var zeroWindow = false

        private fun window(): Int {
            val w = maxOf(0, minOf(65535, toUp.free))
            zeroWindow = w == 0
            return w
        }

        fun sendAck() {
            val n = Gw.tcp(outBuf, v6, server, client, sport, cport, sndNxt, rcvNxt, Gw.ACK, window(), null, 0, 0)
            emit(n)
            needAck = false
        }

        fun flushAck() { if (needAck && state == ESTAB) sendAck() }

        // ---- zamanlayıcı ve kapanış

        fun tick(now: Long) {
            when (state) {
                CONNECTING -> if (!connected) {
                    if (hedgeAt != 0L && now >= hedgeAt) startHedge()
                    else if (hedgeAt != 0L && hedgeAt < nextHedgeAt) nextHedgeAt = hedgeAt
                    if (now > synAckAt) connectFailed()
                }
                CLOSED -> if (closedAt != 0L && now - closedAt > LINGER_MS) forget(this)
                else -> {
                    if (!synAcked && now > synAckAt) {
                        if (++synAckTries > 3) { abort(false); return }
                        synAckAt = now + 1000; sendSynAck()
                    }
                    if (!connected && hedgeAt != 0L) { if (now >= hedgeAt) startHedge() else if (hedgeAt < nextHedgeAt) nextHedgeAt = hedgeAt }
                    if ((phase == COLLECT) && now > firstDeadline) firstTimeout(now)
                    // Ortak bellek tavanı yüzünden durdurulan okuma/pencere: tavan boşaldıysa yeniden aç. (Kendi kuyruğu boş
                    // bir bağlantı onay almayacağı için başka bir şey onu uyandırmaz.)
                    if (readBlocked && sndBuf.free > 0 && sndBuf.size < SND_CAP / 2) { readBlocked = false; setInterest() }
                    if (zeroWindow && synAcked && toUp.free > 0) sendAck()
                    // Güvenlik ağı: gönderilmeyi bekleyen veri varsa (ör. bellek tavanı boşaldı) bir paket gelmesini beklemeden akıt.
                    if (synAcked && sndBuf.size > sndNxt - sndUna) pump()
                    if (pauseUntil != 0L) { if (now >= pauseUntil) flushUp() else if (pauseUntil < nextHedgeAt) nextHedgeAt = pauseUntil }
                    if (phase == AWAIT && !gotData && now > awaitDeadline) retryOrFail()
                    cw?.let { noteCut(it.poll(now)) }
                    if (rtoAt != 0L && now >= rtoAt && sndNxt != sndUna) {
                        if (++tries > MAX_TRIES) { abort(true); return }
                        retransmit()
                        rto = minOf(rto * 2, RTO_MAX)
                        rtoAt = now + rto
                    }
                    if (now - last > config.tcpIdleMs) abort(true)
                }
            }
        }

        private fun checkDone() {
            if (state == ESTAB && finSent && finAcked && clientFin) {
                // Bizim FIN'imiz önce gitti, istemcinin FIN'i en son geldi: onu onaylamadan kapanırsak istemci LAST_ACK'ta kalır, FIN'ini yeniden
                // yollar ve ancak RST ile kurtulur (RFC 793 §3.5: FIN her zaman onaylanır). Son onay burada, kapanıştan önce gider.
                if (needAck) sendAck()
                shutdown()
            }
        }

        /**
         * Beklenmeyen bir hatadan sonra akışı ne olursa olsun kapatır. İstemci beklemesin diye RST gönderilir (bağlanma aşamasındaysa da);
         * kapanış sırasında yeni bir hata çıksa bile tablo/sayaç yolunda kalır ([tick] kapalı akışı [forget] eder).
         */
        fun failSafe() {
            try {
                if (state == CONNECTING) {
                    emit(Gw.tcp(outBuf, v6, server, client, sport, cport, 0, rcvNxt, Gw.RST or Gw.ACK, 0, null, 0, 0))
                    shutdown()
                } else abort(true)
            } catch (_: Throwable) {
                try { shutdown() } catch (_: Throwable) {}
            }
        }

        /** Bağlantıyı bitir. [rst] doğruysa istemciye RST gider. */
        fun abort(rst: Boolean) {
            if (state == CLOSED) return
            if (rst && state == ESTAB) {
                val n = Gw.tcp(outBuf, v6, server, client, sport, cport, sndNxt, rcvNxt, Gw.RST or Gw.ACK, 0, null, 0, 0)
                emit(n)
            }
            shutdown()
        }

        private fun shutdown() {
            closeChannel()
            state = CLOSED
            closedAt = nowMs()
            sndBuf.clear(); toUp.clear(); parts.clear()
            first = ByteArray(0)
        }

        fun closeChannel() {
            dropHedge()
            try { key?.cancel() } catch (_: Exception) {}
            try { ch?.close() } catch (_: Exception) {}
            key = null; ch = null; connected = false
        }
    }

    // ------------------------------------------------------------------ UDP

    /**
     * Reklam+ açıkken UDP/443 (QUIC): yeni bir akışın ilk paketi QUIC v1 Initial'sa SNI okunur. Ad engelli bir reklam/izleyici
     * (ya da engelleme açıksa bilinen bir DoH sunucusu) ise akış düşürülür. Ad okunamazsa (0-RTT, parçalı Initial, tanınmayan
     * biçim) akış da düşürülür: istemci TCP/TLS'e döner ve orada ad görünür. Zaten açılmış akışların paketleri sorgulanmaz.
     */
    private fun quicAllowed(cfg: GwConfig, engine: FilterEngine?, v6: Boolean, src: ByteArray, dst: ByteArray, sport: Int, p: ByteArray, off: Int, len: Int): Boolean {
        val dport = 443
        if (if (v6) udp6[key6(dst, dport, sport)] != null else udp4[key4(dst, dport, sport)] != null) return true
        if (engine == null) return true
        val name = QuicInitial.peekSni(p, off, len) ?: return false
        if (cfg.blockDoh && Dpi.isDohHost(name)) return false
        val ok = engine.verdictOf(name) == FilterVerdict.PASS
        if (!ok) AppAds.blocked(17, src, sport, dst, dport, name)
        return ok
    }

    /** QUIC Initial'ın SNI'si engelli site listesinde mi ([BlockedSites])? Liste boşsa hiçbir şey çözülmez. */
    private fun quicListed(p: ByteArray, off: Int, len: Int): Boolean {
        if (!BlockedSites.any()) return false
        val name = QuicInitial.peekSni(p, off, len) ?: return false
        return BlockedSites.matches(name)
    }

    private fun onUdp(p: ByteArray, u: Int, total: Int, v6: Boolean, src: ByteArray, dst: ByteArray) {
        val sport = Packets.u16(p, u); val dport = Packets.u16(p, u + 2)
        val dLen = minOf(Packets.u16(p, u + 4), total - u) - 8
        if (dLen < 0) return
        val off = u + 8
        val cfg = config
        if (dport == 53 && LeakProbe.active) LeakProbe.check(p, off, dLen)
        if (AppFirewall.armed) {
            // Uygulama güvenlik duvarı: yeni akış ya da kural/ağ değişimi sonrası ilk paket denetlenir; engelliyse sessizce atılır.
            val ex = if (v6) udp6[key6(dst, dport, sport)] else udp4[key4(dst, dport, sport)]
            val g = AppFirewall.gen
            if (ex == null || ex.fwGen != g) {
                if (AppFirewall.blocked(17, src, sport, dst, dport)) { fwBlocked.incrementAndGet(); ex?.close(); return }
                if (ex != null) ex.fwGen = g
            }
        }
        var adsMemo: FilterEngine? = null
        var adsDone = false
        fun ads(): FilterEngine? { if (!adsDone) { adsMemo = adsFor(cfg, 17, src, sport, dst, dport); adsDone = true }; return adsMemo }
        if (!cfg.passthrough) {
            if (dport == 443 && (cfg.blockQuic || (cfg.dpi && cfg.quicSelective && (bypassSeen(dst) || quicListed(p, off, dLen))) || (cfg.quicWithAds && !quicAllowed(cfg, ads(), v6, src, dst, sport, p, off, dLen)))) { quicDropped.incrementAndGet(); return }
            if ((dport == 853 || (dport == 443 && Dpi.isDohAddress(dst))) && cfg.blockDoh) { dohBlocked.incrementAndGet(); return }
            if (dport == 53 && cfg.adsDns) {
                if (answerBlocked(ads(), cfg.dropHttps, p, off, dLen, v6, src, dst, sport)) return
            }
        }
        var f = if (v6) udp6[key6(dst, dport, sport)] else udp4[key4(dst, dport, sport)]
        if (f == null) {
            if (flowsUdp.get() >= config.maxUdp && !evictUdp()) return
            if (!admitFlow()) return
            if (!cfg.passthrough && cfg.ipNames && dport != 53 && dport != 443 && !Dpi.isLocalAddress(dst)) {
                val e = ads()
                val nm = if (e != null) IpNames.blocked(dst, e) else null
                if (nm != null) { blockedHosts.incrementAndGet(); AppAds.blocked(17, src, sport, dst, dport, nm); return }
            }
            f = UdpFlow(v6, src, dst, sport, dport)
            f.fwGen = AppFirewall.gen
            if (!f.open()) return
            if (v6) udp6[key6(dst, dport, sport)] = f else udp4[key4(dst, dport, sport)] = f
            flowsUdp.incrementAndGet()
        }
        f.send(p, off, dLen)
    }

    /**
     * Düz DNS sorgusu kendimiz mi yanıtlanmalı? Evetse cevabı biz üretip tünele yazarız (DNS sağlayıcı ne olursa olsun):
     * HTTPS/SVCB kaydı istenmişse ([dropHttps]) "kayıt yok"; biçimi bozuk sorguya "biçim hatası"; engelli ada engelleme cevabı
     * (kurulamazsa "reddedildi": engelli ad ASLA üst sunucuya gitmez).
     */
    private fun answerBlocked(e: FilterEngine?, dropHttps: Boolean, p: ByteArray, off: Int, len: Int, v6: Boolean, client: ByteArray, server: ByteArray, cport: Int): Boolean {
        if (len < Packets.DNS_HDR + 5 || len > DnsForwarder.MAX_DNS) return false     // EDNS0 dolgulu uzun sorular da süzülür
        val n = dnsAnswer(e, dropHttps, p, off, len, dnsOut, Packets.HDR, true)
        if (n <= 0) return false
        lastDnsBlocked?.let { AppAds.blocked(17, client, cport, server, 53, it) }
        dnsOut[Packets.HDR] = p[off]; dnsOut[Packets.HDR + 1] = p[off + 1]
        emit(Gw.udp(outBuf, v6, server, client, 53, cport, dnsOut, Packets.HDR, n))
        return true
    }

    /**
     * Gelen DNS sorgusu ([q], [off], [len]) için süzgecin vereceği cevabı [o] içine [oOff] konumundan yazar ve boyunu döner;
     * sorgu geçirilecekse 0 (kimlik cevaba yazılmaz: çağıran koyar). Sayaçlar ve son engellenenler burada güncellenir.
     */
    private fun dnsAnswer(e: FilterEngine?, dropHttps: Boolean, q: ByteArray, off: Int, len: Int, o: ByteArray, oOff: Int, count: Boolean): Int {
        lastDnsBlocked = null
        if (dropHttps && FilterEngine.isHttpsQuery(q, off, len)) {
            val qEnd = Dns.questionEnd(q, off, len)
            val n = if (qEnd > 0) FilterEngine.buildReply(q, off, qEnd, o, oOff) else -1
            if (n > 0) return n
        }
        if (e == null) return 0
        if (e.isMalformed(q, off, off + len)) {
            val n = FilterEngine.buildFormerr(q, off, o, oOff)
            return if (n > 0) n else 0
        }
        val v = e.verdict(q, off, off + len)
        if (v == FilterVerdict.PASS) return 0
        val qEnd = Dns.questionEnd(q, off, len)
        if (qEnd <= 0) return 0
        val canary = v == FilterVerdict.CANARY
        var n = if (canary) FilterEngine.buildNxdomain(q, off, qEnd, o, oOff) else FilterEngine.buildBlocked(q, off, qEnd, o, oOff)
        if (n <= 0) n = FilterEngine.buildRefused(q, off, o, oOff)
        if (n <= 0) return 0
        if (!canary && count) {                          // sayaç, cevap yollanmadan önce artar: cevabı gören sayaçta da görür
            dnsBlocked.incrementAndGet()
            FilterLive.note(e.lastName(), v == FilterVerdict.USER)
            lastDnsBlocked = e.lastName()
        }
        return n
    }

    /** Sabit bir DNS sunucusundan gelen cevabın CNAME zinciri engelli bir adda bitiyorsa cevabı engelleme cevabıyla değiştirir (yerinde). Yeni boyu döner. */
    private fun guardDnsReply(b: ByteArray, n: Int, e: FilterEngine?, client: ByteArray, cport: Int, server: ByteArray, sport: Int): Int {
        if (e == null) return n
        var v = e.cnameVerdict(b, 0, n)
        // Yeniden bağlama koruması (genel ad -> yerel ağ adresi): iç yönlendirici ([CnameGuard]) ile aynı kural.
        if (v == FilterVerdict.PASS && FilterRuntime.rebind && e.rebindVerdict(b, 0, n)) v = FilterVerdict.LIST
        if (v == FilterVerdict.PASS) return n
        val qEnd = Dns.questionEnd(b, 0, n)
        if (qEnd <= 0) return n
        val id0 = b[0]; val id1 = b[1]
        val asked = CnameGuard.queryName(b, 0, qEnd)       // kayıt, CNAME hedefi değil sorulan ad olmalı
        var m = FilterEngine.buildBlocked(b, 0, qEnd, b, 0)
        if (m <= 0) { m = FilterEngine.buildRefused(b, 0, b, 0); b[0] = id0; b[1] = id1 }
        if (m <= 0) return n
        dnsBlocked.incrementAndGet()
        FilterLive.note(asked, v == FilterVerdict.USER)
        AppAds.blocked(17, client, cport, server, sport, asked)
        return m
    }

    private inner class UdpFlow(val v6: Boolean, val client: ByteArray, val server: ByteArray, val cport: Int, val sport: Int) {
        var fwGen = 0
        var ch: DatagramChannel? = null
        var key: SelectionKey? = null
        var last = nowMs()

        fun open(): Boolean = try {
            val c = DatagramChannel.open()
            ch = c
            c.configureBlocking(false)
            if (!protectUdp(c.socket())) throw IOException("protect")
            val p = config.nat64
            val dst = if (server.size == 4 && config.noV4 && p != null && p.size == 12) config.nat64Addr(p, server) else InetAddress.getByAddress(server)
            c.connect(InetSocketAddress(dst, sport))
            key = c.register(selector, SelectionKey.OP_READ, this)
            true
        } catch (_: Exception) { closeChannel(); false }       // tabloya hiç girmedi: close() sayaçtan düşerdi (sayaç eksiye kayıp sınırı işlevsiz bırakırdı)

        private var decoyChecked = false

        /** Akışın ilk paketi parmak izine uyuyorsa, gerçek paketten ÖNCE düşük TTL'li rastgele paketler gönderir. */
        private fun decoys(p: ByteArray, off: Int, len: Int) {
            decoyChecked = true
            if (!config.udpDecoy || !config.dpi || config.passthrough) return
            if (!UdpDecoy.applies(sport, p, off, len)) return
            val c = ch ?: return
            val sock = c.socket()
            if (!setUdpTtl(sock, UdpDecoy.TTL)) return                // TTL ayarlanamıyorsa sahte paket yok: sunucuya ulaşmasın
            try {
                val junk = ByteArray(len)
                for (i in 0 until UdpDecoy.COUNT) {
                    random.nextBytes(junk)
                    junk[0] = 0xFF.toByte()                            // geçerli STUN/Discord başlığı olmasın
                    if (c.write(ByteBuffer.wrap(junk)) > 0) udpDecoys.incrementAndGet()
                }
            } catch (_: Exception) {
            } finally { setUdpTtl(sock, 64) }
        }

        /** UDP/443 akışının ilk paketi QUIC v1 Initial ise: önce düşük TTL'li sahte kopya, sonra çerçeveleri ters sırada yeniden kurulmuş gerçek paket. */
        private fun quicFirst(p: ByteArray, off: Int, len: Int): Boolean {
            if (!config.quicSplit || !config.dpi || config.passthrough || sport != config.quicPort || len < 1200) return false
            val c = ch ?: return false
            val re = QuicInitial.reorder(p, off, len) ?: return false
            val fk = QuicInitial.fake(p, off, len)
            val sock = c.socket()
            if (config.autoTtl) hopProbe?.request(server, 443)
            val ft = fakeTtlFor(server)
            if (fk != null && ft > 0 && setUdpTtl(sock, ft)) {
                try { if (c.write(ByteBuffer.wrap(fk)) > 0) quicFakes.incrementAndGet() } catch (_: Exception) {
                } finally { setUdpTtl(sock, 64) }
            }
            try { c.write(ByteBuffer.wrap(re)); bytesUp.addAndGet(re.size.toLong()); quicSplits.incrementAndGet() } catch (_: Exception) { return false }
            return true
        }

        fun send(p: ByteArray, off: Int, len: Int) {
            last = nowMs()
            if (!decoyChecked) {
                decoys(p, off, len)
                if (quicFirst(p, off, len)) return
            }
            try { ch?.write(ByteBuffer.wrap(p, off, len)); bytesUp.addAndGet(len.toLong()) } catch (_: Exception) { }
        }

        fun onKey(k: SelectionKey) {
            val c = ch ?: return
            var n = 0
            while (n++ < 8) {
                readBuf.clear()
                // receive(): sıfır baytlık bir datagramı da tüketip (RFC 768'de geçerli) döner; kuyrukta bir şey yoksa null.
                // read() ise iki durumda da 0 döndürdüğü için boş yanıt sessizce düşüyordu.
                val from = try { c.receive(readBuf) } catch (_: IOException) { close(); return }
                if (from == null) break
                val r = readBuf.position()
                last = nowMs()
                val max = Gw.MTU - (if (v6) 48 else 28)
                if (r > max) continue                                   // MTU'dan büyük: IP parçalama yok, atılır
                var rl = r
                if (r > 0 && sport == 53 && config.adsDns && !config.passthrough) rl = guardDnsReply(readBuf.array(), r, adsFor(config, 17, client, cport, server, sport), client, cport, server, sport)   // gizli izleyici (CNAME) engeli
                val total = Gw.udp(outBuf, v6, server, client, sport, cport, readBuf.array(), 0, rl)
                emit(total)
                bytesDown.addAndGet(r.toLong())
            }
        }

        fun close() {
            val had = ch != null
            closeChannel()
            if (had) {
                if (v6) { if (udp6[key6(server, sport, cport)] === this) udp6.remove(key6(server, sport, cport)) }
                else if (udp4[key4(server, sport, cport)] === this) udp4.remove(key4(server, sport, cport))
                flowsUdp.decrementAndGet()
            }
        }

        fun closeChannel() {
            try { key?.cancel() } catch (_: Exception) {}
            try { ch?.close() } catch (_: Exception) {}
            key = null; ch = null
        }
    }

    private companion object {
        const val BYPASS_MAX = 256
        const val BYPASS_TTL_MS = 30 * 60_000L
        const val INBOX_MAX = 4096
        /** Yeni bağlantı (SYN) kuyruğu sınırı ve tur başına işlenen en çok SYN. */
        const val FRESH_MAX = 1024
        const val FRESH_PER_ROUND = 256
        const val TICK_MS = 200L
        const val IDLE_WAIT_MS = 1000L
        const val MAX_TCP = 1500
        const val LINGER_MS = 3000L
        const val CONNECT_MS = 12_000L
        const val SND_CAP = 96 * 1024
        /** Tüm TCP akışlarının kuyruklarının toplam tavanı (bkz. [MemBudget]). */
        const val MEM_BUDGET = 24 * 1024 * 1024
        const val UP_CAP = 128 * 1024
        const val FIRST_MAX = 16 * 1024
        const val FIRST_WAIT_MS = 400L
        /** Tanınmış (TLS/HTTP) ama eksik ilk uçuşun, ad denetimi varken tamamlanması için en çok bekleme: ötesinde bağlantı kesilir. */
        const val FIRST_HARD_MS = 3000L
        const val RTO_INIT = 250L
        const val RTO_MAX = 4000L
        const val MAX_TRIES = 9
        const val MAX_HEDGES = 48
    }
}

// TCP akış durumları ve ilk uçuş evreleri
private const val CONNECTING = 0
private const val ESTAB = 1
private const val CLOSED = 2
private const val PRE = 0        // henüz istemci verisi yok
private const val COLLECT = 1    // ilk uçuş toplanıyor
private const val AWAIT = 2      // ilk uçuş yazıldı, ilk cevap bekleniyor (yeniden denenebilir)
private const val RELAY = 3      // düz aktarım

/**
 * Hedef çok noktaya ya da genel yayına mı gidiyor? IPv6: ff00::/8 (çok noktaya). IPv4: 224.0.0.0/4 (çok noktaya) ya da tam 255.255.255.255
 * (sınırlı genel yayın). Eski koşul önceliği belirsizdi ve "255.x.y.255" gibi adreslerin hepsini de eliyordu; tam eşleşme aranır.
 * Alt ağa yönelik genel yayın (ör. 192.168.1.255) bu denetimde yoktur: ağ maskesi bilinmeden ayırt edilemez.
 */
internal fun isMulticastOrBroadcast(v6: Boolean, dst: ByteArray): Boolean =
    (if (v6) AddrClass.v6(dst, 0) else AddrClass.v4(dst, 0)) and (AddrClass.MULTICAST or AddrClass.BROADCAST) != 0
