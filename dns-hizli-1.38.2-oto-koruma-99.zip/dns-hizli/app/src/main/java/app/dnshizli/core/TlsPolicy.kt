package app.dnshizli.core

import javax.net.ssl.SSLPeerUnverifiedException

/**
 * El sıkışma bittikten sonra pazarlık edilen TLS sürümünü ve şifre takımını denetler (savunma derinliği). Soket zaten yalnızca
 * TLS 1.2/1.3'e açılır; yine de sunucunun ya da araya girenin seçtiği sonuç doğrulanır ve şunlardan biri çıkarsa bağlantı
 * kurulmaz (sertifika hatası gibi "güven hatası" sayılır):
 *  - TLS 1.2/1.3 dışı sürüm,
 *  - ileri gizlilik vermeyen anahtar değişimi (statik RSA `TLS_RSA_…`, statik DH/ECDH): kaydedilen DNS trafiği sunucu anahtarı
 *    ele geçirilince sonradan çözülebilirdi,
 *  - kırık ya da boş algoritmalar (NULL, anonim, EXPORT, RC4, DES/3DES, RC2, IDEA, SEED, MD5),
 *  - TLS 1.3'te AES-GCM/ChaCha20/CCM dışı takım,
 *  - TLS 1.2'de AEAD olmayan (CBC + HMAC) takım: "önce MAC sonra şifre" yapısı dolgu/zamanlama saldırılarına açıktır (Lucky13 sınıfı).
 * Gerçek sağlayıcılar (Cloudflare, Google, Quad9, AdGuard…) ECDHE + AEAD ya da TLS 1.3 seçer; bu denetim onları etkilemez.
 */
internal object TlsPolicy {
    private val BROKEN = listOf("_NULL_", "_ANON_", "EXPORT", "_RC4_", "_DES_", "_DES40_", "_3DES_", "_RC2_", "_IDEA_", "_SEED_", "_MD5")

    /** Kabul edilmiyorsa nedeni (kısa metin), kabulse null. */
    fun check(protocol: String?, suite: String?): String? {
        if (protocol != "TLSv1.3" && protocol != "TLSv1.2") return "TLS sürümü: ${protocol ?: "bilinmiyor"}"
        val s = suite?.uppercase(java.util.Locale.ROOT)
        if (s.isNullOrEmpty()) return "şifre takımı bilinmiyor"
        for (w in BROKEN) if (w in s) return "zayıf şifre takımı: $suite"
        if (protocol == "TLSv1.3") {
            return if (s.startsWith("TLS_AES_") || s.startsWith("TLS_CHACHA20_")) null else "beklenmeyen TLS 1.3 takımı: $suite"
        }
        // TLS 1.2: ileri gizlilik (ECDHE/DHE) ve AEAD şart
        if (s.startsWith("TLS_RSA_") || s.startsWith("SSL_RSA_") || s.startsWith("TLS_DH_") || s.startsWith("TLS_ECDH_")) return "ileri gizlilik yok: $suite"
        if (!(s.contains("_GCM_") || s.contains("CHACHA20_POLY1305") || s.endsWith("_CCM") || s.contains("_CCM_"))) return "AEAD olmayan takım: $suite"
        return null
    }

    /**
     * El sıkışmadan ÖNCE soketi kısıtlar: yalnızca TLS 1.2/1.3 ve [check]'ten geçen takımlar teklif edilir. Böylece zayıf takım hiç
     * önerilmez (araya giren sürüm/takım düşürmesi yapamaz); el sıkışmadan sonraki [require] ikinci kilit olarak kalır.
     * Süzgeçten hiçbir şey geçmezse (beklenmeyen sağlayıcı) varsayılan bırakılır: [require] yine reddeder.
     */
    fun harden(ssl: javax.net.ssl.SSLSocket) {
        val protos = ssl.supportedProtocols.filter { it == "TLSv1.3" || it == "TLSv1.2" }
        if (protos.isNotEmpty()) ssl.enabledProtocols = protos.toTypedArray()
        val suites = ssl.supportedCipherSuites.filter { cs ->
            if (cs.startsWith("TLS_AES_") || cs.startsWith("TLS_CHACHA20_")) check("TLSv1.3", cs) == null else check("TLSv1.2", cs) == null
        }
        if (suites.isNotEmpty()) ssl.enabledCipherSuites = suites.toTypedArray()
    }

    fun acceptable(protocol: String?, suite: String?): Boolean = check(protocol, suite) == null

    /** [check] reddederse güven hatası fırlatır ([SSLPeerUnverifiedException]: sertifika hatası gibi sayılır, yedek sunucuya geçilir). */
    fun require(protocol: String?, suite: String?) {
        check(protocol, suite)?.let { throw SSLPeerUnverifiedException(it) }
    }
}
