package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.Random

/**
 * Sağlamlaştırma: DPI ayrıştırıcı/bölücüleri, ağ geçidi paket girişi ve DNS filtresi rastgele / bozuk girdiyle taranır.
 * Beklenti: hiçbir girdi istisna fırlatmaz, bölücüler boş parça üretmez ve (bölünebilen yöntemlerde) veriyi bozmaz,
 * ağ geçidi taramadan sonra da çalışır.
 */
private class GatewayFuzzRig {
    val gw = Gateway({ _, _, _ -> }, setTtl = { _, _ -> false })
    init { gw.start() }
    fun close() = gw.stop()
}

fun runFuzzTests() {
    val rnd = Random(777)
    val hello = testHello("fuzz.example.org")
    val real = hello
    val req = "GET /a HTTP/1.1\r\nHost: fuzz.example.org\r\nUser-Agent: x\r\nAccept: */*\r\n\r\n".toByteArray()

    fun mutate(src: ByteArray): ByteArray {
        val x = src.copyOf()
        when (rnd.nextInt(4)) {
            0 -> repeat(1 + rnd.nextInt(6)) { x[rnd.nextInt(x.size)] = rnd.nextInt().toByte() }
            1 -> { val i = rnd.nextInt(x.size); x[i] = (if (rnd.nextBoolean()) 0xFF else 0).toByte() }
            2 -> { val a = rnd.nextInt(x.size); val b = rnd.nextInt(x.size); val t = x[a]; x[a] = x[b]; x[b] = t }
            else -> {}
        }
        return x
    }

    T.group("Sağlamlık: DPI ayrıştırıcıları ve bölücüleri (rastgele girdi)")
    run {
        var thrown: Throwable? = null; var where = ""
        var empty = 0; var lost = 0; var runs = 0
        val h = Dpi.Hello(); val hi = Dpi.HttpInfo()
        repeat(120_000) {
            val tls = rnd.nextBoolean()
            val buf = when (rnd.nextInt(3)) {
                0 -> ByteArray(rnd.nextInt(200)).also { rnd.nextBytes(it); if (it.isNotEmpty() && rnd.nextBoolean()) it[0] = if (tls) 0x16 else 'G'.code.toByte() }
                else -> mutate(if (tls) real else req)
            }
            val n = if (buf.isEmpty()) 0 else rnd.nextInt(buf.size + 1)
            try {
                where = "parse"
                Dpi.classify(buf, n); Dpi.tlsNeed(buf, n); Dpi.httpEnd(buf, n)
                val okT = Dpi.parseHello(buf, n, h)
                if (okT) { require(h.sniOff >= 5 && h.sniOff + h.sniLen <= n) { "SNI sınır dışı" }; h.host(buf) }
                val okH = Dpi.parseHttp(buf, n, hi)
                if (okH) { require(hi.valOff >= 0 && hi.valOff + hi.valLen <= n) { "Host sınır dışı" }; Dpi.httpHost(buf, hi) }
                val kind = if (tls) Dpi.TLS else Dpi.HTTP
                val plans = if (tls) Dpi.TLS_PLANS else Dpi.HTTP_PLANS
                for (p in 0 until plans) {
                    where = "split kind=$kind plan=$p n=$n"
                    val parts = Dpi.split(kind, p, buf, n)
                    runs++
                    if ((n > 0 && parts.isEmpty()) || parts.any { it.data.isEmpty() }) empty++
                    if (n == 0 && parts.isNotEmpty()) empty++
                    // kayıt değiştiren / başlık yeniden yazan yöntemler dışında akış birebir korunur
                    val exact = kind == Dpi.TLS && p in intArrayOf(0, 2, 4, 5)
                    if (exact && n > 0) {
                        val j = parts.fold(ByteArray(0)) { a, x -> a + x.data }
                        if (!j.contentEquals(buf.copyOf(n))) lost++
                    }
                    require(parts.sumOf { it.data.size } <= n + 16 + 2) { "bölünmüş veri aşırı büyüdü" }
                    require(parts.size <= 16) { "çok fazla parça" }
                }
            } catch (e: Throwable) { thrown = e }
        }
        T.check("120 bin rastgele/bozuk girdide ayrıştırıcılar ve tüm bölme yöntemleri istisna fırlatmaz", thrown == null, "$where: $thrown")
        T.check("bölücüler hiçbir zaman boş parça üretmez ($runs deneme)", empty == 0, "boş=$empty")
        T.check("bayt-koruyan TLS yöntemlerinde (0,2,4,5) akış hiçbir girdide bozulmaz", lost == 0, "bozulan=$lost")
        // sınır durumları
        var edgeOk = true
        for (n in 0..12) for (k in intArrayOf(Dpi.TLS, Dpi.HTTP, Dpi.NONE)) for (p in 0..9) {
            try { Dpi.split(k, p, ByteArray(16) { 0x16 }, n) } catch (e: Throwable) { edgeOk = false; println("    kenar: kind=$k plan=$p n=$n -> $e") }
        }
        T.check("çok kısa girdilerde (0..12 bayt) ve geçersiz yöntem numaralarında bölücü çökmez", edgeOk)
    }

    T.group("Sağlamlık: ağ geçidi paket girişi (rastgele IP/TCP/UDP paketleri)")
    run {
        val rig = GatewayFuzzRig()
        var thrown: Throwable? = null
        val seed = ByteArray(80)
        repeat(30_000) {
            val len = 20 + rnd.nextInt(120)
            val p = ByteArray(len)
            when (rnd.nextInt(4)) {
                0 -> rnd.nextBytes(p)
                1 -> { rnd.nextBytes(p); p[0] = (0x45).toByte(); p[9] = 6 }                 // IPv4 TCP biçimli
                2 -> { rnd.nextBytes(p); p[0] = (0x45).toByte(); p[9] = 17 }                // IPv4 UDP biçimli
                else -> { rnd.nextBytes(p); p[0] = 0x60 }                                   // IPv6
            }
            if (p[0].toInt() == 0x45) { p[2] = (len ushr 8).toByte(); p[3] = len.toByte() }
            try { rig.gw.onPacket(p, len) } catch (e: Throwable) { thrown = e }
        }
        T.check("30 bin bozuk paket ağ geçidine verilir, istisna çıkmaz", thrown == null, thrown.toString())
        Thread.sleep(400)
        T.check("tarama sonrası ağ geçidi çalışır, akış sayıları sınırlar içindedir", rig.gw.stats().tcpFlows <= 1500 && rig.gw.stats().udpFlows <= 400)
        rig.close()
    }

    T.group("Sağlamlık: DNS filtresi ve cevap kurucuları (rastgele sorgu)")
    run {
        FilterRuntime.reset()
        FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), listOf("tracker-net.example"))
        val eng = FilterRuntime.engine!!
        var thrown: Throwable? = null
        val out = ByteArray(Packets.HDR + 1500)
        val q0 = Dns.buildQuery(5, "tracker-net.example")
        repeat(80_000) {
            val b = if (rnd.nextInt(3) == 0) ByteArray(rnd.nextInt(80)).also { rnd.nextBytes(it) } else mutate(q0)
            val n = if (b.isEmpty()) 0 else rnd.nextInt(b.size + 1)
            try {
                val v = eng.verdict(b, 0, n)
                if (v != FilterVerdict.PASS) {
                    val qe = Dns.questionEnd(b, 0, n)
                    if (qe in 12..n) {
                        val r = FilterEngine.buildReply(b, 0, qe, out, 0)
                        require(r in -1..(n + FilterEngine.MAX_REPLY_EXTRA)) { "cevap uzunluğu $r" }
                        val r2 = FilterEngine.buildNxdomain(b, 0, qe, out, 0)
                        require(r2 in -1..n) { "nxdomain uzunluğu $r2" }
                    }
                }
            } catch (e: Throwable) { thrown = e }
        }
        T.check("80 bin bozuk sorguda süzgeç ve cevap kurucuları istisna fırlatmaz, uzunluklar sınır içinde", thrown == null, thrown.toString())
        FilterRuntime.reset()
    }
}
