package app.dnshizli.platform

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.HandlerThread
import java.util.concurrent.atomic.AtomicInteger
import app.dnshizli.core.Sfx
import app.dnshizli.core.Synth
import app.dnshizli.core.Voice

/**
 * Sentezlenmiş ses efektlerini çalar. Dosya yoktur: [Synth] sesleri ilk kullanımda üretir (birkaç milisaniye), her olay için
 * bir statik [AudioTrack] tutulur ve sonraki çalmalar başa sarıp yeniden başlatır. Ses akışı "dokunma/sistem sesi"dir:
 * telefon sessiz ya da titreşimdeyse sistem bunu zaten kısar; ses odağı istenmez, çalan müziği durdurmaz.
 * Tını değişince eski diziler bırakılır (en çok 9 olay × ≈ 40 KB).
 *
 * Tüm ses işi (sentez, AudioTrack kurma, durdurma/başa sarma/çalma ikili çağrıları) ayrı bir iş parçacığında yapılır: ana iş
 * parçacığında bu işler sayfa geçişi gibi anlarda gözle görülür takılmaya (yüzlerce ms) yol açıyordu. Bekleyen çalma sayısı
 * sınırlıdır; sistem yavaşsa eski sesler atılır, kuyruk birikmez.
 */
class SoundFx {
    private val tracks = HashMap<Sfx, AudioTrack>()
    private var voice: Voice? = null
    private val worker = HandlerThread("dns-sound").also { it.isDaemon = true; it.start() }
    private val handler = Handler(worker.looper)
    private val pending = AtomicInteger()

    /** Ana iş parçacığından çağrılır; hemen döner. */
    fun play(e: Sfx, v: Voice, volume: Float) {
        if (pending.get() >= MAX_PENDING) return
        pending.incrementAndGet()
        val queued = handler.post {
            try { playNow(e, v, volume) } finally { pending.decrementAndGet() }
        }
        if (!queued) pending.decrementAndGet()
    }

    @Synchronized
    private fun playNow(e: Sfx, v: Voice, volume: Float) {
        try {
            if (voice != v) { releaseNow(); voice = v }
            var t = tracks[e]
            if (t == null) {
                val pcm = Synth.render(e, v)
                t = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build(),
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(Synth.RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build(),
                    )
                    .setBufferSizeInBytes(pcm.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                if (t.write(pcm, 0, pcm.size) != pcm.size) { t.release(); return }
                tracks[e] = t
            }
            t.stop()
            t.setPlaybackHeadPosition(0)
            t.setVolume(volume.coerceIn(0f, 1f))
            t.play()
        } catch (_: Exception) {
            // Ses cihazı yoksa ya da başlatılamadıysa sessizce vazgeç: ses süstür, uygulamayı aksatmamalı.
        }
    }

    /** Çalma sırasındaki işlerden sonra çalışır (sıra korunur); ana iş parçacığını bekletmez. */
    fun release() { handler.post { releaseNow() } }

    @Synchronized
    private fun releaseNow() {
        for (t in tracks.values) try { t.release() } catch (_: Exception) {}
        tracks.clear()
        voice = null
    }

    /** Etkinlik yok olurken: bekleyen işler bitince sesleri bırakır ve iş parçacığını kapatır (yeniden kullanılmaz). */
    fun shutdown() { handler.post { releaseNow(); worker.quitSafely() } }

    private companion object {
        const val MAX_PENDING = 4
    }
}
