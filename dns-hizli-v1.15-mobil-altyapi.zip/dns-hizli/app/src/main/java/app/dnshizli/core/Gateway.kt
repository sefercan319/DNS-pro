package app.dnshizli.core

import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.DatagramChannel
import java.nio.channels.SelectionKey
import java.nio.channels.Selector
import java.nio.channels.SocketChannel
import java.security.SecureRandom
import java.util.Random
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** Ağ geçidinin canlı ayarları (iş parçacığından bağımsız değişebilir). */
class GwConfig {
    /** TLS/HTTP ilk uçuşunu bölerek DPI'yı atlat. */
    @Volatile var dpi = false
    /** QUIC'i (UDP/443) düşür: uygulamalar TCP'ye döner, böylece SNI/DPI yöntemleri onları da kapsar. */
    @Volatile var blockQuic = false
    /** DNS'i atlatan şifreli DNS'i (TCP/UDP 853 ve bilinen DoH adları) engelle: uygulamalar sistem DNS'ine döner. */
    @Volatile var blockDoh = false
    /** Reklam/izleyici engelleme için motor (ağ geçidine ÖZEL örnek; tünel okuyucusuyla paylaşılmaz). null = kapalı. */
    @Volatile var ads: FilterEngine? = null
    /** [ads] boşsa buradan alınır (motor arka planda kurulduğundan her seferinde güncel olanı verir). */
    @Volatile var adsSource: (() -> FilterEngine?)? = null
    fun engine(): FilterEngine? = ads ?: adsSource?.invoke()
    /** Sistemin düz DNS sorguları (UDP/53) da süzülsün mü? (DNS düğmesi kapalıyken de reklam engellensin.) */
    @Volatile var adsDns = true
    /** true ise yeni bağlantılar yalnızca aktarılır: bölme, engelleme, hiçbir şey yapılmaz (acil durum). */
    @Volatile var passthrough = false
    /** IPv6-only (NAT64) ağ için 96 bitlik ön ek (12 bayt); null = bilinmiyor. IPv4 hedefler ön ek + adres olarak da denenir. */
    @Volatile var nat64: ByteArray? = null
    /** Ağda IPv4 çıkış yolu yok (yalnızca IPv6): IPv4 hedefler önce [nat64] ile bağlanır, olmazsa düz IPv4 denenir. */
    @Volatile var noV4 = false
    /** Ön ek + IPv4 → NAT64 adresi. Varsayılan düz birleştirme; testler değiştirebilir (ortamda IPv6 olmayabilir). */
    /** Bağlantı kurulurken SYN yanıtsız kalırsa kısa süre sonra paralel ikinci deneme (RFC 8305 benzeri). Kayıplı mobil ağlarda 1 sn'lik çekirdek zamanlayıcısını beklemez. */
    @Volatile var hedge = true
    /** >= 0 ise yedek denemenin gecikmesi (ms) sabitlenir (testler); aksi halde ağın ölçülen bağlantı süresinden. */
    @Volatile var hedgeDelayMs = -1L
    @Volatile var nat64Addr: (ByteArray, ByteArray) -> InetAddress = { p, v -> InetAddress.getByAddress(p + v) }
}

data class GwStats(
    val tcpFlows: Int, val udpFlows: Int,
    val opened: Long, val connectFail: Long, val recentOk: Int, val recentFail: Int,
    val blockedHosts: Long, val split: Long, val retried: Long, val quicDropped: Long, val dnsBlocked: Long,
    val bytesUp: Long, val bytesDown: Long, val dohBlocked: Long = 0L,
    val hedged: Long = 0L, val hedgeWon: Long = 0L, val netResets: Long = 0L,
)

/**
 * Tünel içindeki TÜM trafiği (DNS dışında) gerçek ağa aktaran kullanıcı alanı geçidi. Sıfırdan yazıldı, dış kütüphane yok.
 * Android'e bağlı değildir: soketler [protectTcp]/[protectUdp] ile (VpnService.protect) işaretlenir, testlerde gerçek
 * loopback soketleri kullanılır.
 *
 * Tasarım:
 *  - Tek iş parçacığı ("gw-io") her şeyi yapar: tünelden gelen paketler [onPacket] ile kuyruğa konur, seçici
 *    (Selector) hem sokete hem zamanlayıcıya bakar. Kilit yoktur.
 *  - TCP: istemci (telefondaki uygulama) ile bu geçit arasında kendi TCP durum makinemiz vardır; sunucu tarafı gerçek bir
 *    SocketChannel'dır. SYN+ACK, ancak sunucuya bağlanılınca gönderilir (bağlanamayan hedef hemen RST alır; IPv6 → IPv4
 *    geri dönüşü bozulmaz). Pencere ölçeği yok (65535), SACK yok; üç yinelenen ACK + zamanlayıcı ile yeniden gönderim.
 *  - İlk uçuş (TLS ClientHello / HTTP isteği) toplanır, SNI/Host okunur; reklam motoru engelliyorsa bağlantı RST ile
 *    kesilir, DPI açıksa [Dpi] ile bölünerek yazılır. Cevap gelmezse (zaman aşımı/RST) AYNI istemci bağlantısı üzerinde
 *    sunucuya yeni bir bağlantı açılıp sıradaki yöntemle yeniden denenir ([Dpi.Planner]).
 *  - UDP: akış başına bir DatagramChannel; boşta 30 sn sonra kapanır.
 */
internal class Gateway(
    private val out: (ByteArray, Int, Int) -> Unit,
    private val protectTcp: (java.net.Socket) -> Boolean = { true },
    private val protectUdp: (java.net.DatagramSocket) -> Boolean = { true },
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000L },
    private val random: Random = SecureRandom(),
    /** Yuvanın IP TTL'ini ayarlar ("disorder" yöntemi). Başarısızsa false: yöntem düz bölmeye düşer. */
    private val setTtl: (java.net.Socket, Int) -> Boolean = { _, _ -> false },
) {
    val config = GwConfig()

    // DPI yöntem belleği ağ türüne göre ayrı tutulur: Wi-Fi'de öğrenilen yöntem mobil operatörde işe yaramayabilir (ve tersi).
    // Mobilde bekleme süreleri daha cömert ([Dpi.Planner.slow]): telsiz uyanması ve dalgalı gecikme yanlış "yanıt yok"a yol açmasın.
    private val planners = arrayOf(Dpi.Planner(), Dpi.Planner(slow = true), Dpi.Planner(), Dpi.Planner(), Dpi.Planner())   // NetKind sırası
    @Volatile private var plannerIdx = 0
    val planner: Dpi.Planner get() = planners[plannerIdx]

    /** Etkin ağ türü değişti (ör. Wi-Fi ↔ mobil): o türün kendi yöntem belleğine geçilir. [NetKind.NONE]'da değişmez. */
    fun networkChanged(kind: NetKind) {
        if (kind == NetKind.NONE) return
        plannerIdx = kind.ordinal
    }

    private val selector: Selector = Selector.open()
    private val inbox = ConcurrentLinkedQueue<ByteArray>()
    private val inboxCount = AtomicInteger()
    private val wakePending = AtomicBoolean(false)
    @Volatile private var running = false
    private var thread: Thread? = null

    private val tcp4 = HashMap<Long, TcpFlow>()
    private val tcp6 = HashMap<String, TcpFlow>()
    private val udp4 = HashMap<Long, UdpFlow>()
    private val udp6 = HashMap<String, UdpFlow>()
    private val flowsTcp = AtomicInteger()
    private val flowsUdp = AtomicInteger()

    private val outBuf = ByteArray(2048)
    private val readBuf = ByteBuffer.allocate(16 * 1024)
    private val dnsOut = ByteArray(Packets.HDR + 512 + FilterEngine.MAX_REPLY_EXTRA)

    private val opened = AtomicLong(); private val connectFail = AtomicLong()
    private val blockedHosts = AtomicLong(); private val splitCount = AtomicLong(); private val retried = AtomicLong()
    private val quicDropped = AtomicLong(); private val dnsBlocked = AtomicLong(); private val dohBlocked = AtomicLong()
    private val bytesUp = AtomicLong(); private val bytesDown = AtomicLong()
    private val hedged = AtomicLong(); private val hedgeWon = AtomicLong(); private val netResets = AtomicLong()
    private val hedgesInFlight = AtomicInteger()
    private val resetPending = AtomicBoolean(false)
    private var nextHedgeAt = Long.MAX_VALUE            // yalnızca gw-io iş parçacığı: bekleyen en yakın yedek deneme zamanı

    /**
     * Fiziksel ağ değişti (Wi-Fi ↔ mobil, başka Wi-Fi, ağ gidip geldi): eski ağa bağlı sunucu soketleri sessizce ölür ve
     * uygulamalar dakikalarca (TCP yeniden iletim süresi) takılı kalır. Tüm akışlar hemen kesilir (istemciye RST); uygulamalar
     * yeni ağda anında yeniden bağlanır. Herhangi bir iş parçacığından çağrılabilir.
     */
    fun networkReset() {
        resetPending.set(true)
        if (wakePending.compareAndSet(false, true)) selector.wakeup()
    }

    private fun doNetworkReset() {
        var n = 0
        for (f in ArrayList(tcp4.values) + ArrayList(tcp6.values)) { try { f.netReset(); n++ } catch (_: Exception) {} }
        for (u in ArrayList(udp4.values) + ArrayList(udp6.values)) { try { u.close(); n++ } catch (_: Exception) {} }
        netResets.addAndGet(n.toLong())
    }
    @Volatile private var recentOk = 0
    @Volatile private var recentFail = 0
    private var windowStart = 0L
    private var lastTick = 0L

    fun start() {
        if (running) return
        running = true
        windowStart = nowMs()
        thread = Thread({ loop() }, "gw-io").also { it.isDaemon = true; it.start() }
    }

    /** İş parçacığını durdurur ve tüm akışları kapatır (RST göndermez: tünel zaten kapanıyor). */
    fun stop() {
        running = false
        try { selector.wakeup() } catch (_: Exception) {}
        val t = thread
        if (t != null && t !== Thread.currentThread()) try { t.join(1500) } catch (_: InterruptedException) {}
        for (f in ArrayList(tcp4.values) + ArrayList(tcp6.values)) f.closeChannel()
        for (f in ArrayList(udp4.values) + ArrayList(udp6.values)) f.closeChannel()
        tcp4.clear(); tcp6.clear(); udp4.clear(); udp6.clear()
        try { selector.close() } catch (_: Exception) {}
    }

    fun stats(): GwStats = GwStats(
        flowsTcp.get(), flowsUdp.get(), opened.get(), connectFail.get(), recentOk, recentFail,
        blockedHosts.get(), splitCount.get(), retried.get(), quicDropped.get(), dnsBlocked.get(), bytesUp.get(), bytesDown.get(), dohBlocked.get(),
        hedged.get(), hedgeWon.get(), netResets.get(),
    )

    /** Tünel okuyucusundan gelen bir IP paketi (DNS adresine gidenler buraya verilmez). Hızlıdır: yalnızca kuyruğa koyar. */
    fun onPacket(p: ByteArray, len: Int) {
        if (!running || len < 20) return
        if (inboxCount.get() >= INBOX_MAX) return                       // aşırı yük: paket atılır, istemci yeniden gönderir
        inbox.add(p.copyOf(len))
        inboxCount.incrementAndGet()
        if (wakePending.compareAndSet(false, true)) selector.wakeup()
    }

    // ------------------------------------------------------------------ ana döngü

    private fun loop() {
        while (running) {
            try {
                var wait = if (tcp4.isEmpty() && tcp6.isEmpty() && udp4.isEmpty() && udp6.isEmpty()) IDLE_WAIT_MS else TICK_MS
                // Yedek bağlantı zamanı yaklaşıyorsa tam o ana uyan (200 ms'lik zamanlayıcıyı beklemez).
                if (nextHedgeAt != Long.MAX_VALUE) wait = minOf(wait, maxOf(1L, nextHedgeAt - nowMs()))
                selector.select(wait)
                wakePending.set(false)
                if (!running) break
                if (resetPending.compareAndSet(true, false)) doNetworkReset()
                var p = inbox.poll()
                var n = 0
                while (p != null) {
                    inboxCount.decrementAndGet()
                    try { handlePacket(p) } catch (_: Exception) {}
                    if (++n >= 512) break
                    p = inbox.poll()
                }
                val keys = selector.selectedKeys()
                if (keys.isNotEmpty()) {
                    val it = keys.iterator()
                    while (it.hasNext()) {
                        val k = it.next(); it.remove()
                        val h = k.attachment()
                        try {
                            if (k.isValid) when (h) { is TcpFlow -> h.onKey(k); is UdpFlow -> h.onKey(k) }
                        } catch (_: Exception) {
                            when (h) { is TcpFlow -> h.abort(true); is UdpFlow -> h.close() }
                        }
                    }
                }
                val now = nowMs()
                for (f in tcp4.values) f.flushAck()
                for (f in tcp6.values) f.flushAck()
                if (now - lastTick >= TICK_MS || now >= nextHedgeAt) { lastTick = now; nextHedgeAt = Long.MAX_VALUE; tick(now) }
                if (inboxCount.get() > 0 && wakePending.compareAndSet(false, true)) selector.wakeup()
            } catch (_: java.nio.channels.ClosedSelectorException) {
                break
            } catch (_: Exception) {
                // döngü hiçbir hatayla ölmesin
            }
        }
    }

    private fun tick(now: Long) {
        if (now - windowStart >= 60_000) { windowStart = now; recentOk = 0; recentFail = 0 }
        sweep(tcp4, now); sweep(tcp6, now)
        val u = ArrayList<UdpFlow>()
        udp4.values.forEach { if (now - it.last > UDP_IDLE_MS) u.add(it) }
        udp6.values.forEach { if (now - it.last > UDP_IDLE_MS) u.add(it) }
        for (f in u) f.close()
    }

    private fun <K> sweep(m: HashMap<K, TcpFlow>, now: Long) {
        if (m.isEmpty()) return
        for (f in ArrayList(m.values)) try { f.tick(now) } catch (_: Exception) { f.abort(true) }
    }

    // ------------------------------------------------------------------ paket ayrıştırma

    private fun handlePacket(p: ByteArray) {
        val len = p.size
        val v6: Boolean
        val ip: Int
        val proto: Int
        val total: Int
        when ((p[0].toInt() ushr 4) and 0xF) {
            4 -> {
                v6 = false
                ip = (p[0].toInt() and 0xF) * 4
                if (ip < 20 || len < ip + 8) return
                if ((Packets.u16(p, 6) and 0x3FFF) != 0) return           // parçalı IP: desteklenmez
                proto = p[9].toInt() and 0xFF
                total = minOf(Packets.u16(p, 2), len)
            }
            6 -> {
                if (len < 48) return
                v6 = true; ip = 40
                proto = p[6].toInt() and 0xFF                             // uzantı başlıkları desteklenmez
                total = minOf(40 + Packets.u16(p, 4), len)
            }
            else -> return
        }
        if (total < ip + 8) return
        val src = if (v6) p.copyOfRange(8, 24) else p.copyOfRange(12, 16)
        val dst = if (v6) p.copyOfRange(24, 40) else p.copyOfRange(16, 20)
        // Çok noktaya / genel yayın (mDNS, SSDP, DHCP yayını...) aktarılmaz: tünele yanlışlıkla girdiyse sessizce atılır.
        if (if (v6) (dst[0].toInt() and 0xFF) == 0xFF else (dst[0].toInt() and 0xF0) == 0xE0 || (dst[0].toInt() and 0xFF) == 255 && dst[3].toInt() == -1) return
        when (proto) {
            Gw.TCP -> if (total >= ip + 20) onTcp(p, ip, total, v6, src, dst)
            Gw.UDP -> onUdp(p, ip, total, v6, src, dst)
            else -> {}                                                    // ICMP vb.: aktarılmaz
        }
    }

    private fun key4(dst: ByteArray, dport: Int, sport: Int): Long =
        ((Packets.i32(dst, 0).toLong() and 0xFFFFFFFFL) shl 32) or (dport.toLong() shl 16) or sport.toLong()

    private fun key6(dst: ByteArray, dport: Int, sport: Int): String =
        String(dst, Charsets.ISO_8859_1) + dport.toChar() + sport.toChar()

    // ------------------------------------------------------------------ TCP

    private fun onTcp(p: ByteArray, t: Int, total: Int, v6: Boolean, src: ByteArray, dst: ByteArray) {
        val sport = Packets.u16(p, t); val dport = Packets.u16(p, t + 2)
        val seq = Packets.i32(p, t + 4); val ack = Packets.i32(p, t + 8)
        val doff = (p[t + 12].toInt() and 0xF0) ushr 2
        val flags = p[t + 13].toInt() and 0xFF
        val win = Packets.u16(p, t + 14)
        if (doff < 20 || t + doff > total) return
        val pay = t + doff
        val dLen = total - pay
        var f = if (v6) tcp6[key6(dst, dport, sport)] else tcp4[key4(dst, dport, sport)]
        if (flags and Gw.SYN != 0 && flags and Gw.ACK == 0) {
            if (f != null && f.state == CONNECTING && f.rcvNxt == seq + 1) return        // yinelenen SYN: bağlantı sürüyor
            if (f != null && f.state != CLOSED && f.rcvNxt == seq + 1) { f.resendSynAck(); return }
            if (f != null) { f.abort(false); forget(f) }
            if (flowsTcp.get() >= MAX_TCP) { reset(v6, src, dst, sport, dport, seq, ack, flags, dLen); return }
            if ((dport == 853 || (dport == 443 && Dpi.isDohAddress(dst))) && config.blockDoh && !config.passthrough) { dohBlocked.incrementAndGet(); reset(v6, src, dst, sport, dport, seq, ack, flags, dLen); return }
            val mss = peerMss(p, t + 20, pay)
            f = TcpFlow(v6, src, dst, sport, dport, seq, mss)
            if (v6) tcp6[key6(dst, dport, sport)] = f else tcp4[key4(dst, dport, sport)] = f
            flowsTcp.incrementAndGet()
            f.connect()
            return
        }
        if (f == null || f.state == CLOSED) {
            if (flags and Gw.RST == 0) reset(v6, src, dst, sport, dport, seq, ack, flags, dLen)
            return
        }
        f.onSegment(seq, ack, flags, win, p, pay, dLen)
    }

    private fun peerMss(p: ByteArray, from: Int, to: Int): Int {
        var i = from
        while (i < to) {
            val k = p[i].toInt() and 0xFF
            if (k == 0) break
            if (k == 1) { i++; continue }
            if (i + 1 >= to) break
            val l = p[i + 1].toInt() and 0xFF
            if (l < 2) break
            if (k == 2 && l == 4 && i + 4 <= to) return Packets.u16(p, i + 2)
            i += l
        }
        return 536
    }

    /** Bilinmeyen bağlantıya RST (RFC 793 §3.4): istemci hemen vazgeçsin. */
    private fun reset(v6: Boolean, client: ByteArray, server: ByteArray, cport: Int, sport: Int, seq: Int, ack: Int, flags: Int, dLen: Int) {
        val n = if (flags and Gw.ACK != 0)
            Gw.tcp(outBuf, v6, server, client, sport, cport, ack, 0, Gw.RST, 0, null, 0, 0)
        else {
            val a = seq + dLen + (if (flags and Gw.SYN != 0) 1 else 0) + (if (flags and Gw.FIN != 0) 1 else 0)
            Gw.tcp(outBuf, v6, server, client, sport, cport, 0, a, Gw.RST or Gw.ACK, 0, null, 0, 0)
        }
        out(outBuf, 0, n)
    }

    private fun forget(f: TcpFlow) {
        val k4 = !f.v6
        if (k4) { if (tcp4[key4(f.server, f.sport, f.cport)] === f) tcp4.remove(key4(f.server, f.sport, f.cport)) }
        else { if (tcp6[key6(f.server, f.sport, f.cport)] === f) tcp6.remove(key6(f.server, f.sport, f.cport)) }
        flowsTcp.decrementAndGet()
    }

    /**
     * Tek bir istemci TCP bağlantısı + sunucuya giden gerçek soket. [client]/[server] istemci ve uzak adrestir;
     * [cport] telefondaki uygulamanın, [sport] uzak sunucunun portudur.
     */
    private inner class TcpFlow(
        val v6: Boolean, val client: ByteArray, val server: ByteArray, val cport: Int, val sport: Int,
        isn: Int, clientMss: Int,
    ) {
        var state = CONNECTING
        val iss = random.nextInt()
        var sndUna = iss + 1
        var sndNxt = iss + 1
        var rcvNxt = isn + 1
        var peerWnd = 65535
        var lastWin = -1
        var dup = 0
        var synAcked = false
        val mss = minOf(clientMss.coerceAtLeast(100), if (v6) Gw.MSS6 else Gw.MSS4)

        val sndBuf = ByteQueue(SND_CAP)
        val toUp = ByteQueue(UP_CAP)
        var finSent = false; var finAcked = false
        var clientFin = false; var upEof = false; var upShut = false
        var needAck = false
        var rto = RTO_INIT; var rtoAt = 0L; var tries = 0
        var created = nowMs(); var last = created
        var closedAt = 0L
        var synAckAt = 0L; var synAckTries = 0

        var ch: SocketChannel? = null
        var key: SelectionKey? = null
        var connected = false
        var readBlocked = false

        // ilk uçuş / DPI
        var phase = PRE
        var first = ByteArray(0)
        var firstLen = 0
        var firstDeadline = 0L
        var kind = Dpi.NONE
        var plan = -1
        var hostKey = ""
        var awaitDeadline = 0L
        var connStart = 0L
        var useNat = false
        var natTried = false
        var ch2: SocketChannel? = null           // yedek (hedge) bağlantı denemesi
        var key2: SelectionKey? = null
        var hedgeAt = 0L; var hedgeNat = false; var connStart2 = 0L; var hedgeTried = false
        var gotData = false
        val parts = ArrayDeque<Dpi.Part>()
        var partOff = 0
        var oobPending = false

        // ---- sunucu tarafı bağlantı

        fun connect() {
            openUpstream()
        }

        private fun openUpstream() {
            try {
                val c = SocketChannel.open()
                ch = c
                c.configureBlocking(false)
                if (!protectTcp(c.socket())) throw IOException("protect")
                try { c.socket().tcpNoDelay = true; c.socket().keepAlive = true } catch (_: Exception) {}
                connected = false
                connStart = nowMs()
                if (!natTried && server.size == 4 && config.noV4 && config.nat64 != null) useNat = true
                val done = c.connect(InetSocketAddress(upstreamAddr(), sport))
                key = c.register(selector, if (done) SelectionKey.OP_READ else SelectionKey.OP_CONNECT, this)
                hedgeTried = false
                hedgeAt = if (!done && config.hedge) nowMs() + (if (config.hedgeDelayMs >= 0) config.hedgeDelayMs else planner.hedgeMs()) else 0L
                if (hedgeAt != 0L && hedgeAt < nextHedgeAt) nextHedgeAt = hedgeAt
                if (done) onConnected()
                else if (state == CONNECTING) synAckAt = nowMs() + CONNECT_MS
            } catch (e: Exception) {
                connectFailed()
            }
        }

        /** Sunucu adresi; NAT64 kipindeyse ön ek + IPv4 (yalnızca IPv6 olan mobil ağlar). */
        private fun upstreamAddr(): InetAddress {
            val p = config.nat64
            return if (useNat && p != null && p.size == 12 && server.size == 4) config.nat64Addr(p, server) else InetAddress.getByAddress(server)
        }

        /** Asıl deneme yanıtsızken ikinci bir bağlantı açar (varsa öbür adres ailesine); ilk bağlanan kazanır. */
        private fun startHedge() {
            hedgeAt = 0L; hedgeTried = true
            if (ch2 != null || connected || hedgesInFlight.get() >= MAX_HEDGES) return
            try {
                val c = SocketChannel.open()
                c.configureBlocking(false)
                if (!protectTcp(c.socket())) { c.close(); return }
                try { c.socket().tcpNoDelay = true; c.socket().keepAlive = true } catch (_: Exception) {}
                val p = config.nat64
                val canAlt = server.size == 4 && p != null && p.size == 12
                hedgeNat = if (canAlt) !useNat else useNat
                val addr = if (hedgeNat && p != null) config.nat64Addr(p, server) else InetAddress.getByAddress(server)
                connStart2 = nowMs()
                val done = c.connect(InetSocketAddress(addr, sport))
                ch2 = c
                key2 = c.register(selector, if (done) SelectionKey.OP_READ else SelectionKey.OP_CONNECT, this)
                hedgesInFlight.incrementAndGet(); hedged.incrementAndGet()
                if (done) promoteHedge()
            } catch (_: Exception) { dropHedge() }
        }

        /** Yedek bağlantı asılın yerini alır (ilk bağlanan yedekse). */
        private fun promoteHedge() {
            val c2 = ch2 ?: return
            val k2 = key2
            try { key?.cancel() } catch (_: Exception) {}
            try { ch?.close() } catch (_: Exception) {}
            ch = c2; key = k2; ch2 = null; key2 = null
            hedgesInFlight.decrementAndGet(); hedgeWon.incrementAndGet()
            useNat = hedgeNat; connStart = connStart2; hedgeAt = 0L
            onConnected()
        }

        private fun dropHedge() {
            hedgeAt = 0L
            val had = ch2 != null
            try { key2?.cancel() } catch (_: Exception) {}
            try { ch2?.close() } catch (_: Exception) {}
            ch2 = null; key2 = null
            if (had) hedgesInFlight.decrementAndGet()
        }

        /** Ağ değişti: bu akış hemen kesilir (istemciye RST), uygulama yeni ağda yeniden bağlanır. */
        fun netReset() {
            if (state == CLOSED) return
            if (state == CONNECTING) {
                val n = Gw.tcp(outBuf, v6, server, client, sport, cport, 0, rcvNxt, Gw.RST or Gw.ACK, 0, null, 0, 0)
                out(outBuf, 0, n)
                shutdown()
            } else abort(true)
        }

        private fun connectFailed() {
            // Asıl deneme düştü ama yedek sürüyor: yedek asıl olur, hata sayılmaz.
            if (ch2 != null && !connected) {
                try { key?.cancel() } catch (_: Exception) {}
                try { ch?.close() } catch (_: Exception) {}
                ch = ch2; key = key2; ch2 = null; key2 = null
                hedgesInFlight.decrementAndGet()
                useNat = hedgeNat; connStart = connStart2
                if (state == CONNECTING) synAckAt = nowMs() + CONNECT_MS
                return
            }
            // IPv4 ile NAT64 arasında bir kez geçiş: ağın IPv4/IPv6 durumu tahminimizden farklı olabilir.
            if (!natTried && server.size == 4 && config.nat64 != null && (state == CONNECTING || (phase == AWAIT && !gotData))) {
                natTried = true; useNat = !useNat
                closeChannel()
                openUpstream()
                return
            }
            connectFail.incrementAndGet(); recentFail++
            if (state == CONNECTING) {
                // SYN'e RST: uygulama hemen "bağlantı reddedildi" görür
                val n = Gw.tcp(outBuf, v6, server, client, sport, cport, 0, rcvNxt, Gw.RST or Gw.ACK, 0, null, 0, 0)
                out(outBuf, 0, n)
                shutdown()
            } else if (phase == AWAIT && !gotData) retryOrFail() else abort(true)
        }

        private fun onConnected() {
            connected = true
            if (connStart != 0L && !gotData) planner.noteRtt(nowMs() - connStart)
            try { key?.interestOps(SelectionKey.OP_READ) } catch (_: Exception) {}
            if (state == CONNECTING) {
                recentOk++; opened.incrementAndGet()
                state = ESTAB
                synAckAt = nowMs() + 1000; synAckTries = 0
                sendSynAck()
            } else {
                // yeniden deneme bağlantısı: ilk uçuşu sıradaki yöntemle yaz
                writeFirst()
            }
        }

        fun resendSynAck() { if (!synAcked) sendSynAck() }

        private fun sendSynAck() {
            val n = Gw.tcp(outBuf, v6, server, client, sport, cport, iss, rcvNxt, Gw.SYN or Gw.ACK, window(), null, 0, 0, mss)
            out(outBuf, 0, n)
        }

        fun onKey(k: SelectionKey) {
            val kc = k.channel()
            if (kc != null && kc === ch2) {
                if (k.isConnectable) {
                    try { if (kc is SocketChannel && kc.finishConnect()) promoteHedge() } catch (_: Exception) { dropHedge() }
                }
                return
            }
            val c = ch ?: return
            if (kc !== c) return
            if (k.isConnectable) {
                try { if (c.finishConnect()) { dropHedge(); onConnected() } else return } catch (_: Exception) { connectFailed(); return }
            }
            if (k.isValid && k.isWritable) flushUp()
            if (k.isValid && k.isReadable) readUp()
        }

        // ---- istemciden gelen segment

        fun onSegment(seq: Int, ack: Int, flags: Int, win: Int, p: ByteArray, off: Int, dLen: Int) {
            last = nowMs()
            if (flags and Gw.RST != 0) {
                if (Gw.seqLe(rcvNxt - 1, seq) && Gw.seqLt(seq, rcvNxt + 65536)) abort(false)
                return
            }
            if (state == CONNECTING) return
            if (flags and Gw.SYN != 0) { resendSynAck(); return }
            if (flags and Gw.ACK == 0) return
            if (!synAcked) {
                if (ack == iss + 1) synAcked = true else return
            }
            processAck(ack, win, dLen == 0 && flags and (Gw.FIN or Gw.SYN) == 0)
            var o = off; var l = dLen; var s = seq
            if (l > 0) {
                if (Gw.seqLt(s, rcvNxt)) {
                    val skip = rcvNxt - s
                    if (skip >= l) { l = 0; sendAck() } else { o += skip; l -= skip; s = rcvNxt }
                }
                if (l > 0) {
                    if (s != rcvNxt) { sendAck(); l = 0 }
                    else {
                        val acc = acceptClient(p, o, l)
                        rcvNxt += acc
                        needAck = true
                        if (acc < l) return                       // pencere doldu: kalanı istemci yeniden gönderir (FIN de bekler)
                    }
                }
            }
            if (flags and Gw.FIN != 0) {
                if (seq + dLen == rcvNxt && !clientFin) {
                    clientFin = true; rcvNxt++; needAck = true
                    if (phase == PRE || phase == COLLECT) startFirst(true)
                    flushUp()
                } else if (clientFin && seq + dLen + 1 == rcvNxt) needAck = true
            }
            if (state != CLOSED) pump()
            checkDone()
        }

        private fun processAck(ack: Int, win: Int, pure: Boolean) {
            val winChanged = win != lastWin
            lastWin = win
            peerWnd = win
            if (Gw.seqLt(sndUna, ack) && Gw.seqLe(ack, sndNxt)) {
                var n = ack - sndUna
                if (finSent && ack == sndNxt) { finAcked = true; n -= 1 }
                sndBuf.drop(n)
                sndUna = ack
                dup = 0; tries = 0; rto = RTO_INIT
                rtoAt = if (sndUna != sndNxt) nowMs() + rto else 0L
                if (readBlocked && sndBuf.size < SND_CAP / 2) { readBlocked = false; setInterest() }
            } else if (ack == sndUna && pure && sndNxt != sndUna && !winChanged) {
                if (++dup == 3) retransmit()
            }
        }

        /** İstemci verisini işler: ilk uçuş toplanır, sonrası sunucuya kuyruğa girer. Kabul edilen bayt sayısı döner. */
        private fun acceptClient(p: ByteArray, off: Int, len: Int): Int {
            bytesUp.addAndGet(len.toLong())
            when (phase) {
                PRE, COLLECT -> {
                    val n = minOf(len, FIRST_MAX - firstLen)
                    if (n <= 0) { startFirst(true); return acceptClient(p, off, len) }
                    if (first.size < firstLen + n) first = first.copyOf(maxOf(2048, minOf(FIRST_MAX, (firstLen + n) * 2)))
                    System.arraycopy(p, off, first, firstLen, n)
                    firstLen += n
                    if (phase == PRE) { phase = COLLECT; firstDeadline = nowMs() + FIRST_WAIT_MS }
                    startFirst(false)
                    return n
                }
                AWAIT -> {
                    // İstemci cevap gelmeden yeniden veri yolladı: yeniden deneme artık güvenli değil, olduğu gibi akıt.
                    val n = toUp.add(p, off, len)
                    phase = RELAY
                    flushUp()
                    return n
                }
                else -> {
                    val n = toUp.add(p, off, len)
                    flushUp()
                    return n
                }
            }
        }

        // ---- ilk uçuş

        /** Yeterli bayt toplandıysa (ya da [force]) karar verir ve sunucuya yazar. */
        fun startFirst(force: Boolean) {
            if (phase != COLLECT && phase != PRE) return
            if (firstLen == 0 && !force) return
            val k = Dpi.classify(first, firstLen)
            var need = -1
            when (k) {
                Dpi.TLS -> need = Dpi.tlsNeed(first, firstLen)
                Dpi.HTTP -> need = Dpi.httpEnd(first, firstLen)
                else -> if (firstLen < 3 && !force) return
            }
            if (!force && k != Dpi.NONE && (need < 0 || firstLen < need)) return    // eksik: bekle
            kind = k
            decide(if (need in 1..firstLen) need else firstLen)
        }

        private fun decide(flight: Int) {
            val cfg = config
            var host: String? = null
            val http = Dpi.HttpInfo()
            if (kind == Dpi.TLS) {
                val h = Dpi.Hello()
                if (Dpi.parseHello(first, firstLen, h)) host = h.host(first)
            } else if (kind == Dpi.HTTP) {
                if (Dpi.parseHttp(first, firstLen, http)) host = Dpi.httpHost(first, http)
            }
            hostKey = host ?: ((InetAddress.getByAddress(server).hostAddress ?: "") + ":" + sport)
            if (!cfg.passthrough) {
                val ads = cfg.engine()
                if (ads != null && host != null && ads.verdictOf(host) != FilterVerdict.PASS) {
                    blockedHosts.incrementAndGet()
                    FilterLive.note(host, false)
                    abort(true)
                    return
                }
            }
            if (!cfg.passthrough && cfg.blockDoh && host != null && Dpi.isDohHost(host)) {
                dohBlocked.incrementAndGet()
                abort(true)
                return
            }
            plan = if (cfg.dpi && !cfg.passthrough && kind != Dpi.NONE) planner.first(hostKey, kind) else -1
            val retriable = plan >= 0 && flight == firstLen && (kind == Dpi.TLS || http.get)
            phase = if (retriable) AWAIT else RELAY
            awaitDeadline = nowMs() + planner.waitMs(kind)
            writeFirst()
        }

        private fun writeFirst() {
            parts.clear(); partOff = 0
            if (plan >= 0 && kind != Dpi.NONE) {
                val list = Dpi.split(kind, plan, first, firstLen)
                if (list.size > 1) splitCount.incrementAndGet()
                parts.addAll(list)
            } else parts.add(Dpi.Part(first.copyOf(firstLen)))
            if (phase == RELAY) { first = ByteArray(0); }
            flushUp()
        }

        private fun retryOrFail() {
            val nxt = if (plan >= 0) planner.next(kind, plan) else -1
            if (nxt < 0) { abort(true); return }
            retried.incrementAndGet()
            plan = nxt
            closeChannel()
            parts.clear(); oobPending = false
            awaitDeadline = nowMs() + planner.waitMs(kind)
            openUpstream()
        }

        // ---- sunucuya yazma / okuma

        fun flushUp() {
            val c = ch ?: return
            if (!connected) return
            try {
                while (parts.isNotEmpty()) {
                    val part = parts.first()
                    val bb = ByteBuffer.wrap(part.data, partOff, part.data.size - partOff)
                    // "disorder": ilk parça çok düşük TTL ile çıkar; hemen ardından TTL normale döner (yeniden iletim normal gider).
                    val low = part.lowTtl && partOff == 0 && setTtl(c.socket(), 1)
                    val w = try { c.write(bb) } finally { if (low) setTtl(c.socket(), 64) }
                    partOff += w
                    if (partOff < part.data.size) { setInterest(); return }
                    if (part.oobAfter) {
                        try { c.socket().sendUrgentData(0) } catch (_: Exception) { /* bu platformda yok: yalnızca bölme */ }
                    }
                    parts.removeFirst(); partOff = 0
                }
                if (phase != AWAIT) {
                    while (!toUp.isEmpty) {
                        val bb = ByteBuffer.wrap(toUp.array(), toUp.start(), toUp.size)
                        val w = c.write(bb)
                        if (w <= 0) { setInterest(); return }
                        toUp.drop(w)
                        needAck = true
                    }
                }
                if (clientFin && toUp.isEmpty && parts.isEmpty() && !upShut && phase != AWAIT && phase != COLLECT && phase != PRE) {
                    upShut = true
                    try { c.socket().shutdownOutput() } catch (_: Exception) {}
                }
                setInterest()
            } catch (e: IOException) {
                if (phase == AWAIT && !gotData) retryOrFail() else abort(true)
            }
        }

        private fun setInterest() {
            val k = key ?: return
            if (!k.isValid) return
            var ops = 0
            if (!connected) ops = SelectionKey.OP_CONNECT
            else {
                if (!upEof && !readBlocked) ops = ops or SelectionKey.OP_READ
                if (parts.isNotEmpty() || (!toUp.isEmpty && phase != AWAIT)) ops = ops or SelectionKey.OP_WRITE
            }
            try { if (k.interestOps() != ops) k.interestOps(ops) } catch (_: Exception) {}
        }

        private fun readUp() {
            val c = ch ?: return
            var loops = 0
            while (loops++ < 4) {
                val room = sndBuf.free
                if (room <= 0) { readBlocked = true; setInterest(); return }
                readBuf.clear()
                readBuf.limit(minOf(readBuf.capacity(), room))
                val n = try { c.read(readBuf) } catch (e: IOException) {
                    if (phase == AWAIT && !gotData) retryOrFail() else abort(true)
                    return
                }
                if (n < 0) {
                    if (phase == AWAIT && !gotData) { retryOrFail(); return }
                    upEof = true
                    setInterest()
                    pump(); checkDone()
                    return
                }
                if (n == 0) break
                if (!gotData) {
                    gotData = true
                    if (phase == AWAIT) {
                        planner.worked(hostKey, kind, plan)
                        phase = RELAY
                        first = ByteArray(0)
                        flushUp()
                    } else if (phase == PRE || phase == COLLECT) {
                        // sunucu önce konuştu (SMTP, SSH...): toplananı olduğu gibi akıt
                        startFirst(true)
                    }
                }
                bytesDown.addAndGet(n.toLong())
                sndBuf.add(readBuf.array(), 0, n)
                last = nowMs()
                if (n < readBuf.limit()) break
            }
            pump()
        }

        // ---- istemciye gönderme

        fun pump() {
            if (!synAcked || state != ESTAB) return
            var guard = 0
            while (guard++ < 64) {
                if (finSent) break
                val inflight = sndNxt - sndUna
                val unsent = sndBuf.size - inflight
                val wnd = peerWnd - inflight
                if (unsent > 0 && wnd > 0) {
                    val seg = minOf(mss, unsent, wnd)
                    val n = segment(sndNxt, inflight, seg, Gw.ACK or (if (seg == unsent) Gw.PSH else 0))
                    out(outBuf, 0, n)
                    sndNxt += seg
                    if (rtoAt == 0L) rtoAt = nowMs() + rto
                    needAck = false
                } else if (unsent == 0 && upEof && !finSent) {
                    val n = Gw.tcp(outBuf, v6, server, client, sport, cport, sndNxt, rcvNxt, Gw.FIN or Gw.ACK, window(), null, 0, 0)
                    out(outBuf, 0, n)
                    finSent = true; sndNxt++
                    if (rtoAt == 0L) rtoAt = nowMs() + rto
                    needAck = false
                } else break
            }
        }

        private fun segment(seq: Int, from: Int, len: Int, flags: Int): Int {
            val tmp = segTmp
            sndBuf.copy(from, tmp, 0, len)
            return Gw.tcp(outBuf, v6, server, client, sport, cport, seq, rcvNxt, flags, window(), tmp, 0, len)
        }

        private val segTmp = ByteArray(1500)

        private fun retransmit() {
            if (state != ESTAB || !synAcked) return
            val inflightData = (sndNxt - sndUna) - (if (finSent && !finAcked) 1 else 0)
            if (inflightData > 0) {
                val seg = minOf(mss, inflightData)
                out(outBuf, 0, segment(sndUna, 0, seg, Gw.ACK))
            } else if (finSent && !finAcked) {
                out(outBuf, 0, Gw.tcp(outBuf, v6, server, client, sport, cport, sndNxt - 1, rcvNxt, Gw.FIN or Gw.ACK, window(), null, 0, 0))
            }
        }

        private fun window(): Int {
            return maxOf(0, minOf(65535, toUp.free))
        }

        fun sendAck() {
            val n = Gw.tcp(outBuf, v6, server, client, sport, cport, sndNxt, rcvNxt, Gw.ACK, window(), null, 0, 0)
            out(outBuf, 0, n)
            needAck = false
        }

        fun flushAck() { if (needAck && state == ESTAB) sendAck() }

        // ---- zamanlayıcı ve kapanış

        fun tick(now: Long) {
            when (state) {
                CONNECTING -> if (!connected) {
                    if (hedgeAt != 0L && now >= hedgeAt) startHedge()
                    else if (hedgeAt != 0L && hedgeAt < nextHedgeAt) nextHedgeAt = hedgeAt
                    if (now > synAckAt) connectFailed()
                }
                CLOSED -> if (closedAt != 0L && now - closedAt > LINGER_MS) forget(this)
                else -> {
                    if (!synAcked && now > synAckAt) {
                        if (++synAckTries > 3) { abort(false); return }
                        synAckAt = now + 1000; sendSynAck()
                    }
                    if (!connected && hedgeAt != 0L) { if (now >= hedgeAt) startHedge() else if (hedgeAt < nextHedgeAt) nextHedgeAt = hedgeAt }
                    if ((phase == COLLECT) && now > firstDeadline) startFirst(true)
                    if (phase == AWAIT && !gotData && now > awaitDeadline) retryOrFail()
                    if (rtoAt != 0L && now >= rtoAt && sndNxt != sndUna) {
                        if (++tries > MAX_TRIES) { abort(true); return }
                        retransmit()
                        rto = minOf(rto * 2, RTO_MAX)
                        rtoAt = now + rto
                    }
                    if (now - last > TCP_IDLE_MS) abort(true)
                }
            }
        }

        private fun checkDone() {
            if (state == ESTAB && finSent && finAcked && clientFin) shutdown()
        }

        /** Bağlantıyı bitir. [rst] doğruysa istemciye RST gider. */
        fun abort(rst: Boolean) {
            if (state == CLOSED) return
            if (rst && state == ESTAB) {
                val n = Gw.tcp(outBuf, v6, server, client, sport, cport, sndNxt, rcvNxt, Gw.RST or Gw.ACK, 0, null, 0, 0)
                out(outBuf, 0, n)
            }
            shutdown()
        }

        private fun shutdown() {
            closeChannel()
            state = CLOSED
            closedAt = nowMs()
            sndBuf.clear(); toUp.clear(); parts.clear()
            first = ByteArray(0)
        }

        fun closeChannel() {
            dropHedge()
            try { key?.cancel() } catch (_: Exception) {}
            try { ch?.close() } catch (_: Exception) {}
            key = null; ch = null; connected = false
        }
    }

    // ------------------------------------------------------------------ UDP

    private fun onUdp(p: ByteArray, u: Int, total: Int, v6: Boolean, src: ByteArray, dst: ByteArray) {
        val sport = Packets.u16(p, u); val dport = Packets.u16(p, u + 2)
        val dLen = minOf(Packets.u16(p, u + 4), total - u) - 8
        if (dLen < 0) return
        val off = u + 8
        val cfg = config
        if (!cfg.passthrough) {
            if (dport == 443 && cfg.blockQuic) { quicDropped.incrementAndGet(); return }
            if ((dport == 853 || (dport == 443 && Dpi.isDohAddress(dst))) && cfg.blockDoh) { dohBlocked.incrementAndGet(); return }
            if (dport == 53 && cfg.adsDns) {
                val e = cfg.engine()
                if (e != null && answerBlocked(e, p, off, dLen, v6, src, dst, sport)) return
            }
        }
        var f = if (v6) udp6[key6(dst, dport, sport)] else udp4[key4(dst, dport, sport)]
        if (f == null) {
            if (flowsUdp.get() >= MAX_UDP) return
            f = UdpFlow(v6, src, dst, sport, dport)
            if (!f.open()) return
            if (v6) udp6[key6(dst, dport, sport)] = f else udp4[key4(dst, dport, sport)] = f
            flowsUdp.incrementAndGet()
        }
        f.send(p, off, dLen)
    }

    /** Düz DNS sorgusu engellenmeli mi? Evetse cevabı biz üretip tünele yazarız (DNS sağlayıcı ne olursa olsun). */
    private fun answerBlocked(e: FilterEngine, p: ByteArray, off: Int, len: Int, v6: Boolean, client: ByteArray, server: ByteArray, cport: Int): Boolean {
        if (len < Packets.DNS_HDR + 5 || len > 512) return false
        val v = e.verdict(p, off, off + len)
        if (v == FilterVerdict.PASS) return false
        val qEnd = Dns.questionEnd(p, off, len)
        if (qEnd <= 0) return false
        val canary = v == FilterVerdict.CANARY
        val n = if (canary) FilterEngine.buildNxdomain(p, off, qEnd, dnsOut, Packets.HDR) else FilterEngine.buildReply(p, off, qEnd, dnsOut, Packets.HDR)
        if (n <= 0) return false
        dnsOut[Packets.HDR] = p[off]; dnsOut[Packets.HDR + 1] = p[off + 1]
        val total = Gw.udp(outBuf, v6, server, client, 53, cport, dnsOut, Packets.HDR, n)
        if (!canary) {                                   // sayaç, cevap yollanmadan önce artar: cevabı gören sayaçta da görür
            dnsBlocked.incrementAndGet()
            FilterLive.note(e.lastName(), v == FilterVerdict.USER)
        }
        out(outBuf, 0, total)
        return true
    }

    private inner class UdpFlow(val v6: Boolean, val client: ByteArray, val server: ByteArray, val cport: Int, val sport: Int) {
        var ch: DatagramChannel? = null
        var key: SelectionKey? = null
        var last = nowMs()

        fun open(): Boolean = try {
            val c = DatagramChannel.open()
            ch = c
            c.configureBlocking(false)
            if (!protectUdp(c.socket())) throw IOException("protect")
            val p = config.nat64
            val dst = if (server.size == 4 && config.noV4 && p != null && p.size == 12) config.nat64Addr(p, server) else InetAddress.getByAddress(server)
            c.connect(InetSocketAddress(dst, sport))
            key = c.register(selector, SelectionKey.OP_READ, this)
            true
        } catch (_: Exception) { close(); false }

        fun send(p: ByteArray, off: Int, len: Int) {
            last = nowMs()
            try { ch?.write(ByteBuffer.wrap(p, off, len)); bytesUp.addAndGet(len.toLong()) } catch (_: Exception) { }
        }

        fun onKey(k: SelectionKey) {
            val c = ch ?: return
            var n = 0
            while (n++ < 8) {
                readBuf.clear()
                val r = try { c.read(readBuf) } catch (_: IOException) { close(); return }
                if (r <= 0) break
                last = nowMs()
                val max = Gw.MTU - (if (v6) 48 else 28)
                if (r > max) continue                                   // MTU'dan büyük: IP parçalama yok, atılır
                val total = Gw.udp(outBuf, v6, server, client, sport, cport, readBuf.array(), 0, r)
                out(outBuf, 0, total)
                bytesDown.addAndGet(r.toLong())
            }
        }

        fun close() {
            val had = ch != null
            closeChannel()
            if (had) {
                if (v6) { if (udp6[key6(server, sport, cport)] === this) udp6.remove(key6(server, sport, cport)) }
                else if (udp4[key4(server, sport, cport)] === this) udp4.remove(key4(server, sport, cport))
                flowsUdp.decrementAndGet()
            }
        }

        fun closeChannel() {
            try { key?.cancel() } catch (_: Exception) {}
            try { ch?.close() } catch (_: Exception) {}
            key = null; ch = null
        }
    }

    private companion object {
        const val INBOX_MAX = 4096
        const val TICK_MS = 200L
        const val IDLE_WAIT_MS = 1000L
        const val MAX_TCP = 1500
        const val MAX_UDP = 400
        const val UDP_IDLE_MS = 30_000L
        const val TCP_IDLE_MS = 15 * 60_000L
        const val LINGER_MS = 3000L
        const val CONNECT_MS = 12_000L
        const val SND_CAP = 96 * 1024
        const val UP_CAP = 128 * 1024
        const val FIRST_MAX = 16 * 1024
        const val FIRST_WAIT_MS = 400L
        const val TLS_WAIT_MS = 2000L
        const val HTTP_WAIT_MS = 5000L
        const val RTO_INIT = 250L
        const val RTO_MAX = 4000L
        const val MAX_TRIES = 9
        const val MAX_HEDGES = 48
    }
}

// TCP akış durumları ve ilk uçuş evreleri
private const val CONNECTING = 0
private const val ESTAB = 1
private const val CLOSED = 2
private const val PRE = 0        // henüz istemci verisi yok
private const val COLLECT = 1    // ilk uçuş toplanıyor
private const val AWAIT = 2      // ilk uçuş yazıldı, ilk cevap bekleniyor (yeniden denenebilir)
private const val RELAY = 3      // düz aktarım
