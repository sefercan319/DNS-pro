package app.dnshizli.core

/** Español. */
object TxEs : Tx() {
    override val lang = Lang.ES

    override val decimalSep = ','
    override val thousand = " mil"
    override val million = " M"
    override fun percent(n: Int) = "$n %"
    override val dayU = "d"
    override val hourU = "h"
    override val minU = "min"
    override val secU = "s"
    override val justNow = "ahora mismo"
    override fun ago(span: String) = "hace $span"

    override val OFF = "Sin conexión"
    override val CONNECTING = "Conectando…"
    override val ON = "Conectado"
    override val ERROR = "No se pudo conectar"
    override val PAUSED = "En pausa"
    override val HINT_OFF = "Toca la esfera para conectar"
    override val HINT_CONNECTING = "Puede tardar unos segundos"
    override val HINT_ERROR = "Toca para reintentar"
    override val HINT_PAUSED = "Toca para reanudar ahora"
    override val ERR_DEFAULT = "No se pudo establecer la conexión"
    override fun selected(name: String) = "$name seleccionado"
    override fun pausedUntil(time: String) = "Se reanuda a las $time"
    override fun blockedShort(n: String) = "$n bloqueadas"
    override fun queriesShort(n: String) = "$n consultas"
    override fun cacheShort(pct: String) = "$pct en caché"

    override val SERVERS = "Servidores"
    override val FILTER_ALL = "Todos"
    override val FILTER_FAV = "Favoritos"
    override val FILTER_RECENT = "Recientes"
    override val EMPTY_FAV = "Aún no hay favoritos. Toca la estrella de un servidor."
    override val EMPTY_RECENT = "Todavía no te has conectado a ningún servidor."
    override val EMPTY_FILTER = "No hay servidores en esta categoría."
    override val MEASURE = "Medir velocidades"
    override val MEASURING = "Midiendo…"
    override val SORT = "Ordenar por velocidad"
    override val PULL_TO_MEASURE = "Desliza para medir"
    override val RELEASE_TO_MEASURE = "Suelta para medir"
    override fun serversCount(n: Int) = if (n == 1) "1 servidor" else "$n servidores"
    override fun showAllServers(n: Int) = "Mostrar todo ($n)"
    override val SHOW_LESS = "Mostrar menos"
    override val TAG_FAST = "Rápido"
    override val TAG_PRIVACY = "Privacidad"
    override val TAG_ADS = "Anuncios"
    override val TAG_FAMILY = "Familia"
    override val TAG_SECURITY = "Seguridad"
    override val VAR_OPEN = "Sin filtro"
    override val VAR_ADS = "Sin anuncios"
    override val VAR_SECURITY = "Seguridad"
    override val VAR_FAMILY = "Familia"
    override val A11Y_CONNECTED = "conectado"
    override val A11Y_ENCRYPTED = "cifrado"
    override fun favA11y(name: String) = "$name favorito"

    override val COPIED = "Copiado al portapapeles"
    override val DISCONNECTED = "Desconectado"
    override val BACKUP = "Cambiado al servidor de respaldo"
    override val NO_REPLY = "Ningún servidor respondió"
    override val MEASURE_FIRST = "Primero mide las velocidades"
    override val CONNECT = "Conectar"
    override val UNDO = "Deshacer"
    override fun fastest(name: String, ms: Int) = "Más rápido: $name · $ms ms"
    override fun switched(name: String) = "Cambiando a $name"
    override fun hiddenToast(name: String) = "$name oculto"

    override val PRIMARY = "Principal"
    override val SECONDARY = "Secundario"
    override val COPY = "Copiar"
    override fun addressA11y(label: String, ip: String) = "Dirección $label: $ip"
    override val CONNECT_TO_THIS = "Conectar a este servidor"
    override val SWITCH_TO_THIS = "Cambiar a este servidor"
    override val CONNECTED_NOW = "Conectado ahora"
    override val ADD_FAV = "Añadir a favoritos"
    override val REMOVE_FAV = "Quitar de favoritos"
    override val MEASURE_THIS = "Medir velocidad"
    override val HIDE = "Ocultar de la lista"
    override val UNHIDE = "Mostrar en la lista"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Última medición: sin respuesta · $ago" else "Última medición: $ms ms · $ago"
    override val NEVER_MEASURED = "Aún sin medir"
    override val ENC_SUPPORT = "DNS cifrado"
    override val ENC_NONE = "No compatible"
    override val ENC_ONLY = "Solo acepta conexiones cifradas"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Mejor $best ms · mediana $median ms · pérdida $lossPct %"
    override val HISTORY = "Historial de mediciones"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: $n mediciones, sin respuesta" else "$HISTORY: $n mediciones, mediana $median ms"

    override val QUICK_TITLE = "Cambio rápido"
    override val QUICK_FAVORITES = "Favoritos"
    override val QUICK_RECENT = "Usados recientemente"
    override val PAUSE_FOR = "Pausar"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} h" else "$n min"
    override val RESUME = "Reanudar"

    override val SETTINGS = "Ajustes"
    override val MENU = "Menú"
    override val PERSONALIZE = "Personalizar"
    override val PZ_BACKGROUND = "Fondo"
    override val PZ_AUTO = "Tema automático"
    override val PZ_FEEL = "Cristal, texto y movimiento"
    override val PZ_ACCESS = "Accesibilidad y energía"
    override val DNS_SETTINGS = "Ajustes de DNS"
    override val CONN_APPS = "Conexión y apps"
    override val STATS_HISTORY = "Estadísticas e historial"
    override val SEC_LOOK = "Apariencia"
    override val SEC_LIST = "Lista de servidores"
    override val SEC_DATA = "Datos"
    override val ABOUT = "Acerca de"
    override val LANGUAGE = "Idioma"
    override val LANG_AUTO = "Automático (idioma del sistema)"
    override val THEME = "Tema"
    override val THEME_AUTO = "Automático"
    override val THEME_AUTO_NOTE = "Automático · sigue el modo claro/oscuro"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Prado"
        "ocean" -> "Océano"
        "sunset" -> "Atardecer"
        "lavender" -> "Lavanda"
        "coral" -> "Coral"
        "mint" -> "Menta"
        "night" -> "Noche"
        "amoled" -> "Negro (AMOLED)"
        "sakura" -> "Sakura"
        "honey" -> "Honey"
        "aurora" -> "Aurora"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Tema: $name"
    override val THEME_SCHEDULE = "Tema nocturno por horario"
    override val THEME_SCHEDULE_NOTE = "En Automático, Noche de 22:00 a 07:00"
    override val GLASS = "Opacidad del cristal"
    override val BUBBLES = "Burbujas"
    override val STYLE = "Estilo"
    override val STYLE_NOTES = listOf(
        "Cristal, brillo y burbujas: el diseño original.",
        "Cielo, hierba verde, gotas de cristal y botones de gel.",
        "Ciudad, música y juventud: rascacielos, altavoz, anillos, estrellas y rayos.",
        "Naturaleza y tecnología: Tierra verde, aerogeneradores, paneles solares y hojas.",
        "Rosa y morado holográficos, corazones cromados, burbujas, destellos y ventanas de píxeles.",
        "Luz turquesa, verde y amarilla, un rayo brillante y ondas de malla transparentes.",
    )
    override val WALLPAPER = "Foto de fondo"
    override val WP_OFF = "Ninguna"
    override val WP_ON = "Foto"
    override val WP_PICK = "Elegir una foto de la galería"
    override val WP_PICK_NOTE = "Se queda en tu teléfono y nunca se sube. El velo se refuerza solo cuando hace falta para que el texto se lea bien."
    override val WP_PRESETS = "Imágenes incluidas"
    override val WP_PRESETS_NOTE = "8 imágenes que vienen con la app. Sin internet."
    override val WP_REMOVE = "Quitar la foto"
    override val WP_DIM = "Intensidad del velo"
    override val WP_BLUR = "Desenfoque"
    override val OPT_WP_BLUR = listOf("No", "Suave", "Fuerte")
    override val WP_SAVED = "Fondo aplicado"
    override val WP_FAILED = "No se pudo abrir la foto"
    override val WP_REMOVED = "Fondo quitado"
    override val APP_ICON = "Icono de la app"
    override val ICON_NOTES = listOf(
        "Globo de cristal: el icono original.",
        "Una gota de cristal sobre cielo y césped.",
        "Ciudad lima-turquesa con rayos de sol y botón de encendido.",
        "Tierra verde brillante con una hoja brotando.",
        "Un corazón cromado brillante sobre rosa y morado holográficos.",
        "Globo de cristal sobre un brillo turquesa-amarillo y ondas de luz.",
    )
    override val ICON_SET = "El icono cambia al salir de la app"
    override val ICON_NOTE = "Si el acceso directo de la pantalla de inicio desaparece, vuelve a añadir la app."
    override val ICON_FAILED = "No se pudo cambiar el icono"
    override val HELP_WHY_TITLE = "¿Por qué esta app?"
    override val HELP_WHY_BODY = "DNS Hızlı es pequeña y sencilla, hecha por una sola persona, sin una gran empresa detrás. Sin cuenta ni anuncios: tú eliges tu DNS, el cifrado, a qué apps se aplica y cómo se ve."
    override val HELP_WHY_TAIL = "Quizá no sea mejor que la competencia, pero funciona y merece la pena probarla."
    override val TROUBLE = "Solucionar problemas"
    override val TROUBLE_RECHECK = "Comprobar de nuevo"
    override val TROUBLE_ALL_OK = "Todo parece correcto. Si aun así no conecta, prueba otro servidor."
    override val TROUBLE_SOME = "Hay cosas que revisar:"
    override val T_NET = "Internet"
    override val NET_OK = "conectado."
    override val NET_BAD = "no hay o es limitado. Revisa el Wi-Fi o los datos móviles."
    override val T_PERM = "Permiso de VPN"
    override val PERM_OK = "concedido."
    override val PERM_BAD = "aún no concedido. Android lo pedirá al conectar; acepta."
    override val T_VPN = "Otra VPN"
    override val VPN_OK = "ninguna."
    override val VPN_BAD = "parece activa. Android solo permite una VPN a la vez; desactívala."
    override val T_DNS = "DNS privado de Android"
    override val PDNS_OK = "desactivado o automático, sin problema."
    override val PDNS_BAD = "está fijado a un servidor y puede saltarse el DNS de esta app. En Ajustes > Red > DNS privado elige Automático o Desactivado."
    override val SEARCH = "Buscar"
    override val SEARCH_HINT = "Nombre o propietario del servidor"
    override val SEARCH_CLEAR = "Borrar"
    override val SHARE_RESULTS = "Compartir resultados de medición"
    override val SHARE_RESULTS_HEAD = "Mediciones de DNS Hızlı (primero el más rápido)"
    override val NO_RESULTS = "Haz primero una medición"
    override val CUSTOM_EDIT = "Editar"
    override fun customUpdated(name: String) = "$name actualizado"
    override val KEEP_HISTORY = "Guardar historial"
    override val KEEP_HISTORY_NOTE = "Si está desactivado, no se guardan recientes, historial ni mediciones. Lo existente se conserva."
    override val MOTION = "Animaciones"
    override val TEXT_SIZE = "Tamaño del texto"
    override val HIGH_CONTRAST = "Alto contraste"
    override val HIGH_CONTRAST_NOTE = "Cristal más opaco y texto más oscuro"
    override val MINIMAL = "Vista sencilla"
    override val MINIMAL_NOTE = "Oculta los filtros y la línea de estadísticas"
    override val LOW_POWER = "Modo de ahorro"
    override val LOW_POWER_NOTE = "Desactiva todo movimiento, cuida la batería"
    override val HAPTICS = "Vibración"
    override val HAPTICS_NOTE = "Respuesta suave al tocar"
    override val ENCRYPTION = "DNS cifrado"
    override val ENCRYPTION_NOTE = "Auto: primero DoT, luego DoH y por último DNS sin cifrar"
    override val AUTO_CONNECT = "Conectar al abrir la app"
    override val AUTO_CONNECT_NOTE = "Al abrir la app se conecta al último servidor"
    override val CONNECT_ON_BOOT = "Conectar al iniciar"
    override val CONNECT_ON_BOOT_NOTE = "Se conecta solo cuando el teléfono se reinicia"
    override val AUTO_FASTEST = "Conectar al más rápido"
    override val AUTO_FASTEST_NOTE = "La esfera elige el servidor más rápido de la última medición"
    override val REFRESH_ON_NET = "Renovar al cambiar de red"
    override val REFRESH_ON_NET_NOTE = "El DNS se renueva al pasar entre wifi y datos móviles"
    override val NOTIFY_DROP = "Avisar si se cae la conexión"
    override val NOTIFY_DROP_NOTE = "Notificación con botón para reconectar si se corta"
    override val NOTIFY_CONNECT = "Avisar al conectar"
    override val NOTIFY_CONNECT_NOTE = "Una notificación breve cuando se conecta"
    override val NOTIFY_STOP = "Avisar al desconectar"
    override val NOTIFY_STOP_NOTE = "Una notificación breve cuando tú desconectas"
    override val NOTIFY_TIMEOUT = "Avisar si hay tiempo agotado"
    override val NOTIFY_TIMEOUT_NOTE = "Aviso si el servidor DNS deja de responder"
    override val NOTIF_PERM = "Permiso de notificaciones"
    override val PERM_ALLOWED = "Permitido"
    override val PERM_BLOCKED = "No · corregir"
    override val NOTIF_CONNECTED_TITLE = "DNS conectado"
    override val NOTIF_STOPPED_TITLE = "DNS desconectado"
    override val NOTIF_STOPPED_TEXT = "La protección está apagada"
    override val NOTIF_TIMEOUT_TITLE = "Tiempo de espera agotado"
    override val FAIL_CLOSED = "Bloquear DNS si se corta"
    override val FAIL_CLOSED_NOTE = "Si se corta la conexión, las consultas DNS no se filtran a tu operador; fallan hasta reconectar"
    override val NOTIF_SEALED = "DNS bloqueado al reconectar"
    override val ERR_SEALED = "No se pudo conectar. El DNS está bloqueado para que no se filtren consultas. Toca Detener para liberarlo."
    override val SEALED_INFO = "DNS bloqueado hasta que vuelva la conexión"
    override val LATENCY_TITLE = "Latencia por consulta"
    override val LATENCY_EMPTY = "Se ve en vivo al conectar y recibir consultas"
    override val FILTER_MINE = "Mi propia lista"
    override val MINE_PASTE = "Importar del portapapeles"
    override val MINE_PASTE_NOTE = "Archivo hosts o un dominio por línea"
    override val MINE_FILE = "Importar de un archivo"
    override val MINE_FILE_NOTE = "Un .txt o archivo hosts del teléfono"
    override val MINE_EXPORT = "Copiar mi lista de bloqueo"
    override val MINE_EXPORT_NOTE = "Al portapapeles, en formato hosts"
    override val MINE_CLEAR = "Borrar lista importada"
    override val MINE_FOOT = "Lee líneas hosts (0.0.0.0 dominio), listas de dominios simples y reglas ||dominio^. Hasta 50 000 nombres. Tu lista de permitidos siempre manda."
    override val MINE_NOTHING = "No se encontraron dominios válidos"
    override val MINE_CLIP_EMPTY = "El portapapeles está vacío"
    override val MINE_FILE_ERR = "No se pudo leer el archivo"
    override val MINE_CLEARED = "Lista importada borrada"
    override val MINE_CLEAR_ASK = "¿Borrar la lista importada?"
    override val MINE_CUT = "Se alcanzó el límite; el resto se omitió"
    override fun notifTimeout(name: String) = "$name no responde. Reintentando."
    override val MOD_DPI = "Evitar DPI"
    override val MOD_ADS = "Anuncios+"
    override val MOD_DPI_SUB = "Abre sitios bloqueados"
    override val MOD_ADS_SUB = "Bloquea más allá del DNS"
    override val MOD_ON = "Activo"
    override val MOD_OFF = "Inactivo"
    override val BLOCK_QUIC = "Bloquear QUIC"
    override val BLOCK_QUIC_NOTE = "Las apps vuelven a TCP, así que evitar DPI y Anuncios+ también las cubren"
    override val GW_TRIPPED = "Se detectó un problema de conexión: Evitar DPI y Anuncios+ se desactivaron"
    override fun gwOn(modules: String) = "Puerta de enlace activa: $modules"
    override fun gwOnStats(modules: String, blocked: String) = "Puerta de enlace activa: $modules · $blocked bloqueados"
    override fun modOn(name: String) = "$name activado"
    override fun modOff(name: String) = "$name desactivado"
    override fun modAdsCount(n: String) = "$n bloqueados"
    override fun modDpiCount(n: String) = "$n conexiones divididas"
    override fun latencyLine(avg: String, max: String, timeouts: Int) = "prom. $avg · máx. $max" + (if (timeouts > 0) " · $timeouts tiempos agotados" else "")
    override fun mineCount(n: Int) = "$n dominios"
    override fun mineAdded(n: Int) = "$n dominios añadidos"
    override fun mineCopied(n: Int) = "$n dominios copiados"
    override val CACHE = "Caché DNS"
    override val CLEAR_CACHE = "Vaciar caché"
    override val CACHE_CLEARED = "Caché vaciada"
    override val ONLY_CONNECTED = "Disponible mientras estás conectado"
    override val RULE_WIFI = "Servidor para wifi"
    override val RULE_MOBILE = "Servidor para datos móviles"
    override val RULE_AUTO = "Automático"
    override val RULE_AUTO_NOTE = "El último servidor que usaste"
    override val COMPACT = "Lista compacta"
    override val COMPACT_NOTE = "Filas más cortas, sin descripción"
    override val HIDDEN = "Servidores ocultos"
    override val HIDDEN_NONE = "Ninguno"
    override val STAT_QUERIES = "Consultas totales"
    override val STAT_HITS = "Respondidas desde caché"
    override val STAT_BLOCKED = "Bloqueadas (estimado)"
    override val STAT_TIME = "Tiempo total conectado"
    override val WEEK = "Últimos 7 días"
    override fun weekA11y(total: String) = "$total consultas en los últimos 7 días"
    override val WEEKDAYS = listOf("Lu", "Ma", "Mi", "Ju", "Vi", "Sá", "Do")
    override val EXPORT = "Exportar ajustes"
    override val IMPORT = "Importar ajustes"
    override val EXPORTED = "Código de ajustes copiado"
    override val IMPORTED = "Ajustes cargados"
    override val IMPORT_BAD = "No hay un código de ajustes válido en el portapapeles"
    override val RESET_SETTINGS = "Restablecer ajustes"
    override val RESET_STATS = "Restablecer estadísticas"
    override val CONFIRM = "¿Seguro?"
    override val RESET = "Restablecer"
    override val RESET_DONE = "Restablecido"
    override val LOG = "Registro de diagnóstico"
    override val HELP = "¿Cómo funciona?"
    override val VPN_SETTINGS = "Ajustes de VPN del sistema"
    override val SHARE_APP = "Compartir la app"
    override val RATE_APP = "Valorar la app"
    override val FEEDBACK = "Enviar comentarios"
    override fun shareAppText(url: String) = "$APP te conecta a DNS populares con un toque: $url"
    override val VERSION = "Versión"
    override val OPT_BUBBLES = listOf("No", "Pocas", "Muchas")
    override val OPT_MOTION = listOf("Todas", "Pocas", "No")
    override val OPT_CACHE = listOf("No", "Pequeña", "Normal", "Grande")
    override val OPT_ENCRYPTION = listOf("Auto", "DoT", "DoH", "No")
    override val PLAIN_DNS = "DNS sin cifrar"

    override val LOG_NOTE = "Solo se guardan eventos de conexión. Nunca nombres de consultas ni datos personales."
    override val LOG_EMPTY = "Aún no hay registros."
    override val SHARE = "Compartir"
    override val CLEAR = "Borrar"
    override val CLEARED = "Borrado"
    override val HELP_SECTIONS = listOf(
        "¿Qué es el DNS?" to
            "El DNS es el servicio que convierte direcciones de internet (como example.com) en números que entienden los dispositivos. " +
            "El DNS que uses puede influir en la velocidad, la privacidad y el contenido bloqueado.",
        "¿Qué hace la app?" to
            "Usa el servidor DNS que elijas en todas las apps. Para ello abre una interfaz VPN local en tu teléfono, " +
            "pero tu tráfico no va a ningún servidor VPN. Solo las consultas DNS se envían al servidor elegido; " +
            "todo lo demás sigue su camino normal.",
        "DNS cifrado (DoT / DoH)" to
            "En los servidores compatibles las consultas viajan cifradas: nadie en la red (dueño del wifi, operador) puede ver " +
            "qué sitios visitas ni alterar las respuestas. En Automático se prueba primero DoT y luego DoH; si ninguno funciona, " +
            "se usa DNS sin cifrar. Se te avisa cuando ocurre y la app intenta volver al cifrado en cada cambio de red y cada 10 minutos. " +
            "Con \"Cifrado estricto\" activado, nunca se usa DNS sin cifrar. La pantalla principal muestra el método en uso.",
        "Prueba de conexión" to
            "☰ > Ajustes de DNS > Prueba de conexión envía consultas DNS reales por el túnel. Muestra que " +
            "el DNS responde de verdad desde el servidor elegido, a qué velocidad, si el servidor valida las firmas DNSSEC " +
            "y si bloquea un dominio publicitario conocido.",
        "Privacidad" to
            "Sin cuenta, sin recopilación de datos, sin anuncios. La app no guarda nombres de consultas y no envía nada por su cuenta. " +
            "Tus consultas solo van al proveedor DNS elegido, bajo su propia política de privacidad. " +
            "El DNS cifrado (DoT/DoH) impide que cualquiera en la red lea o altere tus consultas. Antes de enviarlas, la app elimina datos adicionales que podrían identificar tu dispositivo (subred del cliente, cookies, identificadores), rellena los mensajes para ocultar su longitud y descarta los tickets de sesión TLS al cambiar de red. " +
            "Siendo sinceros: sin un relé, el proveedor DNS sigue viendo tu dirección IP pública (tiene que responderte), y un error de certificado puede significar que alguien interfiere en la conexión. " +
            "El registro de diagnóstico solo contiene eventos de conexión.",
        "Batería y recursos" to
            "En segundo plano consume muy poco. Con la pantalla apagada no hay bucles en marcha; " +
            "solo trabaja cuando llega una consulta DNS. Las conexiones cifradas se cierran solas cuando no se usan.",
        "Conviene saber" to
            "Android solo permite una VPN a la vez; si hay otra app de VPN activa, esta no podrá conectar. " +
            "La opción \"DNS seguro\" de algunos navegadores y el \"DNS privado\" de Android con un nombre fijo usan su propio servidor " +
            "y pueden saltarse esta redirección; basta con dejarlos en \"Automático\" o \"Desactivado\". " +
            "Mantén pulsada la esfera para cambiar rápido de servidor o pausar la conexión un rato.",
    )

    override val NOTIF_CHANNEL = "Estado de la conexión"
    override val NOTIF_CHANNEL_NOTE = "Se muestra mientras la conexión DNS está activa"
    override val NOTIF_ALERT_CHANNEL = "Avisos de conexión"
    override val NOTIF_CONNECTING = "Conectando…"
    override val NOTIF_STOP = "Desconectar"
    override val NOTIF_NEXT = "Siguiente"
    override val NOTIF_DROP_TITLE = "Se perdió la conexión DNS"
    override val NOTIF_RECONNECT = "Reconectar"
    override fun notifOn(name: String, proto: String) = "Conectado a $name · $proto"
    override fun notifPaused(time: String) = "En pausa · se reanuda a las $time"
    override val TILE_ON = "Conectado"
    override val TILE_OFF = "Desactivado"
    override val WIDGET_TAP = "Toca: conectar / desconectar"
    override val ERR_PERMISSION = "No se concedió el permiso de VPN"
    override val ERR_ESTABLISH = "No se pudo abrir la interfaz VPN. Puede haber otra VPN activa."
    override fun errNoReply(name: String) = "$name no respondió"
    override val PHONE_BYPASS = "El móvil no usa este DNS (¿DNS privado?)"
    override fun errNoProto(name: String, proto: String) = "$name no admite $proto"
    override val ERR_SOCKET = "No se pudo acceder a la red"
    override fun errPrivateDns(host: String) = "El DNS privado de Android está fijado en $host y se salta esta app. Pon Ajustes > Red > DNS privado en Automático o Desactivado."
    override val ERR_REVOKED = "El sistema cerró la conexión"
    override val ERR_TUNNEL = "El túnel se cerró de forma inesperada"
    override val ERR_UNKNOWN = "Ocurrió un error inesperado"

    override val CONSENT_TITLE = "Antes de conectar"
    override val CONSENT_BODY = listOf(
        "$APP usa la interfaz VPN de Android para dirigir tus consultas DNS (los nombres de los sitios que visitas) al servidor DNS que elijas.",
        "Tu tráfico no se envía a ningún servidor VPN; solo las consultas DNS van al proveedor elegido. En los servidores compatibles " +
            "se cifran (DoT/DoH); en los demás viajan sin cifrar. Se aplica la política de privacidad del proveedor." +
            " Si activas «$MOD_DPI» o «$MOD_ADS», todo el tráfico pasa por un relé que funciona solo dentro del teléfono; tampoco se envía a ningún otro sitio.",
        "La app no recopila datos personales, no guarda nombres de consultas y no comparte nada.",
        "Si continúas, Android mostrará una solicitud de conexión VPN; debes tocar \"Aceptar\".",
    )
    override val CONSENT_OK = "Entendido, continuar"
    override val CLOSE = "Cerrar"
    override val BACK = "Atrás"

    // ---- 3. sürüm ----
    override val RESUMING = "Reanudando…"
    override val DOWNGRADED = "No se pudo cifrar, usando DNS sin cifrar"
    override val UPGRADED = "De nuevo con DNS cifrado"
    override val NOTIF_DOWNGRADE_TITLE = "El DNS no está cifrado"
    override fun notifDowngrade(name: String) = "No se pudo establecer una conexión cifrada con $name. Se usa DNS sin cifrar; la app intentará volver al cifrado."
    override fun backupUsed(failed: String, used: String) = "$failed no respondió, conectado a $used"
    override val NOTIF_RETRYING = "Conexión perdida, reintentando…"
    override fun errNoEncrypted(name: String) = "No se pudo establecer una conexión cifrada con $name"
    override fun errUntrusted(name: String) = "No se pudo verificar el certificado de $name; la red o un programa podría estar interfiriendo en las conexiones cifradas"
    override val APPLYING = "Aplicando el nuevo ajuste a la conexión"
    override val CONFIRM_DISCONNECT = "¿Desconectar?"
    override val DISCONNECT = "Desconectar"

    override val SEC_NOTIF = "Notificaciones"
    override val STRICT_ENC = "Cifrado estricto"
    override val STRICT_ENC_NOTE = "Nunca recurrir a DNS sin cifrar"
    override val IP_MODE = "Versión de IP"
    override val IP_MODE_NOTE = "Se prueba primero la que tenga tu red; la otra queda de respaldo"
    override val OPT_IP_MODE = listOf("IPv4 + IPv6", "Solo IPv4")
    override val FILTER = "Bloqueo"
    override val FILTER_LEVEL = "Anuncios y rastreadores"
    override val OPT_FILTER = listOf(
        "No",
        "Básico",
        "Medio",
        "Estricto",
    )
    override val FILTER_NOTES = listOf(
        "No se bloquea nada.",
        "Sitios conocidos de anuncios, phishing y malware. Riesgo muy bajo de fallos.",
        "Básico más rastreadores y analíticas. Algunos sitios pueden dar problemas.",
        "La lista más amplia, también fraude, abuso y redirecciones. Habrá fallos frecuentes.",
    )
    override val FILTER_INFO = "El bloqueo se hace por completo en tu teléfono: si se consulta un sitio de la lista, se responde 0.0.0.0, la consulta no va a ningún servidor y no se guarda ningún nombre. Solo funciona con la conexión activa. El DNS seguro propio de un navegador puede saltárselo. Si un sitio falla, permítelo en Bloqueados recientes."
    override val FILTER_LAST = "Bloqueados recientes"
    override val FILTER_RECENT_NOTE = "Toca: permitir"
    override val FILTER_RECENT_EMPTY = "Nada bloqueado en esta sesión. Los nombres aparecen aquí con la conexión activa y un nivel elegido."
    override val FILTER_RECENT_FOOT = "Solo en memoria durante esta sesión; no se guarda y se borra al desconectar."
    override val FILTER_ALLOW = "Permitidos"
    override val FILTER_BLOCK = "Mi lista de bloqueo"
    override val FILTER_ADD = "Añadir…"
    override val FILTER_REMOVE = "Toca: quitar"
    override val FILTER_ALLOW_ADD = "Dominio a permitir"
    override val FILTER_BLOCK_ADD = "Dominio a bloquear"
    override val FILTER_ERR = "Escribe un dominio válido, p. ej. ejemplo.com"
    override val FILTER_ERR_LIMIT = "Máximo 200 dominios"
    override val FILTER_ALLOW_EMPTY = "No hay dominios permitidos. Si un sitio falla, añádelo aquí."
    override val FILTER_BLOCK_EMPTY = "Tu lista de bloqueo está vacía."
    override val FILTER_ALLOW_FOOT = "El dominio y todos sus subdominios nunca se bloquean. Permitir gana a todas las listas y a tu lista de bloqueo."
    override val FILTER_BLOCK_FOOT = "El dominio y todos sus subdominios se bloquean siempre (incluso con el nivel desactivado)."
    override val FILTER_REMOVE_BTN = "Quitar"
    override fun filterAllowed(name: String) = "$name permitido"
    override fun filterBlocked(name: String) = "$name se bloqueará"
    override fun filterRemoved(name: String) = "$name quitado"
    override fun filterRemoveAsk(name: String) = "¿Quitar $name de la lista?"
    override val TEST_IPV6 = "Ruta IPv6"
    override val AUTO_RECONNECT = "Reconectar automáticamente"
    override val AUTO_RECONNECT_NOTE = "Si se corta la conexión, reintenta tras 5 s, 30 s y 2 min"
    override val BACKUP_SERVER = "Servidor de respaldo"
    override val BACKUP_OFF = "Desactivado"
    override val BACKUP_OFF_NOTE = "No conectar si el servidor elegido no responde"
    override val BACKUP_FASTEST = "El más rápido"
    override val BACKUP_FASTEST_NOTE = "El otro servidor más rápido de la última medición"
    override val CONFIRM_OFF = "Confirmar desconexión"
    override val CONFIRM_OFF_NOTE = "Un toque accidental en la esfera no desconecta"
    override val LOCK_HIDE = "Ocultar en pantalla bloqueada"
    override val LOCK_HIDE_NOTE = "No muestra el servidor en la notificación de la pantalla de bloqueo"
    override val QUIET_NOTIF = "Notificación discreta"
    override val QUIET_NOTIF_NOTE = "Sin icono en la barra de estado, silenciosa"
    override val REMEMBER_FILTER = "Recordar el último filtro"
    override val REMEMBER_FILTER_NOTE = "Al abrir la app vuelve el último filtro que elegiste"
    override val AUTO_MEASURE = "Medir al abrir"
    override val AUTO_MEASURE_NOTE = "Mide automáticamente si la última medición tiene más de un día"
    override val MEASURE_ENC = "Medición cifrada"
    override val MEASURE_ENC_NOTE = "Mide la velocidad por DoT, más cerca del uso cifrado real"
    override val OPT_SORT = listOf("Estándar", "Velocidad", "Nombre")
    override fun sortA11y(mode: String) = "Orden: $mode"
    override val AUTO_LIGHT = "Automático: tema claro"
    override val AUTO_DARK = "Automático: tema oscuro"
    override val NIGHT_HOURS = "Horas nocturnas"
    override val FILTER_ENCRYPTED = "Cifrados"
    override val FILTER_UNFILTERED = "Sin filtro"

    override val TEST = "Probar la conexión"
    override val TEST_NOTE = "DNS, DNSSEC y bloqueo de anuncios"
    override val TESTING = "Probando…"
    override val TEST_TITLE = "Prueba de conexión"
    override val TEST_OK = "El DNS funciona"
    override val TEST_FAIL = "Sin respuesta"
    override val TEST_SERVER = "Servidor"
    override val TEST_METHOD = "Método"
    override val TEST_LATENCY = "Tiempo de respuesta"
    override val TEST_DNSSEC = "Validación DNSSEC"
    override val TEST_ADS = "Bloqueo de anuncios"
    override val DNSSEC_YES = "Activa"
    override val DNSSEC_NO = "Inactiva"
    override val ADS_YES = "Activo"
    override val ADS_NO = "Inactivo"
    override val UNKNOWN = "Desconocido"
    override val TEST_EXPLAIN = "Las consultas pasaron por el túnel, igual que las de una app; las respuestas vinieron del servidor elegido."
    override val TEST_AGAIN = "Probar de nuevo"

    override val RECOMMEND = "Buscar un servidor para mí"
    override val RECOMMEND_NOTE = "Elige tu objetivo y te conectamos al más rápido que encaje"
    override val GOAL_SPEED = "Velocidad"
    override val GOAL_SPEED_NOTE = "El servidor más rápido según tus mediciones"
    override val GOAL_PRIVACY_NOTE = "Sin registros, centrado en la privacidad"
    override val GOAL_ADS_NOTE = "Bloquea anuncios y rastreadores"
    override val GOAL_FAMILY_NOTE = "Bloquea contenido para adultos"
    override val GOAL_SECURITY_NOTE = "Bloquea sitios maliciosos y de phishing"
    override fun recommended(name: String) = "Recomendado: $name"

    override val PRIVATE_DNS = "Nombre de DNS privado"
    override val PRIVATE_DNS_NOTE = "Puedes pegarlo en el ajuste \"DNS privado\" de Android. Así el sistema usa este servidor directamente y esta app queda al margen."
    override val CLEAR_HISTORY = "Borrar mediciones"
    override val HISTORY_CLEARED = "Mediciones borradas"

    override val GUARD = "Protección continua"
    override val GUARD_NOTE = "VPN siempre activada"
    override val GUARD_BODY = listOf(
        "Mientras la app no está conectada (apagada, en pausa o tras un corte), tus consultas DNS van al servidor de tu proveedor de internet.",
        "Para evitarlo, activa \"VPN siempre activada\" para esta app en los ajustes de VPN de Android. Si también activas \"Bloquear conexiones sin VPN\", internet no funcionará mientras la app no esté conectada: no hay fugas, pero pausar también significa quedarse sin internet.",
        "Con la VPN siempre activada, el sistema inicia la app automáticamente al encender el teléfono y cuando se detiene.",
    )
    override val GUARD_BUTTON = "Abrir ajustes de VPN"
    override val BATTERY = "Ajustes de batería"
    override val BATTERY_OK = "Sin restricciones"
    override val BATTERY_LIMITED = "Puede estar restringida"
    override val BATTERY_BODY = listOf(
        "Android suele proteger las apps de VPN. Aun así, algunos fabricantes (Xiaomi, Huawei, Oppo, Vivo, algunas versiones de Samsung) pueden cerrar apps en segundo plano para ahorrar batería.",
        "Si la conexión se corta sola una y otra vez, pon el uso de batería de esta app en \"Sin restricciones\" o \"No optimizada\"; en algunos teléfonos permite también el \"Inicio automático\".",
    )
    override val BATTERY_BUTTON = "Abrir ajustes de batería"

    override val STAT_AVG = "Tiempo medio de respuesta"
    override val STAT_SAVED = "Tiempo ahorrado por la caché"
    override val STAT_TRAFFIC = "Tráfico DNS"
    override val SESSIONS = "Historial de conexiones"
    override val SESSIONS_NOTE = "Últimas 30 conexiones; nunca se guardan nombres de consultas"
    override val SESSIONS_EMPTY = "Aún no hay conexiones registradas."
    override val MOST_USED = "Más usados"
    override val TODAY = "Hoy"
    override val YESTERDAY = "Ayer"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Desconectaste tú"
        EndReason.PAUSE -> "En pausa"
        EndReason.SWITCH -> "Cambio de servidor"
        EndReason.DROP -> "Se cortó"
        EndReason.REVOKED -> "Cerrada por el sistema"
        EndReason.FAILED -> "Sin respuesta"
        EndReason.NETWORK -> "Cambio de red"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries consultas"

    override val SOUND_MOTION = "Sonido y movimiento"
    override val SEC_SOUND = "Sonido"
    override val SOUND_ON = "Efectos de sonido"
    override val SOUND_ON_NOTE = "Sonidos breves y suaves al tocar y al conectar. No suenan si el teléfono está en silencio."
    override val SOUND_UI = "Sonidos al tocar"
    override val SOUND_UI_NOTE = "Botones, interruptores y cambios de página"
    override val SOUND_CONN = "Sonidos de conexión"
    override val SOUND_CONN_NOTE = "Sonidos distintos al conectar, desconectar y en errores"
    override val SOUND_VOL = "Volumen"
    override val SOUND_PACK = "Paquete de sonidos"
    override val SOUND_TEST = "Probar el sonido de conexión"
    override val QUIET_HOURS = "Horas de silencio"
    override val QUIET_NOTE = "Sin sonidos ni vibración en estas horas"
    override val QUIET_RANGE = "Horario de silencio"
    override val SEC_MOTION_FX = "Movimiento y efectos"
    override val ANIM_SPEED = "Velocidad de animación"
    override val TAP_FX = "Efecto al tocar"
    override val TAP_FX_NOTE = "Un pequeño efecto propio del estilo donde tocas"
    override val CELEBRATE = "Celebración al conectar"
    override val CELEBRATE_NOTE = "Un espectáculo propio del estilo alrededor de la esfera al conectar"
    override val HAPTIC_LEVEL = "Intensidad de vibración"
    override val REMEMBER_MODS = "Recordar módulos"
    override val REMEMBER_MODS_NOTE = "Al conectar, Evitar DPI y Anuncios+ se activan como los dejaste"
    override val PROFILES = "Perfiles"
    override val COPY_STATUS = "Copiar resumen del estado"
    override val OPT_PACK = listOf("Auto", "Suave", "Cristal", "Clásico")
    override val SOUND_PACK_NOTE = "Auto: el sonido de tu estilo actual"
    override val OPT_HAPTIC = listOf("Suave", "Normal", "Fuerte")
    override val PROFILE_NAMES = listOf("Velocidad", "Privacidad", "Familia", "Protección total")
    override val PROFILE_NOTES = listOf("Servidor más rápido, caché grande, sin bloqueo", "Cifrado estricto, bloqueo de rastreadores, Anuncios+", "Servidor con filtro familiar, bloqueo medio", "Bloqueo de anuncios y rastreadores, Evitar DPI, Anuncios+")
    override fun profileApplied(name: String) = "Perfil aplicado: $name"

    override val WHATS_NEW = "¿Qué hay de nuevo?"
    override val WHATS_NEW_TOAST = "La app se ha actualizado"
    override val SHOW = "Ver"
    override val WHATS_NEW_ITEMS = listOf(
        "Novedad: efectos de sonido, motor de animación fluido reescrito, efectos al tocar por estilo, perfiles, horas de silencio y más. ☰ > Sonido y movimiento.",
        "Nuevo: botones Evitar DPI y Anuncios+. Funcionan junto al DNS o solos; ambos vienen desactivados.",
        "Nuevo: importa tu lista de bloqueo, avisos de conexión, corte y tiempo agotado, gráfico de latencia por consulta y bloqueo de DNS si se corta.",
        "Nuevo: la lista muestra primero 8 (Mostrar todo / Mostrar menos), Añadir DNS personalizado arriba y barra de desplazamiento fina.",
        "Nuevo: bloqueo de anuncios, rastreadores y malware (No/Básico/Medio/Estricto) con listas propias de permitir y bloquear. ☰ > Bloqueo. Todo local.",
        "Nuevo: estilo Frutiger Aurora; Y2K ahora holográfico y Metro con ciudad y música. Elígelo en ☰ > Personalizar > Estilo.",
        "Nuevo: IPv4 e IPv6 juntos, detección de fallos más rápida; por privacidad se eliminan rastros del dispositivo y se oculta la longitud de los mensajes.",
        "Nuevo: ajustes separados por temas. En el menú ☰: DNS, Conexión y apps, Notificaciones, Lista de servidores, Estadísticas e historial, Datos.",
        "Nuevo: ventana Personalizar (en el menú ☰): idioma, tema, estilo, fondo, icono, texto y accesibilidad.",
        "Nuevo: menú ☰ en la pantalla de inicio y una ventana Acerca de (novedades, ayuda, registro, compartir, versión).",
        "Arreglo: ya funciona poner tu foto o una imagen incluida como fondo (el tamaño de la foto se leía mal).",
        "Arreglo: la prueba de conexión distingue un fallo del servidor de un teléfono que no usa el DNS y avisa en el segundo caso.",
        "Corrección: estilos Metro, Eco y Y2K redibujados; el cambio de icono se aplica al salir de la app.",
        "Nuevo: 8 fondos incluidos (☰ → Personalizar → Foto de fondo → Imágenes incluidas).",
        "Novedad: solucionador de problemas, búsqueda de servidores, compartir resultados, editar servidores propios y opción de no guardar historial.",
        "Icono de la app: elige uno de cinco iconos que combinan con los cinco estilos.",
        "Foto de fondo: usa tu propia imagen como fondo, con velo y desenfoque ajustables; el texto siempre se lee bien.",
        "Cinco estilos: Aqua (clásico), Aero (cielo y hierba), Metro (mosaicos planos), Eco (naturaleza) y Y2K rosa, cada uno con sus animaciones y transiciones más fluidas.",
        "Selección de apps: aplica el DNS solo a las apps que elijas o deja algunas fuera.",
        "Añade tus propios servidores DNS (hasta 8), 10 servidores nuevos y una sección de información en cada servidor: para qué sirve, propietario y ping medio.",
        "Conexión más segura: controles extra contra respuestas DNS falsas, aviso al pasar a DNS sin cifrar, opción de cifrado estricto y vuelta automática al cifrado.",
        "Prueba de conexión: comprueba con un toque que el DNS responde desde el servidor elegido, además de la validación DNSSEC y el bloqueo de anuncios.",
        "Servidor de respaldo y reconexión automática: la app se recupera sola si el servidor elegido no responde o se corta la conexión.",
        "Historial de conexiones, servidores más usados, tiempo medio de respuesta y tráfico DNS.",
        "Nuevos filtros (Cifrados, Sin filtro), orden por nombre, \"Buscar un servidor para mí\" y medición al abrir.",
        "Contadores en vivo en la notificación, botón de pausa de 15 minutos, ocultación en la pantalla de bloqueo y opción de notificación discreta.",
        "Tres temas nuevos (Sakura, Miel, Aurora boreal), un tema a partir de tu fondo de pantalla y elección claro/oscuro para el tema automático.",
        "Cuatro idiomas nuevos: indonesio, vietnamita, polaco y ucraniano.",
    )
    override fun importedWith(changes: String) = "Ajustes cargados · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "cifrado debilitado"
        SensitiveChange.AUTO_START -> "conexión automática activada"
        SensitiveChange.RULES -> "reglas de servidor cambiadas"
        SensitiveChange.PRIVACY -> "ajustes de privacidad o alertas reducidos"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries consultas · $blocked bloqueadas"
    override val NOTIF_LOCKED = "Protección DNS activa"
    override val NOTIF_QUIET_CHANNEL = "Estado de la conexión (discreta)"
    override fun widgetToday(queries: String) = "Hoy $queries consultas"
    override fun pauseAction(minutes: Int) = "Pausar ${minutes(minutes)}"


    override val CUSTOM_NOTE = "Servidor que añadiste"
    override val CUSTOM_ADD = "Añadir DNS personalizado"
    override val CUSTOM_F_NAME = "Nombre"
    override val CUSTOM_F_IP1 = "Dirección IPv4 (p. ej. 1.2.3.4)"
    override val CUSTOM_F_IP2 = "Segunda IPv4 (opcional)"
    override val CUSTOM_F_DOT = "Nombre DoT (opcional)"
    override val CUSTOM_F_DOH = "Dirección DoH, https://… (opcional)"
    override val CUSTOM_SAVE = "Añadir"
    override val CUSTOM_CANCEL = "Cancelar"
    override val CUSTOM_HINT = "Rellena DoT o DoH para una conexión cifrada; si lo dejas vacío se usa DNS sin cifrar."
    override val CUSTOM_ERR_NAME = "El nombre debe tener 1–24 caracteres (sin | ; , =)"
    override val CUSTOM_ERR_IP = "Escribe una dirección IPv4 válida (p. ej. 1.2.3.4)"
    override val CUSTOM_ERR_DOT = "El nombre DoT debe ser un dominio válido"
    override val CUSTOM_ERR_DOH = "La dirección DoH debe empezar por https://"
    override val CUSTOM_ERR_LIMIT = "Puedes añadir hasta 8 servidores propios"
    override fun customAdded(name: String) = "$name añadido"
    override val CUSTOM_DELETE = "Eliminar este servidor"
    override val CUSTOM_IN_USE = "No se puede eliminar mientras está conectado"
    override fun customDeleted(name: String) = "$name eliminado"
    override val INFO_PURPOSE = "Para qué sirve"
    override val INFO_OWNER = "Propietario"
    override val INFO_AVG = "Ping medio"
    override fun avgPing(ms: Int, n: Int) = "$ms $msU · $n mediciones"

    override val APPS = "Aplicaciones"
    override val APPS_ALL = "Todas"
    override fun appsOnly(n: Int) = "Solo las seleccionadas ($n)"
    override fun appsExcept(n: Int) = "Todas menos las seleccionadas ($n)"
    override val APPS_MODE = "¿Qué apps usan este DNS?"
    override val OPT_APPS = listOf("Todas", "Solo selec.", "Todas menos selec.")
    override val APPS_NOTE = "Las apps no incluidas usan el DNS del teléfono. Solo funciona un servidor DNS a la vez; no se puede elegir uno distinto por app."
    override val APPS_LOADING = "Cargando aplicaciones…"
    override val APPS_EMPTY = "No se encontraron aplicaciones"
    override val APPS_NONE_SELECTED = "Ninguna app seleccionada: el DNS se aplica a todas."
    override val APPS_APPLY = "Aplicar ahora"
    override val APPS_PENDING = "El cambio se aplica al renovar la conexión (se corta un par de segundos)."

    override val NOTES = mapOf(
        "cloudflare" to "Rápido, centrado en la privacidad",
        "google" to "Estable, muy usado",
        "quad9" to "Bloquea dominios maliciosos",
        "adguard" to "Bloquea anuncios y rastreadores",
        "controld" to "Sin filtros, rápido",
        "opendns" to "Cisco, protección antiphishing",
        "dnssb" to "Centrado en la privacidad, rápido",
        "dns4eu" to "DNS de la UE, contra malware",
        "uncensored" to "Sin filtros ni redirecciones",
        "quad9-open" to "No bloquea nada",
        "adguard-open" to "Sin bloqueos, centrado en privacidad",
        "dns4eu-open" to "DNS de la UE, sin filtros",
        "controld-ads" to "Anuncios, rastreadores, malware",
        "dns4eu-ads" to "DNS de la UE, anuncios y malware",
        "cloudflare-security" to "Bloquea sitios maliciosos",
        "controld-malware" to "Bloquea sitios maliciosos",
        "cleanbrowsing-security" to "Phishing y sitios maliciosos",
        "cloudflare-family" to "Filtro de malware y adultos",
        "opendns-family" to "Filtro de contenido adulto",
        "adguard-family" to "Filtro de anuncios y adultos",
        "cleanbrowsing-family" to "Contenido adulto, búsqueda segura",
        "dns4eu-child" to "DNS de la UE, protección infantil",
        "controld-family" to "Filtro de contenido adulto",
        "nextdns" to "Filtro configurable, rápido",
        "cira-private" to "Canadá, sin filtros, privacidad",
        "cira-protected" to "Canadá, bloquea sitios maliciosos",
        "libredns" to "Independiente, sin filtros",
        "switch" to "Suiza, bloquea sitios maliciosos",
        "wikimedia" to "DNS de Wikimedia, privacidad",
        "digitale" to "ONG suiza, sin filtros",
        "quad101" to "Taiwán, rápido",
        "alidns" to "China, rápido",
    )
}
