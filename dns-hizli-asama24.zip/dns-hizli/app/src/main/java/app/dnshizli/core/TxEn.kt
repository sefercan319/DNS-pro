package app.dnshizli.core

/** English. Also the fallback for unsupported system languages. */
object TxEn : Tx() {
    override val lang = Lang.EN

    override val decimalSep = '.'
    override val thousand = "K"
    override val million = "M"
    override fun percent(n: Int) = "$n%"
    override val dayU = "d"
    override val hourU = "h"
    override val minU = "min"
    override val secU = "s"
    override val justNow = "just now"
    override fun ago(span: String) = "$span ago"

    override val OFF = "Not connected"
    override val CONNECTING = "Connecting…"
    override val ON = "Connected"
    override val ERROR = "Couldn't connect"
    override val PAUSED = "Paused"
    override val HINT_OFF = "Tap the orb to connect"
    override val HINT_CONNECTING = "This may take a few seconds"
    override val HINT_ERROR = "Tap to try again"
    override val HINT_PAUSED = "Tap to resume now"
    override val ERR_DEFAULT = "Connection failed"
    override fun selected(name: String) = "$name selected"
    override fun pausedUntil(time: String) = "Resumes at $time"
    override fun blockedShort(n: String) = "$n blocked"
    override fun queriesShort(n: String) = "$n queries"
    override fun cacheShort(pct: String) = "$pct cached"

    override val SERVERS = "Servers"
    override val FILTER_ALL = "All"
    override val FILTER_FAV = "Favorites"
    override val FILTER_RECENT = "Recent"
    override val EMPTY_FAV = "No favorites yet. Tap a server's star."
    override val EMPTY_RECENT = "You haven't connected to a server yet."
    override val EMPTY_FILTER = "No servers in this category."
    override val MEASURE = "Measure speeds"
    override val MEASURING = "Measuring…"
    override val SORT = "Sort order"
    override val PULL_TO_MEASURE = "Pull to measure speeds"
    override val RELEASE_TO_MEASURE = "Release to measure"
    override fun serversCount(n: Int) = if (n == 1) "1 server" else "$n servers"
    override fun showAllServers(n: Int) = "Show all ($n)"
    override val SHOW_LESS = "Show less"
    override val TAG_FAST = "Fast"
    override val TAG_PRIVACY = "Privacy"
    override val TAG_ADS = "Ad-block"
    override val TAG_FAMILY = "Family"
    override val TAG_SECURITY = "Security"
    override val VAR_OPEN = "Unfiltered"
    override val VAR_ADS = "Ad-block"
    override val VAR_SECURITY = "Security"
    override val VAR_FAMILY = "Family"
    override val A11Y_CONNECTED = "connected"
    override val A11Y_ENCRYPTED = "encrypted"
    override fun favA11y(name: String) = "$name favorite"

    override val COPIED = "Copied to clipboard"
    override val DISCONNECTED = "Disconnected"
    override val BACKUP = "Switched to backup server"
    override val NO_REPLY = "No server replied"
    override val MEASURE_FIRST = "Measure speeds first"
    override val CONNECT = "Connect"
    override val UNDO = "Undo"
    override fun fastest(name: String, ms: Int) = "Fastest: $name · $ms ms"
    override fun switched(name: String) = "Switching to $name"
    override fun hiddenToast(name: String) = "$name hidden"

    override val PRIMARY = "Primary"
    override val SECONDARY = "Secondary"
    override val COPY = "Copy"
    override fun addressA11y(label: String, ip: String) = "$label address: $ip"
    override val CONNECT_TO_THIS = "Connect to this server"
    override val SWITCH_TO_THIS = "Switch to this server"
    override val CONNECTED_NOW = "Connected now"
    override val ADD_FAV = "Add to favorites"
    override val REMOVE_FAV = "Remove favorite"
    override val MEASURE_THIS = "Measure speed"
    override val HIDE = "Hide from list"
    override val UNHIDE = "Show in list"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Last check: no reply · $ago" else "Last check: $ms ms · $ago"
    override val NEVER_MEASURED = "Not measured yet"
    override val ENC_SUPPORT = "Encrypted DNS"
    override val ENC_NONE = "Not supported"
    override val ENC_ONLY = "Accepts encrypted connections only"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Best $best ms · median $median ms · loss $lossPct%"
    override val HISTORY = "Speed history"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: $n checks, no reply" else "$HISTORY: $n checks, median $median ms"

    override val QUICK_TITLE = "Quick switch"
    override val QUICK_FAVORITES = "Favorites"
    override val QUICK_RECENT = "Recently used"
    override val PAUSE_FOR = "Pause"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} h" else "$n min"
    override val RESUME = "Resume"

    override val SETTINGS = "Settings"
    override val MENU = "Menu"
    override val PERSONALIZE = "Personalize"
    override val PZ_BACKGROUND = "Background"
    override val PZ_AUTO = "Automatic theme"
    override val PZ_FEEL = "Glass, text and motion"
    override val PZ_ACCESS = "Accessibility and power"
    override val DNS_SETTINGS = "DNS settings"
    override val CONN_APPS = "Connection & apps"
    override val STATS_HISTORY = "Statistics & history"
    override val SEC_LOOK = "Appearance"
    override val SEC_LIST = "Server list"
    override val SEC_DATA = "Data"
    override val ABOUT = "About"
    override val LANGUAGE = "Language"
    override val LANG_AUTO = "Automatic (system language)"
    override val THEME = "Theme"
    override val THEME_AUTO = "Automatic"
    override val THEME_AUTO_NOTE = "Automatic · follows system light/dark"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Meadow"
        "ocean" -> "Ocean"
        "sunset" -> "Sunset"
        "lavender" -> "Lavender"
        "coral" -> "Coral"
        "mint" -> "Mint"
        "sakura" -> "Sakura"
        "honey" -> "Honey"
        "night" -> "Night"
        "amoled" -> "Black (AMOLED)"
        "aurora" -> "Aurora"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Theme: $name"
    override val THEME_SCHEDULE = "Night theme on a schedule"
    override val THEME_SCHEDULE_NOTE = "In Automatic, the dark theme during the hours you pick"
    override val GLASS = "Glass opacity"
    override val BUBBLES = "Bubbles"
    override val STYLE = "Style"
    override val STYLE_NOTES = listOf(
        "Glassy, glossy, bubbly: the original look.",
        "Sky, green grass, glass droplets and gel buttons.",
        "City, music and youth: skyscrapers, a speaker, rings, stars and rays.",
        "Nature meets tech: green Earth, wind turbines, solar panels and leaves.",
        "Holographic pink and purple, chrome hearts, bubbles, sparkles and pixel windows.",
        "Turquoise, green and yellow light, a bright beam and see-through mesh waves.",
    )
    override val WALLPAPER = "Background photo"
    override val WP_OFF = "None"
    override val WP_ON = "Photo"
    override val WP_PICK = "Choose a photo from gallery"
    override val WP_PICK_NOTE = "Stays on your phone, never uploaded. The veil strengthens automatically when needed to keep text readable."
    override val WP_PRESETS = "Built-in pictures"
    override val WP_PRESETS_NOTE = "8 pictures that come with the app. No internet needed."
    override val WP_REMOVE = "Remove photo"
    override val WP_DIM = "Veil strength"
    override val WP_BLUR = "Blur"
    override val OPT_WP_BLUR = listOf("Off", "Soft", "Strong")
    override val WP_SAVED = "Background set"
    override val WP_FAILED = "Couldn't open the photo"
    override val WP_REMOVED = "Background removed"
    override val APP_ICON = "App icon"
    override val ICON_NOTES = listOf(
        "Glass globe: the original icon.",
        "A glass drop over sky and grass.",
        "Lime-turquoise city with sun rays and a power button.",
        "A glossy green Earth with a sprouting leaf.",
        "A glossy chrome heart on holographic pink and purple.",
        "A glass globe over a turquoise-to-yellow glow and light waves.",
    )
    override val ICON_SET = "Icon changes after you exit"
    override val ICON_NOTE = "If the home screen shortcut disappears, add the app again."
    override val ICON_FAILED = "Couldn't change the icon"
    override val HELP_WHY_TITLE = "Why this app?"
    override val HELP_WHY_BODY = "DNS Hızlı is small and simple, built by one person with no big company behind it. No account, no ads: you choose your DNS, the encryption, which apps it applies to, and how it looks."
    override val HELP_WHY_TAIL = "Maybe it's not better than its competitors, but it works, and it's worth a try."
    override val TROUBLE = "Troubleshoot"
    override val TROUBLE_RECHECK = "Check again"
    override val TROUBLE_ALL_OK = "Everything looks fine. If it still won't connect, try another server."
    override val TROUBLE_SOME = "Things that need attention:"
    override val T_NET = "Internet"
    override val NET_OK = "connected."
    override val NET_BAD = "missing or limited. Check Wi-Fi or mobile data."
    override val T_PERM = "VPN permission"
    override val PERM_OK = "granted."
    override val PERM_BAD = "not granted yet. Android will ask when you try to connect; allow it."
    override val T_VPN = "Other VPN"
    override val VPN_OK = "none."
    override val VPN_BAD = "seems to be on. Android allows only one VPN at a time; turn it off."
    override val T_DNS = "Android Private DNS"
    override val PDNS_OK = "off or automatic, no problem."
    override val PDNS_BAD = "is pinned to one server and may bypass this app's DNS. In Settings > Network > Private DNS choose Automatic or Off."
    override val SEARCH = "Search"
    override val SEARCH_HINT = "Server name or owner"
    override val SEARCH_CLEAR = "Clear"
    override val SHARE_RESULTS = "Share measurement results"
    override val SHARE_RESULTS_HEAD = "DNS Hızlı measurements (fastest first)"
    override val NO_RESULTS = "Run a measurement first"
    override val CUSTOM_EDIT = "Edit"
    override fun customUpdated(name: String) = "$name updated"
    override val KEEP_HISTORY = "Keep history"
    override val KEEP_HISTORY_NOTE = "When off, recent servers, history and measurements aren't recorded. Existing data stays."
    override val MOTION = "Animations"
    override val TEXT_SIZE = "Text size"
    override val HIGH_CONTRAST = "High contrast"
    override val HIGH_CONTRAST_NOTE = "More opaque glass and darker text"
    override val MINIMAL = "Minimal view"
    override val MINIMAL_NOTE = "Hides filters and the stats line"
    override val LOW_POWER = "Low power mode"
    override val LOW_POWER_NOTE = "Turns off all motion, battery friendly"
    override val HAPTICS = "Vibration"
    override val HAPTICS_NOTE = "Light feedback on touch"
    override val ENCRYPTION = "Encrypted DNS"
    override val ENCRYPTION_NOTE = "Auto: DoT first, then DoH, plain DNS last"
    override val AUTO_CONNECT = "Connect when app opens"
    override val AUTO_CONNECT_NOTE = "Connects to the last server when you open the app"
    override val CONNECT_ON_BOOT = "Connect on startup"
    override val CONNECT_ON_BOOT_NOTE = "Connects automatically after the phone restarts"
    override val AUTO_FASTEST = "Connect to the fastest"
    override val AUTO_FASTEST_NOTE = "Tapping the orb picks the fastest server from the last check"
    override val REFRESH_ON_NET = "Refresh on network change"
    override val REFRESH_ON_NET_NOTE = "DNS is refreshed when switching between Wi-Fi and mobile data"
    override val NOTIFY_DROP = "Notify if connection drops"
    override val NOTIFY_DROP_NOTE = "A notification with a reconnect button on unexpected drops"
    override val NOTIFY_CONNECT = "Notify when connected"
    override val NOTIFY_CONNECT_NOTE = "A short notification when the connection is up"
    override val NOTIFY_STOP = "Notify when turned off"
    override val NOTIFY_STOP_NOTE = "A short notification when you disconnect"
    override val NOTIFY_TIMEOUT = "Notify on timeouts"
    override val NOTIFY_TIMEOUT_NOTE = "A notification if the DNS server stops answering"
    override val NOTIF_PERM = "System notification permission"
    override val PERM_ALLOWED = "Allowed"
    override val PERM_BLOCKED = "Off · fix"
    override val NOTIF_CONNECTED_TITLE = "DNS connected"
    override val NOTIF_STOPPED_TITLE = "DNS disconnected"
    override val NOTIF_STOPPED_TEXT = "Protection is off"
    override val NOTIF_TIMEOUT_TITLE = "DNS timed out"
    override val FAIL_CLOSED = "Block DNS if it stays down"
    override val FAIL_CLOSED_NOTE = "If the connection drops, DNS queries don't leak to your carrier; they fail until it reconnects"
    override val NOTIF_SEALED = "DNS blocked while reconnecting"
    override val ERR_SEALED = "Couldn't connect. DNS is blocked so queries don't leak. Tap Stop to release it."
    override val SEALED_INFO = "DNS is blocked until the connection returns"
    override val LATENCY_TITLE = "Latency per query"
    override val LATENCY_EMPTY = "Shows live once you're connected and queries arrive"
    override val FILTER_MINE = "My own list"
    override val MINE_PASTE = "Import from clipboard"
    override val MINE_PASTE_NOTE = "A hosts file or one domain per line"
    override val MINE_FILE = "Import from a file"
    override val MINE_FILE_NOTE = "A .txt or hosts file on your phone"
    override val MINE_EXPORT = "Copy my block list"
    override val MINE_EXPORT_NOTE = "To the clipboard, in hosts format"
    override val MINE_CLEAR = "Delete imported list"
    override val MINE_FOOT = "Reads hosts lines (0.0.0.0 domain), plain domain lists and ||domain^ rules. Up to 50,000 names. Your allow list always wins."
    override val MINE_NOTHING = "No valid domains found"
    override val MINE_CLIP_EMPTY = "The clipboard is empty"
    override val MINE_FILE_ERR = "Couldn't read that file"
    override val MINE_CLEARED = "Imported list deleted"
    override val MINE_CLEAR_ASK = "Delete the imported list?"
    override val MINE_CUT = "Limit reached, the rest was skipped"
    override fun notifTimeout(name: String) = "$name isn't answering. Trying again."
    override val MOD_DPI = "DPI bypass"
    override val MOD_ADS = "Ads+"
    override val MOD_DPI_SUB = "Opens blocked sites"
    override val MOD_ADS_SUB = "Blocks beyond DNS"
    override val MOD_ON = "On"
    override val MOD_OFF = "Off"
    override val BLOCK_QUIC = "Block QUIC"
    override val BLOCK_QUIC_NOTE = "Apps fall back to TCP, so DPI bypass and Ads+ cover them too"
    override val GW_TRIPPED = "Connection trouble detected: DPI bypass and Ads+ were turned off"
    override fun gwOn(modules: String) = "Gateway on: $modules"
    override fun gwOnStats(modules: String, blocked: String) = "Gateway on: $modules · $blocked blocked"
    override fun modOn(name: String) = "$name turned on"
    override fun modOff(name: String) = "$name turned off"
    override fun modAdsCount(n: String) = "$n blocked"
    override fun modDpiCount(n: String) = "$n connections split"
    override fun latencyLine(avg: String, max: String, timeouts: Int) = "avg $avg · max $max" + (if (timeouts > 0) " · $timeouts timeouts" else "")
    override fun mineCount(n: Int) = "$n domains"
    override fun mineAdded(n: Int) = "$n domains added"
    override fun mineCopied(n: Int) = "$n domains copied"
    override val CACHE = "DNS cache"
    override val CLEAR_CACHE = "Clear cache"
    override val CACHE_CLEARED = "Cache cleared"
    override val ONLY_CONNECTED = "Available while connected"
    override val RULE_WIFI = "Wi-Fi server"
    override val RULE_MOBILE = "Mobile data server"
    override val RULE_AUTO = "Automatic"
    override val RULE_AUTO_NOTE = "The server you used last"
    override val COMPACT = "Compact list"
    override val COMPACT_NOTE = "Shorter rows without descriptions"
    override val HIDDEN = "Hidden servers"
    override val HIDDEN_NONE = "None"
    override val STAT_QUERIES = "Total queries"
    override val STAT_HITS = "Answered from cache"
    override val STAT_BLOCKED = "Blocked (estimated)"
    override val STAT_TIME = "Total time connected"
    override val WEEK = "Last 7 days"
    override fun weekA11y(total: String) = "$total queries in the last 7 days"
    override val WEEKDAYS = listOf("Mo", "Tu", "We", "Th", "Fr", "Sa", "Su")
    override val EXPORT = "Export settings"
    override val IMPORT = "Import settings"
    override val EXPORTED = "Settings code copied to clipboard"
    override val IMPORTED = "Settings loaded"
    override val IMPORT_BAD = "No valid settings code in the clipboard"
    override val RESET_SETTINGS = "Reset settings"
    override val RESET_STATS = "Reset statistics"
    override val CONFIRM = "Are you sure?"
    override val RESET = "Reset"
    override val RESET_DONE = "Reset done"
    override val LOG = "Diagnostic log"
    override val HELP = "How does it work?"
    override val VPN_SETTINGS = "System VPN settings"
    override val SHARE_APP = "Share the app"
    override val RATE_APP = "Rate the app"
    override val FEEDBACK = "Send feedback"
    override fun shareAppText(url: String) = "$APP connects you to popular DNS servers with one tap: $url"
    override val VERSION = "Version"
    override val OPT_BUBBLES = listOf("Off", "Few", "Many")
    override val OPT_MOTION = listOf("Full", "Reduced", "Off")
    override val OPT_CACHE = listOf("Off", "Small", "Normal", "Large")
    override val OPT_ENCRYPTION = listOf("Auto", "DoT", "DoH", "Off")
    override val PLAIN_DNS = "Plain DNS"

    override val LOG_NOTE = "Only connection events are kept. Query names and personal data are never stored."
    override val LOG_EMPTY = "No entries yet."
    override val SHARE = "Share"
    override val CLEAR = "Clear"
    override val CLEARED = "Cleared"
    override val HELP_SECTIONS = listOf(
        "What is DNS?" to
            "DNS is the service that turns internet addresses (like example.com) into numbers devices understand. " +
            "The DNS you use can affect speed, privacy and which content is blocked.",
        "What does the app do?" to
            "It uses the DNS server you choose in every app. To do this it opens a local VPN interface on your phone, " +
            "but your traffic does not go to a VPN server. Only DNS queries are sent to the server you picked; " +
            "everything else continues on its normal path.",
        "Encrypted DNS (DoT / DoH)" to
            "On servers that support it, queries are sent encrypted: nobody on the network (Wi-Fi owner, operator) can see " +
            "which sites you visit or tamper with the answers. In Automatic, DoT is tried first, then DoH; if neither works, " +
            "plain DNS is used. You are warned when that happens, and the app tries to switch back to encryption on every " +
            "network change and every 10 minutes. With \"Strict encryption\" on, plain DNS is never used. " +
            "The home screen shows which method is in use.",
        "Connection test" to
            "☰ > DNS settings > Test the connection sends real DNS questions through the tunnel. It shows that " +
            "DNS really answers from the server you chose, how fast, whether the server validates DNSSEC signatures and " +
            "whether it blocks a well-known ad domain.",
        "Privacy" to
            "No account, no data collection, no ads. The app does not store query names and sends nothing anywhere on its own. " +
            "Your queries go only to the DNS provider you chose, under that provider's own privacy policy. " +
            "Encrypted DNS (DoT/DoH) keeps anyone on the network from reading your queries or tampering with them. Before sending, the app strips extra data that could identify your device (client subnet, cookies, device IDs), pads messages to hide their length and forgets TLS session tickets when the network changes. " +
            "To be honest: without a relay, the DNS provider still sees your public IP address (it has to answer you), and a certificate error can mean someone is interfering with the connection. " +
            "The diagnostic log only contains connection events.",
        "Battery and resources" to
            "It uses very few resources in the background. Nothing loops while the screen is off; " +
            "it only works when a DNS query arrives. Encrypted connections close on their own when idle.",
        "Good to know" to
            "Android allows only one VPN at a time; this app can't connect while another VPN app is active. " +
            "A browser's \"secure DNS\" setting and Android's \"Private DNS\" set to a specific hostname use their own server " +
            "and may bypass this routing; leaving them on \"Automatic\" or \"Off\" is enough. " +
            "Long-press the orb to quickly switch to your usual servers or pause the connection for a while.",
    )

    override val NOTIF_CHANNEL = "Connection status"
    override val NOTIF_CHANNEL_NOTE = "Shown while the DNS connection is on"
    override val NOTIF_ALERT_CHANNEL = "Connection alerts"
    override val NOTIF_CONNECTING = "Connecting…"
    override val NOTIF_STOP = "Disconnect"
    override val NOTIF_NEXT = "Next"
    override val NOTIF_DROP_TITLE = "DNS connection lost"
    override val NOTIF_RECONNECT = "Reconnect"
    override fun notifOn(name: String, proto: String) = "Connected to $name · $proto"
    override fun notifPaused(time: String) = "Paused · resumes at $time"
    override val TILE_ON = "Connected"
    override val TILE_OFF = "Off"
    override val WIDGET_TAP = "Tap: connect / disconnect"
    override val ERR_PERMISSION = "VPN permission was not granted"
    override val ERR_ESTABLISH = "Couldn't open the VPN interface. Another VPN may be active."
    override fun errNoReply(name: String) = "$name did not reply"
    override val PHONE_BYPASS = "Phone isn't using this DNS (Private DNS?)"
    override fun errNoProto(name: String, proto: String) = "$name doesn't support $proto"
    override val ERR_SOCKET = "Couldn't reach the network"
    override fun errPrivateDns(host: String) = "Android's Private DNS is set to $host and bypasses this app. Set Settings > Network > Private DNS to Automatic or Off."
    override val ERR_REVOKED = "The connection was closed by the system"
    override val ERR_TUNNEL = "The tunnel closed unexpectedly"
    override val ERR_UNKNOWN = "Something unexpected happened"

    override val CONSENT_TITLE = "Before you connect"
    override val CONSENT_BODY = listOf(
        "$APP uses Android's VPN interface to route your DNS queries (the names of the sites you visit) to the DNS server you choose.",
        "Your traffic is not sent to a VPN server; only DNS queries go to the provider you chose. On servers that support it, " +
            "queries are encrypted (DoT/DoH); otherwise they are sent unencrypted. The provider's own privacy policy applies." +
            " If you switch on \"$MOD_DPI\" or \"$MOD_ADS\", all traffic passes through a relay that runs only inside your phone; it is still not sent anywhere else.",
        "The app collects no personal data, does not store query names and shares nothing with anyone.",
        "If you continue, Android will show a VPN connection request; you need to tap \"OK\".",
    )
    override val CONSENT_OK = "Got it, continue"
    override val CLOSE = "Close"
    override val BACK = "Back"

    override val RESUMING = "Resuming…"
    override val DOWNGRADED = "Couldn't encrypt, using plain DNS"
    override val UPGRADED = "Back on encrypted DNS"
    override val NOTIF_DOWNGRADE_TITLE = "DNS is not encrypted"
    override fun notifDowngrade(name: String) = "Couldn't set up an encrypted connection to $name. Plain DNS is in use; the app will try to switch back to encryption."
    override fun backupUsed(failed: String, used: String) = "$failed didn't reply, connected to $used"
    override val NOTIF_RETRYING = "Connection lost, retrying…"
    override fun errNoEncrypted(name: String) = "Couldn't set up an encrypted connection to $name"
    override fun errUntrusted(name: String) = "$name's certificate couldn't be verified; the network or software may be tampering with encrypted connections"
    override val APPLYING = "Applying the new setting to the connection"
    override val CONFIRM_DISCONNECT = "Disconnect?"
    override val DISCONNECT = "Disconnect"

    override val SEC_NOTIF = "Notifications"
    override val STRICT_ENC = "Strict encryption"
    override val STRICT_ENC_NOTE = "Never fall back to plain DNS"
    override val IP_MODE = "IP version"
    override val IP_MODE_NOTE = "Whichever your network has is tried first, the other is the backup"
    override val OPT_IP_MODE = listOf("IPv4 + IPv6", "IPv4 only")
    override val FILTER = "Blocking"
    override val FILTER_LEVEL = "Ad and tracker blocking"
    override val OPT_FILTER = listOf(
        "Off",
        "Basic",
        "Medium",
        "Strict",
    )
    override val FILTER_NOTES = listOf(
        "Nothing is blocked.",
        "Known ad, phishing and malware sites. Very low risk of breaking things.",
        "Basic plus more trackers and analytics. Some sites may have problems.",
        "The widest list, also fraud, abuse and redirects. Expect frequent breakage.",
    )
    override val FILTER_INFO = "Blocking happens entirely on your phone: when a listed site is looked up, a 0.0.0.0 answer is returned, the query goes to no server and no name is saved. It works only while connected. A browser's own secure DNS setting can bypass it. If a site breaks, allow it from Recently blocked."
    override val FILTER_LAST = "Recently blocked"
    override val FILTER_RECENT_NOTE = "Tap: allow"
    override val FILTER_RECENT_EMPTY = "Nothing blocked this session. Names appear here while connected and a level is on."
    override val FILTER_RECENT_FOOT = "Kept in memory for this session only; never saved, cleared when you disconnect."
    override val FILTER_ALLOW = "Allowed"
    override val FILTER_BLOCK = "My block list"
    override val FILTER_ADD = "Add…"
    override val FILTER_REMOVE = "Tap: remove"
    override val FILTER_ALLOW_ADD = "Domain to allow"
    override val FILTER_BLOCK_ADD = "Domain to block"
    override val FILTER_ERR = "Enter a valid domain, e.g. example.com"
    override val FILTER_ERR_LIMIT = "At most 200 domains can be added"
    override val FILTER_ALLOW_EMPTY = "No allowed domains. If a site breaks, add it here."
    override val FILTER_BLOCK_EMPTY = "Your own block list is empty."
    override val FILTER_ALLOW_FOOT = "The domain and all its subdomains are never blocked. Allow beats every list and your own block list."
    override val FILTER_BLOCK_FOOT = "The domain and all its subdomains are always blocked (even when the level is off)."
    override val FILTER_REMOVE_BTN = "Remove"
    override fun filterAllowed(name: String) = "$name is now allowed"
    override fun filterBlocked(name: String) = "$name will be blocked"
    override fun filterRemoved(name: String) = "$name removed"
    override fun filterRemoveAsk(name: String) = "Remove $name from the list?"
    override val TEST_IPV6 = "IPv6 path"
    override val AUTO_RECONNECT = "Reconnect automatically"
    override val AUTO_RECONNECT_NOTE = "If the connection drops, retries after 5 s, 30 s and 2 min"
    override val BACKUP_SERVER = "Backup server"
    override val BACKUP_OFF = "Off"
    override val BACKUP_OFF_NOTE = "Don't connect if the selected server doesn't reply"
    override val BACKUP_FASTEST = "Fastest"
    override val BACKUP_FASTEST_NOTE = "The fastest other server from the last check"
    override val CONFIRM_OFF = "Ask before disconnecting"
    override val CONFIRM_OFF_NOTE = "An accidental tap on the orb won't disconnect"
    override val LOCK_HIDE = "Hide on lock screen"
    override val LOCK_HIDE_NOTE = "The server name isn't shown in the lock screen notification"
    override val QUIET_NOTIF = "Quiet notification"
    override val QUIET_NOTIF_NOTE = "No status bar icon, silent"
    override val REMEMBER_FILTER = "Remember last filter"
    override val REMEMBER_FILTER_NOTE = "The filter you last chose comes back when the app opens"
    override val AUTO_MEASURE = "Measure on start"
    override val AUTO_MEASURE_NOTE = "Measures automatically if the last check is over a day old"
    override val MEASURE_ENC = "Encrypted measurement"
    override val MEASURE_ENC_NOTE = "Measures speed over DoT, closer to real encrypted use"
    override val OPT_SORT = listOf("Default", "Speed", "Name")
    override fun sortA11y(mode: String) = "Sort: $mode"
    override val AUTO_LIGHT = "Automatic: light theme"
    override val AUTO_DARK = "Automatic: dark theme"
    override val NIGHT_HOURS = "Night hours"
    override val FILTER_ENCRYPTED = "Encrypted"
    override val FILTER_UNFILTERED = "Unfiltered"

    override val TEST = "Test the connection"
    override val TEST_NOTE = "DNS, DNSSEC and ad blocking"
    override val TESTING = "Testing…"
    override val TEST_TITLE = "Connection test"
    override val TEST_OK = "DNS is working"
    override val TEST_FAIL = "No reply"
    override val TEST_SERVER = "Server"
    override val TEST_METHOD = "Method"
    override val TEST_LATENCY = "Response time"
    override val TEST_DNSSEC = "DNSSEC validation"
    override val TEST_ADS = "Ad blocking"
    override val DNSSEC_YES = "Validating"
    override val DNSSEC_NO = "Not validating"
    override val ADS_YES = "On"
    override val ADS_NO = "Off"
    override val UNKNOWN = "Unknown"
    override val TEST_EXPLAIN = "The questions were sent through the tunnel, just like an app would ask; the answers came from your chosen server."
    override val TEST_AGAIN = "Test again"

    override val RECOMMEND = "Find a server for me"
    override val RECOMMEND_NOTE = "Pick your goal and we'll connect to the fastest match"
    override val GOAL_SPEED = "Speed"
    override val GOAL_SPEED_NOTE = "The fastest server by your checks"
    override val GOAL_PRIVACY_NOTE = "No logs, privacy focused"
    override val GOAL_ADS_NOTE = "Blocks ads and trackers"
    override val GOAL_FAMILY_NOTE = "Blocks adult content"
    override val GOAL_SECURITY_NOTE = "Blocks malicious and phishing sites"
    override fun recommended(name: String) = "Recommended: $name"

    override val PRIVATE_DNS = "Private DNS name"
    override val PRIVATE_DNS_NOTE = "You can paste it into Android's Private DNS setting. The system then uses this server directly and this app is bypassed."
    override val CLEAR_HISTORY = "Clear speed history"
    override val HISTORY_CLEARED = "Measurements cleared"

    override val GUARD = "Always-on protection"
    override val GUARD_NOTE = "Always-on VPN"
    override val GUARD_BODY = listOf(
        "While the app isn't connected (turned off, paused or after a drop), your DNS queries go to your internet provider's server.",
        "To prevent this, turn on \"Always-on VPN\" for this app in Android's VPN settings. If \"Block connections without VPN\" is also on, the internet won't work at all while the app isn't connected: nothing leaks, but pausing also means no internet.",
        "With Always-on VPN, the system starts the app automatically when the phone boots and after it stops.",
    )
    override val GUARD_BUTTON = "Open system VPN settings"
    override val BATTERY = "Battery settings"
    override val BATTERY_OK = "Not restricted"
    override val BATTERY_LIMITED = "May be restricted"
    override val BATTERY_BODY = listOf(
        "Android usually protects VPN apps. Still, some manufacturers (Xiaomi, Huawei, Oppo, Vivo, some Samsung versions) may close background apps to save battery.",
        "If the connection keeps dropping on its own, set this app's battery usage to \"Unrestricted\" or \"Not optimized\"; on some phones also allow \"Autostart\".",
    )
    override val BATTERY_BUTTON = "Open battery settings"

    override val STAT_AVG = "Average response time"
    override val STAT_SAVED = "Time saved by the cache"
    override val STAT_TRAFFIC = "DNS traffic"
    override val SESSIONS = "Connection history"
    override val SESSIONS_NOTE = "Last 30 connections; query names are never stored"
    override val SESSIONS_EMPTY = "No connections recorded yet."
    override val MOST_USED = "Most used"
    override val TODAY = "Today"
    override val YESTERDAY = "Yesterday"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "You disconnected"
        EndReason.PAUSE -> "Paused"
        EndReason.SWITCH -> "Server changed"
        EndReason.DROP -> "Dropped"
        EndReason.REVOKED -> "Closed by the system"
        EndReason.FAILED -> "Didn't reply"
        EndReason.NETWORK -> "Network changed"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries queries"

    override val SOUND_MOTION = "Sound & motion"
    override val SEC_SOUND = "Sound"
    override val SOUND_ON = "Sound effects"
    override val SOUND_ON_NOTE = "Short, soft sounds on taps and when connecting. Silent when the phone is muted."
    override val SOUND_UI = "Tap sounds"
    override val SOUND_UI_NOTE = "Buttons, switches and page changes"
    override val SOUND_CONN = "Connection sounds"
    override val SOUND_CONN_NOTE = "Separate sounds for connect, disconnect and errors"
    override val SOUND_VOL = "Volume"
    override val SOUND_PACK = "Sound pack"
    override val SOUND_TEST = "Try the connect sound"
    override val QUIET_HOURS = "Quiet hours"
    override val QUIET_NOTE = "No sounds or vibration during these hours"
    override val QUIET_RANGE = "Quiet hours range"
    override val SEC_MOTION_FX = "Motion & effects"
    override val ANIM_SPEED = "Animation speed"
    override val TAP_FX = "Tap effect"
    override val TAP_FX_NOTE = "A small style-specific effect where you touch"
    override val CELEBRATE = "Connect celebration"
    override val CELEBRATE_NOTE = "A style-specific show around the orb when connected"
    override val HAPTIC_LEVEL = "Vibration strength"
    override val REMEMBER_MODS = "Remember modules"
    override val REMEMBER_MODS_NOTE = "On connect, DPI bypass and Ads+ turn on as you last left them"
    override val PROFILES = "Profiles"
    override val COPY_STATUS = "Copy status summary"
    override val OPT_PACK = listOf("Auto", "Soft", "Glass", "Classic")
    override val SOUND_PACK_NOTE = "Auto: the sound of your current style"
    override val OPT_HAPTIC = listOf("Light", "Normal", "Strong")
    override val PROFILE_NAMES = listOf("Speed", "Privacy", "Family", "Full protection")
    override val PROFILE_NOTES = listOf("Fastest server, large cache, no blocking", "Strict encryption, tracker blocking, Ads+", "Family-filter server, medium blocking", "Ad and tracker blocking, DPI bypass, Ads+")
    override fun profileApplied(name: String) = "Profile applied: $name"

    override val WHATS_NEW = "What's new?"
    override val WHATS_NEW_TOAST = "The app was updated"
    override val SHOW = "Show"
    override val WHATS_NEW_ITEMS = listOf(
        "New: sound effects, a rewritten fluid animation engine, style-specific tap effects, profiles, quiet hours and more. ☰ > Sound & motion.",
        "New: DPI bypass and Ads+ buttons. They work alongside DNS or on their own; both are off by default.",
        "New: import your own block list, connected / dropped / timeout notifications, a per-query latency graph and Block DNS if it stays down.",
        "New: the server list opens with the first 8 (Show all / Show less), Add custom DNS at the top, and a thin scroll bar.",
        "New: ad, tracker and malware blocking (Off/Basic/Medium/Strict) with allow and own block lists. ☰ > Blocking. Lists ship in the app; all on-device.",
        "New: Frutiger Aurora style; Y2K is now holographic and Metro has a city and music look. Pick one in ☰ > Personalize > Style.",
        "New: IPv4 and IPv6 together, faster fault detection; for privacy, device traces are stripped from queries and message lengths hidden.",
        "New: Settings are split by topic. The ☰ menu opens DNS settings, Connection and apps, Notifications, Server list, Statistics and history, and Data separately.",
        "New: Personalize window (in the ☰ menu): language, theme, style, background, icon, text and accessibility options live here.",
        "New: ☰ menu on the home screen and a new About window (news, help, log, share, version).",
        "Fix: setting your own photo or a built-in image as background works now (the photo size was misread).",
        "Fix: the connection check tells a server problem from the phone not using the DNS, and warns in the second case.",
        "Fix: Metro, Eco and Y2K styles redrawn; the icon change now applies when you leave the app.",
        "New: 8 built-in background pictures (☰ → Personalize → Background photo → Built-in pictures).",
        "New: troubleshooter, server search, sharing measurement results, editing custom servers and an option to keep no history.",
        "App icon: pick one of five icons that match the five styles.",
        "Background photo: use your own picture as the background, with adjustable veil and blur; text always stays readable.",
        "Five look styles: Aqua (classic), Aero (sky and grass), Metro (flat tiles), Eco (nature) and pink Y2K, each with its own animations, plus smoother transitions.",
        "App selection: apply DNS to only the apps you pick, or leave some apps out.",
        "Add your own DNS servers (up to 8), 10 new built-in servers, and an info section on every server: what it's for, its owner, average ping.",
        "Safer connection: extra checks against forged DNS answers, a warning when falling back to plain DNS, a strict encryption option and automatic return to encryption.",
        "Connection test: check with one tap that DNS answers from your chosen server, plus DNSSEC validation and ad blocking.",
        "Backup server and automatic reconnect: the app recovers by itself if the selected server doesn't reply or the connection drops.",
        "Connection history, most used servers, average response time and DNS traffic.",
        "New filters (Encrypted, Unfiltered), sort by name, \"Find a server for me\" and measuring on start.",
        "Live counters in the notification, a 15-minute pause button, hiding on the lock screen and a quiet notification option.",
        "Three new themes (Sakura, Honey, Aurora), a theme from your wallpaper and light/dark choices for the automatic theme.",
        "Four new languages: Indonesian, Vietnamese, Polish and Ukrainian.",
    )
    override fun importedWith(changes: String) = "Settings loaded · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "encryption weakened"
        SensitiveChange.AUTO_START -> "auto-connect turned on"
        SensitiveChange.RULES -> "server rules changed"
        SensitiveChange.PRIVACY -> "privacy or alert settings relaxed"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries queries · $blocked blocked"
    override val NOTIF_LOCKED = "DNS protection is on"
    override val NOTIF_QUIET_CHANNEL = "Connection status (quiet)"
    override fun widgetToday(queries: String) = "Today $queries queries"
    override fun pauseAction(minutes: Int) = "Pause ${minutes(minutes)}"

    override val CUSTOM_NOTE = "A server you added"
    override val CUSTOM_ADD = "Add custom DNS"
    override val CUSTOM_F_NAME = "Name"
    override val CUSTOM_F_IP1 = "IPv4 address (e.g. 1.2.3.4)"
    override val CUSTOM_F_IP2 = "Second IPv4 address (optional)"
    override val CUSTOM_F_DOT = "DoT name (optional)"
    override val CUSTOM_F_DOH = "DoH address, https://… (optional)"
    override val CUSTOM_SAVE = "Add"
    override val CUSTOM_CANCEL = "Cancel"
    override val CUSTOM_HINT = "Fill in DoT or DoH for an encrypted connection; if left empty, plain DNS is used."
    override val CUSTOM_ERR_NAME = "Name must be 1–24 characters (no | ; , =)"
    override val CUSTOM_ERR_IP = "Enter a valid IPv4 address (e.g. 1.2.3.4)"
    override val CUSTOM_ERR_DOT = "DoT name must be a valid domain name"
    override val CUSTOM_ERR_DOH = "DoH address must start with https://"
    override val CUSTOM_ERR_LIMIT = "You can add up to 8 custom servers"
    override fun customAdded(name: String) = "$name added"
    override val CUSTOM_DELETE = "Delete this server"
    override val CUSTOM_IN_USE = "Can't delete while connected to it"
    override fun customDeleted(name: String) = "$name deleted"
    override val INFO_PURPOSE = "What it's for"
    override val INFO_OWNER = "Owner"
    override val INFO_AVG = "Average ping"
    override fun avgPing(ms: Int, n: Int) = "$ms $msU · $n measurements"

    override val APPS = "Apps"
    override val APPS_ALL = "All apps"
    override fun appsOnly(n: Int) = "Only selected ($n)"
    override fun appsExcept(n: Int) = "All except selected ($n)"
    override val APPS_MODE = "Which apps use this DNS?"
    override val OPT_APPS = listOf("All", "Selected only", "All but selected")
    override val APPS_NOTE = "Apps that aren't covered use the phone's own DNS. Only one DNS server runs at a time; you can't pick a different server per app."
    override val APPS_LOADING = "Loading apps…"
    override val APPS_EMPTY = "No apps found"
    override val APPS_NONE_SELECTED = "No apps selected: DNS applies to all apps."
    override val APPS_APPLY = "Apply now"
    override val APPS_PENDING = "The change takes effect when the connection is renewed (it drops for a second or two)."

    override val NOTES = mapOf(
        "cloudflare" to "Fast, privacy focused",
        "google" to "Stable, widely used",
        "quad9" to "Blocks malicious domains",
        "adguard" to "Blocks ads and trackers",
        "controld" to "Unfiltered, fast",
        "opendns" to "Cisco, phishing protection",
        "dnssb" to "Privacy focused, fast",
        "dns4eu" to "EU's DNS, malware protection",
        "uncensored" to "No filtering or redirects",
        "quad9-open" to "No blocking",
        "adguard-open" to "No blocking, privacy focused",
        "dns4eu-open" to "EU's DNS, unfiltered",
        "controld-ads" to "Ads, trackers, malware",
        "dns4eu-ads" to "EU's DNS, ads and malware",
        "cloudflare-security" to "Blocks malicious sites",
        "controld-malware" to "Blocks malicious sites",
        "cleanbrowsing-security" to "Phishing and malicious sites",
        "cloudflare-family" to "Malware and adult content filter",
        "opendns-family" to "Adult content filter",
        "adguard-family" to "Ads and adult content filter",
        "cleanbrowsing-family" to "Adult content, safe search",
        "dns4eu-child" to "EU's DNS, child protection",
        "controld-family" to "Adult content filter",
        "nextdns" to "Configurable filtering, fast",
        "cira-private" to "Canada, unfiltered, privacy focused",
        "cira-protected" to "Canada, blocks malicious sites",
        "libredns" to "Independent, unfiltered",
        "switch" to "Swiss, blocks malicious sites",
        "wikimedia" to "Wikimedia's DNS, privacy focused",
        "digitale" to "Swiss non-profit, unfiltered",
        "quad101" to "Taiwan, fast",
        "alidns" to "China, fast",
    )
}
