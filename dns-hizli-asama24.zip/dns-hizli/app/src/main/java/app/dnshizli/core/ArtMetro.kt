package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Frutiger Metro: 2000'lerin başının şehir, müzik ve gençlik vektör sanatı. Zeminde güneş ışını çizgileri, gökdelen
 * silueti (pencereli), hoparlör, iç içe halkalar, yıldızlar, girdaplar, yarım ton noktalar, sıçrama damlaları ve pembe/turuncu
 * şerit dalgalar. Düğmeler, kartlar, anahtarlar ve küre öteki stillerle aynıdır (temel cam çizim); yalnızca zemin ve
 * hareket Metro'ya özgüdür. Renk teması bir miktar karışır.
 * Hareket: karolar yana yatarak girer (turnike).
 */
class MetroArt(theme: AeroTheme, glass: Float) : AeroArt(theme, glass) {
    override val style: UiStyle get() = UiStyle.METRO
    override val particleMode: ParticleMode get() = ParticleMode.NONE
    override val motion: StyleMotion = StyleMotion(PageMotion.TURNSTILE, 0.32f, 0.035f, 0f, depth = 0.8f, tilt = 6f, up = SpringSpec.CRISP, toggle = SpringSpec.CRISP, fx = FxKind.SLICE)
    override val titleScale: Float get() = 1.22f

    private val lime = 0xFFC4EE4E.toInt()
    private val turq = 0xFF27D1C2.toInt()
    private val pink = 0xFFFF4FA3.toInt()
    private val orange = 0xFFFFA83A.toInt()
    private val blue = 0xFF1F8BFF.toInt()
    private val inkC = 0xFF081A2B.toInt()

    private val star5 = GPath().apply {
        for (i in 0 until 10) {
            val a = (-90.0 + i * 36.0) * PI / 180.0
            val r = if (i % 2 == 0) 1f else 0.42f
            val x = (cos(a) * r).toFloat()
            val y = (sin(a) * r).toFloat()
            if (i == 0) moveTo(x, y) else lineTo(x, y)
        }
        close()
    }

    private class Shapes(val w: Float, val h: Float, art: MetroArt) {
        val th = art.theme
        val dk = art.dark
        val base = if (dk)
            Fill.linear(0f, 0f, 0f, h, Rgb.lerp(0xFF04101C.toInt(), th.skyTop, 0.22f), Rgb.lerp(0xFF0A2540.toInt(), th.skyMid, 0.22f),
                Rgb.lerp(0xFF020912.toInt(), th.skyBottom, 0.18f), 0.55f)
        else
            Fill.linear(0f, 0f, 0f, h, Rgb.lerp(art.lime, th.skyTop, 0.30f), Rgb.lerp(art.turq, th.skyMid, 0.34f),
                Rgb.lerp(0xFFFFE9A6.toInt(), th.skyBottom, 0.25f), 0.60f)
        val ray = GPath()
        val swash = GPath()
        val swash2 = GPath()
        val swirl = GPath()
        val swashFill = Fill.linear(0f, 0f, w, 0f, Rgb.alpha(art.pink, if (dk) 0.55f else 0.80f), Rgb.alpha(art.orange, if (dk) 0.55f else 0.85f),
            Rgb.alpha(art.turq, if (dk) 0.45f else 0.65f), 0.55f)
        val glow = Fill.radial(w * 0.5f, h * 0.66f, w * 0.9f, Rgb.alpha(Rgb.WHITE, if (dk) 0.18f else 0.55f), Rgb.alpha(Rgb.WHITE, 0f))

        init {
            // ışınlar: tek bir kama; sahnede döndürülerek çizilir
            val cx = w * 0.5f
            val cy = h * 0.66f
            val len = (w + h) * 1.2f
            val half = (PI / 36.0).toFloat()
            ray.moveTo(cx, cy).lineTo(cx + len * sin(-half), cy - len * cos(-half)).lineTo(cx + len * sin(half), cy - len * cos(half)).close()
            // şerit dalgalar
            swash.moveTo(-0.1f * w, 0.84f * h).cubicTo(0.20f * w, 0.70f * h, 0.45f * w, 1.00f * h, 0.78f * w, 0.80f * h)
                .cubicTo(0.92f * w, 0.72f * h, 1.0f * w, 0.74f * h, 1.1f * w, 0.70f * h)
            swash2.moveTo(-0.1f * w, 0.90f * h).cubicTo(0.25f * w, 0.78f * h, 0.52f * w, 1.04f * h, 0.86f * w, 0.86f * h)
                .cubicTo(0.96f * w, 0.80f * h, 1.0f * w, 0.82f * h, 1.1f * w, 0.78f * h)
            // girdap: birim koordinatlarda sarmal
            var first = true
            var a = 0.0
            while (a < 4.2 * PI) {
                val r = 0.08f + (a / (4.2 * PI)).toFloat() * 0.92f
                val x = (cos(a) * r).toFloat()
                val y = (sin(a) * r).toFloat()
                if (first) { swirl.moveTo(x, y); first = false } else swirl.lineTo(x, y)
                a += 0.18
            }
        }
    }

    private var shapes: Shapes? = null

    private fun shapes(w: Float, h: Float): Shapes {
        var s = shapes
        if (s == null || s.w != w || s.h != h) { s = Shapes(w, h, this); shapes = s }
        return s
    }

    /** İç içe halkalar: dıştan içe dönüşümlü ana renk ve beyaz. */
    private fun rings(g: Gfx, x: Float, y: Float, r: Float, c1: Int, c2: Int, n: Int = 5) {
        for (i in 0 until n) {
            g.paint(if (i % 2 == 0) c1 else c2); g.circle(x, y, r * (1f - i / n.toFloat()))
        }
    }

    private fun star(g: Gfx, x: Float, y: Float, r: Float, rot: Float, fill: Int, line: Int) {
        g.save(); g.translate(x, y); g.rotate(rot); g.scale(r, r)
        g.paint(fill); g.path(star5)
        g.strokeWidth(0.10f); g.paint(line); g.strokePath(star5)
        g.restore()
    }

    private fun speaker(g: Gfx, x: Float, y: Float, r: Float) {
        g.paint(Rgb.alpha(inkC, if (dark) 0.85f else 0.82f)); g.circle(x, y, r)
        g.paint(Rgb.alpha(lime, 0.95f)); g.circle(x, y, r * 0.82f)
        g.paint(Rgb.alpha(inkC, 0.9f)); g.circle(x, y, r * 0.62f)
        g.paint(Rgb.alpha(turq, 0.95f)); g.circle(x, y, r * 0.46f)
        g.paint(Rgb.alpha(inkC, 0.9f)); g.circle(x, y, r * 0.16f)
        g.paint(white(0.75f)); g.oval(x - r * 0.46f, y - r * 0.50f, x - r * 0.04f, y - r * 0.24f)
    }

    private val xs = floatArrayOf(2f, 11f, 20f, 28f, 38f, 47f, 55f, 64f, 73f, 82f, 90f)
    private val ws = floatArrayOf(8f, 8f, 7f, 9f, 8f, 7f, 8f, 8f, 8f, 7f, 9f)
    private val hs = floatArrayOf(0.08f, 0.13f, 0.10f, 0.17f, 0.12f, 0.20f, 0.09f, 0.15f, 0.11f, 0.18f, 0.085f)
    private val dots = floatArrayOf(0.52f, 0.06f, 4f, 0.56f, 0.09f, 2.4f, 0.49f, 0.10f, 2f, 0.62f, 0.05f, 3f, 0.07f, 0.18f, 3f, 0.04f, 0.22f, 2f)

    private fun skyline(g: Gfx, w: Float, h: Float) {
        val u = w / 100f
        val base = h * 0.985f
        // (x, genişlik, yükseklik) yüzde cinsinden; yükseklik h'nin yüzdesi
        val body = Rgb.alpha(inkC, if (dark) 0.70f else 0.50f)
        val face = Rgb.alpha(if (dark) blue else turq, if (dark) 0.55f else 0.55f)
        val win = Rgb.alpha(if (dark) 0xFFBFE8FF.toInt() else 0xFFFFF4B0.toInt(), if (dark) 0.75f else 0.85f)
        for (i in xs.indices) {
            val l = xs[i] * u
            val bw = ws[i] * u
            val bh = hs[i] * h
            g.paint(body); g.rect(l, base - bh, l + bw, base)
            g.paint(face); g.rect(l + bw * 0.62f, base - bh, l + bw, base)
            if (i == 5) { g.paint(body); g.rect(l + bw * 0.45f, base - bh - h * 0.05f, l + bw * 0.55f, base - bh) } // anten
            g.paint(win)
            var wy = base - bh + 5f
            while (wy < base - 8f) {
                g.rect(l + bw * 0.14f, wy, l + bw * 0.14f + 3f, wy + 3.5f)
                g.rect(l + bw * 0.38f, wy, l + bw * 0.38f + 3f, wy + 3.5f)
                wy += 11f
            }
        }
    }

    override fun sky(g: Gfx, w: Float, h: Float) {
        val s = shapes(w, h)
        val u = min(w, h)
        g.paint(s.base); g.rect(0f, 0f, w, h)
        // güneş ışınları
        g.paint(white(if (dark) 0.06f else 0.20f))
        for (i in 0 until 18) {
            g.save()
            val cx = w * 0.5f
            val cy = h * 0.66f
            g.translate(cx, cy); g.rotate(i * 20f); g.translate(-cx, -cy)
            g.path(s.ray)
            g.restore()
        }
        g.paint(s.glow); g.rect(0f, 0f, w, h)
        // yarım ton noktalar (sol üst, küçülerek solar)
        val dot = Rgb.alpha(if (dark) blue else pink, if (dark) 0.55f else 0.55f)
        g.paint(dot)
        for (i in 0 until 7) for (j in 0 until 7) {
            val r = (3.2f - (i + j) * 0.25f)
            if (r > 0.5f) g.circle(w * 0.04f + i * 11f, h * 0.05f + j * 11f, r)
        }
        // halkalar
        rings(g, w * 1.0f, h * 0.17f, u * 0.12f, Rgb.alpha(inkC, 0.80f), white(0.92f))
        rings(g, w * 0.0f, h * 0.47f, u * 0.07f, Rgb.alpha(if (dark) blue else pink, 0.92f), white(0.9f), 4)
        rings(g, w * 0.93f, h * 0.60f, u * 0.04f, Rgb.alpha(if (dark) turq else orange, 0.92f), white(0.9f), 3)
        // yıldızlar
        val sf = Rgb.alpha(Rgb.WHITE, if (dark) 0.15f else 0.90f)
        val sl = Rgb.alpha(inkC, if (dark) 0.9f else 0.85f)
        star(g, w * 0.30f, h * 0.12f, u * 0.045f, 12f, sf, sl)
        star(g, w * 0.14f, h * 0.30f, u * 0.035f, -20f, Rgb.alpha(if (dark) turq else pink, 0.95f), sl)
        star(g, w * 0.70f, h * 0.38f, u * 0.05f, 25f, sf, sl)
        star(g, w * 0.92f, h * 0.75f, u * 0.04f, -10f, Rgb.alpha(orange, 0.95f), sl)
        star(g, w * 0.46f, h * 0.50f, u * 0.025f, 5f, sf, sl)
        // hoparlör ve girdaplar
        speaker(g, w * 0.95f, h * 0.31f, u * 0.075f)
        g.save(); g.translate(w * 0.62f, h * 0.075f); g.rotate(70f); g.scale(u * 0.08f, u * 0.08f)
        g.strokeWidth(0.12f); g.paint(Rgb.alpha(if (dark) pink else inkC, 0.75f)); g.strokePath(s.swirl); g.restore()
        // sıçrama damlaları
        g.paint(Rgb.alpha(inkC, if (dark) 0.5f else 0.8f))
        var i = 0
        while (i < dots.size) { g.circle(w * dots[i], h * dots[i + 1], dots[i + 2]); i += 3 }
        // şehir
        skyline(g, w, h)
        // şerit dalgalar
        g.strokeWidth(h * 0.030f); g.paint(s.swashFill); g.strokePath(s.swash)
        g.strokeWidth(h * 0.012f); g.paint(white(if (dark) 0.50f else 0.85f)); g.strokePath(s.swash2)
    }

    override fun skyFrame(g: Gfx, w: Float, h: Float, live: Boolean, time: Float) = sky(g, w, h)
}
