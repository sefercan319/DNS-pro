package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File

/**
 * Reklam engelleme geliştirmeleri: gizli izleyici (CNAME) engeli, kanarya adlar (şifreli DNS'e geçişi kapatma),
 * genişletilmiş DoH/DoT listesi ve yeni liste kaynakları.
 */

private fun wire(name: String): ByteArray {
    val o = java.io.ByteArrayOutputStream()
    for (l in name.split('.')) { o.write(l.length); o.write(l.toByteArray()) }
    o.write(0)
    return o.toByteArray()
}

private fun w16(o: java.io.ByteArrayOutputStream, v: Int) { o.write((v ushr 8) and 0xFF); o.write(v and 0xFF) }

/**
 * DNS cevabı kurar: [cnames] zinciri (sahip → hedef), sonunda [finalA] ya da [finalAAAA] kaydı.
 * [compress] doğruysa CNAME hedefi sorudaki ada işaretçiyle (0xC00C) ya da tam yazılır.
 */
private fun response(
    qname: String, qtype: Int, chain: List<String>, id: Int = 0x2468, rcode: Int = 0, qd: Int = 1,
    withFinal: Boolean = true, loopPointer: Boolean = false,
): ByteArray {
    val o = java.io.ByteArrayOutputStream()
    var an = chain.size + (if (withFinal) 1 else 0)
    w16(o, id); w16(o, 0x8180 or rcode); w16(o, qd); w16(o, an); w16(o, 0); w16(o, 0)
    for (i in 0 until qd) { o.write(wire(qname)); w16(o, qtype); w16(o, 1) }
    var owner: ByteArray = byteArrayOf(0xC0.toByte(), 0x0C)
    var ownerName = qname
    for (t in chain) {
        o.write(owner); w16(o, 5); w16(o, 1); o.write(byteArrayOf(0, 0, 1, 0x2C))
        val rd = if (loopPointer) byteArrayOf(0xC0.toByte(), (o.size() + 2 + 0).toByte()) else wire(t)
        w16(o, rd.size); o.write(rd)
        owner = wire(t); ownerName = t
    }
    if (withFinal) {
        o.write(owner); w16(o, qtype); w16(o, 1); o.write(byteArrayOf(0, 0, 1, 0x2C))
        val rd = if (qtype == 28) ByteArray(16) { (it + 1).toByte() } else byteArrayOf(93.toByte(), 184.toByte(), 216.toByte(), 34)
        w16(o, rd.size); o.write(rd)
    }
    return o.toByteArray()
}

private fun setEngine(allow: List<String> = emptyList(), block: List<String> = listOf("tracker-net.example")): FilterEngine {
    FilterRuntime.reset()
    FilterRuntime.updateNow(FilterLevel.OFF, allow, block)
    return FilterRuntime.engine!!
}

fun runAdBoostTests() {
    T.group("Reklam: gizli izleyici (CNAME) engeli")
    run {
        setEngine()
        val msg = response("metrik.magaza.example", 1, listOf("izle.tracker-net.example"))
        val buf = msg.copyOf(msg.size + 64)
        FilterLive.clear()
        val n = CnameGuard.guard(buf, 0, msg.size)
        T.check("CNAME zinciri engelli ada çıkıyorsa cevap engelleme cevabına çevrilir (boş adres)", n != msg.size && Dns.isLocalBlock(buf, 0, n))
        T.check("kimlik ve soru korunur; engelli A sorusu NXDOMAIN (cevap kaydı yok, SOA yetkisi)", Packets.u16(buf, 0) == 0x2468 && (Packets.u16(buf, 2) and 0xF) == 3 && Packets.u16(buf, 4) == 1 && Packets.u16(buf, 6) == 0 && Packets.u16(buf, 8) == 1)
        T.check("engellenen ad (sorulan ad) 'hangi site bozuldu' listesine yazılır", FilterLive.recent().any { it.name == "metrik.magaza.example" && !it.user } || FilterLive.recent().any { it.name == "metrik.magaza.example" })
        // AAAA
        val m6 = response("metrik.magaza.example", 28, listOf("izle.tracker-net.example"))
        val b6 = m6.copyOf(m6.size + 64)
        val n6 = CnameGuard.guard(b6, 0, m6.size)
        T.check("AAAA sorusunda NXDOMAIN (SOA ile 30 sn negatif önbellek)", Dns.isLocalBlock(b6, 0, n6) && (Packets.u16(b6, 2) and 0xF) == 3)
        // zincir uzunluğu
        val temiz = response("www.magaza.example", 1, listOf("cdn.baska.example"))
        val tb = temiz.copyOf(temiz.size + 64)
        T.check("temiz zincire dokunulmaz (bayt bayt aynı)", CnameGuard.guard(tb, 0, temiz.size) == temiz.size && tb.copyOf(temiz.size).contentEquals(temiz))
        val derin = response("a.magaza.example", 1, listOf("b1.x.example", "b2.x.example", "b3.x.example", "b4.x.example", "b5.x.example", "b6.x.example", "b7.x.example", "izle.tracker-net.example"))
        val db = derin.copyOf(derin.size + 64)
        T.check("8. adımdaki engelli hedef de yakalanır", Dns.isLocalBlock(db, 0, CnameGuard.guard(db, 0, derin.size)))
        val cok = response("a.magaza.example", 1, listOf("b1.x.example", "b2.x.example", "b3.x.example", "b4.x.example", "b5.x.example", "b6.x.example", "b7.x.example", "b8.x.example", "izle.tracker-net.example"))
        val cb = cok.copyOf(cok.size + 64)
        T.check("sınırın (8 adım) ötesine bakılmaz: cevap olduğu gibi kalır", CnameGuard.guard(cb, 0, cok.size) == cok.size)
        T.check("NXDOMAIN, soru sayısı ≠ 1 ve cevapsız mesajlara dokunulmaz", run {
            val a = response("m.magaza.example", 1, listOf("izle.tracker-net.example"), rcode = 3).let { it.copyOf(it.size + 64) to it.size }
            val b = response("m.magaza.example", 1, listOf("izle.tracker-net.example"), qd = 2).let { it.copyOf(it.size + 64) to it.size }
            val c = response("m.magaza.example", 1, listOf("izle.tracker-net.example"), withFinal = false).let { it.copyOf(it.size + 64) to it.size }
            CnameGuard.guard(a.first, 0, a.second) == a.second && CnameGuard.guard(b.first, 0, b.second) == b.second && CnameGuard.guard(c.first, 0, c.second) == c.second
        })
        val lp = response("m.magaza.example", 1, listOf("x.tracker-net.example"), loopPointer = true)
        val lb = lp.copyOf(lp.size + 64)
        T.check("kendine işaret eden (döngü) CNAME hedefi güvenle atlanır", run { CnameGuard.guard(lb, 0, lp.size); true })
        // tamponun ötesinde ek yer yoksa
        val tight = msg.copyOf()
        T.check("cevap sığmıyorsa değiştirilmez (tampon taşmaz)", CnameGuard.guard(tight, 0, tight.size).let { it == tight.size || it in 1..tight.size })
        // base != 0
        val off = ByteArray(48 + msg.size + 64); System.arraycopy(msg, 0, off, 48, msg.size)
        T.check("başlangıç konumu sıfır olmayan tamponda da çalışır (Secure yolu)", Dns.isLocalBlock(off, 48, CnameGuard.guard(off, 48, msg.size)))
    }
    run {
        // kullanıcı izin listesi her zaman üstündür
        setEngine(allow = listOf("metrik.magaza.example"))
        val msg = response("metrik.magaza.example", 1, listOf("izle.tracker-net.example"))
        val b = msg.copyOf(msg.size + 64)
        T.check("sorulan ad izin listesindeyse CNAME engeli uygulanmaz", CnameGuard.guard(b, 0, msg.size) == msg.size)
        setEngine(allow = listOf("izle.tracker-net.example"))
        val b2 = msg.copyOf(msg.size + 64)
        T.check("hedef izin listesindeyse de geçer", CnameGuard.guard(b2, 0, msg.size) == msg.size)
        setEngine(allow = listOf("magaza.example"))
        val b3 = msg.copyOf(msg.size + 64)
        T.check("üst alan adı izinliyse alt alan adı da geçer", CnameGuard.guard(b3, 0, msg.size) == msg.size)
        FilterRuntime.reset()
        val b4 = msg.copyOf(msg.size + 64)
        T.check("motor yokken hiçbir şey değişmez", CnameGuard.guard(b4, 0, msg.size) == msg.size)
    }
    run {
        // dayanıklılık: bozuk/kesik/rastgele
        setEngine()
        val base = response("metrik.magaza.example", 1, listOf("izle.tracker-net.example"))
        val rnd = java.util.Random(42)
        var thrown = 0; var bad = 0
        for (round in 0 until 30000) {
            val m = base.copyOf()
            val flips = 1 + rnd.nextInt(6)
            for (k in 0 until flips) m[rnd.nextInt(m.size)] = rnd.nextInt(256).toByte()
            val len = if (rnd.nextInt(4) == 0) rnd.nextInt(m.size + 1) else m.size
            val buf = m.copyOf(m.size + 64)
            try {
                val n = CnameGuard.guard(buf, 0, len)
                if (n != len && (n <= 0 || n > buf.size)) bad++
            } catch (e: Throwable) { thrown++ }
        }
        T.check("30000 bozuk/kesik cevapta hata fırlatmaz, uzunluk geçerli kalır", thrown == 0 && bad == 0, "thrown=$thrown bad=$bad")
        val rb = ByteArray(300)
        var t2 = 0
        for (round in 0 until 20000) { rnd.nextBytes(rb); try { CnameGuard.guard(rb.copyOf(), 0, 1 + rnd.nextInt(300)) } catch (e: Throwable) { t2++ } }
        T.check("tamamen rastgele baytlarla da hata fırlatmaz", t2 == 0)
    }
    run {
        // çok iş parçacığı: her iş parçacığının kendi motor kopyası var; sonuçlar tutarlı
        setEngine()
        val ok = java.util.concurrent.atomic.AtomicInteger(); val fail = java.util.concurrent.atomic.AtomicInteger()
        val blockedMsg = response("metrik.magaza.example", 1, listOf("izle.tracker-net.example"))
        val cleanMsg = response("www.magaza.example", 1, listOf("cdn.baska.example"))
        val ts = (0 until 8).map {
            Thread {
                for (i in 0 until 3000) {
                    val m = if (i % 2 == 0) blockedMsg else cleanMsg
                    val b = m.copyOf(m.size + 64)
                    val n = CnameGuard.guard(b, 0, m.size)
                    val isB = Dns.isLocalBlock(b, 0, n)
                    if (isB == (i % 2 == 0)) ok.incrementAndGet() else fail.incrementAndGet()
                }
            }.also { it.start() }
        }
        ts.forEach { it.join() }
        T.check("8 iş parçacığı × 3000 cevap: hepsi doğru karar (yarış yok)", ok.get() == 24000 && fail.get() == 0, "ok=${ok.get()} fail=${fail.get()}")
        // temiz cevap yolunda bellek ayırmaz
        val mx = java.lang.management.ManagementFactory.getThreadMXBean() as? com.sun.management.ThreadMXBean
        if (mx != null && mx.isThreadAllocatedMemorySupported) {
            val b = cleanMsg.copyOf(cleanMsg.size + 64)
            repeat(2000) { CnameGuard.guard(b, 0, cleanMsg.size) }
            val tid = Thread.currentThread().id
            val b0 = mx.getThreadAllocatedBytes(tid)
            repeat(20000) { CnameGuard.guard(b, 0, cleanMsg.size) }
            val per = (mx.getThreadAllocatedBytes(tid) - b0) / 20000
            T.check("temiz cevapta çağrı başına bellek ayırmaz (≤ 16 bayt)", per <= 16, "$per bayt")
        }
    }

    T.group("Reklam: aynı site içi CNAME muafiyeti (site kırılmasın)")
    run {
        setEngine(block = listOf("cdn.magaza.example", "izle.tracker-net.example"))
        val same = response("www.magaza.example", 1, listOf("cdn.magaza.example"))
        val bufS = same.copyOf(same.size + 64)
        val nS = CnameGuard.guard(bufS, 0, same.size)
        T.check("aynı site içi CNAME (CDN) engellenmez: site içeriği açılır", nS == same.size && !Dns.isLocalBlock(bufS, 0, nS))
        val cross = response("www.magaza.example", 1, listOf("izle.tracker-net.example"))
        val bufC = cross.copyOf(cross.size + 64)
        val nC = CnameGuard.guard(bufC, 0, cross.size)
        T.check("farklı siteye CNAME hâlâ engellenir (izleyici zinciri)", nC != cross.size && Dns.isLocalBlock(bufC, 0, nC))
        val deep = response("a.b.magaza.example", 1, listOf("cdn.magaza.example"))
        val bufD = deep.copyOf(deep.size + 64)
        val nD = CnameGuard.guard(bufD, 0, deep.size)
        T.check("alt alan adlarında da site muafiyeti geçerli", nD == deep.size && !Dns.isLocalBlock(bufD, 0, nD))
    }

    T.group("Reklam: kanarya adlar (şifreli DNS'e geçişi kapat)")
    run {
        val e = setEngine()
        fun v(n: String) = e.verdictOf(n)
        T.check("use-application-dns.net, mask.icloud.com, mask-h2.icloud.com kanaryadır", listOf("use-application-dns.net", "mask.icloud.com", "mask-h2.icloud.com").all { v(it) == FilterVerdict.CANARY })
        T.check("benzer adlar kanarya değildir", listOf("xuse-application-dns.net", "use-application-dns.net.ornek.org", "icloud.com", "www.mask.icloud.com").none { v(it) == FilterVerdict.CANARY })
        val eAllow = setEngine(allow = listOf("use-application-dns.net"))
        T.check("kullanıcı izin listesi kanaryanın üstündedir", eAllow.verdictOf("use-application-dns.net") == FilterVerdict.PASS)
        FilterRuntime.reset(); FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), emptyList())
        val q = Dns.buildQuery(0x1357, "use-application-dns.net")
        T.check("motor etkin değilken (liste yok) kanarya cevabı verilmez", FilterRuntime.engine!!.verdict(q, 0, q.size) == FilterVerdict.PASS)
        val out = ByteArray(600)
        val n = FilterEngine.buildNxdomain(q, 0, q.size, out, 0)
        T.check("NXDOMAIN cevabı: kimlik, soru, RCODE=3, SOA yetkisi", n == q.size + 33 && Dns.isLocalBlock(out, 0, n) && Packets.u16(out, 0) == 0x1357 && (Packets.u16(out, 2) and 0xF) == 3 && (Packets.u16(out, 2) and 0x8000) != 0 &&
            Packets.u16(out, 4) == 1 && Packets.u16(out, 6) == 0)
        // sarmalayıcıdan geçişte
        setEngine()
        val inner = object : Forwarder {
            var got = 0
            override val proto: Proto get() = Proto.PLAIN
            override fun start() {}
            override fun onPacket(p: ByteArray, len: Int) { got++ }
            override fun stats() = Stats(queries = got.toLong(), forwarded = got.toLong())
            override fun resetNetwork(reason: String) {}
            override fun clearCache() {}
            override fun close() {}
        }
        val wrote = ArrayList<ByteArray>()
        val fw = FilteringForwarder(inner) { b, off, len -> wrote.add(b.copyOfRange(off, off + len)) }
        FilterLive.clear()
        val dns = Dns.buildQuery(0x4242, "use-application-dns.net")
        val pk = ByteArray(Packets.HDR + dns.size)
        System.arraycopy(dns, 0, pk, Packets.HDR, dns.size)
        pk[0] = 0x45; Packets.put16(pk, 2, pk.size); Packets.put16(pk, 6, 0x4000); pk[8] = 64; pk[9] = 17
        Packets.put32(pk, 12, Packets.ip(10, 111, 222, 1)); Packets.put32(pk, 16, Packets.ip(10, 111, 222, 2))
        Packets.put16(pk, 10, Packets.checksum(pk, 0, 20)); Packets.put16(pk, 20, 40001); Packets.put16(pk, 22, 53); Packets.put16(pk, 24, 8 + dns.size)
        fw.onPacket(pk, pk.size)
        T.check("tünelde kanarya sorgusu NXDOMAIN ile cevaplanır, üst DNS'e gitmez", inner.got == 0 && wrote.size == 1 && (Packets.u16(wrote[0], Packets.HDR + 2) and 0xF) == 3)
        T.check("kanarya 'engellenen site' sayılmaz, listeye girmez, istatistiği artırmaz", FilterLive.recent().isEmpty() && fw.stats().blocked == 0L)
    }

    T.group("Reklam: DoH / DoT sızıntı listesi")
    run {
        val majors = listOf("dns.google", "cloudflare-dns.com", "one.one.one.one", "dns.quad9.net", "doh.opendns.com", "dns.adguard-dns.com", "dns.nextdns.io",
            "doh.dns.sb", "doh.cleanbrowsing.org", "dns.controld.com", "dns.mullvad.net", "dns0.eu", "dns.twnic.tw", "doh.li", "wikimedia-dns.org", "doh.xfinity.com")
        T.check("büyük sağlayıcıların hepsi tanınır, alt alan adları dahil", majors.all { Dpi.isDohHost(it) && Dpi.isDohHost("x.$it") })
        T.check("benzer ve ilgisiz adlar tanınmaz", listOf("notdns.google", "google.com", "cloudflare.com", "example.org", "dns.google.evil.com", "mydoh.li").none { Dpi.isDohHost(it) })
        fun a4(a: Int, b: Int, c: Int, d: Int) = byteArrayOf(a.toByte(), b.toByte(), c.toByte(), d.toByte())
        T.check("bilinen DoH IPv4 adresleri tanınır", listOf(a4(8, 8, 8, 8), a4(8, 8, 4, 4), a4(1, 1, 1, 1), a4(1, 0, 0, 1), a4(9, 9, 9, 9), a4(208, 67, 222, 222), a4(94, 140, 14, 14), a4(76, 76, 2, 0)).all { Dpi.isDohAddress(it) })
        T.check("sıradan adresler tanınmaz", listOf(a4(8, 8, 8, 7), a4(93, 184, 216, 34), a4(127, 0, 0, 1), a4(10, 0, 0, 1), a4(1, 1, 1, 4)).none { Dpi.isDohAddress(it) })
        T.check("IPv6 DoH adresleri tanınır, diğerleri değil", Dpi.isDohAddress(java.net.InetAddress.getByName("2606:4700:4700::1111").address) &&
            Dpi.isDohAddress(java.net.InetAddress.getByName("2001:4860:4860::8888").address) && !Dpi.isDohAddress(java.net.InetAddress.getByName("2001:db8::1").address))
        T.check("hatalı uzunlukta adres güvenle reddedilir", !Dpi.isDohAddress(ByteArray(0)) && !Dpi.isDohAddress(ByteArray(5)) && !Dpi.isDohAddress(ByteArray(15)))
    }

    T.group("Reklam: liste kaynakları ve kapsam")
    run {
        FilterRuntime.source = FilterSource { name -> File("app/src/main/assets/filter", name).inputStream() }
        FilterRuntime.reset(); FilterRuntime.updateNow(FilterLevel.BASIC, emptyList(), emptyList())
        val basic = FilterRuntime.engine!!
        // 1Hosts Lite'tan gelen, eski listelerde bulunmayan ve yaygın olmayan alan adları
        val yeni = listOf("newscompiler.com", "aqyad.com", "polarichip.com", "wavesecure.net", "hellospur.com", "albss.com", "backname.io")
        T.check("1Hosts Lite'tan gelen yeni alan adları Basit seviyede engellenir", yeni.count { basic.verdictOf(it) != FilterVerdict.PASS } >= 6, yeni.map { it to basic.verdictOf(it) }.toString())
        T.check("Perflyst ve OEM (Xiaomi, Huawei, Samsung) izleyicileri Orta seviyede engellenir", run {
            FilterRuntime.reset(); FilterRuntime.updateNow(FilterLevel.MEDIUM, emptyList(), emptyList())
            val m = FilterRuntime.engine!!
            listOf("data.mistat.xiaomi.com", "metrics.data.hicloud.com", "nmetrics.samsung.com", "app-measurement.com", "events.appsflyer.com").all { m.verdictOf(it) != FilterVerdict.PASS }
        })
        T.check("popülerlik kapısı: yaygın siteler (despegar.com) Basit/Orta'da engellenmez, yalnızca Sıkı'da", run {
            fun v(l: FilterLevel): Int { FilterRuntime.reset(); FilterRuntime.updateNow(l, emptyList(), emptyList()); return FilterRuntime.engine!!.verdictOf("despegar.com") }
            v(FilterLevel.BASIC) == FilterVerdict.PASS && v(FilterLevel.MEDIUM) == FilterVerdict.PASS && v(FilterLevel.STRICT) != FilterVerdict.PASS
        })
        T.check("korunan adlar (bağlantı denetimi, ödeme, banka) hâlâ hiçbir seviyede engellenmez", run {
            FilterRuntime.reset(); FilterRuntime.updateNow(FilterLevel.STRICT, emptyList(), emptyList())
            val s = FilterRuntime.engine!!
            listOf("connectivitycheck.gstatic.com", "captive.apple.com", "www.msftconnecttest.com").all { s.verdictOf(it) == FilterVerdict.PASS }
        })
        val kaynaklar = File("app/src/main/assets/filter/KAYNAKLAR.txt").readText()
        T.check("KAYNAKLAR.txt: 1Hosts (MPL-2.0) lisansı, özgün kaynak ve yeniden üretim aracı belirtilmiş", kaynaklar.contains("MPL-2.0") && kaynaklar.contains("github.com/badmojr/1Hosts") && kaynaklar.contains("build_filter.py"))
        FilterRuntime.reset()
    }
}
