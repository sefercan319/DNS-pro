package app.dnshizli.core

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicLongArray
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLPeerUnverifiedException
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * Şifreli DNS hedefi: bağlanılacak IP:port, sertifikada beklenen ad (SNI) ve DoH için yol.
 * [alt]: aynı sunucunun öbür IP ailesindeki adresi (IPv4 ↔ IPv6). Varsa bağlantı önce [addr]'a, olmazsa [alt]'a kurulur;
 * hangisinin çalıştığı ağ değişene kadar hatırlanır. Sertifika her iki adreste aynı [host] adına göre doğrulanır.
 */
class SecureTarget(val addr: InetSocketAddress, val host: String, val path: String = "/dns-query", val alt: InetSocketAddress? = null)

/**
 * Şifreli DNS yönlendiricisi: DNS-over-TLS (RFC 7858, port 853) ya da DNS-over-HTTPS (RFC 8484, HTTP/1.1 POST, port 443).
 * Android'e bağlı değildir; JVM testlerinde yerel bir TLS sunucusuyla uçtan uca sınanır.
 *
 * Tasarım ("şeritler"):
 *  - Sorgular bir kuyruğa girer. Her şerit = 1 iş parçacığı + 1 TLS bağlantısı; sırayla soru gönderir, cevabı okur.
 *  - Şeritler iş varken açılır (en çok [maxLanes]); kuyrukta [BURST_AFTER_MS]'den uzun bekleyen iş varsa (ör. yavaş
 *    cevaplanan adlar şeritleri meşgul ediyorsa) geçici olarak [burstLanes]'e kadar ek şerit açılır.
 *    [idleMs] boyunca iş gelmezse şerit bağlantısını kapatıp biter: boştayken hiç iş parçacığı, soket ya da zamanlayıcı kalmaz.
 *  - Aynı anda bekleyen ÖZDEŞ sorgular tek sorguya birleşir (istemcinin yeniden denemeleri şerit tüketmez).
 *  - TLS bağlantısı sunucunun gerçek IP'sine açılır (ad çözümlemesi gerekmez, tünel döngüsü olmaz);
 *    sertifika, katalogdaki ada ([SecureTarget.host]) göre doğrulanır. Doğrulanamayan sunucuya sorgu gönderilmez.
 *  - Cevabın kimliği (DoT) ve soru bölümü sorguyla aynı olmalıdır.
 *  - Bayat bağlantı (sunucu boşta kapatmış) fark edilince sessizce yenisi açılır; bu sunucu hatası sayılmaz.
 *  - Sunucu yakın zamanda başka sorulara cevap verdiyse tek bir sorunun zaman aşımı "yavaş ad" sayılır, sunucu hatası
 *    sayılmaz. Birincil hedefe bağlantılar üst üste gerçekten başarısız olursa yedeğe geçilir; ağ değişince birincile dönülür.
 *  - Büyük cevaplar IP parçalarıyla tünele yazılır (bkz. [Packets.writeReply]).
 */
class SecureForwarder(
    override val proto: Proto,
    private val targets: List<SecureTarget>,
    private val writeToTun: (ByteArray, Int, Int) -> Unit,
    /** Tünel dışında tutulacak (VpnService.protect) ve bağlanmış ham soket üretir. */
    private val openSocket: (InetSocketAddress, Int) -> Socket = { a, t -> Socket().also { it.connect(a, t) } },
    tls: SSLSocketFactory = SSLSocketFactory.getDefault() as SSLSocketFactory,
    /**
     * Ağ değiştiğinde TLS oturum önbelleği olmayan yeni bir fabrika üretir. Oturum biletleri sunucunun bizi iki ağ arasında
     * (Wi-Fi ↔ mobil) tanımasına yarardı; bu yüzden ağ değişince eski biletler atılır. null: fabrika değişmez (testler).
     */
    private val freshTls: (() -> SSLSocketFactory)? = null,
    private val verifier: HostnameVerifier = HttpsURLConnection.getDefaultHostnameVerifier(),
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000 },
    private val timeoutMs: Int = 4000,
    private val connectTimeoutMs: Int = 3000,
    private val giveUpMs: Long = 6000,
    private val idleMs: Long = 20_000,
    private val maxLanes: Int = 4,
    private val burstLanes: Int = maxOf(maxLanes, 12),
    cacheEntries: Int = 256,
    private val threadFactory: (Runnable, String) -> Thread =
        { r, name -> Thread(r, name).apply { isDaemon = true } },
    private val log: (String) -> Unit = {},
) : Forwarder {

    init {
        require(proto == Proto.DOT || proto == Proto.DOH) { "yalnızca DoT ya da DoH" }
        require(targets.isNotEmpty()) { "en az bir hedef gerekli" }
    }

    private class Job(val key: String, val query: ByteArray, val qEnd: Int, val addedOpt: Boolean, val at: Long, first: Waiter) {
        val waiters = ArrayList<Waiter>(1).also { it.add(first) }   // [this] kilidiyle korunur
        var done = false                                          // [this] kilidiyle korunur
    }

    private val queue = LinkedBlockingQueue<Job>(MAX_QUEUE)
    private val byKey = ConcurrentHashMap<String, Job>()
    private val cache = DnsCache(cacheEntries, nowMs)
    private val parsed = ParsedQuery()
    private val lanes = AtomicInteger()
    private val idleLanes = AtomicInteger()
    private val laneSeq = AtomicInteger()
    private val connecting = AtomicInteger()
    private val conns: MutableSet<Conn> = ConcurrentHashMap.newKeySet()
    private val laneThreads: MutableSet<Thread> = ConcurrentHashMap.newKeySet()
    private val lastOk = AtomicLongArray(targets.size).also { for (i in targets.indices) it.set(i, Long.MIN_VALUE / 2) }
    @Volatile private var tlsFactory: SSLSocketFactory = tls
    /** Hedef başına: önce öbür aile ([SecureTarget.alt]) mi denenecek? Ağ değişince sıfırlanır. */
    private val altFirst = java.util.concurrent.atomic.AtomicIntegerArray(targets.size)
    private val tlsFailures = AtomicLong()
    @Volatile private var closed = false
    @Volatile private var started = false
    @Volatile private var netGen = 0
    private val connEst = RttEstimator()      // TCP bağlantı süresi (ağ değişince sıfırlanır): ilk IP ailesine tanınan süreyi belirler
    @Volatile private var primaryIdx = 0
    private val streak = AtomicInteger()

    // yalnızca onPacket (tünel) iş parçacığı
    private val tunBuf = ByteArray(Packets.HDR6 + MAX_MSG)
    private val tunScratch = ByteArray(Packets.MTU)

    private val queries = AtomicLong()
    private val cacheHits = AtomicLong()
    private val forwarded = AtomicLong()
    private val answered = AtomicLong()
    private val retries = AtomicLong()
    private val timeouts = AtomicLong()
    private val dropped = AtomicLong()
    private val resets = AtomicLong()
    private val latencySum = AtomicLong()
    private val failovers = AtomicLong()
    private val blocked = AtomicLong()
    private val bytesUp = AtomicLong()
    private val bytesDown = AtomicLong()
    private val merged = AtomicLong()
    private val rejected = AtomicLong()
    private val ring = LatencyRing()

    override fun start() { started = true }

    override fun latencies(out: IntArray): Int = ring.copyTo(out)

    override fun stats() = Stats(
        queries.get(), cacheHits.get(), forwarded.get(), answered.get(), retries.get(),
        timeouts.get(), dropped.get(), resets.get(), latencySum.get(), failovers.get(), primaryIdx != 0, blocked.get(),
        bytesUp.get(), bytesDown.get(), merged.get(), rejected.get(), tlsFailures.get(),
    )

    internal fun laneCount() = lanes.get()
    internal fun openConnections() = conns.size

    override fun clearCache() = cache.clear()

    override fun resetNetwork(reason: String) {
        if (closed) return
        netGen++
        connEst.reset()
        primaryIdx = 0
        streak.set(0)
        cache.clear()
        for (i in targets.indices) altFirst.set(i, 0)
        freshTls?.let { f -> try { tlsFactory = f() } catch (_: Exception) {} }
        for (i in targets.indices) lastOk.set(i, Long.MIN_VALUE / 2)
        // Açık bağlantıları kapat: eski ağdaki okumada bekleyen şerit hemen uyanıp yeni bağlantıyla yeniden dener.
        for (c in conns.toTypedArray()) c.close()
        resets.incrementAndGet()
        log("şifreli bağlantılar yenilendi ($reason)")
    }

    override fun onPacket(p: ByteArray, len: Int) {
        if (closed) return
        val q = parsed
        if (!q.parse(p, len, MAX_UDP_QUERY)) return
        queries.incrementAndGet()
        val key = String(p, q.dnsOff + 2, q.dnsLen - 2, Charsets.ISO_8859_1)

        val n = cache.get(key, q.clientId, tunBuf, Packets.HDR)
        if (n > 0) {
            cacheHits.incrementAndGet()
            if (Dns.isBlocked(tunBuf, Packets.HDR, n)) blocked.incrementAndGet()
            q.writeCached(tunBuf, tunScratch, n, writeToTun)
            return
        }

        val waiter = q.waiter()
        val same = byKey[key]
        if (same != null) {
            synchronized(same) {
                if (!same.done && same.waiters.size < MAX_WAITERS) {
                    same.waiters.add(waiter)
                    merged.incrementAndGet()
                    return
                }
            }
        }

        // Gizlilik: istemciye ait EDNS seçenekleri atılır, "alt ağı iletme" işareti ve 128 baytlık dolgu eklenir.
        val san = Dns.sanitizeQuery(p, q.dnsOff, q.dnsLen, pad = true, absentPayload = 1232)
        if (san == null) { dropped.incrementAndGet(); return }
        val query = san.query
        val job = Job(key, query, Dns.questionEnd(query, 0, query.size), san.addedOpt, nowMs(), waiter)
        // Boşta bekleyen şerit sayısı kuyruğa koymadan ÖNCE okunur: koyduktan sonra okunsa, işi hemen kapan
        // boştaki şerit sayacı sıfırlamış olur ve gereksiz yeni bir şerit (TLS bağlantısı) açılırdı.
        val idleBefore = idleLanes.get()
        byKey[key] = job
        if (!queue.offer(job)) { byKey.remove(key, job); dropped.incrementAndGet(); return }
        forwarded.incrementAndGet()
        if (queue.size > idleBefore || lanes.get() == 0) ensureLane(force = true)
        maybeBurst()
    }

    /**
     * Kuyruğun başındaki iş çok bekliyorsa ve şeritlerin hiçbiri bağlantı kurmuyorsa (yani hepsi cevap bekliyor:
     * yavaş çözülen adlarla meşguller) geçici bir ek şerit açar. Bağlantı kuran şerit varsa beklemek yeterlidir.
     */
    private fun maybeBurst() {
        val head = queue.peek() ?: return
        if (connecting.get() > 0) return
        if (nowMs() - head.at >= BURST_AFTER_MS) ensureLane(force = true, burst = true)
    }

    /** Boşta şerit yoksa (ya da [force]) ve sınır aşılmadıysa yeni şerit açar. */
    private fun ensureLane(force: Boolean = false, burst: Boolean = false) {
        if (closed || !started) return
        if (!force && idleLanes.get() > 0) return
        val cap = if (burst) burstLanes else maxLanes
        while (true) {
            val n = lanes.get()
            if (n >= cap) return
            if (lanes.compareAndSet(n, n + 1)) break
        }
        val t = threadFactory(Runnable { laneLoop() }, "dns-lane-" + laneSeq.incrementAndGet())
        laneThreads.add(t)
        try {
            t.start()
        } catch (e: Throwable) {
            laneThreads.remove(t)
            lanes.decrementAndGet()
        }
    }

    private fun markDone(job: Job) {
        synchronized(job) { job.done = true }
        byKey.remove(job.key, job)
    }

    /** Hedef son [HEALTH_MS] içinde başka bir soruya cevap verdi mi? */
    private fun healthy(target: Int): Boolean = nowMs() - lastOk.get(target) < HEALTH_MS

    // ------------------------------------------------------------------ şerit

    private fun laneLoop() {
        val buf = ByteArray(Packets.HDR6 + MAX_MSG)
        val scratch = ByteArray(Packets.MTU)
        var conn: Conn? = null
        var idleMarked = false
        try {
            while (!closed) {
                if (!idleMarked) idleLanes.incrementAndGet()
                idleMarked = false
                val job = try {
                    queue.poll(idleMs, TimeUnit.MILLISECONDS)
                } catch (_: InterruptedException) {
                    null
                } finally {
                    idleLanes.decrementAndGet()
                }
                if (job == null) {
                    // Boşta kaldı: kuyruğa bu arada iş düştüyse devam et, yoksa bitir.
                    if (queue.isEmpty() || closed) break else continue
                }
                maybeBurst()
                if (nowMs() - job.at > giveUpMs) { timeouts.incrementAndGet(); ring.add(LatencyRing.TIMEOUT); markDone(job); continue }

                var replyLen = -1
                var attempt = 0
                var avoid = -1                     // son denemede başarısız olan hedef: sıradaki deneme diğerine gider
                while (attempt < 3 && !closed && nowMs() - job.at <= giveUpMs) {
                    attempt++
                    var c = conn
                    if (c != null && (c.dead || c.gen != netGen)) { c.close(); c = null; conn = null }
                    val fresh = c == null
                    val idx = c?.target ?: (if (avoid >= 0 && avoid == primaryIdx && targets.size > 1) (avoid + 1) % targets.size else primaryIdx)
                    var exchanging = false
                    try {
                        if (c == null) {
                            connecting.incrementAndGet()
                            try { c = open(idx) } finally { connecting.decrementAndGet() }
                            conn = c
                        }
                        exchanging = true
                        replyLen = exchange(c, job, buf, Packets.HDR)
                        noteSuccess(c.target)
                        c.used = true
                        break
                    } catch (e: RuntimeException) {
                        // Beklenmeyen bir hata (ör. bozuk cevap) şeridi öldürmesin: bağlantıyı bırak, bu soruyu düşür.
                        c?.close()
                        conn = null
                        log("beklenmeyen şifreli DNS hatası: ${e.javaClass.simpleName}")
                        break
                    } catch (e: IOException) {
                        val wasStale = c != null && ((!fresh && c.used) || c.gen != netGen)   // ağ değişince kapanan bağlantı sunucu hatası sayılmaz
                        c?.close()
                        conn = null
                        if (closed) break
                        val slow = exchanging && e is SocketTimeoutException
                        if (slow && healthy(idx)) {
                            // Sunucu başka sorulara cevap veriyor: bu ad yavaş çözülüyor. Şeridi daha fazla meşgul etme;
                            // istemci kendi yeniden denemesini yapar (o sırada cevap önbelleğe girmiş olabilir).
                            break
                        }
                        // Daha önce çalışmış bir bağlantı koptuysa (sunucu boşta kapatmış) bu bir sunucu hatası değildir.
                        if (!wasStale) {
                            noteFailure(idx, e)
                            avoid = idx
                        }
                        if (attempt < 3) retries.incrementAndGet()
                    }
                }
                if (replyLen < Packets.DNS_HDR) { timeouts.incrementAndGet(); ring.add(LatencyRing.TIMEOUT); markDone(job); continue }
                // Cevabı teslim etmeden ÖNCE boşta say: istemcinin bu cevaba hemen gönderdiği bir sonraki soru
                // yeni bir şerit (ve gereksiz bir TLS el sıkışması) açtırmasın, bu şeride düşsün.
                idleLanes.incrementAndGet()
                idleMarked = true
                deliver(job, buf, replyLen, scratch)
            }
        } finally {
            if (idleMarked) idleLanes.decrementAndGet()
            conn?.close()
            lanes.decrementAndGet()
            laneThreads.remove(Thread.currentThread())
            // Kapanırken kuyrukta iş kaldıysa ve başka şerit yoksa yenisini aç.
            if (!closed && queue.isNotEmpty()) ensureLane()
        }
    }

    private fun deliver(job: Job, buf: ByteArray, len0: Int, scratch: ByteArray) {
        val len = CnameGuard.guard(buf, Packets.HDR, len0)            // gizli izleyici (CNAME) engeli
        answered.incrementAndGet()
        val took = maxOf(0L, nowMs() - job.at)
        latencySum.addAndGet(took)
        ring.add(took.coerceAtMost(LatencyRing.MAX_MS.toLong()).toInt())
        bytesDown.addAndGet(len.toLong())
        if (Dns.isBlocked(buf, Packets.HDR, len)) blocked.incrementAndGet()
        // İstemci EDNS istemediği halde biz OPT eklediysek cevaptaki OPT atılır (önbelleğe de böyle girer).
        val rlen = if (job.addedOpt) Dns.stripOpt(buf, Packets.HDR, len) else len
        val ttl = Dns.cacheTtl(buf, Packets.HDR, rlen)
        if (ttl > 0) cache.put(job.key, buf, Packets.HDR, rlen, ttl)
        synchronized(job) {
            job.done = true
            val n = job.waiters.size
            for (i in 0 until n) {
                // Her istemci için kimlik ve başlıklar (sağlama toplamı dahil) yeniden yazılır; DNS verisi aynı kalır.
                job.waiters[i].deliver(buf, scratch, rlen, writeToTun)
            }
        }
        byKey.remove(job.key, job)
    }

    private fun noteSuccess(target: Int) {
        lastOk.set(target, nowMs())
        if (target == primaryIdx) streak.set(0)
    }

    private fun noteFailure(target: Int, e: IOException) {
        log("şifreli bağlantı hatası: ${e.javaClass.simpleName}")
        if (isTrustFailure(e)) tlsFailures.incrementAndGet()
        if (targets.size < 2 || target != primaryIdx) return
        if (streak.incrementAndGet() >= FAILOVER_AFTER) {
            streak.set(0)
            primaryIdx = (target + 1) % targets.size
            failovers.incrementAndGet()
            log("yedek sunucuya geçildi")
        }
    }

    // ------------------------------------------------------------------ bağlantı

    private inner class Conn(val target: Int, val gen: Int, val sock: SSLSocket) {
        val input: InputStream = BufferedInputStream(sock.inputStream, 8192)
        val output: OutputStream = BufferedOutputStream(sock.outputStream, 1024)
        @Volatile var dead = false
        @Volatile var used = false

        /** Süren soru-cevabın son anı: yavaş yavaş bayt gönderen bir sunucu şeridi sonsuza dek tutamaz. */
        var deadline = Long.MAX_VALUE

        fun close() {
            dead = true
            conns.remove(this)
            try { sock.close() } catch (_: Exception) {}
        }
    }

    /** Sertifika ya da ad doğrulaması başarısız oldu mu? (Araya girilmiş ya da yanlış sunucu belirtisi.) */
    private fun isTrustFailure(e: Throwable): Boolean {
        var c: Throwable? = e
        var depth = 0
        while (c != null && depth++ < 6) {
            if (c is SSLPeerUnverifiedException || c is java.security.cert.CertificateException) return true
            c = c.cause
        }
        return false
    }

    /** Bu hedef için sırayla denenecek adresler: tek aile ya da (öbür aile varsa) hatırlanan sıra. */
    private fun attemptOrder(idx: Int): List<InetSocketAddress> {
        val t = targets[idx]
        val alt = t.alt ?: return listOf(t.addr)
        return if (altFirst.get(idx) == 1) listOf(alt, t.addr) else listOf(t.addr, alt)
    }

    private fun open(idx: Int): Conn {
        val t = targets[idx]
        val order = attemptOrder(idx)
        var last: IOException? = null
        for ((k, addr) in order.withIndex()) {
            // İki aile varken ilkine kısa süre tanınır: yanıt vermeyen (ör. kopuk IPv6) aile bağlantıyı geciktirmesin.
            val budget = if (order.size > 1 && k == 0) minOf(connectTimeoutMs, MobilePolicy.firstFamilyMs(connEst).toInt()) else connectTimeoutMs
            try {
                val c = openOne(idx, t, addr, budget)
                if (order.size > 1) altFirst.set(idx, if (addr == t.alt) 1 else 0)
                return c
            } catch (e: IOException) {
                last = e
                if (closed) break
            }
        }
        throw last ?: IOException("adres yok")
    }

    private fun openOne(idx: Int, t: SecureTarget, addr: InetSocketAddress, connectMs: Int): Conn {
        val gen = netGen   // el sıkışma sürerken ağ değişirse bu bağlantı eski ağdandır
        val t0 = nowMs()
        val raw = try {
            openSocket(addr, connectMs).also { connEst.sample((nowMs() - t0).toDouble()) }
        } catch (e: IOException) {
            throw e
        } catch (e: Exception) {
            throw IOException("soket açılamadı: ${e.javaClass.simpleName}", e)   // şerit beklenmedik hatayla ölmesin
        }
        val ssl: SSLSocket
        try {
            raw.soTimeout = timeoutMs
            raw.tcpNoDelay = true
            ssl = tlsFactory.createSocket(raw, t.host, addr.port, true) as SSLSocket
            // Yalnızca TLS 1.2 ve 1.3: eski sürümlere (ve onların zayıf takımlarına) düşürme saldırısı mümkün olmasın.
            val modern = ssl.supportedProtocols.filter { it == "TLSv1.3" || it == "TLSv1.2" }
            if (modern.isNotEmpty()) ssl.enabledProtocols = modern.toTypedArray()
            ssl.soTimeout = timeoutMs
            ssl.startHandshake()
            if (!verifier.verify(t.host, ssl.session)) {
                try { ssl.close() } catch (_: Exception) {}
                throw SSLPeerUnverifiedException("sertifika ${t.host} adına ait değil")
            }
        } catch (e: IOException) {
            try { raw.close() } catch (_: Exception) {}
            throw e
        } catch (e: RuntimeException) {
            try { raw.close() } catch (_: Exception) {}
            throw IOException("TLS kurulamadı: ${e.javaClass.simpleName}", e)
        }
        val c = try { Conn(idx, gen, ssl) } catch (e: Exception) {
            try { raw.close() } catch (_: Exception) {}
            throw IOException("TLS akışı açılamadı: ${e.javaClass.simpleName}", e)
        }
        if (gen != netGen) { c.close(); throw IOException("ağ değişti") }
        conns.add(c)
        if (closed) { c.close(); throw IOException("kapandı") }
        return c
    }

    /** Soruyu gönderir, cevabı [out] içine [off] konumuna yazar; cevap uzunluğunu döner. Cevabın sorusu denetlenir. */
    private fun exchange(c: Conn, job: Job, out: ByteArray, off: Int): Int {
        c.deadline = nowMs() + timeoutMs
        bytesUp.addAndGet(job.query.size.toLong())
        val len = if (proto == Proto.DOT) exchangeDot(c, job.query, out, off) else exchangeDoh(c, job.query, out, off)
        if (!Dns.sameQuestion(job.query, 0, job.qEnd, out, off, len)) {
            rejected.incrementAndGet()
            throw IOException("cevabın sorusu uyuşmadı")
        }
        return len
    }

    private fun exchangeDot(c: Conn, query: ByteArray, out: ByteArray, off: Int): Int {
        val o = c.output
        o.write(query.size ushr 8)
        o.write(query.size and 0xFF)
        o.write(query)
        o.flush()
        val wantId = Packets.u16(query, 0)
        // Aynı bağlantıda sırayla soru-cevap yapıldığı için ilk gelen cevap bizimdir; yine de kimlik denetlenir.
        repeat(4) {
            val len = (readByte(c) shl 8) or readByte(c)
            if (len < Packets.DNS_HDR || len > MAX_MSG) throw IOException("geçersiz uzunluk $len")
            readFully(c, out, off, len)
            if (Packets.u16(out, off) == wantId) return len
        }
        throw IOException("cevap kimliği uyuşmadı")
    }

    private fun exchangeDoh(c: Conn, query: ByteArray, out: ByteArray, off: Int): Int {
        val t = targets[c.target]
        val q = query.copyOf()
        Packets.put16(q, 0, 0)                     // RFC 8484: önbellek dostu olsun diye kimlik 0
        val head = "POST ${t.path} HTTP/1.1\r\nHost: ${t.host}\r\nUser-Agent: Mozilla/5.0\r\n" +
            "Accept: application/dns-message\r\nContent-Type: application/dns-message\r\n" +
            "Content-Length: ${q.size}\r\n\r\n"
        val o = c.output
        o.write(head.toByteArray(Charsets.ISO_8859_1))
        o.write(q)
        o.flush()

        val status = readLine(c) ?: throw EOFException("cevap yok")
        val parts = status.split(' ')
        if (parts.size < 2 || !parts[0].startsWith("HTTP/1.")) throw IOException("bozuk durum satırı")
        val code = parts[1].toIntOrNull() ?: throw IOException("bozuk durum satırı")
        var contentLength = -1
        var chunked = false
        var close = false
        var type = ""
        var lines = 0
        while (true) {
            val line = readLine(c) ?: throw EOFException("başlık kesildi")
            if (line.isEmpty()) break
            if (++lines > MAX_HEADER_LINES) throw IOException("çok fazla başlık")
            val colon = line.indexOf(':')
            if (colon <= 0) continue
            val name = line.substring(0, colon).trim().lowercase()
            val value = line.substring(colon + 1).trim()
            when (name) {
                "content-length" -> contentLength = if (value.isNotEmpty() && value.length <= 9 && value.all { it in '0'..'9' }) value.toInt() else -1
                "transfer-encoding" -> chunked = value.lowercase().contains("chunked")
                "connection" -> close = value.lowercase().contains("close")
                "content-type" -> type = value.lowercase()
            }
        }
        val len = when {
            chunked -> readChunked(c, out, off)
            contentLength >= 0 -> {
                if (contentLength > MAX_MSG) throw IOException("cevap çok büyük")
                readFully(c, out, off, contentLength); contentLength
            }
            else -> throw IOException("uzunluk bilinmiyor")
        }
        if (close) c.dead = true
        if (code != 200) throw IOException("HTTP $code")
        if (!type.startsWith("application/dns-message")) throw IOException("beklenmeyen içerik: $type")
        if (len < Packets.DNS_HDR) throw IOException("kısa cevap")
        // DoH cevabının kimliği 0'dır: istemciye giden kimlik teslimde yazılır; soru bölümü exchange()'de denetlenir.
        Packets.put16(out, off, Packets.u16(query, 0))
        return len
    }

    private fun checkDeadline(c: Conn) {
        if (nowMs() > c.deadline) throw SocketTimeoutException("cevap süresi doldu")
    }

    private fun readByte(c: Conn): Int {
        checkDeadline(c)
        val b = c.input.read()
        if (b < 0) throw EOFException("bağlantı kapandı")
        return b
    }

    private fun readFully(c: Conn, out: ByteArray, off: Int, n: Int) {
        var got = 0
        while (got < n) {
            checkDeadline(c)
            val r = c.input.read(out, off + got, n - got)
            if (r < 0) throw EOFException("bağlantı kapandı")
            got += r
        }
    }

    /** CRLF ile biten ASCII satırı (CRLF hariç); bağlantı kapandıysa null. */
    private fun readLine(c: Conn): String? {
        val sb = StringBuilder(64)
        while (true) {
            checkDeadline(c)
            val b = c.input.read()
            if (b < 0) return if (sb.isEmpty()) null else throw EOFException("satır kesildi")
            if (b == '\n'.code) {
                if (sb.isNotEmpty() && sb[sb.length - 1] == '\r') sb.setLength(sb.length - 1)
                return sb.toString()
            }
            if (sb.length > MAX_LINE) throw IOException("satır çok uzun")
            sb.append(b.toChar())
        }
    }

    private fun readChunked(c: Conn, out: ByteArray, off: Int): Int {
        var total = 0
        while (true) {
            val sizeLine = readLine(c) ?: throw EOFException("parça kesildi")
            val hex = sizeLine.substringBefore(';').trim()
            // Yalnızca onaltılık rakamlar (işaret, boşluk, "0x" yok) ve makul uzunluk.
            if (hex.isEmpty() || hex.length > 6 || !hex.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) {
                throw IOException("bozuk parça")
            }
            val size = hex.toInt(16)
            if (size == 0) {
                var trailers = 0
                while (true) {
                    val l = readLine(c) ?: break
                    if (l.isEmpty()) break
                    if (++trailers > MAX_HEADER_LINES) throw IOException("çok fazla son başlık")
                }
                return total
            }
            if (size > MAX_MSG - total) throw IOException("cevap çok büyük")
            readFully(c, out, off + total, size)
            total += size
            readLine(c)                                   // parça sonundaki CRLF
        }
    }

    override fun close() {
        if (closed) return
        closed = true
        for (c in conns.toTypedArray()) c.close()
        for (t in laneThreads.toTypedArray()) t.interrupt()
        queue.clear()
        byKey.clear()
        cache.clear()
    }

    companion object {
        /** Şifreli bağlantıda kabul edilen en büyük DNS mesajı. */
        const val MAX_MSG = 16384

        /** Tünelden gelen UDP sorgusunun üst sınırı. */
        const val MAX_UDP_QUERY = 4096

        /** Çift aile varken ilk ailenin bağlantı süresi (ms); yanıt vermezse öbürüne geçilir. */
        const val FIRST_FAMILY_MS = 1500

        const val MAX_QUEUE = 256
        const val FAILOVER_AFTER = 2

        /** Bekleyen tek sorguya eklenebilecek en fazla istemci. */
        const val MAX_WAITERS = 16

        /** Kuyruktaki iş bu kadar beklerse geçici ek şerit açılır (ms). */
        const val BURST_AFTER_MS = 300L

        /** Hedefin "sağlıklı" sayılması için son başarılı cevaptan bu yana en fazla geçen süre (ms). */
        const val HEALTH_MS = 10_000L

        private const val MAX_HEADER_LINES = 64
        private const val MAX_LINE = 8192
    }
}
