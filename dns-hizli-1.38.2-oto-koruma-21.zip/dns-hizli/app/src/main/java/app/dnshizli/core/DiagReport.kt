package app.dnshizli.core

/**
 * Tanılama raporu girdisi. Yalnızca sürüm, cihaz modeli, ağ türü, ayar kodları ve sayılar taşır.
 * Alan adı, IP adresi, sunucu adı, geçmiş ya da kişisel veri alanı YOKTUR: rapor bu yüzden içermez.
 */
class DiagInput(
    val appVersion: String,
    val versionCode: Int,
    val androidSdk: Int,
    val deviceModel: String,
    val netKind: String,
    val vpnActive: Boolean,
    val encryption: String,
    val odoh: String,
    val ipMode: String,
    val failClosed: Boolean,
    val strictEncryption: Boolean,
    val filterMem: String,
    val problems: Int,
    val crashCount: Int,
    val lastCrash: String?,
    /** Tanınan sistem ve cihaz sınıfı ([DeviceProfile.diagLine]); tanınmadıysa boş. */
    val system: String = "",
    /** Son çalışma olayları ([Journal] satırları; sorgu adı içermez). Rapor yine de [clean] ile temizler. */
    val events: List<String> = emptyList(),
    /** Denetim güven puanı (0..100); -1 = ölçülmedi. */
    val score: Int = -1,
    /** Şu an geçerli denetim bulguları ([Finding] metinleri, "[KATEGORİ] ağırlık: metin"). */
    val audit: List<String> = emptyList(),
    /** Telefon/ROM uyum notları ([CompatPlan.notes]). */
    val compat: List<String> = emptyList(),
    /** Ayar özeti ("anahtar=değer" çiftleri; yalnızca açık/kapalı ve sabit seçenekler). */
    val settings: List<String> = emptyList(),
)

/**
 * Destek için paylaşılabilir, sade teknik özet. Otomatik gönderilmez: kullanıcı önce metni görür, sonra kendisi paylaşır.
 * Metin alanları [clean] ile temizlenir; alan adı ya da IP benzeri bir değer gelse bile rapora çıkmaz.
 */
object DiagReport {
    const val MAX = 18000
    private const val MAX_FIELD = 60
    private const val EVENTS = 220

    private val DOMAIN = Regex("[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.(?:xn--[A-Za-z0-9-]{2,}|[A-Za-z]{2,})")
    private val IPV6_V4 = Regex("(?i)(?:[0-9a-f]{0,4}:){2,7}\\d{1,3}(?:\\.\\d{1,3}){3}")      // ::ffff:1.2.3.4, 64:ff9b::1.2.3.4
    private val IPV4 = Regex("\\b\\d{1,3}(\\.\\d{1,3}){3}\\b")
    private val IPV6 = Regex("(?i)(?<![0-9a-f:])(?=[0-9a-f:]*[0-9a-f])(?:[0-9a-f]{0,4}:){2,7}[0-9a-f]{0,4}(?![0-9a-f:])")

    /** Kontrol ve yön değiştirici karakterleri, '@' işaretini ve alan adı/IP benzeri parçaları siler; uzunluğu sınırlar. */
    fun clean(s: String, max: Int = MAX_FIELD): String {
        var t = s.filter { !TextSafe.isHidden(it) && it != '@' }
        t = IPV6_V4.replace(t, "?")
        t = IPV6.replace(t, "?")                    // önce IPv6: ::ffff:1.2.3.4 tek parça maskelenir
        t = IPV4.replace(t, "?")
        t = DOMAIN.replace(t, "?")
        t = t.trim().replace(Regex("\\s+"), " ")
        return t.take(max)
    }

    private fun yn(b: Boolean) = if (b) "açık" else "kapalı"

    fun build(i: DiagInput): String {
        val lines = listOf(
            "DNS Hızlı tanılama raporu",
            "Sürüm: ${clean(i.appVersion)} (${i.versionCode})",
            "Android: ${i.androidSdk}",
            "Cihaz: ${clean(i.deviceModel)}",
        ) + (if (i.system.isBlank()) emptyList() else listOf("Sistem: ${clean(i.system, 100)}")) + listOf(
            "Ağ türü: ${clean(i.netKind)}",
            "Tünel: ${yn(i.vpnActive)}",
            "Şifreleme: ${clean(i.encryption)}",
            "ODoH: ${clean(i.odoh)}",
            "IP modu: ${clean(i.ipMode)}",
            "Bağlantı kesilince engelle: ${yn(i.failClosed)}",
            "Sıkı şifreleme: ${yn(i.strictEncryption)}",
            "Filtre belleği: ${clean(i.filterMem)}",
            "Sorun sayısı: ${i.problems.coerceAtLeast(0)}",
            "Kayıtlı çökme: ${i.crashCount.coerceAtLeast(0)}",
            "Son çökme: ${i.lastCrash?.let { clean(it, 200) }?.takeIf { it.isNotBlank() } ?: "yok"}",
        )
        val out = ArrayList<String>(lines)
        if (i.score >= 0 || i.audit.isNotEmpty()) {
            out += "Denetim (güven puanı ${i.score.coerceIn(0, 100).takeIf { i.score >= 0 } ?: "?"}/100):"
            if (i.audit.isEmpty()) out += "  sorun görülmedi" else i.audit.take(30).forEach { out += "  " + clean(it, 260) }
        }
        if (i.compat.isNotEmpty()) { out += "Uyumluluk:"; i.compat.take(12).forEach { out += "  " + clean(it, 200) } }
        if (i.settings.isNotEmpty()) out += "Ayarlar: " + i.settings.take(40).joinToString(" ") { clean(it, 40) }
        val ev = i.events.takeLast(EVENTS).map { clean(it, 260) }.filter { it.isNotBlank() }
        if (ev.isNotEmpty()) {
            val g = groupEvents(ev)
            val sum = g.entries.joinToString(" · ") { "${it.key} ${it.value.size}" }
            val warn = ev.count { LEVEL.find(it)?.groupValues?.get(2) == "!" }
            val err = ev.count { LEVEL.find(it)?.groupValues?.get(2) == "!!" }
            out += "Olay özeti: ${ev.size} satır, $warn uyarı, $err hata"
            out += "Kategoriler: $sum"
            val snaps = ev.filter { it.contains("[ÖZET]") }.takeLast(3)
            if (snaps.isNotEmpty()) { out += "Son sayaçlar:"; snaps.forEach { out += "  " + it } }
            out += "Son olaylar:"
            for ((cat, l) in g) { out += "— $cat (${l.size})"; l.forEach { out += "  $it" } }
        }
        return out.joinToString("\n").take(MAX)
    }

    private val LEVEL = Regex("^(\\S+) (!{0,2}) ?\\[([^\\]]+)\\] ")

    /** Olay satırlarını kategoriye göre gruplar (kategori sırası [Journal.CATEGORIES]; bilinmeyenler GENEL). Satırlardaki zaman damgası korunur. */
    fun groupEvents(ev: List<String>): LinkedHashMap<String, List<String>> {
        val buckets = HashMap<String, MutableList<String>>()
        for (e in ev) {
            val c = LEVEL.find(e)?.groupValues?.get(3)?.takeIf { it in Journal.CATEGORIES } ?: "GENEL"
            buckets.getOrPut(c) { ArrayList() }.add(e)
        }
        val r = LinkedHashMap<String, List<String>>()
        for (c in Journal.CATEGORIES) buckets[c]?.let { r[c] = it }
        return r
    }

    /** Test ve güvence için: metinde alan adı, IP ya da '@' var mı. */
    fun containsSensitive(text: String): Boolean =
        DOMAIN.containsMatchIn(text) || IPV4.containsMatchIn(text) || IPV6.containsMatchIn(text) || text.contains('@')
}
