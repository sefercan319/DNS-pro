package app.dnshizli.core

/**
 * Ağ geçidi için paket yardımcıları (IPv4 + IPv6, TCP + UDP). Android'e bağlı değildir.
 * Adresler 4 ya da 16 baytlık dizilerdir.
 */
internal object Gw {
    const val TCP = 6
    const val UDP = 17

    /**
     * IPv6 uzantı başlıklarını (hop-by-hop 0, yönlendirme 43, hedef seçenekleri 60) atlar ve taşıma başlığını bulur.
     * Dönüş: (taşıma protokolü shl 16) | taşıma başlığının konumu; parçalama başlığı (44), bilinmeyen uzantı, sınır dışı
     * uzunluk ya da çok uzun zincir için -1. Önceden uzantılı paketler sessizce düşüyordu; artık geçer.
     */
    fun ipv6Transport(p: ByteArray, len: Int): Int {
        if (len < 40) return -1
        var next = p[6].toInt() and 0xFF
        var off = 40
        var hops = 0
        while (next == 0 || next == 43 || next == 60) {
            if (++hops > 8 || off + 2 > len) return -1
            val ext = ((p[off + 1].toInt() and 0xFF) + 1) * 8
            if (off + ext > len) return -1
            next = p[off].toInt() and 0xFF
            off += ext
        }
        if (next == 44 || next == 51) return -1            // parçalama ve kimlik doğrulama başlığı desteklenmez
        if (off > 0xFFFF) return -1
        return (next shl 16) or off
    }

    /**
     * Tünelden gelen paket, genel bir sunucuya (herhangi bir adrese) giden düz DNS sorgusu mu (UDP/53, tek parça, QR=0)?
     * Ağ geçidi açıkken sabit bir DNS sunucusuna (ör. 8.8.8.8) doğrudan soran uygulamaların sorgusu seçilen DNS'e ve süzgece
     * yönlendirilir; cevap, sorgunun gittiği adresten geliyormuş gibi yazılır. Yerel/özel/bağlantı-yerel/çok noktaya hedefler
     * (yönlendirici, şirket DNS'i) yönlendirilmez: yerel adlar yalnızca orada çözülür.
     */
    fun isPublicPlainDns(b: ByteArray, len: Int): Boolean {
        if (len < 20) return false
        val v6: Boolean
        val ihl: Int
        val dnsOff: Int
        val dl: Int
        when ((b[0].toInt() ushr 4) and 0xF) {
            4 -> { ihl = Packets.queryHeaderLen(b, len); v6 = false; if (ihl < 0) return false; dnsOff = ihl + Packets.UDP_HDR; dl = Packets.dnsLength(b, ihl) }
            6 -> { ihl = Packets.queryHeaderLen6(b, len); v6 = true; if (ihl < 0) return false; dnsOff = ihl + Packets.UDP_HDR; dl = Packets.dnsLength6(b) }
            else -> return false
        }
        if (dl < Packets.DNS_HDR || dl > 4096 || dnsOff + dl > len) return false
        if ((b[dnsOff + 2].toInt() and 0x80) != 0) return false                       // sorgu değil
        val dst = if (v6) b.copyOfRange(24, 40) else b.copyOfRange(16, 20)
        return !isLocalDestination(v6, dst)
    }

    /** Yerel ağa, döngüye, bağlantı-yerel/özel/operatör NAT'ı aralığına ya da çok noktaya giden hedef mi? */
    fun isLocalDestination(v6: Boolean, a: ByteArray): Boolean {
        if (isMulticastOrBroadcast(v6, a)) return true
        if (!v6) {
            val x = a[0].toInt() and 0xFF
            val y = a[1].toInt() and 0xFF
            return x == 0 || x == 10 || x == 127 || (x == 169 && y == 254) || (x == 172 && y in 16..31) || (x == 192 && y == 168) || (x == 100 && y in 64..127)
        }
        var zero = true
        for (i in 0 until 15) if (a[i].toInt() != 0) { zero = false; break }
        if (zero && (a[15].toInt() == 0 || a[15].toInt() == 1)) return true            // :: ve ::1
        val h = a[0].toInt() and 0xFF
        val g = a[1].toInt() and 0xFF
        return (h and 0xFE) == 0xFC || (h == 0xFE && (g and 0xC0) == 0x80)             // fc00::/7, fe80::/10
    }

    const val FIN = 0x01
    const val SYN = 0x02
    const val RST = 0x04
    const val PSH = 0x08
    const val ACK = 0x10

    /** Tünel MTU'su (servisle aynı) ve bundan çıkan en büyük TCP veri boyutu. */
    const val MTU = 1500
    const val MSS4 = MTU - 40
    const val MSS6 = MTU - 60

    fun sum(init: Long, b: ByteArray, off: Int, len: Int): Long {
        var s = init
        var i = off
        val end = off + len
        while (i + 1 < end) { s += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF); i += 2 }
        if (i < end) s += (b[i].toInt() and 0xFF) shl 8
        return s
    }

    fun fold(sum: Long): Int {
        var s = sum
        while (s ushr 16 != 0L) s = (s and 0xFFFF) + (s ushr 16)
        return s.toInt().inv() and 0xFFFF
    }

    private fun pseudo(src: ByteArray, dst: ByteArray, proto: Int, len: Int): Long {
        var s = sum(0, src, 0, src.size)
        s = sum(s, dst, 0, dst.size)
        return s + proto + len
    }

    private fun writeIp(out: ByteArray, v6: Boolean, src: ByteArray, dst: ByteArray, proto: Int, payload: Int): Int {
        if (!v6) {
            out[0] = 0x45; out[1] = 0
            Packets.put16(out, 2, 20 + payload)
            Packets.put16(out, 4, Packets.nextIdent())
            Packets.put16(out, 6, 0x4000)            // bölme yok (DF)
            out[8] = 64; out[9] = proto.toByte()
            out[10] = 0; out[11] = 0
            System.arraycopy(src, 0, out, 12, 4)
            System.arraycopy(dst, 0, out, 16, 4)
            Packets.put16(out, 10, checksum20(out))
            return 20
        }
        out[0] = 0x60; out[1] = 0; out[2] = 0; out[3] = 0
        Packets.put16(out, 4, payload)
        out[6] = proto.toByte(); out[7] = 64
        System.arraycopy(src, 0, out, 8, 16)
        System.arraycopy(dst, 0, out, 24, 16)
        return 40
    }

    private fun checksum20(b: ByteArray): Int = fold(sum(0, b, 0, 20))

    /** TCP segmenti yazar; toplam IP paket uzunluğunu döndürür. [mss] > 0 ise MSS seçeneği eklenir. */
    fun tcp(
        out: ByteArray, v6: Boolean, src: ByteArray, dst: ByteArray, sport: Int, dport: Int,
        seq: Int, ack: Int, flags: Int, win: Int, data: ByteArray?, dOff: Int, dLen: Int, mss: Int = 0,
    ): Int {
        val opt = if (mss > 0) 4 else 0
        val tcpLen = 20 + opt + dLen
        val ip = writeIp(out, v6, src, dst, TCP, tcpLen)
        val t = ip
        Packets.put16(out, t, sport); Packets.put16(out, t + 2, dport)
        Packets.put32(out, t + 4, seq); Packets.put32(out, t + 8, ack)
        out[t + 12] = (((20 + opt) / 4) shl 4).toByte()
        out[t + 13] = flags.toByte()
        Packets.put16(out, t + 14, win.coerceIn(0, 65535))
        out[t + 16] = 0; out[t + 17] = 0; out[t + 18] = 0; out[t + 19] = 0
        if (opt != 0) { out[t + 20] = 2; out[t + 21] = 4; Packets.put16(out, t + 22, mss) }
        if (dLen > 0 && data != null) System.arraycopy(data, dOff, out, t + 20 + opt, dLen)
        var s = pseudo(src, dst, TCP, tcpLen)
        s = sum(s, out, t, tcpLen)
        Packets.put16(out, t + 16, fold(s))
        return ip + tcpLen
    }

    fun udp(out: ByteArray, v6: Boolean, src: ByteArray, dst: ByteArray, sport: Int, dport: Int, data: ByteArray, dOff: Int, dLen: Int): Int {
        val udpLen = 8 + dLen
        val ip = writeIp(out, v6, src, dst, UDP, udpLen)
        Packets.put16(out, ip, sport); Packets.put16(out, ip + 2, dport)
        Packets.put16(out, ip + 4, udpLen); out[ip + 6] = 0; out[ip + 7] = 0
        System.arraycopy(data, dOff, out, ip + 8, dLen)
        var c = fold(pseudo(src, dst, UDP, udpLen).let { sum(it, out, ip, udpLen) })
        if (c == 0) c = 0xFFFF
        Packets.put16(out, ip + 6, c)
        return ip + udpLen
    }

    /** Alınan TCP/UDP paketinin sağlama toplamı doğru mu? (IPv4 başlığı da denetlenir.) */
    fun checksumOk(p: ByteArray, len: Int): Boolean {
        val v6 = (p[0].toInt() ushr 4) == 6
        val ip = if (v6) 40 else (p[0].toInt() and 0xF) * 4
        if (!v6 && fold(sum(0, p, 0, ip)) != 0) return false
        val proto = if (v6) p[6].toInt() and 0xFF else p[9].toInt() and 0xFF
        val l = if (v6) 40 + Packets.u16(p, 4) else Packets.u16(p, 2)
        if (l > len) return false
        val src = if (v6) p.copyOfRange(8, 24) else p.copyOfRange(12, 16)
        val dst = if (v6) p.copyOfRange(24, 40) else p.copyOfRange(16, 20)
        if (proto == UDP && Packets.u16(p, ip + 6) == 0 && !v6) return true
        return fold(sum(pseudo(src, dst, proto, l - ip), p, ip, l - ip)) == 0
    }

    fun seqLt(a: Int, b: Int) = (a - b) < 0
    fun seqLe(a: Int, b: Int) = (a - b) <= 0
}

/**
 * Birçok [ByteQueue]'nun paylaştığı toplam bellek tavanı. Tek tek kuyruk sınırları (ör. 96 + 128 KiB) bağlantı sayısıyla
 * çarpılınca yüzlerce MB eder: okumayan bir uygulama ya da hızlı veri basan bir sunucu servisi bellek yetersizliğinden
 * öldürebilirdi. Tavan dolunca kuyruklar daha az kabul eder; TCP'nin kendi geri basıncı (pencere 0, okuma durur) devreye girer.
 * Tek iş parçacığından (gw-io) kullanılır, kilit yoktur.
 */
internal class MemBudget(val limit: Int) {
    var used = 0
        internal set
    val left: Int get() = maxOf(0, limit - used)
}

/** Baştan tüketilen, sondan eklenen büyüyebilir bayt kuyruğu (sıfır kopya olmadan basit; tünel verisi için yeterli). */
internal class ByteQueue(private val cap: Int, private val budget: MemBudget? = null) {
    private var buf = ByteArray(0)
    private var head = 0
    var size = 0
        private set

    /** Bu kuyruğa şu an eklenebilecek bayt: kendi sınırı ve (varsa) ortak bellek tavanından kalan, hangisi küçükse. */
    val free: Int get() = if (budget == null) cap - size else minOf(cap - size, budget.left)
    val isEmpty: Boolean get() = size == 0

    /** En çok [free] bayt ekler; eklenen sayıyı döndürür. */
    fun add(src: ByteArray, off: Int, len: Int): Int {
        val n = minOf(len, free)
        if (n <= 0) return 0
        if (head + size + n > buf.size) {
            if (head > 0 && size + n <= buf.size) {
                System.arraycopy(buf, head, buf, 0, size); head = 0
            } else {
                val nb = ByteArray(minOf(cap, maxOf(2048, (size + n) * 2)))
                System.arraycopy(buf, head, nb, 0, size)
                buf = nb; head = 0
            }
        }
        System.arraycopy(src, off, buf, head + size, n)
        size += n
        budget?.let { it.used += n }
        return n
    }

    /** Baştan [from] ofsetinden en çok [len] baytı [dst]'ye kopyalar. */
    fun copy(from: Int, dst: ByteArray, dOff: Int, len: Int): Int {
        val n = minOf(len, size - from)
        if (n <= 0) return 0
        System.arraycopy(buf, head + from, dst, dOff, n)
        return n
    }

    fun drop(n: Int) {
        val k = minOf(n, size)
        if (k <= 0) return
        head += k; size -= k
        budget?.let { it.used -= k }
        if (size == 0) head = 0
    }

    fun array(): ByteArray = buf
    fun start(): Int = head
    /** Boşaltır ve belleği geri verir (bağlantı kapanınca dizi de bırakılır; boş bağlantılar bellek tutmasın). */
    fun clear() {
        budget?.let { it.used -= size }
        head = 0; size = 0
        buf = ByteArray(0)
    }
}
