// tls-referans: Go crypto/tls'in QUIC arabirimiyle (kayıt katmanı yok, yalnız el sıkışma iletileri) TLS 1.3 sunucusu.
// Uygulamanın QuicTls istemcisini X25519MLKEM768 ve x25519 ile sınamak için (sizma43). Satır tabanlı:
//
//	çıktı ilk satır : CERT <base64 DER>
//	girdi           : <seviye> <hex>        (0 Initial, 2 Handshake)
//	çıktı           : W <seviye> <hex> | S <seviye> <hex sır> (sunucu yazma sırrı) | DONE | ERR <ileti>, her girdiden sonra END
//
// Bağımsız değişken: hybrid (yalnız X25519MLKEM768), x25519 (yalnız x25519), both (Go varsayılanı: karmayı tercih eder).
package main

import (
	"bufio"
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"math/big"
	"os"
	"strconv"
	"strings"
	"time"
)

func main() {
	key, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	tmpl := &x509.Certificate{SerialNumber: big.NewInt(7), Subject: pkix.Name{CommonName: "localhost"}, DNSNames: []string{"localhost"},
		NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(24 * time.Hour), KeyUsage: x509.KeyUsageDigitalSignature,
		ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}}
	der, _ := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	cfg := &tls.Config{Certificates: []tls.Certificate{{Certificate: [][]byte{der}, PrivateKey: key}}, MinVersion: tls.VersionTLS13, NextProtos: []string{"doq"}}
	switch os.Args[1] {
	case "hybrid":
		cfg.CurvePreferences = []tls.CurveID{tls.X25519MLKEM768}
	case "x25519":
		cfg.CurvePreferences = []tls.CurveID{tls.X25519}
	}
	q := tls.QUICServer(&tls.QUICConfig{TLSConfig: cfg})
	q.SetTransportParameters([]byte{0x01, 0x02, 0x40, 0x64})
	out := bufio.NewWriter(os.Stdout)
	fmt.Fprintf(out, "CERT %s\n", base64.StdEncoding.EncodeToString(der))
	out.Flush()
	if err := q.Start(context.Background()); err != nil {
		fmt.Fprintf(out, "ERR %v\n", err)
		out.Flush()
		return
	}
	drain := func() {
		for {
			e := q.NextEvent()
			switch e.Kind {
			case tls.QUICNoEvent:
				return
			case tls.QUICWriteData:
				fmt.Fprintf(out, "W %d %s\n", e.Level, hex.EncodeToString(e.Data))
			case tls.QUICSetWriteSecret:
				fmt.Fprintf(out, "S %d %s\n", e.Level, hex.EncodeToString(e.Data))
			case tls.QUICHandshakeDone:
				fmt.Fprintln(out, "DONE")
			}
		}
	}
	drain()
	in := bufio.NewScanner(os.Stdin)
	in.Buffer(make([]byte, 1<<20), 1<<20)
	for in.Scan() {
		f := strings.Fields(in.Text())
		if len(f) != 2 {
			continue
		}
		lv, _ := strconv.Atoi(f[0])
		b, _ := hex.DecodeString(f[1])
		if err := q.HandleData(tls.QUICEncryptionLevel(lv), b); err != nil {
			fmt.Fprintf(out, "ERR %v\n", err)
		}
		drain()
		fmt.Fprintln(out, "END")
		out.Flush()
	}
}
