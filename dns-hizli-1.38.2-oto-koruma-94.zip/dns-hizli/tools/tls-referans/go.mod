module dnshizli/tls-referans

go 1.24
