#!/usr/bin/env python3
"""Sunucu küresinin vektör haritası: Natural Earth 1:10m ülke çokgenleri (world-atlas@2.0.2 countries-10m.json, npm; kamu malı).
Çıktı app/.../core/GlobeVec.kt (üretilmiş dosya, elle düzenlenmez).

  - Yaylar (arcs): ülkelerin paylaştığı kenarlar. Her köşe için önem düzeyi (0..7): Douglas–Peucker sapması (küre üzerinde, radyan),
    üst düğümden büyük olamaz. Çizerken ekranın gerektirdiği düzeyden düşük köşeler atlanır (yakınlaştıkça tüm ayrıntı gelir).
    [L0] (≈0,006°) altı sapmalar hiç saklanmaz. Koordinatlar 0,002° birimli, farklar zigzag varint.
  - Yay türü: iki ülkenin ortak sınırı, kıyı (tek ülke) ya da dikiş (180. boylam / kutup kesimi; çizilmez).
  - Kaba kara maskesi (0,25°, bir hücre genişletilmiş; global-land-mask): yarım ton noktalarının denizde olanlarını erken eler.
  - Ülkeler: boyama grubu (komşular farklı: 4 renk, çokgen komşuluğundan açgözlü) ve halkalar (yay sırası; eksi = ters yön).
Hepsi zlib ile sıkıştırılmış, base64.

Kullanım: python3 tools/kure/kara.py countries-10m.json > app/src/main/java/app/dnshizli/core/GlobeVec.kt
"""
import base64, json, math, sys, zlib
import numpy as np

topo = json.load(open(sys.argv[1]))
sx, sy = topo["transform"]["scale"]; tx, ty = topo["transform"]["translate"]
Q = 0.002
LEVELS = [0.0001, 0.0005, 0.0012, 0.003, 0.0075, 0.019, 0.047]   # radyan; düzey k: sapma ≥ LEVELS[k]

arcs = []
for a in topo["arcs"]:
    x = y = 0; pts = []
    for dx, dy in a:
        x += dx; y += dy
        pts.append((x * sx + tx, y * sy + ty))
    arcs.append(pts)

def vec(p):
    lo, la = math.radians(p[0]), math.radians(p[1])
    return np.array([math.cos(la) * math.cos(lo), math.cos(la) * math.sin(lo), math.sin(la)])

def importance(pts):
    """Her köşenin DP sapması (radyan, kiriş-düzlem uzaklığı), üst bölmeden büyük değil; uçlar sonsuz."""
    n = len(pts)
    tol = [0.0] * n
    tol[0] = tol[-1] = float("inf")
    if n < 3: return tol
    V = np.array([vec(p) for p in pts])
    stack = [(0, n - 1, float("inf"))]
    while stack:
        s, e, cap = stack.pop()
        if e - s < 2: continue
        a, b = V[s], V[e]
        nrm = np.cross(a, b); L = np.linalg.norm(nrm)
        seg = V[s + 1:e]
        if L < 1e-12:
            d = np.linalg.norm(seg - a, axis=1)
        else:
            d = np.abs(seg @ (nrm / L))
        k = int(np.argmax(d)); m = s + 1 + k
        t = min(cap, float(d[k]))
        tol[m] = t
        stack.append((s, m, t)); stack.append((m, e, t))
    return tol

def level(t):
    if t == float("inf"): return 7
    k = -1
    for i, th in enumerate(LEVELS):
        if t >= th: k = i
    return k

geoms = topo["objects"]["countries"]["geometries"]
arc_users = {}
countries = []
for ci, g in enumerate(geoms):
    t = g.get("type")
    if t == "Polygon": polys = [g["arcs"]]
    elif t == "MultiPolygon": polys = g["arcs"]
    else: polys = []
    rings = [r for poly in polys for r in poly]
    for r in rings:
        for k in r:
            arc_users.setdefault(k if k >= 0 else ~k, set()).add(ci)
    countries.append(rings)

adj = {}
for k, users in arc_users.items():
    for a in users:
        for b in users:
            if a != b: adj.setdefault(a, set()).add(b)
color = {}
for c in sorted(range(len(geoms)), key=lambda c: (-len(adj.get(c, ())), c)):
    used = [0] * 4
    for d in adj.get(c, ()):
        if d in color: used[color[d]] += 1
    free = [k for k in range(4) if used[k] == 0]
    color[c] = free[0] if free else min(range(4), key=lambda k: used[k])
conflicts = sum(1 for c, ds in adj.items() for d in ds if color[c] == color[d]) // 2

out = bytearray(); lv = bytearray(); kinds = bytearray()
def varint(buf, v):
    while True:
        b = v & 0x7F; v >>= 7
        if v: buf.append(b | 0x80)
        else: buf.append(b); return
def zz(v): return (v << 1) ^ (v >> 63)

kept = 0
for k, pts in enumerate(arcs):
    tol = importance(pts)
    sel = []
    for p, t in zip(pts, tol):
        L = level(t)
        if L < 0: continue
        q = (round((p[0] + 180) / Q), round((p[1] + 90) / Q))
        if sel and sel[-1][0] == q:
            sel[-1] = (q, max(sel[-1][1], L)); continue
        sel.append((q, L))
    if len(sel) < 2: sel = [((round((pts[0][0] + 180) / Q), round((pts[0][1] + 90) / Q)), 7), ((round((pts[-1][0] + 180) / Q), round((pts[-1][1] + 90) / Q)), 7)]
    kept += len(sel)
    varint(out, len(sel)); px = py = 0
    for (x, y), L in sel:
        varint(out, zz(x - px)); varint(out, zz(y - py)); px, py = x, y
        lv.append(L)
    # Dikiş: 180. boylam ya da Güney Kutbu boyunca yapay kesim (Rusya, Fiji, Antarktika); çizilmez.
    seam = all(abs(p[0]) >= 180.0 - 1e-9 or p[1] <= -89.99 for p in pts)
    kinds.append(2 if seam else (1 if len(arc_users.get(k, ())) >= 2 else 0))

cs = bytearray()
varint(cs, len(countries))
for ci, rings in enumerate(countries):
    varint(cs, color.get(ci, 0)); varint(cs, len(rings))
    for r in rings:
        varint(cs, len(r))
        for a in r: varint(cs, zz(a))

from global_land_mask import globe
MW, MH = 1440, 720
la = 90 - (np.arange(MH) + 0.5) * 0.25; lo = -180 + (np.arange(MW) + 0.5) * 0.25
LA, LO = np.meshgrid(la, lo, indexing="ij")
m = np.zeros((MH, MW), dtype=bool)
for dla in (-0.11, 0, 0.11):
    for dlo in (-0.11, 0, 0.11):
        m |= globe.is_land(np.clip(LA + dla, -89.99, 89.99), np.mod(LO + dlo + 180, 360) - 180)
# NE'deki küçük adalar maskede yoksa diye: köşelerin hücrelerini de işaretle
for pts in arcs:
    for x, y in pts:
        m[min(MH - 1, int((90 - y) / 0.25)), min(MW - 1, int((x + 180) / 0.25))] = True
d = m.copy()
d[1:, :] |= m[:-1, :]; d[:-1, :] |= m[1:, :]
d2 = d.copy(); d2[:, 1:] |= d[:, :-1]; d2[:, :-1] |= d[:, 1:]; d2[:, 0] |= d[:, -1]; d2[:, -1] |= d[:, 0]
mask = np.packbits(d2.reshape(-1).astype(np.uint8), bitorder="little").tobytes()

def b64z(b): return base64.b64encode(zlib.compress(bytes(b), 9)).decode()
def chunks(s, n=8000): return [s[i:i + n] for i in range(0, len(s), n)]
def kt(name, b):
    body = ",\n".join('        "%s"' % c for c in chunks(b64z(b)))
    return "    val %s: String get() = listOf(\n%s,\n    ).joinToString(\"\")\n" % (name, body)

names = [g.get("properties", {}).get("name", "") for g in geoms]
sys.stderr.write("yay=%d kose=%d (kaynak %d) ulke=%d cakisma=%d boyut=%d+%d+%d\n" % (len(arcs), kept, sum(len(a) for a in arcs), len(countries), conflicts, len(zlib.compress(bytes(out), 9)), len(zlib.compress(bytes(lv), 9)), len(zlib.compress(bytes(cs), 9))))
print("""package app.dnshizli.core

// ÜRETİLMİŞ DOSYA: tools/kure/kara.py (elle düzenlemeyin).
// Kaynak: Natural Earth 1:10m ülke sınırları (world-atlas 2.0.2; kamu malı).
internal object GlobeVec {
    const val Q = %s
    /** Düzey eşikleri (radyan): köşenin düzeyi k ise Douglas–Peucker sapması ≥ LEVELS[k]; 7 = yay ucu. */
    val LEVELS = floatArrayOf(%s)
    const val ARC_COUNT = %d
    const val VERTEX_COUNT = %d
    /** zlib: her yay için [köşe sayısı, (dx, dy) zigzag varint × sayı]; birim [Q] derece, orijin (-180, -90). */
%s    /** zlib: köşe başına önem düzeyi (0..7), yaylar sırasıyla. */
%s    /** zlib: yay başına tür (1 = iki ülkenin ortak sınırı, 0 = kıyı, 2 = dikiş, çizilmez). */
%s    /** zlib: [ülke sayısı; her ülke: grup, halka sayısı; her halka: yay sayısı, yaylar (zigzag; eksi = ~yay, ters yön)]. */
%s    /** zlib: kaba kara maskesi, [MASK_W]×[MASK_H] bit (satır: kuzeyden güneye, sütun: -180'den doğuya), genişletilmiş. */
    const val MASK_W = 1440
    const val MASK_H = 720
%s    /** Ülke adları (Natural Earth, İngilizce), [COUNTRIES] sırasıyla. */
    val NAMES: Array<String> get() = arrayOf(%s)
}""" % (repr(Q), ", ".join("%gf" % t for t in LEVELS), len(arcs), kept, kt("ARCS", out), kt("ARC_LEVELS", lv), kt("ARC_KINDS", kinds), kt("COUNTRIES", cs), kt("MASK", mask),
       ", ".join('"%s"' % n.replace('"', '') for n in names)))
