#!/usr/bin/env python3
"""Küredeki ülkelerin ISO 3166-1 sayısal kodları (world-atlas@2.0.2 countries-10m.json'daki "id"), GlobeVec ile aynı sırada.
Kodu olmayan bölgeler (Kosova, Somaliland, Kuzey Kıbrıs, üs bölgeleri…) 0; uygulama onlar için Natural Earth adını gösterir.
Ad, cihazın kendi ülke adları tablosundan uygulama dilinde alınır (Android ICU: sayısal kod → bölge → yerel ad).

Kullanım: python3 tools/kure/kimlik.py countries-10m.json > app/src/main/java/app/dnshizli/core/GlobeIds.kt
"""
import json, sys
g = json.load(open(sys.argv[1]))["objects"]["countries"]["geometries"]
ids = [int(x["id"]) if x.get("id") not in (None, "") and str(x.get("id")).isdigit() else 0 for x in g]
rows = [", ".join(str(v) for v in ids[i:i + 20]) for i in range(0, len(ids), 20)]
print("""package app.dnshizli.core

// ÜRETİLMİŞ DOSYA: tools/kure/kimlik.py (elle düzenlemeyin).
internal object GlobeIds {
    /** Ülke sırasıyla ISO 3166-1 sayısal kod (0: kodsuz bölge). */
    val NUMERIC = intArrayOf(
        %s,
    )
}""" % ",\n        ".join(rows))
