#!/usr/bin/env bash
# Alternatif yönlendirme: imzalı liste dosyalarını deponun dağıtım dalına (listeler-dagitim) da koyar. Uygulama, GitHub Releases
# engellenirse aynı dosyaları bu daldan raw.githubusercontent.com ve jsDelivr (cdn / fastly / gcore) üzerinden indirir.
# Güven imzaya dayanır: bu dal yalnızca bir kopya yeridir; içeriği değiştirilse bile uygulama imza/özet denetiminde reddeder.
# Kullanım (depo kökünde, actions/checkout kimliğiyle): bash tools/yayin/ayna.sh DOSYA [DOSYA...]
set -euo pipefail
BR="listeler-dagitim"
[ "$#" -ge 1 ] || { echo "::error::ayna.sh: dosya verilmedi"; exit 1; }
for f in "$@"; do [ -f "$f" ] || { echo "::error::ayna.sh: dosya yok: $f"; exit 1; }; done
ROOT="$(git rev-parse --show-toplevel)"
FILES=()
for f in "$@"; do FILES+=("$(cd "$(dirname "$f")" && pwd)/$(basename "$f")"); done
git config --global user.name "liste-yayini"
git config --global user.email "liste-yayini@users.noreply.github.com"
for try in 1 2 3; do
  W="$(mktemp -d)"
  if git -C "$ROOT" fetch -q origin "+refs/heads/$BR:refs/remotes/origin/$BR" 2>/dev/null; then
    git -C "$ROOT" worktree add -q -B "$BR" "$W" "origin/$BR"
  else
    git -C "$ROOT" worktree add -q --detach "$W"
    git -C "$W" checkout -q --orphan "$BR"
    git -C "$W" rm -rq --cached . 2>/dev/null || true
    find "$W" -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf {} +
  fi
  for f in "${FILES[@]}"; do cp -f "$f" "$W/"; done
  git -C "$W" add -A
  if git -C "$W" diff --cached --quiet; then echo "Ayna: değişiklik yok"; git -C "$ROOT" worktree remove --force "$W"; exit 0; fi
  git -C "$W" commit -qm "listeler: $(date -u +%F)"
  if git -C "$W" push -q origin "$BR"; then
    git -C "$ROOT" worktree remove --force "$W"
    # jsDelivr önbelleğini tazele (en iyi çaba: başarısızlık yayını bozmaz; önbellek en geç 12 saatte kendiliğinden yenilenir)
    if [ -n "${GITHUB_REPOSITORY:-}" ]; then
      for f in "${FILES[@]}"; do curl -s -m 10 -o /dev/null "https://purge.jsdelivr.net/gh/${GITHUB_REPOSITORY}@${BR}/$(basename "$f")" || true; done
    fi
    echo "Ayna güncellendi: $BR"
    exit 0
  fi
  git -C "$ROOT" worktree remove --force "$W"
  echo "Ayna itilemedi (deneme $try), yeniden deneniyor"; sleep $((try * 5))
done
echo "::warning::Ayna dalı güncellenemedi; asıl yayın etkilenmedi"
