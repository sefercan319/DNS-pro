// mlkem-referans: Go standart kütüphanesinin crypto/mlkem'i (FIPS 203) ile karşılıklı doğrulama aracı (sizma41 çağırır).
//
//	ek <tohum-hex>            → tohumdan (d‖z, 64 bayt) kapsülleme anahtarı
//	encap <ek-hex>            → "<kapsül-hex> <anahtar-hex>" (rastgele)
//	decap <tohum-hex> <c-hex> → ortak anahtar
package main

import (
	"crypto/mlkem"
	"encoding/hex"
	"fmt"
	"os"
)

func must(b []byte, err error) []byte {
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	return b
}

func main() {
	if len(os.Args) < 3 {
		os.Exit(2)
	}
	switch os.Args[1] {
	case "ek":
		dk, err := mlkem.NewDecapsulationKey768(must(hex.DecodeString(os.Args[2])))
		if err != nil {
			os.Exit(1)
		}
		fmt.Println(hex.EncodeToString(dk.EncapsulationKey().Bytes()))
	case "encap":
		ek, err := mlkem.NewEncapsulationKey768(must(hex.DecodeString(os.Args[2])))
		if err != nil {
			fmt.Println("GECERSIZ")
			return
		}
		k, c := ek.Encapsulate()
		fmt.Println(hex.EncodeToString(c), hex.EncodeToString(k))
	case "decap":
		dk, err := mlkem.NewDecapsulationKey768(must(hex.DecodeString(os.Args[2])))
		if err != nil {
			os.Exit(1)
		}
		k, err := dk.Decapsulate(must(hex.DecodeString(os.Args[3])))
		if err != nil {
			os.Exit(1)
		}
		fmt.Println(hex.EncodeToString(k))
	}
}
