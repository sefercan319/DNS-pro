module dnshizli/mlkem-referans

go 1.24
