#!/usr/bin/env python3
"""Bağımsız WireGuard el sıkışma referansı (Python, 'cryptography' + hashlib).

Uygulamanın saf Kotlin WireGuard'ı (core/WgNoise.kt, core/WgCrypto.kt) bu betiğin ürettiği vektörlerle baytı baytına karşılaştırılır
(selftest sizma36). Kodlar ayrı yazılmıştır: Kotlin tarafı kendi BLAKE2s/ChaCha20-Poly1305 uygulamasını kullanır, burada hashlib ve
OpenSSL tabanlı 'cryptography' kullanılır. Kaynak: WireGuard whitepaper §5.4.
Kullanım: python3 wg_ref.py > ../../selftest/data/wg_vectors.json
"""
import hashlib, hmac, json, struct, sys
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives import serialization

def H(*p):
    h = hashlib.blake2s()
    for x in p: h.update(x)
    return h.digest()

def MAC(k, *p):
    h = hashlib.blake2s(key=k, digest_size=16)
    for x in p: h.update(x)
    return h.digest()

def HMAC(k, d): return hmac.new(k, d, hashlib.blake2s).digest()

def KDF(k, x, n):
    t0 = HMAC(k, x); out = []; prev = b""
    for i in range(1, n + 1):
        prev = HMAC(t0, prev + bytes([i])); out.append(prev)
    return out

def raw_pub(priv): return X25519PrivateKey.from_private_bytes(priv).public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
def DH(priv, pub): return X25519PrivateKey.from_private_bytes(priv).exchange(X25519PublicKey.from_public_bytes(pub))
def nonce(c): return b"\x00" * 4 + struct.pack("<Q", c)
def AEAD(k, c, p, a): return ChaCha20Poly1305(k).encrypt(nonce(c), p, a)

CONSTRUCTION = b"Noise_IKpsk2_25519_ChaChaPoly_BLAKE2s"
IDENTIFIER = b"WireGuard v1 zx2c4 Jason@zx2c4.com"

def tai64n(ms):
    return struct.pack(">Q", (1 << 62) + ms // 1000) + struct.pack(">I", (ms % 1000) * 1000000)

def case(seed, payloads):
    b = lambda tag: H(bytes([seed]) + tag)          # belirlenimci 32 bayt
    si, sr, psk, ei, er = b(b"si"), b(b"sr"), b(b"psk") if seed % 2 else bytes(32), b(b"ei"), b(b"er")
    Si, Sr = raw_pub(si), raw_pub(sr)
    epoch = 1_700_000_000_123 + seed
    idx_i, idx_r = 0x11223344 + seed, 0x55667788 + seed
    # başlatma
    C = H(CONSTRUCTION); Hh = H(C, IDENTIFIER); Hh = H(Hh, Sr)
    Ei = raw_pub(ei)
    C = KDF(C, Ei, 1)[0]; Hh = H(Hh, Ei)
    C, k = KDF(C, DH(ei, Sr), 2)
    es = AEAD(k, 0, Si, Hh); Hh = H(Hh, es)
    C, k = KDF(C, DH(si, Sr), 2)
    et = AEAD(k, 0, tai64n(epoch), Hh); Hh = H(Hh, et)
    m = bytes([1, 0, 0, 0]) + struct.pack("<I", idx_i) + Ei + es + et
    m += MAC(H(b"mac1----", Sr), m)
    m += bytes(16)
    # yanıt
    Er = raw_pub(er)
    C = KDF(C, Er, 1)[0]; Hh = H(Hh, Er)
    C = KDF(C, DH(er, Ei), 1)[0]
    C = KDF(C, DH(er, Si), 1)[0]
    C, tau, k = KDF(C, psk, 3)
    Hh = H(Hh, tau)
    en = AEAD(k, 0, b"", Hh)
    r = bytes([2, 0, 0, 0]) + struct.pack("<I", idx_r) + struct.pack("<I", idx_i) + Er + en
    r += MAC(H(b"mac1----", Si), r)
    r += bytes(16)
    t_i_send, t_i_recv = KDF(C, b"", 2)
    def data(key, recv_idx, ctr, p):
        pad = (len(p) + 15) & ~15 if p else 0
        return bytes([4, 0, 0, 0]) + struct.pack("<I", recv_idx) + struct.pack("<Q", ctr) + AEAD(key, ctr, p + bytes(pad - len(p)), b"")
    di = [data(t_i_send, idx_r, n, p).hex() for n, p in enumerate(payloads)]
    dr = [data(t_i_recv, idx_i, n, p).hex() for n, p in enumerate(payloads)]
    return dict(si=si.hex(), sr=sr.hex(), psk=psk.hex(), ei=ei.hex(), er=er.hex(), epoch=epoch, idx_i=idx_i, idx_r=idx_r,
                initiation=m.hex(), response=r.hex(), t_send=t_i_send.hex(), t_recv=t_i_recv.hex(),
                payloads=[p.hex() for p in payloads], data_i=di, data_r=dr)

def prim():
    k = bytes(range(32)); n = bytes(range(12)); a = b"wg-aad"
    msgs = [b"", b"a", bytes(range(16)), bytes(range(17)), bytes(range(255)) * 3]
    return dict(
        blake2s_abc=H(b"abc").hex(),
        blake2s_empty=H(b"").hex(),
        blake2s_keyed=MAC(bytes(range(32)), bytes(range(64))).hex(),
        blake2s_keyed32=hashlib.blake2s(bytes(range(200)), key=bytes(range(32))).hexdigest(),
        hmac=HMAC(b"anahtar", b"veri").hex(),
        kdf3=[x.hex() for x in KDF(bytes(32), b"girdi", 3)],
        chacha=[dict(pt=m.hex(), ct=ChaCha20Poly1305(k).encrypt(n, m, a).hex()) for m in msgs],
    )

payloads = [b"", bytes(range(20)), bytes([0x45]) + bytes(range(1, 84)), bytes(1300)]
json.dump(dict(primitives=prim(), cases=[case(s, payloads) for s in range(4)]), sys.stdout, indent=1)
