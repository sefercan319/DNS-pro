package main

import (
	"bytes"
	"crypto/hmac"
	"crypto/mlkem"
	"crypto/rand"
	"encoding/base64"
	"encoding/binary"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

type pqRig struct {
	q    *pqState
	pub  []byte
	base []byte
	log  string
}

func newPQRig(t *testing.T, failWg bool) *pqRig {
	dir := t.TempDir()
	pub := make([]byte, 32)
	base := make([]byte, 32)
	_, _ = rand.Read(pub)
	_, _ = rand.Read(base)
	cd := filepath.Join(dir, "istemci-2")
	_ = os.MkdirAll(cd, 0o700)
	_ = os.WriteFile(filepath.Join(cd, "pub"), []byte(base64.StdEncoding.EncodeToString(pub)+"\n"), 0o600)
	_ = os.WriteFile(filepath.Join(cd, "psk"), []byte(base64.StdEncoding.EncodeToString(base)+"\n"), 0o600)
	log := filepath.Join(dir, "wg.log")
	script := filepath.Join(dir, "wg")
	body := "#!/bin/sh\necho \"$@\" >> " + log + "\ncat >> " + log + "\n"
	if failWg {
		body += "exit 1\n"
	}
	_ = os.WriteFile(script, []byte(body), 0o755)
	return &pqRig{q: &pqState{dir: dir, wgCmd: script, wgIf: "dhs0", seen: map[string]time.Time{}, now: time.Now}, pub: pub, base: base, log: log}
}

func (r *pqRig) request(ek []byte, ts time.Time, key []byte) []byte {
	p := append([]byte{}, pqMagicReq...)
	p = binary.BigEndian.AppendUint64(p, uint64(ts.Unix()))
	p = append(p, r.pub...)
	p = append(p, ek...)
	return append(p, mac(key, "dhs-pq1-istek", p)...)
}

func TestPQExchange(t *testing.T) {
	r := newPQRig(t, false)
	dk, _ := mlkem.GenerateKey768()
	req := r.request(dk.EncapsulationKey().Bytes(), time.Now(), r.base)
	resp := r.q.handle(req)
	if len(resp) != 4+1088+32 || !bytes.Equal(resp[:4], pqMagicResp) {
		t.Fatalf("cevap: %x", resp[:min(8, len(resp))])
	}
	reqMac := req[len(req)-32:]
	if !hmac.Equal(resp[len(resp)-32:], mac(r.base, "dhs-pq1-cevap", resp[:len(resp)-32], reqMac)) {
		t.Fatal("cevap mac")
	}
	ss, err := dk.Decapsulate(resp[4 : 4+1088])
	if err != nil {
		t.Fatal(err)
	}
	psk := mac(r.base, "dhs-pq1-psk", ss, r.pub, reqMac)
	b, _ := os.ReadFile(r.log)
	want := "set dhs0 peer " + base64.StdEncoding.EncodeToString(r.pub) + " preshared-key /dev/stdin\n" + base64.StdEncoding.EncodeToString(psk) + "\n"
	if string(b) != want {
		t.Fatalf("wg çağrısı:\n%q\n%q", b, want)
	}
	if code := r.q.handle(req); !bytes.Equal(code, errResp(2)) {
		t.Fatal("tekrar kabul edildi")
	}
}

func TestPQRejects(t *testing.T) {
	r := newPQRig(t, false)
	dk, _ := mlkem.GenerateKey768()
	ek := dk.EncapsulationKey().Bytes()
	wrong := make([]byte, 32)
	cases := map[string]struct {
		p    []byte
		code byte
	}{
		"yanlış psk ile mac": {r.request(ek, time.Now(), wrong), 1},
		"eski zaman":         {r.request(ek, time.Now().Add(-3*time.Minute), r.base), 2},
		"gelecek zaman":      {r.request(ek, time.Now().Add(3*time.Minute), r.base), 2},
		"kısa":               {r.request(ek, time.Now(), r.base)[:100], 4},
	}
	unknown := r.request(ek, time.Now(), r.base)
	unknown[12] ^= 1 // bilinmeyen eş (mac da bozulur)
	cases["bilinmeyen eş"] = struct {
		p    []byte
		code byte
	}{unknown, 1}
	bad := append([]byte{}, ek...)
	for i := 0; i < 2; i++ { // ilk katsayı 4095 (≥ q): geçersiz anahtar, mac doğru
		bad[i] = 0xFF
	}
	bad[1] = 0x0F | bad[1]
	cases["geçersiz ek"] = struct {
		p    []byte
		code byte
	}{r.request(bad, time.Now(), r.base), 4}
	for name, c := range cases {
		if got := r.q.handle(c.p); !bytes.Equal(got, errResp(c.code)) {
			t.Fatalf("%s: %x", name, got)
		}
	}
	if b, _ := os.ReadFile(r.log); len(b) != 0 {
		t.Fatalf("reddedilen istekte wg çağrıldı: %s", b)
	}
	f := newPQRig(t, true)
	if got := f.q.handle(f.request(ek, time.Now(), f.base)); !bytes.Equal(got, errResp(3)) {
		t.Fatalf("wg hatası bildirilmedi: %x", got)
	}
}

func (r *pqRig) request2(ekEph, ctS []byte, ts time.Time) []byte {
	p := append([]byte{}, pqMagicReq2...)
	p = binary.BigEndian.AppendUint64(p, uint64(ts.Unix()))
	p = append(p, r.pub...)
	p = append(p, ekEph...)
	p = append(p, ctS...)
	return append(p, mac(r.base, "dhs-pq2-istek", p)...)
}

func TestPQ2StaticIdentity(t *testing.T) {
	r := newPQRig(t, false)
	if got := r.q.handleKey2(); !bytes.Equal(got, errResp(5)) {
		t.Fatal("kalıcı anahtar yokken KEY2 hata vermeli")
	}
	if _, err := genStatic(r.q.dir); err != nil {
		t.Fatal(err)
	}
	r.q.static = loadStatic(r.q.dir)
	kr := r.q.handleKey2()
	if !bytes.Equal(kr[:5], keyMagicResp) || len(kr) != 5+mlkem.EncapsulationKeySize768 {
		t.Fatal("KEY2 cevabı")
	}
	ekS, _ := mlkem.NewEncapsulationKey768(kr[5:])
	ssS, ctS := ekS.Encapsulate()
	dk, _ := mlkem.GenerateKey768()
	req := r.request2(dk.EncapsulationKey().Bytes(), ctS, time.Now())
	resp := r.q.handle2(req)
	if len(resp) != 4+1088+32 || !bytes.Equal(resp[:4], pqMagicResp2) {
		t.Fatalf("PQ2 cevabı: %x", resp[:5])
	}
	reqMac := req[len(req)-32:]
	auth := mac(r.base, "dhs-pq2-kimlik", ssS)
	if !hmac.Equal(resp[len(resp)-32:], mac(auth, "dhs-pq2-cevap", resp[:len(resp)-32], reqMac)) {
		t.Fatal("cevap kimlik mac'i")
	}
	ssE, _ := dk.Decapsulate(resp[4 : 4+1088])
	psk := mac(r.base, "dhs-pq2-psk", ssE, ssS, r.pub, reqMac)
	b, _ := os.ReadFile(r.log)
	if !strings.Contains(string(b), base64.StdEncoding.EncodeToString(psk)) {
		t.Fatal("wg'ye ayarlanan PSK uyuşmuyor")
	}
	// başka bir kalıcı anahtara sahip sahte aktarıcı doğru kimlik mac'i üretemez
	fake := newPQRig(t, false)
	fake.pub, fake.base = r.pub, r.base
	_ = os.WriteFile(filepath.Join(fake.q.dir, "istemci-2", "pub"), []byte(base64.StdEncoding.EncodeToString(r.pub)+"\n"), 0o600)
	_ = os.WriteFile(filepath.Join(fake.q.dir, "istemci-2", "psk"), []byte(base64.StdEncoding.EncodeToString(r.base)+"\n"), 0o600)
	_, _ = genStatic(fake.q.dir)
	fake.q.static = loadStatic(fake.q.dir)
	dk2, _ := mlkem.GenerateKey768()
	ssS2, ctS2 := ekS.Encapsulate() // istemci gerçek aktarıcının (sabitlenen) anahtarına kapsüller
	req2 := fake.request2(dk2.EncapsulationKey().Bytes(), ctS2, time.Now())
	fr := fake.q.handle2(req2)
	if len(fr) == 4+1088+32 && hmac.Equal(fr[len(fr)-32:], mac(mac(r.base, "dhs-pq2-kimlik", ssS2), "dhs-pq2-cevap", fr[:len(fr)-32], req2[len(req2)-32:])) {
		t.Fatal("sahte aktarıcının cevabı doğrulandı")
	}
	if !bytes.Equal(r.q.handle2(req), errResp(2)) {
		t.Fatal("PQ2 tekrar kabul edildi")
	}
}

func TestPQReplayAfterRestart(t *testing.T) {
	r := newPQRig(t, false)
	state := t.TempDir()
	r.q.stateDir = state
	dk, _ := mlkem.GenerateKey768()
	ts := time.Now()
	req := r.request(dk.EncapsulationKey().Bytes(), ts, r.base)
	if resp := r.q.handle(req); !bytes.Equal(resp[:4], pqMagicResp) {
		t.Fatal("ilk istek")
	}
	// aktarıcı yeniden başladı: bellekteki "görülen" tablosu boş, ama durum dosyası var
	q2 := &pqState{dir: r.q.dir, wgCmd: r.q.wgCmd, wgIf: "dhs0", seen: map[string]time.Time{}, now: time.Now, stateDir: state}
	if got := q2.handle(req); !bytes.Equal(got, errResp(2)) {
		t.Fatalf("yeniden başlatmadan sonra eski istek kabul edildi: %x", got[:5])
	}
	// daha eski zamanlı yeni bir istek de reddedilir; daha yenisi kabul edilir
	dk2, _ := mlkem.GenerateKey768()
	if got := q2.handle(r.request(dk2.EncapsulationKey().Bytes(), ts.Add(-10*time.Second), r.base)); !bytes.Equal(got, errResp(2)) {
		t.Fatal("eski zamanlı istek kabul edildi")
	}
	if got := q2.handle(r.request(dk2.EncapsulationKey().Bytes(), ts.Add(2*time.Second), r.base)); !bytes.Equal(got[:4], pqMagicResp) {
		t.Fatal("yeni istek reddedildi")
	}
}
