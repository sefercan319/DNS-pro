// dhs-sunucu: DNS Hızlı "Stealth" aktarıcısı.
//
// WireGuard paketlerini TLS içinde, WebSocket ikili çerçeveleriyle taşır; DPI yalnızca sıradan bir HTTPS bağlantısı görür.
// Gizli yolu bilmeyen her istek (tarayıcı, tarayıcı robotu, etkin yoklama) sıradan bir nginx 404 sayfası alır.
// Yalnızca Go standart kütüphanesi kullanılır. Sunucudaki WireGuard (çekirdek, wg-quick) yerel UDP adresinde dinler;
// her istemci bağlantısı için ayrı bir yerel UDP soketi açılır (WireGuard uç nokta dolaşımı bunu doğal karşılar).
//
//	dhs-sunucu -sertifika-uret /etc/dhs        # sertifika + anahtar üretir, istemcinin sabitleyeceği özeti yazar
//	dhs-sunucu -dinle :443 -dizin /etc/dhs -wg 127.0.0.1:51820
package main

import (
	"bufio"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/subtle"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/base64"
	"encoding/pem"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"math/big"
	"net"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

const (
	wsGUID        = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
	maxHeader     = 8192
	maxPayload    = 65535
	headerTimeout = 10 * time.Second
	idleTimeout   = 200 * time.Second // WireGuard canlı tutması olmasa da 180 sn'de yeniden el sıkışır
)

var errProto = errors.New("protokol hatası")

// ---------------------------------------------------------------- çerçeveler (RFC 6455, yalnızca gereken alt küme)

const (
	opBinary = 0x2
	opClose  = 0x8
	opPing   = 0x9
	opPong   = 0xA
)

// readFrame istemci çerçevesini okur: maskeli olmalı, parçalanmamış olmalı, ayrılmış bitler sıfır olmalı.
func readFrame(r io.Reader, buf []byte) (op byte, payload []byte, err error) {
	var h [14]byte
	if _, err = io.ReadFull(r, h[:2]); err != nil {
		return
	}
	if h[0]&0x70 != 0 || h[0]&0x80 == 0 || h[1]&0x80 == 0 {
		return 0, nil, errProto // ayrılmış bit, parçalı çerçeve ya da maskesiz istemci çerçevesi
	}
	op = h[0] & 0x0F
	n := int(h[1] & 0x7F)
	switch {
	case n == 126:
		if _, err = io.ReadFull(r, h[2:4]); err != nil {
			return
		}
		n = int(h[2])<<8 | int(h[3])
		if n < 126 {
			return 0, nil, errProto // en kısa kodlama zorunlu
		}
	case n == 127:
		return 0, nil, errProto
	}
	if op >= 0x8 && n > 125 {
		return 0, nil, errProto
	}
	if n > maxPayload || n > len(buf) {
		return 0, nil, errProto
	}
	var mask [4]byte
	if _, err = io.ReadFull(r, mask[:]); err != nil {
		return
	}
	payload = buf[:n]
	if _, err = io.ReadFull(r, payload); err != nil {
		return
	}
	for i := range payload {
		payload[i] ^= mask[i&3]
	}
	if op != opBinary && op != opClose && op != opPing && op != opPong {
		return 0, nil, errProto
	}
	return op, payload, nil
}

// appendFrame sunucu çerçevesi üretir (maskesiz).
func appendFrame(dst []byte, op byte, p []byte) []byte {
	dst = append(dst, 0x80|op)
	if len(p) < 126 {
		dst = append(dst, byte(len(p)))
	} else {
		dst = append(dst, 126, byte(len(p)>>8), byte(len(p)))
	}
	return append(dst, p...)
}

// ---------------------------------------------------------------- HTTP yükseltme

// headerLimit: left ≥ 0 iken en çok left bayt okutur, sonra EOF; left < 0 sınırsız.
type headerLimit struct {
	r    io.Reader
	left int64
}

func (h *headerLimit) Read(p []byte) (int, error) {
	if h.left < 0 {
		return h.r.Read(p)
	}
	if h.left == 0 {
		return 0, io.EOF
	}
	if int64(len(p)) > h.left {
		p = p[:h.left]
	}
	n, err := h.r.Read(p)
	h.left -= int64(n)
	return n, err
}

type request struct {
	method, path, upgrade, connection, key, version string
}

func readRequest(br *bufio.Reader) (*request, error) {
	total := 0
	line := func() (string, error) {
		s, err := br.ReadString('\n')
		total += len(s)
		if total > maxHeader {
			return "", errProto
		}
		if err != nil {
			return "", err
		}
		return strings.TrimRight(s, "\r\n"), nil
	}
	first, err := line()
	if err != nil {
		return nil, err
	}
	parts := strings.Split(first, " ")
	if len(parts) != 3 || !strings.HasPrefix(parts[2], "HTTP/1.") {
		return nil, errProto
	}
	req := &request{method: parts[0], path: parts[1]}
	for {
		l, err := line()
		if err != nil {
			return nil, err
		}
		if l == "" {
			break
		}
		k, v, ok := strings.Cut(l, ":")
		if !ok {
			return nil, errProto
		}
		v = strings.TrimSpace(v)
		switch strings.ToLower(strings.TrimSpace(k)) {
		case "upgrade":
			req.upgrade = v
		case "connection":
			req.connection = v
		case "sec-websocket-key":
			req.key = v
		case "sec-websocket-version":
			req.version = v
		}
	}
	return req, nil
}

func acceptKey(key string) string {
	h := sha1.Sum([]byte(key + wsGUID))
	return base64.StdEncoding.EncodeToString(h[:])
}

func headerHas(v, token string) bool {
	for _, p := range strings.Split(v, ",") {
		if strings.EqualFold(strings.TrimSpace(p), token) {
			return true
		}
	}
	return false
}

// pathOK gizli yolu sabit zamanlı karşılaştırır (uzunluk da sızmaz: özetler karşılaştırılır).
func pathOK(got, want string) bool {
	a := sha256.Sum256([]byte(got))
	b := sha256.Sum256([]byte(want))
	return subtle.ConstantTimeCompare(a[:], b[:]) == 1
}

func validKey(k string) bool {
	b, err := base64.StdEncoding.DecodeString(k)
	return err == nil && len(b) == 16
}

const decoyBody = "<html>\r\n<head><title>404 Not Found</title></head>\r\n<body>\r\n<center><h1>404 Not Found</h1></center>\r\n<hr><center>nginx</center>\r\n</body>\r\n</html>\r\n"

func decoy(w io.Writer, status string) {
	fmt.Fprintf(w, "HTTP/1.1 %s\r\nServer: nginx\r\nDate: %s\r\nContent-Type: text/html\r\nContent-Length: %d\r\nConnection: close\r\n\r\n%s",
		status, time.Now().UTC().Format(time.RFC1123[:len(time.RFC1123)-3]+"GMT"), len(decoyBody), decoyBody)
}

// ---------------------------------------------------------------- sunucu

type server struct {
	path    string
	wg      *net.UDPAddr
	limit   int64
	active  atomic.Int64
	pending atomic.Int64
	logf    func(string, ...any)
	pq      *pqState // nil: kuantum sonrası PSK kapalı
}

func (s *server) handle(c net.Conn) {
	defer c.Close()
	// Kimliği doğrulanmamış bağlantılar ayrı (geniş) sınırla sayılır: yoklayıcılar aktarım yuvalarını dolduramaz.
	if s.pending.Add(1) > 4*s.limit {
		s.pending.Add(-1)
		return
	}
	authed := false
	defer func() {
		if !authed {
			s.pending.Add(-1)
		}
	}()
	_ = c.SetDeadline(time.Now().Add(headerTimeout))
	// Başlık evresinde okunabilecek bayt sınırlı: yeni satırsız dev bir satır belleği şişiremez (ReadString biriktirir).
	hl := &headerLimit{r: c, left: maxHeader + 1}
	br := bufio.NewReaderSize(hl, 4096)
	req, err := readRequest(br)
	if err != nil {
		if errors.Is(err, errProto) {
			decoy(c, "400 Bad Request")
		}
		return
	}
	ok := pathOK(req.path, s.path) && req.method == "GET" && strings.EqualFold(req.upgrade, "websocket") &&
		headerHas(req.connection, "upgrade") && req.version == "13" && validKey(req.key)
	if !ok {
		decoy(c, "404 Not Found")
		return
	}
	authed = true
	s.pending.Add(-1)
	hl.left = -1 // yükseltildi: aktarım evresinde sınır yok (çerçeve boyu ayrıca sınırlı)
	if s.active.Add(1) > s.limit {
		s.active.Add(-1)
		decoy(c, "503 Service Temporarily Unavailable")
		return
	}
	defer s.active.Add(-1)
	if _, err := fmt.Fprintf(c, "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: %s\r\n\r\n", acceptKey(req.key)); err != nil {
		return
	}
	udp, err := net.DialUDP("udp", nil, s.wg)
	if err != nil {
		s.logf("wireguard soketi açılamadı: %v", err)
		return
	}
	defer udp.Close()
	s.relay(c, br, udp)
}

func (s *server) relay(c net.Conn, br *bufio.Reader, udp *net.UDPConn) {
	var wmu sync.Mutex
	write := func(op byte, p []byte, out []byte) error {
		wmu.Lock()
		defer wmu.Unlock()
		_ = c.SetWriteDeadline(time.Now().Add(30 * time.Second))
		_, err := c.Write(appendFrame(out[:0], op, p))
		return err
	}
	done := make(chan struct{})
	var once sync.Once
	stop := func() { once.Do(func() { close(done); _ = c.Close(); _ = udp.Close() }) }
	defer stop()

	sh := &shaper{}
	go func() { // WireGuard → istemci
		defer stop()
		buf := make([]byte, maxPayload)
		out := make([]byte, 0, maxPayload+4)
		shaped := make([]byte, 0, maxPayload+8)
		for {
			_ = udp.SetReadDeadline(time.Now().Add(idleTimeout))
			n, err := udp.Read(buf)
			if err != nil {
				return
			}
			sh.lastReal.Store(time.Now().UnixMilli())
			sh.wgSeen.Store(true) // sunucudaki WireGuard bu istemciye cevap verdi: kimliği doğrulanmış eş
			if write(opBinary, sh.frame(buf[:n], shaped), out) != nil {
				return
			}
		}
	}()

	buf := make([]byte, maxPayload)
	ctl := make([]byte, 0, 2048)
	for { // istemci → WireGuard
		_ = c.SetReadDeadline(time.Now().Add(idleTimeout))
		op, p, err := readFrame(br, buf)
		if err != nil {
			return
		}
		switch op {
		case opBinary:
			if isShapeReq(p) { // trafik gizleme isteği: WireGuard'a gitmez
				sh.level.Store(int32(p[5]))
				if p[5] > 0 && sh.started.CompareAndSwap(false, true) {
					coverOut := make([]byte, 0, maxPayload+8)
					go sh.coverLoop(done, func(b []byte) error { return write(opBinary, b, coverOut) })
				}
				continue
			}
			if s.pq != nil && (isKey2(p) || isPQ2(p)) { // PQ2: kalıcı anahtarla sunucu kimliği
				var r []byte
				if isKey2(p) {
					r = s.pq.handleKey2()
				} else {
					r = s.pq.handle2(p)
				}
				if write(opBinary, r, ctl) != nil {
					return
				}
				continue
			}
			if s.pq != nil && isPQ(p) { // denetim iletisi: WireGuard'a gitmez
				if write(opBinary, s.pq.handle(p), ctl) != nil {
					return
				}
				continue
			}
			if len(p) > 0 {
				if _, err := udp.Write(p); err != nil {
					return
				}
			}
		case opPing:
			if write(opPong, p, ctl) != nil {
				return
			}
		case opClose:
			_ = write(opClose, nil, ctl)
			return
		}
	}
}

// ---------------------------------------------------------------- sertifika

// spkiPin istemcinin sabitlediği değer: sertifikanın ortak anahtar bilgisinin (SPKI) SHA-256 özeti, base64.
func spkiPin(cert *x509.Certificate) string {
	h := sha256.Sum256(cert.RawSubjectPublicKeyInfo)
	return base64.StdEncoding.EncodeToString(h[:])
}

func generate(dir string) (string, error) {
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return "", err
	}
	serial, _ := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 120))
	tmpl := &x509.Certificate{
		SerialNumber:          serial,
		Subject:               pkix.Name{CommonName: "localhost"},
		NotBefore:             time.Now().Add(-24 * time.Hour),
		NotAfter:              time.Now().Add(20 * 365 * 24 * time.Hour),
		KeyUsage:              x509.KeyUsageDigitalSignature,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	if err != nil {
		return "", err
	}
	kb, err := x509.MarshalPKCS8PrivateKey(key)
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", err
	}
	if err := os.WriteFile(filepath.Join(dir, "sunucu.key"), pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: kb}), 0o600); err != nil {
		return "", err
	}
	if err := os.WriteFile(filepath.Join(dir, "sunucu.crt"), pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}), 0o644); err != nil {
		return "", err
	}
	cert, _ := x509.ParseCertificate(der)
	return spkiPin(cert), nil
}

func randomPath() string {
	b := make([]byte, 24)
	_, _ = rand.Read(b)
	return "/" + base64.RawURLEncoding.EncodeToString(b)
}

func loadTLS(dir string) (*tls.Config, string, error) {
	pair, err := tls.LoadX509KeyPair(filepath.Join(dir, "sunucu.crt"), filepath.Join(dir, "sunucu.key"))
	if err != nil {
		return nil, "", err
	}
	leaf, err := x509.ParseCertificate(pair.Certificate[0])
	if err != nil {
		return nil, "", err
	}
	return &tls.Config{
		Certificates: []tls.Certificate{pair},
		MinVersion:   tls.VersionTLS12,
		NextProtos:   []string{"http/1.1"},
	}, spkiPin(leaf), nil
}

func main() {
	listen := flag.String("dinle", ":443", "TLS dinleme adresi")
	dir := flag.String("dizin", "/etc/dhs", "sertifika, anahtar ve gizli yol dizini")
	wg := flag.String("wg", "127.0.0.1:51820", "sunucudaki WireGuard UDP adresi")
	limit := flag.Int64("azami", 256, "en çok eşzamanlı bağlantı")
	gen := flag.Bool("sertifika-uret", false, "dizine yeni sertifika/anahtar ve gizli yol üret, özeti yaz, çık")
	show := flag.Bool("goster", false, "sabitleme özetini ve gizli yolu yaz, çık")
	pqOn := flag.Bool("pq", true, "kuantum sonrası PSK (ML-KEM-768) değişimine izin ver")
	wgIf := flag.String("wg-arayuz", "dhs0", "PSK'si ayarlanacak WireGuard arayüzü")
	wgCmd := flag.String("wg-komut", "wg", "wg aracı")
	stateDir := flag.String("durum", "", "kalıcı durum dizini (PQ tekrar koruması yeniden başlatmada korunur); boşsa yalnız bellekte")
	genPq := flag.Bool("pq-anahtar-uret", false, "yoksa kalıcı ML-KEM anahtarı (PQ2 sunucu kimliği) üret, PqPin yaz, çık")
	flag.Parse()

	if *gen {
		pin, err := generate(*dir)
		if err != nil {
			log.Fatalf("sertifika üretilemedi: %v", err)
		}
		p := randomPath()
		if err := os.WriteFile(filepath.Join(*dir, "yol"), []byte(p+"\n"), 0o600); err != nil {
			log.Fatalf("yol yazılamadı: %v", err)
		}
		pqPin, err := genStatic(*dir)
		if err != nil {
			log.Fatalf("kalıcı ML-KEM anahtarı üretilemedi: %v", err)
		}
		fmt.Printf("Pin = %s\nPath = %s\nPqPin = %s\n", pin, p, pqPin)
		return
	}
	if *genPq {
		pqPin, err := genStatic(*dir)
		if err != nil {
			log.Fatalf("kalıcı ML-KEM anahtarı üretilemedi: %v", err)
		}
		fmt.Printf("PqPin = %s\n", pqPin)
		return
	}
	cfg, pin, err := loadTLS(*dir)
	if err != nil {
		log.Fatalf("sertifika okunamadı (önce -sertifika-uret): %v", err)
	}
	pb, err := os.ReadFile(filepath.Join(*dir, "yol"))
	path := strings.TrimSpace(string(pb))
	if err != nil || !strings.HasPrefix(path, "/") || len(path) < 17 {
		log.Fatalf("gizli yol okunamadı ya da çok kısa")
	}
	if *show {
		fmt.Printf("Pin = %s\nPath = %s\n", pin, path)
		if k := loadStatic(*dir); k != nil {
			fmt.Printf("PqPin = %s\n", staticPin(k))
		}
		return
	}
	wgAddr, err := net.ResolveUDPAddr("udp", *wg)
	if err != nil {
		log.Fatalf("geçersiz -wg: %v", err)
	}
	ln, err := tls.Listen("tcp", *listen, cfg)
	if err != nil {
		log.Fatalf("dinlenemedi: %v", err)
	}
	s := &server{path: path, wg: wgAddr, limit: *limit, logf: log.Printf}
	if *pqOn {
		s.pq = &pqState{dir: *dir, wgCmd: *wgCmd, wgIf: *wgIf, seen: map[string]time.Time{}, now: time.Now, static: loadStatic(*dir), stateDir: *stateDir}
	}
	log.Printf("dhs-sunucu %s üzerinde; WireGuard %s", *listen, *wg)
	serve(ln, s)
}

func serve(ln net.Listener, s *server) {
	for {
		c, err := ln.Accept()
		if err != nil {
			var ne net.Error
			if errors.As(err, &ne) && ne.Timeout() {
				time.Sleep(50 * time.Millisecond)
				continue
			}
			if errors.Is(err, net.ErrClosed) {
				return
			}
			time.Sleep(50 * time.Millisecond)
			continue
		}
		go s.handle(c)
	}
}
