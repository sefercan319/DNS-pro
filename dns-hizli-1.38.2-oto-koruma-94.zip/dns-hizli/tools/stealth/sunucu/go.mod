module dnshizli/dhs-sunucu

go 1.24
