#!/usr/bin/env bash
# DNS Hızlı — Stealth sunucusu kurulumu (Debian / Ubuntu VPS).
#
#   curl -fsSL https://github.com/__DEPO__/releases/download/stealth-sunucu/kur.sh | sudo bash
#   sudo bash kur.sh istemci-ekle      # yeni bir telefon için ayrı anahtar
#   sudo bash kur.sh goster            # mevcut istemci yapılandırmalarını yeniden yaz
#   sudo bash kur.sh kaldir
#
# Kurulan: çekirdek WireGuard (dhs0, UDP 51820, NAT), dhs-sunucu (TLS 443 → yerel WireGuard), sabitlenmiş öz-imzalı sertifika,
# gizli yol, systemd birimleri. Çıktı: uygulamaya yapıştırılacak yapılandırma ([Stealth] bölümüyle) ve QR.
# Ortam: DHS_PORT (443), DHS_WG_PORT (51820), DHS_SNI (boş), DHS_DNS (1.1.1.1).
set -euo pipefail

DEPO="__DEPO__"
PORT="${DHS_PORT:-443}"
WG_PORT="${DHS_WG_PORT:-51820}"
SNI="${DHS_SNI:-}"
DNS="${DHS_DNS:-1.1.1.1}"
DIR=/etc/dhs
WGC=/etc/wireguard/dhs0.conf
BIN=/usr/local/bin/dhs-sunucu
NET4=10.77.0
NET6=fd77:dd5:77

hata() { echo "HATA: $*" >&2; exit 1; }
[ "$(id -u)" = 0 ] || hata "root olarak çalıştır (sudo)"
command -v apt-get >/dev/null || hata "yalnızca Debian/Ubuntu destekleniyor"
case "$PORT$WG_PORT" in *[!0-9]*) hata "port sayı olmalı" ;; esac
case "$SNI" in *[!A-Za-z0-9.-]*) hata "DHS_SNI geçersiz" ;; esac
case "$DNS" in *[!0-9a-fA-F.:,]*) hata "DHS_DNS geçersiz" ;; esac

genel_ip() {
  local ip=""
  ip=$(curl -4 -fsS --max-time 5 https://api.ipify.org 2>/dev/null || true)
  [ -n "$ip" ] || ip=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<NF;i++) if($i=="src") print $(i+1)}' | head -1)
  case "$ip" in *[!0-9.]*|"") hata "genel IPv4 adresi bulunamadı" ;; esac
  echo "$ip"
}

dis_arayuz() { ip -4 route show default | awk '{for(i=1;i<NF;i++) if($i=="dev") print $(i+1)}' | head -1; }

ikili_kur() {
  local a
  case "$(uname -m)" in x86_64) a=amd64 ;; aarch64|arm64) a=arm64 ;; *) hata "desteklenmeyen mimari: $(uname -m)" ;; esac
  local u="https://github.com/$DEPO/releases/download/stealth-sunucu"
  local t; t=$(mktemp -d)
  curl -fsSL --retry 3 -o "$t/dhs-sunucu-linux-$a" "$u/dhs-sunucu-linux-$a"
  curl -fsSL --retry 3 -o "$t/SHA256SUMS" "$u/SHA256SUMS"
  (cd "$t" && grep " dhs-sunucu-linux-$a\$" SHA256SUMS | sha256sum -c -) || hata "indirilen dosyanın özeti tutmuyor"
  install -m 0755 "$t/dhs-sunucu-linux-$a" "$BIN"
  rm -rf "$t"
}

istemci_yaz() { # $1 = numara (2..)
  local n=$1 cdir="$DIR/istemci-$1"
  local priv pub psk spub ip pin path
  priv=$(cat "$cdir/priv"); psk=$(cat "$cdir/psk"); spub=$(cat "$DIR/wg.pub"); ip=$(cat "$DIR/genel_ip")
  pin=$("$BIN" -goster -dizin "$DIR" | awk -F' = ' '/^Pin/{print $2}')
  path=$("$BIN" -goster -dizin "$DIR" | awk -F' = ' '/^Path/{print $2}')
  local pqpin; pqpin=$("$BIN" -goster -dizin "$DIR" | awk -F' = ' '/^PqPin/{print $2}')
  {
    echo "[Interface]"
    echo "PrivateKey = $priv"
    echo "Address = $NET4.$n/32, $NET6::$n/128"
    echo "DNS = $DNS"
    echo "MTU = 1280"
    echo
    echo "[Peer]"
    echo "PublicKey = $spub"
    echo "PresharedKey = $psk"
    echo "AllowedIPs = 0.0.0.0/0, ::/0"
    echo "Endpoint = $ip:$WG_PORT"
    echo "PersistentKeepalive = 25"
    echo
    echo "[Stealth]"
    echo "Endpoint = $ip:$PORT"
    echo "Pin = $pin"
    echo "Path = $path"
    echo "PQ = 1"
    [ -n "$pqpin" ] && echo "PqPin = $pqpin"
    [ -n "$SNI" ] && echo "SNI = $SNI"
  } > "$cdir/dns-hizli.conf"
  chmod 600 "$cdir/dns-hizli.conf"
  echo
  echo "===== İstemci $n — DNS Hızlı → Deneysel → WireGuard → panodan al ====="
  cat "$cdir/dns-hizli.conf"
  echo "====================================================================="
  if command -v qrencode >/dev/null; then qrencode -t ansiutf8 < "$cdir/dns-hizli.conf"; fi
  echo "(Dosya: $cdir/dns-hizli.conf — [Stealth] bölümü yalnız DNS Hızlı içindir; resmî WireGuard uygulaması için o bölümü sil.)"
}

# Aktarıcı (dhs kullanıcısı) kuantum sonrası PSK için istemcilerin ortak anahtarını ve temel PSK'sini okur; özel anahtarları okuyamaz.
izinler() {
  local d
  for d in "$DIR"/istemci-*; do
    [ -d "$d" ] || continue
    chown root:dhs "$d" "$d/pub" "$d/psk"; chmod 750 "$d"; chmod 640 "$d/pub" "$d/psk"; chmod 600 "$d/priv"
  done
}

istemci_ekle() {
  [ -f "$WGC" ] || hata "önce kurulum yap"
  local n=2
  while [ -d "$DIR/istemci-$n" ]; do n=$((n+1)); done
  [ "$n" -le 250 ] || hata "istemci sınırı"
  local cdir="$DIR/istemci-$n"
  mkdir -p "$cdir"; chmod 700 "$cdir"
  (umask 077; wg genkey > "$cdir/priv"; wg pubkey < "$cdir/priv" > "$cdir/pub"; wg genpsk > "$cdir/psk")
  {
    echo
    echo "[Peer]"
    echo "# istemci-$n"
    echo "PublicKey = $(cat "$cdir/pub")"
    echo "PresharedKey = $(cat "$cdir/psk")"
    echo "AllowedIPs = $NET4.$n/32, $NET6::$n/128"
  } >> "$WGC"
  izinler
  # Çalışan arayüze YALNIZ yeni eş eklenir. (wg syncconf tüm eşlerin PSK'sini dosyadaki temel değere geri yazardı: kuantum sonrası
  # değişimle PSK'si yenilenmiş bağlı istemcilerin hepsi düşerdi.)
  if ip link show dhs0 >/dev/null 2>&1; then
    wg set dhs0 peer "$(cat "$cdir/pub")" preshared-key "$cdir/psk" allowed-ips "$NET4.$n/32,$NET6::$n/128"
  fi
  istemci_yaz "$n"
}

kur() {
  echo "Paketler kuruluyor…"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get install -y -qq wireguard-tools iptables curl ca-certificates >/dev/null
  apt-get install -y -qq qrencode >/dev/null 2>&1 || true
  ikili_kur
  mkdir -p "$DIR"; chmod 700 "$DIR"
  genel_ip > "$DIR/genel_ip"
  if [ ! -f "$DIR/sunucu.crt" ]; then "$BIN" -sertifika-uret -dizin "$DIR" >/dev/null; fi
  "$BIN" -pq-anahtar-uret -dizin "$DIR" >/dev/null       # kuantum sonrası sunucu kimliği (eski kurulumda yoksa üretilir)
  local IF; IF=$(dis_arayuz); [ -n "$IF" ] || hata "varsayılan ağ arayüzü bulunamadı"
  case "$IF" in *[!A-Za-z0-9._-]*) hata "arayüz adı beklenmedik: $IF" ;; esac
  if [ ! -f "$WGC" ]; then
    (umask 077; wg genkey > "$DIR/wg.key"; wg pubkey < "$DIR/wg.key" > "$DIR/wg.pub")
    local v6=""
    if ip -6 route show default 2>/dev/null | grep -q default; then
      v6="ip6tables -t nat -A POSTROUTING -s $NET6::/64 -o $IF -j MASQUERADE; ip6tables -A FORWARD -i dhs0 -j ACCEPT; ip6tables -A FORWARD -o dhs0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT"
    fi
    local v6d=${v6//-A /-D }
    umask 077
    cat > "$WGC" <<CONF
[Interface]
Address = $NET4.1/24, $NET6::1/64
ListenPort = $WG_PORT
PrivateKey = $(cat "$DIR/wg.key")
PostUp = iptables -t nat -A POSTROUTING -s $NET4.0/24 -o $IF -j MASQUERADE; iptables -A FORWARD -i dhs0 -j ACCEPT; iptables -A FORWARD -o dhs0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT; ${v6:-true}
PostDown = iptables -t nat -D POSTROUTING -s $NET4.0/24 -o $IF -j MASQUERADE; iptables -D FORWARD -i dhs0 -j ACCEPT; iptables -D FORWARD -o dhs0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT; ${v6d:-true}
CONF
    umask 022
  fi
  cat > /etc/sysctl.d/90-dhs.conf <<'SYS'
net.ipv4.ip_forward = 1
net.ipv6.conf.all.forwarding = 1
SYS
  sysctl -q --system || true
  id dhs >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin dhs
  chown root:dhs "$DIR" "$DIR/sunucu.key" "$DIR/sunucu.crt" "$DIR/yol"
  chown root:dhs "$DIR/pq.anahtar"
  chmod 750 "$DIR"; chmod 640 "$DIR/sunucu.key" "$DIR/yol" "$DIR/pq.anahtar"
  izinler
  cat > /etc/systemd/system/dhs-sunucu.service <<UNIT
[Unit]
Description=DNS Hızlı Stealth aktarıcısı
After=network-online.target wg-quick@dhs0.service
Wants=network-online.target

[Service]
User=dhs
Group=dhs
ExecStart=$BIN -dinle :$PORT -dizin $DIR -wg 127.0.0.1:$WG_PORT -wg-arayuz dhs0 -durum /var/lib/dhs
StateDirectory=dhs
StateDirectoryMode=0700
Restart=always
RestartSec=2
# CAP_NET_ADMIN: yalnızca "wg set dhs0 peer … preshared-key" (kuantum sonrası PSK) için
AmbientCapabilities=CAP_NET_BIND_SERVICE CAP_NET_ADMIN
CapabilityBoundingSet=CAP_NET_BIND_SERVICE CAP_NET_ADMIN
NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
PrivateTmp=yes
PrivateDevices=yes
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
RestrictAddressFamilies=AF_INET AF_INET6 AF_NETLINK AF_UNIX
RestrictNamespaces=yes
LockPersonality=yes
MemoryDenyWriteExecute=yes
SystemCallArchitectures=native
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload
  systemctl enable --now wg-quick@dhs0 >/dev/null
  systemctl enable dhs-sunucu >/dev/null
  systemctl restart dhs-sunucu
  if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
    ufw allow "$PORT/tcp" >/dev/null; ufw allow "$WG_PORT/udp" >/dev/null
  fi
  sleep 1
  systemctl is-active --quiet dhs-sunucu || { journalctl -u dhs-sunucu -n 20 --no-pager; hata "dhs-sunucu başlamadı"; }
  echo "Kurulum tamam: TLS $PORT/tcp (Stealth), WireGuard $WG_PORT/udp."
  if ls -d "$DIR"/istemci-* >/dev/null 2>&1; then goster; else istemci_ekle; fi
}

goster() {
  local d
  for d in "$DIR"/istemci-*; do [ -d "$d" ] && istemci_yaz "${d##*-}"; done
}

kaldir() {
  systemctl disable --now dhs-sunucu wg-quick@dhs0 2>/dev/null || true
  rm -f /etc/systemd/system/dhs-sunucu.service /etc/sysctl.d/90-dhs.conf "$BIN" "$WGC"
  rm -rf "$DIR"
  systemctl daemon-reload
  echo "Kaldırıldı."
}

case "${1:-kur}" in
  kur) kur ;;
  istemci-ekle) istemci_ekle ;;
  goster) goster ;;
  kaldir) kaldir ;;
  *) hata "kullanım: kur.sh [kur|istemci-ekle|goster|kaldir]" ;;
esac
