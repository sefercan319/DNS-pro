# Stealth (bize özel)

WireGuard trafiğini TLS içinde, WebSocket çerçeveleriyle kendi sunucuna taşır. Ağ yalnızca sıradan bir HTTPS bağlantısı görür; UDP'nin
kısıtlandığı ya da WireGuard'ın tanınıp engellendiği yerlerde de çalışır.

## Kurulum (telefondan)
1. GitHub → Actions → **Stealth sunucusu** → Run workflow (bir kez; `stealth-sunucu` yayınını oluşturur).
2. Bir Debian/Ubuntu VPS'e SSH ile bağlan (ör. Termux / JuiceSSH) ve çalıştır:
   `curl -fsSL https://github.com/<sahip>/<depo>/releases/download/stealth-sunucu/kur.sh | sudo bash`
3. Ekrana yazılan yapılandırmayı kopyala → uygulamada **Deneysel → WireGuard → Yapılandırmayı panodan al** → **WireGuard ile bağlan**.

Başka telefon: `sudo bash kur.sh istemci-ekle`. Yeniden göster: `sudo bash kur.sh goster`. Kaldır: `sudo bash kur.sh kaldir`.
Ortam: `DHS_PORT` (443), `DHS_WG_PORT` (51820), `DHS_SNI` (boş), `DHS_DNS` (1.1.1.1).

## Güvenlik
- Sunucu sertifikası öz-imzalıdır; uygulama onu **SPKI SHA-256 özetiyle sabitler** (`Pin`). Araya giren sahte sertifika reddedilir.
- Gizli yolu (`Path`) bilmeyen her istek nginx 404 sayfası alır; kimliği doğrulanmamış bağlantılar ayrı sınırla sayılır.
- Aktarıcı root olmadan, sertleştirilmiş systemd biriminde çalışır; ikili dosya SHA256SUMS ile doğrulanarak kurulur.
- Yapılandırmadaki `[Stealth]` bölümü yalnızca DNS Hızlı içindir; resmî WireGuard uygulamasında o bölümü silip doğrudan UDP ile kullanılabilir.

## Kuantum sonrası (PQ = 1)
Her Stealth bağlantısında (UDP yolundayken kısa ayrı bir bağlantıyla) uygulama aktarıcıyla ML-KEM-768 değişimi yapar; aktarıcı
`wg set dhs0 peer … preshared-key` ile eşin PSK'sini, uygulama da kendi PSK'sini aynı türetilmiş değere ayarlar. WireGuard'ın X25519'u
ileride kuantum bilgisayarla kırılsa da bugün kaydedilen trafik PSK bilinmeden açılamaz (UDP ve Stealth yolunun ikisinde de).
İstek yapılandırmadaki PresharedKey ile doğrulanır; tekrar ve 2 dk'dan eski istekler reddedilir. Aktarıcı bunun için yalnızca
CAP_NET_ADMIN alır; istemcilerin özel anahtarlarını okuyamaz.

## Kuantum sonrası sunucu kimliği (PqPin)
Aktarıcının kalıcı ML-KEM-768 anahtarı (`pq.anahtar`) vardır; yapılandırmadaki `PqPin` onun SHA-256 özetidir. İstemci bu anahtara kapsül
koyar ve cevabı o sırdan türeyen anahtarla doğrular: anahtarı olmayan sahte aktarıcı doğru cevap üretemez. Özet uyuşmazsa bağlantı kullanılmaz.

## Trafik gizleme (SHP1)
Uygulamada "Trafik gizleme" açıkken istemci aktarıcıdan sunucu → telefon yönünde dolgu ve örtü ister; çerçeveler `0xF5 ‖ uzunluk ‖ paket ‖ dolgu`.

## Geliştirme
`cd sunucu && go test -race ./...` — çerçeve sınırları, RFC 6455 Accept, tuzak/yoklama, bağlantı sınırı, uçtan uca TLS.
Uygulama tarafıyla birlikte çalışma testi: `./run-tests.sh sizma39` (Go varsa aktarıcıyı derler, gerçek WireGuard akışını sınar).
