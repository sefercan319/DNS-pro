# Yol haritası (eklenecekler)

Proton / NymVPN / Surfshark karşılaştırmasından çıkan, uygulamada henüz olmayan özellikler. Sıra önerilen uygulama sırasıdır.

| # | Özellik | Durum |
|---|---|---|
| 1 | Alternatif yönlendirme: liste güncellemesi için aynalar (raw.githubusercontent, jsDelivr cdn/fastly/gcore) | ✅ bitti (oto-koruma 71) |
| 2a | Bize özel WireGuard çekirdeği (saf Kotlin: BLAKE2s, ChaCha20-Poly1305, XChaCha20, Noise IKpsk2, tekrar penceresi, çerez) | ✅ bitti (71) |
| 2b | WireGuard yapılandırma ayrıştırıcı (.conf / QR metni; komut alanları asla çalıştırılmaz) | ✅ bitti (71) |
| 2c | WireGuard tünel entegrasyonu (VpnService; zamanlayıcılar; DNS süzgeci ve reklam engeli tünel içinde) | ✅ bitti (72) |
| 2d | WireGuard içe aktarma arayüzü (dosya, pano) | ✅ bitti (72) |
| 2e | WireGuard QR kodu ile içe aktarma (kamera + saf Kotlin QR çözücü) | ⏳ |
| 3 | Stealth: WireGuard'ı TLS içinde taşıyan bize özel aktarıcı + VPS sunucu programı + kurulum betiği (TCP üzerinden çalışır) | ✅ bitti (73) |
| 4 | Smart kip: WireGuard UDP → Stealth otomatik seçim | ✅ bitti (74) |
| 5 | Kuantum sonrası: ML-KEM-768 (FIPS 203), saf Kotlin, resmi vektörlerle | ✅ bitti (75) |
| 6 | Kuantum sonrası: QUIC (DoQ/DoH3) X25519MLKEM768 karma anahtar değişimi (desteklemeyen sunucuda X25519'a düşüş) | ✅ bitti (76) |
| 7 | Kuantum sonrası: WireGuard PSK'sinin ML-KEM ile üretilmesi (Stealth sunucusuyla) | ✅ bitti (75) |

Kapsam dışı (gerekmiyor ya da uygulanamaz): NAT Type (sunucuya ait), ODoH ve sistem DoH/DoT'ta tek taraflı kuantum sonrası (sunucu/Android'e bağlı).
