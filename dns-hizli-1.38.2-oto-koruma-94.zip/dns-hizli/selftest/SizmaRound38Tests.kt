package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File

/**
 * sizma62: uyum motoru 2 — hız (önceden hesaplanmış dizin, plan belleği), otomatik koruma ile ortak resim, eğilim tahmini, akış seli,
 * ağ başına öğrenme, hata güvenliği, yeni denetimler (önceden yenileme, iki kademeli hareket, akış sınırı, disk yazma aralığı).
 */
internal fun runRound38Tests() {
    speedTests()
    shieldTests()
    trendTests()
    networkMemoryTests()
    failSafeTests()
    newKnobTests()
    wiringTests()
}

private val LOWD = DeviceProfiler.detect(DeviceInfo(manufacturer = "Xiaomi", brand = "Redmi", model = "Redmi 9A", sdk = 33, ramMb = 2048, heapMb = 128, lowRamFlag = true))
private val MIDD = DeviceProfiler.detect(DeviceInfo(manufacturer = "Samsung", brand = "samsung", model = "SM-A546B", sdk = 34, ramMb = 6144, heapMb = 256))
private val HIGHD = DeviceProfiler.detect(DeviceInfo(manufacturer = "Samsung", brand = "samsung", model = "SM-S928B", sdk = 35, ramMb = 12288, heapMb = 512))
private val ALLON = AppSettings(
    dnsOn = true, dpiOn = true, adsPlus = true, mitmOn = true, udpDecoy = true, quicSplit = true, blockQuic = false, dnsRace = true,
    splitDns = true, filterLevel = FilterLevel.STRICT, autoShield = true, oemBlock = true, appFw = "com.a.b=A", motion = Motion.FULL,
    wallpaper = true, wpBlur = WpBlur.STRONG, tapFx = true, celebrate = true, soundOn = true, deviceAuto = true,
)

private fun speedTests() {
    T.group("sizma62: uyum motoru: hız")
    val c = HarmonyContext(LOWD, CompatFacts(batterySaver = true, thermal = 2))
    repeat(300) { HarmonyCore.compute(ALLON, c, Load.BUSY) }          // ısınma (JIT)
    val n = 2000
    val t0 = System.nanoTime()
    repeat(n) { HarmonyCore.compute(ALLON, c, Load.BUSY) }
    val avgUs = (System.nanoTime() - t0) / 1000.0 / n
    println("    uyum motoru: en ağır plan ortalama %.1f µs (90 özellik, %d kısma)".format(avgUs, HarmonyCore.compute(ALLON, c, Load.BUSY).off.size))
    T.check("en ağır durumda bile plan 1 ms'nin çok altında (ortalama ${"%.0f".format(avgUs)} µs)", avgUs < 1000.0)
    val e = HarmonyEngine()
    repeat(50) { e.plan(ALLON, c, 1_000L) }
    T.check("girdiler değişmediyse yeniden hesaplanmaz (plan belleği)", e.stats.computed == 1L && e.stats.memoHits == 49L, e.stats.line())
    e.plan(ALLON.copy(udpDecoy = false), c, 1_000L)
    T.check("bir ayar değişince hemen yeniden hesaplanır", e.stats.computed == 2L)
    e.plan(ALLON.copy(udpDecoy = false), c.copy(facts = CompatFacts()), 1_000L)
    T.check("ortam değişince de yeniden hesaplanır", e.stats.computed == 3L)
    T.check("istatistik satırı süreyi ve bellek isabetini yazar", e.stats.line().contains("bellekten") && e.stats.line().contains("µs"))
    val a = HarmonyCore.compute(ALLON, c, Load.BUSY); val b = HarmonyCore.compute(ALLON, c, Load.BUSY)
    T.check("dizi tabanlı çözüm eşlem arayüzüyle aynı sonucu verir", a.states == HarmonyCore.resolve(HarmonyCore.overlay(ALLON, c.shield), a.states.filter { it.value == FState.SHED }.mapValues { "x" }, HashMap()) .let { r ->
        a.states.mapValues { (k, v) -> if (v == FState.SHED) r[k] else v } } && a.sig == b.sig)
}

private fun shieldTests() {
    T.group("sizma62: uyum motoru: otomatik koruma ile ortak resim")
    val s = AppSettings(dnsOn = true, dpiOn = false, autoDpi = true, autoShield = true, udpDecoy = true, quicSplit = true, blockQuic = false, adsPlus = false, appFw = "com.a.b=A", dnsRace = false)
    val plain = HarmonyCore.compute(s, HarmonyContext(HIGHD))
    T.check("koruma DPI açmamışken DPI işleri uyur", plain.state("udpDecoy") == FState.DORMANT && plain.state("dpi.autoTtl") == FState.DORMANT)
    val dpi = HarmonyCore.compute(s, HarmonyContext(HIGHD, shield = setOf(Act.DPI_ON)))
    T.check("koruma DPI'ı kendisi açınca DPI işleri hesaba girer", dpi.state("dpiOn") == FState.ACTIVE && dpi.state("udpDecoy") == FState.ACTIVE && dpi.state("dpi.autoTtl") == FState.ACTIVE)
    T.check("ve bu iç günlüğe not düşülür", dpi.notes.any { it.contains("DPI_ON") })
    val quic = HarmonyCore.compute(s.copy(dpiOn = true), HarmonyContext(HIGHD, shield = setOf(Act.QUIC_OFF)))
    T.check("koruma QUIC'i kapatınca QUIC bölme boşa çıkar", quic.state("quicSplit") == FState.SUPERSEDED && !quic.allows(Knob.QUIC_SPLIT))
    val mitm = HarmonyCore.compute(s.copy(adsPlus = true, mitmOn = true, fpGuard = true), HarmonyContext(HIGHD, shield = setOf(Act.MITM_OFF)))
    T.check("koruma tarayıcı kipini sökünce ona bağlı parmak izi koruması uyur", mitm.state("mitmOn") == FState.OFF && mitm.state("fpGuard") == FState.DORMANT)
    T.check("koruma katmanı kullanıcının ayarını değiştirmez", HarmonyCore.overlay(s, setOf(Act.DPI_ON)) != s && !s.dpiOn && HarmonyCore.overlay(s, emptySet()) === s)
    val g = HarmonyGovernor()
    repeat(3) { g.sample(LoadSample(dnsMs = 20)) }
    g.sample(LoadSample(dnsMs = 20, shieldFlood = true))
    T.check("koruma akış seli görünce beklemeden aşırı yük", g.load == Load.OVERLOAD)
    repeat(2) { g.sample(LoadSample(dnsMs = 20)) }
    T.check("sel bitince her zamanki gibi kademeli iner", g.load == Load.OVERLOAD)
    g.sample(LoadSample(dnsMs = 20))
    T.check("üç sakin ölçümde bir kademe", g.load == Load.BUSY)
}

private fun trendTests() {
    T.group("sizma62: uyum motoru: eğilim tahmini")
    val g = HarmonyGovernor()
    repeat(4) { g.sample(LoadSample(dnsMs = 40)) }
    // taban 40: yoğun eşiği 190. 60 → 90 → 130: hepsi eşiğin altında ama hızla yükseliyor (130 + 40 = 170 < 190: henüz değil)
    g.sample(LoadSample(dnsMs = 60)); g.sample(LoadSample(dnsMs = 90)); g.sample(LoadSample(dnsMs = 130))
    T.check("yavaş yükseliş erken alarm üretmez", g.load == Load.SMOOTH)
    g.sample(LoadSample(dnsMs = 175))
    T.check("hızlanan yükseliş (175 + 45 ≥ 190): eşik geçilmeden yoğuna geçilir", g.load == Load.BUSY)
    val g2 = HarmonyGovernor()
    repeat(4) { g2.sample(LoadSample(dnsMs = 40)) }
    g2.sample(LoadSample(dnsMs = 90)); g2.sample(LoadSample(dnsMs = 60)); g2.sample(LoadSample(dnsMs = 170)); g2.sample(LoadSample(dnsMs = 100))
    T.check("iniş-çıkış (gürültü) eğilim sayılmaz", g2.load == Load.SMOOTH)
    val g3 = HarmonyGovernor()
    repeat(4) { g3.sample(LoadSample(dnsMs = 40)) }
    g3.sample(LoadSample(dnsMs = 41)); g3.sample(LoadSample(dnsMs = 42)); g3.sample(LoadSample(dnsMs = 43))
    T.check("tabana yakın küçük artışlar eğilim sayılmaz", g3.load == Load.SMOOTH)
}

private fun networkMemoryTests() {
    T.group("sizma62: uyum motoru: ağ başına öğrenme")
    val e = HarmonyEngine()
    e.networkChanged("WIFI:", 11)
    repeat(4) { e.observe(LoadSample(dnsMs = 25), Efficacy(), 0) }
    e.observe(LoadSample(), Efficacy(hedged = 0, hedgeWon = 0), 0)
    e.observe(LoadSample(), Efficacy(hedged = 40, hedgeWon = 0), 0)
    T.check("Wi-Fi'de taban öğrenildi ve yedek bağlantı etkisiz bulundu", e.governor.baseMs == 25 && Knob.HEDGE in e.breakers.open(1))
    e.networkChanged("MOBILE:28601", 22)
    T.check("mobile geçince sıfırdan (başka ağ, başka koşullar)", e.governor.baseMs == 0 && e.breakers.open(1).isEmpty())
    repeat(4) { e.observe(LoadSample(dnsMs = 80), Efficacy(), 0) }
    e.networkChanged("WIFI:", 33)
    T.check("Wi-Fi'ye dönünce öğrenilenler geri gelir (taban ve sigorta)", e.governor.baseMs == 25 && Knob.HEDGE in e.breakers.open(1))
    e.networkChanged("MOBILE:28601", 44)
    T.check("mobil taban da saklanmıştı", e.governor.baseMs == 80)
    e.networkChanged("MOBILE:28601", 44)
    T.check("aynı ağın tekrar eden olayı öğrenileni silmez", e.governor.baseMs == 80)
    e.networkChanged("MOBILE:28602", 45)
    T.check("başka operatör ayrı ağdır", e.governor.baseMs == 0)
    for (i in 0 until 12) e.networkChanged("NET$i", 100L + i)
    T.check("en çok ${HarmonyEngine.MAX_NETS} ağ akılda tutulur (en eskisi unutulur)", e.knownNetworks() <= HarmonyEngine.MAX_NETS + 1)
    e.networkChanged("WIFI:", 999)
    T.check("unutulan ağ sıfırdan öğrenilir", e.governor.baseMs == 0)
}

private fun failSafeTests() {
    T.group("sizma62: uyum motoru: hata güvenliği")
    var fail = false
    val e = HarmonyEngine { s, c, l, b -> if (fail) throw IllegalStateException("deneme") else HarmonyCore.compute(s, c, l, b) }
    val c = HarmonyContext(MIDD, CompatFacts(batterySaver = true))
    val good = e.plan(AppSettings(dpiOn = true, udpDecoy = true, blockQuic = false), c, 0)
    fail = true
    val p = e.plan(AppSettings(dpiOn = true, udpDecoy = true, blockQuic = false, dnsRace = false), c, 1)
    T.check("hesap hata atarsa son iyi plan kullanılır, servis düşmez", p === good && e.stats.failures == 1L, e.stats.line())
    val e2 = HarmonyEngine { _, _, _, _ -> throw OutOfMemoryError("deneme") }
    T.check("hiç iyi plan yoksa hiçbir şeyi kısmayan plan (kullanıcının ayarları aynen)", e2.plan(AppSettings(), c, 0) === HarmonyPlan.NONE)
    fail = false
    T.check("hata geçince normal hesaba döner", e.plan(AppSettings(dpiOn = true, udpDecoy = true, blockQuic = false, dnsRace = false), c, 2) !== good && e.stats.line().contains("hata"))
}

private fun newKnobTests() {
    T.group("sizma62: uyum motoru: yeni denetimler")
    val met = HarmonyCore.compute(AppSettings(dnsOn = true, dnsRace = false, refreshOnNetwork = true, autoFastest = true, autoMeasure = true), HarmonyContext(MIDD, CompatFacts(metered = true, mobile = true)))
    T.check("ölçülü mobil veride önbellek ön yenilemesi kısılabilir", !met.allows(Knob.PREFETCH), met.journal().joinToString(" | "))
    T.check("Wi-Fi'de ön yenileme sürer", HarmonyCore.compute(AppSettings(dnsOn = true), HarmonyContext(MIDD)).allows(Knob.PREFETCH))
    T.check("önbellek kapalıyken ön yenileme uyur", HarmonyCore.compute(AppSettings(dnsOn = true, cache = CacheLevel.OFF), HarmonyContext(MIDD)).state("dns.prefetch") == FState.DORMANT)
    val mem = HarmonyCore.compute(AppSettings(dpiOn = true, adsPlus = true), HarmonyContext(HIGHD, heapPct = 95))
    T.check("yığın %95: akış sınırları %60, boşta süreler kısalır", mem.flowScale == 0.6f && mem.idleScale == 0.75f && HarmonyCore.flows(1500, 200, mem) == 900 && HarmonyCore.flows(250, 200, mem) == 200)
    T.check("yığın %87: akış sınırları %80", HarmonyCore.compute(AppSettings(), HarmonyContext(HIGHD, heapPct = 87)).flowScale == 0.8f)
    T.check("bellek rahatken akış sınırına dokunulmaz", HarmonyCore.compute(AppSettings(), HarmonyContext(HIGHD, heapPct = 40)).flowScale == 1f)
    val full = AppSettings(motion = Motion.FULL, deviceAuto = true)
    HarmonyLive.plan = HarmonyCore.compute(ALLON, HarmonyContext(LOWD), Load.OVERLOAD)
    T.check("aşırı yükte zayıf cihazda hareket durur", full.effectiveMotion == Motion.OFF && HarmonyLive.plan.motionOff)
    HarmonyLive.plan = HarmonyCore.compute(ALLON, HarmonyContext(LOWD), Load.SMOOTH)
    T.check("normal yükte en çok 'Az' (hareket durmaz)", full.effectiveMotion == Motion.REDUCED && !HarmonyLive.plan.motionOff)
    HarmonyLive.reset()
    PrivacyReport.reset()
    var now = 1_700_000_000_000L
    var saves = 0
    PrivacyReport.clock = { now }; PrivacyReport.zoneOffset = { 0 }; PrivacyReport.saver = { saves++ }
    PrivacyReport.record("com.a.b", "t.example.com"); val s0 = saves
    now += 70_000; PrivacyReport.record("com.a.b", "t.example.com")
    T.check("rapor normalde dakikada bir diske yazılır", saves == s0 + 1)
    PrivacyReport.saveScale = 3
    now += 70_000; PrivacyReport.record("com.a.b", "t.example.com")
    T.check("motor aralığı uzatınca yazma seyrekleşir", saves == s0 + 1)
    now += 120_000; PrivacyReport.record("com.a.b", "t.example.com")
    T.check("3 dakika dolunca yazılır; kapanışta yine hemen yazılır", saves == s0 + 2 && run { PrivacyReport.record("com.a.b", "x.com"); PrivacyReport.flush(); saves == s0 + 3 })
    PrivacyReport.reset()
    T.check("sıfırlanınca aralık normale döner", PrivacyReport.saveScale == 1)
}

private fun wiringTests() {
    T.group("sizma62: uyum motoru: bağlantılar")
    val sv = File("app/src/main/java/app/dnshizli/platform/DnsVpnService.kt").readText()
    T.check("servis: koruma önlemleri ve yığın ölçümü plana girer; akış seli sinyali", sv.contains("val shield = try { immune.active() }") && sv.contains("shieldFlood = Act.FLOW_SOFT in acts || Act.FLOW_HARD in acts"))
    T.check("servis: akış sınırları, rapor yazma, sızıntı testi ve liste denetimi aralığı motora bağlı",
        sv.contains("HarmonyCore.flows(p.maxTcp, Compat.TCP_MIN, hp)") && sv.contains("PrivacyReport.saveScale = hp.tickScale") &&
            sv.contains("LEAK_PROBE_MS * HarmonyLive.plan.tickScale") && sv.contains("LIST_CHECK_MS * HarmonyLive.plan.tickScale"))
    T.check("servis: ağ kimliği ve tutamacıyla ağ başına öğrenme", sv.contains("engine.networkChanged(kind.name + \":\" + (if (kind == NetKind.MOBILE) operatorCode() else \"\"), handle)"))
    val dns = File("app/src/main/java/app/dnshizli/core/DnsForwarder.kt").readText()
    val sec = File("app/src/main/java/app/dnshizli/core/SecureForwarder.kt").readText()
    T.check("düz ve şifreli DNS'te ön yenileme motorun iznine bağlı", dns.contains("HarmonyLive.allows(Knob.PREFETCH) && cache.prefetchDue(key)") && sec.contains("HarmonyLive.allows(Knob.PREFETCH) && cache.prefetchDue(key)"))
}
