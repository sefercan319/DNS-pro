package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.Section
import app.dnshizli.ui.Strings
import java.io.File
import java.util.ArrayDeque

/** sizma40: Smart kip — WireGuard UDP engellenince Stealth'e kendiliğinden geçiş, ağ değişince UDP'ye dönüş, kip seçimi. */
internal fun runRound16Tests() {
    pathLogicTests()
    simulationTests()
    uiTests()
    staticTests()
}

private fun pathLogicTests() {
    T.group("sizma40: yol seçici (WgPath) kararları")
    val p = WgPath(WgPath.Mode.AUTO, hasUdp = true, hasStealth = true, now = 0)
    T.check("otomatik: UDP ile başlar", p.path == WgPath.Path.UDP)
    T.check("el sıkışma yokken geçiş yok", p.onTick(60_000, -1) == null)
    T.check("6.9 sn bekleyen el sıkışma: henüz geçmez", p.onTick(6_900, 6_900) == null)
    T.check("7 sn cevapsız: Stealth'e geçer", p.onTick(7_000, 7_000) == WgPath.Path.STEALTH && p.switches == 1)
    T.check("geçişten önceki bekleme Stealth'e sayılmaz (yolun başından sayılır)", p.onTick(36_000, 36_000) == null)
    T.check("Stealth 30 sn cevapsız ama UDP 2 dk dolmadı: kalır", p.onTick(60_000, 60_000) == null)
    T.check("2 dk sonra Stealth hâlâ cevapsız: UDP yeniden denenir", p.onTick(127_000, 127_000) == WgPath.Path.UDP)
    val q = WgPath(WgPath.Mode.AUTO, true, true, 0)
    q.onTick(8_000, 8_000)
    T.check("ağ değişince UDP yeniden denenir", q.onNetworkChanged(20_000) == WgPath.Path.UDP && q.path == WgPath.Path.UDP)
    T.check("UDP'deyken ağ değişimi geçiş üretmez (süre sıfırlanır)", q.onNetworkChanged(21_000) == null && q.onTick(27_000, 27_000) == null && q.onTick(28_000, 28_000) == WgPath.Path.STEALTH)
    val u = WgPath(WgPath.Mode.UDP, true, true, 0)
    T.check("yalnız UDP: asla geçmez", u.onTick(500_000, 500_000) == null && u.onNetworkChanged(1) == null && u.path == WgPath.Path.UDP)
    val s = WgPath(WgPath.Mode.STEALTH, true, true, 0)
    T.check("yalnız Stealth: Stealth ile başlar, geçmez", s.path == WgPath.Path.STEALTH && s.onTick(500_000, 500_000) == null)
    T.check("Stealth yoksa otomatik = UDP, geçmez", WgPath(WgPath.Mode.AUTO, true, false, 0).let { it.path == WgPath.Path.UDP && it.onTick(99_000, 99_000) == null })
    T.check("UDP yoksa otomatik = Stealth", WgPath(WgPath.Mode.AUTO, false, true, 0).path == WgPath.Path.STEALTH)
    T.check("yalnız UDP istendi ama UDP yok: Stealth'e düşülür", WgPath(WgPath.Mode.UDP, false, true, 0).path == WgPath.Path.STEALTH)
    val m = WgPath(WgPath.Mode.AUTO, true, true, 0)
    T.check("bağlıyken kip: Stealth seçilince hemen geçer", m.setMode(WgPath.Mode.STEALTH, 1000) == WgPath.Path.STEALTH)
    T.check("otomatiğe dönünce bulunduğu yolda kalır", m.setMode(WgPath.Mode.AUTO, 2000) == null && m.path == WgPath.Path.STEALTH)
    T.check("kip kimliği: bilinmeyen → otomatik", WgPath.Mode.of("x") == WgPath.Mode.AUTO && WgPath.Mode.of("stealth") == WgPath.Mode.STEALTH && WgPath.Mode.of(null) == WgPath.Mode.AUTO)
}

/** Sahte saatle uçtan uca: UDP yolu karadelik (DPI WireGuard'ı düşürüyor), Stealth yolu sunucuya ulaşıyor. */
private fun simulationTests() {
    T.group("sizma40: benzetim — UDP engelli ağda Stealth'e geçip bağlanır, ağ değişince UDP'ye döner")
    var clock = 0L
    val cPriv = Wg.generatePrivate(); val sPriv = Wg.generatePrivate()
    val b64 = { b: ByteArray -> java.util.Base64.getEncoder().encodeToString(b) }
    val cfg = (WgConfig.parse("""
        [Interface]
        PrivateKey = ${b64(cPriv)}
        Address = 10.77.0.2/32
        [Peer]
        PublicKey = ${b64(Wg.publicKey(sPriv))}
        AllowedIPs = 0.0.0.0/0
        Endpoint = 203.0.113.5:51820
        [Stealth]
        Endpoint = 203.0.113.5:443
        Pin = ${b64(ByteArray(32))}
        Path = /AbCdEfGhIjKlMnOpQr
    """.trimIndent()) as WgConfig.Companion.Result.Ok).cfg
    val res = WgResponder(sPriv).also { it.addPeer(WgResponder.Peer(Wg.publicKey(cPriv))) }
    var srvSession: WgSession? = null
    var udpBlocked = true
    var stealth = false
    var udpSent = 0; var stealthSent = 0
    val toClient = ArrayDeque<ByteArray>()
    fun server(m: ByteArray) {
        when (m[0].toInt()) {
            Wg.TYPE_INITIATION -> res.consumeInitiation(m, 0, m.size)?.let { i -> val (r, s) = res.respond(i, 3, clock)!!; srvSession = s; toClient.add(r) }
            Wg.TYPE_DATA -> srvSession?.decrypt(m, 0, m.size, clock)
        }
    }
    val tunnel = WgTunnel(cfg, { m -> if (stealth) { stealthSent++; server(m) } else { udpSent++; if (!udpBlocked) server(m) } }, { _, _, _ -> }, now = { clock })
    val picker = WgPath(WgPath.Mode.AUTO, cfg.hasUdpEndpoint, cfg.stealth != null, clock)
    fun step(ms: Long = 1000) {
        clock += ms
        tunnel.tick()
        picker.onTick(clock, tunnel.handshakePendingMs())?.let { p -> stealth = p == WgPath.Path.STEALTH; tunnel.reconnected() }
        while (toClient.isNotEmpty()) { val r = toClient.removeFirst(); tunnel.fromNet(r, 0, r.size) }
    }
    val pkt = ByteArray(60).also { it[0] = 0x45; Packets.put16(it, 2, 60); it[9] = 17; System.arraycopy(byteArrayOf(10, 77, 0, 2), 0, it, 12, 4); System.arraycopy(byteArrayOf(1, 1, 1, 1), 0, it, 16, 4) }
    tunnel.fromTun(pkt, pkt.size)
    var connectedAt = -1L
    for (i in 0 until 20) { step(); if (tunnel.connected && connectedAt < 0) connectedAt = clock }
    T.check("UDP'de el sıkışmaları cevapsız kaldı (2 deneme)", udpSent >= 2)
    T.check("~7 sn içinde Stealth'e geçti ve bağlandı (gecikme ≤ 9 sn)", picker.path == WgPath.Path.STEALTH && tunnel.connected && connectedAt in 7_000..9_000, "bağlandı=$connectedAt yol=${picker.path}")
    T.check("geçişten sonra paketler Stealth'ten gidiyor", stealthSent >= 1)
    // Yeni ağ: UDP açık
    udpBlocked = false
    val u0 = udpSent
    picker.onNetworkChanged(clock)?.let { p -> stealth = p == WgPath.Path.STEALTH; tunnel.reconnected() }
    for (i in 0 until 3) step()
    T.check("ağ değişince UDP'ye döndü, oturum UDP üzerinden sürüyor", picker.path == WgPath.Path.UDP && !stealth && udpSent > u0 && tunnel.connected)
    // UDP yeniden engellendi (oturum ortasında DPI): ölü eş → yeni el sıkışma → Stealth
    udpBlocked = true
    tunnel.fromTun(pkt, pkt.size)
    var back = false
    for (i in 0 until 60) { step(); if (picker.path == WgPath.Path.STEALTH && tunnel.connected) { back = true; break } }
    T.check("oturum ortasında UDP kesilince ölü eş algılanır ve Stealth'e geçilir", back, "yol=${picker.path} geçiş=${picker.switches}")
    tunnel.close()
}

private fun uiTests() {
    T.group("sizma40: arayüz — bağlantı yolu seçimi")
    val b64 = { b: ByteArray -> java.util.Base64.getEncoder().encodeToString(b) }
    fun conf(stealth: Boolean, udp: Boolean = true) = """
        [Interface]
        PrivateKey = ${b64(Wg.generatePrivate())}
        Address = 10.77.0.2/32
        [Peer]
        PublicKey = ${b64(Wg.publicKey(Wg.generatePrivate()))}
        AllowedIPs = 0.0.0.0/0
        ${if (udp) "Endpoint = 203.0.113.5:51820" else ""}
        ${if (stealth) "[Stealth]\nEndpoint = 203.0.113.5:443\nPin = ${b64(ByteArray(32))}\nPath = /AbCdEfGhIjKlMnOpQr" else ""}
    """.trimIndent()
    val rig = Rig(Rig.base())
    rig.host.wgText = conf(stealth = false)
    fun open() {
        rig.scene.openSection(Section.EXPERIMENTAL); rig.settle(900)
        repeat(12) { if (rig.find(Strings.WG_TITLE) == null) rig.drag(180f, rig.h * 0.7f, rig.h * 0.7f - 220f, 8) }
        rig.tapText(Strings.WG_TITLE, settleMs = 600)
    }
    open()
    T.check("yalnız UDP yapılandırmasında yol seçeneği yok", rig.find(Strings.WG_PATH) == null)
    val rig2 = Rig(Rig.base())
    rig2.host.wgText = conf(stealth = true, udp = false)
    T.check("yalnız Stealth yapılandırmasında yol seçimi anlamsız", !rig2.model.wgHasBothPaths())
    rig.host.wgText = conf(stealth = true)
    T.check("ikisi de varsa yol seçimi var", rig.model.wgHasBothPaths())
    val r3 = Rig(Rig.base())
    r3.host.wgText = conf(stealth = true)
    r3.scene.openSection(Section.EXPERIMENTAL); r3.settle(900)
    repeat(12) { if (r3.find(Strings.WG_TITLE) == null) r3.drag(180f, r3.h * 0.7f, r3.h * 0.7f - 220f, 8) }
    r3.tapText(Strings.WG_TITLE, settleMs = 600)
    T.check("seçenek görünür, şu anki kip notta", r3.find(Strings.WG_PATH) != null && r3.find(Strings.wgPathName("auto")) != null)
    r3.tapText(Strings.WG_PATH, settleMs = 600)
    T.check("üç kip listelenir", r3.find(Strings.wgPathName("udp")) != null && r3.find(Strings.wgPathName("stealth")) != null)
    r3.tapText(Strings.wgPathName("stealth") + ",", settleMs = 600)
    T.check("seçim platforma iletilir", r3.host.wgModeId == "stealth" && "wgMode:stealth" in r3.host.calls && r3.model.wgPathMode() == WgPath.Mode.STEALTH)
    T.check("Türkçe metinler", L.tx.wgPathName("auto").isNotBlank() && Strings.WG_PATH_FOOT.contains("7"))
}

private fun staticTests() {
    T.group("sizma40: servis yapısı (Smart geçişi)")
    fun src(p: String) = listOf(p, "../$p").map { File(it) }.firstOrNull { it.isFile }?.readText() ?: ""
    val w = src("app/src/main/java/app/dnshizli/platform/WgVpnService.kt")
    T.check("her iki yolun adı tün kurulmadan çözülür", w.indexOf("resolveAll(cfg)") in 1 until w.indexOf("establish(cfg, mtu)") &&
        Regex("""fun resolveAll\(c: WgConfig\)[\s\S]{0,400}resolve\(c\.peer\.endpointHost[\s\S]{0,200}resolve\(st\.host, st\.port\)""").containsMatchIn(w))
    T.check("zamanlayıcı yol seçiciyi besler", w.contains("picker?.onTick(System.currentTimeMillis(), t.handshakePendingMs())"))
    T.check("ağ değişimi seçiciye bildirilir", w.contains("picker?.onNetworkChanged("))
    T.check("UDP'ye dönüşte Stealth oturumu kapanır, tünel yeniden el sıkışır", Regex("""if \(!toStealth\) stealthSession\?\.close\(\)[\s\S]{0,160}tunnel\?\.reconnected\(\)""").containsMatchIn(w))
    T.check("Stealth okuyucu UDP yolundayken bağlantı kurmaz", w.contains("if (!stealthMode) { try { Thread.sleep(250)"))
    T.check("kip değişimi bağlıyken uygulanır", w.contains("ACTION_MODE") && src("app/src/main/java/app/dnshizli/platform/MainActivity.kt").contains("WgVpnService.modeIntent("))
}
