package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

/** sizma39: Stealth — WebSocket çerçeveleri, [Stealth] yapılandırması, Go aktarıcısıyla (tools/stealth/sunucu) uçtan uca WireGuard. */
internal fun runRound15Tests() {
    wsTests()
    configTests()
    interopTests()
    deployStaticTests()
}

private fun deployStaticTests() {
    T.group("sizma39: Stealth servis, kurulum betiği ve iş akışı yapısı")
    fun src(p: String) = listOf(p, "../$p").map { File(it) }.firstOrNull { it.isFile }
    val w = src("app/src/main/java/app/dnshizli/platform/WgVpnService.kt")?.readText() ?: ""
    T.check("Stealth TCP soketi bağlanmadan önce korunur", Regex("""protect\(s\)[\s\S]{0,120}s\.connect\(a""").containsMatchIn(w))
    T.check("tünel kilidi ağ yazımında beklemez: gönderim kuyruk + ayrı yazıcı", w.contains("stealthOut.offer(it)") && w.contains("fun writeStealth("))
    T.check("yeniden bağlanınca reconnected() çağrılır, bayat kuyruk boşaltılır", Regex("""stealthOut\.clear\(\)[\s\S]{0,200}tunnel\?\.reconnected\(\)""").containsMatchIn(w))
    T.check("Stealth kipinde çözülen ad aktarıcınınkidir", w.contains("resolve(st.host, st.port)"))
    val kf = src("tools/stealth/kur.sh")
    val k = kf?.readText() ?: ""
    val syntax = kf != null && ProcessBuilder("bash", "-n", kf.path).start().waitFor() == 0
    T.check("kur.sh sözdizimi geçerli (bash -n)", syntax)
    T.check("ikili dosya SHA256SUMS ile doğrulanır", k.contains("sha256sum -c -"))
    T.check("aktarıcı root olmadan, sertleştirilmiş systemd birimiyle çalışır", k.contains("User=dhs") && k.contains("NoNewPrivileges=yes") && k.contains("ProtectSystem=strict") && k.contains("CapabilityBoundingSet=CAP_NET_BIND_SERVICE"))
    T.check("anahtarlar umask 077 ile üretilir, sunucu özel anahtarı yazdırılmaz", k.contains("umask 077; wg genkey") && !Regex("""echo[^\n]*wg\.key""").containsMatchIn(k))
    T.check("ortam girdileri doğrulanır (port, SNI, DNS)", k.contains("port sayı olmalı") && k.contains("DHS_SNI geçersiz") && k.contains("DHS_DNS geçersiz"))
    T.check("depo adı yayın sırasında işlenir", k.contains("DEPO=\"__DEPO__\""))
    val wf = src(".github/workflows/stealth-sunucu.yml")?.readText() ?: ""
    T.check("iş akışı: gofmt + vet + yarış denetimli test, statik derleme, özet dosyası", wf.contains("go test -race") && wf.contains("go vet") && wf.contains("CGO_ENABLED") && wf.contains("SHA256SUMS") && wf.contains("s#__DEPO__#"))
    T.check("iş akışı eylemleri SHA ile sabitli", Regex("""uses: [^@\s]+@[0-9a-f]{40}""").findAll(wf).count() == Regex("""uses: """).findAll(wf).count())
}

private fun b64(b: ByteArray) = java.util.Base64.getEncoder().encodeToString(b)

private fun wsTests() {
    T.group("sizma39: WebSocket çerçeveleri (RFC 6455 alt kümesi)")
    T.check("Accept: RFC 6455 §1.3 örneği", Ws.accept("dGhlIHNhbXBsZSBub25jZQ==") == "s3pPLMBiTxaQ9kYGzzhZRbK+xOo=")
    val rng = SecureRandom()
    var ok = true
    for (n in listOf(0, 1, 125, 126, 1500, 65535)) {
        val p = ByteArray(n).also { rng.nextBytes(it) }
        val f = Ws.frame(Ws.OP_BINARY, p, 0, n, byteArrayOf(9, 8, 7, 6))
        val h = if (n < 126) 2 else 4
        val len = if (n < 126) f[1].toInt() and 0x7F else ((f[2].toInt() and 0xFF) shl 8) or (f[3].toInt() and 0xFF)
        val un = ByteArray(n) { (f[h + 4 + it].toInt() xor f[h + (it and 3)].toInt()).toByte() }
        ok = ok && f[0].toInt() and 0xFF == 0x82 && f[1].toInt() and 0x80 != 0 && len == n && un.contentEquals(p) && (n < 126 || f[1].toInt() and 0x7F == 126)
    }
    T.check("istemci çerçevesi: maskeli, tek parça, en kısa uzunluk kodlaması, maske doğru", ok)
    fun srv(op: Int, p: ByteArray) = byteArrayOf((0x80 or op).toByte(), p.size.toByte()) + p
    val buf = ByteArray(70000)
    val f = Ws.read(ByteArrayInputStream(srv(2, "abc".toByteArray())), buf)
    T.check("sunucu çerçevesi okunur", f != null && f.op == 2 && f.len == 3 && String(buf, 0, 3) == "abc")
    T.check("akış sonu: null", Ws.read(ByteArrayInputStream(ByteArray(0)), buf) == null)
    fun rejects(b: ByteArray) = try { Ws.read(ByteArrayInputStream(b), buf); false } catch (_: IOException) { true }
    T.check("maskeli sunucu çerçevesi reddedilir", rejects(byteArrayOf(0x82.toByte(), 0x81.toByte(), 1, 2, 3, 4, 5)))
    T.check("parçalı çerçeve reddedilir", rejects(byteArrayOf(0x02, 1, 5)))
    T.check("ayrılmış bit reddedilir", rejects(byteArrayOf(0xC2.toByte(), 1, 5)))
    T.check("64 bit uzunluk reddedilir", rejects(byteArrayOf(0x82.toByte(), 127, 0, 0, 0, 0, 0, 0, 0, 1)))
    T.check("en kısa olmayan 126 kodlaması reddedilir", rejects(byteArrayOf(0x82.toByte(), 126, 0, 5, 1, 2, 3, 4, 5)))
    T.check("125'ten büyük ping reddedilir", rejects(byteArrayOf(0x89.toByte(), 126, 0, 126) + ByteArray(126)))
    T.check("metin çerçevesi reddedilir", rejects(srv(1, "x".toByteArray())))
    T.check("yarım çerçeve: hata", rejects(byteArrayOf(0x82.toByte(), 10, 1, 2)))
    val key = "dGhlIHNhbXBsZSBub25jZQ=="
    val good = "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo="
    T.check("101 + doğru Accept kabul", Ws.responseOk(good, key))
    T.check("yanlış Accept reddedilir", !Ws.responseOk(good.replace("s3pP", "AAAA"), key))
    T.check("404 (nginx tuzağı) reddedilir", !Ws.responseOk("HTTP/1.1 404 Not Found\r\nServer: nginx", key))
    T.check("Upgrade başlığı yoksa reddedilir", !Ws.responseOk(good.replace("Upgrade: websocket\r\n", ""), key))
    val req = String(Ws.request("www.example.com", "/gizli-yol-123456789", key))
    T.check("istek: tarayıcı benzeri başlıklar, gizli yol, sürüm 13", req.startsWith("GET /gizli-yol-123456789 HTTP/1.1\r\nHost: www.example.com\r\n") &&
        req.contains("Sec-WebSocket-Version: 13\r\n") && req.contains("User-Agent: Mozilla/5.0") && req.endsWith("\r\n\r\n"))
}

private fun cfg(stealth: String, peerEndpoint: String? = "203.0.113.9:51820"): WgConfig.Companion.Result {
    val priv = Wg.generatePrivate(); val pub = Wg.publicKey(Wg.generatePrivate())
    return WgConfig.parse("""
        [Interface]
        PrivateKey = ${b64(priv)}
        Address = 10.77.0.2/32
        [Peer]
        PublicKey = ${b64(pub)}
        AllowedIPs = 0.0.0.0/0
        ${if (peerEndpoint != null) "Endpoint = $peerEndpoint" else ""}
        $stealth
    """.trimIndent())
}

private fun configTests() {
    T.group("sizma39: [Stealth] yapılandırma bölümü")
    val pin = b64(ByteArray(32) { it.toByte() })
    val okS = "[Stealth]\nEndpoint = relay.example:443\nPin = $pin\nPath = /AbCdEfGhIjKlMnOpQr_-\nSNI = www.example.com"
    val r = cfg(okS)
    val c = (r as? WgConfig.Companion.Result.Ok)?.cfg
    T.check("geçerli bölüm okunur", c?.stealth?.let { it.host == "relay.example" && it.port == 443 && it.sni == "www.example.com" && it.path == "/AbCdEfGhIjKlMnOpQr_-" && it.pin.contentEquals(ByteArray(32) { i -> i.toByte() }) } == true,
        (r as? WgConfig.Companion.Result.Err)?.why ?: "")
    T.check("UDP uç noktası da korunur (ileride akıllı kip)", c?.hasUdpEndpoint == true && c.peer.endpointPort == 51820)
    val only = (cfg(okS, peerEndpoint = null) as? WgConfig.Companion.Result.Ok)?.cfg
    T.check("yalnızca Stealth: [Peer] Endpoint gerekmez, doğrudan UDP yok", only != null && !only.hasUdpEndpoint && only.stealth != null)
    T.check("Stealth yoksa Endpoint hâlâ zorunlu", cfg("", peerEndpoint = null) is WgConfig.Companion.Result.Err)
    fun err(s: String) = cfg(s) is WgConfig.Companion.Result.Err
    T.check("Pin eksik → hata", err("[Stealth]\nEndpoint = relay.example:443\nPath = /AbCdEfGhIjKlMnOpQr"))
    T.check("Path eksik → hata", err("[Stealth]\nEndpoint = relay.example:443\nPin = $pin"))
    T.check("Endpoint eksik → hata", err("[Stealth]\nPin = $pin\nPath = /AbCdEfGhIjKlMnOpQr"))
    T.check("kısa yol → hata", err("[Stealth]\nEndpoint = r.example:443\nPin = $pin\nPath = /kisa"))
    T.check("yolda boşluk/özel karakter → hata", err("[Stealth]\nEndpoint = r.example:443\nPin = $pin\nPath = /AbCdEfGhIjKlMnOp?q=1") && err("[Stealth]\nEndpoint = r.example:443\nPin = $pin\nPath = /AbCdEfGhIjKl%20MnOp"))
    T.check("yol / ile başlamazsa → hata", err("[Stealth]\nEndpoint = r.example:443\nPin = $pin\nPath = AbCdEfGhIjKlMnOpQrS"))
    T.check("Pin 32 bayt değilse → hata", err("[Stealth]\nEndpoint = r.example:443\nPin = ${b64(ByteArray(16))}\nPath = /AbCdEfGhIjKlMnOpQr"))
    T.check("SNI olarak IP → hata (SNI ad olmalı)", err("$okS\n".replace("SNI = www.example.com", "SNI = 1.2.3.4")))
    T.check("iki [Stealth] → hata", err("$okS\n[Stealth]\nEndpoint = a.example:443"))
    val noSni = (cfg("[Stealth]\nEndpoint = 198.51.100.7:443\nPin = $pin\nPath = /AbCdEfGhIjKlMnOpQr") as? WgConfig.Companion.Result.Ok)?.cfg
    T.check("SNI verilmezse null (IP'ye SNI'siz bağlanılır)", noSni?.stealth?.sni == null)
    val rig = Rig(Rig.base())
    rig.host.clipboard = """
        [Interface]
        PrivateKey = ${b64(Wg.generatePrivate())}
        Address = 10.77.0.2/32
        [Peer]
        PublicKey = ${b64(Wg.publicKey(Wg.generatePrivate()))}
        AllowedIPs = 0.0.0.0/0
        $okS
    """.trimIndent()
    rig.model.wgImportClipboard()
    T.check("özet Stealth'i gösterir", rig.model.wgSummary()?.contains("relay.example:443 · Stealth") == true, rig.model.wgSummary() ?: "")
}

/** Go aktarıcısını derler (yalnızca kaynak değişince). Go yoksa null. */
internal fun relayBinary(): File? {
    val src = listOf("tools/stealth/sunucu", "../tools/stealth/sunucu").map { File(it) }.firstOrNull { File(it, "main.go").isFile } ?: return null
    val go = listOf("/usr/local/go/bin/go", "/usr/bin/go").map { File(it) }.firstOrNull { it.canExecute() }?.path
        ?: System.getenv("PATH")?.split(File.pathSeparator)?.map { File(it, "go") }?.firstOrNull { it.canExecute() }?.path ?: return null
    val hash = ListUpdate.sha256Hex((src.listFiles { f -> f.name.endsWith(".go") || f.name == "go.mod" } ?: emptyArray()).sortedBy { it.name }
        .fold(ByteArray(0)) { acc, f -> acc + f.name.toByteArray() + f.readBytes() }).take(16)     // her .go dosyası değişince yeniden derlenir
    val out = File(System.getProperty("java.io.tmpdir"), "dhs-sunucu-$hash")
    if (out.canExecute()) return out
    val p = ProcessBuilder(go, "build", "-o", out.absolutePath, ".").directory(src).redirectErrorStream(true).start()
    val log = p.inputStream.bufferedReader().readText()
    if (!p.waitFor(180, TimeUnit.SECONDS) || p.exitValue() != 0) { println("  go build başarısız: $log"); return null }
    return out
}

private fun interopTests() {
    T.group("sizma39: Go aktarıcısı ile uçtan uca (TLS sabitleme + WebSocket + WireGuard)")
    val bin = relayBinary()
    if (bin == null) { T.check("Go yok: birlikte çalışma testi atlandı (CI'da Go kurulu)", true); return }
    val dir = File.createTempFile("dhs", "").also { it.delete(); it.mkdirs() }
    val gen = ProcessBuilder(bin.path, "-sertifika-uret", "-dizin", dir.path).redirectErrorStream(true).start()
    val genOut = gen.inputStream.bufferedReader().readText(); gen.waitFor(30, TimeUnit.SECONDS)
    val pinS = Regex("Pin = (\\S+)").find(genOut)?.groupValues?.get(1)
    val path = Regex("Path = (\\S+)").find(genOut)?.groupValues?.get(1)
    T.check("sunucu sertifika + gizli yol üretir", pinS != null && path != null && WgConfig.pathOk(path), genOut)
    if (pinS == null || path == null) return
    val pin = java.util.Base64.getDecoder().decode(pinS)

    // Sahte WireGuard sunucusu (UDP): el sıkışmasını yanıtlar, gelen IP paketini adresleri değiştirip geri yollar.
    val sPriv = Wg.generatePrivate(); val cPriv = Wg.generatePrivate()
    val res = WgResponder(sPriv).also { it.addPeer(WgResponder.Peer(Wg.publicKey(cPriv))) }
    val udp = DatagramSocket(0, InetAddress.getLoopbackAddress())
    var srvSession: WgSession? = null
    var srvSeen = 0
    val wgThread = Thread {
        val b = ByteArray(70000)
        while (!udp.isClosed) {
            val dp = DatagramPacket(b, b.size)
            try { udp.receive(dp) } catch (_: Exception) { break }
            val m = b.copyOf(dp.length)
            val reply: ByteArray? = when (m[0].toInt()) {
                Wg.TYPE_INITIATION -> res.consumeInitiation(m, 0, m.size)?.let { i -> res.respond(i, 0x77, System.currentTimeMillis())!!.let { (r, s) -> srvSession = s; r } }
                Wg.TYPE_DATA -> srvSession?.let { s ->
                    val pt = s.decrypt(m, 0, m.size, System.currentTimeMillis()) ?: return@let null
                    if (pt.isEmpty()) return@let null
                    srvSeen++
                    val n = WgTunnel.innerLength(pt)!!; val p = pt.copyOf(n)
                    val src = p.copyOfRange(12, 16); System.arraycopy(p, 16, p, 12, 4); System.arraycopy(src, 0, p, 16, 4)
                    s.encrypt(p, 0, n, System.currentTimeMillis())
                }
                else -> null
            }
            if (reply != null) try { udp.send(DatagramPacket(reply, reply.size, dp.socketAddress)) } catch (_: Exception) {}
        }
    }.also { it.isDaemon = true; it.start() }

    val port = ServerSocket(0, 1, InetAddress.getLoopbackAddress()).use { it.localPort }
    val proc = ProcessBuilder(bin.path, "-dinle", "127.0.0.1:$port", "-dizin", dir.path, "-wg", "127.0.0.1:${udp.localPort}").redirectErrorStream(true).start()
    try {
        val addr = InetSocketAddress(InetAddress.getLoopbackAddress(), port)
        var up = false
        repeat(50) { if (!up) { up = try { Socket().use { s -> s.connect(addr, 200) }; true } catch (_: Exception) { Thread.sleep(100); false } } }
        T.check("aktarıcı dinliyor", up)
        val st = StealthCfg("127.0.0.1", port, "www.example.com", path, pin)
        val plain: (InetSocketAddress) -> Socket = { a -> Socket().also { it.connect(a, 3000) } }

        fun failsWith(c: StealthCfg): String? = try { StealthClient.open(c, addr, plain).close(); null } catch (e: IOException) { e.toString() }
        val badPin = failsWith(StealthCfg("127.0.0.1", port, "www.example.com", path, ByteArray(32)))
        T.check("yanlış pin: TLS reddedilir (araya giren sertifika kabul edilmez)", badPin != null && (badPin.contains("SSL") || badPin.contains("Certificate") || badPin.contains("sabitlenen")), badPin ?: "bağlandı!")
        val badPath = failsWith(StealthCfg("127.0.0.1", port, "www.example.com", path + "x", pin))
        T.check("yanlış yol: aktarıcı nginx 404 verir, yükseltme yok", badPath != null && badPath.contains("404"), badPath ?: "bağlandı!")
        val noSni = failsWith(StealthCfg("127.0.0.1", port, null, path, pin))
        T.check("SNI'siz (IP) bağlantı da çalışır", noSni == null, noSni ?: "")

        // Gerçek akış: WgTunnel ⇄ StealthSession ⇄ Go aktarıcı ⇄ UDP ⇄ sahte WireGuard
        val conf = (WgConfig.parse("""
            [Interface]
            PrivateKey = ${b64(cPriv)}
            Address = 10.77.0.2/32
            [Peer]
            PublicKey = ${b64(Wg.publicKey(sPriv))}
            AllowedIPs = 0.0.0.0/0
            [Stealth]
            Endpoint = 127.0.0.1:$port
            Pin = $pinS
            Path = $path
            SNI = www.example.com
        """.trimIndent()) as WgConfig.Companion.Result.Ok).cfg
        val sess = StealthClient.open(conf.stealth!!, addr, plain)
        val tunOut = java.util.Collections.synchronizedList(ArrayList<ByteArray>())
        val tunnel = WgTunnel(conf, { sess.send(it) }, { b, o, l -> tunOut.add(b.copyOfRange(o, o + l)) })
        val reader = Thread {
            val b = ByteArray(70000)
            try { while (true) { val n = sess.receive(b); if (n < 0) break; tunnel.fromNet(b, 0, n) } } catch (_: Exception) {}
        }.also { it.isDaemon = true; it.start() }
        val pkts = listOf(64, 1200, 1400).map { n ->
            val p = ByteArray(n); p[0] = 0x45; Packets.put16(p, 2, n); p[8] = 64; p[9] = 17
            System.arraycopy(byteArrayOf(10, 77, 0, 2), 0, p, 12, 4); System.arraycopy(byteArrayOf(9, 9, 9, 9), 0, p, 16, 4)
            for (i in 28 until n) p[i] = (i * 7).toByte()
            p
        }
        for (p in pkts) tunnel.fromTun(p, p.size)
        val deadline = System.currentTimeMillis() + 8000
        while (tunOut.size < pkts.size && System.currentTimeMillis() < deadline) Thread.sleep(20)
        T.check("el sıkışma aktarıcı üzerinden tamamlandı", tunnel.handshakes == 1L && tunnel.connected)
        val back = synchronized(tunOut) { tunOut.toList() }
        T.check("3 paket gitti, sunucu cevapları tünelden çözülüp geri geldi (adresler takas)", back.size == 3 && srvSeen == 3 &&
            back.zip(pkts).all { (b, p) -> b.size == p.size && b.copyOfRange(12, 16).contentEquals(p.copyOfRange(16, 20)) && b.copyOfRange(20, b.size).contentEquals(p.copyOfRange(20, p.size)) },
            "geri=${back.size} sunucu=$srvSeen")
        // Taşıma yenilendi: yeni oturumla devam (sunucu yeni kaynak portu görür; canlı tutma uç noktayı günceller)
        sess.close(); reader.join(2000)
        val sess2 = StealthClient.open(conf.stealth!!, addr, plain)
        val t2out = java.util.Collections.synchronizedList(ArrayList<ByteArray>())
        val tunnel2 = WgTunnel(conf, { sess2.send(it) }, { b, o, l -> t2out.add(b.copyOfRange(o, o + l)) })
        Thread { val b = ByteArray(70000); try { while (true) { val n = sess2.receive(b); if (n < 0) break; tunnel2.fromNet(b, 0, n) } } catch (_: Exception) {} }.also { it.isDaemon = true; it.start() }
        tunnel2.reconnected()
        val d2 = System.currentTimeMillis() + 8000
        while (!tunnel2.connected && System.currentTimeMillis() < d2) Thread.sleep(20)
        tunnel2.fromTun(pkts[0], pkts[0].size)
        while (t2out.isEmpty() && System.currentTimeMillis() < d2) Thread.sleep(20)
        T.check("yeniden bağlanınca reconnected() el sıkışmayı hemen başlatır, trafik sürer", tunnel2.connected && t2out.size == 1)
        sess2.close(); tunnel.close(); tunnel2.close()
    } finally {
        proc.destroy(); proc.waitFor(5, TimeUnit.SECONDS); proc.destroyForcibly()
        udp.close(); wgThread.join(1000)
        dir.deleteRecursively()
    }
}
