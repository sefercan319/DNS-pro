package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.Strings
import java.io.File
import java.util.ArrayDeque

/** sizma46: çoklu atlama — WireGuard içinde WireGuard (giriş → çıkış), "gerektiğinde" kararı, arayüz, servis yapısı. */
internal fun runRound22Tests() {
    chainTests()
    planTests()
    e2eTests()
    uiTests()
    staticTests()
}

private fun b64(b: ByteArray) = java.util.Base64.getEncoder().encodeToString(b)

private fun chainTests() {
    T.group("sizma46: sarma / açma (WgChain)")
    val src = byteArrayOf(10, 1, 0, 2); val exit = byteArrayOf(203.toByte(), 0, 113, 50)
    val c = WgChain(src, exit, 51820)
    val pl = ByteArray(148) { it.toByte() }
    val w = c.wrap(pl)
    T.check("IPv4/UDP sarma: başlıklar, DF, sağlama toplamları geçerli", w.size == 28 + 148 && w[9].toInt() == 17 && (Packets.u16(w, 6) and 0x4000) != 0 &&
        Packets.checksum(w, 0, 20) == 0 && Packets.udpChecksumOk(w, 20, w.size - 20, Packets.i32(w, 12), Packets.i32(w, 16)) && Packets.u16(w, 22) == 51820)
    // dönüş: çıkıştan bize
    val back = w.copyOf(); System.arraycopy(exit, 0, back, 12, 4); System.arraycopy(src, 0, back, 16, 4); Packets.put16(back, 20, 51820); Packets.put16(back, 22, 51821)
    WgDnsForwarder.fixChecksums(back, back.size, false, 20)
    T.check("çıkıştan gelen cevap açılır", c.unwrap(back, back.size)?.contentEquals(pl) == true)
    val f0 = c.foreign
    val wrongSrc = back.copyOf().also { it[15] = 99 }
    val wrongPort = back.copyOf().also { Packets.put16(it, 22, 1234) }
    val tcp = back.copyOf().also { it[9] = 6 }
    val frag = back.copyOf().also { Packets.put16(it, 6, 0x2000) }
    T.check("başka kaynak / port / TCP / parça / kısa paket tün'e gitmez", listOf(wrongSrc, wrongPort, tcp, frag).all { c.unwrap(it, it.size) == null } && c.unwrap(back, 10) == null && c.foreign == f0 + 5)
    val c6 = WgChain(Ip.parse("fd00::2")!!, Ip.parse("2001:db8::50")!!, 51820)
    val w6 = c6.wrap(pl)
    T.check("IPv6 sarma", w6.size == 48 + 148 && (w6[0].toInt() ushr 4) == 6 && w6[6].toInt() == 17)
    T.check("MTU payı: iki katman", WgChain.innerMtu(1420, false) == 1360 && WgChain.innerMtu(1420, true) == 1340)
    T.check("aile uyumsuzluğu reddedilir", runCatching { WgChain(src, Ip.parse("2001:db8::1")!!, 1) }.isFailure)
}

private fun planTests() {
    T.group("sizma46: gerektiğinde çoklu atlama (HopPlan)")
    val a = HopPlan(HopPlan.Mode.AUTO, 0)
    T.check("otomatik: doğrudan başlar", !a.chained)
    T.check("19 sn cevapsız: henüz geçmez", !a.onTick(19_000, 19_000))
    T.check("20 sn cevapsız: zincire geçer (bir kez)", a.onTick(20_000, 20_000) && a.chained && !a.onTick(60_000, 60_000))
    T.check("ağ değişince doğrudan yeniden denenir", a.onNetworkChanged(70_000) && !a.chained)
    T.check("ağ değişiminden sonra süre baştan sayılır", !a.onTick(80_000, 50_000) && a.onTick(90_000, 50_000))
    T.check("her zaman: baştan zincir", HopPlan(HopPlan.Mode.ALWAYS, 0).chained)
    T.check("kapalı: asla", HopPlan(HopPlan.Mode.OFF, 0).let { !it.chained && !it.onTick(1_000_000, 1_000_000) })
    T.check("el sıkışma yokken geçiş yok", !HopPlan(HopPlan.Mode.AUTO, 0).onTick(1_000_000, -1))
}

/** Süreç içi iki WireGuard sunucusu: giriş (A) zincir paketini "internete" (B'ye) iletir, çıkış (B) iç tüneli sonlandırır. */
private fun e2eTests() {
    T.group("sizma46: uçtan uca — telefon → giriş → çıkış")
    var clock = 1000L
    val cPrivA = Wg.generatePrivate(); val aPriv = Wg.generatePrivate(); val cPrivB = Wg.generatePrivate(); val bPriv = Wg.generatePrivate()
    val aIp = byteArrayOf(198.toByte(), 51, 100, 1); val bIp = byteArrayOf(203.toByte(), 0, 113, 50)
    val entryCfg = (WgConfig.parse("[Interface]\nPrivateKey = ${b64(cPrivA)}\nAddress = 10.1.0.2/32\n[Peer]\nPublicKey = ${b64(Wg.publicKey(aPriv))}\nAllowedIPs = 0.0.0.0/0\nEndpoint = 198.51.100.1:51820") as WgConfig.Companion.Result.Ok).cfg
    val exitCfg = (WgConfig.parse("[Interface]\nPrivateKey = ${b64(cPrivB)}\nAddress = 10.2.0.2/32\n[Peer]\nPublicKey = ${b64(Wg.publicKey(bPriv))}\nAllowedIPs = 0.0.0.0/0\nEndpoint = 203.0.113.50:51820") as WgConfig.Companion.Result.Ok).cfg
    val resA = WgResponder(aPriv).also { it.addPeer(WgResponder.Peer(Wg.publicKey(cPrivA))) }
    val resB = WgResponder(bPriv).also { it.addPeer(WgResponder.Peer(Wg.publicKey(cPrivB))) }
    var sA: WgSession? = null; var sB: WgSession? = null
    val toPhone = ArrayDeque<ByteArray>()            // ağdan telefona (A'dan gelen UDP yükleri)
    val aSaw = ArrayList<ByteArray>()                // A'nın çözdüğü iç paketler (A'nın görebildiği her şey)
    var bSawFrom: ByteArray? = null                  // B'nin gördüğü kaynak adres (A'nın NAT adresi olmalı)
    val bPlain = ArrayList<ByteArray>()              // B'nin çözdüğü uygulama paketleri
    val tunOut = ArrayList<ByteArray>()
    lateinit var bReply: (ByteArray) -> Unit
    fun serverB(from: ByteArray, m: ByteArray) {
        bSawFrom = from
        when (m[0].toInt()) {
            Wg.TYPE_INITIATION -> resB.consumeInitiation(m, 0, m.size)?.let { i -> val (r, s) = resB.respond(i, 9, clock)!!; sB = s; bReply(r) }
            Wg.TYPE_DATA -> sB?.decrypt(m, 0, m.size, clock)?.let { pt -> if (pt.isNotEmpty()) {
                val p = pt.copyOf(WgTunnel.innerLength(pt)!!); bPlain.add(p)
                val r = p.copyOf(); val s4 = r.copyOfRange(12, 16); System.arraycopy(r, 16, r, 12, 4); System.arraycopy(s4, 0, r, 16, 4)
                bReply(sB!!.encrypt(r, 0, r.size, clock)!!)
            } }
        }
    }
    fun serverA(m: ByteArray) {
        when (m[0].toInt()) {
            Wg.TYPE_INITIATION -> resA.consumeInitiation(m, 0, m.size)?.let { i -> val (r, s) = resA.respond(i, 7, clock)!!; sA = s; toPhone.add(r) }
            Wg.TYPE_DATA -> sA?.decrypt(m, 0, m.size, clock)?.let { pt -> if (pt.isNotEmpty()) {
                val p = pt.copyOf(WgTunnel.innerLength(pt)!!); aSaw.add(p)
                // A: hedefe (B) NAT ile iletir; kaynak A'nın adresi olur
                if (p.copyOfRange(16, 20).contentEquals(bIp)) serverB(aIp, p.copyOfRange(28, p.size))
            } }
        }
    }
    val chain = WgChain(byteArrayOf(10, 1, 0, 2), bIp, 51820)
    lateinit var inner: WgTunnel
    val outer = WgTunnel(entryCfg, { m -> serverA(m) }, { b, o, l -> chain.unwrap(b.copyOfRange(o, o + l), l)?.let { inner.fromNet(it, 0, it.size) } }, now = { clock })
    inner = WgTunnel(exitCfg, { m -> val w = chain.wrap(m); outer.fromTun(w, w.size) }, { b, o, l -> tunOut.add(b.copyOfRange(o, o + l)) }, now = { clock })
    bReply = { r ->
        // B'nin cevabı A'ya; A geri NAT'layıp telefonun tünel adresine sarar ve şifreler
        val back = chain.wrap(r).also { System.arraycopy(bIp, 0, it, 12, 4); System.arraycopy(byteArrayOf(10, 1, 0, 2), 0, it, 16, 4); Packets.put16(it, 20, 51820); Packets.put16(it, 22, 51821); WgDnsForwarder.fixChecksums(it, it.size, false, 20) }
        toPhone.add(sA!!.encrypt(back, 0, back.size, clock)!!)
    }
    fun pump() { var g = 0; while (toPhone.isNotEmpty() && g++ < 100) { val m = toPhone.removeFirst(); outer.fromNet(m, 0, m.size) } }
    val app = ByteArray(84).also { it[0] = 0x45; Packets.put16(it, 2, 84); it[8] = 64; it[9] = 17; System.arraycopy(byteArrayOf(10, 2, 0, 2), 0, it, 12, 4); System.arraycopy(byteArrayOf(1, 1, 1, 1), 0, it, 16, 4); for (k in 28 until 84) it[k] = 0x5A }
    inner.fromTun(app, app.size)
    repeat(10) { clock += 200; outer.tick(); inner.tick(); pump() }
    T.check("dış (giriş) ve iç (çıkış) el sıkışmaları tamamlandı", outer.connected && inner.connected)
    T.check("uygulama paketi çıkışta çözüldü, cevabı tün'e geldi", bPlain.any { it.copyOfRange(28, 84).all { b -> b == 0x5A.toByte() } } && tunOut.isNotEmpty() && tunOut.last().copyOfRange(12, 16).contentEquals(byteArrayOf(1, 1, 1, 1)))
    T.check("çıkış sunucusu telefonu değil giriş sunucusunu görür", bSawFrom?.contentEquals(aIp) == true)
    T.check("giriş sunucusu yalnız çıkışa giden şifreli WireGuard paketlerini görür (içerik ve hedef site görünmez)",
        aSaw.isNotEmpty() && aSaw.all { it.copyOfRange(16, 20).contentEquals(bIp) && Packets.u16(it, 22) == 51820 } &&
            aSaw.none { p -> (0..p.size - 56).any { k -> (0 until 56).all { j -> p[k + j] == 0x5A.toByte() } } })
}

private fun uiTests() {
    T.group("sizma46: arayüz — giriş sunucusu ve kip")
    fun conf(endpoint: String?, priv: ByteArray = Wg.generatePrivate(), pub: ByteArray = Wg.publicKey(Wg.generatePrivate()), stealth: Boolean = false) =
        "[Interface]\nPrivateKey = ${b64(priv)}\nAddress = 10.9.0.2/32\n[Peer]\nPublicKey = ${b64(pub)}\nAllowedIPs = 0.0.0.0/0\n" +
            (if (endpoint != null) "Endpoint = $endpoint\n" else "") + (if (stealth) "[Stealth]\nEndpoint = 203.0.113.9:443\nPin = ${b64(ByteArray(32))}\nPath = /AbCdEfGhIjKlMnOpQr\n" else "")
    val exitPub = Wg.publicKey(Wg.generatePrivate())
    val r = Rig(Rig.base())
    r.host.wgText = conf("203.0.113.50:51820", pub = exitPub)
    r.model.wgSetHop(HopPlan.Mode.ALWAYS)
    T.check("giriş sunucusu yokken kip açılmaz", r.host.wgHopId == "off" && r.model.toast?.text == Strings.WG_HOP_NEED_ENTRY)
    r.host.clipboard = conf("198.51.100.1:51820", pub = exitPub)
    r.model.wgImportEntryClipboard()
    T.check("aynı sunucu giriş olamaz", r.host.wgEntry == null && r.model.toast?.text == Strings.WG_HOP_SAME)
    r.host.clipboard = conf("198.51.100.1:51820")
    r.model.wgImportEntryClipboard()
    T.check("giriş sunucusu kaydedilir", r.host.wgEntry != null && r.model.toast?.text == Strings.WG_HOP_SAVED && r.model.wgEntrySummary() == "198.51.100.1:51820")
    r.host.wgOn = true
    r.model.wgSetHop(HopPlan.Mode.AUTO)
    T.check("bağlıyken kip değişince yeniden bağlanır", r.host.wgHopId == "auto" && r.host.calls.indexOf("wgDisconnect") >= 0 && r.host.calls.lastIndexOf("wgConnect") > r.host.calls.lastIndexOf("wgDisconnect"))
    r.model.wgDeleteEntry()
    T.check("giriş silinince kip kapanır", r.host.wgEntry == null && r.host.wgHopId == "off")
    val r2 = Rig(Rig.base())
    r2.host.wgText = conf(null, stealth = true)
    r2.host.clipboard = conf("198.51.100.1:51820")
    r2.model.wgImportEntryClipboard()
    T.check("çıkışın UDP uç noktası yoksa reddedilir", r2.host.wgEntry == null && r2.model.toast?.text == Strings.WG_HOP_EXIT_UDP)
    T.check("Türkçe metinler", Strings.wgHopName("auto") == "Gerektiğinde" && Strings.WG_HOP == "Çoklu atlama")
}

private fun staticTests() {
    T.group("sizma46: servis yapısı")
    val w = listOf("app/src/main/java/app/dnshizli/platform/WgVpnService.kt", "../app/src/main/java/app/dnshizli/platform/WgVpnService.kt").map { File(it) }.first { it.isFile }.readText()
    T.check("yol yeniden kurulurken tün açık kalır, eski okuyucular nesille çıkar", w.contains("@Synchronized private fun setupPath(chained: Boolean)") && w.contains("while (!stopping && my == gen)") && w.contains("closePath()"))
    T.check("zincirde ağ tüneline yalnız sarılmış iç paket gider; dönüşte yalnız açılabilen iç tünele", w.contains("ch.wrap(m); tunnel?.fromTun(w, w.size)") && w.contains("ch.unwrap(p, l)?.let { w -> inner?.fromNet(w, 0, w.size) }"))
    T.check("tün reader çıkışı (iç tünel) besler; DNS iç tünelden", w.contains("private val entry: WgTunnel? get() = inner ?: tunnel") && w.contains("WgDnsForwarder(e, writeTun"))
    T.check("zincir olasıysa tün MTU'su iki katmana göre küçülür", w.contains("WgChain.innerMtu(ent.mtu, true)"))
    T.check("gerektiğinde: doğrudan olmazsa zincir, ağ değişince doğrudan", w.contains("hop?.onTick(System.currentTimeMillis(), t.handshakePendingMs()) == true") && w.contains("hop?.onNetworkChanged(System.currentTimeMillis()) == true) { setupPath(false)"))
    T.check("giriş sunucusunun adları da tün kurulmadan çözülür", w.indexOf("resolveAll(ent)") in 1 until w.indexOf("establish(cfg, mtu)"))
    val st = listOf("app/src/main/java/app/dnshizli/platform/WgStore.kt", "../app/src/main/java/app/dnshizli/platform/WgStore.kt").map { File(it) }.first { it.isFile }.readText()
    T.check("giriş yapılandırması da Keystore ile sıkı sarılı", Regex("""fun saveEntry[\s\S]{0,120}sealStrict""").containsMatchIn(st))
}
