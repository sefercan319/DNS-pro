package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File

/** sizma50: dış denetim raporu (oto-koruma 78) bulguları — her biri doğrulandı, düzeltildi ve burada sınanıyor. */
internal fun runRound26Tests() {
    pqStrictTests()
    linkTests()
    lockTests()
    misc()
}

private fun src(p: String) = listOf(p, "../$p").map { File(it) }.firstOrNull { it.isFile }?.readText() ?: ""
private val W by lazy { src("app/src/main/java/app/dnshizli/platform/WgVpnService.kt") }

private fun pqStrictTests() {
    T.group("sizma50: VULN-01 — PqPin katı kip (düşürme yok)")
    T.check("katı kipte hiçbir hata kodu (kimliksiz ERR çerçevesi) 'devam' sayılmaz", W.contains("if (cfg.stealth?.pqPin != null) return false              // katı kip"))
    T.check("katı kipte skipPqOnce ile PQ'suz yeniden bağlanma yok", W.contains("if (st.pq && (strict || !skipPqOnce))") && W.contains("if (!ok && strict) {"))
    T.check("UDP yolunda doğrulanmış PQ PSK'si yoksa tünel bekletilir (klasik PSK ile el sıkışılmaz), 30 sn'de bir yeniden denenir",
        W.contains("if (st.pqPin != null && saved == null) t.hold = true") && W.contains("if (t.hold && !stealthMode && System.currentTimeMillis() - lastPqTry > 30_000L)"))
    T.check("PQ alınınca bekleyen tünel hemen el sıkışır", W.contains("if (t.hold) { t.hold = false; t.reconnected() }"))
    T.check("çoklu atlamada çıkış için doğrulanmış PSK yoksa (katı) iç tünel bekletilir; bildirimde PQ ancak iki tünelde de varsa",
        W.contains("else if (exit.stealth?.pqPin != null) { inn.hold = true") && W.contains("(inner?.pskFromPq ?: true)"))
    T.check("kimlik hatası kullanıcıya bildirilir", W.contains("Notifier.securityAlert(this, Strings.WG_PQ_IDENTITY_FAIL)"))
    // çekirdek: hold iken el sıkışma gitmez, kalkınca gider
    val b64 = { b: ByteArray -> java.util.Base64.getEncoder().encodeToString(b) }
    val cfg = (WgConfig.parse("[Interface]\nPrivateKey = ${b64(Wg.generatePrivate())}\nAddress = 10.7.0.2/32\n[Peer]\nPublicKey = ${b64(Wg.publicKey(Wg.generatePrivate()))}\nAllowedIPs = 0.0.0.0/0\nEndpoint = 203.0.113.1:51820") as WgConfig.Companion.Result.Ok).cfg
    val sent = ArrayList<ByteArray>()
    val t = WgTunnel(cfg, { sent.add(it) }, { _, _, _ -> }, now = { 1000L })
    t.hold = true
    val p = ByteArray(40).also { it[0] = 0x45; Packets.put16(it, 2, 40); System.arraycopy(byteArrayOf(1, 1, 1, 1), 0, it, 16, 4) }
    t.fromTun(p, p.size); t.tick(); t.reconnected()
    T.check("hold: veri gelse de, tick ya da yeniden bağlanmada el sıkışma GİTMEZ", sent.isEmpty())
    t.hold = false; t.reconnected()
    T.check("hold kalkınca el sıkışma gider (kuyruktaki paket sonra iletilir)", sent.size == 1 && sent[0][0].toInt() == Wg.TYPE_INITIATION)
}

private fun linkTests() {
    T.group("sizma50: VULN-02 — bağlantı denetimi atlatmaları")
    T.check("ters bölü ile resmî alan beyaz listesi atlatılamaz", LinkCheck.check("https://oltalama-sitesi.com\\.ziraatbank.com.tr/giris").let { it.host == "oltalama-sitesi.com" && it.level != LinkCheck.Level.OK })
    T.check("şemasız Kiril başlangıçlı bağlantı kırpılmaz (а = Kiril)", LinkCheck.extract("Hesabınız kısıtlandı: аkbank.com/giris").firstOrNull()?.startsWith("аkbank") == true)
    T.check("…ve TEHLİKE olarak işaretlenir", LinkCheck.check(LinkCheck.extract("Hesabınız kısıtlandı: аkbank.com/giris").first()).level == LinkCheck.Level.DANGER)
    T.check("kısa marka + tuzak sözcük birleşik (pttkargo, sgkborc, qnbmobil, gibodeme) → TEHLİKE",
        listOf("https://pttkargo.com", "https://sgkborc.com", "https://qnbmobil.com", "https://gibodeme.net", "https://kargo-ptt.xyz").all { LinkCheck.check(it).level == LinkCheck.Level.DANGER })
    T.check("…ama birleşik olmayan kısa marka içeren meşru adlar alarm vermez", LinkCheck.check("https://optimum.com").level == LinkCheck.Level.OK && LinkCheck.check("https://www.ptt.gov.tr/kargo").level == LinkCheck.Level.OK)
    val lw = src("app/src/main/java/app/dnshizli/platform/LinkWatchService.kt")
    T.check("bildirim: yakın zamanda uyarılan bağlantı sonrakileri atlatmaz (continue)", lw.contains("if (!fresh) continue") && !lw.contains("> now - 600_000L) return"))
    val act = src("app/src/main/java/app/dnshizli/platform/MainActivity.kt")
    T.check("uygulama açıkken paylaşım (onNewIntent) da denetlenir", Regex("""fun onNewIntent[\s\S]{0,600}Intent\.ACTION_SEND""").containsMatchIn(act))
}

private fun lockTests() {
    T.group("sizma50: VULN-03/04 — kilit ekranı ve ana iş parçacığı")
    val tile = src("app/src/main/java/app/dnshizli/platform/DnsTileService.kt")
    T.check("kutucuk WireGuard açıkken DNS kipini başlatmaz; WireGuard'ı yalnız kilit açılınca keser", Regex("""if \(WgVpnService\.running\) \{[\s\S]{0,300}if \(isLocked\) unlockAndRun \{ stopWg\(\) \}""").containsMatchIn(tile) &&
        tile.indexOf("if (WgVpnService.running)") < tile.indexOf("DnsVpnService.connectIntent"))
    T.check("kutucuk WireGuard'ı etkin gösterir", tile.contains("tile.state = if (ui.running || wg)"))
    T.check("widget ve bildirim eylemleri WireGuard'ı düşürmez", src("app/src/main/java/app/dnshizli/platform/DnsWidget.kt").contains("if (WgVpnService.running) {") && src("app/src/main/java/app/dnshizli/platform/ActionReceiver.kt").contains("if (WgVpnService.running) return"))
    val dns = src("app/src/main/java/app/dnshizli/platform/DnsVpnService.kt")
    T.check("DNS servisi de WireGuard açıkken başlatma komutlarını yok sayar (yalnız arayüz açıkça ister)", dns.contains("val wgBlocks = WgVpnService.running && intent?.getBooleanExtra(EXTRA_REPLACE_WG, false) != true") &&
        src("app/src/main/java/app/dnshizli/platform/MainActivity.kt").contains("replaceWg = WgVpnService.running"))
    T.check("WireGuard bildirimindeki Kes düğmesi kilit açmayı ister (setAuthenticationRequired)", src("app/src/main/java/app/dnshizli/platform/Notifier.kt").contains(".setAuthenticationRequired(true)") &&
        Regex("""fun wireGuard[\s\S]{0,600}addAction\(button\(""").containsMatchIn(src("app/src/main/java/app/dnshizli/platform/Notifier.kt")))
    T.check("kip / gizleme değişimi ana iş parçacığında soket yazmaz", Regex("""ACTION_MODE\) \{[\s\S]{0,500}Thread\(\{[\s\S]{0,200}applyShaping\(\)[\s\S]{0,40}"wg-mode"\)""").containsMatchIn(W))
}

private fun misc() {
    T.group("sizma50: VULN-05..08")
    val k = src("tools/stealth/kur.sh")
    T.check("kur.sh: yeni istemci eklerken wg syncconf yok (aktif PQ PSK'leri ezilmez); yalnız yeni eş eklenir", !k.contains("wg syncconf dhs0") && k.contains("wg set dhs0 peer \"\$(cat \"\$cdir/pub\")\" preshared-key"))
    T.check("aktarıcı kalıcı durum dizini (yeniden başlatmada tekrar koruması)", k.contains("-durum /var/lib/dhs") && k.contains("StateDirectory=dhs"))
    val pq = src("tools/stealth/sunucu/pq.go")
    T.check("aktarıcı: aynı eşin değişimleri sıralı (wg set yarışı yok), son zaman kalıcı", pq.contains("unlock := q.lockPeer(pub)") && pq.contains("ts.Unix() <= last") && pq.contains("q.accepted(pub, ts)"))
    T.check("aktarıcı: örtü trafiği yalnız WireGuard cevabından sonra", src("tools/stealth/sunucu/shape.go").contains("!s.wgSeen.Load()"))
    val lu = src("app/src/main/java/app/dnshizli/platform/ListUpdater.kt")
    T.check("liste güncelleyici: sıklık sınırı imza doğrulandıktan SONRA yazılır", lu.indexOf("verifySignature(manifest, sig, key)") in 1 until lu.indexOf("putLong(KEY_CHECKED, System.currentTimeMillis())"))
    T.check("engelli liste: gelecekten donma koruması ve açılışta imza yeniden doğrulanır", lu.contains("ListUpdate.isNewerVersion(prefs.getLong(KEY_BLOCKED, 0L), p.version)") && lu.contains("BlockedSites.verified(bytes, sf.readBytes(), key)"))
    val now = 1_800_000_000L
    T.check("isNewerVersion: ileri tarihli sürüm reddedilir, zehirli kurulu sürüm düzelir", !ListUpdate.isNewerVersion(1, now + 40L * 86400, now) && ListUpdate.isNewerVersion(now + 400L * 86400, now, now) && !ListUpdate.isNewerVersion(now, now, now) && ListUpdate.isNewerVersion(now, now + 1, now))
    T.check("WireGuard'da uygulama kapsamı uygulanır", W.contains("applyScope(b)") && W.contains("addDisallowedApplication(p)"))
    T.check("kopuk tünelde ad çözümü tünele gitmez (alttaki ağdan, seyrek)", W.contains("if (++failures % 4 == 0) resolveOutside(st.host, st.port)") && W.contains("NET_CAPABILITY_NOT_VPN"))
    T.check("çoklu atlama: giriş MTU'su yetmezse zincir kurulmaz (taşma yok), arayüz de reddeder", W.contains("chainMtu < 1280") && src("app/src/main/java/app/dnshizli/ui/Model.kt").contains("if (WgChain.innerMtu(c.mtu, true) < 1280) { toast(Strings.WG_HOP_MTU)"))
    T.check("tarayıcı kipi: tek 'broken pipe' 10 dk susturmaz, açık TLS reddi hemen", MitmProxy.rejectKind(java.io.IOException("Broken pipe")) == 1 &&
        MitmProxy.rejectKind(javax.net.ssl.SSLHandshakeException("Received fatal alert: certificate_unknown")) == 2 && MitmProxy.rejectKind(java.io.EOFException("eof")) == 0 &&
        MitmProxy.rejectKind(java.io.IOException("x", java.io.IOException("Broken pipe"))) == 1)
}
