package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.Section
import java.io.File

/** sizma53: gizlilik raporu — uygulama başına 7 günlük kalıcı izleyici dökümü. */
internal fun runRound29Tests() {
    privacyCore()
    privacyPersist()
    privacyWiring()
    privacyUi()
    globeIdle()
    PrivacyReport.reset(); AppAds.reset(); FilterLive.keep(true)
}

private const val DAY = 86_400_000L

private fun privacyCore() {
    T.group("sizma53: gizlilik raporu: sayım ve günler")
    PrivacyReport.reset(); FilterLive.keep(true)
    var now = 1_800_000_000_000L
    PrivacyReport.clock = { now }; PrivacyReport.zoneOffset = { 0 }
    repeat(5) { PrivacyReport.record("com.instagram.android", "graph.facebook.com") }
    repeat(3) { PrivacyReport.record("com.instagram.android", "Ads.Example.NET.") }
    PrivacyReport.record("com.instagram.android", "t.example.org")
    PrivacyReport.record("com.oyun.app", "ads.example.net")
    var r = PrivacyReport.report()
    T.check("uygulama başına toplam, farklı alan sayısı ve sıralama (en çok engellenen başta)",
        r.size == 2 && r[0].pkg == "com.instagram.android" && r[0].blocked == 9 && r[0].distinct == 3 && r[1].blocked == 1, r.map { it.pkg + ":" + it.blocked + "/" + it.distinct }.toString())
    T.check("en çok engellenen alan başta; ad küçük harfe, sondaki nokta atılır", r[0].top.map { it.first } == listOf("graph.facebook.com", "ads.example.net", "t.example.org") && r[0].top[1].second == 3)
    T.check("toplam", PrivacyReport.total() == 10)
    PrivacyReport.record("geçersiz paket", "x.example.com")
    PrivacyReport.record("com.oyun.app", "kötü ad‮.com")
    PrivacyReport.record("com.oyun.app", null)
    r = PrivacyReport.report()
    T.check("geçersiz paket sayılmaz; geçersiz/boş ad sayılır ama ad listesine girmez",
        r.none { it.pkg == "geçersiz paket" } && r.first { it.pkg == "com.oyun.app" }.let { it.blocked == 3 && it.distinct == 1 })

    // günler
    now += DAY
    repeat(4) { PrivacyReport.record("com.oyun.app", "ads.example.net") }
    r = PrivacyReport.report()
    val oyun = r.first { it.pkg == "com.oyun.app" }
    T.check("gün gün sayılar (eskiden bugüne, 7 hücre)", oyun.perDay.size == 7 && oyun.perDay[5] == 3 && oyun.perDay[6] == 4 && oyun.blocked == 7, oyun.perDay.joinToString())
    T.check("yalnızca bugün", PrivacyReport.report(1).let { it.size == 1 && it[0].blocked == 4 })
    T.check("sıra 7 günlük toplama göre (9 > 7)", r[0].pkg == "com.instagram.android" && r[1].pkg == "com.oyun.app")
    now += 6 * DAY
    T.check("7 günü geçen gün düşer (ilk günün 9+3 engellemesi gider)", PrivacyReport.report().let { it.size == 1 && it[0].blocked == 4 })
    now += 7 * DAY
    T.check("hepsi eskiyince rapor boş", PrivacyReport.report().isEmpty() && PrivacyReport.isEmpty())

    // yerel gün sınırı: UTC+3'te 21:30 UTC ertesi gündür
    PrivacyReport.reset()
    val midnightUtc = 1_800_000_000_000L / DAY * DAY
    now = midnightUtc + 20 * 3_600_000L
    PrivacyReport.clock = { now }; PrivacyReport.zoneOffset = { 3 * 3_600_000 }
    PrivacyReport.record("com.a.b", "x.example.com")
    now = midnightUtc + 21 * 3_600_000L + 30 * 60_000L
    PrivacyReport.record("com.a.b", "x.example.com")
    T.check("gün, yerel gece yarısında değişir (UTC+3)", PrivacyReport.report()[0].perDay.let { it[5] == 1 && it[6] == 1 })

    // sınırlar
    PrivacyReport.reset(); PrivacyReport.clock = { now }; PrivacyReport.zoneOffset = { 0 }
    for (i in 0 until PrivacyReport.MAX_NAMES + 10) PrivacyReport.record("com.a.b", "n$i.example.com")
    PrivacyReport.record("com.a.b", "n0.example.com")
    T.check("uygulama başına en çok ${PrivacyReport.MAX_NAMES} ad; sayaç yine de artar; bilinen ad artmaya devam eder",
        PrivacyReport.report()[0].let { it.distinct == PrivacyReport.MAX_NAMES && it.blocked == PrivacyReport.MAX_NAMES + 11 && it.top[0] == ("n0.example.com" to 2) })
    for (i in 0 until PrivacyReport.MAX_PKGS + 20) { PrivacyReport.record("com.p$i.app", "x.example.com"); PrivacyReport.record("com.p$i.app", "x.example.com") }
    T.check("gün başına en çok ${PrivacyReport.MAX_PKGS} uygulama (en az engelleten çıkar, çok engelleten kalır)",
        PrivacyReport.report().size == PrivacyReport.MAX_PKGS && PrivacyReport.report().any { it.pkg == "com.a.b" })

    // "Geçmişi tut"
    PrivacyReport.reset(); PrivacyReport.clock = { now }; PrivacyReport.zoneOffset = { 0 }
    PrivacyReport.record("com.a.b", "x.example.com")
    FilterLive.keep(false)
    PrivacyReport.record("com.a.b", "y.example.com")
    T.check("geçmiş kapatılınca adlar silinir, sayılar kalır; yeni adlar tutulmaz", PrivacyReport.report()[0].let { it.blocked == 2 && it.distinct == 0 && it.top.isEmpty() })
    FilterLive.keep(true)
    PrivacyReport.record("com.a.b", "y.example.com")
    T.check("geçmiş açılınca adlar yeniden tutulur", PrivacyReport.report()[0].distinct == 1)

    // AppAds besler
    PrivacyReport.reset(); AppAds.reset(); PrivacyReport.clock = { now }; PrivacyReport.zoneOffset = { 0 }
    AppAds.record("com.twitter.android", "ads-api.twitter.com")
    AppAds.owner = { _, _, _, _, _ -> "com.twitter.android" }
    AppAds.blocked(17, byteArrayOf(10, 0, 0, 2), 5000, byteArrayOf(10, 0, 0, 1), 53, "analytics.twitter.com")
    AppAds.owner = { _, _, _, _, _ -> null }
    AppAds.blocked(17, byteArrayOf(10, 0, 0, 2), 5001, byteArrayOf(10, 0, 0, 1), 53, "kimin.example.com")
    T.check("uygulama bazlı engelleme kaydı rapora da yazılır; sahibi bilinmeyen istek yazılmaz",
        PrivacyReport.report().let { it.size == 1 && it[0].pkg == "com.twitter.android" && it[0].blocked == 2 && it[0].distinct == 2 })
    T.check("oturum istatistiği sıfırlanınca rapor kalır (kalıcı döküm ayrıdır)", AppAds.clearStats().let { PrivacyReport.total() == 2 })
    AppAds.reset()
}

private fun privacyPersist() {
    T.group("sizma53: gizlilik raporu: kalıcılık")
    PrivacyReport.reset(); FilterLive.keep(true)
    var now = 1_800_000_000_000L
    PrivacyReport.clock = { now }; PrivacyReport.zoneOffset = { 0 }
    val saved = ArrayList<String>()
    PrivacyReport.saver = { saved.add(it) }
    PrivacyReport.record("com.a.b", "x.example.com")
    T.check("ilk kayıt hemen yazılır", saved.size == 1 && saved[0].startsWith("v1\n") && saved[0].contains("com.a.b\t1\tx.example.com:1"))
    repeat(50) { now += 500; PrivacyReport.record("com.a.b", "x.example.com") }
    T.check("${PrivacyReport.SAVE_EVERY_MS / 1000} sn dolmadan her istekte disk yazılmaz", saved.size == 1)
    now += PrivacyReport.SAVE_EVERY_MS
    PrivacyReport.record("com.c.d", "y.example.com")
    T.check("süre dolunca yazılır", saved.size == 2 && saved[1].contains("com.a.b\t51\t") && saved[1].contains("com.c.d\t1\ty.example.com:1"))
    PrivacyReport.flush()
    T.check("bekleyen değişiklik yoksa flush yazmaz", saved.size == 2)
    now += 1000; PrivacyReport.record("com.c.d", "y.example.com"); PrivacyReport.flush()
    T.check("flush bekleyen değişikliği hemen yazar (servis kapanışı)", saved.size == 3 && saved[2].contains("com.c.d\t2\t"))

    // gidiş-dönüş
    val text = PrivacyReport.encode()
    val before = PrivacyReport.report().map { Triple(it.pkg, it.blocked, it.top) }
    PrivacyReport.reset(); PrivacyReport.clock = { now }; PrivacyReport.zoneOffset = { 0 }
    PrivacyReport.load(text)
    T.check("kodla → yükle aynı raporu verir", PrivacyReport.report().map { Triple(it.pkg, it.blocked, it.top) } == before)
    PrivacyReport.load(text)
    T.check("yükleme bellektekiyle birleşir (açılışta gelen istekler kaybolmaz)", PrivacyReport.report().first { it.pkg == "com.a.b" }.blocked == 102)

    // bozuk girdiler
    PrivacyReport.reset(); PrivacyReport.clock = { now }; PrivacyReport.zoneOffset = { 0 }
    val today = PrivacyReport.dayOf(now)
    PrivacyReport.load("v1\nD$today\ncom.ok.app\t3\tx.example.com:2,KÖTÜ:1,y.example.com:abc,:4\nkötü paket\t5\t\ncom.neg.app\t-4\t\ncom.ok2.app\tx\t\nsatır\nD${today - 30}\ncom.eski.app\t9\t\n")
    T.check("bozuk satırlar ve adlar atlanır, eski gün düşer", PrivacyReport.report().let { it.size == 1 && it[0].pkg == "com.ok.app" && it[0].blocked == 3 && it[0].top == listOf("x.example.com" to 2) })
    PrivacyReport.reset(); PrivacyReport.clock = { now }; PrivacyReport.zoneOffset = { 0 }
    PrivacyReport.load("v2\nD$today\ncom.ok.app\t3\t\n"); PrivacyReport.load(null); PrivacyReport.load("v1\n" + "x".repeat(500_000))
    T.check("bilinmeyen sürüm, boş ya da aşırı büyük dosya yok sayılır", PrivacyReport.report().isEmpty())
    T.check("boş rapor boş metin olarak kodlanır (dosya silinir)", PrivacyReport.encode() == "")

    // silme
    saved.clear(); PrivacyReport.saver = { saved.add(it) }
    PrivacyReport.record("com.a.b", "x.example.com")
    PrivacyReport.clear()
    T.check("raporu sil: bellek boşalır ve boş metin yazılır", PrivacyReport.report().isEmpty() && saved.last() == "")
    PrivacyReport.saver = { throw RuntimeException("disk dolu") }
    now += PrivacyReport.SAVE_EVERY_MS * 2
    PrivacyReport.record("com.a.b", "x.example.com")
    T.check("disk hatası kaydı bozmaz", PrivacyReport.total() == 1)
    PrivacyReport.reset()
}

private fun privacyWiring() {
    T.group("sizma53: gizlilik raporu: bağlantılar")
    val base = "app/src/main/java/app/dnshizli/"
    fun src(p: String) = File(base + p).readText()
    val store = src("platform/PrivacyStore.kt")
    T.check("rapor uygulamanın kendi klasöründe, geçici dosya + yeniden adlandırma ile yazılır; tek arka plan iş parçacığı",
        store.contains("filesDir") && store.contains("renameTo") && store.contains("newSingleThreadExecutor") && store.contains("PrivacyReport.load(") && store.contains("PrivacyReport.saver ="))
    T.check("uygulama açılışında kurulur", src("platform/AppOwner.kt").contains("PrivacyStore.install(app)"))
    T.check("iki VPN servisi de kapanırken bekleyeni yazar", src("platform/DnsVpnService.kt").contains("PrivacyReport.flush()") && src("platform/WgVpnService.kt").contains("PrivacyReport.flush()"))
    T.check("dosya yedeğe/buluta gitmez (filesDir dışlanmış)", File("app/src/main/res/xml/data_extraction_rules.xml").readText().let { x -> x.split("<exclude domain=\"file\" path=\".\" />").size == 3 })
    T.check("geçmiş kapatılınca rapordaki adlar silinir", src("core/Filter.kt").contains("PrivacyReport.dropNames()"))
    T.check("rapor AppAds kaydından beslenir", src("core/AppAds.kt").contains("PrivacyReport.record(pkg, name)"))
    // metinler
    val bad = PrivacyText.M.filter { (_, v) -> v.size != Lang.values().size || v.any { it.isBlank() } }.keys
    T.check("tüm metinler 12 dilde dolu", bad.isEmpty(), bad.toString())
    val ph = PrivacyText.M.filter { (_, v) -> v.map { s -> Regex("\\{\\d}").findAll(s).map { it.value }.toSet() }.toSet().size != 1 }.keys
    T.check("yer tutucular her dilde aynı", ph.isEmpty(), ph.toString())
    T.check("Türkçe döküm cümlesi", PrivacyText.t("detail", Lang.TR, "14", "312") == "Son 7 günde 14 farklı izleyici/reklam alanına 312 kez bağlanmaya çalıştı; hepsi engellendi.")
}

private fun shown53(r: Rig): List<String> = TextRecorder().also { r.scene.draw(it) }.runs.map { it.s }

private fun privacyUi() {
    T.group("sizma53: gizlilik raporu: arayüz")
    PrivacyReport.reset(); AppAds.reset(); FilterLive.keep(true)
    val awt = AwtGfx(java.awt.image.BufferedImage(1, 1, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics())
    val r = Rig(Rig.base("aqua").copy(filterLevel = FilterLevel.MEDIUM), 360, 780, metrics = awt)
    r.host.sdk = 34
    PrivacyReport.clock = { r.host.now }; PrivacyReport.zoneOffset = { 0 }
    AppAds.labeler = { mapOf("com.instagram.android" to "Instagram", "com.oyun.app" to "Süper Oyun", "com.zhiliaoapp.musically" to "TikTok")[it] ?: it }
    r.scene.openSection(Section.FILTER); r.settle(900)
    T.check("Engelleme sayfasında 'Gizlilik raporu' satırı var; boşken değer yok", r.reveal(PrivacyText.t("title")) != null && r.find(PrivacyText.t("title"))?.info?.value == null)
    r.tapText(PrivacyText.t("title"), settleMs = 900)
    T.check("boş rapor açıklaması görünür", shown53(r).any { PrivacyText.t("empty").startsWith(it.removeSuffix("…")) && it.length > 8 })
    r.scene.back(); r.settle(900)

    val ig = listOf("graph.facebook.com" to 120, "graph.instagram.com" to 64, "an.facebook.com" to 40, "connect.facebook.net" to 30, "app-measurement.com" to 22,
        "crashlytics.com" to 14, "googleads.g.doubleclick.net" to 12, "sdk.iad-01.braze.com" to 6, "pixel.facebook.com" to 4)
    for ((n, c) in ig) repeat(c) { PrivacyReport.record("com.instagram.android", n) }
    for ((n, c) in listOf("ads.unity3d.com" to 80, "applovin.com" to 61, "ironsrc.mobi" to 33, "googleads.g.doubleclick.net" to 20)) repeat(c) { PrivacyReport.record("com.oyun.app", n) }
    for ((n, c) in listOf("log.byteoversea.com" to 44, "mon.tiktokv.com" to 31, "analytics.tiktok.com" to 9)) repeat(c) { PrivacyReport.record("com.zhiliaoapp.musically", n) }
    r.settle(1200)
    r.scene.back(); r.settle(600); r.scene.openSection(Section.FILTER); r.settle(900)
    val total = PrivacyReport.total()
    T.check("satır değeri 7 günlük toplamı gösterir", r.reveal(PrivacyText.t("title")) != null && r.find(PrivacyText.t("title"))?.info?.value == PrivacyText.t("summary", L.lang, Format.count(total.toLong())),
        r.findAll(PrivacyText.t("title")).joinToString { it.info.label } + " / " + total)
    r.tapText(PrivacyText.t("title"), settleMs = 900)
    val s = shown53(r)
    T.check("uygulamalar en çok engelletenden sıralı, farklı alan sayısıyla", r.find("Instagram") != null && r.find("Süper Oyun") != null && r.find("TikTok") != null &&
        r.find("Instagram")!!.t < r.find("Süper Oyun")!!.t && s.any { it.startsWith(PrivacyText.t("distinct", L.lang, "9")) })
    run { val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/gizlilik-raporu.png"); cv.dispose() }
    r.tapText("Instagram", settleMs = 900)
    T.check("ayrıntı: döküm cümlesi, gün gün sayılar ve engellenen alanlar", shown53(r).let { t -> t.any { it.contains("graph.facebook.com") } } &&
        r.find(PrivacyText.t("mode")) != null)
    run { val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/gizlilik-raporu-instagram.png"); cv.dispose() }
    r.tapText("graph.instagram.com", settleMs = 900)
    T.check("alana dokununca izin listesine eklenir (bozulan özelliği açmak için)", r.model.settings.filterAllow.contains("graph.instagram.com"))
    T.check("ön izlemeler üretildi", File("build/onizleme/gizlilik-raporu.png").isFile && File("build/onizleme/gizlilik-raporu-instagram.png").isFile)
    PrivacyReport.reset(); AppAds.reset()
}

/** Maymun testinin bulduğu hata: boşta dönme ve çizilmeyen küre sonsuza dek 60 fps kare istiyordu. */
private fun globeIdle() {
    T.group("sizma53: küre: boşta 60 fps istemez")
    val c = GlobeCamera(0.0, 0.0)
    c.tick(5.0, true)
    val lon = c.lon0
    T.check("boşta dönme sürer ama 'hareket' sayılmaz (sahne 30 fps süs kipinde kalır)", !c.tick(0.5, true) && c.lon0 != lon)
    val gp = File("app/src/main/java/app/dnshizli/ui/GlobePage.kt").readText()
    T.check("arka plan işi yalnızca çizilirken kare ister", gp.contains("val building = drew && ") && gp.contains("val shadeWait = drew && ") && gp.contains("drawnSinceTick = true"))
}
