package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.Section
import java.io.File

/** sizma56: gizlilik (sızıntı) testi — görünen IP ve ülke, IPv6, WebRTC (STUN), DNS yolu ve sağlayıcı. */
internal fun runRound32Tests() {
    checkParse()
    checkStun()
    checkVerdicts()
    checkUi()
}

private fun checkParse() {
    T.group("sizma56: gizlilik testi: trace ayrıştırma")
    val body = "fl=12f1\nh=1.1.1.1\nip=88.230.12.34\nts=1730000000.1\nvisit_scheme=https\nuag=x\ncolo=IST\nsliver=none\nhttp=http/1.1\nloc=TR\ntls=TLSv1.3\nsni=off\nwarp=off\n"
    T.check("ip ve ülke okunur", PrivacyCheck.parseTrace(body) == ("88.230.12.34" to "TR"))
    T.check("IPv6 adresi okunur", PrivacyCheck.parseTrace("ip=2a02:ff0:3::1\nloc=de\n") == ("2a02:ff0:3::1" to "DE"))
    T.check("bilinmeyen ülke (XX) ya da bozuk kod null", PrivacyCheck.parseTrace("ip=1.2.3.4\nloc=XX") == ("1.2.3.4" to null) && PrivacyCheck.parseTrace("ip=1.2.3.4\nloc=T1") == ("1.2.3.4" to null))
    T.check("bozuk/eksik ip ya da dev gövde null", PrivacyCheck.parseTrace("ip=999.1.1.1") == null && PrivacyCheck.parseTrace("loc=TR") == null &&
        PrivacyCheck.parseTrace("ip=<script>") == null && PrivacyCheck.parseTrace("ip=1.2.3.4\n" + "x".repeat(5000)) == null && PrivacyCheck.parseTrace(null) == null)
    T.check("adres biçimi: IPv6 kısaltılır", PrivacyCheck.fmt(byteArrayOf(0x20, 0x01, 0x0d, 0xb8.toByte(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1)) == "2001:db8::1" &&
        PrivacyCheck.fmt(byteArrayOf(1, 2, 3, 4)) == "1.2.3.4")
    T.check("aynı adres (IPv6 yazım farkı gözetmez)", PrivacyCheck.sameIp("2001:db8:0:0::1", "2001:DB8::1") && !PrivacyCheck.sameIp("1.2.3.4", "1.2.3.5") && !PrivacyCheck.sameIp(null, "1.2.3.4"))
}

private fun stunResp(txid: ByteArray, attrs: ByteArray, type: Int = 0x0101): ByteArray {
    val b = ByteArray(20 + attrs.size)
    Packets.put16(b, 0, type); Packets.put16(b, 2, attrs.size); Packets.put32(b, 4, 0x2112A442)
    System.arraycopy(txid, 0, b, 8, 12); System.arraycopy(attrs, 0, b, 20, attrs.size)
    return b
}

private fun checkStun() {
    T.group("sizma56: gizlilik testi: STUN")
    val tx = ByteArray(12) { (it * 7 + 1).toByte() }
    val req = PrivacyCheck.stunRequest(tx)
    T.check("bağlama isteği: 20 bayt, tür 0x0001, sihirli çerez, işlem kimliği", req.size == 20 && Packets.u16(req, 0) == 1 && Packets.u16(req, 2) == 0 &&
        Packets.i32(req, 4) == 0x2112A442 && req.copyOfRange(8, 20).contentEquals(tx))
    // XOR-MAPPED-ADDRESS 88.230.12.34:54321
    val ip = byteArrayOf(88, 230.toByte(), 12, 34)
    val xa = ByteArray(12).also { Packets.put16(it, 0, 0x0020); Packets.put16(it, 2, 8); it[5] = 1; Packets.put16(it, 6, 54321 xor 0x2112)
        val m = byteArrayOf(0x21, 0x12, 0xA4.toByte(), 0x42); for (i in 0 until 4) it[8 + i] = (ip[i].toInt() xor m[i].toInt()).toByte() }
    T.check("XOR-MAPPED-ADDRESS (IPv4) çözülür", PrivacyCheck.parseStun(stunResp(tx, xa), 32, tx) == "88.230.12.34")
    // IPv6 XOR
    val ip6 = byteArrayOf(0x2a, 0x02, 0x0f, 0xf0.toByte(), 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1)
    val xa6 = ByteArray(24).also { Packets.put16(it, 0, 0x0020); Packets.put16(it, 2, 20); it[5] = 2
        val mask = byteArrayOf(0x21, 0x12, 0xA4.toByte(), 0x42) + tx
        for (i in 0 until 16) it[8 + i] = (ip6[i].toInt() xor mask[i].toInt()).toByte() }
    T.check("XOR-MAPPED-ADDRESS (IPv6) çözülür", PrivacyCheck.parseStun(stunResp(tx, xa6), 44, tx) == "2a02:ff0:3::1")
    val ma = ByteArray(12).also { Packets.put16(it, 0, 0x0001); Packets.put16(it, 2, 8); it[5] = 1; for (i in 0 until 4) it[8 + i] = ip[i] }
    T.check("yalnızca MAPPED-ADDRESS varsa o kullanılır", PrivacyCheck.parseStun(stunResp(tx, ma), 32, tx) == "88.230.12.34")
    val other = tx.copyOf().also { it[0] = 99 }
    T.check("işlem kimliği tutmayan, hata yanıtı ya da kısa/bozuk paket reddedilir", PrivacyCheck.parseStun(stunResp(tx, xa), 32, other) == null &&
        PrivacyCheck.parseStun(stunResp(tx, xa, 0x0111), 32, tx) == null && PrivacyCheck.parseStun(ByteArray(10), 10, tx) == null &&
        PrivacyCheck.parseStun(stunResp(tx, xa).copyOf(26), 26, tx) == null)
}

private fun checkVerdicts() {
    T.group("sizma56: gizlilik testi: yargılar")
    fun row(rows: List<CheckRow>, k: String) = rows.first { it.key == k }
    val dnsCtx = PrivacyContext(connected = true, wireGuard = false, serverName = "Cloudflare", protoName = "DoH", encrypted = true)
    var r = PrivacyCheck.rows(PrivacyProbe("88.230.12.34", "TR", null, null, "88.230.12.34", true), dnsCtx) { if (it == "TR") "Türkiye" else null }
    T.check("DNS kipi: IP gizli değil uyarısı, ülke adı dilde; IPv6 yok = iyi; WebRTC aynı = iyi; DNS tünelden = iyi; sağlayıcı şifreli = iyi",
        row(r, "ip").state == CheckState.WARN && row(r, "ip").detail.startsWith("88.230.12.34 · Türkiye") && row(r, "v6").state == CheckState.OK &&
            row(r, "rtc").state == CheckState.OK && row(r, "dns").state == CheckState.OK && row(r, "prov").state == CheckState.OK && row(r, "prov").detail.startsWith("Cloudflare · DoH"))
    val wgCtx = PrivacyContext(connected = true, wireGuard = true, wgV6 = false)
    r = PrivacyCheck.rows(PrivacyProbe("185.1.2.3", "NL", "2a02:ff0:3::1", "TR", "88.230.12.34", true), wgCtx)
    T.check("WireGuard: çıkış IP'si iyi; tünel IPv6 taşımazken görünen IPv6 SIZINTI; STUN farklı adres SIZINTI",
        row(r, "ip").state == CheckState.OK && row(r, "v6").state == CheckState.BAD && row(r, "rtc").state == CheckState.BAD)
    r = PrivacyCheck.rows(PrivacyProbe("185.1.2.3", "NL", "2a0e::5", "NL", "2a0e:0::5", true), PrivacyContext(connected = true, wireGuard = true, wgV6 = true))
    T.check("WireGuard IPv6'yı taşıyorsa IPv6 iyi; STUN IPv6 adresiyle aynıysa iyi", row(r, "v6").state == CheckState.OK && row(r, "rtc").state == CheckState.OK)
    r = PrivacyCheck.rows(PrivacyProbe("88.230.12.34", null, null, null, null, false), dnsCtx)
    T.check("DNS tünel dışında = sorun (Özel DNS yönlendirmesi); STUN yanıtsız = iyi (WebRTC adres öğrenemez)", row(r, "dns").state == CheckState.BAD && row(r, "rtc").state == CheckState.OK)
    r = PrivacyCheck.rows(PrivacyProbe(), PrivacyContext(connected = false, wireGuard = false))
    T.check("bağlı değil ve ağ yok: IP ölçülemedi, DNS ve sağlayıcı test edilmedi", row(r, "ip").state == CheckState.WARN && row(r, "dns").state == CheckState.OFF && row(r, "prov").state == CheckState.OFF)
    r = PrivacyCheck.rows(PrivacyProbe("1.2.3.4"), dnsCtx.let { PrivacyContext(true, false, serverName = "Google", protoName = "Düz DNS", encrypted = false) })
    T.check("şifresiz sağlayıcı = bilgi (şifrelemeyi aç)", row(r, "prov").state == CheckState.WARN)
    r = PrivacyCheck.rows(PrivacyProbe("1.2.3.4"), PrivacyContext(true, false, serverName = "Cloudflare", protoName = "DoT", encrypted = true, tlsFailures = 2, splitWith = listOf("Quad9", "DNS4EU")))
    T.check("sertifika hatası = sorun; bölme ortakları adlarıyla", row(r, "prov").state == CheckState.BAD && row(r, "prov").detail.startsWith("Cloudflare + Quad9 + DNS4EU · DoT"))
    val ps = PrivacyCheck.paragraphs(r)
    T.check("paragraflar: durum etiketi + başlık + ayrıntı, sonda dipnot", ps.size == 6 && ps[0].startsWith("[") && ps.last() == PrivacyCheckText.t("foot"))
    val bad = PrivacyCheckText.M.filter { (_, v) -> v.size != Lang.values().size || v.any { it.isBlank() } }.keys
    T.check("metinler 12 dilde dolu", bad.isEmpty(), bad.toString())
    val pr = File("app/src/main/java/app/dnshizli/platform/PrivacyProber.kt").readText()
    T.check("platform: trace adresleri IP sabit, STUN, LeakProbe; sonuç saklanmaz", pr.contains("PrivacyCheck.TRACE4") && pr.contains("PrivacyCheck.TRACE6") &&
        pr.contains("PrivacyCheck.stunRequest") && pr.contains("LeakProbe.begin()") && !pr.contains("SharedPreferences"))
    T.check("WireGuard IPv6 kapsamı servis kurulurken kaydedilir", File("app/src/main/java/app/dnshizli/platform/WgVpnService.kt").readText().contains("fullV6 = cfg.peer.allowedIps.any { it.ip.size == 16 && it.prefix == 0 }"))
}

private fun checkUi() {
    T.group("sizma56: gizlilik testi: arayüz")
    val awt = AwtGfx(java.awt.image.BufferedImage(1, 1, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics())
    val r = Rig(Rig.base("aqua"), 360, 780, metrics = awt)
    r.connectOk()
    r.model.onVpn(r.model.vpn.copy(proto = Proto.DOH)); r.settle(300)
    r.host.isoNames = mapOf("TR" to "Türkiye")
    r.host.probeVal = PrivacyProbe("88.230.12.34", "TR", null, null, "88.230.12.34", true)
    r.host.probeDefer = true
    r.scene.openSection(Section.FILTER); r.settle(900)
    r.tapText(PrivacyCheckText.t("title"), settleMs = 900)
    fun shown() = TextRecorder().also { r.scene.draw(it) }.runs.map { it.s }
    T.check("önce 'test ediliyor'", shown().any { PrivacyCheckText.t("running").startsWith(it.removeSuffix("…")) && it.length > 6 })
    r.host.probeDone?.invoke(); r.settle(900)
    val s = shown()
    T.check("sonuçlar: IP + ülke, sağlayıcı", s.any { it.contains("88.230.12.34 · Türkiye") } && s.any { it.contains("Cloudflare") && it.contains("DoH") }, s.joinToString(" | ").take(400))
    run { val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/gizlilik-testi.png"); cv.dispose() }
    r.host.probeDefer = false
    r.tapText(PrivacyCheckText.t("again"), settleMs = 900)
    T.check("yeniden test edilir", shown().any { it.contains("88.230.12.34") })
    T.check("ön izleme", File("build/onizleme/gizlilik-testi.png").isFile)
}
