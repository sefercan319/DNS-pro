package app.dnshizli.selftest

import app.dnshizli.core.*

/** sizma60: mevcut gizlilik özelliklerinin iyileştirmeleri (güvenlik duvarı sahip-bilinmiyor önbelleği, parmak izi erişilebilirlik ipuçları). */
internal fun runRound36Tests() {
    fwUnknownOwner()
    fpA11yHints()
    reportDoc()
    recentLatency()
}

private fun pkt4(proto: Int, sport: Int, dport: Int): ByteArray {
    val b = ByteArray(40)
    b[0] = 0x45; Packets.put16(b, 2, 40); b[8] = 64; b[9] = proto.toByte()
    b[12] = 10; b[15] = 2
    b[16] = 1; b[17] = 2; b[18] = 3; b[19] = 4
    Packets.put16(b, 20, sport); Packets.put16(b, 22, dport)
    return b
}

private fun fwUnknownOwner() {
    T.group("sizma60: güvenlik duvarı: sahibi geçici bilinmeyen akış uzun süre serbest kalmaz")
    AppFirewall.reset(); AppAds.reset()
    var now = 9_000_000L
    AppAds.clock = { now }; AppFirewall.clock = { now }
    var known = false
    var asked = 0
    AppAds.owner = { _, _, sport, _, _ -> asked++; if (sport == 6100 && known) "com.bad.app" else if (sport == 6200) "com.good.app" else null }
    AppFirewall.setRules(mapOf("com.bad.app" to FwMode.ALL)); AppFirewall.setNet(NetKind.WIFI)
    T.check("sahip bilinmiyorsa paket geçer (başka uygulama asla yanlışlıkla kesilmez)", !AppFirewall.dropIp(pkt4(6, 6100, 443), 40))
    known = true
    now += 500
    T.check("bilinmeyen karar kısa süre önbellekte (her pakette sorulmaz)", !AppFirewall.dropIp(pkt4(6, 6100, 443), 40))
    now += 2_100
    T.check("2 sn sonra yeniden sorulur ve engelli uygulamanın akışı kesilir (eskiden 30 sn sızardı)", AppFirewall.dropIp(pkt4(6, 6100, 443), 40))
    val a0 = asked
    T.check("bilinen izinli uygulama ilk pakette sorulur", !AppFirewall.dropIp(pkt4(6, 6200, 443), 40) && asked == a0 + 1)
    repeat(20) { now += 1_000; AppFirewall.dropIp(pkt4(6, 6200, 443), 40) }
    T.check("bilinen izinli akış hâlâ 30 sn önbellekte (ek sahip sorgusu yok)", asked == a0 + 1)
    T.check("engelli akış önbellekte kalır", AppFirewall.dropIp(pkt4(6, 6100, 443), 40))
    AppFirewall.reset(); AppAds.reset()
}

private fun fpA11yHints() {
    T.group("sizma60: parmak izi: erişilebilirlik tercih ipuçları")
    val inp = listOf("Host: a.com", "Sec-CH-Prefers-Reduced-Motion: reduce", "sec-ch-prefers-contrast: more", "Sec-CH-Forced-Colors: active",
        "Sec-CH-Prefers-Reduced-Transparency: reduce", "Sec-CH-Prefers-Color-Scheme: dark", "Accept: */*")
    val out = Fingerprint.request(inp)
    T.check("azaltılmış hareket/saydamlık, kontrast ve zorunlu renkler silinir", out == listOf("Host: a.com", "Sec-CH-Prefers-Color-Scheme: dark", "Accept: */*"), out.toString())
    T.check("renk şeması kalır (yaygın; silinirse site yanlış temayla açılır)", out.any { it.startsWith("Sec-CH-Prefers-Color-Scheme") })
    T.check("silinen başlık listesi küçük harf", Fingerprint.DROP_REQ.all { it == it.lowercase() })
}

private fun reportDoc() {
    T.group("sizma60: gizlilik raporu: saklama süresi")
    PrivacyReport.reset()
    var now = 1_700_000_000_000L
    PrivacyReport.clock = { now }; PrivacyReport.zoneOffset = { 0 }
    PrivacyReport.record("com.a.b", "t.example.com")
    PrivacyReport.setKeepDays(0)
    T.check("1 saat seçilince rapor boşalır ve yeni kayıt tutulmaz", PrivacyReport.isEmpty().also { PrivacyReport.record("com.a.b", "x.com") } && PrivacyReport.total() == 0)
    PrivacyReport.setKeepDays(7)
    PrivacyReport.record("com.a.b", "x.com")
    T.check("süre geri açılınca kayıt yeniden tutulur", PrivacyReport.total() == 1)
    PrivacyReport.reset()
}

private fun recentLatency() {
    T.group("sizma60: ana ekran ms: son cevapların ortancası")
    val T0 = LatencyRing.TIMEOUT
    // Bağlanış anındaki el sıkışma/boş önbellek patlaması (900 ms'ler) ardından normal cevaplar (20 ms'ler)
    val ring = LatencyRing()
    repeat(40) { ring.add(900) }
    repeat(30) { ring.add(20 + it % 5) }
    val buf = IntArray(LatencyRing.CAPACITY)
    val n = ring.copyTo(buf)
    val cumulative = (40 * 900 + (0 until 30).sumOf { 20 + it % 5 }) / 70
    val recent = LatencySummary.recentMs(buf, n)
    T.check("ilk anların yüksek süreleri gösterilen ms'i şişirmez (birikimli $cumulative ms, son cevaplar $recent ms)", recent in 20..24 && cumulative > 300, "$recent")
    T.check("tek tük yavaş cevap ortancayı bozmaz", LatencySummary.recentMs(intArrayOf(20, 22, 21, 2500, 19, 23, 20), 7) == 21)
    T.check("zaman aşımları sayılmaz", LatencySummary.recentMs(intArrayOf(T0, 30, T0, 40, T0), 5) == 35)
    T.check("örnek yoksa 0 (servis birikimli ortalamaya düşer)", LatencySummary.recentMs(intArrayOf(T0, T0), 2) == 0 && LatencySummary.recentMs(IntArray(0), 0) == 0)
    T.check("yalnızca en yeni ${LatencySummary.RECENT} cevaba bakılır", LatencySummary.recentMs(IntArray(100) { if (it < 70) 500 else 10 }, 100) == 10)
    T.check("n dizi boyunu aşsa da taşmaz", LatencySummary.recentMs(intArrayOf(5, 7, 9), 50) == 7)
}
