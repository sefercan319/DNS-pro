package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File

/** sizma61: uyum motoru — özellik grafiği, çözücü, kaynak bütçesi, canlı yük, etkinlik sigortaları, bekleme; arka planda ve görünmez. */
internal fun runRound37Tests() {
    graphTests()
    resolveTests()
    budgetTests()
    safetyTests()
    governorTests()
    breakerTests()
    engineTests()
    liveTests()
    hiddenTests()
}

private val LOW = DeviceProfiler.detect(DeviceInfo(manufacturer = "Xiaomi", brand = "Redmi", model = "Redmi 9A", sdk = 33, ramMb = 2048, heapMb = 128, lowRamFlag = true))
private val MIDP = DeviceProfiler.detect(DeviceInfo(manufacturer = "Samsung", brand = "samsung", model = "SM-A546B", sdk = 34, ramMb = 6144, heapMb = 256))
private val HIGH = DeviceProfiler.detect(DeviceInfo(manufacturer = "Samsung", brand = "samsung", model = "SM-S928B", sdk = 35, ramMb = 12288, heapMb = 512))

/** Her şeyin açık olduğu ağır profil. */
private val HEAVY = AppSettings(
    dnsOn = true, dpiOn = true, adsPlus = true, mitmOn = true, udpDecoy = true, quicSplit = true, blockQuic = false, dnsRace = true,
    splitDns = true, filterLevel = FilterLevel.STRICT, autoShield = true, oemBlock = true, appFw = "com.a.b=A", motion = Motion.FULL,
    wallpaper = true, wpBlur = WpBlur.STRONG, tapFx = true, celebrate = true, soundOn = true, deviceAuto = true,
)

private fun ctx(p: DeviceProfile?, f: CompatFacts = CompatFacts()) = HarmonyContext(p, f)

private fun graphTests() {
    T.group("sizma61: uyum motoru: özellik grafiği")
    val bad = FeatureGraph.validate()
    T.check("grafik yapısal olarak sağlam (bilinmeyen bağımlılık, döngü, yanlış katman yok)", bad.isEmpty(), bad.joinToString("; "))
    T.check("uygulamanın davranış ayarlarının hepsi düğüm (≥ 90 özellik)", FeatureGraph.all.size >= 90, "${FeatureGraph.all.size}")
    T.check("her alan kapsanır", Domain.values().all { d -> FeatureGraph.all.any { it.domain == d } })
    T.check("her denetim tam bir özelliğe bağlı", Knob.values().all { k -> FeatureGraph.all.count { it.knob == k } == 1 })
    T.check("çekirdek ve koruma katmanında denetim yok (motor koruyucu hiçbir şeyi kısamaz)", FeatureGraph.all.none { (it.tier == Tier.CORE || it.tier == Tier.PROTECT) && it.knob != null })
    val ord = FeatureGraph.order().map { it.id }
    T.check("bağımlılık sırası: her özellik dayandıklarından sonra", FeatureGraph.all.all { x -> (x.needs + x.needsAny).all { ord.indexOf(it) < ord.indexOf(x.id) } })
    val prot = listOf("filter", "encrypt", "dohGuard", "appFw", "dpiOn", "adsPlus", "rebindGuard", "strictEncryption", "failClosed", "appLock", "secureScreen")
    T.check("koruyucular doğru katmanda", prot.all { FeatureGraph.byId[it]?.tier == Tier.PROTECT || FeatureGraph.byId[it]?.tier == Tier.CORE })
}

private fun resolveTests() {
    T.group("sizma61: uyum motoru: çözücü (uyuyan, boşa çıkan)")
    val base = AppSettings(dnsOn = true, blockQuic = false, dnsRace = false)
    val p0 = HarmonyCore.compute(base.copy(udpDecoy = true, quicSplit = true), ctx(HIGH))
    T.check("DPI kapalıyken sahte UDP ve QUIC bölme uyur (nedeni: DPI)", p0.state("udpDecoy") == FState.DORMANT && p0.state("quicSplit") == FState.DORMANT && p0.reasons["udpDecoy"]!!.contains("dpiOn"))
    T.check("modül yokken ağ geçidi ve ona bağlı işler uyur", p0.state("gateway") == FState.DORMANT && p0.state("gw.hedge") == FState.DORMANT)
    val p1 = HarmonyCore.compute(base.copy(dpiOn = true), ctx(HIGH))
    T.check("DPI açılınca ağ geçidi, yedek bağlantı ve hop ölçümü etkin", p1.state("gateway") == FState.ACTIVE && p1.state("gw.hedge") == FState.ACTIVE && p1.state("dpi.autoTtl") == FState.ACTIVE)
    T.check("yalnızca güvenlik duvarı kuralı da ağ geçidini etkinleştirir", HarmonyCore.compute(base.copy(appFw = "com.a.b=W"), ctx(HIGH)).state("gateway") == FState.ACTIVE)
    val p2 = HarmonyCore.compute(base.copy(dpiOn = true, quicSplit = true, blockQuic = true), ctx(HIGH))
    T.check("QUIC engeli varken QUIC bölme boşa çıkar ve denetimi kapanır", p2.state("quicSplit") == FState.SUPERSEDED && !p2.allows(Knob.QUIC_SPLIT))
    T.check("Reklam+ de QUIC bölmeyi boşa çıkarır", HarmonyCore.compute(base.copy(dpiOn = true, quicSplit = true, adsPlus = true), ctx(HIGH)).state("quicSplit") == FState.SUPERSEDED)
    T.check("ODoH varken DNS bölme boşa çıkar", HarmonyCore.compute(base.copy(splitDns = true, odoh = OdohMode.STRICT), ctx(HIGH)).state("splitDns") == FState.SUPERSEDED)
    T.check("parmak izi koruması tarayıcı kipi yokken uyur", HarmonyCore.compute(base.copy(fpGuard = true), ctx(HIGH)).state("fpGuard") == FState.DORMANT &&
        HarmonyCore.compute(base.copy(fpGuard = true, mitmOn = true, adsPlus = true), ctx(HIGH)).state("fpGuard") == FState.ACTIVE)
    T.check("ses düzeyi sıfırken arayüz sesleri boşa çıkar", HarmonyCore.compute(base.copy(soundOn = true, soundUi = true, soundVolume = 0f), ctx(HIGH)).state("soundUi") == FState.SUPERSEDED)
    val t = HarmonyCore.compute(base.copy(dpiOn = true, udpDecoy = true), ctx(HIGH, CompatFacts(ttlBroken = true)))
    T.check("TTL ayarlanamayan cihazda hop ölçümü ve sahte UDP kısılır", !t.allows(Knob.AUTO_TTL) && !t.allows(Knob.UDP_DECOY) && t.off[Knob.AUTO_TTL]!!.contains("TTL"))
    T.check("DNS kapalıyken DNS'e bağlı tüm özellikler uyur", HarmonyCore.compute(AppSettings(dnsOn = false, dnsRace = true), ctx(HIGH)).let { p -> listOf("encrypt", "dnsRace", "dohGuard", "rebindGuard").all { p.state(it) == FState.DORMANT || p.state(it) == FState.OFF } })
}

private fun budgetTests() {
    T.group("sizma61: uyum motoru: kaynak bütçesi")
    val def = AppSettings()
    for ((name, p) in listOf("güçlü" to HIGH, "orta" to MIDP, "zayıf" to LOW)) {
        val pl = HarmonyCore.compute(def, ctx(p))
        T.check("varsayılan ayarlar $name cihazda hiçbir şeyi kısmaz", pl.off.isEmpty(), pl.journal().joinToString(" | "))
    }
    val hHeavy = HarmonyCore.compute(HEAVY, ctx(HIGH))
    T.check("güçlü cihaz her şey açıkken bütçeden kısmaz (yalnızca boşa çıkan QUIC bölme kapalı)", hHeavy.states.values.none { it == FState.SHED } && hHeavy.off.keys == setOf(Knob.QUIC_SPLIT), hHeavy.journal().joinToString(" | "))
    val lHeavy = HarmonyCore.compute(HEAVY, ctx(LOW))
    T.check("zayıf cihazda her şey açıkken kısar", lHeavy.off.isNotEmpty(), lHeavy.journal().joinToString(" | "))
    T.check("önce süs (efektler) kısılır", !lHeavy.allows(Knob.VISUALS) && lHeavy.off[Knob.VISUALS]!!.startsWith("bütçe"))
    T.check("koruyucu hiçbir özellik kısılmaz", lHeavy.states.filter { it.value == FState.SHED }.keys.all { FeatureGraph.byId.getValue(it).sheddable })
    T.check("kısma sonunda kapasite aşılmaz ya da taşan kaynağa yük bindiren kısılabilir iş kalmaz", Res.values().all { r -> lHeavy.usage.getValue(r) <= lHeavy.capacity.getValue(r) } ||
        FeatureGraph.all.none { f -> f.sheddable && f.knob != Knob.MOTION && lHeavy.state(f.id) == FState.ACTIVE &&
            Res.values().any { r -> f.cost[r] > 0 && lHeavy.usage.getValue(r) > lHeavy.capacity.getValue(r) } }, lHeavy.journal().joinToString(" | "))
    T.check("hareketin tamamen durması yalnızca kritik durumda (normal yükte en çok 'Az')", lHeavy.allows(Knob.MOTION) &&
        !HarmonyCore.compute(HEAVY, ctx(LOW), Load.OVERLOAD).allows(Knob.MOTION))
    val dpiRace = def.copy(dpiOn = true, udpDecoy = true, dnsRace = true, blockQuic = false)
    val pw = HarmonyCore.compute(dpiRace, ctx(MIDP, CompatFacts(batterySaver = true)))
    T.check("pil tasarrufunda telefonu uyandıran işler kısılır (sahte UDP, hop ölçümü, DNS yarışı)", !pw.allows(Knob.UDP_DECOY) && !pw.allows(Knob.AUTO_TTL), pw.journal().joinToString(" | "))
    T.check("pil tasarrufunda arka plan aralığı uzar", pw.tickScale == 2 && HarmonyCore.compute(dpiRace, ctx(MIDP)).tickScale == 1)
    val met = HarmonyCore.compute(dpiRace, ctx(MIDP, CompatFacts(metered = true, mobile = true)))
    T.check("ölçülü mobil veride veri harcayan işler kısılır (DNS yarışı)", !met.allows(Knob.DNS_RACE) && met.off[Knob.DNS_RACE] == "bütçe: data", met.journal().joinToString(" | "))
    T.check("Wi-Fi'de aynı ayarlarla kısılmaz", HarmonyCore.compute(dpiRace, ctx(MIDP, CompatFacts(metered = true, mobile = false))).allows(Knob.DNS_RACE))
    val hot = HarmonyCore.compute(def.copy(motion = Motion.FULL, deviceAuto = true), ctx(HIGH, CompatFacts(thermal = 4)))
    T.check("kritik ısınmada efektler kısılır, arka plan seyrekleşir", hot.reduceVisuals && hot.tickScale == 3, hot.journal().joinToString(" | "))
    val over = HarmonyCore.compute(def.copy(dpiOn = true, adsPlus = true, blockQuic = false), ctx(HIGH), Load.OVERLOAD)
    T.check("aşırı yükte güçlü cihazda bile isteğe bağlı işler kısılır, boşta süreler yarıya iner", over.off.isNotEmpty() && over.idleScale == 0.5f, over.journal().joinToString(" | "))
    T.check("yoğunlukta boşta süreler %75", HarmonyCore.compute(def, ctx(HIGH), Load.BUSY).idleScale == 0.75f && HarmonyCore.idle(30_000L, over) == 15_000L && HarmonyCore.idle(6_000L, over) == 5_000L)
    T.check("aynı girdi aynı plan (belirlenimci)", HarmonyCore.compute(HEAVY, ctx(LOW)).sig == lHeavy.sig)
}

private fun safetyTests() {
    T.group("sizma61: uyum motoru: güvenliğe ve kullanıcı ayarına dokunmaz")
    val s = AppSettings(dpiOn = true, adsPlus = true, blockQuic = true, quicSplit = true, udpDecoy = false, dnsRace = true)
    val c = GwConfig()
    c.dpi = true; c.blockQuic = true; c.blockDoh = true; c.adsDns = true; c.dropHttps = true; c.flowBudget = 77; c.ipNames = true
    val worst = HarmonyCore.compute(s, ctx(LOW, CompatFacts(batterySaver = true, ttlBroken = true, thermal = 4, metered = true, mobile = true)), Load.OVERLOAD)
    HarmonyCore.applyTo(c, s, worst, compatHedge = true)
    T.check("en kötü koşulda bile DPI, QUIC engeli, DoH engeli, DNS süzgeci, HTTPS kaydı engeli, IP→ad eşleme aynen", c.dpi && c.blockQuic && c.blockDoh && c.adsDns && c.dropHttps && c.flowBudget == 77 && c.ipNames)
    T.check("en kötü koşulda isteğe bağlı işler kısılır", !c.hedge && !c.autoTtl && !c.ja3 && !c.quicSplit && !c.udpDecoy)
    HarmonyCore.applyTo(c, s, HarmonyPlan.NONE, compatHedge = true)
    T.check("sakinken geri açılır; kullanıcının kapattığı (sahte UDP) açılmaz", c.hedge && c.autoTtl && c.ja3 && c.quicSplit && !c.udpDecoy)
    HarmonyCore.applyTo(c, s, HarmonyPlan.NONE, compatHedge = false)
    T.check("cihaz uyum planı yedek denemeyi kapattıysa motor açmaz", !c.hedge)
    T.check("kısılan her özellik kısılabilir katmanda", worst.states.filter { it.value == FState.SHED }.keys.all { FeatureGraph.byId.getValue(it).let { f -> f.tier == Tier.OPTIONAL || f.tier == Tier.COSMETIC } })
    T.check("kullanıcının ayarı değişmez (motor ayar nesnesine yazmaz)", s == AppSettings(dpiOn = true, adsPlus = true, blockQuic = true, quicSplit = true, udpDecoy = false, dnsRace = true))
}

private fun governorTests() {
    T.group("sizma61: uyum motoru: canlı yük (salınımsız)")
    val g = HarmonyGovernor()
    repeat(5) { g.sample(LoadSample(dnsMs = 30)) }
    T.check("olağan gecikmede akıcı, taban öğrenildi", g.load == Load.SMOOTH && g.baseMs == 30)
    g.sample(LoadSample(dnsMs = 400))
    T.check("tek bir yavaş ölçüm seviyeyi değiştirmez", g.load == Load.SMOOTH)
    g.sample(LoadSample(dnsMs = 30)); g.sample(LoadSample(dnsMs = 400))
    T.check("araya sakin ölçüm girerse sayaç sıfırlanır", g.load == Load.SMOOTH)
    g.sample(LoadSample(dnsMs = 200))
    T.check("iki ardışık yüksek ölçüm: yoğun", g.load == Load.BUSY)
    g.sample(LoadSample(dnsMs = 900)); g.sample(LoadSample(dnsMs = 900))
    T.check("çok yüksek gecikme sürerse aşırı yük", g.load == Load.OVERLOAD)
    g.sample(LoadSample(dnsMs = 30)); g.sample(LoadSample(dnsMs = 30))
    T.check("iki sakin ölçüm yetmez", g.load == Load.OVERLOAD)
    g.sample(LoadSample(dnsMs = 30))
    T.check("üç sakin ölçümde bir seviye iner", g.load == Load.BUSY)
    repeat(3) { g.sample(LoadSample(dnsMs = 30)) }
    T.check("sonra akıcıya döner", g.load == Load.SMOOTH)
    val g2 = HarmonyGovernor()
    g2.sample(LoadSample(dnsMs = 20)); g2.sample(LoadSample(dnsMs = 2000)); g2.sample(LoadSample(dnsMs = 200))
    T.check("aşırı + yoğun ardışık: en düşüğüne çıkılır", g2.load == Load.BUSY)
    val g3 = HarmonyGovernor()
    T.check("akış tablosu %90: yoğun, %96: aşırı, sınır bilinmiyorsa yok", g3.instant(LoadSample(tcpFlows = 900, maxTcp = 1000)) == Load.BUSY &&
        g3.instant(LoadSample(udpFlows = 385, maxUdp = 400)) == Load.OVERLOAD && g3.instant(LoadSample(tcpFlows = 5000, maxTcp = 0)) == Load.SMOOTH)
    T.check("yığın belleği %85: yoğun, %93: aşırı", g3.instant(LoadSample(heapPct = 86)) == Load.BUSY && g3.instant(LoadSample(heapPct = 95)) == Load.OVERLOAD && g3.instant(LoadSample(heapPct = 50)) == Load.SMOOTH)
    g3.sample(LoadSample(internalErrors = 10, atMs = 100_000L, periodMs = 30_000L))
    T.check("iç hata artışı", g3.instant(LoadSample(internalErrors = 14)) == Load.BUSY && g3.instant(LoadSample(internalErrors = 40)) == Load.OVERLOAD)
    T.check("zamanlayıcı 3 sn geç: yoğun; 10 sn geç: aşırı (işlemci açlığı)", g3.instant(LoadSample(atMs = 133_000L, periodMs = 30_000L)) == Load.BUSY &&
        g3.instant(LoadSample(atMs = 140_000L, periodMs = 30_000L)) == Load.OVERLOAD && g3.instant(LoadSample(atMs = 130_500L, periodMs = 30_000L)) == Load.SMOOTH)
    T.check("10 dakikalık gecikme uykudur, yük sayılmaz (Doze)", g3.instant(LoadSample(atMs = 730_000L, periodMs = 30_000L)) == Load.SMOOTH)
    val g4 = HarmonyGovernor()
    repeat(3) { g4.sample(LoadSample(dnsMs = 15)) }
    repeat(3) { g4.sample(LoadSample(dnsMs = 300)) }
    val wasBusy = g4.load == Load.BUSY
    repeat(60) { g4.sample(LoadSample(dnsMs = 300)) }
    T.check("ağ kalıcı yavaşladıysa taban yeni olağana uyar", wasBusy && g4.load == Load.SMOOTH, g4.load.name)
    g4.reset()
    T.check("sıfırlanınca taban unutulur", g4.load == Load.SMOOTH && g4.baseMs == 0)
}

private fun breakerTests() {
    T.group("sizma61: uyum motoru: etkinlik sigortaları")
    val b = HarmonyBreakers()
    var t = 1_000_000L
    b.observe(Efficacy(hedged = 0, hedgeWon = 0), t)
    b.observe(Efficacy(hedged = 20, hedgeWon = 0), t)
    T.check("az denemede karar verilmez", b.open(t).isEmpty())
    b.observe(Efficacy(hedged = 40, hedgeWon = 1), t)
    T.check("40 yedekten 1 kazanç (%2.5): yedek bağlantı bu ağda etkisiz", Knob.HEDGE in b.open(t))
    T.check("15 dk sonra yeniden denenir", Knob.HEDGE !in b.open(t + 15 * 60_000L + 1))
    t += 15 * 60_000L + 1
    b.observe(Efficacy(hedged = 80, hedgeWon = 1), t)
    T.check("yine etkisizse 30 dk", Knob.HEDGE in b.open(t + 20 * 60_000L) && Knob.HEDGE !in b.open(t + 30 * 60_000L + 1))
    t += 30 * 60_000L + 1
    b.observe(Efficacy(hedged = 120, hedgeWon = 21), t)
    T.check("işe yararsa kapalı kalır", b.open(t).isEmpty())
    val r = HarmonyBreakers()
    r.observe(Efficacy(races = 0, raceWins = 0), 0)
    r.observe(Efficacy(races = 50, raceWins = 20), 0)
    T.check("yarış sık kazanıyorsa dokunulmaz", r.open(0).isEmpty())
    r.observe(Efficacy(races = 100, raceWins = 20), 0)
    T.check("yarış hiç kazanmıyorsa kısılır", Knob.DNS_RACE in r.open(0))
    r.observe(Efficacy(races = 3, raceWins = 0), 0)
    T.check("sayaç sıfırlanması (yeni yönlendirici) yanlış karar üretmez", Knob.DNS_RACE in r.open(0))
    r.reset()
    T.check("ağ değişince unutulur", r.open(0).isEmpty())
    val pl = HarmonyCore.compute(AppSettings(dpiOn = true), ctx(HIGH), broken = mapOf(Knob.HEDGE to "bu ağda etkisiz (sigorta)"))
    T.check("sigorta plana yansır", !pl.allows(Knob.HEDGE) && pl.state("gw.hedge") == FState.SHED)
}

private fun engineTests() {
    T.group("sizma61: uyum motoru: bekleme (aç-kapa salınımı yok)")
    val e = HarmonyEngine()
    val s = AppSettings(dpiOn = true, udpDecoy = true, dnsRace = true, blockQuic = false)
    var now = 10_000_000L
    val hot = ctx(MIDP, CompatFacts(batterySaver = true))
    val cool = ctx(MIDP)
    T.check("pil tasarrufu: sahte UDP kısıldı", !e.plan(s, hot, now).allows(Knob.UDP_DECOY))
    now += 30_000
    T.check("koşul hemen kalksa da 90 sn dolmadan geri açılmaz", !e.plan(s, cool, now).allows(Knob.UDP_DECOY))
    now += 61_000
    T.check("90 sn sonra geri açılır", e.plan(s, cool, now).allows(Knob.UDP_DECOY))
    T.check("yeniden kısılması anında", !e.plan(s, hot, now + 1).allows(Knob.UDP_DECOY))
    T.check("kullanıcı kapattıysa bekletilmez (tutulacak bir şey yok)", e.plan(s.copy(udpDecoy = false), cool, now + 2).off.keys.none { it == Knob.UDP_DECOY })
    val e2 = HarmonyEngine()
    repeat(3) { e2.observe(LoadSample(dnsMs = 20), Efficacy(), 0) }
    repeat(2) { e2.observe(LoadSample(dnsMs = 900), Efficacy(), 0) }
    T.check("gözlem yükü plana taşır", e2.plan(AppSettings(dpiOn = true, adsPlus = true), ctx(HIGH), 0).load == Load.OVERLOAD)
    e2.networkChanged()
    T.check("ağ değişince yük sıfırlanır", e2.plan(AppSettings(dpiOn = true, adsPlus = true), ctx(HIGH), 1).load == Load.SMOOTH)
}

private fun liveTests() {
    T.group("sizma61: uyum motoru: canlı etki (DNS yarışı, efektler)")
    HarmonyLive.reset()
    T.check("başlangıçta her şeye izin", Knob.values().all { HarmonyLive.allows(it) })
    val full = AppSettings(motion = Motion.FULL, deviceAuto = true, lowPower = false)
    T.check("plan efekt kısmıyorsa tam hareket", full.effectiveMotion == Motion.FULL)
    HarmonyLive.plan = HarmonyCore.compute(full.copy(dpiOn = true, adsPlus = true), ctx(HIGH, CompatFacts(thermal = 3)))
    T.check("ciddi ısınmada tam efektler 'Az'a iner; kullanıcıya 'uyarlandı' gösterilmez", full.effectiveMotion == Motion.REDUCED && !full.motionAdapted && full.motion == Motion.FULL,
        "${full.effectiveMotion} " + HarmonyLive.plan.journal().joinToString(" | "))
    HarmonyLive.plan = HarmonyCore.compute(full.copy(dpiOn = true, adsPlus = true), ctx(LOW, CompatFacts(thermal = 4)))
    T.check("kritik ısınmada kaynak yine yetmezse hareket durur", full.effectiveMotion == Motion.OFF && !full.motionAdapted, "${full.effectiveMotion} " + HarmonyLive.plan.journal().joinToString(" | "))
    T.check("cihaza göre otomatik kapalıysa motor efektlere dokunmaz", full.copy(deviceAuto = false).effectiveMotion == Motion.FULL)
    T.check("düşük güç modu her zaman önce gelir", full.copy(lowPower = true).effectiveMotion == Motion.OFF)
    HarmonyLive.reset()
    T.check("plan kalkınca efektler geri gelir", full.effectiveMotion == Motion.FULL)
    // DNS yarışı: ikinci sunucu önce cevap verirse kazanç sayılır; motor yarışı kısınca yarış olmaz.
    FakeDns(dropFirst = 1, delayMs = 400).use { slow ->
        FakeDns().use { fast ->
            Harness(listOf(slow.addr, fast.addr), retryAfterMs = 900, giveUpAfterMs = 3000).use { h ->
                h.send(clientPacket(0x6101, name = "r1.example.com", srcPort = 46301)); h.reply(3500)
                h.send(clientPacket(0x6102, name = "r2.example.com", srcPort = 46302))
                T.check("yarışta cevap geldi", h.reply(3500) != null)
                Thread.sleep(600)
                T.check("ikinci sunucu önce cevap verdi: yarış kazancı sayıldı", h.fw.raceCount() == 1L && h.fw.raceWinCount() == 1L && h.fw.stats().raceWins == 1L,
                    "yarış=${h.fw.raceCount()} kazanç=${h.fw.raceWinCount()}")
            }
        }
    }
    FakeDns(dropFirst = 1).use { flaky ->
        FakeDns().use { backup ->
            Harness(listOf(flaky.addr, backup.addr), retryAfterMs = 600, giveUpAfterMs = 3000).use { h ->
                HarmonyLive.plan = HarmonyCore.compute(AppSettings(dnsRace = true), ctx(MIDP, CompatFacts(metered = true, mobile = true)))
                h.send(clientPacket(0x6111, name = "r3.example.com", srcPort = 46311)); h.reply(3500)
                h.send(clientPacket(0x6112, name = "r4.example.com", srcPort = 46312))
                T.check("motor yarışı kısınca cevap yine gelir", h.reply(3500) != null)
                T.check("ve yarış yapılmaz", h.fw.raceCount() == 0L)
                HarmonyLive.reset()
            }
        }
    }
}

private fun hiddenTests() {
    T.group("sizma61: uyum motoru: arka planda ve görünmez")
    val pages = File("app/src/main/java/app/dnshizli/ui/Pages.kt").readText()
    T.check("arayüzde motor satırı ya da sayfası yok", !pages.contains("HarmonyLive") && !pages.contains("openHarmony") && !pages.contains("\"h.title\""))
    T.check("motor metinleri arayüz dizgelerinde yok", AuditText.codes().none { it.startsWith("h.") })
    val sv = File("app/src/main/java/app/dnshizli/platform/DnsVpnService.kt").readText()
    T.check("servis: plan uyum katmanıyla birlikte hesaplanıp ağ geçidine uygulanır", sv.contains("engine.plan(prefs.loadSettings(), HarmonyContext(DeviceTune.profile, facts, lastHeap, shield), SystemClock.elapsedRealtime())") &&
        sv.contains("HarmonyLive.plan = hp") && sv.contains("HarmonyCore.applyTo(c, prefs.loadSettings(), hp, p.hedge)") && sv.contains("HarmonyCore.idle(p.udpIdleMs, hp)"))
    T.check("servis: ölçüm (yük, bellek, zamanlayıcı, etkinlik), ağ değişince sıfırlama, arka plan aralığı", sv.contains("engine.observe(LoadSample(") && sv.contains("heapPct = heap,") &&
        sv.contains("Efficacy(st?.hedged") && sv.contains("engine.networkChanged(kind.name") && sv.contains("plan.auditMs * HarmonyLive.plan.tickScale"))
    T.check("servis: ısınma ölçülür", sv.contains("currentThermalStatus"))
    T.check("motor yalnızca iç günlüğe yazar", sv.contains("hp.journal().forEach { Journal.info(\"UYUM\""))
    T.check("çelişki uyarısı korunur: DNS bölme + ODoH", "co.split-odoh" in Coherence.codes(AppSettings(splitDns = true, odoh = OdohMode.STRICT), true, true))
}
