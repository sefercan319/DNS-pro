package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.Random

/**
 * sizma34: adres sınıflandırmanın tek kaynağa ([AddrClass]) taşınması. Eski yedi ayrı uygulama kelimesi kelimesine kâhin olarak
 * kopyalandı; yeni sonuç 200 bin rastgele adreste ya eskiyle AYNI ya da yalnızca belgelenmiş, daha sıkı (daha "yerel") yönde farklı.
 */
internal fun runRound10Tests() {
    try { body() } finally { AddrClass.networkNat64 = null }
}

// ------------------------------------------------------------------ eski uygulamalar (kâhin; değiştirilmez)
private object Old {
    fun privateV4(b: ByteArray, o: Int): Boolean {
        val a = b[o].toInt() and 0xFF
        val c = b[o + 1].toInt() and 0xFF
        return when (a) {
            10, 127 -> true
            172 -> c in 16..31
            192 -> c == 168
            169 -> c == 254
            0 -> (b[o + 1].toInt() or b[o + 2].toInt() or b[o + 3].toInt()) != 0
            else -> false
        }
    }
    fun privateV6(b: ByteArray, o: Int): Boolean {
        val h = b[o].toInt() and 0xFF
        if ((h and 0xFE) == 0xFC) return true
        if (h == 0xFE && (b[o + 1].toInt() and 0xC0) == 0x80) return true
        if (h == 0x00 && b[o + 1].toInt() == 0x64 && (b[o + 2].toInt() and 0xFF) == 0xFF && (b[o + 3].toInt() and 0xFF) == 0x9B) {
            for (k in 4 until 12) if (b[o + k].toInt() != 0) return false
            return privateV4(b, o + 12)
        }
        var zeros10 = true
        for (k in 0 until 10) if (b[o + k].toInt() != 0) { zeros10 = false; break }
        if (!zeros10) return false
        val f = Packets.u16(b, o + 10)
        if (f == 0xFFFF) return privateV4(b, o + 12)
        if (f != 0) return false
        for (k in 12 until 15) if (b[o + k].toInt() != 0) return false
        return b[o + 15].toInt() == 1
    }
    fun embeddedV4(addr: ByteArray): ByteArray? {
        if (addr.size != 16) return null
        var mapped = true
        for (k in 0 until 10) if (addr[k].toInt() != 0) { mapped = false; break }
        if (mapped && (addr[10].toInt() and 0xFF) == 0xFF && (addr[11].toInt() and 0xFF) == 0xFF) return addr.copyOfRange(12, 16)
        val nat64 = addr[0].toInt() == 0x00 && addr[1].toInt() == 0x64 && (addr[2].toInt() and 0xFF) == 0xFF && (addr[3].toInt() and 0xFF) == 0x9B
        if (nat64) { for (k in 4 until 12) if (addr[k].toInt() != 0) return null; return addr.copyOfRange(12, 16) }
        return null
    }
    fun dpiLocal(addr: ByteArray): Boolean {
        if (addr.size == 4) {
            val a = addr[0].toInt() and 0xFF
            val b = addr[1].toInt() and 0xFF
            return privateV4(addr, 0) || (a == 100 && b in 64..127) || a >= 224
        }
        if (addr.size != 16) return false
        if (privateV6(addr, 0)) return true
        if ((addr[0].toInt() and 0xFF) == 0xFF) return true
        embeddedV4(addr)?.let { return dpiLocal(it) }
        return false
    }
    fun mcastBcast(v6: Boolean, dst: ByteArray): Boolean {
        if (v6) return (dst[0].toInt() and 0xFF) == 0xFF
        if ((dst[0].toInt() and 0xF0) == 0xE0) return true
        return dst[0].toInt() == -1 && dst[1].toInt() == -1 && dst[2].toInt() == -1 && dst[3].toInt() == -1
    }
    fun gwLocal(v6: Boolean, a: ByteArray): Boolean {
        if (mcastBcast(v6, a)) return true
        if (!v6) {
            val x = a[0].toInt() and 0xFF
            val y = a[1].toInt() and 0xFF
            return x == 0 || x == 10 || x == 127 || (x == 169 && y == 254) || (x == 172 && y in 16..31) || (x == 192 && y == 168) || (x == 100 && y in 64..127)
        }
        embeddedV4(a)?.let { return gwLocal(false, it) }
        var zero = true
        for (i in 0 until 15) if (a[i].toInt() != 0) { zero = false; break }
        if (zero && (a[15].toInt() == 0 || a[15].toInt() == 1)) return true
        val h = a[0].toInt() and 0xFF
        val g = a[1].toInt() and 0xFF
        return (h and 0xFE) == 0xFC || (h == 0xFE && (g and 0xC0) == 0x80)
    }
    fun globalV4(a: Int, b: Int, c: Int, d: Int): Boolean = when {
        a == 0 || a == 10 || a == 127 || a >= 224 -> false
        a == 100 && b in 64..127 -> false
        a == 169 && b == 254 -> false
        a == 172 && b in 16..31 -> false
        a == 192 && b == 168 -> false
        a == 192 && b == 0 && c == 0 -> false
        a == 192 && b == 0 && c == 2 -> false
        a == 198 && (b == 18 || b == 19) -> false
        a == 198 && b == 51 && c == 100 -> false
        a == 203 && b == 0 && c == 113 -> false
        else -> true
    }
    fun globalV6(b: ByteArray): Boolean {
        if (b.size != 16) return false
        val b0 = b[0].toInt() and 0xFF
        val b1 = b[1].toInt() and 0xFF
        if ((b0 and 0xE0) != 0x20) return false
        if (b0 == 0x20 && b1 == 0x01) {
            val b2 = b[2].toInt() and 0xFF
            val b3 = b[3].toInt() and 0xFF
            if (b2 == 0x00 && b3 == 0x00) return false
            if (b2 == 0x0D && b3 == 0xB8) return false
        }
        if (b0 == 0x20 && b1 == 0x02) return false
        if (b0 == 0x3F && b1 == 0xFF && (b[2].toInt() and 0xF0) == 0) return false
        return true
    }
}

private val NSP = byteArrayOf(0x20, 0x01, 0x0d, 0xb8.toByte(), 0, 0x64, 0, 0, 0, 0, 0, 0)

/** Bilerek eklenen gömülü IPv4 biçimleri ve yeni yerel IPv6 sınıfları: eskinin göremediği, yeninin gördüğü adresler. */
private fun newlyRecognized(a: ByteArray): Boolean {
    if (a.size != 16) return false
    val h = a[0].toInt() and 0xFF; val g = a[1].toInt() and 0xFF
    if (h == 0xFE && (g and 0xC0) == 0xC0) return true                                       // fec0::/10
    var z8 = true; for (k in 0 until 8) if (a[k].toInt() != 0) { z8 = false; break }
    if (z8 && Packets.u16(a, 8) == 0xFFFF && Packets.u16(a, 10) == 0) return true            // SIIT
    var z12 = true; for (k in 0 until 12) if (a[k].toInt() != 0) { z12 = false; break }
    if (z12) return true                                                                       // IPv4 uyumlu (::a.b.c.d)
    if (h == 0x00 && g == 0x64 && (a[2].toInt() and 0xFF) == 0xFF && (a[3].toInt() and 0xFF) == 0x9B && a[4].toInt() == 0 && a[5].toInt() == 1) return true   // 64:ff9b:1::/48
    var nsp = true; for (k in 0 until 12) if (a[k] != NSP[k]) { nsp = false; break }
    return nsp
}

private fun body() {
    val rnd = Random(34)
    fun v4(): ByteArray {
        val b = ByteArray(4).also { rnd.nextBytes(it) }
        when (rnd.nextInt(6)) {
            0 -> b[0] = intArrayOf(0, 10, 127, 169, 172, 192, 100, 224, 239, 240, 255, 198, 203)[rnd.nextInt(13)].toByte()
            1 -> { b[0] = 192.toByte(); b[1] = intArrayOf(0, 168)[rnd.nextInt(2)].toByte(); b[2] = intArrayOf(0, 2, 1)[rnd.nextInt(3)].toByte() }
            2 -> { b[0] = 255.toByte(); b[1] = 255.toByte(); b[2] = 255.toByte(); b[3] = if (rnd.nextBoolean()) 255.toByte() else 254.toByte() }
            3 -> { b[0] = 0; if (rnd.nextBoolean()) { b[1] = 0; b[2] = 0; b[3] = intArrayOf(0, 1, 7)[rnd.nextInt(3)].toByte() } }
            else -> {}
        }
        return b
    }
    fun v6(): ByteArray {
        val a = ByteArray(16).also { rnd.nextBytes(it) }
        val e = v4()
        when (rnd.nextInt(14)) {
            0 -> { a.fill(0, 0, 10); a[10] = -1; a[11] = -1; System.arraycopy(e, 0, a, 12, 4) }                 // eşlenmiş
            1 -> { a.fill(0, 0, 8); a[8] = -1; a[9] = -1; a[10] = 0; a[11] = 0; System.arraycopy(e, 0, a, 12, 4) } // SIIT
            2 -> { a.fill(0, 0, 12); System.arraycopy(e, 0, a, 12, 4) }                                          // IPv4 uyumlu
            3 -> { a.fill(0); a[1] = 0x64; a[2] = -1; a[3] = 0x9B.toByte(); System.arraycopy(e, 0, a, 12, 4) }   // 64:ff9b::/96
            4 -> { a.fill(0); a[1] = 0x64; a[2] = -1; a[3] = 0x9B.toByte(); a[5] = 1; a[6] = e[0]; a[7] = e[1]; a[9] = e[2]; a[10] = e[3] }   // /48
            5 -> { System.arraycopy(NSP, 0, a, 0, 12); System.arraycopy(e, 0, a, 12, 4) }                       // ağ öneki
            6 -> a[0] = intArrayOf(0xFC, 0xFD, 0xFE, 0xFF, 0x20, 0x3F)[rnd.nextInt(6)].toByte()
            7 -> { a[0] = 0xFE.toByte(); a[1] = intArrayOf(0x80, 0xBF, 0xC0, 0xFF)[rnd.nextInt(4)].toByte() }
            8 -> { a.fill(0); a[15] = intArrayOf(0, 1, 2)[rnd.nextInt(3)].toByte() }
            9 -> { a[0] = 0x20; a[1] = intArrayOf(1, 2)[rnd.nextInt(2)].toByte(); if (rnd.nextBoolean()) { a[2] = 0; a[3] = 0 } else { a[2] = 0x0D; a[3] = 0xB8.toByte() } }
            else -> {}
        }
        return a
    }

    T.group("sizma34: adres sınıflandırma tek kaynakta — eski 7 uygulamayla fark çözümlemesi (200 bin adres)")
    var bad = 0; val badEx = ArrayList<String>()
    var intended = 0
    fun hex(a: ByteArray) = a.joinToString("") { "%02x".format(it) }
    fun cmp(what: String, a: ByteArray, old: Boolean, new: Boolean, allowNewerLocal: Boolean) {
        if (old == new) return
        if (allowNewerLocal && new && !old) { intended++; return }
        bad++; if (badEx.size < 6) badEx += "$what ${hex(a)} eski=$old yeni=$new"
    }
    AddrClass.networkNat64 = NSP.copyOf()
    repeat(100_000) {
        val a = v4()
        cmp("privateV4", a, Old.privateV4(a, 0), FilterEngine.privateV4(a, 0), false)
        val av = a[0].toInt() and 0xFF
        cmp("dpiLocal4", a, Old.dpiLocal(a), Dpi.isLocalAddress(a), Packets.u16(a, 0) == 0 && Packets.u16(a, 2) == 0)     // 0.0.0.0 artık yerel
        cmp("gwLocal4", a, Old.gwLocal(false, a), Gw.isLocalDestination(false, a), av >= 240)                          // 240/4 artık yerel
        cmp("mcast4", a, Old.mcastBcast(false, a), isMulticastOrBroadcast(false, a), false)
        cmp("global4", a, Old.globalV4(av, a[1].toInt() and 0xFF, a[2].toInt() and 0xFF, a[3].toInt() and 0xFF),
            Dns.isGlobalIpv4(av, a[1].toInt() and 0xFF, a[2].toInt() and 0xFF, a[3].toInt() and 0xFF), false)
    }
    repeat(100_000) {
        val a = v6()
        val nr = newlyRecognized(a)
        cmp("privateV6", a, Old.privateV6(a, 0), FilterEngine.privateV6(a, 0), nr)
        val zeroAll = a.all { it.toInt() == 0 }
        val emb0 = Old.embeddedV4(a)?.all { it.toInt() == 0 } == true
        cmp("dpiLocal6", a, Old.dpiLocal(a), Dpi.isLocalAddress(a), nr || zeroAll || emb0)                             // "::" ve ::ffff:0.0.0.0 artık yerel
        cmp("gwLocal6", a, Old.gwLocal(true, a), Gw.isLocalDestination(true, a), nr || Old.embeddedV4(a)?.let { (it[0].toInt() and 0xFF) >= 240 } == true)
        cmp("global6", a, Old.globalV6(a), Ip.isGlobalV6(a), false)
        // gömülü IPv4 içeren çoklu yayın da (::ffff:224.x) yeni sınıfta çoklu yayın sayılır; eski yalnız ff00::/8'e bakıyordu
        val emb = AddrClass.embeddedV4(a)
        cmp("mcast6", a, Old.mcastBcast(true, a), isMulticastOrBroadcast(true, a), emb != null && Old.mcastBcast(false, emb))
    }
    T.check("beklenmeyen fark yok (yalnızca belgelenmiş, daha sıkı yönde farklar: $intended)", bad == 0, badEx.joinToString(" | "))
    T.check("farkların hepsi 'artık yerel/özel tanınıyor' yönünde (gevşeme yok)", bad == 0 && intended > 0)

    T.group("sizma34: gömülü IPv4'ün tüm biçimleri — 192.168.1.1 her biçimde yerel")
    fun v6of(vararg w: Int): ByteArray { val o = ByteArray(16); for (i in w.indices) Packets.put16(o, i * 2, w[i]); return o }
    AddrClass.networkNat64 = null
    val forms = linkedMapOf(
        "::ffff:192.168.1.1" to v6of(0, 0, 0, 0, 0, 0xffff, 0xc0a8, 0x0101),
        "::ffff:0:192.168.1.1 (SIIT)" to v6of(0, 0, 0, 0, 0xffff, 0, 0xc0a8, 0x0101),
        "::192.168.1.1 (IPv4 uyumlu)" to v6of(0, 0, 0, 0, 0, 0, 0xc0a8, 0x0101),
        "64:ff9b::192.168.1.1" to v6of(0x64, 0xff9b, 0, 0, 0, 0, 0xc0a8, 0x0101),
        "64:ff9b:1:c0a8:1:100:: (/48 yerel kullanım)" to v6of(0x64, 0xff9b, 1, 0xc0a8, 0x0001, 0x0100, 0, 0),
        "fec0::1 (site-local)" to v6of(0xfec0, 0, 0, 0, 0, 0, 0, 1),
    )
    for ((name, a) in forms) T.check("$name: yeniden bağlama + DPI + ağ geçidi yerel", FilterEngine.privateV6(a, 0) && Dpi.isLocalAddress(a) && Gw.isLocalDestination(true, a))
    val nsp = v6of(0x2001, 0x0db8, 0x64, 0, 0, 0, 0xc0a8, 0x0101)
    T.check("operatör öneki bilinmiyorken 2001:db8:64::192.168.1.1 gömülü sayılmaz", !FilterEngine.privateV6(nsp, 0))
    val cfg = GwConfig(); cfg.nat64 = NSP.copyOf()
    T.check("ağ geçidi öneki öğrenince (GwConfig.nat64) aynı adres yerel: operatör DNS64'ü LAN adresi sentezlese de yakalanır",
        AddrClass.networkNat64?.contentEquals(NSP) == true && FilterEngine.privateV6(nsp, 0) && Gw.isLocalDestination(true, nsp))
    cfg.nat64 = null
    T.check("önek silinince unutulur", AddrClass.networkNat64 == null && !FilterEngine.privateV6(nsp, 0))
    val pub = linkedMapOf("::ffff:8.8.8.8" to v6of(0, 0, 0, 0, 0, 0xffff, 0x0808, 0x0808), "64:ff9b:1:808:8:800::" to v6of(0x64, 0xff9b, 1, 0x0808, 0x0008, 0x0800, 0, 0),
        "::" to v6of(), "2606:4700::1111" to v6of(0x2606, 0x4700, 0, 0, 0, 0, 0, 0x1111))
    for ((name, a) in pub) T.check("$name: yeniden bağlama hedefi değil", !FilterEngine.privateV6(a, 0))
    T.check("64:ff9b:1::/48 biçiminde u baytı (8) dolu ya da sonek dolu: gömülü sayılmaz (geçersiz RFC 6052)",
        AddrClass.embeddedV4(v6of(0x64, 0xff9b, 1, 0xc0a8, 0x0101, 0x0100, 0, 0)) == null && AddrClass.embeddedV4(v6of(0x64, 0xff9b, 1, 0xc0a8, 0x0001, 0x0100, 0, 1)) == null)

    T.group("sizma34: uçtan uca — DNS64 sentezli AAAA cevabı yeniden bağlama korumasına takılır")
    val e = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("x.invalid"))
    fun aaaa(name: String, ip: ByteArray): ByteArray {
        val q = Dns.buildQuery(0x4343, name)
        val r = ByteArray(28); r[0] = 0xC0.toByte(); r[1] = 0x0C
        Packets.put16(r, 2, 28); Packets.put16(r, 4, 1); Packets.put32(r, 6, 60); Packets.put16(r, 10, 16)
        System.arraycopy(ip, 0, r, 12, 16)
        val m = buildAnswer(q, q.size, r, 1)
        Packets.put16(m, Dns.questionEnd(m, 0, m.size) - 4, 28)
        return m
    }
    for ((name, a) in forms) { val m = aaaa("kotu.example.com", a); T.check("AAAA $name → engellenir", e.rebindVerdict(m, 0, m.size)) }
    val ok = aaaa("site.example.com", v6of(0x64, 0xff9b, 1, 0x0808, 0x0008, 0x0800, 0, 0))
    T.check("AAAA 64:ff9b:1::8.8.8.8 (genel) → geçer", !e.rebindVerdict(ok, 0, ok.size))

    T.group("sizma34: metin IP denetimi tek katı ayrıştırıcıdan")
    T.check("Ip.isGlobalV4 / V6 tek kaynakta", Ip.isGlobalV4(byteArrayOf(8, 8, 8, 8)) && !Ip.isGlobalV4(byteArrayOf(192.toByte(), 168.toByte(), 0, 1)) &&
        Ip.isGlobalV6(v6of(0x2606, 0x4700, 0, 0, 0, 0, 0, 0x1111)) && !Ip.isGlobalV6(v6of(0x2001, 0x0db8, 0, 0, 0, 0, 0, 1)) && !Ip.isGlobalV6(v6of(0xfe80, 0, 0, 0, 0, 0, 0, 1)))
    val src = listOf("DnsProbe.kt", "OdohHttp.kt").map { java.io.File("app/src/main/java/app/dnshizli/core/$it").readText() }
    T.check("bootstrap/ODoH adres denetimi elle bölme yerine Ip.parse + AddrClass kullanır (\"300.1.1.1\" gibi taşan değer kabul edilemez)",
        src.all { it.contains("Ip.parse(ip)?.let { it.size == 4 && AddrClass.isGlobal(it) }") && !it.contains("toIntOrNull() ?: return false") })
    val dup = java.io.File("app/src/main/java/app/dnshizli").walkTopDown().filter { it.extension == "kt" && it.name != "AddrClass.kt" }
        .filter { f -> f.readText().let { t -> Regex("""c in 16\.\.31|y in 16\.\.31|b in 16\.\.31""").containsMatchIn(t) } }.map { it.name }.toList()
    T.check("özel ağ kuralı (172.16/12) AddrClass dışında yeniden yazılmamış", dup.isEmpty(), dup.joinToString())
}
