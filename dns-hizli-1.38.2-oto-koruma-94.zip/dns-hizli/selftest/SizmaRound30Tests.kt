package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.Section
import java.io.File

/** sizma54: uygulama güvenlik duvarı — uygulama başına internet engeli (her zaman / yalnızca mobil / yalnızca Wi-Fi). */
internal fun runRound30Tests() {
    fwCore()
    fwIp()
    fwDns()
    fwGateway()
    fwSettings()
    fwUi()
    AppFirewall.reset(); AppAds.reset()
}

private fun fwCore() {
    T.group("sizma54: güvenlik duvarı: kurallar ve ağ türü")
    AppFirewall.reset()
    T.check("kip × ağ: her zaman (ağ yokken değil), yalnızca mobil, yalnızca Wi-Fi; kabloluda yalnızca 'her zaman'",
        FwMode.ALL.blocksOn(NetKind.WIFI) && FwMode.ALL.blocksOn(NetKind.MOBILE) && FwMode.ALL.blocksOn(NetKind.ETHERNET) && !FwMode.ALL.blocksOn(NetKind.NONE) &&
            FwMode.MOBILE.blocksOn(NetKind.MOBILE) && !FwMode.MOBILE.blocksOn(NetKind.WIFI) && !FwMode.MOBILE.blocksOn(NetKind.ETHERNET) &&
            FwMode.WIFI.blocksOn(NetKind.WIFI) && !FwMode.WIFI.blocksOn(NetKind.MOBILE))
    val m = mapOf("com.a.b" to FwMode.ALL, "com.c.d" to FwMode.MOBILE, "org.e.f" to FwMode.WIFI)
    T.check("kodla/çöz gidiş-dönüş, sıralı", AppFirewall.decode(AppFirewall.encode(m)) == m && AppFirewall.encode(m) == "com.a.b=A,com.c.d=M,org.e.f=W")
    T.check("geçersiz paket/kip/biçim atılır", AppFirewall.decode("com.a.b=A,kötü paket=A,com.x.y=Z,=A,com.q.r=AA,com.ok.app=M") == mapOf("com.a.b" to FwMode.ALL, "com.ok.app" to FwMode.MOBILE))
    T.check("en çok ${AppFirewall.MAX_RULES} kural; boş/dev metin boş", AppFirewall.decode((0 until 400).joinToString(",") { "com.p$it.app=A" }).size == AppFirewall.MAX_RULES &&
        AppFirewall.decode(null).isEmpty() && AppFirewall.decode("x".repeat(200_000)).isEmpty())
    T.check("kural yokken silahsız ve hiçbir şey uygulanmaz", !AppFirewall.armed && !AppFirewall.applies())

    var now = 1_000_000L
    var probe = NetKind.WIFI
    var probes = 0
    AppFirewall.clock = { now }
    AppFirewall.netProbe = { probes++; probe }
    AppFirewall.setRules(mapOf("com.c.d" to FwMode.MOBILE))
    val g0 = AppFirewall.gen
    T.check("yalnızca-mobil kural Wi-Fi'deyken uygulanmaz (sahip hiç sorulmaz)", AppFirewall.armed && !AppFirewall.applies() && AppFirewall.net == NetKind.WIFI && probes == 1)
    T.check("ağ türü en çok 3 sn'de bir sorulur", AppFirewall.applies().let { probes == 1 })
    probe = NetKind.MOBILE; now += 3_000
    T.check("mobile geçince uygulanır; kuşak artar (süren akışlar yeniden denetlenir)", AppFirewall.applies() && AppFirewall.gen > g0 && AppFirewall.blocks("com.c.d") && !AppFirewall.blocks("com.a.b") && !AppFirewall.blocks(null))
    val g1 = AppFirewall.gen
    AppFirewall.setNet(NetKind.MOBILE)
    T.check("aynı ağ bildirimi kuşağı değiştirmez", AppFirewall.gen == g1)
    AppFirewall.setNet(NetKind.WIFI)
    T.check("servisin ağ olayı hemen uygulanır (sorgu beklemez)", AppFirewall.gen > g1 && !AppFirewall.applies() && probes == 2)
    val g2 = AppFirewall.gen
    AppFirewall.setRules(mapOf("com.c.d" to FwMode.MOBILE))
    T.check("aynı kurallar kuşağı değiştirmez; farklısı değiştirir", AppFirewall.gen == g2 && AppFirewall.setRules(mapOf("com.c.d" to FwMode.WIFI)).let { AppFirewall.gen > g2 })

    // sahip çözümü
    AppAds.reset()
    AppFirewall.setRules(mapOf("com.bad.app" to FwMode.ALL))
    AppAds.owner = { _, _, sport, _, _ -> if (sport == 5001) "com.bad.app" else if (sport == 5002) "com.good.app" else null }
    val src = byteArrayOf(10, 0, 0, 2); val dst = byteArrayOf(1, 2, 3, 4)
    T.check("engelli uygulama kesilir, diğeri ve sahibi bilinmeyen geçer (yanlış uygulama asla kesilmez)",
        AppFirewall.blocked(6, src, 5001, dst, 443) && !AppFirewall.blocked(6, src, 5002, dst, 443) && !AppFirewall.blocked(6, src, 5003, dst, 443))
    T.check("oturum sayacı", AppFirewall.count("com.bad.app") == 1 && AppFirewall.count("com.good.app") == 0)
    AppAds.owner = null
    T.check("sahip çözücü yoksa (Android 10'dan eski) hiçbir şey kesilmez", !AppFirewall.blocked(6, src, 5001, dst, 443))
    T.check("ağ geçidi gereksinimi: kural varsa", AppFirewall.needsGateway("com.a.b=A") && !AppFirewall.needsGateway("") && !AppFirewall.needsGateway("bozuk"))
    val s0 = AppSettings()
    T.check("tünel yolu: modül ya da kural varsa tüm trafik; vana beklemesindeyse kural tek başına açtırmaz; yaşam döngüsü yalnızca modüllerle",
        !ServicePolicy.gwRoute(s0) && ServicePolicy.gwRoute(s0.copy(appFw = "com.a.b=W")) && !ServicePolicy.gwRoute(s0.copy(appFw = "com.a.b=W"), fwHold = true) &&
            ServicePolicy.gwRoute(s0.copy(adsPlus = true), fwHold = true) && !ServicePolicy.gwWanted(s0.copy(appFw = "com.a.b=A")))
    AppFirewall.reset(); AppAds.reset()
}

private fun ipv4(proto: Int, sport: Int, dport: Int, dst: ByteArray = byteArrayOf(1, 2, 3, 4), frag: Int = 0): ByteArray {
    val b = ByteArray(40)
    b[0] = 0x45; Packets.put16(b, 2, 40); Packets.put16(b, 6, frag); b[8] = 64; b[9] = proto.toByte()
    b[12] = 10; b[13] = 0; b[14] = 0; b[15] = 2
    System.arraycopy(dst, 0, b, 16, 4)
    Packets.put16(b, 20, sport); Packets.put16(b, 22, dport)
    return b
}

private fun fwIp() {
    T.group("sizma54: güvenlik duvarı: WireGuard paket yolu")
    AppFirewall.reset(); AppAds.reset()
    var now = 5_000_000L
    AppAds.clock = { now }; AppFirewall.clock = { now }
    var asked = 0
    AppAds.owner = { _, _, sport, _, _ -> asked++; if (sport in 6000..6099) "com.bad.app" else "com.good.app" }
    T.check("kural yokken hiçbir paket atılmaz ve sahip sorulmaz", !AppFirewall.dropIp(ipv4(6, 6000, 443), 40) && asked == 0)
    AppFirewall.setRules(mapOf("com.bad.app" to FwMode.ALL)); AppFirewall.setNet(NetKind.WIFI)
    T.check("engelli uygulamanın TCP ve UDP paketi atılır, diğerininki geçer",
        AppFirewall.dropIp(ipv4(6, 6000, 443), 40) && AppFirewall.dropIp(ipv4(17, 6001, 443), 40) && !AppFirewall.dropIp(ipv4(6, 7000, 443), 40))
    val a0 = asked
    repeat(50) { now += 100; AppFirewall.dropIp(ipv4(6, 6000, 443), 40); AppFirewall.dropIp(ipv4(6, 7000, 443), 40) }
    T.check("akış kararı önbellekte (her pakette sahip sorulmaz)", asked == a0)
    now += 31_000
    AppFirewall.dropIp(ipv4(6, 6000, 443), 40)
    T.check("30 sn sonra yeniden sorulur", asked == a0 + 1)
    AppFirewall.setRules(mapOf("com.bad.app" to FwMode.MOBILE))
    T.check("kural değişince önbellek boşalır: Wi-Fi'de yalnızca-mobil kural paketi geçirir", !AppFirewall.dropIp(ipv4(6, 6000, 443), 40))
    AppFirewall.setRules(mapOf("com.bad.app" to FwMode.ALL))
    T.check("ICMP ve parça (ilk parça değil) geçer; kısa paket geçer", !AppFirewall.dropIp(ipv4(1, 6000, 443), 40) && !AppFirewall.dropIp(ipv4(6, 6000, 443, frag = 0x0010), 40) &&
        !AppFirewall.dropIp(ipv4(6, 6000, 443), 19))
    val v6 = ByteArray(60)
    v6[0] = 0x60; Packets.put16(v6, 4, 20); v6[6] = 17; v6[7] = 64
    v6[8] = 0xfd.toByte(); v6[23] = 2; v6[24] = 0x20; v6[25] = 0x01; v6[39] = 1
    Packets.put16(v6, 40, 6050); Packets.put16(v6, 42, 443)
    T.check("IPv6 UDP de atılır", AppFirewall.dropIp(v6, 60))
    T.check("WireGuard tünel okuyucusu paketi tünele vermeden denetler", File("app/src/main/java/app/dnshizli/platform/WgVpnService.kt").readText().contains("AppFirewall.armed && AppFirewall.dropIp(buf, n)) continue"))
    AppFirewall.reset(); AppAds.reset()
}

private class FwInner : Forwarder {
    var got = 0
    override val proto: Proto get() = Proto.PLAIN
    override fun start() {}
    override fun onPacket(p: ByteArray, len: Int) { got++ }
    override fun stats() = Stats(queries = got.toLong(), forwarded = got.toLong())
    override fun resetNetwork(reason: String) {}
    override fun clearCache() {}
    override fun close() {}
}

private fun dnsPkt(dns: ByteArray, srcPort: Int): ByteArray {
    val b = ByteArray(Packets.HDR + dns.size)
    System.arraycopy(dns, 0, b, Packets.HDR, dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size); Packets.put16(b, 6, 0x4000); b[8] = 64; b[9] = 17
    Packets.put32(b, 12, Packets.ip(10, 111, 222, 1)); Packets.put32(b, 16, Packets.ip(10, 111, 222, 2))
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, srcPort); Packets.put16(b, 22, 53); Packets.put16(b, 24, 8 + dns.size)
    return b
}

private fun fwDns() {
    T.group("sizma54: güvenlik duvarı: DNS")
    AppFirewall.reset(); AppAds.reset(); FilterRuntime.reset()
    AppAds.owner = { _, _, sport, _, _ -> if (sport == 40100) "com.bad.app" else "com.good.app" }
    AppFirewall.setRules(mapOf("com.bad.app" to FwMode.ALL)); AppFirewall.setNet(NetKind.MOBILE)
    val inner = FwInner()
    val wrote = ArrayList<ByteArray>()
    val fw = FilteringForwarder(inner) { b, o, l -> wrote.add(b.copyOfRange(o, o + l)) }
    val bad = dnsPkt(Dns.buildQuery(0x4141, "example.com"), 40100)
    fw.onPacket(bad, bad.size)
    T.check("süzgeç kapalıyken de engelli uygulamanın sorgusu dışarı gitmez; 'engelli' cevabı aynı kimlikle hemen yazılır",
        inner.got == 0 && wrote.size == 1 && Packets.u16(wrote[0], Packets.HDR) == 0x4141 && Dns.isLocalBlock(wrote[0], Packets.HDR, wrote[0].size - Packets.HDR))
    val good = dnsPkt(Dns.buildQuery(0x4242, "example.com"), 40200)
    fw.onPacket(good, good.size)
    T.check("diğer uygulamanın sorgusu olduğu gibi geçer", inner.got == 1 && wrote.size == 1)
    AppFirewall.setNet(NetKind.WIFI); AppFirewall.setRules(mapOf("com.bad.app" to FwMode.MOBILE))
    fw.onPacket(bad, bad.size)
    T.check("yalnızca-mobil kural Wi-Fi'de sorguyu geçirir", inner.got == 2)
    AppFirewall.reset()
    fw.onPacket(bad, bad.size)
    T.check("kural kalkınca geçer", inner.got == 3)
    AppAds.reset(); FilterRuntime.reset()
}

private fun fwGateway() {
    T.group("sizma54: güvenlik duvarı: ağ geçidi (TCP RST, UDP düşürme, süren akış)")
    AppFirewall.reset(); AppAds.reset()
    val badPorts = java.util.concurrent.ConcurrentHashMap.newKeySet<Int>()
    AppAds.owner = { _, _, sport, _, _ -> if (sport in badPorts) "com.bad.app" else "com.good.app" }
    AppFirewall.setRules(mapOf("com.bad.app" to FwMode.ALL)); AppFirewall.setNet(NetKind.WIFI)
    val srv = Srv { s -> val i = s.getInputStream(); val o = s.getOutputStream(); val b = ByteArray(512); while (true) { val n = i.read(b); if (n < 0) break; o.write(b, 0, n); o.flush() } }
    val r = GRig()
    try {
        val bad = GCli(r, srv.port); badPorts.add(bad.sport)
        val sa = bad.connect()
        T.check("engelli uygulamanın bağlantısı hemen RST alır, sunucuya hiç bağlanılmaz", sa != null && sa.flags and F_RST != 0 && srv.accepted.get() == 0 && r.gw.stats().fwBlocked == 1L)
        val good = GCli(r, srv.port)
        val ga = good.connect()
        T.check("diğer uygulama bağlanır ve veri akar", ga != null && ga.flags == (F_SYN or F_ACK) && good.write("merhaba".toByteArray()).let { good.readAll(7, 3000).decodeToString() == "merhaba" })
        // süren akış: uygulama sonradan engellenir → sonraki paketinde kesilir
        // Test düzeneği: aynı soketin sahibi gerçekte değişmez; burada sahibi "değiştiriyoruz", bu yüzden önce AppAds'in 1 sn'lik
        // sahip önbelleği ve bekleyen ACK'ler bitsin, sonra kural değişsin.
        Thread.sleep(1_200)
        badPorts.add(good.sport)
        AppFirewall.setRules(mapOf("com.bad.app" to FwMode.ALL, "com.x.y" to FwMode.WIFI))      // kural değişimi (kuşak artar)
        good.write("tekrar".toByteArray())
        var rst = false
        val end = System.currentTimeMillis() + 3000
        while (System.currentTimeMillis() < end) { val s = good.next(500) ?: continue; if (s.flags and F_RST != 0) { rst = true; break } }
        T.check("kural değişince süren akış yeniden denetlenir; engelli uygulamanın açık bağlantısı RST ile kesilir", rst && r.gw.stats().fwBlocked == 2L, "rst=$rst fw=${r.gw.stats().fwBlocked} tcp=${r.gw.stats().tcpFlows}")
        // UDP (yankı sunucusu)
        val us = java.net.DatagramSocket(0, java.net.InetAddress.getByAddress(LO4))
        Thread({ try { val bb = ByteArray(2000); val p = java.net.DatagramPacket(bb, bb.size); while (true) { us.receive(p); us.send(java.net.DatagramPacket(bb, p.length, p.socketAddress)) } } catch (_: Exception) {} }).also { it.isDaemon = true }.start()
        val b = ByteArray(200); val data = "ping".toByteArray()
        r.q.clear()
        val u = Gw.udp(b, false, CLI4, LO4, 6200, us.localPort, data, 0, data.size)
        badPorts.add(6200)
        r.gw.onPacket(b.copyOf(u), u)
        T.check("engelli uygulamanın UDP paketi atılır (akış açılmaz, cevap yok)", r.q.poll(800, java.util.concurrent.TimeUnit.MILLISECONDS) == null && r.gw.stats().udpFlows == 0 && r.gw.stats().fwBlocked == 3L, r.gw.stats().toString())
        val u2 = Gw.udp(b, false, CLI4, LO4, 6300, us.localPort, data, 0, data.size)
        r.gw.onPacket(b.copyOf(u2), u2)
        val rep = r.q.poll(3, java.util.concurrent.TimeUnit.SECONDS)
        T.check("diğer uygulamanın UDP akışı açılır ve cevap döner", rep != null && Packets.u16(rep, 22) == 6300 && r.gw.stats().udpFlows == 1, r.gw.stats().toString())
        us.close()
        AppFirewall.setNet(NetKind.MOBILE); AppFirewall.setRules(mapOf("com.bad.app" to FwMode.WIFI))
        val bad2 = GCli(r, srv.port); badPorts.add(bad2.sport)
        val sa2 = bad2.connect()
        T.check("yalnızca-Wi-Fi kural mobil veride bağlantıya izin verir", sa2 != null && sa2.flags == (F_SYN or F_ACK))
    } finally { r.close(); srv.close() }
    val gw = File("app/src/main/java/app/dnshizli/core/Gateway.kt").readText()
    T.check("TCP ve UDP yolunda kuşak denetimi var", gw.contains("f.fwGen != AppFirewall.gen") && gw.contains("ex.fwGen != g"))
    AppFirewall.reset(); AppAds.reset()
}

private fun fwSettings() {
    T.group("sizma54: güvenlik duvarı: ayar, içe aktarma, servis")
    val s = AppSettings(appFw = "com.a.b=A,com.c.d=M")
    val back = SettingsCodec.decode(SettingsCodec.encode(s))
    T.check("dışa/içe aktarmada kurallar korunur", back.appFw == "com.a.b=A,com.c.d=M")
    T.check("ayar anahtarı içe aktarma incelemesinde", "appFw" in ImportReview.REVIEWED)
    T.check("paylaşılan kod bir engeli kaldırır ya da daraltırsa uyarılır", SensitiveChange.RULES in ImportReview.changes(s, s.copy(appFw = "com.c.d=M")) &&
        SensitiveChange.RULES in ImportReview.changes(s, s.copy(appFw = "com.a.b=W,com.c.d=M")))
    T.check("yeni engel eklemek ya da genişletmek uyarı değildir", SensitiveChange.RULES !in ImportReview.changes(s, s.copy(appFw = "com.a.b=A,com.c.d=A,com.e.f=W")))
    val svc = File("app/src/main/java/app/dnshizli/platform/DnsVpnService.kt").readText()
    T.check("servis: tünel yolu ve ağ geçidi gwRoute ile; ağ değişimi güvenlik duvarına bildirilir; vana döngüsü engelli",
        svc.contains("if (gwRoute(settings)) addGatewayRoutes(b, v6)") && svc.contains("if (gwRoute(settings)) attachGateway(t, settings)") &&
            svc.contains("AppFirewall.setNet(kind)") && svc.contains("fwHold = true") && svc.contains("if (v6 || !gwRoute(settings)) b.allowFamily(OsConstants.AF_INET6)"))
    T.check("açılışta kurallar ve ağ sorgusu kurulur", File("app/src/main/java/app/dnshizli/platform/AppOwner.kt").readText().let { it.contains("AppFirewall.setRules(AppFirewall.decode(st.appFw))") && it.contains("AppFirewall.netProbe =") })
    val bad = FwText.M.filter { (_, v) -> v.size != Lang.values().size || v.any { it.isBlank() } }.keys
    T.check("metinler 12 dilde dolu", bad.isEmpty(), bad.toString())
    val ph = FwText.M.filter { (_, v) -> v.map { x -> Regex("\\{\\d}").findAll(x).map { it.value }.toSet() }.toSet().size != 1 }.keys
    T.check("yer tutucular her dilde aynı", ph.isEmpty(), ph.toString())
}

private fun fwUi() {
    T.group("sizma54: güvenlik duvarı: arayüz")
    AppFirewall.reset(); AppAds.reset()
    val awt = AwtGfx(java.awt.image.BufferedImage(1, 1, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics())
    val r = Rig(Rig.base("aqua"), 360, 780, metrics = awt)
    r.host.sdk = 34
    r.host.installedApps = listOf(AppEntry("com.instagram.android", "Instagram"), AppEntry("com.oyun.app", "Süper Oyun"), AppEntry("com.zhiliaoapp.musically", "TikTok"))
    AppAds.labeler = { p -> r.host.installedApps.firstOrNull { it.pkg == p }?.label ?: p }
    r.connectOk()
    r.scene.openSection(Section.FILTER); r.settle(900)
    T.check("Engelleme sayfasında güvenlik duvarı satırı", r.reveal(FwText.t("title")) != null && r.find(FwText.t("title"))?.info?.value == null)
    r.tapText(FwText.t("title"), settleMs = 900)
    T.check("boşken açıklama", TextRecorder().also { r.scene.draw(it) }.runs.any { FwText.t("empty").startsWith(it.s.removeSuffix("…")) && it.s.length > 8 })
    r.tapText(AppAdsText.t("pick"), settleMs = 900)
    r.tapText("Süper Oyun", settleMs = 900)
    T.check("ilk kural bağlıyken: tünelin tüm trafiği alacağı notu görünür", TextRecorder().also { r.scene.draw(it) }.runs.any { FwText.t("routeNote").startsWith(it.s.removeSuffix("…")) && it.s.length > 8 })
    r.host.calls.clear()
    r.tapText(FwText.t("all"), settleMs = 900)
    T.check("'Her zaman engelle' kaydedilir, canlı uygulanır ve tünel yeniden kurulur", r.model.settings.appFw == "com.oyun.app=A" && AppFirewall.rules == mapOf("com.oyun.app" to FwMode.ALL) &&
        "applyApps" in r.host.calls)
    r.tapText(AppAdsText.t("pick"), settleMs = 900)
    r.tapText("TikTok", settleMs = 900)
    r.host.calls.clear()
    r.tapText(FwText.t("mobile"), settleMs = 900)
    T.check("ikinci kural kaydedilir; tünelin yapısı değişmediğinden yeniden kurulmaz", r.model.settings.appFw == "com.oyun.app=A,com.zhiliaoapp.musically=M" && "applyApps" !in r.host.calls)
    T.check("listede rozetler", r.find("Süper Oyun") != null && r.find("TikTok") != null)
    run { val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/guvenlik-duvari.png"); cv.dispose() }
    r.tapText("TikTok", settleMs = 900)
    run { val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/guvenlik-duvari-kip.png"); cv.dispose() }
    r.tapText(FwText.t("allow"), settleMs = 900)
    T.check("'İnternete izin ver' kuralı kaldırır", r.model.settings.appFw == "com.oyun.app=A")
    r.scene.back(); r.settle(600)
    T.check("satır değeri kural sayısı", r.reveal(FwText.t("title")) != null && r.find(FwText.t("title"))?.info?.value == FwText.t("summary", L.lang, "1"))
    // gizlilik raporundan doğrudan
    PrivacyReport.reset(); PrivacyReport.clock = { r.host.now }; PrivacyReport.zoneOffset = { 0 }
    repeat(5) { PrivacyReport.record("com.instagram.android", "graph.facebook.com") }
    r.tapText(PrivacyText.t("title"), settleMs = 900)
    r.tapText("Instagram", settleMs = 900)
    r.tapText(FwText.t("access"), settleMs = 900)
    r.tapText(FwText.t("wifi"), settleMs = 900)
    T.check("gizlilik raporundaki uygulamadan internet erişimi ayarlanır", r.model.settings.appFw == "com.instagram.android=W,com.oyun.app=A")
    T.check("ön izlemeler", File("build/onizleme/guvenlik-duvari.png").isFile && File("build/onizleme/guvenlik-duvari-kip.png").isFile)
    PrivacyReport.reset(); AppFirewall.reset(); AppAds.reset()
}
