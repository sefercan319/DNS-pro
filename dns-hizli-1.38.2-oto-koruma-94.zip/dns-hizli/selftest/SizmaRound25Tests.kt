package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File

/** sizma49: denetim turu — dev mesajda düzenli ifade süresi, sırların her yolda silinmesi, paylaşım metni, atomik yazım, aktarıcı başlık sınırı. */
internal fun runRound25Tests() {
    T.group("sizma49: güvenlik ve hata düzeltmeleri")
    // 1) Bildirim dinleyicisi saldırganın yazdığı mesajı işler: düzenli ifade dev girdide uzun sürmemeli
    val evil = listOf("a".repeat(200_000), ("a-".repeat(40) + ".").repeat(5000), "x".repeat(60) + "." + "y".repeat(100_000), "ğ".repeat(100_000) + ".com")
    var worst = 0L
    for (e in evil) { val t0 = System.nanoTime(); LinkCheck.extract(e); worst = maxOf(worst, (System.nanoTime() - t0) / 1_000_000) }
    T.check("dev/uyumsuz mesajlarda bağlantı çıkarma hızlı (en kötü ${worst} ms < 500)", worst < 500)
    T.check("ilk 4096 karakterden sonrası taranmaz", LinkCheck.extract("a ".repeat(3000) + "kotu.example").isEmpty() && LinkCheck.extract("kotu.example " + "a".repeat(9000)).size == 1)
    T.check("ana makine adında %xx kodlaması açılır (gizlenmiş taklit yakalanır)", LinkCheck.check("https://%7Aiiraat-bonus.example/").host == "ziiraat-bonus.example" &&
        LinkCheck.check("https://ziraat%2Dbonus.xyz/giris").level == LinkCheck.Level.DANGER)
    T.check("ters bölü hilesi: tarayıcı gibi ilk ad alınır", LinkCheck.check("https://ziraat-guvenlik.xyz\\@www.ziraatbank.com.tr/").host == "ziraat-guvenlik.xyz")
    fun src(p: String) = listOf(p, "../$p").map { File(it) }.firstOrNull { it.isFile }?.readText() ?: ""
    val pq = src("app/src/main/java/app/dnshizli/core/PqPsk.kt")
    T.check("PQ1: açma anahtarı zaman aşımı dahil her çıkışta silinir", Regex("""fun exchange\([\s\S]{0,1200}finally \{ p\.dk\.fill\(0\)""").containsMatchIn(pq))
    T.check("PQ2: geçici açma anahtarı ve kalıcı sır her çıkışta silinir", pq.contains("pending?.let { it.dk.fill(0); it.ssStatic.fill(0) }"))
    T.check("değişim tamponu en büyük çerçeveyi alır (araya giren büyük paket akışı bozmaz)", pq.split("ByteArray(Ws.MAX_PAYLOAD)").size == 3)
    val act = src("app/src/main/java/app/dnshizli/platform/MainActivity.kt")
    T.check("paylaşılan metin biçimli CharSequence olsa da okunur", act.contains("getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()") && !act.contains("getStringExtra(Intent.EXTRA_TEXT)"))
    val st = src("app/src/main/java/app/dnshizli/platform/WgStore.kt")
    T.check("giriş sunucusu yapılandırması atomik yazılır", Regex("""fun saveEntry[\s\S]{0,400}renameTo""").containsMatchIn(st))
    val w = src("app/src/main/java/app/dnshizli/platform/WgVpnService.kt")
    T.check("UDP yolunda PQ değişimi yol kilidini tutmaz (ayrı iş parçacığı)", w.contains("Thread({ if (my == gen && !stopping) pqOverSeparateConnection(cfg) }, \"wg-pq\")"))
    T.check("gecikmeli PQ sonucu yol değiştiyse başka tünele uygulanmaz", w.contains("tunnel?.takeIf { it.cfg === cfg }?.let { t ->"))
    val relay = src("tools/stealth/sunucu/main.go")
    T.check("aktarıcı: başlık evresinde okunan bayt sınırlı (satır sonu olmayan dev satır belleği şişiremez)", relay.contains("hl := &headerLimit{r: c, left: maxHeader + 1}") && relay.contains("hl.left = -1"))
}
