package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

/** sizma41: kuantum sonrası — Keccak/SHA3/SHAKE ve ML-KEM (FIPS 203): NIST ACVP vektörleri + Go crypto/mlkem ile karşılıklı doğrulama. */
internal fun runRound17Tests() {
    keccakTests()
    acvpTests()
    propertyTests()
    goInteropTests()
}

private fun hx(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
private fun ByteArray.h() = joinToString("") { "%02x".format(it) }

private class J(private val s: String) {
    var i = 0
    fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
    fun value(): Any? {
        ws()
        return when (s[i]) {
            '{' -> { i++; val m = LinkedHashMap<String, Any?>(); ws(); if (s[i] == '}') { i++; return m }
                while (true) { ws(); val k = str(); ws(); i++; m[k] = value(); ws(); if (s[i++] == '}') return m }; @Suppress("UNREACHABLE_CODE") m }
            '[' -> { i++; val l = ArrayList<Any?>(); ws(); if (s[i] == ']') { i++; return l }
                while (true) { l.add(value()); ws(); if (s[i++] == ']') return l }; @Suppress("UNREACHABLE_CODE") l }
            '"' -> str()
            't' -> { i += 4; true }
            'f' -> { i += 5; false }
            else -> { val st = i; while (i < s.length && (s[i].isDigit() || s[i] == '-' || s[i] == '.')) i++; s.substring(st, i).toLong() }
        }
    }
    fun str(): String { i++; val st = i; while (s[i] != '"') i++; return s.substring(st, i++) }
}
@Suppress("UNCHECKED_CAST") private fun Any?.o() = this as Map<String, Any?>
@Suppress("UNCHECKED_CAST") private fun Any?.a() = this as List<Any?>
private val V by lazy { J(listOf("selftest/data/mlkem_acvp.json", "../selftest/data/mlkem_acvp.json").map { File(it) }.first { it.isFile }.readText()).value().o() }
private fun kem(p: Any?) = when (p) { "ML-KEM-512" -> MlKem.ML_KEM_512; "ML-KEM-1024" -> MlKem.ML_KEM_1024; else -> MlKem.ML_KEM_768 }

private fun keccakTests() {
    T.group("sizma41: Keccak — SHA3 / SHAKE (FIPS 202)")
    val rng = SecureRandom()
    var same = true
    for (n in listOf(0, 1, 71, 72, 73, 135, 136, 137, 500) + List(40) { rng.nextInt(1000) }) {
        val m = ByteArray(n).also { rng.nextBytes(it) }
        same = same && Keccak.sha3_256(m).contentEquals(MessageDigest.getInstance("SHA3-256").digest(m)) &&
            Keccak.sha3_512(m).contentEquals(MessageDigest.getInstance("SHA3-512").digest(m))
    }
    T.check("SHA3-256/512: JDK ile 49 uzunlukta aynı (blok sınırları dahil)", same)
    val sv = listOf(
        Triple(ByteArray(0), "7f9c2ba4e88f827d616045507605853ed73b8093f6efbc88eb1a6eacfa66ef263cb1eea988004b93", "46b9dd2b0ba88d13233b3feb743eeb243fcd52ea62b81b82b50c27646ed5762fd75dc4ddd8c0f200"),
        Triple("abc".toByteArray(), "5881092dd818bf5cf8a3ddb793fbcba74097d5c526a6d35f97b83351940f2cc844c50af32acd3f2c", "483366601360a8771c6863080cc4114d8db44530f8f1e1ee4f94ea37e78b5739d5a15bef186a5386"),
        Triple(ByteArray(200) { 0xa3.toByte() }, "131ab8d2b594946b9c81333f9bb6e0ce75c3b93104fa3469d3917457385da037cf232ef7164a6d1e", "cd8a920ed141aa0407a22d59288652e9d9f1a7ee0c1e7c1ca699424da84a904d2d700caae7396ece"),
    )
    T.check("SHAKE128/256: FIPS 202 / hashlib vektörleri (boş, abc, 200×a3)", sv.all { (m, s128, s256) ->
        Keccak.shake128().absorb(m).squeeze(40).h() == s128 && Keccak.shake256(40, m).h() == s256 })
    val whole = Keccak.shake128().absorb("abc".toByteArray()).squeeze(500)
    val sp = Keccak.shake128().absorb("a".toByteArray()).absorb("bc".toByteArray())
    val parts = sp.squeeze(1) + sp.squeeze(167) + sp.squeeze(168) + sp.squeeze(164)
    T.check("parçalı emme/sıkma tek seferle aynı (oran sınırını aşan çıktı)", parts.contentEquals(whole))
}

private fun acvpTests() {
    T.group("sizma41: ML-KEM — NIST ACVP vektörleri (FIPS 203)")
    val kg = V["keyGen"].a()
    var okKg = 0
    for (t in kg) { val m = t.o(); val kp = kem(m["p"]).keyGenInternal(hx(m["d"] as String), hx(m["z"] as String))
        if (kp.ek.h() == (m["ek"] as String).lowercase() && kp.dk.h() == (m["dk"] as String).lowercase()) okKg++ }
    T.check("anahtar üretimi: ${kg.size}/${kg.size} (512/768/1024)", okKg == kg.size, "$okKg")
    val en = V["encap"].a()
    var okEn = 0
    for (t in en) { val m = t.o(); val r = kem(m["p"]).encapsulateInternal(hx(m["ek"] as String), hx(m["m"] as String))
        if (r.ct.h() == (m["c"] as String).lowercase() && r.key.h() == (m["k"] as String).lowercase()) okEn++ }
    T.check("kapsülleme: ${en.size}/${en.size}", okEn == en.size, "$okEn")
    val de = V["decap"].a()
    var okDe = 0; var rej = 0
    for (t in de) { val m = t.o(); val k = kem(m["p"]).decapsulate(hx(m["dk"] as String), hx(m["c"] as String))
        if (k?.h() == (m["k"] as String).lowercase()) { okDe++; if ((m["why"] as String).contains("modified")) rej++ } }
    T.check("kapsül açma: ${de.size}/${de.size}, bozuk kapsülde örtük ret değeri NIST'inkiyle aynı ($rej durum)", okDe == de.size && rej >= 6, "$okDe")
    val dc = V["dkCheck"].a()
    T.check("açma anahtarı denetimi (H değiştirilmiş → ret): ${dc.size}/${dc.size}", dc.all { val m = it.o(); MlKem.ML_KEM_768.dkValid(hx(m["dk"] as String)) == m["ok"] })
    val ec = V["ekCheck"].a()
    T.check("kapsülleme anahtarı denetimi (katsayı ≥ q → ret): ${ec.size}/${ec.size}", ec.all { val m = it.o(); MlKem.ML_KEM_768.ekValid(hx(m["ek"] as String)) == m["ok"] })
    val badEk = ec.map { it.o() }.first { it["ok"] == false }["ek"] as String
    T.check("geçersiz anahtara kapsülleme yapılmaz", MlKem.ML_KEM_768.encapsulate(hx(badEk)) == null)
}

private fun propertyTests() {
    T.group("sizma41: ML-KEM-768 özellikler")
    val k = MlKem.ML_KEM_768
    T.check("boyutlar: ek 1184, dk 2400, kapsül 1088", k.ekSize == 1184 && k.dkSize == 2400 && k.ctSize == 1088)
    val rng = SecureRandom()
    var ok = true; var t0 = System.nanoTime()
    repeat(30) {
        val kp = k.keyGen(rng); val e = k.encapsulate(kp.ek, rng)!!
        ok = ok && k.decapsulate(kp.dk, e.ct)?.contentEquals(e.key) == true
    }
    val ms = (System.nanoTime() - t0) / 1_000_000 / 30
    T.check("30 rastgele tur: açılan anahtar aynı", ok)
    T.check("tur süresi makul (< 200 ms; ölçülen $ms ms)", ms < 200)
    val kp = k.keyGen(rng); val e = k.encapsulate(kp.ek, rng)!!
    val bad = e.ct.copyOf().also { it[100] = (it[100].toInt() xor 1).toByte() }
    val r1 = k.decapsulate(kp.dk, bad); val r2 = k.decapsulate(kp.dk, bad)
    T.check("tek bit bozuk kapsül: farklı ama belirlenimci anahtar (örtük ret)", r1 != null && !r1.contentEquals(e.key) && r1.contentEquals(r2))
    T.check("yanlış uzunluk: null", k.decapsulate(kp.dk, e.ct.copyOf(1087)) == null && k.decapsulate(kp.dk.copyOf(2399), e.ct) == null)
    val seed = ByteArray(64).also { rng.nextBytes(it) }
    T.check("tohumdan anahtar belirlenimci", k.keyFromSeed(seed).ek.contentEquals(k.keyFromSeed(seed).ek))
    val f = IntArray(256) { rng.nextInt(3329) }
    T.check("NTT ∘ NTT⁻¹ = birim", MlKem.invNtt(MlKem.ntt(f)).contentEquals(f))
    val buf = ByteArray(384); MlKem.byteEncode(f, 12, buf, 0)
    T.check("12 bit kodlama gidiş-dönüş", MlKem.byteDecode(buf, 0, 12).contentEquals(f))
    val src = listOf("app/src/main/java/app/dnshizli/core/MlKem.kt", "../app/src/main/java/app/dnshizli/core/MlKem.kt").map { File(it) }.first { it.isFile }.readText()
    T.check("kapsül karşılaştırması sabit zamanlı (erken çıkışlı contentEquals yok)", !src.contains("ct.contentEquals") && !src.contains("contentEquals(c2)") && src.contains("diff or -diff"))
}

private fun goBinary(): File? {
    val src = listOf("tools/mlkem-referans", "../tools/mlkem-referans").map { File(it) }.firstOrNull { File(it, "main.go").isFile } ?: return null
    val go = listOf("/usr/local/go/bin/go", "/usr/bin/go").map { File(it) }.firstOrNull { it.canExecute() }?.path
        ?: System.getenv("PATH")?.split(File.pathSeparator)?.map { File(it, "go") }?.firstOrNull { it.canExecute() }?.path ?: return null
    val out = File(System.getProperty("java.io.tmpdir"), "mlkemref-" + ListUpdate.sha256Hex(File(src, "main.go").readBytes()).take(16))
    if (out.canExecute()) return out
    val p = ProcessBuilder(go, "build", "-o", out.absolutePath, ".").directory(src).redirectErrorStream(true).start()
    val log = p.inputStream.bufferedReader().readText()
    if (!p.waitFor(180, TimeUnit.SECONDS) || p.exitValue() != 0) { println("  go build: $log"); return null }   // Go < 1.24: crypto/mlkem yok
    return out
}

private fun run(bin: File, vararg a: String): String {
    val p = ProcessBuilder(listOf(bin.path) + a).redirectErrorStream(true).start()
    val o = p.inputStream.bufferedReader().readText().trim(); p.waitFor(30, TimeUnit.SECONDS); return o
}

private fun goInteropTests() {
    T.group("sizma41: ML-KEM-768 — Go crypto/mlkem ile karşılıklı")
    val bin = goBinary()
    if (bin == null) { T.check("Go 1.24+ yok: karşılıklı test atlandı (ACVP vektörleri yine de geçti)", true); return }
    val k = MlKem.ML_KEM_768
    val rng = SecureRandom()
    var ekSame = 0; var goOpensOurs = 0; var weOpenGos = 0
    repeat(5) {
        val seed = ByteArray(64).also { rng.nextBytes(it) }
        val kp = k.keyFromSeed(seed)
        if (run(bin, "ek", seed.h()) == kp.ek.h()) ekSame++
        val e = k.encapsulate(kp.ek, rng)!!
        if (run(bin, "decap", seed.h(), e.ct.h()) == e.key.h()) goOpensOurs++
        val (c, key) = run(bin, "encap", kp.ek.h()).split(" ")
        if (k.decapsulate(kp.dk, hx(c))?.h() == key) weOpenGos++
    }
    T.check("aynı tohumdan aynı ortak anahtar (5/5)", ekSame == 5)
    T.check("Go bizim kapsülümüzü açar (5/5)", goOpensOurs == 5)
    T.check("biz Go'nun kapsülünü açarız (5/5)", weOpenGos == 5)
}
