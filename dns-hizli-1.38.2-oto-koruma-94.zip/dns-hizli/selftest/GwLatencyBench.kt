package app.dnshizli.selftest

import app.dnshizli.core.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean

/** Ağ geçidi gecikme ölçümü: küçük istek/cevap (ping benzeri) süresi; boşta ve paralel büyük indirme sürerken. */
internal fun gwPingRtts(dpi: Boolean, ads: Boolean, load: Boolean, n: Int = 40): List<Double> {
    val r = GRig()
    r.gw.config.dpi = dpi
    if (ads) r.gw.config.ads = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example"))
    val echo = Srv { s -> val i = s.getInputStream(); val o = s.getOutputStream(); val b = ByteArray(64)
        while (true) { val k = i.read(b); if (k < 0) break; o.write(b, 0, k); o.flush() } }
    val bulk = Srv { s -> val o = s.getOutputStream(); val b = ByteArray(16384); try { while (true) o.write(b) } catch (_: Exception) {} }
    val stop = AtomicBoolean(false)
    // Paketler tek kuyrukta: ping istemcisi kendi portunu süzer; yük istemcisi tap ile kendi paketlerini tüketir.
    var loader: Thread? = null
    if (load) {
        val lc = GCli(r, bulk.port)
        val lport = lc.sport
        val acks = java.util.concurrent.LinkedBlockingQueue<ByteArray>()
        r.tap = { p ->
            val ip = (p[0].toInt() and 0xF) * 4
            if (Packets.u16(p, ip + 2) == lport) { acks.add(p); true } else false
        }
        lc.send(F_SYN, mss = 1460); lc.seq++
        val sa = acks.poll(3, java.util.concurrent.TimeUnit.SECONDS)!!
        val ip = (sa[0].toInt() and 0xF) * 4
        lc.rcv = Packets.i32(sa, ip + 4) + 1
        lc.send(F_ACK)
        loader = Thread {
            var got = 0L
            while (!stop.get()) {
                val p = acks.poll(50, java.util.concurrent.TimeUnit.MILLISECONDS) ?: continue
                val h = (p[0].toInt() and 0xF) * 4
                val doff = (p[h + 12].toInt() and 0xF0) ushr 2
                val dl = p.size - h - doff
                if (dl > 0 && Packets.i32(p, h + 4) == lc.rcv) { lc.rcv += dl; got += dl; lc.send(F_ACK) }
                else if (dl > 0) lc.send(F_ACK)
            }
        }.also { it.isDaemon = true; it.start() }
        Thread.sleep(300)
    }
    val c = GCli(r, echo.port)
    c.connect()
    val out = ArrayList<Double>()
    val msg = ByteArray(32) { 7 }
    repeat(n) {
        val t0 = System.nanoTime()
        c.write(msg)
        val back = c.read(32, 3000)
        if (back.size == 32) out.add((System.nanoTime() - t0) / 1e6)
        Thread.sleep(20)
    }
    stop.set(true); loader?.join(500)
    r.close(); echo.close(); bulk.close()
    return out
}

internal fun gwUdpRtts(n: Int = 40): List<Double> {
    val r = GRig()
    val srv = DatagramSocket(0, InetAddress.getByAddress(LO4))
    Thread { val b = ByteArray(512); while (!srv.isClosed) try { val p = DatagramPacket(b, b.size); srv.receive(p); srv.send(DatagramPacket(b, p.length, p.socketAddress)) } catch (_: Exception) {} }.also { it.isDaemon = true; it.start() }
    val buf = ByteArray(200)
    val out = ArrayList<Double>()
    repeat(n) { i ->
        val t0 = System.nanoTime()
        val len = Gw.udp(buf, false, CLI4, LO4, 40000, srv.localPort, ByteArray(16) { i.toByte() }, 0, 16)
        r.gw.onPacket(buf.copyOf(len), len)
        val p = r.q.poll(2, java.util.concurrent.TimeUnit.SECONDS)
        if (p != null) out.add((System.nanoTime() - t0) / 1e6)
        Thread.sleep(20)
    }
    r.close(); srv.close()
    return out
}

internal fun runGwLatencyBench() {
    fun s(l: List<Double>): String { val v = l.sorted(); if (v.isEmpty()) return "yok"; return "n=${v.size} ortanca=%.2f p90=%.2f en çok=%.2f ms".format(v[v.size / 2], v[(v.size * 9) / 10], v.last()) }
    gwPingRtts(false, false, false, 20)   // ısınma
    println("TCP ping boşta:            " + s(gwPingRtts(false, false, false)))
    println("TCP ping boşta DPI:        " + s(gwPingRtts(true, false, false)))
    println("TCP ping boşta Reklam+:    " + s(gwPingRtts(false, true, false)))
    println("TCP ping indirme sürerken: " + s(gwPingRtts(false, false, true)))
    println("TCP ping indirme + DPI:    " + s(gwPingRtts(true, true, true)))
    println("TLS ilk cevap:             " + s(gwTlsFirst(false, false)))
    println("TLS ilk cevap DPI:         " + s(gwTlsFirst(true, false)))
    println("TLS ilk cevap Reklam+:     " + s(gwTlsFirst(false, true)))
    println("TLS ilk cevap DPI+Reklam+: " + s(gwTlsFirst(true, true)))
    println("UDP ping:                  " + s(gwUdpRtts()))
}

/** Yeni TLS bağlantısı: SYN'den sunucunun ilk cevabına dek süre (sayfa açılışındaki her bağlantı bunu öder). */
internal fun gwTlsFirst(dpi: Boolean, ads: Boolean, n: Int = 25): List<Double> {
    val r = GRig()
    r.gw.config.dpi = dpi
    if (ads) r.gw.config.ads = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example"))
    val srv = Srv { s -> val i = s.getInputStream(); val b = ByteArray(4096); val k = i.read(b); if (k > 0) { s.getOutputStream().write(ByteArray(100) { 0x16 }); s.getOutputStream().flush() }; Thread.sleep(200) }
    val out = ArrayList<Double>()
    repeat(n) {
        val c = GCli(r, srv.port)
        val t0 = System.nanoTime()
        c.connect()
        c.write(testHello("example.com"))
        val back = c.read(100, 3000)
        if (back.size == 100) out.add((System.nanoTime() - t0) / 1e6)
        c.send(F_RST)
    }
    r.close(); srv.close()
    return out
}
