package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

/** sizma42: kuantum sonrası WireGuard PSK (ML-KEM-768, Stealth aktarıcısıyla) — biçim, doğrulama, tünel PSK değişimi, Go ile uçtan uca. */
internal fun runRound18Tests() {
    formatTests()
    tunnelPskTests()
    configTests()
    goEndToEnd()
    staticTests()
}

private fun b64(b: ByteArray) = java.util.Base64.getEncoder().encodeToString(b)

/** pq.go'nun yaptığını Kotlin'de yapan sahte aktarıcı (biçim denetimi için; asıl karşılıklı test Go ile). */
private fun fakeRelay(req: ByteArray, base: ByteArray, rng: SecureRandom): Pair<ByteArray, ByteArray> {
    val ek = req.copyOfRange(44, 44 + 1184); val pub = req.copyOfRange(12, 44); val reqMac = req.copyOfRange(req.size - 32, req.size)
    val e = MlKem.ML_KEM_768.encapsulate(ek, rng)!!
    val resp = byteArrayOf(0xF1.toByte(), 'P'.code.toByte(), 'Q'.code.toByte(), '1'.code.toByte()) + e.ct
    return (resp + PqPsk.hmac(base, "dhs-pq1-cevap", resp, reqMac)) to PqPsk.hmac(base, "dhs-pq1-psk", e.key, pub, reqMac)
}

private fun formatTests() {
    T.group("sizma42: PQ1 ileti biçimi ve doğrulama")
    val rng = SecureRandom()
    val base = ByteArray(32).also { rng.nextBytes(it) }; val pub = ByteArray(32).also { rng.nextBytes(it) }
    val p = PqPsk.start(base, pub, 1_700_000_000L, rng)
    T.check("istek: 1260 bayt, 0xF0 'PQ1', zaman BE, ortak anahtar, ek, mac", p.request.size == 1260 && PqPsk.REQ_LEN == 1260 &&
        p.request[0] == 0xF0.toByte() && String(p.request, 1, 3) == "PQ1" && p.request.copyOfRange(12, 44).contentEquals(pub) &&
        java.nio.ByteBuffer.wrap(p.request, 4, 8).long == 1_700_000_000L &&
        PqPsk.hmac(base, "dhs-pq1-istek", p.request.copyOfRange(0, 1228)).contentEquals(p.request.copyOfRange(1228, 1260)))
    val (resp, want) = fakeRelay(p.request, base, rng)
    val r = PqPsk.finish(p, resp, resp.size)
    T.check("doğru cevap: iki taraf aynı PSK'yi türetir", r is PqPsk.Result.Ok && r.psk.contentEquals(want))
    T.check("açma anahtarı kullanımdan sonra silinir", p.dk.all { it == 0.toByte() })
    fun fin(mut: (ByteArray) -> ByteArray): PqPsk.Result { val q = PqPsk.start(base, pub, 1L, rng); val (rs, _) = fakeRelay(q.request, base, rng); val m = mut(rs); return PqPsk.finish(q, m, m.size) }
    T.check("cevap mac'i bozuk → ret", (fin { it.copyOf().also { b -> b[b.size - 1] = (b[b.size - 1].toInt() xor 1).toByte() } } as? PqPsk.Result.Fail)?.code == 0)
    T.check("kapsül bozuk (mac doğru değil) → ret", (fin { it.copyOf().also { b -> b[50] = (b[50].toInt() xor 1).toByte() } } as? PqPsk.Result.Fail)?.code == 0)
    T.check("kısa cevap → ret", (fin { it.copyOf(100) } as? PqPsk.Result.Fail)?.code == 0)
    val other = PqPsk.start(base, pub, 1L, rng); val (rsOther, _) = fakeRelay(other.request, base, rng)
    val q2 = PqPsk.start(base, pub, 1L, rng)
    T.check("başka isteğin cevabı (tekrar) → ret (cevap isteğe bağlı)", (PqPsk.finish(q2, rsOther, rsOther.size) as? PqPsk.Result.Fail)?.code == 0)
    val err = byteArrayOf(0xF2.toByte(), 'P'.code.toByte(), 'Q'.code.toByte(), '1'.code.toByte(), 2)
    T.check("aktarıcı hata kodu okunur", (PqPsk.finish(PqPsk.start(base, pub, 1L, rng), err, 5) as? PqPsk.Result.Fail)?.code == 2)
    T.check("denetim iletisi WireGuard paketinden ayrılır", PqPsk.isControl(err, 5) && PqPsk.isControl(resp, resp.size) && !PqPsk.isControl(byteArrayOf(4, 0, 0, 0, 1), 5) && !PqPsk.isControl(byteArrayOf(1, 0, 0, 0), 4))
}

private fun tunnelPskTests() {
    T.group("sizma42: tünelde PSK değişimi")
    val cPriv = Wg.generatePrivate(); val sPriv = Wg.generatePrivate()
    val base = ByteArray(32) { 7 }; val pq = ByteArray(32) { 9 }
    val cfg = (WgConfig.parse("[Interface]\nPrivateKey = ${b64(cPriv)}\nAddress = 10.77.0.2/32\n[Peer]\nPublicKey = ${b64(Wg.publicKey(sPriv))}\nPresharedKey = ${b64(base)}\nAllowedIPs = 0.0.0.0/0\nEndpoint = 203.0.113.1:51820") as WgConfig.Companion.Result.Ok).cfg
    fun attempt(serverPsk: ByteArray, clientPsk: ByteArray?): Boolean {
        val res = WgResponder(sPriv).also { it.addPeer(WgResponder.Peer(Wg.publicKey(cPriv), serverPsk)) }
        val wire = ArrayList<ByteArray>()
        val t = WgTunnel(cfg, { wire.add(it) }, { _, _, _ -> }, now = { 1000L })
        if (clientPsk != null) t.setPsk(clientPsk, fromPq = true) else t.reconnected()
        val init = wire.first { it[0].toInt() == Wg.TYPE_INITIATION }
        val i = res.consumeInitiation(init, 0, init.size) ?: return false
        val (r, _) = res.respond(i, 1, 1000L)!!
        t.fromNet(r, 0, r.size)
        return t.connected || t.handshakes == 1L
    }
    T.check("yapılandırmadaki PSK ile el sıkışır", attempt(base, null))
    T.check("PQ PSK'ye geçince sunucu da aynıysa el sıkışır", attempt(pq, pq))
    T.check("sunucu eski PSK'deyken yeni PSK ile el sıkışma tutmaz (uyumsuzluk sessiz kalmaz: Smart/yeniden değişim düzeltir)", !attempt(base, pq))
    val t = WgTunnel(cfg, {}, { _, _, _ -> }, now = { 1L })
    t.setPsk(pq, fromPq = true, handshakeNow = false)
    T.check("PSK kaynağı izlenir (bildirimde · PQ)", t.pskFromPq && t.handshakePendingMs() == -1L)
}

private fun configTests() {
    T.group("sizma42: [Stealth] PQ alanı")
    val pin = b64(ByteArray(32))
    fun c(pq: String, psk: Boolean) = WgConfig.parse("[Interface]\nPrivateKey = ${b64(Wg.generatePrivate())}\nAddress = 10.77.0.2/32\n[Peer]\nPublicKey = ${b64(Wg.publicKey(Wg.generatePrivate()))}\n" +
        (if (psk) "PresharedKey = ${b64(ByteArray(32) { 3 })}\n" else "") + "AllowedIPs = 0.0.0.0/0\n[Stealth]\nEndpoint = r.example:443\nPin = $pin\nPath = /AbCdEfGhIjKlMnOpQr\nPQ = $pq")
    T.check("PQ = 1 okunur", (c("1", true) as? WgConfig.Companion.Result.Ok)?.cfg?.stealth?.pq == true)
    T.check("PQ = 0 / yok: kapalı", (c("0", true) as? WgConfig.Companion.Result.Ok)?.cfg?.stealth?.pq == false)
    T.check("PQ için temel PSK zorunlu (istek onunla doğrulanır)", (c("1", false) as? WgConfig.Companion.Result.Err)?.why?.contains("PresharedKey") == true)
    T.check("geçersiz PQ değeri → hata", c("belki", true) is WgConfig.Companion.Result.Err)
}

private fun goEndToEnd() {
    T.group("sizma42: Go aktarıcısıyla uçtan uca kuantum sonrası PSK + WireGuard")
    val bin = relayBinary()
    if (bin == null) { T.check("Go yok: atlandı", true); return }
    val dir = File.createTempFile("dhspq", "").also { it.delete(); it.mkdirs() }
    val gen = ProcessBuilder(bin.path, "-sertifika-uret", "-dizin", dir.path).redirectErrorStream(true).start()
    val out = gen.inputStream.bufferedReader().readText(); gen.waitFor(30, TimeUnit.SECONDS)
    val pinS = Regex("Pin = (\\S+)").find(out)!!.groupValues[1]; val path = Regex("Path = (\\S+)").find(out)!!.groupValues[1]
    val rng = SecureRandom()
    val cPriv = Wg.generatePrivate(); val sPriv = Wg.generatePrivate(); val cPub = Wg.publicKey(cPriv)
    val base = ByteArray(32).also { rng.nextBytes(it) }
    File(dir, "istemci-2").also { it.mkdirs(); File(it, "pub").writeText(b64(cPub) + "\n"); File(it, "psk").writeText(b64(base) + "\n") }
    val log = File(dir, "wg.log")
    val fakeWg = File(dir, "wg").also { it.writeText("#!/bin/sh\necho \"$@\" >> ${log.path}\ncat >> ${log.path}\n"); it.setExecutable(true) }
    // Sahte WireGuard sunucusu: PSK'yi "wg set" günlüğünden okur (gerçek sunucuda çekirdek WireGuard bunu yapar)
    var srvPsk = base
    val udp = DatagramSocket(0, InetAddress.getLoopbackAddress())
    var srvSession: WgSession? = null
    val th = Thread {
        val b = ByteArray(70000)
        while (!udp.isClosed) {
            val dp = DatagramPacket(b, b.size); try { udp.receive(dp) } catch (_: Exception) { break }
            val m = b.copyOf(dp.length)
            if (m[0].toInt() == Wg.TYPE_INITIATION) {
                val res = WgResponder(sPriv).also { it.addPeer(WgResponder.Peer(cPub, srvPsk)) }
                val i = res.consumeInitiation(m, 0, m.size) ?: continue
                val (r, s) = res.respond(i, 5, System.currentTimeMillis())!!; srvSession = s
                try { udp.send(DatagramPacket(r, r.size, dp.socketAddress)) } catch (_: Exception) {}
            }
        }
    }.also { it.isDaemon = true; it.start() }
    val port = ServerSocket(0, 1, InetAddress.getLoopbackAddress()).use { it.localPort }
    val proc = ProcessBuilder(bin.path, "-dinle", "127.0.0.1:$port", "-dizin", dir.path, "-wg", "127.0.0.1:${udp.localPort}", "-wg-komut", fakeWg.path, "-wg-arayuz", "dhs0").redirectErrorStream(true).start()
    try {
        val addr = InetSocketAddress(InetAddress.getLoopbackAddress(), port)
        var up = false
        repeat(50) { if (!up) up = try { Socket().use { s -> s.connect(addr, 200) }; true } catch (_: Exception) { Thread.sleep(100); false } }
        val st = StealthCfg("127.0.0.1", port, null, path, java.util.Base64.getDecoder().decode(pinS), pq = true)
        val plain: (InetSocketAddress) -> Socket = { a -> Socket().also { it.connect(a, 3000) } }
        val sess = StealthClient.open(st, addr, plain)
        val r = PqPsk.exchange(sess, base, cPub, System.currentTimeMillis() / 1000)
        val ok = r as? PqPsk.Result.Ok
        val lines = if (log.isFile) log.readLines() else emptyList()
        T.check("değişim başarılı; aktarıcı wg set ile aynı PSK'yi ayarladı", ok != null && lines.size == 2 &&
            lines[0] == "set dhs0 peer ${b64(cPub)} preshared-key /dev/stdin" && lines[1] == b64(ok.psk), "$r ${lines.joinToString("|")}")
        if (ok != null) srvPsk = java.util.Base64.getDecoder().decode(lines[1])
        // Aynı oturumda WireGuard: yeni PSK ile el sıkışma
        val conf = (WgConfig.parse("[Interface]\nPrivateKey = ${b64(cPriv)}\nAddress = 10.77.0.2/32\n[Peer]\nPublicKey = ${b64(Wg.publicKey(sPriv))}\nPresharedKey = ${b64(base)}\nAllowedIPs = 0.0.0.0/0\nEndpoint = 127.0.0.1:1") as WgConfig.Companion.Result.Ok).cfg
        val tunnel = WgTunnel(conf, { sess.send(it) }, { _, _, _ -> })
        Thread { val b = ByteArray(70000); try { while (true) { val n = sess.receive(b); if (n < 0) break; tunnel.fromNet(b, 0, n) } } catch (_: Exception) {} }.also { it.isDaemon = true; it.start() }
        if (ok != null) tunnel.setPsk(ok.psk, fromPq = true)
        val d = System.currentTimeMillis() + 6000
        while (!tunnel.connected && System.currentTimeMillis() < d) Thread.sleep(20)
        T.check("kuantum sonrası PSK ile WireGuard el sıkışması aktarıcı üzerinden tamamlandı", tunnel.connected && tunnel.pskFromPq)
        sess.close(); tunnel.close()
        // yanlış temel PSK: aktarıcı 1 koduyla reddeder, wg çağrılmaz
        val n0 = log.readLines().size
        val s2 = StealthClient.open(st, addr, plain)
        val bad = PqPsk.exchange(s2, ByteArray(32) { 1 }, cPub, System.currentTimeMillis() / 1000)
        T.check("yanlış temel PSK: kod 1, wg çağrılmaz, oturum kullanılabilir kalır", (bad as? PqPsk.Result.Fail)?.code == 1 && log.readLines().size == n0)
        val skew = PqPsk.exchange(s2, base, cPub, System.currentTimeMillis() / 1000 - 600)
        T.check("10 dk eski zaman: kod 2 (tekrar koruması)", (skew as? PqPsk.Result.Fail)?.code == 2)
        s2.close()
        // PQ kapalı aktarıcı (eski sürüm davranışı): istek WireGuard'a gider, cevap gelmez → zaman aşımı, kod 0
        proc.destroy(); proc.waitFor(5, TimeUnit.SECONDS)
        val p2 = ProcessBuilder(bin.path, "-dinle", "127.0.0.1:$port", "-dizin", dir.path, "-wg", "127.0.0.1:${udp.localPort}", "-pq=false").redirectErrorStream(true).start()
        try {
            var up2 = false
            repeat(50) { if (!up2) up2 = try { Socket().use { s -> s.connect(addr, 200) }; true } catch (_: Exception) { Thread.sleep(100); false } }
            val s3 = StealthClient.open(st, addr, plain)
            val t0 = System.currentTimeMillis()
            val none = PqPsk.exchange(s3, base, cPub, System.currentTimeMillis() / 1000, timeoutMs = 1500)
            T.check("PQ desteklemeyen aktarıcı: zaman aşımı (kod 0), uzun beklemez", (none as? PqPsk.Result.Fail)?.code == 0 && System.currentTimeMillis() - t0 < 4000)
            s3.close()
        } finally { p2.destroy(); p2.waitFor(5, TimeUnit.SECONDS) }
    } finally {
        proc.destroy(); proc.waitFor(5, TimeUnit.SECONDS); proc.destroyForcibly()
        udp.close(); th.join(1000); dir.deleteRecursively()
    }
}

private fun staticTests() {
    T.group("sizma42: servis ve kurulum yapısı")
    fun src(p: String) = listOf(p, "../$p").map { File(it) }.firstOrNull { it.isFile }?.readText() ?: ""
    val w = src("app/src/main/java/app/dnshizli/platform/WgVpnService.kt")
    T.check("saklı PQ PSK ile başlanır, UDP yolunda ayrı bağlantıyla yenilenir", w.contains("WgStore.loadPq(this, cfg.publicKey)") && w.contains("pqOverSeparateConnection(cfg)"))
    T.check("Stealth bağlantısında değişim veri akışından önce", Regex("""pqExchange\(sess[\s\S]{0,1600}stealthSession = sess""").containsMatchIn(w))
    T.check("cevapsız/bozuk değişimde oturum kapatılır, bir kez PQ'suz denenir (döngü yok)", w.contains("skipPqOnce = true; continue"))
    T.check("bildirimde · PQ yalnız PQ PSK etkinken", w.contains("tunnel?.pskFromPq == true"))
    val st = src("app/src/main/java/app/dnshizli/platform/WgStore.kt")
    T.check("PQ PSK Keystore ile sarılı, ortak anahtara bağlı; yeni yapılandırmada silinir", st.contains("sealStrict(clientPub + psk") && st.contains("contentEquals(clientPub)") && Regex("""fun save\(ctx: Context, text: String\)[\s\S]{0,80}clearPq\(ctx\)""").containsMatchIn(st))
    val k = src("tools/stealth/kur.sh")
    T.check("kur.sh: PQ = 1 yazar; aktarıcı yalnız CAP_NET_ADMIN ek yetkisi alır, istemci özel anahtarlarını okuyamaz", k.contains("echo \"PQ = 1\"") &&
        k.contains("AmbientCapabilities=CAP_NET_BIND_SERVICE CAP_NET_ADMIN") && k.contains("chmod 600 \"\$d/priv\"") && k.contains("-wg-arayuz dhs0"))
}
