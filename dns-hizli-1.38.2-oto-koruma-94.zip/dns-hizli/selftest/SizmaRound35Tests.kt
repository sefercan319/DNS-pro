package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.Section
import java.io.File

/** sizma59: uygulamanın kendi kayıtları — geçmişi otomatik sil, uygulama kilidi, ekran görüntüsü engeli. */
internal fun runRound35Tests() {
    retention()
    appLock()
    secureUi()
    PrivacyReport.reset(); FilterLive.clear(); FilterLive.clock = { System.currentTimeMillis() }
}

private fun retention() {
    T.group("sizma59: geçmişi otomatik sil")
    var now = 1_800_000_000_000L
    // günlük
    val log = DiagLog(100) { now }
    log.add("eski"); now += 2 * 3_600_000L; log.add("yeni")
    log.prune(now - 3_600_000L)
    T.check("günlük: süresi dolan satır silinir", log.size() == 1 && log.dump().contains("yeni"))
    // son engellenenler / geçenler
    FilterLive.clear(); FilterLive.keep(true); FilterLive.clock = { now }
    FilterLive.note("eski.example.com", false); FilterLive.notePassed("gecen.example.com")
    now += 2 * 3_600_000L
    FilterLive.note("yeni.example.com", false)
    HistoryTtl.pruneAll(now, HistoryTtl.HOUR)
    T.check("son engellenen/geçen: 1 saatten eskiler silinir, yeniler kalır", FilterLive.recent().map { it.name } == listOf("yeni.example.com") && FilterLive.recentPassed().isEmpty())
    FilterLive.note("yeni.example.com", false)
    T.check("yeniden görülen adın zamanı yenilenir", FilterLive.recent()[0].at == now && FilterLive.recent()[0].count == 2)
    HistoryTtl.pruneAll(now + 10 * 86_400_000L, HistoryTtl.OFF)
    T.check("kapalıyken hiçbir şey silinmez", FilterLive.recent().size == 1)
    // gizlilik raporu
    PrivacyReport.reset(); PrivacyReport.clock = { now }; PrivacyReport.zoneOffset = { 0 }
    val saved = ArrayList<String>(); PrivacyReport.saver = { saved.add(it) }
    PrivacyReport.record("com.a.b", "x.example.com"); now += 86_400_000L; PrivacyReport.record("com.a.b", "x.example.com")
    T.check("rapor 1 hafta: iki gün de durur", PrivacyReport.total() == 2)
    HistoryTtl.pruneAll(now, HistoryTtl.DAY)
    T.check("rapor 1 gün: yalnızca bugün kalır ve diske hemen yazılır", PrivacyReport.total() == 1 && PrivacyReport.keepDays == 1 && saved.last().contains("com.a.b\t1\t"))
    HistoryTtl.pruneAll(now, HistoryTtl.HOUR)
    PrivacyReport.record("com.a.b", "x.example.com")
    T.check("rapor 1 saat: hiç tutulmaz, mevcut silinir", PrivacyReport.total() == 0 && PrivacyReport.isEmpty() && saved.last() == "")
    HistoryTtl.pruneAll(now, HistoryTtl.WEEK)
    PrivacyReport.record("com.a.b", "x.example.com")
    T.check("yeniden 1 haftaya dönünce tutar", PrivacyReport.total() == 1 && PrivacyReport.keepDays == 7)
    PrivacyReport.reset()
    // oturumlar
    val ses = SessionLog.encode(listOf(Session("cloudflare", Proto.DOH, now - 3 * 86_400_000L, now - 2 * 86_400_000L, EndReason.USER, 5),
        Session("quad9", Proto.DOT, now - 7_200_000L, now - 600_000L, EndReason.USER, 9)))
    T.check("oturumlar: 1 günden eski silinir, kapalıyken aynen", SessionLog.decode(SessionLog.prune(ses, HistoryTtl.DAY, now)).map { it.serverId } == listOf("quad9") &&
        SessionLog.prune(ses, HistoryTtl.OFF, now) === ses && SessionLog.decode(SessionLog.prune(ses, HistoryTtl.HOUR, now)).map { it.serverId } == listOf("quad9"))
    // ayarlar
    val s = AppSettings(historyTtl = HistoryTtl.DAY, appLock = true, secureScreen = true)
    val back = SettingsCodec.decode(SettingsCodec.encode(s))
    T.check("ayar gidiş-dönüş", back.historyTtl == HistoryTtl.DAY && back.appLock && back.secureScreen)
    T.check("içe aktarmada: saklamayı uzatmak, kilidi ya da ekran engelini kapatmak uyarılır; kısaltmak uyarılmaz",
        SensitiveChange.PRIVACY in ImportReview.changes(s, s.copy(historyTtl = HistoryTtl.WEEK)) && SensitiveChange.PRIVACY in ImportReview.changes(s, s.copy(historyTtl = HistoryTtl.OFF)) &&
            SensitiveChange.PRIVACY in ImportReview.changes(s, s.copy(appLock = false)) && SensitiveChange.PRIVACY in ImportReview.changes(s, s.copy(secureScreen = false)) &&
            SensitiveChange.PRIVACY !in ImportReview.changes(s, s.copy(historyTtl = HistoryTtl.HOUR)))
    val app = File("app/src/main/java/app/dnshizli/platform/App.kt").readText()
    val prefs = File("app/src/main/java/app/dnshizli/platform/PrefsStore.kt").readText()
    T.check("süreç boyunca 5 dk'da bir budanır; oturum eklenirken de", app.contains("HistoryTtl.pruneAll(System.currentTimeMillis(), s.historyTtl)") && app.contains("prefs.pruneSessions(s.historyTtl)") &&
        prefs.contains("SessionLog.prune(SessionLog.add(cur.sessions, s), cur.historyTtl"))
    val r = Rig(Rig.base("aqua"))
    FilterLive.clear(); FilterLive.clock = { r.host.now - 5 * 3_600_000L }; FilterLive.note("eski.example.com", false); FilterLive.clock = { r.host.now }
    r.model.update { it.copy(historyTtl = HistoryTtl.HOUR) }
    T.check("ayar kısalınca eskiler hemen silinir", FilterLive.recent().isEmpty())
    FilterLive.clear()
}

private fun appLock() {
    T.group("sizma59: uygulama kilidi")
    val r = Rig(Rig.base("aqua").copy(appLock = true))
    T.check("kilit açıkken uygulama kilitli başlar; içerik çizilmez, yalnızca kilit kapağı", r.model.locked &&
        TextRecorder().also { r.scene.draw(it) }.runs.map { it.s }.let { it.contains(SecText.t("locked")) && it.contains(SecText.t("unlock")) && !it.contains(app.dnshizli.ui.Strings.GLOBE) })
    T.check("erişilebilirlikte yalnızca 'kilidi aç'", r.items().size == 1 && r.items()[0].info.label.startsWith(SecText.t("unlock")))
    r.host.authAnswer = null
    r.model.onForeground(1000)
    T.check("öne gelince doğrulama istenir (bir kez)", r.host.authCalls == 1)
    r.tapText(SecText.t("unlock"))
    T.check("istem açıkken dokunmak ikinci istem açmaz", r.host.authCalls == 1)
    r.host.authDone!!.invoke(false); r.settle(100)
    T.check("iptal/başarısızlıkta kilit kalır", r.model.locked)
    r.host.authAnswer = true
    r.tapText(SecText.t("unlock"), settleMs = 300)
    T.check("doğrulanınca kilit kalkar ve arayüz görünür", !r.model.locked && r.items().size > 1)
    r.model.onBackground(5000); r.model.onForeground(9000)
    T.check("arka plandan dönünce yeniden kilitlenir ve doğrulama istenir", r.host.authCalls == 3 && !r.model.locked)   // authAnswer=true: hemen açıldı
    r.host.authAnswer = null
    r.model.onBackground(10_000); r.model.onForeground(11_000)
    val calls = r.host.authCalls
    r.model.onBackground(11_500)                  // doğrulama istemi uygulamayı arka plana atar: sayılmaz
    r.host.authDone!!.invoke(true); r.model.onForeground(12_000)
    T.check("istem sürerken arka plana geçiş yeniden kilitlemez (döngü yok)", !r.model.locked && r.host.authCalls == calls)
    val noLock = Rig(Rig.base("aqua"))
    noLock.host.canLockVal = false
    noLock.model.setAppLock(true)
    T.check("telefonda ekran kilidi yoksa açılmaz ve nedeni söylenir", !noLock.model.settings.appLock && noLock.model.toast?.text == SecText.t("noLock"))
    val off = Rig(Rig.base("aqua"))
    off.model.onBackground(1); off.model.onForeground(2)
    T.check("kilit kapalıyken hiç kilitlenmez", !off.model.locked && off.host.authCalls == 0)
    val ma = File("app/src/main/java/app/dnshizli/platform/MainActivity.kt").readText()
    T.check("platform: biyometri ya da ekran kilidi (uygulama PIN saklamaz), FLAG_SECURE, son uygulamalar önizlemesi",
        ma.contains("BIOMETRIC_WEAK or") && ma.contains("DEVICE_CREDENTIAL") && ma.contains("FLAG_SECURE") && ma.contains("setRecentsScreenshotEnabled(!model.settings.hideOnLockscreen && !secure)") &&
            ma.contains("model.onForeground(") && ma.contains("model.onBackground("))
}

private fun secureUi() {
    T.group("sizma59: ayar satırları")
    val awt = AwtGfx(java.awt.image.BufferedImage(1, 1, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics())
    val r = Rig(Rig.base("aqua"), 360, 780, metrics = awt)
    r.scene.openSection(Section.NOTIFICATIONS); r.settle(900)
    T.check("bildirim/gizlilik sayfasında kilit ve ekran görüntüsü anahtarları", r.reveal(SecText.t("lock")) != null && r.reveal(SecText.t("secure")) != null)
    r.tapText(SecText.t("secure"), settleMs = 600)
    T.check("ekran görüntüsü engeli açılır ve pencereye uygulanır", r.model.settings.secureScreen && r.host.secureApplied == 1)
    r.tapText(SecText.t("lock"), settleMs = 600)
    T.check("kilit açılır (açılır açılmaz kilitlenmez)", r.model.settings.appLock && !r.model.locked && r.host.secureApplied == 2)
    r.scene.back(); r.settle(600)
    r.scene.openSection(Section.STATS); r.settle(900)
    T.check("istatistik sayfasında saklama süresi seçici", r.reveal(SecText.t("ttl")) != null)
    run { val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/gecmis-otomatik-sil.png"); cv.dispose() }
    val lk = Rig(Rig.base("aqua").copy(appLock = true), 360, 780, metrics = awt)
    run { val cv = AwtCanvas(lk.w, lk.h); lk.draw(cv.gfx); cv.savePng("build/onizleme/uygulama-kilidi.png"); cv.dispose() }
    val bad = SecText.M.filter { (_, v) -> v.size != Lang.values().size || v.any { it.isBlank() } }.keys
    T.check("metinler 12 dilde; süre seçenekleri her dilde 4", bad.isEmpty() && Lang.values().all { SecText.ttlOptions(it).size == 4 })
}
