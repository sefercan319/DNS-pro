package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.GlobeNode
import app.dnshizli.ui.GlobePage
import app.dnshizli.ui.Strings
import java.awt.image.BufferedImage
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** sizma51: küre 2 — yüksek çözünürlüklü kara ve ülke verisi, matris izdüşümü, fizik, temaya/stile uyan görünüm, ön izlemeler. */
internal fun runRound27Tests() {
    dataTests()
    cameraTests()
    lookTests()
    drawTests()
    previews()
}

private fun dataTests() {
    T.group("sizma51: vektör harita (Natural Earth 1:10m)")
    val map = GlobeLand.map
    T.check("255 ülke, tüm yaylar; ≥ 200 000 köşe (önceki 91 000 sınır+kıyı noktasının 2 katından fazla, tam çokgen)", map.countryCount == 255 && map.arcCount == GlobeVec.ARC_COUNT && map.vertexCount >= 200_000, "${map.vertexCount}")
    T.check("köşeler birim vektör, düzeyler 0..7", (0 until map.vertexCount step 101).all { v -> val x = map.xyz[3 * v]; val y = map.xyz[3 * v + 1]; val z = map.xyz[3 * v + 2]; abs(x * x + y * y + z * z - 1f) < 1e-4f && map.level[v] in 0..7 })
    T.check("yay uçları her düzeyde var (halkalar kopmaz)", (0 until map.arcCount).all { a -> map.level[map.arcStart[a]].toInt() == 7 && map.level[map.arcStart[a + 1] - 1].toInt() == 7 })
    fun name(lat: Double, lon: Double) = map.countryAt(lat, lon).let { if (it < 0) "" else map.names[it] }
    T.check("ülke konumları: Türkiye, Fransa, Brezilya, Avustralya; okyanus ortası boş", name(39.0, 35.0) == "Turkey" && name(47.0, 2.5) == "France" && name(-10.0, -55.0) == "Brazil" && name(-25.0, 134.0) == "Australia" && name(0.0, -30.0) == "" && name(-20.0, -140.0) == "")
    T.check("adalar gerçek şekliyle: Girit, Sicilya, Sri Lanka, Malta, Kıbrıs, Bozcaada", name(35.25, 24.9) == "Greece" && name(37.5, 14.0) == "Italy" && name(7.8, 80.7) == "Sri Lanka" && name(35.89, 14.44) == "Malta" &&
        name(34.9, 33.0).let { it == "Cyprus" || it == "N. Cyprus" } && name(39.83, 26.05) == "Turkey", "${name(39.83, 26.05)} ${name(35.89, 14.44)}")
    T.check("iç içe ülkeler (delikler): Lesotho, Güney Afrika'nın içinde ayrı ülke", name(-29.5, 28.2) == "Lesotho" && name(-30.0, 25.0) == "South Africa")
    fun g(lat: Double, lon: Double) = map.group[map.countryAt(lat, lon)]
    T.check("komşu ülkeler farklı tonda: Fransa/Almanya, İspanya/Portekiz, ABD/Kanada, Brezilya/Arjantin, Türkiye/İran, Hindistan/Çin",
        g(47.0, 2.5) != g(51.0, 10.5) && g(40.0, -3.7) != g(39.6, -8.0) && g(39.0, -98.0) != g(56.0, -106.0) &&
            g(-10.0, -55.0) != g(-34.0, -64.0) && g(39.0, 35.0) != g(32.5, 54.0) && g(22.0, 79.0) != g(34.0, 100.0))
    val kinds = IntArray(3); for (a in 0 until map.arcCount) kinds[map.kind[a].toInt()]++
    T.check("yay türleri: ülkeler arası sınır ve kıyı", kinds[0] > 1000 && kinds[1] > 200, kinds.joinToString())
    fun v(la: Double, lo: Double) = floatArrayOf((kotlin.math.cos(Math.toRadians(la)) * kotlin.math.cos(Math.toRadians(lo))).toFloat(), (kotlin.math.cos(Math.toRadians(la)) * kotlin.math.sin(Math.toRadians(lo))).toFloat(), kotlin.math.sin(Math.toRadians(la)).toFloat())
    val seamPts = listOf(v(66.0, 180.0), v(66.0, -180.0), v(-90.0, 30.0)); val real = listOf(v(65.0, 179.99), v(-16.5, -179.99), v(-78.0, 160.0))
    T.check("yapay kesim (tam 180°, Güney Kutbu) çizilmez; yanındaki gerçek kıyılar (Çukotka, Fiji, Antarktika) çizilir", seamPts.all { GlobeLand.isSeam(it[0], it[1], it[2]) } && real.none { GlobeLand.isSeam(it[0], it[1], it[2]) })
    T.check("ayrıntı düzeyi yakınlaştıkça incelir", GlobeLand.minLevel(170f) > GlobeLand.minLevel(800f) && GlobeLand.minLevel(170f * 12) == 0)
    T.check("kaba kara maskesi: Ankara kara, Pasifik ortası deniz; kıyıya yakın adalar kaçmaz", map.maybeLand(Math.toRadians(39.9), Math.toRadians(32.8)) && !map.maybeLand(Math.toRadians(-20.0), Math.toRadians(-140.0)) && map.maybeLand(Math.toRadians(35.89), Math.toRadians(14.44)))
    T.check("üretici betik veri kaynağını belgeler", File("tools/kure/kara.py").readText().let { it.contains("countries-10m") && it.contains("Douglas") && it.contains("zlib") && it.contains("MASK") })
    T.check("eski nokta verisi kaldırıldı", !File("app/src/main/java/app/dnshizli/core/GlobeData.kt").exists() && !File("app/src/main/java/app/dnshizli/core/GlobeDataFine.kt").exists())

    T.group("sizma51: yarım ton ve ışık")
    val (k1, _) = GlobeHalftone.levelFor(170f); val (k12, _) = GlobeHalftone.levelFor(170f * 12)
    T.check("yarım ton: ekranda nokta aralığı 1,25–2,5 dp, yakınlaştıkça ızgara sıklaşır", (100..3000 step 37).all { r -> val (k, _) = GlobeHalftone.levelFor(r.toFloat()); val s = Math.PI / (GlobeHalftone.BASE_RINGS shl k) * r; s >= GlobeHalftone.MIN_SPACING - 1e-3 && s < 2 * GlobeHalftone.MIN_SPACING + 1e-3 } && k12 > k1)
    T.check("yakın planda yüzey ızgarası ≥ 40 milyon noktalık küreye denk", GlobeHalftone.totalPoints(k12 + 1) >= 40_000_000L, "${GlobeHalftone.totalPoints(k12 + 1)}")
    val cam = GlobeCamera(Math.toRadians(39.0), Math.toRadians(35.0), 1.0); val mm = FloatArray(9); cam.matrix(mm)
    val buf = GlobeHalftone.Buf()
    val n1 = GlobeHalftone.generate(k1, mm, cam.lat0, cam.lon0, 180f, 180f, 170f, 360f, 360f, map, buf)
    val all = GlobeHalftone.Buf(); val n0 = GlobeHalftone.generate(k1, mm, cam.lat0, cam.lon0, 180f, 180f, 170f, 360f, 360f, null, all)
    T.check("noktalar ekranda; kaba maske denizdekileri eler (≥ %50)", n1 > 3000 && n1 < n0 * 0.5 && (0 until buf.n).all { buf.a[2 * it] in -3f..363f && buf.a[2 * it + 1] in -3f..363f }, "$n1 / $n0")
    val z8 = GlobeCamera(Math.toRadians(39.0), Math.toRadians(35.0), 8.0); z8.matrix(mm)
    val rz = 170f * 8; val (kz, _) = GlobeHalftone.levelFor(rz)
    val b8 = GlobeHalftone.Buf(); val n8 = GlobeHalftone.generate(kz, mm, z8.lat0, z8.lon0, 180f, 180f, rz, 360f, 360f, null, b8)
    T.check("yakın planda yalnız görünen bölge üretilir (ekran başına sınırlı nokta)", n8 in 5000..120000, "$n8")
    val sh = GlobeShading(128, GlobeLook.of(Themes.aqua, UiStyle.AQUA))
    fun a(arr: IntArray, x: Float, y: Float): Int { val c = sh.size / 2f; val px = (c + x * sh.radiusPx).toInt(); val py = (c - y * sh.radiusPx).toInt(); return (arr[py * sh.size + px] ushr 24) and 0xFF }
    T.check("ışın izleme: ışıklı yarım (sol üst) aydınlık, gece yarısı (sağ alt) karanlık, yumuşak geçiş", a(sh.shade, -0.4f, 0.4f) < 60 && a(sh.shade, 0.6f, -0.6f) > 150 && a(sh.shade, 0.3f, -0.2f) in 40..200)
    val hh = GlobeShading.norm(GlobeShading.LX, GlobeShading.LY, GlobeShading.LZ + 1f)
    T.check("okyanus parlaması (GGX) yarı yol yönünde tepe yapar, gece yüzünde yok", a(sh.spec, hh[0], hh[1]) > 40 && a(sh.spec, hh[0], hh[1]) > 4 * a(sh.spec, 0.3f, -0.3f) && a(sh.spec, 0.7f, -0.6f) < 20, "${a(sh.spec, hh[0], hh[1])} ${a(sh.spec, 0.3f, -0.3f)}")
    T.check("atmosfer: kenarda ve dışında hale, merkezde ve uzakta yok", a(sh.atmo, -0.7f, 0.7f) > a(sh.atmo, 0f, 0f) && a(sh.atmo, -0.73f, 0.73f) > 0 && a(sh.atmo, -0.99f, 0.99f) == 0)
}

private fun cameraTests() {
    T.group("sizma51: kamera matrisi ve fizik")
    val c = GlobeCamera(Math.toRadians(-40.0), Math.toRadians(35.0)); val p = GlobeCamera.P(); val m = FloatArray(9)
    c.matrix(m)
    val rnd = java.util.Random(7)
    var ok = true
    repeat(200) {
        val la = Math.toRadians(rnd.nextDouble() * 180 - 90); val lo = Math.toRadians(rnd.nextDouble() * 360 - 180)
        c.project(la, lo, p)
        val wx = cos(la) * cos(lo); val wy = cos(la) * sin(lo); val wz = sin(la)
        val x = m[0] * wx + m[1] * wy + m[2] * wz; val y = m[3] * wx + m[4] * wy + m[5] * wz; val z = m[6] * wx + m[7] * wy + m[8] * wz
        if (abs(x - p.x) > 1e-5 || abs(y - p.y) > 1e-5 || abs(z - p.z) > 1e-5) ok = false
    }
    T.check("matris izdüşümü trigonometrik izdüşümle aynı (200 rastgele nokta)", ok)
    val ll = DoubleArray(2)
    c.project(Math.toRadians(41.0), Math.toRadians(29.0), p)
    T.check("ters izdüşüm: ekrandan enlem/boylama dönüş", c.unproject(p.x, p.y, ll) && abs(Math.toDegrees(ll[0]) - 41.0) < 1e-6 && abs(Math.toDegrees(ll[1]) - 29.0) < 1e-6 && !c.unproject(0.8, 0.8, ll))
    // iki parmak: parmakların altındaki nokta yerinde kalır
    val z = GlobeCamera(0.0, 0.0, 1.0)
    z.unproject(60.0 / 150, -(-40.0) / 150, ll)
    val la = ll[0]; val lo = ll[1]
    z.zoomAt(2.0, 60.0, -40.0, 150.0)
    z.project(la, lo, p)
    T.check("yakınlaştırma parmak altındaki noktayı tutar", abs(p.x * 150 - 60) < 0.5 && abs(-p.y * 150 - (-40)) < 0.5 && z.zoom == 2.0, "${p.x * 150} ${-p.y * 150}")
    // parmak durup kalkarsa savrulmaz
    val s = GlobeCamera(0.0, 0.0); s.beginDrag(); repeat(5) { s.dragBy(-20.0, 0.0, 100.0, 0.016) }; s.endDrag(heldSec = 0.3)
    val l0 = s.lon0; s.tick(0.2, false)
    T.check("durup bırakınca atalet yok", s.lon0 == l0)
    val f = GlobeCamera(0.0, 0.0); f.beginDrag(); repeat(5) { f.dragBy(-400.0, 0.0, 100.0, 0.016) }; f.endDrag()
    val a0 = f.lon0; f.tick(0.01, false)
    T.check("sert savurmada hız sınırlı", abs(GlobeCamera.wrap(f.lon0 - a0)) <= GlobeCamera.MAX_SPEED * 0.01 + 1e-9)
    val st = GlobeCamera(); st.zoomStep()
    T.check("çift dokunma yumuşak: hedef 2, yakınlaşma kareler boyunca", st.zoomTarget == 2.0 && st.zoom == 1.0 && run { st.tick(0.05, false); st.zoom > 1.0 && st.zoom < 2.0 } && run { repeat(120) { st.tick(0.016, false) }; st.zoom == 2.0 })
    val fl = GlobeCamera(Math.toRadians(170.0), 0.0); fl.flyTo(0.0, Math.toRadians(-170.0))
    fl.tick(0.016, false)
    T.check("uçuş kısa yoldan (180°'yi geçerek) ve hedefe varır", (fl.lon0 > Math.toRadians(170.0) || fl.lon0 < Math.toRadians(-170.0)) && run { repeat(200) { fl.tick(0.016, false) }; !fl.flying && abs(fl.lon0 - Math.toRadians(-170.0)) < 1e-6 })
    val ds = GlobeCamera(0.0, 0.0); ds.zoomStepAt(Math.toRadians(20.0), Math.toRadians(30.0)); repeat(200) { ds.tick(0.016, false) }
    T.check("noktaya çift dokunma: oraya uçar ve yakınlaşır", abs(ds.lat0 - Math.toRadians(20.0)) < 1e-4 && abs(ds.lon0 - Math.toRadians(30.0)) < 1e-4 && ds.zoom == 2.0)
    val zr = GlobeCamera(0.0, 0.0, GlobeCamera.MAX_ZOOM)
    zr.zoomAt(2.0, 0.0, 0.0, 150.0)
    val overZ = zr.zoom
    zr.endDrag(1.0); repeat(200) { zr.tick(0.016, false) }
    T.check("yakınlaştırma lastiği: sınırı dirençle aşar (yarı yoldan az), bırakınca sınıra döner", overZ > GlobeCamera.MAX_ZOOM && overZ < GlobeCamera.MAX_ZOOM * 1.5 && abs(zr.zoom - GlobeCamera.MAX_ZOOM) < 1e-3, "$overZ")
    val zf = GlobeCamera(0.0, 0.0, 2.0)
    repeat(4) { zf.zoomAt(1.1, 0.0, 0.0, 150.0, 0.016) }
    val zEnd = zf.zoom; zf.endDrag(0.0); repeat(200) { zf.tick(0.016, false) }
    T.check("iki parmak hızlı bırakılınca yakınlaşma süzülür; durup bırakınca süzülmez", zf.zoom > zEnd * 1.05 &&
        GlobeCamera(0.0, 0.0, 2.0).let { c2 -> repeat(4) { c2.zoomAt(1.1, 0.0, 0.0, 150.0, 0.016) }; val e = c2.zoom; c2.endDrag(0.5); repeat(100) { c2.tick(0.016, false) }; abs(c2.zoom - e) < 1e-6 })
    val sm = GlobeCamera(0.0, 0.0); sm.flyTo(0.0, 1.0); sm.tick(0.016, false); val first = abs(sm.lon0)
    var peak = 0.0; var prev = sm.lon0; repeat(150) { sm.tick(0.016, false); peak = maxOf(peak, sm.lon0); }
    T.check("uçuş yumuşak kalkar (ilk karede sıçrama yok) ve hedefi aşmaz", first < 0.01 && peak <= 1.0 + 1e-6, "$first $peak")
    val hand = GlobeCamera(0.0, 0.0); hand.beginDrag(); repeat(5) { hand.dragBy(-30.0, 0.0, 100.0, 0.016) }; hand.endDrag(); val h0 = hand.lon0
    hand.flyTo(0.0, -1.0); hand.tick(0.016, false)
    T.check("savrulurken uçuş başlarsa hız devredilir (ani duruş yok)", hand.lon0 > h0)
    val dr = GlobeCamera(0.0, 0.0); dr.flyTo(1.0, 1.0); dr.beginDrag()
    T.check("sürükleme uçuşu iptal eder", !dr.flying)
}

private fun lookTests() {
    T.group("sizma51: küre şekli (perspektif) ve serbest dönme")
    run {
        val pc = GlobeCamera(0.0, 0.0, 1.0); val q = GlobeCamera.P()
        T.check("zoom 1: dik izdüşüm (perspektif yok)", pc.persp == 0.0)
        val zs = listOf(1.0, 2.0, 4.0, 8.0, 12.0)
        val ok = zs.all { zz ->
            val c = GlobeCamera(0.0, 0.0, zz)
            c.project(0.0, 1e-4, q); val center = q.x / 1e-4
            val horizon = kotlin.math.acos(c.persp)
            c.project(0.0, horizon - 1e-7, q); val edge = q.x
            kotlin.math.abs(center - zz) < 1e-3 && kotlin.math.abs(edge - 1.0) < 1e-3 && q.z < 0.01
        }
        T.check("yakınlaştırınca merkez zoom kat büyür, ufuk hep aynı dairede: küre şekli korunur, düz haritaya dönmez", ok)
        val c12 = GlobeCamera(0.0, 0.0, 12.0)
        T.check("en yakında bile ufuk görünür (görünen bölge ~9,5° yarıçaplı küre kapağı)", Math.toDegrees(kotlin.math.acos(c12.persp)) in 9.0..10.0)
        val ll = DoubleArray(2)
        val uOk = zs.all { zz -> val c = GlobeCamera(Math.toRadians(20.0), Math.toRadians(40.0), zz); c.project(Math.toRadians(41.0), Math.toRadians(29.0), q)
            q.z <= 0 || (c.unproject(q.x, q.y, ll) && kotlin.math.abs(Math.toDegrees(ll[0]) - 41.0) < 1e-6 && kotlin.math.abs(Math.toDegrees(ll[1]) - 29.0) < 1e-6) }
        T.check("perspektifte ters izdüşüm doğru (dokunma ve iki parmak)", uOk && !c12.unproject(1.01, 0.0, ll))
        val fr = GlobeCamera(0.0, 0.0); fr.beginDrag(); repeat(40) { fr.dragBy(13.0, -27.0, 100.0, 0.016) }; fr.endDrag(1.0)
        val mm = FloatArray(9); fr.matrix(mm)
        fun dot(i: Int, j: Int) = (0 until 3).sumOf { (mm[3 * i + it] * mm[3 * j + it]).toDouble() }
        T.check("her yöne döndürme sonrası yönelim geçerli dönme (dik birim eksenler)", (0 until 3).all { i -> (0 until 3).all { j -> kotlin.math.abs(dot(i, j) - (if (i == j) 1.0 else 0.0)) < 1e-6 } })
        val back = GlobeCamera(0.0, 0.0); back.beginDrag(); back.dragBy(0.0, -100.0 * Math.PI, 100.0, 0.016); back.endDrag(1.0)
        T.check("dikey sürüklemeyle küre ters yüz çevrilebilir (kutbun üstünden)", kotlin.math.abs(GlobeCamera.wrap(back.lon0 - Math.PI)) < 1e-6 && kotlin.math.abs(back.lat0) < 1e-6)
        val fl = GlobeCamera(0.0, 0.0); fl.beginDrag(); fl.dragBy(40.0, 70.0, 100.0, 0.016); fl.endDrag(1.0)
        fl.flyTo(Math.toRadians(41.0), Math.toRadians(29.0)); repeat(300) { fl.tick(0.016, false) }
        fl.project(Math.toRadians(41.0), Math.toRadians(29.0), q); val n = GlobeCamera.P(); fl.project(Math.toRadians(42.0), Math.toRadians(29.0), n)
        T.check("seçime uçuş yuvarlanmayı da düzeltir: hedef merkezde, kuzey yukarıda", kotlin.math.abs(q.x) < 1e-6 && kotlin.math.abs(q.y) < 1e-6 && kotlin.math.abs(n.x) < 1e-6 && n.y > 0 && !fl.flying)
    }

    T.group("sizma51: temaya ve stile uyan görünüm")
    var worst = 99.0; var worstAt = ""
    var groupsOk = true; var bad = ""
    for (t in Themes.all) for (st in UiStyle.values()) {
        val l = GlobeLook.of(t, st)
        for (c in l.land + l.coast) { val k = Rgb.contrast(c, l.oceanLit); if (k < worst) { worst = k; worstAt = "${t.id}/${st.id}" } }
        for (i in 0 until 4) for (j in i + 1 until 4) {
            val a = l.land[i]; val b = l.land[j]
            if (abs(Rgb.r(a) - Rgb.r(b)) + abs(Rgb.g(a) - Rgb.g(b)) + abs(Rgb.b(a) - Rgb.b(b)) < 24) { groupsOk = false; bad = "${t.id}/${st.id} $i-$j" }
        }
    }
    T.check("her tema × stilde kara/kıyı noktaları aydınlık okyanusa karşı ≥ 3:1", worst >= 3.0, "%.2f %s".format(worst, worstAt))
    T.check("her bileşimde 4 ülke tonu birbirinden ayırt edilir", groupsOk, bad)
    val aqua = GlobeLook.of(Themes.aqua, UiStyle.AQUA)
    val sunset = GlobeLook.of(Themes.sunset, UiStyle.AQUA)
    T.check("tema değişince renkler uyar (okyanus ve kara farklı)", aqua.oceanDeep != sunset.oceanDeep && aqua.land[0] != sunset.land[0])
    val night = GlobeLook.of(Themes.night, UiStyle.AQUA)
    T.check("koyu temada okyanus daha koyu", Rgb.luminance(night.oceanDeep) < Rgb.luminance(aqua.oceanDeep))
    val metro = GlobeLook.of(Themes.aqua, UiStyle.METRO)
    T.check("Metro düz: gradyan, parlama, hale yok; kare nokta", metro.flat && metro.specular == 0f && metro.shade == 0f && Rgb.a(metro.atmosphere) == 0 && metro.square)
    val y2k = GlobeLook.of(Themes.aqua, UiStyle.Y2K)
    T.check("Y2K: kare piksel, ızgara, krom parlama", y2k.square && Rgb.a(y2k.grid) > 0 && y2k.specular > 0.8f)
    val liquid = GlobeLook.of(Themes.aqua, UiStyle.LIQUID)
    val duru = GlobeLook.of(Themes.aqua, UiStyle.DURU)
    T.check("Liquid cam parlaması güçlü, Duru sade", liquid.specular > aqua.specular && liquid.rim > aqua.rim && duru.specular < aqua.specular && Rgb.a(duru.grid) == 0)
    val aurora = GlobeLook.of(Themes.aqua, UiStyle.AURORA)
    T.check("Aurora: güçlü, iki renkli hale", Rgb.a(aurora.atmosphere) > Rgb.a(aqua.atmosphere) && aurora.atmosphereInner != aurora.atmosphere)
    val eco = GlobeLook.of(Themes.aqua, UiStyle.ECO)
    T.check("Eco: kara yeşile kayar", Rgb.toHsl(eco.land[0])[0] in 70f..160f)
    T.check("her tema × stilde okyanus mavi/turkuaz aralığında (turuncu temada mora kaymaz)", Themes.all.all { t -> UiStyle.values().all { st -> Rgb.toHsl(GlobeLook.of(t, st).oceanDeep)[0] in 165f..240f } })
    T.check("gri tema (gri vurgu) çökmez, okyanus yine mavimsi", Themes.all.filter { Rgb.toHsl(it.accentDeep)[1] < 0.12f }.all { Rgb.toHsl(GlobeLook.of(it, UiStyle.AQUA).oceanDeep)[0] in 190f..240f })
    T.check("alacakaranlık şeridi ve zincir saydamlığı stile göre (Metro yok, Aurora güçlü)", metro.dusk == 0f && aurora.dusk > aqua.dusk && metro.chainAlpha == 1f && duru.chainAlpha < aqua.chainAlpha)
    T.check("aynı tema × stil önbellekten gelir", GlobeLook.of(Themes.aqua, UiStyle.AQUA) === aqua)
}

private fun findGlobe(n: app.dnshizli.ui.Node): GlobeNode? = (n as? GlobeNode) ?: n.children.firstNotNullOfOrNull { findGlobe(it) }

private fun drawTests() {
    T.group("sizma51: çizim")
    GlobeLand.map
    GlobeNode.syncShading = true; GlobeNode.syncBuild = true
    val rig = Rig(Rig.base())
    rig.tapText(Strings.GLOBE, settleMs = 900)
    val g = findGlobe(rig.scene.currentPage!!)!!
    class Rec : CountingGfx() { var dotN = 0; var lineN = 0; var paths = 0; var pics = 0
        override fun dots(xy: FloatArray, n: Int, r: Float, square: Boolean) { dotN += n; for (k in 0 until 2 * n) if (!xy[k].isFinite()) bad++ }
        override fun lines(xy: FloatArray, n: Int) { lineN += n; for (k in 0 until 4 * n) if (!xy[k].isFinite()) bad++ }
        override fun path(p: GPath) { paths++ }
        override fun makePic(argb: IntArray, w: Int, h: Int): Pic? { pics++; return Pic(w, h, Any(), 0f, 1f) } }
    for (st in UiStyle.values()) {
        rig.model.update { it.copy(style = st) }; rig.settle(50)
        val d = Rec(); g.draw(d, rig.scene.env)
        val ok = d.dotN > 2000 && d.lineN > 300 && d.paths in 1..4 && d.bad == 0 && d.depth == 0 && !d.underflow && (st == UiStyle.METRO) == (d.pics == 0)
        if (!ok) { T.check("çizim ${st.id}", false, "${d.dotN} ${d.lineN} ${d.paths} ${d.pics} ${d.bad}"); return }
    }
    T.check("her stilde: ülke dolguları (≤ 4 yol), yarım ton, kıyı ve sınır çizgileri, ışık katmanları (Metro düz), NaN yok", true)
    rig.model.update { it.copy(style = UiStyle.AQUA) }; rig.settle(50)
    val d1 = Rec(); g.draw(d1, rig.scene.env); val v1 = g.lastVertices
    g.camera.focus(Math.toRadians(41.0), Math.toRadians(28.0)); g.camera.zoomBy(GlobeCamera.MAX_ZOOM); rig.settle(16)
    val d2 = Rec(); g.draw(d2, rig.scene.env)
    T.check("yakın planda ayrıntı artar, yarım ton yine ekran başına sınırlı", g.lastBorderSegs > 0 && d2.dotN in 1000..160000 && v1 > 0, "${d2.dotN} ${g.lastBorderSegs}")
    T.group("sizma51: başarım (kalite düşürmeden)")
    run {
        val map = GlobeLand.map
        T.check("düzey dizinleri: L düzeyi tam olarak önemi ≥ L köşeler, uçlar her düzeyde", (0..7).all { L ->
            val st = map.lvStart[L]; val vs = map.lvVerts[L]
            vs.size == (0 until map.vertexCount).count { map.level[it] >= L } && (0 until map.arcCount).all { a -> vs[st[a]] == map.arcStart[a] && vs[st[a + 1] - 1] == map.arcStart[a + 1] - 1 } })
        val r2 = Rig(Rig.base()); r2.tapText(Strings.GLOBE, settleMs = 900)
        val gg = findGlobe(r2.scene.currentPage!!)!!
        gg.camera.focus(Math.toRadians(39.0), Math.toRadians(35.0)); r2.settle(16)
        class Clip : CountingGfx() { var clips = 0; override fun clipPath(p: GPath) { clips++ } }
        val c1 = Clip(); gg.draw(c1, r2.scene.env); val pFar = gg.lastProjected
        val reused0 = gg.framesReused; gg.draw(Clip(), r2.scene.env)
        T.check("kamera değişmeyen karede geometri yeniden kurulmaz", gg.framesReused == reused0 + 1)
        T.check("uzak görünümde kırpma yok (kaba maske yeter), izdüşürülen köşe sınırlı", c1.clips == 0 && pFar in 1000..60000, "$pFar")
        gg.camera.zoomBy(GlobeCamera.MAX_ZOOM); r2.settle(16)
        val c2 = Clip(); gg.draw(c2, r2.scene.env)
        T.check("yakın planda kesin kırpma; görünmeyen halkalar izdüşürülmez (köşe sayısı sınırlı)", c2.clips == 1 && gg.lastProjected in 100..80000, "${gg.lastProjected}")
        val bld = GlobeFrame.Builder(map); val fr = GlobeFrame(); val mm = FloatArray(9)
        fun key(c: GlobeCamera, r: Float) = GlobeFrame.Key(c.lon0, c.lat0, c.zoom, 360f, 440f, 170f, GlobeLand.minLevel(r), c.zoom >= GlobeNode.CLIP_ZOOM, GlobeHalftone.levelFor(r).first, -1, persp = c.persp.toFloat(), scale = r)
        repeat(30) { val c = GlobeCamera(Math.toRadians(30.0 + it), Math.toRadians(35.0)); c.matrix(mm); bld.build(fr, key(c, 170f), mm, 180f, 220f) }
        val t0 = System.nanoTime()
        repeat(20) { val c = GlobeCamera(Math.toRadians(39.0), Math.toRadians(35.0 + it)); c.matrix(mm); bld.build(fr, key(c, 170f), mm, 180f, 220f) }
        repeat(20) { val c = GlobeCamera(Math.toRadians(41.0 + it * 0.01), Math.toRadians(28.0), 12.0); c.matrix(mm); bld.build(fr, key(c, 170f * 12), mm, 180f, 220f) }
        val ms = (System.nanoTime() - t0) / 1e6 / 40
        T.check("kare kurulumu ortalama < 8 ms (JVM; yakın ve uzak, döndürürken, perspektif)", ms < 8.0, "%.1f ms".format(ms))
    }

    T.group("sizma51: arka plan kurulumu")
    run {
        val map = GlobeLand.map
        val mm = FloatArray(9); val cam = GlobeCamera(Math.toRadians(45.0), Math.toRadians(20.0), 3.0); cam.matrix(mm)
        val r = 170f * 3
        val k = GlobeFrame.Key(cam.lon0, cam.lat0, cam.zoom, 360f, 440f, 170f, GlobeLand.minLevel(r), true, GlobeHalftone.levelFor(r).first, -1, persp = cam.persp.toFloat(), scale = r)
        val ref = GlobeFrame(); GlobeFrame.Builder(map).build(ref, k, mm, 180f, 220f)
        val wk = GlobeFrame.worker(map); val owner = Any(); val other = Any()
        val fr = GlobeFrame()
        val sub = wk.submit(owner, fr, k, mm, 180f, 220f)
        var got: GlobeFrame? = null; var stolen = false; val until = System.currentTimeMillis() + 5000
        while (got == null && System.currentTimeMillis() < until) { if (wk.take(other) != null) stolen = true; got = wk.take(owner); if (got == null) Thread.sleep(2) }
        T.check("arka plan kurucu aynı kareyi kurar (eşzamanlı ile birebir), başka sahip alamaz",
            sub && !stolen && got === fr && fr.key == k && fr.dots.n == ref.dots.n && fr.vertices == ref.vertices && fr.borderN == ref.borderN && fr.coastN == ref.coastN &&
                (0 until 2 * fr.dots.n).all { fr.dots.a[it] == ref.dots.a[it] })
        GlobeNode.syncBuild = false
        val rr = Rig(Rig.base()); rr.tapText(Strings.GLOBE, settleMs = 900)
        val gn = findGlobe(rr.scene.currentPage!!)!!
        gn.draw(CountingGfx(), rr.scene.env)
        val firstOk = gn.lastProjected > 0
        val oldBuild = gn.lastBuildNs
        gn.camera.focus(Math.toRadians(10.0), Math.toRadians(100.0))
        gn.draw(CountingGfx(), rr.scene.env)
        val stale = gn.lastBuildNs == oldBuild
        val wantsFrames = gn.tick(0.016f, rr.scene.env)
        var fresh = false; val until2 = System.currentTimeMillis() + 5000
        while (!fresh && System.currentTimeMillis() < until2) { Thread.sleep(3); gn.draw(CountingGfx(), rr.scene.env); fresh = gn.lastBuildNs != oldBuild }
        T.check("arayüz bekletilmez: ilk kare hemen, sonrakinde önceki kare çizilir, yenisi hazır olunca gelir; bu sürede kare istenir", firstOk && stale && wantsFrames && fresh, "$firstOk $stale $wantsFrames $fresh")
        val gp = File("app/src/main/java/app/dnshizli/ui/GlobePage.kt").readText()
        T.check("sunucu noktaları ve ışık çizilen karenin kamerasıyla (harita ile kayma yok)", gp.contains("drawMarkers(g, env, r, mm, pp)") && gp.contains("val r = f?.r ?: radius"))
        T.check("ışık katmanları normalde arka planda hesaplanır (ana iş parçacığı beklemez)", gp.contains("\"kure-isik\"") && !gp.contains("model.host.requestFrame()"))
        GlobeNode.syncBuild = true
        val sh = GlobeShading(64, GlobeLook.of(Themes.aqua, UiStyle.AQUA))
        T.check("gölge + atmosfer tek görüntüde birleşik (bir çizim eksik), saydamlık doğru", (0 until sh.top.size step 7).all { i ->
            val a1 = ((sh.shade[i] ushr 24) and 0xFF) / 255f; val a2 = ((sh.atmo[i] ushr 24) and 0xFF) / 255f; val a = ((sh.top[i] ushr 24) and 0xFF) / 255f
            kotlin.math.abs(a - (a2 + a1 * (1 - a2))) < 0.01f })
    }
    T.check("ışık katmanları stil değişmedikçe yeniden hesaplanmaz", run { val d3 = Rec(); g.draw(d3, rig.scene.env); d3.pics == 0 })
    val src = File("app/src/main/java/app/dnshizli/platform/AndroidGfx.kt").readText()
    T.check("Android: noktalar drawPoints, çizgiler drawLines; görüntü Bitmap.createBitmap ile", src.contains("c.drawPoints(xy, 0, 2 * n, dotPaint)") && src.contains("c.drawLines(xy, 0, 4 * n, strokePaint)") && src.contains("Bitmap.createBitmap(argb, w, h, Bitmap.Config.ARGB_8888)"))
    val cg = CountingGfx(); cg.dots(floatArrayOf(1f, 2f, 3f, 4f), 2, 1f); cg.lines(floatArrayOf(0f, 0f, 1f, 1f), 1)
    T.check("Gfx.dots/lines varsayılanı tek tek çizer; makePic varsayılanı yok", cg.shapes == 3 && cg.makePic(IntArray(4), 2, 2) == null)
    val gp = File("app/src/main/java/app/dnshizli/ui/GlobePage.kt").readText()
    T.check("sayfa: seçilen noktaya uçar; çift dokunma noktaya; iki parmak odaklı; bırakma süresi fiziğe gider; etiket çakışmaz",
        gp.contains("globe.camera.flyTo(") && gp.contains("camera.zoomStepAt(ll[0], ll[1])") && gp.contains("camera.zoomAt(f.toDouble()") && gp.contains("camera.endDrag((clock - lastT).toDouble())") && gp.contains("if (placed.any {") && gp.contains("GlobeLand.warm()"))
}

private fun previews() {
    T.group("sizma51: ön izleme görselleri")
    GlobeLand.map
    GlobeNode.syncShading = true; GlobeNode.syncBuild = true
    val awt = AwtGfx(BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB).createGraphics())
    val combos = listOf(
        Triple("aqua", UiStyle.AQUA, "kure2-aqua"), Triple("night", UiStyle.AERO, "kure2-gece-aero"),
        Triple("aqua", UiStyle.METRO, "kure2-metro"), Triple("sakura", UiStyle.Y2K, "kure2-y2k"),
        Triple("northern", UiStyle.AURORA, "kure2-aurora"), Triple("meadow", UiStyle.ECO, "kure2-eco"),
        Triple("ivory", UiStyle.DURU, "kure2-duru"), Triple("ocean", UiStyle.LIQUID, "kure2-liquid"),
        Triple("sunset", UiStyle.AQUA, "kure2-sunset"),
    )
    for ((theme, st, name) in combos) {
        val r = Rig(Rig.base(theme).copy(style = st), 360, 780, metrics = awt)
        r.tapText(Strings.GLOBE, settleMs = 900)
        val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/$name.png"); cv.dispose()
    }
    // yakın plan: Avrupa, yakınlaştırma 3.5
    run {
        val r = Rig(Rig.base("night"), 360, 780, metrics = awt); r.tapText(Strings.GLOBE, settleMs = 900)
        val g = findGlobe(r.scene.currentPage!!)!!
        g.camera.focus(Math.toRadians(46.0), Math.toRadians(12.0)); g.camera.zoomBy(3.5); r.settle(50)
        val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/kure2-yakin-avrupa.png"); cv.dispose()
    }
    run {
        val r = Rig(Rig.base("aqua"), 360, 780, metrics = awt); r.tapText(Strings.GLOBE, settleMs = 900)
        val g = findGlobe(r.scene.currentPage!!)!!
        g.camera.focus(Math.toRadians(39.0), Math.toRadians(35.0)); g.camera.zoomBy(5.5); r.settle(50)
        val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/kure2-yakin-turkiye.png"); cv.dispose()
    }
    run {
        val r = Rig(Rig.base("sapphire"), 360, 780, metrics = awt); r.tapText(Strings.GLOBE, settleMs = 900)
        val g = findGlobe(r.scene.currentPage!!)!!
        g.camera.focus(Math.toRadians(40.6), Math.toRadians(27.5)); g.camera.zoomBy(GlobeCamera.MAX_ZOOM); r.settle(50)
        val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/kure2-yakin-marmara.png"); cv.dispose()
    }
    run {
        // yakın planda etiketler çakışmaz
        val r = Rig(Rig.base("night"), 360, 780, metrics = awt); r.tapText(Strings.GLOBE, settleMs = 900)
        val g = findGlobe(r.scene.currentPage!!)!!
        g.camera.focus(Math.toRadians(48.0), Math.toRadians(10.0)); g.camera.zoomBy(3.5); r.settle(50)
        class Boxes : CountingGfx() { val rects = ArrayList<FloatArray>()
            override fun roundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) { rects.add(floatArrayOf(l, t, r, b)) } }
        val bx = Boxes(); g.draw(bx, r.scene.env)
        val ov = bx.rects.indices.any { i -> (i + 1 until bx.rects.size).any { j -> val a = bx.rects[i]; val b = bx.rects[j]; a[0] < b[2] && b[0] < a[2] && a[1] < b[3] && b[1] < a[3] } }
        T.check("yakın planda birden çok ad etiketi, hiçbiri çakışmaz", bx.rects.size >= 2 && !ov, "${bx.rects.size}")
    }
    T.check("ön izlemeler üretildi", (combos.map { it.third } + "kure2-yakin-avrupa" + "kure2-yakin-turkiye" + "kure2-yakin-marmara").all { File("build/onizleme/$it.png").isFile })
}
