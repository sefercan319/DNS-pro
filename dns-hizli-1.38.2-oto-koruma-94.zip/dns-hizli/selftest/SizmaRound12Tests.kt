package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File

/** sizma36: alternatif yönlendirme aynaları ve bize özel (saf Kotlin) WireGuard çekirdeği — bağımsız Python referansıyla bayt bayt. */
internal fun runRound12Tests() {
    runMirrorTests()
    runWgPrimitiveTests()
    runWgHandshakeTests()
    runWgSessionTests()
    runWgConfigTests()
}

private fun runWgConfigTests() {
    T.group("sizma36: WireGuard yapılandırma dosyası (.conf / QR metni)")
    val priv = java.util.Base64.getEncoder().encodeToString(Wg.generatePrivate())
    val pub = java.util.Base64.getEncoder().encodeToString(Wg.publicKey(Wg.generatePrivate()))
    val psk = java.util.Base64.getEncoder().encodeToString(ByteArray(32) { 9 })
    val good = """
        # yorum
        [Interface]
        PrivateKey = $priv
        Address = 10.66.0.2/32, fd00:66::2/128
        DNS = 1.1.1.1, 2606:4700:4700::1111, ornek.lan
        MTU = 1380
        PostUp = rm -rf /

        [Peer]
        PublicKey = $pub
        PresharedKey = $psk
        AllowedIPs = 0.0.0.0/0, ::/0
        Endpoint = vpn.ornek.com:51820
        PersistentKeepalive = 25
    """.trimIndent()
    val r = WgConfig.parse(good)
    val c = (r as? WgConfig.Companion.Result.Ok)?.cfg
    T.check("tam yapılandırma okunur (adres, DNS, MTU, psk, uç nokta, canlı tutma)", c != null && c.addresses.size == 2 && c.dns.size == 2 && c.mtu == 1380 &&
        c.peer.endpointHost == "vpn.ornek.com" && c.peer.endpointPort == 51820 && c.peer.keepaliveSec == 25 && c.peer.presharedKey.all { it.toInt() == 9 } && c.fullTunnel,
        (r as? WgConfig.Companion.Result.Err)?.why ?: "")
    T.check("PostUp gibi komut alanları ÇALIŞTIRILMAZ, uyarı olarak kaydedilir; DNS arama alanı uyarı", c != null && c.warnings.any { it.contains("PostUp") } && c.warnings.any { it.contains("ornek.lan") })
    T.check("v6 uç nokta [adres]:port", WgConfig.endpoint("[2001:db8::1]:443") == ("2001:db8::1" to 443) && WgConfig.endpoint("1.2.3.4:51820") == ("1.2.3.4" to 51820))
    T.check("geçersiz uç noktalar reddedilir", listOf("ornek.com", "ornek.com:0", "ornek.com:70000", "2001:db8::1:51820", "[1.2.3.4]:5", "a b:1", ":51820").all { WgConfig.endpoint(it) == null })
    T.check("AllowedIPs ağ adresine indirgenir, Address olduğu gibi", WgConfig.cidr("192.168.1.77/24", false)?.toString() == "192.168.1.0/24" && WgConfig.cidr("10.0.0.2/32", true)?.toString() == "10.0.0.2/32" &&
        WgConfig.cidr("10.0.0.0/33", false) == null && WgConfig.cidr("::/0", false)?.prefix == 0)
    T.check("CIDR içerme", WgConfig.cidr("10.8.0.0/14", false)!!.contains(byteArrayOf(10, 11, 255.toByte(), 1)) && !WgConfig.cidr("10.8.0.0/14", false)!!.contains(byteArrayOf(10, 12, 0, 1)))
    fun err(t: String) = (WgConfig.parse(t) as? WgConfig.Companion.Result.Err)?.why
    val noKey = good.replace("PrivateKey = $priv", "PrivateKey = kisa")
    T.check("geçersiz anahtar, eksik uç nokta, ikinci eş, bölüm dışı alan, büyük dosya reddedilir",
        err(noKey) != null && err(good.replace("Endpoint = vpn.ornek.com:51820", "")) != null && err(good + "\n[Peer]\nPublicKey = $pub") != null &&
            err("PrivateKey = $priv\n" + good) != null && err("x".repeat(20_000)) != null && err(good.replace("MTU = 1380", "MTU = 9000")) != null)
    val zeroPub = good.replace("PublicKey = $pub", "PublicKey = " + java.util.Base64.getEncoder().encodeToString(ByteArray(32)))
    T.check("küçük alt grup (sıfır) ortak anahtar reddedilir", err(zeroPub)?.contains("uyumsuz") == true)
}

// ---- küçük JSON okuyucu (bağımlılıksız; yalnız test verisi için)
private class Js(private val s: String) {
    var i = 0
    fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
    fun value(): Any? {
        ws()
        return when (s[i]) {
            '{' -> { i++; val m = LinkedHashMap<String, Any?>(); ws(); if (s[i] == '}') { i++; return m }
                while (true) { ws(); val k = str(); ws(); i++; m[k] = value(); ws(); if (s[i++] == '}') return m } ; @Suppress("UNREACHABLE_CODE") m }
            '[' -> { i++; val l = ArrayList<Any?>(); ws(); if (s[i] == ']') { i++; return l }
                while (true) { l.add(value()); ws(); if (s[i++] == ']') return l } ; @Suppress("UNREACHABLE_CODE") l }
            '"' -> str()
            else -> { val st = i; while (i < s.length && (s[i].isDigit() || s[i] == '-' || s[i] == '.')) i++; s.substring(st, i).toLong() }
        }
    }
    fun str(): String { i++; val st = i; while (s[i] != '"') i++; return s.substring(st, i++) }
}
@Suppress("UNCHECKED_CAST") private fun Any?.obj() = this as Map<String, Any?>
@Suppress("UNCHECKED_CAST") private fun Any?.arr() = this as List<Any?>
private fun hx(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
private fun ByteArray.h() = joinToString("") { "%02x".format(it) }
private val V by lazy { Js(File("selftest/data/wg_vectors.json").readText()).value().obj() }

private fun runMirrorTests() {
    T.group("sizma36: alternatif yönlendirme — liste aynaları")
    val base = "https://github.com/ali/dns-hizli/releases/download/listeler/"
    val u = ListMirrors.urls(base)
    T.check("asıl adres önce, sonra 4 ayna (raw.githubusercontent + jsDelivr cdn/fastly/gcore)", u.size == 5 && u[0] == base &&
        u[1] == "https://raw.githubusercontent.com/ali/dns-hizli/listeler-dagitim/" && u[2] == "https://cdn.jsdelivr.net/gh/ali/dns-hizli@listeler-dagitim/" &&
        u.drop(3).all { it.contains("jsdelivr.net/gh/ali/dns-hizli@listeler-dagitim/") }, u.toString())
    T.check("son başarılı ayna önce denenir", ListMirrors.urls(base, u[2]).first() == u[2] && ListMirrors.urls(base, u[2]).toSet() == u.toSet())
    T.check("tanınmayan son başarılı adres yok sayılır", ListMirrors.urls(base, "https://kotu.example/").first() == base)
    T.check("GitHub biçiminde olmayan adres: yalnız kendisi; https değilse hiç", ListMirrors.urls("https://ornek.com/listeler/") == listOf("https://ornek.com/listeler/") && ListMirrors.urls("http://x/").isEmpty())
    T.check("kötü sahip/depo adı (yol kaçışı) ayna üretmez", ListMirrors.urls("https://github.com/a/../releases/download/x/").size == 1)
    T.check("yönlendirme yalnız aynalara ve GitHub dağıtım adlarına", ListMirrors.redirectAllowed("objects.githubusercontent.com", base) && ListMirrors.redirectAllowed("fastly.jsdelivr.net", base) &&
        !ListMirrors.redirectAllowed("kotu.example", base) && !ListMirrors.redirectAllowed("jsdelivr.net.kotu.example", base))
    val w1 = File(".github/workflows/listeleri-yayinla.yml").readText(); val w2 = File(".github/workflows/engelli-liste.yml").readText()
    T.check("iki yayın iş akışı da dosyaları dağıtım dalına koyar (yayından SONRA, aynı eşzamanlılık grubu)",
        w1.indexOf("tools/yayin/ayna.sh") > w1.indexOf("gh release upload") && w2.indexOf("tools/yayin/ayna.sh") > w2.indexOf("gh release upload") &&
            w1.contains("group: listeler-yayin") && w2.contains("group: listeler-yayin"))
    val ok = try { ProcessBuilder("bash", "-n", "tools/yayin/ayna.sh").start().waitFor() == 0 } catch (_: Exception) { true }
    T.check("ayna.sh sözdizimi geçerli", ok)
    val up = File("app/src/main/java/app/dnshizli/platform/ListUpdater.kt").readText()
    T.check("istemci aynaları sırayla dener ve bütün dosyaları aynı aynadan alır", up.contains("ListMirrors.urls(BASE_URL") && up.contains("updateFrom(") && up.contains("ListMirrors.redirectAllowed"))
}

private fun runWgPrimitiveTests() {
    T.group("sizma36: WireGuard yapı taşları — BLAKE2s, HMAC/KDF, ChaCha20-Poly1305, XChaCha20")
    val p = V.getValue("primitives").obj()
    T.check("BLAKE2s(\"abc\") RFC 7693 vektörü", Blake2s.hash("abc".toByteArray()).h() == p["blake2s_abc"] && p["blake2s_abc"] == "508c5e8c327c14e2e1a72ba34eeb452f37458b209ed63a294d999b4c86675982")
    T.check("BLAKE2s boş ileti", Blake2s.hash(ByteArray(0)).h() == p["blake2s_empty"])
    T.check("anahtarlı BLAKE2s-128 (MAC) Python ile aynı", Blake2s.mac(ByteArray(32) { it.toByte() }, ByteArray(64) { it.toByte() }).h() == p["blake2s_keyed"])
    T.check("anahtarlı BLAKE2s-256, çok bloklu girdi", Blake2s.State(32, ByteArray(32) { it.toByte() }).update(ByteArray(200) { it.toByte() }).digest().h() == p["blake2s_keyed32"])
    val parts = Blake2s.State(32).update(ByteArray(70) { it.toByte() }, 0, 33).update(ByteArray(70) { it.toByte() }, 33, 37).digest()
    T.check("parça parça besleme tek seferle aynı", parts.contentEquals(Blake2s.hash(ByteArray(70) { it.toByte() })))
    T.check("HMAC-BLAKE2s", Blake2s.hmac("anahtar".toByteArray(), "veri".toByteArray()).h() == p["hmac"])
    T.check("WireGuard KDF3", Blake2s.kdf(ByteArray(32), "girdi".toByteArray(), 3).map { it.h() } == p["kdf3"].arr())
    val k = ByteArray(32) { it.toByte() }; val n = ByteArray(12) { it.toByte() }; val aad = "wg-aad".toByteArray()
    var allCc = true
    for (c in p["chacha"].arr()) { val o = c.obj(); val pt = hx(o["pt"] as String); val ct = ChaChaPoly.seal(k, n, aad, pt)
        if (ct.h() != o["ct"] || ChaChaPoly.open(k, n, aad, ct)?.contentEquals(pt) != true) allCc = false }
    T.check("ChaCha20-Poly1305: 0/1/16/17/765 bayt, Python (OpenSSL) ile aynı ve geri açılır", allCc)
    // RFC 8439 §2.8.2
    val rk = hx("808182838485868788898a8b8c8d8e8f909192939495969798999a9b9c9d9e9f"); val rn = hx("070000004041424344454647")
    val ra = hx("50515253c0c1c2c3c4c5c6c7")
    val rp = "Ladies and Gentlemen of the class of '99: If I could offer you only one tip for the future, sunscreen would be it.".toByteArray()
    val rc = ChaChaPoly.seal(rk, rn, ra, rp)
    T.check("RFC 8439 §2.8.2 AEAD vektörü (şifre metni başı ve etiket)", rc.copyOf(16).h() == "d31a8d34648e60db7b86afbc53ef7ec2" && rc.copyOfRange(rc.size - 16, rc.size).h() == "1ae10b594f09e26a7e902ecbd0600691")
    // draft-irtf-cfrg-xchacha A.3.1
    val xc = ChaChaPoly.xseal(rk, hx("404142434445464748494a4b4c4d4e4f5051525354555657"), ra, rp)
    T.check("XChaCha20-Poly1305 taslak vektörü", xc.copyOf(32).h() == "bd6d179d3e83d43b9576579493c0e939572a1700252bfaccbed2902c21396cbb" && xc.copyOfRange(xc.size - 16, xc.size).h() == "c0875924c1c7987947deafd8780acf49")
    val bad = rc.copyOf(); bad[5] = (bad[5].toInt() xor 1).toByte()
    T.check("bozulmuş şifre metni / etiket / aad reddedilir", ChaChaPoly.open(rk, rn, ra, bad) == null && ChaChaPoly.open(rk, rn, hx("00"), rc) == null && ChaChaPoly.open(rk, rn, ra, rc.copyOf(10)) == null)
    // JDK ile 300 rastgele çapraz sınama
    val rnd = java.util.Random(36); var jdkOk = true; var jdkRan = false
    try {
        repeat(300) {
            val key = ByteArray(32).also { rnd.nextBytes(it) }; val nn = ByteArray(12).also { rnd.nextBytes(it) }
            val ad = ByteArray(rnd.nextInt(40)).also { rnd.nextBytes(it) }; val pt = ByteArray(rnd.nextInt(2000)).also { rnd.nextBytes(it) }
            val c = javax.crypto.Cipher.getInstance("ChaCha20-Poly1305")
            c.init(javax.crypto.Cipher.ENCRYPT_MODE, javax.crypto.spec.SecretKeySpec(key, "ChaCha20"), javax.crypto.spec.IvParameterSpec(nn))
            c.updateAAD(ad)
            if (!c.doFinal(pt).contentEquals(ChaChaPoly.seal(key, nn, ad, pt))) jdkOk = false
            jdkRan = true
        }
    } catch (_: java.security.GeneralSecurityException) {}
    T.check("JDK ChaCha20-Poly1305 ile 300 rastgele girdide birebir (JDK destekliyorsa)", jdkOk, "çalıştı=$jdkRan")
}

private fun runWgHandshakeTests() {
    T.group("sizma36: WireGuard el sıkışması — bağımsız referansla bayt bayt (4 durum, psk'li/psk'siz)")
    for ((ci, c0) in V.getValue("cases").arr().withIndex()) {
        val c = c0.obj()
        val si = hx(c["si"] as String); val sr = hx(c["sr"] as String); val psk = hx(c["psk"] as String)
        val epoch = c["epoch"] as Long; val idxI = (c["idx_i"] as Long).toInt(); val idxR = (c["idx_r"] as Long).toInt()
        val init = WgInitiator(si, Wg.publicKey(sr), psk)
        val m = init.initiation(idxI, 0L, hx(c["ei"] as String), epoch)
        T.check("durum $ci: başlatma iletisi (148 bayt) referansla aynı", m?.h() == c["initiation"], m?.h()?.take(40) ?: "null")
        val resp = WgResponder(sr); resp.addPeer(WgResponder.Peer(Wg.publicKey(si), psk))
        val pyInit = hx(c["initiation"] as String)
        val got = resp.consumeInitiation(pyInit, 0, pyInit.size)
        T.check("durum $ci: yanıtlayıcı referansın başlatmasını doğrular, eşi tanır", got != null && got.senderIndex == idxI)
        val (r, rs) = resp.respond(got!!, idxR, 0L, hx(c["er"] as String))!!
        T.check("durum $ci: yanıt iletisi (92 bayt) referansla aynı", r.h() == c["response"])
        val pyResp = hx(c["response"] as String)
        val s = init.response(pyResp, 0, pyResp.size, 0L)
        T.check("durum $ci: başlatıcı referansın yanıtından oturum kurar", s != null && s.remoteIndex == idxR && s.localIndex == idxI)
        val pays = c["payloads"].arr().map { hx(it as String) }
        val di = c["data_i"].arr().map { it as String }; val dr = c["data_r"].arr().map { it as String }
        var encOk = true; var decOk = true; var respDec = true
        for ((k, p) in pays.withIndex()) {
            if (s!!.encrypt(p, 0, p.size, 0L)?.h() != di[k]) encOk = false
            val pr = hx(dr[k]); val back = s.decrypt(pr, 0, pr.size, 0L)
            if (back == null || !back.copyOf(p.size).contentEquals(p) || back.size != ((p.size + 15) and 15.inv())) decOk = false
            val pi = hx(di[k]); val rb = rs.decrypt(pi, 0, pi.size, 0L)
            if (rb == null || !rb.copyOf(p.size).contentEquals(p)) respDec = false
        }
        T.check("durum $ci: taşıma iletileri (canlı tutma, 20, 84, 1300 bayt; 16'ya dolgu) referansla aynı", encOk)
        T.check("durum $ci: referansın yanıtlayıcı iletileri açılır; yanıtlayıcı başlatıcının iletilerini açar", decOk && respDec)
    }
}

private fun runWgSessionTests() {
    T.group("sizma36: WireGuard — saldırı ve dayanıklılık")
    val si = Wg.generatePrivate(); val sr = Wg.generatePrivate()
    fun pair(nowMs: Long = 0L): Triple<WgInitiator, WgResponder, Pair<WgSession, WgSession>> {
        val ini = WgInitiator(si, Wg.publicKey(sr)); val res = WgResponder(sr); res.addPeer(WgResponder.Peer(Wg.publicKey(si)))
        val m = ini.initiation(7, nowMs)!!; val g = res.consumeInitiation(m, 0, m.size)!!
        val (r, rs) = res.respond(g, 9, nowMs)!!; val s = ini.response(r, 0, r.size, nowMs)!!
        return Triple(ini, res, s to rs)
    }
    run {
        val ini = WgInitiator(si, Wg.publicKey(sr)); val res = WgResponder(sr); res.addPeer(WgResponder.Peer(Wg.publicKey(si)))
        val m = ini.initiation(1, 0L)!!
        val bad = m.copyOf(); bad[120] = (bad[120].toInt() xor 1).toByte()
        T.check("mac1 bozuk başlatma reddedilir (DoS ön elemesi)", res.consumeInitiation(bad, 0, bad.size) == null)
        val bad2 = m.copyOf(); bad2[50] = (bad2[50].toInt() xor 1).toByte()
        T.check("şifreli statik anahtarı bozulmuş başlatma reddedilir", res.consumeInitiation(bad2, 0, bad2.size) == null)
        T.check("geçerli başlatma kabul", res.consumeInitiation(m, 0, m.size) != null)
        T.check("aynı başlatmanın tekrarı reddedilir (zaman damgası)", res.consumeInitiation(m, 0, m.size) == null)
        val stranger = WgInitiator(Wg.generatePrivate(), Wg.publicKey(sr)).initiation(2, 0L)!!
        T.check("tanınmayan eş reddedilir", res.consumeInitiation(stranger, 0, stranger.size) == null)
        val m2 = ini.initiation(3, 0L, epochMs = 0L)!!
        T.check("saat geri gitse de yeni başlatma damgası artar, kabul edilir", res.consumeInitiation(m2, 0, m2.size) != null)
    }
    run {
        val (_, _, ss) = pair(); val (s, rs) = ss
        val p = ByteArray(60) { it.toByte() }
        T.check("yanıtlayıcı ilk veri gelene dek gönderemez (anahtar onayı)", rs.encrypt(p, 0, p.size, 0L) == null)
        val m0 = s.encrypt(p, 0, p.size, 0L)!!
        T.check("başlatıcı gönderir, yanıtlayıcı açar ve onaylanır", rs.decrypt(m0, 0, m0.size, 0L)?.copyOf(60)?.contentEquals(p) == true && rs.encrypt(p, 0, p.size, 0L) != null)
        T.check("aynı paketin tekrarı reddedilir", rs.decrypt(m0, 0, m0.size, 0L) == null)
        val ms = (1..5).map { s.encrypt(p, 0, p.size, 0L)!! }
        T.check("sıra dışı (pencere içi) kabul, tekrarı ret", rs.decrypt(ms[3], 0, ms[3].size, 0L) != null && rs.decrypt(ms[1], 0, ms[1].size, 0L) != null &&
            rs.decrypt(ms[3], 0, ms[3].size, 0L) == null)
        val tam = ms[4].copyOf(); tam[30] = (tam[30].toInt() xor 1).toByte()
        T.check("bozulmuş paket reddedilir ve pencereyi kaydırmaz", rs.decrypt(tam, 0, tam.size, 0L) == null && rs.decrypt(ms[4], 0, ms[4].size, 0L) != null)
        val forged = ms[2].copyOf(); Wg.put64(forged, 8, 1_000_000L)
        rs.decrypt(forged, 0, forged.size, 0L)
        T.check("sahte yüksek sayaç (doğrulanmamış) pencereyi ileri itmez", rs.decrypt(ms[2], 0, ms[2].size, 0L) != null)
        T.check("180 sn sonra oturum reddeder, 120 sn'de yenileme ister", s.shouldRekey(120_000L) && !s.shouldRekey(119_000L) &&
            s.encrypt(p, 0, p.size, 180_000L) == null && rs.decrypt(ms[0], 0, ms[0].size, 180_000L) == null)
    }
    run {
        val r = WgReplay(); var ok = true
        for (c in 0L until 5000L step 3) ok = ok && r.accept(c)
        ok = ok && !r.accept(3) && !r.accept(4998 - 2100) && r.accept(4999) && !r.accept(4999) && r.accept(4998 - 10)
        ok = ok && r.accept(1_000_000L) && !r.accept(1_000_000L - 3000) && r.accept(1_000_000L - 100)
        T.check("tekrar penceresi: yinelenen, çok eski ret; pencere içi ve ileri sıçrama doğru", ok)
    }
    run {
        val ini = WgInitiator(si, Wg.publicKey(sr)); val res = WgResponder(sr); res.addPeer(WgResponder.Peer(Wg.publicKey(si)))
        val m = ini.initiation(5, 0L)!!
        val cookie = ByteArray(16) { (it * 7).toByte() }
        val cr = res.cookieReply(m, 0, cookie, ByteArray(24) { it.toByte() })
        T.check("çerez cevabı açılır (XChaCha20, aad = mac1)", ini.cookieReply(cr, 0, cr.size, 0L))
        val m2 = ini.initiation(5, 1000L)!!
        T.check("sonraki başlatma mac2 = MAC(çerez, ileti[0:132]) taşır", Blake2s.mac(cookie, m2.copyOf(132)).contentEquals(m2.copyOfRange(132, 148)))
        val m3 = ini.initiation(5, 1000L + Wg.COOKIE_LIFETIME_MS)!!
        T.check("çerez 120 sn sonra kullanılmaz (mac2 sıfır)", m3.copyOfRange(132, 148).all { it.toInt() == 0 })
        val fake = cr.copyOf(); fake[40] = (fake[40].toInt() xor 1).toByte()
        T.check("bozuk çerez cevabı reddedilir", !WgInitiator(si, Wg.publicKey(sr)).also { it.initiation(5, 0L) }.cookieReply(fake, 0, fake.size, 0L))
    }
    run {
        val (_, _, ss) = pair(); val (s, _) = ss
        val p = ByteArray(1400)
        val t0 = System.nanoTime(); var bytes = 0L
        while (System.nanoTime() - t0 < 400_000_000L) { s.encrypt(p, 0, p.size, 0L); bytes += p.size }
        val mbs = bytes / 1e6 / ((System.nanoTime() - t0) / 1e9)
        T.check("şifreleme hızı makul (> 15 MB/sn, JVM)", mbs > 15, "%.0f MB/sn".format(mbs))
    }
}
