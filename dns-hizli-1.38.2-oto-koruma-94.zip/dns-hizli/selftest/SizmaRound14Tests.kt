package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.Section
import app.dnshizli.ui.Strings
import java.io.File
import java.util.ArrayDeque

/** sizma38: WireGuard entegrasyonu — bölünmüş tünelde DNS yolu, Keystore sıkı sarma, içe aktarma arayüzü, servis/bildirim yapısı. */
internal fun runRound14Tests() {
    splitDnsTests()
    vaultTests()
    importUiTests()
    platformStaticTests()
}

private fun udp4(src: ByteArray, dst: ByteArray, sport: Int, dport: Int, payload: ByteArray, proto: Int = 17): ByteArray {
    val n = 28 + payload.size
    val b = ByteArray(n)
    b[0] = 0x45; Packets.put16(b, 2, n); b[8] = 64; b[9] = proto.toByte()
    System.arraycopy(src, 0, b, 12, 4); System.arraycopy(dst, 0, b, 16, 4)
    Packets.put16(b, 20, sport); Packets.put16(b, 22, dport); Packets.put16(b, 24, 8 + payload.size)
    System.arraycopy(payload, 0, b, 28, payload.size)
    WgDnsForwarder.fixChecksums(b, n, false, 20)
    return b
}

private fun cfgText(priv: ByteArray, pub: ByteArray, allowed: String, dns: String = "10.64.0.1") = """
    [Interface]
    PrivateKey = ${java.util.Base64.getEncoder().encodeToString(priv)}
    Address = 10.66.0.2/32
    DNS = $dns
    PostUp = rm -rf /
    [Peer]
    PublicKey = ${java.util.Base64.getEncoder().encodeToString(pub)}
    AllowedIPs = $allowed
    Endpoint = vpn.example:51820
""".trimIndent()

private fun splitDnsTests() {
    T.group("sizma38: bölünmüş tünel — DNS sunucusu AllowedIPs dışında olsa da yalnızca DNS tünelden gider")
    val cPriv = Wg.generatePrivate(); val sPriv = Wg.generatePrivate()
    val cfg = (WgConfig.parse(cfgText(cPriv, Wg.publicKey(sPriv), "192.168.50.0/24")) as WgConfig.Companion.Result.Ok).cfg
    val cli = byteArrayOf(10, 66, 0, 2); val dnsIp = byteArrayOf(10, 64, 0, 1); val fake4 = SelfTest.FAKE4
    val res = WgResponder(sPriv).also { it.addPeer(WgResponder.Peer(Wg.publicKey(cPriv))) }
    var srvSession: WgSession? = null
    val wire = ArrayDeque<ByteArray>(); val tun = ArrayList<ByteArray>(); val atServer = ArrayList<ByteArray>()
    val tunnel = WgTunnel(cfg, { wire.add(it) }, { b, o, l -> tun.add(b.copyOfRange(o, o + l)) }, now = { 1000L })
    fun pump() {
        while (wire.isNotEmpty()) {
            val m = wire.removeFirst()
            when (m[0].toInt()) {
                Wg.TYPE_INITIATION -> { val i = res.consumeInitiation(m, 0, m.size) ?: continue; val (r, s) = res.respond(i, 7, 1000L)!!; srvSession = s; tunnel.fromNet(r, 0, r.size) }
                Wg.TYPE_DATA -> { val pt = srvSession!!.decrypt(m, 0, m.size, 1000L) ?: continue; if (pt.isNotEmpty()) atServer.add(pt.copyOf(WgTunnel.innerLength(pt)!!)) }
            }
        }
    }
    fun push(p: ByteArray) { val m = srvSession!!.encrypt(p, 0, p.size, 1000L)!!; tunnel.fromNet(m, 0, m.size) }
    val bridge = WgDnsForwarder(tunnel, { b, o, l -> tun.add(b.copyOfRange(o, o + l)) }, fake4, SelfTest.FAKE6, now = { 1000L })
    try {
        val q = udp4(cli, fake4, 40000, 53, Dns.buildQuery(0x1111, "site.example"))
        bridge.onPacket(q, q.size); pump()
        T.check("DNS sorgusu tünelden yapılandırmanın DNS'ine gitti (AllowedIPs dışında olmasına rağmen)",
            atServer.size == 1 && atServer[0].copyOfRange(16, 20).contentEquals(dnsIp) && tunnel.dropped == 0L, "srv=${atServer.size} drop=${tunnel.dropped}")
        val d0 = tunnel.dropped
        val tcp = udp4(cli, dnsIp, 40001, 53, ByteArray(4), proto = 6); tunnel.fromTun(tcp, tcp.size)
        val other = udp4(cli, dnsIp, 40002, 443, ByteArray(4)); tunnel.fromTun(other, other.size)
        T.check("o adrese DNS dışı trafik (TCP/53, UDP/443) tünele alınmaz", tunnel.dropped == d0 + 2 && atServer.size == 1)
        val outside = udp4(cli, byteArrayOf(8, 8, 8, 8), 40003, 53, ByteArray(12)); tunnel.fromTun(outside, outside.size)
        T.check("başka bir adrese UDP/53 tünele alınmaz", tunnel.dropped == d0 + 3)
        val t0 = tun.size
        val ans = atServer[0].copyOfRange(28, atServer[0].size).also { Packets.put16(it, 2, 0x8180) }
        push(udp4(dnsIp, cli, 53, 40000, ans))
        T.check("bekleyen sorgunun cevabı kabul edilir, sahte adresten döner", tun.size == t0 + 1 && tun.last().copyOfRange(12, 16).contentEquals(fake4))
        val s0 = tunnel.spoofed
        push(udp4(dnsIp, cli, 53, 40000, ans))
        T.check("aynı cevap ikinci kez: bekleyen yok → sahte sayılır, tün'e yazılmaz", tunnel.spoofed == s0 + 1 && tun.size == t0 + 1)
        push(udp4(dnsIp, cli, 443, 40005, ByteArray(8)))
        T.check("DNS sunucusundan DNS dışı paket (AllowedIPs dışı) sahte sayılır", tunnel.spoofed == s0 + 2 && tun.size == t0 + 1)
        push(udp4(byteArrayOf(192.toByte(), 168.toByte(), 50, 9), cli, 9999, 40006, ByteArray(8)))
        T.check("AllowedIPs içinden gelen normal paket tün'e yazılır", tun.size == t0 + 2)
        bridge.close()
        val q2 = udp4(cli, dnsIp, 40007, 53, Dns.buildQuery(1, "x.example")); val d1 = tunnel.dropped
        tunnel.fromTun(q2, q2.size)
        T.check("köprü kapanınca DNS istisnası da kalkar", tunnel.dropped == d1 + 1)
        T.check("isUdp53: kısa/IPv4 olmayan paket güvenle reddedilir", !WgTunnel.isUdp53(ByteArray(0), 0, true) && !WgTunnel.isUdp53(ByteArray(10), 10, true))
    } finally { bridge.close(); tunnel.close() }
}

private fun vaultTests() {
    T.group("sizma38: WireGuard yapılandırması yalnızca sarılı saklanır (düz metne düşmez)")
    val xor = object : KeyWrapper {
        override fun wrap(plain: ByteArray) = ByteArray(12) { 7 } + plain.map { (it.toInt() xor 0x5A).toByte() }.toByteArray()
        override fun unwrap(blob: ByteArray) = if (blob.size < 12) null else blob.copyOfRange(12, blob.size).map { (it.toInt() xor 0x5A).toByte() }.toByteArray()
    }
    val broken = object : KeyWrapper { override fun wrap(plain: ByteArray): ByteArray? = null; override fun unwrap(blob: ByteArray): ByteArray? = null }
    val text = "[Interface]\nPrivateKey = gizli".toByteArray()
    val sealed = KeyVault.sealStrict(text, xor)
    T.check("sarılı blob düz metni içermez", sealed != null && !String(sealed, Charsets.ISO_8859_1).contains("gizli"))
    T.check("sarılı blob geri açılır", KeyVault.openStrict(sealed!!, xor)?.contentEquals(text) == true)
    T.check("sarma yapılamazsa null (KeyVault.store gibi düz yazmaya düşmez)", KeyVault.sealStrict(text, broken) == null && KeyVault.store(text, broken).contentEquals(text))
    T.check("düz dosya açılmaz (sıkı biçim yalnızca sarılıyı kabul eder)", KeyVault.openStrict(text, xor) == null)
    T.check("anahtar kaybolduysa açılamaz", KeyVault.openStrict(sealed, broken) == null)
}

private fun importUiTests() {
    T.group("sizma38: WireGuard içe aktarma — doğrulanmadan kaydedilmez, komut alanları çalışmaz")
    val cPriv = Wg.generatePrivate(); val pub = Wg.publicKey(Wg.generatePrivate())
    val good = cfgText(cPriv, pub, "0.0.0.0/0, ::/0")
    val r = Rig(Rig.base())
    r.host.clipboard = "çöp metin"
    r.model.wgImportClipboard()
    T.check("geçersiz metin: neden gösterilir, hiçbir şey kaydedilmez", r.host.wgText == null && "wgSave" !in r.host.calls && r.model.toast?.text?.startsWith(Strings.wgError("").trimEnd()) == true, r.model.toast?.text ?: "")
    r.host.clipboard = null
    r.model.wgImportClipboard()
    T.check("boş pano: uyarı", r.model.toast?.text == Strings.MINE_CLIP_EMPTY)
    r.host.clipboard = good
    r.model.wgImportClipboard()
    T.check("geçerli yapılandırma kaydedilir ve özet gösterilir", r.host.wgText == good && r.model.toast?.text?.contains("vpn.example:51820") == true, r.model.toast?.text ?: "")
    T.check("özet: tam tünel", r.model.wgSummary() == Strings.wgSummary("vpn.example:51820", true))
    r.host.wgSaveOk = false; r.host.wgText = null
    r.model.wgImportClipboard()
    T.check("depo yazamazsa başarı denmez", r.host.wgText == null && r.model.toast?.text == Strings.MINE_FILE_ERR)
    r.host.wgSaveOk = true
    r.model.wgToggle()
    T.check("yapılandırma yokken bağlan: uyarı, servis başlamaz", "wgConnect" !in r.host.calls && r.model.toast?.text == Strings.WG_NONE)
    r.host.wgText = good
    r.model.wgToggle(); T.check("bağlan", r.host.wgOn)
    r.model.wgToggle(); T.check("kes", !r.host.wgOn)
    r.model.wgToggle(); r.model.wgDelete()
    T.check("silerken açık tünel önce kesilir", !r.host.wgOn && r.host.wgText == null && r.host.calls.indexOf("wgDisconnect") < r.host.calls.lastIndexOf("wgDelete"))

    val rig = Rig(Rig.base())
    rig.scene.openSection(Section.EXPERIMENTAL); rig.settle(900)
    repeat(12) { if (rig.find(Strings.WG_TITLE) == null) rig.drag(180f, rig.h * 0.7f, rig.h * 0.7f - 220f, 8) }
    T.check("Deneysel sayfasında WireGuard satırı var", rig.find(Strings.WG_TITLE) != null)
    rig.tapText(Strings.WG_TITLE, settleMs = 600)
    T.check("yapılandırma yokken: yalnızca içe aktarma seçenekleri", rig.find(Strings.WG_PASTE) != null && rig.find(Strings.WG_FILE) != null && rig.find(Strings.WG_CONNECT) == null && rig.find(Strings.WG_DELETE) == null)
    rig.host.clipboard = good
    rig.tapText(Strings.WG_PASTE, settleMs = 600)
    T.check("seçenekten panodan içe aktarma çalışır", rig.host.wgText == good)
}

private fun platformStaticTests() {
    T.group("sizma38: WireGuard servisi ve depo yapısı")
    fun src(p: String) = listOf(p, "../$p").map { File(it) }.firstOrNull { it.isFile }?.readText() ?: ""
    val man = src("app/src/main/AndroidManifest.xml")
    val svc = Regex("""<service[^>]*WgVpnService[^>]*>""", RegexOption.DOT_MATCHES_ALL).find(man)?.value ?: ""
    T.check("bildirimde WgVpnService: dışa kapalı, BIND_VPN_SERVICE, systemExempted", svc.contains("exported=\"false\"") && svc.contains("BIND_VPN_SERVICE") && svc.contains("systemExempted"))
    val w = src("app/src/main/java/app/dnshizli/platform/WgVpnService.kt")
    T.check("uç nokta soketi bağlanmadan önce korunur (tünele geri dönmez)", w.indexOf("protect(s)") in 1 until w.indexOf("s.connect(ep)"))
    T.check("uç nokta adı tün kurulmadan çözülür", w.indexOf("resolveAll(cfg)") in 1 until w.indexOf("establish(cfg, mtu)") && w.contains("resolve(c.peer.endpointHost, c.peer.endpointPort)"))
    T.check("IPv6 ailesi elle serbest bırakılmaz (yapılandırmada yoksa engelli kalır)", !w.contains(".allowFamily("))
    T.check("DNS süzgeçten geçer (FilteringForwarder(WgDnsForwarder))", w.contains("FilteringForwarder(WgDnsForwarder("))
    T.check("kapanışta oturum anahtarları silinir", w.contains("tunnel?.close()"))
    val st = src("app/src/main/java/app/dnshizli/platform/WgStore.kt")
    T.check("depo yalnızca sıkı sarma kullanır, yedeğe girmez", st.contains("sealStrict") && st.contains("openStrict") && !st.contains("KeyVault.store") && st.contains("noBackupFilesDir"))
    T.check("WireGuard kendi Keystore anahtarını kullanır", st.contains("AndroidKeystoreWrapper(\"dnshizli_wg_cfg_wrap\")"))
    val act = src("app/src/main/java/app/dnshizli/platform/MainActivity.kt")
    T.check("aynı anda tek VPN: DNS kipi başlarken WireGuard kesilir, WireGuard başlarken DNS kipi kesilir",
        act.contains("if (WgVpnService.running) try { startService(WgVpnService.stopIntent(this))") && Regex("""fun startWg\(\)[\s\S]{0,200}DnsVpnService\.disconnectIntent""").containsMatchIn(act))
}
