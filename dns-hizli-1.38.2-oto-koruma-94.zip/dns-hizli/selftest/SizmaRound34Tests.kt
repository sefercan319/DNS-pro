package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.Section
import java.io.File

/** sizma58: tarayıcı parmak izi koruması (tarayıcı kipi). */
internal fun runRound34Tests() {
    T.group("sizma58: parmak izi koruması")
    val samsung = "Mozilla/5.0 (Linux; Android 14; SM-S918B Build/UP1A.231005.007; wv) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.58 Mobile Safari/537.36"
    T.check("model, Android sürümü ve derleme kimliği silinir; Chrome ana sürümü kalır", Fingerprint.userAgent(samsung) ==
        "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36", Fingerprint.userAgent(samsung))
    val sb = "Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/26.0.1 Chrome/122.0.6261.105 Mobile Safari/537.36"
    T.check("Samsung Internet: ailesi ve ana sürümü kalır", Fingerprint.userAgent(sb) == "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/26.0 Chrome/122.0.0.0 Mobile Safari/537.36", Fingerprint.userAgent(sb))
    val ff = "Mozilla/5.0 (Android 14; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0"
    T.check("Firefox: zaten azaltılmış biçim bozulmaz", Fingerprint.userAgent(ff) == ff)
    val already = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"
    T.check("zaten nötr UA aynen kalır (iki kez uygulamak bir şey değiştirmez)", Fingerprint.userAgent(already) == already && Fingerprint.userAgent(Fingerprint.userAgent(samsung)) == Fingerprint.userAgent(samsung))
    val lines = listOf("Host: a.com", "User-Agent: $samsung", "Sec-CH-UA: \"Chromium\";v=\"130\"", "sec-ch-ua-model: \"SM-S918B\"", "Sec-CH-UA-Platform-Version: \"14.0.0\"",
        "Sec-CH-UA-Full-Version-List: x", "Device-Memory: 8", "DPR: 3", "X-Requested-With: com.x", "Sec-CH-UA-Mobile: ?1", "Cookie: a=b")
    val out = Fingerprint.request(lines)
    T.check("yüksek entropili ipuçları silinir, model boşaltılır, düşük entropililer ve diğerleri kalır (sıra korunur)",
        out == listOf("Host: a.com", "User-Agent: " + Fingerprint.userAgent(samsung), "Sec-CH-UA: \"Chromium\";v=\"130\"", "Sec-CH-UA-Model: \"\"", "Sec-CH-UA-Mobile: ?1", "Cookie: a=b"), out.toString())
    T.check("cevapta Accept-CH / Critical-CH silinir", Fingerprint.response(listOf("Content-Type: text/html", "Accept-CH: Sec-CH-UA-Model", "critical-ch: x", "Set-Cookie: a=b")) ==
        listOf("Content-Type: text/html", "Set-Cookie: a=b"))

    val (up, head) = fingerprintE2E(true, samsung)
    T.check("uçtan uca: sunucu modeli, sürümü ve WebView paketini görmez", up != null && !up.contains("SM-S918B") && !up.contains("Android 14") && !up.contains("6723") &&
        !up.contains("com.example.app") && !up.contains("Device-Memory") && up.contains("Chrome/130.0.0.0") && up.contains("Sec-CH-UA-Mobile: ?1"), up ?: "")
    T.check("uçtan uca: tarayıcı ipucu isteğini almaz", !head.contains("Accept-CH", ignoreCase = true) && !head.contains("Critical-CH", ignoreCase = true), head)
    val (up2, head2) = fingerprintE2E(false, samsung)
    T.check("kapalıyken başlıklara dokunulmaz", up2 != null && up2.contains("SM-S918B") && head2.contains("Accept-CH"))

    val back = SettingsCodec.decode(SettingsCodec.encode(AppSettings(fpGuard = false)))
    T.check("varsayılan açık; ayar gidiş-dönüş; içe aktarmada kapatma uyarılır", AppSettings().fpGuard && !back.fpGuard && "fpGuard" in ImportReview.REVIEWED &&
        SensitiveChange.PRIVACY in ImportReview.changes(AppSettings(), AppSettings(fpGuard = false)))
    T.check("servis ayarı vekile canlı verir", File("app/src/main/java/app/dnshizli/platform/DnsVpnService.kt").readText().contains("px.fingerprint = s.fpGuard"))
    T.check("metinler 12 dilde", FpText.M.values.all { v -> v.size == Lang.values().size && v.none { it.isBlank() } })
    val r = Rig(Rig.base("aqua"))
    r.scene.openSection(Section.EXPERIMENTAL); r.settle(900)
    T.check("tarayıcı kipi kapalıyken anahtar görünmez", r.find(FpText.t("title")) == null)
    r.model.update { it.copy(mitmOn = true) }; r.settle(600)
    T.check("tarayıcı kipi açıkken anahtar görünür", r.reveal(FpText.t("title")) != null)
}
