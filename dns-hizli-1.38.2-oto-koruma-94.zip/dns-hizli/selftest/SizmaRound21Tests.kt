package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.core.LinkCheck.Level
import app.dnshizli.core.LinkCheck.Reason
import app.dnshizli.ui.Section
import app.dnshizli.ui.Strings
import java.io.File

/** sizma45: dolandırıcılık mesajı koruması — bağlantı çıkarma, işaretler, Türkiye'ye özgü örnekler, arayüz, paylaşım, bildirim denetimi. */
internal fun runRound21Tests() {
    extractTests()
    checkTests()
    uiTests()
    staticTests()
}

private fun extractTests() {
    T.group("sizma45: mesajdan bağlantı çıkarma")
    val sms = "Sayin musterimiz, kargonuz teslim edilemedi. Adres guncellemek icin: ptt-kargo-teslim.xyz/tr?id=8812 . Iyi gunler!"
    T.check("çıplak alan adı (şemasız) bulunur, sondaki nokta atılır", LinkCheck.extract(sms) == listOf("ptt-kargo-teslim.xyz/tr?id=8812"))
    T.check("https bağlantıları ve parantez/virgül sonları", LinkCheck.extract("bak (https://ornek.com/a), sonra http://x.example.") == listOf("https://ornek.com/a", "http://x.example"))
    T.check("e-posta adresi bağlantı sayılmaz", LinkCheck.extract("yaz: ali@ornek.com") .isEmpty())
    T.check("sayılar/tarihler bağlantı sayılmaz", LinkCheck.extract("Tutar 1.250,00 TL, tarih 12.05.2026").isEmpty())
    T.check("en çok 10 bağlantı", LinkCheck.extract((1..30).joinToString(" ") { "a$it.example.com" }).size == 10)
}

private fun lv(u: String, v: (String) -> Int = { -1 }) = LinkCheck.check(u, v)
private fun has(r: LinkCheck.Result, x: Reason) = r.findings.any { it.reason == x }

private fun checkTests() {
    T.group("sizma45: bağlantı işaretleri")
    T.check("resmî adres: güvenli (e-Devlet, Ziraat, Garanti alt alanı)", lv("https://www.turkiye.gov.tr/").level == Level.OK && lv("https://www.ziraatbank.com.tr/tr").level == Level.OK && lv("https://sube.garantibbva.com.tr/isube/login").level == Level.OK)
    val a = lv("https://ziraat-bonus-puan.com/giris")
    T.check("marka adı resmî olmayan alanda → TEHLİKE", a.level == Level.DANGER && has(a, Reason.BRAND_ELSEWHERE) && has(a, Reason.BAIT_WORDS))
    val b = lv("ptt-kargo-teslim.xyz/tr?id=8812")
    T.check("kısa marka (ptt) + riskli uzantı + tuzak sözcük → birleşik TEHLİKE", b.level == Level.DANGER && (has(b, Reason.BRAND_HINT) || has(b, Reason.BRAND_ELSEWHERE)) && has(b, Reason.RISKY_TLD), b.findings.joinToString { it.reason.name })
    T.check("kısa marka tek başına sözcük içinde → alarm yok (getptt değil 'optt')", lv("https://shopttravel.com").findings.none { it.reason == Reason.BRAND_HINT })
    val c = lv("https://garantibbwa.com.tr/")
    T.check("tek harf farklı taklit (garantibbwa) → TEHLİKE", c.level == Level.DANGER && has(c, Reason.LOOKALIKE))
    val d = lv("https://xn--zraatbank-vpb.com.tr/")
    T.check("Türkçe harfle taklit (zıraatbank) → TEHLİKE", d.level == Level.DANGER && has(d, Reason.LOOKALIKE), d.findings.joinToString { it.reason.name + ":" + it.detail })
    val e = lv("https://xn--pypal-4ve.com/")   // Kiril 'а'
    T.check("Kiril harfli karışık alfabe (pаypal) → TEHLİKE", e.level == Level.DANGER && (has(e, Reason.MIXED_SCRIPT) || has(e, Reason.LOOKALIKE)))
    T.check("tamamen Türkçe IDN (çiçek) yalnız dikkat", lv("https://xn--iek-1lab.com/").level == Level.CAUTION)
    T.check("rn → m taklidi (akbank değil 'akbarnk' değil; 'netflix' için 'netfiix')", lv("https://netfiix.com/login").level == Level.DANGER)
    T.check("küresel marka başka alanda: tek başına dikkat, tuzak sözcükle tehlike", lv("https://amazon-fan.example/").level == Level.CAUTION && lv("https://amazon-hediye.xyz/odul").level == Level.DANGER)
    T.check("çıplak IP → TEHLİKE", lv("http://185.1.2.3/odeme").level == Level.DANGER)
    val f = lv("https://www.isbank.com.tr@kotu.example/giris")
    T.check("kullanıcı@ hilesi → TEHLİKE (gerçek ad @ sonrası)", f.level == Level.DANGER && has(f, Reason.USERINFO) && f.host == "kotu.example")
    T.check(".apk indirme → TEHLİKE", lv("https://guncelleme.example/app.apk").level == Level.DANGER)
    T.check("kısaltılmış bağlantı → dikkat (hedef gizli)", lv("https://bit.ly/3xYz").let { it.level == Level.CAUTION && has(it, Reason.SHORTENER) })
    T.check("şifresiz http tek başına dikkat", lv("http://ornek.example/").level == Level.CAUTION)
    T.check("engel listesindeki ad → TEHLİKE", lv("https://phish.example/a") { if (it == "phish.example") FilterVerdict.LIST else FilterVerdict.PASS }.let { it.level == Level.DANGER && has(it, Reason.BLOCKLIST) })
    T.check("sıradan site: işaret yok", lv("https://www.wikipedia.org/wiki/Istanbul").level == Level.OK)
    T.check("kayıt edilebilir alan .com.tr dahil doğru", LinkCheck.registrable("a.b.ziraatbank.com.tr") == "ziraatbank.com.tr" && LinkCheck.registrable("x.ornek.com") == "ornek.com")
    T.check("sonuç sıralı: tehlikeli işaret önce", a.findings.first().reason.level == Level.DANGER)
    var fp = 0
    for (u in listOf("https://www.google.com", "https://www.trendyol.com/sepet", "https://www.hepsiburada.com", "https://www.sahibinden.com", "https://mail.google.com",
        "https://www.yurticikargo.com/tr/online-servisler/gonderi-sorgula", "https://www.ptt.gov.tr", "https://e-sube.halkbank.com.tr", "https://www.vakifbank.com.tr",
        "https://www.n11.com", "https://getir.com", "https://s3.amazonaws.com/x", "https://www.amazon.de", "https://www.vodafone.de", "https://scontent.cdninstagram.com/v", "https://www.turkcell.com.tr/paket", "https://www.instagram.com/p/x", "https://github.com", "https://www.ntv.com.tr/ekonomi"))
        if (lv(u).level == Level.DANGER) fp++
    T.check("19 bilinen meşru adreste (yardımcı/CDN ve ülke alanları dahil) yanlış TEHLİKE yok", fp == 0, "$fp")
}

private fun uiTests() {
    T.group("sizma45: arayüz — panodan denetim, engelleme")
    val rig = Rig(Rig.base())
    rig.host.clipboard = "Garanti BBVA: hesabiniz askiya alindi, dogrulayin: https://garanti-bbva-guvenlik.xyz/giris"
    rig.model.checkClipboardLink(); rig.settle(600)
    T.check("panodaki bağlantı denetlenir, sonuç paneli açılır", rig.scene.hasSheet && rig.find(Strings.LINK_DANGER) != null && rig.find("garanti-bbva-guvenlik.xyz") != null)
    rig.tapText(Strings.LINK_BLOCK_BTN, settleMs = 600)
    T.check("'Bu alanı engelle' kayıtlı alanı kendi engel listesine ekler", "garanti-bbva-guvenlik.xyz" in rig.model.settings.filterBlock)
    val r2 = Rig(Rig.base())
    r2.host.clipboard = "merhaba nasılsın"
    r2.model.checkClipboardLink(); r2.settle(300)
    T.check("bağlantı yoksa uyarı, panel açılmaz", !r2.scene.hasSheet && r2.model.toast?.text == Strings.LINK_NONE)
    r2.model.checkLinkText("https://www.turkiye.gov.tr"); r2.settle(600)
    T.check("güvenli bağlantıda engelle düğmesi yok, uyarı metni var", r2.scene.hasSheet && r2.find(Strings.LINK_BLOCK_BTN) == null && r2.find(Strings.LINK_OK.take(20)) != null)
    val r3 = Rig(Rig.base())
    r3.scene.openSection(Section.FILTER); r3.settle(900)
    T.check("Süzgeç sayfasında bağlantı denetimi ve bildirim denetimi satırları", r3.find(Strings.LINK_CHECK_CLIP) != null && r3.find(Strings.LINK_WATCH) != null)
    r3.tapText(Strings.LINK_WATCH, settleMs = 400)
    T.check("bildirim denetimi açılınca erişim yoksa sistem ayarı açılır", "linkWatchOpen" in r3.host.calls && r3.host.linkWatchOn)
    T.check("Türkçe metinler", Strings.LINK_CHECK == "Bağlantı denetimi" && Strings.linkReason("APK", "").contains("kurma"))
}

private fun staticTests() {
    T.group("sizma45: paylaşım ve bildirim denetimi yapısı")
    fun src(p: String) = listOf(p, "../$p").map { File(it) }.firstOrNull { it.isFile }?.readText() ?: ""
    val man = src("app/src/main/AndroidManifest.xml")
    T.check("Paylaş → DNS Hızlı (text/plain)", Regex("""android.intent.action.SEND"[\s\S]{0,200}text/plain""").containsMatchIn(man))
    val svc = Regex("""<service[^>]*LinkWatchService[^>]*>""").find(man)?.value ?: ""
    T.check("bildirim dinleyicisi yalnız sistemce bağlanabilir (BIND_NOTIFICATION_LISTENER_SERVICE)", svc.contains("BIND_NOTIFICATION_LISTENER_SERVICE"))
    val w = src("app/src/main/java/app/dnshizli/platform/LinkWatchService.kt")
    T.check("yalnız ayar açıkken, yalnız mesaj bildirimleri, yalnız TEHLİKE uyarılır; metin saklanmaz", w.contains("if (!enabled(this)") && w.contains("isMessage(") && w.contains("r.level != LinkCheck.Level.DANGER") && !w.contains("SharedPreferences.Editor") && !w.contains("writeText"))
    T.check("aynı alan için 10 dk tekrar uyarı yok", w.contains("600_000L"))
    val a = src("app/src/main/java/app/dnshizli/platform/MainActivity.kt")
    T.check("paylaşılan metin yalnız denetlenir (açılmaz)", a.contains("model.checkLinkText(intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString())"))
}
