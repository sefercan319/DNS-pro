package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.Section
import app.dnshizli.ui.Strings
import java.io.File

/** sizma57: üretici izleme engeli (Samsung, Xiaomi) — tek anahtar, süzgeç kapalıyken de. */
internal fun runRound33Tests() {
    T.group("sizma57: üretici izleme engeli")
    val all = OemTelemetry.ALL
    T.check("adlar geçerli, küçük harf, tekrarsız; genel sonek yok", all.all { FilterNames.normalize(it) == it && !FilterNames.isPublicSuffix(it) } && all.toSet().size == all.size,
        all.filter { FilterNames.normalize(it) != it }.toString())
    // telefonu bozacak adlar asla listede ya da onların üst adı değil
    val vital = listOf("account.xiaomi.com", "i.mi.com", "api.micloud.xiaomi.net", "update.miui.com", "themes.miui.com", "app.mi.com", "weatherapi.market.xiaomi.com",
        "samsung.com", "account.samsung.com", "galaxystore.samsung.com", "samsungcloud.com", "api.samsungcloud.com", "samsungapps.com", "fota-cloud-dn.ospserver.net")
    fun covered(n: String) = all.any { n == it || n.endsWith(".$it") }
    T.check("hesap, bulut, tema, mağaza, güncelleme ve hava durumu adları engellenmez", vital.none { covered(it) }, vital.filter { covered(it) }.toString())
    T.check("bilinen izleme adları ve alt adları kapsanır", listOf("data.mistat.xiaomi.com", "tracking.intl.miui.com", "sdkconfig.ad.xiaomi.com", "api.ad.intl.xiaomi.com",
        "log-config.samsungacr.com", "config.samsungads.com", "nmetrics.samsung.com").all { covered(it) })
    val s0 = AppSettings(filterBlock = listOf("benim.example.com"))
    T.check("kapalıyken liste değişmez; açıkken kendi listenin ardına eklenir (tekrarsız)", OemTelemetry.blockFor(s0, false) == listOf("benim.example.com") &&
        OemTelemetry.blockFor(s0.copy(oemBlock = true), false).let { it.first() == "benim.example.com" && it.size == 1 + all.size } &&
        OemTelemetry.blockFor(s0.copy(oemBlock = true, filterBlock = listOf("samsungads.com")), false).count { it == "samsungads.com" } == 1)
    T.check("kişisel sürümde YouTube listesiyle birlikte", OemTelemetry.blockFor(s0.copy(oemBlock = true, youtubeAds = true), true).containsAll(YouTubeAds.HOSTS + all))
    T.check("üretici tanıma", OemTelemetry.brandOf("Xiaomi") == "Xiaomi" && OemTelemetry.brandOf("POCO") == "Xiaomi" && OemTelemetry.brandOf("samsung") == "Samsung" && OemTelemetry.brandOf("Google") == null)

    // motor: süzgeç kapalıyken de engeller
    FilterRuntime.reset()
    FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), OemTelemetry.blockFor(AppSettings(oemBlock = true), false))
    val e = FilterRuntime.engine
    fun blocked(n: String): Boolean { val q = Dns.buildQuery(1, n); return e != null && e.verdict(q, 0, q.size) != FilterVerdict.PASS }
    T.check("süzgeç kapalıyken de: izleme adı ve alt adı engellenir, hesap adı geçer", e != null && blocked("data.mistat.xiaomi.com") && blocked("log-2.samsungacr.com") &&
        !blocked("account.xiaomi.com") && !blocked("www.samsung.com"))
    FilterRuntime.reset()

    val back = SettingsCodec.decode(SettingsCodec.encode(AppSettings(oemBlock = true)))
    T.check("ayar gidiş-dönüş; içe aktarmada kapatma uyarılır", back.oemBlock && "oemBlock" in ImportReview.REVIEWED &&
        SensitiveChange.PRIVACY in ImportReview.changes(AppSettings(oemBlock = true), AppSettings(oemBlock = false)))
    val src = listOf("ui/Model.kt", "platform/DnsVpnService.kt", "platform/WgVpnService.kt", "platform/App.kt").map { File("app/src/main/java/app/dnshizli/$it").readText() }
    T.check("motoru kuran her yer üretici listesini kullanır", src.all { !it.contains("YouTubeAds.blockFor(") && it.contains("OemTelemetry.blockFor(") })
    val bad = OemText.M.filter { (_, v) -> v.size != Lang.values().size || v.any { it.isBlank() } }.keys
    T.check("metinler 12 dilde", bad.isEmpty())

    val awt = AwtGfx(java.awt.image.BufferedImage(1, 1, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics())
    val r = Rig(Rig.base("aqua"), 360, 780, metrics = awt)
    r.scene.openSection(Section.FILTER); r.settle(900)
    T.check("Engelleme sayfasında anahtar", r.reveal(OemText.t("title")) != null)
    r.tapText(OemText.t("title"), settleMs = 900)
    T.check("açılınca kaydedilir; 'son engellenenler' süzgeç kapalıyken de görünür", r.model.settings.oemBlock && r.reveal(Strings.FILTER_LAST) != null)
    r.reveal(OemText.t("title"))
    run { val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/uretici-izleme.png"); cv.dispose() }
    FilterRuntime.reset()
}
