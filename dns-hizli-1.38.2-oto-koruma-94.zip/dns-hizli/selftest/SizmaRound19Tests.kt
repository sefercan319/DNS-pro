package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.BufferedReader
import java.io.File
import java.io.OutputStreamWriter
import java.security.KeyStore
import java.security.SecureRandom
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/** sizma43: QUIC (DoQ/DoH3) TLS 1.3'te kuantum sonrası karma anahtar değişimi X25519MLKEM768 — Go crypto/tls ile birlikte çalışma, düşüş. */
internal fun runRound19Tests() {
    helloTests()
    goTests()
    memoryTests()
}

private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
private val NO_TRUST = object : X509TrustManager {
    override fun checkClientTrusted(c: Array<X509Certificate>?, a: String?) {}
    override fun checkServerTrusted(c: Array<X509Certificate>?, a: String?) {}
    override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
}

/** ClientHello'daki (tür → gövde) uzantılar. */
private fun exts(ch: ByteArray): Map<Int, ByteArray> {
    var p = 4 + 2 + 32
    p += 1 + (ch[p].toInt() and 0xFF)
    p += 2 + (((ch[p].toInt() and 0xFF) shl 8) or (ch[p + 1].toInt() and 0xFF))
    p += 1 + (ch[p].toInt() and 0xFF)
    val end = p + 2 + (((ch[p].toInt() and 0xFF) shl 8) or (ch[p + 1].toInt() and 0xFF)); p += 2
    val m = LinkedHashMap<Int, ByteArray>()
    while (p < end) {
        val t = ((ch[p].toInt() and 0xFF) shl 8) or (ch[p + 1].toInt() and 0xFF); val l = ((ch[p + 2].toInt() and 0xFF) shl 8) or (ch[p + 3].toInt() and 0xFF)
        m[t] = ch.copyOfRange(p + 4, p + 4 + l); p += 4 + l
    }
    return m
}

private fun helloTests() {
    T.group("sizma43: ClientHello — karma + x25519 birlikte önerilir")
    val pq = QuicTls("dns.example", "doq", ByteArray(4), NO_TRUST, SecureRandom(), pq = true).clientHello()
    val cl = QuicTls("dns.example", "doq", ByteArray(4), NO_TRUST, SecureRandom(), pq = false).clientHello()
    val e = exts(pq); val ec = exts(cl)
    T.check("supported_groups: X25519MLKEM768 önce, sonra x25519", e[10]?.let { hex(it) } == "000411ec001d" && ec[10]?.let { hex(it) } == "0002001d")
    val ks = e[51]!!
    T.check("key_share: 1216 baytlık karma (ML-KEM ek ‖ X25519) + 32 baytlık x25519 — HRR gerekmez", ks.size == 2 + 4 + 1216 + 4 + 32 &&
        hex(ks.copyOfRange(2, 6)) == "11ec04c0" && hex(ks.copyOfRange(6 + 1216, 6 + 1216 + 4)) == "001d0020" &&
        ks.copyOfRange(6 + 1184, 6 + 1216).contentEquals(ks.copyOfRange(6 + 1216 + 4, ks.size)))
    T.check("PQ kapalıyken yalnız x25519 (eski davranış)", ec[51]!!.size == 2 + 4 + 32)
    T.check("ClientHello boyutu: ~1,4 KB (birden çok Initial paketine bölünür)", pq.size in 1250..1600 && cl.size < 300, "${pq.size}")
    // ServerHello'da beklenmeyen grup/uzunluk → tipli hata
    val t = QuicTls("dns.example", "doq", ByteArray(4), NO_TRUST, SecureRandom(), pq = false); t.clientHello()
    fun sh(group: Int, share: ByteArray): ByteArray {
        val ext = byteArrayOf(0, 43, 0, 2, 3, 4, 0, 51) + byteArrayOf(((share.size + 4) shr 8).toByte(), (share.size + 4).toByte(), (group shr 8).toByte(), group.toByte(), (share.size shr 8).toByte(), share.size.toByte()) + share
        val body = byteArrayOf(3, 3) + ByteArray(32) { 1 } + byteArrayOf(0, 0x13, 0x01, 0, (ext.size shr 8).toByte(), ext.size.toByte()) + ext
        return byteArrayOf(2, (body.size shr 16).toByte(), (body.size shr 8).toByte(), body.size.toByte()) + body
    }
    fun rejects(m: ByteArray, pq: Boolean): Boolean { val c = QuicTls("x.example", "doq", ByteArray(4), NO_TRUST, SecureRandom(), pq = pq); c.clientHello(); return try { c.feed(0, m); false } catch (_: QuicTlsException) { true } }
    T.check("PQ önermediysek sunucunun karma seçimi reddedilir (düşürme/karışıklık yok)", rejects(sh(0x11EC, ByteArray(1120) { 9 }), pq = false))
    T.check("karma paylaşımın uzunluğu yanlışsa ret", rejects(sh(0x11EC, ByteArray(1119) { 9 }), pq = true))
    T.check("önerilmeyen grup (secp256r1) ret", rejects(sh(0x17, ByteArray(65) { 4 }), pq = true))
}

private fun goBin(): File? {
    val src = listOf("tools/tls-referans", "../tools/tls-referans").map { File(it) }.firstOrNull { File(it, "main.go").isFile } ?: return null
    val go = listOf("/usr/local/go/bin/go", "/usr/bin/go").map { File(it) }.firstOrNull { it.canExecute() }?.path
        ?: System.getenv("PATH")?.split(File.pathSeparator)?.map { File(it, "go") }?.firstOrNull { it.canExecute() }?.path ?: return null
    val out = File(System.getProperty("java.io.tmpdir"), "tlsref-" + ListUpdate.sha256Hex(File(src, "main.go").readBytes()).take(16))
    if (out.canExecute()) return out
    val p = ProcessBuilder(go, "build", "-o", out.absolutePath, ".").directory(src).redirectErrorStream(true).start()
    val log = p.inputStream.bufferedReader().readText()
    if (!p.waitFor(180, TimeUnit.SECONDS) || p.exitValue() != 0) { println("  go build: $log"); return null }
    return out
}

private class Run(val group: Int, val done: Boolean, val secretsMatch: Boolean, val err: String?)

private fun handshake(bin: File, mode: String, pq: Boolean): Run {
    val p = ProcessBuilder(bin.path, mode).start()
    try {
        val r: BufferedReader = p.inputStream.bufferedReader(); val w = OutputStreamWriter(p.outputStream)
        val der = java.util.Base64.getDecoder().decode(r.readLine().removePrefix("CERT "))
        val cert = CertificateFactory.getInstance("X.509").generateCertificate(der.inputStream()) as X509Certificate
        val ksT = KeyStore.getInstance(KeyStore.getDefaultType()).also { it.load(null); it.setCertificateEntry("c", cert) }
        val tm = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()).also { it.init(ksT) }.trustManagers.filterIsInstance<X509TrustManager>().first()
        val t = QuicTls("localhost", "doq", byteArrayOf(0x01, 0x02, 0x40, 0x64), tm, SecureRandom(), pq = pq)
        val secrets = HashMap<Int, ByteArray>()
        var done = false; var err: String? = null
        fun send(level: Int, b: ByteArray) {
            w.write("$level ${hex(b)}\n"); w.flush()
            while (true) {
                val l = r.readLine() ?: break
                if (l == "END") break
                val f = l.split(" ")
                when (f[0]) {
                    "W" -> try { t.feed(if (f[1] == "0") 0 else 1, unhex(f[2])) } catch (e: QuicTlsException) { err = e.message }
                    "S" -> secrets[f[1].toInt()] = unhex(f[2])
                    "DONE" -> done = true
                    "ERR" -> err = l
                }
            }
        }
        send(0, t.clientHello())
        t.clientFinished?.let { send(2, it) }
        val match = secrets[2]?.contentEquals(t.hsServer) == true && secrets[3]?.contentEquals(t.appServer) == true
        return Run(t.group, done && t.done, match, err)
    } finally { p.destroy(); p.waitFor(5, TimeUnit.SECONDS) }
}

private fun goTests() {
    T.group("sizma43: Go crypto/tls (QUIC) ile el sıkışma")
    val bin = goBin()
    if (bin == null) { T.check("Go 1.24+ yok: atlandı", true); return }
    val a = handshake(bin, "hybrid", pq = true)
    T.check("yalnız karma kabul eden sunucu: X25519MLKEM768 ile tamamlanır, anahtar takvimi Go ile aynı", a.group == 0x11EC && a.done && a.secretsMatch, "${a.group} ${a.err}")
    val b = handshake(bin, "both", pq = true)
    T.check("Go varsayılanı: karma seçilir", b.group == 0x11EC && b.done && b.secretsMatch, "${b.group} ${b.err}")
    val c = handshake(bin, "x25519", pq = true)
    T.check("karmayı bilmeyen sunucu: ek gidiş-dönüş olmadan x25519'a düşer", c.group == 0x1d && c.done && c.secretsMatch, "${c.group} ${c.err}")
    val d = handshake(bin, "both", pq = false)
    T.check("PQ kapalı istemci: x25519 (geri uyum)", d.group == 0x1d && d.done && d.secretsMatch)
    val e = handshake(bin, "hybrid", pq = false)
    T.check("ortak grup yoksa sessiz düşüş yok: sunucu reddeder, el sıkışma bitmez", !e.done && e.err != null)
    var ok = 0
    repeat(5) { if (handshake(bin, "hybrid", pq = true).let { it.done && it.secretsMatch }) ok++ }
    T.check("5 ardışık karma el sıkışma (rastgele ML-KEM anahtarları) başarılı", ok == 5)
}

private fun memoryTests() {
    T.group("sizma43: düşüş hafızası (QuicPq)")
    QuicPq.clear()
    T.check("varsayılan: karma önerilir", QuicPq.use("dns.example", 1000))
    QuicPq.failed("DNS.example", 1000)
    T.check("karma ile başarısızlıktan sonra o ad yalnız x25519 (büyük/küçük harf duyarsız)", !QuicPq.use("dns.example", 2000) && QuicPq.use("baska.example", 2000))
    T.check("24 saat sonra karma yeniden denenir", QuicPq.use("dns.example", 1000 + QuicPq.FORGET_MS + 1))
    QuicPq.failed("kesinti.example", 5000); QuicPq.notPqRelated("kesinti.example")
    T.check("x25519 denemesi de başarısızsa (ağ kesintisi) ad karmaya geri döner", QuicPq.use("kesinti.example", 6000))
        QuicPq.enabled = false
    T.check("kapatılınca hiç önerilmez", !QuicPq.use("yeni.example", 0))
    QuicPq.clear()
    val src = listOf("app/src/main/java/app/dnshizli/core/QuicClient.kt", "../app/src/main/java/app/dnshizli/core/QuicClient.kt").map { File(it) }.first { it.isFile }.readText()
    T.check("güven (sertifika) hatası düşüş sebebi değildir; diğer başarısızlıklar hafızaya yazılır", src.contains("QuicPq.failed(host, nowMs())") && src.contains("it is QuicTlsException && it.trust") && src.contains("else if (!pq) QuicPq.notPqRelated(host)"))
    T.check("bağlantı karma grubu bildirir", src.contains("val keyGroup: Int"))
}
