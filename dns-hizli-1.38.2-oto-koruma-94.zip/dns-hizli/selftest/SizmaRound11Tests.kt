package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.Random

/** sizma35: DNS adı okuma tek kaynakta ([DnsName]) — sınırlar, işaretçi kuralı, bileşenler arası tutarlılık; eski okuyucularla fark çözümlemesi. */
internal fun runRound11Tests() {
    try { body11() } finally { Isolation.reset(); IpNames.clear() }
}

private object OldNames {
    /** Eski FilterEngine.readName (sıkıştırmasız). */
    fun question(q: ByteArray, from: Int, end: Int): String? {
        val name = ByteArray(256); var i = from; var n = 0
        while (true) {
            if (i >= end) return null
            val l = q[i].toInt() and 0xFF
            if (l == 0) break
            if (l > 63 || (l and 0xC0) != 0 || i + 1 + l > end) return null
            if (n + l + 1 > name.size - 1) return null
            if (n > 0) name[n++] = '.'.code.toByte()
            for (k in 1..l) { val c = q[i + k].toInt() and 0xFF; name[n++] = (if (c in 'A'.code..'Z'.code) c + 32 else c).toByte() }
            i += 1 + l
        }
        return if (n > 0) String(name, 0, n, Charsets.ISO_8859_1) else null
    }
    /** Eski FilterEngine.readWire (işaretçili, 8 atlama, yön denetimi yok). */
    fun wire(msg: ByteArray, base: Int, from: Int, end: Int): String? {
        val name = ByteArray(256); var i = from; var n = 0; var jumps = 0
        while (true) {
            if (i < base || i >= end) return null
            val l = msg[i].toInt() and 0xFF
            if (l == 0) break
            if ((l and 0xC0) == 0xC0) {
                if (i + 2 > end || ++jumps > 8) return null
                i = base + (((l and 0x3F) shl 8) or (msg[i + 1].toInt() and 0xFF)); continue
            }
            if ((l and 0xC0) != 0 || l > 63 || i + 1 + l > end) return null
            if (n + l + 1 > name.size - 1) return null
            if (n > 0) name[n++] = '.'.code.toByte()
            for (k in 1..l) { val c = msg[i + k].toInt() and 0xFF; name[n++] = (if (c in 'A'.code..'Z'.code) c + 32 else c).toByte() }
            i += 1 + l
        }
        return if (n > 0) String(name, 0, n, Charsets.ISO_8859_1) else null
    }
    /** Eski IpNames ad okuması (Latin-1 küçültme, 253). */
    fun ipNames(b: ByteArray, from: Int, end: Int): String? {
        val sb = StringBuilder(); var p = from
        while (true) {
            if (p >= end) return null
            val l = b[p].toInt() and 0xFF
            if (l == 0) break
            if (l and 0xC0 != 0 || p + 1 + l > end || sb.length + l > 253) return null
            if (sb.isNotEmpty()) sb.append('.')
            for (i in 1..l) sb.append((b[p + i].toInt() and 0xFF).toChar().lowercaseChar())
            p += 1 + l
        }
        return sb.toString()
    }
}

private fun enc(labels: List<ByteArray>): ByteArray { val o = java.io.ByteArrayOutputStream(); for (l in labels) { o.write(l.size); o.write(l) }; o.write(0); return o.toByteArray() }

private fun body11() {
    val rnd = Random(35)
    T.group("sizma35: DNS adı — eski okuyucularla fark çözümlemesi (50 bin ad)")
    var diffQ = 0; var diffIp = 0; var latin = 0; var long254 = 0; val ex = ArrayList<String>()
    repeat(50_000) {
        val labels = (1..rnd.nextInt(6) + 1).map { val n = rnd.nextInt(if (rnd.nextInt(20) == 0) 63 else 12) + 1
            ByteArray(n) { if (rnd.nextInt(8) == 0) rnd.nextInt(256).toByte() else "abcXYZ019-_".random(kotlin.random.Random(rnd.nextLong())).code.toByte() } }
        val w = enc(labels)
        val msg = ByteArray(12) + w + byteArrayOf(0, 1, 0, 1)
        val now = DnsName.string(msg, 0, 12, msg.size)
        val oq = OldNames.question(msg, 12, msg.size)
        val textLen = labels.sumOf { it.size } + labels.size - 1
        if (textLen > 253) { long254++; if (now != null) { diffQ++ }; return@repeat }
        if (now != oq) { diffQ++; if (ex.size < 4) ex += "soru: eski=$oq yeni=$now" }
        val oi = OldNames.ipNames(msg, 12, msg.size)
        if (oi != now) { if (labels.any { l -> l.any { (it.toInt() and 0xFF) in 0xC0..0xDE && (it.toInt() and 0xFF) != 0xD7 } }) latin++ else { diffIp++; if (ex.size < 4) ex += "ip: eski=$oi yeni=$now" } }
    }
    T.check("geçerli (≤253) adlarda süzgeç okuması birebir aynı; >253 ($long254 ad) her yerde geçersiz", diffQ == 0, ex.joinToString(" | "))
    T.check("IP→ad belleği: tek fark Latin-1 büyük harfler ($latin ad) — artık süzgeçle aynı (eskiden farklı özet = ağ geçidinde kaçak)", diffIp == 0 && latin > 0, ex.joinToString(" | "))

    T.group("sizma35: DNS adı — sınırlar ve işaretçi kuralı")
    fun msgOf(vararg parts: ByteArray): ByteArray { val o = java.io.ByteArrayOutputStream(); o.write(ByteArray(12)); for (p in parts) o.write(p); return o.toByteArray() }
    val l63 = msgOf(enc(listOf(ByteArray(63) { 'a'.code.toByte() }, "com".toByteArray())))
    T.check("63 baytlık etiket geçerli", DnsName.string(l63, 0, 12, l63.size)?.length == 67)
    val l64 = msgOf(byteArrayOf(64) + ByteArray(64) { 'a'.code.toByte() } + byteArrayOf(0))
    T.check("64 (0x40 türü) etiket geçersiz", DnsName.string(l64, 0, 12, l64.size) == null)
    val t80 = msgOf(byteArrayOf(0x81.toByte(), 'a'.code.toByte(), 0))
    T.check("0x80 türü etiket geçersiz", DnsName.string(t80, 0, 12, t80.size) == null)
    fun nameOfLen(n: Int): ByteArray { val labs = ArrayList<ByteArray>(); var left = n; while (left > 0) { val k = minOf(63, left); labs.add(ByteArray(k) { 'x'.code.toByte() }); left -= k + 1 }; return enc(labs) }
    val ok253 = msgOf(nameOfLen(253)); val bad254 = msgOf(nameOfLen(255))
    T.check("253 karakterlik ad geçerli, daha uzunu geçersiz", (DnsName.string(ok253, 0, 12, ok253.size)?.length ?: 0) in 250..253 && DnsName.string(bad254, 0, 12, bad254.size) == null)
    // işaretçiler: geriye geçerli, ileri / kendine geçersiz
    val q = msgOf(enc(listOf("www".toByteArray(), "ornek".toByteArray(), "com".toByteArray())))
    val back = q + byteArrayOf(3, 'c'.code.toByte(), 'd'.code.toByte(), 'n'.code.toByte(), 0xC0.toByte(), 16)
    T.check("geriye işaretçi: cdn + ornek.com", DnsName.string(back, 0, q.size, back.size, compress = true) == "cdn.ornek.com")
    T.check("soru bölümünde işaretçi geçersiz", DnsName.string(back, 0, q.size, back.size, compress = false) == null)
    val self = q + byteArrayOf(0xC0.toByte(), q.size.toByte())
    T.check("kendine işaretçi (döngü) reddedilir", DnsName.string(self, 0, q.size, self.size, compress = true) == null)
    val fwd = q + byteArrayOf(0xC0.toByte(), (q.size + 2).toByte(), 1, 'x'.code.toByte(), 0)
    T.check("ileri işaretçi reddedilir (eski okuyucu kabul ediyordu)", DnsName.string(fwd, 0, q.size, fwd.size, compress = true) == null &&
        OldNames.wire(fwd, 0, q.size, fwd.size) == "x")
    // 17 halkalı geri zincir: 16 atlama sınırı
    val chain = java.io.ByteArrayOutputStream(); chain.write(ByteArray(12)); chain.write(byteArrayOf(1, 'a'.code.toByte(), 0))
    var prev = 12
    repeat(17) { val at = chain.size(); chain.write(byteArrayOf(1, 'b'.code.toByte(), 0xC0.toByte(), prev.toByte())); prev = at }
    val ch = chain.toByteArray()
    T.check("17 atlamalı zincir reddedilir (en çok 16)", DnsName.string(ch, 0, prev, ch.size, compress = true) == null)
    T.check("next(): sıkıştırmalı adın teldeki sonu ilk işaretçiden sonrası", DnsName.next(DnsName.read(back, 0, q.size, back.size, ByteArray(256), true)) == back.size)

    T.group("sizma35: bileşenler arası tutarlılık — aynı ad her yerde aynı özet")
    // Latin-1 büyük harfli (0xC9 'É') gizli izleyici: CNAME belleği ve süzgeç sorgusu aynı ada bakmalı
    FilterRuntime.source = null
    FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), listOf("izleyici.test"))
    CloakMemory.clear()
    val qn = listOf(byteArrayOf(0x4D, 0xC9.toByte(), 0x54), "site".toByteArray(), "example".toByteArray())   // "MÉT.site.example"
    val tgt = enc(listOf("t".toByteArray(), "izleyici".toByteArray(), "test".toByteArray()))
    val o = java.io.ByteArrayOutputStream()
    val hd = ByteArray(12); Packets.put16(hd, 0, 9); Packets.put16(hd, 2, 0x8180); Packets.put16(hd, 4, 1); Packets.put16(hd, 6, 2)
    o.write(hd); o.write(enc(qn)); o.write(byteArrayOf(0, 1, 0, 1)); o.write(byteArrayOf(0xC0.toByte(), 12, 0, 5, 0, 1, 0, 0, 0, 60, 0, tgt.size.toByte())); o.write(tgt)
    o.write(tgt); o.write(byteArrayOf(0, 1, 0, 1, 0, 0, 0, 60, 0, 4, 1, 2, 3, 4))                    // nihai A kaydı (yalnız CNAME'e dokunulmaz)
    val ans = o.toByteArray() + ByteArray(64)
    CnameGuard.guard(ans, 0, ans.size - 64)
    val query = ByteArray(12).also { Packets.put16(it, 4, 1) } + enc(qn) + byteArrayOf(0, 1, 0, 1)
    T.check("CNAME ile yakalanan Latin-1 harfli ad, aynı baytlı sorguda da engellenir (özet tutarlı)", FilterRuntime.engine!!.fork().verdict(query, 0, query.size) == FilterVerdict.LIST)
    // IP→ad belleği aynı küçültmeyle: ağ geçidi IP'den adı süzgece sorduğunda eşleşir
    IpNames.clear()
    val a1 = byteArrayOf(1, 2, 3, 4)
    val dnsAns = run {
        val oo = java.io.ByteArrayOutputStream(); val h2 = ByteArray(12); Packets.put16(h2, 2, 0x8180); Packets.put16(h2, 4, 1); Packets.put16(h2, 6, 1)
        oo.write(h2); oo.write(enc(listOf("ADS".toByteArray(), byteArrayOf(0xC9.toByte(), 0x58), "test".toByteArray()))); oo.write(byteArrayOf(0, 1, 0, 1))
        oo.write(byteArrayOf(0xC0.toByte(), 12, 0, 1, 0, 1, 0, 0, 0, 60, 0, 4)); oo.write(a1); oo.toByteArray()
    }
    val pk = ByteArray(28 + dnsAns.size); pk[0] = 0x45; pk[9] = 17; Packets.put16(pk, 20, 53); System.arraycopy(dnsAns, 0, pk, 28, dnsAns.size)
    IpNames.learn(pk, 0, pk.size)
    val names = IpNames.namesOf(a1)
    T.check("IP→ad belleği yalnız ASCII küçültür (\"ads.\\u00c9x.test\"), süzgeç özetiyle aynı", names.size == 1 && names[0] == "ads.Éx.test", names.toString())
    val gwEng = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("ads.Éx.test"))
    T.check("ağ geçidi IP'den adı süzgece sorunca engel tutar (eskiden 'é' ile farklı özet = kaçak)", IpNames.blocked(a1, gwEng) != null)

    T.group("sizma35: tek kaynak — ad okuma döngüsü başka yerde yeniden yazılmamış")
    val dir = java.io.File("app/src/main/java/app/dnshizli/core")
    val allowed = setOf("DnsName.kt", "Packets.kt", "Hpack.kt", "QuicInitial.kt", "QuicTls.kt", "QuicClient.kt")
    val dup = dir.listFiles().orEmpty().filter { it.extension == "kt" && it.name !in allowed }
        .filter { f -> Regex("""\+=\s*1\s*\+\s*l\b""").containsMatchIn(f.readText()) }.map { it.name }
    T.check("DNS ad döngüsü yalnızca DnsName (ve konum atlayan Packets) içinde", dup.isEmpty(), dup.joinToString())
}
