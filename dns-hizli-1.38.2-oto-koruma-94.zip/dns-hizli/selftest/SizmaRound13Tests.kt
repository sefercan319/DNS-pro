package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.ArrayDeque

/** sizma37: WireGuard tünel motoru (zamanlayıcılar, şifreli anahtar yönlendirmesi) ve tünel içi DNS köprüsü — süreç içi sahte sunucuyla. */
internal fun runRound13Tests() {
    tunnelTests()
    dnsBridgeTests()
}

private fun v4udp(src: ByteArray, dst: ByteArray, sport: Int, dport: Int, payload: ByteArray): ByteArray {
    val n = 28 + payload.size
    val b = ByteArray(n)
    b[0] = 0x45; Packets.put16(b, 2, n); b[8] = 64; b[9] = 17
    System.arraycopy(src, 0, b, 12, 4); System.arraycopy(dst, 0, b, 16, 4)
    Packets.put16(b, 20, sport); Packets.put16(b, 22, dport); Packets.put16(b, 24, 8 + payload.size)
    System.arraycopy(payload, 0, b, 28, payload.size)
    WgDnsForwarder.fixChecksums(b, n, false, 20)
    return b
}

/** Süreç içi WireGuard sunucusu: başlatmalara yanıt verir, gelen paketi işleyiciye verir, cevabı şifreleyip istemciye yollar. */
private class FakeServer(val priv: ByteArray, clientPub: ByteArray, val onPacket: (ByteArray) -> ByteArray?) {
    val res = WgResponder(priv).also { it.addPeer(WgResponder.Peer(clientPub)) }
    var session: WgSession? = null
    lateinit var deliver: (ByteArray) -> Unit
    var drop = false
    var inits = 0
    val received = ArrayList<ByteArray>()
    var clock: () -> Long = { 0L }
    fun onUdp(m: ByteArray) {
        if (drop) return
        when (m[0].toInt()) {
            Wg.TYPE_INITIATION -> { inits++; val i = res.consumeInitiation(m, 0, m.size) ?: return; val (r, s) = res.respond(i, 0x5A5A, clock())!!; session = s; deliver(r) }
            Wg.TYPE_DATA -> {
                val s = session ?: return
                val pt = s.decrypt(m, 0, m.size, clock()) ?: return
                if (pt.isEmpty()) return
                val n = WgTunnel.innerLength(pt) ?: return
                val p = pt.copyOf(n); received.add(p)
                val reply = onPacket(p) ?: return
                deliver(s.encrypt(reply, 0, reply.size, clock())!!)
            }
        }
    }
    fun push(p: ByteArray) { val s = session!!; deliver(s.encrypt(p, 0, p.size, clock())!!) }
}

private fun conf(priv: ByteArray, srvPub: ByteArray, extra: String = "", allowed: String = "0.0.0.0/0, ::/0", ka: Int = 0) = (WgConfig.parse("""
    [Interface]
    PrivateKey = ${java.util.Base64.getEncoder().encodeToString(priv)}
    Address = 10.66.0.2/32
    DNS = 10.64.0.1
    $extra
    [Peer]
    PublicKey = ${java.util.Base64.getEncoder().encodeToString(srvPub)}
    AllowedIPs = $allowed
    Endpoint = 203.0.113.9:51820
    PersistentKeepalive = $ka
""".trimIndent()) as WgConfig.Companion.Result.Ok).cfg

private val CLI = byteArrayOf(10, 66, 0, 2)

private fun tunnelTests() {
    T.group("sizma37: WireGuard tünel motoru — el sıkışma, sıra, yankı, zamanlayıcılar")
    val cPriv = Wg.generatePrivate(); val sPriv = Wg.generatePrivate()
    var t = 1_000_000L
    val tun = ArrayList<ByteArray>()
    val wire = ArrayDeque<ByteArray>()
    val srv = FakeServer(sPriv, Wg.publicKey(cPriv)) { p -> v4udp(p.copyOfRange(16, 20), p.copyOfRange(12, 16), Packets.u16(p, 22), Packets.u16(p, 20), p.copyOfRange(28, p.size)) }
    srv.clock = { t }
    lateinit var tunnel: WgTunnel
    tunnel = WgTunnel(conf(cPriv, Wg.publicKey(sPriv)), { wire.add(it) }, { b, o, l -> tun.add(b.copyOfRange(o, o + l)) }, { t })
    srv.deliver = { m -> tunnel.fromNet(m, 0, m.size) }
    fun pump() { while (wire.isNotEmpty()) srv.onUdp(wire.removeFirst()) }
    val p1 = v4udp(CLI, byteArrayOf(93, 184.toByte(), 216.toByte(), 34), 40000, 7, "merhaba".toByteArray())
    tunnel.fromTun(p1, p1.size)
    T.check("oturum yokken paket sıraya alınır, başlatma gider", wire.size == 1 && wire.peek()[0].toInt() == Wg.TYPE_INITIATION && tun.isEmpty())
    pump()
    T.check("el sıkışma tamam, sıradaki paket sunucuya ulaştı, yankı geri geldi", tunnel.connected && srv.received.any { it.contentEquals(p1) } &&
        tun.size == 1 && String(tun[0], 28, 7) == "merhaba" && tunnel.handshakes == 1L)
    // şifreli anahtar yönlendirmesi: AllowedIPs dışı kaynak
    val spoof = WgTunnel(conf(cPriv, Wg.publicKey(sPriv), allowed = "10.64.0.0/16"), { wire.add(it) }, { b, o, l -> tun.add(b.copyOfRange(o, o + l)) }, { t })
    T.check("AllowedIPs dışı hedefe paket gönderilmez", run { val q = v4udp(CLI, byteArrayOf(8, 8, 8, 8), 1, 2, ByteArray(4)); spoof.fromTun(q, q.size); wire.isEmpty() && spoof.dropped == 1L })
    // sunucudan kaynak adresi izin dışı paket
    val before = tun.size
    srv.push(v4udp(byteArrayOf(1, 2, 3, 4), CLI, 9, 9, ByteArray(3)))
    T.check("tam tünelde her kaynak serbest (0.0.0.0/0)", tun.size == before + 1)
    run {
        val tun2 = ArrayList<ByteArray>(); val w2 = ArrayDeque<ByteArray>()
        val srv2 = FakeServer(sPriv, Wg.publicKey(cPriv)) { null }; srv2.clock = { t }
        val tn = WgTunnel(conf(cPriv, Wg.publicKey(sPriv), allowed = "10.64.0.0/16"), { w2.add(it) }, { b, o, l -> tun2.add(b.copyOfRange(o, o + l)) }, { t })
        srv2.deliver = { m -> tn.fromNet(m, 0, m.size) }
        val q = v4udp(CLI, byteArrayOf(10, 64, 0, 1), 1, 2, ByteArray(4)); tn.fromTun(q, q.size)
        while (w2.isNotEmpty()) srv2.onUdp(w2.removeFirst())
        srv2.push(v4udp(byteArrayOf(8, 8, 8, 8), CLI, 53, 1, ByteArray(4)))
        T.check("bölünmüş tünel: eş izin verilmeyen adres (8.8.8.8) adına paket sokamaz", tun2.isEmpty() && tn.spoofed == 1L)
        srv2.push(v4udp(byteArrayOf(10, 64, 0, 9), CLI, 53, 1, ByteArray(4)))
        T.check("izinli kaynak (10.64.0.9) geçer", tun2.size == 1)
    }
    // zamanlayıcılar
    run {
        var tt = 0L; val w = ArrayDeque<ByteArray>()
        val dead = WgTunnel(conf(cPriv, Wg.publicKey(sPriv)), { w.add(it) }, { _, _, _ -> }, { tt })
        val q = v4udp(CLI, byteArrayOf(1, 1, 1, 1), 1, 2, ByteArray(4)); dead.fromTun(q, q.size)
        tt += 4_000; dead.tick(); val a = w.size
        tt += 2_000; dead.tick(); val b = w.size
        T.check("cevap yoksa başlatma 5 sn (+titreşim) sonra yinelenir", a == 1 && b == 2)
        repeat(100) { tt += 1_000; dead.tick() }
        val c = w.size
        repeat(30) { tt += 1_000; dead.tick() }
        T.check("90 sn sonra deneme bırakılır (pil ve ağ dövülmez; saniyelik tik ile 5-6 sn aralık)", c in 14..19 && w.size == c, "gönderim=$c/${w.size}")
    }
    run {
        // pasif canlı tutma, kalıcı canlı tutma, 120 sn yenileme, 540 sn anahtar silme
        val w = ArrayDeque<ByteArray>()
        val tn = WgTunnel(conf(cPriv, Wg.publicKey(sPriv), ka = 25), { w.add(it) }, { _, _, _ -> }, { t })
        srv.deliver = { m -> tn.fromNet(m, 0, m.size) }
        tn.tick()
        T.check("kalıcı canlı tutmalı eş trafik beklemeden bağlanır", w.size == 1 && w.peek()[0].toInt() == Wg.TYPE_INITIATION)
        while (w.isNotEmpty()) srv.onUdp(w.removeFirst())
        val sentAfterHs = srv.received.size
        T.check("bağlandı; anahtar onayı için boş veri gitti", tn.connected)
        t += 26_000; tn.tick()
        T.check("25 sn kalıcı canlı tutma gönderilir", w.isNotEmpty() && w.peek()[0].toInt() == Wg.TYPE_DATA)
        while (w.isNotEmpty()) srv.onUdp(w.removeFirst())
        srv.push(v4udp(byteArrayOf(1, 1, 1, 1), CLI, 53, 1, ByteArray(4)))
        t += 10_500; tn.tick()
        T.check("veri alınıp 10 sn bir şey gönderilmezse pasif canlı tutma", w.isNotEmpty())
        while (w.isNotEmpty()) srv.onUdp(w.removeFirst())
        val hs0 = tn.handshakes
        t += 121_000
        val q = v4udp(CLI, byteArrayOf(1, 1, 1, 1), 1, 2, ByteArray(4)); tn.fromTun(q, q.size)
        val hasInit = w.any { it[0].toInt() == Wg.TYPE_INITIATION }
        while (w.isNotEmpty()) srv.onUdp(w.removeFirst())
        T.check("120 sn sonra gönderimde anahtar yenilenir (eski oturum geçişte de çalışır)", hasInit && tn.handshakes == hs0 + 1 && tn.connected, "yeni=${tn.handshakes - hs0}")
        t += 541_000; tn.tick()
        T.check("540 sn hareketsizlikte anahtarlar silinir", !tn.connected)
        T.check("sunucuya giden paket sayısı mantıklı", srv.received.size >= sentAfterHs)
    }
    T.check("bozuk/kısa paketler motoru düşürmez", run { tunnel.fromNet(ByteArray(3), 0, 3); tunnel.fromNet(ByteArray(200) { 4 }, 0, 200); tunnel.fromTun(ByteArray(10), 10); true })
    T.check("iç paket uzunluğu dolgudan ayrılır; bozuk başlık reddedilir", WgTunnel.innerLength(ByteArray(32).also { it[0] = 0x45; Packets.put16(it, 2, 28) }) == 28 &&
        WgTunnel.innerLength(ByteArray(32).also { it[0] = 0x45; Packets.put16(it, 2, 40) }) == null && WgTunnel.innerLength(ByteArray(32).also { it[0] = 0x15 }) == null)
}

private fun dnsBridgeTests() {
    T.group("sizma37: WireGuard kipinde DNS — süzgeçten geçer, tünelin içinden gider, sahte adresle döner")
    val cPriv = Wg.generatePrivate(); val sPriv = Wg.generatePrivate()
    val fake4 = byteArrayOf(10, 111, 222.toByte(), 2)
    val tun = ArrayList<ByteArray>(); val wire = ArrayDeque<ByteArray>()
    val seenDst = ArrayList<String>()
    val srv = FakeServer(sPriv, Wg.publicKey(cPriv)) { p ->
        seenDst.add(Ip.format(p.copyOfRange(16, 20)))
        val q = p.copyOfRange(28, p.size)
        val a = q.copyOf(); Packets.put16(a, 2, 0x8180)
        v4udp(p.copyOfRange(16, 20), p.copyOfRange(12, 16), 53, Packets.u16(p, 20), a)
    }
    val tunnel = WgTunnel(conf(cPriv, Wg.publicKey(sPriv)), { wire.add(it) }, { b, o, l -> tun.add(b.copyOfRange(o, o + l)) })
    srv.deliver = { m -> tunnel.fromNet(m, 0, m.size) }
    val bridge = WgDnsForwarder(tunnel, { b, o, l -> tun.add(b.copyOfRange(o, o + l)) }, fake4, SelfTest.FAKE6)
    try {
        FilterRuntime.source = null
        FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), listOf("reklam.example"))
        val fw = FilteringForwarder(bridge) { b, o, l -> tun.add(b.copyOfRange(o, o + l)) }
        fun q(name: String, port: Int) = v4udp(CLI, fake4, port, 53, Dns.buildQuery(0x2222, name))
        val a = q("site.example", 41000); fw.onPacket(a, a.size)
        while (wire.isNotEmpty()) srv.onUdp(wire.removeFirst())
        val ans = tun.lastOrNull()
        T.check("temiz ad: sorgu tünelden yapılandırmanın DNS'ine (10.64.0.1) gider", seenDst == listOf("10.64.0.1"))
        T.check("cevap sahte DNS adresinden döner, port korunur, sağlama toplamları geçerli", ans != null && ans.copyOfRange(12, 16).contentEquals(fake4) && Packets.u16(ans, 22) == 41000 &&
            Packets.checksum(ans, 0, 20) == 0 && Packets.udpChecksumOk(ans, 20, ans.size - 20, Packets.i32(ans, 12), Packets.i32(ans, 16)))
        val n0 = tun.size
        val b = q("reklam.example", 41001); fw.onPacket(b, b.size)
        T.check("engelli ad tünele HİÇ gitmez, yerelde cevaplanır", seenDst.size == 1 && wire.isEmpty() && tun.size == n0 + 1)
        val l = v4udp(CLI, fake4, 41002, 53, Dns.buildQuery(0x3333, "7.1.168.192.in-addr.arpa")); fw.onPacket(l, l.size)
        T.check("ev ağı ters sorgusu da tünele gitmez (yerel bölge)", seenDst.size == 1 && wire.isEmpty())
        // istenmemiş DNS cevabı (bekleyen sorgu yok) tün'e sahte adresle yazılmaz
        val t0 = tun.size
        srv.push(v4udp(byteArrayOf(10, 64, 0, 1), CLI, 53, 45555, Dns.buildQuery(1, "x.example")))
        T.check("beklenmeyen DNS cevabı sahte adrese çevrilmez (olduğu gibi tüne gider)", tun.size == t0 + 1 && tun.last().copyOfRange(12, 16).contentEquals(byteArrayOf(10, 64, 0, 1)))
    } finally { Isolation.reset(); bridge.close() }
}
