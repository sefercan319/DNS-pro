package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.Section
import java.io.File

/** sizma55: DNS bölme — siteler 2–3 sağlayıcıya, her site hep aynı sağlayıcıya. */
internal fun runRound31Tests() {
    splitHash()
    splitPartners()
    splitForwarder()
    splitSettings()
    splitUi()
}

private fun q(name: String, id: Int = 0x1234, port: Int = 40500): ByteArray {
    val dns = Dns.buildQuery(id, name)
    val b = ByteArray(Packets.HDR + dns.size)
    System.arraycopy(dns, 0, b, Packets.HDR, dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size); Packets.put16(b, 6, 0x4000); b[8] = 64; b[9] = 17
    Packets.put32(b, 12, Packets.ip(10, 111, 222, 1)); Packets.put32(b, 16, Packets.ip(10, 111, 222, 2))
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, port); Packets.put16(b, 22, 53); Packets.put16(b, 24, 8 + dns.size)
    return b
}

private fun site(name: String): String { val b = name.toByteArray(); return String(b, SplitDns.siteStart(b, b.size), b.size - SplitDns.siteStart(b, b.size)) }

private fun splitHash() {
    T.group("sizma55: DNS bölme: site ve dağılım")
    T.check("site sınırı: son iki etiket; ülke kodlu ikinci düzeyde üç", site("a.b.example.com") == "example.com" && site("www.bbc.co.uk") == "bbc.co.uk" &&
        site("x.y.hepsiburada.com.tr") == "hepsiburada.com.tr" && site("example.com") == "example.com" && site("localhost") == "localhost" &&
        site("co.uk") == "co.uk" && site("foo.de") == "foo.de" && site("a.foo.io") == "foo.io")
    val salt = 0x5eed_1234_abcdL
    val n = 3
    T.check("aynı sitenin tüm alt adları aynı sağlayıcıya (büyük/küçük harf ve sondaki nokta fark etmez)",
        listOf("www.youtube.com", "i.ytimg.youtube.com", "YOUTUBE.com.", "m.youtube.com").map { SplitDns.indexOf(it, n, salt) }.toSet().size == 1)
    val sc = ByteArray(256)
    val p = q("Mail.Google.COM")
    T.check("paketten okunan ad metin yoluyla aynı sonucu verir", SplitDns.index(p, Packets.HDR, p.size - Packets.HDR, n, salt, sc) == SplitDns.indexOf("mail.google.com", n, salt))
    val counts = IntArray(n)
    for (i in 0 until 3000) counts[SplitDns.indexOf("site$i.example$i.com", n, salt)]++
    T.check("dağılım dengeli (3000 site, her sağlayıcı %28–39)", counts.all { it in 840..1170 }, counts.joinToString())
    val other = (0 until 300).count { SplitDns.indexOf("s$it.org", n, salt) != SplitDns.indexOf("s$it.org", n, salt + 1) }
    T.check("tuz değişince eşleme değişir (dışarıdan tahmin edilemez)", other > 150, other.toString())
    T.check("tek sağlayıcıda ve okunamayan adda 0", SplitDns.indexOf("x.com", 1, salt) == 0 && SplitDns.index(ByteArray(40), 28, 12, 3, salt, sc) == 0)
    val bad = q("a.example.com").also { it[Packets.HDR + 12] = 0xC0.toByte() }
    T.check("sıkıştırma işaretçili ad okunmaz (0)", SplitDns.readName(bad, Packets.HDR, bad.size - Packets.HDR, sc) == -1)
    T.check("tuz üretimi: 0 değil ve korunur", SplitDns.ensureSalt(0L) != 0L && SplitDns.ensureSalt(77L) == 77L)
}

private fun splitPartners() {
    T.group("sizma55: DNS bölme: ortak sağlayıcılar")
    val st = AppSettings()
    fun parts(primary: String, chosen: List<String> = emptyList(), s: AppSettings = st) =
        SplitDns.partners(Catalog.byId(primary)!!, s.plan(Catalog.byId(primary)!!).first { it != Proto.ODOH }, chosen, { Catalog.byId(it) }, { s.plan(it) })
    val a = parts("cloudflare")
    T.check("otomatik: 2 ortak, farklı markalar, ana sunucunun markası yok", a.size == 2 && a.none { it.first.brand == "Cloudflare" } && a.map { it.first.brand }.toSet().size == 2, a.map { it.first.id }.toString())
    T.check("şifreli kipte ortak da şifreli (düz DNS'e düşülmez)", a.all { it.second != Proto.PLAIN && it.second != Proto.ODOH })
    val fam = parts("cloudflare-family")
    T.check("aile sunucusunun ortakları da aile süzgeçli (bölme süzgeci delmez)", fam.isNotEmpty() && fam.all { it.first.variant == Variant.FAMILY }, fam.map { it.first.id }.toString())
    val sec = parts("cloudflare-security")
    T.check("güvenlik sunucusunun ortakları güvenlik süzgeçli", sec.all { it.first.variant == Variant.SECURITY || it.first.tags.contains(Tag.SECURITY) })
    val ch = parts("cloudflare", listOf("quad9", "cloudflare", "nextdns", "adguard"))
    T.check("seçilenler sırayla, ana sunucu atlanır, en çok 2", ch.map { it.first.id } == listOf("quad9", "nextdns"))
    val uncensored = parts("cloudflare", listOf("uncensored"), st.copy(encryption = Encryption.DOH))
    T.check("ortak ana yöntemi desteklemiyorsa kendi şifreli yöntemiyle; hiç yoksa atlanır", uncensored.isEmpty() || uncensored.all { it.second == Proto.DOT })
    val plain = parts("cloudflare", s = st.copy(encryption = Encryption.OFF))
    T.check("düz DNS seçiliyken ortaklar da düz olabilir", plain.isNotEmpty())
    T.check("kimlik listesi: biçim, tekrar, en çok 2", SplitDns.decode("quad9, quad9,kötü id,nextdns,adguard") == listOf("quad9", "nextdns") && SplitDns.encode(listOf("a", "b", "c")) == "a,b")
}

private class CountFw(override val proto: Proto = Proto.DOH) : Forwarder {
    var got = 0
    var timeouts = 0L
    var answered = 0L
    var resets = 0
    override fun start() {}
    override fun onPacket(p: ByteArray, len: Int) { got++ }
    override fun stats() = Stats(queries = got.toLong(), answered = answered, timeouts = timeouts, latencySumMs = answered * 10)
    override fun resetNetwork(reason: String) { resets++ }
    override fun clearCache() {}
    override fun close() {}
}

private fun splitForwarder() {
    T.group("sizma55: DNS bölme: yönlendirici")
    val parts = List(3) { CountFw() }
    var now = 1_000_000L
    val sf = SplitForwarder(parts, 42L) { now }
    val names = (0 until 60).map { "w$it.site$it.net" }
    val first = names.map { n -> val before = parts.map { it.got }; val pk = q(n); sf.onPacket(pk, pk.size); parts.indices.first { parts[it].got != before[it] } }
    val again = names.map { n -> val before = parts.map { it.got }; val pk = q("cdn." + n.substringAfter('.')); sf.onPacket(pk, pk.size); parts.indices.first { parts[it].got != before[it] } }
    T.check("her site her seferinde aynı sağlayıcıya (alt ad farklı olsa da)", first == again)
    T.check("üç sağlayıcı da kullanılıyor; paylar sayılıyor", parts.all { it.got > 0 } && sf.shares().sum() == 120L)
    T.check("eşleme yardımcı işlevle aynı", names.indices.all { first[it] == SplitDns.indexOf(names[it], 3, 42L) })
    // sağlık: 2. sağlayıcı zaman aşımına uğruyor, hiç cevap yok
    val victim = first[0]
    parts[victim].timeouts = 5
    now += 2_500
    val pk = q(names[0]); sf.onPacket(pk, pk.size)
    val gotNow = parts.map { it.got }
    sf.onPacket(pk, pk.size)
    T.check("yanıt vermeyen sağlayıcının sitesi geçici olarak sıradakine gider", parts[victim].got == gotNow[victim] && sf.down()[victim])
    now += SplitDns.DOWN_MS + 1
    parts[victim].answered = 3
    sf.onPacket(pk, pk.size)
    T.check("süre dolunca yeniden denenir", parts[victim].got == gotNow[victim] + 1 && !sf.down()[victim])
    parts[victim].timeouts = 20; now += 2_500; sf.onPacket(pk, pk.size)
    sf.resetNetwork("test")
    T.check("ağ değişince tüm sağlayıcılar sıfırlanır ve devre dışılar kalkar", parts.all { it.resets == 1 } && sf.down().none { it })
    val st = sf.stats()
    T.check("istatistik toplanır", st.queries == parts.sumOf { it.got }.toLong() && st.answered == 3L)
    val one = CountFw(); val single = SplitForwarder(listOf(one), 1L)
    val p2 = q("a.com"); single.onPacket(p2, p2.size)
    T.check("tek sağlayıcıda doğrudan geçer", one.got == 1)
    val lat = IntArray(4)
    T.check("süreler birleştirilir (desteklemeyende 0)", sf.latencies(lat) == 0)
}

private fun splitSettings() {
    T.group("sizma55: DNS bölme: ayarlar ve servis")
    val s = AppSettings(splitDns = true, splitWith = "quad9,nextdns", splitSalt = 99L)
    val back = SettingsCodec.decode(SettingsCodec.encode(s))
    T.check("ayar kaydı gidiş-dönüş", back.splitDns && back.splitWith == "quad9,nextdns" && back.splitSalt == 99L)
    T.check("gizli tuz dışa aktarılmaz (yerel)", "splitSalt" in SettingsCodec.LOCAL_KEYS && "splitDns" in ImportReview.REVIEWED && "splitWith" in ImportReview.REVIEWED)
    T.check("paylaşılan kod bölmeyi kapatır ya da ortakları değiştirirse uyarılır", SensitiveChange.PRIVACY in ImportReview.changes(s, s.copy(splitDns = false)) &&
        SensitiveChange.PRIVACY in ImportReview.changes(s, s.copy(splitWith = "adguard")))
    val r = Rig(Rig.base("aqua"))
    r.model.update { it.copy(splitDns = true) }
    T.check("bölme açılınca cihaza özgü tuz hemen üretilir", r.model.settings.splitSalt != 0L)
    val salt = r.model.settings.splitSalt
    r.model.update { it.copy(splitDns = false) }; r.model.update { it.copy(splitDns = true) }
    T.check("tuz kalıcı (kapatıp açınca aynı: siteler aynı sağlayıcıda kalır)", r.model.settings.splitSalt == salt)
    r.connectOk(); r.host.calls.clear()
    r.model.update { it.copy(splitDns = false) }
    T.check("bağlıyken açıp kapatmak ayarları yeniden uygular", "reapply" in r.host.calls)
    val svc = File("app/src/main/java/app/dnshizli/platform/DnsVpnService.kt").readText()
    T.check("servis: bölme ODoH dışında, süzgeç bölmenin üstünde", svc.contains("if (settings.splitDns && proto != Proto.ODOH)") && svc.contains("SplitForwarder(listOf(first) + parts") &&
        svc.contains("return FilteringForwarder(f, write)"))
    val bad = SplitText.M.filter { (_, v) -> v.size != Lang.values().size || v.any { it.isBlank() } }.keys
    T.check("metinler 12 dilde dolu", bad.isEmpty(), bad.toString())
}

private fun splitUi() {
    T.group("sizma55: DNS bölme: arayüz")
    val awt = AwtGfx(java.awt.image.BufferedImage(1, 1, java.awt.image.BufferedImage.TYPE_INT_ARGB).createGraphics())
    val r = Rig(Rig.base("aqua"), 360, 780, metrics = awt)
    r.scene.openSection(Section.DNS); r.settle(900)
    T.check("DNS sayfasında bölme anahtarı; kapalıyken ortak satırı yok", r.reveal(SplitText.t("title")) != null && r.find(SplitText.t("partners")) == null)
    r.tapText(SplitText.t("title"), settleMs = 900)
    T.check("açılınca ortak satırı ana + ortak adlarını gösterir", r.model.settings.splitDns && r.reveal(SplitText.t("partners")) != null &&
        (r.find(SplitText.t("partners"))?.info?.value ?: "").startsWith("Cloudflare + "))
    r.tapText(SplitText.t("partners"), settleMs = 900)
    run { val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/dns-bolme.png"); cv.dispose() }
    r.tapText("NextDNS", settleMs = 900)
    T.check("ortak seçilir", r.model.settings.splitWith == "nextdns")
    r.tapText("NextDNS", settleMs = 900)
    T.check("yeniden dokununca çıkar (otomatiğe döner)", r.model.settings.splitWith == "")
    T.check("ön izleme", File("build/onizleme/dns-bolme.png").isFile)
}
