package app.dnshizli.core

/**
 * Adres sınıflandırmanın TEK doğruluk kaynağı. Eskiden üç ayrı yerde (yeniden bağlama koruması, DPI yerel hedef, ağ geçidi yerel hedef)
 * ayrı ayrı ve birbirinden farklı yazılmıştı; NAT64 açığı (64:ff9b::192.168.1.1 yerel sayılmıyordu) tam olarak bu ayrışmadan çıktı.
 * Artık üç politika da buradaki bayraklardan türetilir; IPv6 içine gömülü IPv4 adresleri tek bir yerde ve TÜM biçimleriyle çözülür:
 *  - ::ffff:a.b.c.d (IPv4'e eşlenmiş, RFC 4291) ve ::ffff:0:a.b.c.d (SIIT çevrilmiş, RFC 2765)
 *  - ::a.b.c.d (eski "IPv4 uyumlu", RFC 4291 §2.5.5.1; :: ve ::1 hariç)
 *  - 64:ff9b::/96 (iyi bilinen NAT64 öneki) ve 64:ff9b:1::/48 (yerel kullanım öneki, RFC 8215; RFC 6052 /48 yerleşimi: u baytı atlanır)
 *  - Ağın kendi NAT64 öneki ([networkNat64], /96): operatörün DNS64'ü 192.168.1.1'i bu önekle sentezlerse de yerel sayılır.
 * Ayırma yapmaz (yalnız [embeddedV4] kopya döner).
 */
object AddrClass {
    const val UNSPEC = 1            // 0.0.0.0, ::
    const val LOOPBACK = 2          // 127/8, ::1
    const val PRIVATE = 4           // 10/8, 172.16/12, 192.168/16, fc00::/7 (ULA)
    const val LINK_LOCAL = 8        // 169.254/16, fe80::/10
    const val CGNAT = 16            // 100.64/10 (operatör NAT'ı, RFC 6598)
    const val MULTICAST = 32        // 224/4, ff00::/8
    const val BROADCAST = 64        // 255.255.255.255
    const val RESERVED = 128        // 240/4 (yayın hariç)
    const val THIS_NET = 256        // 0/8 içinde 0.0.0.0 dışı ("bu ağ", RFC 1122)
    const val SITE_LOCAL = 512      // fec0::/10 (kullanımdan kalktı ama yığınlar hâlâ yerel sayar)
    const val SPECIAL = 1024        // genel olmayan özel amaçlı: 192.0.0/24, belgeleme (192.0.2/24, 198.51.100/24, 203.0.113/24, 2001:db8::/32), 198.18/15

    /** DNS yeniden bağlama koruması: genel bir adın bu adreslere çözülmesi engellenir. CGNAT bilerek yok (operatör hizmetleri). */
    const val REBIND = LOOPBACK or PRIVATE or LINK_LOCAL or THIS_NET or SITE_LOCAL

    /** Yerel hedef: DPI bölmesi ve ağ geçidi işlemleri uygulanmaz (modem, NAS, yerel servis, yayın, ayrılmış). */
    const val LOCAL = REBIND or UNSPEC or CGNAT or MULTICAST or BROADCAST or RESERVED

    /** Herkese açık tek noktaya yayın OLMAYAN her şey (ilk çözümleme/bootstrap cevabı bunlara yönlenemez). */
    const val NOT_GLOBAL = LOCAL or SPECIAL

    /** Ağın kendi NAT64 öneki (12 bayt, /96); ağ geçidi öğrenince yazar ([GwConfig.nat64]). null = bilinmiyor. */
    @Volatile var networkNat64: ByteArray? = null

    /** IPv4 ([b]'de [o]'dan 4 bayt) bayrakları. */
    fun v4(b: ByteArray, o: Int = 0): Int {
        val a = b[o].toInt() and 0xFF
        val c = b[o + 1].toInt() and 0xFF
        return when {
            a == 0 -> if ((b[o + 1].toInt() or b[o + 2].toInt() or b[o + 3].toInt()) == 0) UNSPEC else THIS_NET
            a == 10 -> PRIVATE
            a == 127 -> LOOPBACK
            a == 172 && c in 16..31 -> PRIVATE
            a == 192 && c == 168 -> PRIVATE
            a == 169 && c == 254 -> LINK_LOCAL
            a == 100 && c in 64..127 -> CGNAT
            a == 192 && c == 0 && ((b[o + 2].toInt() and 0xFF) == 0 || (b[o + 2].toInt() and 0xFF) == 2) -> SPECIAL
            a == 198 && (c == 18 || c == 19) -> SPECIAL
            a == 198 && c == 51 && (b[o + 2].toInt() and 0xFF) == 100 -> SPECIAL
            a == 203 && c == 0 && (b[o + 2].toInt() and 0xFF) == 113 -> SPECIAL
            a in 224..239 -> MULTICAST
            a == 255 && c == 255 && (b[o + 2].toInt() and 0xFF) == 255 && (b[o + 3].toInt() and 0xFF) == 255 -> BROADCAST
            a >= 240 -> RESERVED
            else -> 0
        }
    }

    /** IPv6 ([b]'de [o]'dan 16 bayt) bayrakları: kendi sınıfı + varsa gömülü IPv4'ün bayrakları. */
    fun v6(b: ByteArray, o: Int = 0): Int {
        val h = b[o].toInt() and 0xFF
        val g = b[o + 1].toInt() and 0xFF
        var f = 0
        if ((h and 0xFE) == 0xFC) f = f or PRIVATE
        else if (h == 0xFE && (g and 0xC0) == 0x80) f = f or LINK_LOCAL
        else if (h == 0xFE && (g and 0xC0) == 0xC0) f = f or SITE_LOCAL
        else if (h == 0xFF) f = f or MULTICAST
        else if (h == 0x20 && g == 0x01 && b[o + 2].toInt() == 0x0D && (b[o + 3].toInt() and 0xFF) == 0xB8) f = f or SPECIAL      // belgeleme
        else if (h == 0x20 && g == 0x01 && b[o + 2].toInt() == 0 && b[o + 3].toInt() == 0) f = f or SPECIAL                     // Teredo 2001::/32
        else if (h == 0x20 && g == 0x02) f = f or SPECIAL                                                                         // 6to4 2002::/16
        else if (h == 0x3F && g == 0xFF && (b[o + 2].toInt() and 0xF0) == 0) f = f or SPECIAL                                    // belgeleme 3fff::/20
        else {
            var zero15 = true
            for (k in 0 until 15) if (b[o + k].toInt() != 0) { zero15 = false; break }
            if (zero15) {
                val last = b[o + 15].toInt() and 0xFF
                if (last == 0) return UNSPEC
                if (last == 1) return LOOPBACK
            }
        }
        val e = embeddedAt(b, o)
        if (e != NONE) f = f or v4(scratchV4(b, o, e), 0)
        return f
    }

    /** Uzunluğa göre (4 ya da 16 bayt) bayraklar; başka uzunlukta 0. */
    fun of(a: ByteArray): Int = when (a.size) { 4 -> v4(a, 0); 16 -> v6(a, 0); else -> 0 }

    fun isRebindTarget(a: ByteArray): Boolean = of(a) and REBIND != 0
    fun isLocal(a: ByteArray): Boolean = of(a) and LOCAL != 0
    /** Herkese açık tek noktaya yayın: IPv4'te özel/ayrılmış olmayan; IPv6'da 2000::/3 içinde ve özel amaçlı olmayan (Teredo, 6to4, belgeleme hariç). */
    fun isGlobal(a: ByteArray): Boolean = when (a.size) {
        4 -> v4(a, 0) and NOT_GLOBAL == 0
        16 -> (a[0].toInt() and 0xE0) == 0x20 && v6(a, 0) and NOT_GLOBAL == 0
        else -> false
    }

    /** IPv6 adresine gömülü IPv4 (yeni dizi), yoksa null. */
    fun embeddedV4(a: ByteArray, o: Int = 0): ByteArray? {
        if (a.size < o + 16) return null
        val e = embeddedAt(a, o)
        return if (e == NONE) null else scratchV4(a, o, e).copyOf()
    }

    // ---- gömülü IPv4 yerleşimleri
    private const val NONE = 0
    private const val TAIL = 1         // son 4 bayt
    private const val RFC6052_48 = 2   // /48 önek: baytlar 6,7,9,10 (8 = u baytı)

    private fun embeddedAt(b: ByteArray, o: Int): Int {
        // ::ffff:a.b.c.d ve ::a.b.c.d ve ::ffff:0:a.b.c.d
        var z8 = true
        for (k in 0 until 8) if (b[o + k].toInt() != 0) { z8 = false; break }
        if (z8) {
            val w4 = Packets.u16(b, o + 8); val w5 = Packets.u16(b, o + 10)
            if (w4 == 0 && w5 == 0xFFFF) return TAIL                           // eşlenmiş
            if (w4 == 0xFFFF && w5 == 0) return TAIL                           // SIIT çevrilmiş
            if (w4 == 0 && w5 == 0) {                                          // IPv4 uyumlu (:: ve ::1 hariç)
                val v = (b[o + 12].toInt() or b[o + 13].toInt() or b[o + 14].toInt())
                return if (v == 0 && (b[o + 15].toInt() and 0xFF) <= 1) NONE else TAIL
            }
        }
        // 64:ff9b::/96 ve 64:ff9b:1::/48
        if (b[o].toInt() == 0x00 && b[o + 1].toInt() == 0x64 && (b[o + 2].toInt() and 0xFF) == 0xFF && (b[o + 3].toInt() and 0xFF) == 0x9B) {
            var z = true
            for (k in 4 until 12) if (b[o + k].toInt() != 0) { z = false; break }
            if (z) return TAIL
            if (b[o + 4].toInt() == 0x00 && b[o + 5].toInt() == 0x01 && b[o + 8].toInt() == 0) {
                for (k in 11 until 16) if (b[o + k].toInt() != 0) return NONE
                return RFC6052_48
            }
        }
        // ağın kendi NAT64 öneki (/96)
        val p = networkNat64
        if (p != null && p.size == 12) {
            var eq = true
            for (k in 0 until 12) if (b[o + k] != p[k]) { eq = false; break }
            if (eq) return TAIL
        }
        return NONE
    }

    private val scratch = ThreadLocal.withInitial { ByteArray(4) }
    private fun scratchV4(b: ByteArray, o: Int, e: Int): ByteArray {
        val s = scratch.get()
        if (e == TAIL) { s[0] = b[o + 12]; s[1] = b[o + 13]; s[2] = b[o + 14]; s[3] = b[o + 15] }
        else { s[0] = b[o + 6]; s[1] = b[o + 7]; s[2] = b[o + 9]; s[3] = b[o + 10] }
        return s
    }
}
