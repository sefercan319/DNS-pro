package app.dnshizli.core

import kotlin.math.abs

/**
 * Sunucu küresinin görünümü: renkler temadan, ışık ve doku stilden türetilir; böylece her tema × stil bileşiminde küre kendiliğinden uyar.
 *  - Okyanus tonu temanın derin vurgusundan maviye çekilir; kara noktaları açık, tema tonunda; komşu ülkeler 4 farklı tonda ([land]).
 *  - Kıyı noktaları ([coast]) temanın parıltı renginde parlar, sınır noktaları ([border]) ve sınır çizgileri ülkeleri ayırır.
 *  - Işık (sol üst önden): [shade] gece yüzü kararması, [specular] parlama, [rim] kenar ışıması, [atmosphere] dış hale.
 *  - Stil dokusu: Metro düz (gradyansız, kare nokta), Y2K kare piksel ve ızgara, Liquid cam parlaması, Duru sade, Aurora güçlü hale.
 * Saf hesap: arayüzden bağımsız sınanır (her bileşimde kara/okyanus kontrastı).
 */
class GlobeLook(
    val oceanLit: Int,
    val oceanDeep: Int,
    val land: IntArray,
    val coast: Int,
    val border: Int,
    val borderLine: Int,
    val borderLineWidth: Float,
    val grid: Int,
    val atmosphere: Int,
    val atmosphereInner: Int,
    val shade: Float,
    val specular: Float,
    val rim: Float,
    val square: Boolean,
    val dot: Float,
    val flat: Boolean,
    /** Kıyı/sınır nokta zincirlerinin saydamlığı. */
    val chainAlpha: Float,
    /** Gündüz/gece sınırındaki ılık alacakaranlık şeridinin gücü. */
    val dusk: Float,
) {
    /** Ülke dolguları (vektör çokgenler): kara tonlarının okyanusa doğru koyulaşmış hali; yarım ton noktaları üstünde parlar. */
    val fill: IntArray = IntArray(4) { Rgb.lerp(oceanDeep, land[it], if (flat) 0.78f else 0.66f) }
    /** Yarım ton noktalarının rengi (kara üstünde). */
    val halftone: Int = Rgb.alpha(Rgb.lerp(land[0], Rgb.WHITE, 0.6f), if (flat) 0.6f else 0.55f)
    companion object {
        private val cache = HashMap<Long, GlobeLook>()

        @Synchronized
        fun of(theme: AeroTheme, style: UiStyle): GlobeLook {
            val key = (theme.accentDeep.toLong() shl 32) xor (theme.glow.toLong() * 31 + theme.accentLight) xor (style.ordinal.toLong() shl 58) xor (if (theme.dark) 1L shl 63 else 0L)
            return cache.getOrPut(key) { build(theme, style) }
        }

        /** [a]'dan [b]'ye en kısa ton farkı (-180..180). */
        private fun hueDiff(a: Float, b: Float): Float { var d = (b - a) % 360f; if (d > 180f) d -= 360f; if (d < -180f) d += 360f; return d }

        private fun mixHue(a: Float, b: Float, t: Float): Float {
            var d = (b - a) % 360f
            if (d > 180f) d -= 360f
            if (d < -180f) d += 360f
            return (a + d * t + 360f) % 360f
        }

        private fun build(t: AeroTheme, style: UiStyle): GlobeLook {
            val deep = Rgb.toHsl(t.accentDeep)
            val light = Rgb.toHsl(t.accentLight)
            val glow = Rgb.toHsl(t.glow)
            val grey = deep[1] < 0.12f
            // Okyanus: tema tonunu korur ama maviye yaklaşır (turuncu temada bile "deniz" okunur).
            // Deniz hep "deniz" okunsun: ton maviden en çok ±22° (ECO turkuaza) sapar; turuncu/pembe temada mora kaymaz.
            val center = if (style == UiStyle.ECO) 188f else 214f
            val oh = if (grey) 215f else center + hueDiff(center, deep[0]).coerceIn(-40f, 40f) * 0.55f
            val os = if (grey) 0.18f else 0.62f
            val dark = t.dark
            val oceanDeep = Rgb.fromHsl(oh, os, if (dark) 0.075f else 0.13f)
            val oceanLit = Rgb.fromHsl(oh, os * 0.95f, if (dark) 0.23f else 0.31f)
            // Kara: açık, tema tonunda; ECO yeşile, diğerleri temanın açık vurgusuna yaslanır.
            val lh = when { style == UiStyle.ECO -> mixHue(light[0], 105f, 0.6f); grey -> 210f; else -> light[0] }
            val ls = when (style) { UiStyle.METRO -> 0.62f; UiStyle.DURU -> 0.32f; UiStyle.Y2K -> 0.58f; else -> 0.5f }
            // Komşu ülkeler: ton, açıklık ve doygunlukta birlikte ayrışır (uzaktan da seçilsin).
            val hues = floatArrayOf(0f, 46f, -40f, 92f)
            val lights = floatArrayOf(0.93f, 0.74f, 0.85f, 0.66f)
            val sats = floatArrayOf(0.75f, 1.25f, 1.05f, 1.4f)
            var hf = if (style == UiStyle.DURU) 0.7f else 1f
            fun tone(k: Int, lo: Float): Int {
                // en koyu ton [lo]; aralık üstte 0.95'e sıkışır, sıralama korunur
                val l = lo + (lights[k] - 0.66f) / (0.93f - 0.66f) * (0.95f - lo)
                return Rgb.fromHsl(lh + hues[k] * hf, (ls * sats[k]).coerceAtMost(0.9f), l)
            }
            // her temada okyanusa karşı en az 3.2:1: gerekirse tüm tonlar birlikte açılır (ayrım korunur)
            fun dist(a: Int, b: Int) = abs(Rgb.r(a) - Rgb.r(b)) + abs(Rgb.g(a) - Rgb.g(b)) + abs(Rgb.b(a) - Rgb.b(b))
            var land: IntArray
            var tries = 0
            while (true) {
                // her temada okyanusa karşı en az 3.2:1: gerekirse tüm tonlar birlikte açılır (sıralama korunur)
                var lo = 0.66f
                while (lo < 0.88f && (0 until 4).any { Rgb.contrast(tone(it, lo), oceanLit) < 3.2 }) lo += 0.01f
                land = IntArray(4) { tone(it, lo) }
                // açık okyanusta tonlar üste sıkışırsa ayrımı ton farkını büyüterek geri kazan
                val close = (0 until 4).any { i -> (i + 1 until 4).any { j -> dist(land[i], land[j]) < 30 } }
                if (!close || tries++ >= 6) break
                hf *= 1.25f
            }
            val gh = if (Rgb.toHsl(t.glow)[1] < 0.12f) lh else glow[0]
            var cl = 0.78f
            var coast = Rgb.fromHsl(gh, if (style == UiStyle.DURU) 0.45f else 0.9f, cl)
            while (Rgb.contrast(coast, oceanLit) < 3.2 && cl < 0.97f) { cl += 0.02f; coast = Rgb.fromHsl(gh, if (style == UiStyle.DURU) 0.45f else 0.9f, cl) }
            val border = Rgb.fromHsl(gh, 0.4f, 0.97f)
            val lineA = when (style) { UiStyle.METRO -> 0.95f; UiStyle.DURU -> 0.45f; UiStyle.Y2K -> 0.85f; else -> 0.75f }
            val borderLine = Rgb.alpha(Rgb.fromHsl(gh, 0.55f, 0.93f), lineA)
            val gridA = when (style) { UiStyle.Y2K -> 0.20f; UiStyle.METRO -> 0.10f; UiStyle.AQUA, UiStyle.AERO -> 0.07f; UiStyle.AURORA -> 0.06f; else -> 0f }
            val grid = Rgb.alpha(Rgb.fromHsl(gh, 0.5f, 0.85f), gridA)
            val atmA = when (style) { UiStyle.AURORA -> 0.75f; UiStyle.METRO -> 0f; UiStyle.DURU -> 0.25f; UiStyle.LIQUID -> 0.5f; else -> 0.45f }
            val atmosphere = Rgb.alpha(t.glow, atmA)
            val atmosphereInner = if (style == UiStyle.AURORA) Rgb.alpha(t.accent, atmA) else atmosphere
            val shade = when (style) { UiStyle.METRO -> 0f; UiStyle.DURU -> 0.25f; UiStyle.AURORA -> 0.6f; else -> 0.45f }
            val spec = when (style) { UiStyle.METRO -> 0f; UiStyle.DURU -> 0.15f; UiStyle.LIQUID -> 0.8f; UiStyle.Y2K -> 0.9f; UiStyle.ECO -> 0.3f; UiStyle.AURORA -> 0.35f; else -> 0.55f }
            val rim = when (style) { UiStyle.METRO -> 0f; UiStyle.DURU -> 0.2f; UiStyle.LIQUID -> 0.75f; UiStyle.AURORA -> 0.6f; else -> 0.45f }
            val square = style == UiStyle.METRO || style == UiStyle.Y2K
            val dot = when (style) { UiStyle.DURU -> 0.34f; UiStyle.METRO -> 0.36f; UiStyle.Y2K -> 0.38f; else -> 0.40f }
            return GlobeLook(oceanLit, oceanDeep, land, coast, border, borderLine, if (style == UiStyle.METRO) 1.4f else 1.1f, grid,
                atmosphere, atmosphereInner, shade, spec, rim, square, dot, style == UiStyle.METRO,
                chainAlpha = when (style) { UiStyle.METRO -> 1f; UiStyle.DURU -> 0.7f; else -> 0.95f },
                dusk = when (style) { UiStyle.METRO -> 0f; UiStyle.DURU -> 0.06f; UiStyle.AURORA -> 0.2f; else -> 0.14f })
        }
    }
}
