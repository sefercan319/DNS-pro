package app.dnshizli.core

/**
 * WireGuard'ın kriptografik yapı taşları, dış kütüphanesiz (JVM ve Android'de birebir aynı davranış):
 *  - BLAKE2s (RFC 7693): özet, anahtarlı özet (MAC), HMAC-BLAKE2s ve WireGuard KDF'leri
 *  - ChaCha20-Poly1305 (RFC 8439) ve XChaCha20-Poly1305 (HChaCha20 ile; çerez cevabı için)
 * Doğrulama: RFC test vektörleri ve JDK/Python kaynaklarıyla çapraz sınama (selftest sizma36).
 */
object Blake2s {
    private val IV = intArrayOf(
        0x6A09E667, -0x4498517b, 0x3C6EF372, -0x5ab00ac6, 0x510E527F, -0x64fa9774, 0x1F83D9AB, 0x5BE0CD19,
    )
    private val SIGMA = arrayOf(
        intArrayOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15), intArrayOf(14, 10, 4, 8, 9, 15, 13, 6, 1, 12, 0, 2, 11, 7, 5, 3),
        intArrayOf(11, 8, 12, 0, 5, 2, 15, 13, 10, 14, 3, 6, 7, 1, 9, 4), intArrayOf(7, 9, 3, 1, 13, 12, 11, 14, 2, 6, 5, 10, 4, 0, 15, 8),
        intArrayOf(9, 0, 5, 7, 2, 4, 10, 15, 14, 1, 11, 12, 6, 8, 3, 13), intArrayOf(2, 12, 6, 10, 0, 11, 8, 3, 4, 13, 7, 5, 15, 14, 1, 9),
        intArrayOf(12, 5, 1, 15, 14, 13, 4, 10, 0, 7, 6, 3, 9, 2, 8, 11), intArrayOf(13, 11, 7, 14, 12, 1, 3, 9, 5, 0, 15, 4, 8, 6, 2, 10),
        intArrayOf(6, 15, 14, 9, 11, 3, 0, 8, 12, 2, 13, 7, 1, 4, 10, 5), intArrayOf(10, 2, 8, 4, 7, 6, 1, 5, 15, 11, 9, 14, 3, 12, 13, 0),
    )

    /** Artımlı BLAKE2s durumu (en çok 32 bayt çıktı, en çok 32 bayt anahtar). */
    class State(private val outLen: Int, key: ByteArray? = null) {
        private val h = IV.copyOf()
        private val buf = ByteArray(64)
        private var bufLen = 0
        private var t = 0L
        private val m = IntArray(16)
        private val v = IntArray(16)

        init {
            require(outLen in 1..32)
            val kl = key?.size ?: 0
            require(kl <= 32)
            h[0] = h[0] xor (0x01010000 or (kl shl 8) or outLen)
            if (kl > 0) { System.arraycopy(key!!, 0, buf, 0, kl); bufLen = 64 }
        }

        fun update(b: ByteArray, off: Int = 0, len: Int = b.size): State {
            var o = off; var l = len
            while (l > 0) {
                if (bufLen == 64) { t += 64; compress(false); bufLen = 0 }
                val take = minOf(64 - bufLen, l)
                System.arraycopy(b, o, buf, bufLen, take)
                bufLen += take; o += take; l -= take
            }
            return this
        }

        fun digest(): ByteArray {
            t += bufLen
            for (i in bufLen until 64) buf[i] = 0
            compress(true)
            val out = ByteArray(outLen)
            for (i in 0 until outLen) out[i] = (h[i ushr 2] ushr (8 * (i and 3))).toByte()
            return out
        }

        private fun compress(last: Boolean) {
            for (i in 0 until 16) m[i] = (buf[i * 4].toInt() and 0xFF) or ((buf[i * 4 + 1].toInt() and 0xFF) shl 8) or
                ((buf[i * 4 + 2].toInt() and 0xFF) shl 16) or ((buf[i * 4 + 3].toInt() and 0xFF) shl 24)
            for (i in 0 until 8) { v[i] = h[i]; v[i + 8] = IV[i] }
            v[12] = v[12] xor t.toInt()
            v[13] = v[13] xor (t ushr 32).toInt()
            if (last) v[14] = v[14].inv()
            for (r in 0 until 10) {
                val s = SIGMA[r]
                g(0, 4, 8, 12, m[s[0]], m[s[1]]); g(1, 5, 9, 13, m[s[2]], m[s[3]])
                g(2, 6, 10, 14, m[s[4]], m[s[5]]); g(3, 7, 11, 15, m[s[6]], m[s[7]])
                g(0, 5, 10, 15, m[s[8]], m[s[9]]); g(1, 6, 11, 12, m[s[10]], m[s[11]])
                g(2, 7, 8, 13, m[s[12]], m[s[13]]); g(3, 4, 9, 14, m[s[14]], m[s[15]])
            }
            for (i in 0 until 8) h[i] = h[i] xor v[i] xor v[i + 8]
        }

        private fun g(a: Int, b: Int, c: Int, d: Int, x: Int, y: Int) {
            v[a] = v[a] + v[b] + x; v[d] = Integer.rotateRight(v[d] xor v[a], 16)
            v[c] = v[c] + v[d]; v[b] = Integer.rotateRight(v[b] xor v[c], 12)
            v[a] = v[a] + v[b] + y; v[d] = Integer.rotateRight(v[d] xor v[a], 8)
            v[c] = v[c] + v[d]; v[b] = Integer.rotateRight(v[b] xor v[c], 7)
        }
    }

    fun hash(vararg parts: ByteArray): ByteArray { val s = State(32); for (p in parts) s.update(p); return s.digest() }
    fun mac(key: ByteArray, vararg parts: ByteArray, outLen: Int = 16): ByteArray { val s = State(outLen, key); for (p in parts) s.update(p); return s.digest() }

    /** HMAC-BLAKE2s (blok 64 bayt), WireGuard KDF'lerinin temeli. */
    fun hmac(key: ByteArray, data: ByteArray): ByteArray {
        val k = if (key.size > 64) hash(key) else key
        val ipad = ByteArray(64) { i -> ((if (i < k.size) k[i].toInt() else 0) xor 0x36).toByte() }
        val opad = ByteArray(64) { i -> ((if (i < k.size) k[i].toInt() else 0) xor 0x5c).toByte() }
        return hash(opad, hash(ipad, data))
    }

    /** WireGuard KDF_n (HKDF benzeri, HMAC-BLAKE2s): n = 1..3 çıktı. */
    fun kdf(key: ByteArray, input: ByteArray, n: Int): Array<ByteArray> {
        val t0 = hmac(key, input)
        val out = ArrayList<ByteArray>(n)
        var prev = ByteArray(0)
        for (i in 1..n) { prev = hmac(t0, prev + byteArrayOf(i.toByte())); out.add(prev) }
        t0.fill(0)
        return out.toTypedArray()
    }
}

/** ChaCha20-Poly1305 AEAD (RFC 8439) ve XChaCha20-Poly1305. Anahtar 32 bayt; nonce 12 (X: 24) bayt. Etiket 16 bayt. */
object ChaChaPoly {
    private fun quarter(s: IntArray, a: Int, b: Int, c: Int, d: Int) {
        s[a] += s[b]; s[d] = Integer.rotateLeft(s[d] xor s[a], 16)
        s[c] += s[d]; s[b] = Integer.rotateLeft(s[b] xor s[c], 12)
        s[a] += s[b]; s[d] = Integer.rotateLeft(s[d] xor s[a], 8)
        s[c] += s[d]; s[b] = Integer.rotateLeft(s[b] xor s[c], 7)
    }
    private fun le32(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)
    private fun put32(b: ByteArray, o: Int, v: Int) { b[o] = v.toByte(); b[o + 1] = (v ushr 8).toByte(); b[o + 2] = (v ushr 16).toByte(); b[o + 3] = (v ushr 24).toByte() }

    private fun rounds(s: IntArray) {
        repeat(10) {
            quarter(s, 0, 4, 8, 12); quarter(s, 1, 5, 9, 13); quarter(s, 2, 6, 10, 14); quarter(s, 3, 7, 11, 15)
            quarter(s, 0, 5, 10, 15); quarter(s, 1, 6, 11, 12); quarter(s, 2, 7, 8, 13); quarter(s, 3, 4, 9, 14)
        }
    }

    private fun init(key: ByteArray, counter: Int, nonce12: ByteArray): IntArray {
        val s = IntArray(16)
        s[0] = 0x61707865; s[1] = 0x3320646e; s[2] = 0x79622d32; s[3] = 0x6b206574
        for (i in 0 until 8) s[4 + i] = le32(key, i * 4)
        s[12] = counter
        for (i in 0 until 3) s[13 + i] = le32(nonce12, i * 4)
        return s
    }

    /** ChaCha20 akış şifresi: [data][off, off+len) yerinde XOR'lanır (sayaç [counter]'dan başlar). */
    fun xor(key: ByteArray, nonce12: ByteArray, counter: Int, data: ByteArray, off: Int, len: Int) {
        val base = init(key, counter, nonce12)
        val x = IntArray(16)
        val ks = ByteArray(64)
        var p = off; var left = len; var ctr = counter
        while (left > 0) {
            base[12] = ctr
            System.arraycopy(base, 0, x, 0, 16)
            rounds(x)
            for (i in 0 until 16) put32(ks, i * 4, x[i] + base[i])
            val n = minOf(64, left)
            for (i in 0 until n) data[p + i] = (data[p + i].toInt() xor ks[i].toInt()).toByte()
            p += n; left -= n; ctr++
        }
    }

    /** HChaCha20: 32 bayt anahtar + 16 bayt nonce → 32 bayt alt anahtar (XChaCha20 için). */
    fun hchacha(key: ByteArray, nonce16: ByteArray): ByteArray {
        val s = IntArray(16)
        s[0] = 0x61707865; s[1] = 0x3320646e; s[2] = 0x79622d32; s[3] = 0x6b206574
        for (i in 0 until 8) s[4 + i] = le32(key, i * 4)
        for (i in 0 until 4) s[12 + i] = le32(nonce16, i * 4)
        rounds(s)
        val out = ByteArray(32)
        for (i in 0 until 4) put32(out, i * 4, s[i])
        for (i in 0 until 4) put32(out, 16 + i * 4, s[12 + i])
        return out
    }

    // ---- Poly1305 (26 bit sınırlı, 5 parça)
    private fun poly1305(key32: ByteArray, aad: ByteArray, ct: ByteArray, ctOff: Int, ctLen: Int): ByteArray {
        val r0 = le32(key32, 0) and 0x3ffffff
        val r1 = (le32(key32, 3) ushr 2) and 0x3ffff03
        val r2 = (le32(key32, 6) ushr 4) and 0x3ffc0ff
        val r3 = (le32(key32, 9) ushr 6) and 0x3f03fff
        val r4 = (le32(key32, 12) ushr 8) and 0x00fffff
        val s1 = r1 * 5L; val s2 = r2 * 5L; val s3 = r3 * 5L; val s4 = r4 * 5L
        var h0 = 0L; var h1 = 0L; var h2 = 0L; var h3 = 0L; var h4 = 0L
        val blk = ByteArray(17)
        fun block(src: ByteArray, o: Int, n: Int, full: Boolean) {
            for (i in 0 until 16) blk[i] = if (i < n) src[o + i] else 0
            if (!full) blk[n] = 1
            val hi = if (full) (1 shl 24) else 0
            h0 += (le32(blk, 0) and 0x3ffffff).toLong()
            h1 += ((le32(blk, 3) ushr 2) and 0x3ffffff).toLong()
            h2 += ((le32(blk, 6) ushr 4) and 0x3ffffff).toLong()
            h3 += ((le32(blk, 9) ushr 6) and 0x3ffffff).toLong()
            h4 += ((le32(blk, 12) ushr 8) or hi).toLong() and 0xFFFFFFFFL
            val d0 = h0 * r0 + h1 * s4 + h2 * s3 + h3 * s2 + h4 * s1
            var d1 = h0 * r1 + h1 * r0 + h2 * s4 + h3 * s3 + h4 * s2
            var d2 = h0 * r2 + h1 * r1 + h2 * r0 + h3 * s4 + h4 * s3
            var d3 = h0 * r3 + h1 * r2 + h2 * r1 + h3 * r0 + h4 * s4
            var d4 = h0 * r4 + h1 * r3 + h2 * r2 + h3 * r1 + h4 * r0
            var c = d0 ushr 26; h0 = d0 and 0x3ffffff
            d1 += c; c = d1 ushr 26; h1 = d1 and 0x3ffffff
            d2 += c; c = d2 ushr 26; h2 = d2 and 0x3ffffff
            d3 += c; c = d3 ushr 26; h3 = d3 and 0x3ffffff
            d4 += c; c = d4 ushr 26; h4 = d4 and 0x3ffffff
            h0 += c * 5; c = h0 ushr 26; h0 = h0 and 0x3ffffff; h1 += c
        }
        fun feed(src: ByteArray, o: Int, n: Int) {
            var p = 0
            while (p + 16 <= n) { block(src, o + p, 16, true); p += 16 }
            if (p < n) { val rem = ByteArray(16); System.arraycopy(src, o + p, rem, 0, n - p); block(rem, 0, 16, true) }   // sıfır dolgulu tam blok (AEAD yapısı)
        }
        feed(aad, 0, aad.size)
        feed(ct, ctOff, ctLen)
        val lens = ByteArray(16)
        put32(lens, 0, aad.size); put32(lens, 8, ctLen)
        block(lens, 0, 16, true)
        // son indirgeme
        var c = h1 ushr 26; h1 = h1 and 0x3ffffff; h2 += c
        c = h2 ushr 26; h2 = h2 and 0x3ffffff; h3 += c
        c = h3 ushr 26; h3 = h3 and 0x3ffffff; h4 += c
        c = h4 ushr 26; h4 = h4 and 0x3ffffff; h0 += c * 5
        c = h0 ushr 26; h0 = h0 and 0x3ffffff; h1 += c
        var g0 = h0 + 5; c = g0 ushr 26; g0 = g0 and 0x3ffffff
        var g1 = h1 + c; c = g1 ushr 26; g1 = g1 and 0x3ffffff
        var g2 = h2 + c; c = g2 ushr 26; g2 = g2 and 0x3ffffff
        var g3 = h3 + c; c = g3 ushr 26; g3 = g3 and 0x3ffffff
        val g4 = h4 + c - (1L shl 26)
        val mask = (g4 ushr 63) - 1                     // g4 >= 0 ise tümü 1 (g seçilir)
        h0 = (h0 and mask.inv()) or (g0 and mask); h1 = (h1 and mask.inv()) or (g1 and mask)
        h2 = (h2 and mask.inv()) or (g2 and mask); h3 = (h3 and mask.inv()) or (g3 and mask)
        h4 = (h4 and mask.inv()) or (g4 and mask)
        val f0 = ((h0) or (h1 shl 26)) and 0xFFFFFFFFL
        val f1 = ((h1 ushr 6) or (h2 shl 20)) and 0xFFFFFFFFL
        val f2 = ((h2 ushr 12) or (h3 shl 14)) and 0xFFFFFFFFL
        val f3 = ((h3 ushr 18) or (h4 shl 8)) and 0xFFFFFFFFL
        var t = f0 + (le32(key32, 16).toLong() and 0xFFFFFFFFL)
        val tag = ByteArray(16)
        put32(tag, 0, t.toInt()); t = (t ushr 32) + f1 + (le32(key32, 20).toLong() and 0xFFFFFFFFL)
        put32(tag, 4, t.toInt()); t = (t ushr 32) + f2 + (le32(key32, 24).toLong() and 0xFFFFFFFFL)
        put32(tag, 8, t.toInt()); t = (t ushr 32) + f3 + (le32(key32, 28).toLong() and 0xFFFFFFFFL)
        put32(tag, 12, t.toInt())
        return tag
    }

    private fun polyKey(key: ByteArray, nonce12: ByteArray): ByteArray { val k = ByteArray(64); xor(key, nonce12, 0, k, 0, 64); return k.copyOf(32) }

    /** Şifreler: düz metin + 16 bayt etiket. */
    fun seal(key: ByteArray, nonce12: ByteArray, aad: ByteArray, pt: ByteArray): ByteArray {
        val out = ByteArray(pt.size + 16)
        System.arraycopy(pt, 0, out, 0, pt.size)
        xor(key, nonce12, 1, out, 0, pt.size)
        val tag = poly1305(polyKey(key, nonce12), aad, out, 0, pt.size)
        System.arraycopy(tag, 0, out, pt.size, 16)
        return out
    }

    /** Açar: etiket tutmazsa null (sabit zamanlı karşılaştırma). */
    fun open(key: ByteArray, nonce12: ByteArray, aad: ByteArray, ct: ByteArray, off: Int = 0, len: Int = ct.size - off): ByteArray? {
        if (len < 16) return null
        val n = len - 16
        val tag = poly1305(polyKey(key, nonce12), aad, ct, off, n)
        var d = 0
        for (i in 0 until 16) d = d or (tag[i].toInt() xor ct[off + n + i].toInt())
        if (d != 0) return null
        val out = ct.copyOfRange(off, off + n)
        xor(key, nonce12, 1, out, 0, n)
        return out
    }

    /** WireGuard nonce'u: 4 sıfır bayt + 64 bit küçük-sonlu sayaç. */
    fun wgNonce(counter: Long): ByteArray { val n = ByteArray(12); for (i in 0 until 8) n[4 + i] = (counter ushr (8 * i)).toByte(); return n }

    fun xseal(key: ByteArray, nonce24: ByteArray, aad: ByteArray, pt: ByteArray): ByteArray {
        val sub = hchacha(key, nonce24.copyOf(16))
        val n = ByteArray(12); System.arraycopy(nonce24, 16, n, 4, 8)
        return seal(sub, n, aad, pt)
    }

    fun xopen(key: ByteArray, nonce24: ByteArray, aad: ByteArray, ct: ByteArray): ByteArray? {
        val sub = hchacha(key, nonce24.copyOf(16))
        val n = ByteArray(12); System.arraycopy(nonce24, 16, n, 4, 8)
        return open(sub, n, aad, ct)
    }
}
