package app.dnshizli.core

/** Parmak izi koruması metinleri (12 dil). Sıra: TR, EN, DE, ES, FR, PT, RU, IT, ID, VI, PL, UK. */
object FpText {
    val M: Map<String, Array<String>> = mapOf(
        "title" to arrayOf("Parmak izi koruması", "Fingerprint protection", "Fingerprint-Schutz", "Protección de huella", "Protection d'empreinte", "Proteção de impressão digital",
            "Защита отпечатка", "Protezione impronta", "Perlindungan sidik jari", "Chống dấu vân tay trình duyệt", "Ochrona odcisku", "Захист відбитка"),
        "note" to arrayOf("Telefon modeli ve sürüm bilgisi sitelere gitmez", "Phone model and version details are not sent to sites", "Telefonmodell und Version gehen nicht an Websites",
            "El modelo y la versión del teléfono no llegan a los sitios", "Modèle et version du téléphone non envoyés aux sites", "Modelo e versão do telefone não vão aos sites",
            "Модель и версия телефона не передаются сайтам", "Modello e versione del telefono non vanno ai siti", "Model dan versi ponsel tidak dikirim ke situs",
            "Không gửi mẫu máy và phiên bản cho trang web", "Model i wersja telefonu nie trafiają do stron", "Модель і версія телефона не передаються сайтам"),
    )

    fun t(key: String, lang: Lang = L.lang): String {
        val row = M[key] ?: return key
        return row.getOrNull(lang.ordinal)?.takeIf { it.isNotBlank() } ?: row.getOrNull(Lang.EN.ordinal) ?: row[0]
    }
}
