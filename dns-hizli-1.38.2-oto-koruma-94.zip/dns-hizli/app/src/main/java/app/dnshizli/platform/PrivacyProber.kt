package app.dnshizli.platform

import app.dnshizli.core.LeakProbe
import app.dnshizli.core.PrivacyCheck
import app.dnshizli.core.PrivacyProbe
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * Gizlilik testinin ağ ölçümleri ([PrivacyCheck]). Uygulamanın kendi soketleri de tünelin içindedir ([app.dnshizli.core.AppScopes.plan]
 * kendimizi hep kapsar): ölçülen, diğer uygulamaların ve sitelerin gördüğüdür. Dört iş paralel yürür; hepsi en çok ~6 sn sürer.
 *  - IPv4 ve IPv6 üzerinden Cloudflare "cdn-cgi/trace" (adres sabit IP; sertifika IP için geçerli, doğrulanır): görünen IP + ülke
 *  - STUN bağlama isteği (UDP; WebRTC'nin adres öğrenme yolu)
 *  - bağlıyken sistem çözücüsüyle benzersiz ".invalid" adı: tünelden geçti mi ([LeakProbe])
 * Hiçbir sonuç saklanmaz ya da gönderilmez.
 */
object PrivacyProber {
    private const val TIMEOUT_MS = 5_000

    fun run(connected: Boolean, onDone: (PrivacyProbe) -> Unit) {
        Thread({
            var t4: Pair<String, String?>? = null
            var t6: Pair<String, String?>? = null
            var stun: String? = null
            var dns: Boolean? = null
            val jobs = listOf(
                Thread({ t4 = trace(PrivacyCheck.TRACE4) }, "gizlilik-ip4"),
                Thread({ t6 = trace(PrivacyCheck.TRACE6) }, "gizlilik-ip6"),
                Thread({ stun = stun() }, "gizlilik-stun"),
                Thread({ if (connected) dns = dnsThrough() }, "gizlilik-dns"),
            )
            for (j in jobs) { j.isDaemon = true; j.start() }
            for (j in jobs) try { j.join(TIMEOUT_MS + 2_000L) } catch (_: InterruptedException) {}
            onDone(PrivacyProbe(t4?.first, t4?.second, t6?.first, t6?.second, stun, dns))
        }, "gizlilik-testi").apply { isDaemon = true }.start()
    }

    private fun trace(url: String): Pair<String, String?>? = try {
        val c = URL(url).openConnection() as HttpsURLConnection
        c.connectTimeout = TIMEOUT_MS; c.readTimeout = TIMEOUT_MS
        c.useCaches = false; c.instanceFollowRedirects = false
        c.setRequestProperty("Accept", "text/plain")
        try {
            if (c.responseCode != 200) null
            else c.inputStream.use { ins -> val b = ByteArray(4096); var n = 0; while (n < b.size) { val r = ins.read(b, n, b.size - n); if (r < 0) break; n += r }; PrivacyCheck.parseTrace(String(b, 0, n, Charsets.US_ASCII)) }
        } finally { c.disconnect() }
    } catch (_: Exception) { null }

    private fun stun(): String? = try {
        DatagramSocket().use { s ->
            s.soTimeout = 1_500
            val addr = InetSocketAddress(InetAddress.getByName(PrivacyCheck.STUN_HOST), PrivacyCheck.STUN_PORT)
            val txid = ByteArray(12).also { java.security.SecureRandom().nextBytes(it) }
            val req = PrivacyCheck.stunRequest(txid)
            val buf = ByteArray(512)
            var out: String? = null
            for (attempt in 0 until 3) {
                s.send(DatagramPacket(req, req.size, addr))
                try {
                    val p = DatagramPacket(buf, buf.size)
                    s.receive(p)
                    out = PrivacyCheck.parseStun(buf, p.length, txid)
                    if (out != null) break
                } catch (_: java.net.SocketTimeoutException) {}
            }
            out
        }
    } catch (_: Exception) { null }

    /** Sistem çözücüsüyle sorulan benzersiz ad tünelde görüldü mü (3 sn bekler). */
    private fun dnsThrough(): Boolean {
        val name = LeakProbe.begin()
        try { InetAddress.getByName(name) } catch (_: Exception) {}       // ".invalid": yok cevabı beklenir; önemli olan sorgunun yolu
        val end = System.currentTimeMillis() + 3_000
        while (!LeakProbe.seen() && System.currentTimeMillis() < end) try { Thread.sleep(50) } catch (_: InterruptedException) { break }
        return LeakProbe.end()
    }
}
