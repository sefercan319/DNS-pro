package app.dnshizli.core

/**
 * Alternatif yönlendirme: filtre listesi yayınına ulaşmanın yedek yolları. Asıl adres (GitHub Releases) engellenir ya da yavaşlarsa
 * aynı dosyalar deponun dağıtım dalından ([BRANCH]) farklı alan adlarıyla indirilir: raw.githubusercontent.com ve jsDelivr CDN'inin üç
 * ayrı ağı (cdn / fastly / gcore). Yayın iş akışı her yayında dosyaları bu dala da koyar.
 *
 * Güven kaynağın adresine değil imzaya dayanır: manifest ECDSA ile imzalı, her dosyanın SHA-256'sı manifestte; ayrıca geri dönüş,
 * gelecekten donma ve kanarya denetimleri var. Bu yüzden bir ayna eski ya da bozuk dosya verse bile kabul edilmez; yalnızca sıradaki
 * aynaya geçilir. Bir güncellemenin bütün dosyaları AYNI aynadan alınır (aynalar arası karışık sürüm olmasın).
 */
object ListMirrors {
    const val BRANCH = "listeler-dagitim"
    private val RELEASES = Regex("^https://github\\.com/([A-Za-z0-9_.-]{1,100})/([A-Za-z0-9_.-]{1,100})/releases/download/[A-Za-z0-9_.-]{1,100}/$")

    /** Asıl yayın adresinden (sonu "/") deneme sırasıyla adres listesi; tanınmayan biçimde yalnızca asıl adres. [first]: son başarılı ayna önce. */
    fun urls(base: String, first: String? = null): List<String> {
        val m = RELEASES.matchEntire(base) ?: return if (base.startsWith("https://") && base.endsWith("/")) listOf(base) else emptyList()
        val (owner, repo) = m.destructured
        // "." / ".." ya da noktayla başlayan ad GitHub'da geçersizdir; yol kaçışıyla başka bir adrese ayna üretilmesin.
        if (owner.startsWith(".") || repo.startsWith(".")) return listOf(base)
        val all = listOf(
            base,
            "https://raw.githubusercontent.com/$owner/$repo/$BRANCH/",
            "https://cdn.jsdelivr.net/gh/$owner/$repo@$BRANCH/",
            "https://fastly.jsdelivr.net/gh/$owner/$repo@$BRANCH/",
            "https://gcore.jsdelivr.net/gh/$owner/$repo@$BRANCH/",
        )
        return if (first != null && first in all) listOf(first) + all.filter { it != first } else all
    }

    /** İndirmede izlenebilecek yönlendirme hedefleri: aynaların ve GitHub'ın dağıtım adları (başka bir sunucuya götürülmeyiz). */
    fun redirectAllowed(host: String, base: String): Boolean {
        val h = host.lowercase()
        val b = try { java.net.URI(base).host?.lowercase() } catch (_: Exception) { null }
        return h == b || h == "github.com" || h.endsWith(".githubusercontent.com") || h.endsWith(".github.com") ||
            h == "cdn.jsdelivr.net" || h == "fastly.jsdelivr.net" || h == "gcore.jsdelivr.net"
    }
}
