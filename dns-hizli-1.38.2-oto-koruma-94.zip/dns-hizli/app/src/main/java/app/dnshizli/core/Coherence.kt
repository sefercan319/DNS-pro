package app.dnshizli.core

import java.util.concurrent.atomic.AtomicLong

/**
 * Sızıntı denetimi sayaçları: DNS'i tünele alan yolların kaç kez devreye girdiği. Yalnızca sayaç (ad/adres yok).
 * Sayaç hiç artmıyorsa ya uygulamalar sistem DNS'ini kullanıyor (iyi) ya da yol çalışmıyor; günlükteki özet bunu ayırt ettirir.
 */
object LeakAudit {
    val plainUdp = AtomicLong()     // sabit sunucuya giden düz UDP/53'ün şifreli DNS'e çevrilmesi
    val plainTcp = AtomicLong()     // sabit sunucuya giden düz TCP/53'ün şifreli DNS'e çevrilmesi
    fun reset() { plainUdp.set(0); plainTcp.set(0) }
    fun line(): String = "düz DNS tünele alındı: UDP ${plainUdp.get()}, TCP ${plainTcp.get()}"
}

/**
 * Modüllerin (DNS, DPI, Reklam+) birlikte tutarlı çalışıp çalışmadığına bakan saf kural kümesi. Her uyarı kısa, sabit bir
 * Türkçe cümledir (günlüğe olduğu gibi yazılır; durum değişmedikçe tekrarlanmaz).
 */
object Coherence {
    /** DNS bizdeyken DNS'i atlatan şifreli DNS (DoT/DoH/DoH3) ağ geçidinde kapatılmalı mı? Reklam+ ya da DNS sızıntı kalkanı açıksa evet. */
    fun blockDoh(s: AppSettings) = s.dnsOn && (s.adsPlus || s.dohGuard)

    /** Çelişen ayarların kodları ([AuditText] anahtarları). */
    fun codes(s: AppSettings, listsLive: Boolean, dohBlocking: Boolean): List<String> {
        val out = ArrayList<String>()
        val gw = s.dpiOn || s.adsPlus
        if (s.dnsOn && gw && !dohBlocking) out += "co.doh-open"
        if (s.dnsOn && !gw && !s.dohGuard) out += "co.shield-off"
        if (s.dpiOn && !s.dnsOn) out += "co.dpi-nodns"
        if (s.adsPlus && !listsLive) out += "co.lists"
        if (s.adsPlus && !s.dnsOn) out += "co.ads-nodns"
        if (s.dnsOn && s.splitDns && s.odoh != OdohMode.OFF) out += "co.split-odoh"
        return out
    }

    /** [codes] kodlarının seçili dildeki (varsayılan Türkçe) metinleri. */
    fun warnings(s: AppSettings, listsLive: Boolean, dohBlocking: Boolean, lang: Lang = Lang.TR): List<String> =
        codes(s, listsLive, dohBlocking).map { AuditText.render(it, emptyList(), lang) }
}
