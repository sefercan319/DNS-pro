package app.dnshizli.core

/**
 * Keccak-f[1600] ve FIPS 202 işlevleri (SHA3-256, SHA3-512, SHAKE128, SHAKE256). Saf Kotlin; Android'in sağlayıcılarında SHAKE yoktur.
 * ML-KEM ([MlKem]) bunları kullanır. Doğrulama: JDK SHA3 ile rastgele karşılaştırma ve FIPS 202 / Python hashlib vektörleri (sizma41).
 */
object Keccak {
    /** Tur sabitleri FIPS 202 §3.2.5'teki rc(t) LFSR'ından üretilir (elle yazılmış tablo hatası olmaz). */
    private val RC = LongArray(24) { ir ->
        var v = 0L
        for (j in 0..6) if (rcBit(j + 7 * ir)) v = v or (1L shl ((1 shl j) - 1))
        v
    }
    private fun rcBit(t: Int): Boolean {
        if (t % 255 == 0) return true
        var r = 1
        repeat(t % 255) { r = r shl 1; if (r and 0x100 != 0) r = r xor 0x171 }
        return r and 1 != 0
    }
    private val ROT = intArrayOf(0, 1, 62, 28, 27, 36, 44, 6, 55, 20, 3, 10, 43, 25, 39, 41, 45, 15, 21, 8, 18, 2, 61, 56, 14)

    fun permute(a: LongArray) {
        val c = LongArray(5); val b = LongArray(25)
        for (round in 0 until 24) {
            for (x in 0 until 5) c[x] = a[x] xor a[x + 5] xor a[x + 10] xor a[x + 15] xor a[x + 20]
            for (x in 0 until 5) {
                val d = c[(x + 4) % 5] xor java.lang.Long.rotateLeft(c[(x + 1) % 5], 1)
                for (y in 0 until 25 step 5) a[y + x] = a[y + x] xor d
            }
            for (x in 0 until 5) for (y in 0 until 5) {
                val i = x + 5 * y
                b[y + 5 * ((2 * x + 3 * y) % 5)] = java.lang.Long.rotateLeft(a[i], ROT[i])
            }
            for (y in 0 until 25 step 5) for (x in 0 until 5) a[y + x] = b[y + x] xor (b[y + (x + 1) % 5].inv() and b[y + (x + 2) % 5])
            a[0] = a[0] xor RC[round]
        }
    }

    /** Süngerin emme/sıkma durumu. [rate] bayt; [pad] 0x06 (SHA3) ya da 0x1F (SHAKE). */
    class Sponge(private val rate: Int, private val pad: Int) {
        private val s = LongArray(25)
        private var pos = 0
        private var squeezing = false

        private fun xorByte(i: Int, v: Int) { s[i ushr 3] = s[i ushr 3] xor ((v.toLong() and 0xFF) shl (8 * (i and 7))) }
        private fun getByte(i: Int): Byte = (s[i ushr 3] ushr (8 * (i and 7))).toByte()

        fun absorb(b: ByteArray, off: Int = 0, len: Int = b.size): Sponge {
            check(!squeezing)
            for (k in off until off + len) { xorByte(pos++, b[k].toInt()); if (pos == rate) { permute(s); pos = 0 } }
            return this
        }

        fun absorb(v: Int): Sponge = absorb(byteArrayOf(v.toByte()))

        private fun finish() { xorByte(pos, pad); xorByte(rate - 1, 0x80); permute(s); pos = 0; squeezing = true }

        fun squeeze(out: ByteArray, off: Int = 0, len: Int = out.size) {
            if (!squeezing) finish()
            for (k in off until off + len) { if (pos == rate) { permute(s); pos = 0 }; out[k] = getByte(pos++) }
        }

        fun squeeze(n: Int): ByteArray = ByteArray(n).also { squeeze(it) }
    }

    fun sha3_256(vararg parts: ByteArray): ByteArray { val sp = Sponge(136, 0x06); for (p in parts) sp.absorb(p); return sp.squeeze(32) }
    fun sha3_512(vararg parts: ByteArray): ByteArray { val sp = Sponge(72, 0x06); for (p in parts) sp.absorb(p); return sp.squeeze(64) }
    fun shake128(): Sponge = Sponge(168, 0x1F)
    fun shake256(): Sponge = Sponge(136, 0x1F)
    fun shake256(n: Int, vararg parts: ByteArray): ByteArray { val sp = shake256(); for (p in parts) sp.absorb(p); return sp.squeeze(n) }
}
