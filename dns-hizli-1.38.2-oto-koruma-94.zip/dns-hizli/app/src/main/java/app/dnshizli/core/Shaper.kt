package app.dnshizli.core

import java.util.Random
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Trafik gizleme (Mullvad DAITA / Nym mixnet ayarına benzer, tek sunuculu): şifreli trafiğin ŞEKLİNDEN (paket boyları, zamanlama,
 * boşluklar) hangi sitelere girildiğini tahmin etmeyi zorlaştırır. Gerçek mixnet değildir (birçok bağımsız düğüm gerekir); telefonla
 * kendi sunucun arasındaki gözlemciye karşıdır.
 *  - Boyut: paketler sabit kalıplara doldurulur (DÜŞÜK: 128/256/512/1024/MTU; YÜKSEK: hep MTU). Standart WireGuard alıcısı dolguyu atar.
 *  - Örtü: sahte (sıfır dolgulu) paketler — DÜŞÜK: 1,5-6 sn'de bir rastgele; YÜKSEK: gerçek trafik yokken ~10/sn sabit taban akış.
 *  - Zamanlama: YÜKSEK'te gönderimlere 0-12 ms rastgele gecikme (sıra korunur).
 * Stealth yolunda aktarıcı da sunucudan gelen yönü aynı biçimde doldurur ve örter (tools/stealth/sunucu: SHP1).
 * Bedel: YÜKSEK ≈ saatte 45 MB ek veri ve biraz gecikme; DÜŞÜK ≈ birkaç MB.
 */
class Shaper(val level: Level, private val rng: Random = Random()) {
    enum class Level(val id: String, val code: Int) {
        OFF("off", 0), LOW("low", 1), HIGH("high", 2);
        companion object { fun of(id: String?): Level = values().firstOrNull { it.id == id } ?: OFF }
    }

    fun padSize(len: Int, mtu: Int): Int = when (level) {
        Level.OFF -> 0
        Level.LOW -> BUCKETS.firstOrNull { it >= len }?.coerceAtMost(mtu)?.takeIf { it >= len } ?: mtu
        Level.HIGH -> mtu
    }

    fun coverSize(mtu: Int): Int = when (level) {
        Level.OFF -> 0
        Level.LOW -> minOf(COVER_LOW[rng.nextInt(COVER_LOW.size)], mtu)
        Level.HIGH -> mtu
    }

    /** Bir sonraki örtü denemesine kadar beklenecek süre (ms); OFF'ta -1. */
    fun nextCoverDelayMs(): Long = when (level) {
        Level.OFF -> -1
        Level.LOW -> 1500L + rng.nextInt(4500)
        Level.HIGH -> 80L + rng.nextInt(41)
    }

    /** Örtü gönderilsin mi? YÜKSEK: son gerçek gönderimden beri [HIGH_FLOOR_MS] geçtiyse (gerçek trafik zaten akıyorsa gerekmez). */
    fun coverWanted(now: Long, lastRealSent: Long): Boolean = when (level) {
        Level.OFF -> false
        Level.LOW -> true
        Level.HIGH -> now - lastRealSent >= HIGH_FLOOR_MS
    }

    fun jitterMs(): Int = if (level == Level.HIGH) rng.nextInt(JITTER_HIGH + 1) else 0

    companion object {
        val BUCKETS = intArrayOf(128, 256, 512, 1024)
        private val COVER_LOW = intArrayOf(256, 512, 1024)
        const val HIGH_FLOOR_MS = 80L
        const val JITTER_HIGH = 12
    }
}

/**
 * Gönderimleri rastgele geciktirir ama SIRAYI korur (her paketin zamanı bir öncekinden önce olamaz). Tek iş parçacığı; [close] ile durur.
 * Gecikme 0 ise doğrudan gönderir.
 */
class JitterSender(private val send: (ByteArray) -> Unit, private val delayMs: () -> Int, private val now: () -> Long = { System.nanoTime() / 1_000_000 }) {
    private val lock = ReentrantLock()
    private val cond = lock.newCondition()
    private val q = ArrayDeque<Pair<Long, ByteArray>>()
    private var lastAt = 0L
    @Volatile private var closed = false
    private val thread = Thread({ run() }, "wg-jitter").also { it.isDaemon = true; it.start() }

    fun offer(p: ByteArray) {
        val d = delayMs()
        if (d <= 0 && lock.withLock { q.isEmpty() }) { send(p); return }
        lock.withLock {
            if (q.size >= 512) return                                       // taşma: düşer (UDP gibi)
            val at = maxOf(now() + d, lastAt)
            lastAt = at
            q.addLast(at to p)
            cond.signal()
        }
    }

    private fun run() {
        while (!closed) {
            val p: ByteArray = lock.withLock {
                while (q.isEmpty() && !closed) cond.await()
                if (closed) return
                val (at, pk) = q.first()
                val wait = at - now()
                if (wait > 0) { cond.await(wait, java.util.concurrent.TimeUnit.MILLISECONDS); return@withLock null }
                q.removeFirst(); pk
            } ?: continue
            try { send(p) } catch (_: Exception) {}
        }
    }

    fun close() { closed = true; lock.withLock { cond.signalAll() } }
}
