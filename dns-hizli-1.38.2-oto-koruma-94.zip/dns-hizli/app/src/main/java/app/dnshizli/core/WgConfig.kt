package app.dnshizli.core

/**
 * WireGuard yapılandırma dosyası (wg-quick ".conf" biçimi; QR kodu da aynı metni taşır). Sıkı ayrıştırma: bilinmeyen alan uyarı olarak
 * kaydedilir, geçersiz anahtar/adres/uç nokta ayrıştırmayı durdurur (yarım yapılandırmayla tünel kurulmaz). Bize özel tünel bunu kullanır.
 *
 *   [Interface]  PrivateKey, Address (virgüllü CIDR), DNS (virgüllü IP), MTU
 *   [Peer]       PublicKey, PresharedKey, AllowedIPs (virgüllü CIDR), Endpoint (ad:port, [v6]:port), PersistentKeepalive
 *   [Stealth]    Endpoint (aktarıcı ad:port), Pin (sertifika SPKI SHA-256, base64), Path (gizli yol), SNI (isteğe bağlı),
 *                PQ (1: kuantum sonrası PSK değişimi, [PqPsk])
 *                — bize özel bölüm: WireGuard TLS içinde kendi aktarıcımıza gider ([StealthCfg]). Varsa [Peer] Endpoint isteğe bağlıdır.
 * Şimdilik tek eş desteklenir (istemci yapılandırmalarının neredeyse tamamı tek eşlidir).
 */
class WgConfig(
    val privateKey: ByteArray,
    val addresses: List<Cidr>,
    val dns: List<ByteArray>,
    val mtu: Int,
    val peer: PeerCfg,
    val warnings: List<String>,
    val stealth: StealthCfg? = null,
) {
    class Cidr(val ip: ByteArray, val prefix: Int) {
        override fun toString() = "${Ip.format(ip)}/$prefix"
        /** [a] bu ağın içinde mi? */
        fun contains(a: ByteArray): Boolean {
            if (a.size != ip.size) return false
            var bits = prefix; var i = 0
            while (bits >= 8) { if (a[i] != ip[i]) return false; bits -= 8; i++ }
            if (bits == 0) return true
            val mask = (0xFF shl (8 - bits)) and 0xFF
            return (a[i].toInt() and mask) == (ip[i].toInt() and mask)
        }
    }
    class PeerCfg(val publicKey: ByteArray, val presharedKey: ByteArray, val allowedIps: List<Cidr>, val endpointHost: String, val endpointPort: Int, val keepaliveSec: Int)

    /** Doğrudan UDP uç noktası var mı ([Peer] Endpoint)? Yalnızca Stealth'li yapılandırmada olmayabilir. */
    val hasUdpEndpoint: Boolean get() = peer.endpointPort > 0

    /** Tüm trafik mi (0.0.0.0/0 ya da ::/0)? */
    val fullTunnel: Boolean get() = peer.allowedIps.any { it.prefix == 0 }
    val publicKey: ByteArray get() = Wg.publicKey(privateKey)

    companion object {
        const val MAX_TEXT = 16 * 1024
        const val DEFAULT_MTU = 1420

        /** Hata nedeni (Türkçe kısa) ya da yapılandırma. */
        sealed class Result { class Ok(val cfg: WgConfig) : Result(); class Err(val why: String) : Result() }

        fun parse(text: String): Result {
            if (text.length > MAX_TEXT) return Result.Err("dosya çok büyük")
            var section = ""
            var priv: ByteArray? = null; val addrs = ArrayList<Cidr>(); val dns = ArrayList<ByteArray>(); var mtu = DEFAULT_MTU
            var pub: ByteArray? = null; var psk = ByteArray(32); val allowed = ArrayList<Cidr>(); var host: String? = null; var port = 0; var ka = 0
            var peers = 0
            var stealthSeen = false
            var sHost: String? = null; var sPort = 0; var sPin: ByteArray? = null; var sPath: String? = null; var sSni: String? = null; var sPq = false; var sPqPin: ByteArray? = null
            val warn = ArrayList<String>()
            for ((no, raw) in text.split('\n').withIndex()) {
                val line = raw.substringBefore('#').trim()
                if (line.isEmpty()) continue
                if (line.startsWith("[") && line.endsWith("]")) {
                    section = line.substring(1, line.length - 1).trim().lowercase()
                    if (section == "peer" && ++peers > 1) return Result.Err("birden çok [Peer] desteklenmiyor")
                    if (section == "stealth") { if (stealthSeen) return Result.Err("birden çok [Stealth]"); stealthSeen = true }
                    if (section != "interface" && section != "peer" && section != "stealth") return Result.Err("bilinmeyen bölüm: [$section]")
                    continue
                }
                val eq = line.indexOf('=')
                if (eq <= 0) return Result.Err("satır ${no + 1}: 'ad = değer' biçiminde değil")
                val k = line.substring(0, eq).trim().lowercase()
                val v = line.substring(eq + 1).trim()
                when (section to k) {
                    "interface" to "privatekey" -> priv = key(v) ?: return Result.Err("geçersiz PrivateKey")
                    "interface" to "address" -> for (p in list(v)) addrs.add(cidr(p, host = true) ?: return Result.Err("geçersiz Address: $p"))
                    "interface" to "dns" -> for (p in list(v)) { val ip = Ip.parse(p); if (ip != null) dns.add(ip) else warn.add("DNS arama alanı yok sayıldı: $p") }
                    "interface" to "mtu" -> mtu = v.toIntOrNull()?.takeIf { it in 1280..1500 } ?: return Result.Err("MTU 1280-1500 olmalı")
                    "interface" to "listenport", "interface" to "fwmark", "interface" to "table",
                    "interface" to "preup", "interface" to "postup", "interface" to "predown", "interface" to "postdown", "interface" to "saveconfig" ->
                        warn.add("istemcide kullanılmayan alan yok sayıldı: ${line.substring(0, eq).trim()}")   // komut alanları ASLA çalıştırılmaz
                    "peer" to "publickey" -> pub = key(v) ?: return Result.Err("geçersiz PublicKey")
                    "peer" to "presharedkey" -> psk = key(v) ?: return Result.Err("geçersiz PresharedKey")
                    "peer" to "allowedips" -> for (p in list(v)) allowed.add(cidr(p, host = false) ?: return Result.Err("geçersiz AllowedIPs: $p"))
                    "peer" to "endpoint" -> { val e = endpoint(v) ?: return Result.Err("geçersiz Endpoint (ad:port ya da [v6]:port)"); host = e.first; port = e.second }
                    "peer" to "persistentkeepalive" -> ka = (if (v.equals("off", true)) 0 else v.toIntOrNull())?.takeIf { it in 0..65535 } ?: return Result.Err("geçersiz PersistentKeepalive")
                    "stealth" to "endpoint" -> { val e = endpoint(v) ?: return Result.Err("geçersiz Stealth Endpoint"); sHost = e.first; sPort = e.second }
                    "stealth" to "pin" -> sPin = key(v) ?: return Result.Err("geçersiz Stealth Pin (base64 SHA-256)")
                    "stealth" to "path" -> sPath = v.takeIf { pathOk(it) } ?: return Result.Err("geçersiz Stealth Path (/ ile başlar, 17-200 karakter)")
                    "stealth" to "pqpin" -> sPqPin = key(v) ?: return Result.Err("geçersiz Stealth PqPin (base64 SHA-256)")
                    "stealth" to "pq" -> sPq = when (v.lowercase()) { "1", "on", "evet", "true" -> true; "0", "off", "hayir", "hayır", "false" -> false; else -> return Result.Err("geçersiz Stealth PQ (1 ya da 0)") }
                    "stealth" to "sni" -> sSni = if (v.isEmpty()) null else FilterNames.lenient(v)?.takeIf { Ip.parse(v) == null } ?: return Result.Err("geçersiz Stealth SNI")
                    else -> if (section.isEmpty()) return Result.Err("satır ${no + 1}: bölüm başlığından önce alan") else warn.add("bilinmeyen alan yok sayıldı: ${line.substring(0, eq).trim()}")
                }
            }
            val p = priv ?: return Result.Err("PrivateKey yok")
            if (addrs.isEmpty()) return Result.Err("Address yok")
            val pk = pub ?: return Result.Err("[Peer] PublicKey yok")
            var stealth: StealthCfg? = null
            if (stealthSeen) {
                val sh = sHost ?: return Result.Err("[Stealth] Endpoint yok")
                val pin = sPin ?: return Result.Err("[Stealth] Pin yok")
                val path = sPath ?: return Result.Err("[Stealth] Path yok")
                if (sPqPin != null) sPq = true                         // kimlik özeti varsa kuantum sonrası değişim açıktır
                if (sPq && psk.all { it == 0.toByte() }) return Result.Err("[Stealth] PQ için [Peer] PresharedKey gerekli")
                stealth = StealthCfg(sh, sPort, sSni, path, pin, sPq, sPqPin)
            }
            val h = host ?: stealth?.host ?: return Result.Err("Endpoint yok (sunucu adresi gerekli)")
            if (host == null) port = 0                              // yalnızca Stealth: doğrudan UDP yok
            if (allowed.isEmpty()) return Result.Err("AllowedIPs yok")
            if (Wg.dh(p, pk) == null) return Result.Err("anahtarlar uyumsuz (geçersiz ortak anahtar)")
            return Result.Ok(WgConfig(p, addrs, dns, mtu, PeerCfg(pk, psk, allowed, h, port, ka), warn, stealth))
        }

        /** Gizli yol: "/" ile başlar, 17-200 karakter, URL'de kaçışsız güvenli karakterler. */
        fun pathOk(v: String): Boolean = v.length in 17..200 && v[0] == '/' &&
            v.all { it in 'a'..'z' || it in 'A'..'Z' || it in '0'..'9' || it == '-' || it == '_' || it == '/' || it == '.' || it == '~' }

        private fun list(v: String) = v.split(',').map { it.trim() }.filter { it.isNotEmpty() }

        /** 32 baytlık base64 anahtar (44 karakter, '=' ile biter). */
        fun key(v: String): ByteArray? {
            if (v.length != 44 || !v.endsWith("=")) return null
            val b = try { java.util.Base64.getDecoder().decode(v) } catch (_: IllegalArgumentException) { return null }
            return b.takeIf { it.size == 32 }
        }

        fun cidr(s: String, host: Boolean): Cidr? {
            val slash = s.indexOf('/')
            val ipS = if (slash < 0) s else s.substring(0, slash)
            val ip = Ip.parse(ipS) ?: return null
            val max = ip.size * 8
            val pre = if (slash < 0) max else s.substring(slash + 1).toIntOrNull() ?: return null
            if (pre !in 0..max) return null
            if (!host) {                                           // AllowedIPs: ağ adresine indirgenir (192.168.1.5/24 → 192.168.1.0/24)
                val n = ip.copyOf(); var bits = pre
                for (i in n.indices) { if (bits >= 8) { bits -= 8; continue }; n[i] = (n[i].toInt() and ((0xFF shl (8 - bits)) and 0xFF)).toByte(); bits = 0 }
                return Cidr(n, pre)
            }
            return Cidr(ip, pre)
        }

        /** "ad:port", "1.2.3.4:51820", "[2001:db8::1]:51820". */
        fun endpoint(v: String): Pair<String, Int>? {
            val host: String; val portS: String
            if (v.startsWith("[")) {
                val e = v.indexOf("]:"); if (e < 0) return null
                host = v.substring(1, e); portS = v.substring(e + 2)
                if (Ip.parse(host)?.size != 16) return null
            } else {
                val c = v.lastIndexOf(':'); if (c <= 0 || v.indexOf(':') != c) return null
                host = v.substring(0, c); portS = v.substring(c + 1)
                if (Ip.parse(host) == null && FilterNames.lenient(host) == null) return null
            }
            val port = portS.toIntOrNull()?.takeIf { it in 1..65535 } ?: return null
            return host to port
        }
    }
}
