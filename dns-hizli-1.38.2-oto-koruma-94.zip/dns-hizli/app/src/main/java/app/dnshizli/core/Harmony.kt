package app.dnshizli.core

/**
 * Uyum motorunun çalışırken kısabildiği denetimler. Her biri bir İSTEĞE BAĞLI işi açıp kapatır; hiçbiri güvenliği ya da engellemeyi
 * değiştirmez (süzgeç, güvenlik duvarı, şifreleme, DPI atlatmanın kendisi, sızıntı kalkanları motorun erişiminde değildir).
 */
enum class Knob(val id: String) {
    /** Düz DNS'te yavaş cevapta ikinci sunucuya paralel soru. */
    DNS_RACE("race"),
    /** Süresi dolmak üzere olan önbellek kayıtlarını önceden yenileme (DNS). */
    PREFETCH("prefetch"),
    /** Yanıtsız SYN'de paralel yedek bağlantı (ağ geçidi). */
    HEDGE("hedge"),
    /** STUN/ses akışlarının önüne sahte UDP paketleri (DPI). */
    UDP_DECOY("decoy"),
    /** QUIC Initial paketini yeniden kurma (DPI). */
    QUIC_SPLIT("quicsplit"),
    /** Sahte paket TTL'i için sunucuya hop ölçümü. */
    AUTO_TTL("autottl"),
    /** TLS parmak izi (JA3) gözlemi. */
    JA3("ja3"),
    /** Arayüzün tam hareketli efektleri: kısılınca "Az" düzeyine iner. */
    VISUALS("visuals"),
    /** Arayüz hareketinin tamamı: kısılınca hareket durur (yalnızca kaynak tam efektler kısıldıktan sonra da yetmezse). */
    MOTION("motion"),
}

/** Anlık yük seviyesi. */
enum class Load { SMOOTH, BUSY, OVERLOAD }

/** Bir özelliğin çözümlenmiş durumu. */
enum class FState {
    /** Kullanıcı kapalı tutuyor. */
    OFF,
    /** Çalışıyor. */
    ACTIVE,
    /** Açık ama dayandığı özellik etkin değil (ör. DPI kapalıyken sahte UDP): kendiliğinden uyur. */
    DORMANT,
    /** Açık ama başka bir özellik onu boşa çıkarıyor (ör. QUIC engeli varken QUIC bölme). */
    SUPERSEDED,
    /** Motor kaynak/yük/etkinlik nedeniyle geçici kıstı. */
    SHED,
}

/**
 * Bir ölçüm anı (platform toplar). Bilinmeyen değerler 0 / -1.
 * [heapPct]: yığın belleği yüzdesi. [atMs]/[periodMs]: ölçüm anı ve beklenen aralık (zamanlayıcı gecikmesi = işlemci açlığı).
 * [shieldFlood]: otomatik koruma ([Immune]) akış seli önlemi uyguluyor: saldırı ya da kaçak bir uygulama var, beklemeden aşırı yük.
 */
data class LoadSample(
    val dnsMs: Int = 0,
    val tcpFlows: Int = 0, val maxTcp: Int = 0,
    val udpFlows: Int = 0, val maxUdp: Int = 0,
    val internalErrors: Long = -1L,
    val heapPct: Int = -1,
    val atMs: Long = -1L, val periodMs: Long = 0L,
    val shieldFlood: Boolean = false,
) {
    companion object {
        /** Bu sürecin yığın kullanımı (%); ölçülemezse -1. */
        fun heapNow(): Int = try {
            val r = Runtime.getRuntime()
            val max = r.maxMemory()
            if (max <= 0 || max == Long.MAX_VALUE) -1 else (((r.totalMemory() - r.freeMemory()) * 100) / max).toInt().coerceIn(0, 100)
        } catch (_: Throwable) { -1 }
    }
}

/** İsteğe bağlı işlerin işe yarayıp yaramadığını gösteren birikimli sayaçlar (-1 = bilinmiyor). */
data class Efficacy(val hedged: Long = -1L, val hedgeWon: Long = -1L, val races: Long = -1L, val raceWins: Long = -1L)

/**
 * Motorun karar ortamı: cihaz profili, ölçülen koşullar, son yığın ölçümü ve otomatik korumanın ([Immune]) o an uyguladığı önlemler.
 * Önlemler çözüme katılır: koruma DPI'ı kendisi açtıysa DPI'a bağlı işler de hesaba girer; QUIC'i kapattıysa QUIC bölme boşa çıkar;
 * tarayıcı kipini söktüyse ona bağlı işler uyur. Böylece motor ile koruma aynı resmi görür, birbirine karşı çalışmaz.
 */
data class HarmonyContext(
    val profile: DeviceProfile?,
    val facts: CompatFacts = CompatFacts(),
    val heapPct: Int = -1,
    val shield: Set<Act> = emptySet(),
)

/**
 * Uyum planı: her özelliğin durumu ve nedeni, kısılan denetimler, kaynak kullanımı/kapasitesi ve çarpanlar.
 * [idleScale]: boşta akış süreleri. [flowScale]: açık akış sınırları (bellek baskısında). [tickScale]: arka plan işlerinin aralığı
 * (denetim, sızıntı testi, liste denetimi, rapor diske yazma).
 */
class HarmonyPlan(
    val load: Load,
    val states: Map<String, FState>,
    val reasons: Map<String, String>,
    val off: Map<Knob, String>,
    val usage: Map<Res, Int>,
    val capacity: Map<Res, Int>,
    val idleScale: Float,
    val tickScale: Int,
    val flowScale: Float = 1f,
    val notes: List<String> = emptyList(),
) {
    fun allows(k: Knob): Boolean = k !in off
    fun state(id: String): FState = states[id] ?: FState.OFF
    /** Tam efektler kısıldı ("Az"). */
    val reduceVisuals: Boolean get() = Knob.VISUALS in off || Knob.MOTION in off
    /** Hareket tamamen durdu. */
    val motionOff: Boolean get() = Knob.MOTION in off

    /** Günlük için imza: değişmedikçe tekrar yazılmaz. */
    val sig: String get() = load.name + ":" + off.keys.sortedBy { it.ordinal }.joinToString(",") { it.id } + ":" + idleScale + ":" + tickScale + ":" + flowScale

    /** İç günlük satırları (kullanıcıya gösterilmez). */
    fun journal(): List<String> {
        val out = ArrayList<String>()
        out += "yük ${load.name}, kaynak " + Res.values().joinToString(" ") { "${it.name.lowercase()} ${usage[it] ?: 0}/${capacity[it] ?: 0}" } +
            (if (idleScale < 1f) ", boşta süre ×$idleScale" else "") + (if (flowScale < 1f) ", akış sınırı ×$flowScale" else "") +
            (if (tickScale > 1) ", arka plan aralığı ×$tickScale" else "")
        if (off.isNotEmpty()) out += "kısılan: " + off.entries.joinToString("; ") { "${it.key.id} (${it.value})" }
        val idle = states.filter { it.value == FState.DORMANT || it.value == FState.SUPERSEDED }.keys
        if (idle.isNotEmpty()) out += "uyuyan/boşa çıkan: " + idle.sorted().joinToString(", ") { it + " (" + (reasons[it] ?: "?") + ")" }
        out += notes
        return out
    }

    fun with(off: Map<Knob, String>, notes: List<String> = this.notes) =
        HarmonyPlan(load, states, reasons, off, usage, capacity, idleScale, tickScale, flowScale, notes)

    companion object {
        val NONE = HarmonyPlan(Load.SMOOTH, emptyMap(), emptyMap(), emptyMap(), emptyMap(), emptyMap(), 1f, 1)
    }
}

/**
 * Grafiğin önceden hesaplanmış dizini: bağımlılık sırası, kimlik → sıra numarası, bağımlılıkların sıra numaraları, maliyet dizileri,
 * denetim → özellik, üstünlük ilişkileri. Çözüm her turda dizilerle çalışır (eşlem araması, sıralama ve topolojik sıralama yok).
 */
internal object HarmonyIndex {
    val order: Array<Feature> = FeatureGraph.order().toTypedArray()
    val n = order.size
    val pos: Map<String, Int> = order.withIndex().associate { it.value.id to it.index }
    val needs: Array<IntArray> = Array(n) { i -> order[i].needs.map { pos.getValue(it) }.toIntArray() }
    val needsAny: Array<IntArray> = Array(n) { i -> order[i].needsAny.map { pos.getValue(it) }.toIntArray() }
    val cost: Array<IntArray> = Array(n) { i -> IntArray(Res.values().size) { r -> order[i].cost[Res.values()[r]] } }
    val sheddable: IntArray = (0 until n).filter { order[it].sheddable }.toIntArray()
    val knobPos: Map<Knob, Int> = order.withIndex().filter { it.value.knob != null }.associate { it.value.knob!! to it.index }
    val supersedes: Array<IntArray> = FeatureGraph.relations.filter { it.kind == RelKind.SUPERSEDES }.map { intArrayOf(pos.getValue(it.a), pos.getValue(it.b)) }.toTypedArray()
    val whyOf: Array<String> = FeatureGraph.relations.filter { it.kind == RelKind.SUPERSEDES }.map { it.why }.toTypedArray()
    val tension: List<Relation> = FeatureGraph.relations.filter { it.kind == RelKind.TENSION }
}

/**
 * Uyum motorunun saf çekirdeği: aynı girdiye aynı plan. Adımlar:
 *  0) Koruma katmanı: otomatik korumanın etkin önlemleri ayarların üstüne bindirilir (çözüm onları da görür).
 *  1) Kapasite: cihaz sınıfından taban; pil tasarrufu, ısınma, ölçülü mobil veri ve anlık yük kaynak kapasitelerini daraltır.
 *  2) Çözüm: bağımlılık sırasıyla kapalı / etkin / uyuyan / boşa çıkan durumları; cihazın yapamadığı ve sigortası atan işler kısılır.
 *  3) Bütçe: bir kaynak taşıyorsa yalnızca kısılabilenler, önce süs, sonra en az değerli olan, o kaynağa en çok yük bindiren sırasıyla
 *     kısılır; her kısmada bağımlılar yeniden çözülür (uyuyan bağımlı da yükünü bırakır).
 *  4) Çarpanlar: boşta akış süresi, akış sınırı, arka plan aralığı.
 * Kullanıcının ayarı değişmez; yalnızca çalışan değerler.
 */
object HarmonyCore {
    private val RES = Res.values()

    fun capacity(ctx: HarmonyContext, load: Load): Map<Res, Int> {
        val tier = ctx.profile?.tier ?: DeviceTier.MID
        val f = ctx.facts
        // Taban kapasiteler: varsayılan ayarlar her sınıfta, tüm modüller güçlü cihazda sığacak şekilde (testlerle ayarlı).
        var cpu = when (tier) { DeviceTier.HIGH -> 30.0; DeviceTier.MID -> 22.0; DeviceTier.LOW -> 12.0 }
        var mem = when (tier) { DeviceTier.HIGH -> 24.0; DeviceTier.MID -> 16.0; DeviceTier.LOW -> 10.0 }
        var battery = 24.0; var data = 14.0; var wake = 8.0; var latency = 8.0
        if (f.batterySaver) { battery = 10.0; wake = 3.0 }
        when {
            f.thermal >= 4 -> { cpu *= 0.25; battery *= 0.5 }
            f.thermal >= 3 -> { cpu *= 0.4; battery *= 0.6 }
            f.thermal >= 2 -> { cpu *= 0.6; battery *= 0.7 }
        }
        if (f.metered && f.mobile) data = 2.0
        if (ctx.heapPct >= 93) mem *= 0.6 else if (ctx.heapPct >= 85) mem *= 0.8
        when (load) {
            Load.SMOOTH -> {}
            Load.BUSY -> { cpu *= 0.75; latency *= 0.75 }
            Load.OVERLOAD -> { cpu *= 0.5; latency *= 0.5; mem *= 0.75 }
        }
        return mapOf(Res.CPU to cpu.toInt(), Res.MEM to mem.toInt(), Res.BATTERY to battery.toInt(), Res.DATA to data.toInt(), Res.WAKE to wake.toInt(), Res.LATENCY to latency.toInt())
    }

    /** Otomatik korumanın önlemleri ayarların üstüne: DPI'ı açtıysa DPI, QUIC'i kapattıysa QUIC engeli, tarayıcı kipini söktüyse kip yok. */
    fun overlay(s: AppSettings, shield: Set<Act>): AppSettings {
        if (shield.isEmpty()) return s
        val dpi = s.dpiOn || Act.DPI_ON in shield
        val quic = s.blockQuic || Act.QUIC_OFF in shield
        val mitm = s.mitmOn && Act.MITM_OFF !in shield
        return if (dpi == s.dpiOn && quic == s.blockQuic && mitm == s.mitmOn) s else s.copy(dpiOn = dpi, blockQuic = quic, mitmOn = mitm)
    }

    /** Dizi tabanlı çözüm. [forced]: kısılan sıra numaraları → neden. [on]: kullanıcı açık mı (bir kez hesaplanır). */
    private fun resolveIdx(on: BooleanArray, forced: Array<String?>, st: Array<FState>, why: Array<String?>) {
        val ix = HarmonyIndex
        for (i in 0 until ix.n) {
            why[i] = null
            st[i] = when {
                !on[i] -> FState.OFF
                ix.needs[i].any { st[it] != FState.ACTIVE } -> { why[i] = "gerekli: " + ix.needs[i].filter { st[it] != FState.ACTIVE }.joinToString("+") { ix.order[it].id }; FState.DORMANT }
                ix.needsAny[i].isNotEmpty() && ix.needsAny[i].none { st[it] == FState.ACTIVE } -> { why[i] = "gerekli: " + ix.needsAny[i].joinToString("|") { ix.order[it].id }; FState.DORMANT }
                forced[i] != null -> { why[i] = forced[i]; FState.SHED }
                else -> FState.ACTIVE
            }
        }
        for ((j, r) in ix.supersedes.withIndex()) {
            val a = r[0]; val b = r[1]
            if (st[a] == FState.ACTIVE && (st[b] == FState.ACTIVE || st[b] == FState.SHED)) { st[b] = FState.SUPERSEDED; why[b] = ix.whyOf[j] }
        }
    }

    private fun onFlags(s: AppSettings): BooleanArray = BooleanArray(HarmonyIndex.n) { i -> try { HarmonyIndex.order[i].on(s) } catch (_: Exception) { false } }

    /** Durumları çözer (eşlem arayüzü; testler ve günlük için). [forced]: kimlik → neden. */
    internal fun resolve(s: AppSettings, forced: Map<String, String>, reasons: MutableMap<String, String>): Map<String, FState> {
        val ix = HarmonyIndex
        val f = arrayOfNulls<String>(ix.n)
        for ((id, w) in forced) ix.pos[id]?.let { f[it] = w }
        val st = Array(ix.n) { FState.OFF }
        val why = arrayOfNulls<String>(ix.n)
        resolveIdx(onFlags(s), f, st, why)
        reasons.clear()
        val out = LinkedHashMap<String, FState>()
        for (i in 0 until ix.n) { out[ix.order[i].id] = st[i]; why[i]?.let { reasons[ix.order[i].id] = it } }
        return out
    }

    fun usage(states: Map<String, FState>): Map<Res, Int> {
        val u = HashMap<Res, Int>()
        for (r in RES) u[r] = 0
        for ((id, v) in states) if (v == FState.ACTIVE) { val c = FeatureGraph.byId[id]?.cost ?: continue; for (r in RES) u[r] = u.getValue(r) + c[r] }
        return u
    }

    private fun usageIdx(st: Array<FState>, out: IntArray) {
        java.util.Arrays.fill(out, 0)
        val c = HarmonyIndex.cost
        for (i in st.indices) if (st[i] == FState.ACTIVE) { val k = c[i]; for (r in out.indices) out[r] += k[r] }
    }

    fun compute(s: AppSettings, ctx: HarmonyContext, load: Load = Load.SMOOTH, broken: Map<Knob, String> = emptyMap()): HarmonyPlan {
        val ix = HarmonyIndex
        val eff = overlay(s, ctx.shield)
        val capMap = capacity(ctx, load)
        val cap = IntArray(RES.size) { capMap.getValue(RES[it]) }
        val forced = arrayOfNulls<String>(ix.n)
        // Cihazın yapamadığı ya da bu ağda işe yaramadığı ölçülen işler baştan kısılır.
        if (ctx.facts.ttlBroken) { ix.pos["dpi.autoTtl"]?.let { forced[it] = "TTL ayarlanamıyor" }; ix.pos["udpDecoy"]?.let { forced[it] = "TTL ayarlanamıyor" } }
        for ((k, why) in broken) ix.knobPos[k]?.let { if (forced[it] == null) forced[it] = why }
        val on = onFlags(eff)
        val st = Array(ix.n) { FState.OFF }
        val why = arrayOfNulls<String>(ix.n)
        resolveIdx(on, forced, st, why)
        val use = IntArray(RES.size)
        // Kritik durum: kritik ısınma ya da aşırı yük. Yalnızca o zaman arayüz hareketi tamamen durdurulabilir (tam efektler her zaman önce).
        val severe = ctx.facts.thermal >= 4 || load == Load.OVERLOAD
        // Bütçe: en çok taşan kaynaktan başlayarak kısılabilir özellikler tek tek kısılır.
        var guard = 0
        while (guard++ < ix.n) {
            usageIdx(st, use)
            var over = -1; var worst = 0
            for (r in use.indices) { val d = use[r] - cap[r]; if (d > worst) { worst = d; over = r } }
            if (over < 0) break
            var pick = -1
            for (i in ix.sheddable) {
                if (st[i] != FState.ACTIVE || ix.cost[i][over] <= 0) continue
                if (ix.order[i].knob == Knob.MOTION && !severe) continue     // hareketi tamamen durdurmak yalnızca kritik durumda
                if (pick < 0 || better(i, pick, over)) pick = i
            }
            if (pick < 0) break
            forced[pick] = "bütçe: " + RES[over].name.lowercase()
            resolveIdx(on, forced, st, why)
        }
        usageIdx(st, use)
        // Motorun kapattığı: kısılan, boşa çıkan ve bunlara dayandığı için uyuyan (ör. hareket durunca tam efektler de durur).
        val byEngine = BooleanArray(ix.n)
        for (i in 0 until ix.n) byEngine[i] = st[i] == FState.SHED || st[i] == FState.SUPERSEDED ||
            (st[i] == FState.DORMANT && on[i] && ix.needs[i].any { byEngine[it] })
        val off = LinkedHashMap<Knob, String>()
        for (k in Knob.values()) {
            val i = ix.knobPos[k] ?: continue
            if (byEngine[i]) off[k] = if (st[i] == FState.DORMANT) "bağlı olduğu iş kısıldı" else why[i] ?: "?"
        }
        val states = LinkedHashMap<String, FState>(ix.n * 2)
        val reasons = HashMap<String, String>()
        for (i in 0 until ix.n) { states[ix.order[i].id] = st[i]; why[i]?.let { reasons[ix.order[i].id] = it } }
        val usage = HashMap<Res, Int>(); for (r in RES.indices) usage[RES[r]] = use[r]
        val memTight = use[Res.MEM.ordinal] > cap[Res.MEM.ordinal]
        val idle = when {
            load == Load.OVERLOAD -> 0.5f
            load == Load.BUSY || memTight || ctx.heapPct >= 85 -> 0.75f
            else -> 1f
        }
        val flow = when {
            ctx.heapPct >= 93 -> 0.6f
            ctx.heapPct >= 85 || memTight -> 0.8f
            else -> 1f
        }
        val tick = when {
            load == Load.OVERLOAD || ctx.facts.thermal >= 3 -> 3
            ctx.facts.batterySaver || ctx.facts.thermal >= 2 -> 2
            else -> 1
        }
        val notes = ArrayList<String>()
        if (eff !== s) notes += "otomatik koruma önlemleri hesaba katıldı: " + ctx.shield.joinToString(",") { it.name }
        for (t in ix.tension) {
            val a = ix.pos.getValue(t.a); val b = ix.pos.getValue(t.b)
            if (st[a] == FState.ACTIVE && st[b] == FState.ACTIVE) notes += "gerilim: ${t.a} + ${t.b} — ${t.why}"
        }
        return HarmonyPlan(load, states, reasons, off, usage, capMap, idle, tick, flow, notes)
    }

    /** Kısma önceliği: önce süs, sonra değeri düşük, sonra o kaynağa yükü büyük, eşitlikte kimlik sırası (belirlenimci). */
    private fun better(a: Int, b: Int, r: Int): Boolean {
        val fa = HarmonyIndex.order[a]; val fb = HarmonyIndex.order[b]
        if (fa.tier != fb.tier) return fa.tier.ordinal > fb.tier.ordinal
        if (fa.value != fb.value) return fa.value < fb.value
        val ca = HarmonyIndex.cost[a][r]; val cb = HarmonyIndex.cost[b][r]
        if (ca != cb) return ca > cb
        return fa.id < fb.id
    }

    /** Ağ geçidine uygulanan değerler: ayar AÇIK ve plan izin veriyorsa açık. Kapatılmış bir ayar asla açılmaz. */
    fun applyTo(c: GwConfig, s: AppSettings, p: HarmonyPlan, compatHedge: Boolean) {
        c.udpDecoy = s.udpDecoy && p.allows(Knob.UDP_DECOY)
        c.quicSplit = s.quicSplit && p.allows(Knob.QUIC_SPLIT)
        c.autoTtl = p.allows(Knob.AUTO_TTL)
        c.ja3 = p.allows(Knob.JA3)
        c.hedge = compatHedge && p.allows(Knob.HEDGE)
    }

    /** Boşta akış süreleri: uyum planının değeri × motorun çarpanı (en az 5 sn). */
    fun idle(ms: Long, p: HarmonyPlan): Long = maxOf(5_000L, (ms * p.idleScale).toLong())

    /** Açık akış sınırı: uyum planının değeri × motorun çarpanı (cihaz uyum katmanının tabanının altına inmez). */
    fun flows(max: Int, floor: Int, p: HarmonyPlan): Int = maxOf(floor, (max * p.flowScale).toInt())
}

/**
 * Canlı yük değerlendirmesi (salınımsız): bir seviyeye çıkmak için [UP] ardışık ölçüm, inmek için [DOWN] ardışık sakin ölçüm gerekir.
 * Sinyaller: DNS gecikmesi (ağın kendi olağanına göre) ve EĞİLİMİ (art arda yükselen ve bir sonraki ölçümde eşiği geçecek gecikme
 * erkenden "yoğun" sayılır), akış tablosu doluluğu, iç hata artışı, yığın belleği, zamanlayıcı gecikmesi (işlemci açlığı; 5 dakikadan
 * uzunu uyku sayılır). Otomatik korumanın akış seli önlemi beklemeden aşırı yük demektir.
 */
class HarmonyGovernor {
    @Volatile var load = Load.SMOOTH
        private set
    private var base = 0.0
    private var lastErrors = -1L
    private var lastAt = -1L
    private var upStreak = 0
    private var downStreak = 0
    private var pending = Load.SMOOTH
    private var prev1 = 0
    private var prev2 = 0

    /** Gecikme tabanı (ms). */
    val baseMs: Int get() = base.toInt()

    @Synchronized fun reset() { load = Load.SMOOTH; base = 0.0; lastErrors = -1L; lastAt = -1L; upStreak = 0; downStreak = 0; pending = Load.SMOOTH; prev1 = 0; prev2 = 0 }

    /** Ağ başına öğrenilen taban (yük seviyesi değil: o, o anın durumudur). */
    @Synchronized fun exportBase(): Double = base
    @Synchronized fun importBase(b: Double) { if (b > 0) base = b }

    private fun busyAt(): Double = maxOf(base * 3, base + 150)
    private fun overAt(): Double = maxOf(base * 6, base + 400)

    /** Tek ölçümün gösterdiği seviye (geçmişsiz; zamanlayıcı gecikmesi için önceki ölçüm anına bakar). */
    internal fun instant(x: LoadSample): Load {
        var lvl = Load.SMOOTH
        fun raise(l: Load) { if (l.ordinal > lvl.ordinal) lvl = l }
        if (x.maxTcp > 0) { val r = x.tcpFlows.toDouble() / x.maxTcp; if (r >= 0.95) raise(Load.OVERLOAD) else if (r >= 0.85) raise(Load.BUSY) }
        if (x.maxUdp > 0) { val r = x.udpFlows.toDouble() / x.maxUdp; if (r >= 0.95) raise(Load.OVERLOAD) else if (r >= 0.85) raise(Load.BUSY) }
        if (x.dnsMs > 0 && base > 0) {
            if (x.dnsMs >= overAt()) raise(Load.OVERLOAD) else if (x.dnsMs >= busyAt()) raise(Load.BUSY)
        }
        if (x.internalErrors >= 0 && lastErrors >= 0) {
            val d = x.internalErrors - lastErrors
            if (d >= 20) raise(Load.OVERLOAD) else if (d >= 3) raise(Load.BUSY)
        }
        if (x.heapPct >= 93) raise(Load.OVERLOAD) else if (x.heapPct >= 85) raise(Load.BUSY)
        if (x.atMs >= 0 && lastAt >= 0 && x.periodMs > 0) {
            val lag = (x.atMs - lastAt) - x.periodMs
            if (lag in 8_000L..300_000L) raise(Load.OVERLOAD) else if (lag in 2_000L..300_000L) raise(Load.BUSY)
        }
        return lvl
    }

    /** Eğilim: üç ardışık yükselen ölçüm, son ölçüm tabanın en az iki katı ve doğrusal uzatma bir sonraki ölçümde "yoğun" eşiğini geçiyor. */
    private fun rising(x: Int): Boolean =
        base > 0 && prev2 > 0 && x > prev1 && prev1 > prev2 && x >= base * 2 && x + (x - prev1) >= busyAt()

    @Synchronized fun sample(x: LoadSample): Load {
        var now = instant(x)
        // Eğilim üç ardışık yükselişin kendisidir (zaten sürmüş bir sinyal): ek onay beklemeden "yoğun"a geçilir.
        val trend = now == Load.SMOOTH && x.dnsMs > 0 && rising(x.dnsMs)
        if (trend) now = Load.BUSY
        if (x.internalErrors >= 0) lastErrors = x.internalErrors
        if (x.atMs >= 0) lastAt = x.atMs
        if (x.dnsMs > 0) {
            base = if (base <= 0 || x.dnsMs < base) x.dnsMs.toDouble() else minOf(x.dnsMs.toDouble(), base * (if (now == Load.SMOOTH) 1.02 else 1.06))
            prev2 = prev1; prev1 = x.dnsMs
        }
        if (x.shieldFlood) {
            // Koruma akış seli görüyor: beklemeden aşırı yük (saldırı/kaçak uygulama sürerken ek işlere yer yok).
            load = Load.OVERLOAD; upStreak = 0; downStreak = 0
            return load
        }
        if (trend && load == Load.SMOOTH) { load = Load.BUSY; upStreak = 0; downStreak = 0; return load }
        when {
            now.ordinal > load.ordinal -> {
                downStreak = 0
                pending = if (upStreak == 0 || now.ordinal < pending.ordinal) now else pending
                if (++upStreak >= UP) { load = pending; upStreak = 0 }
            }
            now.ordinal < load.ordinal -> {
                upStreak = 0
                if (++downStreak >= DOWN) { load = Load.values()[load.ordinal - 1]; downStreak = 0 }
            }
            else -> { upStreak = 0; downStreak = 0 }
        }
        return load
    }

    companion object {
        const val UP = 2
        const val DOWN = 3
    }
}

/**
 * Etkinlik sigortaları: bir isteğe bağlı iş bu ağda işe yaramıyorsa (çok denendi, neredeyse hiç kazanmadı) bir süre kapatılır.
 *  - Yedek bağlantı (hedge): açılan yedeklerden kaçı asıl bağlantıyı geçti.
 *  - DNS yarışı: yarışların kaçında ikinci sunucu önce cevap verdi.
 * Pencere [MIN_TRIES] denemede değerlendirilir; kazanç oranı [MIN_RATIO] altındaysa sigorta atar: 15 dk, tekrarında iki katı (en çok 2 sa).
 * Süre dolunca yeniden denenir (yarı açık); iyi giderse ceza azalır. Durum ağ başına saklanır ([export]/[import]).
 */
class HarmonyBreakers {
    private class B { var lastTries = -1L; var lastWins = -1L; var tries = 0L; var wins = 0L; var openUntil = 0L; var strikes = 0 }
    private val map = HashMap<Knob, B>()

    /** Ağ başına saklanan özet: ceza sayısı ve açık kalma sonu (sayaç tabanları değil: sayaçlar yönlendiriciyle birlikte değişir). */
    class Saved(val strikes: Map<Knob, Int>, val openUntil: Map<Knob, Long>)

    @Synchronized fun reset() { map.clear() }

    @Synchronized fun export(): Saved = Saved(map.mapValues { it.value.strikes }, map.mapValues { it.value.openUntil })

    @Synchronized fun import(s: Saved) {
        map.clear()
        for ((k, n) in s.strikes) map.getOrPut(k) { B() }.strikes = n
        for ((k, u) in s.openUntil) map.getOrPut(k) { B() }.openUntil = u
    }

    @Synchronized fun observe(e: Efficacy, now: Long) {
        feed(Knob.HEDGE, e.hedged, e.hedgeWon, now)
        feed(Knob.DNS_RACE, e.races, e.raceWins, now)
    }

    private fun feed(k: Knob, tries: Long, wins: Long, now: Long) {
        if (tries < 0 || wins < 0) return
        val b = map.getOrPut(k) { B() }
        if (b.lastTries < 0 || tries < b.lastTries || wins < b.lastWins) { b.lastTries = tries; b.lastWins = wins; return }   // ilk ölçüm ya da sayaç sıfırlandı
        b.tries += tries - b.lastTries; b.wins += wins - b.lastWins
        b.lastTries = tries; b.lastWins = wins
        if (now < b.openUntil || b.tries < MIN_TRIES) return
        if (b.wins.toDouble() / b.tries < MIN_RATIO) {
            b.strikes++
            b.openUntil = now + minOf(MAX_OPEN_MS, BASE_OPEN_MS shl (b.strikes - 1).coerceAtMost(4))
        } else if (b.strikes > 0) b.strikes--
        b.tries = 0; b.wins = 0
    }

    @Synchronized fun open(now: Long): Map<Knob, String> {
        val out = LinkedHashMap<Knob, String>()
        for ((k, b) in map) if (now < b.openUntil) out[k] = "bu ağda etkisiz (sigorta)"
        return out
    }

    companion object {
        const val MIN_TRIES = 30L
        const val MIN_RATIO = 0.05
        const val BASE_OPEN_MS = 15 * 60_000L
        const val MAX_OPEN_MS = 2 * 60 * 60_000L
    }
}

/** Motorun kendi ölçümleri (iç günlük): kaç plan hesaplandı, kaçı bellekten geldi, hesap süresi, hata sayısı. */
class HarmonyStats {
    @Volatile var computed = 0L; internal set
    @Volatile var memoHits = 0L; internal set
    @Volatile var failures = 0L; internal set
    @Volatile var lastMicros = 0L; internal set
    @Volatile var maxMicros = 0L; internal set
    fun line(): String = "motor: $computed hesap, $memoHits bellekten, son ${lastMicros} µs, en çok ${maxMicros} µs" + if (failures > 0) ", $failures hata (son iyi plan kullanıldı)" else ""
}

/**
 * Uyum motoru (durumlu kabuk). [HarmonyCore]'u yük ([HarmonyGovernor]) ve etkinlik sigortalarıyla ([HarmonyBreakers]) besler ve:
 *  - SALINIMI önler: kısılan bir iş en az [DWELL_MS] kısılı kalır; yeniden kısma anında.
 *  - HIZLIDIR: girdiler (ayar, ortam, yük, sigortalar) değişmediyse plan yeniden hesaplanmaz.
 *  - AĞ BAŞINA ÖĞRENİR: gecikme tabanı ve sigortalar ağ anahtarına göre saklanır ([MAX_NETS] ağ); bilinen bir ağa dönünce yeniden
 *    öğrenmeden kaldığı yerden devam eder.
 *  - HATAYA DAYANIKLIDIR: hesap bir istisna atarsa son iyi plan (yoksa hiçbir şeyi kısmayan plan) kullanılır; motor asla servisi
 *    düşürmez ya da korumayı bozmaz.
 * Arka planda çalışır; kullanıcıya hiçbir şey göstermez, yalnızca iç günlüğe yazar.
 */
class HarmonyEngine(
    private val compute: (AppSettings, HarmonyContext, Load, Map<Knob, String>) -> HarmonyPlan = { s, c, l, b -> HarmonyCore.compute(s, c, l, b) },
) {
    val governor = HarmonyGovernor()
    val breakers = HarmonyBreakers()
    val stats = HarmonyStats()
    private val shedSince = HashMap<Knob, Long>()
    private var last: HarmonyPlan = HarmonyPlan.NONE
    private var memoKey: Any? = null
    private var memoPlan: HarmonyPlan? = null
    private var netKey = ""
    private var netHandle = 0L
    private val nets = object : LinkedHashMap<String, Pair<Double, HarmonyBreakers.Saved>>(16, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Pair<Double, HarmonyBreakers.Saved>>?) = size > MAX_NETS
    }

    @Synchronized fun observe(sample: LoadSample, eff: Efficacy, now: Long) {
        governor.sample(sample)
        breakers.observe(eff, now)
    }

    @Synchronized fun plan(s: AppSettings, ctx: HarmonyContext, now: Long): HarmonyPlan {
        val broken = breakers.open(now)
        val key = listOf(s, ctx, governor.load, broken, DeviceTune.rev)     // grafik DeviceTune'u da okur (efektler)
        val raw = memoPlan.takeIf { key == memoKey }?.also { stats.memoHits++ } ?: try {
            val t0 = System.nanoTime()
            val p = compute(s, ctx, governor.load, broken)
            val us = (System.nanoTime() - t0) / 1000
            stats.computed++; stats.lastMicros = us; if (us > stats.maxMicros) stats.maxMicros = us
            memoKey = key; memoPlan = p
            p
        } catch (_: Throwable) {
            stats.failures++
            return last
        }
        // Bekleme: yeni kısılanların anı kaydedilir; erken geri açılacak olanlar bekleme süresi dolana dek kısılı kalır.
        val off = LinkedHashMap(raw.off)
        for (k in raw.off.keys) shedSince.putIfAbsent(k, now)
        for ((k, why) in last.off) if (k !in off) {
            val since = shedSince[k] ?: now
            if (now - since < DWELL_MS && userWants(k, s)) off[k] = why else shedSince.remove(k)
        }
        val p = if (off == raw.off) raw else raw.with(off)
        last = p
        return p
    }

    /** Kullanıcı bu işi kendisi kapattıysa bekleme anlamsız (kısılı tutulacak bir şey yok). */
    private fun userWants(k: Knob, s: AppSettings): Boolean {
        val i = HarmonyIndex.knobPos[k] ?: return false
        return try { HarmonyIndex.order[i].on(s) } catch (_: Exception) { false }
    }

    /**
     * Ağ değişti. [key] ağın kimliği (ör. "MOBILE:28601", "WIFI"): eski ağın öğrendikleri saklanır, yeni ağ biliniyorsa onunki geri
     * yüklenir. Yük seviyesi her zaman sıfırdan başlar (o anın durumudur, ağın özelliği değil).
     */
    @Synchronized fun networkChanged(key: String = "", handle: Long = 0L) {
        // Aynı ağın yetenek/bağlantı olayı tekrar ederse (Android sık yapar) öğrenilenler silinmez.
        if (handle != 0L && key == netKey && handle == netHandle) return
        netHandle = handle
        if (netKey.isNotEmpty()) nets[netKey] = governor.exportBase() to breakers.export()
        governor.reset(); breakers.reset()
        netKey = key
        nets[key]?.let { (b, br) -> governor.importBase(b); breakers.import(br) }
        memoKey = null
    }

    /** Bilinen ağ sayısı (testler/günlük). */
    @Synchronized fun knownNetworks(): Int = nets.size + (if (netKey.isNotEmpty() && netKey !in nets) 1 else 0)

    companion object {
        const val DWELL_MS = 90_000L
        const val MAX_NETS = 8
    }
}

/** Servisin en son uyguladığı plan: ağ geçidi, DNS yönlendiricileri, arayüz (efektler) ve arka plan işleri aynı planı okur. */
object HarmonyLive {
    @Volatile var plan: HarmonyPlan = HarmonyPlan.NONE
    fun allows(k: Knob): Boolean = plan.allows(k)
    fun reset() { plan = HarmonyPlan.NONE }
}
