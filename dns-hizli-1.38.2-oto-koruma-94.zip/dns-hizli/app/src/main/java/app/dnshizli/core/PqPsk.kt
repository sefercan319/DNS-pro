package app.dnshizli.core

import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Kuantum sonrası PSK (PQ1) — istemci tarafı. Stealth kanalında aktarıcıyla ML-KEM-768 değişimi yapılır; aktarıcı sunucudaki WireGuard
 * eşinin PresharedKey'ini, istemci de kendi tünelininkini aynı türetilmiş değere ayarlar. WireGuard'ın X25519 el sıkışması ileride
 * kuantum bilgisayarla kırılsa bile (bugün kaydedilen trafik için) PSK bilinmeden oturum anahtarları çıkarılamaz. Biçim: tools/stealth/sunucu/pq.go.
 *
 * Temel PSK yapılandırmadaki PresharedKey'dir: istek ve cevap onunla doğrulanır (yol + sabitlenmiş TLS'e ek olarak), oturum PSK'si
 * hem ML-KEM sırrına hem temel PSK'ye bağlıdır (ikisinden biri sızsa da yetmez).
 */
object PqPsk {
    private val KEM = MlKem.ML_KEM_768
    val REQ_LEN = 4 + 8 + 32 + KEM.ekSize + 32
    val RESP_LEN = 4 + KEM.ctSize + 32
    private val REQ = byteArrayOf(0xF0.toByte(), 'P'.code.toByte(), 'Q'.code.toByte(), '1'.code.toByte())
    private val RESP = byteArrayOf(0xF1.toByte(), 'P'.code.toByte(), 'Q'.code.toByte(), '1'.code.toByte())
    private val ERR = byteArrayOf(0xF2.toByte(), 'P'.code.toByte(), 'Q'.code.toByte(), '1'.code.toByte())

    class Pending internal constructor(val request: ByteArray, internal val dk: ByteArray, internal val base: ByteArray, internal val pub: ByteArray)

    sealed class Result {
        class Ok(val psk: ByteArray) : Result()
        /** Aktarıcının hata kodu (1 eş/mac, 2 saat/tekrar, 3 wg ayarlanamadı, 4 biçim) ya da 0: cevap bozuk/doğrulanamadı. */
        class Fail(val code: Int) : Result()
    }

    internal fun hmac(key: ByteArray, label: String, vararg parts: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA256"); m.init(SecretKeySpec(key, "HmacSHA256"))
        m.update(label.toByteArray(Charsets.US_ASCII)); for (p in parts) m.update(p)
        return m.doFinal()
    }

    fun start(basePsk: ByteArray, clientPub: ByteArray, unixSec: Long, rng: SecureRandom = SecureRandom()): Pending {
        val kp = KEM.keyGen(rng)
        val body = ByteArray(REQ_LEN - 32)
        System.arraycopy(REQ, 0, body, 0, 4)
        for (i in 0 until 8) body[4 + i] = (unixSec ushr (56 - 8 * i)).toByte()
        System.arraycopy(clientPub, 0, body, 12, 32)
        System.arraycopy(kp.ek, 0, body, 44, KEM.ekSize)
        return Pending(body + hmac(basePsk, "dhs-pq1-istek", body), kp.dk, basePsk.copyOf(), clientPub.copyOf())
    }

    /** Aktarıcının cevabı denetim iletisi mi (WireGuard paketi değil)? */
    fun isControl(b: ByteArray, len: Int): Boolean =
        len >= 4 && ((b[0] == RESP[0] || b[0] == ERR[0]) && b[1] == RESP[1] && b[2] == RESP[2] && (b[3] == RESP[3] || b[3] == '2'.code.toByte()) ||
            len >= 5 && b[0] == KEY_RESP[0] && Wg.eq(b, 1, KEY_RESP, 1, 4))

    // ------------------------------------------------------------------ PQ2: kuantum sonrası sunucu kimliği (kalıcı ML-KEM anahtarı)
    val REQ_LEN2 = 4 + 8 + 32 + KEM.ekSize + KEM.ctSize + 32
    val RESP_LEN2 = 4 + KEM.ctSize + 32
    private val KEY_REQ = byteArrayOf(0xF6.toByte(), 'K'.code.toByte(), 'E'.code.toByte(), 'Y'.code.toByte(), '2'.code.toByte())
    private val KEY_RESP = byteArrayOf(0xF7.toByte(), 'K'.code.toByte(), 'E'.code.toByte(), 'Y'.code.toByte(), '2'.code.toByte())
    private val REQ2 = byteArrayOf(0xF0.toByte(), 'P'.code.toByte(), 'Q'.code.toByte(), '2'.code.toByte())
    private val RESP2 = byteArrayOf(0xF1.toByte(), 'P'.code.toByte(), 'Q'.code.toByte(), '2'.code.toByte())
    /** Kalıcı anahtarın özeti sabitlenenle uyuşmadı: aktarıcı taklit ediliyor olabilir (bu oturum kullanılmamalı). */
    const val FAIL_IDENTITY = 6

    class Pending2 internal constructor(val request: ByteArray, internal val dk: ByteArray, internal val base: ByteArray, internal val pub: ByteArray, internal val ssStatic: ByteArray)

    fun start2(basePsk: ByteArray, clientPub: ByteArray, staticEk: ByteArray, unixSec: Long, rng: SecureRandom = SecureRandom()): Pending2? {
        val eph = KEM.keyGen(rng)
        val st = KEM.encapsulate(staticEk, rng) ?: return null
        val body = ByteArray(REQ_LEN2 - 32)
        System.arraycopy(REQ2, 0, body, 0, 4)
        for (i in 0 until 8) body[4 + i] = (unixSec ushr (56 - 8 * i)).toByte()
        System.arraycopy(clientPub, 0, body, 12, 32)
        System.arraycopy(eph.ek, 0, body, 44, KEM.ekSize)
        System.arraycopy(st.ct, 0, body, 44 + KEM.ekSize, KEM.ctSize)
        return Pending2(body + hmac(basePsk, "dhs-pq2-istek", body), eph.dk, basePsk.copyOf(), clientPub.copyOf(), st.key)
    }

    /** Cevabın doğrulama anahtarı kalıcı kapsülün sırrından türer: yalnızca gerçek aktarıcı geçerli cevap üretebilir. */
    fun finish2(p: Pending2, b: ByteArray, len: Int): Result {
        try {
            if (len == 5 && Wg.eq(b, 0, ERR, 0, 4)) return Result.Fail(b[4].toInt() and 0xFF)
            if (len != RESP_LEN2 || !Wg.eq(b, 0, RESP2, 0, 4)) return Result.Fail(0)
            val reqMac = p.request.copyOfRange(REQ_LEN2 - 32, REQ_LEN2)
            val auth = hmac(p.base, "dhs-pq2-kimlik", p.ssStatic)
            val want = hmac(auth, "dhs-pq2-cevap", b.copyOfRange(0, len - 32), reqMac)
            if (!Wg.eq(want, 0, b, len - 32, 32)) return Result.Fail(FAIL_IDENTITY)
            val ssE = KEM.decapsulate(p.dk, b.copyOfRange(4, 4 + KEM.ctSize)) ?: return Result.Fail(0)
            return Result.Ok(hmac(p.base, "dhs-pq2-psk", ssE, p.ssStatic, p.pub, reqMac).also { ssE.fill(0) })
        } finally { p.dk.fill(0); p.ssStatic.fill(0) }
    }

    /** PQ2: kalıcı anahtarı ister, özetini [staticPin] ile denetler, sonra değişimi yapar. */
    fun exchange2(s: StealthSession, basePsk: ByteArray, clientPub: ByteArray, staticPin: ByteArray, unixSec: Long, timeoutMs: Int = 5000, rng: SecureRandom = SecureRandom()): Result {
        val buf = ByteArray(Ws.MAX_PAYLOAD)
        s.setReadTimeout(timeoutMs)
        var pending: Pending2? = null
        try {
            s.send(KEY_REQ)
            val n = awaitControl(s, buf, timeoutMs) ?: return Result.Fail(0)
            if (n == 5 && Wg.eq(buf, 0, ERR, 0, 4)) return Result.Fail(buf[4].toInt() and 0xFF)
            if (n != 5 + KEM.ekSize || !Wg.eq(buf, 0, KEY_RESP, 0, 5)) return Result.Fail(0)
            val ek = buf.copyOfRange(5, n)
            if (!java.security.MessageDigest.isEqual(java.security.MessageDigest.getInstance("SHA-256").digest(ek), staticPin)) return Result.Fail(FAIL_IDENTITY)
            val p = start2(basePsk, clientPub, ek, unixSec, rng) ?: return Result.Fail(FAIL_IDENTITY)
            pending = p
            s.send(p.request)
            val m = awaitControl(s, buf, timeoutMs) ?: return Result.Fail(0)
            return finish2(p, buf, m)
        } catch (_: java.io.IOException) {
            return Result.Fail(0)
        } finally {
            pending?.let { it.dk.fill(0); it.ssStatic.fill(0) }                   // zaman aşımı / hata yolunda da sırlar silinir
            try { s.setReadTimeout(0) } catch (_: Exception) {}
        }
    }

    private fun awaitControl(s: StealthSession, buf: ByteArray, timeoutMs: Int): Int? {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val n = s.receive(buf)
            if (n < 0) return null
            if (isControl(buf, n)) return n
        }
        return null
    }

    fun finish(p: Pending, b: ByteArray, len: Int): Result {
        try {
            if (len == 5 && Wg.eq(b, 0, ERR, 0, 4)) return Result.Fail(b[4].toInt() and 0xFF)
            if (len != RESP_LEN || !Wg.eq(b, 0, RESP, 0, 4)) return Result.Fail(0)
            val reqMac = p.request.copyOfRange(REQ_LEN - 32, REQ_LEN)
            val want = hmac(p.base, "dhs-pq1-cevap", b.copyOfRange(0, len - 32), reqMac)
            if (!Wg.eq(want, 0, b, len - 32, 32)) return Result.Fail(0)
            val ss = KEM.decapsulate(p.dk, b.copyOfRange(4, 4 + KEM.ctSize)) ?: return Result.Fail(0)
            return Result.Ok(hmac(p.base, "dhs-pq1-psk", ss, p.pub, reqMac).also { ss.fill(0) })
        } finally { p.dk.fill(0) }
    }

    /** Açık bir Stealth oturumunda değişimi yapar (en çok [timeoutMs] bekler). */
    fun exchange(s: StealthSession, basePsk: ByteArray, clientPub: ByteArray, unixSec: Long, timeoutMs: Int = 5000, rng: SecureRandom = SecureRandom()): Result {
        val p = start(basePsk, clientPub, unixSec, rng)
        val buf = ByteArray(Ws.MAX_PAYLOAD)                     // araya büyük WireGuard çerçevesi girse de akış bozulmaz
        s.setReadTimeout(timeoutMs)
        try {
            s.send(p.request)
            val deadline = System.currentTimeMillis() + timeoutMs
            while (System.currentTimeMillis() < deadline) {
                val n = s.receive(buf)
                if (n < 0) return Result.Fail(0)
                if (isControl(buf, n)) return finish(p, buf, n)
                // denetim cevabından önce gelen WireGuard paketi (olağan dışı): yok sayılır
            }
            return Result.Fail(0)
        } catch (_: java.io.IOException) {
            return Result.Fail(0)
        } finally { p.dk.fill(0); try { s.setReadTimeout(0) } catch (_: Exception) {} }     // her çıkışta açma anahtarı silinir
    }
}
