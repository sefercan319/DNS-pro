package app.dnshizli.core

import java.security.SecureRandom

/**
 * WireGuard el sıkışması (Noise_IKpsk2_25519_ChaChaPoly_BLAKE2s) ve taşıma oturumu, WireGuard tanım belgesinin (whitepaper §5.4)
 * birebir uygulaması; dış kütüphane yok. Hem başlatıcı (istemci) hem yanıtlayıcı (testler ve bize özel aktarıcı/sunucu) tarafı vardır.
 * Rastgelelik ve saat dışarıdan verilebilir: sınama vektörleri bağımsız bir uygulamayla (tools/wg-referans) baytı baytına karşılaştırılır.
 */
object Wg {
    val CONSTRUCTION = "Noise_IKpsk2_25519_ChaChaPoly_BLAKE2s".toByteArray()
    val IDENTIFIER = "WireGuard v1 zx2c4 Jason@zx2c4.com".toByteArray()
    val LABEL_MAC1 = "mac1----".toByteArray()
    val LABEL_COOKIE = "cookie--".toByteArray()

    const val TYPE_INITIATION = 1
    const val TYPE_RESPONSE = 2
    const val TYPE_COOKIE = 3
    const val TYPE_DATA = 4
    const val INITIATION_LEN = 148
    const val RESPONSE_LEN = 92
    const val COOKIE_LEN = 64
    const val DATA_HEADER = 16
    const val TAG = 16

    // Zamanlayıcılar (whitepaper §6.1)
    const val REKEY_AFTER_MESSAGES = 1L shl 60
    const val REJECT_AFTER_MESSAGES = (-1L ushr 1) - (1L shl 13)       // 2^64 - 2^13 - 1 yerine işaretli sınır: pratikte ulaşılmaz
    const val REKEY_AFTER_TIME_MS = 120_000L
    const val REJECT_AFTER_TIME_MS = 180_000L
    const val REKEY_ATTEMPT_TIME_MS = 90_000L
    const val REKEY_TIMEOUT_MS = 5_000L
    const val KEEPALIVE_TIMEOUT_MS = 10_000L
    const val COOKIE_LIFETIME_MS = 120_000L

    internal val INIT_C: ByteArray = Blake2s.hash(CONSTRUCTION)
    internal val INIT_H: ByteArray = Blake2s.hash(INIT_C, IDENTIFIER)

    fun publicKey(priv: ByteArray): ByteArray = X25519.publicKey(clamp(priv))
    /** Özel anahtar kırpması (RFC 7748); WireGuard anahtarları zaten kırpılmış üretilir, girdi her ihtimale karşı kırpılır. */
    fun clamp(k: ByteArray): ByteArray { val c = k.copyOf(); c[0] = (c[0].toInt() and 248).toByte(); c[31] = ((c[31].toInt() and 127) or 64).toByte(); return c }
    fun generatePrivate(rng: SecureRandom = SecureRandom()): ByteArray = clamp(ByteArray(32).also { rng.nextBytes(it) })

    internal fun dh(priv: ByteArray, pub: ByteArray): ByteArray? = X25519.shared(clamp(priv), pub)?.takeIf { s -> s.any { it.toInt() != 0 } }

    /** TAI64N zaman damgası: 8 bayt (2^62 + saniye, büyük-sonlu) + 4 bayt nanosaniye. */
    fun tai64n(epochMs: Long): ByteArray {
        val out = ByteArray(12)
        val s = (1L shl 62) + epochMs / 1000
        val ns = ((epochMs % 1000) * 1_000_000L).toInt()
        for (i in 0 until 8) out[i] = (s ushr (56 - 8 * i)).toByte()
        for (i in 0 until 4) out[8 + i] = (ns ushr (24 - 8 * i)).toByte()
        return out
    }

    internal fun le32(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)
    internal fun put32(b: ByteArray, o: Int, v: Int) { b[o] = v.toByte(); b[o + 1] = (v ushr 8).toByte(); b[o + 2] = (v ushr 16).toByte(); b[o + 3] = (v ushr 24).toByte() }
    internal fun le64(b: ByteArray, o: Int): Long { var v = 0L; for (i in 7 downTo 0) v = (v shl 8) or (b[o + i].toLong() and 0xFF); return v }
    internal fun put64(b: ByteArray, o: Int, v: Long) { for (i in 0 until 8) b[o + i] = (v ushr (8 * i)).toByte() }

    internal fun mac1Key(pub: ByteArray) = Blake2s.hash(LABEL_MAC1, pub)
    internal fun cookieKey(pub: ByteArray) = Blake2s.hash(LABEL_COOKIE, pub)

    /** Sabit zamanlı eşitlik. */
    internal fun eq(a: ByteArray, ao: Int, b: ByteArray, bo: Int, n: Int): Boolean { var d = 0; for (i in 0 until n) d = d or (a[ao + i].toInt() xor b[bo + i].toInt()); return d == 0 }
}

/** Kurulmuş bir taşıma oturumu: anahtarlar, dizinler, sayaçlar, tekrar penceresi. */
class WgSession internal constructor(
    private val sendKey: ByteArray,
    private val recvKey: ByteArray,
    val localIndex: Int,
    val remoteIndex: Int,
    val isInitiator: Boolean,
    val createdMs: Long,
) {
    private var sendCounter = 0L
    private val replay = WgReplay()
    @Volatile var lastReceivedMs = createdMs; private set
    @Volatile var lastSentMs = createdMs; private set
    /** Yanıtlayıcı oturumu, başlatıcıdan ilk veri gelene dek gönderim için kullanılamaz (whitepaper §5.4.6). */
    @Volatile var confirmed = isInitiator; private set

    val sent: Long get() = sendCounter

    /** Anahtar yenilenmeli mi (başlatıcı: 120 sn ya da 2^60 ileti)? */
    fun shouldRekey(nowMs: Long): Boolean = isInitiator && (nowMs - createdMs >= Wg.REKEY_AFTER_TIME_MS || sendCounter >= Wg.REKEY_AFTER_MESSAGES)
    /** Oturum artık kullanılamaz (180 sn ya da sayaç sınırı). */
    fun expired(nowMs: Long): Boolean = nowMs - createdMs >= Wg.REJECT_AFTER_TIME_MS || sendCounter >= Wg.REJECT_AFTER_MESSAGES

    /**
     * IP paketini ([p][off, off+len); boş = canlı tutma) şifreler: tür 4 başlığı + sayaç + 16'nın katına doldurulmuş şifreli metin.
     * Oturum kullanılamıyorsa null.
     */
    /**
     * [padTo]: düz metin en az bu boya (16'nın katına) doldurulur — trafik gizleme ([Shaper]). WireGuard alıcısı asıl boyu iç IP başlığından
     * okur (standart sunucu da dolguyu atar); [len] 0 ve [padTo] > 0 ise sıfırlardan oluşan "örtü" paketi olur (alıcı IP sayamaz, atar).
     */
    @Synchronized fun encrypt(p: ByteArray, off: Int, len: Int, nowMs: Long, padTo: Int = 0): ByteArray? {
        if (!confirmed || expired(nowMs)) return null
        val padded = if (len == 0 && padTo <= 0) 0 else (maxOf(len, padTo) + 15) and 15.inv()
        val pt = ByteArray(padded)
        System.arraycopy(p, off, pt, 0, len)
        val ctr = sendCounter++
        val ct = ChaChaPoly.seal(sendKey, ChaChaPoly.wgNonce(ctr), ByteArray(0), pt)
        val out = ByteArray(Wg.DATA_HEADER + ct.size)
        out[0] = Wg.TYPE_DATA.toByte()
        Wg.put32(out, 4, remoteIndex)
        Wg.put64(out, 8, ctr)
        System.arraycopy(ct, 0, out, Wg.DATA_HEADER, ct.size)
        lastSentMs = nowMs
        return out
    }

    /**
     * Tür 4 iletisini açar. Dolgulu düz metni döner (IP başlığındaki uzunluk asıl boyu verir); canlı tutma için boş dizi.
     * Etiket tutmaz, tekrar ya da süre dolmuşsa null.
     */
    @Synchronized fun decrypt(m: ByteArray, off: Int, len: Int, nowMs: Long): ByteArray? {
        if (len < Wg.DATA_HEADER + Wg.TAG || m[off].toInt() != Wg.TYPE_DATA || Wg.le32(m, off + 4) != localIndex) return null
        if (nowMs - createdMs >= Wg.REJECT_AFTER_TIME_MS) return null
        val ctr = Wg.le64(m, off + 8)
        if (ctr < 0 || ctr >= Wg.REJECT_AFTER_MESSAGES || !replay.mayAccept(ctr)) return null
        val pt = ChaChaPoly.open(recvKey, ChaChaPoly.wgNonce(ctr), ByteArray(0), m, off + Wg.DATA_HEADER, len - Wg.DATA_HEADER) ?: return null
        if (!replay.accept(ctr)) return null                      // doğrulandıktan SONRA pencereye yazılır (sahte paket pencereyi kaydıramaz)
        lastReceivedMs = nowMs
        confirmed = true
        return pt
    }

    fun wipe() { sendKey.fill(0); recvKey.fill(0) }
}

/** Kayan tekrar penceresi (RFC 6479 yaklaşımı, 2048 bit): eski ya da yinelenen sayaçlar reddedilir. */
class WgReplay {
    private val bits = LongArray(WINDOW / 64)
    private var top = -1L
    fun mayAccept(c: Long): Boolean {
        if (c > top) return true
        if (top - c >= WINDOW - 64) return false
        return bits[((c / 64) % (WINDOW / 64)).toInt()] and (1L shl (c % 64).toInt()) == 0L
    }
    fun accept(c: Long): Boolean {
        if (!mayAccept(c)) return false
        if (c > top) {
            var cur = if (top < 0) -1L else top / 64
            val target = c / 64
            var steps = 0
            while (cur < target && steps < WINDOW / 64) { cur++; bits[(cur % (WINDOW / 64)).toInt()] = 0L; steps++ }
            if (target - (if (top < 0) -1L else top / 64) >= WINDOW / 64) bits.fill(0)
            top = c
        }
        val i = ((c / 64) % (WINDOW / 64)).toInt()
        bits[i] = bits[i] or (1L shl (c % 64).toInt())
        return true
    }
    companion object { const val WINDOW = 2048 }
}

/**
 * Başlatıcı (istemci) tarafı. [ephemeral] ve [nowMs] testler içindir. Çerez cevabı alınırsa sonraki başlatma iletisi mac2 taşır.
 */
class WgInitiator(
    private val staticPriv: ByteArray,
    private val peerPub: ByteArray,
    private val psk: ByteArray = ByteArray(32),
    private val rng: SecureRandom = SecureRandom(),
) {
    val staticPub: ByteArray = Wg.publicKey(staticPriv)
    private var c = ByteArray(0); private var h = ByteArray(0)
    private var ePriv = ByteArray(0); private var ePub = ByteArray(0)
    private var localIndex = 0
    private var lastMac1: ByteArray? = null
    private var cookie: ByteArray? = null
    private var cookieAt = 0L
    private val staticDh: ByteArray? = Wg.dh(staticPriv, peerPub)
    /** Son zaman damgası: aynı ya da daha eski damgalı başlatma yanıtlayıcıca reddedilir; saat geri gitse de ileri tutulur. */
    private var lastTs = ByteArray(12)

    /** Başlatma iletisi (148 bayt). Eş ortak anahtarı geçersizse (küçük alt grup) null. */
    @Synchronized fun initiation(localIndex: Int, nowMs: Long, ephemeral: ByteArray? = null, epochMs: Long = System.currentTimeMillis()): ByteArray? {
        val sDh = staticDh ?: return null
        this.localIndex = localIndex
        c = Wg.INIT_C.copyOf()
        h = Blake2s.hash(Wg.INIT_H, peerPub)
        ePriv = Wg.clamp(ephemeral ?: ByteArray(32).also { rng.nextBytes(it) })
        ePub = X25519.publicKey(ePriv)
        c = Blake2s.kdf(c, ePub, 1)[0]
        h = Blake2s.hash(h, ePub)
        val eDh = Wg.dh(ePriv, peerPub) ?: return null
        var kk = Blake2s.kdf(c, eDh, 2); c = kk[0]
        val encStatic = ChaChaPoly.seal(kk[1], ChaChaPoly.wgNonce(0), h, staticPub)
        h = Blake2s.hash(h, encStatic)
        kk = Blake2s.kdf(c, sDh, 2); c = kk[0]
        var ts = Wg.tai64n(epochMs)
        if (Wg.compareBytes(ts, lastTs) <= 0) ts = Wg.bump(lastTs)
        lastTs = ts
        val encTs = ChaChaPoly.seal(kk[1], ChaChaPoly.wgNonce(0), h, ts)
        h = Blake2s.hash(h, encTs)
        val m = ByteArray(Wg.INITIATION_LEN)
        m[0] = Wg.TYPE_INITIATION.toByte()
        Wg.put32(m, 4, localIndex)
        System.arraycopy(ePub, 0, m, 8, 32)
        System.arraycopy(encStatic, 0, m, 40, 48)
        System.arraycopy(encTs, 0, m, 88, 28)
        val mac1 = Blake2s.mac(Wg.mac1Key(peerPub), m.copyOf(116))
        System.arraycopy(mac1, 0, m, 116, 16)
        lastMac1 = mac1
        val ck = cookie
        if (ck != null && nowMs - cookieAt < Wg.COOKIE_LIFETIME_MS) System.arraycopy(Blake2s.mac(ck, m.copyOf(132)), 0, m, 132, 16)
        return m
    }

    /** Yanıtı işler; geçerliyse taşıma oturumu. */
    @Synchronized fun response(m: ByteArray, off: Int, len: Int, nowMs: Long): WgSession? {
        if (len != Wg.RESPONSE_LEN || m[off].toInt() != Wg.TYPE_RESPONSE || Wg.le32(m, off + 8) != localIndex || ePriv.isEmpty()) return null
        // mac1: bizim ortak anahtarımızla (yanıtlayıcı doğru eşi hedefliyor)
        val mac1 = Blake2s.mac(Wg.mac1Key(staticPub), m.copyOfRange(off, off + 60))
        if (!Wg.eq(mac1, 0, m, off + 60, 16)) return null
        val rEph = m.copyOfRange(off + 12, off + 44)
        var cc = Blake2s.kdf(c, rEph, 1)[0]
        var hh = Blake2s.hash(h, rEph)
        cc = Blake2s.kdf(cc, Wg.dh(ePriv, rEph) ?: return null, 1)[0]
        cc = Blake2s.kdf(cc, Wg.dh(staticPriv, rEph) ?: return null, 1)[0]
        val k3 = Blake2s.kdf(cc, psk, 3); cc = k3[0]
        hh = Blake2s.hash(hh, k3[1])
        ChaChaPoly.open(k3[2], ChaChaPoly.wgNonce(0), hh, m, off + 44, 16) ?: return null
        val t = Blake2s.kdf(cc, ByteArray(0), 2)
        val remote = Wg.le32(m, off + 4)
        ePriv.fill(0); ePriv = ByteArray(0)
        return WgSession(t[0], t[1], localIndex, remote, true, nowMs)
    }

    /** Çerez cevabı (tür 3): yanıtlayıcı yük altında; sonraki başlatma mac2 ile gider. */
    @Synchronized fun cookieReply(m: ByteArray, off: Int, len: Int, nowMs: Long): Boolean {
        if (len != Wg.COOKIE_LEN || m[off].toInt() != Wg.TYPE_COOKIE || Wg.le32(m, off + 4) != localIndex) return false
        val mac1 = lastMac1 ?: return false
        val ck = ChaChaPoly.xopen(Wg.cookieKey(peerPub), m.copyOfRange(off + 8, off + 32), mac1, m.copyOfRange(off + 32, off + 64)) ?: return false
        cookie = ck; cookieAt = nowMs
        return true
    }
}

/** Yanıtlayıcı (sunucu) tarafı: testler ve bize özel aktarıcı için. Eşler ortak anahtarlarıyla tanınır. */
class WgResponder(private val staticPriv: ByteArray, private val rng: SecureRandom = SecureRandom()) {
    val staticPub: ByteArray = Wg.publicKey(staticPriv)
    class Peer(val pub: ByteArray, val psk: ByteArray = ByteArray(32)) { internal var lastTs = ByteArray(12) }
    private val peers = ArrayList<Peer>()
    fun addPeer(p: Peer) { synchronized(peers) { peers.add(p) } }

    /** Doğrulanmış başlatma: kimin olduğu ve yanıt üretmek için gereken durum. */
    class Initiation internal constructor(val peer: Peer, val senderIndex: Int, internal val c: ByteArray, internal val h: ByteArray, internal val ePub: ByteArray)

    fun consumeInitiation(m: ByteArray, off: Int, len: Int): Initiation? {
        if (len != Wg.INITIATION_LEN || m[off].toInt() != Wg.TYPE_INITIATION) return null
        val mac1 = Blake2s.mac(Wg.mac1Key(staticPub), m.copyOfRange(off, off + 116))
        if (!Wg.eq(mac1, 0, m, off + 116, 16)) return null
        var c = Wg.INIT_C.copyOf()
        var h = Blake2s.hash(Wg.INIT_H, staticPub)
        val ePub = m.copyOfRange(off + 8, off + 40)
        c = Blake2s.kdf(c, ePub, 1)[0]
        h = Blake2s.hash(h, ePub)
        var kk = Blake2s.kdf(c, Wg.dh(staticPriv, ePub) ?: return null, 2); c = kk[0]
        val encStatic = m.copyOfRange(off + 40, off + 88)
        val sPub = ChaChaPoly.open(kk[1], ChaChaPoly.wgNonce(0), h, encStatic) ?: return null
        h = Blake2s.hash(h, encStatic)
        val peer = synchronized(peers) { peers.firstOrNull { Wg.eq(it.pub, 0, sPub, 0, 32) } } ?: return null
        kk = Blake2s.kdf(c, Wg.dh(staticPriv, sPub) ?: return null, 2); c = kk[0]
        val encTs = m.copyOfRange(off + 88, off + 116)
        val ts = ChaChaPoly.open(kk[1], ChaChaPoly.wgNonce(0), h, encTs) ?: return null
        h = Blake2s.hash(h, encTs)
        synchronized(peer) {
            if (Wg.compareBytes(ts, peer.lastTs) <= 0) return null          // tekrar oynatılan başlatma
            peer.lastTs = ts
        }
        return Initiation(peer, Wg.le32(m, off + 4), c, h, ePub)
    }

    /** Yanıt iletisi ve yanıtlayıcı oturumu (ilk veri gelene dek gönderimde kullanılamaz). */
    fun respond(i: Initiation, localIndex: Int, nowMs: Long, ephemeral: ByteArray? = null): Pair<ByteArray, WgSession>? {
        val ePriv = Wg.clamp(ephemeral ?: ByteArray(32).also { rng.nextBytes(it) })
        val ePub = X25519.publicKey(ePriv)
        var c = Blake2s.kdf(i.c, ePub, 1)[0]
        var h = Blake2s.hash(i.h, ePub)
        c = Blake2s.kdf(c, Wg.dh(ePriv, i.ePub) ?: return null, 1)[0]
        c = Blake2s.kdf(c, Wg.dh(ePriv, i.peer.pub) ?: return null, 1)[0]
        val k3 = Blake2s.kdf(c, i.peer.psk, 3); c = k3[0]
        h = Blake2s.hash(h, k3[1])
        val empty = ChaChaPoly.seal(k3[2], ChaChaPoly.wgNonce(0), h, ByteArray(0))
        val m = ByteArray(Wg.RESPONSE_LEN)
        m[0] = Wg.TYPE_RESPONSE.toByte()
        Wg.put32(m, 4, localIndex)
        Wg.put32(m, 8, i.senderIndex)
        System.arraycopy(ePub, 0, m, 12, 32)
        System.arraycopy(empty, 0, m, 44, 16)
        System.arraycopy(Blake2s.mac(Wg.mac1Key(i.peer.pub), m.copyOf(60)), 0, m, 60, 16)
        val t = Blake2s.kdf(c, ByteArray(0), 2)
        ePriv.fill(0)
        return m to WgSession(t[1], t[0], localIndex, i.senderIndex, false, nowMs)
    }

    /** Yük altında: başlatmaya çerez cevabı (tür 3). [cookie]: istemci adresinden türetilen değer (sunucu sırrıyla). */
    fun cookieReply(init: ByteArray, off: Int, cookie: ByteArray, nonce24: ByteArray): ByteArray {
        val m = ByteArray(Wg.COOKIE_LEN)
        m[0] = Wg.TYPE_COOKIE.toByte()
        Wg.put32(m, 4, Wg.le32(init, off + 4))
        System.arraycopy(nonce24, 0, m, 8, 24)
        val enc = ChaChaPoly.xseal(Wg.cookieKey(staticPub), nonce24, init.copyOfRange(off + 116, off + 132), cookie)
        System.arraycopy(enc, 0, m, 32, 32)
        return m
    }
}

internal fun Wg.compareBytes(a: ByteArray, b: ByteArray): Int {
    for (i in a.indices) { val d = (a[i].toInt() and 0xFF) - (b[i].toInt() and 0xFF); if (d != 0) return d }
    return 0
}

/** Zaman damgasını bir nanosaniye ileri alır (saat geri gitse de damgalar tekdüze artsın). */
internal fun Wg.bump(ts: ByteArray): ByteArray {
    val o = ts.copyOf()
    var i = 11
    while (i >= 0) { val v = (o[i].toInt() and 0xFF) + 1; o[i] = v.toByte(); if (v <= 0xFF) break; i-- }
    return o
}
