package app.dnshizli.core

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * QUIC (DoQ / DoH3) için kuantum sonrası karma anahtar değişimi (X25519MLKEM768) hafızası. Varsayılan açık: karma ve x25519 birlikte önerilir,
 * sunucu desteklemiyorsa x25519'u seçer (ek gidiş-dönüş yok). Karma ClientHello ile el sıkışma başarısız olursa (büyük ClientHello'yu
 * düşüren ağ/sunucu) o ad [FORGET_MS] boyunca yalnız x25519 ile denenir; güven (sertifika) hataları düşüş sebebi sayılmaz.
 */
object QuicPq {
    @Volatile var enabled = true
    const val FORGET_MS = 24 * 3600_000L
    private val noPq = ConcurrentHashMap<String, Long>()
    /** Karma grupla kurulan bağlantı sayısı (tanılama). */
    val hybridOk = AtomicLong()

    fun use(host: String, now: Long): Boolean {
        if (!enabled) return false
        val t = noPq[host.lowercase()] ?: return true
        if (now - t > FORGET_MS || now < t) { noPq.remove(host.lowercase()); return true }
        return false
    }

    fun failed(host: String, now: Long) { if (noPq.size < 256) noPq[host.lowercase()] = now }

    /** Yalnız x25519 denemesi de başarısız oldu: önceki başarısızlık karma kaynaklı değildi (ağ kesintisi gibi); ad yeniden karmaya döner. */
    fun notPqRelated(host: String) { noPq.remove(host.lowercase()) }

        fun clear() { noPq.clear(); hybridOk.set(0); enabled = true }
}
