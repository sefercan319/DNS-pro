package app.dnshizli.core

import java.security.SecureRandom

/**
 * ML-KEM (FIPS 203, kuantum sonrası anahtar kapsülleme). Saf Kotlin, dış kütüphane yok. Varsayılan ML-KEM-768 (k=3).
 * Doğrulama: NIST ACVP vektörleri (anahtar üretimi, kapsülleme, kapsül açma — geçersiz kapsülde örtük ret dahil — ve anahtar denetimleri)
 * ve Go standart kütüphanesinin crypto/mlkem'i ile karşılıklı açma (sizma41).
 *
 * Gizli değere bağlı dallanma yoktur: açmada yeniden şifreleme karşılaştırması ve örtük ret seçimi sabit zamanlıdır.
 */
class MlKem private constructor(val k: Int, private val eta1: Int, private val du: Int, private val dv: Int) {
    private val eta2 = 2

    val ekSize = 384 * k + 32
    val dkSize = 768 * k + 96
    val ctSize = 32 * (du * k + dv)

    class KeyPair(val ek: ByteArray, val dk: ByteArray)
    class Encapsulated(val ct: ByteArray, val key: ByteArray)

    // ------------------------------------------------------------------ ML-KEM (Algoritma 16-18 iç biçimleri, 19-21 dış)

    fun keyGen(rng: SecureRandom = SecureRandom()): KeyPair {
        val d = ByteArray(32).also { rng.nextBytes(it) }; val z = ByteArray(32).also { rng.nextBytes(it) }
        return keyGenInternal(d, z).also { d.fill(0) }
    }

    /** 64 baytlık tohumdan (d‖z) belirlenimci anahtar (Go crypto/mlkem NewDecapsulationKey768 ile aynı biçim). */
    fun keyFromSeed(seed: ByteArray): KeyPair { require(seed.size == 64); return keyGenInternal(seed.copyOfRange(0, 32), seed.copyOfRange(32, 64)) }

    fun keyGenInternal(d: ByteArray, z: ByteArray): KeyPair {
        val (ekPke, dkPke) = pkeKeyGen(d)
        val dk = ByteArray(dkSize)
        System.arraycopy(dkPke, 0, dk, 0, dkPke.size)
        System.arraycopy(ekPke, 0, dk, 384 * k, ekPke.size)
        System.arraycopy(Keccak.sha3_256(ekPke), 0, dk, 768 * k + 32, 32)
        System.arraycopy(z, 0, dk, 768 * k + 64, 32)
        return KeyPair(ekPke, dk)
    }

    /** Kapsülleme; ortak anahtar geçersizse (uzunluk ya da modül denetimi) null. */
    fun encapsulate(ek: ByteArray, rng: SecureRandom = SecureRandom()): Encapsulated? {
        if (!ekValid(ek)) return null
        val m = ByteArray(32).also { rng.nextBytes(it) }
        return encapsulateInternal(ek, m).also { m.fill(0) }
    }

    fun encapsulateInternal(ek: ByteArray, m: ByteArray): Encapsulated {
        val kr = Keccak.sha3_512(m, Keccak.sha3_256(ek))
        val key = kr.copyOfRange(0, 32); val r = kr.copyOfRange(32, 64)
        return Encapsulated(pkeEncrypt(ek, m, r), key)
    }

    /** Kapsülü açar. Kapsül bozuksa hata vermez: örtük ret (J(z‖c)) döner — saldırgan farkı göremez. Uzunluklar yanlışsa null. */
    fun decapsulate(dk: ByteArray, ct: ByteArray): ByteArray? {
        if (dk.size != dkSize || ct.size != ctSize || !dkValid(dk)) return null
        val dkPke = dk.copyOfRange(0, 384 * k)
        val ekPke = dk.copyOfRange(384 * k, 768 * k + 32)
        val h = dk.copyOfRange(768 * k + 32, 768 * k + 64)
        val z = dk.copyOfRange(768 * k + 64, 768 * k + 96)
        val m2 = pkeDecrypt(dkPke, ct)
        val kr = Keccak.sha3_512(m2, h)
        val k2 = kr.copyOfRange(0, 32)
        val kBar = Keccak.shake256(32, z, ct)
        val c2 = pkeEncrypt(ekPke, m2, kr.copyOfRange(32, 64))
        var diff = 0
        for (i in ct.indices) diff = diff or (ct[i].toInt() xor c2[i].toInt())
        val mask = ((diff or -diff) shr 31)                   // eşitse 0, değilse -1 (sabit zamanlı)
        return ByteArray(32) { ((k2[it].toInt() and mask.inv()) or (kBar[it].toInt() and mask)).toByte() }
    }

    /** Kapsülleme anahtarı denetimi (FIPS 203 §7.2): uzunluk + her katsayı < q (yeniden kodlama aynı olmalı). */
    fun ekValid(ek: ByteArray): Boolean {
        if (ek.size != ekSize) return false
        for (i in 0 until k) {
            val p = byteDecode(ek, 384 * i, 12)
            for (c in p) if (c >= Q) return false
        }
        return true
    }

    /** Açma anahtarı denetimi (§7.3): uzunluk + içindeki ek'nin özeti kayıtlı H ile aynı. */
    fun dkValid(dk: ByteArray): Boolean {
        if (dk.size != dkSize) return false
        val h = Keccak.sha3_256(dk.copyOfRange(384 * k, 768 * k + 32))
        return Wg.eq(h, 0, dk, 768 * k + 32, 32)
    }

    // ------------------------------------------------------------------ K-PKE (Algoritma 13-15)

    private fun matrixEntry(rho: ByteArray, i: Int, j: Int): IntArray = sampleNtt(rho, j, i)   // Â[i,j] ← SampleNTT(ρ‖j‖i)

    private fun pkeKeyGen(d: ByteArray): Pair<ByteArray, ByteArray> {
        val g = Keccak.sha3_512(d, byteArrayOf(k.toByte()))
        val rho = g.copyOfRange(0, 32); val sigma = g.copyOfRange(32, 64)
        var n = 0
        val s = Array(k) { ntt(cbd(prf(sigma, n++, eta1), eta1)) }
        val e = Array(k) { ntt(cbd(prf(sigma, n++, eta1), eta1)) }
        val ek = ByteArray(384 * k + 32)
        val dk = ByteArray(384 * k)
        for (i in 0 until k) {
            val t = IntArray(N)
            for (j in 0 until k) addTo(t, mulNtt(matrixEntry(rho, i, j), s[j]))
            addTo(t, e[i])
            byteEncode(t, 12, ek, 384 * i)
            byteEncode(s[i], 12, dk, 384 * i)
        }
        System.arraycopy(rho, 0, ek, 384 * k, 32)
        return ek to dk
    }

    private fun pkeEncrypt(ek: ByteArray, m: ByteArray, r: ByteArray): ByteArray {
        val t = Array(k) { byteDecode(ek, 384 * it, 12) }
        val rho = ek.copyOfRange(384 * k, 384 * k + 32)
        var n = 0
        val y = Array(k) { ntt(cbd(prf(r, n++, eta1), eta1)) }
        val e1 = Array(k) { cbd(prf(r, n++, eta2), eta2) }
        val e2 = cbd(prf(r, n, eta2), eta2)
        val ct = ByteArray(ctSize)
        for (i in 0 until k) {
            val acc = IntArray(N)
            for (j in 0 until k) addTo(acc, mulNtt(matrixEntry(rho, j, i), y[j]))   // Âᵀ
            val u = invNtt(acc); addTo(u, e1[i])
            byteEncode(compress(u, du), du, ct, 32 * du * i)
        }
        val acc = IntArray(N)
        for (j in 0 until k) addTo(acc, mulNtt(t[j], y[j]))
        val v = invNtt(acc); addTo(v, e2); addTo(v, decompress(byteDecode(m, 0, 1), 1))
        byteEncode(compress(v, dv), dv, ct, 32 * du * k)
        return ct
    }

    private fun pkeDecrypt(dk: ByteArray, ct: ByteArray): ByteArray {
        val acc = IntArray(N)
        for (i in 0 until k) {
            val u = ntt(decompress(byteDecode(ct, 32 * du * i, du), du))
            addTo(acc, mulNtt(byteDecode(dk, 384 * i, 12), u))
        }
        val v = decompress(byteDecode(ct, 32 * du * k, dv), dv)
        val w = invNtt(acc)
        for (i in 0 until N) w[i] = (v[i] - w[i] + Q) % Q
        val out = ByteArray(32)
        byteEncode(compress(w, 1), 1, out, 0)
        return out
    }

    // ------------------------------------------------------------------ örnekleme

    private fun prf(s: ByteArray, b: Int, eta: Int): ByteArray = Keccak.shake256(64 * eta, s, byteArrayOf(b.toByte()))

    /** Algoritma 8: merkezî binom dağılımı. */
    private fun cbd(b: ByteArray, eta: Int): IntArray {
        val f = IntArray(N)
        fun bit(i: Int) = (b[i ushr 3].toInt() ushr (i and 7)) and 1
        for (i in 0 until N) {
            var x = 0; var y = 0
            for (j in 0 until eta) { x += bit(2 * i * eta + j); y += bit(2 * i * eta + eta + j) }
            f[i] = (x - y + Q) % Q
        }
        return f
    }

    /** Algoritma 7: SHAKE128(ρ‖j‖i) akışından reddetmeli örnekleme. */
    private fun sampleNtt(rho: ByteArray, j: Int, i: Int): IntArray {
        val x = Keccak.shake128().absorb(rho).absorb(j).absorb(i)
        val a = IntArray(N)
        val c = ByteArray(168)
        var n = 0
        while (n < N) {
            x.squeeze(c)
            var p = 0
            while (p + 3 <= c.size && n < N) {
                val c0 = c[p].toInt() and 0xFF; val c1 = c[p + 1].toInt() and 0xFF; val c2 = c[p + 2].toInt() and 0xFF
                val d1 = c0 + 256 * (c1 and 0x0F); val d2 = (c1 ushr 4) + 16 * c2
                if (d1 < Q) a[n++] = d1
                if (d2 < Q && n < N) a[n++] = d2
                p += 3
            }
        }
        return a
    }

    companion object {
        const val Q = 3329
        const val N = 256
        val ML_KEM_512 = MlKem(2, 3, 10, 4)
        val ML_KEM_768 = MlKem(3, 2, 10, 4)
        val ML_KEM_1024 = MlKem(4, 2, 11, 5)

        private fun bitRev7(x: Int): Int { var r = 0; for (i in 0 until 7) r = r or (((x ushr i) and 1) shl (6 - i)); return r }
        private fun powMod(b: Int, e: Int): Int { var r = 1L; var x = b.toLong(); var n = e; while (n > 0) { if (n and 1 == 1) r = r * x % Q; x = x * x % Q; n = n ushr 1 }; return r.toInt() }
        /** ζ^BitRev7(i), ζ = 17 (FIPS 203 Ek A). */
        private val ZETAS = IntArray(128) { powMod(17, bitRev7(it)) }
        /** Taban çarpım için ζ^(2·BitRev7(i)+1). */
        private val GAMMAS = IntArray(128) { powMod(17, 2 * bitRev7(it) + 1) }

        /** Algoritma 9 (kopya üzerinde). */
        internal fun ntt(src: IntArray): IntArray {
            val f = src.copyOf()
            var i = 1; var len = 128
            while (len >= 2) {
                var start = 0
                while (start < N) {
                    val z = ZETAS[i++]
                    for (j in start until start + len) {
                        val t = (z * f[j + len]) % Q
                        f[j + len] = (f[j] - t + Q) % Q
                        f[j] = (f[j] + t) % Q
                    }
                    start += 2 * len
                }
                len = len shr 1
            }
            return f
        }

        /** Algoritma 10 (yerinde; girdiyi değiştirir ve döner). */
        internal fun invNtt(f: IntArray): IntArray {
            var i = 127; var len = 2
            while (len <= 128) {
                var start = 0
                while (start < N) {
                    val z = ZETAS[i--]
                    for (j in start until start + len) {
                        val t = f[j]
                        f[j] = (t + f[j + len]) % Q
                        f[j + len] = (z * ((f[j + len] - t + Q) % Q)) % Q
                    }
                    start += 2 * len
                }
                len = len shl 1
            }
            for (j in 0 until N) f[j] = (f[j] * 3303) % Q
            return f
        }

        /** Algoritma 11-12. */
        internal fun mulNtt(a: IntArray, b: IntArray): IntArray {
            val h = IntArray(N)
            for (i in 0 until 128) {
                val a0 = a[2 * i]; val a1 = a[2 * i + 1]; val b0 = b[2 * i]; val b1 = b[2 * i + 1]
                h[2 * i] = ((a0 * b0) % Q + ((a1 * b1) % Q) * GAMMAS[i]) % Q
                h[2 * i + 1] = ((a0 * b1) % Q + (a1 * b0) % Q) % Q
            }
            return h
        }

        private fun addTo(a: IntArray, b: IntArray) { for (i in 0 until N) a[i] = (a[i] + b[i]) % Q }

        internal fun compress(x: IntArray, d: Int): IntArray = IntArray(N) { (((x[it] shl d) + Q / 2) / Q) and ((1 shl d) - 1) }
        internal fun decompress(y: IntArray, d: Int): IntArray = IntArray(N) { (y[it] * Q + (1 shl (d - 1))) ushr d }

        /** Algoritma 5: 256 adet d bitlik tamsayı, küçük uçlu bit dizisi. */
        internal fun byteEncode(f: IntArray, d: Int, out: ByteArray, off: Int) {
            var acc = 0L; var bits = 0; var o = off
            for (v in f) {
                acc = acc or ((v.toLong() and ((1L shl d) - 1)) shl bits); bits += d
                while (bits >= 8) { out[o++] = acc.toByte(); acc = acc ushr 8; bits -= 8 }
            }
        }

        /** Algoritma 6 (d = 12'de değerler 0..4095; modül denetimi [ekValid]'de). */
        internal fun byteDecode(b: ByteArray, off: Int, d: Int): IntArray {
            val f = IntArray(N)
            var acc = 0L; var bits = 0; var o = off
            for (i in 0 until N) {
                while (bits < d) { acc = acc or ((b[o++].toLong() and 0xFF) shl bits); bits += 8 }
                f[i] = (acc and ((1L shl d) - 1)).toInt(); acc = acc ushr d; bits -= d
            }
            return f
        }
    }
}
