package app.dnshizli.platform

import android.content.Context
import app.dnshizli.core.PrivacyReport
import java.io.File
import java.util.concurrent.Executors

/**
 * Gizlilik raporunun ([PrivacyReport]) diskteki yeri: uygulamanın kendi klasöründe tek düz metin dosyası. Yedeğe/buluta gitmez
 * (data_extraction_rules.xml), başka uygulama okuyamaz. Yazma tek arka plan iş parçacığında, önce geçici dosyaya yapılıp yeniden
 * adlandırılır; yarım kalan yazma eski raporu bozmaz. Okuma süreç açılışında arka planda yapılır.
 */
object PrivacyStore {
    private const val FILE = "privacy-report.txt"
    private const val TMP = "privacy-report.tmp"
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "gizlilik-rapor").also { it.isDaemon = true } }

    fun install(ctx: Context) {
        val dir = ctx.applicationContext.filesDir
        PrivacyReport.saver = { text -> io.execute { write(dir, text) } }
        io.execute {
            val f = File(dir, FILE)
            val text = try { if (f.isFile && f.length() < 1_000_000) f.readText(Charsets.UTF_8) else null } catch (_: Exception) { null }
            PrivacyReport.load(text)
        }
    }

    private fun write(dir: File, text: String) {
        try {
            val dst = File(dir, FILE)
            if (text.isEmpty()) { dst.delete(); return }
            val tmp = File(dir, TMP)
            tmp.writeText(text, Charsets.UTF_8)
            if (!tmp.renameTo(dst)) { dst.delete(); tmp.renameTo(dst) }
        } catch (_: Exception) {}
    }
}
