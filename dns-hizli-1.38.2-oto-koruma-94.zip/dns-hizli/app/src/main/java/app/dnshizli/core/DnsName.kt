package app.dnshizli.core

/**
 * DNS tel biçimindeki adı okumanın TEK kuralı. Eskiden altı ayrı yerde (süzgeç sorusu, süzgeç cevap/CNAME, alan anahtarı, IP→ad belleği,
 * gizli izleyici adı, yerel bölgeler) ayrı ayrı yazılmıştı; uzunluk sınırları (253/254/255), harf küçültme (yalnız ASCII / Latin-1) ve
 * sıkıştırma işaretçisi kuralları birbirini tutmuyordu. Aynı ad bir yerde "geçerli", başka yerde "geçersiz" ya da farklı özetle
 * okunabiliyordu (süzgeç kaçağı / bellek uyuşmazlığı). Kurallar (RFC 1035 §2.3.4, §4.1.4):
 *  - etiket ≤ 63 bayt; 0x40/0x80 türü etiketler geçersiz; tel uzunluğu ≤ 255 (metin ≤ 253)
 *  - sıkıştırma işaretçisi yalnızca istenirse ve yalnızca GERİYE (daha önceki bir konuma) — döngü kurulamaz; en çok [MAX_JUMPS] atlama
 *  - yalnız ASCII A-Z küçültülür (etiket baytları başka değiştirilmez: süzgeç özetiyle birebir)
 * Ayırma yapmaz (dizgi isteyen yardımcılar hariç).
 */
object DnsName {
    const val MAX_TEXT = 253
    const val MAX_JUMPS = 16

    /**
     * [msg]'de [from]'daki adı [out]'a (en az 253 bayt) noktalı ve küçük harfle yazar. [base]: mesaj başı (işaretçiler buna göre);
     * [compress] false ise işaretçi geçersizdir (soru bölümü). Dönüş: geçersizse -1, değilse (metin uzunluğu shl 32) or (adın telde
     * bittiği konum: ilk işaretçiden ya da sıfır bayttan sonrası).
     */
    fun read(msg: ByteArray, base: Int, from: Int, end: Int, out: ByteArray, compress: Boolean): Long {
        if (base < 0 || from < base || end > msg.size) return -1
        var i = from
        var n = 0
        var wire = 0
        var jumps = 0
        var next = -1
        var floor = i                                     // işaretçi bundan önceki bir konumu göstermeli
        while (true) {
            if (i < base || i >= end) return -1
            val l = msg[i].toInt() and 0xFF
            if (l == 0) { if (next < 0) next = i + 1; break }
            if ((l and 0xC0) == 0xC0) {
                if (!compress || i + 2 > end || ++jumps > MAX_JUMPS) return -1
                val ptr = base + (((l and 0x3F) shl 8) or (msg[i + 1].toInt() and 0xFF))
                if (ptr >= floor) return -1               // ileri ya da kendine işaretçi: döngü / sahte uzatma
                if (next < 0) next = i + 2
                floor = ptr
                i = ptr
                continue
            }
            if ((l and 0xC0) != 0 || i + 1 + l > end) return -1
            wire += l + 1
            if (wire + 1 > 255) return -1
            if (n > 0) out[n++] = '.'.code.toByte()
            for (k in 1..l) {
                val c = msg[i + k].toInt() and 0xFF
                out[n++] = (if (c in 'A'.code..'Z'.code) c + 32 else c).toByte()
            }
            i += 1 + l
        }
        return (n.toLong() shl 32) or next.toLong()
    }

    fun length(r: Long): Int = (r ushr 32).toInt()
    fun next(r: Long): Int = (r and 0xFFFFFFFFL).toInt()

    private val tl = ThreadLocal.withInitial { ByteArray(256) }

    /** Adı dizgi olarak okur (ayırır); geçersizse null. Kök ad "" döner. */
    fun string(msg: ByteArray, base: Int, from: Int, end: Int, compress: Boolean = false): String? {
        val buf = tl.get()
        val r = read(msg, base, from, end, buf, compress)
        if (r < 0) return null
        return String(buf, 0, length(r), Charsets.ISO_8859_1)
    }
}
