package app.dnshizli.core

import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.security.MessageDigest
import java.security.PublicKey
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.MGF1ParameterSpec
import java.security.spec.PSSParameterSpec
import java.security.interfaces.RSAPublicKey
import javax.net.ssl.X509TrustManager

/**
 * QUIC içindeki TLS 1.3 istemcisi (RFC 8446 + RFC 9001 §4). Kayıt katmanı yoktur: el sıkışma iletileri QUIC CRYPTO çerçevelerinde taşınır.
 * Tek takım: TLS_AES_128_GCM_SHA256; gruplar: X25519MLKEM768 (kuantum sonrası karma, [pq] açıksa önce) ve x25519; imzalar: rsa_pss_rsae_sha256/384, ecdsa_secp256r1_sha256,
 * ecdsa_secp384r1_sha384. HelloRetryRequest, oturum bileti, 0-RTT, istemci sertifikası desteklenmez.
 *
 * Güvenlik: sertifika zinciri sistem güven deposuyla ([trust]) doğrulanır, SNI adı sertifikanın SAN listesinde aranır ve CertificateVerify
 * imzası ile Finished özeti denetlenir. Bunlardan biri tutmazsa [QuicTlsException] atılır; hiçbir veri gönderilmez.
 */
/** [trust]: sertifika/imza/özet doğrulaması başarısız (araya girilmiş ya da yanlış sunucu belirtisi); yalnızca bozuk biçim değil. */
class QuicTlsException(msg: String, val trust: Boolean = false, cause: Throwable? = null) : Exception(msg, cause)

class QuicTls(
    private val host: String,
    private val alpn: String,
    private val transportParams: ByteArray,
    private val trust: X509TrustManager,
    rng: SecureRandom = SecureRandom(),
    /**
     * Kuantum sonrası karma anahtar değişimi (X25519MLKEM768, 0x11EC) önerilsin mi? İki anahtar paylaşımı birden gönderilir (karma + x25519):
     * desteklemeyen sunucu HelloRetryRequest'e gerek kalmadan x25519'u seçer. Ortak sır = ML-KEM sırrı ‖ X25519 sırrı (ikisi birden kırılmadıkça güvenli).
     */
    private val pq: Boolean = true,
) {
    /** Her seviye için (istemci, sunucu) trafik sırrı; null: henüz yok. */
    var hsClient: ByteArray? = null; private set
    var hsServer: ByteArray? = null; private set
    var appClient: ByteArray? = null; private set
    var appServer: ByteArray? = null; private set
    /** Sunucunun ilettiği QUIC taşıma parametreleri (EncryptedExtensions). */
    var peerParams: ByteArray? = null; private set
    /** İstemci Finished iletisi (Handshake seviyesinde gönderilecek); sunucu Finished doğrulanınca dolar. */
    var clientFinished: ByteArray? = null; private set
    var done = false; private set
    /** Sunucunun seçtiği anahtar değişimi grubu (0x11EC karma, 0x001D x25519); ServerHello'dan önce 0. */
    var group = 0; private set

    private val priv = X25519.generatePrivate(rng)
    private val kem: MlKem.KeyPair? = if (pq) MlKem.ML_KEM_768.keyGen(rng) else null
    private val random = ByteArray(32).also { rng.nextBytes(it) }
    private val transcript = ByteArrayOutputStream()
    private val buf = arrayOf(ByteArrayOutputStream(), ByteArrayOutputStream())    // 0: Initial seviyesi, 1: Handshake seviyesi
    private var state = 0       // 0 SH bekle, 1 EE, 2 Cert, 3 CV, 4 Fin, 5 bitti
    private var hsSecret: ByteArray? = null
    private var leaf: X509Certificate? = null
    private var transcriptAtCert: ByteArray? = null

    private fun sha(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b)
    private fun th() = sha(transcript.toByteArray())
    private fun extract(salt: ByteArray, ikm: ByteArray) = QuicInitial.hmac(salt, ikm)
    private fun label(secret: ByteArray, l: String, ctx: ByteArray, n: Int = 32) = QuicInitial.expandLabel(secret, l, ctx, n)
    private fun derive(secret: ByteArray, l: String, hash: ByteArray) = label(secret, l, hash)

    private fun u16(o: ByteArrayOutputStream, v: Int) { o.write(v shr 8); o.write(v) }
    private fun ext(o: ByteArrayOutputStream, type: Int, body: ByteArray) { u16(o, type); u16(o, body.size); o.write(body) }

    /** ClientHello iletisi (Initial seviyesinde CRYPTO olarak gider). */
    fun clientHello(): ByteArray {
        val e = ByteArrayOutputStream()
        val hn = host.toByteArray(Charsets.ISO_8859_1)
        if (!isIpLiteral(host)) ext(e, 0, ByteArrayOutputStream().also { u16(it, hn.size + 3); it.write(0); u16(it, hn.size); it.write(hn) }.toByteArray())
        if (kem != null) ext(e, 10, byteArrayOf(0, 4, 0x11, 0xEC.toByte(), 0, 0x1d))      // supported_groups: X25519MLKEM768, x25519
        else ext(e, 10, byteArrayOf(0, 2, 0, 0x1d))                                        // supported_groups: x25519
        ext(e, 13, byteArrayOf(0, 8, 0x08, 0x04, 0x08, 0x05, 0x04, 0x03, 0x05, 0x03))      // signature_algorithms
        val an = alpn.toByteArray(Charsets.ISO_8859_1)
        ext(e, 16, ByteArrayOutputStream().also { u16(it, an.size + 1); it.write(an.size); it.write(an) }.toByteArray())
        ext(e, 43, byteArrayOf(2, 3, 4))                                                   // supported_versions: TLS 1.3
        ext(e, 45, byteArrayOf(1, 1))                                                      // psk_key_exchange_modes: psk_dhe_ke
        ext(e, 51, ByteArrayOutputStream().also {
            val pk = X25519.publicKey(priv)
            val hybrid = kem?.let { k -> k.ek + pk }                                        // ML-KEM ek ‖ X25519 (draft-ietf-tls-ecdhe-mlkem)
            u16(it, pk.size + 4 + (hybrid?.let { h -> h.size + 4 } ?: 0))
            if (hybrid != null) { u16(it, 0x11EC); u16(it, hybrid.size); it.write(hybrid) }
            u16(it, 0x1d); u16(it, pk.size); it.write(pk)
        }.toByteArray())
        ext(e, 57, transportParams)                                                        // quic_transport_parameters
        val body = ByteArrayOutputStream()
        body.write(3); body.write(3)                                                       // legacy_version
        body.write(random)
        body.write(0)                                                                      // legacy_session_id boş (RFC 9001 §8.4)
        u16(body, 2); u16(body, 0x1301)
        body.write(1); body.write(0)                                                       // sıkıştırma yok
        u16(body, e.size()); body.write(e.toByteArray())
        val msg = ByteArrayOutputStream()
        msg.write(1); val n = body.size(); msg.write(n shr 16); msg.write(n shr 8); msg.write(n)
        msg.write(body.toByteArray())
        val m = msg.toByteArray()
        transcript.write(m)
        return m
    }

    /** [level] seviyesinde (0 Initial, 1 Handshake) gelen sıralı CRYPTO baytları. */
    fun feed(level: Int, data: ByteArray) {
        if (level !in 0..1) throw QuicTlsException("beklenmeyen seviye")
        val b = buf[level]
        b.write(data)
        while (true) {
            val all = b.toByteArray()
            if (all.size < 4) return
            val len = ((all[1].toInt() and 0xFF) shl 16) or ((all[2].toInt() and 0xFF) shl 8) or (all[3].toInt() and 0xFF)
            if (len > 65536) throw QuicTlsException("el sıkışma iletisi çok büyük")
            if (all.size < 4 + len) return
            val msg = all.copyOfRange(0, 4 + len)
            b.reset(); b.write(all, 4 + len, all.size - 4 - len)
            try { handle(level, msg) }
            catch (e: QuicTlsException) { throw e }
            catch (e: Exception) { throw QuicTlsException("bozuk el sıkışma iletisi (${e.javaClass.simpleName})") }      // kesik/bozuk alan: hangi istisna olursa olsun tek tür hata
        }
    }

    private fun handle(level: Int, m: ByteArray) {
        val type = m[0].toInt() and 0xFF
        val body = m.copyOfRange(4, m.size)
        when (state) {
            0 -> { if (type != 2 || level != 0) throw QuicTlsException("ServerHello bekleniyordu"); serverHello(m, body); state = 1 }
            1 -> { if (type != 8 || level != 1) throw QuicTlsException("EncryptedExtensions bekleniyordu"); transcript.write(m); encExt(body); state = 2 }
            2 -> {
                if (level != 1) throw QuicTlsException("seviye")
                if (type == 13) throw QuicTlsException("istemci sertifikası istendi (desteklenmiyor)")
                if (type != 11) throw QuicTlsException("Certificate bekleniyordu")
                transcript.write(m); certificate(body); transcriptAtCert = th(); state = 3
            }
            3 -> { if (type != 15 || level != 1) throw QuicTlsException("CertificateVerify bekleniyordu"); certVerify(body); transcript.write(m); state = 4 }
            4 -> { if (type != 20 || level != 1) throw QuicTlsException("Finished bekleniyordu"); finished(body, m); state = 5 }
            else -> if (type != 4) throw QuicTlsException("el sıkışma sonrası beklenmeyen ileti $type")   // NewSessionTicket yok sayılır
        }
    }

    private fun serverHello(m: ByteArray, b: ByteArray) {
        if (b.size < 38) throw QuicTlsException("kısa ServerHello")
        if (b[0].toInt() != 3 || b[1].toInt() != 3) throw QuicTlsException("beklenmeyen legacy_version")
        val rnd = b.copyOfRange(2, 34)
        if (rnd.contentEquals(HRR)) throw QuicTlsException("HelloRetryRequest desteklenmiyor")
        var p = 34
        val sid = b[p++].toInt() and 0xFF
        p += sid
        if (p + 3 > b.size) throw QuicTlsException("bozuk ServerHello")
        val suite = ((b[p].toInt() and 0xFF) shl 8) or (b[p + 1].toInt() and 0xFF)
        if (suite != 0x1301) throw QuicTlsException("beklenmeyen şifre takımı")
        if (b[p + 2].toInt() != 0) throw QuicTlsException("sıkıştırma pazarlığı yapılmamalı")
        p += 3                                                                              // takım + sıkıştırma
        val el = ((b[p].toInt() and 0xFF) shl 8) or (b[p + 1].toInt() and 0xFF); p += 2
        if (p + el > b.size) throw QuicTlsException("bozuk uzantılar")
        var share: ByteArray? = null
        var ver = 0
        val end = p + el
        while (p + 4 <= end) {
            val t = ((b[p].toInt() and 0xFF) shl 8) or (b[p + 1].toInt() and 0xFF)
            val l = ((b[p + 2].toInt() and 0xFF) shl 8) or (b[p + 3].toInt() and 0xFF)
            p += 4
            if (p + l > end) throw QuicTlsException("bozuk uzantı")
            if (t == 43 && l == 2) ver = ((b[p].toInt() and 0xFF) shl 8) or (b[p + 1].toInt() and 0xFF)
            if (t == 51 && l >= 4) {
                val g = ((b[p].toInt() and 0xFF) shl 8) or (b[p + 1].toInt() and 0xFF)
                val kl = ((b[p + 2].toInt() and 0xFF) shl 8) or (b[p + 3].toInt() and 0xFF)
                if (kl + 4 != l) throw QuicTlsException("bozuk anahtar paylaşımı")
                when {
                    g == 0x1d && kl == 32 -> { share = b.copyOfRange(p + 4, p + 36); group = g }
                    g == 0x11EC && kl == HYBRID_SERVER_SHARE && kem != null -> { share = b.copyOfRange(p + 4, p + 4 + kl); group = g }
                    else -> throw QuicTlsException("sunucu önermediğimiz bir grup seçti")
                }
            }
            p += l
        }
        if (ver != 0x0304) throw QuicTlsException("TLS 1.3 pazarlığı yapılmadı")
        val ks = share ?: throw QuicTlsException("anahtar paylaşımı yok")
        val dh = if (group == 0x11EC) {
            // karma: kapsül (1088) ‖ X25519 ortak anahtarı (32); sır = ML-KEM sırrı ‖ X25519 sırrı
            val ss = MlKem.ML_KEM_768.decapsulate(kem!!.dk, ks.copyOfRange(0, 1088)) ?: throw QuicTlsException("ML-KEM kapsülü açılamadı")
            val x = X25519.shared(priv, ks.copyOfRange(1088, 1120)) ?: throw QuicTlsException("geçersiz x25519 noktası")
            ss + x
        } else X25519.shared(priv, ks) ?: throw QuicTlsException("geçersiz x25519 noktası")
        kem?.dk?.fill(0)
        transcript.write(m)
        val early = extract(ByteArray(32), ByteArray(32))
        val derived = derive(early, "derived", sha(ByteArray(0)))
        val hs = extract(derived, dh)
        hsSecret = hs
        val h = th()
        hsClient = derive(hs, "c hs traffic", h)
        hsServer = derive(hs, "s hs traffic", h)
    }

    private fun encExt(b: ByteArray) {
        if (b.size < 2) throw QuicTlsException("kısa EncryptedExtensions")
        var p = 2
        val end = minOf(b.size, 2 + (((b[0].toInt() and 0xFF) shl 8) or (b[1].toInt() and 0xFF)))
        var alpnOk = false
        while (p + 4 <= end) {
            val t = ((b[p].toInt() and 0xFF) shl 8) or (b[p + 1].toInt() and 0xFF)
            val l = ((b[p + 2].toInt() and 0xFF) shl 8) or (b[p + 3].toInt() and 0xFF)
            p += 4
            if (p + l > end) throw QuicTlsException("bozuk uzantı")
            if (t == 16 && l >= 4) {
                val n = b[p + 2].toInt() and 0xFF
                alpnOk = n == alpn.length && String(b, p + 3, n, Charsets.ISO_8859_1) == alpn
            }
            if (t == 57) peerParams = b.copyOfRange(p, p + l)
            p += l
        }
        if (!alpnOk) throw QuicTlsException("ALPN '$alpn' pazarlığı yapılmadı")
        if (peerParams == null) throw QuicTlsException("QUIC taşıma parametreleri yok")
    }

    private fun certificate(b: ByteArray) {
        var p = 0
        val ctx = b[p++].toInt() and 0xFF
        p += ctx
        val total = ((b[p].toInt() and 0xFF) shl 16) or ((b[p + 1].toInt() and 0xFF) shl 8) or (b[p + 2].toInt() and 0xFF); p += 3
        if (p + total > b.size) throw QuicTlsException("bozuk sertifika listesi")
        val end = p + total
        val cf = CertificateFactory.getInstance("X.509")
        val chain = ArrayList<X509Certificate>()
        while (p + 3 <= end) {
            val l = ((b[p].toInt() and 0xFF) shl 16) or ((b[p + 1].toInt() and 0xFF) shl 8) or (b[p + 2].toInt() and 0xFF); p += 3
            if (p + l > end) throw QuicTlsException("bozuk sertifika")
            chain.add(cf.generateCertificate(b.copyOfRange(p, p + l).inputStream()) as X509Certificate)
            p += l
            val el = ((b[p].toInt() and 0xFF) shl 8) or (b[p + 1].toInt() and 0xFF); p += 2 + el
            if (chain.size >= 8) break
        }
        if (chain.isEmpty()) throw QuicTlsException("sertifika yok")
        val c0 = chain[0]
        try { trust.checkServerTrusted(chain.toTypedArray(), if (c0.publicKey.algorithm == "RSA") "RSA" else "ECDHE_ECDSA") }
        catch (e: Exception) {
            // Platform doğrulayıcı süre hatasını her zaman CertificateExpiredException nedeniyle sarmaz: zincirde süresi dolmuş/henüz geçerli olmayan
            // sertifika varsa bu bir saat sorunudur (saldırı alarmı değil); nedeni açıkça işaretle.
            val timeEx = chain.firstNotNullOfOrNull { c -> try { c.checkValidity(); null } catch (t: java.security.cert.CertificateExpiredException) { t } catch (t: java.security.cert.CertificateNotYetValidException) { t } }
            if (timeEx != null) throw QuicTlsException("sertifika süresi geçerli değil", true, timeEx)
            throw QuicTlsException("sertifika zinciri güvenilmez: ${e.javaClass.simpleName}", true, e)
        }
        try { c0.checkValidity() } catch (e: Exception) { throw QuicTlsException("sertifika süresi geçerli değil", true, e) }
        if (!hostMatches(c0, host)) throw QuicTlsException("sertifika $host adına ait değil", true)
        leaf = c0
    }

    private fun certVerify(b: ByteArray) {
        val cert = leaf ?: throw QuicTlsException("sertifika yok")
        if (b.size < 4) throw QuicTlsException("kısa CertificateVerify")
        val alg = ((b[0].toInt() and 0xFF) shl 8) or (b[1].toInt() and 0xFF)
        val sl = ((b[2].toInt() and 0xFF) shl 8) or (b[3].toInt() and 0xFF)
        if (4 + sl > b.size) throw QuicTlsException("bozuk imza")
        val sig = b.copyOfRange(4, 4 + sl)
        val content = ByteArrayOutputStream()
        repeat(64) { content.write(0x20) }
        content.write("TLS 1.3, server CertificateVerify".toByteArray(Charsets.ISO_8859_1))
        content.write(0)
        content.write(transcriptAtCert ?: throw QuicTlsException("sıra"))
        if (!verifySig(alg, cert.publicKey, content.toByteArray(), sig)) throw QuicTlsException("CertificateVerify imzası geçersiz", true)
    }

    private fun finished(b: ByteArray, m: ByteArray) {
        val hs = hsSecret ?: throw QuicTlsException("sıra")
        val sFin = label(hsServer!!, "finished", ByteArray(0))
        val expect = QuicInitial.hmac(sFin, th())
        if (b.size != 32 || !MessageDigest.isEqual(b, expect)) throw QuicTlsException("sunucu Finished özeti yanlış", true)
        transcript.write(m)
        val h = th()                                                                        // ClientHello..sunucu Finished
        val derived = derive(hs, "derived", sha(ByteArray(0)))
        val master = extract(derived, ByteArray(32))
        appClient = derive(master, "c ap traffic", h)
        appServer = derive(master, "s ap traffic", h)
        val cFin = label(hsClient!!, "finished", ByteArray(0))
        val verify = QuicInitial.hmac(cFin, h)
        val out = ByteArray(4 + 32)
        out[0] = 20; out[3] = 32
        System.arraycopy(verify, 0, out, 4, 32)
        clientFinished = out
        transcript.write(out)
        done = true
    }

    companion object {
        const val GROUP_X25519 = 0x1d
        const val GROUP_X25519_MLKEM768 = 0x11EC
        private const val HYBRID_SERVER_SHARE = 1088 + 32
        private val HRR = byteArrayOf(
            0xCF.toByte(), 0x21, 0xAD.toByte(), 0x74, 0xE5.toByte(), 0x9A.toByte(), 0x61, 0x11, 0xBE.toByte(), 0x1D, 0x8C.toByte(), 0x02, 0x1E, 0x65, 0xB8.toByte(), 0x91.toByte(),
            0xC2.toByte(), 0xA2.toByte(), 0x11, 0x16, 0x7A, 0xBB.toByte(), 0x8C.toByte(), 0x5E, 0x07, 0x9E.toByte(), 0x09, 0xE2.toByte(), 0xC8.toByte(), 0xA8.toByte(), 0x33, 0x9C.toByte())

        /** Sertifikanın SAN dNSName / iPAddress listesinde [host] var mı? Joker yalnızca en soldaki tek etiketi kapsar. SAN yoksa eşleşmez. */
        /** Yalnızca gerçek IP değişmezi (DNS çözümlemesi tetiklenmesin diye katı denetim): a.b.c.d ya da iki nokta üst üsteli onaltılık. */
        internal fun isIpLiteral(h: String): Boolean {
            if (h.isEmpty()) return false
            val v4 = h.split('.')
            if (v4.size == 4 && v4.all { it.isNotEmpty() && it.length <= 3 && it.all { c -> c in '0'..'9' } && it.toInt() <= 255 }) return true
            return h.contains(':') && h.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' || it == ':' || it == '.' }
        }

        fun hostMatches(c: X509Certificate, host: String): Boolean {
            val sans = try { c.subjectAlternativeNames } catch (_: Exception) { null } ?: return false
            val isIp = isIpLiteral(host)
            val want = host.lowercase().trimEnd('.')
            for (s in sans) {
                val type = s[0] as? Int ?: continue
                val v = s[1] as? String ?: continue
                if (isIp) {
                    if (type == 7 && try { InetAddress.getByName(v) == InetAddress.getByName(host) } catch (_: Exception) { false }) return true
                } else if (type == 2) {
                    val n = v.lowercase().trimEnd('.')
                    if (n == want) return true
                    if (n.startsWith("*.") && n.indexOf('*', 1) < 0 && n.indexOf('.', 2) > 0) {      // joker en az iki etiketli bir alanın altında olmalı (*.com gibi değil)
                        val dot = want.indexOf('.')
                        if (dot > 0 && want.substring(dot) == n.substring(1) && want.substring(0, dot).isNotEmpty()) return true
                    }
                }
            }
            return false
        }

        /** RFC 8446 §4.4.3: ecdsa_secp256r1_sha256 yalnızca P-256, secp384r1 yalnızca P-384 anahtarıyla kullanılır. */
        private fun ecBits(key: PublicKey, bits: Int): Boolean = key is java.security.interfaces.ECPublicKey && key.params.curve.field.fieldSize == bits

        fun verifySig(alg: Int, key: PublicKey, content: ByteArray, sig: ByteArray): Boolean {
            return try {
                when (alg) {
                    0x0804, 0x0805 -> {
                        if (key !is RSAPublicKey) return false
                        val (md, spec, name) = if (alg == 0x0804) Triple("SHA-256", MGF1ParameterSpec.SHA256, "SHA256withRSA/PSS") else Triple("SHA-384", MGF1ParameterSpec.SHA384, "SHA384withRSA/PSS")
                        val salt = if (alg == 0x0804) 32 else 48
                        val s = try {
                            Signature.getInstance("RSASSA-PSS").also { it.setParameter(PSSParameterSpec(md, "MGF1", spec, salt, 1)) }
                        } catch (_: Exception) { Signature.getInstance(name) }
                        s.initVerify(key); s.update(content); s.verify(sig)
                    }
                    0x0403 -> if (!ecBits(key, 256)) false else Signature.getInstance("SHA256withECDSA").let { it.initVerify(key); it.update(content); it.verify(sig) }
                    0x0503 -> if (!ecBits(key, 384)) false else Signature.getInstance("SHA384withECDSA").let { it.initVerify(key); it.update(content); it.verify(sig) }
                    else -> false
                }
            } catch (_: Exception) { false }
        }
    }
}
