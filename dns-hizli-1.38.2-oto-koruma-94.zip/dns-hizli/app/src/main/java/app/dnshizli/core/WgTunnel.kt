package app.dnshizli.core

import java.security.SecureRandom

/**
 * Bize özel WireGuard tünel motoru (platformdan bağımsız; servis yalnızca UDP soketi ve tün arayüzünü bağlar).
 *  - Giden: tünden okunan IP paketi → hedef AllowedIPs içindeyse şifrelenip uç noktaya gönderilir; oturum yoksa sıraya alınır, el sıkışma başlar.
 *  - Gelen: uç noktadan gelen ileti türüne göre (yanıt / çerez / veri) işlenir; çözülen paketin KAYNAĞI AllowedIPs içinde olmalı
 *    (şifreli anahtar yönlendirmesi: eş, izin verilmeyen bir adres adına paket sokamaz), dolgu IP başlığındaki uzunlukla kırpılır.
 *  - Zamanlayıcılar (whitepaper §6): el sıkışma yeniden deneme (5 sn + titreşim, en çok 90 sn), 120 sn yenileme, alıcı tarafı 165 sn
 *    yenileme, 10 sn pasif canlı tutma, kalıcı canlı tutma, ölü eş algılama (15 sn), 540 sn sonra anahtarların silinmesi.
 * Bütün çağrılar tek bir kilit altında; tick() saniyede bir çağrılır.
 */
class WgTunnel(
    val cfg: WgConfig,
    private val sendUdp: (ByteArray) -> Unit,
    private val writeTun: (ByteArray, Int, Int) -> Unit,
    private val now: () -> Long = { System.currentTimeMillis() },
    private val rng: SecureRandom = SecureRandom(),
    private val log: (String) -> Unit = {},
) {
    private var initiator = WgInitiator(cfg.privateKey, cfg.peer.publicKey, cfg.peer.presharedKey, rng)
    /** Şu an kullanılan PSK yapılandırmadaki değil de kuantum sonrası değişimden mi geliyor? */
    @Volatile var pskFromPq = false; private set
    private var current: WgSession? = null
    private var previous: WgSession? = null
    private var handshakeIndex = 0
    private var handshakeStarted = 0L
    private var inHandshake = false            // ayrı bayrak: saat değeri 0 olsa da durum doğru kalır
    private var lastInitSent = 0L
    private var retryJitter = 0L
    private val queue = ArrayDeque<ByteArray>()
    private var lastDataReceived = 0L
    private var lastDataSentAwaitingReply = 0L  // yanıt beklenen son veri gönderimi (ölü eş algılama)
    private var lastAnySent = 0L
    private var sentSinceReceive = true        // son veri alımından sonra bir şey gönderildi mi (pasif canlı tutma)

    /** Gelen DNS cevaplarını sahte DNS adresine geri yazan köprü (varsa); paketi tüketirse true döner. */
    @Volatile var dnsBridge: ((ByteArray, Int) -> Boolean)? = null
    /**
     * DNS sunucusu AllowedIPs dışında kalırsa (bölünmüş tünel) yalnızca o adrese giden DNS paketleri tünele alınır; dönüşte o kaynaktan
     * gelen paket ancak [dnsBridge] bekleyen bir sorgunun cevabı olarak tüketirse kabul edilir, değilse sahte sayılır.
     */
    @Volatile var dnsHosts: List<ByteArray> = emptyList()

    /** Trafik gizleme (boyut dolgusu, örtü paketleri); null/OFF: standart WireGuard. */
    @Volatile var shaper: Shaper? = null
    /** Son gerçek veri gönderimi (örtü trafiği sabit akış için). */
    @Volatile var lastRealSentMs = 0L; private set
    @Volatile var coverSent = 0L; private set

    private fun padFor(len: Int): Int = shaper?.padSize(len, cfg.mtu) ?: 0

    /** Örtü paketi: oturum onaylıysa sıfır dolgulu boş paket gönderir (sunucu IP olarak sayamaz, atar). Gönderildiyse true. */
    @Synchronized fun sendCover(): Boolean {
        val sh = shaper ?: return false
        val s = current ?: return false
        val t = now()
        val m = s.encrypt(ByteArray(0), 0, 0, t, sh.coverSize(cfg.mtu)) ?: return false
        sendUdp(m); lastAnySent = t; sentSinceReceive = true; coverSent++
        return true
    }

    // ---- sayaçlar
    @Volatile var handshakes = 0L; private set
    @Volatile var lastHandshakeMs = 0L; private set
    @Volatile var rxBytes = 0L; private set
    @Volatile var txBytes = 0L; private set
    @Volatile var dropped = 0L; private set
    @Volatile var spoofed = 0L; private set

    val connected: Boolean @Synchronized get() = current?.let { !it.expired(now()) && it.confirmed } == true

    /** Tünden gelen IP paketi. */
    @Synchronized fun fromTun(p: ByteArray, len: Int) {
        val dst = dstAddr(p, len) ?: run { dropped++; return }
        if (cfg.peer.allowedIps.none { it.contains(dst) } && !(isUdp53(p, len, dstPort = true) && dnsHosts.any { it.contentEquals(dst) })) { dropped++; return }
        val t = now()
        val s = current
        if (s != null && s.confirmed && !s.expired(t)) {
            val m = s.encrypt(p, 0, len, t, padFor(len)) ?: run { queueAndHandshake(p, len, t); return }
            send(m, t, data = true)
            if (s.shouldRekey(t) && !inHandshake) startHandshake(t)
            return
        }
        queueAndHandshake(p, len, t)
    }

    /** Uç noktadan gelen UDP yükü. */
    @Synchronized fun fromNet(m: ByteArray, off: Int, len: Int) {
        if (len < 4) return
        val t = now()
        when (m[off].toInt()) {
            Wg.TYPE_RESPONSE -> {
                if (!inHandshake) return
                val s = initiator.response(m, off, len, t) ?: return
                previous?.wipe()
                previous = current
                current = s
                inHandshake = false
                handshakes++; lastHandshakeMs = t
                log("WireGuard el sıkışması tamam")
                flushQueue(t)
                if (queue.isEmpty() && lastAnySent < t) sendKeepalive(t)       // anahtar onayı için ilk veri (boş) hemen gider
            }
            Wg.TYPE_COOKIE -> if (initiator.cookieReply(m, off, len, t)) { lastInitSent = 0L; tick() }
            Wg.TYPE_DATA -> {
                val idx = Wg.le32(m, off + 4)
                val s = listOfNotNull(current, previous).firstOrNull { it.localIndex == idx } ?: return
                val pt = s.decrypt(m, off, len, t) ?: return
                lastDataReceived = t
                lastDataSentAwaitingReply = 0L
                if (pt.isNotEmpty()) sentSinceReceive = false
                if (pt.isEmpty()) return                                     // canlı tutma
                val n = innerLength(pt) ?: run { dropped++; return }
                val src = srcAddr(pt, n) ?: run { dropped++; return }
                val routed = cfg.peer.allowedIps.any { it.contains(src) }
                if (!routed && !(isUdp53(pt, n, dstPort = false) && dnsHosts.any { it.contentEquals(src) })) { spoofed++; return }
                if (dnsBridge?.invoke(pt, n) == true) { rxBytes += n; return }
                if (!routed) { spoofed++; return }
                rxBytes += n
                writeTun(pt, 0, n)
                // alıcı tarafı yenileme: başlatıcı oturumu 165 sn'yi geçtiyse (gönderim olmasa da) yeni anahtar
                if (s === current && s.isInitiator && t - s.createdMs >= Wg.REJECT_AFTER_TIME_MS - Wg.KEEPALIVE_TIMEOUT_MS - Wg.REKEY_TIMEOUT_MS && !inHandshake) startHandshake(t)
            }
            else -> {}
        }
    }

    /** Saniyede bir: el sıkışma yeniden deneme, canlı tutma, ölü eş, yenileme, anahtar silme. */
    @Synchronized fun tick() {
        val t = now()
        if (inHandshake) {
            if (t - handshakeStarted >= Wg.REKEY_ATTEMPT_TIME_MS) {
                inHandshake = false; queue.clear(); log("WireGuard: sunucu 90 sn cevap vermedi, deneme bırakıldı")
            } else if (t - lastInitSent >= Wg.REKEY_TIMEOUT_MS + retryJitter) sendInitiation(t)
        }
        val s = current
        if (s != null) {
            if (t - s.createdMs >= 3 * Wg.REJECT_AFTER_TIME_MS) { wipeAll(); return }
            if (s.confirmed && !s.expired(t)) {
                if (s.shouldRekey(t) && !inHandshake && lastAnySent > 0 && t - lastAnySent < Wg.KEEPALIVE_TIMEOUT_MS) startHandshake(t)
                // pasif canlı tutma: veri aldık ama 10 sn'dir bir şey göndermedik
                else if (lastDataReceived > 0 && !sentSinceReceive && t - lastDataReceived >= Wg.KEEPALIVE_TIMEOUT_MS) sendKeepalive(t)
                // kalıcı canlı tutma (NAT eşlemesi düşmesin)
                else if (cfg.peer.keepaliveSec > 0 && t - lastAnySent >= cfg.peer.keepaliveSec * 1000L) sendKeepalive(t)
            }
            // ölü eş: veri gönderdik, 15 sn'dir hiçbir şey gelmedi → yeni el sıkışma
            if (lastDataSentAwaitingReply > 0 && t - lastDataSentAwaitingReply >= Wg.KEEPALIVE_TIMEOUT_MS + Wg.REKEY_TIMEOUT_MS && !inHandshake) {
                lastDataSentAwaitingReply = 0L; startHandshake(t)
            }
        } else if (cfg.peer.keepaliveSec > 0 && !inHandshake && handshakes == 0L) startHandshake(t)   // kalıcı canlı tutmalı eş: hemen bağlan
    }

    /**
     * PresharedKey'i değiştirir (kuantum sonrası değişim: [PqPsk]). Mevcut oturum anahtarları, yeni el sıkışma bitene dek veriyi taşımaya
     * devam eder; yeni PSK ile hemen el sıkışma başlar (süren eski el sıkışma bırakılır: cevabı eski PSK'ye göredir).
     */
    @Synchronized fun setPsk(psk: ByteArray, fromPq: Boolean, handshakeNow: Boolean = true) {
        require(psk.size == 32)
        initiator = WgInitiator(cfg.privateKey, cfg.peer.publicKey, psk.copyOf(), rng)
        pskFromPq = fromPq
        inHandshake = false
        if (handshakeNow) startHandshake(now())
    }

    /** Süren el sıkışmanın yaşı (ms); el sıkışma yoksa -1. Yol seçimi ([WgPath]) bunu izler. */
    @Synchronized fun handshakePendingMs(): Long = if (inHandshake) now() - handshakeStarted else -1L

    /**
     * Taşıma yenilendi (Stealth yeniden bağlandı, ağ değişti): sunucu bizi artık yeni kaynaktan görecek. Geçerli oturum varsa hemen boş
     * bir canlı tutma gider (kimliği doğrulanmış paket sunucunun uç noktayı güncellemesini sağlar); yoksa el sıkışma başlar.
     */
    @Synchronized fun reconnected() {
        val t = now()
        val s = current
        if (s != null && s.confirmed && !s.expired(t)) sendKeepalive(t)
        else if (!inHandshake) startHandshake(t)
        else { lastInitSent = 0L; tick() }                                    // el sıkışma sürüyordu: beklemeden yeniden gönder
    }

    @Synchronized fun close() { wipeAll(); queue.clear(); inHandshake = false }

    // ---- iç işler
    private fun queueAndHandshake(p: ByteArray, len: Int, t: Long) {
        if (queue.size >= MAX_QUEUE) { queue.removeFirst(); dropped++ }
        queue.addLast(p.copyOf(len))
        if (!inHandshake) startHandshake(t)
    }

    /**
     * true iken el sıkışma başlatılmaz (paketler kuyrukta bekler): katı kuantum sonrası kipte ([StealthCfg.pqPin]) doğrulanmış PQ PSK'si
     * gelmeden klasik PSK ile tünel kurulmasın diye. Kalkınca [reconnected] ile hemen el sıkışılır.
     */
    @Volatile var hold = false

    private fun startHandshake(t: Long) { if (hold) return; handshakeStarted = t; inHandshake = true; sendInitiation(t) }

    private fun sendInitiation(t: Long) {
        handshakeIndex = rng.nextInt()
        val m = initiator.initiation(handshakeIndex, t) ?: run { inHandshake = false; log("WireGuard: sunucu anahtarı geçersiz"); return }
        lastInitSent = t
        retryJitter = (rng.nextInt(334)).toLong()
        sendUdp(m)
    }

    private fun flushQueue(t: Long) {
        val s = current ?: return
        while (queue.isNotEmpty()) {
            val p = queue.removeFirst()
            val m = s.encrypt(p, 0, p.size, t, padFor(p.size)) ?: break
            send(m, t, data = true)
        }
    }

    private fun sendKeepalive(t: Long) {
        val s = current ?: return
        val m = s.encrypt(ByteArray(0), 0, 0, t) ?: return
        send(m, t, data = false)
    }

    private fun send(m: ByteArray, t: Long, data: Boolean) {
        sendUdp(m)
        lastAnySent = t
        sentSinceReceive = true
        if (data) { txBytes += m.size; lastRealSentMs = t; if (lastDataSentAwaitingReply == 0L) lastDataSentAwaitingReply = t }
    }

    private fun wipeAll() { current?.wipe(); previous?.wipe(); current = null; previous = null }

    companion object {
        const val MAX_QUEUE = 128

        /** IP paketinin gerçek uzunluğu (dolgu atılır); biçim bozuksa null. */
        /** UDP ve (hedef ya da kaynak) port 53 mü? */
        fun isUdp53(p: ByteArray, len: Int, dstPort: Boolean): Boolean {
            if (len < 1) return false
            val v6 = (p[0].toInt() ushr 4) == 6
            val ihl = if (v6) 40 else (p[0].toInt() and 0x0F) * 4
            if (len < ihl + 8 || (if (v6) p[6].toInt() else p[9].toInt()) != 17) return false
            return Packets.u16(p, ihl + if (dstPort) 2 else 0) == 53
        }

        fun innerLength(p: ByteArray): Int? {
            if (p.size < 20) return null
            return when ((p[0].toInt() ushr 4) and 0xF) {
                4 -> Packets.u16(p, 2).takeIf { it in 20..p.size }
                6 -> if (p.size < 40) null else (40 + Packets.u16(p, 4)).takeIf { it <= p.size }
                else -> null
            }
        }
        fun srcAddr(p: ByteArray, len: Int): ByteArray? = when ((p[0].toInt() ushr 4) and 0xF) {
            4 -> if (len >= 20) p.copyOfRange(12, 16) else null
            6 -> if (len >= 40) p.copyOfRange(8, 24) else null
            else -> null
        }
        fun dstAddr(p: ByteArray, len: Int): ByteArray? = when (if (len > 0) (p[0].toInt() ushr 4) and 0xF else 0) {
            4 -> if (len >= 20) p.copyOfRange(16, 20) else null
            6 -> if (len >= 40) p.copyOfRange(24, 40) else null
            else -> null
        }
    }
}

/**
 * WireGuard kipinde DNS: tün arayüzünün DNS'i bizim sahte adresimizdir; sorgu önce süzgeçten geçer ([FilteringForwarder] bunu sarar),
 * engellenmeyen sorgu hedefi yapılandırmadaki DNS sunucusuna çevrilerek TÜNELİN İÇİNDEN gönderilir (DNS de VPN sunucusundan çıkar,
 * yerel ağa sızmaz). Cevabın kaynağı yeniden sahte adrese çevrilip tün'e yazılır. IPv4 ve IPv6; sağlama toplamları yeniden hesaplanır.
 */
class WgDnsForwarder(
    private val tunnel: WgTunnel,
    private val writeTun: (ByteArray, Int, Int) -> Unit,
    private val fake4: ByteArray, private val fake6: ByteArray,
    private val now: () -> Long = { System.currentTimeMillis() },
) : Forwarder {
    override val proto: Proto get() = Proto.PLAIN
    private val dns4: ByteArray = tunnel.cfg.dns.firstOrNull { it.size == 4 } ?: byteArrayOf(1, 1, 1, 1)
    private val dns6: ByteArray = tunnel.cfg.dns.firstOrNull { it.size == 16 } ?: Ip.parse("2606:4700:4700::1111")!!
    /** Bekleyen sorgular: (ip sürümü, istemci portu) → son gönderim zamanı. Yalnızca bunlara gelen cevaplar geri çevrilir. */
    private val pending = LinkedHashMap<Int, Long>()
    @Volatile private var queries = 0L
    @Volatile private var answered = 0L

    init {
        tunnel.dnsBridge = { p, n -> onTunnelPacket(p, n) }
        tunnel.dnsHosts = listOf(dns4, dns6)
    }

    override fun start() {}
    override fun stats() = Stats(queries = queries, forwarded = queries, answered = answered)
    override fun resetNetwork(reason: String) { synchronized(pending) { pending.clear() } }
    override fun clearCache() {}
    override fun close() { tunnel.dnsBridge = null; tunnel.dnsHosts = emptyList() }

    override fun onPacket(p: ByteArray, len: Int) {
        val v6 = (p[0].toInt() ushr 4) == 6
        val ihl = if (v6) 40 else (p[0].toInt() and 0x0F) * 4
        if (len < ihl + 8 || (if (v6) p[6].toInt() else p[9].toInt()) != 17) return
        if (Packets.u16(p, ihl + 2) != 53) return
        val out = p.copyOf(len)
        if (v6) System.arraycopy(dns6, 0, out, 24, 16) else System.arraycopy(dns4, 0, out, 16, 4)
        fixChecksums(out, len, v6, ihl)
        synchronized(pending) {
            pending[key(v6, Packets.u16(p, ihl))] = now()
            if (pending.size > 512) pending.remove(pending.keys.first())
        }
        queries++
        tunnel.fromTun(out, len)
    }

    /** Tünelden gelen paket bizim DNS cevabımızsa kaynağı sahte adrese çevirip tün'e yazar. */
    private fun onTunnelPacket(p: ByteArray, n: Int): Boolean {
        val v6 = (p[0].toInt() ushr 4) == 6
        val ihl = if (v6) 40 else (p[0].toInt() and 0x0F) * 4
        if (n < ihl + 8 || (if (v6) p[6].toInt() else p[9].toInt()) != 17 || Packets.u16(p, ihl) != 53) return false
        val srcOk = if (v6) Wg.eq(p, 8, dns6, 0, 16) else Wg.eq(p, 12, dns4, 0, 4)
        if (!srcOk) return false
        val k = key(v6, Packets.u16(p, ihl + 2))
        val at = synchronized(pending) { pending.remove(k) } ?: return false
        if (now() - at > 30_000L) return false
        val out = p.copyOf(n)
        if (v6) System.arraycopy(fake6, 0, out, 8, 16) else System.arraycopy(fake4, 0, out, 12, 4)
        fixChecksums(out, n, v6, ihl)
        answered++
        writeTun(out, 0, n)
        return true
    }

    private fun key(v6: Boolean, port: Int) = (if (v6) 0x10000 else 0) or port

    companion object {
        /** IPv4 başlık + UDP (v4/v6) sağlama toplamlarını yeniden hesaplar. */
        fun fixChecksums(b: ByteArray, len: Int, v6: Boolean, ihl: Int) {
            val udpLen = len - ihl
            b[ihl + 6] = 0; b[ihl + 7] = 0
            if (v6) {
                var sum = 0L
                for (i in 8 until 40 step 2) sum += Packets.u16(b, i)
                sum += udpLen.toLong(); sum += 17
                var i = ihl
                while (i + 1 < ihl + udpLen) { sum += Packets.u16(b, i); i += 2 }
                if (i < ihl + udpLen) sum += (b[i].toInt() and 0xFF) shl 8
                while (sum ushr 16 != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
                var c = (sum.inv() and 0xFFFF).toInt(); if (c == 0) c = 0xFFFF
                Packets.put16(b, ihl + 6, c)
            } else {
                b[10] = 0; b[11] = 0
                Packets.put16(b, 10, Packets.checksum(b, 0, ihl))
                val c = Packets.udpChecksum(b, ihl, udpLen, Packets.i32(b, 12), Packets.i32(b, 16))
                Packets.put16(b, ihl + 6, if (c == 0) 0xFFFF else c)
            }
        }
    }
}
