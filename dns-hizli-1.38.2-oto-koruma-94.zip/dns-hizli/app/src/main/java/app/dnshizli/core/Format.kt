package app.dnshizli.core

/** Ekranda gösterilen sayı ve süre biçimleri. Birimler ve ayraçlar etkin dilden ([L.tx]) gelir. */
object Format {
    private fun pad2(n: Long): String = if (n < 10) "0$n" else "$n"

    /** 754 -> "12:34", 3725 -> "1:02:05". */
    fun clock(totalSec: Long): String {
        val s = totalSec.coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "$h:${pad2(m)}:${pad2(sec)}" else "${pad2(m)}:${pad2(sec)}"
    }

    /** Uzun süreler: 45 -> "45 sn", 600 -> "10 dk", 7500 -> "2 sa 5 dk", 200000 -> "2 gün 7 sa" (Türkçe örnek). */
    fun span(totalSec: Long): String {
        val t = L.tx
        val s = totalSec.coerceAtLeast(0)
        val d = s / 86400
        val h = (s % 86400) / 3600
        val m = (s % 3600) / 60
        return when {
            d > 0 -> if (h > 0) "$d ${t.dayU} $h ${t.hourU}" else "$d ${t.dayU}"
            h > 0 -> if (m > 0) "$h ${t.hourU} $m ${t.minU}" else "$h ${t.hourU}"
            m > 0 -> "$m ${t.minU}"
            else -> "$s ${t.secU}"
        }
    }

    /** 950 -> "950", 1250 -> "1,2 bin", 48000 -> "48 bin", 3400000 -> "3,4 mn" (Türkçe örnek). */
    fun count(n: Long): String {
        val t = L.tx
        val sep = t.decimalSep
        return when {
            n < 1000 -> "$n"
            n < 10_000 -> if ((n % 1000) / 100 == 0L) "${n / 1000}${t.thousand}" else "${n / 1000}$sep${(n % 1000) / 100}${t.thousand}"   // 1000 -> "1 bin" ("1,0 bin" değil)
            n < 1_000_000 -> "${n / 1000}${t.thousand}"
            n < 10_000_000 -> if ((n % 1_000_000) / 100_000 == 0L) "${n / 1_000_000}${t.million}" else "${n / 1_000_000}$sep${(n % 1_000_000) / 100_000}${t.million}"
            else -> "${n / 1_000_000}${t.million}"
        }
    }

    /** [part]/[whole] yüzdesi ("%4"); en az bir tane varsa ama %1'in altındaysa "<%1"; hiç yoksa boş. */
    fun share(part: Long, whole: Long): String {
        if (whole <= 0 || part <= 0) return ""
        val p = (part * 100 / whole).toInt().coerceIn(0, 100)
        return if (p == 0) "<" + L.tx.percent(1) else L.tx.percent(p)
    }

    /** "1,2 bin · %4": sayı ve toplamdaki payı. Pay hesaplanamıyorsa yalnızca sayı. */
    fun countWithShare(part: Long, whole: Long): String {
        val sh = share(part, whole)
        return if (sh.isEmpty()) count(part) else count(part) + " · " + sh
    }

    fun ms(n: Int): String = "$n " + L.tx.msU

    /** 900 -> "900 B", 1536 -> "1,5 KB", 3_400_000 -> "3,2 MB" (1024 tabanı; ayraç dile göre). */
    fun bytes(n: Long): String {
        val t = L.tx
        val u = t.byteUnits
        val v = n.coerceAtLeast(0)
        if (v < 1024) return "$v ${u[0]}"
        var unit = 0
        var x = v.toDouble()
        while (x >= 1024.0 && unit < u.size - 1) { x /= 1024.0; unit++ }
        // Yuvarlama 1024'e varırsa ("1023,8 KB" → "1024 KB") bir üst birime geçilir ("1 MB").
        if ((x + 0.5).toLong() >= 1024 && unit < u.size - 1) { x /= 1024.0; unit++ }
        val tenths = (x * 10 + 0.5).toLong()
        val text = if (tenths >= 100) "${(x + 0.5).toLong()}" else "${tenths / 10}${t.decimalSep}${tenths % 10}"
        return "$text ${u[unit]}"
    }

    /** Geçen süreyi "az önce", "5 dk önce", "3 sa önce", "2 gün önce" olarak yazar (Türkçe örnek). */
    fun ago(deltaMs: Long): String {
        val t = L.tx
        val s = deltaMs.coerceAtLeast(0) / 1000
        return when {
            s < 45 -> t.justNow
            s < 90 * 60 -> t.ago("${maxOf(1L, (s + 30) / 60)} ${t.minU}")
            s < 36 * 3600 -> t.ago("${(s + 1800) / 3600} ${t.hourU}")
            else -> t.ago("${(s + 43200) / 86400} ${t.dayU}")
        }
    }

    /** Saat:dakika ("15:42"), cihazın saat diliminde. */
    fun hm(epochMs: Long, tz: java.util.TimeZone = java.util.TimeZone.getDefault()): String {
        val c = java.util.Calendar.getInstance(tz)
        c.timeInMillis = epochMs
        return "${pad2(c.get(java.util.Calendar.HOUR_OF_DAY).toLong())}:${pad2(c.get(java.util.Calendar.MINUTE).toLong())}"
    }
}

/** Küçük, iş parçacığı güvenli halka tampon: son olayları saklar. Kullanıcı yardım ekranından kopyalayabilir. */
class DiagLog(private val capacity: Int = 800, private val clock: () -> Long = { System.currentTimeMillis() }) {
    private val lines = ArrayDeque<Pair<Long, String>>()

    @Synchronized
    fun add(msg: String) {
        if (lines.size >= capacity) lines.removeFirst()
        lines.addLast(clock() to clean(msg))
    }

    private companion object {
        const val MAX_LINE = 500

        /**
         * Günlüğe uzaktan gelen metin (sertifika adı, sunucu mesajı, özel durum iletisi) girebilir: satır sonu ve denetim karakterleri boşluğa çevrilir
         * (yoksa paylaşılan tanılama raporuna sahte "!! [KATEGORİ]" satırı eklenebilir), yön değiştiren/görünmez Unicode karakterleri atılır, uzunluk sınırlanır.
         */
        fun clean(m: String): String {
            val sb = StringBuilder(minOf(m.length, MAX_LINE))
            for (c in m) {
                if (sb.length >= MAX_LINE) break
                when {
                    c == '\n' || c == '\r' || c == '\u2028' || c == '\u2029' || c.isISOControl() -> if (sb.isEmpty() || sb.last() != ' ') sb.append(' ')
                    Character.getType(c) == Character.FORMAT.toInt() -> {}
                    else -> sb.append(c)
                }
            }
            return sb.toString()
        }
    }

    @Synchronized
    fun size(): Int = lines.size

    @Synchronized
    fun clear() = lines.clear()

    /** [cutoff]'tan eski satırlar silinir ("geçmişi otomatik sil"). */
    @Synchronized
    fun prune(cutoff: Long) { while (lines.isNotEmpty() && lines.first().first < cutoff) lines.removeFirst() }

    /** Her satır: "SS:DD:SN mesaj" (cihazın yerel saatiyle), en eski üstte. */
    @Synchronized
    fun dump(): String {
        val fmt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ROOT)
        return lines.joinToString("\n") { (t, m) -> fmt.format(java.util.Date(t)) + " " + m }
    }
}

/**
 * Uygulama genelinde tek günlük. Sorgu adı, IP veya kişisel veri asla yazılmaz.
 * Satır biçimi: "[KATEGORİ] ileti" (bilgi), "! [KATEGORİ] ileti" (uyarı), "!! [KATEGORİ] ileti" (hata).
 */
object Journal {
    val log = DiagLog()
    /** Kategorisiz eski satırlara anahtar sözcüklerden kategori eklenir; böylece rapor her satırı bir başlık altına koyabilir. */
    fun add(msg: String) = log.add(if (msg.startsWith("[") || msg.startsWith("! [") || msg.startsWith("!! [")) msg else "[${categorize(msg)}] $msg")

    /** Kategori sırası rapordaki başlık sırasıdır. */
    val CATEGORIES = listOf("SIZINTI", "SIZMA", "DPI", "REKLAM", "KORUMA", "DNS", "BAĞLANTI", "AĞ", "İSTİKRAR", "KAYNAK", "ÖZET", "HATA", "GENEL")

    fun categorize(msg: String): String {
        val m = msg.lowercase()
        fun has(vararg k: String) = k.any { m.contains(it) }
        return when {
            has("sızıntı") -> "SIZINTI"
            has("sertifika", "sahte", "saldırı", "araya gir") -> "SIZMA"
            has("dpi", "quic", "el sıkış") || Regex("\\bech\\b").containsMatchIn(m) -> "DPI"
            has("süzgeç", "reklam", "liste", "engellen") -> "REKLAM"
            has("otomatik koruma", "kendini onar", "onarıld", "oto-koruma") -> "KORUMA"
            has("ağ değişti", "ağ geldi", "ağ geçidi", "ağ bilgisi") -> "AĞ"
            has("hata", "çök", "beklenmeyen", "başlatılamadı", "açılamadı") -> "HATA"
            has("bağlan", "bağlandı", "tünel", "kesildi", "duraklat", "durduruldu", "yeniden denenecek") -> "BAĞLANTI"
            has("sunucu", "yönlendirici", "önbellek", "test", "dns") -> "DNS"
            else -> "GENEL"
        }
    }

    fun info(cat: String, msg: String) = log.add("[$cat] $msg")
    fun warn(cat: String, msg: String) = log.add("! [$cat] $msg")
    fun error(cat: String, msg: String, e: Throwable? = null) = log.add("!! [$cat] $msg" + (if (e == null) "" else " (${where(e)})"))

    /**
     * Özel durumun sınıfı ve uygulama içindeki ilk çağrı yeri ("SocketTimeoutException < SecureForwarder.kt:412"), nedeni varsa onun sınıfı.
     * İleti metni KASITLI olarak yazılmaz: içinde ad ya da adres olabilir.
     */
    fun where(e: Throwable): String {
        val sb = StringBuilder(e.javaClass.simpleName.ifEmpty { "Hata" })
        val c = e.cause
        if (c != null && c !== e) sb.append(" ← ").append(c.javaClass.simpleName.ifEmpty { "Hata" })
        val f = e.stackTrace.firstOrNull { it.className.startsWith("app.dnshizli") }
        if (f != null) sb.append(" < ").append(f.fileName ?: "?").append(':').append(f.lineNumber)
        return sb.toString()
    }
}

enum class NetKind { WIFI, MOBILE, ETHERNET, OTHER, NONE }

data class NetInfo(val wifi: Boolean, val cellular: Boolean, val ethernet: Boolean, val validated: Boolean)

/** "Ağa göre DNS" kuralları. Saf fonksiyonlar: kolayca test edilir. */
object Rules {
    /** Bağlı fiziksel ağlardan hangisinin kullanıldığını seçer (doğrulanmış Wi-Fi > Ethernet > mobil). */
    fun pick(nets: List<NetInfo>): NetKind {
        val usable = nets.filter { it.validated }.ifEmpty { nets }
        return when {
            usable.any { it.wifi } -> NetKind.WIFI
            usable.any { it.ethernet } -> NetKind.ETHERNET
            usable.any { it.cellular } -> NetKind.MOBILE
            usable.isNotEmpty() -> NetKind.OTHER
            else -> NetKind.NONE
        }
    }

    /** Bu ağ türü için kullanıcı özel bir sunucu atamış mı? */
    fun ruleFor(s: AppSettings, kind: NetKind): String? = when (kind) {
        NetKind.WIFI -> s.wifiServer
        NetKind.MOBILE -> s.mobileServer
        else -> null
    }

    /** Bağlanılacak ilk sunucu: ağ kuralı, yoksa son kullanılan, yoksa varsayılan. */
    fun initialServer(s: AppSettings, kind: NetKind): String =
        ruleFor(s, kind) ?: s.lastServer ?: Catalog.DEFAULT_ID
}

sealed class CheckResult {
    data class Ok(val ms: Int) : CheckResult()
    object NoAnswer : CheckResult()

    /** Sunucunun TLS sertifikası doğrulanamadı: aradaki biri (ağ, güvenlik yazılımı) şifreli bağlantıya karışıyor olabilir. Beklemeden döner. */
    object Untrusted : CheckResult()
}

/**
 * Bağlantı testi: sistemin kendi çözümleyicisiyle bir ad çözdürür ([resolve]) ve bu sorgunun gerçekten
 * yönlendiriciden geçip cevaplandığını sayaçlardan doğrular. Böylece "Bağlı" yazısı yalnızca tünel
 * açıldı demek değil, DNS gerçekten çalışıyor demek olur.
 */
object ConnectionCheck {
    fun run(fw: Forwarder, resolve: () -> Unit, timeoutMs: Long = 4000): CheckResult {
        val before = fw.stats()
        val t0 = System.nanoTime()
        val worker = Thread({ try { resolve() } catch (_: Throwable) {} }, "dns-check")
        worker.isDaemon = true
        worker.start()
        while (true) {
            val now = fw.stats()
            val elapsed = (System.nanoTime() - t0) / 1_000_000
            if (now.answered > before.answered || now.cacheHits > before.cacheHits) {
                return CheckResult.Ok(elapsed.toInt())
            }
            // Sertifika reddi geçici bir ağ sorunu değildir: kalan süreyi beklemeden bildir (hızlı hata tespiti).
            if (now.tlsFailures > before.tlsFailures) return CheckResult.Untrusted
            // Yönlendirici sorguyu zaten pes ettiyse (tüm denemeler ve adresler tükendi) kalan süre beklenmez.
            if (now.timeouts > before.timeouts) return CheckResult.NoAnswer
            if (elapsed >= timeoutMs) return CheckResult.NoAnswer
            try { Thread.sleep(15) } catch (_: InterruptedException) { return CheckResult.NoAnswer }
        }
    }
}
