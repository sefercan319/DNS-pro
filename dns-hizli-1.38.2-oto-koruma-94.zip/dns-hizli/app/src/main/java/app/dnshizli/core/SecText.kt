package app.dnshizli.core

/** Uygulamanın kendi kayıtları (otomatik silme, kilit, ekran görüntüsü) metinleri (12 dil). Sıra: TR, EN, DE, ES, FR, PT, RU, IT, ID, VI, PL, UK. */
object SecText {
    val M: Map<String, Array<String>> = mapOf(
        "ttl" to arrayOf("Geçmişi otomatik sil", "Auto-delete history", "Verlauf auto-löschen", "Autoborrar historial", "Effacement auto",
            "Autoapagar histórico", "Автоудаление истории", "Autoelimina cronologia", "Hapus riwayat otomatis", "Tự động xóa lịch sử",
            "Autousuwanie historii", "Автовидалення історії"),
        "ttlOpts" to arrayOf("Kapalı|1 saat|1 gün|1 hafta", "Off|1 hour|1 day|1 week", "Aus|1 Std.|1 Tag|1 Woche", "No|1 hora|1 día|1 semana", "Non|1 heure|1 jour|1 semaine",
            "Não|1 hora|1 dia|1 semana", "Выкл.|1 час|1 день|1 неделя", "No|1 ora|1 giorno|1 settimana", "Mati|1 jam|1 hari|1 minggu", "Tắt|1 giờ|1 ngày|1 tuần",
            "Wył.|1 godz.|1 dzień|1 tydz.", "Вимк.|1 год|1 день|1 тиждень"),
        "ttlNote" to arrayOf("Eski günlük, rapor ve oturumlar silinir", "Older log, report and sessions are deleted", "Ältere Protokolle, Berichte, Sitzungen weg",
            "Se borran registros, informe y sesiones viejos", "Journal, rapport et sessions anciens effacés", "Registro, relatório e sessões antigos apagados",
            "Старые журнал, отчёт и сеансы удаляются", "Log, rapporto e sessioni vecchi eliminati", "Log, laporan, dan sesi lama dihapus",
            "Xóa nhật ký, báo cáo và phiên cũ", "Stary dziennik, raport i sesje usuwane", "Старі журнал, звіт і сеанси видаляються"),
        "lock" to arrayOf("Uygulama kilidi", "App lock", "App-Sperre", "Bloqueo de la app", "Verrouillage de l'appli", "Bloqueio do app", "Блокировка приложения",
            "Blocco app", "Kunci aplikasi", "Khóa ứng dụng", "Blokada aplikacji", "Блокування застосунку"),
        "lockNote" to arrayOf("Açarken parmak izi, yüz ya da ekran kilidi PIN'i ister", "Asks for fingerprint, face or screen-lock PIN when opened",
            "Fragt beim Öffnen nach Fingerabdruck, Gesicht oder Bildschirm-PIN", "Pide huella, rostro o PIN de pantalla al abrir", "Demande empreinte, visage ou code de l'écran à l'ouverture",
            "Pede digital, rosto ou PIN da tela ao abrir", "При открытии запрашивает отпечаток, лицо или PIN экрана", "All'apertura chiede impronta, volto o PIN dello schermo",
            "Meminta sidik jari, wajah, atau PIN layar saat dibuka", "Yêu cầu vân tay, khuôn mặt hoặc mã khóa màn hình khi mở", "Przy otwarciu prosi o odcisk, twarz lub PIN ekranu",
            "Під час відкриття просить відбиток, обличчя чи PIN екрана"),
        "noLock" to arrayOf("Önce telefonda ekran kilidi (PIN, desen ya da şifre) ayarlayın", "Set a screen lock (PIN, pattern or password) on the phone first",
            "Richten Sie zuerst eine Displaysperre (PIN, Muster oder Passwort) ein", "Primero configura un bloqueo de pantalla (PIN, patrón o contraseña)",
            "Définissez d'abord un verrouillage d'écran (code, schéma ou mot de passe)", "Configure antes um bloqueio de tela (PIN, padrão ou senha)",
            "Сначала задайте блокировку экрана (PIN, графический ключ или пароль)", "Imposta prima un blocco schermo (PIN, sequenza o password)",
            "Atur kunci layar (PIN, pola, atau sandi) di ponsel terlebih dahulu", "Hãy đặt khóa màn hình (PIN, hình vẽ hoặc mật khẩu) trước",
            "Najpierw ustaw blokadę ekranu (PIN, wzór lub hasło)", "Спершу встановіть блокування екрана (PIN, графічний ключ або пароль)"),
        "locked" to arrayOf("DNS Hızlı kilitli", "DNS Hızlı is locked", "DNS Hızlı ist gesperrt", "DNS Hızlı está bloqueado", "DNS Hızlı est verrouillé", "DNS Hızlı está bloqueado",
            "DNS Hızlı заблокирован", "DNS Hızlı è bloccato", "DNS Hızlı terkunci", "DNS Hızlı đang khóa", "DNS Hızlı jest zablokowany", "DNS Hızlı заблоковано"),
        "unlock" to arrayOf("Kilidi aç", "Unlock", "Entsperren", "Desbloquear", "Déverrouiller", "Desbloquear", "Разблокировать", "Sblocca", "Buka kunci", "Mở khóa",
            "Odblokuj", "Розблокувати"),
        "authTitle" to arrayOf("DNS Hızlı'yı aç", "Open DNS Hızlı", "DNS Hızlı öffnen", "Abrir DNS Hızlı", "Ouvrir DNS Hızlı", "Abrir DNS Hızlı", "Открыть DNS Hızlı",
            "Apri DNS Hızlı", "Buka DNS Hızlı", "Mở DNS Hızlı", "Otwórz DNS Hızlı", "Відкрити DNS Hızlı"),
        "secure" to arrayOf("Ekran görüntüsünü engelle", "Block screenshots", "Screenshots verhindern", "Bloquear capturas de pantalla", "Bloquer les captures d'écran",
            "Bloquear capturas de tela", "Запретить скриншоты", "Blocca screenshot", "Blokir tangkapan layar", "Chặn chụp màn hình", "Blokuj zrzuty ekranu", "Заборонити знімки екрана"),
        "secureNote" to arrayOf("Görüntü ya da kayıt alınamaz; son uygulamalarda içerik gizlenir", "No screenshots or recordings; content hidden in recent apps",
            "Keine Screenshots/Aufnahmen; Inhalt in „Zuletzt verwendet“ verborgen", "Sin capturas ni grabaciones; contenido oculto en recientes",
            "Pas de captures ni d'enregistrement ; contenu masqué dans les récents", "Sem capturas ou gravações; conteúdo oculto nos recentes",
            "Без снимков и записи; содержимое скрыто в недавних", "Niente screenshot o registrazioni; contenuto nascosto nelle recenti",
            "Tak bisa tangkap/rekam layar; isi disembunyikan di terbaru", "Không chụp hay ghi màn hình; ẩn nội dung ở gần đây",
            "Bez zrzutów i nagrań; treść ukryta w ostatnich", "Без знімків і запису; вміст приховано в нещодавніх"),
    )

    fun t(key: String, lang: Lang = L.lang): String {
        val row = M[key] ?: return key
        return row.getOrNull(lang.ordinal)?.takeIf { it.isNotBlank() } ?: row.getOrNull(Lang.EN.ordinal) ?: row[0]
    }

    fun ttlOptions(lang: Lang = L.lang): List<String> = t("ttlOpts", lang).split('|')
}
