package app.dnshizli.core

/**
 * Çoklu atlama (multi-hop): WireGuard içinde WireGuard. Telefon → GİRİŞ sunucusu (A) → ÇIKIŞ sunucusu (B) → internet.
 *  - İç tünel (B) uygulama trafiğini şifreler; ürettiği WireGuard UDP paketleri, dış tünelin (A) adresinden B'nin uç noktasına giden
 *    IP/UDP paketine sarılıp dış tünele verilir. A yalnızca B'ye giden şifreli paketleri görür (içeriği ve gidilen siteleri göremez);
 *    B trafiği görür ama telefonun gerçek IP'sini değil, A'nın adresini görür.
 *  - Dış tünelden gelen paket B'nin uç noktasından bizim kaynak portumuza gelen UDP ise yükü iç tünele verilir; başka hiçbir paket
 *    (A'nın ağından gelen sahte/başıboş trafik) tün'e yazılmaz.
 * Saf: tüneller ve tün yazıcısı dışarıdan bağlanır; IPv4 ve IPv6 uç noktası.
 */
class WgChain(
    /** Dış tünelin (A) bize verdiği adres (sarma paketinin kaynağı). Uç nokta ailesiyle aynı aile olmalı. */
    private val outerSrc: ByteArray,
    /** Çıkış sunucusunun (B) çözülmüş uç noktası. */
    private val exitIp: ByteArray,
    private val exitPort: Int,
    private val srcPort: Int = 51821,
) {
    init { require(outerSrc.size == exitIp.size && (exitIp.size == 4 || exitIp.size == 16)) { "aile uyumsuz" } }
    private val v6 = exitIp.size == 16
    private val hdr = if (v6) 48 else 28

    /** İç tünelin WireGuard yükünü (B'ye gidecek) dış tünele verilecek IP/UDP paketine sarar. */
    fun wrap(payload: ByteArray): ByteArray {
        val n = hdr + payload.size
        val b = ByteArray(n)
        if (v6) {
            b[0] = 0x60; Packets.put16(b, 4, 8 + payload.size); b[6] = 17; b[7] = 64
            System.arraycopy(outerSrc, 0, b, 8, 16); System.arraycopy(exitIp, 0, b, 24, 16)
        } else {
            b[0] = 0x45; Packets.put16(b, 2, n); b[6] = 0x40; b[8] = 64; b[9] = 17                 // DF: parçalanma yok
            System.arraycopy(outerSrc, 0, b, 12, 4); System.arraycopy(exitIp, 0, b, 16, 4)
        }
        val ihl = if (v6) 40 else 20
        Packets.put16(b, ihl, srcPort); Packets.put16(b, ihl + 2, exitPort); Packets.put16(b, ihl + 4, 8 + payload.size)
        System.arraycopy(payload, 0, b, hdr, payload.size)
        WgDnsForwarder.fixChecksums(b, n, v6, ihl)
        return b
    }

    @Volatile var foreign = 0L; private set

    /**
     * Dış tünelden çözülmüş IP paketi. B'den bizim porta gelen UDP ise WireGuard yükünü döner (iç tünele verilir); değilse null
     * ([foreign] sayılır; tün'e yazılmaz — çoklu atlamada tün'e yalnız iç tünelin çıktısı gider).
     */
    fun unwrap(p: ByteArray, len: Int): ByteArray? {
        val ver = if (len > 0) (p[0].toInt() ushr 4) and 0xF else 0
        if (v6 != (ver == 6) || (ver != 4 && ver != 6)) { foreign++; return null }
        val ihl = if (v6) 40 else (p[0].toInt() and 0x0F) * 4
        if (len < ihl + 8 || (if (v6) p[6].toInt() else p[9].toInt()) != 17) { foreign++; return null }
        if (!v6 && (Packets.u16(p, 6) and 0x3FFF) != 0) { foreign++; return null }                // parça
        val srcOk = if (v6) Wg.eq(p, 8, exitIp, 0, 16) else Wg.eq(p, 12, exitIp, 0, 4)
        if (!srcOk || Packets.u16(p, ihl) != exitPort || Packets.u16(p, ihl + 2) != srcPort) { foreign++; return null }
        val ulen = Packets.u16(p, ihl + 4)
        if (ulen < 8 || ihl + ulen > len) { foreign++; return null }
        return p.copyOfRange(ihl + 8, ihl + ulen)
    }

    companion object {
        /** İki katman WireGuard + IP/UDP başlığı payı: iç tünelin MTU'su dış tünelinkinden bu kadar küçük olmalı. */
        fun innerMtu(outerMtu: Int, v6: Boolean): Int = outerMtu - 32 - (if (v6) 48 else 28)

        /** Dış tünel yapılandırmasındaki, uç nokta ailesine uyan ilk adres. */
        fun outerSource(outer: WgConfig, exitIp: ByteArray): ByteArray? = outer.addresses.firstOrNull { it.ip.size == exitIp.size }?.ip
    }
}

/**
 * "Gerektiğinde" çoklu atlama kararı: önce çıkış sunucusuna doğrudan bağlanılır; [DIRECT_GIVE_UP_MS] boyunca el sıkışma bitmezse
 * (ağ doğrudan bağlantıyı engelliyor) giriş sunucusu üzerinden zincire geçilir. Ağ değişince doğrudan yeniden denenir.
 * Kip "her zaman" ise baştan zincir, "kapalı" ise hiç.
 */
class HopPlan(val mode: Mode, now: Long) {
    enum class Mode(val id: String) {
        OFF("off"), ALWAYS("always"), AUTO("auto");
        companion object { fun of(id: String?): Mode = values().firstOrNull { it.id == id } ?: OFF }
    }
    var chained: Boolean = mode == Mode.ALWAYS; private set
    private var since = now

    /** [pendingMs]: doğrudan tünelin süren el sıkışma yaşı (-1 yok). Zincire geçilmeliyse true (bir kez). */
    @Synchronized fun onTick(now: Long, pendingMs: Long): Boolean {
        if (mode != Mode.AUTO || chained || pendingMs < 0) return false
        if (minOf(pendingMs, now - since) >= DIRECT_GIVE_UP_MS) { chained = true; since = now; return true }
        return false
    }

    /** Ağ değişti: otomatikte doğrudan yeniden denenir. Zincirden çıkılmalıysa true. */
    @Synchronized fun onNetworkChanged(now: Long): Boolean {
        since = now
        if (mode == Mode.AUTO && chained) { chained = false; return true }
        return false
    }

    companion object { const val DIRECT_GIVE_UP_MS = 20_000L }   // doğrudan tünelin UDP→Stealth geçişine de zaman tanır
}
