package app.dnshizli.core

/** Ek uyum uyarıları ([Coherence]), 12 dil. Sıra: TR, EN, DE, ES, FR, PT, RU, IT, ID, VI, PL, UK. */
internal object AuditTextH {
    val M: Map<String, Array<String>> = mapOf(
        "co.split-odoh" to arrayOf(
            "DNS bölme ve ODoH birlikte açık: ODoH sorguları zaten sunucudan gizlediği için bölme kullanılmıyor",
            "DNS splitting and ODoH are both on: ODoH already hides queries from the server, so splitting is not used",
            "DNS-Aufteilung und ODoH sind beide an: ODoH verbirgt Anfragen bereits vor dem Server, daher wird nicht aufgeteilt",
            "División DNS y ODoH activos a la vez: ODoH ya oculta las consultas al servidor, así que no se divide",
            "Répartition DNS et ODoH actives : ODoH cache déjà les requêtes au serveur, la répartition n'est pas utilisée",
            "Divisão DNS e ODoH ligados: o ODoH já esconde as consultas do servidor, então a divisão não é usada",
            "Включены и распределение DNS, и ODoH: ODoH уже скрывает запросы от сервера, распределение не используется",
            "Divisione DNS e ODoH attivi insieme: ODoH nasconde già le richieste al server, quindi non si divide",
            "Pembagian DNS dan ODoH sama-sama aktif: ODoH sudah menyembunyikan kueri dari server, jadi tidak dibagi",
            "Bật cả chia DNS và ODoH: ODoH đã ẩn truy vấn khỏi máy chủ nên không chia",
            "Włączone podział DNS i ODoH: ODoH już ukrywa zapytania przed serwerem, więc podział nie jest używany",
            "Увімкнено і розподіл DNS, і ODoH: ODoH вже приховує запити від сервера, тож розподіл не використовується"),
    )
}
