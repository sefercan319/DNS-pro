package app.dnshizli.core

/** Bir uygulamanın internet engeli: her zaman, yalnızca mobil veride ya da yalnızca Wi-Fi'de. */
enum class FwMode(val id: Char) {
    ALL('A'), MOBILE('M'), WIFI('W');

    /** Bu kip [k] ağında engeller mi? Ağ yoksa hiçbir şey engellenmez (bağlantı zaten yok). Kablolu/diğer ağda yalnızca [ALL]. */
    fun blocksOn(k: NetKind): Boolean = when (this) {
        ALL -> k != NetKind.NONE
        MOBILE -> k == NetKind.MOBILE
        WIFI -> k == NetKind.WIFI
    }

    companion object { fun byId(c: Char): FwMode? = values().firstOrNull { it.id == c } }
}

/**
 * Uygulama güvenlik duvarı: seçilen uygulamanın internete çıkışı tamamen kesilir (her zaman / yalnızca mobil veride / yalnızca
 * Wi-Fi'de).
 *
 * Nasıl tam kesilir:
 *  - Kural varken tünel tüm trafiği alır (ağ geçidi; [ServicePolicy.gwWanted]). Engelli uygulamanın yeni TCP bağlantısına hemen RST,
 *    UDP paketine sessizce düşürme ([Gateway]). Kural ya da ağ değişince ([gen]) süren akışlar da yeniden denetlenip kesilir.
 *  - DNS sorgusu "engelli" cevabıyla anında döner ([FilteringForwarder]): uygulama beklemeden "bağlantı yok" görür.
 *  - WireGuard kipinde tünele giden her IP paketi ([dropIp]) aynı denetimden geçer.
 *
 * Sahip, Android'in `getConnectionOwnerUid` çağrısıyla bulunur ([AppAds.pkgOf]; API 29+). Sahibi çözülemeyen bağlantı (eski Android,
 * sistem) engellenmez: başka bir uygulama asla yanlışlıkla kesilmez.
 */
object AppFirewall {
    const val MAX_RULES = 300
    private const val FLOW_TTL_MS = 30_000L
    /** Sahibi bulunamayan akış (soket henüz kayıtlı değil, geçici hata) kısa tutulur: engelli uygulama 30 sn sızmasın. */
    private const val UNKNOWN_TTL_MS = 2_000L
    private const val MAX_FLOWS = 4096
    private const val NET_PROBE_MS = 3_000L

    @Volatile var rules: Map<String, FwMode> = emptyMap()
        private set
    /** Kural ya da ağ değişince artar: süren akışlar yeniden denetlenir. */
    @Volatile var gen = 0
        private set
    /** Etkin fiziksel ağ (servisin ağ olayları günceller; yoksa [netProbe] birkaç saniyede bir sorulur). */
    @Volatile var net: NetKind = NetKind.NONE
        private set
    /** Platform: o anki ağ türü (WireGuard kipinde ağ olayı dinlenmez). */
    @Volatile var netProbe: (() -> NetKind)? = null
    @Volatile var clock: () -> Long = { System.currentTimeMillis() }
    @Volatile private var lastProbe = 0L

    private val lock = Any()
    private val counts = HashMap<String, Int>()
    /** WireGuard yolu: (proto, kaynak port, hedef, hedef port) → (karar 1 engel / 0 geç / 2 sahip bilinmiyor, zaman, kuşak). */
    private val flows = LinkedHashMap<Long, LongArray>(256, 0.75f, true)

    /** En az bir kural var mı? (Ucuz; paket yolunda ilk bakılan.) */
    val armed: Boolean get() = rules.isNotEmpty()

    fun setRules(m: Map<String, FwMode>) {
        val clean = m.filterKeys { AppScopes.validPkg(it) }
        if (clean == rules) return
        rules = clean
        bump()
    }

    fun setNet(k: NetKind) {
        lastProbe = clock()
        if (k == net) return
        net = k
        bump()
    }

    private fun bump() { synchronized(lock) { gen++; flows.clear() } }

    private fun refreshNet() {
        val p = netProbe ?: return
        val now = clock()
        if (now - lastProbe < NET_PROBE_MS && now >= lastProbe) return
        lastProbe = now
        val k = try { p() } catch (_: Exception) { return }
        if (k != net) { net = k; bump() }
    }

    /** Şu anki ağda en az bir kural engelliyor mu? (Değilse sahip sorgusu hiç yapılmaz.) */
    fun applies(): Boolean {
        val r = rules
        if (r.isEmpty()) return false
        refreshNet()
        val k = net
        return r.values.any { it.blocksOn(k) }
    }

    /** [pkg] şu anki ağda engelli mi? */
    fun blocks(pkg: String?): Boolean {
        if (pkg == null) return false
        return rules[pkg]?.blocksOn(net) == true
    }

    /** Bağlantı engellenmeli mi? Engellenirse sayaç artar. */
    fun blocked(proto: Int, src: ByteArray, sport: Int, dst: ByteArray, dport: Int): Boolean {
        if (!applies()) return false
        val pkg = AppAds.pkgOf(proto, src, sport, dst, dport) ?: return false
        if (!blocks(pkg)) return false
        note(pkg)
        return true
    }

    private fun note(pkg: String) = synchronized(lock) {
        if (counts.size < MAX_RULES * 2 || counts.containsKey(pkg)) counts[pkg] = (counts[pkg] ?: 0) + 1
    }

    /** Bu oturumda engellenen bağlantı denemesi sayısı. */
    fun count(pkg: String): Int = synchronized(lock) { counts[pkg] ?: 0 }

    /**
     * WireGuard tüneline giden ham IP paketi: engelli uygulamanınsa true (paket atılır). Akış kararı [FLOW_TTL_MS] önbellekte
     * tutulur (her pakette sahip sorulmaz); kural/ağ değişince önbellek boşalır. TCP/UDP dışı paketler ve parçalar geçer.
     */
    fun dropIp(p: ByteArray, len: Int): Boolean {
        if (!applies() || len < 20) return false
        val ver = (p[0].toInt() and 0xF0) ushr 4
        val proto: Int; val l4: Int; val sOff: Int; val dOff: Int; val aLen: Int
        if (ver == 4) {
            val ihl = (p[0].toInt() and 0x0F) * 4
            if (ihl < 20 || len < ihl + 4) return false
            if ((Packets.u16(p, 6) and 0x1FFF) != 0) return false            // parça (ilk parça değil): port yok
            proto = p[9].toInt() and 0xFF; l4 = ihl; sOff = 12; dOff = 16; aLen = 4
        } else if (ver == 6) {
            if (len < 44) return false
            proto = p[6].toInt() and 0xFF; l4 = 40; sOff = 8; dOff = 24; aLen = 16   // uzantı başlıklı paketler geçer (TCP/UDP doğrudan gelir)
        } else return false
        if (proto != 6 && proto != 17) return false
        val sport = Packets.u16(p, l4); val dport = Packets.u16(p, l4 + 2)
        var key = proto.toLong() * 1_000_003L + sport
        key = key * 1_000_003L + dport
        for (i in dOff until dOff + aLen) key = key * 131L + (p[i].toInt() and 0xFF)
        val now = clock()
        val g = gen
        synchronized(lock) {
            val c = flows[key]
            if (c != null && c[2] == g.toLong() && now - c[1] < (if (c[0] == 2L) UNKNOWN_TTL_MS else FLOW_TTL_MS) && now >= c[1]) return c[0] == 1L
        }
        // önbellekte yok: yalnızca burada kopya (her pakette bellek ayrılmaz)
        val pkg = AppAds.pkgOf(proto, p.copyOfRange(sOff, sOff + aLen), sport, p.copyOfRange(dOff, dOff + aLen), dport)
        val drop = blocks(pkg)
        synchronized(lock) {
            flows[key] = longArrayOf(if (drop) 1L else if (pkg == null) 2L else 0L, now, g.toLong())
            if (flows.size > MAX_FLOWS) { val it = flows.entries.iterator(); it.next(); it.remove() }
        }
        if (drop && pkg != null) note(pkg)
        return drop
    }

    fun reset() {
        rules = emptyMap(); net = NetKind.NONE; netProbe = null; lastProbe = 0L
        clock = { System.currentTimeMillis() }
        synchronized(lock) { counts.clear(); flows.clear(); gen++ }
    }

    // ---------------------------------------------------------------- kural kaydı

    /** "pkg=A,pkg2=M" biçimi; geçersiz paket adı ya da kip atılır. */
    fun encode(m: Map<String, FwMode>): String =
        m.filter { AppScopes.validPkg(it.key) }.toSortedMap().entries.take(MAX_RULES).joinToString(",") { it.key + "=" + it.value.id }

    fun decode(s: String?): Map<String, FwMode> {
        if (s.isNullOrBlank() || s.length > 100_000) return emptyMap()
        val out = LinkedHashMap<String, FwMode>()
        for (part in s.split(',')) {
            if (out.size >= MAX_RULES) break
            val i = part.lastIndexOf('=')
            if (i <= 0 || i != part.length - 2) continue
            val pkg = part.substring(0, i)
            val mode = FwMode.byId(part[i + 1]) ?: continue
            if (AppScopes.validPkg(pkg)) out[pkg] = mode
        }
        return out
    }

    /** Kayıtlı kurallar tünelin tüm trafiği almasını gerektiriyor mu? */
    fun needsGateway(s: String?): Boolean = decode(s).isNotEmpty()
}
