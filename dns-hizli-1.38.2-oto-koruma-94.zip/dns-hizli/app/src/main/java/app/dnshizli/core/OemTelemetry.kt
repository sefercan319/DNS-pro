package app.dnshizli.core

/**
 * Üretici izleme engeli: Samsung ve Xiaomi telefonların sistem uygulamalarının gönderdiği izleme (analiz/istatistik), reklam ve
 * reklam ölçüm adları tek anahtarla engellenir; süzgeç seviyesi kapalı ya da Basit olsa da çalışır. Ad, alt alan adlarıyla engellenir.
 *
 * Seçim TEMKİNLİDİR: yalnızca izleme/reklam/ölçüm adları. Hesap, bulut eşitleme, tema, mağaza, güncelleme, ödeme, hava durumu, kişi
 * eşitleme adları listede YOKTUR (engellenirse telefonun özellikleri bozulur). Kaynaklar (izin veren lisanslar):
 *  - GoodbyeAds Samsung AdBlock ve Xiaomi Extension listeleri (jerryn70, MIT) — süzülerek
 *  - NextDNS yerel izleyici listesi, Xiaomi (MIT)
 * Huawei, Oppo/Realme/OnePlus ve Vivo için izin veren lisanslı ayrıntılı bir kaynak bulunamadı (GPL listeler pakete gömülmez);
 * Huawei yerel izleyicileri Orta ve Sıkı süzgeçte (NextDNS listesi) zaten engellenir.
 */
object OemTelemetry {
    val SAMSUNG: List<String> = listOf(
        "samsungads.com", "samsungadhub.com", "samsungtvads.com", "samsungacr.com",
        "nmetrics.samsung.com", "smetrics.samsung.com", "insights.samsung.com", "bigdata.ssp.samsung.com",
        "analytics.samsungknox.com", "analytics-api.samsunghealthcn.com", "gpm.samsungqbe.com",
        "samsung-com.112.2o7.net", "samsung.demdex.net",
    )

    val XIAOMI: List<String> = listOf(
        "data.mistat.xiaomi.com", "data.mistat.intl.xiaomi.com", "data.mistat.india.xiaomi.com", "data.mistat.rus.xiaomi.com",
        "abtest.mistat.xiaomi.com", "abtest.mistat.intl.xiaomi.com", "o.data.mistat.xiaomi.com",
        "tracking.miui.com", "tracking.intl.miui.com", "tracking.india.miui.com", "tracking.rus.miui.com",
        "sa.api.intl.miui.com", "api.collect.data.intl.miui.com",
        "a.stat.xiaomi.com", "stat.xiaomi.com", "stats.xiaomi.com", "sg.a.stat.mi.com", "stat.pandora.xiaomi.com", "log.pandora.xiaomi.com",
        "ad.xiaomi.com", "ad.intl.xiaomi.com", "ad1.xiaomi.com", "ad.mi.com", "api.admob.xiaomi.com",
        "adv.sec.miui.com", "adv.sec.intl.miui.com", "info.analysis.kp.sec.miui.com", "mlog.search.xiaomi.net",
    )

    val ALL: List<String> get() = SAMSUNG + XIAOMI

    /** Cihaz üreticisi (Build.MANUFACTURER) bu listelerden birine giriyor mu: arayüzde "bu telefon: Xiaomi" bilgisi için. */
    fun brandOf(manufacturer: String?): String? {
        val m = manufacturer?.lowercase()?.trim() ?: return null
        return when {
            m.contains("samsung") -> "Samsung"
            m.contains("xiaomi") || m.contains("redmi") || m.contains("poco") -> "Xiaomi"
            else -> null
        }
    }

    /** Motora verilecek kullanıcı engel listesi: kendi engel listesi + (kişisel sürüm) YouTube + (açıksa) üretici izleme adları. */
    fun blockFor(s: AppSettings, personal: Boolean): List<String> {
        val base = YouTubeAds.blockFor(s, personal)
        return if (s.oemBlock) base + ALL.filter { it !in base } else base
    }
}
