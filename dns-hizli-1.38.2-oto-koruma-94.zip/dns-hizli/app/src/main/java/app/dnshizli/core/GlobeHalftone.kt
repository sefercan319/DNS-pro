package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.round
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Kara üzerindeki yarım ton noktaları: küreye sabitlenmiş enlem halkası ızgarası (halka aralığı Δ, halkada ~2π·cosφ/Δ nokta,
 * tek halkalar yarım adım kaydırılmış: altıgen düzen). Düzey k'de Δ = π / (64·2^k): yakınlaştıkça ızgara iki kat sıklaşır,
 * iki düzey saydamlıkla karışır, noktalar kaymaz. Yalnız ekranda görünebilecek enlem ve boylam aralığı üretilir; kaba kara
 * maskesinde deniz olan noktalar atlanır (kesin şekli kara yolu kırpar).
 */
object GlobeHalftone {
    const val BASE_RINGS = 64
    /** Ekranda en sık nokta aralığı (dp); düzeyler bunun 1..2 katı arasında. */
    const val MIN_SPACING = 1.5f

    /** Yarıçap [r] (dp) için kaba düzey ve ince düzeyin karışım payı (0..1). */
    fun levelFor(r: Float): Pair<Int, Float> {
        val k = floor(ln(PI * r / (BASE_RINGS * MIN_SPACING)) / ln(2.0)).toInt().coerceAtLeast(0)
        val s = (PI / (BASE_RINGS shl k) * r).toFloat()
        return k to ((s / MIN_SPACING - 1f).coerceIn(0f, 1f))
    }

    /** Düzey [k] ızgarasının küre üzerindeki toplam nokta sayısı. */
    fun totalPoints(k: Int): Long {
        val m = BASE_RINGS shl k; val d = PI / m; var n = 0L
        for (j in 0 until m) n += max(1, round(2 * PI * cos(-PI / 2 + (j + 0.5) * d) / d).toInt())
        return n
    }

    /**
     * Düzey [k] noktalarını ekran koordinatı olarak [out]'a ekler (x, y ardışık); eklenen sayıyı döner. [m]: kamera matrisi,
     * merkez ([cx], [cy]), ufuk yarıçapı [r], görünüm [w]×[h]; [lat0]/[lon0]: ekran merkezindeki nokta; [persp]: perspektif
     * katsayısı (0 = dik). [map] verilirse yalnız kaba maskenin kara aralıkları gezilir (deniz ve arka yüz hiç dolaşılmaz).
     */
    fun generate(k: Int, m: FloatArray, lat0: Double, lon0: Double, cx: Float, cy: Float, r: Float, w: Float, h: Float,
                 map: GlobeLand.VecMap?, out: Buf, limit: Int = 400_000, persp: Float = 0f): Int {
        val rings = BASE_RINGS shl k
        val d = PI / rings
        // görünen başlık: ekran köşegeni ile ufkun (perspektifte acos(P)) küçüğü
        val hd = sqrt(w * w + h * h) / 2f / r
        val horizon = acos(persp.toDouble().coerceIn(0.0, 1.0))
        val alpha = minOf(horizon, if (hd >= 0.999f) PI / 2 else asin(hd.toDouble())) + d
        val pp = persp; val ks = sqrt(1f - pp * pp)
        val sinC = sin(lat0); val cosC = cos(lat0)
        val jLo = max(0, floor((lat0 - alpha + PI / 2) / d - 0.5).toInt())
        val jHi = minOf(rings - 1, floor((lat0 + alpha + PI / 2) / d + 0.5).toInt())
        val cosA = cos(alpha)
        val n0 = out.n
        val m0 = m[0]; val m1 = m[1]; val m3 = m[3]; val m4 = m[4]; val m6 = m[6]; val m7 = m[7]
        val pad = 3f
        val W = GlobeVec.MASK_W
        for (j in jLo..jHi) {
            val phi = -PI / 2 + (j + 0.5) * d
            val sp = sin(phi); val cp = cos(phi)
            val cnt = max(1, round(2 * PI * cp / d).toInt())
            val dl = 2 * PI / cnt
            val off = if (j and 1 == 1) 0.5 else 0.0
            // görünen boylam aralığı (dizin uzayında; sarmalanabilir)
            var iFrom: Int; var iTo: Int
            if (cp < 1e-9 || cosC < 1e-9) { iFrom = 0; iTo = cnt - 1 }
            else {
                val c = (cosA - sp * sinC) / (cp * cosC)
                if (c >= 1.0) continue
                if (c <= -1.0) { iFrom = 0; iTo = cnt - 1 }
                else {
                    val half = acos(c) + dl
                    iFrom = floor((lon0 - half + PI) / dl - off).toInt(); iTo = floor((lon0 + half + PI) / dl - off).toInt() + 1
                    if (iTo - iFrom >= cnt) { iFrom = 0; iTo = cnt - 1 }
                }
            }
            val spf = sp.toFloat(); val cpf = cp.toFloat()
            val zz = m[8] * spf; val xz = m[2] * spf; val yz = m[5] * spf
            // gezilecek aralıklar: kara aralıkları (maske) ∩ görünen aralık
            val row = ((PI / 2 - phi) / PI * GlobeVec.MASK_H).toInt().coerceIn(0, GlobeVec.MASK_H - 1)
            val rFrom = map?.runStart?.get(row) ?: 0; val rTo = map?.runStart?.get(row + 1) ?: 1
            for (ri in rFrom until rTo) {
                val iA: Int; val iB: Int
                if (map == null) { iA = 0; iB = cnt - 1 }
                else {
                    val c0 = map.runs[2 * ri]; val c1 = map.runs[2 * ri + 1]
                    iA = kotlin.math.ceil((c0.toDouble() / W * 2 * PI) / dl - off).toInt()
                    iB = kotlin.math.ceil((c1.toDouble() / W * 2 * PI) / dl - off).toInt() - 1
                    if (iB < iA) continue
                }
                for (t in -1..1) {
                    val lo = maxOf(iA + t * cnt, iFrom); val hi = minOf(iB + t * cnt, iTo)
                    if (lo > hi) continue
                    // boylamı artımlı döndür (nokta başına trigonometri yok)
                    val lam0 = -PI + (lo + off) * dl
                    var cl = cos(lam0); var sl = sin(lam0)
                    val cd = cos(dl); val sd = sin(dl)
                    for (q in lo..hi) {
                        val wx = cpf * cl.toFloat(); val wy = cpf * sl.toFloat()
                        val z = m6 * wx + m7 * wy + zz
                        if (z > pp + 0.01f * (1f - pp)) {
                            val sc = r * ks / (1f - pp * z)
                            val sx = cx + sc * (m0 * wx + m1 * wy + xz)
                            val sy = cy - sc * (m3 * wx + m4 * wy + yz)
                            if (sx > -pad && sx < w + pad && sy > -pad && sy < h + pad) {
                                out.add(sx, sy)
                                if (out.n - n0 >= limit) return out.n - n0
                            }
                        }
                        val ncl = cl * cd - sl * sd; sl = sl * cd + cl * sd; cl = ncl
                    }
                }
            }
        }
        return out.n - n0
    }

    /** Büyüyen kayan nokta tamponu (x, y çiftleri). */
    class Buf { var a = FloatArray(8192); var n = 0
        fun clear() { n = 0 }
        fun add(x: Float, y: Float) { if (2 * n + 2 > a.size) a = a.copyOf(a.size * 2); a[2 * n] = x; a[2 * n + 1] = y; n++ } }
}
