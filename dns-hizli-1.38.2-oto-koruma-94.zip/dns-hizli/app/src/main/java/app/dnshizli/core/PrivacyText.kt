package app.dnshizli.core

/** Gizlilik raporu sayfasının 12 dildeki metinleri. Sıra: TR, EN, DE, ES, FR, PT, RU, IT, ID, VI, PL, UK. */
object PrivacyText {
    val M: Map<String, Array<String>> = mapOf(
        "title" to arrayOf("Gizlilik raporu", "Privacy report", "Datenschutzbericht", "Informe de privacidad", "Rapport de confidentialité", "Relatório de privacidade",
            "Отчёт о приватности", "Rapporto sulla privacy", "Laporan privasi", "Báo cáo quyền riêng tư", "Raport prywatności", "Звіт про приватність"),
        "summary" to arrayOf("{0} engelleme", "{0} blocked", "{0} blockiert", "{0} bloqueos", "{0} blocages", "{0} bloqueios", "заблокировано: {0}", "{0} blocchi",
            "{0} diblokir", "{0} lượt chặn", "zablokowano: {0}", "заблоковано: {0}"),
        "empty" to arrayOf(
            "Son 7 günde engellenen izleyici yok. Bağlıyken ve engelleme açıkken hangi uygulamanın hangi izleyici ve reklam alanlarına bağlanmaya çalıştığı burada birikir.",
            "No trackers blocked in the last 7 days. While connected with blocking on, this collects which app tried to reach which tracker and ad domains.",
            "In den letzten 7 Tagen wurden keine Tracker blockiert. Bei aktiver Verbindung und Blockierung wird hier gesammelt, welche App welche Tracker- und Werbedomains erreichen wollte.",
            "No se bloquearon rastreadores en los últimos 7 días. Con la conexión y el bloqueo activos, aquí se acumula qué app intentó contactar qué dominios de rastreo y anuncios.",
            "Aucun traqueur bloqué ces 7 derniers jours. Connecté avec le blocage actif, vous verrez ici quelle appli a tenté de joindre quels domaines de pistage et de pub.",
            "Nenhum rastreador bloqueado nos últimos 7 dias. Conectado e com o bloqueio ativo, aqui se acumula qual app tentou acessar quais domínios de rastreamento e anúncios.",
            "За последние 7 дней трекеры не блокировались. При подключении и включённой блокировке здесь собирается, какое приложение пыталось обратиться к каким трекерам и рекламным доменам.",
            "Nessun tracker bloccato negli ultimi 7 giorni. Con connessione e blocco attivi, qui si raccoglie quale app ha tentato di contattare quali domini di tracciamento e pubblicità.",
            "Tidak ada pelacak yang diblokir dalam 7 hari terakhir. Saat terhubung dan pemblokiran aktif, di sini terkumpul aplikasi mana mencoba menghubungi domain pelacak dan iklan apa.",
            "Không có trình theo dõi nào bị chặn trong 7 ngày qua. Khi đã kết nối và bật chặn, tại đây sẽ ghi lại ứng dụng nào đã cố kết nối tới tên miền theo dõi và quảng cáo nào.",
            "W ostatnich 7 dniach nie zablokowano żadnych trackerów. Przy włączonym połączeniu i blokowaniu zbiera się tu, która aplikacja próbowała połączyć się z jakimi domenami śledzącymi i reklamowymi.",
            "За останні 7 днів трекери не блокувалися. Коли з'єднання та блокування ввімкнено, тут збирається, який застосунок намагався звернутися до яких трекерів і рекламних доменів."),
        "foot" to arrayOf(
            "Son 7 gün. Her engelleme, uygulamanın bir izleyici ya da reklam alanına bağlanma denemesidir. Rapor yalnızca bu telefonda tutulur; hiçbir yere gönderilmez ve yedeklenmez.",
            "Last 7 days. Each block is an attempt by the app to reach a tracker or ad domain. The report stays on this phone only; it is never sent anywhere or backed up.",
            "Letzte 7 Tage. Jede Sperre ist ein Versuch der App, eine Tracker- oder Werbedomain zu erreichen. Der Bericht bleibt nur auf diesem Telefon; er wird nie gesendet oder gesichert.",
            "Últimos 7 días. Cada bloqueo es un intento de la app de contactar un dominio de rastreo o anuncios. El informe solo se guarda en este teléfono; nunca se envía ni se respalda.",
            "7 derniers jours. Chaque blocage est une tentative de l'appli de joindre un domaine de pistage ou de pub. Le rapport reste sur ce téléphone ; il n'est jamais envoyé ni sauvegardé.",
            "Últimos 7 dias. Cada bloqueio é uma tentativa do app de acessar um domínio de rastreamento ou anúncios. O relatório fica só neste telefone; nunca é enviado nem copiado.",
            "Последние 7 дней. Каждая блокировка — попытка приложения обратиться к трекеру или рекламному домену. Отчёт хранится только на этом телефоне; никуда не отправляется и не копируется.",
            "Ultimi 7 giorni. Ogni blocco è un tentativo dell'app di contattare un dominio di tracciamento o pubblicità. Il rapporto resta solo su questo telefono; non viene mai inviato né salvato altrove.",
            "7 hari terakhir. Setiap blokir adalah upaya aplikasi menghubungi domain pelacak atau iklan. Laporan hanya disimpan di ponsel ini; tidak pernah dikirim atau dicadangkan.",
            "7 ngày qua. Mỗi lượt chặn là một lần ứng dụng cố kết nối tới tên miền theo dõi hoặc quảng cáo. Báo cáo chỉ lưu trên điện thoại này; không bao giờ được gửi đi hay sao lưu.",
            "Ostatnie 7 dni. Każda blokada to próba połączenia aplikacji z domeną śledzącą lub reklamową. Raport zostaje tylko na tym telefonie; nigdy nie jest wysyłany ani archiwizowany.",
            "Останні 7 днів. Кожне блокування — спроба застосунку звернутися до трекера чи рекламного домену. Звіт зберігається лише на цьому телефоні; нікуди не надсилається й не копіюється."),
        "distinct" to arrayOf("{0} farklı alan", "{0} different domains", "{0} verschiedene Domains", "{0} dominios distintos", "{0} domaines différents", "{0} domínios diferentes",
            "доменов: {0}", "{0} domini diversi", "{0} domain berbeda", "{0} tên miền khác nhau", "różnych domen: {0}", "доменів: {0}"),
        "detail" to arrayOf(
            "Son 7 günde {0} farklı izleyici/reklam alanına {1} kez bağlanmaya çalıştı; hepsi engellendi.",
            "In the last 7 days it tried {1} times to reach {0} different tracker/ad domains; all were blocked.",
            "In den letzten 7 Tagen versuchte sie {1}-mal, {0} verschiedene Tracker-/Werbedomains zu erreichen; alle wurden blockiert.",
            "En los últimos 7 días intentó {1} veces contactar {0} dominios distintos de rastreo/anuncios; todos se bloquearon.",
            "Ces 7 derniers jours, elle a tenté {1} fois de joindre {0} domaines de pistage/pub différents ; tous ont été bloqués.",
            "Nos últimos 7 dias tentou {1} vezes acessar {0} domínios diferentes de rastreamento/anúncios; todos foram bloqueados.",
            "За последние 7 дней приложение {1} раз пыталось обратиться к трекерам/рекламным доменам (разных: {0}); все попытки заблокированы.",
            "Negli ultimi 7 giorni ha tentato {1} volte di contattare {0} domini diversi di tracciamento/pubblicità; tutti bloccati.",
            "Dalam 7 hari terakhir aplikasi ini mencoba {1} kali menghubungi {0} domain pelacak/iklan berbeda; semuanya diblokir.",
            "Trong 7 ngày qua ứng dụng đã cố {1} lần kết nối tới {0} tên miền theo dõi/quảng cáo khác nhau; tất cả đều bị chặn.",
            "W ostatnich 7 dniach aplikacja {1} razy próbowała połączyć się z domenami śledzącymi/reklamowymi (różnych: {0}); wszystkie zablokowano.",
            "За останні 7 днів застосунок {1} разів намагався звернутися до трекерів/рекламних доменів (різних: {0}); усі спроби заблоковано."),
        "daily" to arrayOf("Gün gün (eskiden bugüne): {0}", "Day by day (oldest to today): {0}", "Tag für Tag (älteste bis heute): {0}", "Día a día (del más antiguo a hoy): {0}",
            "Jour par jour (du plus ancien à aujourd'hui) : {0}", "Dia a dia (do mais antigo a hoje): {0}", "По дням (от старых к сегодня): {0}", "Giorno per giorno (dal più vecchio a oggi): {0}",
            "Per hari (terlama hingga hari ini): {0}", "Theo ngày (cũ nhất đến hôm nay): {0}", "Dzień po dniu (od najstarszego do dziś): {0}", "По днях (від давніх до сьогодні): {0}"),
        "mode" to arrayOf("Engelleme kipi", "Blocking mode", "Blockiermodus", "Modo de bloqueo", "Mode de blocage", "Modo de bloqueio", "Режим блокировки", "Modalità di blocco",
            "Mode pemblokiran", "Chế độ chặn", "Tryb blokowania", "Режим блокування"),
        "reset" to arrayOf("Raporu sil", "Delete report", "Bericht löschen", "Borrar informe", "Supprimer le rapport", "Apagar relatório", "Удалить отчёт", "Elimina rapporto",
            "Hapus laporan", "Xóa báo cáo", "Usuń raport", "Видалити звіт"),
        "noNames" to arrayOf(
            "\"Geçmişi tut\" kapalı: alan adları tutulmuyor, yalnızca sayılar.",
            "\"Keep history\" is off: domain names are not kept, only counts.",
            "„Verlauf behalten“ ist aus: Domainnamen werden nicht gespeichert, nur Zahlen.",
            "\"Guardar historial\" está desactivado: no se guardan dominios, solo cifras.",
            "« Conserver l'historique » est désactivé : seuls les nombres sont gardés, pas les domaines.",
            "\"Manter histórico\" está desativado: só os números são guardados, não os domínios.",
            "«Хранить историю» выключено: сохраняются только числа, без доменов.",
            "\"Conserva cronologia\" è disattivato: si conservano solo i numeri, non i domini.",
            "\"Simpan riwayat\" nonaktif: hanya angka yang disimpan, bukan nama domain.",
            "\"Giữ lịch sử\" đang tắt: chỉ lưu số lượng, không lưu tên miền.",
            "„Zachowuj historię” jest wyłączone: zapisywane są tylko liczby, bez domen.",
            "«Зберігати історію» вимкнено: зберігаються лише числа, без доменів."),
    )

    fun codes(): Set<String> = M.keys

    fun t(key: String, lang: Lang = L.lang, vararg args: String): String {
        val row = M[key] ?: return key
        var s = row.getOrNull(lang.ordinal)?.takeIf { it.isNotBlank() } ?: row.getOrNull(Lang.EN.ordinal) ?: row[0]
        for ((i, a) in args.withIndex()) s = s.replace("{$i}", a)
        return s
    }
}
