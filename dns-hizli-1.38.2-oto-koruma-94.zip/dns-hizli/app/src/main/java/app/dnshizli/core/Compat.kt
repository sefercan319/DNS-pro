package app.dnshizli.core

/** Çalışma anında ölçülen koşullar (platform toplar). Varsayılanlar "sorunsuz" durumdur. */
data class CompatFacts(
    val batterySaver: Boolean = false,
    /** Uygulama pil optimizasyonundan muaf mı? (Bilinmiyorsa true: yanlış uyarı verilmez.) */
    val ignoresBatteryOpt: Boolean = true,
    val metered: Boolean = false,
    val mobile: Boolean = false,
    val v6Only: Boolean = false,
    /** Soket TTL ayarı en az bir kez reddedildi (sahte paket yöntemleri çalışmaz). */
    val ttlBroken: Boolean = false,
    /** Isınma düzeyi (Android PowerManager termal durumu: 0 yok, 1 hafif, 2 orta, 3 ciddi, 4 kritik…). Bilinmiyorsa 0. */
    val thermal: Int = 0,
)

/** Uyum notu: kod + değişkenler; metin görüntülenirken seçili dilde üretilir ([AuditText]). */
data class Note(val code: String, val args: List<String> = emptyList()) {
    val text: String get() = AuditText.render(code, args, L.lang)
    fun text(lang: Lang): String = AuditText.render(code, args, lang)
}

/**
 * Uyum planı: ağ geçidine ve denetçiye uygulanan değerler ve kullanıcıya gösterilen notlar.
 * [maxTcp]/[maxUdp] açık akış sınırı, [udpIdleMs]/[tcpIdleMs] boşta kalma süresi, [hedge] paralel yedek bağlantı denemesi,
 * [summaryMs]/[auditMs] günlük özeti ve denetim aralığı, [recommendLight] filtre belleğinin "Hafif" olması önerisi.
 */
class CompatPlan(
    val maxTcp: Int, val maxUdp: Int,
    val udpIdleMs: Long, val tcpIdleMs: Long,
    val hedge: Boolean,
    val summaryMs: Long, val auditMs: Long,
    val recommendLight: Boolean,
    val notes: List<Note>,
) {
    fun noteTexts(lang: Lang = L.lang): List<String> = notes.map { it.text(lang) }
}

/**
 * Katmanlı uyum kuralları (saf mantık, [DeviceProfile] + [CompatFacts] verilir). Katmanlar sırayla uygulanır ve yalnızca
 * KISAR (hiçbir katman sınırı artırmaz), bu yüzden sonuç katman sırasından bağımsız ve daha çok kısıtla hep daha temkinlidir:
 *  1) cihaz sınıfı ve bellek  2) arka planda kapatılma eğilimi (üretici/ROM)  3) pil tasarrufu  4) ağ türü (ölçülü mobil, yalnızca IPv6)
 *  5) soket yetenekleri (TTL)  6) bileşik kısıt (≥2 kısıt birden → ek daraltma + Hafif filtre önerisi)  7) sistem sürümü.
 */
object Compat {
    const val TCP_DEFAULT = 1500
    const val UDP_DEFAULT = 400
    const val TCP_MIN = 200
    const val UDP_MIN = 80

    fun plan(p: DeviceProfile?, facts: CompatFacts = CompatFacts()): CompatPlan {
        val notes = ArrayList<Note>()
        var tcp: Int; var udp: Int
        var constraints = 0
        var summary = 5 * 60_000L
        var audit = 30_000L
        var hedge = true
        var udpIdle = 30_000L
        var tcpIdle = 15 * 60_000L
        if (p == null) {
            tcp = 1000; udp = 300
            notes += Note("c.pending")
        } else {
            val i = p.info
            // 1) sınıf ve bellek
            tcp = when (p.tier) { DeviceTier.LOW -> 500; DeviceTier.MID -> 1000; DeviceTier.HIGH -> TCP_DEFAULT }
            udp = when (p.tier) { DeviceTier.LOW -> 150; DeviceTier.MID -> 250; DeviceTier.HIGH -> UDP_DEFAULT }
            if (p.tier == DeviceTier.LOW) { constraints++; notes += Note("c.lowtier") }
            if (i.heapMb in 1..127) { tcp = minOf(tcp, 400); udp = minOf(udp, 120); constraints++; notes += Note("c.heap", listOf(i.heapMb.toString())) }
            if (i.lowRamFlag) { tcp = minOf(tcp, 500); udp = minOf(udp, 150); constraints++; notes += Note("c.lowram") }
            // 2) kapatılma eğilimi
            when (p.kill) {
                KillRisk.HIGH -> { constraints++; summary = 3 * 60_000L; tcpIdle = 10 * 60_000L; notes += Note("c.kill-high", listOf(p.rom.label)) }
                KillRisk.MEDIUM -> notes += Note("c.kill-med", listOf(p.rom.label))
                KillRisk.LOW -> {}
            }
            if (p.kill != KillRisk.LOW && !facts.ignoresBatteryOpt) notes += Note("c.battery-opt")
            when (p.family) {
                OemCompat.Family.XIAOMI -> notes += Note("c.bg-xiaomi")
                OemCompat.Family.HUAWEI, OemCompat.Family.HONOR -> notes += Note("c.bg-huawei")
                OemCompat.Family.OPPO, OemCompat.Family.ONEPLUS -> notes += Note("c.bg-oppo")
                OemCompat.Family.VIVO -> notes += Note("c.bg-vivo")
                OemCompat.Family.SAMSUNG -> notes += Note("c.samsung")
                else -> {}
            }
            if (p.rom.custom) notes += Note("c.custom", listOf(p.rom.label))
            if (p.rom == Rom.GRAPHENE || p.rom == Rom.CALYX) notes += Note("c.graphene", listOf(p.rom.label))
            // 7) sistem sürümü
            if (i.sdk in 1..28) notes += Note("c.old", listOf(i.sdk.toString()))
        }
        // 3) pil tasarrufu
        if (facts.batterySaver) {
            constraints++
            hedge = false; summary *= 2; audit = 60_000L
            tcp = tcp * 4 / 5; udp = udp * 4 / 5
            notes += Note("c.powersave")
        }
        // 4) ağ
        if (facts.metered && facts.mobile) { udpIdle = 20_000L; notes += Note("c.metered") }
        if (facts.v6Only) notes += Note("c.v6only")
        // 5) soket yetenekleri
        if (facts.ttlBroken) notes += Note("c.ttl")
        // 6) bileşik kısıt
        var light = false
        if (constraints >= 2) {
            tcp = tcp * 3 / 5; udp = udp * 3 / 5
            light = true
            notes += Note("c.heavy")
        }
        return CompatPlan(
            maxTcp = tcp.coerceIn(TCP_MIN, TCP_DEFAULT), maxUdp = udp.coerceIn(UDP_MIN, UDP_DEFAULT),
            udpIdleMs = udpIdle, tcpIdleMs = tcpIdle, hedge = hedge, summaryMs = summary, auditMs = audit,
            recommendLight = light, notes = notes,
        )
    }
}

/** Servisin en son ölçtüğü koşullar; arayüz/rapor aynı planı gösterebilsin diye. */
object CompatLive {
    @Volatile var facts: CompatFacts = CompatFacts()
    fun plan(): CompatPlan = Compat.plan(DeviceTune.profile, facts)
}
