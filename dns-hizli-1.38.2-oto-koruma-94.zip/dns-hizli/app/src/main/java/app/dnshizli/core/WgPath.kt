package app.dnshizli.core

/**
 * WireGuard bağlantı yolu seçimi (Smart kip). Yapılandırmada hem doğrudan UDP uç noktası hem [Stealth] varsa:
 *  - Otomatik: önce UDP (hızlı). El sıkışma [UDP_GIVE_UP_MS] içinde bitmezse (UDP engelli / WireGuard imzası kesiliyor) Stealth'e geçer.
 *    Stealth'te de [STEALTH_GIVE_UP_MS] boyunca bağlanamazsa ve UDP en az [RETRY_UDP_MS] önce denendiyse UDP yeniden denenir.
 *    Ağ değişince UDP yeniden denenir (yeni ağda UDP açık olabilir).
 *  - UDP / Stealth: yalnız o yol (yoksa diğerine düşülür; hiç yol yoksa yapılandırma zaten geçersizdir).
 * Saf karar mantığı; zaman dışarıdan verilir. Bekleyen el sıkışma süresi yolun başladığı andan sayılır (geçişten önceki süre sayılmaz).
 */
class WgPath(mode: Mode, val hasUdp: Boolean, val hasStealth: Boolean, now: Long) {
    enum class Mode(val id: String) {
        AUTO("auto"), UDP("udp"), STEALTH("stealth");
        companion object { fun of(id: String?): Mode = values().firstOrNull { it.id == id } ?: AUTO }
    }
    enum class Path { UDP, STEALTH }

    var mode: Mode = mode; private set
    var path: Path = initial(mode); private set
    var switches = 0; private set
    private var pathSince = now
    private var udpFailedAt = Long.MIN_VALUE / 2

    private val smart get() = mode == Mode.AUTO && hasUdp && hasStealth

    private fun initial(m: Mode): Path = when (m) {
        Mode.STEALTH -> if (hasStealth) Path.STEALTH else Path.UDP
        Mode.UDP -> if (hasUdp) Path.UDP else Path.STEALTH
        Mode.AUTO -> if (hasUdp) Path.UDP else Path.STEALTH
    }

    /** Saniyede bir. [pendingMs]: süren el sıkışmanın yaşı (yoksa -1). Yol değişirse yeni yol, yoksa null. */
    @Synchronized fun onTick(now: Long, pendingMs: Long): Path? {
        if (!smart || pendingMs < 0) return null
        val waited = minOf(pendingMs, now - pathSince)
        if (path == Path.UDP && waited >= UDP_GIVE_UP_MS) { udpFailedAt = now; return switchTo(Path.STEALTH, now) }
        if (path == Path.STEALTH && waited >= STEALTH_GIVE_UP_MS && now - udpFailedAt >= RETRY_UDP_MS) return switchTo(Path.UDP, now)
        return null
    }

    /** Ağ değişti: otomatikte UDP yeniden denenir. */
    @Synchronized fun onNetworkChanged(now: Long): Path? {
        if (!smart) return null
        udpFailedAt = Long.MIN_VALUE / 2
        return if (path == Path.STEALTH) switchTo(Path.UDP, now) else { pathSince = now; null }
    }

    /** Kullanıcı kipi değiştirdi (bağlıyken). */
    @Synchronized fun setMode(m: Mode, now: Long): Path? {
        mode = m
        val want = when {
            m == Mode.AUTO -> path                      // otomatik: bulunduğu yolda kalır, gerekirse kendisi geçer
            else -> initial(m)
        }
        return if (want != path) switchTo(want, now) else null
    }

    private fun switchTo(p: Path, now: Long): Path { path = p; pathSince = now; switches++; return p }

    companion object {
        const val UDP_GIVE_UP_MS = 7_000L           // WireGuard 5 sn'de yeniden dener: iki başlatma cevapsız
        const val STEALTH_GIVE_UP_MS = 30_000L
        const val RETRY_UDP_MS = 120_000L
    }
}
