package app.dnshizli.platform

import android.content.Context
import app.dnshizli.core.Cosmetic
import app.dnshizli.core.Journal
import app.dnshizli.core.KeyVault
import app.dnshizli.core.KeyWrapper
import app.dnshizli.core.MitmCa
import java.io.File

/** Tarayıcı kipinin yerel CA'sı: uygulamanın özel klasöründe (yedeklenmez) tutulur; yoksa, bozuksa ya da kural alanları değiştiyse (Ad Kısıtı eşleşmez) yeniden üretilir; yeni sertifika yeniden kurulmalıdır. */
object MitmStore {
    private var cached: MitmCa? = null

    @Synchronized fun get(ctx: Context): MitmCa {
        cached?.let { return it }
        val dir = File(ctx.filesDir, "mitm").also { it.mkdirs() }
        val kf = File(dir, "ca.key")
        val cf = File(dir, "ca.crt")
        val xf = File(dir, "inter.crt")
        val domains = Cosmetic.BUILTIN.domains()
        val loaded = try {
            if (kf.exists() && cf.exists() && xf.exists()) {
                // Anahtar dosyası Keystore ile sarılıdır; eski düz dosya burada okunup sarılı biçime çevrilir.
                val k = KeyVault.load(kf.readBytes(), KeystoreWrapper)
                k.rewrite?.let { try { kf.writeBytes(it); Journal.add("CA anahtarı Keystore ile sarıldı") } catch (_: Exception) {} }
                k.plain?.let { MitmCa.load(it, cf.readBytes(), xf.readBytes(), domains = domains) }
            } else null
        } catch (_: Exception) { null }
        val ca = loaded ?: MitmCa.generate(domains).also {
            try { cf.writeBytes(it.certDer()); xf.writeBytes(it.interDer()); kf.writeBytes(KeyVault.store(it.keyBytes(), KeystoreWrapper)) } catch (_: Exception) { /* yazılamadı: bu oturumda bellekte kalır */ }
        }
        cached = ca
        return ca
    }
}

/** Android Keystore'daki AES-GCM anahtarıyla sarma: çıktı = 12 bayt IV + şifreli metin (+ etiket). Anahtar cihazdan çıkamaz. */
internal object KeystoreWrapper : AndroidKeystoreWrapper("dnshizli_mitm_ca_wrap")

/** Her sır türü kendi Keystore anahtarını kullanır (biri silinse/bozulsa diğeri etkilenmez). */
internal open class AndroidKeystoreWrapper(private val ALIAS: String) : KeyWrapper {
    private val PROVIDER = "AndroidKeyStore"
    private val IV_LEN = 12

    private fun key(): javax.crypto.SecretKey {
        val ks = java.security.KeyStore.getInstance(PROVIDER).apply { load(null) }
        (ks.getKey(ALIAS, null) as? javax.crypto.SecretKey)?.let { return it }
        val g = javax.crypto.KeyGenerator.getInstance(android.security.keystore.KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        g.init(
            android.security.keystore.KeyGenParameterSpec.Builder(ALIAS, android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return g.generateKey()
    }

    override fun wrap(plain: ByteArray): ByteArray? = try {
        val c = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        c.init(javax.crypto.Cipher.ENCRYPT_MODE, key())
        c.iv + c.doFinal(plain)
    } catch (e: Exception) { Journal.add("Keystore sarma yapılamadı: ${e.javaClass.simpleName}"); null }

    override fun unwrap(blob: ByteArray): ByteArray? = try {
        if (blob.size <= IV_LEN + 16) null else {
            val c = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
            c.init(javax.crypto.Cipher.DECRYPT_MODE, key(), javax.crypto.spec.GCMParameterSpec(128, blob, 0, IV_LEN))
            c.doFinal(blob, IV_LEN, blob.size - IV_LEN)
        }
    } catch (e: Exception) { Journal.add("Keystore açma yapılamadı: ${e.javaClass.simpleName}"); null }
}
