package app.dnshizli.core

/** DNS bölme metinleri (12 dil). Sıra: TR, EN, DE, ES, FR, PT, RU, IT, ID, VI, PL, UK. */
object SplitText {
    val M: Map<String, Array<String>> = mapOf(
        "title" to arrayOf("Sorguları sağlayıcılara böl", "Split queries across providers", "Anfragen auf Anbieter verteilen", "Repartir consultas entre proveedores",
            "Répartir les requêtes entre fournisseurs", "Dividir consultas entre provedores", "Распределять запросы между провайдерами", "Dividi le richieste tra provider",
            "Bagi kueri ke beberapa penyedia", "Chia truy vấn cho nhiều nhà cung cấp", "Rozdzielaj zapytania między dostawców", "Розподіляти запити між провайдерами"),
        "note" to arrayOf(
            "Siteler 2–3 sağlayıcıya dağıtılır; hiçbiri geçmişin tamamını görmez",
            "Sites are spread over 2–3 providers; none sees your whole history",
            "Websites auf 2–3 Anbieter verteilt; keiner sieht alles",
            "Sitios repartidos entre 2–3 proveedores; ninguno lo ve todo",
            "Sites répartis entre 2–3 fournisseurs ; aucun ne voit tout",
            "Sites divididos entre 2–3 provedores; nenhum vê tudo",
            "Сайты делятся между 2–3 провайдерами; никто не видит всё",
            "Siti divisi tra 2–3 provider; nessuno vede tutto",
            "Situs dibagi ke 2–3 penyedia; tak satu pun melihat semuanya",
            "Chia trang cho 2–3 nhà cung cấp; không ai thấy hết",
            "Strony dzielone między 2–3 dostawców; nikt nie widzi wszystkiego",
            "Сайти діляться між 2–3 провайдерами; ніхто не бачить усього"),
        "partners" to arrayOf("Ortak sağlayıcılar", "Partner providers", "Partner-Anbieter", "Proveedores asociados", "Fournisseurs associés", "Provedores parceiros",
            "Дополнительные провайдеры", "Provider aggiuntivi", "Penyedia mitra", "Nhà cung cấp đi kèm", "Dodatkowi dostawcy", "Додаткові провайдери"),
        "auto" to arrayOf("Otomatik (önerilen)", "Automatic (recommended)", "Automatisch (empfohlen)", "Automático (recomendado)", "Automatique (recommandé)", "Automático (recomendado)",
            "Автоматически (рекомендуется)", "Automatico (consigliato)", "Otomatis (disarankan)", "Tự động (khuyên dùng)", "Automatycznie (zalecane)", "Автоматично (рекомендовано)"),
        "foot" to arrayOf(
            "Her site (alt adlarıyla) hep aynı sağlayıcıya gider. En çok 2 ortak seçin. Otomatikte, seçili sunucunun türüne uygun (aile, güvenlik, reklam süzgeçli ya da süzgeçsiz) şifreli sağlayıcılar kullanılır; böylece bölme süzgeci delmez. Bir sağlayıcı yanıt vermezse onun siteleri 1 dakikalığına diğerine gider. ODoH açıkken bölme kullanılmaz (ODoH zaten sunucudan gizler).",
            "Each site (with its subdomains) always goes to the same provider. Pick up to 2 partners. Automatic uses encrypted providers of the same kind as the selected server (family, security, ad-filtering or unfiltered), so splitting never bypasses filtering. If a provider stops answering, its sites go to another for 1 minute. Splitting is not used while ODoH is on (ODoH already hides you from the server).",
            "Jede Website (mit Subdomains) geht immer zum selben Anbieter. Bis zu 2 Partner wählen. Automatisch nutzt verschlüsselte Anbieter derselben Art wie der gewählte Server (Familie, Sicherheit, Werbefilter oder ungefiltert), damit das Verteilen keinen Filter umgeht. Antwortet ein Anbieter nicht, gehen seine Websites 1 Minute lang an einen anderen. Bei aktivem ODoH wird nicht verteilt (ODoH verbirgt Sie bereits vor dem Server).",
            "Cada sitio (con sus subdominios) va siempre al mismo proveedor. Elige hasta 2 socios. En automático se usan proveedores cifrados del mismo tipo que el servidor elegido (familiar, seguridad, filtro de anuncios o sin filtro), así repartir nunca salta el filtro. Si un proveedor no responde, sus sitios van a otro durante 1 minuto. Con ODoH activo no se reparte (ODoH ya te oculta del servidor).",
            "Chaque site (avec ses sous-domaines) va toujours au même fournisseur. Choisissez jusqu'à 2 partenaires. En automatique, des fournisseurs chiffrés du même type que le serveur choisi (famille, sécurité, anti-pub ou sans filtre) sont utilisés : la répartition ne contourne jamais le filtrage. Si un fournisseur ne répond plus, ses sites passent à un autre pendant 1 minute. Pas de répartition avec ODoH (ODoH vous cache déjà du serveur).",
            "Cada site (com seus subdomínios) vai sempre ao mesmo provedor. Escolha até 2 parceiros. No automático são usados provedores criptografados do mesmo tipo do servidor escolhido (família, segurança, filtro de anúncios ou sem filtro), então a divisão nunca fura o filtro. Se um provedor não responder, os sites dele vão para outro por 1 minuto. Com ODoH ativo não há divisão (o ODoH já esconde você do servidor).",
            "Каждый сайт (с поддоменами) всегда идёт к одному провайдеру. Выберите до 2 партнёров. Автоматически берутся шифрованные провайдеры того же типа, что и выбранный сервер (семейный, защита, без рекламы или без фильтра), поэтому распределение не обходит фильтр. Если провайдер не отвечает, его сайты на 1 минуту уходят к другому. При включённом ODoH распределения нет (ODoH и так скрывает вас от сервера).",
            "Ogni sito (con i sottodomini) va sempre allo stesso provider. Scegli fino a 2 partner. In automatico si usano provider cifrati dello stesso tipo del server scelto (famiglia, sicurezza, anti-pubblicità o senza filtro), così la divisione non aggira mai il filtro. Se un provider non risponde, i suoi siti passano a un altro per 1 minuto. Con ODoH attivo non si divide (ODoH ti nasconde già dal server).",
            "Setiap situs (beserta subdomainnya) selalu ke penyedia yang sama. Pilih hingga 2 mitra. Mode otomatis memakai penyedia terenkripsi sejenis dengan server terpilih (keluarga, keamanan, penyaring iklan, atau tanpa filter), jadi pembagian tidak pernah melewati filter. Jika penyedia tidak menjawab, situsnya dialihkan ke yang lain selama 1 menit. Saat ODoH aktif, pembagian tidak dipakai (ODoH sudah menyembunyikan Anda dari server).",
            "Mỗi trang (kể cả tên miền con) luôn đi tới cùng một nhà cung cấp. Chọn tối đa 2 đối tác. Chế độ tự động dùng nhà cung cấp mã hóa cùng loại với máy chủ đã chọn (gia đình, bảo mật, lọc quảng cáo hoặc không lọc), nên việc chia không bao giờ vượt qua bộ lọc. Nếu một nhà cung cấp không trả lời, các trang của nó chuyển sang nhà khác trong 1 phút. Khi bật ODoH thì không chia (ODoH vốn đã ẩn bạn khỏi máy chủ).",
            "Każda strona (z subdomenami) trafia zawsze do tego samego dostawcy. Wybierz do 2 partnerów. Automatycznie używani są szyfrowani dostawcy tego samego rodzaju co wybrany serwer (rodzinny, bezpieczeństwo, filtr reklam lub bez filtra), więc podział nigdy nie omija filtra. Gdy dostawca nie odpowiada, jego strony na 1 minutę trafiają do innego. Przy włączonym ODoH podziału nie ma (ODoH i tak ukrywa Cię przed serwerem).",
            "Кожен сайт (із піддоменами) завжди йде до того самого провайдера. Оберіть до 2 партнерів. Автоматично беруться шифровані провайдери того самого типу, що й вибраний сервер (сімейний, захист, без реклами чи без фільтра), тож розподіл не обходить фільтр. Якщо провайдер не відповідає, його сайти на 1 хвилину йдуть до іншого. З увімкненим ODoH розподілу немає (ODoH і так приховує вас від сервера)."),
        "none" to arrayOf("Uygun ortak yok", "No suitable partner", "Kein passender Partner", "Ningún socio adecuado", "Aucun partenaire adapté", "Nenhum parceiro adequado",
            "Нет подходящего партнёра", "Nessun partner adatto", "Tidak ada mitra yang cocok", "Không có đối tác phù hợp", "Brak odpowiedniego partnera", "Немає відповідного партнера"),
    )

    fun codes(): Set<String> = M.keys

    fun t(key: String, lang: Lang = L.lang, vararg args: String): String {
        val row = M[key] ?: return key
        var s = row.getOrNull(lang.ordinal)?.takeIf { it.isNotBlank() } ?: row.getOrNull(Lang.EN.ordinal) ?: row[0]
        for ((i, a) in args.withIndex()) s = s.replace("{$i}", a)
        return s
    }
}
