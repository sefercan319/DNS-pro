package app.dnshizli.core

/** Bir uygulamanın reklam engelleme kipi: genel ayar, hiç engelleme yok (muaf) ya da en sıkı liste. */
enum class AppMode(val id: Char) {
    NORMAL('N'), EXEMPT('E'), STRICT('S');

    companion object { fun byId(c: Char): AppMode? = values().firstOrNull { it.id == c } }
}

/** Bir uygulamanın engellenen istek özeti (en çok engellenenden başlayarak). */
class AppRow(val pkg: String, val blocked: Int, val top: List<Pair<String, Int>>)

/** Bir uygulamanın bozulmuş olabileceğine dair belirti: aynı ad kısa sürede çok kez engellenmiş (uygulama yeniden deniyor). */
class AppSuspect(val pkg: String, val name: String, val count: Int, val at: Long)

/**
 * Uygulama bazlı reklam engelleme: kim kaç istek engelletti, uygulama başına kip (muaf / sıkı) ve bozulan uygulamayı kurtarma.
 *
 * Hangi uygulamanın hangi bağlantıyı yaptığı Android'in `getConnectionOwnerUid` çağrısıyla ([owner], platform verir; API 29+)
 * öğrenilir. Çözülemezse (eski Android, kısa ömürlü bağlantı) o istek uygulamaya yazılmaz ve genel ayar uygulanır:
 * hiçbir zaman "yanlış uygulamaya muaf" davranılmaz.
 *
 * Yalnızca bellekte tutulur; kurallar ayarlarla ([AppSettings.appAds]) kalıcıdır. Hiçbir şey cihazdan çıkmaz.
 */
object AppAds {
    /** Pencere: aynı adın bu sürede en az [STORM] kez engellenmesi "yeniden deneme fırtınası" sayılır. */
    const val WINDOW_MS = 60_000L
    const val STORM = 40
    const val MAX_PKGS = 200
    const val MAX_NAMES = 24
    const val MAX_RULES = 300
    private const val CACHE_MS = 1_000L
    private const val SUSPECT_KEEP_MS = 30 * 60_000L

    /** (proto 6/17, kaynak, kaynak port, hedef, hedef port) → paket adı; bilinmiyorsa null. */
    @Volatile var owner: ((Int, ByteArray, Int, ByteArray, Int) -> String?)? = null
    /** Paket adı → görünen ad (platform verir; varsayılan paket adının kendisi). */
    @Volatile var labeler: (String) -> String = { it }
    @Volatile var clock: () -> Long = { System.currentTimeMillis() }
    @Volatile var rules: Map<String, AppMode> = emptyMap()
        private set

    private class Stat {
        var blocked = 0
        val names = HashMap<String, Int>()
        var winStart = 0L
        val win = HashMap<String, Int>()
    }

    private val lock = Any()
    private val stats = LinkedHashMap<String, Stat>()
    private val suspects = LinkedHashMap<String, AppSuspect>()
    private val dismissed = HashSet<String>()
    private val cache = LinkedHashMap<Long, Pair<Long, String>>()

    fun setRules(m: Map<String, AppMode>) { rules = m.filterValues { it != AppMode.NORMAL } }


    /** En az bir uygulama sıkı kipte mi? (Sıkı motoru yalnızca o zaman kurmak için.) */
    fun wantsStrict(): Boolean = rules.values.any { it == AppMode.STRICT }

    fun reset() {
        synchronized(this.lock) { stats.clear(); suspects.clear(); dismissed.clear(); cache.clear() }
        rules = emptyMap(); owner = null; clock = { System.currentTimeMillis() }
    }

    // ---------------------------------------------------------------- kural kaydı

    /** "pkg=E,pkg2=S" biçimi; geçersiz paket adı ya da kip atılır. */
    fun encode(m: Map<String, AppMode>): String =
        m.filter { it.value != AppMode.NORMAL && AppScopes.validPkg(it.key) }.toSortedMap().entries.take(MAX_RULES)
            .joinToString(",") { it.key + "=" + it.value.id }

    fun decode(s: String?): Map<String, AppMode> {
        if (s.isNullOrBlank() || s.length > 100_000) return emptyMap()
        val out = LinkedHashMap<String, AppMode>()
        for (part in s.split(',')) {
            if (out.size >= MAX_RULES) break
            val i = part.lastIndexOf('=')
            if (i <= 0 || i != part.length - 2) continue
            val pkg = part.substring(0, i)
            val mode = AppMode.byId(part[i + 1]) ?: continue
            if (mode != AppMode.NORMAL && AppScopes.validPkg(pkg)) out[pkg] = mode
        }
        return out
    }

    // ---------------------------------------------------------------- sahip çözümü ve motor seçimi

    private fun key(proto: Int, sport: Int, dst: ByteArray, dport: Int): Long {
        var h = proto.toLong() * 1_000_003L + sport
        h = h * 1_000_003L + dport
        for (i in maxOf(0, dst.size - 4) until dst.size) h = h * 131L + (dst[i].toInt() and 0xFF)
        return h
    }

    /** Bağlantının sahibi uygulama (paket adı) ya da null. Sonuç kısa süre önbelleğe alınır (aynı soket tekrar sorulmaz). */
    fun pkgOf(proto: Int, src: ByteArray, sport: Int, dst: ByteArray, dport: Int): String? {
        val fn = owner ?: return null
        val now = clock()
        val k = key(proto, sport, dst, dport)
        synchronized(lock) {
            val c = cache[k]
            if (c != null && now - c.first < CACHE_MS) return c.second.ifEmpty { null }
        }
        val pkg = try { fn(proto, src, sport, dst, dport) } catch (_: Exception) { null }
        synchronized(lock) {
            cache[k] = now to (pkg ?: "")
            if (cache.size > 256) { val it = cache.entries.iterator(); it.next(); it.remove() }
        }
        return pkg
    }

    /**
     * Bu bağlantıda uygulanacak motor: kural yoksa ya da sahip bilinmiyorsa [base]; muafsa null; sıkıysa [strict] (yoksa [base]).
     * [base] null ise (reklam engelleme kapalı) kipler hiçbir şeyi açmaz.
     */
    fun pick(base: FilterEngine?, strict: FilterEngine?, proto: Int, src: ByteArray, sport: Int, dst: ByteArray, dport: Int): FilterEngine? {
        if (base == null) return null
        val r = rules
        if (r.isEmpty() || owner == null) return base
        val pkg = pkgOf(proto, src, sport, dst, dport) ?: return base
        return when (r[pkg]) {
            AppMode.EXEMPT -> null
            AppMode.STRICT -> strict ?: base
            else -> base
        }
    }

    // ---------------------------------------------------------------- istatistik

    /** Engellenen bir isteği sahibine yazar (sahip çözülemezse sessizce atlanır). */
    fun blocked(proto: Int, src: ByteArray, sport: Int, dst: ByteArray, dport: Int, name: String?) {
        if (name.isNullOrEmpty() || owner == null) return
        val pkg = pkgOf(proto, src, sport, dst, dport) ?: return
        record(pkg, name)
    }

    /** Sahibi zaten bilinen istek ([FilteringForwarder] ve testler). */
    fun record(pkg: String, name: String) {
        val now = clock()
        synchronized(lock) {
            var s = stats[pkg]
            if (s == null) {
                if (stats.size >= MAX_PKGS) {
                    val worst = stats.entries.minByOrNull { it.value.blocked }
                    if (worst != null) stats.remove(worst.key)
                }
                s = Stat(); stats[pkg] = s
            }
            s.blocked++
            if (s.names.size < MAX_NAMES || s.names.containsKey(name)) s.names[name] = (s.names[name] ?: 0) + 1
            if (now - s.winStart >= WINDOW_MS || now < s.winStart) { s.winStart = now; s.win.clear() }
            if (s.win.size < MAX_NAMES * 2 || s.win.containsKey(name)) {
                val c = (s.win[name] ?: 0) + 1
                s.win[name] = c
                if (c >= STORM && rules[pkg] != AppMode.EXEMPT && (pkg + "|" + name) !in dismissed) {
                    val old = suspects[pkg]
                    if (old == null || old.name != name || c > old.count) suspects[pkg] = AppSuspect(pkg, name, c, now)
                }
            }
        }
        PrivacyReport.record(pkg, name)
    }

    /** En çok engelleten uygulamalar. */
    fun top(n: Int): List<AppRow> = synchronized(lock) {
        stats.entries.sortedByDescending { it.value.blocked }.take(n).map { e ->
            AppRow(e.key, e.value.blocked, e.value.names.entries.sortedByDescending { it.value }.take(5).map { it.key to it.value })
        }
    }

    fun totalBlocked(): Int = synchronized(lock) { stats.values.sumOf { it.blocked } }

    /** Bozulmuş olabilecek uygulamalar (son 30 dk; kullanıcı yok saydıysa ya da muaf tuttuysa yok). */
    fun suspects(): List<AppSuspect> = synchronized(lock) {
        val now = clock()
        val it = suspects.entries.iterator()
        while (it.hasNext()) { val e = it.next(); if (now - e.value.at > SUSPECT_KEEP_MS || rules[e.key] == AppMode.EXEMPT) it.remove() }
        suspects.values.sortedByDescending { it.count }
    }

    /** Bir uygulama için engellenen adlar (kurtarmada tek dokunuşla izin verilecekler), en çok engellenenden. */
    fun namesOf(pkg: String, n: Int = 8): List<String> = synchronized(lock) {
        stats[pkg]?.names?.entries?.sortedByDescending { it.value }?.take(n)?.map { it.key } ?: emptyList()
    }

    /** Uyarıyı yok say (aynı uygulama + ad için yeniden uyarılmaz). */
    fun dismiss(pkg: String) = synchronized(lock) {
        val s = suspects.remove(pkg)
        if (s != null) dismissed.add(pkg + "|" + s.name)
        Unit
    }

    /** Denetim katmanı için: en baskın şüphe (yoksa null). */
    fun worstSuspect(): AppSuspect? = suspects().firstOrNull()

    fun clearStats() = synchronized(lock) { stats.clear(); suspects.clear(); dismissed.clear() }
}
