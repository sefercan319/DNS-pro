package app.dnshizli.core

/** Uygulama güvenlik duvarı metinleri (12 dil). Sıra: TR, EN, DE, ES, FR, PT, RU, IT, ID, VI, PL, UK. */
object FwText {
    val M: Map<String, Array<String>> = mapOf(
        "title" to arrayOf("Uygulama güvenlik duvarı", "App firewall", "App-Firewall", "Cortafuegos de apps", "Pare-feu des applis", "Firewall de apps",
            "Брандмауэр приложений", "Firewall delle app", "Firewall aplikasi", "Tường lửa ứng dụng", "Zapora aplikacji", "Брандмауер застосунків"),
        "summary" to arrayOf("{0} uygulama", "{0} apps", "{0} Apps", "{0} apps", "{0} applis", "{0} apps", "приложений: {0}", "{0} app", "{0} aplikasi",
            "{0} ứng dụng", "aplikacji: {0}", "застосунків: {0}"),
        "empty" to arrayOf(
            "Henüz kural yok. İnternete çıkmasını istemediğiniz uygulamayı ekleyin: her zaman, yalnızca mobil veride ya da yalnızca Wi-Fi'de engellenir.",
            "No rules yet. Add an app you don't want online: it is blocked always, only on mobile data or only on Wi-Fi.",
            "Noch keine Regeln. Fügen Sie eine App hinzu, die nicht online gehen soll: immer, nur mobil oder nur im WLAN gesperrt.",
            "Aún no hay reglas. Añade una app que no quieras conectada: se bloquea siempre, solo con datos móviles o solo en Wi-Fi.",
            "Aucune règle pour l'instant. Ajoutez une appli à couper d'Internet : toujours, seulement en données mobiles ou seulement en Wi-Fi.",
            "Nenhuma regra ainda. Adicione um app que não deve acessar a internet: bloqueado sempre, só nos dados móveis ou só no Wi-Fi.",
            "Правил пока нет. Добавьте приложение, которому нельзя в интернет: блокировка всегда, только в мобильной сети или только по Wi-Fi.",
            "Nessuna regola. Aggiungi un'app da tenere offline: bloccata sempre, solo con dati mobili o solo in Wi-Fi.",
            "Belum ada aturan. Tambahkan aplikasi yang tidak boleh online: diblokir selalu, hanya di data seluler atau hanya di Wi-Fi.",
            "Chưa có quy tắc. Thêm ứng dụng bạn không muốn kết nối mạng: chặn luôn, chỉ khi dùng dữ liệu di động hoặc chỉ khi dùng Wi-Fi.",
            "Brak reguł. Dodaj aplikację, która ma nie mieć internetu: blokada zawsze, tylko na danych komórkowych albo tylko w Wi-Fi.",
            "Правил ще немає. Додайте застосунок, якому не можна в інтернет: блокування завжди, лише в мобільній мережі або лише через Wi-Fi."),
        "foot" to arrayOf(
            "Engelli uygulama internete hiç çıkamaz: ad çözümü ve tüm bağlantıları kesilir (WireGuard kipinde de). Kural varken tüm trafik uygulamanın içinden geçer (Reklam+ gibi); diğer uygulamalar etkilenmez. Bağlantının sahibi bulunamazsa engellenmez. Bağlı değilken kurallar çalışmaz.",
            "A blocked app cannot go online at all: its name lookups and all connections are cut (also in WireGuard mode). While a rule exists, all traffic passes through the app (like Ads+); other apps are unaffected. A connection whose owner cannot be determined is not blocked. Rules do not apply while disconnected.",
            "Eine gesperrte App kommt gar nicht ins Internet: Namensauflösung und alle Verbindungen werden gekappt (auch im WireGuard-Modus). Solange eine Regel existiert, läuft der gesamte Verkehr durch die App (wie Werbung+); andere Apps sind nicht betroffen. Verbindungen ohne ermittelbaren Besitzer werden nicht gesperrt. Ohne Verbindung gelten die Regeln nicht.",
            "Una app bloqueada no puede conectarse: se cortan sus resoluciones de nombres y todas sus conexiones (también en modo WireGuard). Mientras haya una regla, todo el tráfico pasa por la app (como Anuncios+); las demás apps no se ven afectadas. Si no se identifica al dueño de una conexión, no se bloquea. Sin conexión, las reglas no se aplican.",
            "Une appli bloquée ne peut plus du tout accéder à Internet : ses résolutions de noms et toutes ses connexions sont coupées (aussi en mode WireGuard). Tant qu'une règle existe, tout le trafic passe par l'appli (comme Pubs+) ; les autres applis ne sont pas touchées. Une connexion dont le propriétaire est introuvable n'est pas bloquée. Hors connexion, les règles ne s'appliquent pas.",
            "Um app bloqueado não acessa a internet: as consultas de nomes e todas as conexões são cortadas (também no modo WireGuard). Enquanto houver uma regra, todo o tráfego passa pelo app (como Anúncios+); os outros apps não são afetados. Conexão cujo dono não é identificado não é bloqueada. Desconectado, as regras não valem.",
            "Заблокированное приложение вообще не выходит в интернет: его DNS-запросы и все соединения обрываются (и в режиме WireGuard). Пока есть правило, весь трафик идёт через приложение (как Реклама+); другие приложения не затрагиваются. Соединение с неизвестным владельцем не блокируется. Без подключения правила не действуют.",
            "Un'app bloccata non può andare online: risoluzioni dei nomi e tutte le connessioni vengono interrotte (anche in modalità WireGuard). Finché esiste una regola, tutto il traffico passa dall'app (come Pubblicità+); le altre app non sono toccate. Una connessione di cui non si trova il proprietario non viene bloccata. Da disconnessi le regole non valgono.",
            "Aplikasi yang diblokir sama sekali tidak bisa online: resolusi nama dan semua koneksinya diputus (juga di mode WireGuard). Selama ada aturan, semua lalu lintas melewati aplikasi ini (seperti Iklan+); aplikasi lain tidak terpengaruh. Koneksi yang pemiliknya tidak diketahui tidak diblokir. Saat tidak terhubung, aturan tidak berlaku.",
            "Ứng dụng bị chặn hoàn toàn không thể kết nối mạng: phân giải tên và mọi kết nối đều bị cắt (cả ở chế độ WireGuard). Khi có quy tắc, mọi lưu lượng đi qua ứng dụng này (như Quảng cáo+); ứng dụng khác không bị ảnh hưởng. Kết nối không xác định được chủ sẽ không bị chặn. Khi chưa kết nối, quy tắc không có hiệu lực.",
            "Zablokowana aplikacja w ogóle nie wyjdzie do internetu: jej zapytania DNS i wszystkie połączenia są ucinane (także w trybie WireGuard). Gdy istnieje reguła, cały ruch przechodzi przez aplikację (jak Reklamy+); inne aplikacje nie są dotknięte. Połączenie bez ustalonego właściciela nie jest blokowane. Bez połączenia reguły nie działają.",
            "Заблокований застосунок узагалі не виходить в інтернет: його DNS-запити й усі з'єднання обриваються (і в режимі WireGuard). Поки є правило, увесь трафік іде через застосунок (як Реклама+); інші застосунки не зачіпаються. З'єднання з невідомим власником не блокується. Без підключення правила не діють."),
        "allow" to arrayOf("İnternete izin ver", "Allow internet", "Internet erlauben", "Permitir internet", "Autoriser Internet", "Permitir internet", "Разрешить интернет",
            "Consenti internet", "Izinkan internet", "Cho phép internet", "Zezwól na internet", "Дозволити інтернет"),
        "all" to arrayOf("Her zaman engelle", "Always block", "Immer sperren", "Bloquear siempre", "Toujours bloquer", "Bloquear sempre", "Блокировать всегда",
            "Blocca sempre", "Selalu blokir", "Luôn chặn", "Zawsze blokuj", "Блокувати завжди"),
        "mobile" to arrayOf("Yalnızca mobil veride engelle", "Block on mobile data only", "Nur mobil sperren", "Bloquear solo con datos móviles", "Bloquer en données mobiles seulement",
            "Bloquear só nos dados móveis", "Блокировать только в мобильной сети", "Blocca solo con dati mobili", "Blokir hanya di data seluler", "Chỉ chặn khi dùng dữ liệu di động",
            "Blokuj tylko na danych komórkowych", "Блокувати лише в мобільній мережі"),
        "wifi" to arrayOf("Yalnızca Wi-Fi'de engelle", "Block on Wi-Fi only", "Nur im WLAN sperren", "Bloquear solo en Wi-Fi", "Bloquer en Wi-Fi seulement", "Bloquear só no Wi-Fi",
            "Блокировать только по Wi-Fi", "Blocca solo in Wi-Fi", "Blokir hanya di Wi-Fi", "Chỉ chặn khi dùng Wi-Fi", "Blokuj tylko w Wi-Fi", "Блокувати лише через Wi-Fi"),
        "tagAll" to arrayOf("engelli", "blocked", "gesperrt", "bloqueada", "bloquée", "bloqueado", "заблокировано", "bloccata", "diblokir", "bị chặn", "zablokowana", "заблоковано"),
        "tagMobile" to arrayOf("mobilde engelli", "blocked on mobile", "mobil gesperrt", "bloqueada en móvil", "bloquée en mobile", "bloqueado no móvel", "без мобильной сети",
            "bloccata su mobile", "diblokir di seluler", "chặn khi di động", "blokada na komórkowej", "без мобільної мережі"),
        "tagWifi" to arrayOf("Wi-Fi'de engelli", "blocked on Wi-Fi", "im WLAN gesperrt", "bloqueada en Wi-Fi", "bloquée en Wi-Fi", "bloqueado no Wi-Fi", "без Wi-Fi",
            "bloccata in Wi-Fi", "diblokir di Wi-Fi", "chặn khi Wi-Fi", "blokada w Wi-Fi", "без Wi-Fi"),
        "tries" to arrayOf("Bu oturumda {0} bağlantı denemesi kesildi", "{0} connection attempts cut this session", "{0} Verbindungsversuche in dieser Sitzung gekappt",
            "{0} intentos de conexión cortados en esta sesión", "{0} tentatives de connexion coupées cette session", "{0} tentativas de conexão cortadas nesta sessão",
            "Прервано попыток соединения за сеанс: {0}", "{0} tentativi di connessione interrotti in questa sessione", "{0} percobaan koneksi diputus di sesi ini",
            "Đã cắt {0} lần thử kết nối trong phiên này", "Przerwane próby połączenia w tej sesji: {0}", "Перервано спроб з'єднання за сеанс: {0}"),
        "access" to arrayOf("İnternet erişimi", "Internet access", "Internetzugang", "Acceso a internet", "Accès Internet", "Acesso à internet", "Доступ в интернет",
            "Accesso a internet", "Akses internet", "Truy cập internet", "Dostęp do internetu", "Доступ до інтернету"),
        "routeNote" to arrayOf(
            "Kural varken tünel tüm trafiği alır; bağlantı bir an kesilip yeniden kurulabilir.",
            "While a rule exists the tunnel takes all traffic; the connection may drop briefly and reconnect.",
            "Solange eine Regel existiert, nimmt der Tunnel den gesamten Verkehr; die Verbindung kann kurz neu aufgebaut werden.",
            "Mientras haya una regla, el túnel toma todo el tráfico; la conexión puede cortarse un instante y restablecerse.",
            "Tant qu'une règle existe, le tunnel prend tout le trafic ; la connexion peut se couper un instant puis revenir.",
            "Enquanto houver uma regra, o túnel recebe todo o tráfego; a conexão pode cair por um instante e voltar.",
            "Пока есть правило, туннель принимает весь трафик; соединение может на миг прерваться и восстановиться.",
            "Finché esiste una regola il tunnel prende tutto il traffico; la connessione può interrompersi un attimo e ripartire.",
            "Selama ada aturan, terowongan menerima semua lalu lintas; koneksi bisa terputus sebentar lalu tersambung lagi.",
            "Khi có quy tắc, đường hầm nhận toàn bộ lưu lượng; kết nối có thể ngắt giây lát rồi nối lại.",
            "Gdy istnieje reguła, tunel przejmuje cały ruch; połączenie może na chwilę zerwać się i wrócić.",
            "Поки є правило, тунель приймає весь трафік; з'єднання може на мить перерватися й відновитися."),
    )

    fun codes(): Set<String> = M.keys

    fun t(key: String, lang: Lang = L.lang, vararg args: String): String {
        val row = M[key] ?: return key
        var s = row.getOrNull(lang.ordinal)?.takeIf { it.isNotBlank() } ?: row.getOrNull(Lang.EN.ordinal) ?: row[0]
        for ((i, a) in args.withIndex()) s = s.replace("{$i}", a)
        return s
    }

    fun tag(m: FwMode?): String = when (m) {
        FwMode.ALL -> t("tagAll"); FwMode.MOBILE -> t("tagMobile"); FwMode.WIFI -> t("tagWifi"); null -> ""
    }
}
