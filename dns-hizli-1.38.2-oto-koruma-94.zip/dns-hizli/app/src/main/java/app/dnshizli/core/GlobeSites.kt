package app.dnshizli.core

/**
 * Sunucu küresindeki konumlar. Sağlayıcıların çoğu anycast'tir: aynı adres dünyanın birçok yerinden hizmet verir ve size en yakın
 * nokta cevaplar; küre onları işleten kuruluşun merkezinde gösterir ve "anycast" diye işaretler (gerçek sunucu konumu iddiası yok).
 * Tek konumdan hizmet verenler (unicast) sunucu konumundadır. Konumu bilinmeyen sağlayıcılar ve kullanıcının kendi eklediği sunucular
 * kürede yoktur; sayfada ayrı listelenir.
 */
object GlobeSites {
    /** [place]: yer adı anahtarı (çeviri [Tx.globePlace]); [anycast]: konum merkez mi (true) sunucu mu (false). */
    class Site(val lat: Double, val lon: Double, val place: String, val anycast: Boolean)

    private val BY_BRAND = mapOf(
        "Cloudflare" to Site(37.77, -122.42, "us-sf", true),
        "Google" to Site(37.39, -122.08, "us-mv", true),
        "Quad9" to Site(47.37, 8.54, "ch-zrh", true),
        "AdGuard" to Site(34.68, 33.04, "cy", true),
        "Control D" to Site(43.65, -79.38, "ca-tor", true),
        "OpenDNS" to Site(37.34, -121.89, "us-sj", true),
        "DNS4EU" to Site(49.19, 16.61, "cz", true),
        "UncensoredDNS" to Site(55.68, 12.57, "dk", true),
        "CIRA Shield" to Site(45.42, -75.70, "ca-ott", true),
        "LibreDNS" to Site(50.48, 12.37, "de", false),
        "SWITCH" to Site(47.37, 8.54, "ch-zrh", false),
        "Wikimedia" to Site(37.79, -122.40, "us-sf", true),
        "Digitale Gesellschaft" to Site(46.95, 7.45, "ch", false),
        "Quad101" to Site(25.03, 121.56, "tw", true),
        "AliDNS" to Site(30.27, 120.15, "cn", true),
    )

    fun of(s: DnsServer): Site? = if (s.custom) null else BY_BRAND[s.brand]

    /** Kürede gösterilen marka listesi (her marka bir nokta; varyantlar noktaya dokununca listelenir). */
    fun brands(servers: List<DnsServer>): List<String> = servers.mapNotNull { s -> s.brand.takeIf { of(s) != null } }.distinct()

    fun siteOfBrand(brand: String): Site? = BY_BRAND[brand]
}
