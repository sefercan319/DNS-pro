package app.dnshizli.platform

import android.content.Context
import app.dnshizli.core.BlockedSites
import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.FilterTier
import app.dnshizli.core.Journal
import app.dnshizli.core.ListCanary
import app.dnshizli.core.ListMirrors
import app.dnshizli.core.ListStore
import app.dnshizli.core.ListUpdate
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.HttpsURLConnection

/**
 * Engelleme listelerini arka planda, imzalı olarak günceller.
 *
 * Akış: manifest + imzası indirilir → imza gömülü açık anahtarla doğrulanır → sürüm kurulu sürümden yeni olmalı →
 * her liste indirilir, boyu ve özeti manifestle eşleşmeli → hepsi tamam olunca tek adımda yerine konur ([ListStore]:
 * dizin değişimi, yarım kalan güncelleme eski ve yeni dosyaları karıştırmaz) → motor yeniden kurulur. Herhangi bir adımda hata
 * olursa mevcut listeler olduğu gibi kalır.
 *
 * Uygulama sürümü değişince indirilmiş önbellek yok sayılır (paketteki listeler daha yeni olabilir) ve güncelleme hemen
 * yeniden denenir; önbellek yalnızca kendi uygulama sürümüyle indirilmişse okunur.
 *
 * Gizlilik: yalnızca HTTPS ile sabit adreslerden dosya çekilir. Kimlik, cihaz ya da kullanım bilgisi gönderilmez
 * (istek başlıkları varsayılandır). Sunucu tarafında IP adresi görülebilir; bu GİZLILIK.md'de belirtilir.
 */
object ListUpdater {
    /**
     * Yayın adresi (GitHub Releases, "listeler" etiketi). Derleme ortamından gelir ([app.dnshizli.BuildConfig.LIST_BASE_URL]:
     * GitHub Actions'ta deponun kendi adresi); boşsa aşağıdaki sabit kullanılır.
     */
    private const val BASE_URL_FALLBACK = "https://github.com/OWNER/REPO/releases/download/listeler/"
    val BASE_URL: String get() = app.dnshizli.BuildConfig.LIST_BASE_URL.ifEmpty { BASE_URL_FALLBACK }

    /**
     * Manifest imzasını doğrulayan ECDSA P-256 açık anahtarı (X.509 DER, base64). BOŞ BIRAKILIRSA GÜNCELLEME KAPALIDIR.
     * Anahtar üretimi ve yayın kurulumu: tools/yayin/README.md
     */
    const val PUBLIC_KEY_B64 = ""

    /** Derleme ortamından gelen anahtar ([app.dnshizli.BuildConfig.LIST_PUBLIC_KEY], GitHub gizli değeri) öncelikli. */
    private val keyB64: String get() = app.dnshizli.BuildConfig.LIST_PUBLIC_KEY.ifEmpty { PUBLIC_KEY_B64 }

    private const val PREFS = "liste_guncelleme"
    private const val KEY_VERSION = "surum"
    private const val KEY_CHECKED = "son_kontrol"
    private const val KEY_APP = "uygulama_surumu"
    /** Sağlık denetimini geçemeyen son sürüm: aynı sürüm tekrar tekrar indirilmez; daha yeni bir yayın yine denenir. */
    private const val KEY_BAD = "reddedilen_surum"
    /** Son başarılı ayna (alternatif yönlendirme): sonraki denetim önce ondan başlar. */
    private const val KEY_MIRROR = "son_ayna"
    /** Şu an kullanılan yayın adresi (asıl ya da ayna). Güncelleme tek iş parçacığında çalışır. */
    @Volatile private var mirror: String = ""
    private const val KEY_BLOCKED = "engelli_surum"
    private const val BLOCKED_FILE = "engelli.txt"
    /**
     * Denetim sıklığı: dönen reklam/yönlendirme adları listelere birkaç saat içinde girer, yayın her gün yenilenir.
     * Kotasız ağda (Wi-Fi) 3 saatte bir (yalnızca küçük manifest indirilir; listeler ancak yeni sürümde), ölçülü ağda (mobil veri) 3 günde bir denenir: listeler birkaç MB'tır.
     */
    private const val CHECK_UNMETERED_MS = 3L * 60 * 60_000
    private const val CHECK_METERED_MS = 72L * 60 * 60_000
    private const val TIMEOUT_MS = 15_000

    /** Tek bir dosyanın toplam indirme süresi: damla damla veri yollayan bir sunucu arka plan işini sonsuza dek tutamaz. */
    private const val TOTAL_MS = 90_000L
    private const val SIG_MAX = 512

    private val running = AtomicBoolean(false)
    @Volatile private var recovered = false

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun installedVersion(ctx: Context): Long = prefs(ctx).getLong(KEY_VERSION, 0L)

    /**
     * Kaynak: bu uygulama sürümüyle indirilmiş ve güncellenebilen bir liste varsa önbellekten, yoksa paketten okunur. Önbellek
     * dosyası bozuksa motor [FilterRuntime] içinde paketteki sürüme düşer.
     */
    fun open(ctx: Context, name: String): InputStream {
        if (name in ListUpdate.UPDATABLE && cacheUsable(ctx)) {
            val f = File(ListStore.dir(ctx.filesDir), name)
            if (f.isFile) {
                // Diskte sessizce bozulmuş (bit çürümesi, yarım yazım) dosya motora hiç verilmez: kurulum anındaki özetle doğrulanır.
                if (ListStore.verified(ctx.filesDir, name)) return FileInputStream(f)
                Journal.warn("REKLAM", "önbellekteki liste özeti uymadı ($name): paketteki sürüm kullanılıyor, yeniden indirilecek")
                prefs(ctx).edit().putLong(KEY_VERSION, 0L).putLong(KEY_CHECKED, 0L).apply()
            }
        }
        return ctx.assets.open("filter/$name")
    }

    private fun cacheUsable(ctx: Context): Boolean {
        if (!recovered) { ListStore.recover(ctx.filesDir); recovered = true }
        return ListStore.cacheUsable(prefs(ctx).getInt(KEY_APP, 0), app.dnshizli.BuildConfig.VERSION_CODE)
    }

    /** Açılışta çağrılır: son denemeden bu yana bir gün geçtiyse ve açık anahtar tanımlıysa arka planda dener. */
    fun maybeUpdate(ctx: Context) {
        if (!BlockedSites.any()) loadBlocked(ctx)
        if (ListUpdate.publicKey(decodeKey()) == null) return
        val p = prefs(ctx)
        if (p.getInt(KEY_APP, 0) != app.dnshizli.BuildConfig.VERSION_CODE) {
            // Uygulama güncellendi (ya da ilk açılış): önbellek yok sayılır; sürüm ve sıklık sınırı sıfırlanır, hemen denenir.
            p.edit().putLong(KEY_VERSION, 0L).putLong(KEY_CHECKED, 0L).apply()
        }
        val last = p.getLong(KEY_CHECKED, 0L)
        val now = System.currentTimeMillis()
        val every = if (metered(ctx)) CHECK_METERED_MS else CHECK_UNMETERED_MS
        if (last in 1..now && now - last < every) return
        Thread({ runCatching { updateNow(ctx) } }, "liste-guncelleme").also { it.isDaemon = true }.start()
    }

    /** Güncellemeyi hemen dener. Yeni bir sürüm uygulandıysa true. Aynı anda tek güncelleme çalışır. */
    fun updateNow(ctx: Context): Boolean {
        val key = ListUpdate.publicKey(decodeKey()) ?: return false
        if (!running.compareAndSet(false, true)) return false
        try {
            val r = update(ctx, key)
            runCatching { updateBlocked(ctx, key) }
            return r
        } finally {
            running.set(false)
        }
    }

    /** Diskteki engelli site listesini (daha önce imzası doğrulanıp yazılmış) belleğe yükler. Yok ya da bozuksa sessizce boş kalır. */
    fun loadBlocked(ctx: Context) {
        try {
            val f = File(ctx.filesDir, BLOCKED_FILE)
            if (!f.isFile || f.length() > BlockedSites.MAX_BYTES) return
            val bytes = f.readBytes()
            val key = ListUpdate.publicKey(decodeKey())
            val sf = File(ctx.filesDir, "$BLOCKED_FILE.sig")
            // İmzası varsa yeniden doğrulanır; tutmazsa yüklenmez (eski sürümden kalan imzasız dosya bir kez kabul edilir, güncellemede imzalı yazılır)
            val parsed = if (key != null && sf.isFile && sf.length() <= SIG_MAX) BlockedSites.verified(bytes, sf.readBytes(), key) else BlockedSites.parse(bytes)
            parsed?.let { BlockedSites.set(it.names) }
        } catch (_: Exception) {}
    }

    /**
     * Engelli site listesi (engelli-TR.txt + .sig): imza, sürüm (geri alma koruması) ve boyut denetiminden geçerse yazılır.
     * Liste yoksa (henüz yayınlanmamış) ya da bozuksa hiçbir şey değişmez; filtre listelerinin güncellemesinden bağımsızdır.
     */
    private fun updateBlocked(ctx: Context, key: java.security.PublicKey) {
        var list: ByteArray? = null
        var sigOf: ByteArray? = null
        var p: BlockedSites.Parsed? = null
        for (base in ListMirrors.urls(BASE_URL, prefs(ctx).getString(KEY_MIRROR, null))) {             // alternatif yönlendirme
            mirror = base
            val l = fetch("engelli-TR.txt", BlockedSites.MAX_BYTES) ?: continue
            val sg = fetch("engelli-TR.sig", SIG_MAX) ?: continue
            val v = BlockedSites.verified(l, sg, key) ?: continue
            list = l; sigOf = sg; p = v; break
        }
        if (list == null || p == null) return
        val prefs = prefs(ctx)
        // Geri alma ve "gelecekten donma" koruması filtre listeleriyle aynı kuraldan ([ListUpdate.isNewerVersion]): saatten çok ileride
        // imzalanmış bir sürüm reddedilir, zehirli (çok ileri) kurulu sürüm meşru sürümle kendiliğinden düzelir.
        if (!ListUpdate.isNewerVersion(prefs.getLong(KEY_BLOCKED, 0L), p.version)) return
        val old = BlockedSites.size()
        if (p.names.size < 50 || (old > 0 && p.names.size < old / 2)) return
        val tmp = File(ctx.filesDir, "$BLOCKED_FILE.tmp")
        tmp.writeBytes(list)
        if (!tmp.renameTo(File(ctx.filesDir, BLOCKED_FILE))) { tmp.delete(); return }
        // İmza da saklanır: açılışta liste yeniden doğrulanır (diskte bozulan ya da değiştirilen dosya yüklenmez)
        sigOf?.let { s -> runCatching { val st = File(ctx.filesDir, "$BLOCKED_FILE.sig.tmp"); st.writeBytes(s); st.renameTo(File(ctx.filesDir, "$BLOCKED_FILE.sig")) } }
        prefs.edit().putLong(KEY_BLOCKED, p.version).apply()
        BlockedSites.set(p.names)
        Journal.info("DPI", "engelli site listesi güncellendi: ${p.names.size} ad")
    }

    /**
     * Alternatif yönlendirme: asıl yayın adresi ve aynaları ([ListMirrors]) sırayla denenir; son başarılı ayna önce. Bir güncellemenin
     * bütün dosyaları aynı aynadan alınır. Güven imzaya dayanır: ayna eski ya da bozuk dosya verirse doğrulama reddeder, sıradakine geçilir.
     */
    private fun update(ctx: Context, key: java.security.PublicKey): Boolean {
        val p = prefs(ctx)
        for (base in ListMirrors.urls(BASE_URL, p.getString(KEY_MIRROR, null))) {
            mirror = base
            val r = updateFrom(ctx, key, p)
            if (r != null) {
                if (base != BASE_URL) Journal.info("REKLAM", "liste yayınına alternatif yoldan ulaşıldı")
                p.edit().putString(KEY_MIRROR, base).apply()
                return r
            }
        }
        return false
    }

    /** Seçili aynadan ([mirror]) bir güncelleme denemesi. Aynaya ulaşılamadıysa ya da dosyası doğrulanamadıysa null (sıradaki denenir). */
    private fun updateFrom(ctx: Context, key: java.security.PublicKey, p: android.content.SharedPreferences): Boolean? {
        val manifest = fetch("manifest.txt", ListUpdate.MAX_MANIFEST) ?: return null
        val sig = fetch("manifest.sig", SIG_MAX) ?: return null
        if (!ListUpdate.verifySignature(manifest, sig, key)) return null                // bozuk/sahte ayna: sıradakine geç
        // Sıklık sınırı yalnızca GERÇEK yayına ulaşılınca (imza doğrulandıktan sonra) işler: çevrimdışı, giriş sayfalı ağ ya da bozuk
        // bir ayna yüzünden yapılan başarısız deneme 12 saat ya da 3 gün boyunca yeni denemeyi engellemesin.
        p.edit().putLong(KEY_CHECKED, System.currentTimeMillis()).apply()
        val m = ListUpdate.parse(manifest) ?: return null
        if (!ListUpdate.isNewer(installedVersion(ctx), m)) return null                  // bu ayna eski olabilir (CDN önbelleği): sıradaki daha yeni olabilir
        if (m.version == p.getLong(KEY_BAD, 0L)) return false

        // Önce hepsini belleğe al ve doğrula: tek bir dosya bile uyuşmazsa hiçbir şey yerine konmaz.
        val data = LinkedHashMap<String, ByteArray>()
        for (e in m.entries) {
            val bytes = fetch(e.name, ListUpdate.MAX_FILE.toInt()) ?: return null
            if (!ListUpdate.matches(bytes, e)) return null
            data[e.name] = bytes
        }

        // Sağlık denetimi: imza yayıncıyı doğrular, içeriğin doğru olduğunu değil. Popüler siteleri engelleyen ya da boş bir liste yerine konmaz.
        val bad = canary(ctx, data)
        if (bad != null) {
            p.edit().putLong(KEY_BAD, m.version).apply()
            Journal.warn("REKLAM", "liste güncellemesi sağlık denetiminden geçemedi (sürüm ${m.version}): $bad; eski liste korunuyor")
            return false
        }

        if (!ListStore.install(ctx.filesDir, data)) return false
        p.edit().putLong(KEY_VERSION, m.version).putInt(KEY_APP, app.dnshizli.BuildConfig.VERSION_CODE).apply()
        FilterRuntime.reloadLists()
        return true
    }

    /** Güncelleme sağlık denetimi ([ListCanary]); denetim yapılamazsa (bellek, paket okunamadı) null: güncellemeyi engellemez. */
    private fun canary(ctx: Context, data: Map<String, ByteArray>): String? = try {
        val prot = ctx.assets.open("filter/protected.txt").use { ListCanary.protectedOf(it.readBytes().toString(Charsets.UTF_8)) }
        val ref = HashMap<String, Int>()
        for (n in ListUpdate.UPDATABLE) ctx.assets.open("filter/$n").use { ref[n] = FilterTier.read(it).size }
        ListCanary.check(data, prot, ref)
    } catch (_: Exception) {
        null
    } catch (_: OutOfMemoryError) {
        null
    }

    /** Sabit bir yayın adresinden en çok [max] bayt okur. Hata, HTTP hatası, süre ya da sınır aşımında null. */
    private fun fetch(name: String, max: Int): ByteArray? {
        val base = mirror
        if (!base.startsWith("https://")) return null
        val conn = URL(base + name).openConnection() as? HttpsURLConnection ?: return null
        return try {
            conn.connectTimeout = TIMEOUT_MS
            conn.readTimeout = TIMEOUT_MS
            conn.instanceFollowRedirects = false             // yönlendirmeyi elle, yalnızca izinli https adreslerine izleriz
            conn.useCaches = false
            conn.setRequestProperty("Accept", "application/octet-stream")
            var c: HttpsURLConnection = conn
            var hops = 0
            while (c.responseCode in intArrayOf(301, 302, 303, 307, 308)) {
                if (++hops > 4) return null
                val loc = c.getHeaderField("Location") ?: return null
                val next = try { URL(c.url, loc) } catch (_: Exception) { return null }
                if (next.protocol != "https" || !redirectHostOk(next.host)) return null
                if (c !== conn) c.disconnect()
                c = next.openConnection() as? HttpsURLConnection ?: return null
                c.connectTimeout = TIMEOUT_MS
                c.readTimeout = TIMEOUT_MS
                c.instanceFollowRedirects = false
                c.useCaches = false
                c.setRequestProperty("Accept", "application/octet-stream")
            }
            if (c.responseCode != HttpURLConnection.HTTP_OK) { if (c !== conn) c.disconnect(); return null }
            val deadline = System.nanoTime() + TOTAL_MS * 1_000_000L
            try { c.inputStream.use { readCapped(it, max, deadline) } } finally { if (c !== conn) c.disconnect() }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    /**
     * Yönlendirme yalnızca yayın adresinin kendi alan adına ya da GitHub'ın dosya dağıtım adlarına izlenir. (İçerik zaten imza
     * ve özetle doğrulanır; bu, istemciyi beklenmedik bir sunucuya götürülmekten de korur.)
     */
    private fun redirectHostOk(host: String): Boolean = ListMirrors.redirectAllowed(host, mirror)

    private fun readCapped(input: InputStream, max: Int, deadlineNanos: Long): ByteArray? {
        val out = ByteArrayOutputStream(64 * 1024)
        val buf = ByteArray(16 * 1024)
        while (true) {
            if (System.nanoTime() - deadlineNanos > 0L) return null
            val n = input.read(buf)
            if (n < 0) break
            if (out.size() + n > max) return null
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    /** Etkin ağ ölçülü mü (mobil veri, kotalı Wi-Fi)? Bilinmiyorsa ölçülü sayılır (veri harcanmasın). */
    private fun metered(ctx: Context): Boolean = try {
        val cm = ctx.getSystemService(android.net.ConnectivityManager::class.java)
        cm == null || cm.isActiveNetworkMetered
    } catch (_: Exception) {
        true
    }

    private fun decodeKey(): ByteArray =
        if (keyB64.isEmpty()) ByteArray(0) else try {
            java.util.Base64.getDecoder().decode(keyB64)
        } catch (_: IllegalArgumentException) {
            ByteArray(0)
        }
}
