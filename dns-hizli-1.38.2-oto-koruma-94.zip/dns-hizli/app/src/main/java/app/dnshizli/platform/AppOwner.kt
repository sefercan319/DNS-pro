package app.dnshizli.platform

import android.content.Context
import android.net.ConnectivityManager
import android.os.Build
import android.os.Process
import app.dnshizli.core.AppAds
import app.dnshizli.core.AppFirewall
import app.dnshizli.core.AppSettings
import app.dnshizli.core.FilterRuntime
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap

/**
 * Bir ağ bağlantısının hangi uygulamaya ait olduğunu Android'den öğrenir ([ConnectivityManager.getConnectionOwnerUid], API 29+;
 * yalnızca o an etkin VPN uygulaması, yani biz sorabiliriz). Eski sürümde ya da çözülemezse null: genel ayar uygulanır.
 * Uygulama bazlı kurallar ([AppAds]) ve istatistikler bu çözümü kullanır; hiçbir veri cihazdan çıkmaz.
 */
object AppOwner {
    private val uidPkg = ConcurrentHashMap<Int, String>()
    private val labels = ConcurrentHashMap<String, String>()

    /** Süreç açılışında bir kez: sahip çözücüyü ve kayıtlı kuralları kurar. */
    fun install(ctx: Context, st: AppSettings) {
        val app = ctx.applicationContext
        apply(st)
        AppAds.labeler = { pkg -> label(app, pkg) }
        PrivacyStore.install(app)
        AppFirewall.netProbe = { NetworkWatcher.currentKind(app) }
        if (Build.VERSION.SDK_INT >= 29) {
            AppAds.owner = { proto, src, sport, dst, dport -> resolve(app, proto, src, sport, dst, dport) }
        }
    }

    /** Ayardaki kipleri yürürlüğe koyar (sıkı kip varsa sıkı motor kurulur). */
    fun apply(st: AppSettings) {
        AppAds.setRules(AppAds.decode(st.appAds))
        FilterRuntime.setStrictApps(AppAds.wantsStrict())
        AppFirewall.setRules(AppFirewall.decode(st.appFw))
    }

    @android.annotation.TargetApi(29)
    private fun resolve(ctx: Context, proto: Int, src: ByteArray, sport: Int, dst: ByteArray, dport: Int): String? {
        return try {
            val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return null
            val uid = cm.getConnectionOwnerUid(proto, InetSocketAddress(InetAddress.getByAddress(src), sport), InetSocketAddress(InetAddress.getByAddress(dst), dport))
            if (uid < 0 || uid == Process.myUid()) return null          // bilinmiyor ya da kendi trafiğimiz
            uidPkg[uid] ?: ctx.packageManager.getPackagesForUid(uid)?.firstOrNull()?.also { if (uidPkg.size < 512) uidPkg[uid] = it }
        } catch (_: Exception) {
            null
        }
    }

    /** Görünen ad; bulunamazsa paket adı. */
    fun label(ctx: Context, pkg: String): String = labels.getOrPut(pkg) {
        try {
            val pm = ctx.packageManager
            pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString().trim().ifEmpty { pkg }
        } catch (_: Exception) {
            pkg
        }
    }
}
