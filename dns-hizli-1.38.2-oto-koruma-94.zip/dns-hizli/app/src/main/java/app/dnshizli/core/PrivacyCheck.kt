package app.dnshizli.core

/** Gizlilik testinin ham ölçümleri (platform toplar; boş alan = ölçülemedi). */
class PrivacyProbe(
    /** IPv4 üzerinden sitelerin gördüğü adres ve ülke kodu (Cloudflare "cdn-cgi/trace"). */
    val ip4: String? = null,
    val country4: String? = null,
    /** IPv6 üzerinden görünen adres ve ülke; IPv6 bağlantısı yoksa null. */
    val ip6: String? = null,
    val country6: String? = null,
    /** STUN (WebRTC'nin kullandığı yol, UDP) ile görünen adres; UDP engelliyse null. */
    val stunIp: String? = null,
    /** Sistem DNS'i tünelden geçti mi ([LeakProbe]); bağlı değilken null. */
    val dnsThrough: Boolean? = null,
)

/** Testin bağlamı: hangi kip, hangi sağlayıcı, nasıl. */
class PrivacyContext(
    val connected: Boolean,
    /** WireGuard tam tüneli mi (IP gizlenir)? Değilse DNS kipi (IP değişmez). */
    val wireGuard: Boolean,
    /** WireGuard tüneli IPv6'yı da taşıyor mu (AllowedIPs ::/0)? */
    val wgV6: Boolean = false,
    val serverName: String = "",
    /** Kullanılan yöntem ("DoH", "DoT", "Düz DNS" …); boş = bilinmiyor. */
    val protoName: String = "",
    val encrypted: Boolean = false,
    /** Şifreli bağlantıda sertifika doğrulama hatası görüldü mü? */
    val tlsFailures: Long = 0,
    /** DNS bölmede ek sağlayıcılar. */
    val splitWith: List<String> = emptyList(),
)

enum class CheckState { OK, WARN, BAD, OFF }

class CheckRow(val key: String, val state: CheckState, val title: String, val detail: String)

/**
 * Gizlilik testi: görünen IP ve ülke, IPv6 ve WebRTC (STUN) sızıntısı, DNS'in tünelden ve seçilen sağlayıcıya gidip gitmediği.
 * Ölçümü platform yapar ([PrivacyProbe]); burada yalnızca ayrıştırma ve yargı var (JVM'de sınanır).
 */
object PrivacyCheck {
    const val TRACE4 = "https://1.1.1.1/cdn-cgi/trace"
    const val TRACE6 = "https://[2606:4700:4700::1111]/cdn-cgi/trace"
    const val STUN_HOST = "stun.l.google.com"
    const val STUN_PORT = 19302

    /** "cdn-cgi/trace" gövdesinden (ip, ülke kodu); bozuksa null. Ülke iki harf değilse null. */
    fun parseTrace(body: String?): Pair<String, String?>? {
        if (body == null || body.length > 4096) return null
        var ip: String? = null; var loc: String? = null
        for (line in body.lineSequence()) {
            val i = line.indexOf('=')
            if (i <= 0) continue
            val k = line.substring(0, i).trim(); val v = line.substring(i + 1).trim()
            when (k) { "ip" -> ip = v; "loc" -> loc = v }
        }
        val a = ip?.takeIf { validIp(it) } ?: return null
        return a to loc?.uppercase()?.takeIf { it.length == 2 && it.all { c -> c in 'A'..'Z' } && it != "XX" }
    }

    private fun validIp(s: String): Boolean {
        if (s.isEmpty() || s.length > 45) return false
        return if (s.contains(':')) s.all { it.isDigit() || it in 'a'..'f' || it in 'A'..'F' || it == ':' || it == '.' }
        else s.split('.').let { p -> p.size == 4 && p.all { x -> x.toIntOrNull()?.let { it in 0..255 } == true && x.length <= 3 } }
    }

    // ---------------------------------------------------------------- STUN (RFC 5389): bağlama isteği ve yanıtı

    private const val MAGIC = 0x2112A442

    /** 20 baytlık Binding Request ([txid] 12 bayt). */
    fun stunRequest(txid: ByteArray): ByteArray {
        require(txid.size == 12)
        val b = ByteArray(20)
        Packets.put16(b, 0, 0x0001); Packets.put16(b, 2, 0)
        Packets.put32(b, 4, MAGIC)
        System.arraycopy(txid, 0, b, 8, 12)
        return b
    }

    /** Binding Success yanıtından görünen adres (XOR-MAPPED-ADDRESS, yoksa MAPPED-ADDRESS); geçersizse null. */
    fun parseStun(r: ByteArray, len: Int, txid: ByteArray): String? {
        if (len < 20 || len > r.size || Packets.u16(r, 0) != 0x0101 || Packets.i32(r, 4) != MAGIC) return null
        for (k in 0 until 12) if (r[8 + k] != txid[k]) return null
        val end = minOf(len, 20 + Packets.u16(r, 2))
        var i = 20
        var mapped: String? = null
        while (i + 4 <= end) {
            val type = Packets.u16(r, i); val l = Packets.u16(r, i + 2)
            val v = i + 4
            if (v + l > end) return mapped
            if ((type == 0x0020 || type == 0x0001) && l >= 8) {
                val fam = r[v + 1].toInt() and 0xFF
                val xor = type == 0x0020
                val addr: ByteArray? = when {
                    fam == 1 && l >= 8 -> ByteArray(4) { (r[v + 4 + it].toInt() xor (if (xor) (MAGIC ushr (24 - 8 * it)) else 0)).toByte() }
                    fam == 2 && l >= 20 -> ByteArray(16) { k ->
                        val mask = if (!xor) 0 else if (k < 4) (MAGIC ushr (24 - 8 * k)) else txid[k - 4].toInt()
                        (r[v + 4 + k].toInt() xor mask).toByte()
                    }
                    else -> null
                }
                if (addr != null) {
                    val s = fmt(addr)
                    if (xor) return s
                    mapped = s
                }
            }
            i = v + ((l + 3) and 3.inv())
        }
        return mapped
    }

    /** Adres metni: IPv4 noktalı, IPv6 kısaltılmış (en uzun sıfır dizisi "::"). */
    fun fmt(a: ByteArray): String {
        if (a.size == 4) return a.joinToString(".") { (it.toInt() and 0xFF).toString() }
        val w = IntArray(8) { ((a[2 * it].toInt() and 0xFF) shl 8) or (a[2 * it + 1].toInt() and 0xFF) }
        var bs = -1; var bl = 0; var cs = -1; var cl = 0
        for (i in 0 until 8) {
            if (w[i] == 0) { if (cs < 0) { cs = i; cl = 0 }; cl++; if (cl > bl) { bl = cl; bs = cs } } else cs = -1
        }
        if (bl < 2) return w.joinToString(":") { Integer.toHexString(it) }
        val left = (0 until bs).joinToString(":") { Integer.toHexString(w[it]) }
        val right = (bs + bl until 8).joinToString(":") { Integer.toHexString(w[it]) }
        return "$left::$right"
    }

    /** Adreslerin aynı olup olmadığı (IPv6 yazım farkı gözetmeden). */
    fun sameIp(a: String?, b: String?): Boolean {
        if (a == null || b == null) return false
        fun norm(s: String): String = if (!s.contains(':')) s else try { fmt(java.net.InetAddress.getByName(s).address) } catch (_: Exception) { s.lowercase() }
        return norm(a) == norm(b)
    }

    // ---------------------------------------------------------------- yargı

    /** Bilgi penceresi için: "[İyi] Başlık" + ayrıntı, satır başına bir paragraf; sonda dipnot. */
    fun paragraphs(rows: List<CheckRow>): List<String> = rows.map { r ->
        val st = when (r.state) { CheckState.OK -> "stOk"; CheckState.WARN -> "stWarn"; CheckState.BAD -> "stBad"; CheckState.OFF -> "stOff" }
        "[" + PrivacyCheckText.t(st) + "] " + r.title + "\n" + r.detail
    } + PrivacyCheckText.t("foot")

    /**
     * Test satırları. [country] ülke kodunu dilde ada çevirir (yoksa kod gösterilir).
     */
    fun rows(p: PrivacyProbe, c: PrivacyContext, country: (String) -> String? = { null }): List<CheckRow> {
        val out = ArrayList<CheckRow>(5)
        fun where(ip: String, cc: String?) = if (cc == null) ip else ip + " · " + (country(cc) ?: cc)
        // 1) görünen IP
        out += when {
            p.ip4 == null && p.ip6 == null -> CheckRow("ip", CheckState.WARN, PrivacyCheckText.t("ipTitle"), PrivacyCheckText.t("ipNone"))
            c.connected && c.wireGuard -> CheckRow("ip", CheckState.OK, PrivacyCheckText.t("ipTitle"), where(p.ip4 ?: p.ip6!!, if (p.ip4 != null) p.country4 else p.country6) + "\n" + PrivacyCheckText.t("ipWg"))
            else -> CheckRow("ip", CheckState.WARN, PrivacyCheckText.t("ipTitle"), where(p.ip4 ?: p.ip6!!, if (p.ip4 != null) p.country4 else p.country6) + "\n" + PrivacyCheckText.t("ipDns"))
        }
        // 2) IPv6
        out += when {
            p.ip6 == null -> CheckRow("v6", CheckState.OK, PrivacyCheckText.t("v6Title"), PrivacyCheckText.t("v6None"))
            c.connected && c.wireGuard && !c.wgV6 -> CheckRow("v6", CheckState.BAD, PrivacyCheckText.t("v6Title"), where(p.ip6, p.country6) + "\n" + PrivacyCheckText.t("v6Leak"))
            c.connected && c.wireGuard -> CheckRow("v6", CheckState.OK, PrivacyCheckText.t("v6Title"), where(p.ip6, p.country6) + "\n" + PrivacyCheckText.t("v6Tunnel"))
            else -> CheckRow("v6", CheckState.WARN, PrivacyCheckText.t("v6Title"), where(p.ip6, p.country6) + "\n" + PrivacyCheckText.t("v6Dns"))
        }
        // 3) WebRTC / STUN
        val seen = p.ip4 ?: p.ip6
        out += when {
            p.stunIp == null -> CheckRow("rtc", CheckState.OK, PrivacyCheckText.t("rtcTitle"), PrivacyCheckText.t("rtcNone"))
            seen != null && !sameIp(p.stunIp, p.ip4) && !sameIp(p.stunIp, p.ip6) ->
                CheckRow("rtc", if (c.connected && c.wireGuard) CheckState.BAD else CheckState.WARN, PrivacyCheckText.t("rtcTitle"), p.stunIp + "\n" + PrivacyCheckText.t("rtcLeak"))
            else -> CheckRow("rtc", CheckState.OK, PrivacyCheckText.t("rtcTitle"), p.stunIp + "\n" + PrivacyCheckText.t("rtcSame"))
        }
        // 4) DNS tünelden mi
        out += when (p.dnsThrough) {
            null -> CheckRow("dns", CheckState.OFF, PrivacyCheckText.t("dnsTitle"), PrivacyCheckText.t("dnsOff"))
            true -> CheckRow("dns", CheckState.OK, PrivacyCheckText.t("dnsTitle"), PrivacyCheckText.t("dnsOk"))
            false -> CheckRow("dns", CheckState.BAD, PrivacyCheckText.t("dnsTitle"), PrivacyCheckText.t("dnsLeak"))
        }
        // 5) sağlayıcı
        if (c.connected && c.serverName.isNotEmpty()) {
            val names = (listOf(c.serverName) + c.splitWith).joinToString(" + ")
            val how = if (c.protoName.isEmpty()) names else "$names · ${c.protoName}"
            out += when {
                c.encrypted && c.tlsFailures > 0 -> CheckRow("prov", CheckState.BAD, PrivacyCheckText.t("provTitle"), how + "\n" + PrivacyCheckText.t("provTls"))
                c.encrypted -> CheckRow("prov", CheckState.OK, PrivacyCheckText.t("provTitle"), how + "\n" + PrivacyCheckText.t("provOk"))
                else -> CheckRow("prov", CheckState.WARN, PrivacyCheckText.t("provTitle"), how + "\n" + PrivacyCheckText.t("provPlain"))
            }
        } else out += CheckRow("prov", CheckState.OFF, PrivacyCheckText.t("provTitle"), PrivacyCheckText.t("dnsOff"))
        return out
    }
}
