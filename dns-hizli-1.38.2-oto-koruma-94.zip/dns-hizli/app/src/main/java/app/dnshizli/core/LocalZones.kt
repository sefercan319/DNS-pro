package app.dnshizli.core

/**
 * İnternete hiç sorulmaması gereken adlar: cevabı yerelde "yok" (NXDOMAIN) olarak verilir.
 *  - Özel adres aralıklarının ters (PTR) bölgeleri (RFC 6303, 7793): "1.1.168.192.in-addr.arpa" gibi sorular genel çözümleyiciye giderse
 *    ev ağının adres planı dışarı sızar; cevap zaten her zaman "yok"tur. Yerelde anında verilir (gecikme ve sızıntı yok).
 *  - ".onion" (RFC 7686): Tor adı DNS'e gitmemeli (ziyaret edilen gizli servis sızar).
 *  - ".local" (RFC 6762): mDNS adı; tek noktaya (unicast) DNS'e gitmez, gitse de genel çözümleyici bilmez.
 *  - ".invalid" (RFC 6761): tanım gereği yok.
 * Üst sunucu yerel ağdaysa (ör. Pi-hole, modem) ters bölgeler ve .local o sunucuda anlamlı olabilir: [FilterRuntime.localZones] kapatılır.
 * Ayırma yapmaz: son etiket "arpa/local/onion/invalid" değilse hemen false döner (sorguların neredeyse tamamı).
 */
object LocalZones {
    private val V4 = listOf("10", "127", "0", "254.169", "168.192", "255.255.255.255") +
        (16..31).map { "$it.172" } + (64..127).map { "$it.100" }
    private val V4_ZONES: Set<String> = V4.map { "$it.in-addr.arpa" }.toSet()
    private val V6_ZONES: Set<String> = setOf(
        "1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa",   // ::1
        "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa",   // ::
        "d.f.ip6.arpa", "c.f.ip6.arpa",                                            // fc00::/7 (ULA)
        "8.e.f.ip6.arpa", "9.e.f.ip6.arpa", "a.e.f.ip6.arpa", "b.e.f.ip6.arpa",    // fe80::/10 (bağlantı-yerel)
        "8.b.d.0.1.0.0.2.ip6.arpa",                                                 // 2001:db8::/32 (belgeleme)
    )
    private val TLD = setOf("local", "onion", "invalid")

    /** [name] (küçük harf, sondaki nokta yok) yerelde "yok" denecek bir ad mı? */
    fun matches(name: String): Boolean {
        val n = name.lowercase(java.util.Locale.ROOT).trimEnd('.')
        val last = n.substringAfterLast('.')
        if (last in TLD) return true
        if (last != "arpa") return false
        if (n.endsWith(".in-addr.arpa")) return V4_ZONES.any { n == it || n.endsWith(".$it") }
        if (n.endsWith(".ip6.arpa")) return V6_ZONES.any { n == it || n.endsWith(".$it") }
        return false
    }

    /**
     * DNS sorgusunun ([b] içinde [off]'tan, [len] bayt; başlık dahil) tek sorusu yerel bir ad mı? Biçim bozuksa false (süzgeç ayrıca bakar).
     * Hızlı yol: son etiket önce bayt düzeyinde denetlenir; yalnızca adayda dizgi kurulur.
     */
    fun matchesQuery(b: ByteArray, off: Int, len: Int): Boolean {
        if (len < Packets.DNS_HDR + 5 || Packets.u16(b, off + 4) != 1) return false
        val buf = nameBuf.get()
        val r = DnsName.read(b, off, off + Packets.DNS_HDR, off + len, buf, compress = false)   // tek kural: [DnsName]
        if (r < 0) return false
        val n = DnsName.length(r)
        if (n == 0) return false
        var s = n
        while (s > 0 && buf[s - 1] != '.'.code.toByte()) s--
        if (!isCandidate(buf, s, n - s)) return false
        return matches(String(buf, 0, n, Charsets.ISO_8859_1))
    }
    private val nameBuf = ThreadLocal.withInitial { ByteArray(256) }

    private fun isCandidate(b: ByteArray, s: Int, l: Int): Boolean {
        fun eq(w: String): Boolean {
            if (w.length != l) return false
            for (k in 0 until l) { var c = b[s + k].toInt() and 0xFF; if (c in 'A'.code..'Z'.code) c += 32; if (c != w[k].code) return false }
            return true
        }
        return eq("arpa") || eq("local") || eq("onion") || eq("invalid")
    }

    /** Üst sunucu yerel ağda mı (ters bölgeler ve .local orada çözülebilir)? Adreslerden biri yerelse true. */
    fun lanUpstream(addresses: Collection<String>): Boolean = addresses.any { a -> Ip.parse(a)?.let { Dpi.isLocalAddress(it) } == true }
}
