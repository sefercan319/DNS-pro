package app.dnshizli.ui

import app.dnshizli.core.AeroArt
import app.dnshizli.core.AeroTheme
import app.dnshizli.core.ALIGN_CENTER
import app.dnshizli.core.ALIGN_LEFT
import app.dnshizli.core.ALIGN_RIGHT
import app.dnshizli.core.Gfx
import app.dnshizli.core.Rgb
import app.dnshizli.core.Sfx
import app.dnshizli.core.SpringSpec
import app.dnshizli.core.TextFit
import app.dnshizli.core.TextMetrics
import app.dnshizli.core.Themes

/** Metin renk rolleri: gerçek renk o anki temadan gelir (tema geçişinde renkler akar). */
enum class Ink { TEXT, SOFT, LINK, ON_CONTROL, GOOD }

/** Ölçüler (dp). Hepsi tek yerde: tasarımı değiştirmek için buraya bakın. */
object M {
    const val PAD = 20f
    const val MAX_W = 480f
    const val HEADER_H = 56f
    const val ORB_R = 80f
    const val CHIP_H = 34f
    const val ROW_H = 68f
    const val ROW_H_COMPACT = 52f
    const val ROW_GAP = 10f
    const val CARD_R = 22f
    const val MIN_TAP = 44f
}

/** Her karede çizim ve yerleşim kodlarının paylaştığı bağlam. */
class Env(val model: AppModel, val metrics: TextMetrics) {
    var theme: AeroTheme = Themes.aqua
    var art: AeroArt = AeroArt(Themes.aqua, 0.55f)

    /** Yazı ölçeği (sistem yazı boyutu, 1..1.3 arasına kırpılır). */
    var fs: Float = 1f

    /** Animasyon süre çarpanı; 0 ise animasyon yoktur. */
    var motion: Float = 1f

    /** Sahne saati (sn). */
    var time: Float = 0f

    /** Açılış belirmesi sırasında, kaydırma alanının sayfa başından beri geçen süresi (sn); yoksa [Reveal.DONE]. */
    var revealT: Float = Reveal.DONE

    /** Süs (sürekli) animasyonlar açık mı: kabarcıklar, küre dalgası. */
    var ambient: Boolean = true

    var width = 0f
    var height = 0f
    var insetTop = 0f
    var insetBottom = 0f

    /** Bağlanma kutlaması: başladığından beri geçen süre (sn; bitmişse büyük bir sayı), ekran merkezi ve küre yarıçapı. */
    var celeAge: Float = Float.MAX_VALUE
    var celeX: Float = 0f
    var celeY: Float = 0f
    var celeR: Float = 0f

    /** Ana düğmenin ekrandaki merkezi ve yarıçapı (ses paketi animasyonları için); [orbValid] düğme görünürken doğrudur. */
    var orbX: Float = 0f
    var orbY: Float = 0f
    var orbR: Float = 0f
    var orbValid: Boolean = false

    /** Animasyon hızı çarpanı (ayar: 0,6..1,6); süreler buna bölünür, yaylar hızlanır. */
    var speed: Float = 1f

    fun dur(sec: Float): Float = sec * motion / speed
    fun sz(size: Float): Float = size * fs

    /** Dokunuşta hafif titreşim (ayar açıksa). */
    fun tap(strong: Boolean = false, sfx: Sfx? = Sfx.TAP) { model.tapFeedback(strong, sfx) }

    fun color(ink: Ink): Int = when (ink) {
        Ink.TEXT -> theme.text
        Ink.SOFT -> theme.textSoft
        Ink.LINK -> theme.link
        Ink.ON_CONTROL -> Rgb.WHITE
        Ink.GOOD -> if (theme.dark) 0xFF7EE2A2.toInt() else 0xFF166534.toInt()    // yeşil: koyu zeminde açık, açık zeminde koyu ton
    }
}

enum class Role { BUTTON, SWITCH, SLIDER, TEXT, HEADING }

/** Erişilebilirlik (TalkBack) açıklaması. Etiketi olan düğümler görünür. */
class A11y(
    val label: String,
    val role: Role = Role.BUTTON,
    val checked: Boolean? = null,
    val value: String? = null,
    val longClick: Boolean = false,
)

/** Ekran tarafından okunan düğüm: ekran koordinatlarında sınır + açıklama. */
class A11yItem(val node: Node, val info: A11y, val l: Float, val t: Float, val r: Float, val b: Float)

interface Scrollable {
    val canScroll: Boolean
    fun dragBy(d: Float)
    fun flingBy(v: Float)
    fun stopScroll(): Boolean
}

/**
 * Sahne ağacının temel düğümü. Konum ve boyut (dp) üst düğüme göre; çocuklar [scrollY] kadar kayar.
 * Çizim, yerleşim, dokunma ve erişilebilirlik burada tanımlanır; bileşenler yalnızca ilgili yerleri geçersiz kılar.
 */
abstract class Node {
    /** Boştaki sahne bu düğüm (sayfa) için en geç kaç ms sonra yeniden çalışsın; -1: gerek yok (ör. saniyede bir değişen canlı değer). */
    open fun slowWakeMs(): Int = -1

    var x = 0f
    var y = 0f
    var w = 0f
    var h = 0f
    var parent: Node? = null
    var visible = true

    protected val kids = ArrayList<Node>(4)
    val children: List<Node> get() = kids

    open val scrollY: Float get() = 0f

    /** Açılış belirmesini kendi satırlarında kendisi uygular (kaydırma alanı ona ek bir şey yapmaz). */
    open val revealSelf: Boolean get() = false

    fun <T : Node> add(n: T): T { n.parent?.kids?.remove(n); n.parent = this; kids.add(n); return n }

    fun removeAll() { for (k in kids) k.parent = null; kids.clear() }

    fun remove(n: Node) { if (kids.remove(n)) n.parent = null }

    // ---- yerleşim / çizim / zaman
    open fun layout(env: Env, maxW: Float) {}

    open fun draw(g: Gfx, env: Env) = drawKids(g, env)

    protected fun drawKids(g: Gfx, env: Env) {
        // Dizinli döngü: Iterator nesnesi ayırmaz (her karede çalışan yol).
        var i = 0
        while (i < kids.size) {
            val k = kids[i++]
            if (!k.visible) continue
            g.save()
            g.translate(k.x, k.y - scrollY)
            k.draw(g, env)
            g.restore()
        }
    }

    /** [dt] saniye ilerlet. Etkileşimli bir animasyon sürüyorsa true (tam hızda kare ister). */
    open fun tick(dt: Float, env: Env): Boolean = tickKids(dt, env)

    protected fun tickKids(dt: Float, env: Env): Boolean {
        var any = false
        var i = 0
        while (i < kids.size) { val k = kids[i++]; if (k.visible && k.tick(dt, env)) any = true }
        return any
    }

    /** Yalnızca süs amaçlı sürekli animasyon var mı (düşük hızda kare yeter). */
    open fun ambient(env: Env): Boolean = ambientKids(env)

    protected fun ambientKids(env: Env): Boolean {
        var i = 0
        while (i < kids.size) { val k = kids[i++]; if (k.visible && k.ambient(env)) return true }
        return false
    }

    // ---- dokunma
    open val tappable: Boolean get() = false
    open val dragCapture: Boolean get() = false

    /** [dragCapture] düğümü sürüklemeyi şu an yönetiyor mu (ör. kaydırıcının topuzu tutuldu mu)? */
    open val dragActive: Boolean get() = false

    /** Sürüklemeyi her yönde alır (küre gibi): dikey hareket sayfayı kaydırmaz. Yalnız [dragCapture] ve [dragActive] ile anlamlı. */
    open val dragAll: Boolean get() = false

    /** Yatay sürükleme eşiği aşıldı ve düğüm sürüklemeyi devralıyor (dikey hareket sayfayı kaydırmaya gider). */
    open fun onDragStart(lx: Float, ly: Float, env: Env) {}
    open val longPressable: Boolean get() = false
    open val hitSlop: Float get() = 0f

    /** (lx, ly) bu düğümün yerel koordinatlarında mı? */
    open fun contains(lx: Float, ly: Float): Boolean {
        val s = hitSlop
        return lx >= -s && ly >= -s && lx <= w + s && ly <= h + s
    }

    open fun onDown(lx: Float, ly: Float, env: Env) {}
    open fun onDrag(lx: Float, ly: Float, env: Env) {}

    /** Parmak kalktı. [tap] true ise düğümün içinde kalktı (tıklama). */
    open fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {}
    open fun onCancel(env: Env) {}
    open fun onLongPress(env: Env): Boolean = false

    /** En üstteki dokunulabilir düğümü bulur. (lx, ly) bu düğümün yerel koordinatlarıdır. */
    open fun hit(lx: Float, ly: Float): Node? {
        if (!visible) return null
        for (i in kids.size - 1 downTo 0) {
            val k = kids[i]
            if (!k.visible) continue
            val r = k.hit(lx - k.x, ly + scrollY - k.y)
            if (r != null) return r
        }
        return if ((tappable || dragCapture) && contains(lx, ly)) this else null
    }

    /** (lx, ly) noktasındaki en içteki kaydırılabilir düğüm (varsa). */
    fun hitScrollable(lx: Float, ly: Float): Node? {
        if (!visible) return null
        for (i in kids.size - 1 downTo 0) {
            val k = kids[i]
            if (!k.visible) continue
            val r = k.hitScrollable(lx - k.x, ly + scrollY - k.y)
            if (r != null) return r
        }
        return if (this is Scrollable && lx >= 0f && ly >= 0f && lx <= w && ly <= h) this else null
    }

    /** Bu düğümün [root] içindeki mutlak sol-üst konumu. */
    fun absX(): Float { var v = 0f; var n: Node? = this; while (n != null) { v += n.x; n = n.parent }; return v }
    fun absY(): Float { var v = 0f; var n: Node? = this; while (n != null) { val p = n.parent; v += n.y - (p?.scrollY ?: 0f); n = p }; return v }

    // ---- erişilebilirlik
    open fun a11y(): A11y? = null
    open fun a11yClick(env: Env) { onUp(w / 2, h / 2, true, env) }
    open fun a11yAdjust(dir: Int, env: Env) {}

    /** Ekranda görünen ve etiketi olan tüm düğümleri sırayla toplar. [clip]: görünür alan (ekran koordinatları). */
    fun collectA11y(out: MutableList<A11yItem>, ox: Float, oy: Float, clipT: Float, clipB: Float) {
        if (!visible) return
        val info = a11y()
        if (info != null) {
            val t = oy
            val b = oy + h
            if (b > clipT && t < clipB) out.add(A11yItem(this, info, ox, maxOf(t, clipT), ox + w, minOf(b, clipB)))
        }
        for (k in kids) {
            if (!k.visible) continue
            var ct = clipT
            var cb = clipB
            if (this is ClipsChildren) { ct = maxOf(ct, oy + clipInsetTop); cb = minOf(cb, oy + h) }
            k.collectA11y(out, ox + k.x, oy + k.y - scrollY, ct, cb)
        }
    }
}

/** İki parmakla yakınlaştırılabilen düğüm: [f] ölçek değişimi (1'den büyük: büyüt), ([cx], [cy]) yerel orta nokta. */
interface Pinchable {
    fun onPinch(f: Float, cx: Float, cy: Float, env: Env)
}

/** Çocuklarını kendi sınırlarına kırpan düğümler (kaydırma alanları). [clipInsetTop]: üstte başka bir öğenin (üst çubuk) örttüğü pay. */
interface ClipsChildren {
    val clipInsetTop: Float get() = 0f
}

/**
 * Basınca küçülüp bırakınca geri dönen düğümler için ortak taban. Hareket stile göre değişir ([StyleMotion]): basış ve
 * bırakış birer yaydır (bırakınca hedefi aşıp oturabilir: Y2K'da jöle, Eco'da yaprak gibi), Metro dokunulan noktaya doğru eğilir.
 * Yay hızı korunduğundan basıp hemen bırakmak ya da parmağı kaydırıp geri getirmek zıplamadan akıcı çalışır.
 */
abstract class PressNode : Node() {
    /** 0..1 basış ilerlemesi (kart ve düğme çizimleri bunu okur). */
    val press = Anim(0f)

    /** Yaylı basış: 0..1 civarı; bırakınca hafifçe negatife (büyümeye) sallanabilir. Yalnızca ölçek ve eğim için. */
    protected val lift = Anim(0f)
    protected var down = false
    private var depth = 1f
    private var tiltDeg = 0f
    private var tiltX = 0f

    override val tappable: Boolean get() = true

    override fun onDown(lx: Float, ly: Float, env: Env) {
        down = true
        val m = env.art.motion
        depth = m.depth; tiltDeg = m.tilt
        tiltX = if (w > 1f) ((lx / w - 0.5f) * 2f).coerceIn(-1f, 1f) else 0f
        press.go(1f, env.dur(0.08f))
        liftTo(1f, m.down, env)
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) { release(env) }
    override fun onCancel(env: Env) { release(env) }

    private fun release(env: Env) {
        down = false
        val m = env.art.motion
        press.go(0f, env.dur(0.30f), if (m.spring > 0f) Ease.BACK else Ease.OUT)
        liftTo(0f, m.up, env)
    }

    private fun liftTo(v: Float, spec: SpringSpec, env: Env) {
        if (env.motion <= 0f) lift.set(v) else lift.springTo(v, spec, env.speed)
    }

    override fun tick(dt: Float, env: Env): Boolean {
        val a = press.step(dt)
        val l = lift.step(dt)
        val b = tickKids(dt, env)
        return a || l || b
    }

    /** Basılıyken stile göre küçült (ve Metro'da eğ); bırakınca yaylanarak döner. */
    protected fun pressScale(g: Gfx, cx: Float, cy: Float, amount: Float = 0.035f) {
        val l = lift.value
        val s = 1f - amount * depth * l
        val rot = if (tiltDeg != 0f) tiltX * tiltDeg * l else 0f
        if (s != 1f || rot != 0f) {
            g.translate(cx, cy)
            if (rot != 0f) g.rotate(rot)
            g.scale(s, s)
            g.translate(-cx, -cy)
        }
    }
}

/** Tek veya çok satırlı metin. Sığmayan satır "…" ile kısalır. [maxLines] 0 ise sınırsız (sözcüklerden kaydırır). */
class Label(
    text: String,
    private val size: Float,
    private val bold: Boolean = false,
    private val ink: Ink = Ink.TEXT,
    private val align: Int = ALIGN_LEFT,
    private val maxLines: Int = 1,
    private val headline: Boolean = false,
    /** Tek satırlı yazı sığmazsa önce (en çok %78'e kadar) küçülür, sonra "…" ile kısalır. */
    private val shrink: Boolean = false,
    /** [shrink] için en küçük oran (varsayılan %78). Başlık çubuğu büyük yazıda daha çok küçülebilir. */
    private val minFit: Float = 0.78f,
) : Node() {
    var text: String = text
        set(v) { if (v != field) { field = v; laidW = -1f } }
    var alpha = 1f
    var dy = 0f

    private var lines: List<String> = emptyList()
    private var laidW = -1f
    private var laidFs = 0f
    private var laidMul = 1f
    private var lineH = 0f
    private var fit = 1f

    /** Yazı boyutu: sistem ölçeği ve (başlıklarda) stilin başlık çarpanı. */
    private fun px(env: Env): Float = env.sz(size) * (if (headline) env.art.titleScale else 1f)

    private fun relay(env: Env, maxW: Float) {
        val s = px(env)
        laidW = maxW
        laidFs = env.fs
        laidMul = if (headline) env.art.titleScale else 1f
        lineH = s * 1.32f
        fit = 1f
        if (shrink && maxLines == 1 && maxW > 0f) {
            val tw = env.metrics.textWidth(text, s, bold)
            if (tw > maxW) fit = maxOf(minFit, maxW / tw)
        }
        lines = if (maxLines == 1) {
            listOf(TextFit.ellipsize(env.metrics, text, maxW, s * fit, bold))
        } else {
            val l = TextFit.wrap(env.metrics, text, maxW, s, bold)
            if (maxLines > 0 && l.size > maxLines) {
                val cut = ArrayList(l.subList(0, maxLines))
                cut[maxLines - 1] = TextFit.ellipsize(env.metrics, cut[maxLines - 1] + " …", maxW, s, bold)
                cut
            } else l
        }
    }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        relay(env, maxW)
        h = lines.size * lineH
    }

    override fun draw(g: Gfx, env: Env) {
        if (w <= 0f || alpha <= 0.01f) return
        if (laidW != w || laidFs != env.fs || (headline && laidMul != env.art.titleScale)) relay(env, w)
        val s = px(env) * fit
        g.save()
        if (alpha < 1f) g.alpha(alpha)
        g.paint(env.color(ink))
        val px = when (align) { ALIGN_CENTER -> w / 2f; ALIGN_RIGHT -> w; else -> 0f }
        for (i in lines.indices) g.text(lines[i], px, dy + s * 1.0f + i * lineH, s, bold, align)
        g.restore()
    }

    override fun a11y(): A11y? = if (text.isEmpty()) null else A11y(text, Role.TEXT)
}

class Spacer(private val height: Float) : Node() {
    override fun layout(env: Env, maxW: Float) { w = maxW; h = height }
}

/** Dikey yığın: çocukları üst üste dizer. */
open class Column(
    var gap: Float = 0f,
    var padL: Float = 0f,
    var padT: Float = 0f,
    var padR: Float = 0f,
    var padB: Float = 0f,
) : Node() {
    override fun layout(env: Env, maxW: Float) {
        w = maxW
        var cy = padT
        var first = true
        for (k in kids) {
            if (!k.visible) continue
            if (!first) cy += gap
            first = false
            k.layout(env, maxW - padL - padR)
            k.x = padL
            k.y = cy
            cy += k.h
        }
        h = cy + padB
    }
}

/** Dikey kaydırılan alan. Boyutunu sahip belirler ([setViewport]); içerik kendi ölçüsünü hesaplar. */
open class ScrollView : Node(), Scrollable, ClipsChildren {
    private val sc = Scroller()

    // İnce, şeffaf kaydırma çubuğu: kayarken belirir, durunca yavaşça söner.
    private var barA = 0f
    private var barIdle = 0f
    private var lastPos = Float.NaN

    /** Üstteki opak çubuğun örttüğü yükseklik: bu bölgedeki içerik erişilebilirlik ağacına girmez. */
    override var clipInsetTop: Float = 0f
    var content: Node? = null
        private set

    override val scrollY: Float get() = sc.pos

    val offset: Float get() = sc.pos

    /** Sayfa açılış belirmesi: başlangıçtan beri geçen süre (sn); bitince [Reveal.DONE]. */
    private var reveal = Reveal.DONE

    fun startReveal(env: Env) {
        if (env.motion > 0f && env.art.motion.stagger > 0f) reveal = 0f
    }

    /** En fazla kaydırma konumu (içerik sığıyorsa 0). */
    val maxOffset: Float get() = sc.max
    override val canScroll: Boolean get() = sc.max > sc.min + 0.5f || sc.pullable

    /** En üstte aşağı çekmeyi aç; bırakıldığında çekme mesafesiyle [onPullRelease] çağrılır. */
    var pullable: Boolean
        get() = sc.pullable
        set(v) { sc.pullable = v }
    var onPullRelease: ((Float) -> Unit)? = null

    /** Şu anki çekme mesafesi (dp); çekilmiyorsa 0. */
    val pull: Float get() = sc.pull

    fun setContent(n: Node) {
        content?.let { remove(it) }
        content = n
        add(n)
    }

    /** Görünür alanın boyutunu ve içerik yerleşimini ayarla. [pad]: kaydırma sonunda ek boşluk. */
    fun setViewport(env: Env, vw: Float, vh: Float, pad: Float = 0f) {
        w = vw
        h = vh
        val c = content ?: return
        c.layout(env, vw)
        c.x = 0f; c.y = 0f
        sc.min = 0f
        sc.max = maxOf(0f, c.h + pad - vh)
        sc.clampNow()
    }

    fun scrollTo(p: Float) = sc.jump(p)

    override fun dragBy(d: Float) = sc.drag(d)
    override fun flingBy(v: Float) {
        val p = sc.pull
        sc.fling(v)
        if (p > 0f) onPullRelease?.invoke(p)
    }
    override fun stopScroll(): Boolean = sc.stop()

    override fun tick(dt: Float, env: Env): Boolean {
        val a = sc.step(dt)
        var r = false
        val p = sc.pos
        if (p != lastPos) {
            if (!lastPos.isNaN() && sc.max > 0.5f) { barA = 1f; barIdle = 0f }
            lastPos = p
        } else if (barA > 0f) {
            barIdle += dt
            if (barIdle > BAR_HOLD) barA = if (env.motion > 0f) maxOf(0f, barA - dt / BAR_FADE) else 0f
        }
        if (barA > 0f) r = true
        if (reveal != Reveal.DONE) {
            val stg = env.art.motion.stagger
            reveal += if (env.motion > 0f) dt * env.speed / env.motion else Reveal.limit(stg)
            if (stg <= 0f || reveal >= Reveal.limit(stg)) reveal = Reveal.DONE else r = true
        }
        val b = tickKids(dt, env)
        return a || b || r
    }

    override fun draw(g: Gfx, env: Env) {
        g.save()
        g.clipRect(0f, 0f, w, h)
        val rv = reveal
        val stg = env.art.motion.stagger
        if (rv != Reveal.DONE) env.revealT = rv
        val c = content
        if (c != null) {
            // Görünür olmayan çocukları çizme (uzun listelerde işi azaltır).
            val vt = scrollY
            val vb = scrollY + h
            val ck = c.children
            var i = 0
            while (i < ck.size) {
                val k = ck[i++]
                if (!k.visible) continue
                val ky = k.y + c.y
                if (ky + k.h < vt - 40f || ky > vb + 40f) continue
                g.save()
                g.translate(k.x + c.x, ky - scrollY)
                if (rv != Reveal.DONE && !k.revealSelf) Reveal.apply(g, env, Reveal.progress(rv, i - 1, stg), k.w, k.h)
                k.draw(g, env)
                g.restore()
            }
            // İçerik düğümünün kendi çizimi (zemin vb.) gerekmiyor; yalnızca çocukları çizilir.
        }
        env.revealT = Reveal.DONE
        drawBar(g, env)
        g.restore()
    }

    private fun drawBar(g: Gfx, env: Env) {
        if (barA <= 0.01f || sc.max <= 0.5f) return
        val top = clipInsetTop + 6f
        val track = h - env.insetBottom - 6f - top
        if (track < 48f) return
        val thumb = minOf(track, maxOf(36f, track * h / (sc.max + h)))
        val f = if (sc.pos <= 0f) 0f else if (sc.pos >= sc.max) 1f else sc.pos / sc.max
        val y = top + (track - thumb) * f
        g.save()
        g.alpha(barA * BAR_ALPHA)
        g.paint(env.theme.text)
        g.roundRect(w - 6.5f, y, w - 3.5f, y + thumb, 1.5f)
        g.restore()
    }

    private companion object {
        const val BAR_HOLD = 0.7f
        const val BAR_FADE = 0.4f
        const val BAR_ALPHA = 0.4f
    }

    override fun hit(lx: Float, ly: Float): Node? {
        if (!visible || lx < 0f || ly < 0f || lx > w || ly > h) return null
        return super.hit(lx, ly)
    }
}
