package app.dnshizli.core

/**
 * WireGuard tünelinin canlı durumu (servisten bir anlık görüntü): bağlantı, yol, kuantum sonrası koruma, trafik ve son el
 * sıkışmanın yaşı. Arayüz saniyede bir okur; servis yazmaz, yalnız okunur değerlerden kurulur.
 */
class WgStats(
    val connected: Boolean,
    val stealth: Boolean,
    val pq: Boolean,
    val pqWait: Boolean,
    val hop: Boolean,
    val shaping: Boolean,
    val rxBytes: Long,
    val txBytes: Long,
    /** Son el sıkışmadan bu yana (sn); hiç olmadıysa -1. */
    val handshakeAgeSec: Long,
    /** Bağlantı süresi (sn). */
    val upSec: Long,
) {
    /** Kısa durum satırı ("Bağlı · ↓ 12 MB ↑ 3,1 MB · Stealth · PQ · el sıkışma 45 sn önce"). */
    fun line(): String {
        val t = L.tx
        val parts = ArrayList<String>(6)
        // önce en önemli: durum ve trafik (dar ekranda sonu kısaltılır)
        parts.add(if (stale) t.WG_STALE else if (connected) t.WG_LIVE_ON else t.WG_LIVE_WAIT)
        parts.add("↓ " + Format.bytes(rxBytes) + "  ↑ " + Format.bytes(txBytes))
        if (stealth) parts.add("Stealth")
        if (pq) parts.add("PQ") else if (pqWait) parts.add(t.WG_PQ_WAIT)
        if (hop) parts.add(t.WG_HOP_SHORT)
        if (shaping) parts.add(t.WG_SHAPE_SHORT)
        if (handshakeAgeSec >= 0) parts.add(t.wgHandshakeAge(handshakeAgeSec))
        return parts.joinToString(" · ")
    }

    /** El sıkışma 3 dakikadan eskiyse (WireGuard 2 dk'da yeniler) bağlantı şüpheli: arayüz uyarır. */
    val stale: Boolean get() = connected && handshakeAgeSec > STALE_SEC

    companion object {
        const val STALE_SEC = 180L
    }
}
