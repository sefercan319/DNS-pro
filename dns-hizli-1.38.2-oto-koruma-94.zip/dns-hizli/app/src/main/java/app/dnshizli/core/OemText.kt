package app.dnshizli.core

/** Üretici izleme engeli metinleri (12 dil). Sıra: TR, EN, DE, ES, FR, PT, RU, IT, ID, VI, PL, UK. */
object OemText {
    val M: Map<String, Array<String>> = mapOf(
        "title" to arrayOf("Üretici izlemesini engelle", "Block manufacturer tracking", "Hersteller-Tracking blockieren", "Bloquear rastreo del fabricante",
            "Bloquer le pistage du fabricant", "Bloquear rastreamento do fabricante", "Блокировать слежку производителя", "Blocca il tracciamento del produttore",
            "Blokir pelacakan produsen", "Chặn theo dõi của nhà sản xuất", "Blokuj śledzenie producenta", "Блокувати стеження виробника"),
        "note" to arrayOf("Samsung ve Xiaomi sistem izleme ve reklamı", "Samsung and Xiaomi system tracking and ads", "System-Tracking und Werbung von Samsung und Xiaomi",
            "Rastreo y anuncios del sistema de Samsung y Xiaomi", "Pistage et pubs système de Samsung et Xiaomi", "Rastreamento e anúncios do sistema Samsung e Xiaomi",
            "Системная слежка и реклама Samsung и Xiaomi", "Tracciamento e pubblicità di sistema Samsung e Xiaomi", "Pelacakan dan iklan sistem Samsung dan Xiaomi",
            "Theo dõi và quảng cáo hệ thống của Samsung, Xiaomi", "Systemowe śledzenie i reklamy Samsung i Xiaomi", "Системне стеження й реклама Samsung і Xiaomi"),
    )

    fun t(key: String, lang: Lang = L.lang): String {
        val row = M[key] ?: return key
        return row.getOrNull(lang.ordinal)?.takeIf { it.isNotBlank() } ?: row.getOrNull(Lang.EN.ordinal) ?: row[0]
    }
}
