package app.dnshizli.core

import java.util.ArrayDeque
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock

/**
 * Sorgunun "alanı": sorulan adın kayıt edilebilir kısmı (eTLD+1), küçük harfle. "x.y.flood.example" → "flood.example".
 * Şifreli DNS şeritlerinin kuyruğu ([ZoneQueue]) işleri alana göre gruplar.
 *
 * Public Suffix List yüklüyse ([PublicSuffix]) ona bakılır; değilse küçük bir sezgi kullanılır (son iki etiket; son etiket iki harfli
 * bir ülke uzantısı ve öncesi "co/com/gov…" gibi yaygın bir ikinci düzey ad ise son üç etiket). Tek etiketli ad kendisi bir alandır.
 * Hiçbir koşulda atmaz: okunamayan soru adı "" alanına düşer.
 */
internal object ZoneKey {
    private val SECOND_LEVEL = setOf("co", "com", "org", "net", "gov", "edu", "ac", "or", "ne", "go", "gob", "mil")

    /** [msg] DNS mesajının ([base]'ten başlar, [n] bayt) ilk sorusunun alanı. */
    fun of(msg: ByteArray, base: Int, n: Int): String {
        if (n < Packets.DNS_HDR || base < 0 || base + n > msg.size) return ""
        val end = base + n
        val buf = ByteArray(256)
        val r = DnsName.read(msg, base, base + Packets.DNS_HDR, end, buf, compress = false)    // tek kural: [DnsName]
        if (r < 0) return ""
        val len = DnsName.length(r)
        if (len == 0) return ""
        val s = start(buf, len)
        return String(buf, s, len - s, Charsets.ISO_8859_1)
    }

    /** Noktalı [name]'in alanı (testler ve tanılama için; sıcak yolda [of] kullanılır). */
    fun ofName(name: String): String {
        val b = name.lowercase().trimEnd('.').toByteArray(Charsets.ISO_8859_1)
        if (b.isEmpty()) return ""
        val s = start(b, b.size)
        return String(b, s, b.size - s, Charsets.ISO_8859_1)
    }

    /** Alanın [buf] (noktalı, küçük harfli ad; [len] bayt) içindeki başlangıcı. */
    private fun start(buf: ByteArray, len: Int): Int {
        val psl = PublicSuffix.registrableStart(buf, len)
        if (psl != PublicSuffix.NOT_READY) return maxOf(psl, 0)
        var d1 = -1; var d2 = -1; var d3 = -1
        var i = len - 1
        while (i >= 0 && d3 < 0) {
            if (buf[i] == '.'.code.toByte()) { if (d1 < 0) d1 = i else if (d2 < 0) d2 = i else d3 = i }
            i--
        }
        if (d1 < 0 || d2 < 0) return 0                                       // tek etiket ya da "site.com": adın tamamı
        val tldLen = len - d1 - 1
        val second = String(buf, d2 + 1, d1 - d2 - 1, Charsets.ISO_8859_1)
        return if (tldLen == 2 && second in SECOND_LEVEL) (if (d3 < 0) 0 else d3 + 1) else d2 + 1
    }
}

/** [ZoneQueue]'daki bir iş: kuyruğa girdiği andan şerit onu bırakana ([ZoneQueue.finish]) kadar aynı nesne. */
internal class Ticket<J : Any> internal constructor(val job: J, val at: Long, internal val zone: Zone<J>) {
    /** Şeridin bu iş için soru-cevaba başladığı an ([Long.MAX_VALUE]: henüz başlamadı; bağlantı kurulumu sayılmaz). */
    @Volatile internal var startedAt = Long.MAX_VALUE
    internal var finished = false
}

internal class Zone<J : Any>(val key: String) {
    val q = ArrayDeque<Ticket<J>>()
    val running = ArrayList<Ticket<J>>(4)
    var flaggedUntil = Long.MIN_VALUE / 2
}

/**
 * Şifreli DNS şeritlerinin iş kuyruğu. Her iş bir alana ([ZoneKey]) bağlıdır.
 *
 * Sorun: tek bir alanın adları yavaş çözülüyorsa (yetkili sunucu yavaşsa ya da kasıtlı bir selse) o alanın işleri bütün şeritleri
 * zaman aşımı süresince tutar; başka alanların hızlı sorguları tek sıralı (FIFO) kuyrukta bekler ("sıra başı engeli").
 *
 * Çözüm: şüphe yokken sıra BİREBİR eskisi gibidir (en eski iş önce, hiçbir alan öncelikli değil, sınır yok). Bir alan "şüpheli" olunca
 *  (a) başka alanların işleri ona göre öne geçer, (b) o alanın eşzamanlı işi [zoneCap] ile sınırlanır: böylece sel şeritlerin hepsini
 *  tutamaz; en az bir şerit ve bütün ek şeritler ([burstDue]) başka alanlara kalır.
 * Şüphe KANITA dayanır: alanın çalışan bir işi [suspectAfterMs]'den uzun sürüyor (kanıt yoksa [Long.MAX_VALUE] döner: sunucu şu an
 * hiç cevap vermiyorsa ya da hat yavaşsa herkes yavaştır, kimse cezalandırılmaz) ya da alan yakın zamanda ZAMAN AŞIMINA uğradı
 * ([finish]'te `slow`; [flagMs] boyunca). Şüpheli alanın en eski işi [agingMs]'den uzun beklediyse sıralamada normal sayılır
 * (sınırı hâlâ geçerli): şüpheli alan aç kalmaz, yalnızca payını alır.
 *
 * Bellek: toplam [capacity], alan başına [perZone] bekleyen iş; sınırı aşan teklif reddedilir. Boşalan alanın kaydı silinir
 * (şüpheli işaretliler [flagMs] sonra); izlenen alan sayısı [maxZones]'ı geçmez.
 *
 * Tek kilit; tüm işlemler kısa ve alan sayısıyla (≤ yüzler) doğrusaldır.
 */
internal class ZoneQueue<J : Any>(
    private val capacity: Int,
    private val perZone: Int,
    private val zoneCap: Int,
    private val nowMs: () -> Long,
    private val suspectAfterMs: () -> Long,
    private val flagMs: Long = FLAG_MS,
    private val agingMs: Long = AGING_MS,
    private val maxZones: Int = MAX_ZONES,
    /**
     * Bütün şüpheli alanların birlikte tutabileceği eşzamanlı iş sayısı. [zoneCap] yalnızca alan başına sınırlar; her biri tek işli
     * çok sayıda şüpheli alan (dağıtılmış sel) bu sınırı hiç aşmadan bütün şeritleri doldururdu. Bu bütçe onu engeller.
     */
    private val suspectBudget: Int = zoneCap,
) {
    private val lock = ReentrantLock()
    private val notEmpty = lock.newCondition()
    private val zones = HashMap<String, Zone<J>>()
    @Volatile private var total = 0

    init {
        require(capacity >= 1 && perZone >= 1 && zoneCap >= 1 && maxZones >= 1 && suspectBudget >= 1) { "sınırlar pozitif olmalı" }
    }

    /** Şüpheli alanların şu an tuttuğu toplam iş sayısı (kilit altında). */
    private fun suspectRunning(now: Long, after: Long): Int {
        var n = 0
        for (z in zones.values) if (z.running.isNotEmpty() && suspect(z, now, after)) n += z.running.size
        return n
    }

    /** Bekleyen (henüz bir şeride verilmemiş) toplam iş. Şeride verilmeyecek olanlar (sınırı dolmuş şüpheli alan) dahildir. */
    fun size(): Int = total
    fun isEmpty(): Boolean = total == 0

    /** İzlenen alan sayısı (tanılama/test). */
    fun zoneCount(): Int { lock.lock(); try { return zones.size } finally { lock.unlock() } }

    /** [zone] şu an şüpheli mi? (tanılama/test) */
    fun isSuspect(zone: String): Boolean {
        lock.lock()
        try {
            val z = zones[zone] ?: return false
            return suspect(z, nowMs(), suspectAfterMs())
        } finally { lock.unlock() }
    }

    /** [zone] alanının çalışan iş sayısı (tanılama/test). */
    fun runningOf(zone: String): Int { lock.lock(); try { return zones[zone]?.running?.size ?: 0 } finally { lock.unlock() } }

    /** İşi kuyruğa koyar; kuyruk ya da alanın payı doluysa false. */
    fun offer(zone: String, job: J, at: Long): Boolean {
        lock.lock()
        try {
            if (total >= capacity) return false
            var z = zones[zone]
            if (z == null) {
                if (zones.size >= maxZones) trim(nowMs())
                if (zones.size >= maxZones) return false
                z = Zone(zone)
                zones[zone] = z
            }
            if (z.q.size >= perZone) return false
            z.q.addLast(Ticket(job, at, z))
            total++
            notEmpty.signal()
            return true
        } finally { lock.unlock() }
    }

    /**
     * Şeride verilebilecek en uygun işi alır; yoksa [timeoutMs] kadar bekler (hâlâ yoksa null). Dönen bilet [finish] ile bırakılmalıdır.
     * Sıra: şüpheli olmayan alanlar önce (en eski iş önce), sonra şüpheliler; şüpheli alan sınırındaysa iş verilmez.
     */
    @Throws(InterruptedException::class)
    fun poll(timeoutMs: Long): Ticket<J>? {
        var nanos = TimeUnit.MILLISECONDS.toNanos(timeoutMs)
        lock.lockInterruptibly()
        try {
            while (true) {
                val now = nowMs()
                val z = best(now)
                if (z != null) {
                    val t = z.q.pollFirst()
                    total--
                    z.running.add(t)
                    return t
                }
                if (nanos <= 0L) return null
                // Parçalı bekleme: kanıt zamanla değişir (şüphe düşer, bayrak söner); olay olmasa da kısa aralıkla yeniden bakılır.
                val slice = minOf(nanos, SLICE_NANOS)
                val left = notEmpty.awaitNanos(slice)
                nanos -= maxOf(1L, slice - left)
            }
        } finally { lock.unlock() }
    }

    /** Şeridin soru-cevaba (bağlantı kurulumu bitince) başladığını bildirir: "çalışan iş yaşı" buradan sayılır. İlk çağrı geçerlidir. */
    fun started(t: Ticket<J>) {
        if (t.startedAt == Long.MAX_VALUE) t.startedAt = nowMs()
    }

    /**
     * Bileti bırakır. [slow]: iş sunucu sağlıklıyken zaman aşımına uğradı (alan [flagMs] boyunca şüpheli sayılır).
     * Aynı bilet için ikinci çağrı etkisizdir.
     */
    fun finish(t: Ticket<J>, slow: Boolean) {
        lock.lock()
        try {
            if (t.finished) return
            t.finished = true
            val z = t.zone
            z.running.remove(t)
            val now = nowMs()
            if (slow) z.flaggedUntil = now + flagMs
            if (z.q.isEmpty() && z.running.isEmpty() && z.flaggedUntil <= now) {
                if (zones[z.key] === z) zones.remove(z.key)
            } else if (z.q.isNotEmpty()) {
                notEmpty.signal()                                       // payı boşaldı: bekleyen bir şerit uyanıp bakabilir
            }
        } finally { lock.unlock() }
    }

    /** Şu an bir şeride verilebilecek bekleyen iş sayısı (sınırı dolmuş şüpheli alanın fazlası sayılmaz). */
    fun ready(): Int {
        lock.lock()
        try {
            if (total == 0) return 0
            val now = nowMs()
            val after = suspectAfterMs()
            var budget = maxOf(0, suspectBudget - suspectRunning(now, after))
            var n = 0
            for (z in zones.values) {
                if (z.q.isEmpty()) continue
                if (suspect(z, now, after)) {
                    val k = maxOf(0, minOf(z.q.size, zoneCap - z.running.size, budget))
                    budget -= k
                    n += k
                } else n += z.q.size
            }
            return n
        } finally { lock.unlock() }
    }

    /**
     * Geçici ek şerit gerekli mi? Verilebilir bir iş [afterMs]'den uzun beklediyse; ya da şüpheli bir alan şerit tutarken şüpheli
     * OLMAYAN bir alanın işi [earlyMs]'den uzun beklediyse (şeritler başkasının yavaş işleriyle dolu: daha fazla beklemenin anlamı yok).
     * Sınırı dolmuş şüpheli alanın bekleyenleri sayılmaz: ek şerit onlara verilmez, sel kendi kendine şerit açtıramaz.
     */
    fun burstDue(afterMs: Long, earlyMs: Long): Boolean {
        lock.lock()
        try {
            if (total == 0) return false
            val now = nowMs()
            val after = suspectAfterMs()
            val susRun = suspectRunning(now, after)
            val someSuspectRunning = susRun > 0
            for (z in zones.values) {
                val head = z.q.peekFirst() ?: continue
                val sus = suspect(z, now, after)
                if (sus && (z.running.size >= zoneCap || susRun >= suspectBudget)) continue
                val w = now - head.at
                if (w >= afterMs) return true
                if (someSuspectRunning && !sus && w >= earlyMs) return true
            }
            return false
        } finally { lock.unlock() }
    }

    /** Bekleyen her şeyi atar (kapanış); çalışan biletlerin sonradan [finish] çağırması zararsızdır. */
    fun clear() {
        lock.lock()
        try { zones.clear(); total = 0 } finally { lock.unlock() }
    }

    // ------------------------------------------------------------------ iç

    private fun suspect(z: Zone<J>, now: Long, after: Long): Boolean {
        if (z.flaggedUntil > now) return true
        if (after == Long.MAX_VALUE) return false
        for (i in 0 until z.running.size) {
            val s = z.running[i].startedAt
            if (s != Long.MAX_VALUE && now - s >= after) return true
        }
        return false
    }

    /** Şu an iş verilecek alan: şüpheli olmayanlar önce, sonra şüpheliler; her sınıfta başı en eski olan. Yoksa null. Kilit altında. */
    private fun best(now: Long): Zone<J>? {
        if (total == 0) return null
        val after = suspectAfterMs()
        val susRun = suspectRunning(now, after)
        var best: Zone<J>? = null
        var bestLow = false
        var bestAt = 0L
        for (z in zones.values) {
            val head = z.q.peekFirst() ?: continue
            val sus = suspect(z, now, after)
            if (sus && (z.running.size >= zoneCap || susRun >= suspectBudget)) continue
            val low = sus && now - head.at < agingMs             // uzun bekleyen şüpheli alan sıralamada normal sayılır
            if (best == null || (bestLow && !low) || (low == bestLow && head.at < bestAt)) {
                best = z; bestLow = low; bestAt = head.at
            }
        }
        return best
    }

    /** Boş ve işaretsiz alan kayıtlarını siler; hâlâ doluysa işaretli ama boş olanları da (bayrak unutulur). */
    private fun trim(now: Long) {
        val it = zones.values.iterator()
        while (it.hasNext()) {
            val z = it.next()
            if (z.q.isEmpty() && z.running.isEmpty() && z.flaggedUntil <= now) it.remove()
        }
        if (zones.size < maxZones) return
        val it2 = zones.values.iterator()
        while (it2.hasNext()) {
            val z = it2.next()
            if (z.q.isEmpty() && z.running.isEmpty()) it2.remove()
        }
    }

    companion object {
        /** Çalışan iş bu süreden (ms) uzun sürerse alan şüpheli sayılır (sunucu başka işlere sağlıklı cevap veriyorsa). */
        const val SUSPECT_MS = 200L

        /** Zaman aşımına uğrayan alan bu süre (ms) şüpheli kalır. */
        const val FLAG_MS = 30_000L

        /** Şüpheli alanın en eski işi bu kadar beklerse sıralamada normal alan gibi sayılır (ms). */
        const val AGING_MS = 1500L

        const val MAX_ZONES = 1024
        private val SLICE_NANOS = TimeUnit.MILLISECONDS.toNanos(250)
    }
}
