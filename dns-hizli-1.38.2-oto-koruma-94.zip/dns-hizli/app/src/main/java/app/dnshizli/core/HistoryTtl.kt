package app.dnshizli.core

/**
 * Geçmişi otomatik sil: günlük (tanılama), son engellenen/geçen adlar, gizlilik raporu ve bağlantı oturumları bu süreden eskiyse
 * silinir. Gizlilik raporu gün kovalarıyla tutulduğundan: 1 hafta → 7 gün, 1 gün → yalnızca bugün (yerel gece yarısında silinir,
 * hiçbir kayıt 24 saatten eski olmaz), 1 saat → rapor hiç tutulmaz (saat altı kova yok; tutulanlar hemen silinir).
 */
enum class HistoryTtl(val id: String, val ms: Long) {
    OFF("0", 0L), HOUR("h", 3_600_000L), DAY("d", 86_400_000L), WEEK("w", 7 * 86_400_000L);

    /** Gizlilik raporunun tutacağı gün sayısı (0 = hiç). */
    val reportDays: Int get() = when (this) { OFF, WEEK -> PrivacyReport.DAYS; DAY -> 1; HOUR -> 0 }

    companion object {
        const val PRUNE_EVERY_MS = 5 * 60_000L

        fun byId(id: String?): HistoryTtl? = values().firstOrNull { it.id == id }

        /** [b], [a]'dan daha uzun saklıyor mu (kapalı = sonsuz)? İçe aktarmada uyarı için. */
        fun looser(a: HistoryTtl, b: HistoryTtl): Boolean {
            fun span(t: HistoryTtl) = if (t == OFF) Long.MAX_VALUE else t.ms
            return span(b) > span(a)
        }

        /** Bellekteki geçmişi budar (oturumlar ayarlarda: [SessionLog.prune]). Kapalıysa yalnızca rapor süresi varsayılana döner. */
        fun pruneAll(nowMs: Long, ttl: HistoryTtl) {
            PrivacyReport.setKeepDays(ttl.reportDays)
            if (ttl == OFF) return
            val cut = nowMs - ttl.ms
            Journal.log.prune(cut)
            FilterLive.prune(cut)
        }
    }
}
