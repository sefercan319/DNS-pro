package app.dnshizli.core

/** Bir uygulamanın rapor satırı: engellenen istek sayısı, kaç farklı izleyici/reklam alanı ve en çok engellenenler. */
class PrivacyRow(val pkg: String, val blocked: Int, val distinct: Int, val top: List<Pair<String, Int>>, val perDay: IntArray)

/**
 * Gizlilik raporu: hangi uygulama son [DAYS] günde kaç izleyici/reklam alanına bağlanmaya çalıştı ve kaçı engellendi.
 *
 * [AppAds] oturumluk istatistik tutar; bu rapor gün kovalarıyla kalıcıdır (uygulama kapanıp açılınca ve telefon yeniden
 * başlayınca da sürer). Gün, yerel saatle hesaplanır ([zoneOffset]). Eski günler kendiliğinden düşer.
 *
 * Sınırlar: gün başına en çok [MAX_PKGS] uygulama, uygulama başına en çok [MAX_NAMES] ad (sayaç yine de artar). "Geçmişi tut"
 * kapalıysa ([FilterLive.keepNames]) adlar hiç tutulmaz, yalnızca sayılar. Veri yalnızca uygulamanın kendi klasöründe durur;
 * yedeğe, buluta ya da başka bir yere gitmez.
 *
 * Kalıcılık: platform [saver] verir. Kayıt en çok [SAVE_EVERY_MS]'de bir istenir (her istekte disk yazılmaz); [flush] hemen yazar.
 */
object PrivacyReport {
    const val DAYS = 7
    const val MAX_PKGS = 150
    const val MAX_NAMES = 30
    const val SAVE_EVERY_MS = 60_000L
    private const val DAY_MS = 86_400_000L
    private const val MAX_TEXT = 400_000

    @Volatile var clock: () -> Long = { System.currentTimeMillis() }
    /** Yerel saat farkı (ms); gün sınırı yerel gece yarısıdır. */
    @Volatile var zoneOffset: (Long) -> Int = { java.util.TimeZone.getDefault().getOffset(it) }
    /** Platform: kodlanmış raporu diske yazar (arka planda). Null: kalıcı değil (testler, eski sürüm). */
    @Volatile var saver: ((String) -> Unit)? = null
    /** Diske yazma aralığı çarpanı (uyum motoru: pil tasarrufu, ısınma ve yükte kayıt seyrekleşir; [flush] yine hemen yazar). */
    @Volatile var saveScale = 1

    private class Stat { var blocked = 0; val names = HashMap<String, Int>() }

    private val lock = Any()
    /** gün numarası → paket → istatistik. */
    private val days = java.util.TreeMap<Long, HashMap<String, Stat>>()
    private var dirty = false
    private var lastSave = 0L

    fun dayOf(ms: Long): Long = Math.floorDiv(ms + zoneOffset(ms), DAY_MS)

    /** Rapora girebilecek ad: küçük harf ASCII alan adı (kodlamada ayırıcılarla karışmaz). */
    internal fun validName(n: String): Boolean {
        if (n.isEmpty() || n.length > 253 || n[0] == '.') return false
        for (c in n) if (!(c in 'a'..'z' || c in '0'..'9' || c == '.' || c == '-' || c == '_')) return false
        return true
    }

    /** Kaç gün tutulur ("geçmişi otomatik sil": 7, 1 ya da 0 = hiç tutulmaz). */
    @Volatile var keepDays = DAYS
        private set

    /** Saklama süresini değiştirir; kısalırsa eski günler hemen silinip diske yazılır. */
    fun setKeepDays(n: Int) {
        val v = n.coerceIn(0, DAYS)
        if (v == keepDays) return
        keepDays = v
        val s = synchronized(lock) { prune(dayOf(clock())); dirty = false; lastSave = clock(); encodeLocked() }
        try { saver?.invoke(s) } catch (_: Exception) {}
    }

    /** Engellenen bir istek (sahibi [pkg]). Ad geçersizse ya da adlar tutulmuyorsa yalnızca sayaç artar. */
    fun record(pkg: String, rawName: String?) {
        if (keepDays == 0 || !AppScopes.validPkg(pkg)) return
        val now = clock()
        val name = rawName?.lowercase()?.trimEnd('.')?.takeIf { FilterLive.keepNames && validName(it) }
        var save: String? = null
        synchronized(lock) {
            val d = dayOf(now)
            prune(d)
            val m = days.getOrPut(d) { HashMap() }
            var s = m[pkg]
            if (s == null) {
                if (m.size >= MAX_PKGS) {
                    val worst = m.entries.minByOrNull { it.value.blocked }
                    if (worst != null) m.remove(worst.key)
                }
                s = Stat(); m[pkg] = s
            }
            s.blocked++
            if (name != null && (s.names.size < MAX_NAMES || s.names.containsKey(name))) s.names[name] = (s.names[name] ?: 0) + 1
            dirty = true
            if (saver != null && (now - lastSave >= SAVE_EVERY_MS * saveScale.coerceIn(1, 4) || now < lastSave)) { lastSave = now; dirty = false; save = encodeLocked() }
        }
        save?.let { s -> try { saver?.invoke(s) } catch (_: Exception) {} }
    }

    /** Bekleyen değişikliği hemen yazar (servis kapanırken). */
    fun flush() {
        val s = synchronized(lock) { if (!dirty) return; dirty = false; lastSave = clock(); encodeLocked() }
        try { saver?.invoke(s) } catch (_: Exception) {}
    }

    private fun prune(today: Long) {
        val it = days.keys.iterator()
        while (it.hasNext()) { val d = it.next(); if (d <= today - keepDays || d > today + 1) it.remove() }
    }

    /** Son [nDays] gün (bugün dahil), en çok engellenenden başlayarak. */
    fun report(nDays: Int = DAYS): List<PrivacyRow> = synchronized(lock) {
        val today = dayOf(clock())
        prune(today)
        val n = nDays.coerceIn(1, DAYS)
        if (keepDays == 0) return@synchronized emptyList()
        val from = today - n + 1
        val blocked = HashMap<String, Int>()
        val names = HashMap<String, HashMap<String, Int>>()
        val perDay = HashMap<String, IntArray>()
        for ((d, m) in days.subMap(from, true, today, true)) {
            for ((pkg, s) in m) {
                blocked[pkg] = (blocked[pkg] ?: 0) + s.blocked
                perDay.getOrPut(pkg) { IntArray(n) }[(d - from).toInt()] += s.blocked
                val nm = names.getOrPut(pkg) { HashMap() }
                for ((k, v) in s.names) nm[k] = (nm[k] ?: 0) + v
            }
        }
        blocked.entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key }).map { e ->
            val nm = names[e.key] ?: HashMap()
            PrivacyRow(e.key, e.value, nm.size, nm.entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key }).map { it.key to it.value }, perDay[e.key]!!)
        }
    }

    fun total(nDays: Int = DAYS): Int = report(nDays).sumOf { it.blocked }

    fun isEmpty(): Boolean = synchronized(lock) { prune(dayOf(clock())); days.values.all { it.isEmpty() } }

    /** Tümünü siler ve boş halini yazar. */
    fun clear() {
        synchronized(lock) { days.clear(); dirty = false; lastSave = clock() }
        try { saver?.invoke("") } catch (_: Exception) {}
    }

    /** "Geçmişi tut" kapatıldı: adlar silinir, sayılar kalır. */
    fun dropNames() {
        val s = synchronized(lock) {
            var any = false
            for (m in days.values) for (st in m.values) if (st.names.isNotEmpty()) { st.names.clear(); any = true }
            if (!any) return
            dirty = false; lastSave = clock(); encodeLocked()
        }
        try { saver?.invoke(s) } catch (_: Exception) {}
    }

    /** Testler için: bellek ve ayarlar sıfırlanır (disk dokunulmaz). */
    fun reset() {
        keepDays = DAYS
        synchronized(lock) { days.clear(); dirty = false; lastSave = 0L }
        clock = { System.currentTimeMillis() }
        zoneOffset = { java.util.TimeZone.getDefault().getOffset(it) }
        saver = null
        saveScale = 1
    }

    // ---------------------------------------------------------------- kalıcılık

    /** Biçim: "v1" satırı; her gün "D<gün>"; her uygulama "<pkg>\t<sayı>\t<ad>:<sayı>,…". */
    fun encode(): String = synchronized(lock) { encodeLocked() }

    private fun encodeLocked(): String {
        prune(dayOf(clock()))
        if (days.values.all { it.isEmpty() }) return ""
        val sb = StringBuilder("v1\n")
        for ((d, m) in days) {
            if (m.isEmpty()) continue
            sb.append('D').append(d).append('\n')
            for ((pkg, s) in m.entries.sortedBy { it.key }) {
                sb.append(pkg).append('\t').append(s.blocked).append('\t')
                var first = true
                for ((k, v) in s.names.entries.sortedBy { it.key }) { if (!first) sb.append(','); first = false; sb.append(k).append(':').append(v) }
                sb.append('\n')
            }
        }
        return sb.toString()
    }

    /** Kayıtlı raporu yükler ve bellektekiyle birleştirir (yükleme sürerken gelen istekler kaybolmaz). Bozuk satırlar atlanır; eski günler düşer. */
    fun load(text: String?) {
        val out = java.util.TreeMap<Long, HashMap<String, Stat>>()
        if (text != null && text.length <= MAX_TEXT && text.startsWith("v1\n")) {
            var cur: HashMap<String, Stat>? = null
            for (line in text.split('\n').drop(1)) {
                if (line.isEmpty()) continue
                if (line[0] == 'D') { cur = line.substring(1).toLongOrNull()?.let { out.getOrPut(it) { HashMap() } }; continue }
                val m = cur ?: continue
                val p = line.split('\t')
                if (p.size != 3 || m.size >= MAX_PKGS || !AppScopes.validPkg(p[0])) continue
                val n = p[1].toIntOrNull()?.takeIf { it > 0 } ?: continue
                val s = Stat(); s.blocked = n
                if (p[2].isNotEmpty() && FilterLive.keepNames) for (kv in p[2].split(',')) {
                    if (s.names.size >= MAX_NAMES) break
                    val i = kv.lastIndexOf(':')
                    if (i <= 0) continue
                    val k = kv.substring(0, i); val v = kv.substring(i + 1).toIntOrNull() ?: continue
                    if (v > 0 && validName(k)) s.names[k] = v
                }
                m[p[0]] = s
            }
        }
        synchronized(lock) {
            for ((d, m) in out) {
                val cur = days.getOrPut(d) { HashMap() }
                for ((pkg, s) in m) {
                    val c = cur[pkg]
                    if (c == null) { if (cur.size < MAX_PKGS) cur[pkg] = s; continue }
                    c.blocked += s.blocked
                    for ((k, v) in s.names) if (c.names.size < MAX_NAMES || c.names.containsKey(k)) c.names[k] = (c.names[k] ?: 0) + v
                }
            }
            prune(dayOf(clock()))
        }
    }
}
