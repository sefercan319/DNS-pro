package app.dnshizli.core

/** Özelliğin ait olduğu alan. */
enum class Domain { DNS, CRYPTO, FILTER, GATEWAY, DPI, PRIVACY, RESILIENCE, NOTIFY, UI, SOUND, SYSTEM }

/**
 * Önem katmanı. Motor yalnızca [OPTIONAL] ve [COSMETIC] katmanındaki, çalışan bir denetimi ([Knob]) olan özellikleri kısabilir.
 * [CORE] (bağlantının kendisi) ve [PROTECT] (koruma: süzgeç, şifreleme, güvenlik duvarı, sızıntı kalkanları) asla kısılmaz.
 */
enum class Tier { CORE, PROTECT, OPTIONAL, COSMETIC }

/** Kaynak boyutları: işlemci, bellek, pil, mobil veri, telefonu uyandırma, gecikmeye etkisi. */
enum class Res { CPU, MEM, BATTERY, DATA, WAKE, LATENCY }

/** Bir özelliğin tahmini sürekli maliyeti (her boyutta 0–5). Mutlak değil, özellikler arası göreli büyüklüktür. */
class Cost(val cpu: Int = 0, val mem: Int = 0, val battery: Int = 0, val data: Int = 0, val wake: Int = 0, val latency: Int = 0) {
    operator fun get(r: Res): Int = when (r) {
        Res.CPU -> cpu; Res.MEM -> mem; Res.BATTERY -> battery; Res.DATA -> data; Res.WAKE -> wake; Res.LATENCY -> latency
    }
    val total: Int get() = cpu + mem + battery + data + wake + latency

    companion object { val ZERO = Cost() }
}

/**
 * Özellik grafiğinin düğümü.
 * [on]: kullanıcının ayarına göre açık mı. [needs]: hepsi ETKİN olmalı. [needsAny]: en az biri etkin olmalı.
 * [knob]: motorun çalışırken kısabileceği denetim (yalnızca OPTIONAL/COSMETIC). [value]: kısma sırasında korunma önceliği (1–10).
 */
class Feature(
    val id: String,
    val domain: Domain,
    val tier: Tier,
    val value: Int,
    val cost: Cost,
    val needs: List<String> = emptyList(),
    val needsAny: List<String> = emptyList(),
    val knob: Knob? = null,
    val on: (AppSettings) -> Boolean,
) {
    val sheddable: Boolean get() = knob != null && (tier == Tier.OPTIONAL || tier == Tier.COSMETIC)
}

/** İlişki türleri. */
enum class RelKind {
    /** [Relation.a] etkinken [Relation.b] boşa çalışır: b kısılır (knob'u varsa) ya da "gereksiz" sayılır. */
    SUPERSEDES,
    /** İkisi birlikte birbirinin işini zayıflatır; kullanıcının seçimi korunur, günlüğe bildirilir. */
    TENSION,
    /** Birlikte daha iyi çalışırlar (bilgi; çözümde öncelik verir). */
    SYNERGY,
}

class Relation(val a: String, val b: String, val kind: RelKind, val why: String)

/**
 * Uygulamadaki tüm özelliklerin grafiği: ayarlardaki her davranış bir düğümdür (veri alanları — favoriler, son kullanılanlar,
 * sayaçlar — özellik değildir). Ek olarak ayarı olmayan ama çalışan işler (ağ geçidi, yedek bağlantı, hop ölçümü, JA3 gözlemi,
 * arayüz efektleri) sanal düğüm olarak yer alır. Motor bu grafik üzerinden çözümler: neyin gerçekten etkin olduğunu, neyin
 * bağımlılığı eksik olduğu için uyuduğunu, neyin başka bir özellik yüzünden boşa çalıştığını ve hangi kaynağa ne kadar yük bindiğini.
 */
object FeatureGraph {
    private fun f(
        id: String, d: Domain, t: Tier, value: Int, cost: Cost = Cost.ZERO,
        needs: List<String> = emptyList(), any: List<String> = emptyList(), knob: Knob? = null, on: (AppSettings) -> Boolean,
    ) = Feature(id, d, t, value, cost, needs, any, knob, on)

    private val GW = listOf("dpiOn", "adsPlus", "appFw")

    val all: List<Feature> = listOf(
        // ---------------------------------------------------------------- DNS
        f("dnsOn", Domain.DNS, Tier.CORE, 10, Cost(cpu = 1, mem = 1, battery = 1, wake = 1)) { it.dnsOn },
        f("cache", Domain.DNS, Tier.CORE, 9, Cost(mem = 1)) { it.cache != CacheLevel.OFF },
        f("cacheLarge", Domain.DNS, Tier.CORE, 6, Cost(mem = 2), needs = listOf("cache")) { it.cache == CacheLevel.LARGE },
        f("ipv6", Domain.DNS, Tier.CORE, 7) { it.ipMode == IpMode.BOTH },
        f("dnsRace", Domain.DNS, Tier.OPTIONAL, 4, Cost(cpu = 1, battery = 1, data = 2, wake = 1), needs = listOf("dnsOn"), knob = Knob.DNS_RACE) { it.dnsRace },
        f("splitDns", Domain.DNS, Tier.PROTECT, 7, Cost(cpu = 1, mem = 1, battery = 1, data = 1), needs = listOf("dnsOn")) { it.splitDns },
        f("backupServer", Domain.RESILIENCE, Tier.CORE, 6, needs = listOf("dnsOn")) { it.backupServer != null },
        f("networkRules", Domain.DNS, Tier.CORE, 5, needs = listOf("dnsOn")) { it.wifiServer != null || it.mobileServer != null },
        f("dns.prefetch", Domain.DNS, Tier.OPTIONAL, 5, Cost(battery = 1, data = 1, wake = 1), needs = listOf("dnsOn", "cache"), knob = Knob.PREFETCH) { true },
        f("autoFastest", Domain.DNS, Tier.CORE, 4, Cost(data = 1)) { it.autoFastest },
        f("refreshOnNetwork", Domain.DNS, Tier.CORE, 4, Cost(data = 1, wake = 1)) { it.refreshOnNetwork },
        f("autoMeasure", Domain.DNS, Tier.CORE, 3, Cost(data = 1)) { it.autoMeasure },
        f("measureEncrypted", Domain.DNS, Tier.CORE, 3, Cost(data = 1), needs = listOf("autoMeasure")) { it.measureEncrypted },
        f("customServers", Domain.DNS, Tier.CORE, 5) { it.custom.isNotBlank() },
        // ---------------------------------------------------------------- şifreleme
        f("encrypt", Domain.CRYPTO, Tier.PROTECT, 9, Cost(cpu = 1, latency = 1), needs = listOf("dnsOn")) { it.encryption != Encryption.OFF },
        f("strictEncryption", Domain.CRYPTO, Tier.PROTECT, 8, needs = listOf("encrypt")) { it.strictEncryption },
        f("quicDns", Domain.CRYPTO, Tier.PROTECT, 5, needs = listOf("encrypt")) { it.quicDns },
        f("odoh", Domain.CRYPTO, Tier.PROTECT, 8, Cost(cpu = 1, latency = 2), needs = listOf("dnsOn")) { it.odoh != OdohMode.OFF },
        f("echAllow", Domain.CRYPTO, Tier.PROTECT, 5) { it.echAllow },
        // ---------------------------------------------------------------- süzgeç
        f("filter", Domain.FILTER, Tier.PROTECT, 9, Cost(cpu = 1, mem = 2), any = listOf("dnsOn", "adsPlus")) { it.filterLevel != FilterLevel.OFF },
        f("filterStrict", Domain.FILTER, Tier.PROTECT, 7, Cost(mem = 1), needs = listOf("filter")) { it.filterLevel == FilterLevel.STRICT },
        f("filterLight", Domain.FILTER, Tier.PROTECT, 5, needs = listOf("filter")) { it.filterMem == FilterMem.LIGHT },
        f("filterAllow", Domain.FILTER, Tier.CORE, 6, any = listOf("filter", "adsPlus")) { it.filterAllow.isNotEmpty() },
        f("filterBlock", Domain.FILTER, Tier.PROTECT, 6, any = listOf("dnsOn", "adsPlus")) { it.filterBlock.isNotEmpty() },
        f("rebindGuard", Domain.FILTER, Tier.PROTECT, 7, needs = listOf("dnsOn")) { it.rebindGuard },
        f("dohGuard", Domain.FILTER, Tier.PROTECT, 8, needs = listOf("dnsOn")) { it.dohGuard },
        f("oemBlock", Domain.FILTER, Tier.PROTECT, 6, any = listOf("dnsOn", "adsPlus")) { it.oemBlock },
        f("appAds", Domain.FILTER, Tier.PROTECT, 6, Cost(cpu = 1), any = listOf("filter", "adsPlus")) { it.appAds.isNotBlank() },
        f("keepHistory", Domain.FILTER, Tier.CORE, 4, Cost(mem = 1)) { it.keepHistory },
        f("youtubeAds", Domain.FILTER, Tier.PROTECT, 5, Cost(cpu = 1), any = listOf("adsPlus", "mitmOn")) { it.youtubeAds },
        // ---------------------------------------------------------------- ağ geçidi
        f("adsPlus", Domain.GATEWAY, Tier.PROTECT, 8, Cost(cpu = 2, mem = 2, battery = 2, latency = 1)) { it.adsPlus },
        f("appFw", Domain.PRIVACY, Tier.PROTECT, 8, Cost(cpu = 1, battery = 1)) { AppFirewall.needsGateway(it.appFw) },
        f("gateway", Domain.GATEWAY, Tier.CORE, 8, Cost(cpu = 2, mem = 2, battery = 2, wake = 1, latency = 1), any = GW) { true },
        f("gw.hedge", Domain.GATEWAY, Tier.OPTIONAL, 6, Cost(cpu = 1, battery = 1, data = 1), needs = listOf("gateway"), knob = Knob.HEDGE) { true },
        f("gw.ja3", Domain.GATEWAY, Tier.OPTIONAL, 2, Cost(cpu = 1, mem = 1), needs = listOf("gateway"), knob = Knob.JA3) { true },
        f("blockQuic", Domain.GATEWAY, Tier.PROTECT, 6, any = listOf("dpiOn", "adsPlus")) { it.blockQuic },
        f("autoShield", Domain.RESILIENCE, Tier.PROTECT, 7, Cost(cpu = 1), needs = listOf("gateway")) { it.autoShield },
        f("mitmOn", Domain.GATEWAY, Tier.PROTECT, 6, Cost(cpu = 3, mem = 2, battery = 2, latency = 1), needs = listOf("gateway")) { it.mitmOn },
        f("fpGuard", Domain.PRIVACY, Tier.PROTECT, 6, needs = listOf("mitmOn")) { it.fpGuard },
        // ---------------------------------------------------------------- DPI
        f("dpiOn", Domain.DPI, Tier.PROTECT, 9, Cost(cpu = 2, battery = 1, latency = 1)) { it.dpiOn },
        f("autoDpi", Domain.DPI, Tier.PROTECT, 6, needs = listOf("autoShield")) { it.autoDpi },
        f("dpiListedOnly", Domain.DPI, Tier.PROTECT, 5, needs = listOf("dpiOn")) { it.dpiListedOnly },
        f("udpDecoy", Domain.DPI, Tier.OPTIONAL, 3, Cost(cpu = 1, battery = 1, data = 1, wake = 1), needs = listOf("dpiOn"), knob = Knob.UDP_DECOY) { it.udpDecoy },
        f("quicSplit", Domain.DPI, Tier.OPTIONAL, 5, Cost(cpu = 1, data = 1), needs = listOf("dpiOn"), knob = Knob.QUIC_SPLIT) { it.quicSplit },
        f("dpi.autoTtl", Domain.DPI, Tier.OPTIONAL, 5, Cost(cpu = 1, battery = 1, data = 1, wake = 1, latency = 1), needs = listOf("dpiOn"), knob = Knob.AUTO_TTL) { true },
        // ---------------------------------------------------------------- gizlilik ve güvenlik
        f("historyTtl", Domain.PRIVACY, Tier.PROTECT, 6) { it.historyTtl != HistoryTtl.OFF },
        f("privacyReport", Domain.PRIVACY, Tier.CORE, 5, Cost(mem = 1)) { it.historyTtl != HistoryTtl.HOUR },
        f("appLock", Domain.PRIVACY, Tier.PROTECT, 7) { it.appLock },
        f("secureScreen", Domain.PRIVACY, Tier.PROTECT, 6) { it.secureScreen || it.appLock },
        f("hideOnLockscreen", Domain.PRIVACY, Tier.PROTECT, 5) { it.hideOnLockscreen },
        f("appScope", Domain.PRIVACY, Tier.CORE, 6) { it.appScope != AppScope.ALL },
        // ---------------------------------------------------------------- dayanıklılık
        f("failClosed", Domain.RESILIENCE, Tier.CORE, 8) { it.failClosed },
        f("autoReconnect", Domain.RESILIENCE, Tier.CORE, 8, Cost(wake = 1)) { it.autoReconnect },
        f("autoConnect", Domain.RESILIENCE, Tier.CORE, 6) { it.autoConnect },
        f("connectOnBoot", Domain.RESILIENCE, Tier.CORE, 6) { it.connectOnBoot },
        f("rememberModules", Domain.RESILIENCE, Tier.CORE, 5) { it.rememberModules },
        f("confirmDisconnect", Domain.RESILIENCE, Tier.CORE, 3) { it.confirmDisconnect },
        // ---------------------------------------------------------------- bildirimler
        f("notifyDrop", Domain.NOTIFY, Tier.CORE, 5, any = listOf("dnsOn", "gateway")) { it.notifyDrop },
        f("notifyConnect", Domain.NOTIFY, Tier.COSMETIC, 2, any = listOf("dnsOn", "gateway")) { it.notifyConnect },
        f("notifyStop", Domain.NOTIFY, Tier.COSMETIC, 2, any = listOf("dnsOn", "gateway")) { it.notifyStop },
        f("notifyTimeout", Domain.NOTIFY, Tier.CORE, 4, needs = listOf("dnsOn")) { it.notifyTimeout },
        f("quietNotification", Domain.NOTIFY, Tier.COSMETIC, 3) { it.quietNotification },
        // ---------------------------------------------------------------- arayüz
        f("lowPower", Domain.UI, Tier.CORE, 6) { it.lowPower },
        f("deviceAuto", Domain.SYSTEM, Tier.CORE, 6) { it.deviceAuto },
        // Hareket iki kademe: "ui.motion" (herhangi bir hareket) ve onun üstündeki "ui.visuals" (tam efektler). Önce tam efektler kısılır (değeri daha düşük),
        // kaynak hâlâ yetmezse hareket tamamen durur. Ayar okunur, etkin değer değil: motorun kendi kısması geri beslenip salınım yapmasın.
        f("ui.motion", Domain.UI, Tier.COSMETIC, 3, Cost(cpu = 1, battery = 1), needs = listOf("deviceAuto"), knob = Knob.MOTION) { !it.lowPower && it.motion != Motion.OFF },
        f("ui.visuals", Domain.UI, Tier.COSMETIC, 2, Cost(cpu = 2, battery = 2, mem = 1), needs = listOf("ui.motion"), knob = Knob.VISUALS) { !it.lowPower && it.motion == Motion.FULL && !(it.deviceAuto && DeviceTune.reduceMotion) },
        f("glass", Domain.UI, Tier.COSMETIC, 2, Cost(cpu = 1, battery = 1)) { it.glass > 0f },
        f("wallpaper", Domain.UI, Tier.COSMETIC, 3, Cost(mem = 2)) { it.wallpaper },
        f("wpBlur", Domain.UI, Tier.COSMETIC, 2, Cost(cpu = 1, mem = 1), needs = listOf("wallpaper")) { it.wpBlur != WpBlur.OFF },
        f("wpDim", Domain.UI, Tier.COSMETIC, 1, needs = listOf("wallpaper")) { it.wpDim > 0f },
        f("tapFx", Domain.UI, Tier.COSMETIC, 2, Cost(cpu = 1)) { it.tapFx },
        f("celebrate", Domain.UI, Tier.COSMETIC, 1, Cost(cpu = 1)) { it.celebrate },
        f("animFast", Domain.UI, Tier.COSMETIC, 1) { it.animSpeed > 1f },
        f("haptics", Domain.UI, Tier.COSMETIC, 3, Cost(battery = 1)) { it.haptics },
        f("hapticStrong", Domain.UI, Tier.COSMETIC, 1, Cost(battery = 1), needs = listOf("haptics")) { it.hapticLevel == HapticLevel.STRONG },
        f("highContrast", Domain.UI, Tier.CORE, 8) { it.highContrast },
        f("textScale", Domain.UI, Tier.CORE, 8) { it.textScale != TextScale.NORMAL },
        f("minimal", Domain.UI, Tier.COSMETIC, 4) { it.minimal },
        f("compact", Domain.UI, Tier.COSMETIC, 3) { it.compact },
        f("themeSchedule", Domain.UI, Tier.COSMETIC, 2) { it.themeSchedule },
        f("customTheme", Domain.UI, Tier.COSMETIC, 2) { it.customTheme.isNotBlank() },
        f("liquidColor", Domain.UI, Tier.COSMETIC, 1) { it.liquidColor.isNotBlank() },
        f("orbShapes", Domain.UI, Tier.COSMETIC, 1) { it.orbShapes.isNotBlank() },
        f("orbFlow", Domain.UI, Tier.COSMETIC, 1) { it.orbFlow != OrbFlow.CALM },
        f("fxVariants", Domain.UI, Tier.COSMETIC, 1) { it.fxVariants.isNotBlank() },
        f("showAdvanced", Domain.UI, Tier.CORE, 3) { it.showAdvanced },
        // ---------------------------------------------------------------- ses
        f("soundOn", Domain.SOUND, Tier.COSMETIC, 3, Cost(cpu = 1, battery = 1)) { it.soundOn },
        f("soundUi", Domain.SOUND, Tier.COSMETIC, 2, Cost(battery = 1), needs = listOf("soundOn")) { it.soundUi },
        f("soundConn", Domain.SOUND, Tier.COSMETIC, 3, needs = listOf("soundOn")) { it.soundConn },
        f("quietHours", Domain.SOUND, Tier.COSMETIC, 3, needs = listOf("soundOn")) { it.quietHours },
        f("soundSilent", Domain.SOUND, Tier.COSMETIC, 1, needs = listOf("soundOn")) { it.soundVolume <= 0f },
    )

    val byId: Map<String, Feature> = all.associateBy { it.id }

    val relations: List<Relation> = listOf(
        Relation("blockQuic", "quicSplit", RelKind.SUPERSEDES, "QUIC zaten düşürülüyor: QUIC bölme boşa çalışır"),
        Relation("adsPlus", "quicSplit", RelKind.SUPERSEDES, "Reklam+ QUIC'i düşürüyor: QUIC bölme boşa çalışır"),
        Relation("odoh", "splitDns", RelKind.SUPERSEDES, "ODoH sorguları zaten sunucudan gizler: bölme kullanılmaz"),
        Relation("lowPower", "ui.visuals", RelKind.SUPERSEDES, "düşük güç modu efektleri kapatır"),
        Relation("lowPower", "tapFx", RelKind.SUPERSEDES, "düşük güç modu dokunma efektini kapatır"),
        Relation("lowPower", "celebrate", RelKind.SUPERSEDES, "düşük güç modu kutlamayı kapatır"),
        Relation("minimal", "celebrate", RelKind.SUPERSEDES, "sade görünümde kutlama gösterilmez"),
        Relation("soundSilent", "soundUi", RelKind.SUPERSEDES, "ses düzeyi sıfır: arayüz sesleri boşa çalar"),
        Relation("soundSilent", "soundConn", RelKind.SUPERSEDES, "ses düzeyi sıfır: bağlantı sesleri boşa çalar"),
        Relation("echAllow", "adsPlus", RelKind.TENSION, "ECH site adını gizler: Reklam+ o bağlantıları ad ile süzemez"),
        Relation("dpiListedOnly", "udpDecoy", RelKind.TENSION, "DPI yalnızca listedeki sitelerde: sahte UDP de yalnızca orada etkili"),
        Relation("splitDns", "dnsRace", RelKind.TENSION, "bölme açıkken yarış her sağlayıcının kendi yedeğiyle sınırlı"),
        Relation("failClosed", "autoReconnect", RelKind.SYNERGY, "kapalı kalırsa dur + otomatik yeniden bağlan: kesintide hem sızıntı yok hem dönüş var"),
        Relation("dohGuard", "filter", RelKind.SYNERGY, "DoH kalkanı tarayıcıların süzgeci atlatmasını önler"),
        Relation("adsPlus", "filter", RelKind.SYNERGY, "Reklam+ DNS süzgecinin kaçırdığı IP ile bağlantıları da yakalar"),
        Relation("appLock", "secureScreen", RelKind.SYNERGY, "kilitliyken son uygulamalar önizlemesi de gizli"),
    )

    /** Yapısal denetim: bilinmeyen kimlik, döngülü bağımlılık, kısılabilir olmayan katmanda denetim, yinelenen kimlik. Boşsa sağlam. */
    fun validate(): List<String> {
        val out = ArrayList<String>()
        if (byId.size != all.size) out += "yinelenen kimlik"
        for (x in all) {
            for (n in x.needs + x.needsAny) if (n !in byId) out += "${x.id}: bilinmeyen bağımlılık $n"
            if (x.knob != null && !x.sheddable) out += "${x.id}: denetimi var ama katmanı ${x.tier}"
            if (x.value !in 1..10) out += "${x.id}: değer aralık dışı"
            for (r in Res.values()) if (x.cost[r] !in 0..5) out += "${x.id}: maliyet aralık dışı"
        }
        for (r in relations) { if (r.a !in byId) out += "ilişki: bilinmeyen ${r.a}"; if (r.b !in byId) out += "ilişki: bilinmeyen ${r.b}" }
        val knobs = all.mapNotNull { it.knob }
        if (knobs.size != knobs.toSet().size) out += "bir denetim birden çok özellikte"
        if (order().size != all.size) out += "bağımlılıkta döngü"
        return out
    }

    /** Bağımlılık sırası (önce bağımlı olunanlar). Döngü varsa döngüdekiler listede yer almaz ([validate] yakalar). */
    fun order(): List<Feature> {
        val deg = HashMap<String, Int>()
        val users = HashMap<String, MutableList<String>>()
        for (x in all) {
            val deps = (x.needs + x.needsAny).toSet()
            deg[x.id] = deps.size
            for (d in deps) users.getOrPut(d) { ArrayList() } += x.id
        }
        val q = ArrayDeque(all.filter { deg[it.id] == 0 }.map { it.id })
        val out = ArrayList<Feature>()
        while (q.isNotEmpty()) {
            val id = q.removeFirst()
            out += byId.getValue(id)
            for (u in users[id].orEmpty()) { val n = deg.getValue(u) - 1; deg[u] = n; if (n == 0) q.addLast(u) }
        }
        return out
    }
}
