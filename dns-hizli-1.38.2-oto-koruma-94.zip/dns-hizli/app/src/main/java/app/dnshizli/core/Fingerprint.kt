package app.dnshizli.core

/**
 * Tarayıcı parmak izi koruması (tarayıcı kipi, [MitmProxy]): istek başlıklarındaki cihazı ayırt eden bilgiler nötrleştirilir.
 *  - User-Agent: telefon modeli, Android sürümü ve derleme kimliği ile tarayıcının ayrıntılı sürümü silinir; Chrome'un kendi
 *    "azaltılmış UA" biçimine çevrilir: `(Linux; Android 10; K)` ve `Chrome/130.0.0.0`. Tarayıcı ailesi ve ana sürüm kalır
 *    (siteler mobil/masaüstü ve uyumluluk kararını bozmadan verir).
 *  - Yüksek entropili istemci ipuçları (Sec-CH-UA-Model, -Platform-Version, -Full-Version(-List), -Arch, -Bitness, -WoW64) ve
 *    cihaz ipuçları (Device-Memory, DPR, Viewport-Width, Width, ECT, RTT, Downlink) ile erişilebilirlik tercihleri (azaltılmış
 *    hareket/saydamlık, kontrast, zorunlu renkler) çıkarılır; Sec-CH-UA-Model boş gönderilir.
 *  - X-Requested-With (WebView'daki uygulama paket adı) çıkarılır.
 *  - Cevaptaki Accept-CH / Critical-CH başlıkları silinir: tarayıcı o siteye yüksek entropili ipuçlarını göndermeye hiç başlamaz.
 * Düşük entropili ipuçları (Sec-CH-UA marka listesi, -Mobile, -Platform) dokunulmaz: zaten herkeste aynıdır, silmek ayırt edici olurdu.
 */
object Fingerprint {
    /** Silinen istek başlıkları (küçük harf). */
    val DROP_REQ = setOf(
        "sec-ch-ua-platform-version", "sec-ch-ua-full-version", "sec-ch-ua-full-version-list", "sec-ch-ua-arch", "sec-ch-ua-bitness",
        "sec-ch-ua-wow64", "sec-ch-ua-form-factors", "device-memory", "sec-ch-device-memory", "dpr", "sec-ch-dpr", "viewport-width",
        "sec-ch-viewport-width", "width", "sec-ch-width", "ect", "rtt", "downlink", "x-requested-with",
        // erişilebilirlik tercihleri: az kişide "açık" olduğundan çok ayırt edici; sayfa yine CSS ile uygular
        "sec-ch-prefers-reduced-motion", "sec-ch-prefers-reduced-transparency", "sec-ch-prefers-contrast", "sec-ch-forced-colors",
    )
    /** Silinen cevap başlıkları (küçük harf). */
    val DROP_RES = setOf("accept-ch", "critical-ch")

    private val ANDROID_PART = Regex("""\(Linux; (?:U; )?Android [^;)]*(?:;[^)]*)?\)""")
    private val CHROME_VER = Regex("""\b(Chrome|CriOS|HeadlessChrome)/(\d+)(?:\.\d+){1,3}""")
    private val OTHER_VER = Regex("""\b(SamsungBrowser|EdgA|OPR|Brave|YaBrowser|Firefox|Version)/(\d+)(?:\.\d+){1,3}""")
    private val BUILD_TAIL = Regex(""" Build/[^;)\s]+""")

    /** Nötr User-Agent. Android dışı ya da tanınmayan UA'da yalnızca ayrıntılı sürümler kısaltılır. */
    fun userAgent(ua: String): String {
        if (ua.length > 1024) return ua.take(1024)
        var s = ANDROID_PART.replace(ua, "(Linux; Android 10; K)")
        s = BUILD_TAIL.replace(s, "")
        s = CHROME_VER.replace(s) { m -> "${m.groupValues[1]}/${m.groupValues[2]}.0.0.0" }
        s = OTHER_VER.replace(s) { m -> "${m.groupValues[1]}/${m.groupValues[2]}.0" }
        return s
    }

    private fun name(line: String): String = line.substringBefore(':').trim().lowercase()

    /** İstek başlık satırları ("Ad: değer") nötrleştirilmiş olarak; sıra korunur. */
    fun request(lines: List<String>): List<String> {
        val out = ArrayList<String>(lines.size)
        for (l in lines) {
            val n = name(l)
            when {
                n in DROP_REQ -> {}
                n == "user-agent" -> out.add("User-Agent: " + userAgent(l.substringAfter(':').trim()))
                n == "sec-ch-ua-model" -> out.add("Sec-CH-UA-Model: \"\"")
                else -> out.add(l)
            }
        }
        return out
    }

    /** Cevap başlık satırlarından ipucu istekleri silinmiş olarak. */
    fun response(lines: List<String>): List<String> = lines.filter { name(it) !in DROP_RES }
}
