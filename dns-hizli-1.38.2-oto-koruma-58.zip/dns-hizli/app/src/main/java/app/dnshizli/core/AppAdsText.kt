package app.dnshizli.core

/** Uygulama bazlı reklam engelleme sayfasının 12 dildeki metinleri. Sıra: TR, EN, DE, ES, FR, PT, RU, IT, ID, VI, PL, UK. */
object AppAdsText {
    val M: Map<String, Array<String>> = mapOf(
        "title" to arrayOf(
            "Uygulama bazlı reklam engelleme", "Per-app ad blocking", "App-bezogene Werbeblockierung", "Bloqueo de anuncios por app",
            "Blocage des pubs par appli", "Bloqueio de anúncios por app", "Блокировка рекламы по приложениям", "Blocco pubblicità per app",
            "Pemblokiran iklan per aplikasi", "Chặn quảng cáo theo ứng dụng", "Blokowanie reklam według aplikacji", "Блокування реклами за застосунками"),
        "empty" to arrayOf(
            "Henüz engellenen istek yok. Bağlıyken ve reklam engelleme açıkken hangi uygulamanın kaç reklam isteği gönderdiği burada görünür.",
            "No blocked requests yet. While connected with ad blocking on, you will see here which app sent how many ad requests.",
            "Noch keine blockierten Anfragen. Bei aktiver Verbindung und Werbeblockierung sehen Sie hier, welche App wie viele Werbeanfragen gesendet hat.",
            "Aún no hay solicitudes bloqueadas. Con la conexión y el bloqueo de anuncios activos, aquí verás qué app envió cuántas solicitudes de anuncios.",
            "Aucune requête bloquée pour l'instant. Une fois connecté avec le blocage des pubs actif, vous verrez ici quelle appli a envoyé combien de requêtes publicitaires.",
            "Nenhuma solicitação bloqueada ainda. Conectado e com o bloqueio de anúncios ativo, você verá aqui qual app enviou quantas solicitações de anúncios.",
            "Заблокированных запросов пока нет. При включённом подключении и блокировке рекламы здесь будет видно, какое приложение отправило сколько рекламных запросов.",
            "Nessuna richiesta bloccata finora. Con la connessione e il blocco pubblicità attivi vedrai qui quale app ha inviato quante richieste pubblicitarie.",
            "Belum ada permintaan yang diblokir. Saat terhubung dan pemblokiran iklan aktif, di sini terlihat aplikasi mana yang mengirim berapa permintaan iklan.",
            "Chưa có yêu cầu nào bị chặn. Khi đã kết nối và bật chặn quảng cáo, bạn sẽ thấy ở đây ứng dụng nào đã gửi bao nhiêu yêu cầu quảng cáo.",
            "Brak jeszcze zablokowanych żądań. Przy włączonym połączeniu i blokowaniu reklam zobaczysz tu, która aplikacja wysłała ile żądań reklamowych.",
            "Заблокованих запитів ще немає. Коли з'єднання та блокування реклами ввімкнено, тут видно, який застосунок надіслав скільки рекламних запитів."),
        "foot" to arrayOf(
            "Muaf: o uygulamada hiçbir şey engellenmez (ör. bankacılık). Sıkı: o uygulamada en sıkı liste uygulanır (reklamı bol oyunlar). Bir uygulama engel yüzünden bozulursa üstte \"Bozulmuş olabilir\" olarak görünür; dokununca tek adımda düzeltirsiniz.",
            "Exempt: nothing is blocked in that app (e.g. banking). Strict: the strictest list applies in that app (ad-heavy games). If an app breaks because of a block it shows up at the top as \"May be broken\"; tap it to fix it in one step.",
            "Ausgenommen: In dieser App wird nichts blockiert (z. B. Banking). Streng: In dieser App gilt die strengste Liste (werbelastige Spiele). Geht eine App wegen einer Sperre kaputt, erscheint sie oben als \"Möglicherweise defekt\"; tippen Sie darauf, um es in einem Schritt zu beheben.",
            "Excluida: en esa app no se bloquea nada (p. ej. banca). Estricto: en esa app se aplica la lista más estricta (juegos con muchos anuncios). Si una app falla por un bloqueo, aparece arriba como \"Puede estar averiada\"; tócala para arreglarlo en un paso.",
            "Exemptée : rien n'est bloqué dans cette appli (p. ex. banque). Strict : la liste la plus stricte s'applique à cette appli (jeux saturés de pubs). Si une appli est cassée par un blocage, elle apparaît en haut comme « Peut-être défaillante » ; touchez-la pour corriger en une étape.",
            "Isento: nada é bloqueado nesse app (ex.: banco). Rigoroso: a lista mais rigorosa vale nesse app (jogos cheios de anúncios). Se um app quebrar por causa de um bloqueio, ele aparece no topo como \"Pode estar com defeito\"; toque nele para corrigir em um passo.",
            "Исключение: в этом приложении ничего не блокируется (например, банк). Строгий: в приложении действует самый строгий список (игры с обилием рекламы). Если приложение сломалось из-за блокировки, оно появится вверху как «Возможно, не работает»; нажмите, чтобы исправить за один шаг.",
            "Esente: in quell'app non si blocca nulla (es. banca). Rigoroso: in quell'app vale la lista più severa (giochi pieni di pubblicità). Se un'app si rompe a causa di un blocco, compare in alto come \"Potrebbe essere guasta\"; toccala per sistemarla in un passo.",
            "Dikecualikan: tidak ada yang diblokir di aplikasi itu (mis. perbankan). Ketat: daftar paling ketat berlaku di aplikasi itu (game penuh iklan). Jika aplikasi rusak karena pemblokiran, ia muncul di atas sebagai \"Mungkin rusak\"; ketuk untuk memperbaikinya dalam satu langkah.",
            "Miễn trừ: không chặn gì trong ứng dụng đó (ví dụ ngân hàng). Nghiêm ngặt: áp dụng danh sách chặt nhất cho ứng dụng đó (game nhiều quảng cáo). Nếu ứng dụng hỏng do bị chặn, nó hiện ở đầu danh sách là \"Có thể bị hỏng\"; chạm để sửa trong một bước.",
            "Wyłączona: w tej aplikacji nic nie jest blokowane (np. bankowość). Ścisła: w tej aplikacji obowiązuje najostrzejsza lista (gry pełne reklam). Jeśli aplikacja psuje się przez blokadę, pojawia się na górze jako \"Może nie działać\"; dotknij, aby naprawić w jednym kroku.",
            "Виключена: у цьому застосунку нічого не блокується (наприклад, банк). Сувора: у застосунку діє найсуворіший список (ігри з великою кількістю реклами). Якщо застосунок зламався через блокування, він з'явиться вгорі як «Можливо, не працює»; торкніться, щоб виправити за один крок."),
        "foot29" to arrayOf(
            "Bu telefonda (Android 10'dan eski) uygulama bilgisi alınamıyor: istatistik boş kalır ve kipler uygulanamaz.",
            "On this phone (older than Android 10) the app of a connection cannot be determined: statistics stay empty and modes cannot be applied.",
            "Auf diesem Telefon (älter als Android 10) lässt sich die App einer Verbindung nicht ermitteln: Statistiken bleiben leer und Modi können nicht angewendet werden.",
            "En este teléfono (anterior a Android 10) no se puede saber la app de una conexión: las estadísticas quedan vacías y los modos no se aplican.",
            "Sur ce téléphone (antérieur à Android 10), l'appli d'une connexion est introuvable : les statistiques restent vides et les modes ne s'appliquent pas.",
            "Neste telefone (anterior ao Android 10) não é possível saber o app de uma conexão: as estatísticas ficam vazias e os modos não são aplicados.",
            "На этом телефоне (старше Android 10) приложение соединения определить нельзя: статистика пуста, режимы не применяются.",
            "Su questo telefono (precedente ad Android 10) non è possibile risalire all'app di una connessione: le statistiche restano vuote e le modalità non si applicano.",
            "Di ponsel ini (lebih lama dari Android 10) aplikasi pemilik koneksi tidak dapat diketahui: statistik tetap kosong dan mode tidak dapat diterapkan.",
            "Trên điện thoại này (cũ hơn Android 10) không xác định được ứng dụng của kết nối: thống kê để trống và các chế độ không áp dụng được.",
            "Na tym telefonie (starszym niż Android 10) nie można ustalić aplikacji połączenia: statystyki pozostają puste, a tryby nie działają.",
            "На цьому телефоні (старшому за Android 10) застосунок з'єднання визначити не можна: статистика порожня, режими не застосовуються."),
        "hTitle" to arrayOf("Durum özeti", "Status overview", "Statusübersicht", "Resumen de estado", "Aperçu de l'état", "Resumo do status", "Сводка состояния", "Riepilogo stato", "Ringkasan status", "Tổng quan trạng thái", "Przegląd stanu", "Огляд стану"),
        "hDns" to arrayOf("DNS", "DNS", "DNS", "DNS", "DNS", "DNS", "DNS", "DNS", "DNS", "DNS", "DNS", "DNS"),
        "hDpi" to arrayOf("DPI", "DPI", "DPI", "DPI", "DPI", "DPI", "DPI", "DPI", "DPI", "DPI", "DPI", "DPI"),
        "hAds" to arrayOf("Reklam engelleme", "Ad blocking", "Werbeblockierung", "Bloqueo de anuncios", "Blocage des pubs", "Bloqueio de anúncios", "Блокировка рекламы", "Blocco pubblicità", "Pemblokiran iklan", "Chặn quảng cáo", "Blokowanie reklam", "Блокування реклами"),
        "hNet" to arrayOf("Bağlantı ve güvenlik", "Connection and security", "Verbindung und Sicherheit", "Conexión y seguridad", "Connexion et sécurité", "Conexão e segurança", "Соединение и безопасность", "Connessione e sicurezza", "Koneksi dan keamanan", "Kết nối và bảo mật", "Połączenie i bezpieczeństwo", "З'єднання і безпека"),
        "hOk" to arrayOf("Çalışıyor", "Working", "Funktioniert", "Funcionando", "Fonctionne", "Funcionando", "Работает", "Funziona", "Berfungsi", "Đang hoạt động", "Działa", "Працює"),
        "hOff" to arrayOf("Kapalı", "Off", "Aus", "Desactivado", "Désactivé", "Desativado", "Выключено", "Disattivato", "Nonaktif", "Tắt", "Wyłączone", "Вимкнено"),
        "hNoVpn" to arrayOf("Bağlı değil", "Not connected", "Nicht verbunden", "No conectado", "Non connecté", "Não conectado", "Не подключено", "Non connesso", "Tidak terhubung", "Chưa kết nối", "Niepołączono", "Не підключено"),
        "pick" to arrayOf("Uygulama ekle…", "Add an app…", "App hinzufügen …", "Añadir una app…", "Ajouter une appli…", "Adicionar um app…", "Добавить приложение…", "Aggiungi un'app…", "Tambah aplikasi…", "Thêm ứng dụng…", "Dodaj aplikację…", "Додати застосунок…"),
        "pickTitle" to arrayOf("Uygulama seç", "Choose an app", "App wählen", "Elegir una app", "Choisir une appli", "Escolher um app", "Выберите приложение", "Scegli un'app", "Pilih aplikasi", "Chọn ứng dụng", "Wybierz aplikację", "Оберіть застосунок"),
        "normal" to arrayOf("Genel ayar", "Default", "Standard", "Predeterminado", "Par défaut", "Padrão", "По умолчанию", "Predefinito", "Bawaan", "Mặc định", "Domyślnie", "За замовчуванням"),
        "exempt" to arrayOf("Muaf (engelleme yok)", "Exempt (no blocking)", "Ausgenommen (keine Blockierung)", "Excluida (sin bloqueo)", "Exemptée (aucun blocage)", "Isento (sem bloqueio)", "Исключение (без блокировки)", "Esente (nessun blocco)", "Dikecualikan (tanpa blokir)", "Miễn trừ (không chặn)", "Wyłączona (bez blokowania)", "Виключена (без блокування)"),
        "strict" to arrayOf("Sıkı (en sıkı liste)", "Strict (strictest list)", "Streng (strengste Liste)", "Estricto (lista más estricta)", "Strict (liste la plus stricte)", "Rigoroso (lista mais rigorosa)", "Строгий (самый строгий список)", "Rigoroso (lista più severa)", "Ketat (daftar paling ketat)", "Nghiêm ngặt (danh sách chặt nhất)", "Ścisła (najostrzejsza lista)", "Суворий (найсуворіший список)"),
        "tagExempt" to arrayOf("muaf", "exempt", "ausgenommen", "excluida", "exemptée", "isento", "исключение", "esente", "dikecualikan", "miễn trừ", "wyłączona", "виключена"),
        "tagStrict" to arrayOf("sıkı", "strict", "streng", "estricto", "strict", "rigoroso", "строгий", "rigoroso", "ketat", "nghiêm ngặt", "ścisła", "суворий"),
        "suspect" to arrayOf("Bozulmuş olabilir", "May be broken", "Möglicherweise defekt", "Puede estar averiada", "Peut-être défaillante", "Pode estar com defeito", "Возможно, не работает", "Potrebbe essere guasta", "Mungkin rusak", "Có thể bị hỏng", "Może nie działać", "Можливо, не працює"),
        "rescueExempt" to arrayOf("Bu uygulamayı muaf tut", "Exempt this app", "Diese App ausnehmen", "Excluir esta app", "Exempter cette appli", "Isentar este app", "Исключить это приложение", "Escludi questa app", "Kecualikan aplikasi ini", "Miễn trừ ứng dụng này", "Wyłącz tę aplikację", "Виключити цей застосунок"),
        "rescueAllow" to arrayOf("Engellenen adlara izin ver ({0})", "Allow the blocked names ({0})", "Blockierte Namen erlauben ({0})", "Permitir los nombres bloqueados ({0})", "Autoriser les noms bloqués ({0})", "Permitir os nomes bloqueados ({0})", "Разрешить заблокированные адреса ({0})", "Consenti i nomi bloccati ({0})", "Izinkan nama yang diblokir ({0})", "Cho phép các tên bị chặn ({0})", "Zezwól na zablokowane nazwy ({0})", "Дозволити заблоковані адреси ({0})"),
        "ignore" to arrayOf("Yoksay", "Ignore", "Ignorieren", "Ignorar", "Ignorer", "Ignorar", "Игнорировать", "Ignora", "Abaikan", "Bỏ qua", "Zignoruj", "Ігнорувати"),
        "reset" to arrayOf("İstatistikleri sıfırla", "Reset statistics", "Statistik zurücksetzen", "Restablecer estadísticas", "Réinitialiser les statistiques", "Redefinir estatísticas", "Сбросить статистику", "Azzera statistiche", "Atur ulang statistik", "Đặt lại thống kê", "Zresetuj statystyki", "Скинути статистику"),
        "summary" to arrayOf("{0} kural", "{0} rules", "{0} Regeln", "{0} reglas", "{0} règles", "{0} regras", "правил: {0}", "{0} regole", "{0} aturan", "{0} quy tắc", "reguły: {0}", "правил: {0}"),
        "doneExempt" to arrayOf("{0}: muaf tutuldu", "{0}: exempted", "{0}: ausgenommen", "{0}: excluida", "{0} : exemptée", "{0}: isento", "{0}: исключено", "{0}: esclusa", "{0}: dikecualikan", "{0}: đã miễn trừ", "{0}: wyłączona", "{0}: виключено"),
        "doneAllow" to arrayOf("{0} ad izin listesine eklendi", "{0} names added to the allow list", "{0} Namen zur Erlaubnisliste hinzugefügt", "{0} nombres añadidos a la lista de permitidos", "{0} noms ajoutés à la liste d'autorisation", "{0} nomes adicionados à lista de permitidos", "{0} адресов добавлено в список разрешённых", "{0} nomi aggiunti all'elenco consentiti", "{0} nama ditambahkan ke daftar izin", "Đã thêm {0} tên vào danh sách cho phép", "Dodano {0} nazw do listy dozwolonych", "{0} адрес додано до списку дозволених"),
    )

    fun codes(): Set<String> = M.keys

    fun t(key: String, lang: Lang = L.lang, vararg args: String): String {
        val row = M[key] ?: return key
        var s = row.getOrNull(lang.ordinal)?.takeIf { it.isNotBlank() } ?: row.getOrNull(Lang.EN.ordinal) ?: row[0]
        for ((i, a) in args.withIndex()) s = s.replace("{$i}", a)
        return s
    }
}
