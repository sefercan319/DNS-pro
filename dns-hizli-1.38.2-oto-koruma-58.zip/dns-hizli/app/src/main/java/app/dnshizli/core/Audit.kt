package app.dnshizli.core

/** Denetim bulgusunun alanı (günlükteki kategori etiketiyle aynı). */
enum class AuditCat(val label: String) {
    LEAK("SIZINTI"), DPI("DPI"), ADS("REKLAM"), INTRUSION("SIZMA"), STABILITY("İSTİKRAR"), RESOURCE("KAYNAK"),
}

enum class Sev(val rank: Int) { INFO(0), WARN(1), CRIT(2) }

/** [code] sabit bir tanıttır (aynı bulgu tekrar bildirilmesin diye); [text] alan adı/IP içermeyen Türkçe cümledir. */
data class Finding(val cat: AuditCat, val sev: Sev, val code: String, val args: List<String> = emptyList()) {
    /** Seçili dildeki metin ([AuditText]). */
    val text: String get() = AuditText.render(code, args, L.lang)
    fun text(lang: Lang): String = AuditText.render(code, args, lang)
}

/**
 * Denetim ölçümü: tüm sayaçlar TOPLAMDIR (kurulumdan beri); farkları [Audit] hesaplar. Yalnızca sayı ve bayrak taşır.
 * `recent*` alanları ağ geçidinin kendi son-dakika pencere sayılarıdır (toplam değil).
 */
class AuditSample(
    val at: Long,
    val vpnUp: Boolean = true, val wanted: Boolean = true, val online: Boolean = true, val gwUp: Boolean = false,
    val dnsOn: Boolean = true, val dpiOn: Boolean = false, val adsPlus: Boolean = false, val echOn: Boolean = false,
    val dohBlock: Boolean = false, val failClosed: Boolean = false, val passthrough: Boolean = false,
    // DNS yönlendirici
    val queries: Long = 0, val timeouts: Long = 0, val retries: Long = 0, val rejected: Long = 0,
    val tlsFailures: Long = 0, val clockFailures: Long = 0, val failovers: Long = 0,
    // ağ geçidi
    val opened: Long = 0, val connectFail: Long = 0, val blockedHosts: Long = 0, val dnsBlocked: Long = 0,
    val dohBlocked: Long = 0, val cuts: Long = 0, val exhaustSkipped: Long = 0,
    val recentOk: Int = 0, val recentFail: Int = 0, val recentDpiOk: Int = 0, val recentDpiFail: Int = 0,
    val tcpFlows: Int = 0, val udpFlows: Int = 0, val flowCap: Int = 0,
    // sızıntı denetimi / liste / koruma / olaylar
    val plainDnsRedirected: Long = 0,
    val listsLive: Boolean = true, val listsDegraded: Boolean = false,
    val immuneActive: Int = 0, val netChanges: Long = 0, val connects: Long = 0,
    // uygulama bazlı: bozulmuş olabilecek uygulama (yoksa boş)
    val brokenApp: String = "", val brokenName: String = "", val brokenCount: Int = 0,
    /** Etkin DNS sızıntı testinin son sonucu ([LeakProbe]): 0 = yok/bilinmiyor, 1 = tünelden geçti, 2 = tünel dışına çıktı. */
    val leakProbe: Int = 0,
    // deneysel özellikler
    /** DNS yönlendiricisinin sorguyu iki sunucuya birden gönderdiği (yarış) toplam sayı. */
    val races: Long = 0,
    val mitmOn: Boolean = false, val mitmRejects: Long = 0,
    /** Oto-koruma ağ engeli nedeniyle DPI atlatmayı kendisi açtı ([Act.DPI_ON]). */
    val autoDpi: Boolean = false,
    val listedOnly: Boolean = false, val blockedListSize: Int = 0,
)

/**
 * Sürekli güvenilirlik denetçisi. Telefon tarafı her ~30 sn'de bir [feed] çağırır; sınıf ölçüm geçmişinden sızıntı, DPI/reklam
 * atlatma, sızma girişimi ve istikrarsızlık belirtilerini çıkarır. Saf mantık: Android'e bağlı değil, testlerle sınanır.
 * Her bulgu bir kez bildirilir ([feed] yalnızca YENİ ya da ağırlaşan bulguları döner); sürüp giden bulgu yarım saatte bir tekrar edilir.
 */
class Audit(private val repeatMs: Long = 30 * 60_000L, private val windowMs: Long = 5 * 60_000L, private val minSpanMs: Long = 120_000L) {
    private val hist = ArrayDeque<AuditSample>()
    private var current: List<Finding> = emptyList()
    private val announced = HashMap<String, Pair<Long, Sev>>()      // kod -> (son bildirim, ağırlık)
    private val activeCodes = HashSet<String>()

    @Synchronized fun reset() { hist.clear(); current = emptyList(); announced.clear(); activeCodes.clear() }

    @Synchronized fun active(): List<Finding> = current

    /** 0..100: sorunsuzken 100; her kritik bulgu −30, uyarı −10 (alt sınır 0). Bilgi bulguları puanı düşürmez. */
    @Synchronized fun score(): Int = (100 - current.sumOf { when (it.sev) { Sev.CRIT -> 30; Sev.WARN -> 10; Sev.INFO -> 0 }.toInt() }).coerceIn(0, 100)

    @Synchronized fun feed(s: AuditSample): List<Finding> {
        if (hist.isNotEmpty() && s.at < hist.last().at) hist.clear()                // saat geriye gitti: geçmiş geçersiz
        hist.addLast(s)
        while (hist.size > 2 && hist.first().at < s.at - windowMs - 60_000L) hist.removeFirst()
        val base = hist.firstOrNull { it.at >= s.at - windowMs } ?: s
        val found = if (base !== s && s.at - base.at >= minSpanMs) evaluate(base, s) else staticChecks(s)
        current = found
        val now = s.at
        val fresh = ArrayList<Finding>()
        val keep = HashSet<String>()
        for (f in found) {
            keep.add(f.code)
            val prev = announced[f.code]
            val wasActive = f.code in activeCodes
            val announce = when {
                prev == null -> true
                f.sev.rank > prev.second.rank -> true
                !wasActive -> now - prev.first >= 5 * 60_000L          // kapanıp geri geldi
                else -> now - prev.first >= repeatMs
            }
            if (announce) { announced[f.code] = now to f.sev; fresh.add(f) }
        }
        activeCodes.clear(); activeCodes.addAll(keep)
        return fresh
    }

    /** Pencere yoksa (ilk ölçümler) yalnızca anlık durumdan çıkan bulgular. */
    private fun staticChecks(s: AuditSample): List<Finding> {
        val out = ArrayList<Finding>()
        common(s, out)
        return out
    }

    private fun common(s: AuditSample, out: MutableList<Finding>) {
        val gw = s.dpiOn || s.adsPlus
        if (s.wanted && !s.vpnUp && s.online && !s.failClosed)
            out += Finding(AuditCat.LEAK, Sev.CRIT, "leak.tunnel-down")
        if (s.dnsOn && gw && s.vpnUp && !s.dohBlock)
            out += Finding(AuditCat.LEAK, Sev.WARN, "leak.doh-open")
        if (s.adsPlus && !s.listsLive)
            out += Finding(AuditCat.ADS, Sev.WARN, "ads.lists")
        else if (s.adsPlus && s.listsDegraded)
            out += Finding(AuditCat.ADS, Sev.WARN, "ads.degraded")
        if (s.adsPlus && s.echOn)
            out += Finding(AuditCat.ADS, Sev.INFO, "ads.ech")
        if (s.passthrough)
            out += Finding(AuditCat.DPI, Sev.WARN, "dpi.passthrough")
        if (s.leakProbe == 2 && s.vpnUp)
            out += Finding(AuditCat.LEAK, Sev.WARN, "leak.private-dns")
        if (s.adsPlus && s.brokenApp.isNotEmpty())
            out += Finding(AuditCat.ADS, Sev.INFO, "app.broken", listOf(s.brokenApp, s.brokenName, s.brokenCount.toString()))
        if (s.immuneActive > 0)
            out += Finding(AuditCat.INTRUSION, Sev.WARN, "sec.immune", listOf(s.immuneActive.toString()))
        if (s.autoDpi && !s.dpiOn)
            out += Finding(AuditCat.DPI, Sev.INFO, "dpi.auto")
        if (s.mitmOn && !s.gwUp && s.vpnUp)
            out += Finding(AuditCat.ADS, Sev.INFO, "mitm.nogw")
        if (s.dpiOn && s.listedOnly && s.blockedListSize == 0)
            out += Finding(AuditCat.DPI, Sev.INFO, "dpi.listed-empty")
        if (s.flowCap > 0 && s.tcpFlows * 10 >= s.flowCap * 9)
            out += Finding(AuditCat.RESOURCE, Sev.WARN, "res.flows", listOf(s.tcpFlows, s.flowCap).map { it.toString() })
    }

    private fun d(a: Long, b: Long) = if (b >= a) b - a else b          // sayaç sıfırlandıysa yeni değer

    private fun evaluate(b: AuditSample, s: AuditSample): List<Finding> {
        val out = ArrayList<Finding>()
        common(s, out)
        val gw = s.dpiOn || s.adsPlus
        val span = (s.at - b.at).coerceAtLeast(1L)
        val minutes = span / 60_000.0
        val dQ = d(b.queries, s.queries); val dTo = d(b.timeouts, s.timeouts); val dRe = d(b.retries, s.retries)
        val dRej = d(b.rejected, s.rejected); val dClock = d(b.clockFailures, s.clockFailures)
        val dTls = (d(b.tlsFailures, s.tlsFailures) - dClock).coerceAtLeast(0)
        val dFo = d(b.failovers, s.failovers)
        val dOpen = d(b.opened, s.opened); val dFail = d(b.connectFail, s.connectFail)
        val dBlk = d(b.blockedHosts, s.blockedHosts) + d(b.dnsBlocked, s.dnsBlocked)
        val dDoh = d(b.dohBlocked, s.dohBlocked); val dCuts = d(b.cuts, s.cuts); val dEx = d(b.exhaustSkipped, s.exhaustSkipped)
        val dPlain = d(b.plainDnsRedirected, s.plainDnsRedirected)
        val dRace = d(b.races, s.races); val dMitm = d(b.mitmRejects, s.mitmRejects)
        val dNet = d(b.netChanges, s.netChanges); val dConn = d(b.connects, s.connects)

        // ---- sızıntı
        if (s.dnsOn && s.vpnUp && s.gwUp && dOpen >= 40 && dQ == 0L)
            out += Finding(AuditCat.LEAK, Sev.WARN, "leak.dns-bypass", listOf(dOpen.toString()))
        if (dDoh >= 5)
            out += Finding(AuditCat.LEAK, Sev.INFO, "leak.doh-blocked", listOf(dDoh.toString()))
        if (dPlain >= 1)
            out += Finding(AuditCat.LEAK, Sev.INFO, "leak.plain-redirect", listOf(dPlain.toString()))

        // ---- DPI
        if (s.dpiOn && s.gwUp) {
            val ok = hist.filter { it.at >= b.at }.maxOf { it.recentDpiOk }
            val fail = hist.filter { it.at >= b.at }.maxOf { it.recentDpiFail }
            if (fail >= 8 && ok * 2 < fail)
                out += Finding(AuditCat.DPI, Sev.WARN, "dpi.failing", listOf(ok, fail).map { it.toString() })
            if (dOpen >= 60 && ok == 0 && fail == 0 && s.recentOk > 0)
                out += Finding(AuditCat.DPI, Sev.INFO, "dpi.idle", listOf(dOpen.toString()))
            if (dCuts >= 10)
                out += Finding(AuditCat.DPI, Sev.WARN, "dpi.cuts", listOf(dCuts.toString()))
            if (dEx >= 10)
                out += Finding(AuditCat.DPI, Sev.WARN, "dpi.exhaust", listOf(dEx.toString()))
        }

        // ---- deneysel
        if (s.mitmOn && s.gwUp && dMitm >= 3)
            out += Finding(AuditCat.ADS, Sev.WARN, "mitm.cert", listOf(dMitm.toString()))

        // ---- reklam engelleme
        if (s.adsPlus && s.listsLive && dOpen >= 300 && dBlk == 0L)
            out += Finding(AuditCat.ADS, Sev.WARN, "ads.nohit", listOf(dOpen.toString()))

        // ---- sızma girişimi
        if (dRej >= 3)
            out += Finding(AuditCat.INTRUSION, Sev.CRIT, "sec.spoof", listOf(dRej.toString()))
        if (dTls >= 2)
            out += Finding(AuditCat.INTRUSION, Sev.CRIT, "sec.tls", listOf(dTls.toString()))
        if (dClock >= 1)
            out += Finding(AuditCat.INTRUSION, Sev.WARN, "sec.clock")
        if (gw && minutes > 0 && dOpen / minutes >= 1500)
            out += Finding(AuditCat.INTRUSION, Sev.WARN, "sec.flood", listOf((dOpen / minutes).toLong().toString()))

        // ---- istikrar
        if (dQ >= 20 && dTo * 100 >= dQ * 15)
            out += Finding(AuditCat.STABILITY, Sev.WARN, "stab.timeouts", listOf(dTo * 100 / dQ, dTo, dQ).map { it.toString() })
        if (dQ >= 20 && dRace * 100 >= dQ * 20 && dRace >= 8)
            out += Finding(AuditCat.STABILITY, Sev.INFO, "stab.race", listOf((dRace * 100 / dQ).toString()))
        if (dQ >= 20 && dRe * 100 >= dQ * 30 && dTo * 100 < dQ * 15)
            out += Finding(AuditCat.STABILITY, Sev.INFO, "stab.retries", listOf((dRe * 100 / dQ).toString()))
        if (dOpen + dFail >= 30 && dFail * 100 >= (dOpen + dFail) * 40)
            out += Finding(AuditCat.STABILITY, Sev.WARN, "stab.connect", listOf(dFail * 100 / (dOpen + dFail), dFail).map { it.toString() })
        if (dFo >= 2)
            out += Finding(AuditCat.STABILITY, Sev.WARN, "stab.failover", listOf(dFo.toString()))
        if (dNet >= 6)
            out += Finding(AuditCat.STABILITY, Sev.WARN, "stab.flap", listOf(dNet.toString()))
        if (dConn >= 3)
            out += Finding(AuditCat.STABILITY, Sev.WARN, "stab.restarts", listOf(dConn.toString()))
        // aynı koda yinelenenleri ele
        return out.distinctBy { it.code }
    }
}

/** Denetçinin son durumu: servis yazar, arayüz/rapor okur (aynı süreç). */
object AuditLive {
    @Volatile var findings: List<Finding> = emptyList()
    @Volatile var score: Int = -1
    /** Bu ağın DPI yöntem tablosu (servis her denetimde günceller; rapor okur). */
    @Volatile var dpi: List<String> = emptyList()
    fun set(f: List<Finding>, sc: Int) { findings = f; score = sc }
    fun clear() { findings = emptyList(); score = -1; dpi = emptyList() }
    /** Rapor satırları: "[KATEGORİ] AĞIRLIK: metin". */
    fun lines(lang: Lang = L.lang): List<String> = findings.sortedByDescending { it.sev.rank }.map { "[${it.cat.label}] ${it.sev.name}: ${it.text(lang)}" }
}
