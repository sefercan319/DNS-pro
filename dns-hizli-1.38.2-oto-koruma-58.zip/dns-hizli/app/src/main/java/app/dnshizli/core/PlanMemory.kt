package app.dnshizli.core

/**
 * Ağa göre kalıcı DPI yöntem belleği: "ağ anahtarı" (ağ türü + mobilde operatör kodu) → o ağda son çalışan TLS ve HTTP yöntemi.
 * Uygulama yeniden açıldığında ya da aynı operatöre geri dönüldüğünde denemeler doğrudan çalışan yöntemle başlar.
 * Yalnızca telefonda tutulur; anahtar ağ kimliği (SSID/BSSID) içermez, yalnızca tür ve operatör kodudur.
 * Bir yöntem artık çalışmazsa planlayıcı sıradaki yönteme geçer ve yeni çalışan kayda geçer: bellek kendini düzeltir.
 */
class PlanMemory(private val cap: Int = 16) {
    /** [sites]: site özeti ([Dpi.siteKey]) → o sitede çalışan TLS yöntemi; en çok [SITES_PER_NET], en eski atılır. Ad açık yazılmaz. */
    private class Rec(var tls: Int, var http: Int, val sites: LinkedHashMap<String, Int> = LinkedHashMap())

    private val map = object : LinkedHashMap<String, Rec>(16, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Rec>?) = size > cap
    }

    /** Değişiklik olduğunda çağrılır (kalıcı kayıt için); her başarıda değil, yalnızca yöntem değiştiğinde. */
    @Volatile var onChange: ((String) -> Unit)? = null

    /** Bu ağ için öğrenilmiş (tls, http) yöntemleri; bilinmeyen tür -1. Hiç kayıt yoksa null. */
    @Synchronized fun get(key: String): Pair<Int, Int>? = map[key]?.let { it.tls to it.http }

    @Synchronized fun put(key: String, kind: Int, plan: Int) {
        val r = map[key] ?: Rec(-1, -1).also { map[key] = it }
        val old = if (kind == Dpi.TLS) r.tls else r.http
        if (old == plan) return
        if (kind == Dpi.TLS) r.tls = plan else r.http = plan
        val text = encodeLocked()
        onChange?.invoke(text)
    }

    /** Bu ağda öğrenilmiş site yöntemleri (kopya). */
    @Synchronized fun sites(key: String): Map<String, Int> = map[key]?.let { LinkedHashMap(it.sites) } ?: emptyMap()

    private var lastSiteSave = 0L
    @Volatile var clock: () -> Long = { System.currentTimeMillis() }

    /**
     * Bir sitede çalışan yöntemi (site özeti ile) ağ kaydına yazar. Kalıcı kayıt, her bağlantıda diske gitmesin diye en sık [SITE_SAVE_MS]'de
     * bir yapılır; son değişiklikler bir sonraki yazımda ya da yöntem değişiminde kaydolur.
     */
    @Synchronized fun putSite(key: String, siteKey: String, plan: Int) {
        if (plan !in 0 until Dpi.TLS_PLANS) return
        val r = map[key] ?: Rec(-1, -1).also { map[key] = it }
        if (r.sites[siteKey] == plan) return
        r.sites.remove(siteKey); r.sites[siteKey] = plan
        while (r.sites.size > SITES_PER_NET) r.sites.remove(r.sites.keys.first())
        val now = clock()
        if (now - lastSiteSave >= SITE_SAVE_MS || now < lastSiteSave) { lastSiteSave = now; onChange?.invoke(encodeLocked()) }
    }

    @Synchronized fun encode(): String = encodeLocked()

    private fun encodeLocked(): String =
        map.entries.joinToString(";") {
            val base = "${it.key}=${it.value.tls},${it.value.http}"
            if (it.value.sites.isEmpty()) base else base + "," + it.value.sites.entries.joinToString("/") { e -> "${e.key}.${e.value}" }
        }

    /** Kayıtlı metni okur; bozuk ya da tanınmayan satırlar atlanır, aralık dışı yöntemler -1 olur. */
    @Synchronized fun decode(s: String?) {
        map.clear()
        if (s.isNullOrBlank()) return
        for (part in s.split(';')) {
            val eq = part.indexOf('=')
            if (eq <= 0) continue
            val key = part.substring(0, eq)
            if (!validKey(key)) continue
            val nums = part.substring(eq + 1).split(',')
            if (nums.size != 2 && nums.size != 3) continue
            val t = nums[0].toIntOrNull() ?: continue
            val h = nums[1].toIntOrNull() ?: continue
            val rec = Rec(t.takeIf { it in 0 until Dpi.TLS_PLANS } ?: -1, h.takeIf { it in 0 until Dpi.HTTP_PLANS } ?: -1)
            if (nums.size == 3 && nums[2].length <= 40_000) for (tok in nums[2].split('/')) {
                if (rec.sites.size >= SITES_PER_NET) break
                val m = SITE_TOKEN.matchEntire(tok) ?: continue
                val plan = m.groupValues[2].toInt()
                if (plan in 0 until Dpi.TLS_PLANS) rec.sites[m.groupValues[1]] = plan
            }
            map[key] = rec
        }
    }

    companion object {
        const val SITES_PER_NET = 64
        const val SITE_SAVE_MS = 60_000L
        private val SITE_TOKEN = Regex("([0-9a-f]{1,12})\\.(\\d{1,2})")
        private val KEY_OK = Regex("[A-Z]{2,12}\\|[A-Za-z0-9-]{0,24}")

        fun validKey(k: String): Boolean = KEY_OK.matches(k)

        /** Ağ anahtarı: tür adı + etiket (mobilde operatör kodu, diğer türlerde boş). */
        fun key(kind: NetKind, label: String): String = kind.name + "|" + label.filter { it.isLetterOrDigit() || it == '-' }.take(24)
    }
}
