package app.dnshizli.platform

import android.app.Application
import android.app.LocaleManager
import android.content.Context
import android.os.Build
import android.os.LocaleList
import app.dnshizli.core.DeviceMem
import app.dnshizli.core.FilterLive
import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.YouTubeAds
import app.dnshizli.core.FilterSource
import app.dnshizli.core.L
import app.dnshizli.core.lightEffective

/**
 * Uygulama süreci başlarken dili ayarlar: arayüz, servis, bildirim, kutucuk ve widget aynı dili konuşur.
 * Ayar "auto" ise sistemin (Android 13+: uygulamaya özel) dil sırası kullanılır.
 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val prefs = PrefsStore(this)
        val st = prefs.loadSettings()
        applyLanguage(this, st.lang)
        // Engelleme listeleri uygulamanın içindedir (assets/filter); seviye açıksa arka planda yüklenir.
        // Paketteki listeler yedektir; indirilmiş (imzası doğrulanmış) sürüm varsa önce o okunur. Bozuksa paket kullanılır.
        FilterRuntime.fallbackSource = FilterSource { name -> assets.open("filter/$name") }
        FilterRuntime.source = FilterSource { name -> ListUpdater.open(this, name) }
        ListUpdater.maybeUpdate(this)
        run {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
            DeviceMem.lowRam = am != null && (am.isLowRamDevice || am.memoryClass < DeviceMem.LOW_HEAP_MB)
        }
        DeviceProbe.start(this)                 // cihazı tanır (üretici, sistem, bellek sınıfı); arayüz açılmadan hazırdır
        FilterRuntime.setLight(st.lightEffective())
        AppOwner.install(this, st)
        FilterRuntime.update(st.filterLevel, st.filterAllow, YouTubeAds.blockFor(st, BuildFlags.PERSONAL))
        // İçe aktarılan engel listesi arka planda okunur; yüklenince motor yeniden kurulur.
        if (prefs.importedCount() > 0) {
            val app = this
            Thread({ FilterRuntime.setImported(ImportedStore.load(app)) }, "dns-imported").also { it.isDaemon = true }.start()
        }
        FilterLive.keep(st.keepHistory)
        installCrashNote(prefs)
        noteLastExit()
    }

    /**
     * Sistem önceki süreci neden sonlandırdı? Bellek sınırı (Android 17'de RAM'e göre uygulama başına bellek tavanı:
     * "MemoryLimiter"), düşük bellek, aşırı kaynak, ANR ve yerel çökme günlüğe kısa bir satırla yazılır; tanılama raporu bunu
     * içerir. Normal kapanışlar (kullanıcı çıkışı, güncelleme) yazılmaz. Hata olursa sessizce atlanır.
     */
    private fun noteLastExit() {
        try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager ?: return
            val e = am.getHistoricalProcessExitReasons(packageName, 0, 1).firstOrNull() ?: return
            val name = when (e.reason) {
                android.app.ApplicationExitInfo.REASON_LOW_MEMORY -> "düşük bellek"
                android.app.ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "aşırı kaynak kullanımı"
                android.app.ApplicationExitInfo.REASON_ANR -> "ANR"
                android.app.ApplicationExitInfo.REASON_CRASH_NATIVE -> "yerel çökme"
                android.app.ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "başlatma hatası"
                android.app.ApplicationExitInfo.REASON_OTHER, android.app.ApplicationExitInfo.REASON_SIGNALED -> "sistem sonlandırdı"
                else -> return
            }
            val d = (e.description ?: "").take(60).replace(Regex("[^A-Za-z0-9:_ .,=-]"), "?")
            app.dnshizli.core.Journal.add("önceki süreç: $name${if (d.isNotEmpty()) " ($d)" else ""}")
        } catch (_: Throwable) {}
    }

    /**
     * Beklenmeyen bir çökmede kısa bir özet (hata türü ve uygulamanın kendi kodundaki ilk satır; kişisel veri yok)
     * saklanır; tanılama raporu ve geri bildirim bunu içerir. Ardından sistemin kendi işleyicisi çalışır (davranış değişmez).
     */
    private fun installCrashNote(prefs: PrefsStore) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val stamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.ROOT).format(java.util.Date())
                val frames = e.stackTrace.map { app.dnshizli.core.StackFrame(it.className, it.lineNumber) }
                prefs.addCrashNow(app.dnshizli.core.CrashLog.summarize(e.javaClass.name, frames, t.name, stamp))
            } catch (_: Throwable) {}
            previous?.uncaughtException(t, e)
        }
    }

    companion object {
        /** Ayara göre etkin dili seçer. Bağlam yapılandırmasındaki dil listesini (sistem ya da uygulama dili) kullanır. */
        fun applyLanguage(ctx: Context, setting: String) {
            L.set(L.resolve(setting, localeCodes(ctx)))
        }

        fun localeCodes(ctx: Context): List<String> {
            val ls = ctx.resources.configuration.locales
            return (0 until ls.size()).map { ls[it].language }
        }

        /**
         * Android 13+: uygulama içi dil seçimini sistemin "uygulama dili" ayarına da yazar (Ayarlar > Uygulamalar > Dil
         * aynı seçimi gösterir). "auto" ise uygulamaya özel dil kaldırılır.
         */
        fun syncSystemLocale(ctx: Context, setting: String) {
            if (Build.VERSION.SDK_INT < 33) return
            try {
                val lm = ctx.getSystemService(LocaleManager::class.java) ?: return
                val want = if (setting == L.AUTO) LocaleList.getEmptyLocaleList() else LocaleList.forLanguageTags(setting)
                if (lm.applicationLocales.toLanguageTags() != want.toLanguageTags()) lm.applicationLocales = want
            } catch (_: Exception) {
                // eski ya da kısıtlı cihaz: yalnızca uygulama içi dil kullanılır
            }
        }

        /** Android 13+: kullanıcı sistem ayarlarından uygulama dilini değiştirdiyse onu ayar değerine çevirir; yoksa null. */
        fun systemAppLocale(ctx: Context): String? {
            if (Build.VERSION.SDK_INT < 33) return null
            return try {
                val ls = ctx.getSystemService(LocaleManager::class.java)?.applicationLocales ?: return null
                if (ls.isEmpty) L.AUTO else ls[0].language
            } catch (_: Exception) { null }
        }
    }
}
