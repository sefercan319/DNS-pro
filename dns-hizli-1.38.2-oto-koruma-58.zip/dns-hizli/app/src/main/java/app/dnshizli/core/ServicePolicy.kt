package app.dnshizli.core

/**
 * [app.dnshizli.platform.DnsVpnService] içindeki saf karar mantığı (Android'siz; JVM'de test edilir). Servis yalnızca bu kararları uygular.
 * Buraya taşınanlar: doğrulama deneme sayısı/süresi, gizlilik düşüşü, yedek sunucu seçimi, sunucu halkası, ağ geçidi modülleri, duraklatma süresi.
 */
object ServicePolicy {
    const val CHECK_TRIES = 4
    const val CHECK_MS = 2000L
    const val CHECK_MS_SECURE = 3500L
    const val CHECK_MS_QUIC = 2500L
    const val CHECK_MS_ODOH = 6000L

    const val PAUSE_MIN = 1
    const val PAUSE_MAX = 24 * 60

    /**
     * Doğrulama deneme sayısı. QUIC yöntemleri iyimser ek yöntemdir ve UDP'yi engelleyen ağlarda sık başarısız olur: arkalarında DoT/DoH
     * varken tek, kısa denemeyle yetinilir. [last]: planın son yöntemi (vazgeçmeden önceki son şans).
     */
    fun triesFor(proto: Proto, last: Boolean): Int = when {
        QuicBackoff.isQuic(proto) && !last -> 1
        proto == Proto.ODOH -> 3
        last -> CHECK_TRIES
        proto == Proto.PLAIN -> 2
        else -> 3
    }

    /** Bir yöntemin tek denemesi için bekleme süresi (ms). */
    fun msFor(proto: Proto): Long = when (proto) {
        Proto.PLAIN -> CHECK_MS
        Proto.DOQ, Proto.DOH3 -> CHECK_MS_QUIC
        Proto.ODOH -> CHECK_MS_ODOH          // anahtar alımı + röleye TLS + hedefe giden yol
        else -> CHECK_MS_SECURE
    }

    /** Gizlilik düştü mü? Düz DNS'e inilmesi ya da ODoH beklenirken ODoH dışı bir yönteme geçilmesi. */
    fun isDowngrade(first: Proto?, chosen: Proto): Boolean =
        (chosen == Proto.PLAIN && first != Proto.PLAIN) || (first == Proto.ODOH && chosen != Proto.ODOH)

    /** Yedek sunucu: ayarlı değilse null; "en hızlı" ise son ölçümlere göre başarısız sunucu dışındaki en hızlı kullanılabilir sunucu. */
    fun backupFor(failed: DnsServer, s: AppSettings, latencies: () -> Map<String, Latency>, all: List<DnsServer> = Catalog.all): DnsServer? {
        val b = s.backupServer ?: return null
        val usable: (DnsServer) -> Boolean = { it.id != failed.id && it.id !in s.hidden && s.plan(it).isNotEmpty() }
        if (b == AppSettings.BACKUP_AUTO) return ServerList.fastest(all, latencies(), usable)?.first ?: all.firstOrNull(usable)
        return all.firstOrNull { it.id == b }?.takeIf(usable)
    }

    /**
     * Sunucu halkası: favoriler (en az 2 ise), yoksa son kullanılanlar; katalog sırasıyla (son kullanılanların sırası her geçişte
     * değiştiği için aksi halde iki sunucu arasında gidilip gelinirdi).
     */
    fun nextRing(s: AppSettings, all: List<DnsServer> = Catalog.all): List<String> {
        val usable: (DnsServer) -> Boolean = { s.plan(it).isNotEmpty() && it.id !in s.hidden }
        val fav = all.filter { it.id in s.favorites && usable(it) }.map { it.id }
        if (fav.size >= 2) return fav
        return all.filter { it.id in s.recent && usable(it) }.map { it.id }
    }

    /** Halkada [current]'tan sonraki sunucu kimliği; halka 2'den küçükse null. [current] halkada yoksa ilk eleman. */
    fun nextInRing(ring: List<String>, current: String?): String? {
        if (ring.size < 2) return null
        val cur = ring.indexOf(current)
        return ring[(cur + 1).mod(ring.size)]
    }

    /** Ağ geçidi (DPI atlatma ya da Reklam+) gerekli mi? */
    fun gwWanted(s: AppSettings): Boolean = s.dpiOn || s.adsPlus

    /** Reklam+ için süzgeç seviyesi: en az ORTA; kullanıcı DNS süzgecini SIKI seçtiyse SIKI; Reklam+ kapalıysa OFF. */
    fun gwLevelFor(s: AppSettings): FilterLevel = when {
        !s.adsPlus -> FilterLevel.OFF
        s.filterLevel == FilterLevel.STRICT -> FilterLevel.STRICT
        else -> FilterLevel.MEDIUM
    }

    /** Duraklatma bitiş zamanı (duvar saati ms): dakika [PAUSE_MIN]..[PAUSE_MAX] aralığına sıkıştırılır. */
    fun pauseUntil(nowMs: Long, minutes: Int): Long = nowMs + minutes.coerceIn(PAUSE_MIN, PAUSE_MAX) * 60_000L

    /** Duraklatma bitimine kalan süre (ms); saat geri gitmiş olsa bile en fazla [PAUSE_MAX] dakika, asla negatif değil. */
    fun pauseRemainingMs(untilMs: Long, nowMs: Long): Long = (untilMs - nowMs).coerceIn(0L, PAUSE_MAX * 60_000L)
}
