package app.dnshizli.core

/**
 * [app.dnshizli.platform.DnsVpnService] içindeki durum makineleri: olay (gözlem) girer, karar çıkar; Android çağrısı yok.
 * Servis yalnızca kararı uygular (modülleri kapat, zamanlayıcı kur). Böylece zamanlama/sayaç hataları JVM'de sınanır.
 */

/** Bağlanma yeniden deneme çizelgesi: artan bekleme, "kapalı kal" (sealed) kipinde kısa ve vazgeçmez. */
object RetrySchedule {
    val DELAYS = longArrayOf(5_000L, 30_000L, 120_000L, 5 * 60_000L, 10 * 60_000L, 15 * 60_000L, 30 * 60_000L)
    const val SEALED_MAX_MS = 120_000L

    /** [step]. denemeden önceki bekleme (ms); hak bittiyse (sealed değilken) null. Negatif adım 0 sayılır. */
    fun delayFor(step: Int, sealed: Boolean): Long? {
        val s = step.coerceAtLeast(0)
        if (!sealed && s >= DELAYS.size) return null
        val base = DELAYS[minOf(s, DELAYS.size - 1)]
        return if (sealed) minOf(base, SEALED_MAX_MS) else base
    }
}

/**
 * Ağ geçidi vanası: son dakikadaki bağlantı sonuçlarına bakarak "ağ geçidi ağı bozuyor mu" kararı verir.
 *  - DNS de cevapsızsa ya da çevrimdışıysa suç ağdadır: karar verilmez.
 *  - Bağlantı hiç kurulamıyor (recentOk==0, recentFail ≥ [failMin]) iki ölçüm üst üste → [Verdict.TRIP_ALL] (tüm modüller).
 *  - Bağlantılar açılıyor ama DPI uygulanan hiçbir el sıkışma bitmiyor (≥ [dpiFailMin]) iki ölçüm üst üste → [Verdict.TRIP_DPI] (yalnızca DPI).
 *  - Uzun süre sorunsuz ([OK_FORGIVE_TICKS] ölçüm) çalışırsa önceki kesintiler unutulur (geri açma beklemesi sıfırlanır).
 */
class GwValve(private val failMin: Int = 15, private val dpiFailMin: Int = 8) {
    enum class Verdict { NONE, TRIP_DPI, TRIP_ALL }

    class Obs(
        val online: Boolean, val dnsOk: Boolean, val gwDpi: Boolean, val settingsDpiOn: Boolean,
        val recentOk: Int, val recentFail: Int, val recentDpiOk: Int, val recentDpiFail: Int,
    )

    var tripCount = 0
        private set
    private var okTicks = 0
    private var badTicks = 0
    private var dpiBadTicks = 0

    fun observe(o: Obs): Verdict {
        if (o.online && o.dnsOk && o.recentOk == 0 && o.recentFail >= failMin) badTicks++ else badTicks = 0
        if (o.recentOk > 0) { if (++okTicks >= OK_FORGIVE_TICKS) { okTicks = 0; tripCount = 0 } } else okTicks = 0
        if (o.gwDpi && o.online && o.dnsOk && o.recentOk > 0 && o.recentDpiOk == 0 && o.recentDpiFail >= dpiFailMin) dpiBadTicks++ else dpiBadTicks = 0
        if (dpiBadTicks >= 2) {
            dpiBadTicks = 0
            if (o.settingsDpiOn) return Verdict.TRIP_DPI
        }
        if (badTicks < 2) return Verdict.NONE
        badTicks = 0
        return Verdict.TRIP_ALL
    }

    /** Bir kesinti kaydedilir; geri açmadan önceki bekleme (ms) döner (5, 15, 45, 60, 60 … dk). */
    fun onTrip(): Long { tripCount++; return GwRecovery.waitMs(tripCount) }

    /** Ağ geçidi yeniden kuruldu: sayılan kötü ölçümler sıfırlanır (kesinti sayacı kalır). */
    fun resetTicks() { badTicks = 0; dpiBadTicks = 0 }

    companion object { const val OK_FORGIVE_TICKS = 20 }
}
