package app.dnshizli.core

/**
 * Etkin DNS sızıntı testi: benzersiz, var olmayan bir ad (".invalid") sistem çözücüsüyle sorulur. Sorgu tünelden (DNS yönlendiricimiz ya da
 * ağ geçidi) geçiyorsa paket burada görülür; görülmezse sistem DNS'i tünelin DIŞINDAN gönderiyor demektir (ör. Android'in "Özel DNS"
 * ayarı: DNS-over-TLS, VPN'i atlar). Ad yalnızca bu test için üretilir, kullanıcı verisi içermez.
 */
object LeakProbe {
    @Volatile private var token: ByteArray? = null
    @Volatile private var seen = false

    /** Test sürerken true: hızlı yollar paketi taramak için bunu kontrol eder (test yokken maliyet tek okuma). */
    val active: Boolean get() = token != null

    /** Yeni test başlatır; sorulacak adı döner. */
    fun begin(): String {
        val hex = "0123456789abcdef"
        val r = java.security.SecureRandom()
        val t = StringBuilder("dnsprobe")
        repeat(10) { t.append(hex[r.nextInt(16)]) }
        seen = false
        token = t.toString().toByteArray(Charsets.US_ASCII)
        return t.toString() + ".invalid"
    }

    /** Tünelden geçen bir DNS paketini (ya da yükünü) tarar; test adı varsa işaretler. */
    fun check(p: ByteArray, off: Int, len: Int) {
        val t = token ?: return
        if (len < t.size || off < 0 || off + len > p.size) return
        var i = off
        val end = off + len - t.size
        while (i <= end) {
            if (p[i] == t[0]) {
                var k = 1
                while (k < t.size && p[i + k] == t[k]) k++
                if (k == t.size) { seen = true; return }
            }
            i++
        }
    }

    fun seen(): Boolean = seen

    /** Testi bitirir: ad tünelden geçtiyse true (sızıntı yok). */
    fun end(): Boolean { val r = seen; token = null; return r }
}
