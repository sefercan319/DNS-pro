package app.dnshizli.core

import java.security.PublicKey

/**
 * Engelli site listesi (OONI ölçümlerinden, imzalı; bkz. tools/ooni_sites.py). Şimdilik tek kullanım: listedeki bir adın QUIC bağlantısı
 * (DPI açıkken, [GwConfig.quicSelective]) düşürülür ki tarayıcı TCP'ye dönsün ve çalışan DPI yöntemi onu kapsasın.
 * Dosya: ilk satır "# surum=<unix sn>" (geri alma koruması), sonra her satırda bir alan adı. Hatalı satırlar atlanır.
 */
object BlockedSites {
    const val MAX_BYTES = 1_000_000
    const val MAX_NAMES = 20_000

    class Parsed(val version: Long, val names: Set<String>)

    @Volatile private var names: Set<String> = emptySet()

    fun any(): Boolean = names.isNotEmpty()
    fun size(): Int = names.size
    fun set(n: Set<String>) { names = n }
    fun reset() { names = emptySet() }

    /** [host] ya da üst alan adlarından biri listede mi? (Tek etiketli üst alan adlarına, "com" gibi, bakılmaz.) Nesne ayırmaz. */
    fun matches(host: String): Boolean {
        val set = names
        if (set.isEmpty() || host.isEmpty() || host.length > 253) return false
        var h = host.lowercase()
        if (h.endsWith(".")) h = h.dropLast(1)
        while (true) {
            if (set.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0 || h.indexOf('.', i + 1) < 0) return false          // iki etiketin altına inme
            h = h.substring(i + 1)
        }
    }

    /** Liste metnini ayrıştırır; sürüm satırı yoksa ya da çok büyükse null. */
    fun parse(bytes: ByteArray): Parsed? {
        if (bytes.isEmpty() || bytes.size > MAX_BYTES) return null
        val lines = String(bytes, Charsets.UTF_8).split('\n')
        val head = lines.firstOrNull()?.trim() ?: return null
        if (!head.startsWith("# surum=")) return null
        val v = head.removePrefix("# surum=").toLongOrNull() ?: return null
        if (v <= 0) return null
        val out = HashSet<String>()
        for (i in 1 until lines.size) {
            if (out.size >= MAX_NAMES) break
            val l = lines[i].trim().lowercase()
            if (l.isNotEmpty() && valid(l)) out.add(l)
        }
        return Parsed(v, out)
    }

    /** İmza geçerliyse ve metin ayrıştırılabiliyorsa sonuç; aksi halde null. */
    fun verified(list: ByteArray, sig: ByteArray, key: PublicKey): Parsed? =
        if (ListUpdate.verifySignature(list, sig, key)) parse(list) else null

    private fun valid(s: String): Boolean {
        if (s.length > 253 || s.indexOf('.') < 0) return false
        var label = 0
        for (c in s) {
            if (c == '.') { if (label == 0) return false; label = 0 }
            else if (c in 'a'..'z' || c in '0'..'9' || c == '-') { label++; if (label > 63) return false }
            else return false
        }
        return label > 0 && !s.startsWith("-") && !s.endsWith("-") && !s.all { it.isDigit() || it == '.' }
    }
}
