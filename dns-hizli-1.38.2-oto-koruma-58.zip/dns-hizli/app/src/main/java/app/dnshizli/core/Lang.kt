package app.dnshizli.core

/** Desteklenen arayüz dilleri. [native]: dilin kendi dilindeki adı (seçicide böyle görünür). */
enum class Lang(val code: String, val native: String) {
    TR("tr", "Türkçe"),
    EN("en", "English"),
    DE("de", "Deutsch"),
    ES("es", "Español"),
    FR("fr", "Français"),
    PT("pt", "Português"),
    RU("ru", "Русский"),
    IT("it", "Italiano"),
    // Android, Endonezce için eski "in" kodunu kullanır (values-in, locales_config "in"); "id" de kabul edilir.
    ID("in", "Bahasa Indonesia"),
    VI("vi", "Tiếng Việt"),
    PL("pl", "Polski"),
    UK("uk", "Українська");

    companion object {
        fun byCode(code: String?): Lang? {
            if (code.isNullOrBlank()) return null
            val c = code.lowercase().substringBefore('-').substringBefore('_').let { if (it == "id") "in" else it }
            return values().firstOrNull { it.code == c }
        }
    }
}

/**
 * Etkin dil. Tüm metinler [tx] üzerinden okunur; dil değişince yalnızca bu nesne değişir.
 * Ayardaki değer "auto" ise sistemin dil sırası ([resolve]) kullanılır; desteklenmeyen dilde İngilizce gösterilir.
 */
object L {
    const val AUTO = "auto"

    @Volatile var lang: Lang = Lang.TR
        private set

    @Volatile var tx: Tx = TxTr
        private set

    fun set(l: Lang) { lang = l; tx = of(l) }

    fun of(l: Lang): Tx = when (l) {
        Lang.TR -> TxTr
        Lang.EN -> TxEn
        Lang.DE -> TxDe
        Lang.ES -> TxEs
        Lang.FR -> TxFr
        Lang.PT -> TxPt
        Lang.RU -> TxRu
        Lang.IT -> TxIt
        Lang.ID -> TxId
        Lang.VI -> TxVi
        Lang.PL -> TxPl
        Lang.UK -> TxUk
    }

    /** Ayar ("auto" ya da dil kodu) + sistemin tercih ettiği diller (sırayla) -> gösterilecek dil. */
    fun resolve(setting: String?, systemCodes: List<String>): Lang {
        if (setting != null && setting != AUTO) Lang.byCode(setting)?.let { return it }
        for (c in systemCodes) Lang.byCode(c)?.let { return it }
        return Lang.EN
    }

    fun isValidSetting(s: String?): Boolean = s == AUTO || (s != null && s.length == 2 && Lang.byCode(s) != null)

    /** Ayarda saklanacak biçim: dilin kendi kodu ("id" -> "in"). */
    fun normalize(s: String): String = if (s == AUTO) AUTO else (Lang.byCode(s)?.code ?: AUTO)
}

/**
 * Bir dilin tüm metinleri. Yeni bir metin eklenince her dil onu tanımlamak ZORUNDADIR (soyut üye):
 * eksik çeviri derlemeyi durdurur, kullanıcı asla yarım çevrilmiş bir ekran görmez.
 */
abstract class Tx {
    abstract val lang: Lang
    val APP: String get() = "DNS Hızlı"

    // ------------------------------------------------------------------ sayı/süre biçimleri
    abstract val decimalSep: Char
    abstract val thousand: String      // 1,2 bin / 1.2K
    abstract val million: String
    abstract fun percent(n: Int): String
    abstract val dayU: String
    abstract val hourU: String
    abstract val minU: String
    abstract val secU: String
    /** Milisaniye birimi ("ms"; Rusçada "мс"). */
    open val msU: String get() = "ms"
    /** Bayt birimleri: B, KB, MB, GB (Kiril alfabeli dillerde Б, КБ…). */
    open val byteUnits: List<String> get() = listOf("B", "KB", "MB", "GB")
    abstract val justNow: String
    abstract fun ago(span: String): String

    // ------------------------------------------------------------------ ana ekran durumu
    abstract val OFF: String
    abstract val CONNECTING: String
    abstract val ON: String
    abstract val ERROR: String
    abstract val PAUSED: String
    abstract val HINT_OFF: String
    abstract val HINT_CONNECTING: String
    abstract val HINT_ERROR: String
    abstract val HINT_PAUSED: String
    abstract val ERR_DEFAULT: String
    abstract fun selected(name: String): String
    abstract fun pausedUntil(time: String): String
    abstract fun blockedShort(n: String): String
    abstract fun queriesShort(n: String): String
    abstract fun cacheShort(pct: String): String

    // ------------------------------------------------------------------ liste
    abstract val SERVERS: String
    abstract val FILTER_ALL: String
    abstract val FILTER_FAV: String
    abstract val FILTER_RECENT: String
    abstract val EMPTY_FAV: String
    abstract val EMPTY_RECENT: String
    abstract val EMPTY_FILTER: String
    abstract val MEASURE: String
    abstract val MEASURING: String
    abstract val SORT: String
    abstract val PULL_TO_MEASURE: String
    abstract val RELEASE_TO_MEASURE: String
    abstract fun serversCount(n: Int): String
    abstract fun showAllServers(n: Int): String
    abstract val SHOW_LESS: String
    abstract val TAG_FAST: String
    abstract val TAG_PRIVACY: String
    abstract val TAG_ADS: String
    abstract val TAG_FAMILY: String
    abstract val TAG_SECURITY: String
    abstract val VAR_OPEN: String
    abstract val VAR_ADS: String
    abstract val VAR_SECURITY: String
    abstract val VAR_FAMILY: String
    abstract val A11Y_CONNECTED: String
    abstract val A11Y_ENCRYPTED: String
    abstract fun favA11y(name: String): String

    // ------------------------------------------------------------------ geçici mesajlar
    abstract val COPIED: String
    abstract val DISCONNECTED: String
    abstract val BACKUP: String
    abstract val NO_REPLY: String
    abstract val MEASURE_FIRST: String
    abstract val CONNECT: String
    abstract val UNDO: String
    abstract fun fastest(name: String, ms: Int): String
    abstract fun switched(name: String): String
    abstract fun hiddenToast(name: String): String

    // ------------------------------------------------------------------ ayrıntı paneli
    abstract val PRIMARY: String
    abstract val SECONDARY: String
    abstract val COPY: String
    abstract fun addressA11y(label: String, ip: String): String
    abstract val CONNECT_TO_THIS: String
    abstract val SWITCH_TO_THIS: String
    abstract val CONNECTED_NOW: String
    abstract val ADD_FAV: String
    abstract val REMOVE_FAV: String
    abstract val MEASURE_THIS: String
    abstract val HIDE: String
    abstract val UNHIDE: String
    abstract fun lastMeasure(ms: Int?, ago: String): String
    abstract val NEVER_MEASURED: String
    abstract val ENC_SUPPORT: String
    abstract val ENC_NONE: String
    abstract val ENC_ONLY: String
    abstract fun measureSummary(best: Int, median: Int, lossPct: Int): String
    abstract val HISTORY: String
    abstract fun historyA11y(n: Int, median: Int?): String

    // ------------------------------------------------------------------ hızlı seçim (küreye uzun bas)
    abstract val QUICK_TITLE: String
    abstract val QUICK_FAVORITES: String
    abstract val QUICK_RECENT: String
    abstract val PAUSE_FOR: String
    abstract fun minutes(n: Int): String
    abstract val RESUME: String

    // ------------------------------------------------------------------ ayarlar
    abstract val SETTINGS: String
    abstract val MENU: String
    abstract val PERSONALIZE: String
    abstract val PZ_BACKGROUND: String
    abstract val PZ_AUTO: String
    abstract val PZ_FEEL: String
    abstract val PZ_ACCESS: String
    abstract val PRESET_FOOT: String
    abstract val FX_OFF_NOTE: String
    abstract val PZ_FOLDED: String
    abstract val PZ_UNFOLDED: String
    abstract val PZ_PRESET_CUSTOM: String
    abstract val THIS_DEVICE: String
    abstract val DEVICE_AUTO: String
    abstract val DEVICE_AUTO_NOTE: String
    abstract val DEVICE_SYSTEM: String
    abstract val DEVICE_CLASS: String
    abstract val DEVICE_RISK: String
    abstract val OPT_TIER: List<String>
    abstract val OPT_RISK: List<String>
    abstract val DEVICE_ADVICE: List<String>
    abstract val DEVICE_APPLIED_MOTION: String
    abstract val DEVICE_UNKNOWN: String
    abstract val DEVICE_OFF_NOTE: String
    abstract val PZ_ADAPTED: String
    abstract val SEC_THEME_COLOR: String
    abstract val SEC_SHAPE: String
    abstract val SEC_LANG_ICON: String
    abstract val GROUP_SPECIAL: String
    abstract val GROUP_LIGHT: String
    abstract val GROUP_DARK: String
    abstract val PRESET: String
    abstract val OPT_PRESET: List<String>
    abstract val PRESET_NOTES: List<String>
    abstract val PRESET_DONE: String
    abstract val RESET_LOOK: String
    abstract val RESET_LOOK_BODY: String
    abstract val RESET_LOOK_BTN: String
    abstract val RESET_LOOK_DONE: String
    abstract val MOTION_NOTE_LOWPOWER: String
    abstract val MOTION_NOTE_DEVICE: String
    abstract val DNS_SETTINGS: String
    abstract val CONN_APPS: String
    abstract val STATS_HISTORY: String
    abstract val SEC_LOOK: String
    abstract val SEC_LIST: String
    abstract val SEC_DATA: String
    abstract val ABOUT: String
    abstract val LANGUAGE: String
    abstract val LANG_AUTO: String
    abstract val THEME: String
    abstract val THEME_AUTO: String
    abstract val THEME_AUTO_NOTE: String
    abstract fun themeName(id: String): String
    abstract fun themeA11y(name: String): String
    abstract val THEME_SCHEDULE: String
    abstract val THEME_SCHEDULE_NOTE: String
    abstract val GLASS: String
    abstract val BUBBLES: String
    abstract val STYLE: String

    /** [UiStyle] sırasıyla (Aqua, Aero, Metro, Eco, Y2K) tek satırlık açıklamalar. */
    abstract val STYLE_NOTES: List<String>

    // arka plan fotoğrafı
    abstract val WALLPAPER: String
    abstract val WP_OFF: String
    abstract val WP_ON: String
    abstract val WP_PICK: String
    abstract val WP_PICK_NOTE: String
    abstract val WP_PRESETS: String
    abstract val WP_PRESETS_NOTE: String
    abstract val WP_REMOVE: String
    abstract val WP_DIM: String
    abstract val WP_BLUR: String

    /** [WpBlur] sırasıyla: kapalı, hafif, güçlü. */
    abstract val OPT_WP_BLUR: List<String>
    abstract val WP_SAVED: String
    abstract val WP_FAILED: String
    abstract val WP_REMOVED: String

    // uygulama simgesi ve yardım sayfasının kapanış bölümü
    abstract val APP_ICON: String

    /** [UiStyle] sırasıyla (Aqua, Aero, Metro, Eco, Y2K) simge açıklamaları. */
    abstract val ICON_NOTES: List<String>
    /** Kısa bildirim (tek satıra sığmalı). */
    abstract val ICON_SET: String

    /** Simge seçicisinin altındaki not: ana ekrandaki kısayol kaybolabilir. */
    abstract val ICON_NOTE: String
    abstract val ICON_FAILED: String
    abstract val HELP_WHY_TITLE: String
    abstract val HELP_WHY_BODY: String

    /** Yardım sayfasının son cümlesi; yeşil ve aynı kartın içinde çizilir. */
    abstract val HELP_WHY_TAIL: String

    // aşama 8: sorun giderici, arama, ölçüm paylaşımı, özel sunucu düzenleme, geçmişi tutma
    abstract val TROUBLE: String
    abstract val TROUBLE_RECHECK: String
    abstract val DIAG_ROW: String
    abstract val DIAG_TITLE: String
    abstract val DIAG_NOTE: String
    abstract val DIAG_SHARE_BTN: String
    abstract val TROUBLE_ALL_OK: String
    abstract val TROUBLE_SOME: String
    abstract val T_NET: String
    abstract val NET_OK: String
    abstract val NET_BAD: String
    abstract val T_PERM: String
    abstract val PERM_OK: String
    abstract val PERM_BAD: String
    abstract val T_VPN: String
    abstract val VPN_OK: String
    abstract val VPN_BAD: String
    abstract val T_DNS: String
    abstract val T_LEAK: String
    abstract val YT_ADS: String
    abstract val YT_ADS_NOTE: String
    abstract val SITE_DIAG: String
    abstract val SITE_NO_NAME: String
    abstract val SITE_VPN_OFF: String
    abstract val SITE_USER_BLOCK: String
    abstract val SITE_LIST_BLOCK: String
    abstract val SITE_CANARY: String
    abstract val SITE_DOH: String
    abstract val SITE_ALLOWED: String
    abstract val SITE_NOT_OURS: String
    abstract val SITE_ALLOW_BTN: String
    abstract val LEAK_OK: String
    abstract val LEAK_BAD: String
    abstract val PDNS_OK: String
    abstract val PDNS_BAD: String
    abstract val SEARCH: String
    abstract val SEARCH_HINT: String
    abstract val SEARCH_CLEAR: String
    abstract val SHARE_RESULTS: String
    abstract val SHARE_RESULTS_HEAD: String
    abstract val NO_RESULTS: String
    abstract val CUSTOM_EDIT: String
    abstract fun customUpdated(name: String): String
    abstract val KEEP_HISTORY: String
    abstract val KEEP_HISTORY_NOTE: String
    abstract val MOTION: String
    abstract val TEXT_SIZE: String
    abstract val HIGH_CONTRAST: String
    abstract val HIGH_CONTRAST_NOTE: String
    abstract val MINIMAL: String
    abstract val MINIMAL_NOTE: String
    abstract val LOW_POWER: String
    abstract val LOW_POWER_NOTE: String
    abstract val HAPTICS: String
    abstract val HAPTICS_NOTE: String
    abstract val ENCRYPTION: String
    abstract val ENCRYPTION_NOTE: String
    abstract val AUTO_CONNECT: String
    abstract val AUTO_CONNECT_NOTE: String
    abstract val CONNECT_ON_BOOT: String
    abstract val CONNECT_ON_BOOT_NOTE: String
    abstract val AUTO_FASTEST: String
    abstract val AUTO_FASTEST_NOTE: String
    abstract val REFRESH_ON_NET: String
    abstract val REFRESH_ON_NET_NOTE: String
    abstract val NOTIFY_DROP: String
    abstract val NOTIFY_DROP_NOTE: String
    abstract val NOTIFY_CONNECT: String
    abstract val NOTIFY_CONNECT_NOTE: String
    abstract val NOTIFY_STOP: String
    abstract val NOTIFY_STOP_NOTE: String
    abstract val NOTIFY_TIMEOUT: String
    abstract val NOTIFY_TIMEOUT_NOTE: String
    abstract val NOTIF_PERM: String
    abstract val PERM_ALLOWED: String
    abstract val PERM_BLOCKED: String
    abstract val NOTIF_CONNECTED_TITLE: String
    abstract val NOTIF_STOPPED_TITLE: String
    abstract val NOTIF_STOPPED_TEXT: String
    abstract val NOTIF_TIMEOUT_TITLE: String
    abstract val FAIL_CLOSED: String
    abstract val FAIL_CLOSED_NOTE: String
    abstract val FILTER_MEM: String
    abstract val OPT_FILTER_MEM: List<String>
    abstract val FILTER_MEM_NOTE: String
    abstract val ERR_NO_APPS: String
    abstract val NOTIF_SEALED: String
    abstract val ERR_SEALED: String
    abstract val SEALED_INFO: String
    abstract val LATENCY_TITLE: String
    abstract val LATENCY_EMPTY: String
    abstract val FILTER_MINE: String
    abstract val MINE_PASTE: String
    abstract val MINE_PASTE_NOTE: String
    abstract val MINE_FILE: String
    abstract val MINE_FILE_NOTE: String
    abstract val MINE_EXPORT: String
    abstract val MINE_EXPORT_NOTE: String
    abstract val MINE_CLEAR: String
    abstract val MINE_FOOT: String
    abstract val MINE_NOTHING: String
    abstract val MINE_CLIP_EMPTY: String
    abstract val MINE_FILE_ERR: String
    abstract val MINE_CLEARED: String
    abstract val MINE_CLEAR_ASK: String
    abstract val MINE_CUT: String
    abstract fun notifTimeout(name: String): String
    abstract val MOD_DPI: String
    abstract val MOD_ADS: String
    abstract val MOD_DPI_SUB: String
    abstract val MOD_ADS_SUB: String
    abstract val MOD_ON: String
    abstract val MOD_OFF: String
    abstract val BLOCK_QUIC: String
    abstract val BLOCK_QUIC_NOTE: String
    abstract val UDP_DECOY: String
    abstract val UDP_DECOY_NOTE: String
    abstract val DPI_LISTED_ONLY: String
    abstract val DPI_LISTED_ONLY_NOTE: String
    abstract val DNS_RACE: String
    abstract val DNS_RACE_NOTE: String
    abstract val AUTO_DPI: String
    abstract val AUTO_DPI_NOTE: String
    abstract val MITM_MODE: String
    abstract val MITM_MODE_NOTE: String
    abstract val MITM_CA: String
    abstract val MITM_CA_BODY: List<String>
    abstract val MITM_CA_BUTTON: String
    abstract val QUIC_SPLIT: String
    abstract val QUIC_SPLIT_NOTE: String
    abstract val QUIC_DNS: String
    abstract val QUIC_DNS_NOTE: String
    abstract val ECH_ALLOW: String
    abstract val ECH_ALLOW_NOTE: String
    abstract val AUTO_SHIELD: String
    abstract val AUTO_SHIELD_NOTE: String
    abstract val GW_TRIPPED: String
    abstract val MOD_FAILED: String
    abstract fun gwOn(modules: String): String
    abstract fun gwOnStats(modules: String, blocked: String): String
    abstract fun modOn(name: String): String
    abstract fun modOff(name: String): String
    abstract fun modAdsCount(n: String): String
    abstract fun modDpiCount(n: String): String
    abstract fun latencyLine(avg: String, max: String, timeouts: Int): String
    abstract fun mineCount(n: Int): String
    abstract fun mineAdded(n: Int): String
    /** İçe aktarmada @@ istisnaları yüzünden çıkarılan ad sayısı. */
    abstract fun mineExcepted(n: Int): String
    abstract fun mineCopied(n: Int): String
    abstract val CACHE: String
    abstract val CLEAR_CACHE: String
    abstract val CACHE_CLEARED: String
    abstract val ONLY_CONNECTED: String
    abstract val RULE_WIFI: String
    abstract val RULE_MOBILE: String
    abstract val RULE_AUTO: String
    abstract val RULE_AUTO_NOTE: String
    abstract val COMPACT: String
    abstract val COMPACT_NOTE: String
    abstract val HIDDEN: String
    abstract val HIDDEN_NONE: String
    abstract val STAT_QUERIES: String
    abstract val STAT_HITS: String
    abstract val STAT_BLOCKED: String
    abstract val STAT_TIME: String
    abstract val WEEK: String
    abstract fun weekA11y(total: String): String
    abstract val WEEKDAYS: List<String>     // Pazartesi'den başlayarak kısa adlar (7)
    abstract val EXPORT: String
    abstract val IMPORT: String
    abstract val EXPORTED: String
    abstract val IMPORTED: String
    abstract val IMPORT_BAD: String
    abstract val RESET_SETTINGS: String
    abstract val RESET_STATS: String
    abstract val CONFIRM: String
    abstract val RESET: String
    abstract val RESET_DONE: String
    abstract val LOG: String
    abstract val HELP: String
    abstract val VPN_SETTINGS: String
    abstract val SHARE_APP: String
    abstract val RATE_APP: String
    abstract val FEEDBACK: String
    abstract fun shareAppText(url: String): String
    abstract val VERSION: String
    abstract val OPT_BUBBLES: List<String>
    abstract val OPT_MOTION: List<String>
    abstract val OPT_CACHE: List<String>
    /** Yazı boyutu seçenekleri: dilin yüzde biçimiyle ("%90" / "90%"). */
    val OPT_TEXT: List<String> get() = TextScale.values().map { percent(Math.round(it.factor * 100)) }
    abstract val OPT_ENCRYPTION: List<String>
    abstract val PLAIN_DNS: String

    // ------------------------------------------------------------------ günlük ve yardım
    abstract val LOG_NOTE: String
    abstract val LOG_EMPTY: String
    abstract val SHARE: String
    abstract val CLEAR: String
    abstract val CLEARED: String
    abstract val HELP_SECTIONS: List<Pair<String, String>>

    // ------------------------------------------------------------------ bildirim, kutucuk, servis hataları
    abstract val NOTIF_CHANNEL: String
    abstract val NOTIF_CHANNEL_NOTE: String
    abstract val NOTIF_ALERT_CHANNEL: String
    abstract val NOTIF_CONNECTING: String
    abstract val NOTIF_STOP: String
    abstract val NOTIF_NEXT: String
    abstract val NOTIF_DROP_TITLE: String
    abstract val NOTIF_RECONNECT: String
    abstract fun notifOn(name: String, proto: String): String
    abstract fun notifPaused(time: String): String
    abstract val TILE_ON: String
    abstract val TILE_OFF: String
    abstract val WIDGET_TAP: String
    abstract val ERR_PERMISSION: String
    abstract val ERR_ESTABLISH: String
    abstract fun errNoReply(name: String): String

    /** Bağlıyken: sunucu çalışıyor ama telefon sorgularını tünele göndermiyor (kısa bildirim). */
    abstract val PHONE_BYPASS: String
    abstract fun errNoProto(name: String, proto: String): String
    abstract val ERR_SOCKET: String
    /** Android 9+ "Özel DNS" belirli bir ada sabitken (strict mode) sistem bu VPN'in DNS'ini kullanmaz. */
    abstract fun errPrivateDns(host: String): String
    abstract val ERR_REVOKED: String
    abstract val ERR_TUNNEL: String
    abstract val ERR_UNKNOWN: String

    // ------------------------------------------------------------------ ilk açılış bilgilendirmesi
    abstract val CONSENT_TITLE: String
    abstract val CONSENT_BODY: List<String>
    abstract val CONSENT_OK: String
    // ------------------------------------------------------------------ özel DNS ve sunucu bilgisi
    abstract val CUSTOM_NOTE: String
    abstract val CUSTOM_ADD: String
    abstract val CUSTOM_F_NAME: String
    abstract val CUSTOM_F_IP1: String
    abstract val CUSTOM_F_IP2: String
    abstract val CUSTOM_F_DOT: String
    abstract val CUSTOM_F_DOH: String
    abstract val CUSTOM_SAVE: String
    abstract val CUSTOM_CANCEL: String
    abstract val CUSTOM_HINT: String
    abstract val CUSTOM_ERR_NAME: String
    abstract val CUSTOM_ERR_IP: String
    abstract val CUSTOM_ERR_DOT: String
    abstract val CUSTOM_ERR_DOH: String
    abstract val CUSTOM_ERR_LIMIT: String
    abstract fun customAdded(name: String): String
    abstract val CUSTOM_DELETE: String
    abstract val CUSTOM_IN_USE: String
    abstract fun customDeleted(name: String): String
    abstract val INFO_PURPOSE: String
    abstract val INFO_OWNER: String
    abstract val INFO_AVG: String
    abstract fun avgPing(ms: Int, n: Int): String

    // ------------------------------------------------------------------ uygulama seçimi
    abstract val APPS: String
    abstract val APPS_ALL: String
    abstract fun appsOnly(n: Int): String
    abstract fun appsExcept(n: Int): String
    abstract val APPS_MODE: String
    abstract val OPT_APPS: List<String>
    abstract val APPS_NOTE: String
    abstract val APPS_LOADING: String
    abstract val APPS_EMPTY: String
    abstract val APPS_NONE_SELECTED: String
    abstract val APPS_APPLY: String
    abstract val APPS_PENDING: String

    abstract val CLOSE: String
    abstract val BACK: String

    // ------------------------------------------------------------------ 3. sürüm: güvenlik ve bağlantı
    /** Duraklatma süresi doldu, servis yeniden bağlanıyor. */
    abstract val RESUMING: String
    /** Otomatik şifrelemede şifreli bağlantı kurulamadı, şifresiz DNS'e düşüldü (geçici mesaj). */
    abstract val DOWNGRADED: String
    /** Şifresiz DNS'ten yeniden şifreli yönteme geçildi (geçici mesaj). */
    abstract val UPGRADED: String
    /** Oblivious DoH (ODoH): ayar adı, seçenekler (Kapalı / Yedekli / Sıkı), açıklama. */
    abstract val ODOH: String
    abstract val OPT_ODOH: List<String>
    abstract val ODOH_NOTE: String
    /** ODoH kurulamadı, normal şifreli bağlantıya düşüldü (geçici mesaj, bildirim başlığı ve gövdesi). */
    abstract val DOWNGRADED_ODOH: String
    abstract val NOTIF_ODOH_TITLE: String
    abstract fun notifOdoh(name: String): String
    /** Sıkı ODoH: röleler/hedefler yanıt vermiyor, bağlanılamadı. */
    abstract val ERR_NO_ODOH: String
    abstract val NOTIF_DOWNGRADE_TITLE: String
    abstract fun notifDowngrade(name: String): String
    /** Seçili sunucu yanıt vermedi, yedek sunucuya bağlanıldı. */
    abstract fun backupUsed(failed: String, used: String): String
    abstract val NOTIF_RETRYING: String
    abstract fun errNoEncrypted(name: String): String
    abstract fun errUntrusted(name: String): String
    /** Bağlıyken bağlantı ayarı değişti; yeni ayar hemen uygulanıyor. */
    abstract val APPLYING: String
    abstract val CONFIRM_DISCONNECT: String
    abstract val DISCONNECT: String

    abstract val SEC_NOTIF: String
    abstract val SEC_EXPERIMENTAL: String
    abstract val SHOW_ADVANCED: String
    abstract val SHOW_ADVANCED_NOTE: String
    abstract val STRICT_ENC: String
    abstract val STRICT_ENC_NOTE: String
    abstract val IP_MODE: String
    abstract val IP_MODE_NOTE: String
    abstract val OPT_IP_MODE: List<String>
    abstract val FILTER: String
    abstract val FILTER_LEVEL: String
    abstract val OPT_FILTER: List<String>
    abstract val FILTER_NOTES: List<String>
    abstract val FILTER_INFO: String
    abstract val FILTER_LAST: String
    abstract val FILTER_RECENT_NOTE: String
    abstract val FILTER_RECENT_EMPTY: String
    abstract val FILTER_RECENT_FOOT: String
    abstract val FILTER_PASSED: String
    abstract val FILTER_PASSED_NOTE: String
    abstract val FILTER_PASSED_EMPTY: String
    abstract val FILTER_PASSED_FOOT: String
    abstract val FILTER_SUSPECT_NOTE: String
    abstract val FILTER_BLOCK_SUSPECTS: String
    abstract val FILTER_ALLOW: String
    abstract val FILTER_BLOCK: String
    abstract val FILTER_ADD: String
    abstract val FILTER_REMOVE: String
    abstract val FILTER_ALLOW_ADD: String
    abstract val FILTER_BLOCK_ADD: String
    abstract val FILTER_ERR: String
    abstract val FILTER_ERR_LIMIT: String
    /** Ortak son ek (co.uk, com.tr) listeye yazılmak istendi. */
    abstract val FILTER_ERR_SUFFIX: String
    abstract val FILTER_ALLOW_EMPTY: String
    abstract val FILTER_BLOCK_EMPTY: String
    abstract val FILTER_ALLOW_FOOT: String
    abstract val FILTER_BLOCK_FOOT: String
    abstract val FILTER_REMOVE_BTN: String
    abstract fun filterAllowed(name: String): String
    abstract fun filterBlocked(name: String): String
    abstract fun filterRemoved(name: String): String
    abstract fun filterRemoveAsk(name: String): String
    abstract val TEST_IPV6: String
    abstract val AUTO_RECONNECT: String
    abstract val AUTO_RECONNECT_NOTE: String
    abstract val BACKUP_SERVER: String
    abstract val BACKUP_OFF: String
    abstract val BACKUP_OFF_NOTE: String
    abstract val BACKUP_FASTEST: String
    abstract val BACKUP_FASTEST_NOTE: String
    abstract val CONFIRM_OFF: String
    abstract val CONFIRM_OFF_NOTE: String
    abstract val LOCK_HIDE: String
    abstract val LOCK_HIDE_NOTE: String
    abstract val QUIET_NOTIF: String
    abstract val QUIET_NOTIF_NOTE: String
    abstract val REMEMBER_FILTER: String
    abstract val REMEMBER_FILTER_NOTE: String
    abstract val AUTO_MEASURE: String
    abstract val AUTO_MEASURE_NOTE: String
    abstract val MEASURE_ENC: String
    abstract val MEASURE_ENC_NOTE: String
    /** Sıralama seçenekleri: varsayılan, hız, ad. */
    abstract val OPT_SORT: List<String>
    abstract fun sortA11y(mode: String): String
    abstract val AUTO_LIGHT: String
    abstract val AUTO_DARK: String
    abstract val NIGHT_HOURS: String
    abstract val FILTER_ENCRYPTED: String
    abstract val FILTER_UNFILTERED: String

    // bağlantı testi
    abstract val TEST: String
    abstract val TEST_NOTE: String
    abstract val TESTING: String
    abstract val TEST_TITLE: String
    abstract val TEST_OK: String
    abstract val TEST_FAIL: String
    abstract val TEST_SERVER: String
    abstract val TEST_METHOD: String
    abstract val TEST_LATENCY: String
    abstract val TEST_DNSSEC: String
    abstract val TEST_ADS: String
    abstract val DNSSEC_YES: String
    abstract val DNSSEC_NO: String
    abstract val ADS_YES: String
    abstract val ADS_NO: String
    abstract val UNKNOWN: String
    abstract val TEST_EXPLAIN: String
    abstract val TEST_AGAIN: String

    // öneri
    abstract val RECOMMEND: String
    abstract val RECOMMEND_NOTE: String
    abstract val GOAL_SPEED: String
    abstract val GOAL_SPEED_NOTE: String
    abstract val GOAL_PRIVACY_NOTE: String
    abstract val GOAL_ADS_NOTE: String
    abstract val GOAL_FAMILY_NOTE: String
    abstract val GOAL_SECURITY_NOTE: String
    abstract fun recommended(name: String): String

    // ayrıntı paneli, ölçüm
    abstract val PRIVATE_DNS: String
    abstract val PRIVATE_DNS_NOTE: String
    abstract val CLEAR_HISTORY: String
    abstract val HISTORY_CLEARED: String

    // rehberler
    abstract val GUARD: String
    abstract val GUARD_NOTE: String
    abstract val GUARD_BODY: List<String>
    abstract val GUARD_BUTTON: String
    abstract val BATTERY: String
    abstract val BATTERY_OK: String
    abstract val BATTERY_LIMITED: String
    abstract val BATTERY_BODY: List<String>
    abstract val BATTERY_BUTTON: String
    abstract val BOOT_TAP: String
    abstract val REBIND: String
    abstract val REBIND_NOTE: String
    abstract val DOH_GUARD: String
    abstract val DOH_GUARD_NOTE: String

    // istatistik ve geçmiş
    abstract val STAT_AVG: String
    abstract val STAT_SAVED: String
    abstract val STAT_TRAFFIC: String
    abstract val SESSIONS: String
    abstract val SESSIONS_NOTE: String
    abstract val SESSIONS_EMPTY: String
    abstract val MOST_USED: String
    abstract val TODAY: String
    abstract val YESTERDAY: String
    abstract fun endReason(r: EndReason): String
    /** "1 sa 5 dk · 1,2 bin sorgu" */
    abstract fun sessionLine(duration: String, queries: String): String

    // neler yeni, içe aktarma
    abstract val SOUND_MOTION: String
    abstract val SEC_SOUND: String
    abstract val SOUND_ON: String
    abstract val SOUND_ON_NOTE: String
    abstract val SOUND_UI: String
    abstract val SOUND_UI_NOTE: String
    abstract val SOUND_CONN: String
    abstract val SOUND_CONN_NOTE: String
    abstract val SOUND_VOL: String
    abstract val SOUND_PACK: String
    abstract val SOUND_TEST: String
    abstract val SOUND_PACK_NOTE: String
    abstract val SOUND_OUT: String
    abstract val OPT_SOUND_OUT: List<String>
    abstract val SOUND_OUT_NOTES: List<String>
    abstract val SOUND_BLOCK_RINGER: String
    abstract val SOUND_BLOCK_ZERO: String
    fun soundOutNote(o: SoundOutput): String = SOUND_OUT_NOTES[o.ordinal]
    abstract val PACK_SPACE: String
    abstract val PACKS_NOTE: String
    abstract val QUIET_HOURS: String
    abstract val QUIET_NOTE: String
    abstract val QUIET_RANGE: String
    abstract val SEC_MOTION_FX: String
    abstract val ANIM_SPEED: String
    abstract val TAP_FX: String
    abstract val TAP_FX_NOTE: String
    abstract val CELEBRATE: String
    abstract val CELEBRATE_NOTE: String
    abstract val HAPTIC_LEVEL: String
    abstract val REMEMBER_MODS: String
    abstract val REMEMBER_MODS_NOTE: String
    abstract val PROFILES: String
    abstract val COPY_STATUS: String
    abstract val OPT_PACK: List<String>
    abstract val OPT_HAPTIC: List<String>
    abstract val PROFILE_NAMES: List<String>
    abstract val PROFILE_NOTES: List<String>
    abstract fun profileApplied(name: String): String
    abstract val WHATS_NEW: String
    abstract val WHATS_NEW_TOAST: String
    abstract val SHOW: String
    abstract val WHATS_NEW_ITEMS: List<String>
    abstract fun importedWith(changes: String): String
    abstract fun sensitive(c: SensitiveChange): String

    // bildirim, widget, kısayol
    abstract fun notifOnStats(name: String, proto: String, queries: String, blocked: String): String
    abstract val NOTIF_LOCKED: String
    abstract val NOTIF_QUIET_CHANNEL: String
    abstract fun widgetToday(queries: String): String
    abstract fun pauseAction(minutes: Int): String

    // ------------------------------------------------------------------ katalog notları
    /** Sunucu kimliği -> kısa açıklama. Her katalog sunucusu için tanımlı olmalı (test denetler). */
    abstract val NOTES: Map<String, String>

    // ------------------------------------------------------------------ ortak yardımcılar
    fun note(id: String): String = NOTES[id] ?: ""

    fun variant(v: Variant): String = when (v) {
        Variant.OPEN -> VAR_OPEN
        Variant.ADS -> VAR_ADS
        Variant.SECURITY -> VAR_SECURITY
        Variant.FAMILY -> VAR_FAMILY
    }

    fun tag(t: Tag): String = when (t) {
        Tag.FAST -> TAG_FAST
        Tag.PRIVACY -> TAG_PRIVACY
        Tag.ADS -> TAG_ADS
        Tag.FAMILY -> TAG_FAMILY
        Tag.SECURITY -> TAG_SECURITY
    }

    /** Durum satırındaki sunucu adı + protokol + gecikme: "Cloudflare · DoT · 23 ms". */
    fun onLine(name: String, proto: String?, ms: Int?): String {
        val sb = StringBuilder(name)
        if (proto != null) sb.append(" · ").append(proto)
        if (ms != null) sb.append(" · ").append(ms).append(' ').append(msU)
        return sb.toString()
    }

    /** Ana düğme şekli: ayar başlığı, "temaya göre" başlığı ve [OrbShape] sırasıyla adları. Her dil kendi metnini verir. */
    open val ORB_SHAPE: String get() = "Orb shape"
    open val ORB_SHAPE_EACH: String get() = "Shape per theme"
    open val ORB_SHAPE_NAMES: List<String> get() = listOf("Sphere", "Triangle", "Square", "Hexagon", "Star", "Octagon", "Pentagon", "Rectangle", "Inverted triangle", "Diamond", "Flower", "Six-point star")
    /** Ses paketi adı: ilk dördü dilden, yeni paketler marka adı (yalnızca Uzay çevrilir). */
    fun packName(p: SoundPack): String = when (p) {
        SoundPack.AUTO, SoundPack.SOFT, SoundPack.GLASS, SoundPack.CLASSIC -> OPT_PACK[p.ordinal]
        SoundPack.AQUA -> "Aqua"
        SoundPack.AERO -> "Frutiger Aero"
        SoundPack.METRO -> "Metro"
        SoundPack.ECO -> "Frutiger Eco"
        SoundPack.Y2K -> "Y2K"
        SoundPack.AURORA -> "Aurora"
        SoundPack.RETRO -> "Retro 8-bit"
        SoundPack.SPACE -> PACK_SPACE
        SoundPack.LIQUID -> "Liquid Glass"
        SoundPack.DURU -> "Duru"
    }
    open val ORB_FLOW: String get() = "Liquid motion"
    open val ORB_FLOW_NAMES: List<String> get() = listOf("Calm", "Tide", "Ripple", "Swell", "Twin", "Triangle wave", "Soft square", "Boil", "Spiral", "Still")
    fun orbFlowName(f: OrbFlow): String = ORB_FLOW_NAMES[f.ordinal]
    open val CUSTOM_THEME: String get() = "Custom theme"
    open val CUSTOM_SKY: String get() = "Sky"
    open val CUSTOM_ACCENT: String get() = "Accent"
    open val CUSTOM_SKY_NAMES: List<String> get() = listOf("Morning", "Sea", "Green", "Pink", "Midnight", "Forest floor", "Charcoal", "Red dawn")
    open val CUSTOM_ACCENT_NAMES: List<String> get() = listOf("Turquoise", "Blue", "Purple", "Rose", "Orange", "Green")
    open val CUSTOM_STYLE: String get() = "My style"
    open val FX_PART: String get() = "Animation part"
    open val FX_PART_AUTO: String get() = "Style's own animation"
    open val FX_KIND_NAMES: List<String> get() = listOf("Ring", "Drop", "Slice", "Leaf", "Spark", "Sweep", "Glass", "Wisp",
        "Orbit", "Petal", "Bubble", "Bolt", "Crystal", "Firefly", "Spiral", "Ray", "Shatter", "Pixel")
    fun fxKindName(k: FxKind): String = FX_KIND_NAMES.getOrElse(k.ordinal - 1) { FX_KIND_NAMES[0] }
    fun fxPartName(i: Int): String = fxKindName(FxParts.kind(i)) + " · " + fxVariantName(FxParts.variant(i))
    open val FX_KIND: String get() = "Animation type"
    open val FX_FORM: String get() = "Animation form"
    open val SOUND_PART: String get() = "Sound part"
    open val SOUND_PART_AUTO: String get() = "Automatic (pack)"
    open val SOUND_VOICE: String get() = "Sound timbre"
    open val SOUND_CONTOUR: String get() = "Sound pattern"
    open val SOUND_REGISTER: String get() = "Register"
    open val VOICE_NAMES: List<String> get() = listOf("Bubble", "Glass", "Click", "Wood", "Pixel", "Air", "Drop", "Chime",
        "Blip", "Kalimba", "Chrome", "Pad", "Chip", "Sonar", "Lumen", "Duru")
    open val SOUND_CONTOUR_NAMES: List<String> get() = listOf("Single hit", "Rising triad", "Falling", "Double dot", "Wiggle",
        "Octave jump", "Fifth", "Slow rise", "Quick gamma", "Closing", "Tremolo", "Chord")
    open val SOUND_REGISTER_NAMES: List<String> get() = listOf("Normal", "High")
    fun voiceName(v: Voice): String = VOICE_NAMES.getOrElse(v.ordinal) { v.name }
    fun contourName(c: Int): String = SOUND_CONTOUR_NAMES.getOrElse(c) { SOUND_CONTOUR_NAMES[0] }
    fun registerName(r: Int): String = SOUND_REGISTER_NAMES.getOrElse(r) { SOUND_REGISTER_NAMES[0] }
    open val CUSTOM_SECTION_LOOK: String get() = "Look"
    open val CUSTOM_SECTION_MOTION: String get() = "Motion"
    open val CUSTOM_SECTION_SOUND: String get() = "Sound"
    open val CUSTOM_SECTION_TOOLS: String get() = "Tools"
    open val CUSTOM_SECTION_SAVED: String get() = "Saved styles"
    open val CUSTOM_SLOT_EMPTY: String get() = "Empty · tap to save current"
    open val STYLE_APPLY: String get() = "Apply"
    open val STYLE_DELETE: String get() = "Delete"
    open val ORB_AMOUNT: String get() = "Liquid wave height"
    open val FX_SIZE: String get() = "Animation size"
    open fun customSlotName(slot: Int): String = "Style ${slot + 1}"
    open val CUSTOM_STYLE_NOTE: String get() = "Each part can be picked on its own. Choosing one replaces the style's own animation or sound; the rest of the style stays."
    open val CUSTOM_SHUFFLE: String get() = "Shuffle parts"
    open val CUSTOM_RESET: String get() = "Reset to style defaults"
    open val CUSTOM_LISTEN: String get() = "Play current sound"
    open val CUSTOM_RANDOM_DONE: String get() = "Parts shuffled"
    open val CUSTOM_RESET_DONE: String get() = "Reset"
    open val CUSTOM_SUMMARY: String get() = "Now"
    fun soundPartName(i: Int): String = voiceName(SoundParts.voice(i)) + " · " + contourName(SoundParts.contour(i)) + " · " + registerName(SoundParts.register(i))
    fun customSkyName(i: Int): String = CUSTOM_SKY_NAMES.getOrElse(i) { CUSTOM_SKY_NAMES[0] }
    fun customAccentName(i: Int): String = CUSTOM_ACCENT_NAMES.getOrElse(i) { CUSTOM_ACCENT_NAMES[0] }
    open val FX_VARIANT: String get() = "Tap effect style"
    open val FX_VARIANT_NAMES: List<String> get() = listOf("Original", "Dense", "Spin", "Double pulse", "Converge", "Tilted", "Mirrored", "Growing", "Quick")
    fun fxVariantName(v: Int): String = FX_VARIANT_NAMES.getOrElse(v) { FX_VARIANT_NAMES[0] }
    open val SHIELD_WORD: String get() = "Shield"
    /** Kalkanlar "Kalkan 7" gibi numaralanır; diğer şekillerin adı listeden gelir. */
    fun orbShapeName(s: OrbShape): String = if (s.isShield) "$SHIELD_WORD ${s.shieldNumber}" else ORB_SHAPE_NAMES[s.ordinal]
    open val LIQUID_COLOR: String get() = "Liquid color"
    open val LIQUID_THEME: String get() = "Match theme"
    open val COLOR_WORD: String get() = "Color"
    open val LIQUID_NOTE: String get() = "A chosen color replaces the speed tint; the wave speed still follows the server speed."
    fun liquidColorN(n: Int): String = "$COLOR_WORD $n"

    /** Modül kartı sayacı için "son 10 dk" öneki; çevirisi olmayan dillerde İngilizce kalır. */
    open fun modWindow(count: String): String = "Last 10 min: $count"

    /** Kapalıyken ana ekran ipucu: "Bugün · 1,2 bin sorgu". */
    fun todayLine(queries: Long): String = TODAY + " · " + queriesShort(Format.count(queries))

    /** "12:34 · 1,3 bin sorgu · %38 önbellek · 25 engellendi" */
    fun statsLine(seconds: Long, queries: Long, hitPercent: Int, blocked: Long): String {
        val s = Format.clock(seconds) + " · " + queriesShort(Format.count(queries)) + " · " + cacheShort(percent(hitPercent))
        return if (blocked > 0) s + " · " + blockedShort(Format.count(blocked)) else s
    }

    /** "↑ 1,2 MB · ↓ 3,4 MB" */
    fun traffic(up: String, down: String): String = "↑ $up · ↓ $down"

    /** Hedef (amaç) seçeneğinin adı: null hız demektir, diğerleri etiket adlarıdır. */
    fun goal(t: Tag?): String = if (t == null) GOAL_SPEED else tag(t)

    fun goalNote(t: Tag?): String = when (t) {
        null, Tag.FAST -> GOAL_SPEED_NOTE
        Tag.PRIVACY -> GOAL_PRIVACY_NOTE
        Tag.ADS -> GOAL_ADS_NOTE
        Tag.FAMILY -> GOAL_FAMILY_NOTE
        Tag.SECURITY -> GOAL_SECURITY_NOTE
    }

    fun protoName(p: Proto): String = when (p) {
        Proto.DOT -> "DoT"
        Proto.DOH -> "DoH"
        Proto.DOQ -> "DoQ"
        Proto.DOH3 -> "DoH3"
        Proto.ODOH -> "ODoH"
        Proto.PLAIN -> PLAIN_DNS
    }
}
