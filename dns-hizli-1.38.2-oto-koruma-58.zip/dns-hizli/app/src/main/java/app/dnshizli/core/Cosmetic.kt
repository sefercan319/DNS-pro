package app.dnshizli.core

/**
 * Kozmetik süzgeç kuralları (tarayıcı kipi): alan adı → gizlenecek CSS seçicileri. EasyList'in "alan##seçici" biçiminin yalnızca
 * güvenli alt kümesi okunur (istisna, genişletilmiş, JS ya da `~` yok). Seçiciler `<style>` içine konur; bu yüzden `<`, `{`, `}`, `;`, `@`,
 * `\` ve satır sonu içeren her seçici reddedilir (etiketten kaçış ve kural enjeksiyonu olmaz).
 */
class Cosmetic(rules: Map<String, List<String>>) {
    private val map: Map<String, List<String>> = rules

    fun size(): Int = map.size
    fun domains(): Set<String> = map.keys

    /** [host] ya da üst alan adlarından biri için kural var mı? */
    fun has(host: String): Boolean = walk(host) { true } != null

    /** [host] için kuralı olan en yakın kural alanı (ör. "m.youtube.com" → "youtube.com"); yoksa null. */
    fun ruleDomain(host: String): String? {
        var h = host.lowercase().trimEnd('.')
        if (h.isEmpty() || h.length > 253) return null
        while (true) {
            if (map.containsKey(h)) return h
            val i = h.indexOf('.')
            if (i < 0 || h.indexOf('.', i + 1) < 0) return null
            h = h.substring(i + 1)
        }
    }

    /** [host] için birleşik CSS (her seçici ayrı kural: biri geçersizse diğerleri bozulmaz). Kural yoksa boş. */
    fun css(host: String): String {
        val sb = StringBuilder()
        var n = 0
        var h = host.lowercase().trimEnd('.')
        while (true) {
            map[h]?.let { for (s in it) { if (n++ >= MAX_SELECTORS) return sb.toString(); sb.append(s).append("{display:none!important}") } }
            val i = h.indexOf('.')
            if (i < 0 || h.indexOf('.', i + 1) < 0) break
            h = h.substring(i + 1)
        }
        return sb.toString()
    }

    private fun <T> walk(host: String, f: (List<String>) -> T): T? {
        var h = host.lowercase().trimEnd('.')
        if (h.isEmpty() || h.length > 253) return null
        while (true) {
            map[h]?.let { return f(it) }
            val i = h.indexOf('.')
            if (i < 0 || h.indexOf('.', i + 1) < 0) return null
            h = h.substring(i + 1)
        }
    }

    companion object {
        const val MAX_SELECTORS = 400
        const val MAX_LINE = 400
        private val DOMAIN = Regex("^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$")
        private val BAD = Regex("[<{};@\\\\\\u0000-\\u001f]|/\\*|\\*/")
        private val SEL = Regex("^[A-Za-z0-9_#.\\-\\[\\]=\"'*:+~ ,()^$|>]+$")

        /** Tarayıcıların (kullanıcı CA'sına güvenenler) paket adları: kipi yalnızca bunların trafiğine uygularız. */
        val BROWSERS = setOf(
            "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary", "org.chromium.chrome",
            "com.brave.browser", "com.brave.browser_beta", "com.microsoft.emmx", "com.opera.browser", "com.opera.gx",
            "com.sec.android.app.sbrowser", "com.vivaldi.browser", "com.duckduckgo.mobile.android", "com.kiwibrowser.browser",
        )

        /** Yerleşik küçük kural kümesi (YouTube arayüz reklam alanları; video içi reklamlar sunucudan gelir, gizlenemez). */
        val BUILTIN: Cosmetic = parse(
            "youtube.com##ytd-ad-slot-renderer\n" +
            "youtube.com##ytd-in-feed-ad-layout-renderer\n" +
            "youtube.com##ytd-display-ad-renderer\n" +
            "youtube.com##ytd-banner-promo-renderer\n" +
            "youtube.com##ytd-statement-banner-renderer\n" +
            "youtube.com##ytd-promoted-sparkles-web-renderer\n" +
            "youtube.com###masthead-ad\n" +
            "youtube.com###player-ads\n" +
            "youtube.com##.ytp-ad-overlay-container\n" +
            "youtube.com##.ytp-ad-module\n" +
            "youtube.com##ytd-action-companion-ad-renderer\n" +
            "youtube.com##ytd-companion-slot-renderer\n" +
            "youtube.com##ytm-promoted-sparkles-web-renderer\n" +
            "youtube.com##ytm-companion-ad-renderer\n" +
            "youtube.com##ytm-promoted-video-renderer\n" +
            "reddit.com##shreddit-ad-post\n"
        )

        /**
         * Tırnak, köşeli ve yuvarlak parantez dengeli mi? Tek `<style>` bloğunda dengesiz bir seçici ("a[href=\"x", "b:not(c") ardından gelen
         * kuralları da yutar: bir bozuk satır, aynı alanın geri kalan seçicilerini sessizce işlevsiz bırakırdı.
         */
        internal fun balanced(sel: String): Boolean {
            val stack = ArrayList<Char>()
            var q = '\u0000'
            for (c in sel) {
                if (q != '\u0000') { if (c == q) q = '\u0000'; continue }
                when (c) {
                    '"', '\'' -> q = c
                    '[' -> stack.add(']')
                    '(' -> stack.add(')')
                    ']', ')' -> if (stack.isEmpty() || stack.removeAt(stack.size - 1) != c) return false
                }
            }
            return q == '\u0000' && stack.isEmpty()
        }

        fun parse(text: String): Cosmetic {
            val out = LinkedHashMap<String, MutableList<String>>()
            if (text.length > 2_000_000) return Cosmetic(out)
            for (raw in text.lineSequence()) {
                val line = raw.trim()
                if (line.isEmpty() || line.length > MAX_LINE || line.startsWith("!")) continue
                val i = line.indexOf("##")
                if (i <= 0) continue                                  // genel kural (alan yok) ve diğer biçimler alınmaz
                val sel = line.substring(i + 2).trim()
                if (sel.isEmpty() || BAD.containsMatchIn(sel) || !SEL.matches(sel) || sel.startsWith("+js") || !balanced(sel)) continue
                for (d in line.substring(0, i).split(',')) {
                    val dom = d.trim().lowercase()
                    if (!DOMAIN.matches(dom)) continue                // "~alan", ters kurallar ve joker alanlar atlanır
                    val l = out.getOrPut(dom) { ArrayList() }
                    if (l.size < MAX_SELECTORS && sel !in l) l.add(sel)
                }
            }
            return Cosmetic(out)
        }
    }
}
