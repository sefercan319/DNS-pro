package app.dnshizli.core

/**
 * Android bileşenlerinin (açılış alıcısı, ana etkinlik) KARAR mantığı. Android'e bağlı kısım yalnızca olayı okuyup sonucu
 * uygular; "ne yapılmalı" sorusu burada, saf Kotlin olarak durur ve bilgisayarda sınanır (platform kodu yerelde derlenemez).
 */
object BootPolicy {
    const val BOOT_COMPLETED = "android.intent.action.BOOT_COMPLETED"
    const val QUICKBOOT = "android.intent.action.QUICKBOOT_POWERON"
    const val PACKAGE_REPLACED = "android.intent.action.MY_PACKAGE_REPLACED"

    /** Açılıştan sonra bu süre içinde gelen QUICKBOOT yayını gerçek sayılır (herhangi bir uygulama gönderebilir). */
    const val BOOT_WINDOW_MS = 10 * 60_000L
    private const val MAX_PAUSE_MS = 24L * 60 * 60_000L

    enum class Act {
        /** Hiçbir şey yapma. */ NONE,
        /** Duraklatma bilgisini sil, başka bir şey yapma. */ CLEAR_PAUSE,
        /** Duraklatma bitti (ya da saat güvenilmez): hemen devam et. */ RESUME_NOW,
        /** Duraklatma sürüyor: bitiş alarmını yeniden kur. */ SCHEDULE_ALARM,
        /** Normal bağlan. */ CONNECT,
    }

    fun decide(
        action: String?, uptimeMs: Long, connectOnBoot: Boolean, wasActive: Boolean, onboarded: Boolean,
        vpnReady: Boolean, pausedUntil: Long, nowMs: Long,
    ): Act {
        if (action == null) return Act.NONE
        val justBooted = uptimeMs < BOOT_WINDOW_MS
        // Pencere dışındaki QUICKBOOT: boot=false olur, ne duraklatma kolu ne "wanted" tetiklenir → NONE (ayrı bir erken dönüş gerekmez).
        val boot = action == BOOT_COMPLETED || (action == QUICKBOOT && justBooted)
        if (pausedUntil > 0L && (boot || action == PACKAGE_REPLACED)) {
            if (!vpnReady || !onboarded) return Act.CLEAR_PAUSE
            val left = pausedUntil - nowMs
            // Açılışta saat henüz doğru değilse uzak bir tarih görünebilir: alarm yıllarca çalmasın, süre dolmuş sayılır.
            return if (left <= 0L || left > MAX_PAUSE_MS) Act.RESUME_NOW else Act.SCHEDULE_ALARM
        }
        val wanted = when {
            boot -> connectOnBoot
            action == PACKAGE_REPLACED -> wasActive
            else -> false
        }
        return if (wanted && onboarded && vpnReady) Act.CONNECT else Act.NONE
    }
}

object IntentPolicy {
    enum class Kind { CONNECT, DISCONNECT, PAUSE, OTHER }
    enum class Do {
        NOTHING,
        /** Belirli bir sunucuya bağlan/geç. */ TAP_SERVER,
        /** Küreye dokunmuş gibi bağlan/kes. */ TAP_ORB,
        /** Hemen kes (yalnızca güvenilen kaynak). */ DISCONNECT_NOW,
        /** Dışarıdan geldi: kullanıcıya sor. */ CONFIRM_DISCONNECT,
        /** Duraklat. */ PAUSE,
        /** Duraklatma istendi ama bağlı değil: uyar. */ WARN_NOT_CONNECTED,
    }
    class Plan(val what: Do, val serverId: String? = null, val minutes: Int = 0)

    /**
     * [trusted]: niyet uygulamanın dışa kapalı takma adıyla mı geldi (başka uygulama bunu hedefleyemez). Güvenilmeyen niyet
     * sunucu seçemez, duraklatamaz ve bağlantıyı doğrudan kesemez (yalnızca sorulur); "bağlan" zararsızdır.
     */
    fun plan(
        kind: Kind, trusted: Boolean, extraServer: String?, serverKnown: (String) -> Boolean, rawMinutes: Int,
        running: Boolean, active: Boolean, connectedId: String?, autoConnect: Boolean, onboarded: Boolean,
    ): Plan = when (kind) {
        Kind.CONNECT -> {
            val id = if (trusted) extraServer?.takeIf(serverKnown) else null
            when {
                id != null && connectedId != id -> Plan(Do.TAP_SERVER, id)
                id == null && !active -> Plan(Do.TAP_ORB)
                else -> Plan(Do.NOTHING)
            }
        }
        Kind.DISCONNECT -> if (!running) Plan(Do.NOTHING) else Plan(if (trusted) Do.DISCONNECT_NOW else Do.CONFIRM_DISCONNECT)
        Kind.PAUSE -> if (!trusted) Plan(Do.NOTHING)
            else if (active) Plan(Do.PAUSE, minutes = rawMinutes.coerceIn(1, 24 * 60))
            else Plan(Do.WARN_NOT_CONNECTED)
        Kind.OTHER -> if (autoConnect && onboarded && !active) Plan(Do.TAP_ORB) else Plan(Do.NOTHING)
    }
}
