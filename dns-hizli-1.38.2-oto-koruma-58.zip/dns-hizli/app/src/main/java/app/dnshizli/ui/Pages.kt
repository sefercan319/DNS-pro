package app.dnshizli.ui

import app.dnshizli.core.AppAds
import app.dnshizli.core.AppAdsText
import app.dnshizli.core.Health
import app.dnshizli.core.HealthSummary
import app.dnshizli.core.AppMode
import app.dnshizli.core.Journal
import app.dnshizli.core.AuditLive
import app.dnshizli.core.CompatLive
import app.dnshizli.core.CustomPalette
import app.dnshizli.core.DeviceTune
import app.dnshizli.core.KillRisk
import app.dnshizli.core.Look
import app.dnshizli.core.LookPreset
import app.dnshizli.core.PzFolds
import app.dnshizli.core.SavedStyles
import app.dnshizli.core.SoundParts
import app.dnshizli.core.SoundOutput
import app.dnshizli.core.OrbFlow
import app.dnshizli.core.FxVariants
import app.dnshizli.core.WallpaperPresets
import app.dnshizli.core.FilterMem
import app.dnshizli.core.ALIGN_CENTER
import app.dnshizli.core.Troubleshoot
import app.dnshizli.core.DiagReport
import app.dnshizli.core.DiagInput
import app.dnshizli.core.ALIGN_LEFT
import app.dnshizli.core.AdSuspect
import app.dnshizli.core.BubbleLevel
import app.dnshizli.core.CacheLevel
import app.dnshizli.core.Catalog
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Easing
import app.dnshizli.core.Encryption
import app.dnshizli.core.Format
import app.dnshizli.core.FilterLevel
import app.dnshizli.core.FilterLive
import app.dnshizli.core.FilterNames
import app.dnshizli.core.Gfx
import app.dnshizli.core.Icon
import app.dnshizli.core.Icons
import app.dnshizli.core.IpMode
import app.dnshizli.core.OdohMode
import app.dnshizli.core.L
import app.dnshizli.core.Lang
import app.dnshizli.core.TextScale
import app.dnshizli.core.HapticLevel
import app.dnshizli.core.Profile
import app.dnshizli.core.Profiles
import app.dnshizli.core.SoundPack
import app.dnshizli.core.Motion
import app.dnshizli.core.NightHours
import app.dnshizli.core.OrbMath
import app.dnshizli.core.OrbShape
import app.dnshizli.core.OrbShapes
import app.dnshizli.core.OrbState
import app.dnshizli.core.AppEntry
import app.dnshizli.core.AppScope
import app.dnshizli.core.AppSettings
import app.dnshizli.core.Rgb
import app.dnshizli.core.Session
import app.dnshizli.core.SessionLog
import app.dnshizli.core.Tag
import app.dnshizli.core.TextFit
import app.dnshizli.core.Themes
import app.dnshizli.core.UiStyle
import app.dnshizli.core.WpBlur
import app.dnshizli.core.WallpaperMath
import app.dnshizli.core.UsageStats
import kotlin.math.roundToInt

/** Seçim panelindeki bir seçenek. */
class Option(
    val id: String?,
    val name: String,
    val note: String = "",
    val selected: Boolean = false,
    /** Verilirse satır bir eylemdir: radyo yerine bu simge çizilir. */
    val icon: Icon? = null,
    /** Sağa hizalı kısa bilgi (ör. "12×"). */
    val badge: String = "",
    /** Ad bir alan adıdır: uzunsa baştan kısaltılır, sondaki kayıtlı alan adı görünür kalır. */
    val domain: Boolean = false,
)

/** Sayfaların ve alt sayfaların gezinti istekleri (sahne uygular). */
interface Nav {
    /** ☰ menüsü: ayrı pencerelerin listesi. */
    fun openMenu()
    /** Ayar pencereleri (DNS, bağlantı, bildirimler, sunucu listesi, istatistikler, veriler). */
    fun openSection(section: Section)
    /** Kişiselleştirme penceresi: dil, tema, stil, arka plan, simge, yazı, hareket, erişilebilirlik. */
    fun openPersonalize()
    /** Sıvı rengi: önizleme, "Temaya göre" ve 50 renk. */
    fun openLiquidColor()
    /** Hakkında penceresi: yenilikler, yardım, günlük, paylaş, puanla, geri bildirim, sürüm. */
    fun openAbout()
    /** Kendi stilim: gökyüzü, vurgu, sıvı hareketi, animasyon ve ses parçaları. */
    fun openCustomStyle()
    fun openLog()
    fun openHelp()
    fun openDetails(server: DnsServer)

    /** "Otomatik" + tüm sunucular arasından seçim (ağ kuralları). */
    fun openChoice(title: String, current: String?, onPick: (String?) -> Unit)

    /** Genel seçim paneli (dil, gizlenen sunucular…). */
    fun openOptions(title: String, options: List<Option>, empty: String = "", footer: String = "", onPick: (String?) -> Unit)

    /** Küreye uzun basınca: favoriler, son kullanılanlar, duraklatma. */
    fun openQuickPick()

    /** Bağlantı testini başlatır ve sonucunu panelde gösterir. */
    fun openTest()

    /** "Bana uygun sunucu": amaç seçimi. */
    fun openRecommend()

    /** Başlık, paragraflar ve isteğe bağlı bir eylem düğmesi olan bilgi paneli. */
    fun openInfo(title: String, paragraphs: List<String>, button: String? = null, action: (() -> Unit)? = null)
    fun openSessions()
    fun openWhatsNew()
    fun openApps()
    fun back()
}

class TopSpacer : Node() {
    override fun layout(env: Env, maxW: Float) { w = maxW; h = M.HEADER_H + env.insetTop + 4f }
}

class BottomSpacer : Node() {
    override fun layout(env: Env, maxW: Float) { w = maxW; h = 28f + env.insetBottom }
}

/**
 * Yalnızca ilgili olduğunda görünen düğümler (ör. "Sesler" kapalıyken ses düzeyi satırı gizlenir).
 * [apply] her düğümün görünürlüğünü ayara göre yazar; sonuç herhangi biri değiştiyse true döner (sayfa yerleşimi yeniler).
 * Her karede çağrılabilir: bellek ayırmaz.
 */
class Conds {
    private val nodes = ArrayList<Node>()
    private val tests = ArrayList<(AppSettings) -> Boolean>()
    private var last = BooleanArray(0)

    fun <T : Node> add(n: T, test: (AppSettings) -> Boolean): T { nodes.add(n); tests.add(test); return n }

    val size: Int get() = nodes.size

    fun apply(s: AppSettings): Boolean {
        if (last.size != nodes.size) last = BooleanArray(nodes.size).also { for (i in it.indices) it[i] = true }
        var changed = false
        for (i in 0 until nodes.size) {
            val v = tests[i](s)
            if (v != last[i]) { last[i] = v; changed = true }
            nodes[i].visible = v
        }
        return changed
    }
}

/** Üstte cam başlık çubuğu, altında dikey kaydırılan içerik olan sayfa iskeleti. */
abstract class ScrollPage(title: String, back: Boolean, protected val nav: Nav) : Node() {
    protected val header = Header(title, back) { nav.back() }
    protected val scroll = ScrollView()
    protected val col = Column(gap = 14f)

    init {
        col.add(TopSpacer())
        scroll.setContent(col)
        add(scroll)
        add(header)
    }

    /** Sayfa açılırken satırların art arda belirmesini başlatır (stilin hareketi izin veriyorsa). */
    fun startReveal(env: Env) = scroll.startReveal(env)

    /** Alt sınır boşluğunu ekler; alt sınıflar içeriği ekledikten sonra çağırır. */
    protected fun finish() { col.add(BottomSpacer()) }

    val scrollOffset: Float get() = scroll.offset

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        h = env.height
        val cw = minOf(maxW, M.MAX_W)
        val l = (maxW - cw) / 2f
        col.padL = l + M.PAD
        col.padR = l + M.PAD
        header.layout(env, maxW)
        scroll.clipInsetTop = header.h
        scroll.setViewport(env, maxW, h)
        onLaidOut(env, l)
    }

    protected open fun onLaidOut(env: Env, left: Float) {}

    /** İçerik değişti (satır sayısı vb.): yeniden yerleştir. */
    fun relayoutContent(env: Env) { scroll.setViewport(env, w, h) }

    override fun tick(dt: Float, env: Env): Boolean {
        header.barAlpha = Easing.clamp01((scroll.offset - 6f) / 40f)
        return tickKids(dt, env)
    }
}

// =============================================================================== ana sayfa

/** Üst çubukta, küre kaydırılıp görünmez olunca beliren küçük bağlantı düğmesi. */
class MiniOrb(private val onTap: () -> Unit) : PressNode() {
    var alpha = 0f
    override val tappable: Boolean get() = alpha > 0.5f
    override val hitSlop: Float get() = 2f
    override fun layout(env: Env, maxW: Float) { w = 40f; h = 40f }
    override fun draw(g: Gfx, env: Env) {
        if (alpha <= 0.01f) return
        val st = env.model.vpn.state
        g.save()
        g.alpha(alpha)
        pressScale(g, w / 2f, h / 2f, 0.1f)
        val glow = if (st == OrbState.ON) 0.7f else 0f
        env.art.orbShape = env.model.orbShapeFor(env.model.shownThemeId)
        env.art.liquidTintAmt = 0f
        env.art.liquidColor = env.model.liquidColorArgb
        env.art.orb(g, w / 2f, h / 2f, 17f, OrbMath.targetLevel(st), env.time * 1.5f, glow, if (st == OrbState.ERROR) 1f else 0f, press.value * 0.6f)
        g.restore()
    }
    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) { super.onUp(lx, ly, tap, env); if (tap) { env.tap(true); onTap() } }
    override fun a11y(): A11y? = null
    fun label(env: Env): String = Strings.APP + ": " + env.model.statusTitle()
}

/** Süzgeç çipleri: sığdığı kadar satıra dizilir. Yatay kaydırma yok: her çip görünür ve erişilebilir. */
class ChipsRow(private val model: AppModel) : Node() {
    private val filters = Filter.values()
    private val chips = filters.map { f -> Chip(f.label) { model.setFilter(f) } }
    /** Son çip: arama. Aramada "Ara", arama varken aranan söz görünür ve seçili olur. */
    private val search = Chip(Strings.SEARCH) { model.promptSearch() }
    private val all = chips + search
    private var seen = -1

    init { for (c in all) add(c) }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        var x = 0f
        var y = PAD_T
        search.text = searchText()
        for (c in all) {
            c.layout(env, maxW)
            if (x > 0f && x + c.w > maxW + 0.5f) { x = 0f; y += M.CHIP_H + GAP }
            c.x = x; c.y = y
            x += c.w + GAP
        }
        h = y + M.CHIP_H + PAD_B
        sync(env, false)
    }

    private fun sync(env: Env, animate: Boolean) {
        for (i in filters.indices) chips[i].setSelected(filters[i] == model.filter, env, animate)
        search.setSelected(model.effectiveQuery.isNotEmpty(), env, animate)
    }

    private fun searchText(): String {
        val q = model.effectiveQuery
        return if (q.isEmpty()) Strings.SEARCH else "“" + (if (q.length > 12) q.take(11) + "…" else q) + "”"
    }

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version) { seen = model.version; sync(env, true) }
        return tickKids(dt, env)
    }

    private companion object {
        const val GAP = 6f
        const val PAD_T = 6f
        const val PAD_B = 10f
    }
}

/** "Sunucular" başlığı, sayısı ve sağda sırala / ölç düğmeleri. */
class ListHeader(private val model: AppModel) : Node() {
    private val title = Label(Strings.SERVERS, 18f, bold = true)
    private val count = Label("", 13f, ink = Ink.SOFT)
    private val sortBtn = IconButton(Icon.SORT, Strings.SORT, 40f) { model.toggleSort() }.also {
        it.labelFn = { Strings.sortA11y(Strings.OPT_SORT[model.settings.sortMode.ordinal]) }
    }
    private val measureBtn = IconButton(Icon.REFRESH, Strings.MEASURE, 40f) { model.measureAll() }
    private val spoken = A11yOnly("", Role.HEADING)
    private var seen = -1

    init { add(spoken); add(measureBtn); add(sortBtn) }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        h = 48f
        measureBtn.layout(env, maxW); sortBtn.layout(env, maxW)
        measureBtn.x = w - measureBtn.w; measureBtn.y = (h - measureBtn.h) / 2f
        sortBtn.x = measureBtn.x - 10f - sortBtn.w; sortBtn.y = measureBtn.y
        syncText()
        title.layout(env, maxW - 120f)
        title.x = 4f; title.y = (h - title.h) / 2f
        count.x = 4f + env.metrics.textWidth(title.text, env.sz(18f), true) + 10f
        count.layout(env, maxOf(40f, sortBtn.x - 8f - count.x))   // büyük yazıda da kısalmaz
        count.y = title.y + (title.h - count.h) / 2f + 1f
        spoken.x = 0f; spoken.y = title.y; spoken.h = title.h
        spoken.w = spokenWidth(env)
    }

    private fun spokenWidth(env: Env): Float = minOf(sortBtn.x - 8f, count.x + env.metrics.textWidth(count.text, env.sz(13f), false))

    /** Modelden gelen metin ve düğme durumları. */
    private fun syncText() {
        seen = model.version
        count.text = Strings.serversCount(model.visibleServers().size)
        spoken.label = Strings.SERVERS + ", " + count.text
        sortBtn.active = model.settings.sortMode != app.dnshizli.core.SortMode.DEFAULT
        measureBtn.active = model.measuring
    }

    private fun refresh(env: Env) {
        if (seen == model.version) return
        syncText()
        spoken.w = spokenWidth(env)
    }

    override fun tick(dt: Float, env: Env): Boolean {
        refresh(env)
        if (model.measuring) measureBtn.spin = (measureBtn.spin + dt * 360f) % 360f else measureBtn.spin = 0f
        return tickKids(dt, env)
    }

    /** Ölçüm dönerken küre gibi süs animasyonudur: 33 ms'lik kareler yeter. */
    override fun ambient(env: Env): Boolean = (env.ambient && model.measuring) || ambientKids(env)

    override fun draw(g: Gfx, env: Env) {
        g.save(); g.translate(title.x, title.y); title.draw(g, env); g.restore()
        g.save(); g.translate(count.x, count.y); count.draw(g, env); g.restore()
        drawKids(g, env)
    }
}

/** Sunucu satırlarını tutar; satır nesneleri kimliğe göre yeniden kullanılır (animasyon durumu korunur). */
class ServerListNode(private val onLong: (DnsServer) -> Unit) : Node() {
    private val rows = HashMap<String, ServerRow>()
    private val empty = Label("", 14f, ink = Ink.SOFT, align = ALIGN_CENTER, maxLines = 0)

    fun sync(env: Env) {
        val m = env.model
        val list = m.shownServers()
        removeAll()
        for (s in list) add(rows.getOrPut(s.id) { ServerRow(s, onLong) })
        empty.text = when {
            list.isNotEmpty() -> ""
            m.effectiveFilter == Filter.FAVORITES -> Strings.EMPTY_FAV
            m.effectiveFilter == Filter.RECENT -> Strings.EMPTY_RECENT
            else -> Strings.EMPTY_FILTER
        }
    }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        var cy = 0f
        for (k in kids) {
            k.layout(env, maxW)
            k.x = 0f
            k.y = cy
            cy += k.h + M.ROW_GAP
        }
        h = if (kids.isEmpty()) 0f else cy - M.ROW_GAP
        if (empty.text.isNotEmpty()) {
            empty.layout(env, maxW - 24f)
            empty.x = 12f
            empty.y = 16f + EMPTY_ICON + 10f                      // üstte soluk bir simge için yer
            h = empty.y + empty.h + 16f
        }
    }

    override val revealSelf: Boolean get() = true

    override fun draw(g: Gfx, env: Env) {
        if (empty.text.isNotEmpty()) {
            // Boş durum: filtreye uygun soluk simge (favoriler → yıldız, son kullanılanlar → sinyal, diğer → dünya)
            val ic = when (env.model.effectiveFilter) { Filter.FAVORITES -> Icon.STAR; Filter.RECENT -> Icon.SIGNAL; else -> Icon.GLOBE }
            g.save(); g.alpha(0.55f)
            Icons.draw(g, ic, w / 2f, 16f + EMPTY_ICON / 2f, EMPTY_ICON, env.theme.textSoft, 2f)
            g.restore()
            g.save(); g.translate(empty.x, empty.y); empty.draw(g, env); g.restore()
        }
        val rv = env.revealT
        if (rv == Reveal.DONE) { drawKids(g, env); return }
        // açılışta satırlar art arda belirir (ilk bölümlerden sonra başlar)
        val stg = env.art.motion.stagger
        var i = 0
        while (i < kids.size) {
            val k = kids[i]
            g.save()
            g.translate(k.x, k.y - scrollY)
            Reveal.apply(g, env, Reveal.progress(rv, i + 3, stg), k.w, k.h)
            k.draw(g, env)
            g.restore()
            i++
        }
    }

    override fun a11y(): A11y? = if (empty.text.isNotEmpty()) A11y(empty.text, Role.TEXT) else null

    private companion object { const val EMPTY_ICON = 34f }
}

/**
 * Küre altında hızlı profil çipleri (Hız / Gizlilik / Aile / Tam koruma). Dokununca [AppModel.applyProfile] çalışır
 * (menüdeki profil penceresiyle aynı eylem). Seçili çip, ayarların profille birebir örtüştüğü profildir; örtüşen yoksa hiçbiri seçili olmaz.
 */
class ProfileChips(private val model: AppModel) : Node() {
    // "Aile" gibi adlar süzgeç çipleriyle çakışır: ekran okuyucu için "Profiller: Aile" denir.
    private val chips = Profiles.all.mapIndexed { i, p ->
        Chip(Strings.PROFILE_NAMES[i]) { model.applyProfile(p.id) }.also { it.a11yLabel = Strings.PROFILES + ": " + Strings.PROFILE_NAMES[i] }
    }
    private var seen = -1

    init { for (c in chips) add(c) }

    private fun matches(p: Profile): Boolean {
        val s = model.settings
        return s.lastServer == p.serverId && s.strictEncryption == p.encryptionStrict && s.cache == p.cache &&
            s.autoFastest == p.fastest && s.filterLevel == p.filter
    }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        var x = 0f
        var y = 0f
        for (c in chips) {
            c.layout(env, maxW)
            if (x > 0f && x + c.w > maxW + 0.5f) { x = 0f; y += M.CHIP_H + GAP }
            c.x = x; c.y = y
            x += c.w + GAP
        }
        h = y + M.CHIP_H
        sync(env, false)
    }

    private fun sync(env: Env, animate: Boolean) {
        for (i in chips.indices) chips[i].setSelected(matches(Profiles.all[i]), env, animate)
    }

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version) { seen = model.version; sync(env, true) }
        return tickKids(dt, env)
    }

    private companion object { const val GAP = 6f }
}

class HomePage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.APP, false, nav) {
    private val orb = OrbBlock({ model.tapOrb() }, { nav.openQuickPick() })
    private val profileChips = ProfileChips(model)
    private val modules = ModuleCards(model)
    private val chips = ChipsRow(model)
    private val listHead = ListHeader(model)
    private val list = ServerListNode { nav.openDetails(it) }
    private val addCustom = ActionButton(Strings.CUSTOM_ADD, false) { model.promptCustom() }
    private val more = ActionButton("", false) { model.toggleList() }
    private val menu = IconButton(Icon.MENU, Strings.MENU) { nav.openMenu() }
    private val mini = MiniOrb { model.tapOrb() }
    private var seen = -1
    private var pullReady = false

    init {
        header.addRight(menu)
        header.addRight(mini)
        col.add(orb)
        col.add(profileChips)
        col.add(modules)
        col.add(chips)
        col.add(listHead)
        col.add(addCustom)
        col.add(list)
        col.add(more)
        finish()
        col.gap = 10f
        chips.visible = !model.settings.minimal
        profileChips.visible = !model.settings.minimal
        // En üstte aşağı çekip bırakınca tüm sunucuların hızı ölçülür.
        scroll.pullable = true
        scroll.onPullRelease = { d -> if (d >= Scroller.PULL_TRIGGER) { model.measureAll() } }
    }

    override fun onLaidOut(env: Env, left: Float) { seen = -1 }

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version) {
            seen = model.version
            chips.visible = !model.settings.minimal
            profileChips.visible = !model.settings.minimal
            list.sync(env)
            more.visible = model.listCollapsible()
            more.text = if (model.listExpanded) Strings.SHOW_LESS else Strings.showAllServers(model.visibleServers().size - AppModel.LIST_LIMIT)
            relayoutContent(env)
        }
        // Çekme eşiğine varılınca bir kez hafif titreşim: bırakınca ölçüm başlayacağı hissedilir.
        val ready = scroll.pull >= Scroller.PULL_TRIGGER
        if (ready && !pullReady && model.settings.haptics) model.host.haptic(false)
        pullReady = ready
        val a = super.tick(dt, env)
        // Küre görünümden çıkınca üst çubukta mini düğme belirir.
        val orbScreenBottom = orb.y + orb.cy + orb.r * 0.55f - scroll.offset
        val limit = M.HEADER_H + env.insetTop
        mini.alpha = Easing.clamp01((limit - orbScreenBottom + 6f) / 36f)
        return a
    }

    override fun draw(g: Gfx, env: Env) {
        val p = scroll.pull
        if (p > 2f) {
            // Çekme ipucu: içeriğin üstünde açılan boşlukta, çekildikçe belirir ve döner.
            val ready = p >= Scroller.PULL_TRIGGER
            val a = Easing.clamp01(p / 48f)
            val cy = header.h + p * 0.5f + 2f
            g.save()
            g.alpha(a)
            val fs = env.sz(13f)
            val text = if (ready) Strings.RELEASE_TO_MEASURE else Strings.PULL_TO_MEASURE
            val tw = env.metrics.textWidth(text, fs, true)
            val x0 = (w - tw - 26f) / 2f
            g.save()
            g.translate(x0 + 9f, cy)
            g.rotate(p * 2.4f)
            Icons.draw(g, Icon.REFRESH, 0f, 0f, 18f, if (ready) env.theme.link else env.theme.textSoft, 2f)
            g.restore()
            g.paint(if (ready) env.theme.link else env.theme.textSoft)
            g.text(text, x0 + 26f, centerBaseline(cy, fs), fs, true, ALIGN_LEFT)
            g.restore()
        }
        super.draw(g, env)
    }
}

// =============================================================================== menü ve hakkında

/** ☰ menüsü: her satır ayrı bir pencere açar. */
class MenuPage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.MENU, true, nav) {
    private var seenVersion = -1
    /** Yalnızca "Gelişmiş ayarları göster" açıkken görünen satırlar (liste tercihleri, deneysel özellikler). */
    private val conds = Conds()

    // Satır değerleri (tema, sorgu sayısı, sürüm…) ayarla değişir; değer başlığa sığmayıp alta inebilir, bu yüzden yerleşim yenilenir.
    override fun tick(dt: Float, env: Env): Boolean {
        val changed = conds.apply(model.settings)
        if (changed || seenVersion != model.version) { seenVersion = model.version; relayoutContent(env) }
        return super.tick(dt, env)
    }

    init {
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.PERSONALIZE, { s -> if (s.theme == Themes.AUTO_ID) Strings.THEME_AUTO else if (s.theme == Themes.DYNAMIC_ID) Strings.themeName(s.theme) else (Themes.byId(s.theme)?.name ?: "") }, Icon.PALETTE) { nav.openPersonalize() })
            c.add(NavRow(Strings.SOUND_MOTION, { s -> if (s.soundOn && s.soundPack != SoundPack.AUTO) Strings.packName(s.soundPack) else "" }, Icon.BELL) { nav.openSection(Section.SOUND) })
        })
        // Koruma: günlük kullanılan ayarlar.
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.DNS_SETTINGS, { Strings.OPT_ENCRYPTION[it.encryption.ordinal] }, Icon.LOCK) { nav.openSection(Section.DNS) })
            c.add(NavRow(Strings.FILTER, { filterSummary(it) }, Icon.BLOCK) { nav.openSection(Section.FILTER) })
            // İzin kapalıysa hiçbir bildirim gelmez: menüde de görünür (açıkken değer boş).
            c.add(NavRow(Strings.SEC_NOTIF, { if (model.host.notificationsAllowed()) "" else Strings.PERM_BLOCKED }, Icon.BELL) { nav.openSection(Section.NOTIFICATIONS) })
        })
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.STATS_HISTORY, { s -> if (s.totalQueries > 0) Format.count(s.totalQueries) else "" }, Icon.SIGNAL) { nav.openSection(Section.STATS) })
            c.add(NavRow(Strings.ABOUT, { model.host.versionName() }, Icon.INFO) { nav.openAbout() })
        })
        // Gelişmiş: yalnızca "Gelişmiş ayarları göster" açıkken. Ana menüyü sade tutar; buradaki her şey varsayılanla çalışır.
        col.add(conds.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.CONN_APPS, { menuAppsSummary(it) }, Icon.WIFI) { nav.openSection(Section.CONNECTION) })
            c.add(NavRow(Strings.SEC_LIST, null, Icon.SORT) { nav.openSection(Section.LIST) })
            c.add(NavRow(Strings.SEC_DATA, null, Icon.COPY) { nav.openSection(Section.DATA) })
            c.add(NavRow(Strings.SEC_EXPERIMENTAL, null, Icon.BOLT) { nav.openSection(Section.EXPERIMENTAL) })
        }) { it.showAdvanced })
        col.add(SettingsCard().also { c ->
            c.add(ToggleRow(Strings.SHOW_ADVANCED, Strings.SHOW_ADVANCED_NOTE, { it.showAdvanced }, { s, v -> s.copy(showAdvanced = v) }))
        })
        conds.apply(model.settings)
        finish()
    }
}

/** Menüde yalnızca varsayılandan farklı uygulama kapsamı yazılır ("Hepsi" gürültü olurdu). */
private fun menuAppsSummary(s: AppSettings): String = when (s.appScope) {
    AppScope.ALL -> ""
    AppScope.ONLY -> Strings.appsOnly(s.apps.size)
    AppScope.EXCEPT -> Strings.appsExcept(s.apps.size)
}

/** Hakkında: açıklama yazıları, yenilikler, günlük, sistem VPN ayarları, paylaş, puanla, geri bildirim, sürüm. */
class AboutPage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.ABOUT, true, nav) {
    init {
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.HELP_WHY_TITLE, null, Icon.HEART) {
                nav.openInfo(Strings.HELP_WHY_TITLE, listOf(Strings.HELP_WHY_BODY, Strings.HELP_WHY_TAIL))
            })
            c.add(NavRow(Strings.HELP, null, Icon.INFO) { nav.openHelp() })
            c.add(NavRow(Strings.WHATS_NEW, null, Icon.STAR) { nav.openWhatsNew() })
        })
        col.add(SettingsCard().also { c ->
            c.add(NavRow(Strings.LOG, null, Icon.LOG) { nav.openLog() })
            c.add(NavRow(Strings.VPN_SETTINGS, null, Icon.SHIELD) { model.host.openVpnSettings() })
            c.add(NavRow(Strings.FEEDBACK, null, Icon.COPY) { model.host.shareText(model.host.diagnostics()) })
        })
        col.add(SettingsCard().also { c ->
            // Kişisel (Play dışı) sürümde mağaza sayfası yoktur: paylaş/puanla bağlantıları kırık sayfaya giderdi.
            if (!model.host.personalBuild()) {
                c.add(NavRow(Strings.SHARE_APP, null, Icon.HEART) { model.host.shareApp() })
                c.add(NavRow(Strings.RATE_APP, null, Icon.STAR) { model.host.rateApp() })
            }
            c.add(InfoRow(Strings.VERSION) { model.host.versionName() })
        })
        finish()
    }
}

// =============================================================================== kişiselleştirme

/** Kişiselleştirme penceresi: dil, tema, stil, arka plan, simge ve erişilebilirlik/güç seçenekleri. */
class PersonalizePage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.PERSONALIZE, true, nav) {
    private var seenVersion = -1
    private var seenClosed = ""
    private var seenDevice = -1

    private class Fold(val key: String, val title: FoldTitle, val card: SettingsCard)
    private val folds = ArrayList<Fold>()

    /** Açılan bölümün adı: sayfa yeniden yerleşince bölüm ekrana kaydırılır (alt kısımdaki bölüm açılınca içeriği görünsün). */
    private var revealKey: String? = null

    /** Yalnızca ilgili olduğunda görünen düğümler (ör. otomatik tema satırları yalnızca "Otomatik" seçiliyken). */
    private val conds = Conds()
    private fun <T : Node> whenTrue(n: T, f: (AppSettings) -> Boolean): T = conds.add(n, f)

    /** Katlanabilir başlık + kart. Kapalı bölümler kaydedilir ([PzFolds]); kapalıyken başlığın sağında özet görünür. */
    private fun fold(key: String, title: String, summary: (AppSettings) -> String, build: (SettingsCard) -> Unit) {
        val card = SettingsCard().also(build)
        card.visible = !PzFolds.isClosed(model.settings.pzClosed, key)
        val ft = FoldTitle(title, { !PzFolds.isClosed(model.settings.pzClosed, key) }, { toggleFold(key) }, { summary(model.settings) }, { toggleAllFolds() })
        col.add(ft)
        col.add(card)
        folds.add(Fold(key, ft, card))
    }

    private fun toggleFold(key: String) {
        val opening = PzFolds.isClosed(model.settings.pzClosed, key)
        model.update { it.copy(pzClosed = PzFolds.toggle(it.pzClosed, key)) }
        revealKey = if (opening) key else null
    }

    /** Uzun basış: hepsi açıksa hepsini kapatır, değilse hepsini açar. */
    private fun toggleAllFolds() {
        val next = PzFolds.toggleAll(model.settings.pzClosed)
        model.update { it.copy(pzClosed = next) }
        model.toast(if (next.isEmpty()) Strings.PZ_UNFOLDED else Strings.PZ_FOLDED)
    }

    // Satırların değeri ayar değişince değişir; başlıkla sığmayan değer alta iner; koşullu satırlar ve katlanan bölümler yerleşimi değiştirir.
    override fun tick(dt: Float, env: Env): Boolean {
        val s = model.settings
        val condChanged = conds.apply(s)
        val foldChanged = seenClosed != s.pzClosed
        if (foldChanged) {
            seenClosed = s.pzClosed
            for (i in 0 until folds.size) { val f = folds[i]; f.card.visible = !PzFolds.isClosed(s.pzClosed, f.key) }
        }
        if (condChanged || foldChanged || seenVersion != model.version || seenDevice != DeviceTune.rev) {
            seenVersion = model.version; seenDevice = DeviceTune.rev
            relayoutContent(env)
            revealOpened()
        }
        return super.tick(dt, env)
    }

    /** Yeni açılan bölüm görünür alanın altında kalıyorsa, kartı sığacak kadar (olabildiğince başlığı da) yukarı kaydırır. */
    private fun revealOpened() {
        val key = revealKey ?: return
        revealKey = null
        val f = folds.firstOrNull { it.key == key } ?: return
        val vh = scroll.h
        val bottom = f.card.y + f.card.h + 16f
        val off = scroll.offset
        if (bottom <= off + vh) return
        val want = minOf(bottom - vh, f.title.y - header.h - 6f)
        if (want > off) scroll.scrollTo(want)
    }

    init {
        // 1) Canlı önizleme
        col.add(LookPreview(model) { openLookPresets(nav) })

        // 2) Tema ve renk: gruplanmış renkler; otomatik tema ayarları yalnızca "Otomatik" seçiliyken
        fold("theme", Strings.SEC_THEME_COLOR, { s -> if (s.theme == Themes.AUTO_ID) Strings.THEME_AUTO else themeName(s.theme) }) { c ->
            c.add(SwatchRow())
            c.add(whenTrue(NavRow(Strings.AUTO_LIGHT, { themeName(it.autoLight) }) { openAutoTheme(nav, dark = false) }) { it.theme == Themes.AUTO_ID })
            c.add(whenTrue(NavRow(Strings.AUTO_DARK, { themeName(it.autoDark) }) { openAutoTheme(nav, dark = true) }) { it.theme == Themes.AUTO_ID })
            c.add(whenTrue(ToggleRow(Strings.THEME_SCHEDULE, Strings.THEME_SCHEDULE_NOTE, { it.themeSchedule }, { s, v -> s.copy(themeSchedule = v) })) { it.theme == Themes.AUTO_ID })
            c.add(whenTrue(SegmentRow(Strings.NIGHT_HOURS, NightHours.values().map { it.label }, { it.nightHours.ordinal }, { s, i -> s.copy(nightHours = NightHours.values()[i]) })) { it.theme == Themes.AUTO_ID && it.themeSchedule })
        }

        // 3) Biçim ve küre
        fold("shape", Strings.SEC_SHAPE, { it.style.label }) { c ->
            c.add(NavRow(Strings.STYLE, { it.style.label }) { openStyle(nav) })
            c.add(NavRow(Strings.CUSTOM_STYLE, { s -> s.savedStyles.count { it.isNotEmpty() }.let { n -> if (n > 0) "$n/${SavedStyles.MAX}" else "" } }, Icon.STAR) { nav.openCustomStyle() })
            c.add(NavRow(Strings.ORB_SHAPE, { Strings.orbShapeName(OrbShapes.get(it.orbShapes, model.shownThemeId)) }) { openOrbShape(nav, model.shownThemeId) })
            c.add(NavRow(Strings.ORB_SHAPE_EACH, { s -> OrbShapes.decode(s.orbShapes).size.let { n -> if (n > 0) "$n/${Themes.all.size}" else "" } }) { openOrbShapeThemes(nav) })
            c.add(NavRow(Strings.ORB_FLOW, { Strings.orbFlowName(it.orbFlow) }) { openOrbFlow(nav) })
            c.add(NavRow(Strings.LIQUID_COLOR, { if (it.liquidColor.isEmpty()) Strings.LIQUID_THEME else "#" + it.liquidColor }) { nav.openLiquidColor() })
        }

        // 4) Arka plan: karartma ve bulanıklık yalnızca fotoğraf varken
        fold("bg", Strings.PZ_BACKGROUND, { if (it.wallpaper) Strings.WP_ON else Strings.WP_OFF }) { c ->
            c.add(NavRow(Strings.WALLPAPER, { if (it.wallpaper) Strings.WP_ON else Strings.WP_OFF }) { openWallpaper(nav) })
            c.add(whenTrue(SliderRow(Strings.WP_DIM, { it.wpDim / WallpaperMath.DIM_MAX }, { s, v -> s.copy(wpDim = v * WallpaperMath.DIM_MAX) }, { Strings.percent((it.wpDim * 100).roundToInt()) })) { it.wallpaper })
            c.add(whenTrue(SegmentRow(Strings.WP_BLUR, Strings.OPT_WP_BLUR, { it.wpBlur.ordinal }, { s, i -> s.copy(wpBlur = WpBlur.values()[i]) })) { it.wallpaper })
        }

        // 5) His: hazır görünümler, cam, yazı boyutu, hareket
        fold("feel", Strings.PZ_FEEL, { s -> Look.match(s)?.let { Strings.OPT_PRESET[it.ordinal] } ?: Strings.PZ_PRESET_CUSTOM }) { c ->
            c.add(NavRow(Strings.PRESET, { s -> Look.match(s)?.let { Strings.OPT_PRESET[it.ordinal] } ?: Strings.PZ_PRESET_CUSTOM }, Icon.PALETTE) { openLookPresets(nav) })
            // Yüksek kontrastta cam zaten tam opak çizilir: kaydırıcının etkisi yok, gizlenir.
            c.add(whenTrue(SliderRow(Strings.GLASS, { it.glass }, { s, v -> s.copy(glass = v) }, { Strings.percent((it.glass * 100).roundToInt()) })) { !it.highContrast })
            c.add(SegmentRow(Strings.TEXT_SIZE, Strings.OPT_TEXT, { it.textScale.ordinal }, { s, i -> s.copy(textScale = TextScale.values()[i]) },
                noteFn = { Strings.percent((it.textScale.factor * 100).roundToInt()) }))
            // Sıra: Yok · Az · Tam (her dilde). Kabarcıklar ayrı satır değil; miktarı bu seviyeden gelir.
            c.add(SegmentRow(Strings.MOTION, MOTION_ORDER.map { Strings.OPT_MOTION[MOTION_LABEL_INDEX.getValue(it)] },
                { MOTION_ORDER.indexOf(it.motion) }, { s, i -> s.copy(motion = MOTION_ORDER[i]) },
                noteFn = { s -> if (s.lowPower) Strings.MOTION_NOTE_LOWPOWER else if (s.motionAdapted) Strings.MOTION_NOTE_DEVICE else "" }))
        }

        // 6) Erişilebilirlik ve güç
        fold("access", Strings.PZ_ACCESS, { s -> accessSummary(s) }) { c ->
            c.add(ToggleRow(Strings.HIGH_CONTRAST, Strings.HIGH_CONTRAST_NOTE, { it.highContrast }, { s, v -> s.copy(highContrast = v) }))
            c.add(ToggleRow(Strings.MINIMAL, Strings.MINIMAL_NOTE, { it.minimal }, { s, v -> s.copy(minimal = v) }))
            c.add(ToggleRow(Strings.LOW_POWER, Strings.LOW_POWER_NOTE, { it.lowPower }, { s, v -> s.copy(lowPower = v) }))
            if (model.host.hasVibrator()) c.add(ToggleRow(Strings.HAPTICS, Strings.HAPTICS_NOTE, { it.haptics }, { s, v -> s.copy(haptics = v) }))
        }

        // 7) Bu cihaz: tanınan sistem ve cihaza göre ayar
        fold("device", Strings.THIS_DEVICE, { DeviceTune.profile?.systemLabel ?: "" }) { c ->
            c.add(NavRow(Strings.DEVICE_SYSTEM, { DeviceTune.profile?.systemLabel ?: "" }, Icon.PHONE) { openDevice(nav) })
            c.add(ToggleRow(Strings.DEVICE_AUTO, Strings.DEVICE_AUTO_NOTE, { it.deviceAuto }, { s, v -> s.copy(deviceAuto = v) }))
        }

        // 8) Dil ve simge: nadir değişen ayarlar sayfanın sonunda
        fold("lang", Strings.SEC_LANG_ICON, { langName(it.lang) }) { c ->
            c.add(NavRow(Strings.LANGUAGE, { langName(it.lang) }, Icon.GLOBE) { openLanguage(nav) })
            c.add(NavRow(Strings.APP_ICON, { model.settings.appIcon.label }) { openAppIcon(nav) })
        }

        // 9) Sıfırla: yalnızca varsayılandan farklı bir görünüm ayarı varken görünür; değerde kaç ayarın farklı olduğu yazar
        col.add(whenTrue(SettingsCard().also { c ->
            c.add(NavRow(Strings.RESET_LOOK, { Look.changedCount(it).toString() }, Icon.REFRESH) {
                nav.openInfo(Strings.RESET_LOOK, listOf(Strings.RESET_LOOK_BODY), Strings.RESET_LOOK_BTN) { model.resetLook() }
            })
        }) { Look.changedCount(it) > 0 })
        conds.apply(model.settings)      // ilk yerleşim doğru görünürlükle başlasın (bir kare yanlış satır görünmesin)
        finish()
    }

    /** Kapalı "Erişilebilirlik ve güç" bölümünün özeti: açık seçenek sayısı ("2/4"); hiçbiri açık değilse boş. */
    private fun accessSummary(s: AppSettings): String {
        val vib = model.host.hasVibrator()
        val n = (if (s.highContrast) 1 else 0) + (if (s.minimal) 1 else 0) + (if (s.lowPower) 1 else 0) + (if (vib && s.haptics) 1 else 0)
        return if (n == 0) "" else "$n/${if (vib) 4 else 3}"
    }

    private companion object {
        /** Ekranda gösterim sırası: Yok, Az, Tam. */
        val MOTION_ORDER = listOf(Motion.OFF, Motion.REDUCED, Motion.FULL)
        /** OPT_MOTION etiketleri enum sırasına göre (0 Tam, 1 Az, 2 Yok): her Motion için etiket dizini. */
        val MOTION_LABEL_INDEX = mapOf(Motion.FULL to 0, Motion.REDUCED to 1, Motion.OFF to 2)
    }

    private fun themeName(id: String): String = if (id == Themes.DYNAMIC_ID) Strings.themeName(id) else (Themes.byId(id)?.name ?: id)

    /** Satırdaki kısa değer: "Otomatik" ya da dilin kendi adı. */
    private fun langName(setting: String): String = if (setting == L.AUTO) Strings.THEME_AUTO else (Lang.byCode(setting)?.native ?: Strings.THEME_AUTO)

    private fun openLookPresets(nav: Nav) {
        val cur = Look.match(model.settings)
        val opts = LookPreset.values().map { Option(it.name, Strings.OPT_PRESET[it.ordinal], Strings.PRESET_NOTES[it.ordinal], it == cur) }
        nav.openOptions(Strings.PRESET, opts, footer = Strings.PRESET_FOOT) { id -> LookPreset.values().firstOrNull { it.name == id }?.let { model.applyLookPreset(it) } }
    }

    /** Tanınan cihaz: ad, sistem, sınıf, kapatılma riski, uygulanan otomatik ayar ve üreticiye özel öneriler; gerekirse pil ayarı düğmesi. */
    private fun openDevice(nav: Nav) {
        val p = DeviceTune.profile
        if (p == null) { nav.openInfo(Strings.THIS_DEVICE, listOf(Strings.DEVICE_UNKNOWN)); return }
        val lines = ArrayList<String>()
        lines.add(p.name)
        lines.add(Strings.DEVICE_SYSTEM + ": " + p.systemLabel)
        val ram = if (p.info.ramMb > 0) " · " + ((p.info.ramMb + 512) / 1024) + " GB" else ""
        lines.add(Strings.DEVICE_CLASS + ": " + Strings.OPT_TIER[p.tier.ordinal] + ram + " · " + p.info.refreshHz + " Hz")
        lines.add(Strings.DEVICE_RISK + ": " + Strings.OPT_RISK[p.kill.ordinal])
        if (model.settings.motionAdapted) lines.add(Strings.DEVICE_APPLIED_MOTION)
        else if (!model.settings.deviceAuto) lines.add(Strings.DEVICE_OFF_NOTE)
        for (a in p.advice) lines.add(Strings.DEVICE_ADVICE[a.ordinal])
        val battery = p.kill != KillRisk.LOW
        nav.openInfo(Strings.THIS_DEVICE, lines, if (battery) Strings.BATTERY_BUTTON else null) { if (battery) model.host.openBatterySettings() }
    }

    private fun openLanguage(nav: Nav) {
        val cur = model.settings.lang
        val opts = ArrayList<Option>()
        opts.add(Option(L.AUTO, Strings.LANG_AUTO, L.lang.native, cur == L.AUTO))
        for (l in Lang.values()) opts.add(Option(l.code, l.native, "", cur == l.code))
        nav.openOptions(Strings.LANGUAGE, opts) { id -> if (id != null) model.setLanguage(id) }
    }

    /** "Otomatik" temanın açık ya da koyu modda kullanacağı tema; duvar kağıdı teması varsa o da seçilebilir. */
    private fun openAutoTheme(nav: Nav, dark: Boolean) {
        val cur = if (dark) model.settings.autoDark else model.settings.autoLight
        val opts = ArrayList<Option>()
        if (model.accentSeed != null) opts.add(Option(Themes.DYNAMIC_ID, Strings.themeName(Themes.DYNAMIC_ID), "", cur == Themes.DYNAMIC_ID))
        for (t in Themes.all.filter { it.dark == dark }) opts.add(Option(t.id, t.name, "", cur == t.id))
        nav.openOptions(if (dark) Strings.AUTO_DARK else Strings.AUTO_LIGHT, opts) { id ->
            if (id != null) model.update { if (dark) it.copy(autoDark = id) else it.copy(autoLight = id) }
        }
    }

    private fun openStyle(nav: Nav) {
        val cur = model.settings.style
        val opts = UiStyle.values().mapIndexed { i, st -> Option(st.id, st.label, Strings.STYLE_NOTES[i], cur == st) }
        nav.openOptions(Strings.STYLE, opts) { id -> UiStyle.byId(id)?.let { st -> model.update { it.copy(style = st) } } }
    }

    /** [themeId] teması için ana düğme şeklini seçtirir (küre, üçgen, kare, altıgen, yıldız). */
    private fun openOrbFlow(nav: Nav) {
        val cur = model.settings.orbFlow
        val opts = OrbFlow.values().map { Option(it.id, Strings.orbFlowName(it), "", it == cur) }
        nav.openOptions(Strings.ORB_FLOW, opts) { id -> OrbFlow.byId(id)?.let { model.setOrbFlow(it) } }
    }

    private fun openOrbShape(nav: Nav, themeId: String) {
        val cur = model.orbShapeFor(themeId)
        val opts = OrbShape.values().map { Option(it.id, Strings.orbShapeName(it), "", it == cur) }
        nav.openOptions(Strings.ORB_SHAPE + ": " + Strings.themeName(themeId), opts) { id -> OrbShape.byId(id)?.let { model.setOrbShape(themeId, it) } }
    }

    /** Tema başına şekil: 12 temanın her biri ayrı listelenir, seçilen temanın şekil penceresi açılır. */
    private fun openOrbShapeThemes(nav: Nav) {
        val opts = Themes.all.map { t -> Option(t.id, Strings.themeName(t.id), Strings.orbShapeName(model.orbShapeFor(t.id)), t.id == model.shownThemeId) }
        nav.openOptions(Strings.ORB_SHAPE_EACH, opts) { id -> if (id != null) openOrbShape(nav, id) }
    }

    private fun openAppIcon(nav: Nav) {
        val cur = model.settings.appIcon
        val opts = UiStyle.values().mapIndexed { i, st -> Option(st.id, st.label, Strings.ICON_NOTES[i], cur == st) }
        nav.openOptions(Strings.APP_ICON, opts, footer = Strings.ICON_NOTE) { id -> UiStyle.byId(id)?.let { model.setAppIcon(it) } }
    }

    private fun openWallpaper(nav: Nav) {
        val opts = ArrayList<Option>()
        opts.add(Option("pick", Strings.WP_PICK, Strings.WP_PICK_NOTE))
        opts.add(Option("presets", Strings.WP_PRESETS, Strings.WP_PRESETS_NOTE))
        if (model.settings.wallpaper) opts.add(Option("remove", Strings.WP_REMOVE))
        nav.openOptions(Strings.WALLPAPER, opts) { id ->
            when (id) {
                "pick" -> model.pickWallpaper()
                "remove" -> model.removeWallpaper()
                "presets" -> openPresets(nav)
            }
        }
    }

    private fun openPresets(nav: Nav) {
        val opts = WallpaperPresets.NAMES.mapIndexed { i, n -> Option("p$i", n) }
        nav.openOptions(Strings.WP_PRESETS, opts) { id ->
            val i = id?.removePrefix("p")?.toIntOrNull()
            if (i != null && i in WallpaperPresets.NAMES.indices) model.usePresetWallpaper(i)
        }
    }
}

// =============================================================================== ayar pencereleri

/** Ayar pencereleri: ☰ menüsündeki her satır birini açar. */
enum class Section { DNS, FILTER, CONNECTION, NOTIFICATIONS, LIST, STATS, DATA, SOUND, EXPERIMENTAL }

private fun sectionTitle(s: Section): String = when (s) {
    Section.DNS -> Strings.DNS_SETTINGS
    Section.FILTER -> Strings.FILTER
    Section.CONNECTION -> Strings.CONN_APPS
    Section.NOTIFICATIONS -> Strings.SEC_NOTIF
    Section.LIST -> Strings.SEC_LIST
    Section.STATS -> Strings.STATS_HISTORY
    Section.DATA -> Strings.SEC_DATA
    Section.SOUND -> Strings.SOUND_MOTION
    Section.EXPERIMENTAL -> Strings.SEC_EXPERIMENTAL
}

class SectionPage(private val model: AppModel, nav: Nav, val section: Section) : ScrollPage(sectionTitle(section), true, nav) {
    private var seenVersion = -1

    /** Yalnızca ilgili olduğunda görünen satırlar ve kartlar (ör. şifreleme "Şifresiz" iken "Katı şifreleme" gizlenir). */
    private val conds = Conds()

    /** Bildirim izni: sistem sorgusu her karede yapılmaz, model değişince yenilenir. */
    private var notifOk = true

    // Satırların değeri ayar değişince değişir; başlıkla sığmayan değer alta iner, koşullu satırlar çıkıp kaybolur: yerleşim yenilenir.
    override fun tick(dt: Float, env: Env): Boolean {
        if (seenVersion != model.version && section == Section.NOTIFICATIONS) notifOk = model.host.notificationsAllowed()
        val changed = conds.apply(model.settings)
        if (changed || seenVersion != model.version) { seenVersion = model.version; relayoutContent(env) }
        return super.tick(dt, env)
    }

    init {
        if (section == Section.NOTIFICATIONS) notifOk = model.host.notificationsAllowed()
        when (section) {
            Section.DNS -> buildDns(nav)
            Section.FILTER -> buildFilter(nav)
            Section.CONNECTION -> buildConnection(nav)
            Section.NOTIFICATIONS -> buildNotifications()
            Section.LIST -> buildList(nav)
            Section.STATS -> buildStats(nav)
            Section.DATA -> buildData()
            Section.SOUND -> buildSound()
            Section.EXPERIMENTAL -> buildExperimental(nav)
        }
        conds.apply(model.settings)      // ilk yerleşim doğru görünürlükle başlasın
        finish()
    }

    private fun card(build: (SettingsCard) -> Unit) { col.add(SettingsCard().also(build)) }

    /** Yalnızca [test] doğruyken görünen kart. */
    private fun condCard(test: (AppSettings) -> Boolean, build: (SettingsCard) -> Unit) { col.add(conds.add(SettingsCard().also(build), test)) }

    private fun <T : Node> whenTrue(n: T, test: (AppSettings) -> Boolean): T = conds.add(n, test)

    /** Gelişmiş: yalnızca menüde "Gelişmiş ayarları göster" açıkken görünür; gizliyken ayarın değeri çalışmaya devam eder. */
    private fun <T : Node> advanced(n: T): T = conds.add(n) { it.showAdvanced }

    private fun buildDns(nav: Nav) {
        card { c ->
            c.add(NavRow(Strings.PROFILES, null, Icon.SHIELD) { openProfiles(nav) })
            c.add(advanced(ToggleRow(Strings.REMEMBER_MODS, Strings.REMEMBER_MODS_NOTE, { it.rememberModules }, { s, v -> s.copy(rememberModules = v) })))
        }
        card { c ->
            c.add(SegmentRow(Strings.ENCRYPTION, Strings.OPT_ENCRYPTION, { it.encryption.ordinal }, { s, i -> s.copy(encryption = Encryption.values()[i]) }, Strings.ENCRYPTION_NOTE))
            // "Katı şifreleme" yalnızca Otomatik'te anlamlı: seçilen yöntem sabitken şifresiz DNS'e düşme zaten yok.
            c.add(whenTrue(ToggleRow(Strings.STRICT_ENC, Strings.STRICT_ENC_NOTE, { it.strictEncryption }, { s, v -> s.copy(strictEncryption = v) })) { it.encryption == Encryption.AUTO })
            c.add(whenTrue(ToggleRow(Strings.QUIC_DNS, Strings.QUIC_DNS_NOTE, { it.quicDns }, { s, v -> s.copy(quicDns = v) })) { it.showAdvanced && it.encryption != Encryption.OFF })
            c.add(advanced(SegmentRow(Strings.ODOH, Strings.OPT_ODOH, { it.odoh.ordinal }, { s, i -> s.copy(odoh = OdohMode.values()[i]) }, Strings.ODOH_NOTE)))
            c.add(advanced(SegmentRow(Strings.IP_MODE, Strings.OPT_IP_MODE, { it.ipMode.ordinal }, { s, i -> s.copy(ipMode = IpMode.values()[i]) }, Strings.IP_MODE_NOTE)))
        }
        condCard({ it.showAdvanced }) { c ->
            c.add(NavRow(Strings.BACKUP_SERVER, { backupName(it.backupServer) }) { openBackup(nav) })
            c.add(NavRow(Strings.RULE_WIFI, { ruleName(it.wifiServer) }) {
                nav.openChoice(Strings.RULE_WIFI, model.settings.wifiServer) { id -> model.update { it.copy(wifiServer = id) } }
            })
            c.add(NavRow(Strings.RULE_MOBILE, { ruleName(it.mobileServer) }) {
                nav.openChoice(Strings.RULE_MOBILE, model.settings.mobileServer) { id -> model.update { it.copy(mobileServer = id) } }
            })
        }
        card { c ->
            c.add(SegmentRow(Strings.CACHE, Strings.OPT_CACHE, { it.cache.ordinal }, { s, i -> s.copy(cache = CacheLevel.values()[i]) }))
            c.add(whenTrue(NavRow(Strings.CLEAR_CACHE, null, Icon.REFRESH) { model.clearCache() }) { it.cache != CacheLevel.OFF })
        }
        card { c ->
            c.add(NavRow(Strings.TEST, { if (model.testing) Strings.TESTING else "" }, Icon.CHECK) { nav.openTest() })
            c.add(advanced(NavRow(Strings.TROUBLE, null, Icon.INFO) { openTrouble(nav) }))
            c.add(advanced(NavRow(Strings.DIAG_ROW, null, Icon.INFO) { openDiag(nav) }))
        }
    }

    private fun buildFilter(nav: Nav) {
        card { c ->
            c.add(SegmentRow(Strings.FILTER_LEVEL, Strings.OPT_FILTER, { it.filterLevel.ordinal }, { s, i -> s.copy(filterLevel = FilterLevel.values()[i]) },
                noteFn = { Strings.FILTER_NOTES[it.filterLevel.ordinal] }))
            c.add(InfoRow(Strings.STAT_BLOCKED) { Format.count(FilterLive.blockedTotal) })
            c.add(advanced(ToggleRow(Strings.REBIND, Strings.REBIND_NOTE, { it.rebindGuard }, { s, v -> s.copy(rebindGuard = v) })))
            c.add(whenTrue(SegmentRow(Strings.FILTER_MEM, Strings.OPT_FILTER_MEM, { it.filterMem.ordinal }, { s, i -> s.copy(filterMem = FilterMem.values()[i]) }, noteFn = { Strings.FILTER_MEM_NOTE })) { it.showAdvanced && it.filterLevel != FilterLevel.OFF })
        }
        card { c ->
            // Süzgeç kapalıyken "son engellenenler / geçenler" listeleri boştur: gizlenir.
            // Ağ geçidi (Reklam+ / kendi listeler) DNS süzgeci kapalıyken de süzer ve kayıt tutar: o durumda da gösterilir.
            val listsLive: (AppSettings) -> Boolean = { it.filterLevel != FilterLevel.OFF || it.adsPlus || it.filterBlock.isNotEmpty() || it.filterAllow.isNotEmpty() }
            c.add(whenTrue(NavRow(Strings.FILTER_LAST, { FilterLive.recent().size.let { n -> if (n == 0) "" else n.toString() } }, Icon.LOG) { openRecentBlocked(nav) }, listsLive))
            c.add(whenTrue(NavRow(Strings.FILTER_PASSED, { FilterLive.recentPassed().size.let { n -> if (n == 0) "" else n.toString() } }, Icon.LOG) { openRecentPassed(nav) }) { it.showAdvanced && listsLive(it) })
            c.add(NavRow(Strings.FILTER_ALLOW, { if (it.filterAllow.isEmpty()) "" else it.filterAllow.size.toString() }, Icon.CHECK) { openFilterList(nav, true) })
            c.add(NavRow(Strings.FILTER_BLOCK, { if (it.filterBlock.isEmpty()) "" else it.filterBlock.size.toString() }, Icon.BLOCK) { openFilterList(nav, false) })
            if (model.host.personalBuild()) c.add(ToggleRow(Strings.YT_ADS, Strings.YT_ADS_NOTE, { it.youtubeAds }, { s, v -> s.copy(youtubeAds = v) }))
            c.add(NavRow(Strings.FILTER_MINE, { if (model.importedCount == 0) "" else Format.count(model.importedCount.toLong()) }, Icon.COPY) { openMine(nav) })
            c.add(NavRow(Strings.SITE_DIAG, null, Icon.INFO) { openSiteDiag(nav) })       // "site neden açılmıyor?" tam burada lazım
            c.add(ToggleRow(Strings.DOH_GUARD, Strings.DOH_GUARD_NOTE, { it.dohGuard }, { s, v -> s.copy(dohGuard = v) }))
            c.add(NavRow(AppAdsText.t("title"), { s -> AppAds.decode(s.appAds).size.let { n -> if (n == 0) "" else AppAdsText.t("summary", L.lang, n.toString()) } }, Icon.INFO) { openAppAds(nav) })
            c.add(advanced(NavRow(AppAdsText.t("hTitle"), null, Icon.CHECK) { openHealth(nav) }))
        }
        col.add(ParagraphCard(Strings.FILTER_INFO))
    }

    // ---- uygulama bazlı reklam engelleme -------------------------------------------------------------------------------------

    private fun appTag(pkg: String): String = when (AppAds.decode(model.settings.appAds)[pkg]) {
        AppMode.EXEMPT -> AppAdsText.t("tagExempt")
        AppMode.STRICT -> AppAdsText.t("tagStrict")
        else -> ""
    }

    /** İstatistik + bozulmuş olabilecek uygulamalar + kurallı uygulamalar + "uygulama ekle". Satıra dokununca kip/kurtarma seçilir. */
    private fun openAppAds(nav: Nav) {
        val opts = ArrayList<Option>()
        val seen = HashSet<String>()
        for (s in AppAds.suspects()) {
            seen.add(s.pkg)
            opts.add(Option(SUSPECT_PREFIX + s.pkg, AppAds.labeler(s.pkg), AppAdsText.t("suspect") + ": " + s.name + " " + s.count + "×", icon = Icon.BLOCK, badge = appTag(s.pkg)))
        }
        val rows = AppAds.top(40)
        for (r in rows) {
            if (!seen.add(r.pkg)) continue
            val tag = appTag(r.pkg)
            opts.add(Option(APP_PREFIX + r.pkg, AppAds.labeler(r.pkg), r.top.joinToString(", ") { it.first }, icon = Icon.INFO, badge = if (tag.isEmpty()) "${r.blocked}×" else "${r.blocked}× · $tag"))
        }
        for ((pkg, _) in AppAds.decode(model.settings.appAds)) {
            if (!seen.add(pkg)) continue
            opts.add(Option(APP_PREFIX + pkg, AppAds.labeler(pkg), "", icon = Icon.INFO, badge = appTag(pkg)))
        }
        opts.add(Option(ADD_ID, AppAdsText.t("pick"), "", icon = Icon.PLUS))
        if (rows.isNotEmpty()) opts.add(Option(RESET_ID, AppAdsText.t("reset"), "", icon = Icon.CLOSE))
        val foot = AppAdsText.t("foot") + if (model.host.androidSdk() < 29) "\n\n" + AppAdsText.t("foot29") else ""
        nav.openOptions(AppAdsText.t("title"), opts, AppAdsText.t("empty"), foot) { id ->
            when {
                id == null -> {}
                id == ADD_ID -> openAppPicker(nav)
                id == RESET_ID -> { AppAds.clearStats(); openAppAds(nav) }
                id.startsWith(SUSPECT_PREFIX) -> openAppRescue(nav, id.removePrefix(SUSPECT_PREFIX))
                id.startsWith(APP_PREFIX) -> openAppMode(nav, id.removePrefix(APP_PREFIX))
            }
        }
    }

    private fun openAppPicker(nav: Nav) {
        model.loadApps()
        val list = model.apps ?: emptyList()
        val opts = list.map { Option(it.pkg, it.label, it.pkg, icon = Icon.PLUS, badge = appTag(it.pkg)) }
        nav.openOptions(AppAdsText.t("pickTitle"), opts, "", "") { id -> if (id != null) openAppMode(nav, id) }
    }

    private fun openAppMode(nav: Nav, pkg: String) {
        val cur = AppAds.decode(model.settings.appAds)[pkg] ?: AppMode.NORMAL
        val opts = listOf(
            Option(AppMode.NORMAL.name, AppAdsText.t("normal"), "", selected = cur == AppMode.NORMAL),
            Option(AppMode.EXEMPT.name, AppAdsText.t("exempt"), "", selected = cur == AppMode.EXEMPT),
            Option(AppMode.STRICT.name, AppAdsText.t("strict"), "", selected = cur == AppMode.STRICT),
        )
        nav.openOptions(AppAds.labeler(pkg), opts, "", "") { id ->
            val m = AppMode.values().firstOrNull { it.name == id }
            if (m != null) { model.setAppMode(pkg, m); openAppAds(nav) }
        }
    }

    /** Bozulmuş olabilecek uygulama: muaf tut, engellenen adlara izin ver ya da yok say. */
    private fun openAppRescue(nav: Nav, pkg: String) {
        val names = AppAds.namesOf(pkg)
        val opts = listOf(
            Option(RESCUE_EXEMPT, AppAdsText.t("rescueExempt"), "", icon = Icon.CHECK),
            Option(RESCUE_ALLOW, AppAdsText.t("rescueAllow", L.lang, names.size.toString()), names.joinToString(", "), icon = Icon.CHECK),
            Option(RESCUE_IGNORE, AppAdsText.t("ignore"), "", icon = Icon.CLOSE),
        )
        nav.openOptions(AppAds.labeler(pkg), opts, "", "") { id ->
            when (id) {
                RESCUE_EXEMPT -> { model.setAppMode(pkg, AppMode.EXEMPT); model.toast(AppAdsText.t("doneExempt", L.lang, AppAds.labeler(pkg))); openAppAds(nav) }
                RESCUE_ALLOW -> { val n = model.allowAppNames(pkg); model.toast(AppAdsText.t("doneAllow", L.lang, n.toString())); openAppAds(nav) }
                RESCUE_IGNORE -> { AppAds.dismiss(pkg); openAppAds(nav) }
                else -> {}
            }
        }
    }

    /** "12×": kaç kez engellendi/geçti. Bir kezse boş (gürültü olmasın). */
    private fun hits(n: Int): String = if (n > 1) "$n×" else ""

    /** Bu oturumda engellenenler: dokununca izin listesine eklenir ("site bozuldu" çaresi). Sağda kaç kez engellendiği yazar. */
    private fun openRecentBlocked(nav: Nav) {
        val items = FilterLive.recent()
        val opts = ArrayList<Option>()
        for (e in items) opts.add(Option(e.name, e.name, if (e.user) Strings.FILTER_BLOCK else Strings.FILTER_RECENT_NOTE, icon = Icon.CHECK, badge = hits(e.count), domain = true))
        if (items.isNotEmpty()) opts.add(Option(COPY_ID, Strings.COPY, Strings.mineCount(items.size), icon = Icon.COPY))
        nav.openOptions(Strings.FILTER_LAST, opts, Strings.FILTER_RECENT_EMPTY, Strings.FILTER_RECENT_FOOT) { id ->
            when (id) {
                null -> {}
                COPY_ID -> model.copyNames(items.map { it.name })
                else -> model.addFilterName(true, id)
            }
        }
    }

    /**
     * Bu oturumda süzgeçten geçen adlar: reklam hâlâ görünüyorsa kaçan sunucuyu bulup tek dokunuşla engellemek için.
     * Dokununca ad kendi engel listesine girer ve bu listeden çıkar. Reklama benzeyenler başta, en sık görülen en üstte.
     */
    private fun openRecentPassed(nav: Nav) {
        val all = FilterLive.recentPassed()
        val suspectItems = all.filter { AdSuspect.isSuspect(it.name) }.sortedByDescending { it.count }    // kararlı: eşitlikte yenisi önde
        val suspects = suspectItems.map { it.name }
        val opts = ArrayList<Option>()
        if (suspects.size > 1) opts.add(Option(BLOCK_SUSPECTS, Strings.FILTER_BLOCK_SUSPECTS, Strings.mineCount(suspects.size), icon = Icon.BLOCK))
        for (e in suspectItems) opts.add(Option(e.name, e.name, Strings.FILTER_SUSPECT_NOTE, icon = Icon.BLOCK, badge = hits(e.count), domain = true))
        for (e in all) if (e.name !in suspects) opts.add(Option(e.name, e.name, Strings.FILTER_PASSED_NOTE, icon = Icon.BLOCK, badge = hits(e.count), domain = true))
        if (all.isNotEmpty()) opts.add(Option(COPY_ID, Strings.COPY, Strings.mineCount(all.size), icon = Icon.COPY))
        nav.openOptions(Strings.FILTER_PASSED, opts, Strings.FILTER_PASSED_EMPTY, Strings.FILTER_PASSED_FOOT) { id ->
            when {
                id == null -> {}
                id == COPY_ID -> model.copyNames(all.map { it.name })
                id == BLOCK_SUSPECTS -> { if (model.addFilterBlocks(suspects)) for (n in suspects) FilterLive.forgetPassed(n) }
                model.addFilterName(false, id) -> FilterLive.forgetPassed(id)
            }
        }
    }

    /** Kendi listem: panodan ya da dosyadan içe aktarma, hosts olarak kopyalama, içe aktarılanları silme. */
    private fun openMine(nav: Nav) {
        val opts = listOf(
            Option(MINE_PASTE, Strings.MINE_PASTE, Strings.MINE_PASTE_NOTE, icon = Icon.PLUS),
            Option(MINE_FILE, Strings.MINE_FILE, Strings.MINE_FILE_NOTE, icon = Icon.LOG),
            Option(MINE_EXPORT, Strings.MINE_EXPORT, Strings.MINE_EXPORT_NOTE, icon = Icon.COPY),
            Option(MINE_CLEAR, Strings.MINE_CLEAR, Strings.mineCount(model.importedCount), icon = Icon.CLOSE),
        )
        nav.openOptions(Strings.FILTER_MINE, opts, "", Strings.MINE_FOOT) { id ->
            when (id) {
                MINE_PASTE -> model.importFromClipboard()
                MINE_FILE -> model.importFromFile()
                MINE_EXPORT -> model.copyBlockList()
                MINE_CLEAR -> model.askClearImported()
                else -> {}
            }
        }
    }

    /** İzin ya da kendi engel listesi: "Ekle…" satırı ve kayıtlı alan adları (dokununca kaldırma sorusu). */
    private fun openFilterList(nav: Nav, allow: Boolean) {
        // Aynı sitenin alt alanları yan yana dizilir ([FilterNames.sorted]); "Ekle…" satırında doluluk (ör. 12/200) görünür.
        val names = FilterNames.sorted(if (allow) model.settings.filterAllow else model.settings.filterBlock)
        val opts = ArrayList<Option>()
        opts.add(Option(ADD_ID, Strings.FILTER_ADD, "", icon = Icon.PLUS, badge = "${names.size}/${FilterNames.MAX_LIST}"))
        for (n in names) opts.add(Option(n, n, Strings.FILTER_REMOVE, icon = Icon.CLOSE, domain = true))
        val title = if (allow) Strings.FILTER_ALLOW else Strings.FILTER_BLOCK
        val foot = if (allow) Strings.FILTER_ALLOW_FOOT else Strings.FILTER_BLOCK_FOOT
        nav.openOptions(title, opts, if (allow) Strings.FILTER_ALLOW_EMPTY else Strings.FILTER_BLOCK_EMPTY, foot) { id ->
            when (id) {
                null -> {}
                ADD_ID -> model.promptFilterName(allow) { openFilterList(nav, allow) }
                else -> model.askRemoveFilterName(allow, id)
            }
        }
    }

    private fun buildConnection(nav: Nav) {
        card { c ->
            c.add(ToggleRow(Strings.AUTO_CONNECT, Strings.AUTO_CONNECT_NOTE, { it.autoConnect }, { s, v -> s.copy(autoConnect = v) }))
            c.add(ToggleRow(Strings.CONNECT_ON_BOOT, Strings.CONNECT_ON_BOOT_NOTE, { it.connectOnBoot }, { s, v -> s.copy(connectOnBoot = v) }))
            c.add(advanced(ToggleRow(Strings.AUTO_FASTEST, Strings.AUTO_FASTEST_NOTE, { it.autoFastest }, { s, v -> s.copy(autoFastest = v) })))
        }
        card { c ->
            c.add(ToggleRow(Strings.AUTO_RECONNECT, Strings.AUTO_RECONNECT_NOTE, { it.autoReconnect }, { s, v -> s.copy(autoReconnect = v) }))
            c.add(ToggleRow(Strings.FAIL_CLOSED, Strings.FAIL_CLOSED_NOTE, { it.failClosed }, { s, v -> s.copy(failClosed = v) }))
            c.add(advanced(ToggleRow(Strings.REFRESH_ON_NET, Strings.REFRESH_ON_NET_NOTE, { it.refreshOnNetwork }, { s, v -> s.copy(refreshOnNetwork = v) })))
            c.add(ToggleRow(Strings.AUTO_SHIELD, Strings.AUTO_SHIELD_NOTE, { it.autoShield }, { s, v -> s.copy(autoShield = v) }))
        }
        card { c ->
            c.add(ToggleRow(Strings.CONFIRM_OFF, Strings.CONFIRM_OFF_NOTE, { it.confirmDisconnect }, { s, v -> s.copy(confirmDisconnect = v) }))
            c.add(advanced(ToggleRow(Strings.BLOCK_QUIC, Strings.BLOCK_QUIC_NOTE, { it.blockQuic }, { s, v -> s.copy(blockQuic = v) })))
        }
        card { c ->
            c.add(NavRow(Strings.APPS, { appsSummary(it) }) { nav.openApps() })
            c.add(NavRow(Strings.GUARD, null, Icon.SHIELD) {
                nav.openInfo(Strings.GUARD, Strings.GUARD_BODY, Strings.GUARD_BUTTON) { model.host.openVpnSettings() }
            })
            c.add(NavRow(Strings.BATTERY, { batteryText() }, Icon.BOLT) {
                nav.openInfo(Strings.BATTERY, Strings.BATTERY_BODY, Strings.BATTERY_BUTTON) { model.host.openBatterySettings() }
            })
        }
    }

    /** Deneysel özellikler: varsayılan kapalı, açık onay ister. */
    private fun buildExperimental(nav: Nav) {
        card { c ->
            c.add(ToggleRow(Strings.DNS_RACE, Strings.DNS_RACE_NOTE, { it.dnsRace }, { s, v -> s.copy(dnsRace = v) }))
            c.add(ToggleRow(Strings.AUTO_DPI, Strings.AUTO_DPI_NOTE, { it.autoDpi }, { s, v -> s.copy(autoDpi = v) }))
            c.add(ToggleRow(Strings.QUIC_SPLIT, Strings.QUIC_SPLIT_NOTE, { it.quicSplit }, { s, v -> s.copy(quicSplit = v) }))
            c.add(ToggleRow(Strings.UDP_DECOY, Strings.UDP_DECOY_NOTE, { it.udpDecoy }, { s, v -> s.copy(udpDecoy = v) }))
            // Android 17+ (API 37) özelliği: düşük sürümde satır hiç oluşturulmaz.
            if (model.host.androidSdk() >= ECH_MIN_SDK) c.add(ToggleRow(Strings.ECH_ALLOW, Strings.ECH_ALLOW_NOTE, { it.echAllow }, { s, v -> s.copy(echAllow = v) }))
            c.add(ToggleRow(Strings.DPI_LISTED_ONLY, Strings.DPI_LISTED_ONLY_NOTE, { it.dpiListedOnly }, { s, v -> s.copy(dpiListedOnly = v) }))
        }
        card { c ->
            c.add(ToggleRow(Strings.MITM_MODE, Strings.MITM_MODE_NOTE, { it.mitmOn }, { s, v -> s.copy(mitmOn = v) }))
            c.add(NavRow(Strings.MITM_CA, null, Icon.SHIELD) {
                nav.openInfo(Strings.MITM_CA, Strings.MITM_CA_BODY, Strings.MITM_CA_BUTTON) { model.host.exportMitmCa() }
            })
        }
    }

    private fun buildNotifications() {
        // İzin kapalıysa hiçbir bildirim gelmez: izin satırı en üste çıkar (açıkken en alttaki yerinde kalır).
        condCard({ !notifOk }) { c ->
            c.add(NavRow(Strings.NOTIF_PERM, { Strings.PERM_BLOCKED }, Icon.INFO) { model.host.openNotificationSettings() })
        }
        card { c ->
            c.add(ToggleRow(Strings.NOTIFY_CONNECT, Strings.NOTIFY_CONNECT_NOTE, { it.notifyConnect }, { s, v -> s.copy(notifyConnect = v) }))
            c.add(ToggleRow(Strings.NOTIFY_DROP, Strings.NOTIFY_DROP_NOTE, { it.notifyDrop }, { s, v -> s.copy(notifyDrop = v) }))
            c.add(advanced(ToggleRow(Strings.NOTIFY_STOP, Strings.NOTIFY_STOP_NOTE, { it.notifyStop }, { s, v -> s.copy(notifyStop = v) })))
            c.add(advanced(ToggleRow(Strings.NOTIFY_TIMEOUT, Strings.NOTIFY_TIMEOUT_NOTE, { it.notifyTimeout }, { s, v -> s.copy(notifyTimeout = v) })))
        }
        card { c ->
            c.add(ToggleRow(Strings.LOCK_HIDE, Strings.LOCK_HIDE_NOTE, { it.hideOnLockscreen }, { s, v -> s.copy(hideOnLockscreen = v) }))
            c.add(advanced(ToggleRow(Strings.QUIET_NOTIF, Strings.QUIET_NOTIF_NOTE, { it.quietNotification }, { s, v -> s.copy(quietNotification = v) })))
            c.add(whenTrue(NavRow(Strings.NOTIF_PERM, { Strings.PERM_ALLOWED }, Icon.INFO) {
                model.host.openNotificationSettings()
            }) { notifOk })
        }
    }

    private fun buildList(nav: Nav) {
        card { c ->
            c.add(NavRow(Strings.RECOMMEND, null, Icon.STAR) { nav.openRecommend() })
            c.add(ToggleRow(Strings.COMPACT, Strings.COMPACT_NOTE, { it.compact }, { s, v -> s.copy(compact = v) }))
            c.add(ToggleRow(Strings.REMEMBER_FILTER, Strings.REMEMBER_FILTER_NOTE, { it.rememberFilter }, { s, v -> s.copy(rememberFilter = v) }))
            c.add(ToggleRow(Strings.AUTO_MEASURE, Strings.AUTO_MEASURE_NOTE, { it.autoMeasure }, { s, v -> s.copy(autoMeasure = v) }))
            c.add(whenTrue(ToggleRow(Strings.MEASURE_ENC, Strings.MEASURE_ENC_NOTE, { it.measureEncrypted }, { s, v -> s.copy(measureEncrypted = v) })) { it.autoMeasure })
            c.add(NavRow(Strings.HIDDEN, { if (it.hidden.isEmpty()) Strings.HIDDEN_NONE else it.hidden.size.toString() }) { openHidden(nav) })
        }
    }

    private fun buildStats(nav: Nav) {
        card { c ->
            c.add(InfoRow(Strings.STAT_QUERIES) { Format.count(it.totalQueries) })
            c.add(InfoRow(Strings.STAT_HITS) { Strings.percent(model.hitPercentTotal()) })
            c.add(InfoRow(Strings.STAT_BLOCKED) { Format.countWithShare(it.totalBlocked, it.totalQueries) })
            c.add(InfoRow(Strings.STAT_TIME) { Format.span(it.totalSeconds) })
            c.add(InfoRow(Strings.STAT_AVG) { s -> s.avgLatencyMs?.let { Format.ms(it) } ?: "—" })
            c.add(whenTrue(InfoRow(Strings.STAT_SAVED) { Format.span(it.savedSeconds) }) { it.savedSeconds > 0 })
            c.add(InfoRow(Strings.STAT_TRAFFIC) { Strings.traffic(Format.bytes(it.bytesUp), Format.bytes(it.bytesDown)) })
            c.add(LatencyChart())
            c.add(whenTrue(WeekChart()) { it.daily.isNotEmpty() })         // veri yokken boş çubuklar gösterilmez
            c.add(whenTrue(NavRow(Strings.SESSIONS, { SessionLog.decode(it.sessions).size.toString() }, Icon.LOG) { nav.openSessions() }) { it.sessions.isNotEmpty() })
        }
        card { c ->
            c.add(ToggleRow(Strings.KEEP_HISTORY, Strings.KEEP_HISTORY_NOTE, { it.keepHistory }, { s, v -> s.copy(keepHistory = v) }))
            c.add(whenTrue(NavRow(Strings.SHARE_RESULTS, null, Icon.COPY) { model.shareResults() }) { model.latencies.isNotEmpty() })
            // Temizlenecek ölçüm ya da geçmiş yoksa satır gösterilmez.
            c.add(whenTrue(NavRow(Strings.CLEAR_HISTORY, null, Icon.REFRESH) { model.askClearHistory() }) { model.latencies.isNotEmpty() || model.history.isNotEmpty() })
            c.add(whenTrue(NavRow(Strings.RESET_STATS, null, Icon.BLOCK) { model.askResetStats() }) { it.totalQueries > 0 || it.totalSeconds > 0 || it.usage.isNotEmpty() })
        }
    }

    private fun openProfiles(nav: Nav) {
        val opts = Profiles.all.mapIndexed { i, p -> Option(p.id, Strings.PROFILE_NAMES[i], Strings.PROFILE_NOTES[i]) }
        nav.openOptions(Strings.PROFILES, opts) { id -> if (id != null) model.applyProfile(id) }
    }

    /** Ses paketi listesi: 4 klasik paket ve stile özel 8 animasyonlu paket. */
    private fun openSoundPack(nav: Nav) {
        val cur = model.settings.soundPack
        val opts = SoundPack.values().map { Option(it.id, Strings.packName(it), if (it == SoundPack.AUTO) Strings.SOUND_PACK_NOTE else "", it == cur) }
        nav.openOptions(Strings.SOUND_PACK, opts, footer = Strings.PACKS_NOTE) { id ->
            val p = SoundPack.values().firstOrNull { it.id == id }
            if (p != null) { model.update { it.copy(soundPack = p) }; model.previewSound() }
        }
    }

    private fun openSoundPart(nav: Nav) = openSoundVoicePicker(model, nav)

    private fun buildSound() {
        col.add(SectionTitle(Strings.SEC_SOUND))
        card { c ->
            // Ses kapalıyken ses düzeyi, çıkış ve olay anahtarları işe yaramaz: gizlenir (paket seçimi ve "Dene" kalır: paket animasyonu sesten bağımsızdır).
            c.add(whenTrue(NavRow(Strings.SOUND_PART, { if (it.soundPart < 0) Strings.SOUND_PART_AUTO else Strings.soundPartName(it.soundPart) }) { openSoundPart(nav) }) { it.soundOn && it.showAdvanced })
            c.add(ToggleRow(Strings.SOUND_ON, Strings.SOUND_ON_NOTE, { it.soundOn }, { s, v -> s.copy(soundOn = v) }))
            c.add(whenTrue(ToggleRow(Strings.SOUND_UI, Strings.SOUND_UI_NOTE, { it.soundUi }, { s, v -> s.copy(soundUi = v) })) { it.soundOn && it.showAdvanced })
            c.add(whenTrue(ToggleRow(Strings.SOUND_CONN, Strings.SOUND_CONN_NOTE, { it.soundConn }, { s, v -> s.copy(soundConn = v) })) { it.soundOn && it.showAdvanced })
            // Parmak kalkınca örnek ses çalar: ses düzeyi ayarlanırken duyulur.
            c.add(whenTrue(SliderRow(Strings.SOUND_VOL, { it.soundVolume }, { s, v -> s.copy(soundVolume = v) }, { Strings.percent((it.soundVolume * 100).roundToInt()) },
                onRelease = { it.sfx(app.dnshizli.core.Sfx.CONNECT) }) ) { it.soundOn })
            c.add(NavRow(Strings.SOUND_PACK, { Strings.packName(it.soundPack) }) { openSoundPack(nav) })
            c.add(whenTrue(SegmentRow(Strings.SOUND_OUT, Strings.OPT_SOUND_OUT, { it.soundOutput.ordinal }, { s, i -> s.copy(soundOutput = SoundOutput.values()[i]) },
                noteFn = { Strings.soundOutNote(it.soundOutput) }, after = { it.previewSound() })) { it.soundOn && it.showAdvanced })
            c.add(NavRow(Strings.SOUND_TEST, null, Icon.BELL) { model.previewSound() })
        }
        card { c ->
            c.add(ToggleRow(Strings.QUIET_HOURS, Strings.QUIET_NOTE, { it.quietHours }, { s, v -> s.copy(quietHours = v) }))
            c.add(whenTrue(SegmentRow(Strings.QUIET_RANGE, NightHours.values().map { it.label }, { it.quietRange.ordinal }, { s, i -> s.copy(quietRange = NightHours.values()[i]) })) { it.quietHours })
        }
        col.add(SectionTitle(Strings.SEC_MOTION_FX))
        // Hareket kapalıyken (ya da düşük güçte) animasyon ayarları işe yaramaz: yerine kısa bir açıklama görünür.
        col.add(whenTrue(ParagraphCard(Strings.FX_OFF_NOTE)) { it.effectiveMotion == Motion.OFF })
        condCard({ it.effectiveMotion != Motion.OFF || (it.showAdvanced && hapticsShown(it)) }) { c ->
            c.add(whenTrue(SliderRow(Strings.ANIM_SPEED, { (it.animSpeed - AppSettings.SPEED_MIN) / (AppSettings.SPEED_MAX - AppSettings.SPEED_MIN) },
                { s, v -> s.copy(animSpeed = (Math.round((AppSettings.SPEED_MIN + v * (AppSettings.SPEED_MAX - AppSettings.SPEED_MIN)) * 20f) / 20f).coerceIn(AppSettings.SPEED_MIN, AppSettings.SPEED_MAX)) },
                { Strings.percent((it.animSpeed * 100).roundToInt()) })) { it.effectiveMotion != Motion.OFF })
            c.add(whenTrue(ToggleRow(Strings.TAP_FX, Strings.TAP_FX_NOTE, { it.tapFx }, { s, v -> s.copy(tapFx = v) })) { it.showAdvanced && it.effectiveMotion != Motion.OFF })
            c.add(whenTrue(NavRow(Strings.FX_VARIANT, { Strings.fxVariantName(FxVariants.get(it.fxVariants, it.style)) }) { openFxVariant(nav) }) { it.showAdvanced && it.effectiveMotion != Motion.OFF })
            c.add(whenTrue(ToggleRow(Strings.CELEBRATE, Strings.CELEBRATE_NOTE, { it.celebrate }, { s, v -> s.copy(celebrate = v) })) { it.showAdvanced && it.effectiveMotion != Motion.OFF })
            // Titreşim şiddeti: titreşimsiz cihazda ya da titreşim kapalıyken anlamsız; seçince örnek titreşim verilir.
            c.add(whenTrue(SegmentRow(Strings.HAPTIC_LEVEL, Strings.OPT_HAPTIC, { it.hapticLevel.ordinal }, { s, i -> s.copy(hapticLevel = HapticLevel.values()[i]) },
                after = { it.hapticEvent(app.dnshizli.core.Sfx.CONNECT) })) { it.showAdvanced && hapticsShown(it) })
        }
    }

    private fun hapticsShown(s: AppSettings): Boolean = s.haptics && model.host.hasVibrator()

    /** Aktif stil için dokunma/kutlama efekti varyantı: özgün (0) ve dört yeni biçim. */
    private fun openFxVariant(nav: Nav) {
        val cur = FxVariants.get(model.settings.fxVariants, model.settings.style)
        val opts = (0 until FxVariants.COUNT).map { Option(it.toString(), Strings.fxVariantName(it), "", it == cur) }
        nav.openOptions(Strings.FX_VARIANT, opts) { id -> id?.toIntOrNull()?.let { model.setFxVariant(it) } }
    }

    private fun buildData() {
        card { c ->
            c.add(NavRow(Strings.COPY_STATUS, null, Icon.COPY) { model.copyStatusSummary() })
            c.add(NavRow(Strings.EXPORT, null, Icon.COPY) { model.exportSettings() })
            c.add(NavRow(Strings.IMPORT, null, Icon.LOG) { model.importSettings() })
            c.add(NavRow(Strings.RESET_SETTINGS, null, Icon.REFRESH) { model.askResetSettings() })
        }
    }

    private fun appsSummary(s: AppSettings): String = when (s.appScope) {
        AppScope.ALL -> Strings.APPS_ALL
        AppScope.ONLY -> Strings.appsOnly(s.apps.size)
        AppScope.EXCEPT -> Strings.appsExcept(s.apps.size)
    }

    private fun ruleName(id: String?): String = id?.let { Catalog.byId(it)?.name } ?: Strings.RULE_AUTO

    private fun backupName(id: String?): String = when (id) {
        null -> Strings.BACKUP_OFF
        AppSettings.BACKUP_AUTO -> Strings.BACKUP_FASTEST
        else -> Catalog.byId(id)?.name ?: Strings.BACKUP_OFF
    }

    private fun batteryText(): String = when (model.host.batteryRestricted()) {
        true -> Strings.BATTERY_LIMITED
        false -> Strings.BATTERY_OK
        null -> ""
    }

    /** Sorun giderici: telefon durumunu okuyup bilgi panelinde gösterir; "Yeniden denetle" yeniden okur. */
    /** "Site neden açılmıyor?": bir alan adı yazılır, sonuç bilgi panelinde; engelliyse izin verme düğmesi çıkar. */
    private fun openSiteDiag(nav: Nav) {
        model.host.promptText(Strings.SITE_DIAG, "ornek.com", "", maxLen = 253) { raw ->
            val v = model.siteView(raw)
            nav.openInfo(Strings.SITE_DIAG, v.paragraphs, v.button) { v.allowName?.let { model.addFilterName(true, it) } }
        }
    }

    private fun openTrouble(nav: Nav) {
        val r = Troubleshoot.report(model.host.networkCheck(), model.vpn.active || model.vpn.gwOnly)
        nav.openInfo(Strings.TROUBLE, r.paragraphs, Strings.TROUBLE_RECHECK) { openTrouble(nav) }
    }

    /** Tanılama raporu: metni önce gösterir; paylaşma yalnızca kullanıcı onayıyla yapılır. */
    /** Tek bakışta durum: DNS, DPI, reklam engelleme ve bağlantı/güvenlik (denetim bulgularından). */
    private fun openHealth(nav: Nav) {
        val st = model.settings
        val connected = model.vpn.state == OrbState.ON || model.vpn.gwActive
        val rows = HealthSummary.rows(connected, st.dnsOn, model.dpiOn, model.adsPlusOn || st.filterLevel != FilterLevel.OFF, AuditLive.findings)
        val opts = rows.map {
            val icon = when (it.state) { Health.OK -> Icon.CHECK; Health.WARN -> Icon.INFO; Health.BAD -> Icon.BLOCK; Health.OFF -> Icon.CLOSE }
            Option(it.key, AppAdsText.t("h" + it.key.replaceFirstChar { c -> c.uppercase() }), it.detail, icon = icon)
        }
        nav.openOptions(AppAdsText.t("hTitle"), opts, "", "") { }
    }

    private fun openDiag(nav: Nav) {
        val st = model.settings
        val (ver, code) = model.host.appVersion()
        val problems = Troubleshoot.report(model.host.networkCheck(), model.vpn.active || model.vpn.gwOnly).problems
        val text = DiagReport.build(DiagInput(
            appVersion = ver, versionCode = code, androidSdk = model.host.androidSdk(),
            deviceModel = model.host.deviceModel(), netKind = model.host.networkKind(),
            vpnActive = model.vpn.active, encryption = st.encryption.name, odoh = st.odoh.name,
            ipMode = st.ipMode.name, failClosed = st.failClosed, strictEncryption = st.strictEncryption,
            filterMem = st.filterMem.name, problems = problems,
            crashCount = model.host.crashes().size, lastCrash = model.host.crashes().firstOrNull(),
            system = DeviceTune.profile?.diagLine.orEmpty(),
            events = Journal.log.dump().lines(),
            score = AuditLive.score, audit = AuditLive.lines(), compat = CompatLive.plan().noteTexts(), dpi = AuditLive.dpi,
            settings = listOf(
                "dns=${st.dnsOn}", "dpi=${st.dpiOn}", "reklam+=${st.adsPlus}", "quicEngel=${st.blockQuic}", "udpSahte=${st.udpDecoy}",
                "quicBölme=${st.quicSplit}", "dohKalkanı=${st.dohGuard}", "otoKoruma=${st.autoShield}", "süzgeç=${st.filterLevel.name}",
                "yenidenBağlan=${st.autoReconnect}", "ech=${st.echAllow}", "kapsam=${st.appScope.name}",
            )))
        nav.openInfo(Strings.DIAG_TITLE, text.split("\n") + Strings.DIAG_NOTE, Strings.DIAG_SHARE_BTN) { model.host.shareText(text) }
    }

    private fun openBackup(nav: Nav) {
        val cur = model.settings.backupServer
        val opts = ArrayList<Option>()
        opts.add(Option(OFF_ID, Strings.BACKUP_OFF, Strings.BACKUP_OFF_NOTE, cur == null))
        opts.add(Option(AppSettings.BACKUP_AUTO, Strings.BACKUP_FASTEST, Strings.BACKUP_FASTEST_NOTE, cur == AppSettings.BACKUP_AUTO))
        for (s in Catalog.all) opts.add(Option(s.id, s.name, s.note, cur == s.id))
        nav.openOptions(Strings.BACKUP_SERVER, opts) { id -> model.update { it.copy(backupServer = if (id == OFF_ID) null else id) } }
    }

    private fun openHidden(nav: Nav) {
        val opts = model.hiddenServers().map { Option(it.id, it.name, Strings.UNHIDE) }
        nav.openOptions(Strings.HIDDEN, opts, Strings.HIDDEN_NONE) { id -> if (id != null) model.unhide(id) }
    }

    private companion object {
        const val OFF_ID = "off"
        /** ECH'yi platform düzeyinde destekleyen ilk Android sürümü (Android 17 = API 37). */
        const val ECH_MIN_SDK = 37
        const val ADD_ID = "\u0000add"
        const val COPY_ID = "\u0000copy"
        const val BLOCK_SUSPECTS = "\u0000suspects"
        const val RESET_ID = "\u0000reset"
        const val SUSPECT_PREFIX = "\u0000s:"
        const val APP_PREFIX = "\u0000a:"
        const val RESCUE_EXEMPT = "\u0000rx"
        const val RESCUE_ALLOW = "\u0000ra"
        const val RESCUE_IGNORE = "\u0000ri"
        const val MINE_PASTE = "\u0000paste"
        const val MINE_FILE = "\u0000file"
        const val MINE_EXPORT = "\u0000export"
        const val MINE_CLEAR = "\u0000clear"
    }
}

// =============================================================================== bağlantı geçmişi

/** En çok kullanılan sunucular ve son oturumlar (yalnızca sunucu, yöntem, süre, sorgu sayısı; ad tutulmaz). */
class SessionsPage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.SESSIONS, true, nav) {
    init {
        col.add(Label(Strings.SESSIONS_NOTE, 13f, ink = Ink.SOFT, maxLines = 0))
        val top = UsageStats.top(model.settings.usage, 3)
        if (top.isNotEmpty()) {
            col.add(SectionTitle(Strings.MOST_USED))
            col.add(SettingsCard().also { c ->
                for ((id, secs) in top) c.add(InfoRow(Catalog.byId(id)?.name ?: id) { Format.span(secs) })
            })
        }
        val sessions = SessionLog.decode(model.settings.sessions).asReversed()
        col.add(SectionTitle(Strings.SESSIONS))
        if (sessions.isEmpty()) col.add(ParagraphCard(Strings.SESSIONS_EMPTY))
        else col.add(SettingsCard().also { c -> for (x in sessions) c.add(SessionRow(x, model)) })
        finish()
    }
}

/** Bağlantı geçmişinde tek satır: sunucu · yöntem, zaman, süre ve bitiş nedeni. */
class SessionRow(private val s: Session, private val model: AppModel) : Node() {
    private val title = (Catalog.byId(s.serverId)?.name ?: s.serverId) + " · " + Strings.protoName(s.proto)
    private val line1 = whenText() + " · " + Strings.endReason(s.end)
    private val line2 = Strings.sessionLine(Format.span(s.seconds), Format.count(s.queries))
    private var shown = arrayOf(title, line1, line2)
    private var titleRows: List<String> = listOf(title)
    private var laidW = -1f
    private var laidFs = 0f

    private fun whenText(): String {
        val now = model.host.now()
        val day = app.dnshizli.core.DailyStats.today(s.startMs)
        val today = app.dnshizli.core.DailyStats.today(now)
        val yesterday = app.dnshizli.core.DailyStats.today(now - 86_400_000L)
        val d = when (day) { today -> Strings.TODAY; yesterday -> Strings.YESTERDAY; else -> String.format(java.util.Locale.ROOT, "%02d.%02d", day % 100, (day / 100) % 100) }
        return d + " " + Format.hm(s.startMs)
    }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        // uzun sunucu adı kesilmez: en çok iki satıra sarılır, satır buna göre uzar
        titleRows = TextFit.wrap(env.metrics, title, w - 32f, env.sz(15f), true).ifEmpty { listOf(title) }.take(2)
        h = 74f + (titleRows.size - 1) * env.sz(15f) * 1.25f
        laidW = -1f
    }

    private fun relay(env: Env) {
        laidW = w; laidFs = env.fs
        shown = arrayOf(
            title,
            TextFit.ellipsize(env.metrics, line1, w - 32f, env.sz(13f), false),
            TextFit.ellipsize(env.metrics, line2, w - 32f, env.sz(13f), false),
        )
    }

    override fun draw(g: Gfx, env: Env) {
        if (laidW != w || laidFs != env.fs) relay(env)
        g.paint(env.theme.text)
        val step = env.sz(15f) * 1.25f
        for (i in 0 until titleRows.size) g.text(titleRows[i], 16f, 24f + i * step, env.sz(15f), true, ALIGN_LEFT)
        val extra = (titleRows.size - 1) * step
        g.paint(env.theme.textSoft)
        g.text(shown[1], 16f, 44f + extra, env.sz(13f), false, ALIGN_LEFT)
        g.text(shown[2], 16f, 62f + extra, env.sz(13f), false, ALIGN_LEFT)
    }

    override fun a11y(): A11y = A11y("$title. $line1. $line2", Role.TEXT)
}

// =============================================================================== neler yeni

class WhatsNewPage(nav: Nav) : ScrollPage(Strings.WHATS_NEW, true, nav) {
    init {
        for (item in Strings.WHATS_NEW_ITEMS) col.add(ParagraphCard("• $item"))
        finish()
        col.gap = 8f
    }
}

// =============================================================================== uygulama seçimi

/**
 * Uygulama satırları kartı. Yüzlerce uygulama olabilir: yalnızca ekranda görünen satırlar çizilir
 * ([offset]: bu sayfanın kaydırma konumu; kart doğrudan içerik sütununun çocuğudur).
 */
class AppListCard(private val offset: () -> Float) : Node() {
    fun setApps(list: List<AppEntry>) {
        removeAll()
        for (a in list) {
            val pkg = a.pkg
            add(ToggleRow(a.label, null, { pkg in it.apps }, { s, v -> s.copy(apps = if (v) s.apps + pkg else s.apps - pkg) }))
        }
    }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        var cy = 0f
        for (k in kids) { k.layout(env, maxW); k.x = 0f; k.y = cy; cy += k.h }
        h = cy
    }

    override fun draw(g: Gfx, env: Env) {
        env.art.card(g, 0f, 0f, w, h, M.CARD_R)
        val top = offset() - y - 80f
        val bottom = offset() + env.height - y + 80f
        g.paint(Rgb.alpha(Rgb.WHITE, if (env.theme.dark) 0.14f else 0.55f))
        var i = 0
        while (i < kids.size) {
            val k = kids[i++]
            if (k.y + k.h < top || k.y > bottom) continue
            g.save(); g.translate(k.x, k.y); k.draw(g, env); g.restore()
            if (i > 1) {
                g.paint(Rgb.alpha(Rgb.WHITE, if (env.theme.dark) 0.14f else 0.55f))      // çocuğun boyası ezmiş olabilir
                g.rect(16f, k.y - 0.5f, w - 16f, k.y + 0.5f)
            }
        }
    }
}

/** "Hangi uygulamalar": DNS'in uygulanacağı uygulamaları seçer. */
class AppsPage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.APPS, true, nav) {
    private val status = Label("", 14f, ink = Ink.SOFT, align = ALIGN_CENTER, maxLines = 0)
    private val list = AppListCard { scroll.offset }
    private val pending = ParagraphCard(Strings.APPS_PENDING)
    private val apply = ActionButton(Strings.APPS_APPLY, true) { model.applyAppsNow() }
    private var seen = -1
    private var shownApps: List<AppEntry>? = null

    init {
        col.add(SettingsCard().also { c ->
            c.add(SegmentRow(Strings.APPS_MODE, Strings.OPT_APPS, { it.appScope.ordinal }, { s, i -> s.copy(appScope = AppScope.values()[i]) }))
        })
        col.add(ParagraphCard(Strings.APPS_NOTE))
        col.add(pending)
        col.add(apply)
        col.add(status)
        col.add(list)
        finish()
        col.gap = 12f
        model.loadApps()
    }

    override fun onLaidOut(env: Env, left: Float) { seen = -1 }

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version) {
            seen = model.version
            val s = model.settings
            val apps = model.apps
            if (apps !== shownApps) { shownApps = apps; list.setApps(apps ?: emptyList()) }
            val picking = s.appScope != AppScope.ALL
            val installed = apps?.map { it.pkg }?.toSet() ?: emptySet()
            status.text = when {
                !picking -> ""
                apps == null -> Strings.APPS_LOADING
                apps.isEmpty() -> Strings.APPS_EMPTY
                s.apps.none { it in installed } -> Strings.APPS_NONE_SELECTED
                else -> ""
            }
            list.visible = picking && !apps.isNullOrEmpty()
            pending.visible = model.appsPending
            apply.visible = model.appsPending
            relayoutContent(env)
        }
        return super.tick(dt, env)
    }
}

// =============================================================================== yardım ve günlük

/** İçinde çok satırlı yazı olan cam kart. [tail] verilirse metnin son cümlesi olarak yeşil renkte, aynı kartta çizilir. */
class ParagraphCard(text: String, tail: String? = null) : Node() {
    private val label = Label(text, 15f, ink = Ink.TEXT, maxLines = 0)
    private val last = tail?.let { Label(it, 15f, ink = Ink.GOOD, maxLines = 0) }

    // Uzun basınca kartın metni panoya kopyalanır (yardım yazılarını paylaşmak için).
    override val tappable: Boolean get() = true
    override val longPressable: Boolean get() = true
    override fun onLongPress(env: Env): Boolean {
        env.model.copy(if (last == null) label.text else label.text + "\n" + last.text)
        return true
    }
    override fun layout(env: Env, maxW: Float) {
        w = maxW
        label.layout(env, maxW - 32f)
        label.x = 16f; label.y = 14f
        h = label.h + 28f
        if (last != null) {
            last.layout(env, maxW - 32f)
            last.x = 16f; last.y = 14f + label.h + 8f
            h = last.y + last.h + 14f
        }
    }
    override fun draw(g: Gfx, env: Env) {
        env.art.card(g, 0f, 0f, w, h, M.CARD_R)
        g.save(); g.translate(label.x, label.y); label.draw(g, env); g.restore()
        if (last != null) { g.save(); g.translate(last.x, last.y); last.draw(g, env); g.restore() }
    }
    override fun a11y(): A11y = A11y(if (last == null) label.text else label.text + " " + last.text, Role.TEXT)
}

class HelpPage(nav: Nav) : ScrollPage(Strings.HELP, true, nav) {
    init {
        for ((title, body) in Strings.HELP_SECTIONS) {
            col.add(SectionTitle(title))
            col.add(ParagraphCard(body))
        }
        col.add(SectionTitle(Strings.HELP_WHY_TITLE))
        col.add(ParagraphCard(Strings.HELP_WHY_BODY, Strings.HELP_WHY_TAIL))
        finish()
        col.gap = 8f
    }
}

/** Günlük satırlarını gösteren cam kart. */
class LogView(private val host: Host) : Node() {
    private var lines: List<String> = emptyList()
    private var empty = true

    /** Bir kayıt: sığmayan satırlar kesilmez, alt satırlara sarılır; sorun bildiren kayıtlar kalın yazılır. */
    private class Entry(val rows: List<String>, val bold: Boolean)
    private var shown: List<Entry> = emptyList()

    /** Kayıtları yeniden okur. Ardından üst sayfa yerleşimi yenilemelidir (satır sayısı değişir). */
    fun refresh() {
        val raw = host.diagnostics().trim()
        empty = raw.isEmpty()
        lines = if (empty) listOf(Strings.LOG_EMPTY) else raw.split('\n').asReversed()   // en yeni üstte
    }

    private fun problem(s: String): Boolean {
        val t = s.lowercase()
        return PROBLEM_WORDS.any { t.contains(it) }
    }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        if (lines.isEmpty()) refresh()
        val fs = env.sz(12f)
        shown = lines.map { l ->
            val bold = !empty && problem(l)
            Entry(TextFit.wrap(env.metrics, l, maxW - 32f, fs, bold).ifEmpty { listOf("") }.take(MAX_ROWS), bold)
        }
        var rows = 0
        for (e in shown) rows += e.rows.size
        h = rows * fs * 1.5f + maxOf(0, shown.size - 1) * ENTRY_GAP + 28f
    }

    override fun draw(g: Gfx, env: Env) {
        env.art.card(g, 0f, 0f, w, h, M.CARD_R)
        val s = env.sz(12f)
        var y = 14f
        for (i in 0 until shown.size) {
            val e = shown[i]
            if (i > 0) {
                // kayıtlar arasında ince ayraç
                g.paint(Rgb.alpha(env.theme.textSoft, 0.22f))
                g.rect(16f, y + ENTRY_GAP / 2f - 0.5f, w - 16f, y + ENTRY_GAP / 2f + 0.5f)
                y += ENTRY_GAP
            }
            g.paint(env.theme.text)
            for (j in 0 until e.rows.size) { y += s * 1.5f; g.text(e.rows[j], 16f, y - s * 0.5f, s, e.bold, ALIGN_LEFT) }
        }
    }

    /** Kopyalanacak/paylaşılacak metin (en eski üstte). Kayıt yoksa boş: "Henüz kayıt yok." yer tutucusu kopyalanmaz. */
    fun text(): String = if (empty) "" else lines.asReversed().joinToString("\n")
    override fun a11y(): A11y = A11y(lines.take(8).joinToString(". "), Role.TEXT)

    private companion object {
        const val ENTRY_GAP = 8f
        const val MAX_ROWS = 4
        val PROBLEM_WORDS = listOf("hata", "başarısız", "çalamadı", "çalınmadı", "çökme", "kesildi", "zaman aşımı", "reddedildi", "error", "fail")
    }
}

/** Eşit genişlikte yan yana düğmeler. */
class ButtonsRow(private val buttons: List<ActionButton>) : Node() {
    init { for (b in buttons) add(b) }
    override fun layout(env: Env, maxW: Float) {
        w = maxW
        val gap = 10f
        val bw = (maxW - gap * (buttons.size - 1)) / buttons.size
        var cx = 0f
        for (b in buttons) { b.layout(env, bw); b.x = cx; b.y = 0f; cx += bw + gap }
        h = buttons.maxOf { it.h }
    }
}

class LogPage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.LOG, true, nav) {
    private val view = LogView(model.host)
    private val note = Label(Strings.LOG_NOTE, 13f, ink = Ink.SOFT, maxLines = 0)
    private var envRef: Env? = null

    init {
        view.refresh()
        col.add(note)
        col.add(ButtonsRow(listOf(
            ActionButton(Strings.COPY, false) { model.copy(view.text()) },
            ActionButton(Strings.SHARE, false) { model.host.shareText(view.text()) },
            ActionButton(Strings.CLEAR, false) { clear() },
        )))
        col.add(view)
        finish()
    }

    override fun onLaidOut(env: Env, left: Float) { envRef = env }

    private fun clear() {
        model.host.clearDiagnostics()
        view.refresh()
        envRef?.let { relayoutContent(it) }
        model.toast(Strings.CLEARED)
    }
}

/** Menüde "Orta · 1,2 bin": süzgeç düzeyi ve bugüne dek engellenen toplam (düzey kapalıysa yalnızca düzey). */
private fun filterSummary(s: AppSettings): String {
    val level = Strings.OPT_FILTER[s.filterLevel.ordinal]
    return if (s.filterLevel == FilterLevel.OFF || s.totalBlocked <= 0) level else level + " · " + Format.count(s.totalBlocked)
}
