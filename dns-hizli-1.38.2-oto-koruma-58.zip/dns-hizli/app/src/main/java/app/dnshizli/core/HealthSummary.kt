package app.dnshizli.core

enum class Health { OK, WARN, BAD, OFF }

class HealthRow(val key: String, val state: Health, val detail: String)

/**
 * Tek bakışta durum: DNS, DPI, reklam engelleme, bağlantı/güvenlik. Denetim bulgularından ([Finding]) türetilir; bulgu yoksa "çalışıyor",
 * modül kapalıysa "kapalı", tünel kapalıyken "bağlı değil". Saf mantık, testlerle sınanır.
 */
object HealthSummary {
    private val DNS = setOf("stab.timeouts", "stab.retries", "stab.failover", "sec.spoof", "sec.tls", "sec.clock", "leak.dns-bypass", "leak.plain-redirect", "leak.private-dns", "leak.doh-open")
    private fun group(code: String): String = when {
        code in DNS -> "dns"
        code.startsWith("dpi.") -> "dpi"
        code.startsWith("ads.") || code.startsWith("app.") -> "ads"
        else -> "net"
    }

    fun rows(connected: Boolean, dnsOn: Boolean, dpiOn: Boolean, adsOn: Boolean, findings: List<Finding>, lang: Lang = L.lang): List<HealthRow> {
        fun row(key: String, enabled: Boolean): HealthRow {
            if (!connected) return HealthRow(key, Health.OFF, AppAdsText.t("hNoVpn", lang))
            if (!enabled) return HealthRow(key, Health.OFF, AppAdsText.t("hOff", lang))
            val mine = findings.filter { group(it.code) == key }.sortedByDescending { it.sev.rank }
            val top = mine.firstOrNull() ?: return HealthRow(key, Health.OK, AppAdsText.t("hOk", lang))
            val st = when (top.sev) { Sev.CRIT -> Health.BAD; Sev.WARN -> Health.WARN; Sev.INFO -> Health.OK }
            return HealthRow(key, st, top.text(lang))
        }
        return listOf(row("dns", dnsOn), row("dpi", dpiOn), row("ads", adsOn), row("net", true))
    }
}
