package app.dnshizli.core

import java.io.ByteArrayInputStream
import java.math.BigInteger
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Base64
import javax.net.ssl.KeyManager
import javax.net.ssl.SSLContext
import javax.net.ssl.X509KeyManager

/**
 * Tarayıcı kipi (deneysel, açık onayla) için cihaza özgü yerel sertifika yetkilisi. İki katman: KÖK ([cert], kullanıcının sisteme kurduğu) ve ona bağlı
 * ARA CA ([inter], Ad Kısıtlı). Kök anahtarı üretimde ara CA'yı imzalar imzalamaz ATILIR, cihazda yalnızca ara CA anahtarı kalır: sızsa bile
 * yalnızca kısıtlı alan adları için sertifika üretilebilir (kısıt ara sertifikadadır; kök çapadaki kısıtı her platform uygulamaz).
 * Yetkili yalnızca [leaf] ile istenen sitelere sertifika üretir (kısa ömürlü, SAN'lı).
 * X.509 yapısı elle (DER) kurulur: Android'de BouncyCastle'ın genel API'si yok.
 */
class MitmCa private constructor(private val key: PrivateKey, val cert: X509Certificate, private val inter: X509Certificate) {

    /** Yaprak sertifikalar için tek anahtar çifti (süreç ömrü boyunca): her site için yeni anahtar üretmek gereksiz maliyet. */
    private val leafPair: KeyPair by lazy { newPair() }
    private val ctxs = object : LinkedHashMap<String, SSLContext>(16, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, SSLContext>?) = size > 96
    }

    fun keyBytes(): ByteArray = key.encoded
    fun certDer(): ByteArray = cert.encoded
    fun interDer(): ByteArray = inter.encoded
    fun pem(): String {
        val b64 = Base64.getMimeEncoder(64, "\n".toByteArray()).encodeToString(cert.encoded)
        return "-----BEGIN CERTIFICATE-----\n$b64\n-----END CERTIFICATE-----\n"
    }

    /** [host] için CA'nın imzaladığı yaprak sertifika ve zinciri. [host] geçerli bir ad değilse null. */
    fun leaf(host: String, now: Long = System.currentTimeMillis()): Array<X509Certificate>? {
        if (!validHost(host)) return null
        val pub = leafPair.public.encoded
        val tbs = tbs(
            serial = serial(), issuerCn = cnOf(inter), subjectCn = host, spki = pub, from = now - DAY, to = now + LEAF_DAYS * DAY,
            ext = listOf(
                ext("2.5.29.19", true, Der.seq()),                                                       // CA:FALSE
                ext("2.5.29.15", true, Der.bits(byteArrayOf(0x80.toByte()), 7)),                          // digitalSignature
                ext("2.5.29.37", false, Der.seq(Der.oid("1.3.6.1.5.5.7.3.1"))),                          // serverAuth
                ext("2.5.29.17", false, Der.seq(Der.tlv(0x82, host.toByteArray(Charsets.US_ASCII)))),     // SAN
                ext("2.5.29.35", false, Der.seq(Der.tlv(0x80, skiOf(inter.publicKey.encoded)))),         // AKI
            ),
        )
        val leaf = parse(sign(tbs, key)) ?: return null
        return arrayOf(leaf, inter)
    }

    /** [host] için sunucu tarafı TLS bağlamı (önbellekli). */
    @Synchronized fun serverContext(host: String, now: Long = System.currentTimeMillis()): SSLContext? {
        ctxs[host]?.let { c -> return c }
        val chain = leaf(host, now) ?: return null
        val pk = leafPair.private
        val km = object : X509KeyManager {
            override fun getClientAliases(t: String?, i: Array<out java.security.Principal>?) = null
            override fun chooseClientAlias(t: Array<out String>?, i: Array<out java.security.Principal>?, s: java.net.Socket?) = null
            override fun getServerAliases(t: String?, i: Array<out java.security.Principal>?) = arrayOf("k")
            override fun chooseServerAlias(t: String?, i: Array<out java.security.Principal>?, s: java.net.Socket?) = "k"
            override fun getCertificateChain(a: String?) = chain
            override fun getPrivateKey(a: String?) = pk
        }
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(arrayOf<KeyManager>(km), null, null)
        ctxs[host] = ctx
        return ctx
    }

    companion object {
        const val DAY = 86_400_000L
        const val CA_DAYS = 3650L
        const val LEAF_DAYS = 30L
        private val HOST = Regex("^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$")
        private val rnd = SecureRandom()

        fun validHost(h: String): Boolean = h.length <= 253 && HOST.matches(h)

        /**
         * Yeni yerel CA. [domains] verilirse CA yalnızca bu alan adlarına (ve alt alanlarına) sertifika imzalayabilir (X.509 Ad Kısıtı, kritik):
         * anahtar sızsa bile başka siteler için geçerli sertifika üretilemez. null: kısıtsız (yalnızca test kaynak sunucuları için).
         */
        fun generate(domains: Collection<String>? = null, now: Long = System.currentTimeMillis()): MitmCa {
            val id = ByteArray(4).also { rnd.nextBytes(it) }.joinToString("") { "%02x".format(it) }
            val rootCn = "DNS Hizli Yerel CA $id"
            val interCn = "DNS Hizli Yerel Ara CA $id"
            val rootKp = newPair()
            val rootTbs = tbs(
                serial = serial(), issuerCn = rootCn, subjectCn = rootCn, spki = rootKp.public.encoded, from = now - DAY, to = now + CA_DAYS * DAY,
                ext = listOf(
                    ext("2.5.29.19", true, Der.seq(Der.bool(true), Der.int(BigInteger.ONE))),             // CA:TRUE, pathLen 1 (yalnızca ara CA)
                    ext("2.5.29.15", true, Der.bits(byteArrayOf(0x06), 1)),                               // keyCertSign, cRLSign
                    ext("2.5.29.14", false, Der.tlv(0x04, skiOf(rootKp.public.encoded))),                 // SKI
                ),
            )
            val root = parse(sign(rootTbs, rootKp.private))!!
            val interKp = newPair()
            val interTbs = tbs(
                serial = serial(), issuerCn = rootCn, subjectCn = interCn, spki = interKp.public.encoded, from = now - DAY, to = now + CA_DAYS * DAY,
                ext = listOf(
                    ext("2.5.29.19", true, Der.seq(Der.bool(true), Der.int(BigInteger.ZERO))),            // CA:TRUE, pathLen 0 (yalnızca yaprak)
                    ext("2.5.29.15", true, Der.bits(byteArrayOf(0x06), 1)),
                    ext("2.5.29.14", false, Der.tlv(0x04, skiOf(interKp.public.encoded))),
                    ext("2.5.29.35", false, Der.seq(Der.tlv(0x80, skiOf(rootKp.public.encoded)))),        // AKI
                ) + (if (domains != null) listOf(nameConstraints(domains)) else emptyList()),
            )
            val inter = parse(sign(interTbs, rootKp.private))!!
            return MitmCa(interKp.private, root, inter)                                                  // kök anahtarı burada atılır
        }

        /** permittedSubtrees: her alan adı bir dNSName (kendisi ve alt alanları; "notyoutube.com" kapsanmaz). Sıralı: aynı liste aynı bayt. */
        private fun constraintsValue(domains: Collection<String>): ByteArray {
            val subtrees = domains.map { it.lowercase() }.filter { validHost(it) }.distinct().sorted()
                .fold(ByteArray(0)) { a, d -> a + Der.seq(Der.tlv(0x82, d.toByteArray(Charsets.US_ASCII))) }
            return Der.seq(Der.tlv(0xA0, subtrees))
        }

        private fun nameConstraints(domains: Collection<String>): ByteArray = ext("2.5.29.30", true, constraintsValue(domains))

        /** Sertifikadaki Ad Kısıtı [domains] listesinin tam karşılığı mı? (Liste değiştiyse eski CA kullanılmaz, yenisi üretilir.) */
        private fun constraintsMatch(c: X509Certificate, domains: Collection<String>): Boolean =
            c.criticalExtensionOIDs?.contains("2.5.29.30") == true && c.getExtensionValue("2.5.29.30")?.contentEquals(Der.tlv(0x04, constraintsValue(domains))) == true

        /**
         * Kayıtlı ara CA anahtarı (PKCS#8), kök sertifika ve ara sertifika (DER) üçlüsünü yükler; bozuk, uyuşmayan, kök tarafından imzalanmamış ya da
         * süresi dolmuşsa null. [domains] verilirse ara sertifikanın Ad Kısıtı tam bu liste olmalı (eski/kısıtsız CA'lar yenilenir).
         */
        fun load(keyPkcs8: ByteArray, rootDer: ByteArray, interDer: ByteArray, now: Long = System.currentTimeMillis(), domains: Collection<String>? = null): MitmCa? {
            try {
                val root = parse(rootDer) ?: return null
                val inter = parse(interDer) ?: return null
                inter.verify(root.publicKey)                                           // ara CA gerçekten bu kök tarafından imzalanmış
                if (domains != null && !constraintsMatch(inter, domains)) return null
                val k = KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(keyPkcs8))
                val probe = Signature.getInstance("SHA256withECDSA").also { it.initSign(k); it.update(1) }.sign()
                val ok = Signature.getInstance("SHA256withECDSA").also { it.initVerify(inter.publicKey); it.update(1) }.verify(probe)
                val live = minOf(root.notAfter.time, inter.notAfter.time) >= now + 30 * DAY
                return if (!ok || !live) null else MitmCa(k, root, inter)
            } catch (_: Exception) { return null }
        }

        private fun newPair(): KeyPair = KeyPairGenerator.getInstance("EC").also { it.initialize(256) }.generateKeyPair()

        private fun parse(der: ByteArray): X509Certificate? = try {
            CertificateFactory.getInstance("X.509").generateCertificate(ByteArrayInputStream(der)) as X509Certificate
        } catch (_: Exception) { null }

        private fun serial(): BigInteger = BigInteger(127, rnd).add(BigInteger.ONE)
        private fun skiOf(spki: ByteArray): ByteArray = MessageDigest.getInstance("SHA-1").digest(spki)

        private fun cnOf(c: X509Certificate): String {
            val dn = c.subjectX500Principal.getName(javax.security.auth.x500.X500Principal.RFC2253)
            return dn.substringAfter("CN=").substringBefore(',')
        }

        private fun name(cn: String) = Der.seq(Der.set(Der.seq(Der.oid("2.5.4.3"), Der.tlv(0x0C, cn.toByteArray(Charsets.UTF_8)))))
        private fun ext(oid: String, critical: Boolean, value: ByteArray) =
            if (critical) Der.seq(Der.oid(oid), Der.bool(true), Der.tlv(0x04, value)) else Der.seq(Der.oid(oid), Der.tlv(0x04, value))

        private fun tbs(serial: BigInteger, issuerCn: String, subjectCn: String, spki: ByteArray, from: Long, to: Long, ext: List<ByteArray>): ByteArray =
            Der.seq(
                Der.tlv(0xA0, Der.int(BigInteger.valueOf(2))),
                Der.int(serial),
                SIG_ALG,
                name(issuerCn),
                Der.seq(Der.utc(from), Der.utc(to)),
                name(subjectCn),
                spki,
                Der.tlv(0xA3, Der.seq(*ext.toTypedArray())),
            )

        private val SIG_ALG = Der.seq(Der.oid("1.2.840.10045.4.3.2"))      // ecdsa-with-SHA256

        private fun sign(tbs: ByteArray, k: PrivateKey): ByteArray {
            val sig = Signature.getInstance("SHA256withECDSA").also { it.initSign(k); it.update(tbs) }.sign()
            return Der.seq(tbs, SIG_ALG, Der.bits(sig, 0))
        }
    }

    /** Asgari DER yazıcısı. */
    private object Der {
        fun len(n: Int): ByteArray = when {
            n < 128 -> byteArrayOf(n.toByte())
            n < 256 -> byteArrayOf(0x81.toByte(), n.toByte())
            n < 65536 -> byteArrayOf(0x82.toByte(), (n shr 8).toByte(), n.toByte())
            else -> byteArrayOf(0x83.toByte(), (n shr 16).toByte(), (n shr 8).toByte(), n.toByte())
        }
        fun tlv(tag: Int, body: ByteArray): ByteArray = byteArrayOf(tag.toByte()) + len(body.size) + body
        fun seq(vararg p: ByteArray): ByteArray = tlv(0x30, p.fold(ByteArray(0)) { a, b -> a + b })
        fun set(vararg p: ByteArray): ByteArray = tlv(0x31, p.fold(ByteArray(0)) { a, b -> a + b })
        fun int(v: BigInteger): ByteArray = tlv(0x02, v.toByteArray())
        fun bool(v: Boolean): ByteArray = tlv(0x01, byteArrayOf(if (v) 0xFF.toByte() else 0))
        fun bits(b: ByteArray, unused: Int): ByteArray = tlv(0x03, byteArrayOf(unused.toByte()) + b)
        fun oid(s: String): ByteArray {
            val a = s.split('.').map { it.toLong() }
            val out = java.io.ByteArrayOutputStream()
            out.write((a[0] * 40 + a[1]).toInt())
            for (i in 2 until a.size) {
                var v = a[i]
                val tmp = ArrayList<Int>()
                tmp.add((v and 0x7F).toInt()); v = v shr 7
                while (v > 0) { tmp.add(((v and 0x7F) or 0x80).toInt()); v = v shr 7 }
                for (j in tmp.indices.reversed()) out.write(tmp[j])
            }
            return tlv(0x06, out.toByteArray())
        }
        fun utc(ms: Long): ByteArray {
            // java.time: Gregoryen takvim ve ASCII rakam her cihaz dilinde (Calendar.getInstance, Tay/Japon takviminde yılı kaydırırdı; %d Arapça rakam üretebilirdi).
            val t = java.time.Instant.ofEpochMilli(ms).atOffset(java.time.ZoneOffset.UTC)
            val s = "%02d%02d%02d%02d%02d%02dZ".format(java.util.Locale.ROOT, t.year % 100, t.monthValue, t.dayOfMonth, t.hour, t.minute, t.second)
            return tlv(0x17, s.toByteArray(Charsets.US_ASCII))
        }
    }
}
