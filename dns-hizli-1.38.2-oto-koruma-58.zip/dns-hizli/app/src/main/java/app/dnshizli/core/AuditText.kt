package app.dnshizli.core

/**
 * Denetim bulguları, uyum notları ve modül uyarılarının 12 dildeki metinleri. Bulgu bir KOD ve değişkenlerle ([Finding.args]) taşınır;
 * metin görüntülenirken seçili dilde üretilir. Dil eksikse (olmamalı, testle korunur) önce İngilizce, sonra Türkçe kullanılır.
 */
object AuditText {
    private val ALL: Map<String, Array<String>> = AuditTextA.M + AuditTextB.M

    fun codes(): Set<String> = ALL.keys

    fun has(code: String) = ALL.containsKey(code)

    fun render(code: String, args: List<String>, lang: Lang): String {
        val row = ALL[code] ?: return code
        var t = row.getOrNull(lang.ordinal)?.takeIf { it.isNotBlank() } ?: row.getOrNull(Lang.EN.ordinal) ?: row[0]
        for ((i, a) in args.withIndex()) t = t.replace("{$i}", a)
        return t
    }

    /** Metindeki değişken sayısı (testlerde dillerin tutarlılığı için). */
    fun placeholders(s: String): Set<String> = Regex("\\{\\d\\}").findAll(s).map { it.value }.toSet()

    fun row(code: String): Array<String>? = ALL[code]
}
