package app.dnshizli.core

/**
 * Ses parçaları: 16 tını ([Voice], hepsi) × 12 nota dizisi × 2 perde (normal ve bir oktav yüksek) = 384.
 * Parça [i] = tını ((i / (CONTOURS·REGISTERS))), dizi ((i / REGISTERS) % CONTOURS), register (i % REGISTERS).
 * Her parça kendi ayrı sesidir; [render] ile üretilir.
 */
object SoundParts {
    const val CONTOURS = 12
    const val REGISTERS = 2
    val VOICES: List<Voice> = Voice.values().toList()
    val COUNT: Int = VOICES.size * CONTOURS * REGISTERS

    /** Register kaydırması (yarım ton): 0 normal, 1 bir oktav yüksek. */
    private val SHIFT = floatArrayOf(0f, 12f)

    /** Her dizi: (C5'ten yarım ton, başlangıç sn, süre sn). */
    val CONTOUR_STEPS: List<List<Triple<Float, Float, Float>>> = listOf(
        listOf(Triple(0f, 0f, 0.06f)),                                                        // 0 tek vuruş
        listOf(Triple(0f, 0f, 0.06f), Triple(4f, 0.06f, 0.06f), Triple(7f, 0.12f, 0.10f)),    // 1 yukarı üçlü
        listOf(Triple(7f, 0f, 0.06f), Triple(4f, 0.06f, 0.06f), Triple(0f, 0.12f, 0.12f)),    // 2 aşağı
        listOf(Triple(0f, 0f, 0.04f), Triple(0f, 0.08f, 0.04f)),                              // 3 çift nokta
        listOf(Triple(0f, 0f, 0.05f), Triple(2f, 0.05f, 0.05f), Triple(4f, 0.10f, 0.05f), Triple(2f, 0.15f, 0.08f)), // 4 kıvrım
        listOf(Triple(0f, 0f, 0.05f), Triple(12f, 0.06f, 0.12f)),                             // 5 oktav atlama
        listOf(Triple(0f, 0f, 0.06f), Triple(7f, 0.07f, 0.14f)),                              // 6 beşli
        listOf(Triple(0f, 0f, 0.10f), Triple(3f, 0.11f, 0.10f), Triple(5f, 0.22f, 0.10f), Triple(7f, 0.33f, 0.16f)), // 7 yavaş yükseliş
        listOf(Triple(0f, 0f, 0.03f), Triple(2f, 0.03f, 0.03f), Triple(4f, 0.06f, 0.03f), Triple(5f, 0.09f, 0.03f), Triple(7f, 0.12f, 0.06f)), // 8 hızlı gama
        listOf(Triple(12f, 0f, 0.08f), Triple(7f, 0.09f, 0.08f), Triple(4f, 0.18f, 0.08f), Triple(0f, 0.27f, 0.18f)), // 9 kapanış
        listOf(Triple(0f, 0f, 0.04f), Triple(0f, 0.05f, 0.04f), Triple(0f, 0.10f, 0.04f), Triple(0f, 0.15f, 0.04f), Triple(-2f, 0.22f, 0.10f)), // 10 titreşim
        listOf(Triple(0f, 0f, 0.22f), Triple(4f, 0f, 0.22f), Triple(7f, 0f, 0.22f)),          // 11 akor
    )

    fun index(voice: Int, contour: Int, register: Int): Int =
        (voice.coerceIn(0, VOICES.size - 1) * CONTOURS + contour.coerceIn(0, CONTOURS - 1)) * REGISTERS + register.coerceIn(0, REGISTERS - 1)

    fun voiceIndex(i: Int): Int = i / (CONTOURS * REGISTERS)
    fun voice(i: Int): Voice = VOICES[voiceIndex(i).coerceIn(0, VOICES.size - 1)]
    fun contour(i: Int): Int = (i / REGISTERS) % CONTOURS
    fun register(i: Int): Int = i % REGISTERS

    fun render(i: Int): ShortArray {
        require(i in 0 until COUNT) { "ses parçası dizini: $i" }
        return Synth.renderPart(voice(i), CONTOUR_STEPS[contour(i)], SHIFT[register(i)])
    }
}
