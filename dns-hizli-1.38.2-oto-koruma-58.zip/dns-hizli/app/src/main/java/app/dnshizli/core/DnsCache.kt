package app.dnshizli.core

/**
 * Küçük bir LRU DNS önbelleği. İki sınırı vardır: en fazla [maxEntries] kayıt VE en fazla [maxBytes] bayt
 * (varsayılan: kayıt başına ortalama 1 KB). Böylece büyük cevaplarla (ör. uzun TXT kayıtları) doldurulmaya
 * çalışılsa bile bellek tavanı sabittir. Tek bir cevap [MAX_ENTRY_BYTES]'tan büyükse hiç saklanmaz.
 * Tekrarlayan sorgular ağa hiç çıkmaz: hem hız hem pil kazancı. [maxEntries] sıfır veya negatifse önbellek kapalıdır.
 *
 * Anahtar: sorgu mesajının ilk 2 bayt (id) hariç tamamı. Böylece bayrak ve EDNS farkları
 * yanlışlıkla aynı kayda düşmez.
 *
 * Önbellekten verilen cevaplarda TTL'ler geçen süre kadar azaltılır ([Dns.ageTtls]): istemci, cevabı sunucunun
 * izin verdiğinden daha uzun saklamaz.
 *
 * Bayat cevap (RFC 8767, "serve-stale"): süresi dolmuş OLUMLU bir cevap, [STALE_MAX_MS] boyunca bellekte kalır ve yalnızca
 * sunucu cevap vermediğinde [getStale] ile verilir (TTL [STALE_TTL_S] sn'ye çekilir). Bağlantı kısa süre kopsa ya da sunucu
 * yavaşlasa bile az önce çözülen adlar çalışmaya devam eder; bellek sınırları aynıdır, yeni kayıt önce eski olanı atar.
 */
internal class DnsCache(
    private val maxEntries: Int,
    private val nowMs: () -> Long,
    private val maxBytes: Int = maxOf(0, maxEntries) * 1024,
) {
    private class Cached(val data: ByteArray, val storedAt: Long, val expiresAt: Long, val staleOk: Boolean, val lifeMs: Long) {
        var hits = 0                  // [PREFETCH_WINDOW_MS] içindeki taze isabetler
        var hitsFrom = 0L
        var refreshing = false        // ön yenileme sorgusu yolda
    }

    private val map = LinkedHashMap<String, Cached>(64, 0.75f, true)
    private var bytes = 0

    fun put(key: String, resp: ByteArray, len: Int, ttlSec: Int) = put(key, resp, 0, len, ttlSec)

    /** [resp] içinde [off] konumundan başlayan [len] baytlık cevabı saklar. */
    @Synchronized
    fun put(key: String, resp: ByteArray, off: Int, len: Int, ttlSec: Int) {
        if (maxEntries <= 0 || ttlSec < 1 || len <= 0 || len > MAX_ENTRY_BYTES || len > maxBytes) return
        val life = minOf(ttlSec, MAX_TTL_S) * 1000L
        val now = nowMs()
        map.remove(key)?.let { bytes -= it.data.size }
        map[key] = Cached(resp.copyOfRange(off, off + len), now, now + life, isPositive(resp, off, len), life)
        bytes += len
        trim()
    }

    /** En eski (en az yakın zamanda kullanılan) kayıtlardan başlayarak iki sınıra da inene kadar atar. */
    private fun trim() {
        if (map.size <= maxEntries && bytes <= maxBytes) return
        val it = map.entries.iterator()
        while (it.hasNext() && (map.size > maxEntries || bytes > maxBytes)) {
            bytes -= it.next().value.data.size
            it.remove()
        }
    }

    /**
     * Kayıt varsa cevabı [out] içine [off] konumundan başlayarak kopyalar, DNS id'sini istemcinin
     * id'siyle değiştirir, TTL'leri eskitir ve uzunluğu döner. Yoksa, süresi dolduysa ya da [out]'a sığmıyorsa -1.
     */
    @Synchronized
    fun get(key: String, clientId: Int, out: ByteArray, off: Int): Int {
        if (maxEntries <= 0) return -1
        val e = map[key] ?: return -1
        val now = nowMs()
        if (now < e.storedAt) { map.remove(key); bytes -= e.data.size; return -1 }     // saat geri gitti: kaydın yaşı bilinemez, atılır
        if (now >= e.expiresAt) {
            // Bayat olarak verilebilecek kayıt penceresi boyunca tutulur; aksi halde hemen atılır.
            if (!e.staleOk || now - e.expiresAt > STALE_MAX_MS) { map.remove(key); bytes -= e.data.size }
            return -1
        }
        val n = e.data.size
        if (off < 0 || off + n > out.size) return -1
        if (now - e.hitsFrom > PREFETCH_WINDOW_MS) { e.hitsFrom = now; e.hits = 0 }
        if (e.hits < Int.MAX_VALUE) e.hits++
        System.arraycopy(e.data, 0, out, off, n)
        Packets.put16(out, off, clientId)
        val age = ((now - e.storedAt) / 1000).toInt()
        if (age > 0) Dns.ageTtls(out, off, n, age)
        return n
    }

    /**
     * Süresi dolmuş ama [STALE_MAX_MS] içindeki olumlu cevabı verir (sunucu cevap vermediğinde kullanılır, RFC 8767). Kimlik
     * istemcininkiyle değiştirilir, bütün TTL'ler [STALE_TTL_S] olur. Kayıt yoksa, hâlâ taze ise (normal [get] kullanılır),
     * çok eskiyse, olumsuz cevapsa ya da [out]'a sığmıyorsa -1.
     */
    @Synchronized
    fun getStale(key: String, clientId: Int, out: ByteArray, off: Int): Int {
        if (maxEntries <= 0) return -1
        val e = map[key] ?: return -1
        val now = nowMs()
        if (now < e.storedAt) { map.remove(key); bytes -= e.data.size; return -1 }
        if (now < e.expiresAt || !e.staleOk) return -1
        if (now - e.expiresAt > STALE_MAX_MS) { map.remove(key); bytes -= e.data.size; return -1 }
        val n = e.data.size
        if (off < 0 || off + n > out.size) return -1
        System.arraycopy(e.data, 0, out, off, n)
        Packets.put16(out, off, clientId)
        Dns.setTtls(out, off, n, STALE_TTL_S)
        return n
    }

    /**
     * Ön yenileme (optimistic cache): kayıt son [PREFETCH_WINDOW_MS] içinde [PREFETCH_HITS]'ten çok isabet aldıysa ve TTL'inin son
     * onda birine girdiyse true döner (bir kez: yenileme yolda sayılır). İstemci bu arada eski cevabı 0 ms'de alır.
     */
    @Synchronized
    fun prefetchDue(key: String): Boolean {
        if (maxEntries <= 0) return false
        val e = map[key] ?: return false
        val now = nowMs()
        if (now < e.storedAt || now >= e.expiresAt || e.refreshing || e.hits <= PREFETCH_HITS) return false
        if (now - e.hitsFrom > PREFETCH_WINDOW_MS) return false
        if (e.expiresAt - now > e.lifeMs / 10) return false
        e.refreshing = true
        return true
    }

    @Synchronized
    fun size(): Int = map.size

    /** Saklanan cevapların toplam boyutu (bayt). */
    @Synchronized
    fun byteSize(): Int = bytes

    @Synchronized
    fun clear() { map.clear(); bytes = 0 }

    companion object {
        /** Süresi dolmuş olumlu cevap, yalnızca sunucu yanıtsızken bu kadar süre daha (6 saat) kullanılabilir. */
        const val STALE_MAX_MS = 6 * 3600 * 1000L

        /** Bayat cevapta istemciye verilen TTL (sn): kısa, çünkü sunucu dönünce hemen taze cevap alınmalı. */
        const val STALE_TTL_S = 30

        /** Cevap olumlu mu: QR=1, RCODE=0 ve en az bir cevap kaydı (olumsuz/boş cevaplar bayat olarak verilmez). */
        internal fun isPositive(b: ByteArray, off: Int, len: Int): Boolean {
            if (len < Packets.DNS_HDR) return false
            val flags = Packets.u16(b, off + 2)
            return (flags and 0x8000) != 0 && (flags and 0x000F) == 0 && (flags and 0x0200) == 0 && Packets.u16(b, off + 6) > 0
        }

        /** Sunucu çok uzun TTL verse bile en fazla 5 dakika tutulur. */
        const val MAX_TTL_S = 300
        /** Ön yenileme: bu pencerede bu kadar taze isabet (fazlası) kaydı "sık kullanılan" yapar. */
        const val PREFETCH_WINDOW_MS = 5 * 60 * 1000L
        const val PREFETCH_HITS = 3

        /** Tek bir cevabın önbelleğe alınabilecek en büyük boyu. */
        const val MAX_ENTRY_BYTES = 4096   // yönlendiricinin tünel arabelleğiyle aynı: saklanan her cevap sunulabilir
    }
}
