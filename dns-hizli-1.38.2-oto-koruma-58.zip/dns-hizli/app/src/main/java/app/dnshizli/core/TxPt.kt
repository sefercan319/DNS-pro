package app.dnshizli.core

/** Português (forma neutra, legível no Brasil e em Portugal). */
object TxPt : Tx() {
    override val lang = Lang.PT

    override val decimalSep = ','
    override val thousand = " mil"
    override val million = " mi"
    override fun percent(n: Int) = "$n%"
    override val dayU = "d"
    override val hourU = "h"
    override val minU = "min"
    override val secU = "s"
    override val justNow = "agora mesmo"
    override fun ago(span: String) = "há $span"

    override val OFF = "Desconectado"
    override val CONNECTING = "Conectando…"
    override val ON = "Conectado"
    override val ERROR = "Falha ao conectar"
    override val PAUSED = "Em pausa"
    override val HINT_OFF = "Toque na esfera para conectar"
    override val HINT_CONNECTING = "Pode levar alguns segundos"
    override val HINT_ERROR = "Toque para tentar de novo"
    override val HINT_PAUSED = "Toque para retomar agora"
    override val ERR_DEFAULT = "Não foi possível conectar"
    override fun selected(name: String) = "$name selecionado"
    override fun pausedUntil(time: String) = "Retoma às $time"
    override fun blockedShort(n: String) = "$n bloqueadas"
    override fun queriesShort(n: String) = "$n consultas"
    override fun cacheShort(pct: String) = "$pct em cache"

    override val SERVERS = "Servidores"
    override val FILTER_ALL = "Todos"
    override val FILTER_FAV = "Favoritos"
    override val FILTER_RECENT = "Recentes"
    override val EMPTY_FAV = "Ainda não há favoritos. Toque na estrela de um servidor."
    override val EMPTY_RECENT = "Você ainda não se conectou a nenhum servidor."
    override val EMPTY_FILTER = "Não há servidores nesta categoria."
    override val MEASURE = "Medir velocidades"
    override val MEASURING = "Medindo…"
    override val SORT = "Ordenar por velocidade"
    override val PULL_TO_MEASURE = "Puxe para medir"
    override val RELEASE_TO_MEASURE = "Solte para medir"
    override fun serversCount(n: Int) = if (n == 1) "1 servidor" else "$n servidores"
    override fun showAllServers(n: Int) = "Mostrar tudo ($n)"
    override val SHOW_LESS = "Mostrar menos"
    override val TAG_FAST = "Rápido"
    override val TAG_PRIVACY = "Privacidade"
    override val TAG_ADS = "Anúncios"
    override val TAG_FAMILY = "Família"
    override val TAG_SECURITY = "Segurança"
    override val VAR_OPEN = "Sem filtro"
    override val VAR_ADS = "Sem anúncios"
    override val VAR_SECURITY = "Segurança"
    override val VAR_FAMILY = "Família"
    override val A11Y_CONNECTED = "conectado"
    override val A11Y_ENCRYPTED = "criptografado"
    override fun favA11y(name: String) = "$name favorito"

    override val COPIED = "Copiado para a área de transferência"
    override val DISCONNECTED = "Desconectado"
    override val BACKUP = "Mudou para o servidor reserva"
    override val NO_REPLY = "Nenhum servidor respondeu"
    override val MEASURE_FIRST = "Meça as velocidades primeiro"
    override val CONNECT = "Conectar"
    override val UNDO = "Desfazer"
    override fun fastest(name: String, ms: Int) = "Mais rápido: $name · $ms ms"
    override fun switched(name: String) = "Mudando para $name"
    override fun hiddenToast(name: String) = "$name oculto"

    override val PRIMARY = "Principal"
    override val SECONDARY = "Secundário"
    override val COPY = "Copiar"
    override fun addressA11y(label: String, ip: String) = "Endereço $label: $ip"
    override val CONNECT_TO_THIS = "Conectar a este servidor"
    override val SWITCH_TO_THIS = "Mudar para este servidor"
    override val CONNECTED_NOW = "Conectado agora"
    override val ADD_FAV = "Adicionar aos favoritos"
    override val REMOVE_FAV = "Remover dos favoritos"
    override val MEASURE_THIS = "Medir velocidade"
    override val HIDE = "Ocultar da lista"
    override val UNHIDE = "Mostrar na lista"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Última medição: sem resposta · $ago" else "Última medição: $ms ms · $ago"
    override val NEVER_MEASURED = "Ainda não medido"
    override val ENC_SUPPORT = "DNS criptografado"
    override val ENC_NONE = "Não suportado"
    override val ENC_ONLY = "Aceita apenas conexões criptografadas"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Melhor $best ms · mediana $median ms · perda $lossPct%"
    override val HISTORY = "Histórico de medições"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: $n medições, sem resposta" else "$HISTORY: $n medições, mediana $median ms"

    override val QUICK_TITLE = "Troca rápida"
    override val QUICK_FAVORITES = "Favoritos"
    override val QUICK_RECENT = "Usados recentemente"
    override val PAUSE_FOR = "Pausar"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} h" else "$n min"
    override val RESUME = "Retomar"

    override val SETTINGS = "Configurações"
    override val MENU = "Menu"
    override val PERSONALIZE = "Personalizar"
    override val PZ_BACKGROUND = "Fundo"
    override val PZ_AUTO = "Tema automático"
    override val PZ_FEEL = "Vidro, texto e movimento"
    override val PZ_ACCESS = "Acessibilidade e energia"
    override val PRESET_FOOT = "Um visual pronto ajusta vidro, movimento e velocidade juntos, sem mexer no tema e no estilo. “Legível” deixa o texto pelo menos grande."
    override val FX_OFF_NOTE = "Os ajustes de animação estão ocultos porque o movimento está desligado. Voltam a aparecer ao ativar o movimento em Personalizar."
    override val PZ_FOLDED = "Seções recolhidas"
    override val PZ_UNFOLDED = "Seções expandidas"
    override val PZ_PRESET_CUSTOM = "Personalizado"
    override val THIS_DEVICE = "Este dispositivo"
    override val DEVICE_AUTO = "Adaptar ao dispositivo"
    override val DEVICE_AUTO_NOTE = "Reconhece o telefone e ajusta movimento e dicas. Desligado, valem só as suas escolhas."
    override val DEVICE_SYSTEM = "Sistema"
    override val DEVICE_CLASS = "Classe do dispositivo"
    override val DEVICE_RISK = "Risco de ser fechado em segundo plano"
    override val OPT_TIER = listOf(
        "Básico",
        "Médio",
        "Alto",
    )
    override val OPT_RISK = listOf(
        "Baixo",
        "Médio",
        "Alto",
    )
    override val DEVICE_ADVICE = listOf(
        "Este sistema fecha apps em segundo plano de forma agressiva. Nas definições da bateria, coloque o DNS Hızlı em «sem restrições» e permita o início automático; caso contrário a proteção pode parar sozinha.",
        "O One UI pode pôr apps sem uso em suspensão. Nas definições da bateria, coloque o DNS Hızlı em «Sem restrições» e retire-o da lista «Apps adormecidas».",
        "Dispositivo com pouca memória: a lista leve e um movimento mais sóbrio são escolhidos automaticamente; não precisa fazer nada.",
        "ROM personalizada detetada: sem restrições de bateria do fabricante; basta a definição padrão do Android.",
        "Um sistema próximo do Android puro: não é preciso nenhuma definição de bateria extra.",
        "Dispositivo potente: todos os efeitos visuais e o movimento correm sem problemas.",
    )
    override val DEVICE_APPLIED_MOTION = "Aplicado: movimento simplificado para este dispositivo."
    override val DEVICE_UNKNOWN = "Dispositivo ainda não reconhecido."
    override val DEVICE_OFF_NOTE = "Adaptação desligada: valem só as suas escolhas."
    override val PZ_ADAPTED = "Movimento sóbrio para este dispositivo"
    override val SEC_THEME_COLOR = "Tema e cor"
    override val SEC_SHAPE = "Estilo e esfera"
    override val SEC_LANG_ICON = "Idioma e ícone"
    override val GROUP_SPECIAL = "Especiais"
    override val GROUP_LIGHT = "Claro"
    override val GROUP_DARK = "Escuro"
    override val PRESET = "Aspeto pronto"
    override val OPT_PRESET = listOf(
        "Sóbrio",
        "Equilibrado",
        "Vivo",
        "Economia de bateria",
        "Legível",
    )
    override val PRESET_NOTES = listOf(
        "Pouco movimento, vidro leve: poupa bateria e olhos.",
        "Vidro médio, movimento leve; ideal para a maioria.",
        "Movimento total, vidro intenso e bolhas.",
        "Vidro quase opaco, sem movimento: usa o mínimo de bateria e CPU.",
        "Vidro denso e texto pelo menos grande: o texto se destaca claramente do fundo.",
    )
    override val PRESET_DONE = "Aspeto aplicado"
    override val RESET_LOOK = "Repor aparência"
    override val RESET_LOOK_BODY = "Tema, estilo, esfera, fundo, vidro, tamanho do texto e movimento voltam ao padrão. As definições de DNS, filtro e outras não mudam. Pode anular."
    override val RESET_LOOK_BTN = "Repor"
    override val RESET_LOOK_DONE = "Aparência reposta"
    override val MOTION_NOTE_LOWPOWER = "Modo de poupança ativo: o movimento aparece desligado."
    override val MOTION_NOTE_DEVICE = "Neste dispositivo o movimento é simplificado automaticamente (Adaptar ao dispositivo)."
    override val DNS_SETTINGS = "Configurações de DNS"
    override val CONN_APPS = "Conexão e apps"
    override val STATS_HISTORY = "Estatísticas e histórico"
    override val SEC_LOOK = "Aparência"
    override val SEC_LIST = "Lista de servidores"
    override val SEC_DATA = "Dados"
    override val ABOUT = "Sobre"
    override val LANGUAGE = "Idioma"
    override val LANG_AUTO = "Automático (idioma do sistema)"
    override val THEME = "Tema"
    override val THEME_AUTO = "Automático"
    override val THEME_AUTO_NOTE = "Automático · segue o modo claro/escuro"
    override val CUSTOM_STYLE = "Meu estilo"
    override val FX_PART = "Parte de animação"
    override val FX_PART_AUTO = "Animação própria do estilo"
    override val FX_KIND_NAMES = listOf("Anel", "Gota", "Fatia", "Folha", "Faísca", "Varredura", "Vidro", "Fumaça", "Órbita", "Pétala", "Bolha", "Relâmpago", "Cristal", "Vaga-lume", "Espiral", "Raio", "Estilhaço", "Pixel")
    override val FX_KIND = "Tipo de animação"
    override val FX_FORM = "Forma da animação"
    override val SOUND_PART = "Parte do som"
    override val SOUND_PART_AUTO = "Automático (pacote)"
    override val SOUND_VOICE = "Timbre"
    override val SOUND_CONTOUR = "Padrão de notas"
    override val SOUND_REGISTER = "Registro"
    override val VOICE_NAMES = listOf("Bolha", "Vidro", "Clique", "Madeira", "Pixel", "Ar", "Gota", "Sino", "Bip", "Kalimba", "Cromo", "Pad", "Chip", "Sonar", "Lumen", "Duru")
    override val SOUND_CONTOUR_NAMES = listOf("Toque único", "Tríade ascendente", "Descendente", "Ponto duplo", "Ondulação", "Salto de oitava", "Quinta", "Subida lenta", "Escala rápida", "Fechamento", "Trêmolo", "Acorde")
    override val SOUND_REGISTER_NAMES = listOf("Normal", "Agudo")
    override val CUSTOM_SECTION_LOOK = "Aparência"
    override val CUSTOM_SECTION_MOTION = "Movimento"
    override val CUSTOM_SECTION_SOUND = "Som"
    override val CUSTOM_SECTION_TOOLS = "Ferramentas"
    override val CUSTOM_SECTION_SAVED = "Estilos salvos"
    override val CUSTOM_SLOT_EMPTY = "Vazio · toque para salvar"
    override val STYLE_APPLY = "Aplicar"
    override val STYLE_DELETE = "Excluir"
    override val ORB_AMOUNT = "Altura da onda líquida"
    override val FX_SIZE = "Tamanho da animação"
    override fun customSlotName(slot: Int): String = "Estilo ${slot + 1}"
    override val CUSTOM_STYLE_NOTE = "Você pode escolher cada parte separadamente. A parte escolhida substitui a animação ou o som próprios do estilo; o resto do estilo continua igual."
    override val CUSTOM_SHUFFLE = "Embaralhar partes"
    override val CUSTOM_RESET = "Voltar aos padrões do estilo"
    override val CUSTOM_LISTEN = "Tocar o som atual"
    override val CUSTOM_RANDOM_DONE = "Partes embaralhadas"
    override val CUSTOM_RESET_DONE = "Redefinido"
    override val CUSTOM_SUMMARY = "Agora"
    override val CUSTOM_THEME = "Tema personalizado"
    override val CUSTOM_SKY = "Céu"
    override val CUSTOM_ACCENT = "Destaque"
    override val CUSTOM_SKY_NAMES = listOf("Manhã", "Mar", "Verde", "Rosa", "Meia-noite", "Chão de floresta", "Carvão", "Amanhecer vermelho")
    override val CUSTOM_ACCENT_NAMES = listOf("Turquesa", "Azul", "Roxo", "Rosa", "Laranja", "Verde")
    override val FX_VARIANT = "Estilo do efeito ao toque"
    override val FX_VARIANT_NAMES = listOf("Original", "Denso", "Giratório", "Pulso duplo", "Convergente", "Inclinado", "Espelhado", "Crescente", "Rápido")
    override val ORB_FLOW = "Movimento líquido"
    override val ORB_FLOW_NAMES = listOf("Calmo", "Maré", "Anéis", "Ondulação", "Gêmeos", "Onda triangular", "Quadrado suave", "Fervura", "Espiral", "Parado")
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Prado"
        "ocean" -> "Oceano"
        "sunset" -> "Pôr do sol"
        "lavender" -> "Lavanda"
        "coral" -> "Coral"
        "mint" -> "Menta"
        "night" -> "Noite"
        "amoled" -> "Preto (AMOLED)"
        "sakura" -> "Sakura"
        "honey" -> "Honey"
        "aurora" -> "Aurora"
        "peach" -> "Pêssego"
        "citrus" -> "Cítrico"
        "rose" -> "Rosa"
        "glacier" -> "Glaciar"
        "sand" -> "Areia"
        "lagoon" -> "Lagoa"
        "cocoa" -> "Cacau"
        "candy" -> "Doce"
        "forest" -> "Floresta"
        "ember" -> "Brasa"
        "plum" -> "Ameixa"
        "slate" -> "Ardósia"
        "fjord" -> "Fiorde"
        "marigold" -> "Calêndula"
        "lilac" -> "Lilás"
        "pistachio" -> "Pistache"
        "tangerine" -> "Tangerina"
        "bubblegum" -> "Chiclete"
        "seafoam" -> "Espuma do mar"
        "dune" -> "Duna"
        "mist" -> "Névoa"
        "matcha" -> "Matcha"
        "ivory" -> "Marfim"
        "orchid" -> "Orquídea"
        "twilight" -> "Crepúsculo"
        "obsidian" -> "Obsidiana"
        "espresso" -> "Espresso"
        "neon" -> "Neon"
        "sapphire" -> "Safira"
        "pine" -> "Pinheiro"
        "wine" -> "Vinho"
        "graphite" -> "Grafite"
        "teal" -> "Turquesa noturno"
        "ink" -> "Tinta"
        "copper" -> "Cobre"
        "northern" -> "Aurora boreal"
        "custom" -> "Personalizado"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Tema: $name"
    override val THEME_SCHEDULE = "Tema noturno por horário"
    override val THEME_SCHEDULE_NOTE = "No Automático, Noite das 22:00 às 07:00"
    override val GLASS = "Opacidade do vidro"
    override val BUBBLES = "Bolhas"
    override val STYLE = "Estilo"
    override val STYLE_NOTES = listOf(
        "Vidro, brilho e bolhas: o visual original.",
        "Céu, grama verde, gotas de vidro e botões de gel.",
        "Cidade, música e juventude: arranha-céus, alto-falante, anéis, estrelas e raios.",
        "Natureza e tecnologia: Terra verde, turbinas eólicas, painéis solares e folhas.",
        "Rosa e roxo holográficos, corações cromados, bolhas, brilhos e janelas de pixels.",
        "Luz turquesa, verde e amarela, feixe brilhante e ondas de malha transparentes.",
        "Vidro azul-índigo translúcido com luz branca nas bordas e reflexos refratados.",
        "Calmo e sóbrio: fundo menta, água translúcida embaixo, superfícies de borda fina e pouco movimento."
    )
    override val WALLPAPER = "Foto de fundo"
    override val WP_OFF = "Nenhuma"
    override val WP_ON = "Foto"
    override val WP_PICK = "Escolher uma foto da galeria"
    override val WP_PICK_NOTE = "Fica só no seu telefone e nunca é enviada. O véu se reforça sozinho quando necessário para manter o texto legível."
    override val WP_PRESETS = "Imagens incluídas"
    override val WP_PRESETS_NOTE = "28 imagens que vêm com o app. Sem internet."
    override val WP_REMOVE = "Remover a foto"
    override val WP_DIM = "Intensidade do véu"
    override val WP_BLUR = "Desfoque"
    override val OPT_WP_BLUR = listOf("Não", "Leve", "Forte")
    override val WP_SAVED = "Fundo definido"
    override val WP_FAILED = "Não foi possível abrir a foto"
    override val WP_REMOVED = "Fundo removido"
    override val APP_ICON = "Ícone do app"
    override val ICON_NOTES = listOf(
        "Globo de vidro: o ícone original.",
        "Uma gota de vidro sobre céu e grama.",
        "Cidade lima-turquesa com raios de sol e botão de ligar.",
        "Terra verde brilhante com uma folha brotando.",
        "Um coração cromado brilhante em rosa e roxo holográficos.",
        "Globo de vidro sobre brilho turquesa-amarelo e ondas de luz.",
        "Uma esfera de vidro fosco com borda brilhante sobre luz azul-índigo.",
        "Folhas deslizando sobre a água, com um selo de vidro DNS."
    )
    override val ICON_SET = "O ícone muda ao sair do app"
    override val ICON_NOTE = "Se o atalho da tela inicial sumir, adicione o app de novo."
    override val ICON_FAILED = "Não foi possível alterar o ícone"
    override val HELP_WHY_TITLE = "Por que este app?"
    override val HELP_WHY_BODY = "O DNS Hızlı é pequeno e simples, feito por uma só pessoa, sem uma grande empresa por trás. Sem conta nem anúncios: você escolhe o DNS, a criptografia, a quais apps ele se aplica e a aparência."
    override val HELP_WHY_TAIL = "Talvez não seja melhor que a concorrência, mas funciona e vale a pena experimentar."
    override val TROUBLE = "Resolver problemas"
    override val TROUBLE_RECHECK = "Verificar de novo"
    override val DIAG_ROW = "Relatório de diagnóstico"
    override val DIAG_TITLE = "Relatório de diagnóstico"
    override val DIAG_NOTE = "O relatório contém apenas a versão, o modelo do aparelho e os códigos de configuração. Sem nomes de domínio, endereços IP ou dados pessoais. Nada é enviado a menos que você compartilhe."
    override val DIAG_SHARE_BTN = "Compartilhar"
    override val TROUBLE_ALL_OK = "Tudo parece certo. Se ainda assim não conectar, tente outro servidor."
    override val TROUBLE_SOME = "Pontos que precisam de atenção:"
    override val T_NET = "Internet"
    override val NET_OK = "conectada."
    override val NET_BAD = "ausente ou limitada. Verifique o Wi-Fi ou os dados móveis."
    override val T_PERM = "Permissão de VPN"
    override val PERM_OK = "concedida."
    override val PERM_BAD = "ainda não concedida. O Android vai pedir ao conectar; permita."
    override val T_VPN = "Outra VPN"
    override val VPN_OK = "nenhuma."
    override val VPN_BAD = "parece ativa. O Android permite só uma VPN por vez; desative-a."
    override val T_DNS = "DNS privado do Android"
    override val T_LEAK = "Vazamento de DNS"
    override val YT_ADS = "Servidores de anúncios do YouTube (parcial)"
    override val YT_ADS_NOTE = "Somente na versão pessoal. Bloqueia no nível DNS os servidores de anúncios conhecidos do YouTube. É parcial: alguns anúncios ainda passam; o conteúdo de vídeo não é afetado."
    override val SITE_DIAG = "Por que o site não abre?"
    override val SITE_NO_NAME = "Digite um domínio válido, ex.: exemplo.com.br."
    override val SITE_VPN_OFF = "O DNS Hızlı está desligado. Conecte-se primeiro e tente o site de novo."
    override val SITE_USER_BLOCK = "Este nome está na sua lista de bloqueio."
    override val SITE_LIST_BLOCK = "Este nome está na lista de anúncios e rastreadores; isso pode estar quebrando o site."
    override val SITE_CANARY = "O navegador usa este nome para verificar o DNS criptografado. Ele é bloqueado de propósito, então não é um problema."
    override val SITE_DOH = "Este provedor de DNS criptografado é desligado de propósito pelo gateway."
    override val SITE_ALLOWED = "Este nome está na sua lista de permitidos; o bloqueio de anúncios não o bloqueia."
    override val SITE_NOT_OURS = "O DNS Hızlı não bloqueia este nome. O problema provavelmente está no site ou no navegador. Para testar: desligue o desvio de DPI ou escolha outro servidor."
    override val SITE_ALLOW_BTN = "Permitir"
    override val LEAK_OK = "O DNS do sistema passa pelo nosso túnel."
    override val LEAK_BAD = "O DNS do sistema sai do túnel; as consultas podem chegar à operadora."
    override val PDNS_OK = "desativado ou automático, sem problema."
    override val PDNS_BAD = "está fixo em um servidor e pode ignorar o DNS deste app. Em Configurações > Rede > DNS privado escolha Automático ou Desativado."
    override val SEARCH = "Buscar"
    override val SEARCH_HINT = "Nome ou dono do servidor"
    override val SEARCH_CLEAR = "Limpar"
    override val SHARE_RESULTS = "Compartilhar resultados das medições"
    override val SHARE_RESULTS_HEAD = "Medições do DNS Hızlı (mais rápido primeiro)"
    override val NO_RESULTS = "Faça uma medição primeiro"
    override val CUSTOM_EDIT = "Editar"
    override fun customUpdated(name: String) = "$name atualizado"
    override val KEEP_HISTORY = "Guardar histórico"
    override val KEEP_HISTORY_NOTE = "Desativado, servidores recentes, histórico e medições não são registrados. Os dados existentes ficam."
    override val MOTION = "Animações"
    override val TEXT_SIZE = "Tamanho do texto"
    override val HIGH_CONTRAST = "Alto contraste"
    override val HIGH_CONTRAST_NOTE = "Vidro mais opaco e texto mais escuro"
    override val MINIMAL = "Visual simples"
    override val MINIMAL_NOTE = "Oculta os filtros e a linha de estatísticas"
    override val LOW_POWER = "Modo de economia"
    override val LOW_POWER_NOTE = "Desliga todo movimento, poupa a bateria"
    override val HAPTICS = "Vibração"
    override val HAPTICS_NOTE = "Retorno leve ao toque"
    override val ENCRYPTION = "DNS criptografado"
    override val ENCRYPTION_NOTE = "Auto: primeiro DoT, depois DoH, por último DNS simples"
    override val AUTO_CONNECT = "Conectar ao abrir o app"
    override val AUTO_CONNECT_NOTE = "Conecta ao último servidor quando você abre o app"
    override val CONNECT_ON_BOOT = "Conectar ao iniciar"
    override val CONNECT_ON_BOOT_NOTE = "Conecta sozinho depois que o telefone reinicia"
    override val AUTO_FASTEST = "Conectar ao mais rápido"
    override val AUTO_FASTEST_NOTE = "A esfera escolhe o servidor mais rápido da última medição"
    override val REFRESH_ON_NET = "Renovar ao trocar de rede"
    override val REFRESH_ON_NET_NOTE = "O DNS é renovado ao alternar entre Wi-Fi e dados móveis"
    override val NOTIFY_DROP = "Avisar se a conexão cair"
    override val NOTIFY_DROP_NOTE = "Notificação com botão para reconectar em quedas inesperadas"
    override val NOTIFY_CONNECT = "Avisar ao conectar"
    override val NOTIFY_CONNECT_NOTE = "Uma notificação curta quando a conexão é feita"
    override val NOTIFY_STOP = "Avisar ao desconectar"
    override val NOTIFY_STOP_NOTE = "Uma notificação curta quando você desconecta"
    override val NOTIFY_TIMEOUT = "Avisar se o tempo esgotar"
    override val NOTIFY_TIMEOUT_NOTE = "Notificação se o servidor DNS parar de responder"
    override val NOTIF_PERM = "Permissão de notificações"
    override val PERM_ALLOWED = "Permitida"
    override val PERM_BLOCKED = "Desligada · corrigir"
    override val NOTIF_CONNECTED_TITLE = "DNS conectado"
    override val NOTIF_STOPPED_TITLE = "DNS desconectado"
    override val NOTIF_STOPPED_TEXT = "A proteção está desligada"
    override val NOTIF_TIMEOUT_TITLE = "Tempo do DNS esgotado"
    override val FAIL_CLOSED = "Bloquear DNS se cair"
    override val FAIL_CLOSED_NOTE = "Se a conexão cair, as consultas DNS não vazam para a operadora; falham até reconectar"
    override val FILTER_MEM = "Memória do filtro"
    override val OPT_FILTER_MEM = listOf("Auto", "Leve", "Completa")
    override val FILTER_MEM_NOTE = "Auto: sem a lista grande se pouca memória. Leve: sem. Completa: com"
    override val ERR_NO_APPS = "Nenhuma app escolhida, a proteção não foi iniciada. Escolha apps ou mude para «Todas as apps»."
    override val NOTIF_SEALED = "DNS bloqueado ao reconectar"
    override val ERR_SEALED = "Não foi possível conectar. O DNS está bloqueado para não vazar consultas. Toque em Parar para liberar."
    override val SEALED_INFO = "DNS bloqueado até a conexão voltar"
    override val LATENCY_TITLE = "Latência por consulta"
    override val LATENCY_EMPTY = "Aparece ao vivo quando conectado e com consultas chegando"
    override val FILTER_MINE = "Minha própria lista"
    override val MINE_PASTE = "Importar da área de transferência"
    override val MINE_PASTE_NOTE = "Arquivo hosts ou um domínio por linha"
    override val MINE_FILE = "Importar de um arquivo"
    override val MINE_FILE_NOTE = "Um .txt ou arquivo hosts do celular"
    override val MINE_EXPORT = "Copiar minha lista de bloqueio"
    override val MINE_EXPORT_NOTE = "Para a área de transferência, em formato hosts"
    override val MINE_CLEAR = "Apagar lista importada"
    override val MINE_FOOT = "Lê linhas hosts, listas simples de domínios, regras AdBlock (||domínio^ e exceções @@), dnsmasq, Unbound e RPZ. Até 50.000 nomes. Sua lista de permissões sempre vence."
    override val MINE_NOTHING = "Nenhum domínio válido encontrado"
    override val MINE_CLIP_EMPTY = "A área de transferência está vazia"
    override val MINE_FILE_ERR = "Não foi possível ler o arquivo"
    override val MINE_CLEARED = "Lista importada apagada"
    override val MINE_CLEAR_ASK = "Apagar a lista importada?"
    override val MINE_CUT = "Limite atingido, o restante foi ignorado"
    override fun notifTimeout(name: String) = "$name não responde. Tentando de novo."
    override val MOD_DPI = "Contornar DPI"
    override val MOD_ADS = "Anúncios+"
    override val MOD_DPI_SUB = "Abre sites bloqueados"
    override val MOD_ADS_SUB = "Filtra além do DNS"
    override val MOD_ON = "Ativo"
    override val MOD_OFF = "Inativo"
    override val BLOCK_QUIC = "Bloquear QUIC"
    override val BLOCK_QUIC_NOTE = "Os apps voltam ao TCP, então Contornar DPI e Anúncios+ também os cobrem"
    override val UDP_DECOY = "Pacotes isca de voz/STUN (experimental)"
    override val UDP_DECOY_NOTE = "Iscas de TTL baixo antes da voz Discord/STUN; não chegam ao servidor"
    override val DPI_LISTED_ONLY = "DPI só para sites bloqueados"
    override val DPI_LISTED_ONLY_NOTE = "Só sites da lista; os demais intactos (todos se a lista estiver vazia)"
    override val DNS_RACE = "Corrida DNS"
    override val DNS_RACE_NOTE = "Se o servidor atrasa, a consulta vai aos dois; vence o mais rápido"
    override val AUTO_DPI = "DPI automático"
    override val AUTO_DPI_NOTE = "Ativa o DPI sozinho ao ver bloqueio; desfaz quando acalma"
    override val MITM_MODE = "Modo navegador (experimental)"
    override val MITM_MODE_NOTE = "Oculta anúncios no navegador; requer instalar o certificado"
    override val MITM_CA = "Certificado do modo navegador"
    override val MITM_CA_BODY = listOf(
        "Cria uma autoridade certificadora local exclusiva deste dispositivo e salva o certificado em Downloads.",
        "Vá a Configurações > Segurança > Criptografia e credenciais > Instalar certificado > Certificado de CA e escolha dnshizli-ca.crt.",
        "A chave privada nunca sai do dispositivo.",
        "Sem instalar, ou se o app não for navegador, as conexões não são alteradas.",
        "Pode remover quando quiser nas configurações.",
        "Funciona com Anúncios+ ou DPI ativos.",
    )
    override val MITM_CA_BUTTON = "Salvar e abrir configurações"
    override val QUIC_SPLIT = "Alterar QUIC Initial (experimental)"
    override val QUIC_SPLIT_NOTE = "O 1º pacote QUIC é refeito, uma isca vai antes; bloqueio QUIC off e DPI on"
    override val QUIC_DNS = "Tentar DNS sobre QUIC (experimental)"
    override val QUIC_DNS_NOTE = "Primeiro DoQ/DoH3 se o servidor suportar; se o UDP falhar, usa DoT/DoH"
    override val ECH_ALLOW = "Permitir ECH"
    override val ECH_ALLOW_NOTE = "Registros ECH passam: o DPI é contornado, mas o Ads+ não vê o nome nesses sites"
    override val AUTO_SHIELD = "Proteção automática"
    override val AUTO_SHIELD_NOTE = "Detecta ataques e bloqueios, ativa contramedidas sozinha e aprende quais funcionam"
    override val GW_TRIPPED = "Problema de conexão detectado: Contornar DPI e Anúncios+ foram desativados"
    override val MOD_FAILED = "Não foi possível ativar. Permissão de VPN negada ou outra VPN ativa."
    override fun gwOn(modules: String) = "Gateway ativo: $modules"
    override fun gwOnStats(modules: String, blocked: String) = "Gateway ativo: $modules · $blocked bloqueados"
    override fun modOn(name: String) = "$name ativado"
    override fun modOff(name: String) = "$name desativado"
    override fun modAdsCount(n: String) = "$n bloqueados"
    override fun modDpiCount(n: String) = "$n conexões divididas"
    override fun latencyLine(avg: String, max: String, timeouts: Int) = "média $avg · máx. $max" + (if (timeouts > 0) " · $timeouts esgotados" else "")
    override fun mineCount(n: Int) = "$n domínios"
    override fun mineAdded(n: Int) = "$n domínios adicionados"
    override fun mineExcepted(n: Int) = "$n domínios omitidos por exceções"
    override fun mineCopied(n: Int) = "$n domínios copiados"
    override val CACHE = "Cache de DNS"
    override val CLEAR_CACHE = "Limpar cache"
    override val CACHE_CLEARED = "Cache limpo"
    override val ONLY_CONNECTED = "Disponível quando conectado"
    override val RULE_WIFI = "Servidor do Wi-Fi"
    override val RULE_MOBILE = "Servidor dos dados móveis"
    override val RULE_AUTO = "Automático"
    override val RULE_AUTO_NOTE = "O último servidor que você usou"
    override val COMPACT = "Lista compacta"
    override val COMPACT_NOTE = "Linhas mais curtas, sem descrição"
    override val HIDDEN = "Servidores ocultos"
    override val HIDDEN_NONE = "Nenhum"
    override val STAT_QUERIES = "Consultas no total"
    override val STAT_HITS = "Respondidas do cache"
    override val STAT_BLOCKED = "Bloqueadas (estimativa)"
    override val STAT_TIME = "Tempo total conectado"
    override val WEEK = "Últimos 7 dias"
    override fun weekA11y(total: String) = "$total consultas nos últimos 7 dias"
    override val WEEKDAYS = listOf("Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom")
    override val EXPORT = "Exportar configurações"
    override val IMPORT = "Importar configurações"
    override val EXPORTED = "Código das configurações copiado"
    override val IMPORTED = "Configurações carregadas"
    override val IMPORT_BAD = "Não há um código de configurações válido na área de transferência"
    override val RESET_SETTINGS = "Redefinir configurações"
    override val RESET_STATS = "Redefinir estatísticas"
    override val CONFIRM = "Tem certeza?"
    override val RESET = "Redefinir"
    override val RESET_DONE = "Redefinido"
    override val LOG = "Registro de diagnóstico"
    override val HELP = "Como funciona?"
    override val VPN_SETTINGS = "Configurações de VPN do sistema"
    override val SHARE_APP = "Compartilhar o app"
    override val RATE_APP = "Avaliar o app"
    override val FEEDBACK = "Enviar comentários"
    override fun shareAppText(url: String) = "$APP conecta você aos DNS populares com um toque: $url"
    override val VERSION = "Versão"
    override val OPT_BUBBLES = listOf("Não", "Poucas", "Muitas")
    override val OPT_MOTION = listOf("Todas", "Poucas", "Não")
    override val OPT_CACHE = listOf("Não", "Pequeno", "Normal", "Grande")
    override val OPT_ENCRYPTION = listOf("Auto", "DoT", "DoH", "Não")
    override val PLAIN_DNS = "DNS simples"

    override val LOG_NOTE = "Só eventos de conexão são guardados. Nunca nomes de consultas nem dados pessoais."
    override val LOG_EMPTY = "Ainda não há registros."
    override val SHARE = "Compartilhar"
    override val CLEAR = "Limpar"
    override val CLEARED = "Limpo"
    override val HELP_SECTIONS = listOf(
        "O que é DNS?" to
            "DNS é o serviço que transforma endereços da internet (como example.com) em números que os aparelhos entendem. " +
            "O DNS usado pode afetar a velocidade, a privacidade e o que é bloqueado.",
        "O que o app faz?" to
            "Ele usa o servidor DNS escolhido em todos os apps. Para isso abre uma interface VPN local no telefone, " +
            "mas o seu tráfego não vai para nenhum servidor VPN. Só as consultas DNS são enviadas ao servidor escolhido; " +
            "todo o resto segue o caminho normal.",
        "DNS criptografado (DoT / DoH)" to
            "Nos servidores compatíveis, as consultas são criptografadas: ninguém na rede (dono do Wi-Fi, operadora) vê " +
            "quais sites você visita nem altera as respostas. No Automático, DoT é tentado primeiro e depois DoH; se nenhum funcionar, " +
            "usa-se DNS simples. Você é avisado quando isso acontece, e o app tenta voltar à criptografia a cada troca de rede e a cada 10 minutos. " +
            "Com \"Criptografia estrita\" ativada, o DNS simples nunca é usado. A tela inicial mostra o método em uso.",
        "Teste de conexão" to
            "☰ > Configurações de DNS > Teste de conexão envia consultas DNS reais pelo túnel. Ele mostra que " +
            "o DNS realmente responde pelo servidor escolhido, com que velocidade, se o servidor valida assinaturas DNSSEC " +
            "e se bloqueia um domínio de anúncios conhecido.",
        "Privacidade" to
            "Sem conta, sem coleta de dados, sem anúncios. O app não guarda nomes de consultas e não envia nada por conta própria. " +
            "Suas consultas vão apenas ao provedor DNS escolhido, sob a política de privacidade dele. " +
            "O DNS criptografado (DoT/DoH) impede que qualquer pessoa na rede leia ou altere suas consultas. Antes de enviar, o app remove dados extras que poderiam identificar o dispositivo (sub-rede do cliente, cookies, IDs), preenche as mensagens para esconder o tamanho e descarta os tíquetes de sessão TLS quando a rede muda. " +
            "Para ser honesto: sem um relé, o provedor DNS ainda vê seu endereço IP público (ele precisa responder a você), e um erro de certificado pode significar que alguém está interferindo na conexão. " +
            "O registro de diagnóstico contém só eventos de conexão.",
        "Bateria e recursos" to
            "Em segundo plano consome muito pouco. Com a tela desligada não há nada em loop; " +
            "ele só trabalha quando chega uma consulta DNS. Conexões criptografadas se fecham sozinhas quando ociosas.",
        "Bom saber" to
            "O Android permite apenas uma VPN por vez; com outro app de VPN ativo, este não conecta. " +
            "O \"DNS seguro\" de alguns navegadores e o \"DNS privado\" do Android com um nome fixo usam o próprio servidor " +
            "e podem ignorar este redirecionamento; basta deixá-los em \"Automático\" ou \"Desativado\". " +
            "Toque e segure a esfera para trocar rápido de servidor ou pausar a conexão por um tempo.",
    )

    override val NOTIF_CHANNEL = "Status da conexão"
    override val NOTIF_CHANNEL_NOTE = "Exibida enquanto a conexão DNS está ativa"
    override val NOTIF_ALERT_CHANNEL = "Alertas de conexão"
    override val NOTIF_CONNECTING = "Conectando…"
    override val NOTIF_STOP = "Desconectar"
    override val NOTIF_NEXT = "Próximo"
    override val NOTIF_DROP_TITLE = "A conexão DNS caiu"
    override val NOTIF_RECONNECT = "Reconectar"
    override fun notifOn(name: String, proto: String) = "Conectado a $name · $proto"
    override fun notifPaused(time: String) = "Em pausa · retoma às $time"
    override val TILE_ON = "Conectado"
    override val TILE_OFF = "Desligado"
    override val WIDGET_TAP = "Toque: conectar / desconectar"
    override val ERR_PERMISSION = "A permissão de VPN não foi concedida"
    override val ERR_ESTABLISH = "Não foi possível abrir a interface VPN. Outra VPN pode estar ativa."
    override fun errNoReply(name: String) = "$name não respondeu"
    override val PHONE_BYPASS = "O celular não usa este DNS (DNS privado?)"
    override fun errNoProto(name: String, proto: String) = "$name não suporta $proto"
    override val ERR_SOCKET = "Não foi possível acessar a rede"
    override fun errPrivateDns(host: String) = "O DNS privado do Android está fixado em $host e ignora este app. Defina Configurações > Rede > DNS privado como Automático ou Desativado."
    override val ERR_REVOKED = "O sistema encerrou a conexão"
    override val ERR_TUNNEL = "O túnel foi fechado inesperadamente"
    override val ERR_UNKNOWN = "Ocorreu um erro inesperado"

    override val CONSENT_TITLE = "Antes de conectar"
    override val CONSENT_BODY = listOf(
        "$APP usa a interface VPN do Android para encaminhar suas consultas DNS (os nomes dos sites que você visita) ao servidor DNS escolhido.",
        "Seu tráfego não é enviado a nenhum servidor VPN; só as consultas DNS vão ao provedor escolhido. Nos servidores compatíveis " +
            "elas são criptografadas (DoT/DoH); nos demais seguem sem criptografia. Vale a política de privacidade do provedor." +
            " Se você ativar «$MOD_DPI» ou «$MOD_ADS», todo o tráfego passa por um relé que funciona apenas dentro do telefone; continua sem ser enviado a nenhum outro lugar.",
        "O app não coleta dados pessoais, não guarda nomes de consultas e não compartilha nada.",
        "Se continuar, o Android mostrará um pedido de conexão VPN; toque em \"OK\".",
    )
    override val CONSENT_OK = "Entendi, continuar"
    override val CLOSE = "Fechar"
    override val BACK = "Voltar"

    // ---- 3. sürüm ----
    override val RESUMING = "Retomando…"
    override val DOWNGRADED = "Falha na criptografia, usando DNS simples"
    override val UPGRADED = "De volta ao DNS criptografado"
    override val ODOH = "Oblivious DoH (ODoH)"
    override val OPT_ODOH = listOf("Não", "Reserva", "Estrito")
    override val ODOH_NOTE = "O relé vê seu IP, não a consulta; o servidor vê a consulta, não você."
    override val DOWNGRADED_ODOH = "ODoH indisponível, usando uma conexão criptografada normal"
    override val NOTIF_ODOH_TITLE = "ODoH não está ativo"
    override fun notifOdoh(name: String) = "Não foi possível alcançar os relés ODoH. Usando conexão normal com $name; o app continua tentando voltar ao ODoH."
    override val ERR_NO_ODOH = "Não foi possível conectar via ODoH: relés ou destinos não respondem"
    override val NOTIF_DOWNGRADE_TITLE = "O DNS não está criptografado"
    override fun notifDowngrade(name: String) = "Não foi possível criar uma conexão criptografada com $name. O DNS simples está em uso; o app tentará voltar à criptografia."
    override fun backupUsed(failed: String, used: String) = "$failed não respondeu, conectado a $used"
    override val NOTIF_RETRYING = "Conexão perdida, tentando de novo…"
    override fun errNoEncrypted(name: String) = "Não foi possível criptografar a conexão com $name"
    override fun errUntrusted(name: String) = "Não foi possível verificar o certificado de $name; a rede ou um software pode estar interferindo nas conexões criptografadas"
    override val APPLYING = "Aplicando a nova configuração à conexão"
    override val CONFIRM_DISCONNECT = "Desconectar?"
    override val DISCONNECT = "Desconectar"

    override val SEC_NOTIF = "Notificações"
    override val SEC_EXPERIMENTAL = "Experimental"
    override val SHOW_ADVANCED = "Mostrar ajustes avançados"
    override val SHOW_ADVANCED_NOTE = "Mostra linhas técnicas; os ajustes ocultos continuam ativos"
    override val STRICT_ENC = "Criptografia estrita"
    override val STRICT_ENC_NOTE = "Nunca recorrer ao DNS simples"
    override val IP_MODE = "Versão do IP"
    override val IP_MODE_NOTE = "Primeiro se tenta a da sua rede; a outra fica de reserva"
    override val OPT_IP_MODE = listOf("IPv4 + IPv6", "Só IPv4")
    override val FILTER = "Bloqueio"
    override val FILTER_LEVEL = "Anúncios e rastreadores"
    override val OPT_FILTER = listOf(
        "Off",
        "Básico",
        "Médio",
        "Rígido",
    )
    override val FILTER_NOTES = listOf(
        "Nada é filtrado.",
        "Listas de terceiros de anúncios e sites maliciosos. Risco geralmente baixo.",
        "Básico e mais rastreadores. Alguns sites podem falhar.",
        "A mais ampla: fraude, redirecionamentos e extensões arriscadas (.cfd, .icu…). Falhas frequentes.",
    )
    override val FILTER_INFO = "A filtragem acontece inteiramente no seu telefone: quando um nome da lista é consultado, a resposta é «não encontrado» e o nome não é guardado. Funciona só com a conexão ativa. A configuração de DNS seguro do navegador pode contorná-la. Se um site falhar, permita-o em Nomes filtrados recentemente. As listas podem estar incompletas; nenhum filtro pega tudo."
    override val FILTER_LAST = "Bloqueados recentemente"
    override val FILTER_RECENT_NOTE = "Toque: permitir"
    override val FILTER_RECENT_EMPTY = "Nada bloqueado nesta sessão. Os nomes aparecem aqui com a conexão ativa e um nível ligado."
    override val FILTER_RECENT_FOOT = "Só na memória durante esta sessão; nunca guardado, apagado ao desconectar."
    override val FILTER_PASSED = "Permitidos recentemente"
    override val FILTER_PASSED_NOTE = "Toque: bloquear"
    override val FILTER_PASSED_EMPTY = "Nada permitido ainda nesta sessão. Os nomes aparecem aqui enquanto conectado e com um nível ativo."
    override val FILTER_PASSED_FOOT = "Se ainda aparecem anúncios, procure aqui um nome com cara de anúncio e toque para bloqueá-lo. Só na memória nesta sessão; nunca é salvo."
    override val FILTER_SUSPECT_NOTE = "Parece anúncio · toque: bloquear"
    override val FILTER_BLOCK_SUSPECTS = "Bloquear todos os suspeitos"
    override val FILTER_ALLOW = "Permitidos"
    override val FILTER_BLOCK = "Minha lista de bloqueio"
    override val FILTER_ADD = "Adicionar…"
    override val FILTER_REMOVE = "Toque: remover"
    override val FILTER_ALLOW_ADD = "Domínio a permitir"
    override val FILTER_BLOCK_ADD = "Domínio a bloquear"
    override val FILTER_ERR = "Digite um domínio válido, ex.: exemplo.com"
    override val FILTER_ERR_LIMIT = "No máximo 200 domínios"
    override val FILTER_ERR_SUFFIX = "É um sufixo compartilhado (ex.: co.uk) que abrange todos os sites. Digite um site específico"
    override val FILTER_ALLOW_EMPTY = "Nenhum domínio permitido. Se um site falhar, adicione-o aqui."
    override val FILTER_BLOCK_EMPTY = "Sua lista de bloqueio está vazia."
    override val FILTER_ALLOW_FOOT = "O domínio e todos os subdomínios nunca são bloqueados. Permitir vence todas as listas e a sua lista de bloqueio."
    override val FILTER_BLOCK_FOOT = "O domínio e todos os subdomínios são sempre bloqueados (mesmo com o nível desligado)."
    override val FILTER_REMOVE_BTN = "Remover"
    override fun filterAllowed(name: String) = "$name permitido"
    override fun filterBlocked(name: String) = "$name será bloqueado"
    override fun filterRemoved(name: String) = "$name removido"
    override fun filterRemoveAsk(name: String) = "Remover $name da lista?"
    override val TEST_IPV6 = "Caminho IPv6"
    override val AUTO_RECONNECT = "Reconectar automaticamente"
    override val AUTO_RECONNECT_NOTE = "Se a conexão cair, tenta de novo após 5 s, 30 s e 2 min"
    override val BACKUP_SERVER = "Servidor reserva"
    override val BACKUP_OFF = "Desligado"
    override val BACKUP_OFF_NOTE = "Não conecta se o servidor escolhido não responder"
    override val BACKUP_FASTEST = "Mais rápido"
    override val BACKUP_FASTEST_NOTE = "O outro servidor mais rápido da última medição"
    override val CONFIRM_OFF = "Confirmar ao desconectar"
    override val CONFIRM_OFF_NOTE = "Um toque acidental na esfera não desconecta"
    override val LOCK_HIDE = "Ocultar na tela de bloqueio"
    override val LOCK_HIDE_NOTE = "O nome do servidor não aparece na notificação da tela de bloqueio"
    override val QUIET_NOTIF = "Notificação discreta"
    override val QUIET_NOTIF_NOTE = "Sem ícone na barra de status, silenciosa"
    override val REMEMBER_FILTER = "Lembrar o último filtro"
    override val REMEMBER_FILTER_NOTE = "O último filtro escolhido volta quando você abre o app"
    override val AUTO_MEASURE = "Medir ao abrir"
    override val AUTO_MEASURE_NOTE = "Mede sozinho se a última medição tiver mais de um dia"
    override val MEASURE_ENC = "Medição criptografada"
    override val MEASURE_ENC_NOTE = "Mede a velocidade via DoT, mais perto do uso criptografado real"
    override val OPT_SORT = listOf("Padrão", "Velocidade", "Nome")
    override fun sortA11y(mode: String) = "Ordem: $mode"
    override val AUTO_LIGHT = "Automático: tema claro"
    override val AUTO_DARK = "Automático: tema escuro"
    override val NIGHT_HOURS = "Horário noturno"
    override val FILTER_ENCRYPTED = "Cifrados"
    override val FILTER_UNFILTERED = "Sem filtro"

    override val TEST = "Testar a conexão"
    override val TEST_NOTE = "DNS, DNSSEC e bloqueio de anúncios"
    override val TESTING = "Testando…"
    override val TEST_TITLE = "Teste de conexão"
    override val TEST_OK = "O DNS está funcionando"
    override val TEST_FAIL = "Sem resposta"
    override val TEST_SERVER = "Servidor"
    override val TEST_METHOD = "Método"
    override val TEST_LATENCY = "Tempo de resposta"
    override val TEST_DNSSEC = "Validação DNSSEC"
    override val TEST_ADS = "Bloqueio de anúncios"
    override val DNSSEC_YES = "Valida"
    override val DNSSEC_NO = "Não valida"
    override val ADS_YES = "Ativo"
    override val ADS_NO = "Inativo"
    override val UNKNOWN = "Desconhecido"
    override val TEST_EXPLAIN = "As perguntas foram enviadas pelo túnel, como um app faria; as respostas vieram do servidor escolhido."
    override val TEST_AGAIN = "Testar de novo"

    override val RECOMMEND = "Servidor ideal para mim"
    override val RECOMMEND_NOTE = "Escolha seu objetivo e conectamos ao mais rápido que atenda"
    override val GOAL_SPEED = "Velocidade"
    override val GOAL_SPEED_NOTE = "O servidor mais rápido nas suas medições"
    override val GOAL_PRIVACY_NOTE = "Sem registros, focado em privacidade"
    override val GOAL_ADS_NOTE = "Filtra anúncios e rastreadores"
    override val GOAL_FAMILY_NOTE = "Filtra conteúdo adulto"
    override val GOAL_SECURITY_NOTE = "Filtra sites maliciosos e de phishing"
    override fun recommended(name: String) = "Recomendado: $name"

    override val PRIVATE_DNS = "Nome do DNS privado"
    override val PRIVATE_DNS_NOTE = "Você pode colá-lo na opção DNS privado do Android. Aí o sistema usa este servidor diretamente e este app é ignorado."
    override val CLEAR_HISTORY = "Limpar histórico de medições"
    override val HISTORY_CLEARED = "Medições apagadas"

    override val GUARD = "Proteção contínua"
    override val GUARD_NOTE = "VPN sempre ativa"
    override val GUARD_BODY = listOf(
        "Enquanto o app não está conectado (desligado, em pausa ou após uma queda), suas consultas DNS vão para o servidor do seu provedor de internet.",
        "Para evitar isso, ative \"VPN sempre ativa\" para este app nas configurações de VPN do Android. Se \"Bloquear conexões sem VPN\" também estiver ativado, a internet não funcionará enquanto o app não estiver conectado: nada vaza, mas pausar também significa ficar sem internet.",
        "Com a VPN sempre ativa, o sistema inicia o app sozinho quando o telefone liga e depois que ele é encerrado.",
    )
    override val GUARD_BUTTON = "Abrir configurações de VPN"
    override val BATTERY = "Configurações de bateria"
    override val BATTERY_OK = "Sem restrição"
    override val BATTERY_LIMITED = "Pode estar restrito"
    override val BATTERY_BODY = listOf(
        "O Android costuma proteger apps de VPN. Mesmo assim, alguns fabricantes (Xiaomi, Huawei, Oppo, Vivo, algumas versões da Samsung) podem fechar apps em segundo plano para poupar bateria.",
        "Se a conexão cair sozinha com frequência, defina o uso de bateria deste app como \"Sem restrições\" ou \"Não otimizado\"; em alguns telefones, permita também a \"Inicialização automática\".",
    )
    override val BATTERY_BUTTON = "Abrir configurações de bateria"

    override val BOOT_TAP = "Não foi possível conectar ao iniciar. Toque para conectar."
    override val REBIND = "Proteção da rede local"
    override val REBIND_NOTE = "Impede que sites alcancem seu roteador e aparelhos com truques de DNS"
    override val DOH_GUARD = "Bloquear o DNS próprio do navegador"
    override val DOH_GUARD_NOTE = "O navegador não escapa do filtro com seu DNS. Falhas? Desative DNS seguro"
    override val STAT_AVG = "Tempo médio de resposta"
    override val STAT_SAVED = "Tempo poupado pelo cache"
    override val STAT_TRAFFIC = "Tráfego DNS"
    override val SESSIONS = "Histórico de conexões"
    override val SESSIONS_NOTE = "Últimas 30 conexões; nomes de consultas nunca são guardados"
    override val SESSIONS_EMPTY = "Nenhuma conexão registrada ainda."
    override val MOST_USED = "Mais usados"
    override val TODAY = "Hoje"
    override val ORB_SHAPE = "Forma da esfera"
    override val ORB_SHAPE_EACH = "Forma por tema"
    override val ORB_SHAPE_NAMES = listOf("Esfera", "Triângulo", "Quadrado", "Hexágono", "Estrela", "Octógono", "Pentágono", "Retângulo", "Triângulo invertido", "Diamante", "Flor", "Estrela de seis pontas")
    override val SHIELD_WORD = "Escudo"
    override val LIQUID_COLOR = "Cor do líquido"
    override val LIQUID_THEME = "Conforme o tema"
    override val COLOR_WORD = "Cor"
    override val LIQUID_NOTE = "Uma cor escolhida substitui o tom de velocidade; a velocidade das ondas segue a do servidor."
    override val YESTERDAY = "Ontem"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Você desconectou"
        EndReason.PAUSE -> "Em pausa"
        EndReason.SWITCH -> "Troca de servidor"
        EndReason.DROP -> "Conexão caiu"
        EndReason.REVOKED -> "Encerrada pelo sistema"
        EndReason.FAILED -> "Não respondeu"
        EndReason.NETWORK -> "Troca de rede"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries consultas"

    override val SOUND_MOTION = "Som e movimento"
    override val SEC_SOUND = "Som"
    override val SOUND_ON = "Efeitos sonoros"
    override val SOUND_ON_NOTE = "Sons curtos e suaves ao tocar e ao conectar. Sem som quando o telefone está no silencioso."
    override val SOUND_UI = "Sons de toque"
    override val SOUND_UI_NOTE = "Botões, interruptores e mudanças de página"
    override val SOUND_CONN = "Sons de conexão"
    override val SOUND_CONN_NOTE = "Sons diferentes ao conectar, desconectar e em erros"
    override val SOUND_VOL = "Volume"
    override val SOUND_PACK = "Pacote de sons"
    override val SOUND_TEST = "Testar o som de conexão"
    override val QUIET_HOURS = "Horas de silêncio"
    override val QUIET_NOTE = "Sem sons nem vibração nestas horas"
    override val QUIET_RANGE = "Intervalo de silêncio"
    override val SEC_MOTION_FX = "Movimento e efeitos"
    override val ANIM_SPEED = "Velocidade da animação"
    override val TAP_FX = "Efeito de toque"
    override val TAP_FX_NOTE = "Um pequeno efeito próprio do estilo onde você toca"
    override val CELEBRATE = "Celebração ao conectar"
    override val CELEBRATE_NOTE = "Um show próprio do estilo ao redor da esfera ao conectar"
    override val HAPTIC_LEVEL = "Intensidade da vibração"
    override val REMEMBER_MODS = "Lembrar módulos"
    override val REMEMBER_MODS_NOTE = "Ao conectar, Contornar DPI e Anúncios+ ligam como você os deixou"
    override val PROFILES = "Perfis"
    override val COPY_STATUS = "Copiar resumo do estado"
    override val OPT_PACK = listOf("Auto", "Suave", "Vidro", "Clássico")
    override val SOUND_PACK_NOTE = "Auto: o som do estilo atual"
    override val SOUND_OUT = "Saída de som"
    override val OPT_SOUND_OUT = listOf("Auto", "Sistema", "Mídia")
    override val SOUND_OUT_NOTES = listOf("Usa o volume de mídia se o do sistema estiver desligado", "Mesmo canal dos sons de toque", "Toca mesmo com o telefone no vibrar")
    override val SOUND_BLOCK_RINGER = "Telefone no silencioso ou vibrar. Escolha Saída de som: Mídia."
    override val SOUND_BLOCK_ZERO = "O volume está desligado; nenhum som tocou."
    override val PACK_SPACE = "Espaço"
    override val PACKS_NOTE = "Os novos pacotes (com Liquid Glass) trazem som próprio e dez animações: toque, interruptor, conexão, desconexão, erro, concluído, painel, voltar, seleção e atualização."
    override val OPT_HAPTIC = listOf("Leve", "Normal", "Forte")
    override val PROFILE_NAMES = listOf("Velocidade", "Privacidade", "Família", "Proteção total")
    override val PROFILE_NOTES = listOf("Servidor mais rápido, cache grande, sem bloqueio", "Criptografia rígida, bloqueio de rastreadores, Anúncios+", "Servidor com filtro familiar, bloqueio médio", "Bloqueio de anúncios e rastreadores, Contornar DPI, Anúncios+")
    override fun profileApplied(name: String) = "Perfil aplicado: $name"

    override val WHATS_NEW = "Novidades"
    override val WHATS_NEW_TOAST = "O app foi atualizado"
    override val SHOW = "Mostrar"
    override val WHATS_NEW_ITEMS = listOf(
        "QUIC não atrasa mais sem UDP (ignorado 10 min); limite de fluxos QUIC cheio é renovado; mais robustez contra pacotes malformados. ☰ > Config. de DNS.",
        "Segurança: QUIC/DoQ reforçado contra pacotes falsos e campos enormes; corrigidos contador UDP, conexões QUIC velhas e caminhos DoH3 longos. ☰ > Config. de DNS.",
        "Novo: DNS sobre QUIC opcional (DoQ/DoH3), volta sozinho a DoT/DoH; QUIC Initial refeito. ☰ > Config. de DNS.",
        "Novo: método DPI «ClientHello falso» (isca com TTL baixo, tentado por último). Veja ☰ > Conexão e apps.",
        "Novo: só no Android 17+, opção «Permitir ECH» para o Anúncios+ não remover registros de SNI criptografado. ☰ > Conexão e apps.",
        "Novo: pacotes isca opcionais para a voz do Discord e um novo método TLS; contadores DPI no registro. ☰ > Conexão e apps.",
        "Novo: o DPI detecta sites cortados após a conexão e troca de método; o DNS simples descarta páginas de bloqueio falsas. ☰ > Configurações de DNS.",
        "Novo: Personalizar lembra as seções recolhidas e ganha 2 visuais prontos; os ajustes só aparecem quando fazem sentido. ☰ > Personalizar.",
        "Novo: ajuste ao seu celular (Samsung, Xiaomi, Honor…), DPI mais forte e Personalizar reorganizado. ☰ > Personalizar.",
        "Novo: filtro mais robusto; consultas DNS malformadas ou sorrateiras são recusadas e as listas atualizam com segurança. ☰ > Bloqueio.",
        "Novo: o estilo Duru; tons de menta calmos, folhas sobre a água, com ícone, sons e animações próprios. ☰ > Personalizar > Estilo.",
        "Novo: os sons agora tocam mesmo com o telefone no vibrar; só ficam em silêncio no modo totalmente silencioso. ☰ > Som e movimento.",
        "Novo: Saída de som para celulares sem som (☰ > Som e movimento), proteção da rede local, bloqueio 5x mais rápido, bateria do fabricante.",
        "Novo: Oblivious DoH (ODoH) opcional: um relé vê seu IP, o servidor DNS as consultas, nunca os dois. ☰ > DNS.",
        "Novo: efeitos sonoros, um motor de animação fluido reescrito, efeitos de toque próprios de cada estilo, perfis, horas de silêncio e mais. ☰ > Som e movimento.",
        "Novo: botões Contornar DPI e Anúncios+. Funcionam junto com o DNS ou sozinhos; ambos vêm desativados.",
        "Novo: importe sua lista de bloqueio, avisos de conexão, queda e tempo esgotado, gráfico de latência por consulta e bloqueio de DNS se cair.",
        "Novo: a lista mostra primeiro 8 (Mostrar tudo / Mostrar menos), Adicionar DNS personalizado no topo e barra de rolagem fina.",
        "Novo: bloqueio de anúncios, rastreadores e malware (Off/Básico/Médio/Rígido) com listas de permissão e bloqueio. ☰ > Bloqueio. Tudo no aparelho.",
        "Novo: estilo Frutiger Aurora; Y2K agora holográfico e Metro com cidade e música. Escolha em ☰ > Personalizar > Estilo.",
        "Novo: IPv4 e IPv6 juntos, detecção de falhas mais rápida; por privacidade, rastros do dispositivo saem das consultas e o tamanho das mensagens é ocultado.",
        "Novo: configurações separadas por assunto. No menu ☰: DNS, Conexão e apps, Notificações, Lista de servidores, Estatísticas e histórico, Dados.",
        "Novo: janela Personalizar (no menu ☰): idioma, tema, estilo, fundo, ícone, texto e acessibilidade.",
        "Novo: menu ☰ na tela inicial e uma janela Sobre (novidades, ajuda, registro, compartilhar, versão).",
        "Correção: agora dá para usar sua foto ou uma imagem incluída como fundo (o tamanho era lido errado).",
        "Correção: o teste de conexão distingue falha do servidor de um telefone que não usa o DNS e avisa.",
        "Correção: estilos Metro, Eco e Y2K redesenhados; a troca de ícone vale ao sair do app.",
        "Novo: 8 fundos incluídos (☰ → Personalizar → Foto de fundo → Imagens incluídas).",
        "Novo: solução de problemas, busca de servidores, compartilhar medições, editar servidores próprios e opção sem histórico.",
        "Ícone do app: escolha entre cinco ícones que combinam com os cinco estilos.",
        "Foto de fundo: use sua própria imagem como fundo, com véu e desfoque ajustáveis; o texto sempre fica legível.",
        "Cinco estilos: Aqua (clássico), Aero (céu e grama), Metro (blocos planos), Eco (natureza) e Y2K rosa, cada um com animações próprias e transições mais fluidas.",
        "Seleção de apps: aplique o DNS só aos apps escolhidos ou deixe alguns de fora.",
        "Adicione seus próprios servidores DNS (até 8), 10 novos servidores e uma seção de informações em cada servidor: para que serve, proprietário e ping médio.",
        "Conexão mais segura: verificações extras contra respostas DNS falsas, aviso ao cair para DNS simples, opção de criptografia estrita e volta automática à criptografia.",
        "Teste de conexão: confira com um toque se o DNS responde do servidor escolhido, além da validação DNSSEC e do bloqueio de anúncios.",
        "Servidor reserva e reconexão automática: o app se recupera sozinho se o servidor escolhido não responder ou a conexão cair.",
        "Histórico de conexões, servidores mais usados, tempo médio de resposta e tráfego DNS.",
        "Novos filtros (Cifrados, Sem filtro), ordenação por nome, \"Servidor ideal para mim\" e medição ao abrir.",
        "Contadores ao vivo na notificação, botão de pausa de 15 minutos, ocultação na tela de bloqueio e opção de notificação discreta.",
        "Três novos temas (Sakura, Mel, Aurora), um tema a partir do seu papel de parede e escolha de claro/escuro para o tema automático.",
        "Quatro novos idiomas: indonésio, vietnamita, polonês e ucraniano.",
    )
    override fun importedWith(changes: String) = "Configurações carregadas · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "criptografia enfraquecida"
        SensitiveChange.AUTO_START -> "conexão automática ativada"
        SensitiveChange.RULES -> "regras de servidor alteradas"
        SensitiveChange.PRIVACY -> "configurações de privacidade ou alertas reduzidas"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries consultas · $blocked bloqueadas"
    override val NOTIF_LOCKED = "Proteção DNS ativa"
    override val NOTIF_QUIET_CHANNEL = "Status da conexão (discreta)"
    override fun widgetToday(queries: String) = "Hoje: $queries consultas"
    override fun pauseAction(minutes: Int) = "Pausar ${minutes(minutes)}"


    override val CUSTOM_NOTE = "Servidor que você adicionou"
    override val CUSTOM_ADD = "Adicionar DNS personalizado"
    override val CUSTOM_F_NAME = "Nome"
    override val CUSTOM_F_IP1 = "Endereço IPv4 (ex.: 1.2.3.4)"
    override val CUSTOM_F_IP2 = "Segundo IPv4 (opcional)"
    override val CUSTOM_F_DOT = "Nome DoT (opcional)"
    override val CUSTOM_F_DOH = "Endereço DoH, https://… (opcional)"
    override val CUSTOM_SAVE = "Adicionar"
    override val CUSTOM_CANCEL = "Cancelar"
    override val CUSTOM_HINT = "Preencha DoT ou DoH para uma conexão criptografada; se vazio, usa DNS sem criptografia."
    override val CUSTOM_ERR_NAME = "O nome deve ter 1–24 caracteres (sem | ; , =)"
    override val CUSTOM_ERR_IP = "Digite um endereço IPv4 válido (ex.: 1.2.3.4)"
    override val CUSTOM_ERR_DOT = "O nome DoT deve ser um domínio válido"
    override val CUSTOM_ERR_DOH = "O endereço DoH deve começar com https://"
    override val CUSTOM_ERR_LIMIT = "Você pode adicionar até 8 servidores próprios"
    override fun customAdded(name: String) = "$name adicionado"
    override val CUSTOM_DELETE = "Excluir este servidor"
    override val CUSTOM_IN_USE = "Não é possível excluir enquanto conectado"
    override fun customDeleted(name: String) = "$name excluído"
    override val INFO_PURPOSE = "Para que serve"
    override val INFO_OWNER = "Proprietário"
    override val INFO_AVG = "Ping médio"
    override fun avgPing(ms: Int, n: Int) = "$ms $msU · $n medições"

    override val APPS = "Aplicativos"
    override val APPS_ALL = "Todos"
    override fun appsOnly(n: Int) = "Somente selecionados ($n)"
    override fun appsExcept(n: Int) = "Todos exceto selecionados ($n)"
    override val APPS_MODE = "Quais apps usam este DNS?"
    override val OPT_APPS = listOf("Todos", "Selecionados", "Exceto selec.")
    override val APPS_NOTE = "Apps não incluídos usam o DNS do telefone. Só um servidor DNS funciona por vez; não dá para escolher um por app."
    override val APPS_LOADING = "Carregando aplicativos…"
    override val APPS_EMPTY = "Nenhum aplicativo encontrado"
    override val APPS_NONE_SELECTED = "Nenhuma app escolhida: a proteção não vai iniciar. Escolha apps ou mude para «Todas as apps»."
    override val APPS_APPLY = "Aplicar agora"
    override val APPS_PENDING = "A mudança vale quando a conexão for renovada (cai por um ou dois segundos)."

    override val NOTES = mapOf(
        "cloudflare" to "Rápido",
        "google" to "Muito usado",
        "quad9" to "Filtra domínios maliciosos",
        "adguard" to "Filtra anúncios e rastreadores",
        "controld" to "Sem filtro, rápido",
        "opendns" to "Cisco, filtra domínios de phishing",
        "dnssb" to "Focado em privacidade, rápido",
        "dns4eu" to "DNS da UE, filtro de malware",
        "uncensored" to "Sem filtros ou redirecionamentos",
        "quad9-open" to "Sem filtragem",
        "adguard-open" to "Sem filtragem",
        "dns4eu-open" to "DNS da UE, sem filtro",
        "controld-ads" to "Filtro de anúncios, rastreadores e malware",
        "dns4eu-ads" to "DNS da UE, filtro de anúncios e malware",
        "cloudflare-security" to "Filtro de sites maliciosos",
        "controld-malware" to "Filtro de sites maliciosos",
        "cleanbrowsing-security" to "Filtro de phishing e sites maliciosos",
        "cloudflare-family" to "Filtro de malware e conteúdo adulto",
        "opendns-family" to "Filtro de conteúdo adulto",
        "adguard-family" to "Filtro de anúncios e conteúdo adulto",
        "cleanbrowsing-family" to "Conteúdo adulto, pesquisa segura",
        "dns4eu-child" to "DNS da UE, proteção infantil",
        "controld-family" to "Filtro de conteúdo adulto",
        "nextdns" to "Filtro configurável",
        "cira-private" to "Canadá, sem filtro, privacidade",
        "cira-protected" to "Canadá, filtro de sites maliciosos",
        "libredns" to "Independente, sem filtro",
        "switch" to "Suíça, filtro de sites maliciosos",
        "wikimedia" to "DNS da Wikimedia, focado em privacidade",
        "digitale" to "Sem fins lucrativos suíço, sem filtro",
        "quad101" to "Taiwan, rápido",
        "alidns" to "China, rápido",
    )
}
