package app.dnshizli.platform

import app.dnshizli.core.BootPolicy
import app.dnshizli.core.Journal
import app.dnshizli.ui.Strings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.SystemClock

/**
 * Telefon açılınca ("Telefon açılınca bağlan" ayarı açıksa) ya da uygulama güncellenince (VPN açıktıysa)
 * servisi başlatır. Bu iki yayın, Android'in arka planda önplan servisi başlatma kısıtından muaftır.
 * VPN izni daha önce verilmemişse hiçbir şey yapmaz (izin penceresi arka planda gösterilemez).
 *
 * Duraklatma telefon kapanırken sürüyorsa sistem alarmları kaybolur: burada yeniden kurulur (süre dolduysa hemen devam).
 *
 * Güvenlik: "QUICKBOOT_POWERON" korumalı bir sistem yayını değildir, herhangi bir uygulama gönderebilir. Bu yüzden
 * yalnızca cihaz gerçekten yeni açılmışsa ([BootPolicy.BOOT_WINDOW_MS] içinde) dikkate alınır.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val prefs = PrefsStore(context)
        val settings = prefs.loadSettings()
        val ready = try { VpnService.prepare(context) == null } catch (_: Exception) { false }
        val paused = prefs.pausedUntil()
        // Karar mantığı core/PlatformPolicy.kt'de (bilgisayarda sınanır); burada yalnızca uygulanır.
        when (BootPolicy.decide(action, SystemClock.elapsedRealtime(), settings.connectOnBoot, settings.wasActive, settings.onboarded, ready, paused, System.currentTimeMillis())) {
            BootPolicy.Act.NONE -> {}
            BootPolicy.Act.CLEAR_PAUSE -> prefs.setPausedUntil(0L)
            BootPolicy.Act.RESUME_NOW -> start(context, DnsVpnService.resumeIntent(context, auto = true))
            BootPolicy.Act.SCHEDULE_ALARM -> PauseAlarm.schedule(context, paused)
            BootPolicy.Act.CONNECT -> start(context, DnsVpnService.connectIntent(context, null, auto = true))
        }
    }

    private fun start(context: Context, i: Intent) {
        try {
            context.startForegroundService(i)
        } catch (e: Exception) {
            // Başlatılamadı (Android 12+ arka plan kısıtı, üretici pil yöneticisi). Sessizce korumasız kalmasın: dokununca
            // bağlanan bildirim gösterilir. Bildirim de gösterilemezse yapacak bir şey yok.
            Journal.add("açılışta bağlanılamadı: ${e.javaClass.simpleName}")
            try {
                App.applyLanguage(context, PrefsStore(context).loadSettings().lang)
                Notifier.needApp(context, Strings.BOOT_TAP)
            } catch (_: Exception) {}
        }
    }

}
