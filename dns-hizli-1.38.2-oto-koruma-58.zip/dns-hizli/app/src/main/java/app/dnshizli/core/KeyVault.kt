package app.dnshizli.core

/**
 * Gizli anahtar dosyasının sarılması. Android'de [KeyWrapper] donanım destekli Keystore ile (AES-GCM) uygulanır; anahtar
 * telefondan çıkamaz, bu yüzden uygulamanın özel klasörünün kopyası (kök erişimi, yedek, hata ayıklama) tek başına CA özel
 * anahtarını açığa çıkarmaz. Burası saf Kotlin'dir ve bilgisayarda sınanır; sarma işlemini yapan nesne dışarıdan verilir.
 *
 * Dosya biçimi: "DHK1" + sarmalayıcının çıktısı. Eski sürümün düz PKCS#8 dosyası (DER, 0x30 ile başlar) tanınır ve ilk
 * okunuşta sarılı biçime çevrilir ([Loaded.rewrite]). Sarma kullanılamıyorsa (Keystore hatası) anahtar eskisi gibi düz yazılır:
 * özellik çalışmaya devam eder, güvenlik eskisinden kötü olmaz.
 */
interface KeyWrapper {
    /** Düz baytları sarar; yapılamazsa null. */
    fun wrap(plain: ByteArray): ByteArray?
    /** [wrap] çıktısını açar; bozuk, kurcalanmış ya da anahtarı kaybolmuşsa null. */
    fun unwrap(blob: ByteArray): ByteArray?
}

object KeyVault {
    private val MAGIC = byteArrayOf('D'.code.toByte(), 'H'.code.toByte(), 'K'.code.toByte(), '1'.code.toByte())

    /** [plain]: açılmış anahtar (null = okunamadı, yeniden üretilmeli). [rewrite]: dosyanın yeni içeriği olması gereken sarılı biçim (gerekmiyorsa null). */
    class Loaded(val plain: ByteArray?, val rewrite: ByteArray?)

    fun isSealed(file: ByteArray): Boolean =
        file.size > MAGIC.size && MAGIC.indices.all { file[it] == MAGIC[it] }

    /** Yazılacak dosya içeriği: sarılı biçim; sarma olmazsa düz (eski davranış). */
    fun store(plain: ByteArray, w: KeyWrapper): ByteArray = seal(plain, w) ?: plain

    private fun seal(plain: ByteArray, w: KeyWrapper): ByteArray? {
        val blob = try { w.wrap(plain) } catch (_: Exception) { null } ?: return null
        return MAGIC + blob
    }

    /** Diskten okunan dosya içeriğini çözer. */
    fun load(file: ByteArray, w: KeyWrapper): Loaded {
        if (file.isEmpty()) return Loaded(null, null)
        if (isSealed(file)) {
            val plain = try { w.unwrap(file.copyOfRange(MAGIC.size, file.size)) } catch (_: Exception) { null }
            return Loaded(plain?.takeIf { it.isNotEmpty() }, null)
        }
        // Eski düz dosya: DER dizisi (0x30) değilse anahtar sayılmaz.
        if (file[0].toInt() != 0x30) return Loaded(null, null)
        return Loaded(file, seal(file, w))
    }
}
