package app.dnshizli.core

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.SocketTimeoutException

/** Tek bir akışın hatası (RST_STREAM, aşırı büyük cevap): bağlantıdaki öteki akışlar etkilenmez, bağlantı kapatılmaz. */
internal class H2StreamError(msg: String) : IOException(msg)

/**
 * HTTP/2 (RFC 9113) istemcisi: DNS-over-HTTPS için. Tek bir TLS bağlantısı üzerinde birden çok akış eşzamanlı yürür (çoklama);
 * her bağlantıda bir okuyucu iş parçacığı çalışır.
 *
 * Kapsam:
 *  - HPACK tam çözülür ([HpackDecoder]): statik ve dinamik tablo, Huffman dizgileri, tablo boyutu güncellemeleri. Bağlantının
 *    tablosu korunur; her başlık bloğu alındığı sırada çözülür (tablo eşitliği için akış kapalı olsa bile).
 *  - Yanıtın :status ve content-type değerleri okunur; 1xx ara yanıtlar atlanır, sonrasındaki nihai yanıt kullanılır.
 *  - Server push istenmez (ENABLE_PUSH = 0), ama bir push gelirse başlık bloğu çözülüp akış RST_STREAM(CANCEL) ile reddedilir;
 *    bağlantı kapatılmaz.
 *  - İstekler düz literal ile kodlanır (dinamik tabloya yazılmaz); bu yalnızca istek boyutunu büyütür, DNS için önemsizdir.
 *  - Akış penceresi: DNS cevapları ≤ 16 KB; bağlantı ve akış pencereleri her gelen veri için WINDOW_UPDATE ile yenilenir.
 * Android'e bağlı değildir; JVM testlerinde gerçek bir HTTP/2 sunucusuyla (python h2) ve python hpack ile üretilmiş başlık
 * vektörleriyle sınanır.
 */
internal class Http2Client(
    private val input: InputStream,
    private val output: OutputStream,
    private val authority: String,
    private val nowMs: () -> Long,
) {
    class Response(val status: Int, val contentType: String?, val body: ByteArray)

    private class Stream(val id: Int) {
        var status = -1
        var contentType: String? = null
        val body = ByteArrayOutputStream()
        var done = false
        var err: String? = null
        var streamOnly = false          // hata yalnızca bu akışı ilgilendirir (bağlantı sağlam)
    }

    /** Parçalı (CONTINUATION'lı) bir başlık bloğu; yalnızca okuyucu iş parçacığı kullanır. */
    private class Pending(val sid: Int, val promised: Int, val endStream: Boolean, val block: ByteArrayOutputStream) {
        var frames = 0                  // şimdiye dek gelen CONTINUATION çerçevesi (boş çerçevelerle bayt sınırı atlatılamasın)
    }

    private val lock = Any()
    private val wlock = Any()
    private val streams = HashMap<Int, Stream>()
    private val hpack = HpackDecoder(HpackDecoder.DEFAULT_TABLE_SIZE)     // yalnızca okuyucu iş parçacığından erişilir
    private var pending: Pending? = null
    private var nextId = 1
    private var peerMaxConcurrent = 100
    @Volatile var alive = true
        private set
    @Volatile private var goaway = false
    /** Sunucudan en son çerçeve alınan an. Boşta/ölü bağlantı kararı buna bakar: isteğin yazılması bağlantının canlı olduğunu kanıtlamaz. */
    @Volatile private var lastRx = nowMs()
    /** Sunucudan hiçbir şey gelmeden art arda zaman aşımına uğrayan akış sayısı (sessizce kopmuş bağlantıyı yakalar). */
    @Volatile private var stalls = 0

    /** Bağlantı hâlâ açık ve son bir dakikadan kısa süredir kullanılmış (boşta kalmış bağlantı yenisiyle değiştirilir). */
    fun usable(now: Long): Boolean = alive && !goaway && now - lastRx < IDLE_MS && synchronized(lock) { streams.size < peerMaxConcurrent }

    /** Preface ve SETTINGS gönderir, okuyucuyu başlatır. */
    fun start() {
        synchronized(wlock) {
            output.write(PREFACE)
            val s = ByteArray(18)
            put16(s, 0, 1); put32(s, 2, HpackDecoder.DEFAULT_TABLE_SIZE)  // SETTINGS_HEADER_TABLE_SIZE
            put16(s, 6, 2); put32(s, 8, 0)                                  // SETTINGS_ENABLE_PUSH = 0
            put16(s, 12, 6); put32(s, 14, HpackDecoder.MAX_LIST_BYTES)      // SETTINGS_MAX_HEADER_LIST_SIZE
            writeFrame(TYPE_SETTINGS, 0, 0, s)
            output.flush()
        }
        Thread({ readLoop() }, "doh2-okuyucu").apply { isDaemon = true; start() }
    }

    /** [body]'yi [path]'e POST eder; cevabın durum kodunu, content-type'ını ve gövdesini döner. Zaman aşımında [SocketTimeoutException]. */
    fun post(path: String, contentType: String, body: ByteArray, timeoutMs: Int): Response {
        if (body.size > MAX_FRAME) throw IOException("HTTP/2 isteği çok büyük")
        val head = encodeRequest(path, contentType, body.size)
        val s: Stream
        // RFC 7540 §5.1.1: yeni akış kimlikleri, tele yazılış sırasıyla ARTAN olmalı. Kimlik ataması ve çerçevelerin yazılması bu yüzden
        // TEK kilit altında yapılır (paylaşılan bağlantıda iki şerit aynı anda gelirse 5 numaralı akış 3'ten önce gidemez; aksi halde
        // sunucu PROTOCOL_ERROR ile bağlantıyı keser ve bekleyen tüm sorgular düşer).
        synchronized(wlock) {
            synchronized(lock) {
                if (!alive) throw IOException("HTTP/2 bağlantısı kapalı")
                if (goaway) throw IOException("HTTP/2 bağlantısı kapanıyor")
                if (streams.size >= peerMaxConcurrent) throw IOException("HTTP/2 akış sınırı doldu")
                if (nextId > 0x7FFFFFFF) throw IOException("HTTP/2 akış kimlikleri tükendi")
                s = Stream(nextId); nextId += 2
                streams[s.id] = s
            }
            try {
                writeFrame(TYPE_HEADERS, FLAG_END_HEADERS, s.id, head)
                writeFrame(TYPE_DATA, FLAG_END_STREAM, s.id, body)
                output.flush()
            } catch (e: IOException) {
                synchronized(lock) { streams.remove(s.id) }
                fail(e.message ?: "HTTP/2 yazma hatası")
                throw e
            }
        }
        try {
            val deadline = nowMs() + timeoutMs
            synchronized(lock) {
                while (!s.done) {
                    if (!alive) throw IOException("HTTP/2 bağlantısı koptu")
                    val left = deadline - nowMs()
                    if (left <= 0) throw SocketTimeoutException("HTTP/2 cevabı zaman aşımı")
                    (lock as java.lang.Object).wait(left)
                }
                s.err?.let { throw if (s.streamOnly) H2StreamError(it) else IOException(it) }
                return Response(s.status, s.contentType, s.body.toByteArray())
            }
        } catch (e: SocketTimeoutException) {
            // Tek akışın zaman aşımı normalde bağlantıyı öldürmez (yalnız o ad yavaş olabilir). Ama zaman aşımı süresince sunucudan
            // HİÇBİR çerçeve gelmediyse bağlantı büyük olasılıkla sessizce kopmuştur (NAT/DPI kara deliği): iki kez üst üste olursa kapatılır.
            if (nowMs() - lastRx >= timeoutMs && ++stalls >= 2) fail("sunucudan yanıt yok (sessiz bağlantı)")
            throw e
        } catch (e: H2StreamError) {
            throw e                                                 // tek akışın hatası (RST_STREAM, çok büyük cevap) bağlantıyı öldürmez
        } catch (e: IOException) {
            fail(e.message ?: "HTTP/2 yazma hatası")
            throw e
        } finally {
            synchronized(lock) { streams.remove(s.id) }
        }
    }

    fun close() = fail("kapatıldı")

    // ------------------------------------------------------------------ okuma

    private fun readLoop() {
        val hdr = ByteArray(9)
        try {
            while (alive) {
                readFully(hdr)
                val len = ((hdr[0].toInt() and 0xFF) shl 16) or ((hdr[1].toInt() and 0xFF) shl 8) or (hdr[2].toInt() and 0xFF)
                val type = hdr[3].toInt() and 0xFF
                val flags = hdr[4].toInt() and 0xFF
                val sid = ((hdr[5].toInt() and 0x7F) shl 24) or ((hdr[6].toInt() and 0xFF) shl 16) or ((hdr[7].toInt() and 0xFF) shl 8) or (hdr[8].toInt() and 0xFF)
                if (len > MAX_FRAME) throw IOException("HTTP/2 çerçevesi çok büyük")
                val p = ByteArray(len)
                readFully(p)
                lastRx = nowMs(); stalls = 0
                val pend = pending
                if (pend != null && (type != TYPE_CONTINUATION || sid != pend.sid)) throw IOException("beklenmeyen HTTP/2 CONTINUATION")
                handle(type, flags, sid, p)
            }
        } catch (e: Exception) {
            fail(e.message ?: "HTTP/2 okuma hatası")
        }
    }

    private fun handle(type: Int, flags: Int, sid: Int, p: ByteArray) {
        when (type) {
            TYPE_DATA -> {
                if (sid == 0) throw IOException("HTTP/2 protokol hatası: DATA akış 0'da")
                val data = unpad(p, flags)
                // RFC 9113 §6.1: "Pad Length" alanı ve dolgu da akış denetimine dahildir. Yalnızca veri baytlarını geri verirsek dolgulu
                // çerçeve gönderen bir sunucu bağlantı penceresini yavaş yavaş tüketir; pencere sıfırlanınca bütün cevaplar sonsuza dek takılır.
                if (p.size > 0) {
                    writeWindow(0, p.size)
                    if (flags and FLAG_END_STREAM == 0) writeWindow(sid, p.size)
                }
                synchronized(lock) {
                    val s = streams[sid] ?: return
                    if (s.body.size() + data.size > MAX_BODY) { s.err = "HTTP/2 cevabı çok büyük"; s.streamOnly = true }
                    else s.body.write(data, 0, data.size)
                    if (flags and FLAG_END_STREAM != 0) s.done = true
                    (lock as java.lang.Object).notifyAll()
                }
            }
            TYPE_HEADERS -> {
                if (sid == 0) throw IOException("HTTP/2 protokol hatası: HEADERS akış 0'da")
                var frag = unpad(p, flags)
                if (flags and FLAG_PRIORITY != 0) {
                    if (frag.size < 5) throw IOException("bozuk HTTP/2 öncelik alanı")
                    frag = frag.copyOfRange(5, frag.size)
                }
                startBlock(sid, 0, flags and FLAG_END_STREAM != 0, flags, frag)
            }
            TYPE_PUSH_PROMISE -> {
                if (sid == 0) throw IOException("HTTP/2 protokol hatası: PUSH_PROMISE akış 0'da")
                val body = unpad(p, flags)
                if (body.size < 4) throw IOException("bozuk PUSH_PROMISE")
                val promised = u32(body, 0) and 0x7FFFFFFF
                if (promised == 0) throw IOException("HTTP/2 protokol hatası: PUSH_PROMISE akış 0")
                startBlock(sid, promised, false, flags, body.copyOfRange(4, body.size))
            }
            TYPE_CONTINUATION -> {
                val pend = pending ?: throw IOException("beklenmeyen HTTP/2 CONTINUATION")
                if (pend.block.size() + p.size > HpackDecoder.MAX_LIST_BYTES * 2) throw IOException("HTTP/2 başlık bloğu çok büyük")   // END_HEADERS gelmeden sınırsız CONTINUATION (CVE-2024-27316 sınıfı)
                if (++pend.frames > MAX_CONTINUATIONS) throw IOException("HTTP/2 başlık bloğu çok parçalı")                         // bayt eklemeyen (boş/1 baytlık) çerçevelerle sonsuz bekletme
                pend.block.write(p, 0, p.size)
                if (flags and FLAG_END_HEADERS != 0) {
                    pending = null
                    finishBlock(pend.sid, pend.promised, pend.endStream, pend.block.toByteArray())
                }
            }
            TYPE_RST_STREAM -> synchronized(lock) {
                streams[sid]?.let { it.err = "sunucu akışı sıfırladı"; it.streamOnly = true; it.done = true }
                (lock as java.lang.Object).notifyAll()
            }
            TYPE_SETTINGS -> {
                if (flags and FLAG_ACK != 0) return
                var i = 0
                while (i + 6 <= p.size) {
                    val id = ((p[i].toInt() and 0xFF) shl 8) or (p[i + 1].toInt() and 0xFF)
                    if (id == 3) peerMaxConcurrent = minOf(maxOf(1, u32(p, i + 2)), 1000)     // SETTINGS_MAX_CONCURRENT_STREAMS
                    i += 6
                }
                synchronized(wlock) { writeFrame(TYPE_SETTINGS, FLAG_ACK, 0, ByteArray(0)); output.flush() }
            }
            TYPE_PING -> if (flags and FLAG_ACK == 0) synchronized(wlock) { writeFrame(TYPE_PING, FLAG_ACK, 0, p); output.flush() }
            TYPE_GOAWAY -> {
                // Nazik kapanış (RFC 7540 §6.8): son_akış_kimliği'ne dek olan istekler İŞLENİR; yalnızca ondan büyükler reddedilmiştir (yeniden
                // denenebilir). Bağlantı yeni istek almaz ama eldekilerin cevabı beklenir; sunucu soketi kapatınca okuyucu biter.
                val last = if (p.size >= 4) u32(p, 0) and 0x7FFFFFFF else 0
                synchronized(lock) {
                    goaway = true
                    for (st in streams.values) if (st.id > last && !st.done) { st.err = "sunucu bağlantıyı kapatıyor (GOAWAY)"; st.streamOnly = true; st.done = true }
                    (lock as java.lang.Object).notifyAll()
                }
            }
            else -> {}                                      // WINDOW_UPDATE ve bilinmeyen çerçeveler: yok sayılır
        }
    }

    /** HEADERS / PUSH_PROMISE başlık bloğunun ilk parçasını alır; blok tamamsa hemen çözer. */
    private fun startBlock(sid: Int, promised: Int, endStream: Boolean, flags: Int, frag: ByteArray) {
        if (flags and FLAG_END_HEADERS != 0) {
            finishBlock(sid, promised, endStream, frag)
        } else {
            val b = ByteArrayOutputStream(); b.write(frag, 0, frag.size)
            pending = Pending(sid, promised, endStream, b)
        }
    }

    /** Tam bir başlık bloğu: önce HPACK tablosu eşitlenir (akış yoksa bile), sonra akışa işlenir. */
    private fun finishBlock(sid: Int, promised: Int, endStream: Boolean, block: ByteArray) {
        val fields = hpack.decode(block)
        if (promised != 0) {                                   // server push: istemedik, reddet
            synchronized(wlock) {
                val c = ByteArray(4); put32(c, 0, 8)            // CANCEL
                writeFrame(TYPE_RST_STREAM, 0, promised, c)
                output.flush()
            }
            return
        }
        var st = -1
        var ct: String? = null
        for (f in fields) {
            if (f.name == ":status" && st == -1) st = f.value.takeIf { it.length == 3 && it.all { c -> c.isDigit() } }?.toInt() ?: -1
            else if (f.name == "content-type" && ct == null) ct = f.value
        }
        synchronized(lock) {
            val s = streams[sid]
            if (s != null) {
                if (st in 100..199) {                          // ara (bilgilendirici) yanıt: nihai yanıtı bekle
                    if (endStream) s.done = true
                } else if (s.status < 0) {                     // nihai yanıt (sonraki bloklar: fragman/tröyler, yok sayılır)
                    s.status = st; s.contentType = ct
                }
                if (endStream && st !in 100..199) s.done = true
                (lock as java.lang.Object).notifyAll()
            }
        }
    }

    /** Bağlantıyı öldürür; bekleyen tüm akışlar hata alır. */
    private fun fail(msg: String) {
        synchronized(lock) {
            if (!alive) return
            alive = false
            for (s in streams.values) if (!s.done) { s.err = msg; s.done = true }
            (lock as java.lang.Object).notifyAll()
        }
    }

    private fun readFully(b: ByteArray) {
        var off = 0
        while (off < b.size) {
            val n = input.read(b, off, b.size - off)
            if (n < 0) throw IOException("HTTP/2 bağlantısı kapandı")
            off += n
        }
    }

    private fun unpad(p: ByteArray, flags: Int): ByteArray {
        if (flags and FLAG_PADDED == 0) return p
        if (p.isEmpty()) throw IOException("bozuk HTTP/2 dolgusu")
        val pad = p[0].toInt() and 0xFF
        if (pad + 1 > p.size) throw IOException("bozuk HTTP/2 dolgusu")
        return p.copyOfRange(1, p.size - pad)
    }

    // ------------------------------------------------------------------ yazma

    private fun writeWindow(sid: Int, inc: Int) {
        val w = ByteArray(4)
        put32(w, 0, inc)
        synchronized(wlock) { writeFrame(TYPE_WINDOW_UPDATE, 0, sid, w); output.flush() }
    }

    /** Çerçeve yazar (wlock altında çağrılmalı; flush çağırana aittir). */
    private fun writeFrame(type: Int, flags: Int, sid: Int, p: ByteArray) {
        val h = ByteArray(9)
        h[0] = (p.size shr 16).toByte(); h[1] = (p.size shr 8).toByte(); h[2] = p.size.toByte()
        h[3] = type.toByte(); h[4] = flags.toByte()
        put32(h, 5, sid and 0x7FFFFFFF)
        output.write(h)
        if (p.isNotEmpty()) output.write(p)
    }

    // ------------------------------------------------------------------ istek kodlama (düz literal, dinamik tabloya yazmaz)

    private fun encodeRequest(path: String, ct: String, bodyLen: Int): ByteArray {
        val o = ByteArrayOutputStream()
        lit(o, ":method", "POST"); lit(o, ":scheme", "https"); lit(o, ":authority", authority); lit(o, ":path", path)
        lit(o, "content-type", ct); lit(o, "accept", ct); lit(o, "content-length", bodyLen.toString()); lit(o, "user-agent", "Mozilla/5.0")
        return o.toByteArray()
    }

    /** Dizinsiz, Huffman kullanmayan literal (RFC 7541 §6.2.2). */
    private fun lit(o: ByteArrayOutputStream, name: String, value: String) {
        o.write(0x00)
        str(o, name); str(o, value)
    }

    private fun str(o: ByteArrayOutputStream, s: String) {
        val b = s.toByteArray(Charsets.ISO_8859_1)
        encodeInt(o, b.size, 7, 0)
        o.write(b)
    }

    private fun encodeInt(o: ByteArrayOutputStream, v: Int, prefix: Int, high: Int) {
        val max = (1 shl prefix) - 1
        if (v < max) { o.write(high or v); return }
        o.write(high or max)
        var r = v - max
        while (r >= 128) { o.write((r and 0x7F) or 0x80); r = r ushr 7 }
        o.write(r)
    }

    companion object {
        private val PREFACE = "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n".toByteArray(Charsets.ISO_8859_1)
        const val MAX_FRAME = 16384                 // ilan ettiğimiz (varsayılan) SETTINGS_MAX_FRAME_SIZE
        const val MAX_BODY = 65536
        /** Tek başlık bloğunda kabul edilen en çok CONTINUATION çerçevesi (gerçek bloklar bir iki çerçeveyi geçmez). */
        const val MAX_CONTINUATIONS = 16
        const val IDLE_MS = 20_000L

        const val TYPE_DATA = 0
        const val TYPE_HEADERS = 1
        const val TYPE_RST_STREAM = 3
        const val TYPE_SETTINGS = 4
        const val TYPE_PUSH_PROMISE = 5
        const val TYPE_PING = 6
        const val TYPE_GOAWAY = 7
        const val TYPE_WINDOW_UPDATE = 8
        const val TYPE_CONTINUATION = 9
        const val FLAG_ACK = 0x1
        const val FLAG_END_STREAM = 0x1
        const val FLAG_END_HEADERS = 0x4
        const val FLAG_PADDED = 0x8
        const val FLAG_PRIORITY = 0x20

        private fun put16(b: ByteArray, o: Int, v: Int) { b[o] = (v shr 8).toByte(); b[o + 1] = v.toByte() }
        private fun put32(b: ByteArray, o: Int, v: Int) { b[o] = (v shr 24).toByte(); b[o + 1] = (v shr 16).toByte(); b[o + 2] = (v shr 8).toByte(); b[o + 3] = v.toByte() }
        private fun u32(b: ByteArray, o: Int): Int =
            ((b[o].toInt() and 0xFF) shl 24) or ((b[o + 1].toInt() and 0xFF) shl 16) or ((b[o + 2].toInt() and 0xFF) shl 8) or (b[o + 3].toInt() and 0xFF)

        /** Yalnızca test için: tek bir başlık bloğunun :status değeri (yoksa ya da çözülemiyorsa -1). Yeni bir çözücü kullanır. */
        internal fun statusOf(b: ByteArray): Int =
            HpackDecoder().decode(b).firstOrNull { it.name == ":status" }?.value?.toIntOrNull() ?: -1
    }
}
