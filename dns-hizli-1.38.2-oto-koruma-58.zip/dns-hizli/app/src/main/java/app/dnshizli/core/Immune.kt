package app.dnshizli.core

/** Otomatik korumanın uygulayabildiği önlemler. [sticky]: açılıp kapanan durum (rahatlayınca geri alınır); değilse tek seferlik eylem. */
enum class Act(val sticky: Boolean) {
    /** Aynı sunucuda yönlendiriciyi yenile (yeni soket/kimlik/kaynak port). */
    REFRESH(false),
    /** Düz DNS'teysek şifreli yönteme geç. */
    ENCRYPT(false),
    /** Yedek sunucuya geç. */
    BACKUP(false),
    /** Ağ geçidinde QUIC'i tamamen düşür (SNI süzmesi yerine). */
    QUIC_OFF(true),
    /** Ağ geçidinde DNS'i atlatan şifreli DNS'leri (DoH/DoT) kapat. */
    DOH_BLOCK(true),
    /** Yeni akış hızını sınırla (yumuşak / sert). */
    /** Ağ geçidinde DPI atlatmayı (TLS/HTTP bölme) aç; kullanıcı kapalı bıraktıysa ağ engeli belirtilerinde otomatik. */
    DPI_ON(true),
    /** Deneysel tarayıcı kipi vekilini söker (art arda sertifika reddi / vekil hatası). */
    MITM_OFF(true),
    FLOW_SOFT(true),
    FLOW_HARD(true),
}

/**
 * Algılanan tehdit sınıfları. [trigger]: son [Immune.WINDOW_MS] içindeki ağırlıklı olay toplamı bu değere ulaşınca önlem alınır.
 * [ladder]: bu tehdide karşı denenebilecek önlemler; sırası yalnızca başlangıç önceliğidir, gerçek sıra [Immune] tarafından öğrenilir.
 */
enum class Threat(val trigger: Double, val ladder: List<Act>) {
    /** Kimliği tutan ama sorusu uyuşmayan (sahte ya da bozuk) DNS cevapları. */
    SPOOF(4.0, listOf(Act.REFRESH, Act.ENCRYPT, Act.BACKUP)),
    /** Şifreli bağlantıda sertifika/ad doğrulaması hataları (araya girme ya da yanlış sunucu). */
    BAD_SERVER(4.0, listOf(Act.BACKUP, Act.REFRESH)),
    /** Ağ engeli belirtileri: cevapsız kalan sorgular, tekrarlayan kesintiler. */
    NET_BLOCK(4.0, listOf(Act.QUIC_OFF, Act.DPI_ON, Act.ENCRYPT, Act.BACKUP)),
    /** Aşırı yeni akış (kaynak tüketimi). */
    FLOOD(2.5, listOf(Act.FLOW_SOFT, Act.FLOW_HARD)),
    /** Reklam engelini atlatma girişimleri (DNS'i atlatan şifreli DNS, QUIC). */
    AD_LEAK(5.0, listOf(Act.DOH_BLOCK, Act.QUIC_OFF)),
    /** Deneysel tarayıcı kipinde art arda vekil/sertifika hataları: kip siteleri bozuyor olabilir. */
    PROXY_FAIL(4.0, listOf(Act.MITM_OFF)),
}

/**
 * Kendi kendini onaran ve öğrenen koruma motoru (saf mantık; sinyalleri toplamak ve önlemleri uygulamak servisin işidir).
 *
 * Katmanlar:
 *  1. ALGILAMA. Sinyaller [report] ile ağırlıklı olay olarak gelir; her tehdit için son [WINDOW_MS] içindeki toplam, tehdidin eşiğini
 *     aşarsa etkin sayılır. Eşik UYARLAMALIDIR: sakin dönemlerde ölçülen olay tabanı ([State.base]) gürültülü ağlarda eşiği yükseltir
 *     (en çok 3 katı), böylece sürekli küçük hatası olan bir ağ sürekli alarm üretmez.
 *  2. KADEMELİ MÜDAHALE. Aday önlemlerden TEK biri eklenir. Tüm tehditler birlikte tek bir eşzamanlılık sınırına bağlıdır (aynı anda
 *     yalnızca en acil tehdit müdahale alır, [GLOBAL_COOLDOWN_MS]); çok şiddetli saldırı ([SEVERE]) bu beklemeyi aşar.
 *  3. ÖĞRENME (Beta dağılımı). Her tehdit-önlem çifti için (başarı, başarısızlık) ağırlıkları tutulur; her ölçümden sonra eskiler
 *     [DECAY] ile unutulur (ağ değişir). Verimlilik = ortalama. Aday seçiminde başlangıç sırası + öğrenilmiş verimlilik kullanılır;
 *     keşif oranı deneyim arttıkça %15'ten %3'e iner. Ağ türü bağlamı ([setScope]) ayrı öğrenilir.
 *  4. ÖLÇÜM. Önlemden [EVAL_MS] sonra olay hızı önceki süreyle karşılaştırılır ("rahatlama"). Ek olarak YAN ETKİ denetlenir: servis
 *     kullanıcıya görünen sorunları [harm] ile bildirir; sürekli bir önlemden sonra bu sorunlar belirgin artarsa önlem tehdit
 *     geçmiş olsa bile geri alınır ve cezalandırılır.
 *  5. DEVRE KESİCİ. Etkisiz ya da zararlı bulunan sürekli önlem "yasaklanır"; süre her tekrarda ikiye katlanır (10 dk … 4 saat). Önlem
 *     açılıp kapanıp durmaz (salınım koruması); bir kez başarılı olursa ceza sıfırlanır.
 *  6. RAHATLAMA. [QUIET_MS] olay yoksa önlemler tek tek (en son uygulanan önce) geri alınır.
 *  7. KENDİNİ ONARMA. [selfCheck] her turda iç durumun tutarlılığını denetler ve bozuğu onarır: geleceğe dönük zamanlar, saat geri
 *     sarması, listede olmayan önlemler, tekrarlar, NaN/negatif sayaçlar. Onarım sayısı [repairs] ile görülür.
 *  8. KALICILIK. Öğrenilenler ([encode]) ve çalışma durumu (açık önlemler, yasaklar; [encodeAll]) saklanır; uygulama yeniden başlayınca
 *     [decodeAll] ile geri yüklenir.
 *
 * Kod ya da kural indirilmez, kullanıcı ayarları değiştirilmez; yalnızca çalışma zamanı önlemleri açılıp kapanır. Hiçbir ad, IP ya da
 * içerik saklanmaz: yalnızca tehdit/önlem adları ve sayılar.
 */
class Immune(private val random: java.util.Random = java.util.Random()) {
    data class Change(val threat: Threat, val act: Act, val on: Boolean)

    private class Ev(val at: Long, val w: Double)
    private class Ban(var until: Long, var strikes: Int)

    private class State {
        val events = ArrayList<Ev>()
        val applied = ArrayList<Act>()
        var lastEvent = 0L
        var lastChange = 0L
        var pendAct: Act? = null
        var pendBefore = 0.0
        var pendHarm = 0.0
        var pendAt = 0L
        var base = 0.0                      // sakin dönemlerdeki olay tabanı (üstel ortalama)
        var quietMul = 1                    // sakin bekleme çarpanı: tehdit kısa sürede geri dönerse uzar (salınım koruması)
        var lastRelax = 0L
        var cusum = 0.0                     // CUSUM: tabana göre küçük ama SÜREN artışı biriktirir
        var streak = 0                      // eşiğin art arda kaç turdur aşıldığı (doğrulama)
    }

    private val st = Threat.values().associateWith { State() }
    private val cnt = HashMap<String, DoubleArray>()        // anahtar → [başarı ağırlığı, başarısızlık ağırlığı]
    private val bans = HashMap<String, Ban>()
    private val harmEv = ArrayList<Ev>()
    private var lastGlobal = 0L
    private var holdUntil = 0L
    private val disruptive = ArrayList<Long>()              // son bir saatte uygulanan kesintili (sunucu/bağlantı değiştiren) önlemler
    private var lastTick = 0L

    /** [selfCheck]'in bugüne dek yaptığı onarım sayısı (tanılama). */
    @Volatile var repairs = 0
        private set

    /**
     * Ağ türü bağlamı ("wifi", "mobil" gibi küçük harf/rakam, en çok 12 karakter; boş = bağlamsız). Aynı önlem Wi-Fi'da işe yarayıp mobil
     * veride yaramayabilir: verimlilik bağlam başına ayrıca öğrenilir; o bağlamda henüz ölçüm yoksa genel (bağlamsız) değer kullanılır.
     */
    @Synchronized fun setScope(name: String) {
        val n = if (name.length <= 12 && name.all { it in 'a'..'z' || it in '0'..'9' }) name else ""
        // Ağ değişti (ör. Wi-Fi → mobil): eski ağın kanıtları ve o ağa özgü önlemler yenisi için geçerli değildir. İlk atama değişiklik sayılmaz.
        if (n != scope && scope.isNotEmpty() && n.isNotEmpty()) scopeChanged = true
        if (n.isNotEmpty() || scope.isEmpty()) scope = n
    }
    private var scope = ""
    private var scopeChanged = false

    private fun key(t: Threat, a: Act) = t.name + ":" + a.name
    private fun skey(t: Threat, a: Act) = if (scope.isEmpty()) key(t, a) else scope + "/" + key(t, a)

    private fun mean(c: DoubleArray?): Double? {
        if (c == null) return null
        val n = c[0] + c[1]
        return if (n <= 0.0 || n.isNaN()) null else (c[0] / n).coerceIn(0.0, 1.0)
    }

    /** [t]'ye karşı [a] önleminin öğrenilmiş verimliliği (0..1); bağlamda yoksa genel değer, o da yoksa [PRIOR]. */
    @Synchronized fun efficacy(t: Threat, a: Act): Double = mean(cnt[skey(t, a)]) ?: mean(cnt[key(t, a)]) ?: PRIOR

    /** [t] için son [WINDOW_MS] içindeki ağırlıklı olay toplamı. */
    @Synchronized fun score(t: Threat, now: Long): Double = sum(st.getValue(t).events, now, WINDOW_MS)

    /** [t] için şu anki etkin eşik (uyarlamalı taban dahil). */
    @Synchronized fun threshold(t: Threat): Double = effTrigger(t, st.getValue(t))

    /**
     * [ms] boyunca YENİ önlem alınmaz (ölçüm ve öğrenme sürer). Tünel yeni kurulduğunda ya da ağ değiştiğinde çağrılır: bağlantı
     * kurulurken görülen geçici hatalar saldırı sayılmasın, önlem de açılış karmaşasına eklenmesin.
     */
    @Synchronized fun hold(now: Long, ms: Long) { holdUntil = maxOf(holdUntil, now + ms) }

    /** [a], [t] için yasaklı mı ([now] anında). */
    @Synchronized fun banned(t: Threat, a: Act, now: Long): Boolean = (bans[key(t, a)]?.until ?: 0L) > now

    /** Penceredeki olayların kaç farklı dakikaya yayıldığı: tek dakikalık dalga ile süren saldırıyı ayırır. */
    private fun minutes(s: State, now: Long): Int {
        val set = HashSet<Long>()
        for (e in s.events) if (e.at in (now - WINDOW_MS + 1)..now) set.add(e.at / 60_000L)
        return set.size
    }

    private fun effTrigger(t: Threat, s: State) = minOf(maxOf(t.trigger, s.base * BASE_K, s.base + 6.0 * Math.sqrt(s.base)), t.trigger * 2.0)

    private fun sum(l: List<Ev>, now: Long, window: Long): Double {
        var x = 0.0
        for (e in l) if (e.at in (now - window + 1)..now) x += e.w
        return x
    }

    /** Bir tehdit sinyali bildirir. [weight] tek bildirimde en çok [MAX_WEIGHT] sayılır. */
    @Synchronized fun report(t: Threat, weight: Double, now: Long) {
        if (weight <= 0.0 || weight.isNaN()) return
        val s = st.getValue(t)
        s.events.add(Ev(now, minOf(weight, MAX_WEIGHT)))
        s.lastEvent = now
        if (s.events.size > MAX_EVENTS) s.events.subList(0, s.events.size - MAX_EVENTS).clear()
    }

    /**
     * Kullanıcıya görünen sorun bildirir (ör. sağlık denetiminin şüpheli bulması). Tehdit sayılmaz; yalnızca sürekli bir önlemden sonra
     * artış olup olmadığına bakılır (yan etki denetimi).
     */
    @Synchronized fun harm(weight: Double, now: Long) {
        if (weight <= 0.0 || weight.isNaN()) return
        harmEv.add(Ev(now, minOf(weight, MAX_WEIGHT)))
        if (harmEv.size > MAX_EVENTS) harmEv.subList(0, harmEv.size - MAX_EVENTS).clear()
    }

    /** Şu an açık olan sürekli (sticky) önlemler (tüm tehditler birleşik). */
    @Synchronized fun active(): Set<Act> {
        val r = HashSet<Act>()
        for (s in st.values) for (a in s.applied) if (a.sticky) r.add(a)
        return r
    }

    /** Uygulanan önlemler (tek seferlik olanlar dahil), tehdit başına; tanılama için. */
    @Synchronized fun applied(t: Threat): List<Act> = st.getValue(t).applied.toList()

    /**
     * Seçilen önlem gerçekte uygulanamadı (ör. geçilecek sunucu yok, geçiş başarısız): "uygulanmış" sayılmaz, öğrenme cezası verilmez,
     * sonraki değerlendirmede yeniden seçilebilir (kısa bekleme sonrası). Aksi halde uygulanmamış önlem rahatlama süresine dek kilitli kalırdı.
     */
    @Synchronized fun failed(t: Threat, a: Act, now: Long) {
        val s = st.getValue(t)
        s.applied.remove(a)
        if (s.pendAct == a) s.pendAct = null
        s.lastChange = now                                   // sıradaki deneme için normal bekleme (sıcak döngü olmasın)
    }

    /**
     * Zamanı ilerletir; uygulanması ya da geri alınması gereken önlemleri döndürür. Düzenli (ör. dakikada bir) çağrılmalıdır.
     * Tek seferlik önlemlerin geri alınması [Change] üretmez. [can]: önlemin şu an uygulanabilir olup olmadığı.
     */
    @Synchronized fun tick(now: Long, can: (Act) -> Boolean = { true }): List<Change> {
        val out = ArrayList<Change>()
        selfCheck(now)
        val prevTick = lastTick
        lastTick = now
        if (scopeChanged) {
            scopeChanged = false
            for ((t, s) in st) {
                for (a in s.applied) if (a.sticky) out.add(Change(t, a, false))
                s.applied.clear(); s.events.clear(); s.pendAct = null; s.streak = 0; s.cusum = 0.0; s.base = 0.0; s.lastChange = now
            }
            harmEv.clear()
            holdUntil = maxOf(holdUntil, now + NET_HOLD_MS)
        }
        harmEv.removeAll { it.at <= now - KEEP_MS }
        val order = Threat.values().sortedByDescending { sum(st.getValue(it).events, now, WINDOW_MS) / effTrigger(it, st.getValue(it)) }
        var escalated = 0
        for (t in order) {
            val s = st.getValue(t)
            s.events.removeAll { it.at <= now - KEEP_MS }
            evaluate(t, s, now, out)
            if (sum(s.events, now, WINDOW_MS) >= effTrigger(t, s)) s.streak++ else s.streak = 0
            updateCusum(t, s, now, prevTick)
            if (escalate(t, s, now, out, can, escalated)) escalated++
            relax(t, s, now, out)
            calm(t, s, now)
        }
        return out
    }

    private fun evaluate(t: Threat, s: State, now: Long, out: MutableList<Change>) {
        val a = s.pendAct ?: return
        if (now < s.pendAt) return
        val after = sum(s.events, now, EVAL_MS)
        val relief = if (s.pendBefore <= 0.0) 0.0 else ((s.pendBefore - after) / s.pendBefore).coerceIn(0.0, 1.0)
        val harmAfter = sum(harmEv, now, EVAL_MS)
        // Yan etki: önlemden sonra kullanıcıya görünen sorunlar belirgin arttıysa (ve yeterince çoksa) önlem zararlıdır.
        val collateral = a.sticky && harmAfter >= HARM_MIN && harmAfter > s.pendHarm * HARM_RATIO
        learn(t, a, if (collateral) 0.0 else relief)
        if (collateral) learn(t, a, 0.0)                    // zarar iki kat ağır cezalandırılır
        s.pendAct = null
        if (a.sticky && (collateral || relief < MIN_RELIEF) && s.applied.remove(a)) {
            out.add(Change(t, a, false))                    // işe yaramayan ya da zarar veren önlem geri alınır
            s.lastChange = now
            ban(t, a, now, if (collateral) 2 else 1)
        } else if (!a.sticky && relief < MIN_RELIEF && sum(s.events, now, WINDOW_MS) >= effTrigger(t, s) * SEVERE && s.applied.remove(a)) {
            // Tek seferlik önlem işe yaramadıysa "uygulandı" işareti kalmasın: saldırı sürerken sonsuza dek kilitli kalırdı. Üstel soğumayla yeniden denenebilir.
            ban(t, a, now, 2)
        } else if (relief >= GOOD_RELIEF) {
            bans[key(t, a)]?.strikes = 0                    // başarılı olduysa ceza sıfırlanır
        }
    }

    private fun ban(t: Threat, a: Act, now: Long, add: Int) {
        val b = bans.getOrPut(key(t, a)) { Ban(0, 0) }
        b.strikes = minOf(b.strikes + add, MAX_STRIKES)
        b.until = now + minOf(BAN_BASE_MS shl (b.strikes - 1), BAN_MAX_MS)
    }

    private fun learn(t: Threat, a: Act, relief: Double) {
        bump(key(t, a), relief)
        if (scope.isNotEmpty()) bump(skey(t, a), relief)
    }

    private fun bump(k: String, relief: Double) {
        val c = cnt.getOrPut(k) { doubleArrayOf(1.0, 1.0) }
        c[0] = c[0] * DECAY + relief
        c[1] = c[1] * DECAY + (1.0 - relief)
        val n = c[0] + c[1]
        if (n > MAX_COUNT) { c[0] *= MAX_COUNT / n; c[1] *= MAX_COUNT / n }
    }

    private fun escalate(t: Threat, s: State, now: Long, out: MutableList<Change>, can: (Act) -> Boolean, thisTick: Int): Boolean {
        if (s.lastChange != 0L && now - s.lastChange < COOLDOWN_MS) return false
        val trig = effTrigger(t, s)
        val score = sum(s.events, now, WINDOW_MS)
        val slowShift = s.cusum >= CUSUM_H && minutes(s, now) >= 2 && score >= t.trigger * 0.5      // süren yavaş artış
        if (score < trig && !slowShift) return false
        val severe = score >= trig * SEVERE
        // Doğrulama: eşik art arda CONFIRM_TICKS turda aşılmadıysa (tek seferlik gürültü) yalnızca belirgin patlama ([IMMEDIATE]) harekete geçirir.
        if (!slowShift && !severe && (s.streak < CONFIRM_TICKS || minutes(s, now) < 2) && score < trig * IMMEDIATE) return false
        // Önceki önlemin ölçümü sürerken yenisi yalnızca saldırı çok şiddetliyse eklenir; o önlemin öğrenmesi atlanır.
        if (s.pendAct != null && !severe) return false
        if (now < holdUntil) return false                          // tünel yeni kuruldu / ağ değişti: açılış gürültüsü
        // Tüm tehditler için ortak sınır: aynı turda ya da kısa süre önce başka bir müdahale yapıldıysa en acil olan önce gider.
        if (severe && thisTick >= MAX_SEVERE_PER_TICK) return false      // çok şiddetli saldırıda bile tek turda en çok 2 müdahale (tüm önlemler birden açılmasın)
        if (!severe && (thisTick > 0 || (lastGlobal != 0L && now - lastGlobal < GLOBAL_COOLDOWN_MS))) return false
        disruptive.removeAll { it <= now - 60 * 60_000L }
        val budgetLeft = disruptive.size < MAX_DISRUPTIVE_PER_HOUR
        // Kesintili önlemler (sunucu/yönlendirici değiştirme) kendileri de kısa bir kesinti yaratır: saatte en çok [MAX_DISRUPTIVE_PER_HOUR].
        val act = active()                                         // başka bir tehdidin zaten açtığı sürekli önlem (ör. QUIC_OFF) yeniden seçilmez: etkisiz olur, sonra yanlışlıkla geri alınırdı
        val cands = t.ladder.filter { it !in s.applied && (!it.sticky || it !in act) && can(it) && !banned(t, it, now) && (it.sticky || budgetLeft) }
        if (cands.isEmpty()) return false
        // Keşif oranı deneyim arttıkça düşer: yeni durumda %15, çok ölçülmüş durumda %3.
        var seen = 0.0
        for (a in cands) { val c = cnt[skey(t, a)] ?: cnt[key(t, a)]; if (c != null) seen += maxOf(0.0, c[0] + c[1] - 2.0) }
        val pct = (EXPLORE_PCT - seen.toInt()).coerceIn(EXPLORE_MIN, EXPLORE_PCT)
        val pick = if (cands.size > 1 && random.nextInt(100) < pct) cands[random.nextInt(cands.size)]
        else cands.withIndex().maxByOrNull { (i, a) -> efficacy(t, a) + (cands.size - i) * 0.01 }!!.value
        if (s.lastRelax != 0L && now - s.lastRelax < RETURN_MS) s.quietMul = minOf(s.quietMul * 2, 16)     // geri döndü: bir sonraki rahatlama daha geç
        s.applied.add(pick)
        s.lastChange = now
        s.pendAct = pick
        s.pendBefore = sum(s.events, now, EVAL_MS)
        s.pendHarm = sum(harmEv, now, EVAL_MS)
        s.pendAt = now + EVAL_MS
        lastGlobal = now
        s.cusum = 0.0
        if (!pick.sticky) disruptive.add(now)
        out.add(Change(t, pick, true))
        return true
    }

    private fun relax(t: Threat, s: State, now: Long, out: MutableList<Change>) {
        if (s.applied.isEmpty() || now - s.lastEvent < QUIET_MS * s.quietMul || now - s.lastChange < COOLDOWN_MS) return
        val a = s.applied.removeAt(s.applied.size - 1)
        s.lastChange = now
        s.lastRelax = now
        s.pendAct = null
        for (k in listOf(key(t, a), skey(t, a)).distinct()) {
            val c = cnt[k] ?: continue
            c[0] = c[0] * 0.97 + 0.03; c[1] = c[1] * 0.97 + 0.03      // rahat dönemde öğrenilen değer yavaşça başlangıca döner
        }
        if (a.sticky) out.add(Change(t, a, false))
    }

    /**
     * CUSUM (sıralı değişiklik testi): dakika başına olay hızı x, taban hızı µ'nün biraz üstündeki referans k'yi aşan her fark birikir
     * (S = max(0, S + x − k)). Tek seferlik sıçrama biriktirmez ama tabanın azıcık üstünde SÜREN bir artış (yavaş saldırı) eşiği ([CUSUM_H])
     * aşar. Böylece pencere eşiği gürültüye karşı yüksek tutulabilir, yavaş saldırı yine de erken yakalanır.
     */
    private fun updateCusum(t: Threat, s: State, now: Long, prev: Long) {
        val dt = if (prev == 0L) 60_000L else (now - prev).coerceIn(20_000L, 5 * 60_000L)
        var w = 0.0
        for (e in s.events) if (e.at in (now - dt + 1)..now) w += e.w
        val x = w * 60_000.0 / dt                                  // dakika başına hız
        val mu = s.base / 2.0                                       // taban pencere (2 dk) toplamıdır
        val k = mu + CUSUM_SIGMA * Math.sqrt(mu) + CUSUM_REF
        s.cusum = maxOf(0.0, s.cusum + (x - k) * (dt / 60_000.0)).coerceAtMost(CUSUM_H * 4)
    }

    /** Sakin dönemlerde (önlem yok, eşik altı) olay tabanını günceller. */
    private fun calm(t: Threat, s: State, now: Long) {
        if (s.quietMul > 1 && s.applied.isEmpty() && now - maxOf(s.lastEvent, s.lastRelax) > RETURN_MS * 6) s.quietMul = 1
        if (s.applied.isNotEmpty() || s.pendAct != null) return
        val score = sum(s.events, now, WINDOW_MS)
        // Tırmanan dizi (ör. yavaş artan saldırı) tabanı hızla çekemez: örnek, mevcut tabanın 1,5 katı + 1 ile sınırlıdır.
        if (score < effTrigger(t, s)) s.base = s.base * 0.98 + minOf(score, s.base * 1.5 + 1.0) * 0.02
    }

    /**
     * İç durumun tutarlılığını denetler, bozukları onarır. [tick] her turda çağırır. Onarım yapıldıysa [repairs] artar.
     */
    @Synchronized fun selfCheck(now: Long): Int {
        var fixed = 0
        if (lastTick != 0L && now < lastTick - 1000) {                 // saat geri sarıldı: zamana bağlı her şey geçersiz
            for (s in st.values) { s.events.clear(); s.pendAct = null; s.lastChange = now; s.lastEvent = now }
            harmEv.clear(); lastGlobal = 0L; holdUntil = 0L; disruptive.clear(); bans.clear()
            for (s in st.values) { s.lastRelax = 0L; s.cusum = 0.0 }
            fixed++
        }
        for ((t, s) in st) {
            if (s.events.removeAll { it.at > now + 1000 || it.w.isNaN() || it.w <= 0.0 }) fixed++
            val ok = s.applied.filter { it in t.ladder }.distinct()
            if (ok.size != s.applied.size) { s.applied.clear(); s.applied.addAll(ok); fixed++ }
            val p = s.pendAct
            if (p != null && (p !in s.applied || s.pendAt > now + EVAL_MS * 2)) { s.pendAct = null; fixed++ }
            // Geleceğe dönük zaman damgası (bozuk kayıt/saat sıçraması) rahatlamayı sonsuza dek kilitlerdi: şimdiye çekilir.
            if (s.lastEvent > now) { s.lastEvent = now; fixed++ }
            if (s.lastChange > now) { s.lastChange = now; fixed++ }
            if (s.lastRelax > now) { s.lastRelax = now; fixed++ }
            if (s.base.isNaN() || s.base < 0.0 || s.base > t.trigger * 10) { s.base = 0.0; fixed++ }
        }
        if (harmEv.removeAll { it.at > now + 1000 || it.w.isNaN() || it.w <= 0.0 }) fixed++
        val bad = cnt.entries.filter { e -> e.value.size != 2 || e.value.any { it.isNaN() || it < 0.0 || it > 1e6 } }.map { it.key }
        if (bad.isNotEmpty()) { bad.forEach { cnt.remove(it) }; fixed++ }
        if (lastGlobal > now) { lastGlobal = now; fixed++ }
        if (holdUntil > now + NET_HOLD_MS * 2) { holdUntil = now + NET_HOLD_MS; fixed++ }
        for (b in bans.values) if (b.until > now + BAN_MAX_MS * 2) { b.until = now + BAN_MAX_MS; fixed++ }
        repairs += fixed
        return fixed
    }

    /** Tanılama özeti: etkin önlemler, eşiğe oran, yasaklar. */
    @Synchronized fun describe(now: Long): String {
        val sb = StringBuilder()
        for (t in Threat.values()) {
            val s = st.getValue(t)
            val sc = sum(s.events, now, WINDOW_MS)
            if (s.applied.isEmpty() && sc <= 0.0) continue
            if (sb.isNotEmpty()) sb.append("; ")
            sb.append(t.name).append(' ').append(String.format(java.util.Locale.ROOT, "%.1f/%.1f", sc, effTrigger(t, s)))
            if (s.applied.isNotEmpty()) sb.append(" önlem=").append(s.applied.joinToString(","))
        }
        val bn = bans.entries.filter { it.value.until > now }.map { it.key }
        if (bn.isNotEmpty()) { if (sb.isNotEmpty()) sb.append("; "); sb.append("yasak=").append(bn.joinToString(",")) }
        return sb.toString()
    }

    /** Öğrenilen ağırlıklar: "[bağlam/]TEHDİT:ÖNLEM=başarı:başarısızlık;..." (yalnızca başlangıçtan belirgin farklı olanlar). */
    @Synchronized fun encode(): String =
        cnt.entries.filter { (mean(it.value) ?: PRIOR).let { m -> Math.abs(m - PRIOR) > 0.01 } || it.value[0] + it.value[1] > 2.5 }
            .sortedBy { it.key }
            .joinToString(";") { it.key + "=" + String.format(java.util.Locale.ROOT, "%.2f:%.2f", it.value[0], it.value[1]) }

    /** [encode] çıktısını yükler (eski "değer" biçimi de okunur); bozuk/bilinmeyen girdileri atlar, hata fırlatmaz. */
    @Synchronized fun decode(text: String?) {
        if (text.isNullOrEmpty() || text.length > 4096) return
        for (part in text.split(';')) {
            val i = part.indexOf('=')
            if (i <= 0) continue
            val k = part.substring(0, i)
            val sl = k.indexOf('/')
            if (sl == 0 || sl > 12 || (sl > 0 && !k.substring(0, sl).all { it in 'a'..'z' || it in '0'..'9' })) continue
            val kk = k.substring(sl + 1)
            val c = kk.indexOf(':')
            if (c <= 0) continue
            val t = Threat.values().firstOrNull { it.name == kk.substring(0, c) } ?: continue
            val a = Act.values().firstOrNull { it.name == kk.substring(c + 1) } ?: continue
            if (a !in t.ladder) continue
            val v = part.substring(i + 1)
            val j = v.indexOf(':')
            if (j < 0) {
                val m = v.toDoubleOrNull() ?: continue
                if (m.isNaN()) continue
                val x = m.coerceIn(0.0, 1.0)
                cnt[k] = doubleArrayOf(x * LEGACY_N, (1.0 - x) * LEGACY_N)
            } else {
                val a0 = v.substring(0, j).toDoubleOrNull() ?: continue
                val b0 = v.substring(j + 1).toDoubleOrNull() ?: continue
                if (a0.isNaN() || b0.isNaN() || a0 < 0 || b0 < 0 || a0 + b0 <= 0 || a0 > MAX_COUNT || b0 > MAX_COUNT) continue
                cnt[k] = doubleArrayOf(a0, b0)
            }
        }
    }

    /** Öğrenilenler + çalışma durumu (açık sürekli önlemler, kalan yasak süreleri): "bellek|durum". Durum zaman içermez, kalan süredir. */
    @Synchronized fun encodeAll(now: Long): String {
        val parts = ArrayList<String>()
        for ((t, s) in st) for (a in s.applied) if (a.sticky) parts.add("A." + t.name + "." + a.name)
        for ((k, b) in bans) if (b.until > now) parts.add("B." + k.replace(':', '.') + "." + ((b.until - now) / 1000) + "." + b.strikes)
        return encode() + "|" + parts.joinToString(";")
    }

    /**
     * [encodeAll] çıktısını yükler. Açık sürekli önlemler yeniden açılır (dönen [Change]'ler servisin onları uygulaması içindir) ve
     * olay gelmezse [QUIET_MS] sonra normal biçimde geri alınır. Bozuk girdiler atlanır.
     */
    @Synchronized fun decodeAll(text: String?, now: Long): List<Change> {
        val out = ArrayList<Change>()
        if (text.isNullOrEmpty() || text.length > 8192) return out
        val bar = text.indexOf('|')
        decode(if (bar < 0) text else text.substring(0, bar))
        if (bar < 0) return out
        for (part in text.substring(bar + 1).split(';')) {
            val f = part.split('.')
            try {
                if (f.size == 3 && f[0] == "A") {
                    val t = Threat.values().firstOrNull { it.name == f[1] } ?: continue
                    val a = Act.values().firstOrNull { it.name == f[2] } ?: continue
                    val s = st.getValue(t)
                    if (a !in t.ladder || !a.sticky || a in s.applied || a in active()) continue   // aynı önlem iki tehdide yazılmaz: biri kapatınca öteki "açık" sanırdı
                    s.applied.add(a); s.lastChange = now; s.lastEvent = now
                    out.add(Change(t, a, true))
                } else if (f.size == 5 && f[0] == "B") {
                    val t = Threat.values().firstOrNull { it.name == f[1] } ?: continue
                    val a = Act.values().firstOrNull { it.name == f[2] } ?: continue
                    if (a !in t.ladder) continue
                    val sec = f[3].toLong().coerceIn(0L, BAN_MAX_MS / 1000)
                    bans[key(t, a)] = Ban(now + sec * 1000, f[4].toInt().coerceIn(0, MAX_STRIKES))
                }
            } catch (_: NumberFormatException) {}
        }
        return out
    }

    @Synchronized fun reset() {
        for (s in st.values) { s.events.clear(); s.applied.clear(); s.pendAct = null; s.lastEvent = 0L; s.lastChange = 0L; s.base = 0.0; s.streak = 0; s.cusum = 0.0; s.quietMul = 1; s.lastRelax = 0L }
        harmEv.clear(); bans.clear(); disruptive.clear(); lastGlobal = 0L; lastTick = 0L; holdUntil = 0L
    }

    companion object {
        const val WINDOW_MS = 2 * 60_000L
        const val EVAL_MS = 3 * 60_000L
        const val COOLDOWN_MS = 90_000L
        const val GLOBAL_COOLDOWN_MS = 45_000L
        const val QUIET_MS = 15 * 60_000L
        const val RETURN_MS = 60 * 60_000L
        const val KEEP_MS = 10 * 60_000L
        const val BAN_BASE_MS = 10 * 60_000L
        const val BAN_MAX_MS = 4 * 60 * 60_000L
        const val MAX_STRIKES = 6
        const val MIN_RELIEF = 0.2
        const val GOOD_RELIEF = 0.5
        const val PRIOR = 0.5
        const val EXPLORE_PCT = 15
        const val EXPLORE_MIN = 3
        const val MAX_WEIGHT = 10.0
        const val MAX_EVENTS = 400
        const val SEVERE = 3.0
        const val CONFIRM_TICKS = 2
        const val CUSUM_H = 8.0
        const val MAX_DISRUPTIVE_PER_HOUR = 3
        const val MAX_SEVERE_PER_TICK = 2
        const val NET_HOLD_MS = 3 * 60_000L
        const val CUSUM_SIGMA = 1.0
        const val CUSUM_REF = 0.4
        const val IMMEDIATE = 1.5
        const val BASE_K = 2.5
        const val DECAY = 0.97
        const val MAX_COUNT = 60.0
        const val LEGACY_N = 4.0
        const val HARM_MIN = 3.0
        const val HARM_RATIO = 2.0
    }
}

/**
 * Ağ geçidinde DPI atlatma açık olmalı mı? Kullanıcı açtıysa evet. Kapalıysa yalnızca "Otomatik DPI" açıkken ve otomatik koruma DPI önlemini
 * açmışsa evet: anahtar kapatılınca önceden otomatik açılmış DPI de hemen kapanır (eskiden açık kalıyordu).
 */
internal fun dpiWanted(userDpi: Boolean, autoDpi: Boolean, acts: Set<Act>): Boolean = userDpi || (autoDpi && Act.DPI_ON in acts)
