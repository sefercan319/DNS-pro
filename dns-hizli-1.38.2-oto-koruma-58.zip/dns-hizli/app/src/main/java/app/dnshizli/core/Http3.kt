package app.dnshizli.core

import java.io.ByteArrayOutputStream
import java.io.IOException

/**
 * DNS-over-HTTP/3 (RFC 8484 + RFC 9114) için en küçük HTTP/3 istemcisi, [QuicClient] üzerinde.
 *
 * QPACK dinamik tablosu KULLANILMAZ (kapasite 0 ilan edilir): istekte yalnızca statik tablo ve düz (Huffman'sız) değerler yazılır;
 * cevapta yalnızca ":status" okunur, öteki başlıklar atlanır. Dinamik tabloya başvuran bir cevap (olmamalı) hata sayılır.
 */
class Http3Client(private val quic: QuicClient, private val authority: String) {
    private var ready = false

    /** İstemci denetim ve QPACK akışlarını açar (bir kez). */
    @Synchronized
    private fun init() {
        if (ready) return
        val ctl = quic.openUni()
        // akış türü 0x00 (denetim) + SETTINGS (0x04): QPACK_MAX_TABLE_CAPACITY=0, QPACK_BLOCKED_STREAMS=0
        quic.send(ctl, byteArrayOf(0x00, 0x04, 0x04, 0x01, 0x00, 0x07, 0x00), false)
        quic.send(quic.openUni(), byteArrayOf(0x02), false)         // QPACK kodlayıcı akışı
        quic.send(quic.openUni(), byteArrayOf(0x03), false)         // QPACK çözücü akışı
        ready = true
    }

    private fun str(o: ByteArrayOutputStream, s: String) { o.write(qpackString(s)) }

    /** [body]'yi [path]'e POST eder; 200 cevabın gövdesini döner. */
    fun post(path: String, contentType: String, body: ByteArray, timeoutMs: Int): ByteArray {
        init()
        val h = ByteArrayOutputStream()
        h.write(0); h.write(0)                                      // gerekli ekleme sayısı 0, taban 0
        h.write(0xC0 or 20)                                         // :method POST (statik 20)
        h.write(0xC0 or 23)                                         // :scheme https (statik 23)
        h.write(0x50); str(h, authority)                            // :authority (statik 0 adı)
        h.write(0x51); str(h, path)                                 // :path (statik 1 adı)
        literal(h, "accept", contentType)
        literal(h, "content-type", contentType)
        literal(h, "user-agent", "Mozilla/5.0")
        val hb = h.toByteArray()
        val o = ByteArrayOutputStream(hb.size + body.size + 16)
        o.write(0x01); o.write(QuicClient.varBytes(hb.size.toLong())); o.write(hb)
        o.write(0x00); o.write(QuicClient.varBytes(body.size.toLong())); o.write(body)
        val s = quic.openBidi()
        quic.send(s, o.toByteArray(), true)
        return parseResponse(quic.await(s, timeoutMs))
    }

    /** Adı ve değeri düz yazılan başlık: 001 N H NNN (ad uzunluğu 3 bit önekli) + değer. */
    private fun literal(o: ByteArrayOutputStream, name: String, value: String) {
        val n = name.toByteArray(Charsets.ISO_8859_1)
        if (n.size < 7) o.write(0x20 or n.size) else { o.write(0x27); o.write(n.size - 7) }
        o.write(n)
        str(o, value)
    }

    companion object {
    internal class Pos(var p: Int)

        /** QPACK düz (Huffman'sız) değer: 7 bitlik önekli uzunluk + bayt. 126'dan uzun değerler de doğru yazılır. */
        internal fun qpackString(s: String): ByteArray {
            val b = s.toByteArray(Charsets.ISO_8859_1)
            val o = ByteArrayOutputStream(b.size + 4)
            var n = b.size
            if (n < 127) o.write(n) else {
                o.write(0x7F); n -= 127
                while (n >= 128) { o.write((n and 0x7F) or 0x80); n = n ushr 7 }
                o.write(n)
            }
            o.write(b)
            return o.toByteArray()
        }
    
        internal fun prefInt(b: ByteArray, pos: Pos, bits: Int): Int {
            if (pos.p >= b.size) throw IOException("bozuk QPACK tamsayısı")
            val max = (1 shl bits) - 1
            var v = (b[pos.p++].toInt() and max).toLong()
            if (v < max) return v.toInt()
            var m = 0
            while (true) {
                if (pos.p >= b.size || m > 28) throw IOException("bozuk QPACK tamsayısı")
                val x = b[pos.p++].toInt() and 0xFF
                v += (x and 0x7F).toLong() shl m; m += 7
                if (v > MAX_QPACK_INT) throw IOException("QPACK tamsayısı çok büyük")        // 32 bit taşması ve geriye sarma olmasın
                if (x and 0x80 == 0) return v.toInt()
            }
        }

        /** Başlık bloğundaki bir uzunluk/dizin için üst sınır (yanıt zaten en çok 128 KB). */
        private const val MAX_QPACK_INT = 1L shl 20

        /** HEADERS'ta ":status", DATA'larda gövde. */
        internal fun parseResponse(b: ByteArray): ByteArray {
            var p = 0
            var status = 0
            val body = ByteArrayOutputStream()
            while (p < b.size) {
                val t = QuicInitial.readVar(b, p, b.size); if (t < 0) throw IOException("bozuk HTTP/3 çerçevesi")
                p += QuicInitial.varLen(b[p].toInt() and 0xFF)
                val l = QuicInitial.readVar(b, p, b.size); if (l < 0 || p + QuicInitial.varLen(b[p].toInt() and 0xFF) + l > b.size) throw IOException("bozuk HTTP/3 çerçevesi")
                p += QuicInitial.varLen(b[p].toInt() and 0xFF)
                val e = p + l.toInt()
                when (t) {
                    0x01L -> if (status == 0 || status in 100..199) status = try { statusOf(b.copyOfRange(p, e)) } catch (_: IndexOutOfBoundsException) { throw IOException("bozuk QPACK") }
                    0x00L -> body.write(b, p, e - p)
                }
                p = e
            }
            if (status != 200) throw IOException("HTTP/3 $status")
            return body.toByteArray()
        }
    
        internal fun statusOf(hb: ByteArray): Int {
            if (hb.size < 2 || hb[0].toInt() != 0 || (hb[1].toInt() and 0x7F) != 0) throw IOException("QPACK dinamik tablo kullanıldı")
            val pos = Pos(2)
            var status = 0
            while (pos.p < hb.size) {
                val f = hb[pos.p].toInt() and 0xFF
                when {
                    f and 0x80 != 0 -> {                                        // dizinli alan
                        val st = f and 0x40 != 0
                        val i = prefInt(hb, pos, 6)
                        if (!st) throw IOException("QPACK dinamik tablo kullanıldı")
                        statusIdx(i)?.let { status = it }
                    }
                    f and 0xC0 == 0x40 -> {                                     // adı dizinli, değer düz/Huffman
                        val st = f and 0x10 != 0
                        val i = prefInt(hb, pos, 4)
                        if (!st) throw IOException("QPACK dinamik tablo kullanıldı")
                        if (pos.p >= hb.size) throw IOException("bozuk QPACK")
                        val huff = hb[pos.p].toInt() and 0x80 != 0
                        val vl = prefInt(hb, pos, 7)
                        if (vl < 0 || pos.p + vl > hb.size) throw IOException("bozuk QPACK")
                        if (statusIdx(i) != null) {
                            // Değer Huffman kodlu olabilir (QPACK, HPACK ile aynı Huffman tablosunu kullanır): çözülmezse durum 0 kalıp geçerli cevap atılırdı.
                            val raw = if (huff) try { HuffmanDecoder.decode(hb, pos.p, vl) } catch (_: Exception) { null } else hb.copyOfRange(pos.p, pos.p + vl)
                            raw?.let { status = String(it, Charsets.ISO_8859_1).toIntOrNull() ?: status }
                        }
                        pos.p += vl
                    }
                    f and 0xE0 == 0x20 -> {                                     // adı da düz
                        val nl = prefInt(hb, pos, 3)
                        if (nl < 0 || pos.p + nl >= hb.size) throw IOException("bozuk QPACK")
                        pos.p += nl
                        val vl = prefInt(hb, pos, 7)
                        if (vl < 0 || pos.p + vl > hb.size) throw IOException("bozuk QPACK")
                        pos.p += vl
                    }
                    else -> throw IOException("QPACK dinamik tablo kullanıldı")
                }
            }
            return status
        }
    
        /** QPACK statik tablosunda ":status" satırları (RFC 9204 Ek A): dizin → durum kodu; öteki dizinler null. */
        internal fun statusIdx(i: Int): Int? = when (i) {
            24 -> 103; 25 -> 200; 26 -> 304; 27 -> 404; 28 -> 503
            63 -> 100; 64 -> 204; 65 -> 206; 66 -> 302; 67 -> 400; 68 -> 403; 69 -> 421; 70 -> 425; 71 -> 500
            else -> null
        }
    
    }
}
