package app.dnshizli.core

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

/**
 * İndirilen liste dosyalarının diskte güvenli yerine konması (Android'siz; JVM'de test edilir).
 *
 * Tüm liste kümesi tek bir dizin olarak değiştirilir; dizin yeniden adlandırma tek adımdır, böylece yarım kalmış bir güncelleme
 * (uygulama ölür, disk dolar, telefon kapanır) eski ve yeni sürümden dosyaların karışmasına yol açamaz:
 *
 *  1. yeni dosyalar `liste.yeni/` içine yazılır (kurulu liste dokunulmaz),
 *  2. `liste/` → `liste.eski/`,
 *  3. `liste.yeni/` → `liste/`,
 *  4. `liste.eski/` silinir.
 *
 * Adım 2 ile 3 arasında kesilirse [recover] eskiyi geri koyar; adım 3'ten sonra kesilirse yeni sürüm yerindedir.
 * Okuyucular `liste/` altında dosya bulamazsa paketteki sürüme düşer (bkz. [FilterRuntime]); dizin hiç "yarım" görünmez.
 */
internal object ListStore {
    const val DIR = "liste"
    const val STAGE = "liste.yeni"
    const val BACKUP = "liste.eski"

    /** Kurulu listelerin dizini (yoksa oluşturulmaz). */
    fun dir(root: File): File = File(root, DIR)

    /**
     * Yarım kalmış bir yerine koymayı toparlar. Kurulu dizin yok ama yedek varsa yedek geri konur; yarım yazılmış yeni dizin ve
     * (kurulu dizin yerindeyse) artık gereksiz yedek silinir.
     */
    @Synchronized
    fun recover(root: File) {
        val cur = File(root, DIR)
        val old = File(root, BACKUP)
        if (!cur.exists() && old.exists()) old.renameTo(cur)
        deleteTree(File(root, STAGE))
        if (cur.exists()) deleteTree(old)
    }

    /** Dosya sistemi işlemleri; testlerde disk dolu / yarım yazım / yeniden adlandırma hatası enjekte etmek için değiştirilir. */
    internal class Io(
        val write: (File, ByteArray) -> Unit = { f, b -> java.io.FileOutputStream(f).use { it.write(b); it.fd.sync() } },    // fsync: güç kesintisinde sıfır uzunluklu dosya kalmasın
        val rename: (File, File) -> Boolean = { a, b -> a.renameTo(b) },
    )

    /** Kurulu listelerle birlikte durur: her dosyanın özeti ve boyu (diskteki sessiz bozulmayı yakalamak için). */
    const val DIGESTS = "ozet.txt"
    private const val DIGEST_HEAD = "DNSHIZLI-OZET 1"

    private fun digestText(data: Map<String, ByteArray>): ByteArray {
        val sb = StringBuilder(DIGEST_HEAD).append('\n')
        for ((n, b) in data) sb.append(n).append(' ').append(ListUpdate.sha256Hex(b)).append(' ').append(b.size).append('\n')
        return sb.toString().toByteArray(Charsets.UTF_8)
    }

    /**
     * [data] içindeki dosyaların hepsini (ad → içerik) tek adımda yerine koyar. Başarısızlıkta kurulu liste olduğu gibi kalır ve
     * false döner. Dosya adları yalnızca [ListUpdate.UPDATABLE] içinden olabilir (yol geçişi yok). Her yazım sonrası dosya boyu
     * denetlenir (disk dolunca bazı sistemler hata vermeden kısa yazar); özet dosyası ([DIGESTS]) aynı dizine, aynı adımda girer.
     */
    @Synchronized
    internal fun install(root: File, data: Map<String, ByteArray>, io: Io = Io()): Boolean {
        val cur = File(root, DIR)
        val stage = File(root, STAGE)
        val old = File(root, BACKUP)
        try {
            if (data.isEmpty() || data.keys.any { it !in ListUpdate.UPDATABLE }) return false
            recover(root)
            if (!root.isDirectory && !root.mkdirs()) { return false }
            if (!stage.mkdirs()) return false
            for ((name, bytes) in data) {
                val f = File(stage, name)
                io.write(f, bytes)
                if (f.length() != bytes.size.toLong()) { deleteTree(stage); return false }
            }
            val dg = digestText(data)
            val df = File(stage, DIGESTS)
            io.write(df, dg)
            if (df.length() != dg.size.toLong()) { deleteTree(stage); return false }
            if (cur.exists() && !io.rename(cur, old)) { deleteTree(stage); return false }
            if (!io.rename(stage, cur)) {
                if (old.exists()) io.rename(old, cur)       // geri al
                deleteTree(stage)
                return false
            }
            deleteTree(old)
            return true
        } catch (_: Throwable) {
            deleteTree(stage)
            if (!cur.exists() && old.exists()) old.renameTo(cur)
            return false
        }
    }

    private val verifiedMemo = java.util.concurrent.ConcurrentHashMap<String, Boolean>()

    /**
     * Kurulu liste dosyası, kurulum sırasında kaydedilen özet ve boyla birebir uyuyor mu? Özet dosyası yoksa/bozuksa ya da dosya
     * değişmişse false: çağıran paketteki sürüme düşer. Sonuç, dosya (yol, boy, değişme zamanı) aynı kaldıkça bellekte tutulur;
     * böylece listeler yeniden yüklenirken aynı dosya tekrar tekrar özetlenmez. Her işlem yeniden başlayınca bir kez doğrulanır.
     */
    fun verified(root: File, name: String): Boolean {
        return try {
            val f = File(dir(root), name)
            if (name !in ListUpdate.UPDATABLE || !f.isFile) return false
            val key = f.path + '|' + f.length() + '|' + f.lastModified()
            verifiedMemo[key]?.let { return it }
            val ok = check(root, name, f)
            if (verifiedMemo.size > 64) verifiedMemo.clear()
            verifiedMemo[key] = ok
            ok
        } catch (_: Throwable) { false }
    }

    private fun check(root: File, name: String, f: File): Boolean {
        val df = File(dir(root), DIGESTS)
        if (!df.isFile || df.length() > 4096) return false
        val lines = df.readBytes().toString(Charsets.UTF_8).split('\n')
        if (lines.firstOrNull() != DIGEST_HEAD) return false
        for (l in lines) {
            val p = l.split(' ')
            if (p.size != 3 || p[0] != name) continue
            val size = p[2].toLongOrNull() ?: return false
            if (f.length() != size) return false
            val md = MessageDigest.getInstance("SHA-256")
            FileInputStream(f).use { ins ->
                val buf = ByteArray(65536)
                while (true) { val n = ins.read(buf); if (n < 0) break; md.update(buf, 0, n) }
            }
            return md.digest().joinToString("") { "%02x".format(it) } == p[1]
        }
        return false
    }

    /**
     * Önbellek, yalnızca bu uygulama sürümüyle indirilmişse kullanılır. Uygulama güncellenince paketteki listeler önbellekten daha
     * yeni olabilir; eski önbellek yeni paketi geçersiz kılıp korumayı sessizce eskitmesin diye sürüm değişince önbellek yok sayılır
     * ve güncelleme hemen yeniden denenir.
     */
    fun cacheUsable(cachedForApp: Int, currentApp: Int): Boolean = currentApp > 0 && cachedForApp == currentApp

    private fun deleteTree(f: File) {
        if (!f.exists()) return
        f.listFiles()?.forEach { if (it.isDirectory) deleteTree(it) else it.delete() }
        f.delete()
    }
}
