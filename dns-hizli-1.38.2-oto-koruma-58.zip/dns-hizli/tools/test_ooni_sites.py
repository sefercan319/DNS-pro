import datetime, json, os, tempfile, unittest
import ooni_sites as o


def rows(n_ok=250, blocked=("engel1.example", "engel2.example"), extra=()):
    r = [{"domain": "ok%d.example" % i, "measurement_count": 20, "anomaly_count": 0, "confirmed_count": 0} for i in range(n_ok)]
    r += [{"domain": d, "measurement_count": 20, "anomaly_count": 15, "confirmed_count": 2} for d in blocked]
    return {"result": r + list(extra)}


class T(unittest.TestCase):
    def test_blocked_rule(self):
        b = o.blocked_domains(rows(extra=[{"domain": "az.example", "measurement_count": 3, "anomaly_count": 3, "confirmed_count": 0}]), 8, 0.6, 200)
        self.assertEqual(b, {"engel1.example", "engel2.example"})            # 3 ölçüm yetmez, sağlam ad girmez

    def test_domain_validation(self):
        for bad in ["", "1.2.3.4", "a b.com", "-x.com", "x..com", "tek", "a" * 64 + ".com", "x.com\n.evil", "‮evil.com"]:
            self.assertIsNone(o.valid_domain(bad), bad)
        self.assertEqual(o.valid_domain("Engel.Example."), "engel.example")

    def test_schema_and_size_guards(self):
        for bad in [{}, {"result": "x"}, {"result": [{"x": 1}] * 300}, rows(n_ok=5)]:
            with self.assertRaises(SystemExit):
                o.blocked_domains(bad, 8, 0.6, 200)

    def test_state_expiry(self):
        t = datetime.date(2026, 10, 20)
        s = o.update_state({"eski.example": "2026-07-01", "yeni.example": "2026-09-01", "kotu": "x"}, {"engel1.example"}, t, 90)
        self.assertEqual(set(s), {"yeni.example", "engel1.example"})

    def test_end_to_end_and_shrink_guard(self):
        with tempfile.TemporaryDirectory() as d:
            args = ["--state", d + "/s.json", "--out", d + "/o.txt"]
            o.main(args, rows(), datetime.date(2026, 10, 20))
            lines = open(d + "/o.txt").read().split("\n")
            self.assertTrue(lines[0].startswith("# surum="))
            self.assertEqual([x for x in lines[1:] if x], ["engel1.example", "engel2.example"])
            json.dump({"x%d.example" % i: "2026-10-19" for i in range(10)}, open(d + "/s.json", "w"))
            with self.assertRaises(SystemExit):                              # 10 adlık liste 2'ye düşerse yayın iptal
                o.main(args, rows(), datetime.date(2027, 2, 1))


if __name__ == "__main__":
    unittest.main()
