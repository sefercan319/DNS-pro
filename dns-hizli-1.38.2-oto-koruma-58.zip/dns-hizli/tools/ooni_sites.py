#!/usr/bin/env python3
"""OONI ölçümlerinden bir ülkenin ENGELLİ alan adları listesini üretir (DNS Hızlı için).

Kaynak: OONI herkese açık toplu sayaç API'si (GET /api/v1/aggregation, test web_connectivity, axis_x=domain).
Kural : son --days gün içinde en az --min-meas ölçüm ve (anormal+onaylı)/ölçüm >= --min-ratio olan alan adı "engelli" sayılır.
        Engelli görülen ad listeye girer; --keep-days gün boyunca hiç engelli görülmezse listeden düşer (durum dosyası).
Güvenlik: şema beklenenden farklıysa, çok az alan adı gelirse ya da liste önceki sürümün yarısından küçülürse HATA verir
        (boş/bozuk bir liste yayınlanmaz). Alan adları sıkı doğrulanır (IP, boşluk, kontrol karakteri atılır).
NOT   : API yanıt alanları (domain, measurement_count, anomaly_count, confirmed_count) OONI belgesinden değil, bilinen biçimden
        alınmıştır ve bu betik canlı API'ye karşı henüz çalıştırılmadı; ilk çalıştırmada şema denetimi başarısız olursa
        mesajdaki alan adlarına göre FIELDS düzeltilmelidir.
"""
import argparse, datetime, json, re, sys, time, urllib.parse, urllib.request

API = "https://api.ooni.io/api/v1/aggregation"
FIELDS = ("domain", "measurement_count", "anomaly_count", "confirmed_count")
LABEL = re.compile(r"^(?!-)[a-z0-9-]{1,63}(?<!-)$")


def valid_domain(d):
    d = d.strip().lower().rstrip(".")
    if not d or len(d) > 253 or "." not in d:
        return None
    parts = d.split(".")
    if all(p.isdigit() for p in parts):          # IPv4
        return None
    if not all(LABEL.fullmatch(p) or (p.startswith("xn--") and LABEL.fullmatch(p)) for p in parts):
        return None
    return d


def fetch(country, days, api=API, opener=urllib.request.urlopen, sleep=time.sleep):
    until = datetime.datetime.now(datetime.timezone.utc)
    since = until - datetime.timedelta(days=days)
    q = urllib.parse.urlencode({
        "probe_cc": country, "test_name": "web_connectivity", "axis_x": "domain",
        "since": since.strftime("%Y-%m-%dT%H:%M:%S"), "until": until.strftime("%Y-%m-%dT%H:%M:%S"),
    })
    for attempt in range(5):
        try:
            with opener(urllib.request.Request(api + "?" + q, headers={"User-Agent": "dns-hizli-listeci"}), timeout=120) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as e:                     # 429 / geçici ağ hatası: bekleyip yeniden dene
            if attempt == 4:
                raise SystemExit("API okunamadı: %s" % e)
            sleep(30 * (attempt + 1))


def blocked_domains(payload, min_meas, min_ratio, min_rows):
    rows = payload.get("result") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        raise SystemExit("API şeması beklenenden farklı: 'result' listesi yok")
    if len(rows) < min_rows:
        raise SystemExit("çok az alan adı geldi (%d < %d): API sorunu olabilir, liste değiştirilmedi" % (len(rows), min_rows))
    if not any(isinstance(r, dict) and all(k in r for k in FIELDS) for r in rows):
        raise SystemExit("API şeması beklenenden farklı: %s alanları bulunamadı" % ", ".join(FIELDS))
    tot = {}
    for r in rows:
        if not isinstance(r, dict):
            continue
        d = valid_domain(str(r.get("domain", "")))
        if d is None:
            continue
        try:
            m = int(r["measurement_count"]); b = int(r["anomaly_count"]) + int(r["confirmed_count"])
        except (KeyError, ValueError, TypeError):
            continue
        t = tot.setdefault(d, [0, 0]); t[0] += m; t[1] += b
    return {d for d, (m, b) in tot.items() if m >= min_meas and b / m >= min_ratio}


def update_state(state, blocked, today, keep_days):
    """state: {alan_adı: son_engelli_görülme_tarihi (YYYY-MM-DD)} -> yeni durum."""
    out = {d: s for d, s in state.items() if valid_domain(d) and re.match(r"^\d{4}-\d\d-\d\d$", str(s))}
    for d in blocked:
        out[d] = today.isoformat()
    cut = (today - datetime.timedelta(days=keep_days)).isoformat()
    return {d: s for d, s in out.items() if s >= cut}


def main(argv=None, payload=None, today=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--country", default="TR"); ap.add_argument("--days", type=int, default=30)
    ap.add_argument("--min-meas", type=int, default=8); ap.add_argument("--min-ratio", type=float, default=0.6)
    ap.add_argument("--keep-days", type=int, default=90); ap.add_argument("--min-rows", type=int, default=200)
    ap.add_argument("--max", type=int, default=5000)
    ap.add_argument("--state", default="dist/engelli-state.json"); ap.add_argument("--out", default="dist/engelli.txt")
    a = ap.parse_args(argv)
    today = today or datetime.date.today()
    if payload is None:
        payload = fetch(a.country, a.days)
    blocked = blocked_domains(payload, a.min_meas, a.min_ratio, a.min_rows)
    try:
        state = json.load(open(a.state, encoding="utf-8"))
    except (OSError, ValueError):
        state = {}
    if not isinstance(state, dict):
        state = {}
    new = update_state(state, blocked, today, a.keep_days)
    names = sorted(new)[: a.max]
    if state and len(names) < len(state) * 0.5:
        raise SystemExit("liste önceki sürümün yarısından küçüldü (%d < %d): yayın iptal" % (len(names), len(state)))
    import os
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    open(a.state, "w", encoding="utf-8").write(json.dumps({d: new[d] for d in names}, indent=0, sort_keys=True))
    open(a.out, "w", encoding="utf-8").write("# surum=%d\n" % int(time.time()) + "\n".join(names) + "\n")
    print("engelli alan adı: %d (bu çalıştırmada görülen: %d)" % (len(names), len(blocked)))


if __name__ == "__main__":
    main()
