package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyStore
import java.util.Random
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLServerSocket
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManagerFactory

/**
 * Sızma girişimi 2 — tarayıcı kipi (MITM vekili), tur 2. Saldırgan: kural listesindeki bir sitenin sahibi (kötü niyetli ya da bozuk sunucu).
 *  - chunked çözücü: doğrusal süre, her bölünmede doğru bitiş, bozuk çerçeve; veri içindeki "0\r\n\r\n" erken kesmez.
 *  - kesik gövde "tam" gösterilmez, TE+CL birlikte gelirse akış kesilmez.
 *  - enjeksiyon: betik/yorum/başlık metni içindeki "</head>" atlanır; CSP nonce'u doğru yönergeden.
 *  - kozmetik seçiciler: dengesiz tırnak/parantez komşu kuralları bozamaz.
 *  - yuva tutma: bir alan bütün bağlantı yuvalarını tutup öteki siteleri engelleyemez.
 */

private val LB: InetAddress = InetAddress.getLoopbackAddress()

private fun trustOf(ca: MitmCa): SSLContext {
    val ks = KeyStore.getInstance(KeyStore.getDefaultType()); ks.load(null, null); ks.setCertificateEntry("ca", ca.cert)
    val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()); tmf.init(ks)
    return SSLContext.getInstance("TLS").also { it.init(null, tmf.trustManagers, null) }
}

/** [script]: isteği (ilk okuma) aldıktan sonra çalışır; cevabı kendisi, istediği parçalama ve beklemeyle yazar. */
private class SOut(val out: java.io.OutputStream) {
    fun w(s: String) { out.write(s.toByteArray(Charsets.ISO_8859_1)); out.flush() }
    fun w(b: ByteArray) { out.write(b); out.flush() }
}

private class ScriptOrigin(ca: MitmCa, host: String, val script: (SOut) -> Unit) : AutoCloseable {
    val ss = ca.serverContext(host)!!.serverSocketFactory.createServerSocket(0, 100, LB) as SSLServerSocket
    private val socks = java.util.concurrent.CopyOnWriteArrayList<Socket>()
    init {
        Thread({
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (_: Exception) { break }
                socks.add(s)
                Thread({
                    try {
                        s.soTimeout = 12_000
                        val b = ByteArray(8192)
                        if (s.getInputStream().read(b) > 0) script(SOut(s.getOutputStream()))
                    } catch (_: Exception) {} finally { try { s.close() } catch (_: Exception) {} }
                }).also { it.isDaemon = true }.start()
            }
        }).also { it.isDaemon = true }.start()
    }
    override fun close() { try { ss.close() } catch (_: Exception) {}; for (s in socks) try { s.close() } catch (_: Exception) {} }
}

/** Satır sonu olmayan, [left] baytlık 'a' akışı; okunan bayt sayısı [used]. */
private class Endless(var left: Long) : InputStream() {
    var used = 0L
    override fun read(): Int { if (left <= 0) return -1; left--; used++; return 'a'.code }
    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (len == 0) return 0
        if (left <= 0) return -1
        val n = minOf(len.toLong(), left).toInt()
        java.util.Arrays.fill(b, off, off + n, 'a'.code.toByte()); left -= n; used += n; return n
    }
}

/** İstemci olarak vekile bağlanır ([originPort] gerçek sunucu portu olarak bildirilir); (el sıkışma tamam mı, ham cevap). */
private fun getVia(p: MitmProxy, host: String, ca: MitmCa, originPort: Int, req: String = "GET / HTTP/1.1\r\nHost: x\r\n\r\n", readMs: Int = 6000): Pair<Boolean, ByteArray> {
    val raw = Socket(); raw.bind(InetSocketAddress(LB, 0))
    p.expect(raw.localPort, host, LB, originPort)
    raw.connect(InetSocketAddress(LB, p.port), 3000)
    val s = trustOf(ca).socketFactory.createSocket(raw, host, p.port, true) as SSLSocket
    s.soTimeout = readMs
    try { s.startHandshake() } catch (_: Exception) { try { s.close() } catch (_: Exception) {}; return false to ByteArray(0) }
    s.outputStream.write(req.toByteArray()); s.outputStream.flush()
    val o = ByteArrayOutputStream(); val b = ByteArray(8192)
    try { while (true) { val n = s.inputStream.read(b); if (n < 0) break; o.write(b, 0, n); if (o.size() > 6_000_000) break } } catch (_: Exception) {}
    try { s.close() } catch (_: Exception) {}
    return true to o.toByteArray()
}

/** Her okumada en çok [k] bayt veren akış (TCP/TLS'in keyfi bölünmesini taklit eder). */
private class Trickle(private val data: ByteArray, private val rnd: Random, private val maxRead: Int) : InputStream() {
    private var pos = 0
    override fun read(): Int = if (pos >= data.size) -1 else data[pos++].toInt() and 0xFF
    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (pos >= data.size) return -1
        val n = minOf(len, 1 + rnd.nextInt(maxRead), data.size - pos)
        System.arraycopy(data, pos, b, off, n); pos += n
        return n
    }
}

private fun chunkedBody(rnd: Random, nChunks: Int, trailers: Boolean = rnd.nextBoolean()): Pair<ByteArray, ByteArray> {
    val enc = ByteArrayOutputStream(); val raw = ByteArrayOutputStream()
    repeat(nChunks) {
        val len = 1 + rnd.nextInt(300)
        val d = ByteArray(len).also { rnd.nextBytes(it) }
        if (rnd.nextInt(3) == 0 && len > 12) { val t = "\r\n0\r\n\r\n".toByteArray(); System.arraycopy(t, 0, d, len - t.size - rnd.nextInt(3).coerceAtMost(len - t.size), t.size) }
        if (rnd.nextInt(4) == 0 && len > 12) { val t = "\r\n0\r\n\r\n".toByteArray(); System.arraycopy(t, 0, d, len - t.size, t.size) }      // parça tam bu baytlarla biter
        val hex = if (rnd.nextBoolean()) len.toString(16) else len.toString(16).uppercase()
        enc.write((hex + (if (rnd.nextInt(5) == 0) ";ext=1" else "") + "\r\n").toByteArray()); enc.write(d); enc.write("\r\n".toByteArray())
        raw.write(d)
    }
    enc.write("0\r\n".toByteArray())
    if (trailers) repeat(rnd.nextInt(3)) { enc.write("X-T$it: v\r\n".toByteArray()) }
    enc.write("\r\n".toByteArray())
    return enc.toByteArray() to raw.toByteArray()
}

private fun cssSane(css: String): Boolean {
    val tail = "{display:none!important}"
    var i = 0; var q = '\u0000'
    val st = ArrayList<Char>()
    while (i < css.length) {
        val c = css[i]
        if (q != '\u0000') { if (c == q) q = '\u0000'; i++; continue }
        when (c) {
            '"', '\'' -> q = c
            '[' -> st.add(']')
            '(' -> st.add(')')
            ']', ')' -> { if (st.isEmpty() || st.removeAt(st.size - 1) != c) return false }
            '{' -> { if (st.isNotEmpty() || !css.startsWith(tail, i)) return false; i += tail.length; continue }
            '}' -> return false
        }
        i++
    }
    return q == '\u0000' && st.isEmpty()
}

fun runSizmaMitmTests() {
    val rnd = Random(20261023L)

    // ------------------------------------------------------------------------------------------------------------ chunked bitişi
    T.group("Sızma 2 / vekil: chunked bitiş tespiti her bölünmede doğru (veri içindeki 0\\r\\n\\r\\n yanıltmaz)")
    run {
        var early = 0; var late = 0; var splitBad = 0; var n = 0
        val first = StringBuilder()
        for (iter in 0 until DEEP_X * 700) {
            val (enc, _) = chunkedBody(rnd, rnd.nextInt(12))
            n++
            // bayt bayt: tam son baytta bitmeli
            val ce = ChunkEnd()
            var doneAt = -1
            for (i in enc.indices) if (ce.feed(enc, i, 1)) { doneAt = i; break }
            if (doneAt >= 0 && doneAt < enc.size - 1) { early++; if (first.length < 200) first.append("erken@$doneAt/${enc.size}; ") }
            if (doneAt < 0) { late++; if (first.length < 200) first.append("bitmedi ${enc.size}; ") }
            // rastgele bölünme: son parça dışında bitmemeli, sonunda bitmeli
            val cuts = (0 until 1 + rnd.nextInt(5)).map { 1 + rnd.nextInt(enc.size - 1) }.distinct().sorted()
            val c2 = ChunkEnd(); var prev = 0; var ok = true
            for (c in cuts + enc.size) { val r = c2.feed(enc, prev, c - prev); if (c < enc.size && r) ok = false; prev = c }
            if (!ok || !c2.done || c2.bad) { splitBad++; if (first.length < 200) first.append("bölünme $cuts; ") }
        }
        T.check("$n rastgele chunked gövde: bayt bayt ve rastgele bölünmede tam sonda biter (erken=$early, geç=$late, bölünme=$splitBad)", early == 0 && late == 0 && splitBad == 0, first.toString())

        // eski yöntemin yanıldığı durum: bir okumanın sonu tam "0\r\n\r\n" iken akış henüz bitmedi
        val a = "8\r\nabc\r\n0\r\n\r\n".toByteArray()            // veri "abc\r\n0\r\n" + çerçeve CRLF: tampon "0\r\n\r\n" ile biter
        val b = "4\r\ntail\r\n0\r\n\r\n".toByteArray()
        val ce = ChunkEnd()
        val r1 = ce.feed(a, 0, a.size)
        val r2 = ce.feed(b, 0, b.size)
        T.check("okuma sınırı tam '0\\r\\n\\r\\n' ile bitse de akış bitmiş sayılmaz; gerçek sonda biter", !r1 && r2 && !ce.bad)
        val split = ChunkEnd()
        val s1 = "3\r\nabc\r\n0\r\n".toByteArray(); val s2 = "\r\n".toByteArray()
        T.check("bölünmüş son parça ('0\\r\\n' | '\\r\\n') yine de yakalanır", !split.feed(s1, 0, s1.size) && split.feed(s2, 0, s2.size))
        for (junk in listOf("ZZ\r\nabc", "-1\r\nabc", "123456789\r\nx", ";\r\n", "\r\n")) {
            val j = ChunkEnd(); j.feed(junk.toByteArray(), 0, junk.length)
            T.check("bozuk boyut satırı '${junk.replace("\r\n", "⏎")}' reddedilir (bad)", j.bad && !j.done)
        }
        val big = ChunkEnd(); val ln = ByteArray(2000) { 'a'.code.toByte() }; big.feed("1;".toByteArray(), 0, 2); big.feed(ln, 0, ln.size)
        T.check("sonsuz uzunlukta uzantı satırı bozuk sayılır", big.bad)
    }

    // ------------------------------------------------------------------------------------------------------------ readChunked/readFixed
    T.group("Sızma 2 / vekil: chunked çözücü doğrusal sürede, doğru ve sınırlı (1 baytlık parçalarla DoS yok)")
    run {
        var bad = 0; val first = StringBuilder()
        for (iter in 0 until DEEP_X * 400) {
            val (enc, raw) = chunkedBody(rnd, rnd.nextInt(14))
            val preLen = rnd.nextInt(enc.size + 1)
            val out = ByteArrayOutputStream()
            try {
                MitmProxy.readChunked(enc.copyOfRange(0, preLen), Trickle(enc.copyOfRange(preLen, enc.size), rnd, 1 + rnd.nextInt(9)), out)
                if (!out.toByteArray().contentEquals(raw)) { bad++; if (first.length < 200) first.append("farklı çıktı iter=$iter; ") }
            } catch (e: Throwable) { bad++; if (first.length < 200) first.append("istisna $e; ") }
        }
        T.check("rastgele chunked gövde (ön okuma + keyfi bölünme) birebir çözülür", bad == 0, first.toString())

        val chunks = 300_000
        val one = ByteArrayOutputStream(); repeat(chunks) { one.write("1\r\nX\r\n".toByteArray()) }; one.write("0\r\n\r\n".toByteArray())
        val t0 = System.nanoTime()
        val out = ByteArrayOutputStream()
        MitmProxy.readChunked(ByteArray(0), ByteArrayInputStream(one.toByteArray()), out)
        val ms = (System.nanoTime() - t0) / 1_000_000
        T.check("$chunks adet 1 baytlık parça 4 sn içinde çözülür (önceden ikinci dereceden; dakikalar sürerdi)", out.size() == chunks && ms < 4000, "${ms} ms, ${out.size()} bayt")

        fun fails(body: String, deadline: Long = Long.MAX_VALUE): Boolean = try { MitmProxy.readChunked(ByteArray(0), ByteArrayInputStream(body.toByteArray(Charsets.ISO_8859_1)), ByteArrayOutputStream(), deadline); false } catch (_: IOException) { true }
        T.check("boyut MAX_BODY'yi aşan parça reddedilir", fails("500000\r\nx"))
        T.check("negatif / onaltılık olmayan / 9+ haneli boyut reddedilir", fails("-5\r\nabc\r\n0\r\n\r\n") && fails("zz\r\nabc") && fails("123456789\r\nabc"))
        T.check("kesik gövde (parça ortasında EOF) reddedilir", fails("10\r\nabc"))
        T.check("veri sonrası CRLF yoksa reddedilir", fails("3\r\nabcXX0\r\n\r\n"))
        T.check("çok uzun boyut satırı reddedilir", fails("1;" + "a".repeat(500) + "\r\n"))
        run {
            // satır sonu hiç gelmeyen sınırsız boyut satırı: bellek/işlemci şişirmesi. Okuma küçük bir sınırda kesilmeli (önceki sürüm 50 MB'ı da toplardı).
            val s = Endless(50_000_000L)
            val rejected = try { MitmProxy.readChunked(ByteArray(0), s, ByteArrayOutputStream()); false } catch (_: IOException) { true }
            T.check("satır sonsuz uzayınca (50 MB 'a', satır sonu yok) reddedilir ve en çok ~64 KB okunur", rejected && s.used < 65_536, "okunan=${s.used}")
            val s2 = Endless(50_000_000L)
            val rejected2 = try { MitmProxy.readChunked("5;".toByteArray(), s2, ByteArrayOutputStream()); false } catch (_: IOException) { true }
            T.check("aynısı ön okunmuş başlangıçla (uzantı alanı) da sınırlı", rejected2 && s2.used < 65_536, "okunan=${s2.used}")
        }
        T.check("sabit sınırlar makul aralıkta (alan başı ≤ 200, gövde süresi 1-300 sn)", MitmProxy.MAX_PER_DOMAIN in 1..200 && MitmProxy.BODY_DEADLINE_MS in 1_000L..300_000L)
        T.check("0 parçası olmadan biten akış reddedilir", fails("3\r\nabc\r\n"))
        T.check("süresi geçmiş son tarih (damla damla gövde) reddedilir", fails("3\r\nabc\r\n0\r\n\r\n", deadline = System.nanoTime() / 1_000_000 - 1))

        fun fixed(len: Long, data: ByteArray, pre: ByteArray = ByteArray(0)): Boolean = try { MitmProxy.readFixed(pre, ByteArrayInputStream(data), ByteArrayOutputStream(), len); true } catch (_: IOException) { false }
        T.check("sabit uzunluk: tam gövde kabul, kesik gövde (EOF) reddedilir (önceden kesik sayfa 'tam' gösteriliyordu)", fixed(10, ByteArray(10)) && fixed(10, ByteArray(6), ByteArray(4)) && !fixed(10, ByteArray(9)) && !fixed(10, ByteArray(3), ByteArray(2)))
    }

    // ------------------------------------------------------------------------------------------------------------ enjeksiyon
    T.group("Sızma 2 / vekil: <style> enjeksiyonu betik, yorum ve ham metin içindeki '</head>' tarafından yanıltılmaz")
    run {
        val css = ".ad{display:none!important}"
        fun inj(html: String, nonce: String? = null): String = String(MitmProxy.inject(html.toByteArray(Charsets.ISO_8859_1), css, nonce), Charsets.ISO_8859_1)
        val tagLen = ("<style>" + css + "</style>").length
        fun styleAt(r: String) = r.indexOf(css) - "<style>".length
        val real = "<html><head><script>document.write(\"</head>\")</script></head><body>x</body></html>"
        val r1 = inj(real)
        T.check("betikteki dizge '</head>' atlanır, gerçek </head> öncesine eklenir", styleAt(r1) > r1.indexOf("</script>") && r1.indexOf("</head><body>") == styleAt(r1) + ("<style>" + css + "</style>").length, r1)
        val r2 = inj("<html><head><!-- </head> --><title>a</head>b</title></head><body></body></html>")
        T.check("yorum ve <title> içindeki '</head>' atlanır", styleAt(r2) > r2.indexOf("</title>") && r2.indexOf("<style") < r2.lastIndexOf("</head>"), r2)
        val r3 = inj("<head><textarea></head></textarea><style>a{}</style></head><body></body>")
        T.check("<textarea> ve <style> içindeki '</head>' atlanır", styleAt(r3) > r3.indexOf("</style>") && r3.indexOf("</head>", styleAt(r3)) == styleAt(r3) + tagLen, r3)
        val r4 = inj("<html><HEAD></HEAD ><BODY>x</BODY></html>")
        T.check("büyük harf '</HEAD >' (boşluklu) bulunur", styleAt(r4) + tagLen == r4.indexOf("</HEAD >"), r4)
        val r5 = inj("<head></header><meta></head>")
        T.check("'</header>' '</head>' sayılmaz", styleAt(r5) + tagLen == r5.lastIndexOf("</head>"), r5)
        val r6 = inj("<html><body class=\"a>b\" id=x>içerik</body></html>")
        T.check("'</head>' yoksa <body ...> sonrasına eklenir; tırnaklı özniteliğin içindeki '>' etiketi bitirmez", r6.contains("id=x><style>$css</style>içerik"), r6)
        val onlyScript = "<script>var s='</head>';</script><p>x</p>".toByteArray()
        T.check("yalnızca betik içinde '</head>' olan, gövdesiz belge değiştirilmez (aynı nesne)", MitmProxy.inject(onlyScript, css, null) === onlyScript)
        val unterminated = "<head><title>başlık </head> <body>".toByteArray()
        T.check("kapanmamış <title> içindeki '</head>' / <body> için güvenli taraf: değiştirilmez", MitmProxy.inject(unterminated, css, null) === unterminated)
        T.check("nonce özniteliği eklenir", inj("<head></head>", "AbC+/=_-1").contains("<style nonce=\"AbC+/=_-1\">"))
        val utf = "<head></head><body>ü ğ ş 日本</body>".toByteArray(Charsets.UTF_8)
        val ur = MitmProxy.inject(utf, css, null)
        T.check("UTF-8 baytları enjeksiyondan sonra aynen kalır", String(ur, Charsets.UTF_8).endsWith("<body>ü ğ ş 日本</body>"))
        val bigPage = StringBuilder("<html><head>"); repeat(200_000) { bigPage.append("<a<b<c<script x>") ; if (it % 7 == 0) bigPage.append("</script>") }; bigPage.append("</head><body></body></html>")
        val t0 = System.nanoTime(); MitmProxy.inject(bigPage.toString().toByteArray(Charsets.ISO_8859_1), css, null)
        val ms = (System.nanoTime() - t0) / 1_000_000
        T.check("çok sayıda '<' içeren büyük sayfada tarama doğrusal ($ms ms)", ms < 3000)

        // CSP nonce: doğru yönergeden
        fun nz(vararg p: String) = MitmProxy.styleNonce(p.toList())
        T.check("style-src nonce'u script-src nonce'una tercih edilir", nz("script-src 'nonce-AAA'; style-src 'self' 'nonce-BBB'") == "BBB")
        T.check("style-src-elem öncelikli", nz("style-src 'nonce-B'; style-src-elem 'nonce-E'") == "E")
        T.check("style-src yoksa default-src nonce'u", nz("default-src 'self' 'nonce-D'; script-src 'nonce-A'") == "D")
        T.check("yalnızca script-src nonce'u varsa o kullanılır (zararsız)", nz("script-src 'nonce-A'") == "A")
        T.check("nonce yoksa null; çoklu CSP başlığında doğru yönerge", nz("default-src 'self'") == null && nz("script-src 'nonce-A'", "style-src 'nonce-S'") == "S")
        T.check("yönerge adı büyük harfle de eşleşir", nz("STYLE-SRC 'nonce-Q'") == "Q")
    }

    // ------------------------------------------------------------------------------------------------------------ kozmetik
    T.group("Sızma 2 / kozmetik kurallar: dengesiz seçici komşu kuralları bozamaz; kural alanı eşlemesi")
    run {
        T.check("dengeli: köşeli, yuvarlak, iç içe, tırnaklı", Cosmetic.balanced("a[href=\"x]\"]") && Cosmetic.balanced("div:not(.a[b='c)'])") && Cosmetic.balanced(".a, .b > c") && Cosmetic.balanced("a[b=\"c\"][d]"))
        T.check("dengesiz: açık tırnak, açık [ ve (, fazla kapanış, çapraz kapanış", !Cosmetic.balanced("a[href=\"x") && !Cosmetic.balanced("a[b") && !Cosmetic.balanced("b:not(c") && !Cosmetic.balanced("a]") && !Cosmetic.balanced("a)") && !Cosmetic.balanced("a[b)") && !Cosmetic.balanced("a(b]") && !Cosmetic.balanced("a'b"))
        val c = Cosmetic.parse("x.example##a[href=\"bozuk\nx.example##.iyi1\nx.example##b:not(c\nx.example##.iyi2\nx.example##d[e='f\nx.example##.iyi3\nx.example##g]\nx.example##.iyi4")
        val css = c.css("x.example")
        T.check("bozuk seçiciler atılır, geri kalanı sağlam kalır", css == ".iyi1{display:none!important}.iyi2{display:none!important}.iyi3{display:none!important}.iyi4{display:none!important}", css)

        var bad = 0; val first = StringBuilder()
        val alpha = "abc01_#.-[]=\"'*:+~ ,()^\$|>"
        for (iter in 0 until DEEP_X * 3000) {
            val sb = StringBuilder("d.example##")
            val sels = 1 + rnd.nextInt(5)
            val lines = ArrayList<String>()
            repeat(sels) { val sel = String(CharArray(1 + rnd.nextInt(14)) { alpha[rnd.nextInt(alpha.length)] }); lines += "d.example##$sel" }
            val out = Cosmetic.parse(lines.joinToString("\n")).css("d.example")
            if (!cssSane(out)) { bad++; if (first.length < 300) first.append("'${lines.joinToString(" | ")}' → '$out'; ") }
        }
        T.check("${DEEP_X * 3000} rastgele seçici kümesi: üretilen CSS her zaman iyi biçimli (her kural kendi bloğunda)", bad == 0, "$bad $first")

        val r = Cosmetic.parse("youtube.com##.a\nfoo.youtube.com##.b\nexample.co.uk##.c")
        T.check("kural alanı: en yakın eşleşen alan döner, eşleşme yoksa null",
            r.ruleDomain("m.youtube.com") == "youtube.com" && r.ruleDomain("youtube.com") == "youtube.com" && r.ruleDomain("x.foo.youtube.com") == "foo.youtube.com" &&
                r.ruleDomain("evil.com") == null && r.ruleDomain("com") == null && r.ruleDomain("") == null && r.ruleDomain("a.b.example.co.uk") == "example.co.uk" && r.ruleDomain("YOUTUBE.com.") == "youtube.com")
    }

    // ------------------------------------------------------------------------------------------------------------ uçtan uca
    T.group("Sızma 2 / vekil (uçtan uca): akış kesilmez, kesik gövde gizlenmez, yuvalar tutulamaz")
    run {
        val ca = MitmCa.generate(); val originCa = MitmCa.generate()
        val rules = Cosmetic.parse("a.example##.ad\nb.example##.ad\nhold.example##.x\nother.example##.ad")
        fun proxy() = MitmProxy(ca, rules, { a, port -> Socket(a, port) }, { trustOf(originCa).socketFactory })
        val page = "<html><head></head><body><div class=\"ad\">x</div></body></html>"

        // 1) veri içinde "0\r\n\r\n" ile biten okuma, sonra devamı (HTML olmayan: doğrudan aktarılır)
        ScriptOrigin(originCa, "a.example") { o ->
            o.w("HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nTransfer-Encoding: chunked\r\n\r\n")
            Thread.sleep(150)
            o.w("8\r\nabc\r\n0\r\n\r\n")          // veri: "abc\r\n0\r\n"; tampon "0\r\n\r\n" ile biter
            Thread.sleep(400)
            o.w("4\r\ntail\r\n0\r\n\r\n")
        }.use { origin ->
            proxy().use { p ->
                p.start()
                val (ok, got) = getVia(p, "a.example", ca, origin.ss.localPort)
                val s = String(got, Charsets.ISO_8859_1)
                T.check("chunked cevap, veri içindeki '0\\r\\n\\r\\n' yüzünden erken kesilmez (devamı ve bitiş parçası gelir)", ok && s.contains("tail") && s.endsWith("0\r\n\r\n"), s.takeLast(80).replace("\r\n", "⏎"))
            }
        }
        // 2) Transfer-Encoding + Content-Length birlikte: akış kısa Content-Length'te kesilmez
        ScriptOrigin(originCa, "b.example") { o ->
            o.w("HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 5\r\nTransfer-Encoding: chunked\r\n\r\n")
            Thread.sleep(150)
            o.w("14\r\n01234567890123456789\r\n")
            Thread.sleep(300)
            o.w("5\r\nSONUC\r\n0\r\n\r\n")
        }.use { origin ->
            proxy().use { p ->
                p.start()
                val (ok, got) = getVia(p, "b.example", ca, origin.ss.localPort)
                val s = String(got, Charsets.ISO_8859_1)
                T.check("TE + CL birlikte gelince (TE esas) akış kısa Content-Length'te kesilmez", ok && s.contains("SONUC") && s.endsWith("0\r\n\r\n"), s.takeLast(80).replace("\r\n", "⏎"))
            }
        }
        // 3) kesik HTML gövdesi: "tam" gibi gösterilmez (önceden yeniden yazılan Content-Length ile sessizce kısa sayfa verilirdi)
        ScriptOrigin(originCa, "a.example") { o ->
            o.w("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 1000\r\n\r\n<html><head></head><body>kesik")
        }.use { origin ->
            proxy().use { p ->
                p.start()
                val (ok, got) = getVia(p, "a.example", ca, origin.ss.localPort)
                T.check("kesik HTML gövdesi (EOF < Content-Length) istemciye 'tam sayfa' olarak verilmez", ok && got.isEmpty(), String(got, Charsets.ISO_8859_1).take(120))
                T.check("kesik gövde hata olarak sayılır, enjekte edilmez", p.failed() >= 1L && p.injected() == 0L, p.summary())
            }
        }
        // 4) kontrol: sağlam HTML hâlâ enjekte edilir
        ScriptOrigin(originCa, "a.example") { o ->
            o.w("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${page.length}\r\n\r\n$page")
        }.use { origin ->
            proxy().use { p ->
                p.start()
                val (ok, got) = getVia(p, "a.example", ca, origin.ss.localPort)
                val s = String(got, Charsets.ISO_8859_1)
                T.check("kontrol: sağlam HTML cevabına stil enjekte edilir", ok && s.contains("<style>.ad{display:none!important}</style>") && p.injected() == 1L, s.take(200))
            }
        }

        // 4b) damla damla gelen HTML gövdesi (slowloris): toplam süre aşılınca vekil bırakır, yuva boşalır
        ScriptOrigin(originCa, "a.example") { o ->
            o.w("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 5000\r\n\r\n<html>")
            repeat(60) { Thread.sleep(100); o.w("x") }
        }.use { origin ->
            MitmProxy(ca, rules, { a, port -> Socket(a, port) }, { trustOf(originCa).socketFactory }, bodyDeadlineMs = 600L).use { p ->
                p.start()
                val th = Thread { try { getVia(p, "a.example", ca, origin.ss.localPort, readMs = 8000) } catch (_: Throwable) {} }.also { it.isDaemon = true; it.start() }
                val t0 = System.nanoTime()
                while (p.failed() < 1L && (System.nanoTime() - t0) / 1_000_000 < 3000) Thread.sleep(25)
                val took = (System.nanoTime() - t0) / 1_000_000
                T.check("damla damla gövde: toplam süre (0,6 sn) aşılınca vekil bırakır (≤ 2,5 sn), 6 sn'lik damlatmayı beklemez", p.failed() >= 1L && took < 2500, "bırakma ${took} ms, ${p.summary()}")
                th.join(9000)
            }
        }

        // 5) yuva tutma: bir alan, alan başı sınırı doldurur; başka alan etkilenmez
        val hold = ScriptOrigin(originCa, "hold.example") { _ -> Thread.sleep(9000) }
        val good = ScriptOrigin(originCa, "other.example") { o -> o.w("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${page.length}\r\n\r\n$page") }
        proxy().use { p ->
            p.start()
            val n = MitmProxy.MAX_PER_DOMAIN + 12
            val ok = AtomicInteger(); val rej = AtomicInteger()
            val ths = (0 until n).map {
                Thread({
                    try {
                        val raw = Socket(); raw.bind(InetSocketAddress(LB, 0))
                        p.expect(raw.localPort, "hold.example", LB, hold.ss.localPort)
                        raw.connect(InetSocketAddress(LB, p.port), 3000)
                        val s = trustOf(ca).socketFactory.createSocket(raw, "hold.example", p.port, true) as SSLSocket
                        s.soTimeout = 4000
                        val shook = try { s.startHandshake(); true } catch (_: Exception) { false }
                        if (shook) {
                            ok.incrementAndGet()
                            s.outputStream.write("GET / HTTP/1.1\r\nHost: hold.example\r\n\r\n".toByteArray()); s.outputStream.flush()
                            try { s.inputStream.read() } catch (_: Exception) {}
                        } else rej.incrementAndGet()
                        try { s.close() } catch (_: Exception) {}
                    } catch (_: Exception) { rej.incrementAndGet() }
                }).also { it.isDaemon = true; it.start() }
            }
            val t0 = System.nanoTime()
            while (p.handled() + p.capped() < n && (System.nanoTime() - t0) / 1_000_000 < 15_000) Thread.sleep(50)
            val (gok, got) = getVia(p, "other.example", ca, good.ss.localPort)
            val gs = String(got, Charsets.ISO_8859_1)
            T.check("alan başı sınır: ${MitmProxy.MAX_PER_DOMAIN + 12} eşzamanlı askıda bağlantıdan fazlası reddedilir", p.capped() >= 10L && p.handled() <= MitmProxy.MAX_PER_DOMAIN.toLong() + 1, "reddedilen=${p.capped()} işlenen=${p.handled()} istemci kabul=${ok.get()} ret=${rej.get()}")
            T.check("bir alan yuvaları tutarken başka alan hâlâ hizmet alır (stil enjekte edilir)", gok && gs.contains("display:none!important"), gs.take(160))
            ths.forEach { it.join(8000) }
            // askıdaki bağlantılar bitince sayaç boşalır: alan yeniden kullanılabilir
            hold.close()
            val t1 = System.nanoTime()
            var reopened = false
            val hold2 = ScriptOrigin(originCa, "hold.example") { o -> o.w("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${page.length}\r\n\r\n$page") }
            while (!reopened && (System.nanoTime() - t1) / 1_000_000 < 12_000) {
                val (hk, hg) = getVia(p, "hold.example", ca, hold2.ss.localPort)
                if (hk && String(hg, Charsets.ISO_8859_1).contains("<style")) reopened = true else Thread.sleep(300)
            }
            hold2.close()
            T.check("askıdaki bağlantılar kapanınca alan yeniden hizmet alır (sayaç sızıntısı yok)", reopened)
        }
        good.close()
    }
}
