package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyStore
import java.util.Random
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLServerSocket
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManagerFactory

private val LOOPB: InetAddress = InetAddress.getLoopbackAddress()

private fun trust(ca: MitmCa): SSLContext {
    val ks = KeyStore.getInstance(KeyStore.getDefaultType()); ks.load(null, null); ks.setCertificateEntry("ca", ca.cert)
    val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()); tmf.init(ks)
    return SSLContext.getInstance("TLS").also { it.init(null, tmf.trustManagers, null) }
}

/** [script] her bağlantıda isteği okuyup ham baytları yazar (bozuk cevap üretmek için). */
private class RawOrigin(ca: MitmCa, host: String, val script: (ByteArray, java.io.OutputStream, Int) -> Unit) : AutoCloseable {
    val ss = ca.serverContext(host)!!.serverSocketFactory.createServerSocket(0, 50, LOOPB) as SSLServerSocket
    val n = java.util.concurrent.atomic.AtomicInteger()
    init {
        Thread({
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (_: Exception) { break }
                val k = n.incrementAndGet()
                Thread({
                    try { s.soTimeout = 4000; val b = ByteArray(8192); val r = s.getInputStream().read(b); if (r > 0) { script(b.copyOf(r), s.getOutputStream(), k); s.getOutputStream().flush() } }
                    catch (_: Exception) {} finally { try { s.close() } catch (_: Exception) {} }
                }).also { it.isDaemon = true }.start()
            }
        }).also { it.isDaemon = true }.start()
    }
    override fun close() { ss.close() }
}

private fun fetch(p: MitmProxy, host: String, ca: MitmCa, req: ByteArray, readMs: Int = 7000): Pair<Boolean, ByteArray> {
    val raw = Socket(); raw.bind(InetSocketAddress(LOOPB, 0))
    p.expect(raw.localPort, host, LOOPB, 443)
    raw.connect(InetSocketAddress(LOOPB, p.port), 3000)
    val s = trust(ca).socketFactory.createSocket(raw, host, p.port, true) as SSLSocket
    s.soTimeout = readMs
    try { s.startHandshake() } catch (_: Exception) { try { s.close() } catch (_: Exception) {}; return false to ByteArray(0) }
    s.outputStream.write(req); s.outputStream.flush()
    val o = ByteArrayOutputStream(); val b = ByteArray(8192)
    try { while (true) { val n = s.inputStream.read(b); if (n < 0) break; o.write(b, 0, n); if (o.size() > 6_000_000) break } } catch (_: Exception) {}
    try { s.close() } catch (_: Exception) {}
    return true to o.toByteArray()
}

private val PAGE = "<html><head><title>t</title></head><body><div class=\"ad-banner\">r</div><p>ü</p></body></html>"
private fun okResp(body: String = PAGE, extra: String = "") = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${body.toByteArray().size}\r\n$extra\r\n").toByteArray(Charsets.ISO_8859_1) + body.toByteArray()

fun runDeepMitmTests() {
    val ca = MitmCa.generate(); val originCa = MitmCa.generate(); val host = "site.example.com"
    val rules = Cosmetic.parse("example.com##.ad-banner")
    fun proxy(o: RawOrigin) = MitmProxy(ca, rules, { _, _ -> Socket(LOOPB, o.ss.localPort) }, { trust(originCa).socketFactory })

    T.group("Derin tarayıcı kipi: bozuk sunucu cevapları (tohumlu bayt bozma, kesme, çoğaltma)")
    val valid = listOf(okResp(), ("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nTransfer-Encoding: chunked\r\n\r\n" + "%x\r\n%s\r\n0\r\n\r\n".format(PAGE.length, PAGE)).toByteArray(Charsets.ISO_8859_1))
    var totalRuns = 0; var hung = 0; val violations = ArrayList<String>()
    for (seed in 1L..(10L * DEEP_X)) {
        val rnd = Random(seed)
        val mutated = valid.map { v ->
            val b = v.copyOf()
            when (rnd.nextInt(7)) {
                0 -> b.copyOf(rnd.nextInt(b.size))                                   // kesik
                1 -> { for (i in 0 until 1 + rnd.nextInt(6)) b[rnd.nextInt(minOf(b.size, 160))] = rnd.nextInt(256).toByte(); b }   // başlıkta bayt bozma
                2 -> v + v                                                           // çift cevap
                3 -> "HTTP/1.1 200 OK\r\nContent-Length: -5\r\nContent-Type: text/html\r\n\r\n$PAGE".toByteArray()
                4 -> "HTTP/1.1 200 OK\r\nContent-Length: 10\r\nContent-Length: 99999\r\nContent-Type: text/html\r\n\r\n$PAGE".toByteArray()
                5 -> "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nTransfer-Encoding: chunked\r\n\r\nZZZZ\r\n$PAGE\r\n".toByteArray()
                else -> ("HTTP/1.1 200 OK\nContent-Type: text/html\nContent-Length: ${PAGE.length}\n\n$PAGE").toByteArray()      // CRLF yerine LF
            }
        }
        for ((vi, resp) in mutated.withIndex()) {
            RawOrigin(originCa, host) { _, out, _ -> out.write(resp) }.use { o ->
                proxy(o).use { p ->
                    p.start()
                    val t0 = System.nanoTime()
                    val (ok, got) = fetch(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n".toByteArray(), 8000)
                    val ms = (System.nanoTime() - t0) / 1_000_000
                    totalRuns++
                    if (ms > 12_000) hung++
                    val text = String(got, Charsets.ISO_8859_1)
                    // değişmez: enjekte edilmişse Content-Length gövdeyle birebir uyar ve CSS tek kez vardır
                    if (text.contains("display:none")) {
                        val head = text.substringBefore("\r\n\r\n"); val body = text.substringAfter("\r\n\r\n", "")
                        val cl = Regex("(?i)content-length: (\\d+)").find(head)?.groupValues?.get(1)?.toInt()
                        if (cl == null || cl != body.toByteArray(Charsets.ISO_8859_1).size) violations += "s$seed/v$vi: Content-Length uyuşmuyor ($cl vs ${body.length})"
                        if (Regex("display:none").findAll(body).count() != 1) violations += "s$seed/v$vi: CSS birden çok kez"
                    }
                    if (!ok) violations += "s$seed/v$vi: istemci el sıkışması başarısız (olmamalı)"
                }
            }
        }
    }
    T.check("$totalRuns bozuk cevap: hiçbiri asılı kalmadı (>12 sn)", hung == 0, "asılı=$hung")
    T.check("bozuk cevaplarda enjekte edilen gövde tutarlı (Content-Length, tek CSS)", violations.isEmpty(), violations.take(4).toString())

    T.group("Derin tarayıcı kipi: bozuk/saldırgan istekler (istek sızdırma, çift Content-Length, devasa başlık)")
    val seenReq = java.util.concurrent.CopyOnWriteArrayList<String>()
    RawOrigin(originCa, host) { rq, out, _ -> seenReq.add(String(rq, Charsets.ISO_8859_1)); out.write(okResp()) }.use { o ->
        proxy(o).use { p ->
            p.start()
            val smug = "POST / HTTP/1.1\r\nHost: $host\r\nContent-Length: 4\r\n\r\nabcdGET /gizli HTTP/1.1\r\nHost: $host\r\n\r\n"
            fetch(p, host, ca, smug.toByteArray())
            T.check("fazladan (pipelined) istek sunucuya iletilmez", seenReq.none { it.contains("/gizli") }, seenReq.toString())
            seenReq.clear()
            val dup = "POST / HTTP/1.1\r\nHost: $host\r\nContent-Length: 3\r\nContent-Length: 40\r\n\r\nabcGET /gizli2 HTTP/1.1\r\n\r\n"
            val (_, r1) = fetch(p, host, ca, dup.toByteArray(), 4000)
            T.check("çelişkili çift Content-Length isteği sunucuya iletilmez (istek sızdırma)", seenReq.none { it.contains("Content-Length: 40") || it.contains("/gizli2") } && !String(r1).contains("HTTP/1.1 200"), seenReq.toString())
            seenReq.clear()
            val big = "GET / HTTP/1.1\r\nHost: $host\r\nX-A: ${"a".repeat(70_000)}\r\n\r\n"
            val t0 = System.nanoTime()
            fetch(p, host, ca, big.toByteArray(), 4000)
            T.check("devasa başlık sunucuya gitmez ve vekil asılmaz", seenReq.isEmpty() && (System.nanoTime() - t0) / 1_000_000 < 9000, seenReq.size.toString())
            seenReq.clear()
            val te = "POST / HTTP/1.1\r\nHost: $host\r\nTransfer-Encoding: chunked\r\nContent-Length: 5\r\n\r\n0\r\n\r\n"
            fetch(p, host, ca, te.toByteArray(), 3000)
            T.check("TE+CL birlikte: yalnızca sade tünel (başlık değiştirilmeden), CL düşürülmez/yeniden yazılmaz", seenReq.size <= 1)
            val (okAfter, ra) = fetch(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n".toByteArray())
            T.check("saldırılardan sonra vekil normal isteğe hâlâ cevap veriyor", okAfter && String(ra, Charsets.ISO_8859_1).contains("display:none"))
        }
    }

    T.group("Derin tarayıcı kipi: el sıkışma hatasının sınıflandırılması")
    T.check("TLS uyarıları (bilinmeyen CA, sertifika hatası) reddi sayılır", listOf("Received fatal alert: certificate_unknown", "SSL handshake terminated: error:10000416:SSL routines:OPENSSL_internal:SSLV3_ALERT_CERTIFICATE_UNKNOWN", "Received fatal alert: unknown_ca", "bad_certificate", "TLSV1_ALERT_UNKNOWN_CA", "Broken pipe").all { MitmProxy.rejectedCert(javax.net.ssl.SSLHandshakeException(it)) })
    T.check("EOF, sıfırlama, zaman aşımı ve boş mesaj reddedilme sayılmaz", listOf("Unexpected end of file", "Connection reset", "Read timed out", "", "closed").all { !MitmProxy.rejectedCert(javax.net.ssl.SSLException(it)) } && !MitmProxy.rejectedCert(java.net.SocketTimeoutException("certificate timeout")))
    T.check("iç içe neden zinciri taranır", MitmProxy.rejectedCert(javax.net.ssl.SSLException("x", javax.net.ssl.SSLHandshakeException("Received fatal alert: unknown_ca"))))

    T.group("Derin tarayıcı kipi: yavaş/asılı istemciler ve eşzamanlılık")
    RawOrigin(originCa, host) { _, out, _ -> out.write(okResp()) }.use { o ->
        proxy(o).use { p ->
            p.start()
            // 20 asılı istemci: el sıkışmayı hiç yapmaz
            val stalled = (1..20).map {
                val raw = Socket(); raw.bind(InetSocketAddress(LOOPB, 0)); p.expect(raw.localPort, host, LOOPB, 443); raw.connect(InetSocketAddress(LOOPB, p.port)); raw
            }
            val t0 = System.nanoTime()
            val (ok, r) = fetch(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n".toByteArray())
            T.check("20 asılı bağlantı varken normal istek yine hızlı çalışır (<4 sn)", ok && String(r, Charsets.ISO_8859_1).contains("display:none") && (System.nanoTime() - t0) / 1_000_000 < 4000)
            stalled.forEach { try { it.close() } catch (_: Exception) {} }
            Thread.sleep(300)
            T.check("asılı bağlantıların sessizce kapanması (sertifika reddi değil) adı vekilden muaf TUTMAZ", p.wantsHost(host), p.summary())
            val results = java.util.concurrent.ConcurrentLinkedQueue<Boolean>()
            // tek alan için alan başı sınırın (72) altında kal: sınır kendi testinde (sizma5)
            val th = (1..minOf(40 * DEEP_X / 2, MitmProxy.MAX_PER_DOMAIN - 4)).map { Thread { results.add(fetch(p, host, ca, "GET /$it HTTP/1.1\r\nHost: $host\r\n\r\n".toByteArray()).let { x -> x.first && String(x.second, Charsets.ISO_8859_1).contains("display:none") }) }.also { it.start() } }
            th.forEach { it.join(30_000) }
            T.check("${th.size} eşzamanlı istemci: ≥%95'i enjekte edilmiş cevap aldı (yuva sınırı ${MitmProxy.MAX_CONN})", results.count { it } * 100 >= th.size * 95, "${results.count { it }}/${th.size} ${p.summary()}")
            T.check("hepsi bittikten sonra yuvalar serbest (yeni istek çalışır)", fetch(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n".toByteArray()).first)
        }
    }

    T.group("Derin kozmetik ayrıştırıcı ve CA: rastgele girdi")
    val alphabet = "abcdefghijklmnopqrstuvwxyz0123456789.-#,~*?!@\\/<>{}[]()=\"':;+| \t\r\n$^&"
    var bad: String? = null
    for (seed in 1L..(30L * DEEP_X)) {
        val rnd = Random(seed)
        val text = buildString { repeat(200) { repeat(rnd.nextInt(5)) { append(alphabet[rnd.nextInt(alphabet.length)]) }; if (rnd.nextInt(3) == 0) append("##"); if (rnd.nextInt(6) == 0) append("example.com##"); if (rnd.nextInt(4) == 0) append('\n') } }
        try {
            val c = Cosmetic.parse(text)
            for (d in c.domains()) {
                val css = c.css(d)
                if (css.isNotEmpty() && !Regex("^([A-Za-z0-9_#.\\-\\[\\]=\"'*:+~ ,()^$|>]+\\{display:none!important\\})+$").matches(css)) bad = "css biçimi: ${css.take(80)}"
                if (css.contains("<") || css.contains("@") || css.contains(";") || css.contains("\\") || css.contains("/*")) bad = "tehlikeli: ${css.take(80)}"
                if (css.count { it == '{' } != css.count { it == '}' }) bad = "dengesiz parantez"
            }
        } catch (e: Throwable) { bad = "çöktü ${e.javaClass.simpleName}" }
    }
    T.check("${30 * DEEP_X} rastgele kural dosyası: çıktı hep güvenli biçimde", bad == null, bad ?: "")
    val rndH = Random(7); var hostErr: String? = null
    repeat(300 * DEEP_X) {
        val h = String(CharArray(rndH.nextInt(40)) { alphabet[rndH.nextInt(alphabet.length)] })
        try { val ch = ca.leaf(h); if (ch != null && !MitmCa.validHost(h)) hostErr = "geçersiz ad için sertifika üretildi: '$h'"; if (ch != null && ch[0].subjectAlternativeNames?.any { it[1] == h } != true) hostErr = "SAN uyuşmuyor '$h'" } catch (e: Throwable) { hostErr = "çöktü '$h' ${e.javaClass.simpleName}" }
    }
    T.check("${300 * DEEP_X} rastgele ad: yalnızca geçerli adlara sertifika, SAN tam eşleşir", hostErr == null, hostErr ?: "")
    var certErr: String? = null
    val keyB = ca.keyBytes(); val certB = ca.certDer(); val interB = ca.interDer()
    repeat(60 * DEEP_X) { i ->
        val r = Random(i.toLong())
        val kb = keyB.copyOf(); val cb = certB.copyOf(); val ib = interB.copyOf()
        when (r.nextInt(3)) { 0 -> cb[r.nextInt(cb.size)] = r.nextInt(256).toByte(); 1 -> ib[r.nextInt(ib.size)] = r.nextInt(256).toByte(); else -> kb[r.nextInt(kb.size)] = r.nextInt(256).toByte() }
        try { val m = MitmCa.load(kb, cb, ib)
            // Kabul edilen kayıt (örn. anahtarın kullanılmayan alanındaki bayt) İŞLEVSEL olarak özgün CA olmalı: yaprak, özgün kökle doğrulanır.
            if (m != null && !(kb.contentEquals(keyB) && cb.contentEquals(certB) && ib.contentEquals(interB))) {
                val ch = m.leaf("www.youtube.com")
                if (ch == null || runCatching { ch[0].verify(ch[1].publicKey); ch[1].verify(ca.cert.publicKey) }.isFailure) certErr = "bozuk kayıt işlevsel olmayan CA kabul etti"
            }
        } catch (e: Throwable) { certErr = "çöktü ${e.javaClass.simpleName}" }
    }
    T.check("${60 * DEEP_X} bozulmuş CA kaydı (kök, ara, anahtar): çökmez, kabul edilen kayıt işlevsel olarak özgün CA'dır", certErr == null, certErr ?: "")
}

fun runDeepSettingsTests() {
    T.group("Derin ayarlar: rastgele ayar gidiş-dönüşü ve içe aktarma saldırıları")
    val base = AppSettings()
    var err: String? = null
    for (seed in 1L..(40L * DEEP_X)) {
        val r = Random(seed)
        val s = base.copy(
            dpiOn = r.nextBoolean(), adsPlus = r.nextBoolean(), blockQuic = r.nextBoolean(), udpDecoy = r.nextBoolean(), quicSplit = r.nextBoolean(),
            dpiListedOnly = r.nextBoolean(), mitmOn = r.nextBoolean(), autoShield = r.nextBoolean(), echAllow = r.nextBoolean(),
        )
        try {
            val back = SettingsCodec.decode(SettingsCodec.encode(s))
            if (back != s) err = "gidiş-dönüş farklı (tohum $seed)"
            val code = SettingsCodec.export(s)
            val imp = SettingsCodec.import(code, base)
            if (imp == null) err = "kendi dışa aktarımı okunamadı"
            else {
                if (imp.mitmOn) err = "mitmOn içe aktarımla açıldı (tohum $seed)"
                if (imp.dpiOn != base.dpiOn || imp.adsPlus != base.adsPlus) err = "servis alanı içe aktarımla değişti"
                if (imp.dpiListedOnly != s.dpiListedOnly) err = "dpiListedOnly taşınmadı"
            }
            // saldırı: mitmOn=true ve dpiOn=true içeren elle hazırlanmış kod
            val evil = "DNSH1:" + Base64Mini.encode("mitmOn=true\ndpiOn=true\nadsPlus=true\ndpiListedOnly=true\nautoShield=false".toByteArray())
            val e = SettingsCodec.import(evil, base)
            if (e != null && (e.mitmOn || e.dpiOn || e.adsPlus)) err = "elle hazırlanmış kod yerel/servis alanlarını açtı"
        } catch (ex: Throwable) { err = "çöktü ${ex.javaClass.simpleName}: ${ex.message}" }
    }
    T.check("${40 * DEEP_X} rastgele ayarda gidiş-dönüş eşit, içe aktarma mitmOn/servis alanlarına dokunamaz", err == null, err ?: "")
    var fz: String? = null
    val r = Random(5)
    val valid = SettingsCodec.export(base.copy(dpiListedOnly = true))
    repeat(400 * DEEP_X) {
        val sb = StringBuilder(valid)
        when (r.nextInt(4)) { 0 -> sb.setCharAt(r.nextInt(sb.length), (r.nextInt(94) + 33).toChar()); 1 -> sb.setLength(r.nextInt(sb.length)); 2 -> sb.append("\n".repeat(r.nextInt(50)) + "=".repeat(r.nextInt(30))); else -> sb.insert(r.nextInt(sb.length), String(CharArray(r.nextInt(40)) { (r.nextInt(255) + 1).toChar() })) }
        try { SettingsCodec.import(sb.toString(), base) } catch (e: Throwable) { fz = "${e.javaClass.simpleName} @ ${e.stackTrace.firstOrNull()}" }
    }
    T.check("${400 * DEEP_X} bozulmuş içe aktarma kodu: çökme yok", fz == null, fz ?: "")
}
