package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.util.Random

/**
 * Sızma girişimi 2 — DPI katmanı: özellik tabanlı (property) testler. Rastgele ama GEÇERLİ yapıda binlerce ClientHello ve HTTP isteği
 * üretilir; her yöntem (TLS 0..13, HTTP 0..7) için "sunucuya giden bayt akışı anlamca özgünle aynı" doğrulanır:
 *  - TLS: parçalar birleşince geçerli TLS kayıt akışı; kayıtların el sıkışma yükleri birleşince özgün ClientHello yükü; SNI korunur.
 *  - HTTP: istek satırı, başlık çoklu kümesi ve gövde aynı (başlık sırası/harf büyüklüğü/boşluk farkı serbest).
 *  - Hiçbir yöntem girdi dizisini değiştirmez; hiçbir parça boş değil; sahte kopya gerçeğiyle aynı uzunlukta.
 * Ayrıca planlayıcı ([Dpi.Planner]) rastgele olay dizileri ve çok iş parçacığıyla zorlanır.
 */

private val labels = listOf("a", "cdn", "www", "static", "video", "x1", "api", "m", "edge", "img")
private val tlds = listOf("com", "net", "org", "co.uk", "io", "com.tr", "xyz")

private fun randHost(r: Random): String {
    val n = 1 + r.nextInt(4)
    return (1..n).joinToString(".") { labels[r.nextInt(labels.size)] + (if (r.nextInt(4) == 0) r.nextInt(100).toString() else "") } + "." + tlds[r.nextInt(tlds.size)]
}

private fun u16(v: Int) = byteArrayOf((v ushr 8).toByte(), v.toByte())

private fun ext(type: Int, body: ByteArray) = u16(type) + u16(body.size) + body

/** Rastgele, yapısal olarak geçerli bir TLS ClientHello (tek kayıt). [host] null ise SNI yok. */
internal fun randHello(r: Random, host: String?, forceBig: Boolean = false): ByteArray {
    val exts = ArrayList<ByteArray>()
    if (host != null) {
        val nm = host.toByteArray()
        exts.add(ext(0, u16(3 + nm.size) + byteArrayOf(0) + u16(nm.size) + nm))
    }
    exts.add(ext(10, u16(6) + u16(0x001d) + u16(0x0017) + u16(0x0018)))                  // supported_groups
    exts.add(ext(13, u16(8) + u16(0x0403) + u16(0x0804) + u16(0x0401) + u16(0x0503)))     // signature_algorithms
    exts.add(ext(16, u16(14) + byteArrayOf(2, 'h'.code.toByte(), '2'.code.toByte(), 8) + "http/1.1".toByteArray()))
    if (r.nextBoolean() || forceBig) { val ks = ByteArray(if (forceBig || r.nextInt(3) == 0) 1184 + 32 else 32).also { r.nextBytes(it) }; exts.add(ext(51, u16(ks.size + 4) + u16(0x6399) + u16(ks.size) + ks)) }
    if (r.nextInt(5) == 0) exts.add(ext(0xFE0D, ByteArray(10 + r.nextInt(200)).also { r.nextBytes(it) }))       // ECH
    if (r.nextInt(3) == 0) exts.add(ext(21, ByteArray(r.nextInt(if (forceBig) 4000 else 600))))                // padding
    if (r.nextInt(4) == 0) exts.add(ext(0x4469, ByteArray(r.nextInt(100)).also { r.nextBytes(it) }))          // bilinmeyen uzantı
    exts.shuffle(r)                                                                                            // SNI konumu rastgele
    val extBytes = exts.fold(ByteArray(0)) { a, b -> a + b }
    val sid = ByteArray(if (r.nextBoolean()) 32 else r.nextInt(33)).also { r.nextBytes(it) }
    val suites = ByteArray(2 * (1 + r.nextInt(30))).also { r.nextBytes(it) }
    val body = ByteArrayOutputStream()
    body.write(byteArrayOf(3, 3)); body.write(ByteArray(32).also { r.nextBytes(it) })
    body.write(sid.size); body.write(sid)
    body.write(u16(suites.size)); body.write(suites)
    body.write(byteArrayOf(1, 0))
    body.write(u16(extBytes.size)); body.write(extBytes)
    val b = body.toByteArray()
    val hs = byteArrayOf(1, (b.size ushr 16).toByte(), (b.size ushr 8).toByte(), b.size.toByte()) + b
    return byteArrayOf(0x16, 3, 1) + u16(hs.size) + hs
}

/** [stream] bir TLS kayıt akışı mı? Öyleyse (kayıt sayısı, birleşik el sıkışma yükü); değilse null. */
private fun records(stream: ByteArray): Pair<Int, ByteArray>? {
    var p = 0; var n = 0
    val hs = ByteArrayOutputStream()
    while (p < stream.size) {
        if (p + 5 > stream.size) return null
        if (stream[p].toInt() != 0x16 || stream[p + 1].toInt() != 3) return null
        val l = ((stream[p + 3].toInt() and 0xFF) shl 8) or (stream[p + 4].toInt() and 0xFF)
        if (l <= 0 || l > 16384 || p + 5 + l > stream.size) return null
        hs.write(stream, p + 5, l)
        p += 5 + l; n++
    }
    return n to hs.toByteArray()
}

private fun joined(parts: List<Dpi.Part>): ByteArray { val o = ByteArrayOutputStream(); for (p in parts) o.write(p.data); return o.toByteArray() }

// ------------------------------------------------------------------------------------------------ HTTP referans ayrıştırıcı

private class ParsedHttp(val line: String, val headers: List<Pair<String, String>>, val body: ByteArray)

private fun refParse(b: ByteArray): ParsedHttp? {
    var i = 0
    while (i < b.size && (b[i].toInt() == '\r'.code || b[i].toInt() == '\n'.code)) i++        // baştaki boş satırlar
    fun line(): String? {
        val st = i
        while (i < b.size && b[i].toInt() != '\n'.code) i++
        if (i >= b.size) return null
        val e = if (i > st && b[i - 1].toInt() == '\r'.code) i - 1 else i
        i++
        return String(b, st, e - st, Charsets.ISO_8859_1)
    }
    val first = line() ?: return null
    val hs = ArrayList<Pair<String, String>>()
    while (true) {
        val l = line() ?: return null
        if (l.isEmpty()) break
        val c = l.indexOf(':')
        if (c <= 0) return null
        hs.add(l.substring(0, c).trim().lowercase() to l.substring(c + 1).trim())
    }
    return ParsedHttp(first, hs, b.copyOfRange(i, b.size))
}

private fun randHttp(r: Random, host: String?): ByteArray {
    val methods = listOf("GET", "GET", "GET", "HEAD", "POST", "PUT", "DELETE", "OPTIONS")
    val m = methods[r.nextInt(methods.size)]
    val path = "/" + (1..r.nextInt(4)).joinToString("/") { labels[r.nextInt(labels.size)] } + (if (r.nextInt(3) == 0) "?q=${r.nextInt(1000)}&z=${r.nextInt(9)}" else "")
    val sb = StringBuilder("$m $path HTTP/1.1\r\n")
    val hs = ArrayList<String>()
    if (host != null) hs.add("Host: $host" + (if (r.nextInt(5) == 0) ":${1000 + r.nextInt(8000)}" else ""))
    for (k in 0 until r.nextInt(8)) hs.add(listOf("Accept: */*", "User-Agent: t/${r.nextInt(9)}", "Accept-Language: tr", "Cookie: a=${r.nextInt(99999)}; b=${r.nextInt(9)}", "X-Req: ${"v".repeat(r.nextInt(200))}", "Connection: keep-alive", "Cache-Control: no-cache")[r.nextInt(7)])
    hs.shuffle(r)
    val body = if (m == "POST" || m == "PUT") ByteArray(r.nextInt(900)).also { r.nextBytes(it) } else ByteArray(0)
    if (body.isNotEmpty()) hs.add("Content-Length: ${body.size}")
    for (h in hs) sb.append(h).append("\r\n")
    sb.append("\r\n")
    return sb.toString().toByteArray(Charsets.ISO_8859_1) + body
}

fun runDpiPropertyTests() {
    val rnd = Random(20261021L)
    T.group("Sızma 2 / DPI özellik testi: TLS — her yöntem, ${DEEP_X * 1500} rastgele ClientHello'da akışı bozmaz")
    run {
        var checked = 0
        val bad = ArrayList<String>()
        fun fail(msg: String) { if (bad.size < 8) bad += msg }
        val total = DEEP_X * 1500
        for (iter in 0 until total) {
            val host = if (rnd.nextInt(8) == 0) null else randHost(rnd)
            val hello = randHello(rnd, host, forceBig = rnd.nextInt(10) == 0)
            val orig = hello.copyOf()
            val origPayload = orig.copyOfRange(5, orig.size)
            val h0 = Dpi.Hello()
            val parsed = Dpi.parseHello(hello, hello.size, h0)
            if (host != null && (!parsed || h0.host(hello) != host.lowercase())) fail("parseHello iter=$iter host=$host got=${h0.host(hello)}")
            for (plan in 0 until Dpi.TLS_PLANS) {
                val parts = try { Dpi.split(Dpi.TLS, plan, hello, hello.size) } catch (e: Throwable) { fail("istisna plan=$plan iter=$iter: $e"); continue }
                checked++
                if (!hello.contentEquals(orig)) { fail("girdi DEĞİŞTİ plan=$plan iter=$iter"); System.arraycopy(orig, 0, hello, 0, orig.size) }
                if (parts.isEmpty() || parts.any { it.data.isEmpty() }) { fail("boş parça plan=$plan iter=$iter"); continue }
                if (parts.size > 16) fail("çok parça (${parts.size}) plan=$plan")
                val j = joined(parts)
                val rec = records(j)
                if (rec == null) { fail("geçerli kayıt akışı değil plan=$plan iter=$iter size=${hello.size} parts=${parts.map { it.data.size }}"); continue }
                if (!rec.second.contentEquals(origPayload)) { fail("el sıkışma yükü değişti plan=$plan iter=$iter"); continue }
                // yeniden birleştiren (kayıt birleştiren) bir ara cihaz / bizim ayrıştırıcı aynı SNI'yı görmeli
                if (host != null) {
                    val merged = Dpi.mergedHello(j, j.size) ?: j
                    val hh = Dpi.Hello()
                    if (!Dpi.parseHello(merged, merged.size, hh) || hh.host(merged) != host.lowercase()) fail("birleştirilmiş akışta SNI okunamadı plan=$plan iter=$iter host=$host")
                    // tlsNeed, kayıt bölünmüş akışın tamamını kapsamalı
                    val need = Dpi.tlsNeed(j, j.size)
                    if (need != j.size) fail("tlsNeed=$need != ${j.size} plan=$plan iter=$iter")
                }
                // sahte kopya: aynı uzunlukta ve yalnızca SNI baytlarında farklı
                for (p in parts) if (p.fake != null) {
                    if (p.fake.size != p.data.size) fail("sahte kopya boyu farklı plan=$plan")
                    else if (host != null) {
                        var diff = 0; for (k in p.data.indices) if (p.data[k] != p.fake[k]) diff++
                        if (diff > host.length) fail("sahte kopya SNI dışında da farklı: $diff bayt (SNI=${host.length}) plan=$plan")
                    }
                }
            }
        }
        T.check("TLS: $checked (yöntem × ClientHello) birleşimi, akış geçerli ve özgünle aynı", bad.isEmpty(), bad.joinToString(" | "))
    }

    T.group("Sızma 2 / DPI özellik testi: kayıt sınırları — çok küçük, çok büyük, SNI'sız, bozuk")
    run {
        val bad = ArrayList<String>()
        fun fail(m: String) { if (bad.size < 8) bad += m }
        val shapes = ArrayList<ByteArray>()
        for (n in 0..60) shapes.add(ByteArray(n) { if (it == 0) 0x16 else (it * 7).toByte() })             // kısa/bozuk
        for (n in intArrayOf(100, 500, 1400, 1460, 2900, 9000, 15000, 16384, 16389)) shapes.add(randHello(rnd, "boyut.example.com", forceBig = true).copyOf(n.coerceAtMost(20000)))
        shapes.add(randHello(rnd, null)); shapes.add(randHello(rnd, "a.b")); shapes.add(randHello(rnd, "x".repeat(250) + ".com"))
        for ((si, b) in shapes.withIndex()) for (plan in 0 until Dpi.TLS_PLANS) {
            try {
                val parts = Dpi.split(Dpi.TLS, plan, b, b.size)
                if (b.isNotEmpty() && (parts.isEmpty() || parts.any { it.data.isEmpty() })) fail("boş parça şekil=$si plan=$plan")
                // bozuk/kısa girdide bile veri kaybolmaz: bayt sayısı >= girdi
                if (b.isNotEmpty() && joined(parts).size < b.size) fail("veri kaybı şekil=$si plan=$plan")
            } catch (e: Throwable) { fail("istisna şekil=$si plan=$plan: $e") }
        }
        T.check("TLS: kenar şekillerde (boş, 1..60 bayt, 16 KB, SNI'sız) çökme/veri kaybı yok", bad.isEmpty(), bad.joinToString(" | "))
    }

    T.group("Sızma 2 / DPI özellik testi: HTTP — her yöntem, ${DEEP_X * 1500} rastgele istekte anlamı bozmaz")
    run {
        var checked = 0
        val bad = ArrayList<String>()
        fun fail(m: String) { if (bad.size < 8) bad += m }
        for (iter in 0 until DEEP_X * 1500) {
            val host = if (rnd.nextInt(10) == 0) null else randHost(rnd)
            val req = randHttp(rnd, host)
            val orig = req.copyOf()
            val ref = refParse(req) ?: continue
            for (plan in 0 until Dpi.HTTP_PLANS) {
                val parts = try { Dpi.split(Dpi.HTTP, plan, req, req.size) } catch (e: Throwable) { fail("istisna plan=$plan iter=$iter: $e"); continue }
                checked++
                if (!req.contentEquals(orig)) { fail("girdi DEĞİŞTİ plan=$plan iter=$iter"); System.arraycopy(orig, 0, req, 0, orig.size) }
                if (parts.isEmpty() || parts.any { it.data.isEmpty() }) { fail("boş parça plan=$plan iter=$iter"); continue }
                val got = refParse(joined(parts))
                if (got == null) { fail("birleşik akış HTTP olarak ayrışmıyor plan=$plan iter=$iter"); continue }
                if (got.line != ref.line) fail("istek satırı değişti plan=$plan: '${got.line}' != '${ref.line}'")
                if (got.headers.sortedBy { it.first + "\u0000" + it.second } != ref.headers.sortedBy { it.first + "\u0000" + it.second }) fail("başlıklar değişti plan=$plan iter=$iter")
                if (!got.body.contentEquals(ref.body)) fail("gövde değişti plan=$plan iter=$iter (${got.body.size} != ${ref.body.size})")
                val hi = Dpi.HttpInfo()
                if (host != null && Dpi.parseHttp(req, req.size, hi) && Dpi.httpHost(req, hi) != host.substringBefore(':').lowercase()) fail("httpHost yanlış iter=$iter")
                // süzgeç görünümü: dönüştürülmüş akışta da aynı Host görünmeli (sonraki cihaz aynı adı görür)
                if (host != null) {
                    val j = joined(parts)
                    val hs = Dpi.allHttpHosts(j, j.size)
                    if (host.lowercase() !in hs) fail("dönüştürülmüş akışta Host görünmüyor plan=$plan iter=$iter hs=$hs")
                }
            }
        }
        T.check("HTTP: $checked (yöntem × istek) birleşimi, istek satırı + başlık kümesi + gövde aynı", bad.isEmpty(), bad.joinToString(" | "))
    }

    T.group("Sızma 2 / DPI özellik testi: HTTP süzgeç görünümü — gizlenmiş Host biçimleri her bölme yönteminden sonra da görünür")
    run {
        val bad = ArrayList<String>()
        val forms = listOf(
            "GET /x HTTP/1.1\r\nHost: hedef.example\r\n\r\n",
            "GET /x HTTP/1.1\nHost: hedef.example\n\n",
            "GET /x HTTP/1.1\r\nHost:\r\n hedef.example\r\n\r\n",
            "GET /x HTTP/1.1\r\nHost: ok.example\r\nHost: hedef.example\r\n\r\n",
            "\r\nGET /x HTTP/1.1\r\nHost: hedef.example\r\n\r\n",
            "PROPFIND /x HTTP/1.1\r\nHost: hedef.example\r\n\r\n",
        )
        for ((fi, f) in forms.withIndex()) {
            val b = f.toByteArray()
            if (Dpi.classify(b, b.size) != Dpi.HTTP) { bad += "form $fi HTTP sınıflanmadı"; continue }
            if (Dpi.httpEnd(b, b.size) != b.size) bad += "form $fi başlık sonu yanlış: ${Dpi.httpEnd(b, b.size)} != ${b.size}"
            if ("hedef.example" !in Dpi.allHttpHosts(b, b.size)) bad += "form $fi Host görünmüyor"
            for (plan in 0 until Dpi.HTTP_PLANS) {
                val parts = Dpi.split(Dpi.HTTP, plan, b, b.size)
                val j = joined(parts)
                if (j.size < b.size) bad += "form $fi plan $plan veri kaybı"
                // bölme sonrası ters yönde de: istenen ad gizlenmiş olsa da sunucunun göreceği akışta hâlâ bulunur
                if ("hedef.example" !in Dpi.allHttpHosts(j, j.size) && refParse(j)?.headers?.none { it.first == "host" && it.second.contains("hedef.example") } != true) bad += "form $fi plan $plan: ad görünmez oldu"
            }
        }
        T.check("gizlenmiş Host biçimleri (LF, katlama, çift Host, baştaki boş satır, WebDAV) ayrıştırılır, httpEnd tam uzunluk", bad.isEmpty(), bad.joinToString(" | "))
    }

    T.group("Sızma 2 / DPI planlayıcı: rastgele olay dizileri ve eşzamanlılık (durum makinesi değişmezleri)")
    run {
        val bad = java.util.concurrent.CopyOnWriteArrayList<String>()
        val planner = Dpi.Planner(cap = 64)
        var clock = 1_000_000L
        val keys = (1..200).map { "host$it.example" }
        val threads = (1..4).map { tid ->
            Thread({
                val r = Random(tid * 77L)
                try {
                    repeat(DEEP_X * 15_000) {
                        val kind = if (r.nextBoolean()) Dpi.TLS else Dpi.HTTP
                        val n = if (kind == Dpi.TLS) Dpi.TLS_PLANS else Dpi.HTTP_PLANS
                        val key = keys[r.nextInt(keys.size)]
                        when (r.nextInt(9)) {
                            0 -> planner.worked(key, kind, r.nextInt(n), r.nextInt(1 shl 14), (r.nextInt(5000) - 100).toLong())
                            1 -> planner.failed(key, if (r.nextBoolean()) kind else -1)
                            2 -> planner.exhaust(key, clock + r.nextInt(100_000), kind)
                            3 -> planner.cut(key, kind, r.nextInt(n + 3) - 1, r.nextInt(5), clock + r.nextInt(1_000_000))
                            4 -> planner.noteRtt((r.nextInt(5000) - 500).toLong())
                            5 -> if (r.nextInt(2000) == 0) planner.forget()
                            6 -> planner.seed(kind, r.nextInt(n + 1) - 1)
                            7 -> planner.siteImport(mapOf(Dpi.siteKey(key) to r.nextInt(100) - 10))
                            else -> {}
                        }
                        val f = planner.first(key, kind); val s = planner.firstSafe(key, kind)
                        if (f !in 0 until n) bad += "first=$f kind=$kind"
                        var cur = if (f in 0 until n) f else if (kind == Dpi.TLS) Dpi.TLS_ORDER[0] else 0
                        var steps = 0
                        while (true) {                                                  // next() sonlanır, döngüye girmez
                            val nx = planner.next(kind, cur)
                            if (nx < 0) break
                            cur = nx
                            if (++steps > 40) { bad += "next döngüsü kind=$kind"; break }
                        }
                        val w = planner.waitMs(kind); if (w <= 0 || w > 10_000) bad += "waitMs=$w"
                        val h = planner.hedgeMs(); if (h < 0 || h > 60_000) bad += "hedgeMs=$h"
                        if (s !in 0 until n) bad += "firstSafe=$s kind=$kind"
                    }
                } catch (e: Throwable) { bad += "istisna: $e" }
            }, "pl-$tid").also { it.start() }
        }
        threads.forEach { it.join(60_000) }
        T.check("planlayıcı: rastgele işlem/çok iş parçacığı sonrası değişmezler korunur", bad.isEmpty(), bad.take(5).joinToString(" | "))
        T.check("planlayıcı: site belleği sınırı aşılmaz", planner.siteExport().size <= 64, planner.siteExport().size.toString())
        val st = planner.methodStats()
        T.check("planlayıcı: istatistikler tutarlı (negatif yok)", st.all { it.wins >= 0 && it.fails >= 0 && it.avgMs >= 0 })
    }

    T.group("Sızma 2 / DPI planlayıcı: TLS ve HTTP belleği birbirine karışmaz (aynı ad, ayrı yöntem uzayı)")
    run {
        val now = 5_000_000L
        val h = "ornek.example"
        val p = Dpi.Planner()
        p.worked(h, Dpi.TLS, 12, 0, 120)
        T.check("TLS'te öğrenilen 12 numaralı yöntem HTTP'ye geçmez", p.first(h, Dpi.HTTP) in 0 until Dpi.HTTP_PLANS && p.first(h, Dpi.TLS) == 12, "http=${p.first(h, Dpi.HTTP)} tls=${p.first(h, Dpi.TLS)}")
        p.worked(h, Dpi.HTTP, 5, 0, 80)
        T.check("HTTP'te öğrenilen yöntem TLS belleğini ezmez", p.first(h, Dpi.TLS) == 12 && p.first(h, Dpi.HTTP) == 5, "tls=${p.first(h, Dpi.TLS)} http=${p.first(h, Dpi.HTTP)}")
        T.check("denenemeyen uçuş için de tür ayrı (firstSafe)", p.firstSafe(h, Dpi.TLS) == 12 && p.firstSafe(h, Dpi.HTTP) == 5)
        val before = p.siteExport().size
        p.failed(h, Dpi.HTTP)
        T.check("HTTP için failed yalnızca HTTP girdisini siler", before == 2 && p.siteExport().size == 1 && p.first(h, Dpi.TLS) == 12, "önce=$before sonra=${p.siteExport().size}")
        p.worked(h, Dpi.HTTP, 5, 0, 80)
        p.exhaust(h, now, Dpi.HTTP)
        T.check("HTTP'de tükenme TLS'i düz aktarmaya düşürmez", p.isExhausted(h, now + 1, Dpi.HTTP) && !p.isExhausted(h, now + 1, Dpi.TLS))
        p.exhaust(h, now, Dpi.TLS)
        T.check("tükenme türe göre ayrı süre tutar", p.isExhausted(h, now + 1, Dpi.TLS) && !p.isExhausted(h, now + Dpi.EXHAUST_MS, Dpi.HTTP))
        val q = Dpi.Planner()
        q.worked(h, Dpi.TLS, 3, 0, 50); q.worked(h, Dpi.HTTP, 1, 0, 50)
        val n1 = q.cut(h, Dpi.HTTP, 1, 2, now) ; val n2 = q.cut(h, Dpi.HTTP, 1, 2, now + 1)
        T.check("kesinti puanı yalnızca kendi türünün yöntemini ilerletir", q.first(h, Dpi.TLS) == 3 && (n1 == 2 || n2 == 2) && q.first(h, Dpi.HTTP) == 2, "n1=$n1 n2=$n2 http=${q.first(h, Dpi.HTTP)}")
        q.failed(h)
        T.check("failed(tür verilmezse) iki türü de siler", q.siteExport().isEmpty(), q.siteExport().toString())
        // kalıcı bellekten bozuk değerler (başka sürüm, elle düzenleme) yöntem seçimini bozamaz
        val r = Dpi.Planner()
        r.siteImport(mapOf(Dpi.siteKey("bozuk.example") to 99, Dpi.siteKey("eksi.example") to -3, Dpi.siteKey("iyi.example") to 9))
        T.check("bozuk içe aktarma değerleri atılır, geçerli olan alınır",
            r.first("bozuk.example", Dpi.TLS) in 0 until Dpi.TLS_PLANS && r.first("eksi.example", Dpi.TLS) in 0 until Dpi.TLS_PLANS && r.first("iyi.example", Dpi.TLS) == 9 && r.siteExport().size == 1,
            r.siteExport().toString())
    }
}
