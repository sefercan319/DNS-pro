package app.dnshizli.selftest

import app.dnshizli.core.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** Derin katman zorluk çarpanı: eski taramalar 1x, bu katman FUZZ_X(4) üstüne 3x. */
internal const val DEEP_X = 3

private val LO: InetAddress = InetAddress.getLoopbackAddress()

/**
 * Kaos DNS sunucusu: tohumlu rastgelelikle paket düşürür, geciktirir, yineler, yanlış kimlikli (sahte), yanlış soruyla ya da
 * çöp cevap gönderir. [dead] doğruysa hiç cevap vermez. Gerçek cevap hep 1.2.3.4 döner; sahteler 6.6.6.6.
 */
private class ChaosDns(seed: Long, private val drop: Double = 0.15, private val delayP: Double = 0.10, private val dupP: Double = 0.08,
                       private val spoofP: Double = 0.06, private val wrongQP: Double = 0.05, private val junkP: Double = 0.04) : AutoCloseable {
    val socket = DatagramSocket(0, LO)
    val rng = Random(seed)
    @Volatile var dead = false
    val received = AtomicInteger()
    val addr: InetSocketAddress get() = InetSocketAddress(LO, socket.localPort)
    private val workers = java.util.concurrent.Executors.newCachedThreadPool { r -> Thread(r, "chaos").apply { isDaemon = true } }

    init {
        Thread({
            val buf = ByteArray(2048); val p = DatagramPacket(buf, buf.size)
            while (!socket.isClosed) {
                try { p.length = buf.size; socket.receive(p) } catch (_: Exception) { return@Thread }
                received.incrementAndGet()
                if (dead) continue
                val q = buf.copyOf(p.length); val to = p.socketAddress
                val r = synchronized(rng) { rng.nextDouble() }
                val delayMs = synchronized(rng) { 30L + rng.nextInt(250) }
                val jitter = synchronized(rng) { rng.nextInt(8).toLong() }
                fun send(b: ByteArray, after: Long = jitter) {
                    try { workers.execute { try { Thread.sleep(after); socket.send(DatagramPacket(b, b.size, to)) } catch (_: Exception) {} } } catch (_: Exception) {}
                }
                val good = buildAnswer(q, q.size, aRecord(byteArrayOf(1, 2, 3, 4)), 1)
                var acc = drop
                when {
                    r < acc -> {}
                    r < (acc + delayP).also { acc = it } -> send(good, delayMs)
                    r < (acc + dupP).also { acc = it } -> { send(good); send(good, 40) }
                    r < (acc + spoofP).also { acc = it } -> {
                        val bad = buildAnswer(q, q.size, aRecord(byteArrayOf(6, 6, 6, 6)), 1); Packets.put16(bad, 0, (Packets.u16(bad, 0) + 1 + jitter.toInt()) and 0xFFFF)
                        send(bad, 0); send(good, 20)
                    }
                    r < (acc + wrongQP).also { acc = it } -> {
                        val other = Dns.buildQuery(Packets.u16(q, 0), "evil-" + (delayMs) + ".example")
                        send(buildAnswer(other, other.size, aRecord(byteArrayOf(6, 6, 6, 6)), 1), 0); send(good, 25)
                    }
                    r < (acc + junkP).also { acc = it } -> { send(byteArrayOf(1, 2, 3, 4, 5), 0); send(good, 30) }
                    else -> send(good)
                }
            }
        }, "chaos-rx").apply { isDaemon = true; start() }
    }
    override fun close() { socket.close(); workers.shutdownNow() }
}

private class Load(threads: Int) : AutoCloseable {
    @Volatile private var run = true
    private val ts = (1..threads).map { Thread { var x = 1L; while (run) { x = x * 6364136223846793005L + 1442695040888963407L; if (x == 42L) Thread.yield() } }.apply { isDaemon = true; start() } }
    override fun close() { run = false; ts.forEach { it.join(500) } }
}

fun runDeepDnsTests() {
    T.group("Derin DNS: kaos sunucularla çok iş parçacıklı yarış")
    for (seed in 1L..(3L * DEEP_X)) {
        ChaosDns(seed * 7919).use { a -> ChaosDns(seed * 104729).use { b ->
            Harness(listOf(a.addr, b.addr), retryAfterMs = 90, giveUpAfterMs = 3500, sweepMs = 20).use { h ->
                val n = 40 * DEEP_X
                val ports = 6
                val sent = ConcurrentHashMap<String, Int>()      // "port:id" -> istek sayısı
                // onPacket sözleşmesi: tek iş parçacığından çağrılır (tünel okuyucu); portlar aynı iş parçacığında dönüşümlü
                for (k in 0 until n / ports) for (pi in 0 until ports) {
                    val id = 0x2000 + pi * 500 + k
                    sent["${44000 + pi}:$id"] = 1
                    h.send(clientPacket(id, name = "q$k-$pi.example.com", srcPort = 44000 + pi))
                    Thread.sleep(2)
                }
                val got = ConcurrentHashMap<String, Int>(); val bad = ArrayList<String>()
                val end = System.currentTimeMillis() + 6000
                while (System.currentTimeMillis() < end && got.size < sent.size) {
                    val r = h.reply(300) ?: continue
                    val port = Packets.u16(r, 22); val id = Packets.u16(r, 28)
                    val why = replyOk(r, id, port)
                    if (why != null) bad += "p$port id$id $why"
                    got.merge("$port:$id", 1) { x, y -> x + y }
                }
                Thread.sleep(400)
                while (true) { val r = h.reply(50) ?: break; got.merge("${Packets.u16(r, 22)}:${Packets.u16(r, 28)}", 1) { x, y -> x + y } }
                val dup = got.filter { it.value > 1 }
                val st = h.fw.stats()
                T.check("tohum $seed: her cevap geçerli ve sahte (6.6.6.6) hiç iletilmedi", bad.isEmpty(), bad.take(3).toString())
                T.check("tohum $seed: istemciye aynı sorgunun ikinci cevabı gitmedi (yinelenen yok)", dup.isEmpty(), dup.toString())
                T.check("tohum $seed: sorguların ≥%90'ı cevaplandı (${got.size}/${sent.size})", got.size * 10 >= sent.size * 9, "timeouts=${st.timeouts} retries=${st.retries}")
                T.check("tohum $seed: bekleyen sorgu kalmadı", run { var t = 0; while (h.fw.pendingCount() > 0 && t++ < 60) Thread.sleep(100); h.fw.pendingCount() == 0 }, "bekleyen=${h.fw.pendingCount()}")
                T.check("tohum $seed: yanlış soru/çöp cevap sayıldı ve reddedildi", st.rejected >= 0)
            }
        } }
    }

    T.group("Derin DNS: aşamalı arıza (birincil ölür, yedek devralır, birincil döner)")
    for (seed in 1L..(2L * DEEP_X)) {
        ChaosDns(seed * 31, drop = 0.02, delayP = 0.02, dupP = 0.02, spoofP = 0.02, wrongQP = 0.0, junkP = 0.0).use { prim ->
            ChaosDns(seed * 77, drop = 0.02, delayP = 0.02, dupP = 0.02, spoofP = 0.02, wrongQP = 0.0, junkP = 0.0).use { back ->
                Harness(listOf(prim.addr, back.addr), retryAfterMs = 80, giveUpAfterMs = 3000, sweepMs = 20).use { h ->
                    fun phase(tag: String, from: Int, count: Int): Int {
                        var ok = 0
                        for (i in 0 until count) {
                            h.send(clientPacket(from + i, name = "$tag$i.example.com", srcPort = 45000 + (i % 3)))
                            val r = h.reply(3500)
                            if (r != null && replyOk(r, from + i, 45000 + (i % 3)) == null) ok++
                        }
                        return ok
                    }
                    val a = phase("a", 0x100, 8)
                    prim.dead = true
                    val b = phase("b", 0x200, 12)
                    val st = h.fw.stats()
                    T.check("seed $seed: birincil sağlıklıyken 8/8", a >= 7, "a=$a")
                    T.check("seed $seed: birincil ölünce 12 sorgunun ≥11'i yedekten cevaplandı", b >= 11, "b=$b")
                    T.check("seed $seed: ölü birincil → yedeğe kalıcı geçiş", st.backup && st.failovers >= 1, "backup=${st.backup} fo=${st.failovers}")
                    val t0 = System.nanoTime()
                    h.send(clientPacket(0x300, name = "c.example.com", srcPort = 45010))
                    val r = h.reply(3000)
                    val ms = (System.nanoTime() - t0) / 1_000_000
                    T.check("seed $seed: geçişten sonra sorgu hızlı (<400 ms)", r != null && ms < 400, "ms=$ms")
                    h.fw.resetNetwork("test")
                    prim.dead = false
                    val c = phase("c", 0x400, 6)
                    T.check("seed $seed: ağ değişince birincil yeniden denenir, 6/6", c >= 5 && !h.fw.stats().backup, "c=$c backup=${h.fw.stats().backup}")
                }
            }
        }
    }

    T.group("Derin DNS: yük altında yarış kararlılığı (CPU doygun)")
    Load(Runtime.getRuntime().availableProcessors() * 2).use { _ ->
        var fails = 0; val why = ArrayList<String>()
        for (round in 1..(8 * DEEP_X)) {
            FakeDns(dropFirst = 1).use { flaky ->
                FakeDns().use { backup ->
                    Harness(listOf(flaky.addr, backup.addr), retryAfterMs = 300, giveUpAfterMs = 4000, sweepMs = 20).use { h ->
                        h.send(clientPacket(0x3001, name = "g$round.example.com", srcPort = 46201))
                        val r1 = h.reply(5000)
                        val s1 = h.fw.streakCount()
                        val pre = h.fw.streakCount()
                        h.send(clientPacket(0x3002, name = "h$round.example.com", srcPort = 46202))
                        val post = h.fw.streakCount()
                        val r2 = h.reply(5000)
                        Thread.sleep(120)
                        val ok = r1 != null && r2 != null && s1 >= 1 && h.fw.raceCount() == 1L && backup.received.get() >= 2
                        if (!ok) { fails++; if (why.size < 3) why += "tur$round: r1=${r1 != null} r2=${r2 != null} streak1=$s1 pre=$pre post=$post yarış=${h.fw.raceCount()} yedekAldı=${backup.received.get()} flakyAldı=${flaky.received.get()}" }
                    }
                }
            }
        }
        T.check("yarış: ${8 * DEEP_X} turun hepsinde yedek yeniden denemeyi cevapladı, sayaç arttı, sonraki sorgu yarıştı", fails == 0, why.toString())
    }

    T.group("Derin DNS: tek sunucuda yarış yok, bozuk girdi çökertmez")
    FakeDns().use { one ->
        Harness(listOf(one.addr), retryAfterMs = 100, giveUpAfterMs = 1500).use { h ->
            val rnd = Random(99)
            for (i in 0 until 200 * DEEP_X) {
                val pkt = clientPacket(i, name = "z$i.example.com", srcPort = 47000 + i % 5)
                if (i % 3 == 0) for (k in 0 until 1 + rnd.nextInt(4)) pkt[rnd.nextInt(pkt.size)] = rnd.nextInt(256).toByte()
                try { h.send(pkt) } catch (e: Exception) { T.check("bozuk istemci paketi çökertmez", false, e.toString()); break }
            }
            T.check("tek sunucu: yarış sayısı 0", h.fw.raceCount() == 0L)
            Thread.sleep(2200)
            T.check("bozuk paketlerden sonra bekleyen sorgu kalmadı ve yönlendirici hâlâ cevap veriyor", run {
                while (h.reply(20) != null) {}
                h.send(clientPacket(0x5555, srcPort = 47100)); h.reply(2000)?.let { replyOk(it, 0x5555, 47100) == null } == true
            })
        }
    }
}
