package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.Locale

/** Sızma girişimleri (saldırgan gözüyle): günlük sahteciliği, ad taklidi, ayrıştırma farkları, cihaz dili, içe aktarma, filtre atlatma. */
fun runRedTeamTests() {
    T.group("Sızma girişimi: günlük/rapor sahteciliği (uzaktan gelen metin sahte satır uyduramaz)")
    run {
        val log = DiagLog(clock = { 0L })
        // Sertifika CN'i, sunucu iletisi ya da istisna metni satır sonu taşıyabilir
        log.add("[SIZMA] sertifika adı: evil.com\n!! [HATA] sahte kritik satır\r\n[ÖZET] her şey yolunda")
        log.add("x !! [HATA] unicode satır ayırıcı‮gnirts")
        log.add("a".repeat(5000))
        val lines = log.dump().split('\n')
        T.check("tek ileti = tek satır (3 ileti, 3 satır)", lines.size == 3, lines.size.toString())
        T.check("sahte '!! [HATA]' satırı oluşmaz", lines.none { it.substringAfter(' ').startsWith("!! [HATA] sahte") })
        T.check("yön değiştirme/görünmez karakter atılır", lines.none { l -> l.any { Character.getType(it) == Character.FORMAT.toInt() } })
        T.check("uzunluk sınırlı (≤ 520)", lines.all { it.length <= 520 })
    }

    T.group("Sızma girişimi: ad taklidi (görünmez/yön değiştiren karakterler) ve rakam farkları")
    run {
        val bad = listOf("Cloudflare‮", "‮evil", "Goo​gle", "Quad9⁦", "A B", "xy", "a\u0000b", "tab\there", "a|b", "a;b", "a=b", "a,b")
        T.check("taklit edilebilir özel sunucu adları reddedilir", bad.none { CustomDns.validName(it) }, bad.filter { CustomDns.validName(it) }.toString())
        T.check("meşru adlar kabul (Türkçe harf, emoji, boşluk)", listOf("Şeker DNS", "Ev DNS 🚀", "İş Yeri", "ağ-2").all { CustomDns.validName(it) })
        T.check("Unicode rakamlı IPv4 ASCII sanılmaz", listOf("١.٢.٣.٤", "1.2.3.٤", "१.२.३.४", "１.２.３.４").none { Ip.parse(it) != null || CustomDns.validIp(it) })
        T.check("sekizlik/onaltılık/kısa IPv4 yazımları reddedilir", listOf("0177.0.0.1", "0x7f.0.0.1", "127.1", "2130706433", "1.2.3", "1.2.3.4.5", " 1.2.3.4", "1.2.3.4\n", "1.2.3.4\u0000").none { CustomDns.validIp(it) })
        T.check("IPv6 yerel/loopback/eşlenmiş reddedilir", listOf("::1", "fe80::1", "::ffff:1.2.3.4", "::", "ff02::1").none { CustomDns.validIp(it) })
        T.check("DoH adresi: kimlik bilgisi, port, satır sonu, IP, yol kaçışı reddedilir",
            listOf("https://user:pw@dns.example.com/dns-query", "https://dns.example.com:444/x", "https://dns.example.com/dns-query\r\nHost: evil", "https://1.2.3.4/dns-query",
                "https://dns.example.com/a b", "http://dns.example.com/x", "https://dns.example.com/../../x?a=b", "https://dns.example.com/‮dns", "https://dns.example.com#x").none { CustomDns.validDoh(it) },
            listOf("https://user:pw@dns.example.com/dns-query", "https://dns.example.com:444/x", "https://dns.example.com/dns-query\r\nHost: evil", "https://1.2.3.4/dns-query",
                "https://dns.example.com/a b", "http://dns.example.com/x", "https://dns.example.com/../../x?a=b", "https://dns.example.com/‮dns", "https://dns.example.com#x").filter { CustomDns.validDoh(it) }.toString())
        T.check("DoT adı: IP, satır sonu, alt çizgi, uzun etiket reddedilir", listOf("1.2.3.4", "dns.example.com\r\n", "a_b.example.com", "a".repeat(64) + ".example.com", "dns..example.com", "-a.example.com").none { CustomDns.validDot(it) })
    }

    T.group("Sızma girişimi: cihaz dili/takvimi sertifika üretimini bozamaz")
    run {
        val old = Locale.getDefault()
        try {
            val tags = listOf("ar-SA-u-nu-arab", "fa-IR-u-nu-arabext", "hi-IN-u-nu-deva", "th-TH", "th-TH-u-nu-thai", "ja-JP-u-ca-japanese", "ar-SA-u-ca-islamic", "tr-TR", "he-IL", "bn-BD-u-nu-beng")
            var bad: String? = null
            for (tag in tags) {
                Locale.setDefault(Locale.forLanguageTag(tag))
                try {
                    val now = System.currentTimeMillis()
                    val ca = MitmCa.generate(Cosmetic.BUILTIN.domains(), now)
                    val ch = ca.leaf("www.youtube.com", now)
                    val nb = ca.cert.notBefore.time
                    val years = (ca.cert.notAfter.time - nb) / (365.0 * 86_400_000)
                    if (ch == null || Math.abs(nb - (now - MitmCa.DAY)) > 2000 || years < 9.9 || years > 10.1) bad = "$tag: notBefore=${ca.cert.notBefore} süre=$years yıl"
                    else { ch[0].verify(ch[1].publicKey); ch[1].verify(ca.cert.publicKey) }
                } catch (e: Throwable) { bad = "$tag: ${e.javaClass.simpleName} ${e.message?.take(60)}" }
                if (bad != null) break
            }
            T.check("${tags.size} farklı cihaz dilinde CA ve yaprak tarihleri doğru, zincir doğrulanır", bad == null, bad ?: "")
            // Gün anahtarları Gregoryen takvimle (Tay Budist yılı 2569 / Japon çağı anahtarı bozmaz)
            Locale.setDefault(Locale.forLanguageTag("th-TH"))
            val key = DailyStats.today(1_800_000_000_000L, java.util.TimeZone.getTimeZone("UTC"))
            T.check("günlük istatistik anahtarı Gregoryen (20xx)", key in 20_000_101..20_991_231, key.toString())
        } finally { Locale.setDefault(old) }
    }

    T.group("Sızma girişimi: içe aktarma kodu (yerel anahtarlar, taklit, dev girdiler)")
    run {
        fun code(vararg kv: String) = "DNSH1:" + Base64Mini.encode(kv.joinToString("\n").toByteArray(Charsets.UTF_8))
        val base = AppSettings()
        val evil = SettingsCodec.import(code("mitmOn=true", "custom=u1|Evil|6.6.6.6||||;u2|X|7.7.7.7||||", "apps=com.victim", "appScope=only", "onboarded=true", "encryption=off", "wifiServer=u1"), base)
        T.check("yerel anahtarlar (mitmOn, özel sunucular, uygulama kapsamı) içe aktarılmaz", evil != null && !evil.mitmOn && evil.apps.isEmpty() && evil.appScope == base.appScope && evil.wifiServer != "u1")
        T.check("güvenliği gevşeten içe aktarma işaretlenir (şifreleme kapatma)", evil != null && SensitiveChange.ENCRYPTION_WEAKER in ImportReview.changes(base, evil))
        val huge = "DNSH1:" + Base64Mini.encode(("filterAllow=" + "a.com,".repeat(100_000)).toByteArray())
        T.check("devasa kod reddedilir ya da sınırlanır, çökmez", SettingsCodec.import(huge, base).let { it == null || it.filterAllow.size <= 1000 })
        T.check("satır sonu/CRLF ve çift anahtar tutarlı", SettingsCodec.import(code("encryption=auto\r", "encryption=off\r"), base) != null)
    }

    T.group("Sızma girişimi: engel listesi atlatma (harf, nokta, sonek, sıfır bayt, benzer ad)")
    run {
        BlockedSites.set(setOf("blocked-site.example", "ads.tracker.net"))
        try {
            val yes = listOf("blocked-site.example", "BLOCKED-SITE.EXAMPLE", "Blocked-Site.Example.", "www.blocked-site.example", "a.b.c.blocked-site.example", "ads.tracker.net", "X.ADS.Tracker.NET.")
            val no = listOf("blocked-site.example.evil.com", "xblocked-site.example", "blocked-site.example\u0000.evil.com", "blocked-site.exampIe", "tracker.net", "net", "", ".", "blocked_site.example", "ads.tracker.net.evil")
            T.check("aynı alan adının yazım çeşitleri engellenir", yes.all { BlockedSites.matches(it) }, yes.filter { !BlockedSites.matches(it) }.toString())
            T.check("benzer/saldırgan adlar yanlış eşleşmez", no.none { BlockedSites.matches(it) }, no.filter { BlockedSites.matches(it) }.toString())
        } finally { BlockedSites.reset() }
        val rules = Cosmetic.parse("youtube.com##.ad\nreddit.com##.x")
        T.check("kozmetik kural kapsamı: yalnızca ad ve alt alanları", rules.has("m.YOUTUBE.com") && rules.has("a.b.youtube.com.") && !rules.has("notyoutube.com") && !rules.has("youtube.com.evil.net") && !rules.has("youtube.com\u0000.evil.net"))
    }
}
