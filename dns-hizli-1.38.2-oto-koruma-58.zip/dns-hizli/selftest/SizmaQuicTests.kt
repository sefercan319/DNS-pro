package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.util.Random
import javax.crypto.Cipher

/**
 * Sızma 2 — QUIC Initial: istemci SNI'yı bir CRYPTO çerçevesine koyup sunucunun göreceği asıl adı başka bir (çakışan) çerçeveye saklarsa
 * denetim atlatılabilirdi (sunucu ilk gelen baytı, biz son gelen baytı alırsak). Çakışan farklı baytlar artık "belirsiz" = akış düşürülür.
 * Ayrıca yapı-bilinçli rastgele Initial'lar (DCID/SCID/PN uzunluğu, çerçeve bölme/sıra/dolgu) ve bozulmuş yükler.
 */

private fun vb(v: Int): ByteArray = when {
    v < 64 -> byteArrayOf(v.toByte())
    v < 16384 -> byteArrayOf((0x40 or (v ushr 8)).toByte(), v.toByte())
    else -> byteArrayOf((0x80 or (v ushr 24)).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())
}

private fun cryptoFrame(off: Int, d: ByteArray, from: Int = 0, to: Int = d.size): ByteArray {
    val o = ByteArrayOutputStream(); o.write(0x06); o.write(vb(off + from)); o.write(vb(to - from)); o.write(d, from, to - from); return o.toByteArray()
}

/** İstemci Initial datagramı: [frames] şifresiz yük (dolgu otomatik, toplam en az 1200 bayt). */
private fun buildInitial(dcid: ByteArray, scid: ByteArray, pnLen: Int, pn: Long, frames: ByteArray, tail: ByteArray? = null): ByteArray {
    val keys = QuicInitial.clientKeys(dcid)
    val hdrFixed = 1 + 4 + 1 + dcid.size + 1 + scid.size + 1 + 2 + pnLen
    var plain = frames
    val minPlain = 1200 - hdrFixed - 16
    if (plain.size < minPlain) plain = plain + ByteArray(minPlain - plain.size)
    val lenField = pnLen + plain.size + 16
    val h = ByteArrayOutputStream()
    h.write(0xC0 or (pnLen - 1)); h.write(byteArrayOf(0, 0, 0, 1)); h.write(dcid.size); h.write(dcid); h.write(scid.size); h.write(scid); h.write(0)
    h.write(0x40 or (lenField ushr 8)); h.write(lenField and 0xFF)
    val pnOff = h.size()
    for (i in pnLen - 1 downTo 0) h.write(((pn ushr (8 * i)) and 0xFF).toInt())
    val header = h.toByteArray()
    val ct = QuicInitial.gcm(Cipher.ENCRYPT_MODE, keys, pn, header, plain, 0, plain.size)
    val out = header + ct
    val sample = QuicInitial.aesEcb(keys.hp, out.copyOfRange(pnOff + 4, pnOff + 20))
    out[0] = (out[0].toInt() xor (sample[0].toInt() and 0x0F)).toByte()
    for (i in 0 until pnLen) out[pnOff + i] = (out[pnOff + i].toInt() xor sample[1 + i].toInt()).toByte()
    return if (tail != null) out + tail else out
}

fun runQuicEvasionTests() {
    val rnd = Random(20261024L)
    fun hello(host: String): ByteArray { val r = randHello(rnd, host); return r.copyOfRange(5, r.size) }
    fun dcid() = ByteArray(8 + rnd.nextInt(13)).also { rnd.nextBytes(it) }

    T.group("Sızma 2 / QUIC Initial: çakışan CRYPTO çerçeveleri denetimi atlatamaz (ilk-kazanır / son-kazanır belirsizliği)")
    run {
        val bad = "blocked.example"; val ok = "benign1.example"            // aynı uzunluk
        val hBad = hello(bad)
        // sabit uzunlukta iki ClientHello: yalnızca SNI baytları farklı
        val hOk = hBad.copyOf().also { val si = QuicInitial.sni(hBad)!!; for (i in 0 until si[1]) it[si[0] + i] = ok[i].code.toByte() }
        val dc = dcid()
        val plain = buildInitial(dc, ByteArray(0), 4, 0, cryptoFrame(0, hBad))
        T.check("kontrol: tek çerçeveli Initial'dan SNI okunur", QuicInitial.peekSni(plain, 0, plain.size) == bad)
        val badFirst = buildInitial(dc, ByteArray(0), 4, 0, cryptoFrame(0, hBad) + cryptoFrame(0, hOk))
        val okFirst = buildInitial(dc, ByteArray(0), 4, 0, cryptoFrame(0, hOk) + cryptoFrame(0, hBad))
        T.check("aynı ofsette iki farklı ClientHello (gerçek ad önce / sonra): hangisi seçilirse seçilsin belirsiz → null (düşürülür)",
            QuicInitial.peekSni(badFirst, 0, badFirst.size) == null && QuicInitial.peekSni(okFirst, 0, okFirst.size) == null,
            "gerçekFirst=${QuicInitial.peekSni(badFirst, 0, badFirst.size)} benignFirst=${QuicInitial.peekSni(okFirst, 0, okFirst.size)}")
        val si = QuicInitial.sni(hBad)!!
        val cut = si[0] + si[1] / 2
        val part = buildInitial(dc, ByteArray(0), 4, 0, cryptoFrame(0, hBad, 0, cut + 5) + cryptoFrame(0, hOk, cut - 3, hOk.size))
        T.check("kısmen çakışan çerçevede (yalnızca çakışan bölge farklı) belirsiz → null", QuicInitial.peekSni(part, 0, part.size) == null)
        val same = buildInitial(dc, ByteArray(0), 4, 0, cryptoFrame(0, hBad, 0, cut + 10) + cryptoFrame(0, hBad, cut - 10, hBad.size) + cryptoFrame(0, hBad))
        T.check("özdeş yeniden gönderim (aynı baytlar çakışır) normal kabul edilir", QuicInitial.peekSni(same, 0, same.size) == bad)
        val rev = buildInitial(dc, ByteArray(0), 4, 0, cryptoFrame(0, hBad, cut, hBad.size) + cryptoFrame(0, hBad, 0, cut))
        T.check("ters sıralı çerçeveler (çakışmasız) birleşir", QuicInitial.peekSni(rev, 0, rev.size) == bad)
        val gap = buildInitial(dc, ByteArray(0), 4, 0, cryptoFrame(0, hBad, 0, cut) + cryptoFrame(0, hBad, cut + 5, hBad.size))
        T.check("boşluklu çerçeveler → null", QuicInitial.peekSni(gap, 0, gap.size) == null)
        val ack = buildInitial(dc, ByteArray(0), 4, 0, byteArrayOf(0x02, 0, 0, 0, 0) + cryptoFrame(0, hBad))
        T.check("CRYPTO/PADDING/PING dışı çerçeve (ACK) → null (düşürülür)", QuicInitial.peekSni(ack, 0, ack.size) == null)
        val ping = buildInitial(dc, ByteArray(0), 4, 0, byteArrayOf(0x01, 0x01) + cryptoFrame(0, hBad) + byteArrayOf(0x01))
        T.check("PING çerçeveleri araya girse de okunur", QuicInitial.peekSni(ping, 0, ping.size) == bad)
        val huge = buildInitial(dc, ByteArray(0), 4, 0, cryptoFrame(120_000, hBad))
        T.check("çok büyük CRYPTO ofseti (bellek şişirme) reddedilir", QuicInitial.peekSni(huge, 0, huge.size) == null)
        // Gateway'in kullandığı kimlik: reorder/fake çakışan paketlerde de çökmez ve null döner
        T.check("çakışan paketlerde reorder/fake güvenle null", QuicInitial.reorder(badFirst, 0, badFirst.size) == null && QuicInitial.fake(okFirst, 0, okFirst.size) == null)
    }

    T.group("Sızma 2 / QUIC Initial: ${DEEP_X * 400} yapı-bilinçli rastgele Initial (DCID/SCID/PN uzunluğu, çerçeve bölme, sıra, dolgu, artçı paket)")
    run {
        var wrong = 0; var nulls = 0; var reBad = 0; var fkBad = 0; var thrown = 0; var reN = 0; var fkN = 0
        val first = StringBuilder()
        val total = DEEP_X * 400
        for (iter in 0 until total) {
            val host = (1..1 + rnd.nextInt(3)).joinToString(".") { "l${rnd.nextInt(1000)}" } + ".example"
            val h = hello(host)
            // çerçeveler: 1..4 parça, rastgele sıra, araya PING/PADDING, bazen özdeş yeniden gönderim
            val cuts = (0 until rnd.nextInt(4)).map { 1 + rnd.nextInt(h.size - 1) }.distinct().sorted()
            val bounds = listOf(0) + cuts + h.size
            val pieces = (0 until bounds.size - 1).map { cryptoFrame(0, h, bounds[it], bounds[it + 1]) }.toMutableList()
            if (rnd.nextInt(4) == 0) pieces += cryptoFrame(0, h, 0, h.size / 2)            // özdeş yeniden gönderim
            pieces.shuffle(rnd)
            val fr = ByteArrayOutputStream()
            for (p in pieces) { if (rnd.nextInt(3) == 0) fr.write(0x01); if (rnd.nextInt(4) == 0) fr.write(ByteArray(rnd.nextInt(5))); fr.write(p) }
            val pnLen = 1 + rnd.nextInt(4)
            val pkt = buildInitial(dcid(), ByteArray(rnd.nextInt(21)).also { rnd.nextBytes(it) }, pnLen, rnd.nextLong() and ((1L shl (8 * pnLen)) - 1), fr.toByteArray(),
                tail = if (rnd.nextInt(3) == 0) ByteArray(rnd.nextInt(200)).also { rnd.nextBytes(it) } else null)
            try {
                val got = QuicInitial.peekSni(pkt, 0, pkt.size)
                if (got == null) { nulls++; if (first.length < 300) first.append("null host=$host pieces=${pieces.size} pnLen=$pnLen; ") }
                else if (got != host) { wrong++; if (first.length < 300) first.append("yanlış $got != $host; ") }
                val re = QuicInitial.reorder(pkt, 0, pkt.size)
                if (re != null) {
                    reN++
                    val back = QuicInitial.parse(re, 0, re.size)?.let { QuicInitial.frames(it.plain) }?.let { QuicInitial.assemble(it) }
                    if (back == null || !back.contentEquals(h) || re.size != pkt.size) reBad++
                }
                val fk = QuicInitial.fake(pkt, 0, pkt.size)
                if (fk != null) {
                    val fh = QuicInitial.parse(fk, 0, fk.size)?.let { QuicInitial.frames(it.plain) }?.let { QuicInitial.assemble(it) }
                    fkN++
                    val s2 = fh?.let { QuicInitial.sni(it) }
                    if (fh == null || s2 == null || fh.size != h.size || fk.size != pkt.size || s2[1] != host.length || !String(fh, s2[0], s2[1]).endsWith(".iana.org")) fkBad++
                }
            } catch (t: Throwable) { thrown++; if (first.length < 300) first.append("istisna $t; ") }
        }
        T.check("$total rastgele geçerli Initial: SNI her zaman doğru okunur (yanlış=$wrong, okunamayan=$nulls)", wrong == 0 && nulls == 0 && thrown == 0, first.toString())
        T.check("reorder çıktısı aynı ClientHello'yu verir, boyut aynı kalır", reBad == 0, "bozuk=$reBad")
        T.check("fake çıktısı aynı boyutta, SNI'sı iana.org alt alanı", fkBad == 0, "bozuk=$fkBad")
        T.check("test boş değil: reorder ($reN) ve fake ($fkN) çıktıların çoğu üretildi", reN > total / 4 && fkN > total / 4, "reN=$reN fkN=$fkN / $total")
    }

    T.group("Sızma 2 / QUIC Initial: şifresiz yükü bozulmuş (GCM geçerli) Initial'lar — istisna yok, yanlış ad yok, bellek sınırlı")
    run {
        var thrown = 0; var wrongName = 0; var parsedN = 0; var frOk = 0; var frNull = 0
        val first = StringBuilder()
        val host = "hedef.example"
        val h = hello(host)
        val good = cryptoFrame(0, h)
        val t0 = System.nanoTime()
        for (iter in 0 until DEEP_X * 3000) {
            val m = good.copyOf()
            when (rnd.nextInt(6)) {
                0 -> repeat(1 + rnd.nextInt(6)) { m[rnd.nextInt(m.size)] = rnd.nextInt().toByte() }
                1 -> { val at = rnd.nextInt(minOf(m.size, 12)); m[at] = rnd.nextInt().toByte() }                 // çerçeve tipi/ofset/uzunluk
                2 -> { m[1] = 0xFF.toByte(); m[2] = 0xFF.toByte() }                                                 // devasa ofset
                3 -> { m[3] = 0xFF.toByte() }                                                                        // devasa uzunluk
                4 -> { val cut = rnd.nextInt(m.size); for (i in cut until m.size) m[i] = 0 }                         // kesik + dolgu
                else -> { for (k in 0 until 3) m[rnd.nextInt(8)] = (rnd.nextInt(4) * 0x40 + rnd.nextInt(64)).toByte() }   // değişken uzunluklu tamsayı biçimleri
            }
            try { val f = QuicInitial.frames(m); if (f == null) frNull++ else { frOk++; QuicInitial.assemble(f) } }
            catch (t: Throwable) { thrown++; if (first.length < 300) first.append("frames/assemble: $t; ") }
            val pkt = try { buildInitial(dcid(), ByteArray(0), 4, 0, m) } catch (t: Throwable) { continue }
            try {
                val got = QuicInitial.peekSni(pkt, 0, pkt.size)
                if (got != null) { parsedN++; if (got != host && m.contentEquals(good)) wrongName++ }
            } catch (t: Throwable) { thrown++; if (first.length < 300) first.append("$t; ") }
        }
        val ms = (System.nanoTime() - t0) / 1_000_000
        T.check("bozuk çerçeveli Initial'larda istisna yok ($ms ms)", thrown == 0 && wrongName == 0, "istisna=$thrown yanlış=$wrongName $first")
        T.check("test boş değil: bozuk yüklerin bir kısmı çerçeve olarak geçerli ($frOk), bir kısmı reddedilir ($frNull)", frOk > 50 && frNull > 50, "frOk=$frOk frNull=$frNull parsed=$parsedN")
    }

    T.group("Sızma 2 / QUIC assemble: ${DEEP_X * 3000} rastgele çerçeve kümesi, bağımsız referansla birebir (çakışma/boşluk/sıra)")
    run {
        var diff = 0; var conflicts = 0; var gaps = 0; var oks = 0; var thrown = 0
        val first = StringBuilder()
        for (iter in 0 until DEEP_X * 3000) {
            val base = ByteArray(20 + rnd.nextInt(300)).also { rnd.nextBytes(it) }
            val fr = ArrayList<QuicInitial.Crypto>()
            val k = 1 + rnd.nextInt(6)
            var pos = 0
            for (j in 0 until k) {
                val from = if (rnd.nextInt(3) == 0) rnd.nextInt(base.size) else pos
                val to = minOf(base.size, from + 1 + rnd.nextInt(base.size))
                val d = base.copyOfRange(from, to)
                if (rnd.nextInt(5) == 0 && d.isNotEmpty()) d[rnd.nextInt(d.size)] = rnd.nextInt().toByte()   // çakışırsa çelişki yaratabilir
                fr.add(QuicInitial.Crypto(from, d)); pos = maxOf(pos, to)
            }
            fr.shuffle(rnd)
            // referans: bayt haritası, çelişki → null, boşluk → null
            val ref = HashMap<Int, Byte>(); var conflict = false; var end = 0
            for (c in fr) for (i in c.data.indices) { val at = c.offset + i; val v = ref[at]; if (v != null && v != c.data[i]) conflict = true else ref[at] = c.data[i]; end = maxOf(end, at + 1) }
            val expect: ByteArray? = if (conflict || (0 until end).any { it !in ref }) null else ByteArray(end) { ref[it]!! }
            val got = try { QuicInitial.assemble(fr) } catch (t: Throwable) { thrown++; continue }
            val same = if (expect == null) got == null else got != null && got.contentEquals(expect)
            if (!same) { diff++; if (first.length < 300) first.append("fark: k=$k conflict=$conflict beklenen=${expect?.size} gelen=${got?.size}; ") }
            if (expect != null) oks++ else if (conflict) conflicts++ else gaps++
        }
        T.check("assemble, referansla her kümede aynı sonucu verir", diff == 0 && thrown == 0, "fark=$diff istisna=$thrown $first")
        T.check("test boş değil: geçerli ($oks), çelişkili ($conflicts) ve boşluklu ($gaps) kümeler var", oks > 100 && conflicts > 100 && gaps > 100, "oks=$oks conflicts=$conflicts gaps=$gaps")
        T.check("boş çerçeve listesi null", QuicInitial.assemble(emptyList()) == null)
    }
}
