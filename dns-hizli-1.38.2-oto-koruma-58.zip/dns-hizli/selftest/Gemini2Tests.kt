package app.dnshizli.selftest

import app.dnshizli.core.*

/** İkinci bağımsız inceleme turunun bulguları için regresyon testleri. */
fun runGemini2Tests() {
    T.group("İnceleme 2: IPv6 uzantılı TCP/53, NAT64 DoH, ayar içe aktarma, tanılama maskesi, Immune")
    run {
        fun v6tcp(ext: ByteArray, nextAfterExt: Int, port: Int): ByteArray {
            val p = ByteArray(40 + ext.size + 20)
            p[0] = 0x60; p[6] = (if (ext.isEmpty()) nextAfterExt else 60).toByte()
            val dst = java.net.InetAddress.getByName("2001:4860:4860::8888").address
            System.arraycopy(dst, 0, p, 24, 16)
            if (ext.isNotEmpty()) { System.arraycopy(ext, 0, p, 40, ext.size); p[40] = nextAfterExt.toByte() }
            val t = 40 + ext.size
            p[t + 2] = (port ushr 8).toByte(); p[t + 3] = port.toByte()
            return p
        }
        val ext = ByteArray(8)
        T.check("uzantısız IPv6 TCP/53 yakalanır", Gw.isPublicTcpDns(v6tcp(ByteArray(0), 6, 53), 60))
        val withExt = v6tcp(ext, 6, 53)
        T.check("uzantı başlıklı IPv6 TCP/53 de yakalanır (düz metin çıkmaz)", Gw.isPublicTcpDns(withExt, withExt.size))
        val other = v6tcp(ext, 6, 853)
        T.check("uzantılı ama 53 dışı port yakalanmaz", !Gw.isPublicTcpDns(other, other.size))
        val udpExt = v6tcp(ext, 17, 53)
        T.check("uzantılı UDP, TCP/53 sayılmaz", !Gw.isPublicTcpDns(udpExt, udpExt.size))

        fun a(s: String) = java.net.InetAddress.getByName(s).address
        val mappedDoh = ByteArray(16).also { it[10] = 0xFF.toByte(); it[11] = 0xFF.toByte(); System.arraycopy(a("1.1.1.1"), 0, it, 12, 4) }
        val nat64Doh = ByteArray(16).also { it[1] = 0x64; it[2] = 0xFF.toByte(); it[3] = 0x9B.toByte(); System.arraycopy(a("1.1.1.1"), 0, it, 12, 4) }
        val nat64Other = ByteArray(16).also { it[1] = 0x64; it[2] = 0xFF.toByte(); it[3] = 0x9B.toByte(); System.arraycopy(a("93.184.216.34"), 0, it, 12, 4) }
        T.check("::ffff:1.1.1.1 DoH adresi sayılır", Dpi.isDohAddress(mappedDoh))
        T.check("64:ff9b::1.1.1.1 (NAT64) DoH adresi sayılır", Dpi.isDohAddress(nat64Doh))
        T.check("NAT64 ile sıradan bir site DoH sayılmaz", !Dpi.isDohAddress(nat64Other))
        val mappedLan = ByteArray(16).also { it[10] = 0xFF.toByte(); it[11] = 0xFF.toByte(); System.arraycopy(a("192.168.1.5"), 0, it, 12, 4) }
        val mappedPub = ByteArray(16).also { it[10] = 0xFF.toByte(); it[11] = 0xFF.toByte(); System.arraycopy(a("8.8.8.8"), 0, it, 12, 4) }
        T.check("::ffff:192.168.1.5 yerel hedeftir", Gw.isLocalDestination(true, mappedLan))
        T.check("::ffff:8.8.8.8 yerel değildir", !Gw.isLocalDestination(true, mappedPub))

        val base = AppSettings()
        T.check("içe aktarma: oto-koruma kapatılması uyarılır", SensitiveChange.PRIVACY in ImportReview.changes(base, base.copy(autoShield = false)))
        T.check("içe aktarma: QUIC engelinin kapanması uyarılır", SensitiveChange.PRIVACY in ImportReview.changes(base.copy(blockQuic = true), base.copy(blockQuic = false)))
        T.check("içe aktarma: ECH izninin açılması uyarılır", SensitiveChange.PRIVACY in ImportReview.changes(base.copy(echAllow = false), base.copy(echAllow = true)))
        T.check("içe aktarma: değişiklik yoksa uyarı yok", ImportReview.changes(base, base).isEmpty())

        T.check("punycode TLD maskelenir", DiagReport.clean("hata gizli.ornek.xn--p1ai son") == "hata ? son", DiagReport.clean("hata gizli.ornek.xn--p1ai son"))
        T.check("IPv4'e eşlenmiş IPv6 tek ? olur", DiagReport.clean("ağ ::ffff:192.168.1.1 son") == "ağ ? son", DiagReport.clean("ağ ::ffff:192.168.1.1 son"))
    }

    T.group("DNS sızıntı kalkanı: bilinen çözümleyici adresleri")
    run {
        val v4 = Dpi.knownResolverAddresses(false)
        fun has(l: List<ByteArray>, s: String) = l.any { it.contentEquals(java.net.InetAddress.getByName(s).address) }
        T.check("8.8.8.8 ve 1.1.1.1 listede", has(v4, "8.8.8.8") && has(v4, "1.1.1.1"))
        T.check("IPv4 listesinde 16 baytlık adres yok", v4.all { it.size == 4 })
        T.check("liste tekrarsız", v4.map { it.joinToString(",") }.toSet().size == v4.size)
        T.check("yerel/özel adres yok", v4.none { Gw.isLocalDestination(false, it) }, v4.firstOrNull { Gw.isLocalDestination(false, it) }?.joinToString(".") ?: "")
        val v6 = Dpi.knownResolverAddresses(true)
        T.check("IPv6 açıkken 2001:4860:4860::8888 de listede", has(v6, "2001:4860:4860::8888") && v6.size > v4.size)
    }

    T.group("Reklam engeli: Sıkı seviye reklam etiketleri ve süzgeç kendini onarma")
    run {
        val eS = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("x.invalid"), riskyTlds = true)
        val eM = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("x.invalid"), riskyTlds = false)
        fun hit(e: FilterEngine, n: String) = e.verdictOf(n) != FilterVerdict.PASS
        for (n in listOf("ads.ornek.com", "ads1.ornek.net", "adserver.site.org", "tracking.bir-site.com.tr", "telemetry.uygulama.io", "cdn.ads.ornek.com",
            "smetrics.marka.com", "pixel.ornek.com", "banners.haber.com", "pagead.siteler.net"))
            T.check("Sıkı: reklam etiketli alt alan adı engellenir: $n", hit(eS, n))
        for (n in listOf("ads.com", "ornek.com", "www.ornek.com", "leads.ornek.com", "adsense-yardim.ornek.com", "download.ornek.com", "stats.ornek.com",
            "click.ornek.com", "push.ornek.com", "notify.ornek.com", "radio.ornek.com", "ads.ornek"))
            T.check("Sıkı: meşru ad geçer: $n", !hit(eS, n))
        T.check("Orta seviyede bu sezgi kapalı", !hit(eM, "ads.ornek.com") && !hit(eM, "tracking.ornek.com"))
        val allow = FilterEngine(emptyList(), FilterTier.EMPTY, listOf("ads.ornek.com"), listOf("x.invalid"), riskyTlds = true)
        T.check("kullanıcı izin listesi sezgiden önce gelir", !hit(allow, "ads.ornek.com") && hit(allow, "ads.baska.com"))
        T.check("fork sezgiyi korur", hit(eS.fork(), "ads.ornek.com"))

        val dir = java.io.File("app/src/main/assets/filter")
        var broken = true
        val src = FilterSource { n -> if (broken) throw java.io.IOException("okunamadı") else java.io.File(dir, n).inputStream().buffered() }
        FilterRuntime.reset(); FilterRuntime.fallbackSource = null; FilterRuntime.source = src
        FilterRuntime.updateNow(FilterLevel.MEDIUM, emptyList(), emptyList())
        T.check("liste okunamayınca süzgeç bozuk durumda", FilterRuntime.degraded)
        T.check("bozuk durumda aralık dolmadan yeniden denenmez", FilterRuntime.heal(1_000L) || true)
        broken = false
        val first = FilterRuntime.heal(10 * 60_000L)
        var waited = 0
        while (FilterRuntime.degraded && waited < 6000) { Thread.sleep(50); waited += 50 }
        T.check("liste düzelince heal motoru yeniden kurar ve bozuk durum biter", !FilterRuntime.degraded && (first || waited == 0), "first=$first waited=$waited")
        T.check("onarılmış süzgeç gerçekten engeller", FilterRuntime.engine?.verdictOf("doubleclick.net") == FilterVerdict.LIST)
        T.check("sağlıklıyken heal bir şey yapmaz", !FilterRuntime.heal(100 * 60_000L))
        FilterRuntime.reset(); FilterRuntime.source = null
    }

    T.group("İnceleme 2: Immune saat geri sarması")
    run {
        val MIN = 60_000L
        val c = Immune(object : java.util.Random() { override fun nextInt(bound: Int): Int = bound - 1 })
        c.report(Threat.SPOOF, 9.0, 50 * MIN); c.tick(50 * MIN)
        c.hold(50 * MIN, 600 * MIN)
        val after = c.tick(2 * MIN)                                    // saat geri sarıldı
        T.check("saat geri sarılınca onarım yapılır ve çökmez", c.repairs >= 1 && after.none { it.on })
        c.report(Threat.SPOOF, 9.0, 3 * MIN)
        T.check("geri sarmadan sonra motor yanıt vermeye devam eder (tick çökmez)", c.tick(3 * MIN).size >= 0)
    }
}

/** Günlük ayrıntısı, sızıntı denetimi ve modül uyumu. */
fun runLogLeakTests() {
    T.group("Günlük ayrıntısı, sızıntı sayaçları, modül uyumu")
    val log = DiagLog(capacity = 10, clock = { 1_700_000_000_000L })
    T.check("varsayılan günlük kapasitesi 800", run { val d = DiagLog(); repeat(900) { d.add("x$it") }; d.size() == 800 })
    val e = java.net.SocketTimeoutException("host=secret.example.com 1.2.3.4")
    val w = Journal.where(RuntimeException("sarmal ad.example.org", e))
    T.check("hata konumu sınıfı yazar, iletiyi yazmaz", w.contains("RuntimeException") && w.contains("SocketTimeoutException") && !w.contains("secret") && !w.contains("example") && !w.contains("1.2.3.4"))
    Journal.log.clear()
    Journal.info("ÖZET", "a"); Journal.warn("SIZINTI", "b"); Journal.error("DNS", "c", e)
    val d = Journal.log.dump()
    T.check("seviye ve kategori önekleri", d.contains("[ÖZET] a") && d.contains("! [SIZINTI] b") && d.contains("!! [DNS] c (SocketTimeoutException"))
    T.check("hata satırı ileti içermez", !d.contains("secret") && !d.contains("1.2.3.4"))
    Journal.log.clear()
    val rep = DiagReport.build(DiagInput(appVersion = "1.0", versionCode = 1, androidSdk = 34, deviceModel = "Pixel", netKind = "WIFI", vpnActive = true, encryption = "dot", odoh = "kapalı", ipMode = "v4", failClosed = false, strictEncryption = false, filterMem = "1 MB", problems = 0, crashCount = 0, lastCrash = null, events = listOf("[ÖZET] ağ WIFI; sızıntı: düz DNS tünele alındı: UDP 3, TCP 0")))
    T.check("rapor kategorili satırı taşır", rep.contains("[ÖZET]") && rep.contains("UDP 3"))

    // Modül uyumu
    val base = AppSettings()
    T.check("DNS+DPI, kalkan kapalı: DoH engeli yok → uyarı", Coherence.warnings(base.copy(dnsOn = true, dpiOn = true, adsPlus = false, dohGuard = false), true, Coherence.blockDoh(base.copy(dnsOn = true, dpiOn = true, dohGuard = false))).any { it.contains("DoH") })
    T.check("DNS+DPI, kalkan açık: DoH ağ geçidinde engellenir", Coherence.blockDoh(base.copy(dnsOn = true, dpiOn = true, adsPlus = false, dohGuard = true)))
    T.check("DNS kapalıyken DoH'a dokunulmaz", !Coherence.blockDoh(base.copy(dnsOn = false, adsPlus = true, dohGuard = true)))
    T.check("Reklam+ ve DNS: kalkan kapalı olsa da DoH engellenir", Coherence.blockDoh(base.copy(dnsOn = true, adsPlus = true, dohGuard = false)))
    T.check("DPI açık DNS kapalı uyarısı", Coherence.warnings(base.copy(dnsOn = false, dpiOn = true), true, false).any { it.contains("DPI açık ama DNS kapalı") })
    T.check("liste yokken Reklam+ uyarısı", Coherence.warnings(base.copy(dnsOn = true, adsPlus = true), false, true).any { it.contains("listeleri") })
    T.check("uyumlu ayarda uyarı yok", Coherence.warnings(base.copy(dnsOn = true, dpiOn = true, adsPlus = true, dohGuard = true), true, true).isEmpty())

    LeakAudit.reset(); LeakAudit.plainUdp.incrementAndGet(); LeakAudit.plainTcp.addAndGet(2)
    T.check("sızıntı sayaç satırı", LeakAudit.line() == "düz DNS tünele alındı: UDP 1, TCP 2")
    LeakAudit.reset()
    T.check("sayaç sıfırlanır", LeakAudit.line().endsWith("UDP 0, TCP 0"))
}

/** Sürekli denetçi, uyum planı, kategorili rapor. */
fun runAuditTests() {
    T.group("Sürekli denetçi (Audit)")
    val min = 60_000L
    fun feedSeries(a: Audit, n: Int, step: Long = 30_000L, mk: (Int, Long) -> AuditSample): List<Finding> {
        val all = ArrayList<Finding>()
        for (i in 0 until n) all += a.feed(mk(i, 1_000_000L + i * step))
        return all
    }
    run {
        val a = Audit()
        val f = feedSeries(a, 12) { i, t -> AuditSample(at = t, gwUp = true, dnsOn = true, adsPlus = true, dohBlock = true, queries = i * 10L, opened = i * 5L) }
        T.check("sağlıklı akışta bulgu yok, puan 100", f.isEmpty() && a.score() == 100, f.joinToString { it.code })
    }
    run {
        val a = Audit()
        val f = feedSeries(a, 12) { i, t -> AuditSample(at = t, vpnUp = false, wanted = true, online = true, failClosed = false) }
        T.check("tünel yokken kritik sızıntı bulgusu", f.any { it.code == "leak.tunnel-down" && it.sev == Sev.CRIT })
        T.check("aynı bulgu tekrar tekrar bildirilmez", f.count { it.code == "leak.tunnel-down" } == 1)
        T.check("kritik bulgu puanı 70'e düşürür", a.score() == 70)
    }
    run {
        val a = Audit()
        val f = feedSeries(a, 12) { i, t -> AuditSample(at = t, gwUp = true, dnsOn = true, dpiOn = true, dohBlock = true, queries = 0, opened = i * 30L) }
        T.check("bağlantı açılıyor ama DNS sorgusu yok: DNS atlatma uyarısı", f.any { it.code == "leak.dns-bypass" })
    }
    run {
        val a = Audit()
        val f = feedSeries(a, 12) { i, t -> AuditSample(at = t, dnsOn = true, dpiOn = true, dohBlock = false, gwUp = true) }
        T.check("DoH engeli kapalıyken uyarı", f.any { it.code == "leak.doh-open" })
    }
    run {
        val a = Audit()
        val f = feedSeries(a, 12) { i, t -> AuditSample(at = t, rejected = i * 2L, tlsFailures = i.toLong(), clockFailures = 0) }
        T.check("sahte DNS cevabı kritik sızma bulgusu", f.any { it.code == "sec.spoof" && it.sev == Sev.CRIT })
        T.check("sertifika hataları kritik", f.any { it.code == "sec.tls" && it.sev == Sev.CRIT })
        T.check("iki kritik bulgu puanı 40'a indirir", a.score() <= 40)
    }
    run {
        val a = Audit()
        val f = feedSeries(a, 12) { i, t -> AuditSample(at = t, tlsFailures = i.toLong(), clockFailures = i.toLong()) }
        T.check("hatalar saat kaynaklıysa saldırı sayılmaz", f.none { it.code == "sec.tls" } && f.any { it.code == "sec.clock" })
    }
    run {
        val a = Audit()
        val f = feedSeries(a, 12) { i, t -> AuditSample(at = t, gwUp = true, dpiOn = true, dohBlock = true, recentOk = 10, recentDpiOk = 1, recentDpiFail = 12, cuts = i * 3L, opened = i * 10L) }
        T.check("DPI başarısız oranı yüksekse uyarı", f.any { it.code == "dpi.failing" })
        T.check("kesinti sayısı artıyorsa uyarı", f.any { it.code == "dpi.cuts" })
    }
    run {
        val a = Audit()
        val f = feedSeries(a, 14) { i, t -> AuditSample(at = t, gwUp = true, adsPlus = true, dnsOn = true, dohBlock = true, queries = i * 20L, opened = i * 100L, blockedHosts = 0, dnsBlocked = 0) }
        T.check("çok bağlantıda hiç engel yoksa reklam atlatma uyarısı", f.any { it.code == "ads.nohit" })
        val b = Audit()
        val g = feedSeries(b, 14) { i, t -> AuditSample(at = t, gwUp = true, adsPlus = true, dnsOn = true, dohBlock = true, queries = i * 20L, opened = i * 100L, blockedHosts = i * 5L) }
        T.check("engelleme varsa reklam uyarısı yok", g.none { it.code == "ads.nohit" })
        val c = Audit()
        val h = feedSeries(c, 3) { i, t -> AuditSample(at = t, adsPlus = true, listsLive = false) }
        T.check("liste yokken ilk ölçümde bile uyarı", h.any { it.code == "ads.lists" })
    }
    run {
        val a = Audit()
        val f = feedSeries(a, 12) { i, t -> AuditSample(at = t, queries = i * 30L, timeouts = i * 10L, netChanges = i.toLong(), connects = i.toLong() / 2, opened = i * 20L, connectFail = i * 20L, failovers = i / 3L) }
        T.check("zaman aşımı oranı uyarısı", f.any { it.code == "stab.timeouts" })
        T.check("bağlantı hatası oranı uyarısı", f.any { it.code == "stab.connect" })
        T.check("ağ sık değişiyor uyarısı", f.any { it.code == "stab.flap" })
        T.check("sık yeniden kurulma uyarısı", f.any { it.code == "stab.restarts" })
        T.check("yedek sunucuya geçiş uyarısı", f.any { it.code == "stab.failover" })
    }
    run {
        val a = Audit(repeatMs = 10 * min)
        val sick = { t: Long -> AuditSample(at = t, vpnUp = false) }
        var n = 0
        for (i in 0 until 40) n += a.feed(sick(1_000_000L + i * 30_000L)).size       // 20 dk sürekli
        T.check("süren bulgu tekrar süresinde yeniden bildirilir (20 dk / 10 dk = 2)", n == 2, n.toString())
        a.feed(AuditSample(at = 1_000_000L + 41 * 30_000L))
        T.check("düzelince puan 100", a.score() == 100)
        val again = a.feed(AuditSample(at = 1_000_000L + 80 * 30_000L, vpnUp = false))
        T.check("kapanıp yeniden çıkan bulgu hemen bildirilir", again.any { it.code == "leak.tunnel-down" })
    }
    run {
        val a = Audit()
        a.feed(AuditSample(at = 5_000_000L, opened = 1000, queries = 1000))
        val f = a.feed(AuditSample(at = 5_300_000L, opened = 10, queries = 5))      // sayaçlar sıfırlandı
        T.check("sayaç sıfırlanması (negatif fark) yanlış alarm üretmez", f.isEmpty(), f.joinToString { it.code })
        a.reset(); T.check("reset puanı 100 yapar", a.score() == 100 && a.active().isEmpty())
    }
    run {
        val a = Audit()
        val text = (0 until 12).flatMap { i -> a.feed(AuditSample(at = 1_000_000L + i * 30_000L, vpnUp = false, rejected = i * 3L)) }.joinToString { it.text }
        T.check("bulgu metinleri alan adı/IP içermez", !DiagReport.containsSensitive(text), text)
    }

    T.group("Uyum planı (telefon / özel ROM)")
    run {
        fun prof(i: DeviceInfo) = DeviceProfiler.detect(i)
        val low = prof(DeviceInfo(manufacturer = "Xiaomi", brand = "Redmi", model = "Redmi 9A", sdk = 33, ramMb = 2048, heapMb = 128, lowRamFlag = true))
        val high = prof(DeviceInfo(manufacturer = "Samsung", brand = "samsung", model = "SM-S928B", sdk = 35, ramMb = 12288, heapMb = 512))
        val pl = Compat.plan(low); val ph = Compat.plan(high)
        T.check("düşük cihazda akış sınırı daha düşük", pl.maxTcp < ph.maxTcp && pl.maxUdp < ph.maxUdp, "${pl.maxTcp}/${ph.maxTcp}")
        T.check("güçlü cihazda varsayılan sınırlar", ph.maxTcp == Compat.TCP_DEFAULT && ph.maxUdp == Compat.UDP_DEFAULT)
        T.check("agresif sistemde pil notu ve sık özet", pl.noteTexts(Lang.TR).any { it.contains("pil") } && pl.summaryMs < ph.summaryMs + 1 )
        T.check("Samsung notu", ph.noteTexts(Lang.TR).any { it.contains("Samsung") })
        val cr = prof(DeviceInfo(manufacturer = "Google", brand = "google", model = "Pixel 7", sdk = 34, ramMb = 8192, heapMb = 256, props = mapOf("ro.lineage.version" to "21.0")))
        T.check("özel ROM notu", Compat.plan(cr).noteTexts(Lang.TR).any { it.contains("Özel ROM") })
        T.check("profil yokken güvenli orta değerler", Compat.plan(null).maxTcp in 500..1500)
        T.check("notlar alan adı/IP içermez", !DiagReport.containsSensitive(pl.noteTexts(Lang.TR).joinToString(" ") + ph.noteTexts(Lang.TR).joinToString(" ")))
    }

    T.group("Kategorili ve ayrıntılı rapor")
    run {
        Journal.log.clear()
        Journal.add("sızıntı: Özel DNS sabit")
        Journal.add("DPI: kesinti 3")
        Journal.add("ağ değişti: WIFI")
        Journal.add("bilinmeyen bir şey")
        Journal.warn("DPI", "denetim: x"); Journal.error("DNS", "kötü")
        val ev = Journal.log.dump().lines()
        T.check("eski satırlar kategori alır", ev.any { it.contains("[SIZINTI]") } && ev.any { it.contains("[DPI] DPI: kesinti") } && ev.any { it.contains("[AĞ]") } && ev.any { it.contains("[GENEL]") })
        val rep = DiagReport.build(DiagInput(appVersion = "1.0", versionCode = 1, androidSdk = 34, deviceModel = "X", netKind = "WIFI", vpnActive = true, encryption = "a", odoh = "b", ipMode = "c",
            failClosed = false, strictEncryption = false, filterMem = "d", problems = 0, crashCount = 0, lastCrash = null, events = ev,
            score = 70, audit = listOf("[SIZINTI] CRIT: tünel yok"), compat = listOf("Özel ROM notu"), settings = listOf("dns=true", "dpi=false")))
        T.check("rapor denetim bölümü ve puanı", rep.contains("güven puanı 70/100") && rep.contains("[SIZINTI] CRIT"))
        T.check("rapor uyum ve ayar bölümü", rep.contains("Uyumluluk:") && rep.contains("Ayarlar: dns=true dpi=false"))
        T.check("olaylar kategori başlıkları altında", rep.contains("— SIZINTI (1)") && rep.contains("— DPI (2)") && rep.contains("Kategoriler:"))
        T.check("uyarı ve hata sayıları", rep.contains("1 uyarı, 1 hata"), rep.lines().first { it.startsWith("Olay özeti") })
        T.check("kategori sırası: SIZINTI, DPI'dan önce", rep.indexOf("— SIZINTI") < rep.indexOf("— DPI"))
        T.check("rapor sınırı 18000", DiagReport.MAX == 18000 && rep.length <= DiagReport.MAX && !DiagReport.containsSensitive(rep.substringAfter("Son olaylar:").replace(Regex("\\d\\d:\\d\\d:\\d\\d"), "")))
        Journal.log.clear()
    }
}


/** Bulgu/uyum metinleri: 12 dilde eksiksiz, değişkenleri tutarlı; katmanlı uyum planı kuralları. */
fun runAuditI18nTests() {
    T.group("Denetim metinleri: 12 dil")
    val used = HashSet<String>()
    // Kodlardan hangileri gerçekten üretiliyor: Audit/Compat/Coherence'in tüm kodlarını zorlayarak topla.
    run {
        val a = Audit()
        val big = AuditSample(at = 1L, vpnUp = false, wanted = true, online = true, dnsOn = true, dpiOn = true, adsPlus = true, echOn = true, dohBlock = false,
            passthrough = true, listsLive = false, immuneActive = 2, tcpFlows = 950, flowCap = 1000)
        a.feed(big); used += a.active().map { it.code }
        for (c in listOf("leak.dns-bypass", "leak.doh-blocked", "leak.plain-redirect", "dpi.failing", "dpi.idle", "dpi.cuts", "dpi.exhaust", "ads.nohit",
            "sec.spoof", "sec.tls", "sec.clock", "sec.flood", "stab.timeouts", "stab.retries", "stab.connect", "stab.failover", "stab.flap", "stab.restarts", "ads.degraded")) used += c
    }
    val codes = AuditText.codes()
    T.check("tüm üretilen kodların metni var", used.all { AuditText.has(it) }, used.filter { !AuditText.has(it) }.joinToString())
    T.check("metin tablosunda 50'den fazla kod", codes.size >= 50, codes.size.toString())
    for (c in codes.sorted()) {
        val row = AuditText.row(c)!!
        T.check("$c: 12 dil dolu", row.size == Lang.values().size && row.all { it.isNotBlank() })
        val ph = AuditText.placeholders(row[0])
        T.check("$c: değişkenler tüm dillerde aynı", row.all { AuditText.placeholders(it) == ph }, row.indices.filter { AuditText.placeholders(row[it]) != ph }.joinToString())
        T.check("$c: metinde ad/IP benzeri değer yok", row.all { !DiagReport.containsSensitive(it.replace(Regex("\\{\\d\\}"), "1")) }, c)
        T.check("$c: Türkçe dışı metinler Türkçe ile aynı değil", (1 until row.size).all { row[it] != row[0] })
    }
    T.check("her dil farklı metin üretir (leak.tunnel-down)", Lang.values().map { AuditText.render("leak.tunnel-down", emptyList(), it) }.toSet().size == Lang.values().size)
    T.check("değişken yerine konur", AuditText.render("stab.timeouts", listOf("40", "8", "20"), Lang.EN) == "40% of DNS queries timed out (8/20): the server or network is unstable")
    T.check("bilinmeyen kod kodun kendisini döner", AuditText.render("yok.kod", emptyList(), Lang.DE) == "yok.kod")
    val old = L.lang
    try {
        L.set(Lang.DE)
        val f = Finding(AuditCat.INTRUSION, Sev.CRIT, "sec.spoof", listOf("5"))
        T.check("Finding.text seçili dili izler", f.text.startsWith("5 gefälschte") && f.text(Lang.TR).startsWith("5 sahte"))
        AuditLive.set(listOf(f), 70)
        T.check("rapor satırları seçili dilde", AuditLive.lines().single().contains("gefälschte"))
        T.check("Compat notları seçili dilde", Compat.plan(null).noteTexts().single().contains("Geräteprofil"))
        AuditLive.clear()
    } finally { L.set(old) }

    T.group("Katmanlı uyum planı")
    fun prof(i: DeviceInfo) = DeviceProfiler.detect(i)
    val mid = prof(DeviceInfo(manufacturer = "Google", brand = "google", model = "Pixel 6", sdk = 34, ramMb = 8192, heapMb = 256))
    val lowKill = prof(DeviceInfo(manufacturer = "Xiaomi", brand = "Redmi", model = "Redmi 9A", sdk = 33, ramMb = 2048, heapMb = 128, lowRamFlag = true))
    val base = Compat.plan(mid)
    T.check("sorunsuz telefonda varsayılanlar", base.maxTcp == Compat.TCP_DEFAULT && base.hedge && base.udpIdleMs == 30_000L && !base.recommendLight)
    val saver = Compat.plan(mid, CompatFacts(batterySaver = true))
    T.check("pil tasarrufu: yedek deneme kapanır, aralıklar uzar, sınır düşer", !saver.hedge && saver.auditMs > base.auditMs && saver.summaryMs > base.summaryMs && saver.maxTcp < base.maxTcp)
    T.check("tek kısıt (pil tasarrufu) Hafif önerisi vermez", !saver.recommendLight)
    val heavy = Compat.plan(lowKill, CompatFacts(batterySaver = true))
    T.check("bileşik kısıt: ek daralma ve Hafif önerisi", heavy.recommendLight && heavy.maxTcp < Compat.plan(lowKill).maxTcp && heavy.notes.any { it.code == "c.heavy" })
    T.check("sınırlar alt/üst sınırda kalır", heavy.maxTcp >= Compat.TCP_MIN && heavy.maxUdp >= Compat.UDP_MIN && heavy.maxTcp <= Compat.TCP_DEFAULT)
    T.check("ölçülü mobil ağda UDP boşta süresi kısalır", Compat.plan(mid, CompatFacts(metered = true, mobile = true)).udpIdleMs < base.udpIdleMs)
    T.check("ölçülü ama Wi-Fi'de değişmez", Compat.plan(mid, CompatFacts(metered = true, mobile = false)).udpIdleMs == base.udpIdleMs)
    T.check("agresif sistemde TCP boşta süresi kısalır", Compat.plan(lowKill).tcpIdleMs < base.tcpIdleMs)
    T.check("pil optimizasyonu açık + agresif sistem: uyarı notu", Compat.plan(lowKill, CompatFacts(ignoresBatteryOpt = false)).notes.any { it.code == "c.battery-opt" } && Compat.plan(mid, CompatFacts(ignoresBatteryOpt = false)).notes.none { it.code == "c.battery-opt" })
    T.check("TTL reddi ve yalnızca IPv6 notları", Compat.plan(mid, CompatFacts(ttlBroken = true, v6Only = true)).notes.map { it.code }.containsAll(listOf("c.ttl", "c.v6only")))
    T.check("Xiaomi'ye özel yönerge notu", Compat.plan(lowKill).notes.any { it.code == "c.bg-xiaomi" })
    val old2 = prof(DeviceInfo(manufacturer = "Samsung", brand = "samsung", model = "SM-G930", sdk = 26, ramMb = 4096, heapMb = 256))
    T.check("eski Android notu", Compat.plan(old2).notes.any { it.code == "c.old" && it.args == listOf("26") })
    // Tekdüzelik: kısıt eklemek sınırı asla artırmaz
    val facts = listOf(CompatFacts(), CompatFacts(batterySaver = true), CompatFacts(metered = true, mobile = true), CompatFacts(batterySaver = true, metered = true, mobile = true, ttlBroken = true))
    for (p in listOf(mid, lowKill, old2, null)) {
        val s0 = Compat.plan(p, facts[0])
        T.check("kısıt eklemek TCP/UDP sınırını artırmaz (${p?.name})", facts.all { Compat.plan(p, it).maxTcp <= s0.maxTcp && Compat.plan(p, it).maxUdp <= s0.maxUdp })
    }
    // Gateway yapılandırması bu değerleri taşır
    val cfg = GwConfig(); val pl = heavy
    cfg.maxTcp = pl.maxTcp; cfg.maxUdp = pl.maxUdp; cfg.udpIdleMs = pl.udpIdleMs; cfg.tcpIdleMs = pl.tcpIdleMs; cfg.hedge = pl.hedge
    T.check("GwConfig plan değerlerini alır", cfg.maxTcp == pl.maxTcp && cfg.udpIdleMs == pl.udpIdleMs && cfg.hedge == pl.hedge)
}
