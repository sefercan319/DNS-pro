package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

private fun labelsOf(rig: Rig): Set<String> {
    val page = rig.scene.currentPage as ScrollPage
    val seen = HashSet<String>()
    var last = -1f
    repeat(40) {
        for (i in rig.items()) seen.add(i.info.label)
        if (page.scrollOffset == last) return seen
        last = page.scrollOffset
        rig.drag(180f, rig.h * 0.7f, rig.h * 0.7f - 220f, 8)
    }
    return seen
}

private fun has(set: Set<String>, text: String) = set.any { it.contains(text) }

/** "Gelişmiş ayarları göster": varsayılan sade görünüm, anahtar açılınca teknik satırlar, ayar değeri gizliyken de korunur. */
fun runAdvancedUiTests() {
    T.group("Arayüz: Gelişmiş katmanı (varsayılan sade, anahtarla teknik satırlar)")
    T.check("varsayılan kapalı, dışa aktarılmaz, kayıtta korunur",
        !AppSettings().showAdvanced && !SettingsCodec.export(AppSettings(showAdvanced = true)).let { c -> Base64Mini.decode(c.removePrefix("DNSH1:"))!!.toString(Charsets.UTF_8).contains("showAdvanced") } &&
            SettingsCodec.decode(SettingsCodec.encode(AppSettings(showAdvanced = true))).showAdvanced)
    val imp = SettingsCodec.import("DNSH1:" + Base64Mini.encode("showAdvanced=true\nencryption=doh".toByteArray()), AppSettings())
    T.check("içe aktarma kodu 'gelişmiş' görünümü açamaz", imp != null && !imp.showAdvanced)

    fun sectionLabels(sec: Section, adv: Boolean, s: AppSettings = Rig.base().copy(showAdvanced = adv)): Set<String> {
        val rig = Rig(s); rig.scene.openSection(sec); rig.settle(900); return labelsOf(rig)
    }
    // (bölüm, her zaman görünen, yalnızca gelişmişte görünen)
    data class Case(val sec: Section, val basic: List<String>, val adv: List<String>)
    val cases = listOf(
        Case(Section.DNS, listOf(Strings.ENCRYPTION, Strings.CACHE, Strings.TEST, Strings.PROFILES), listOf(Strings.ODOH, Strings.IP_MODE, Strings.BACKUP_SERVER, Strings.RULE_WIFI, Strings.TROUBLE, Strings.REMEMBER_MODS)),
        Case(Section.CONNECTION, listOf(Strings.AUTO_CONNECT, Strings.AUTO_RECONNECT, Strings.FAIL_CLOSED, Strings.AUTO_SHIELD, Strings.APPS), listOf(Strings.AUTO_FASTEST, Strings.REFRESH_ON_NET, Strings.BLOCK_QUIC)),
        Case(Section.NOTIFICATIONS, listOf(Strings.NOTIFY_CONNECT, Strings.NOTIFY_DROP, Strings.LOCK_HIDE), listOf(Strings.NOTIFY_STOP, Strings.NOTIFY_TIMEOUT, Strings.QUIET_NOTIF)),
        Case(Section.SOUND, listOf(Strings.SOUND_ON, Strings.SOUND_PACK, Strings.SOUND_VOL, Strings.ANIM_SPEED), listOf(Strings.SOUND_UI, Strings.SOUND_CONN, Strings.TAP_FX, Strings.CELEBRATE)),
        Case(Section.FILTER, listOf(Strings.FILTER_LEVEL, Strings.FILTER_ALLOW, Strings.FILTER_BLOCK, Strings.DOH_GUARD), listOf(Strings.REBIND)),
    )
    for (c in cases) {
        val off = sectionLabels(c.sec, false); val on = sectionLabels(c.sec, true)
        T.check("${c.sec}: sade görünümde temel satırlar var", c.basic.all { has(off, it) }, c.basic.filter { !has(off, it) }.toString())
        T.check("${c.sec}: sade görünümde teknik satırlar yok", c.adv.none { has(off, it) }, c.adv.filter { has(off, it) }.toString())
        T.check("${c.sec}: gelişmiş açılınca teknik satırlar var", c.adv.all { has(on, it) }, c.adv.filter { !has(on, it) }.toString())
        T.check("${c.sec}: gelişmiş açılınca temel satırlar da durur", c.basic.all { has(on, it) })
        T.check("${c.sec}: sade görünüm gelişmişten kısa", off.size < on.size, "${off.size} < ${on.size}")
    }

    // Menü: sade görünümde Liste ve Deneysel yok; menüdeki anahtar açınca görünür, kapatınca gizlenir
    val rig = Rig(Rig.base().copy(showAdvanced = false))
    rig.scene.openMenu(); rig.settle(900)
    val m0 = labelsOf(rig)
    T.check("menü sade: Liste ve Deneysel yok, anahtar var", !has(m0, Strings.SEC_LIST) && !has(m0, Strings.SEC_EXPERIMENTAL) && has(m0, Strings.SHOW_ADVANCED) && has(m0, Strings.DNS_SETTINGS) && has(m0, Strings.ABOUT))
    rig.tapText(Strings.SHOW_ADVANCED, settleMs = 900)
    T.check("anahtara dokununca ayar açılır", rig.model.settings.showAdvanced)
    val m1 = labelsOf(rig)
    T.check("menü gelişmiş: Liste ve Deneysel görünür", has(m1, Strings.SEC_LIST) && has(m1, Strings.SEC_EXPERIMENTAL))
    rig.tapText(Strings.SHOW_ADVANCED, settleMs = 900)
    T.check("kapatınca tekrar gizlenir", !rig.model.settings.showAdvanced && !has(labelsOf(rig), Strings.SEC_EXPERIMENTAL))

    // Gizli satırın değeri etkisini korur: gelişmiş kapalıyken de ODoH tercihi ayarda durur
    val s = Rig.base().copy(showAdvanced = false, odoh = OdohMode.values().last())
    T.check("gizli ayar değeri korunur (kapatmak sıfırlamaz)", SettingsCodec.decode(SettingsCodec.encode(s)).odoh == s.odoh && !s.showAdvanced)
}
