package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicInteger

/**
 * Sızma girişimi 2 — ağ geçidi: kötü niyetli YEREL uygulama tünelden saldırır.
 *  1) Süzgeç atlatma (engelli adı sunucuya gizlice ulaştırma): başlık gizleme, yavaş damlatma, dev başlık, boşluklu SNI...
 *  2) Kaynak tüketme: akış tablosunu sessiz bağlantılarla doldurup öteki uygulamaları kilitleme (TCP ve UDP).
 *  3) TCP durum makinesi: kör RST, sıra dışı sel, örtüşen yeniden iletim, sıfır pencere, bayrak kombinasyonları, MSS ve sıra numarası taşması.
 * Her atlatma vektörü ayrı bir kontroldür; başarısız olan bir vektör gerçek bir açıktır.
 */

/** Sunucu: gelen baytları kaydeder; istenirse yankılar; [hold] doluysa bağlantıyı bu kadar açık tutar. */
internal class Sink(val echo: Boolean = false, val hold: Long = 0L) {
    private val got = ByteArrayOutputStream()
    val accepted = AtomicInteger()
    private val srv = Srv { s ->
        accepted.incrementAndGet()
        val b = ByteArray(8192); val i = s.getInputStream()
        val end = System.currentTimeMillis() + hold
        while (true) {
            val n = try { i.read(b) } catch (_: Exception) { -1 }
            if (n < 0) break
            synchronized(got) { got.write(b, 0, n) }
            if (echo) { s.getOutputStream().write(b, 0, n); s.getOutputStream().flush() }
        }
        val left = end - System.currentTimeMillis()
        if (left > 0) Thread.sleep(left)
    }
    val port get() = srv.port
    fun bytes(): ByteArray = synchronized(got) { got.toByteArray() }
    fun close() = srv.close()
}

private fun heapMb(): Long { System.gc(); System.gc(); val r = Runtime.getRuntime(); return (r.totalMemory() - r.freeMemory()) / (1024 * 1024) }

/** Engelli adlı bir ağ geçidi kurar. */
private fun blockingRig(vararg names: String): GRig {
    val r = GRig()
    r.gw.config.ads = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), names.toList())
    return r
}

private class Chunk(val data: ByteArray, val delayMs: Long = 0)
private fun s(text: String, delay: Long = 0) = Chunk(text.toByteArray(Charsets.ISO_8859_1), delay)

/** [segs] sırayla gönderilir; bağlantı RST ile kesildiyse ve sunucu hiçbir bayt almadıysa true (engellendi). */
private fun blocked(r: GRig, sink: Sink, segs: List<Chunk>, waitMs: Long = 1500): Boolean {
    val before = sink.bytes().size
    val c = GCli(r, sink.port)
    if (c.connect() == null) return true
    for (sg in segs) {
        if (sg.delayMs > 0) Thread.sleep(sg.delayMs)
        var o = 0
        while (o < sg.data.size) { val n = minOf(1400, sg.data.size - o); c.write(sg.data.copyOfRange(o, o + n)); o += n }
    }
    var rst = false
    val end = System.currentTimeMillis() + waitMs
    while (System.currentTimeMillis() < end) {
        val x = c.next(end - System.currentTimeMillis()) ?: break
        if (x.flags and F_RST != 0) { rst = true; break }
    }
    Thread.sleep(150)
    return rst && sink.bytes().size == before
}

fun runGatewayAbuseTests() {
    // ------------------------------------------------------------------------------------------------ 1) süzgeç atlatma
    T.group("Sızma 2 / Süzgeç atlatma: engelli adı gizleyerek göndermeyi deneyen uygulama")
    run {
        val r = blockingRig("reklam.example")
        val sink = Sink()
        val bad = "reklam.example"
        fun req(hostLines: String, line: String = "GET /x HTTP/1.1", extra: String = "") = "$line\r\n$hostLines$extra\r\n"
        val vectors = listOf(
            "düz Host" to listOf(s(req("Host: $bad\r\n"))),
            "BÜYÜK harfli HOST başlığı" to listOf(s(req("HOST: $bad\r\n"))),
            "değer öncesi sekme" to listOf(s(req("Host:\t$bad\r\n"))),
            "değer sonrası boşluklar" to listOf(s(req("Host:   $bad   \r\n"))),
            "port ekli" to listOf(s(req("Host: $bad:8080\r\n"))),
            "sondaki nokta (FQDN)" to listOf(s(req("Host: $bad.\r\n"))),
            "alt alan + sondaki nokta" to listOf(s(req("Host: cdn.$bad.\r\n"))),
            "çift Host: izinli ilk, engelli ikinci" to listOf(s(req("Host: guvenli.example.org\r\nHost: $bad\r\n"))),
            "çift Host: engelli ilk, izinli ikinci" to listOf(s(req("Host: $bad\r\nHost: guvenli.example.org\r\n"))),
            "başlık katlama (obs-fold): değer sonraki satırda" to listOf(s(req("Host:\r\n $bad\r\n"))),
            "başlık katlama: sekmeli devam satırı" to listOf(s(req("Host:\r\n\t$bad\r\n"))),
            "araya başka başlıklar" to listOf(s(req("Accept: */*\r\nUser-Agent: x\r\nHost: $bad\r\nConnection: close\r\n"))),
            "mutlak URI + izinli Host" to listOf(s(req("Host: guvenli.example.org\r\n", "GET http://$bad/ HTTP/1.1"))),
            "mutlak URI, kullanıcı bilgisi öneki" to listOf(s(req("Host: guvenli.example.org\r\n", "GET http://guvenli.example.org@$bad/ HTTP/1.1"))),
            "mutlak URI, BÜYÜK harfli şema" to listOf(s(req("Host: guvenli.example.org\r\n", "GET HTTP://${bad.uppercase()}/ HTTP/1.1"))),
            "CONNECT hedefi" to listOf(s(req("Host: guvenli.example.org\r\n", "CONNECT $bad:443 HTTP/1.1"))),
            "baştaki boş satırlar (RFC 9112 §2.2)" to listOf(s("\r\n\r\n" + req("Host: $bad\r\n"))),
            "tek baştaki CRLF" to listOf(s("\r\n" + req("Host: $bad\r\n"))),
            "WebDAV yöntemi (PROPFIND)" to listOf(s(req("Host: $bad\r\n", "PROPFIND /x HTTP/1.1"))),
            "TRACE yöntemi" to listOf(s(req("Host: $bad\r\n", "TRACE /x HTTP/1.1"))),
            "yöntem ve Host iki ayrı parça" to listOf(s("GET /x HT"), s("TP/1.1\r\nHo"), s("st: $bad\r\n\r\n")),
            "bayt bayt gönderim (hızlı)" to req("Host: $bad\r\n").map { Chunk(byteArrayOf(it.code.toByte())) },
            "yavaş damlatma: ilk parça sonra 700 ms bekle (HTTP)" to listOf(s("GET /x HTTP/1.1\r\n"), s("Host: $bad\r\n\r\n", 700)),
            "yavaş damlatma: Host adının ortasında 700 ms bekle" to listOf(s("GET /x HTTP/1.1\r\nHost: rek"), s("lam.example\r\n\r\n", 700)),
            "dev başlık: Host 17 KB sonra" to listOf(s("GET /x HTTP/1.1\r\n" + (1..17).joinToString("") { "X-Pad-$it: ${"a".repeat(1000)}\r\n" } + "Host: $bad\r\n\r\n")),
            "TLS düz SNI" to listOf(Chunk(testHello(bad))),
            "TLS BÜYÜK harfli SNI" to listOf(Chunk(testHello(bad.uppercase()))),
            "TLS sondaki noktalı SNI" to listOf(Chunk(testHello("$bad."))),
            "TLS alt alan + sondaki nokta" to listOf(Chunk(testHello("cdn.$bad."))),
            "TLS bayt bayt (hızlı)" to testHello(bad).map { Chunk(byteArrayOf(it)) },
            "TLS yavaş damlatma: 10 bayt sonra 700 ms bekle" to testHello(bad).let { h -> listOf(Chunk(h.copyOfRange(0, 10)), Chunk(h.copyOfRange(10, h.size), 700)) },
            "TLS yavaş damlatma: SNI'nın ortasında 700 ms bekle" to testHello(bad).let { h -> val cut = h.indexOfFirst2("reklam".toByteArray()) + 3; listOf(Chunk(h.copyOfRange(0, cut)), Chunk(h.copyOfRange(cut, h.size), 700)) },
        )
        for ((name, segs) in vectors) {
            val ok = blocked(r, sink, segs, waitMs = 5000)
            T.check("engelli ad gizlenemez: $name", ok, "engellenmedi: sunucu toplam ${sink.bytes().size} bayt aldı")
        }
        val c = GCli(r, sink.port); c.connect(); c.write(testHello("guvenli.example.org"))
        Thread.sleep(300)
        T.check("kontrol: engelli olmayan ad yine geçer (yanlış alarm yok)", sink.bytes().size > 100)
        sink.close(); r.close()
    }

    // ------------------------------------------------------------------------------------------------ 2) tablo doldurma
    T.group("Sızma 2 / Kaynak tüketme: sessiz bağlantılarla akış tablosunu doldurma")
    run {
        val r = GRig()
        r.gw.config.maxTcp = 30
        r.gw.config.evictIdleMs = 300
        val silent = Sink(hold = 60_000)
        val live = Sink(echo = true)
        val hogs = (1..30).map { GCli(r, silent.port).also { c -> c.connect() } }
        val victimCli = GCli(r, live.port)
        Thread.sleep(700)                       // sessizler boşta eşiğini aştı
        r.q.clear()
        victimCli.send(F_SYN, mss = 1460); victimCli.seq++
        val seen = ArrayList<ByteArray>()
        val until = System.currentTimeMillis() + 2500
        while (System.currentTimeMillis() < until) {
            val x = r.q.poll(100, java.util.concurrent.TimeUnit.MILLISECONDS) ?: if (seen.any { Packets.u16(it, 22) == victimCli.sport }) break else continue
            seen.add(x)
        }
        fun flagsOf(x: ByteArray) = x[33].toInt() and 0xFF
        val synAck = seen.firstOrNull { Packets.u16(it, 22) == victimCli.sport }
        val sa = synAck?.let { GSeg(flagsOf(it), Packets.i32(it, 24), Packets.i32(it, 28), 0, ByteArray(0), 0, true, 0, 0) }
        if (sa != null && sa.flags and F_SYN != 0) { victimCli.rcv = sa.seq + 1; victimCli.send(F_ACK) }
        T.check("tablo dolu: meşru yeni bağlantı kabul edilir (en eski sessiz akış tahliye edilir)", sa != null && sa.flags and F_SYN != 0 && sa.flags and F_RST == 0, "sa=${sa?.flags}")
        T.check("tahliye edilen sessiz akışa RST gider (uygulama bağlantının öldüğünü öğrenir)", seen.any { x -> flagsOf(x) and F_RST != 0 && hogs.any { it.sport == Packets.u16(x, 22) } }, "paket=${seen.size}")
        if (sa != null && sa.flags and F_RST == 0) {
            victimCli.write("merhaba".toByteArray())
            T.check("tahliyeden sonra meşru akış çalışır", String(victimCli.read(7)) == "merhaba")
        }
        T.check("tablo sınırı aşılmaz", r.gw.stats().tcpFlows <= 31, "akış=${r.gw.stats().tcpFlows}")
        // Üretken (veri alışverişi yapan) akış, saldırı sürerken tahliye edilmez.
        val prod = GCli(r, live.port); prod.connect(); prod.write("a".toByteArray()); prod.read(1)
        var survived = true
        for (round in 1..6) {
            for (k in 1..10) GCli(r, silent.port).connect()          // saldırı: yeni sessiz bağlantılar
            prod.write("b".toByteArray())
            if (String(prod.read(1)) != "b") { survived = false; break }
            Thread.sleep(150)
        }
        T.check("saldırı sürerken veri alışverişi yapan akış tahliye edilmez", survived)
        T.check("tablo hâlâ sınırlı", r.gw.stats().tcpFlows <= 31, "akış=${r.gw.stats().tcpFlows}")
        silent.close(); live.close(); r.close()
    }
    run {
        // UDP
        val r = GRig()
        r.gw.config.maxUdp = 20
        r.gw.config.evictIdleMs = 300
        val echo = DatagramSocket(0, InetAddress.getByAddress(LO4))
        Thread({ val b = ByteArray(1500); while (!echo.isClosed) { try { val p = DatagramPacket(b, b.size); echo.receive(p); echo.send(DatagramPacket(p.data, p.length, p.socketAddress)) } catch (_: Exception) {} } }, "udp-echo").also { it.isDaemon = true; it.start() }
        val buf = ByteArray(1500)
        fun send(sport: Int, data: ByteArray) { val n = Gw.udp(buf, false, CLI4, LO4, sport, echo.localPort, data, 0, data.size); r.gw.onPacket(buf.copyOf(n), n) }
        for (i in 1..20) send(30000 + i, byteArrayOf(i.toByte()))
        r.q.clear()
        Thread.sleep(700)
        send(31000, "canli".toByteArray())
        var a: ByteArray? = null
        val endAt = System.currentTimeMillis() + 2500
        while (a == null && System.currentTimeMillis() < endAt) { val x = r.q.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS) ?: continue; if (Packets.u16(x, 22) == 31000) a = x }
        T.check("UDP tablosu dolu: yeni (meşru) akışın paketi yine iletilir, eski boşta akış tahliye edilir", a != null && String(a, 28, a.size - 28) == "canli", "a=${a?.size}")
        T.check("UDP tablo sınırı aşılmaz", r.gw.stats().udpFlows <= 21, "akış=${r.gw.stats().udpFlows}")
        echo.close(); r.close()
    }

    // ------------------------------------------------------------------------------------------------ 3) TCP durum makinesi
    T.group("Sızma 2 / TCP durum makinesi: kör RST, sıra dışı sel, örtüşme, sıfır pencere, bayrak kombinasyonları")
    run {
        val r = GRig(); val sink = Sink(echo = true)
        val c = GCli(r, sink.port); c.connect(); c.write("hello".toByteArray())
        T.check("temel akış", String(c.read(5)) == "hello")
        repeat(300) { c.send(F_RST, seqNo = c.seq + 70_000 + it * 977) }       // pencere dışı (ileri)
        repeat(300) { c.send(F_RST, seqNo = c.seq - 5000 - it * 131) }         // pencere dışı (geri)
        c.write("world".toByteArray())
        T.check("pencere dışı RST'ler akışı öldürmez", String(c.read(5)) == "world")
        c.send(F_RST, seqNo = c.seq + 10)
        Thread.sleep(100)
        c.write("x".toByteArray())
        var gotRst = false
        for (k in 1..10) { val x = c.next(300) ?: break; if (x.flags and F_RST != 0) { gotRst = true; break } }
        T.check("pencere içi RST akışı kapatır", gotRst)
        sink.close(); r.close()
    }
    run {
        val r = GRig(); val sink = Sink(echo = true)
        val c = GCli(r, sink.port); c.connect(); c.write("A".toByteArray()); c.read(1)
        val base = heapMb()
        val junk = ByteArray(1000) { 0x41 }
        for (i in 0 until 20_000) { c.send(F_ACK or F_PSH, junk, seqNo = c.seq + 5000 + i * 1000); if (i % 500 == 0) r.q.clear() }
        r.q.clear()
        val grew = heapMb() - base
        T.check("20 bin sıra dışı segment bellek biriktirmez (< 40 MB, $grew MB)", grew < 40, "$grew MB")
        c.write("B".toByteArray())
        T.check("sel sonrası akış sağlıklı, ileri sıralı veri sunucuya hiç gitmedi", String(c.read(1)) == "B" && sink.bytes().contentEquals("AB".toByteArray()), String(sink.bytes()).take(20))
        sink.close(); r.close()
    }
    run {
        // örtüşen yeniden iletim: İLK kopya geçerli; sunucu ile süzgecin gördüğü bayt akışı aynı
        val r = GRig(); val sink = Sink()
        val c = GCli(r, sink.port); c.connect()
        val s0 = c.seq
        c.send(F_ACK or F_PSH, "AAAAABBBBB".toByteArray(), seqNo = s0)
        c.send(F_ACK or F_PSH, "XXXXXCCCCC".toByteArray(), seqNo = s0 + 5)          // 5..14: ilk 5 bayt örtüşür, farklı içerik
        c.send(F_ACK or F_PSH, "YYYYYYYYYYZ".toByteArray(), seqNo = s0 + 4)         // 4..14 daha örtüşme
        c.send(F_ACK or F_PSH, "DDDDD".toByteArray(), seqNo = s0 + 15)
        Thread.sleep(500)
        T.check("örtüşen yeniden iletimde İLK görülen bayt geçerli, yeni kısım eklenir", String(sink.bytes()) == "AAAAABBBBBCCCCCDDDDD", String(sink.bytes()))
        sink.close(); r.close()
    }
    run {
        // FIN sonrası veri, çift FIN, FIN+veri
        val r = GRig(); val sink = Sink(echo = true)
        val c = GCli(r, sink.port); c.connect(); c.write("one".toByteArray()); c.read(3)
        c.send(F_FIN or F_ACK); c.seq++
        c.send(F_ACK or F_PSH, "late".toByteArray())                  // FIN'den sonra veri
        c.send(F_FIN or F_ACK, seqNo = c.seq - 1)                      // çift FIN
        c.send(F_FIN or F_ACK or F_PSH, "x".toByteArray(), seqNo = c.seq + 50)
        Thread.sleep(400)
        T.check("FIN sonrası veri sunucuya ulaşmaz", String(sink.bytes()) == "one", String(sink.bytes()))
        sink.close(); r.close()
    }
    run {
        // sıfır pencere: sunucu 6 MB akıtır, istemci pencereyi 0 tutar → ağ geçidi belleği sınırlı; pencere açılınca baytlar eksiksiz gelir
        val total = 6 * 1024 * 1024
        val payload = ByteArray(total) { (it * 31 + it / 251).toByte() }
        val srv = Srv { sock -> sock.getOutputStream().write(payload); sock.getOutputStream().flush(); Thread.sleep(500) }
        val r = GRig()
        val c = GCli(r, srv.port)
        c.win = 0
        c.connect()
        c.send(F_ACK)
        Thread.sleep(1500)
        val base = heapMb()
        for (k in 1..20) { c.send(F_ACK); Thread.sleep(50); r.q.clear() }
        val held = heapMb() - base
        T.check("sıfır pencere: ağ geçidi sunucu verisini sınırsız tamponlamaz ($held MB artış)", held < 30, "$held MB")
        c.win = 65535
        c.send(F_ACK)                                   // pencere güncellemesi
        val got = c.readAll(total, 60_000)
        T.check("pencere açılınca 6 MB bayt bayt aynı gelir", got.size == total && got.contentEquals(payload), "gelen=${got.size}")
        srv.close(); r.close()
    }
    run {
        // bayrak kombinasyonları: kurulu, kurulmamış ve bilinmeyen akışlarda; RST'ye RST verilmez, çıktı geçerli ve amplifikasyonsuz
        val r = GRig(); val sink = Sink(echo = true)
        val c = GCli(r, sink.port); c.connect(); c.write("z".toByteArray()); c.read(1)
        var inBytes = 0L; var outBytes = 0L; var badOut = 0; var rstToRst = 0
        val buf = ByteArray(2048)
        val rnd = java.util.Random(99)
        r.q.clear()
        for (flags in 0..255) for (variant in 0..2) {
            val payload = if (variant == 2) ByteArray(rnd.nextInt(200)) else ByteArray(0)
            val sport = if (variant == 0) c.sport else 45000 + flags               // 0: kurulu akış, 1-2: bilinmeyen
            val seq = if (variant == 0) c.seq + rnd.nextInt(3) else rnd.nextInt()
            val n = Gw.tcp(buf, false, CLI4, LO4, sport, sink.port, seq, rnd.nextInt(), flags, 65535, payload, 0, payload.size, if (flags and 2 != 0) 1460 else 0)
            inBytes += n
            r.gw.onPacket(buf.copyOf(n), n)
            if (flags % 16 == 15) Thread.sleep(2)
        }
        Thread.sleep(500)
        while (true) {
            val p = r.q.poll() ?: break
            outBytes += p.size
            if (!Gw.checksumOk(p, p.size)) badOut++
        }
        T.check("bayrak taraması: tüm çıktı paketlerinin sağlaması doğru", badOut == 0, "bozuk=$badOut")
        T.check("amplifikasyon yok: çıktı ≤ girdi ($outBytes ≤ $inBytes bayt)", outBytes <= inBytes, "out=$outBytes in=$inBytes")
        val c2 = GCli(r, sink.port); c2.connect(); c2.write("q".toByteArray())
        T.check("tarama sonrası yeni akış çalışır", String(c2.read(1)) == "q")
        sink.close(); r.close()
    }
    run {
        // MSS seçeneği ve sıra numarası taşması
        val r = GRig()
        val payload = ByteArray(40_000) { (it % 251).toByte() }
        val srv = Srv { sock -> sock.getOutputStream().write(payload); sock.getOutputStream().flush(); Thread.sleep(300) }
        var allOk = true; var maxSeg = 0
        for (mss in intArrayOf(0, 1, 2, 7, 99, 100, 536, 1460, 9000, 65535)) {
            val c = GCli(r, srv.port)
            c.send(F_SYN, mss = mss); c.seq++
            val sa = c.next() ?: run { allOk = false; null } ?: continue
            c.rcv = sa.seq + 1; c.send(F_ACK)
            val got = c.readAll(payload.size, 8000)
            if (!got.contentEquals(payload)) { allOk = false }
        }
        T.check("uç MSS değerlerinde (0..65535) akış bozulmadan ulaşır", allOk)
        srv.close()
        // sıra numarası 2^32 sınırını geçerken
        val sink = Sink(echo = true)
        val c = GCli(r, sink.port); c.seq = -3000          // 0xFFFFF448
        c.connect()
        val big = ByteArray(9000) { (it * 7).toByte() }
        for (off in big.indices step 1000) c.write(big.copyOfRange(off, minOf(big.size, off + 1000)))
        val echoed = c.readAll(big.size, 8000)
        T.check("sıra numarası taşarken (0xFFFFFFFF → 0) akış bozulmaz", echoed.contentEquals(big), "gelen=${echoed.size}")
        sink.close(); r.close()
    }
}

private fun ByteArray.indexOfFirst2(pat: ByteArray): Int {
    outer@ for (i in 0..size - pat.size) { for (k in pat.indices) if (this[i + k] != pat[k]) continue@outer; return i }
    return -1
}
