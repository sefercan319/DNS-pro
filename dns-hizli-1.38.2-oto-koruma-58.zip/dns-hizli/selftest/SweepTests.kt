package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.Random

/**
 * Tarama testi: dışarıdan gelebilen HER metin çözücüsü (kalıcı kayıtlar, içe aktarma kodu, yapıştırılan listeler, kural dosyaları) aynı sert girdilerle sınanır:
 * rastgele, geçerli kaydın bozulmuş hâli, aşırı büyük ve yinelenen yapılar. Kural: çökmez, makul sürede biter (ikinci dereceden / ReDoS yok), geri dönüş
 * değerinin boyutu sınırlı kalır.
 */
private class Sweep(val name: String, val maxMs: Long = 1500, val run: (String) -> Any?)

private fun sweepInputs(seed: Long): List<String> {
    val r = Random(seed)
    val out = ArrayList<String>()
    val alpha = "abcxyz019.-_:;,=|/@[]()*+~ \t\r\n\"'\\<>%#&?!{}\u0000é☃𝄞"
    out += listOf("", " ", "\n", ",", ";", "=", ":", "null", "0", "-1", "9".repeat(40), "a=b", "a=b;c=d", "[[[[[[[[", "((((((((", "\\", "%", "\u0000", "..", "a..b", "-", "*", "*.*")
    repeat(120) { out += buildString { repeat(r.nextInt(400)) { append(alpha[r.nextInt(alpha.length)]) } } }
    repeat(40) { out += buildString { repeat(r.nextInt(3000)) { append((32 + r.nextInt(95)).toChar()) } } }
    repeat(20) { out += String(ByteArray(r.nextInt(2000)).also { b -> r.nextBytes(b) }, Charsets.ISO_8859_1) }
    // Aşırı büyük ve yinelenen yapılar (ikinci dereceden büyüme / ReDoS / bellek)
    val n = 120_000
    for (u in listOf(",", ";", "\n", ":", "=", "a,", "a=1;", "a.b.", "1.", "[", "(", "-", "*", "a:b,", "pkg.a=1,", "0=1,", "1,2;")) out += u.repeat(n / u.length.coerceAtLeast(1))
    out += "a".repeat(n); out += "a.".repeat(n / 2) + "com"; out += "x".repeat(70) + ".com"
    out += "(a+)+".repeat(2000) + "!"; out += "a".repeat(5000) + "!" + "a".repeat(5000)
    return out
}

fun runSweepTests() {
    T.group("Tarama: tüm metin çözücüleri (rastgele, bozuk, aşırı büyük girdi)")
    val sweeps = listOf(
        Sweep("AppAds.decode") { AppAds.decode(it).also { m -> if (m.size > 5000) error("sınırsız: ${m.size}") } },
        Sweep("AppScopes.decode") { AppScopes.decode(it).also { m -> if (m.size > 5000) error("sınırsız: ${m.size}") } },
        Sweep("CustomDns.decode") { CustomDns.decode(it).also { m -> if (m.size > 500) error("sınırsız: ${m.size}") } },
        Sweep("CustomPalette.decode/normalize") { CustomPalette.decode(it); CustomPalette.normalize(it) },
        Sweep("FilterNames.normalize/decode") { FilterNames.normalize(it); FilterNames.decode(it).also { m -> if (m.size > 100_000) error("sınırsız: ${m.size}") } },
        Sweep("HostsList.parse") { HostsList.parse(it).also { r -> if (r.names.size > 1_000_000) error("sınırsız") } },
        Sweep("SettingsCodec.import") { SettingsCodec.import(it, AppSettings()) },
        Sweep("Base64Mini.decode") { Base64Mini.decode(it) },
        Sweep("DailyStats.decode") { DailyStats.decode(it).also { m -> if (m.size > 5000) error("sınırsız: ${m.size}") } },
        Sweep("UsageStats.decode") { UsageStats.decode(it).also { m -> if (m.size > 20_000) error("sınırsız: ${m.size}") } },
        Sweep("SessionLog.decode") { SessionLog.decode(it).also { m -> if (m.size > 5000) error("sınırsız: ${m.size}") } },
        Sweep("LatencyCodec.decode") { LatencyCodec.decode(it).also { m -> if (m.size > 5000) error("sınırsız: ${m.size}") } },
        Sweep("LatencyHistory.decode") { LatencyHistory.decode(it).also { m -> if (m.size > 5000) error("sınırsız: ${m.size}") } },
        Sweep("OrbShapes.decode") { OrbShapes.decode(it) },
        Sweep("FxVariants.decode") { FxVariants.decode(it) },
        Sweep("SavedStyles.parse") { SavedStyles.parse(it) },
        Sweep("Cosmetic.parse") { Cosmetic.parse(it).also { c -> c.css("www.youtube.com") } },
        Sweep("PlanMemory.decode") { PlanMemory().decode(it) },
        Sweep("Ip.parse") { Ip.parse(it) },
        Sweep("Immune.decodeAll") { Immune().decodeAll(it, 1_000_000L) },
        Sweep("L.normalize") { L.normalize(it) },
    )
    val inputs = (1L..3L).flatMap { sweepInputs(it) }
    for (sw in sweeps) {
        var crash: String? = null; var slow: String? = null; var worstMs = 0L
        for (s in inputs) {
            val t0 = System.nanoTime()
            try { sw.run(s) } catch (e: Throwable) { if (crash == null) crash = "${e.javaClass.simpleName}: ${e.message?.take(80)} girdi(${s.length})=${s.take(30).replace("\n", "\\n")}" }
            val ms = (System.nanoTime() - t0) / 1_000_000
            if (ms > worstMs) worstMs = ms
            if (ms > sw.maxMs && slow == null) slow = "${ms} ms girdi(${s.length})=${s.take(30).replace("\n", "\\n")}"
        }
        T.check("${sw.name}: ${inputs.size} sert girdide çökmez", crash == null, crash ?: "")
        T.check("${sw.name}: yavaşlamaz (en kötü ${worstMs} ms, sınır ${sw.maxMs})", slow == null, slow ?: "")
    }
}

/** Sahte ama yapısı kasıtlı bozuk DNS iletileri: sınırlarda sayaçlar, kendine/ileri işaret eden sıkıştırma işaretçileri, 63'lük etiket zincirleri. */
private fun dnsLike(r: Random): ByteArray {
    val body = ByteArray(r.nextInt(900) + 1)
    for (i in body.indices) body[i] = when (r.nextInt(8)) { 0 -> 0xC0.toByte(); 1 -> r.nextInt(64).toByte(); 2 -> 0; 3 -> 63; 4 -> 0xFF.toByte(); else -> r.nextInt(256).toByte() }
    val h = ByteArray(12)
    r.nextBytes(h)
    if (r.nextInt(3) > 0) h[2] = (h[2].toInt() or 0x80).toByte()
    if (r.nextInt(4) == 0) for (i in 4..11) h[i] = if (r.nextBoolean()) 0xFF.toByte() else 0
    if (r.nextInt(3) == 0) { h[4] = 0; h[5] = 1 }
    val m = h + body
    // Kendine işaret eden işaretçi (döngü) ve ileri işaretçi
    if (r.nextInt(3) == 0 && m.size > 16) { m[12] = 0xC0.toByte(); m[13] = 12 }
    if (r.nextInt(4) == 0 && m.size > 20) { m[12] = 0xC0.toByte(); m[13] = (m.size - 2).coerceAtMost(255).toByte() }
    return m
}

fun runBinarySweepTests() {
    T.group("Tarama: ikili ayrıştırıcılar (DNS iletisi, TLS/HTTP, QUIC, HPACK, liste, ODoH) — çökme ve yavaşlık")
    class Case(val name: String, val gen: (Random) -> ByteArray, val run: (ByteArray) -> Unit)
    fun rnd(r: Random, max: Int) = ByteArray(r.nextInt(max)).also { r.nextBytes(it) }
    val cases = listOf(
        Case("Dns.cacheTtl/isBlocked/aRecords/questionEnd", ::dnsLike) { m -> Dns.cacheTtl(m, m.size); Dns.isBlocked(m, m.size); Dns.aRecords(m, m.size); Dns.questionEnd(m, 0, m.size) },
        Case("Dns.sameQuestion", ::dnsLike) { m -> Dns.sameQuestion(m, 0, Dns.questionEnd(m, 0, m.size).coerceIn(0, m.size), m, 0, m.size) },
        Case("Dns.setTtls/ageTtls/setTruncated/stripOpt (kopya)", ::dnsLike) { m -> val c = m.copyOf(); Dns.setTtls(c, 0, c.size, 30); Dns.ageTtls(c, 0, c.size, 10); Dns.setTruncated(c, 0); Dns.stripOpt(c.copyOf(), 0, c.size) },
        Case("Dns.sanitizeQuery", ::dnsLike) { m -> Dns.sanitizeQuery(m, 0, m.size, true, 1232); Dns.sanitizeQuery(m, 0, m.size, false, 0) },
        Case("DnsForwarder.parse benzeri: Packets.queryHeaderLen", { r -> rnd(r, 120) }) { m -> Packets.queryHeaderLen(m, m.size); Packets.queryHeaderLen6(m, m.size) },
        Case("Dpi.parseHello/parseHttp", { r -> if (r.nextBoolean()) rnd(r, 700) else (byteArrayOf(0x16, 3, 1, 0, 0x80.toByte(), 1) + rnd(r, 600)) }) { m -> Dpi.parseHello(m, m.size, Dpi.Hello()); Dpi.parseHttp(m, m.size, Dpi.HttpInfo()) },
        Case("QuicInitial.parse", { r -> byteArrayOf((0xC0 or r.nextInt(16)).toByte(), 0, 0, 0, 1) + rnd(r, 1300) }) { m -> QuicInitial.parse(m, 0, m.size) },
        Case("HpackDecoder/Huffman", { r -> rnd(r, 600) }) { m -> try { HpackDecoder().decode(m) } catch (_: java.io.IOException) {}; try { HuffmanDecoder.decode(m, 0, m.size) } catch (_: java.io.IOException) {} },
        Case("BlockedSites.parse", { r -> if (r.nextBoolean()) rnd(r, 4000) else ("# v=" + r.nextInt() + "\n" + "a.com\n".repeat(r.nextInt(500))).toByteArray() }) { m -> BlockedSites.parse(m) },
        Case("ListUpdate.parse", { r -> rnd(r, 3000) }) { m -> ListUpdate.parse(m) },
        Case("OdohConfigs.parse", { r -> rnd(r, 500) }) { m -> try { OdohConfigs.parse(m) } catch (_: OdohException) {} },
    )
    for (c in cases) {
        var crash: String? = null; var slow: String? = null; var worst = 0L
        for (seed in 1L..4000L) {
            val m = c.gen(Random(seed))
            val t0 = System.nanoTime()
            try { c.run(m) } catch (e: Throwable) { if (crash == null) crash = "${e.javaClass.simpleName}: ${e.message?.take(80)} tohum=$seed boy=${m.size}" }
            val ms = (System.nanoTime() - t0) / 1_000_000
            if (ms > worst) worst = ms
            if (ms > 200 && slow == null) slow = "$ms ms tohum=$seed boy=${m.size}"
        }
        T.check("${c.name}: 4000 sert girdide çökmez", crash == null, crash ?: "")
        T.check("${c.name}: yavaşlamaz (en kötü $worst ms)", slow == null, slow ?: "")
    }
}
