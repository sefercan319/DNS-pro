package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.util.Random

/**
 * Sızma girişimi 2 — düşmanca DNS cevabı. Saldırgan ya üst sunucunun kendisi (düz DNS yolunda araya girmiş) ya da bir izleyici alan
 * adının SAHİBİ (yetkili bölgeyi o yönetir: CNAME zincirini istediği uzunlukta kurar, A kayıtlarını istediği sırayla dizer).
 *  1) Gizli izleyici (CNAME) süzgecini uzun zincirle / sahte kayıtlarla atlatma.
 *  2) DNS yeniden bağlama korumasını "çok sayıda genel adres + sonda yerel adres" ile atlatma.
 *  3) Yapı-bilinçli bozma: sayaçlar, uzunluklar, işaretçiler, etiket türleri, sıra, TTL; bütün ayrıştırıcılar + doğruluk kâhini (oracle).
 *  4) Önbellek: uç TTL, taşırma, soru-cevap eşleşmesi.
 */

private fun b16(v: Int) = byteArrayOf((v ushr 8).toByte(), v.toByte())
private fun b32(v: Int) = byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())
private fun wname(n: String): ByteArray {
    if (n.isEmpty()) return byteArrayOf(0)
    val o = ByteArrayOutputStream()
    for (l in n.split('.')) { o.write(l.length); o.write(l.toByteArray(Charsets.ISO_8859_1)) }
    o.write(0)
    return o.toByteArray()
}

/** Cevap kurucu: sıkıştırma işaretçileri gerçek konumlara verilir (ad daha önce yazıldıysa), bölüm sayaçları otomatik. */
private class Dm(val id: Int, val qname: String, val qtype: Int, val rcode: Int = 0) {
    private val o = ByteArrayOutputStream()
    private val names = HashMap<String, Int>()
    private val cnt = IntArray(3)
    init {
        o.write(ByteArray(12))
        names[qname] = o.size()
        o.write(wname(qname)); o.write(b16(qtype)); o.write(b16(1))
    }
    private fun name(n: String, compress: Boolean) {
        val at = names[n]
        if (compress && at != null && at < 0x4000) { o.write(0xC0 or (at ushr 8)); o.write(at and 0xFF) }
        else { if (at == null) names[n] = o.size(); o.write(wname(n)) }
    }
    fun rr(sec: Int, owner: String, type: Int, ttl: Int, rdata: ByteArray, compress: Boolean = true): Dm {
        name(owner, compress); o.write(b16(type)); o.write(b16(1)); o.write(b32(ttl)); o.write(b16(rdata.size)); o.write(rdata)
        cnt[sec]++
        return this
    }
    fun cname(owner: String, target: String, ttl: Int = 300, compress: Boolean = true): Dm {
        name(owner, compress); o.write(b16(5)); o.write(b16(1)); o.write(b32(ttl))
        val at = names[target]
        if (compress && at != null && at < 0x4000) { o.write(b16(2)); o.write(0xC0 or (at ushr 8)); o.write(at and 0xFF) }
        else { val w = wname(target); o.write(b16(w.size)); names.putIfAbsent(target, o.size()); o.write(w) }
        cnt[0]++
        return this
    }
    fun a(owner: String, ip: ByteArray, ttl: Int = 300) = rr(0, owner, 1, ttl, ip)
    fun aaaa(owner: String, ip: ByteArray, ttl: Int = 300) = rr(0, owner, 28, ttl, ip)
    fun https(owner: String, target: String, ttl: Int = 300) = rr(0, owner, 65, ttl, b16(1) + wname(target))
    fun soa(ttl: Int = 60, minimum: Int = 30): Dm {
        val r = ByteArrayOutputStream(); r.write(wname("ns.x.example")); r.write(wname("h.x.example")); r.write(b32(1)); r.write(b32(3600)); r.write(b32(600)); r.write(b32(86400)); r.write(b32(minimum))
        return rr(1, "x.example", 6, ttl, r.toByteArray(), compress = false)
    }
    fun ede(code: Int): Dm = rr(2, "", 41, 0, b16(15) + b16(2) + b16(code), compress = false)
    fun finish(): ByteArray {
        val m = o.toByteArray()
        Packets.put16(m, 0, id); Packets.put16(m, 2, 0x8180 or rcode); Packets.put16(m, 4, 1)
        Packets.put16(m, 6, cnt[0]); Packets.put16(m, 8, cnt[1]); Packets.put16(m, 10, cnt[2])
        return m
    }
}

private fun ip4(a: Int, b: Int, c: Int, d: Int) = byteArrayOf(a.toByte(), b.toByte(), c.toByte(), d.toByte())
private fun ip6(vararg w: Int): ByteArray { val o = ByteArray(16); for (i in w.indices) { o[2 * i] = (w[i] ushr 8).toByte(); o[2 * i + 1] = w[i].toByte() }; return o }

private fun engine(allow: List<String> = emptyList(), block: List<String> = listOf("tracker-net.example", "pixel-ads.example")): FilterEngine {
    FilterRuntime.reset()
    FilterRuntime.updateNow(FilterLevel.OFF, allow, block)
    FilterRuntime.rebind = true
    return FilterRuntime.engine!!
}

private fun isBlockVerdict(v: Int) = v == FilterVerdict.LIST || v == FilterVerdict.USER

fun runSizmaDnsTests() {
    val rnd = Random(20261022L)
    val q = "metrik.site.example"
    val tracker = "x.tracker-net.example"

    // ------------------------------------------------------------------------------------------------------------ 1) CNAME zinciri
    T.group("Sızma 2 / düşmanca DNS: izleyici sahibi CNAME zincirini uzatıp süzgeci atlatamaz (1..40 adım)")
    run {
        val e = engine()
        val miss = ArrayList<Int>(); val falsePos = ArrayList<Int>(); val guardMiss = ArrayList<Int>()
        for (hops in 1..32) {
            val d = Dm(1, q, 1)
            var from = q
            for (i in 1 until hops) { val to = "h$i.site.example"; d.cname(from, to); from = to }
            d.cname(from, tracker)                                    // son halka izleyici: zincir hops adım
            d.a(tracker, ip4(93, 184, 216, 34))
            val m = d.finish()
            if (!isBlockVerdict(e.cnameVerdict(m, 0, m.size))) miss += hops
            val buf = m.copyOf(m.size + 64)
            val n = CnameGuard.guard(buf, 0, m.size)
            if (Dns.isBlocked(buf, 0, n).not() && n == m.size) guardMiss += hops
            // izleyicisiz aynı uzunlukta zincir: yanlış engel olmamalı
            val c = Dm(2, q, 1)
            var f2 = q
            for (i in 1..hops) { val to = "h$i.site.example"; c.cname(f2, to); f2 = to }
            c.a(f2, ip4(93, 184, 216, 34))
            val cm = c.finish()
            if (isBlockVerdict(e.cnameVerdict(cm, 0, cm.size))) falsePos += hops
        }
        T.check("izleyici SON halka: 1..32 adımlık zincirin hepsi engellenir", miss.isEmpty(), "kaçan adım sayıları=$miss")
        T.check("koruyucu cevabı gerçekten engelleme cevabına çevirir (1..32 adım)", guardMiss.isEmpty(), "kaçan=$guardMiss")
        T.check("izleyicisiz aynı siteli 1..32 adımlık zincir engellenmez (yanlış pozitif yok)", falsePos.isEmpty(), "yanlış=$falsePos")

        val over = ArrayList<Int>()
        for (hops in intArrayOf(33, 34, 40, 100, 400)) {
            val c = Dm(3, q, 1)
            var f2 = q
            for (i in 1..hops) { val to = "h$i.site.example"; c.cname(f2, to); f2 = to }
            c.a(f2, ip4(93, 184, 216, 34))
            val cm = c.finish()
            if (!isBlockVerdict(e.cnameVerdict(cm, 0, cm.size))) over += hops
        }
        T.check("32'den uzun zincir (hiçbir çözücü üretmez) güvenli tarafta engellenir", over.isEmpty(), "geçen=$over")

        // izleyici ortada, zincir devam ediyor + önce çok sayıda sahte A kaydı
        val d = Dm(4, q, 1)
        repeat(60) { d.a(q, ip4(93, 184, 216, 1 + it % 200)) }
        d.cname(q, "h1.site.example").cname("h1.site.example", "t.pixel-ads.example").cname("t.pixel-ads.example", "h9.cdn.example").a("h9.cdn.example", ip4(8, 8, 8, 8))
        val dm = d.finish()
        T.check("başa 60 sahte A kaydı koyup zinciri geriye saklama işe yaramaz", isBlockVerdict(e.cnameVerdict(dm, 0, dm.size)))

        // sıkıştırılmamış / sıkıştırılmış gösterim ve büyük harf aynı sonucu verir
        val u = Dm(5, q, 1).cname(q, "H1.Site.Example", compress = false).cname("H1.Site.Example", "X.TRACKER-NET.Example", compress = false).a("x.tracker-net.example", ip4(1, 2, 3, 4), 60).finish()
        T.check("büyük/küçük harf ve sıkıştırmasız gösterim izleyiciyi gizlemez", isBlockVerdict(e.cnameVerdict(u, 0, u.size)))

        // HTTPS/SVCB hedefi izleyici: araya başka HTTPS kayıtları sıkıştırılmış
        val s = Dm(6, q, 65)
        for (i in 1..12) s.https(q, "svc$i.site.example")
        s.https(q, tracker)
        val sm = s.finish()
        T.check("HTTPS/SVCB TargetName izleyici (12 kayıt arkasında) engellenir", isBlockVerdict(e.cnameVerdict(sm, 0, sm.size)))

        // izin listesi her zaman üstündür
        val ea = engine(allow = listOf("site.example"))
        val long = Dm(7, q, 1)
        var f3 = q
        for (i in 1..20) { val to = "h$i.cdn$i.example"; long.cname(f3, to); f3 = to }
        long.cname(f3, tracker).a(tracker, ip4(1, 2, 3, 4))
        val lm = long.finish()
        T.check("kullanıcı izin listesindeki sorulan ad, uzun/izleyicili zincirde bile geçer", !isBlockVerdict(ea.cnameVerdict(lm, 0, lm.size)))
        engine()
    }

    // ------------------------------------------------------------------------------------------------------------ 2) yeniden bağlama
    T.group("Sızma 2 / düşmanca DNS: yeniden bağlama — çok sayıda genel adres + sonda yerel adres")
    run {
        val e = engine()
        val miss = ArrayList<Int>()
        for (decoys in intArrayOf(0, 1, 15, 31, 32, 33, 64, 200, 511, 512, 513, 1000, 2500)) {
            val d = Dm(1, "evil.attacker.example", 1)
            repeat(decoys) { d.a("evil.attacker.example", ip4(93, 184, 1 + it / 250 % 200, 1 + it % 250)) }
            d.a("evil.attacker.example", ip4(127, 0, 0, 1))
            val m = d.finish()
            if (!e.rebindVerdict(m, 0, m.size)) miss += decoys
        }
        T.check("0..2500 sahte genel A kaydından sonra gelen 127.0.0.1 yakalanır", miss.isEmpty(), "kaçan sahte sayıları=$miss")
        val d = Dm(2, "ok.attacker.example", 1)
        repeat(2500) { d.a("ok.attacker.example", ip4(93, 184, 1 + it / 250 % 200, 1 + it % 250)) }
        val m = d.finish()
        T.check("yalnızca genel adresli büyük cevap engellenmez", !e.rebindVerdict(m, 0, m.size))

        val kinds = listOf(
            "AAAA ::1" to ip6(0, 0, 0, 0, 0, 0, 0, 1), "AAAA fc00::1" to ip6(0xfc00, 0, 0, 0, 0, 0, 0, 1), "AAAA fd12:3456::1" to ip6(0xfd12, 0x3456, 0, 0, 0, 0, 0, 1),
            "AAAA fe80::1" to ip6(0xfe80, 0, 0, 0, 0, 0, 0, 1), "AAAA ::ffff:192.168.0.1" to ip6(0, 0, 0, 0, 0, 0xffff, 0xc0a8, 1),
            "AAAA ::ffff:127.0.0.1" to ip6(0, 0, 0, 0, 0, 0xffff, 0x7f00, 1),
        )
        val missed6 = ArrayList<String>()
        for ((name, ip) in kinds) {
            val x = Dm(3, "v6.attacker.example", 28)
            repeat(40) { x.aaaa("v6.attacker.example", ip6(0x2606, 0x4700, 0, 0, 0, 0, 0, 1 + it)) }
            x.aaaa("v6.attacker.example", ip)
            val xm = x.finish()
            if (!e.rebindVerdict(xm, 0, xm.size)) missed6 += name
        }
        T.check("IPv6 yerel adresler (40 sahte genel AAAA arkasında) yakalanır", missed6.isEmpty(), missed6.toString())
        val pub6 = Dm(4, "pub6.attacker.example", 28).aaaa("pub6.attacker.example", ip6(0x2606, 0x4700, 0, 0, 0, 0, 0, 0x1111)).aaaa("pub6.attacker.example", ip6(0, 0, 0, 0, 0, 0xffff, 0x0808, 0x0808)).finish()
        T.check("genel IPv6 ve genel eşlenmiş IPv4 engellenmez", !e.rebindVerdict(pub6, 0, pub6.size))
        val loc = Dm(5, "nas.lan", 1).a("nas.lan", ip4(192, 168, 1, 5)).finish()
        T.check("yerel ad uzantısı (.lan) muaf", !e.rebindVerdict(loc, 0, loc.size))
        val ea = engine(allow = listOf("evim.example"))
        val al = Dm(6, "nas.evim.example", 1).a("nas.evim.example", ip4(192, 168, 1, 5)).finish()
        T.check("kullanıcı izin listesindeki ad muaf", !ea.rebindVerdict(al, 0, al.size))
        // 0.0.0.0 filtreli DNS sağlayıcılarının engelleme cevabıdır: yeniden bağlama sayılmaz
        val zero = Dm(7, "engel.example", 1).a("engel.example", ip4(0, 0, 0, 0)).finish()
        T.check("0.0.0.0 (engelleme cevabı) yeniden bağlama sayılmaz", !engine().rebindVerdict(zero, 0, zero.size))
        engine()
    }

    // ------------------------------------------------------------------------------------------------------------ 3) kâhinli rastgele cevap
    T.group("Sızma 2 / düşmanca DNS: ${DEEP_X * 2500} rastgele geçerli cevap, bağımsız doğruluk kâhiniyle (CNAME + yeniden bağlama)")
    run {
        val e = engine(allow = listOf("izinli.example"))
        val qnames = listOf("m.site.example", "www.news.example", "app.shop.co.uk", "x.y.z.site2.example", "www.izinli.example")
        val benign = listOf("cdn.cdnprov.example", "edge.fastly-ish.example", "a.b.site.example", "lb.cloud.example", "img.news.example", "s.shop.co.uk")
        val trackers = listOf("t.tracker-net.example", "px.pixel-ads.example", "a.b.tracker-net.example")
        val pubV4 = listOf(ip4(93, 184, 216, 34), ip4(8, 8, 8, 8), ip4(1, 1, 1, 1), ip4(172, 32, 0, 1), ip4(192, 169, 0, 1), ip4(11, 0, 0, 1))
        val privV4s = listOf(ip4(10, 1, 2, 3), ip4(127, 0, 0, 1), ip4(192, 168, 1, 1), ip4(172, 20, 1, 1), ip4(169, 254, 169, 254))
        val pub6 = listOf(ip6(0x2606, 0x4700, 0, 0, 0, 0, 0, 0x1111), ip6(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1), ip6(0, 0, 0, 0, 0, 0xffff, 0x0808, 0x0808))
        val priv6 = listOf(ip6(0, 0, 0, 0, 0, 0, 0, 1), ip6(0xfc00, 0, 0, 0, 0, 0, 0, 1), ip6(0xfd12, 0x3456, 0, 0, 0, 0, 0, 1), ip6(0xfe80, 0, 0, 0, 0, 0, 0, 1), ip6(0, 0, 0, 0, 0, 0xffff, 0xc0a8, 1))
        var cBad = 0; var rBad = 0; var blockedN = 0; var rebindN = 0; var total = 0
        val firstBad = StringBuilder()
        for (iter in 0 until DEEP_X * 2500) {
            val qn = qnames[rnd.nextInt(qnames.size)]
            val d = Dm(iter and 0xFFFF, qn, 1)
            val decoys = if (rnd.nextInt(4) == 0) rnd.nextInt(60) else 0
            repeat(decoys) { d.a(qn, pubV4[rnd.nextInt(pubV4.size)]) }
            val hops = rnd.nextInt(12)
            var from = qn
            var hasTracker = false
            val compress = rnd.nextBoolean()
            for (h in 0 until hops) {
                val to = if (rnd.nextInt(5) == 0) trackers[rnd.nextInt(trackers.size)].also { hasTracker = true } else benign[rnd.nextInt(benign.size)]
                d.cname(from, to, compress = compress && rnd.nextBoolean())
                from = to
            }
            val addrs = ArrayList<ByteArray>(); var anyPriv = false
            val nA = if (rnd.nextInt(10) == 0) 0 else 1 + rnd.nextInt(4)
            for (k in 0 until nA) {
                val v6 = rnd.nextInt(3) == 0
                val p = rnd.nextInt(5) == 0
                val ip = if (v6) (if (p) priv6 else pub6).let { l -> l[rnd.nextInt(l.size)] } else (if (p) privV4s else pubV4).let { l -> l[rnd.nextInt(l.size)] }
                if (p) anyPriv = true
                if (v6) d.aaaa(from, ip) else d.a(from, ip)
                addrs += ip
            }
            val an = decoys + hops + nA
            val m = d.finish()
            val allowed = qn.endsWith("izinli.example")
            val expC = !allowed && an >= 2 && hasTracker
            val expR = !allowed && (anyPriv)
            val gotC = isBlockVerdict(e.cnameVerdict(m, 0, m.size))
            val gotR = e.rebindVerdict(m, 0, m.size)
            total++
            if (gotC) blockedN++; if (gotR) rebindN++
            if (gotC != expC) { cBad++; if (firstBad.length < 400) firstBad.append("CNAME qn=$qn hops=$hops decoys=$decoys exp=$expC got=$gotC; ") }
            if (gotR != expR) { rBad++; if (firstBad.length < 400) firstBad.append("REBIND qn=$qn nA=$nA exp=$expR got=$gotR; ") }
        }
        T.check("CNAME kararı kâhinle aynı ($total cevap)", cBad == 0, "$cBad uyuşmaz $firstBad")
        T.check("yeniden bağlama kararı kâhinle aynı ($total cevap)", rBad == 0, "$rBad uyuşmaz $firstBad")
        T.check("kâhin testi boş değil: engellenen ve yeniden bağlama sayısı anlamlı", blockedN > total / 20 && rebindN > total / 20 && blockedN < total && rebindN < total, "cname=$blockedN rebind=$rebindN / $total")
        engine()
    }

    // ------------------------------------------------------------------------------------------------------------ 3b) yapı-bilinçli bozma
    T.group("Sızma 2 / düşmanca DNS: yapı-bilinçli bozma (sayaç, uzunluk, işaretçi, etiket türü, kesme, sıra) — bütün ayrıştırıcılar")
    run {
        val e = engine()
        val base = ArrayList<ByteArray>()
        val trk = "x.tracker-net.example"
        base += Dm(1, q, 1).cname(q, "a.site.example").cname("a.site.example", trk).a(trk, ip4(1, 2, 3, 4)).soa().ede(15).finish()
        base += Dm(2, q, 28).aaaa(q, ip6(0x2606, 0x4700, 0, 0, 0, 0, 0, 1)).aaaa(q, ip6(0xfd00, 0, 0, 0, 0, 0, 0, 1)).finish()
        base += Dm(3, q, 65).https(q, "svc.site.example").https(q, trk).finish()
        base += Dm(4, q, 1, rcode = 3).soa(30, 10).finish()
        base += Dm(5, q, 1).a(q, ip4(0, 0, 0, 0)).ede(17).finish()
        base += Dm(6, q, 1).cname(q, "b.cdn.example", compress = false).cname("b.cdn.example", "c.cdn.example", compress = false).a("c.cdn.example", ip4(127, 0, 0, 1)).finish()
        val query = Dns.buildQuery(0x1234, q)
        val qEnd = Dns.questionEnd(query, 0, query.size)
        var thrown = 0; var guardBad = 0; var ttlBad = 0; var ageBad = 0; var changed = 0; var parsed = 0
        val first = StringBuilder()
        fun note(s: String) { if (first.length < 500) first.append(s).append("; ") }
        val iters = DEEP_X * 6000
        for (iter in 0 until iters) {
            val src = base[rnd.nextInt(base.size)]
            var m = src.copyOf()
            when (rnd.nextInt(9)) {
                0 -> for (k in 4..10 step 2) if (rnd.nextBoolean()) Packets.put16(m, k, when (rnd.nextInt(4)) { 0 -> 0; 1 -> 0xFFFF; 2 -> Packets.u16(m, k) + 1; else -> maxOf(0, Packets.u16(m, k) - 1) })
                1 -> { val at = 12 + rnd.nextInt(m.size - 12); m[at] = (m[at].toInt() xor (1 shl rnd.nextInt(8))).toByte() }
                2 -> { val ptrs = (12 until m.size - 1).filter { (m[it].toInt() and 0xC0) == 0xC0 }; if (ptrs.isNotEmpty()) { val at = ptrs[rnd.nextInt(ptrs.size)]; val tgt = when (rnd.nextInt(4)) { 0 -> at; 1 -> rnd.nextInt(m.size + 40); 2 -> 12; else -> rnd.nextInt(0x3FFF) }; m[at] = (0xC0 or (tgt ushr 8)).toByte(); m[at + 1] = tgt.toByte() } }
                3 -> { val at = 12 + rnd.nextInt(m.size - 12); m[at] = intArrayOf(0x40, 0x80, 0xBF, 0xC0, 0xFF, 63, 0)[rnd.nextInt(7)].toByte() }
                4 -> m = m.copyOf(rnd.nextInt(m.size + 1))
                5 -> { val l = m.size; val at = rnd.nextInt(l); m = m.copyOfRange(0, at) + m.copyOfRange(at, l).let { it + it } }            // bir kısmı iki kez
                6 -> { val at = 12 + rnd.nextInt(m.size - 13); Packets.put16(m, at, rnd.nextInt(0x10000)) }
                7 -> { val a = 12 + rnd.nextInt(m.size - 12); val b = 12 + rnd.nextInt(m.size - 12); val t = m[a]; m[a] = m[b]; m[b] = t }
                else -> Packets.put16(m, 2, rnd.nextInt(0x10000))
            }
            if (rnd.nextInt(3) == 0) repeat(1 + rnd.nextInt(3)) { if (m.size > 12) m[12 + rnd.nextInt(m.size - 12)] = rnd.nextInt().toByte() }
            val cut = if (m.isEmpty()) 0 else if (rnd.nextInt(5) == 0) rnd.nextInt(m.size + 1) else m.size
            try {
                val ttl = Dns.cacheTtl(m, cut)
                if (ttl < 0) { ttlBad++; note("ttl<0") }
                Dns.isBlocked(m, cut); Dns.isLocalBlock(m, 0, cut); Dns.aRecords(m, cut); Dns.questionEnd(m, 0, cut)
                if (Dns.sameQuestion(query, 0, qEnd, m, 0, cut)) parsed++
                e.cnameVerdict(m, 0, cut); e.rebindVerdict(m, 0, cut)
                val buf = m.copyOf(m.size + 64)
                val n = CnameGuard.guard(buf, 0, cut)
                if (cut > 0 && (n <= 0 || n > buf.size)) { guardBad++; note("guard n=$n cut=$cut") }
                else if (n != cut || !(0 until cut).all { buf[it] == m[it] }) {
                    changed++
                    if (n < Packets.DNS_HDR || (Packets.u16(buf, 2) and 0x8000) == 0 || Packets.u16(buf, 0) != Packets.u16(m, 0)) { guardBad++; note("guard çıktısı bozuk id/QR n=$n") }
                }
                val c1 = m.copyOf(); Dns.ageTtls(c1, 0, cut, 1 + rnd.nextInt(5000))
                val c2 = m.copyOf(); Dns.setTtls(c2, 0, cut, rnd.nextInt(100))
                if (c1.size != m.size || c2.size != m.size) { ageBad++; note("boyut") }
                for (k in 0 until minOf(12, cut)) if (c1[k] != m[k] || c2[k] != m[k]) { ageBad++; note("başlık değişti k=$k"); break }
            } catch (t: Throwable) { thrown++; note("istisna: $t @${t.stackTrace.firstOrNull()}") }
        }
        T.check("$iters bozuk cevapta hiçbir ayrıştırıcı istisna atmaz", thrown == 0, "istisna=$thrown $first")
        T.check("koruyucu her zaman geçerli uzunluk ve geçerli (aynı kimlikli, QR=1) engelleme cevabı döner", guardBad == 0, "$guardBad $first")
        T.check("TTL hesabı hiçbir zaman negatif olmaz; TTL eskitme/ayarlama boyutu ve başlığı korur", ttlBad == 0 && ageBad == 0, "ttl=$ttlBad age=$ageBad $first")
        T.check("test boş değil: bozuk cevapların bir kısmı hâlâ eşleşiyor, bir kısmı koruyucuca değiştiriliyor", parsed > iters / 50 && changed > 0, "eşleşen=$parsed değişen=$changed / $iters")
        engine()
    }

    // ------------------------------------------------------------------------------------------------------------ 4) önbellek ve soru eşleşmesi
    T.group("Sızma 2 / düşmanca DNS: önbellek (uç TTL, taşırma) ve soru-cevap eşleşmesi")
    run {
        var t = 1_000_000L
        val cache = DnsCache(64, { t })
        val key = "k"
        val huge = Dm(9, q, 1).a(q, ip4(1, 2, 3, 4), ttl = 0x7FFFFFFF).finish()
        val ttl = Dns.cacheTtl(huge, huge.size)
        cache.put(key, huge, huge.size, ttl)
        val out = ByteArray(512)
        t += 299_000
        val okAt299 = cache.get(key, 7, out, 0) == huge.size
        t += 2_000
        val goneAt301 = cache.get(key, 7, out, 0) == -1
        T.check("sunucu 2^31-1 sn TTL verse de kayıt en çok 300 sn tutulur", ttl == 0x7FFFFFFF && okAt299 && goneAt301, "ttl=$ttl 299=$okAt299 301gone=$goneAt301")
        val neg = Dm(9, q, 1).a(q, ip4(1, 2, 3, 4), ttl = -1).finish()
        T.check("negatif (işaretli) TTL önbelleğe girmez", Dns.cacheTtl(neg, neg.size) == 0)
        val zero = Dm(9, q, 1).a(q, ip4(1, 2, 3, 4), ttl = 0).finish()
        T.check("TTL=0 önbelleğe girmez", Dns.cacheTtl(zero, zero.size) == 0)
        val mixed = Dm(9, q, 1).a(q, ip4(1, 2, 3, 4), ttl = 1000).a(q, ip4(1, 2, 3, 5), ttl = 5).finish()
        T.check("en kısa TTL esas alınır (sunucu uzun/kısa karıştırınca en kısası)", Dns.cacheTtl(mixed, mixed.size) == 5)
        val flood = DnsCache(64, { t })
        val big = Dm(9, q, 16).let { d -> d.rr(0, q, 16, 300, ByteArray(1200) { 'a'.code.toByte() }); d.rr(0, q, 16, 300, ByteArray(1200) { 'b'.code.toByte() }); d.rr(0, q, 16, 300, ByteArray(1200) { 'c'.code.toByte() }); d.finish() }
        for (i in 0 until 20_000) flood.put("flood$i", big, big.size, 300)
        T.check("20 bin büyük cevapla taşırma: kayıt ve bayt sınırı aşılmaz", flood.size() <= 64 && flood.byteSize() <= 64 * 1024, "kayıt=${flood.size()} bayt=${flood.byteSize()}")
        val over = ByteArray(5000)
        System.arraycopy(big, 0, over, 0, big.size)
        flood.put("dev", over, 5000, 300)
        T.check("4096 bayttan büyük cevap hiç saklanmaz", flood.get("dev", 1, ByteArray(6000), 0) == -1)

        val query = Dns.buildQuery(0x1234, "Metrik.Site.Example")
        val qEnd = Dns.questionEnd(query, 0, query.size)
        fun reply(mut: (ByteArray) -> ByteArray = { it }): ByteArray = mut(Dm(0x1234, "Metrik.Site.Example", 1).a("Metrik.Site.Example", ip4(1, 2, 3, 4)).finish())
        fun ok(r: ByteArray) = Dns.sameQuestion(query, 0, qEnd, r, 0, r.size)
        val good = reply()
        val lowerName = reply { it.also { b -> for (i in 13 until 13 + 19) if (b[i] in 0x41..0x5A) b[i] = (b[i] + 32).toByte() } }
        val otherName = Dm(0x1234, "evil.site.example", 1).a("evil.site.example", ip4(1, 2, 3, 4)).finish()
        val otherType = reply { it.also { b -> Packets.put16(b, qEnd - 4, 28) } }
        val otherClass = reply { it.also { b -> Packets.put16(b, qEnd - 2, 3) } }
        val qd2 = reply { it.also { b -> Packets.put16(b, 4, 2) } }
        val qd0 = reply { it.also { b -> Packets.put16(b, 4, 0) } }
        val notResp = reply { it.also { b -> Packets.put16(b, 2, 0x0180) } }
        val opcode = reply { it.also { b -> Packets.put16(b, 2, 0x8980) } }
        T.check("soru-cevap: aynı soru (ve 0x20 harf karıştırması) kabul", ok(good) && ok(lowerName))
        T.check("soru-cevap: başka ad / tür / sınıf / soru sayısı / QR / opcode reddedilir", !ok(otherName) && !ok(otherType) && !ok(otherClass) && !ok(qd2) && !ok(qd0) && !ok(notResp) && !ok(opcode),
            "ad=${ok(otherName)} tür=${ok(otherType)} sınıf=${ok(otherClass)} qd2=${ok(qd2)} qd0=${ok(qd0)} qr=${ok(notResp)} op=${ok(opcode)}")
        val truncated = ArrayList<Int>()
        for (cut in 0 until good.size) if (cut < qEnd && Dns.sameQuestion(query, 0, qEnd, good, 0, cut)) truncated += cut
        T.check("soru bölümü kesilmiş cevap hiçbir uzunlukta kabul edilmez", truncated.isEmpty(), truncated.toString())
    }
    FilterRuntime.reset(); FilterRuntime.rebind = true
}
