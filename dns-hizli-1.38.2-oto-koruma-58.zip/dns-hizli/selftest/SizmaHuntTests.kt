package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.Random

/** Sızma 22 — hata avı: henüz referansla sınanmamış biçim/istatistik/temizleme kodları. */
internal fun runHuntTests() {
    T.group("Sızma 22 / Format.bytes: birim sınırında '1024 KB' gibi taşma yok; değer gerçeğe %5 içinde yakın; birim tek yönlü artar")
    run {
        val tx = L.tx
        val units = tx.byteUnits
        fun parse(s: String): Pair<Double, String>? {
            val sp = s.lastIndexOf(' '); if (sp < 0) return null
            val num = s.substring(0, sp).replace(tx.decimalSep.toString(), ".").toDoubleOrNull() ?: return null
            return num to s.substring(sp + 1)
        }
        val rnd = Random(2201)
        val probes = ArrayList<Long>()
        probes += listOf(0L, 1L, 1023L, 1024L, 1025L)
        var k = 1L; repeat(6) { k *= 1024; probes += listOf(k - 1, k - 2, k - 52, k, k + 1, k * 1023 / 1024, k * 1023 / 1024 + k / 2048) }
        repeat(20_000) { probes += (rnd.nextDouble() * Math.pow(2.0, rnd.nextInt(60).toDouble())).toLong() }
        var overflow = 0; var far = 0; var bad = ""
        var prevUnit = -1; var prevV = -1L
        for (v in probes.filter { it >= 0 }.sorted()) {
            val s = Format.bytes(v)
            val pr = parse(s)
            if (pr == null) { overflow++; if (bad.isEmpty()) bad = "ayrıştırılamadı '$s' ($v)"; continue }
            val num = pr.first; val u = pr.second
            val ui = units.indexOf(u)
            if (ui < 0) { overflow++; if (bad.isEmpty()) bad = "birim yok '$s'"; continue }
            if (num >= 1024.0 && ui < units.size - 1) { overflow++; if (bad.isEmpty()) bad = "'$s' ($v) bir üst birime geçmeliydi" }
            val real = v.toDouble() / Math.pow(1024.0, ui.toDouble())
            if (v >= 1024 && Math.abs(num - real) > real * 0.05 + 0.06) { far++; if (bad.isEmpty()) bad = "'$s' gerçek=$real ($v)" }
            if (ui < prevUnit && v > prevV) { far++; if (bad.isEmpty()) bad = "birim geri gitti: '$s' ($v)" }
            prevUnit = ui; prevV = v
        }
        T.check("${probes.size} değerde birim taşması yok", overflow == 0, "taşma=$overflow $bad")
        T.check("gösterilen değer gerçeğe yakın, birim geri gitmez", far == 0, "fark=$far $bad")
    }
    T.group("Sızma 22 / Format.count: bin/milyon sınırlarında '1000 bin' gibi taşma yok; sıra korunur")
    run {
        val tx = L.tx
        var bad = ""
        val probes = listOf(0L, 1L, 999L, 1000L, 1049L, 1050L, 9949L, 9950L, 9999L, 10_000L, 99_999L, 100_000L, 999_999L, 1_000_000L, 1_049_999L, 9_949_999L, 9_999_999L, 10_000_000L, 999_999_999L, 1_000_000_000L, Long.MAX_VALUE)
        for (v in probes) {
            val s = Format.count(v)
            val numStr = s.takeWhile { it.isDigit() || it == tx.decimalSep }
            val num = numStr.replace(tx.decimalSep.toString(), ".").toDoubleOrNull() ?: -1.0
            if (num < 0 || (s.endsWith(tx.thousand) && num >= 1000.0)) { if (bad.isEmpty()) bad = "'$s' ($v)" }
        }
        T.check("sınır değerlerde sayı taşmaz/boş değildir", bad.isEmpty(), bad)
        T.check("değişmezler: 999 → '999', 1000 → '1 bin', 9999 → '9,9 bin'", Format.count(999) == "999" && Format.count(1000) == "1" + tx.thousand && Format.count(9999) == "9" + tx.decimalSep.toString() + "9" + tx.thousand)
    }

    // ---------------------------------------------------------------- PublicSuffix ↔ PSL belirtimi (naif referans)
    T.group("Sızma 22 / PublicSuffix.registrableStart ↔ PSL belirtimi (publicsuffix.org algoritması, psl.txt'nin tamamı): 150 bin ad")
    run {
        val f = java.io.File("app/src/main/assets/filter/psl.txt")
        if (!f.exists()) { T.check("psl.txt bulunamadı (atlandı)", true); return@run }
        val was = PublicSuffix.ready
        try {
            PublicSuffix.clear(); f.inputStream().use { PublicSuffix.install(it) }
            class Rule(val labels: List<String>, val exception: Boolean)
            val rules = ArrayList<Rule>()
            f.readLines().forEach { raw ->
                val l = raw.trim(); if (l.isEmpty() || l[0] == '#') return@forEach
                val ex = l[0] == '!'; val body = if (ex) l.substring(1) else l
                rules += Rule(body.split('.').reversed(), ex)           // sağdan sola
            }
            val byTld = HashMap<String, MutableList<Rule>>()
            for (r in rules) byTld.getOrPut(r.labels[0]) { ArrayList() }.add(r)
            fun matches(r: Rule, name: List<String>): Boolean {      // name sağdan sola
                if (r.labels.size > name.size) return false
                for (i in r.labels.indices) if (r.labels[i] != "*" && r.labels[i] != name[i]) return false
                return true
            }
            // PSL algoritması: eşleşen kurallar; istisna varsa o (bir etiket eksik), yoksa en çok etiketli; hiçbiri yoksa "*" (1 etiket)
            fun refRegistrable(name: String): String? {
                val l = name.split('.').reversed()
                if (l.size == 1) return null
                val cand = byTld[l[0]].orEmpty().filter { matches(it, l) }
                val ex = cand.filter { it.exception }
                val suffixLabels = if (ex.isNotEmpty()) ex.maxOf { it.labels.size } - 1 else (cand.maxOfOrNull { it.labels.size } ?: 1)
                if (l.size <= suffixLabels) return null
                return l.take(suffixLabels + 1).reversed().joinToString(".")
            }
            val rnd = Random(2202)
            val letters = "abcdefghijklmnopqrstuvwxyz0123456789"
            fun lab() = (0 until 1 + rnd.nextInt(6)).map { letters[rnd.nextInt(letters.length)] }.joinToString("")
            var diff = 0; var shown = ""; var tested = 0
            repeat(150_000) {
                val labels = ArrayList<String>()
                when (rnd.nextInt(4)) {
                    0 -> repeat(1 + rnd.nextInt(4)) { labels.add(lab()) }
                    else -> {
                        val r = rules[rnd.nextInt(rules.size)]
                        for (x in r.labels.reversed()) labels.add(if (x == "*") lab() else x)
                    }
                }
                repeat(rnd.nextInt(3)) { labels.add(0, lab()) }
                if (rnd.nextInt(6) == 0 && labels.size > 1) labels[rnd.nextInt(labels.size)] = lab()
                val name = labels.joinToString(".")
                val buf = name.toByteArray(Charsets.US_ASCII)
                val st = PublicSuffix.registrableStart(buf, buf.size)
                // st==0: ad tek başına sonek ya da tümü kayıt edilebilir olabilir; referans null ise 0 beklenir, değilse aynı metin.
                val oursFull = if (st <= 0) name else String(buf, st, buf.size - st, Charsets.US_ASCII)
                val ref = refRegistrable(name)
                tested++
                val ok = if (ref == null) st == 0 else oursFull == ref
                if (!ok) { diff++; if (shown.isEmpty()) shown = "'$name' bizim='${oursFull}' (st=$st) referans='$ref'" }
            }
            T.check("$tested adın hepsi PSL algoritmasıyla aynı kayıt edilebilir alanı verir", diff == 0, "fark=$diff $shown")
        } finally {
            PublicSuffix.clear()
            if (was) f.inputStream().use { PublicSuffix.install(it) }
        }
    }

    // ---------------------------------------------------------------- TCP/UDP sağlama toplamları ↔ bağımsız referans
    T.group("Sızma 22 / TCP+UDP sağlama toplamı (IPv4 ve IPv6): bağımsız sözde-başlık referansı; her tek bit hatası yakalanır")
    run {
        val rnd = Random(2203)
        fun ref(v6: Boolean, pkt: ByteArray, ipLen: Int, proto: Int, l4Len: Int): Int {
            val addrLen = if (v6) 16 else 4
            val src = pkt.copyOfRange(if (v6) 8 else 12, (if (v6) 8 else 12) + addrLen)
            val dst = pkt.copyOfRange(if (v6) 24 else 16, (if (v6) 24 else 16) + addrLen)
            val ph = java.io.ByteArrayOutputStream()
            ph.write(src); ph.write(dst)
            if (v6) { ph.write(byteArrayOf(0, 0, (l4Len ushr 8).toByte(), l4Len.toByte(), 0, 0, 0, proto.toByte())) }
            else { ph.write(byteArrayOf(0, proto.toByte(), (l4Len ushr 8).toByte(), l4Len.toByte())) }
            val seg = pkt.copyOfRange(ipLen, ipLen + l4Len)
            val csOff = if (proto == 6) 16 else 6
            seg[csOff] = 0; seg[csOff + 1] = 0
            ph.write(seg)
            val all = ph.toByteArray()
            var sum = 0L
            var i = 0
            while (i < all.size) { val hi = all[i].toInt() and 0xFF; val lo = if (i + 1 < all.size) all[i + 1].toInt() and 0xFF else 0; sum += (hi shl 8) or lo; i += 2 }
            while (sum ushr 16 != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
            val c = sum.inv().toInt() and 0xFFFF
            return if (proto == 17 && c == 0) 0xFFFF else c
        }
        var refDiff = 0; var undetected = 0; var shown = ""; var n = 0
        repeat(6000) { iter ->
            val v6 = rnd.nextBoolean(); val tcp = rnd.nextBoolean()
            val src = ByteArray(if (v6) 16 else 4).also { rnd.nextBytes(it) }
            val dst = ByteArray(if (v6) 16 else 4).also { rnd.nextBytes(it) }
            val data = ByteArray(rnd.nextInt(0, 400)).also { rnd.nextBytes(it) }
            val out = ByteArray(2000)
            val total = if (tcp) Gw.tcp(out, v6, src, dst, 1 + rnd.nextInt(65535), 1 + rnd.nextInt(65535), rnd.nextInt(), rnd.nextInt(), rnd.nextInt(64), rnd.nextInt(70000), data, 0, data.size, if (rnd.nextInt(3) == 0) 1 + rnd.nextInt(1460) else 0)
                else Gw.udp(out, v6, src, dst, 1 + rnd.nextInt(65535), 1 + rnd.nextInt(65535), data, 0, data.size)
            val ipLen = if (v6) 40 else 20
            val l4 = total - ipLen
            val proto = if (tcp) 6 else 17
            val stored = Packets.u16(out, ipLen + (if (tcp) 16 else 6))
            n++
            if (stored != ref(v6, out, ipLen, proto, l4)) { refDiff++; if (shown.isEmpty()) shown = "v6=$v6 tcp=$tcp len=$l4" }
            if (!Gw.checksumOk(out, total)) { refDiff++; if (shown.isEmpty()) shown = "üretilen paket doğrulanamadı v6=$v6 tcp=$tcp" }
            // tek bit hatası: kapsanan her bayt
            repeat(12) {
                val pkt = out.copyOf(total)
                var byteIx = rnd.nextInt(total)
                if (v6 && (byteIx < 4 || byteIx == 7)) byteIx = 8 + rnd.nextInt(total - 8)          // trafik sınıfı/akış etiketi/sıçrama sınırı sağlama toplamına girmez
                if (!v6 && byteIx in 0..1) byteIx = 12 + rnd.nextInt(total - 12)                    // sürüm/IHL ve TOS: IHL değişimi başka ayrıştırma yoludur
                pkt[byteIx] = (pkt[byteIx].toInt() xor (1 shl rnd.nextInt(8))).toByte()
                val udpZeroed = !tcp && !v6 && Packets.u16(pkt, ipLen + 6) == 0                    // IPv4 UDP'de 0 = "sağlama toplamı yok"
                val sameVersion = (pkt[0].toInt() ushr 4) == (out[0].toInt() ushr 4) && (v6 || (pkt[0].toInt() and 0xF) == 5)
                if (sameVersion && !udpZeroed && Gw.checksumOk(pkt, total)) { undetected++; if (shown.isEmpty()) shown = "kaçan bit hatası: bayt=$byteIx v6=$v6 tcp=$tcp" }
            }
        }
        T.check("$n paket: yazılan sağlama toplamı bağımsız referansla aynı ve doğrulanır", refDiff == 0, "fark=$refDiff $shown")
        T.check("72 bin tek bit hatasının hiçbiri kabul edilmez", undetected == 0, "kaçan=$undetected $shown")
    }

    // ---------------------------------------------------------------- Immune: doğrulama turu (mutasyon boşluğu)
    T.group("Sızma 22 / Immune: eşiği aşan ama patlama olmayan sinyal TEK turda değil, art arda 2 turda önlem açar")
    run {
        class NoExplore : java.util.Random() { override fun nextInt(bound: Int): Int = bound - 1 }
        val min = 60_000L
        val im = Immune(NoExplore())
        // SPOOF eşiği 4.0, anında-harekete-geçme 4.0×1.5 = 6.0: toplam 5.0 eşiği aşar ama patlama değildir
        im.report(Threat.SPOOF, 4.5, min - 1000)
        val first = im.tick(min)
        im.report(Threat.SPOOF, 0.5, 2 * min - 1000)          // pencere toplamı 5.0 kalır (6.0 altında), iki farklı dakikaya yayılır
        val second = im.tick(2 * min)
        T.check("1. turda (tek seferlik gürültü olabilir) önlem yok", first.isEmpty(), first.toString())
        T.check("2. art arda turda önlem açılır", second.size == 1 && second[0].threat == Threat.SPOOF && second[0].on, second.toString())
        // aynı sinyal bir tur sonra kesilirse (streak sıfırlanır) hiç önlem yok
        val im2 = Immune(NoExplore())
        im2.report(Threat.SPOOF, 4.5, min - 1000)
        val a = im2.tick(min)
        val b = im2.tick(4 * min)       // sinyal pencereden çıktı
        im2.report(Threat.SPOOF, 4.5, 5 * min - 1000)
        val c = im2.tick(5 * min)
        T.check("kesintili sinyal (1 tur, boşluk, 1 tur) önlem açmaz", a.isEmpty() && b.isEmpty() && c.isEmpty(), "$a $b $c")
    }

    // ---------------------------------------------------------------- Format.share / clock / span / ago (mutasyon boşluğu)
    T.group("Sızma 22 / Format.share, clock, span, ago: sınır değerleri tablosu")
    run {
        val tx = L.tx
        T.check("share: pay yoksa ya da toplam 0 ise boş", Format.share(0, 10) == "" && Format.share(5, 0) == "" && Format.share(-1, 10) == "")
        T.check("share: %1'in altı '<' ile gösterilir, tam %1 değil", Format.share(1, 1000) == "<" + tx.percent(1) && Format.share(99, 10_000) == "<" + tx.percent(1) && Format.share(1, 100) == tx.percent(1))
        T.check("share: %4, %50, %100; %100'ü aşarsa %100", Format.share(4, 100) == tx.percent(4) && Format.share(1, 2) == tx.percent(50) && Format.share(7, 7) == tx.percent(100) && Format.share(150, 100) == tx.percent(100))
        T.check("countWithShare: pay yoksa yalnızca sayı", Format.countWithShare(0, 100) == Format.count(0) && Format.countWithShare(5, 100) == Format.count(5) + " · " + tx.percent(5))
        T.check("clock: 0 → 00:00, 59 → 00:59, 754 → 12:34, 3599 → 59:59, 3600 → 1:00:00, 3725 → 1:02:05, negatif → 00:00", Format.clock(0) == "00:00" && Format.clock(59) == "00:59" && Format.clock(754) == "12:34" && Format.clock(3599) == "59:59" && Format.clock(3600) == "1:00:00" && Format.clock(3725) == "1:02:05" && Format.clock(-5) == "00:00")
        T.check("span: sınırlar 59 sn / 1 dk / 59 dk / 1 sa / 23 sa 59 dk / 1 gün", Format.span(59) == "59 ${tx.secU}" && Format.span(60) == "1 ${tx.minU}" && Format.span(3599) == "59 ${tx.minU}" && Format.span(3600) == "1 ${tx.hourU}" && Format.span(86399) == "23 ${tx.hourU} 59 ${tx.minU}" && Format.span(86400) == "1 ${tx.dayU}" && Format.span(90000) == "1 ${tx.dayU} 1 ${tx.hourU}")
        T.check("ago: 44 sn az önce; 45 sn → 1 dk; 89 dk → 89 dk; 90 dk → 2 sa; 36 sa → 2 gün", Format.ago(44_000) == tx.justNow && Format.ago(45_000) == tx.ago("1 ${tx.minU}") && Format.ago(89 * 60_000L) == tx.ago("89 ${tx.minU}") && Format.ago(90 * 60_000L) == tx.ago("2 ${tx.hourU}") && Format.ago(36 * 3600_000L) == tx.ago("2 ${tx.dayU}") && Format.ago(-5) == tx.justNow)
    }

    // ---------------------------------------------------------------- ServerList.fastest / recommend: eşitlikte katalog sırası
    T.group("Sızma 22 / ServerList: eşit gecikmede katalog sırası kazanır; cevapsız ve ölçülmemiş sunucular en hızlı sayılmaz")
    run {
        val all = Catalog.builtin.take(5)
        val lat = HashMap<String, Latency>()
        lat[all[1].id] = Latency(20, 1); lat[all[2].id] = Latency(20, 1); lat[all[3].id] = Latency(35, 1); lat[all[4].id] = Latency(null, 1)
        T.check("eşit gecikmede katalogdaki İLK sunucu seçilir", ServerList.fastest(all, lat)?.first?.id == all[1].id && ServerList.fastest(all, lat)?.second == 20)
        T.check("kullanılamayan atlanır: ilki dışarıda kalırsa ikinci eşit olan", ServerList.fastest(all, lat) { it.id != all[1].id }?.first?.id == all[2].id)
        T.check("hiç ölçüm yoksa null; yalnızca cevapsız varsa null", ServerList.fastest(all, emptyMap()) == null && ServerList.fastest(all, mapOf(all[4].id to Latency(null, 1))) == null)
        T.check("recommend: ölçüm varsa en hızlı, yoksa katalogdaki ilk uygun", ServerList.recommend(all, null, lat)?.id == all[1].id && ServerList.recommend(all, null, emptyMap())?.id == all[0].id && ServerList.recommend(all, null, emptyMap()) { it.id == all[3].id }?.id == all[3].id)
        val order = ServerList.visible(all, null, emptySet(), lat, SortMode.SPEED).map { it.id }
        T.check("hız sıralaması: ölçülmüşler hızlıdan yavaşa (eşitte katalog sırası), sonra ölçülmemiş, en sonda cevapsız", order == listOf(all[1].id, all[2].id, all[3].id, all[0].id, all[4].id), order.toString())
        T.check("sinyal çubukları sınırları: 25→4, 26→3, 50→3, 51→2, 100→2, 101→1, null→0", ServerList.bars(25) == 4 && ServerList.bars(26) == 3 && ServerList.bars(50) == 3 && ServerList.bars(51) == 2 && ServerList.bars(100) == 2 && ServerList.bars(101) == 1 && ServerList.bars(null) == 0)
    }

    T.group("Sızma 22 / LatencyHistory.mean: bozuk/büyük kayıtlı değerlerde Int taşması yok")
    run {
        val big = listOf<Int?>(Int.MAX_VALUE, Int.MAX_VALUE, 10, null)
        val m = LatencyHistory.mean(big)
        T.check("ortalama doğru (taşmaz) ve sayı 3", m != null && m.second == 3 && m.first == ((2L * Int.MAX_VALUE + 10) / 3).toInt(), m.toString())
        T.check("ortanca/en iyi/kayıp yüzdesi", LatencyHistory.median(listOf(5, null, 9, 1)) == 5 && LatencyHistory.best(listOf(null, 7, 3)) == 3 && LatencyHistory.lossPct(listOf(1, null, null, 4)) == 50)
    }
}
