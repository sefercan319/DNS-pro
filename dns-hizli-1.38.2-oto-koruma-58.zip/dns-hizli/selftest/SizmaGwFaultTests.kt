package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.ServerSocket
import java.util.Random
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * Sızma 10 — ağ geçidi iç hata yalıtımı ve durumlu saldırgan soak.
 *  1) Hata enjeksiyonu: tünele yazma hatası, protect() istisnası, akış içinde beklenmeyen istisna/Error. Beklenen: döngü ölmez, yalnızca
 *     ilgili akış kapanır (istemciye RST), tablo/sayaç/bellek tutarlı kalır, sayaç görünür.
 *  2) Soak: dürüst akışların (veri bütünlüğü kâhini) yanında rastgele davranan düşman akışlar (bozuk sıra/ack/pencere/bayrak/seçenek,
 *     SYN seli, ani kapanışlar, RST, UDP gürültüsü). Kâhinler: iç hata 0, çıktı sağlamaları doğru, yakalanmamış istisna yok,
 *     dürüst akışlar bozulmadan tamamlanır, sonunda akış tablosu ve ortak bellek sıfırlanır.
 */
fun runGatewayFaultTests() {
    gwFaultInjectionTests()
    gwStatefulSoakTests()
    gwConfigChurnTests()
}

private val EMPTY = ByteArray(0)
private val GOOD_REPLY = byteArrayOf(0x16, 3, 3, 0, 4, 2, 0, 0, 0)

/** Bu süreçteki açık dosya tanıtıcısı (soket dahil) sayısı (Linux /proc); okunamazsa -1. Hata yollarında sızan soket telefonda "Too many open files" ile servisi düşürür. */
internal fun fdCount(): Int = try { java.io.File("/proc/self/fd").list()?.size ?: -1 } catch (_: Exception) { -1 }

/** Açık tanıtıcı sayısı [limit]'e inene dek (en çok [ms]) bekler; sayı okunamıyorsa (Linux dışı) true. */
internal fun fdSettles(limit: Int, ms: Long): Boolean = fdCount() < 0 || waitUntil(ms) { fdCount() <= limit }

/** İlk okumaya TLS benzeri cevap, sonrasını yankılar. */
private fun echoAfterHello() = Srv { s ->
    val i = s.getInputStream(); val o = s.getOutputStream(); val b = ByteArray(8192)
    var first = true
    while (true) {
        val n = try { i.read(b) } catch (_: Exception) { -1 }
        if (n < 0) break
        if (first) { first = false; o.write(GOOD_REPLY) } else o.write(b, 0, n)
        o.flush()
    }
}

private fun warmFlow(r: GRig, port: Int, name: String): GCli? {
    val c = GCli(r, port)
    val sa = c.connect() ?: return null
    if (sa.flags != (F_SYN or F_ACK)) return null
    c.write(testHello(name))
    return if (c.read(GOOD_REPLY.size, 4000).size == GOOD_REPLY.size) c else null
}

/** İstemciye RST gelene dek (en çok [ms]) segmentleri okur. */
private fun gotRst(c: GCli, ms: Long): Boolean {
    val end = System.currentTimeMillis() + ms
    while (System.currentTimeMillis() < end) {
        val s = c.next(end - System.currentTimeMillis()) ?: return false
        if (s.flags and F_RST != 0) return true
    }
    return false
}

private fun gwFaultInjectionTests() {
    T.group("Sızma 10 / ağ geçidi: tünele yazma hatası akışı açık bırakmaz (ağ sıfırlama, boşta zaman aşımı; IOException ve istisna)")
    fun scenario(label: String, fault: Throwable, counted: Boolean, idleMs: Long, reset: Boolean) {
        val r = GRig()
        if (idleMs > 0) r.gw.config.tcpIdleMs = idleMs
        val closed = AtomicInteger()
        val srv = Srv { s -> try { while (s.getInputStream().read() >= 0) { } } catch (_: Exception) { }; closed.incrementAndGet() }
        val sink = Sink(echo = true)
        val fd0 = fdCount()
        try {
            val est = (0 until 6).count { GCli(r, srv.port).connect()?.flags == (F_SYN or F_ACK) }
            T.check("$label: 6 akış kuruldu", est == 6, "$est")
            r.outFault = { fault }
            if (reset) r.gw.networkReset()
            val gone = waitUntil(10_000) { r.gw.stats().tcpFlows == 0 }
            T.check("$label: tünel yazılamasa da tüm akışlar kapanır ve tablodan çıkar", gone, "kalan=${r.gw.stats().tcpFlows}")
            T.check("$label: sunucu soketleri bırakıldı (6/6)", waitUntil(3000) { closed.get() == 6 }, "kapanan=${closed.get()}")
            T.check("$label: yazma girişimi gerçekten başarısız oldu (enjeksiyon etkili)", r.faults.get() >= 1, "hata=${r.faults.get()}")
            val ie = r.gw.stats().internalErrors
            T.check("$label: iç hata sayacı ${if (counted) "arttı" else "artmadı (ağ hatası beklenen durum)"}", if (counted) ie >= 1 else ie == 0L, "sayaç=$ie ${r.gw.lastInternalError()}")
            T.check("$label: ortak bellek tamamen geri verildi", r.gw.mem.used == 0, "kullanım=${r.gw.mem.used}")
            T.check("$label: dosya tanıtıcısı sızmaz ($fd0 → ${fdCount()})", fdSettles(fd0 + 3, 6000), "başlangıç=$fd0 şimdi=${fdCount()}")
            r.outFault = null
            val c = GCli(r, sink.port); c.connect(); c.write("ping".toByteArray())
            T.check("$label: hata sonrası yeni akış çalışır", String(c.read(4, 4000)) == "ping")
        } finally { srv.close(); sink.close(); r.close() }
    }
    scenario("IOException + ağ sıfırlama", IOException("enjekte: tünel kapalı"), counted = false, idleMs = 0, reset = true)
    scenario("IllegalStateException + ağ sıfırlama", IllegalStateException("enjekte"), counted = true, idleMs = 0, reset = true)
    scenario("IOException + boşta zaman aşımı", IOException("enjekte: tünel kapalı"), counted = false, idleMs = 400, reset = false)
    scenario("AssertionError + boşta zaman aşımı", AssertionError("enjekte"), counted = true, idleMs = 400, reset = false)

    T.group("Sızma 10 / ağ geçidi: VpnService.protect() atar ya da false döner — istemci hemen RST alır, akış sızmaz")
    val protThrow: (java.net.Socket) -> Boolean = { _ -> throw IllegalStateException("protect") }
    val protFalse: (java.net.Socket) -> Boolean = { _ -> false }
    for ((label, prot) in listOf("istisna atar" to protThrow, "false döner" to protFalse)) {
        val r = GRig(protect = prot)
        val fd0 = fdCount()
        try {
            val got = (0 until 5).count { val c = GCli(r, 9); c.send(F_SYN, mss = 1460); gotRst(c, 3000) }
            T.check("protect $label: 5/5 istemci RST alır (asılı kalmaz)", got == 5, "$got")
            T.check("protect $label: bağlantı hatası sayıldı", r.gw.stats().connectFail >= 5, "hata=${r.gw.stats().connectFail}")
            T.check("protect $label: akışlar tablodan çıkar", waitUntil(7000) { r.gw.stats().tcpFlows == 0 }, "kalan=${r.gw.stats().tcpFlows}")
            T.check("protect $label: iç hata değil (beklenen hata yolu)", r.gw.stats().internalErrors == 0L, r.gw.lastInternalError())
            T.check("protect $label: reddedilen soketler kapatıldı, dosya tanıtıcısı sızmaz ($fd0 → ${fdCount()})", fdSettles(fd0 + 2, 5000), "başlangıç=$fd0 şimdi=${fdCount()}")
        } finally { r.close() }
    }

    T.group("Sızma 10 / ağ geçidi: akış içinde beklenmeyen istisna/Error yalnızca o akışı kapatır (RST), döngü ve komşu akışlar etkilenmez")
    run {
        val r = GRig()
        val srv = echoAfterHello()
        val fault = AtomicReference<Throwable?>(null)
        r.gw.config.adsSource = { fault.get()?.let { throw it }; null }
        val fd0 = fdCount()
        try {
            val healthy = ArrayList<GCli>()
            for (i in 0 until 4) warmFlow(r, srv.port, "saglikli$i.test")?.let { healthy.add(it) }
            T.check("4 sağlıklı akış ilk uçuşu geçti", healthy.size == 4, "${healthy.size}")
            val faults = listOf<Throwable>(
                IllegalStateException("enjekte"), IndexOutOfBoundsException("enjekte"), NullPointerException("enjekte"),
                StackOverflowError(), OutOfMemoryError("enjekte"), AssertionError("enjekte"),
            )
            var rsts = 0; var allHealthy = true
            for ((k, f) in faults.withIndex()) {
                fault.set(f)
                val bad = GCli(r, srv.port)
                val sa = bad.connect()
                bad.write(testHello("bozuk$k.test"))
                if (sa != null && gotRst(bad, 3000)) rsts++
                fault.set(null)
                // aynı anda sağlıklı akışlar çalışmaya devam eder
                val payload = ByteArray(1200) { (it * 7 + k).toByte() }
                for (h in healthy) { h.write(payload); if (!h.read(payload.size, 4000).contentEquals(payload)) allHealthy = false }
            }
            T.check("6 farklı hata türü (RuntimeException ve Error'lar): her bozuk akış RST alır", rsts == faults.size, "$rsts/${faults.size}")
            T.check("her hatadan sonra sağlıklı akışlar bayt bayt doğru yankı alır", allHealthy)
            val st = r.gw.stats()
            T.check("iç hata sayacı tam ${faults.size}", st.internalErrors == faults.size.toLong(), "sayaç=${st.internalErrors} ${r.gw.lastInternalError()}")
            val fresh = warmFlow(r, srv.port, "yeni.test")
            T.check("gw-io iş parçacığı yaşıyor: hatalardan sonra yepyeni akış çalışır", fresh != null)
            T.check("bozuk akışlar tablodan çıkar (yalnızca sağlıklı 5 kalır)", waitUntil(6000) { r.gw.stats().tcpFlows == 5 }, "akış=${r.gw.stats().tcpFlows}")
            r.gw.networkReset()
            T.check("ağ sıfırlama sonrası tablo ve bellek sıfır", waitUntil(8000) { r.gw.stats().tcpFlows == 0 } && r.gw.mem.used == 0, "akış=${r.gw.stats().tcpFlows} bellek=${r.gw.mem.used}")
            T.check("hatalı akışlar soketlerini sızdırmaz ($fd0 → ${fdCount()})", fdSettles(fd0 + 3, 6000), "başlangıç=$fd0 şimdi=${fdCount()}")
        } finally { srv.close(); r.close() }
    }
}

// =============================================================================================== durumlu saldırgan soak

private class SoakPeer(val sport: Int, val dport: Int, val honest: Boolean, val rnd: Random, val tlsFirst: Boolean = false) {
    val isn = rnd.nextInt()
    var seq = isn                // istemcinin sıradaki bayt numarası
    var una = 0                  // ağ geçidinin onayladığı son numara (geçitten gelen ack)
    var iss = 0                  // sunucunun ilk sıra numarası
    var rcv = 0                  // sunucudan beklenen sıradaki bayt
    var phase = 0                // 0 yeni, 1 SYN gitti, 2 kuruldu, 3 bitti
    var synAt = 0L
    var rxBytes = 0L
    var finRx = false
    // dürüst akış
    var round = 0
    var chunk = EMPTY
    var sentAt = 0L
    val echo = ByteArrayOutputStream()
    var corrupt = false
    var rstSeen = false
    var done = false
    var retx = 0
}

private class Soak(val r: GRig, seed: Long) {
    val rnd = Random(seed)
    val peers = HashMap<Int, SoakPeer>()
    val buf = ByteArray(2048)
    var badSum = 0
    var rxPk = 0L
    var txPk = 0L
    var spawned = 0
    var maxFlows = 0
    val srvPorts = ArrayList<Int>()
    var echoPort = 0

    fun tx(p: SoakPeer, flags: Int, data: ByteArray = EMPTY, seqNo: Int = p.seq, ackNo: Int = p.rcv, win: Int = 65535, mss: Int = 0) {
        val n = Gw.tcp(buf, false, CLI4, LO4, p.sport, p.dport, seqNo, ackNo, flags, win, data, 0, data.size, mss)
        r.gw.onPacket(buf.copyOf(n), n); txPk++
    }

    /** Seçenek baytları ve acil işaretçi serbest ham TCP segmenti (seçenekler en çok 40 bayt). */
    fun txRaw(p: SoakPeer, flags: Int, data: ByteArray, seqNo: Int, ackNo: Int, win: Int, opts: ByteArray, urg: Int) {
        val o0 = if (opts.size > 40) opts.copyOf(40) else opts
        val o = if (o0.size % 4 == 0) o0 else o0.copyOf((o0.size + 3) / 4 * 4)
        val tcpLen = 20 + o.size + data.size
        val b = ByteArray(20 + tcpLen)
        b[0] = 0x45; Packets.put16(b, 2, b.size); b[8] = 64; b[9] = 6
        System.arraycopy(CLI4, 0, b, 12, 4); System.arraycopy(LO4, 0, b, 16, 4)
        val t = 20
        Packets.put16(b, t, p.sport); Packets.put16(b, t + 2, p.dport); Packets.put32(b, t + 4, seqNo); Packets.put32(b, t + 8, ackNo)
        b[t + 12] = (((20 + o.size) / 4) shl 4).toByte(); b[t + 13] = flags.toByte(); Packets.put16(b, t + 14, win); Packets.put16(b, t + 18, urg)
        System.arraycopy(o, 0, b, t + 20, o.size); System.arraycopy(data, 0, b, t + 20 + o.size, data.size)
        r.gw.onPacket(b, b.size); txPk++
    }

    fun randBytes(n: Int): ByteArray = ByteArray(n).also { rnd.nextBytes(it); if (n > 0 && it[0].toInt() == 0x16) it[0] = 0x17 }

    fun garbageOpts(): ByteArray = when (rnd.nextInt(7)) {
        0 -> byteArrayOf(2, 4, 5, 0xB4.toByte())
        1 -> byteArrayOf(3, 3, 14, 1, 4, 2, 8, 10, 1, 2, 3, 4, 5, 6, 7, 8)
        2 -> byteArrayOf(2, 0, 0, 0)                                  // uzunluk 0 (sonsuz döngü avı)
        3 -> byteArrayOf(2, 1, 1, 1)                                  // uzunluk 1
        4 -> byteArrayOf(2, 255.toByte(), 2, 4, 5, 6)                 // sınır dışı uzunluk
        5 -> byteArrayOf(1, 1, 1, 1, 1, 1, 1, 1, 0)                   // NOP'lar + bitiş
        else -> ByteArray(4 * (1 + rnd.nextInt(10))).also { rnd.nextBytes(it) }
    }

    fun payload(): ByteArray = when (rnd.nextInt(8)) {
        0 -> testHello("soak${rnd.nextInt(40)}.example", rnd.nextInt(300))
        1 -> "GET /${rnd.nextInt(1000)} HTTP/1.1\r\nHost: h${rnd.nextInt(30)}.test\r\n\r\n".toByteArray()
        2 -> "POST / HTTP/1.1\r\nHost: reklam.example\r\nContent-Length: 5\r\n\r\nabcde".toByteArray()   // engelli ad
        3 -> testHello("reklam.example")                                                                   // engelli SNI
        4 -> "GET / HTTP/1.1\r\nHost: slow".toByteArray()                                                   // yarım başlık (yavaş damlatma)
        else -> randBytes(1 + rnd.nextInt(1400))
    }

    fun spawn(honest: Boolean, tls: Boolean = false): SoakPeer {
        val port = if (honest) echoPort else srvPorts[rnd.nextInt(srvPorts.size)]
        val p = SoakPeer(portCounter.incrementAndGet(), port, honest, Random(rnd.nextLong()), tls)
        peers[p.sport] = p; spawned++
        return p
    }

    // ---------------------------------------------------------------------------------- geçitten gelenler
    fun rx(pk: ByteArray) {
        rxPk++
        if (!Gw.checksumOk(pk, pk.size)) badSum++
        if ((pk[0].toInt() ushr 4) != 4 || pk[9].toInt() != 6) return
        val ip = (pk[0].toInt() and 0xF) * 4
        val p = peers[Packets.u16(pk, ip + 2)] ?: return
        if (Packets.u16(pk, ip) != p.dport) return
        val doff = (pk[ip + 12].toInt() and 0xF0) ushr 2
        val fl = pk[ip + 13].toInt() and 0xFF
        val sq = Packets.i32(pk, ip + 4)
        val dlen = pk.size - ip - doff
        if (fl and F_RST != 0) { if (p.phase in 1..2) { p.phase = 3; if (p.honest && !p.done) p.rstSeen = true }; return }
        if (p.phase == 1) {
            if (fl and (F_SYN or F_ACK) == (F_SYN or F_ACK) && Packets.i32(pk, ip + 8) == p.isn + 1) {
                p.iss = sq; p.rcv = sq + 1; p.phase = 2; p.seq = p.isn + 1; p.una = p.isn + 1
                tx(p, F_ACK)
            }
            return
        }
        if (p.phase != 2 || fl and F_SYN != 0) return
        if (fl and F_ACK != 0) { val a = Packets.i32(pk, ip + 8); if (Gw.seqLt(p.una, a)) p.una = a }
        if (dlen > 0) {
            val skip = p.rcv - sq
            if (skip in 0 until dlen) {
                val take = dlen - skip
                p.rcv += take; p.rxBytes += take
                if (p.honest) p.echo.write(pk, ip + doff + skip, take)
                if (p.honest || rnd.nextInt(10) < 7) tx(p, F_ACK)
            } else if (p.honest || rnd.nextInt(10) < 3) tx(p, F_ACK)         // yinelenen / sıra dışı: çift ACK
        }
        if (fl and F_FIN != 0 && sq + dlen == p.rcv && !p.finRx) { p.rcv++; p.finRx = true; tx(p, F_ACK) }
    }

    // ---------------------------------------------------------------------------------- dürüst akış (kâhin)
    /** Tam TLS kayıtlarının yüklerini birleştirir (DPI bölmesi ek kayıt başlığı koyar); 0x16 dışı kayıt görürse null. */
    private fun tlsBodies(b: ByteArray, consumed: IntArray): ByteArray? {
        val o = ByteArrayOutputStream(); var i = 0
        while (i + 5 <= b.size) {
            if (b[i].toInt() != 0x16) return null
            val len = Packets.u16(b, i + 3)
            if (i + 5 + len > b.size) break
            o.write(b, i + 5, len); i += 5 + len
        }
        consumed[0] = i
        return o.toByteArray()
    }

    /** 0 = cevap tamamlanmadı, 1 = doğru, 2 = bozuk. İlk TLS uçuşu DPI ile kayıtlara bölünebilir (meşru): yükler birleştirilip karşılaştırılır. */
    fun verdict(p: SoakPeer): Int {
        val got = p.echo.toByteArray()
        if (p.round == 0 && p.tlsFirst) {
            val c = IntArray(1)
            val body = tlsBodies(got, c) ?: return 2
            if (body.size < p.chunk.size - 5) return 0
            return if (c[0] == got.size && body.contentEquals(p.chunk.copyOfRange(5, p.chunk.size))) 1 else 2
        }
        if (got.size < p.chunk.size) return 0
        return if (got.size == p.chunk.size && got.contentEquals(p.chunk)) 1 else 2
    }

    fun stepHonest(p: SoakPeer, now: Long, endAt: Long) {
        when (p.phase) {
            0 -> { p.phase = 1; p.synAt = now; p.seq = p.isn; tx(p, F_SYN, mss = 1460, seqNo = p.isn, ackNo = 0); p.seq = p.isn + 1 }
            1 -> if (now - p.synAt > 700) { p.synAt = now; tx(p, F_SYN, mss = 1460, seqNo = p.isn, ackNo = 0) }
            2 -> {
                if (p.done) return
                if (p.chunk.isEmpty()) {
                    if (now >= endAt) { tx(p, F_FIN or F_ACK); p.seq++; p.done = true; return }
                    val n = 1 + rnd.nextInt(1200)
                    p.chunk = if (p.round == 0 && p.tlsFirst) testHello("dogru${p.sport}.example", 40 + rnd.nextInt(200))
                    else ByteArray(n).also { rnd.nextBytes(it); it[0] = 0x01 }
                    p.echo.reset()
                    tx(p, F_ACK or F_PSH, p.chunk); p.seq += p.chunk.size; p.sentAt = now
                } else {
                    val v = verdict(p)
                    if (v != 0) { if (v == 2) p.corrupt = true; p.round++; p.chunk = EMPTY }
                    else if (now - p.sentAt > 1500) { tx(p, F_ACK or F_PSH, p.chunk, seqNo = p.seq - p.chunk.size); p.sentAt = now; p.retx++ }
                }
            }
        }
    }

    // ---------------------------------------------------------------------------------- düşman akış
    fun oddAck(p: SoakPeer): Int = when (rnd.nextInt(8)) {
        0 -> p.rcv; 1 -> p.rcv - 1; 2 -> p.rcv + 1; 3 -> p.rcv + 100_000; 4 -> rnd.nextInt(); 5 -> 0; 6 -> p.iss; else -> p.rcv + 1 + rnd.nextInt(5000)
    }

    fun oddWin(): Int = when (rnd.nextInt(6)) { 0 -> 0; 1 -> 1; 2 -> 2; 3 -> 536; 4 -> 65535; else -> rnd.nextInt(65536) }

    fun stepAdv(p: SoakPeer, now: Long) {
        when (p.phase) {
            0 -> {
                p.phase = 1; p.synAt = now
                val mss = intArrayOf(0, 1, 100, 536, 1460, 9000, 65535)[rnd.nextInt(7)]
                when (rnd.nextInt(5)) {
                    0 -> txRaw(p, F_SYN, EMPTY, p.isn, 0, 65535, garbageOpts(), 0)
                    1 -> tx(p, F_SYN, mss = mss, win = oddWin(), seqNo = p.isn, ackNo = 0)
                    else -> tx(p, F_SYN, mss = mss, seqNo = p.isn, ackNo = 0)
                }
                p.seq = p.isn + 1
            }
            1 -> if (now - p.synAt > 2500) p.phase = 3
            2 -> action(p)
        }
    }

    fun action(p: SoakPeer) {
        val k = rnd.nextInt(100)
        when {
            k < 22 -> { val d = payload(); tx(p, F_ACK or F_PSH, d); p.seq += d.size }                                       // sıralı veri
            k < 28 -> tx(p, F_ACK or F_PSH, randBytes(1 + rnd.nextInt(1400)), seqNo = p.seq - 1 - rnd.nextInt(3000))        // eski veri
            k < 33 -> tx(p, F_ACK or F_PSH, randBytes(1 + rnd.nextInt(1400)), seqNo = p.seq + 1 + rnd.nextInt(70_000))      // boşluklu veri
            k < 38 -> { val back = 1 + rnd.nextInt(600); val d = randBytes(back + 1 + rnd.nextInt(800)); tx(p, F_ACK or F_PSH, d, seqNo = p.seq - back); p.seq += d.size - back }   // örtüşme
            k < 46 -> tx(p, F_ACK, ackNo = oddAck(p), win = oddWin())                                                         // tuhaf ACK / pencere
            k < 50 -> repeat(3 + rnd.nextInt(4)) { tx(p, F_ACK) }                                                             // çift ACK (hızlı yeniden iletim)
            k < 53 -> { tx(p, F_FIN or F_ACK); p.seq++ }                                                                      // sıralı FIN
            k < 55 -> tx(p, F_FIN or F_ACK, seqNo = p.seq + 1 + rnd.nextInt(5000))                                            // gelecekten FIN
            k < 57 -> tx(p, F_FIN or F_ACK, seqNo = p.seq - 1)                                                                // yinelenen FIN
            k < 59 -> { val d = randBytes(1 + rnd.nextInt(100)); tx(p, F_FIN or F_ACK or F_PSH, d); p.seq += d.size + 1 }     // FIN + veri
            k < 62 -> tx(p, F_RST, seqNo = when (rnd.nextInt(5)) { 0 -> p.seq + 1; 1 -> p.seq - 1; 2 -> p.seq + 65_535; 3 -> rnd.nextInt(); else -> p.seq + 100 + rnd.nextInt(60_000) })   // çoğu pencere dışı RST
            k < 63 -> { tx(p, F_RST or F_ACK, seqNo = p.seq); p.phase = 3 }                                                   // pencere içi RST: akışı kapatır
            k < 65 -> tx(p, F_SYN, seqNo = if (rnd.nextBoolean()) p.isn else rnd.nextInt(), ackNo = 0, mss = 1460)           // kurulu akışta SYN
            k < 67 -> tx(p, F_SYN or F_FIN or F_ACK, payload(), seqNo = p.seq)                                                // SYN+FIN çöpü
            k < 72 -> tx(p, rnd.nextInt(64), randBytes(rnd.nextInt(200)), seqNo = if (rnd.nextBoolean()) p.seq else rnd.nextInt(), ackNo = oddAck(p))   // rastgele bayraklar
            k < 77 -> { val d = payload(); txRaw(p, F_ACK or F_PSH or (if (rnd.nextBoolean()) 0x20 else 0), d, p.seq, p.rcv, 65535, garbageOpts(), rnd.nextInt(65536)); p.seq += d.size }   // çöp seçenek / acil işaretçi
            k < 82 -> p.seq = p.una                                                                                           // go-back-N: gerçekten onaylananı yeniden gönder
            k < 90 -> {}                                                                                                      // bekle (RTO tetiklensin)
            k < 95 -> { val d = payload(); tx(p, F_ACK or F_PSH, d, win = oddWin()); p.seq += d.size }                        // veri + pencere oyunu
            else -> tx(p, F_ACK, ackNo = p.rcv, win = 0)                                                                      // sıfır pencere
        }
    }

    // ---------------------------------------------------------------------------------- gürültü: hayalet SYN seli, UDP
    fun ghostSyns(n: Int) {
        repeat(n) {
            val gp = SoakPeer(portCounter.incrementAndGet(), srvPorts[rnd.nextInt(srvPorts.size)], false, rnd)
            tx(gp, F_SYN, mss = 1460, seqNo = gp.isn, ackNo = 0)
        }
    }

    fun udpNoise() {
        val dport = intArrayOf(53, 443, 123, 5353, 1 + rnd.nextInt(65534))[rnd.nextInt(5)]
        val d: ByteArray = if (dport == 53 && rnd.nextBoolean()) Dns.buildQuery(rnd.nextInt(65536), if (rnd.nextBoolean()) "reklam.example" else "ok${rnd.nextInt(50)}.test")
        else ByteArray(rnd.nextInt(1300)).also { rnd.nextBytes(it) }
        val n = Gw.udp(buf, false, CLI4, LO4, 20_000 + rnd.nextInt(10_000), dport, d, 0, d.size)
        r.gw.onPacket(buf.copyOf(n), n); txPk++
    }
}

/** Soak ve ayar-değişimi testlerinin ortak sahte sunucuları: yankı, büyük cevap + ani kapanış, hemen kapanan, takılı kalan ve ölü port. */
private class SoakServers : AutoCloseable {
    val echo = Sink(echo = true)
    private val rndSrv = Random(5150)
    val burst = Srv { s ->
        val i = s.getInputStream(); val o = s.getOutputStream()
        try { s.soTimeout = 3000; i.read() } catch (_: Exception) { return@Srv }
        val n = 50_000 + rndSrv.nextInt(350_000)
        o.write(ByteArray(n) { (it * 13).toByte() }); o.flush()
        when (rndSrv.nextInt(3)) { 0 -> {}; 1 -> { s.shutdownOutput(); try { while (i.read() >= 0) { } } catch (_: Exception) { } }; else -> s.setSoLinger(true, 0) }
    }
    val closer = Srv { s -> try { s.soTimeout = 400; s.getInputStream().read(ByteArray(1 + rndSrv.nextInt(300))) } catch (_: Exception) { } }
    val stall = Srv { _ -> Thread.sleep(5000) }
    val dead: Int = ServerSocket(0, 1, java.net.InetAddress.getByAddress(LO4)).let { val p = it.localPort; it.close(); p }
    val ports: List<Int> get() = listOf(echo.port, burst.port, closer.port, stall.port, dead)
    override fun close() { burst.close(); closer.close(); stall.close(); echo.close() }
}

/**
 * Soak döngüsü: dürüst akışları yürütür, [advTarget] düşman akışı sürekli yeniler, SYN seli ve UDP gürültüsü ekler; süre dolunca
 * dürüst akışlar bitene (en çok 25 sn) dek bekler. Geçen süreyi (ms) döner. [tick]: her turda (≈1 ms) çağrılır.
 */
private fun soakLoop(r: GRig, soak: Soak, honest: List<SoakPeer>, soakMs: Long, advTarget: Int, tick: (Long) -> Unit = {}): Long {
    val adv = ArrayList<SoakPeer>()
    val t0 = System.currentTimeMillis()
    val endAt = t0 + soakMs
    val hardEnd = endAt + 25_000
    var nextHonest = 0L
    var iter = 0
    while (true) {
        val now = System.currentTimeMillis()
        var n = 0
        while (n++ < 400) { val pk = r.q.poll() ?: break; soak.rx(pk) }
        if (now >= nextHonest) { for (h in honest) soak.stepHonest(h, now, endAt); nextHonest = now + 2 }
        if (now < endAt) {
            adv.removeAll { if (it.phase == 3) { soak.peers.remove(it.sport); true } else false }
            while (adv.size < advTarget && soak.spawned < 6000) adv.add(soak.spawn(false))
            repeat(14) { if (adv.isNotEmpty()) soak.stepAdv(adv[soak.rnd.nextInt(adv.size)], now) }
            if (soak.rnd.nextInt(100) == 0) soak.ghostSyns(10 + soak.rnd.nextInt(30))
            if (soak.rnd.nextInt(10) == 0) soak.udpNoise()
        } else if (honest.all { h -> h.done || h.rstSeen || h.phase == 3 }) break
        if (now >= hardEnd) break
        tick(now)
        if (++iter % 200 == 0) soak.maxFlows = maxOf(soak.maxFlows, r.gw.stats().tcpFlows)
        Thread.sleep(1)
    }
    soak.maxFlows = maxOf(soak.maxFlows, r.gw.stats().tcpFlows)
    return System.currentTimeMillis() - t0
}

private fun gwStatefulSoakTests() {
    val soakMs = 4_000L + DEEP_X * 2_000L
    T.group("Sızma 10 / ağ geçidi soak: 6 dürüst akış (bütünlük kâhini) + sürekli yenilenen 28 düşman akış, SYN seli, UDP gürültüsü (${soakMs / 1000} sn)")
    val uncaught = java.util.concurrent.CopyOnWriteArrayList<Throwable>()
    val oldH = Thread.getDefaultUncaughtExceptionHandler()
    Thread.setDefaultUncaughtExceptionHandler { _, e -> uncaught.add(e) }
    val gwBefore = Thread.getAllStackTraces().keys.filter { it.name == "gw-io" }.toSet()
    val r = GRig()
    val sv = SoakServers()
    val fd0 = fdCount()
    try {
        val cfg = r.gw.config
        cfg.dpi = true; cfg.maxTcp = 700; cfg.evictIdleMs = 1500; cfg.tcpIdleMs = 6000
        cfg.ads = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example"))
        r.gw.networkChanged(NetKind.WIFI)
        val soak = Soak(r, 0x5EED10)
        soak.echoPort = sv.echo.port
        soak.srvPorts.addAll(sv.ports)
        val honest = (0 until 6).map { soak.spawn(true, tls = it % 2 == 1) }
        val ran = soakLoop(r, soak, honest, soakMs, 28)
        val st0 = r.gw.stats()
        T.check("saldırı gerçekten uygulandı: ${soak.txPk} paket, ${soak.spawned} akış, açılan ${st0.opened}, engellenen ${st0.blockedHosts}", soak.txPk > 20_000 && soak.spawned > 100 && st0.opened > 50, "tx=${soak.txPk} spawn=${soak.spawned} opened=${st0.opened}")
        T.check("dürüst akışlar saldırı sürerken RST/kopma görmedi", honest.none { it.rstSeen }, honest.filter { it.rstSeen }.joinToString { "${it.sport}@tur${it.round}" })
        T.check("dürüst akışlar tamamlandı (hepsi, ${ran / 1000} sn)", honest.all { it.done }, honest.joinToString { "${it.round}${if (it.done) "✓" else "…"}" })
        T.check("dürüst akışlarda bayt bayt doğru yankı (bozulma yok; en az 30 tur)", honest.none { it.corrupt } && honest.all { it.round >= 30 }, honest.joinToString { "${it.round}/${it.corrupt}/yt${it.retx}" })
        T.check("geçidin ürettiği ${soak.rxPk} paketin hepsinin sağlaması doğru", soak.badSum == 0, "bozuk=${soak.badSum}")
        T.check("eşzamanlı akış sınırı aşılmadı (≤ 700, en çok ${soak.maxFlows})", soak.maxFlows <= 700, "${soak.maxFlows}")
        // bitiş: her şey kapanmalı
        Thread.sleep(300)
        r.gw.networkReset()
        val gone = waitUntil(12_000) { r.q.clear(); r.gw.stats().tcpFlows == 0 && r.gw.stats().udpFlows == 0 }
        T.check("ağ sıfırlama sonrası TCP/UDP akış tablosu sıfırlanır", gone, "tcp=${r.gw.stats().tcpFlows} udp=${r.gw.stats().udpFlows}")
        T.check("ortak bellek tamamen geri verildi (sayım sızıntısı yok)", r.gw.mem.used == 0, "kullanım=${r.gw.mem.used}")
        T.check("dosya tanıtıcısı sızmaz: soak sonrası $fd0 → ${fdCount()} (en çok +10)", fdSettles(fd0 + 10, 15_000), "başlangıç=$fd0 şimdi=${fdCount()}")
        val st = r.gw.stats()
        T.check("beklenmeyen iç hata yok", st.internalErrors == 0L, "sayaç=${st.internalErrors} son=${r.gw.lastInternalError()}")
        T.check("hiçbir iş parçacığında yakalanmamış istisna yok", uncaught.isEmpty(), uncaught.take(2).joinToString { "${it.javaClass.simpleName}: ${it.message} @ ${it.stackTrace.firstOrNull()}" })
        // soak sonrası sağlık
        val c = GCli(r, sv.echo.port); c.connect(); c.write("saglik".toByteArray())
        T.check("soak sonrası yeni akış çalışır", String(c.read(6, 5000)) == "saglik")
    } finally {
        Thread.setDefaultUncaughtExceptionHandler(oldH)
        sv.close(); r.close()
    }
    T.check("ağ geçidi iş parçacığı durdurulunca ölür (sızıntı yok)", waitUntil(4000) { Thread.getAllStackTraces().keys.none { it.name == "gw-io" && it.isAlive && it !in gwBefore } })
}

/**
 * Canlı ayar değişimi yarışı: gerçek servis ayarları ana iş parçacığından (ağ geçidi iş parçacığı çalışırken) değiştirir; ağ geçişi
 * geri çağrısı ayrı bir iş parçacığından gelir; arayüz her saniye istatistik okur. Burada ayrı bir iş parçacığı bunların hepsini ≈0,5 ms'de
 * bir rastgele yapar: DPI/reklam motoru/acil aktarma/DoH engeli/akış sınırı/boşta süreleri/yöntem belleği/ağ türü çevrilir, istatistik ve
 * DPI tablosu okunur. Dürüst akışlar bu sırada bozulmamalı, iç hata ve yakalanmamış istisna olmamalıdır.
 */
private fun gwConfigChurnTests() {
    val churnMs = 3_000L + DEEP_X * 1_000L
    T.group("Sızma 10 / ağ geçidi: canlı ayar değişimi yarışı — ayrı iş parçacığı ≈0,5 ms'de bir ayar çevirir, ağ değiştirir, istatistik okur; dürüst akışlar bozulmaz (${churnMs / 1000} sn)")
    val uncaught = java.util.concurrent.CopyOnWriteArrayList<Throwable>()
    val oldH = Thread.getDefaultUncaughtExceptionHandler()
    Thread.setDefaultUncaughtExceptionHandler { _, e -> uncaught.add(e) }
    val gwBefore = Thread.getAllStackTraces().keys.filter { it.name == "gw-io" }.toSet()
    val r = GRig()
    val sv = SoakServers()
    val fd0 = fdCount()
    val stopCtl = java.util.concurrent.atomic.AtomicBoolean(false)
    val ctlErr = java.util.concurrent.CopyOnWriteArrayList<Throwable>()
    val flips = java.util.concurrent.atomic.AtomicLong()
    val reads = java.util.concurrent.atomic.AtomicLong()
    val oldKeep = FilterLive.keepNames
    var ctl: Thread? = null
    try {
        val cfg = r.gw.config
        cfg.dpi = true; cfg.maxTcp = 700; cfg.evictIdleMs = 1500; cfg.tcpIdleMs = 6000
        r.gw.networkChanged(NetKind.WIFI)
        val soak = Soak(r, 0xC0DE12)
        soak.echoPort = sv.echo.port
        soak.srvPorts.addAll(sv.ports)
        val honest = (0 until 6).map { soak.spawn(true, tls = it % 2 == 1) }
        val engines = listOf<FilterEngine?>(
            null,
            FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example")),
            FilterEngine(emptyList(), FilterTier.EMPTY, listOf("izinli.example"), listOf("reklam.example", "izleyici.example")),
        )
        val pm = PlanMemory()
        val kinds = arrayOf(NetKind.WIFI, NetKind.MOBILE, NetKind.ETHERNET, NetKind.OTHER, NetKind.NONE)
        ctl = Thread({
            val rnd = Random(0xBEEF)
            var passUntil = 0L
            while (!stopCtl.get()) {
                try {
                    when (rnd.nextInt(16)) {
                        0 -> cfg.dpi = rnd.nextBoolean()
                        1 -> { cfg.passthrough = true; passUntil = System.currentTimeMillis() + 15 }       // kısa süreli acil aktarma
                        2 -> cfg.blockDoh = rnd.nextBoolean()
                        3 -> cfg.ads = engines[rnd.nextInt(engines.size)]
                        4 -> cfg.adsSource = if (rnd.nextBoolean()) ({ engines[1 + rnd.nextInt(2)] }) else null
                        5 -> cfg.maxTcp = intArrayOf(20, 60, 200, 700)[rnd.nextInt(4)]
                        6 -> cfg.flowBudget = intArrayOf(0, 0, 30, 200)[rnd.nextInt(4)]
                        7 -> cfg.hedge = rnd.nextBoolean()
                        8 -> cfg.dpiListedOnly = rnd.nextBoolean()
                        9 -> cfg.quicWithAds = rnd.nextBoolean()
                        10 -> r.gw.networkChanged(kinds[rnd.nextInt(kinds.size)], if (rnd.nextBoolean()) "28601" else "")
                        11 -> cfg.planMemory = if (rnd.nextBoolean()) pm else null
                        12 -> { cfg.evictIdleMs = longArrayOf(1000, 1500, 10_000)[rnd.nextInt(3)]; cfg.tcpIdleMs = longArrayOf(4000, 6000, 900_000)[rnd.nextInt(3)] }
                        13 -> { r.gw.stats(); r.gw.dpiTable(); r.gw.dpiExtras(); r.gw.shedFlows(); reads.incrementAndGet() }
                        14 -> FilterLive.keepNames = rnd.nextBoolean()
                        else -> cfg.autoTtl = rnd.nextBoolean()
                    }
                    if (passUntil != 0L && System.currentTimeMillis() >= passUntil) { cfg.passthrough = false; passUntil = 0L }
                    flips.incrementAndGet()
                } catch (e: Throwable) { ctlErr.add(e) }
                try { Thread.sleep(0, 500_000) } catch (_: InterruptedException) { }
            }
            cfg.passthrough = false
        }, "ayar-cevirici").also { it.isDaemon = true; it.start() }
        val ran = soakLoop(r, soak, honest, churnMs, 16)
        stopCtl.set(true); ctl.join(3000)
        cfg.passthrough = false; cfg.maxTcp = 700; cfg.flowBudget = 0; cfg.evictIdleMs = 1500; cfg.tcpIdleMs = 6000
        T.check("ayar çeviricisi gerçekten çalıştı: ${flips.get()} değişim, ${reads.get()} okuma", flips.get() > 1000 && reads.get() > 50, "değişim=${flips.get()} okuma=${reads.get()}")
        T.check("ayar/okuma çağrıları (başka iş parçacığından) hiç istisna atmadı", ctlErr.isEmpty(), ctlErr.take(2).joinToString { "${it.javaClass.simpleName}: ${it.message} @ ${it.stackTrace.firstOrNull()}" })
        T.check("dürüst akışlar ayar değişimi sürerken RST/kopma görmedi", honest.none { it.rstSeen }, honest.filter { it.rstSeen }.joinToString { "${it.sport}@tur${it.round}" })
        T.check("dürüst akışlar tamamlandı (hepsi, ${ran / 1000} sn)", honest.all { it.done }, honest.joinToString { "${it.round}${if (it.done) "✓" else "…"}" })
        T.check("dürüst akışlarda bayt bayt doğru yankı (bozulma yok; en az 20 tur)", honest.none { it.corrupt } && honest.all { it.round >= 20 }, honest.joinToString { "${it.round}/${it.corrupt}/yt${it.retx}" })
        T.check("geçidin ürettiği ${soak.rxPk} paketin hepsinin sağlaması doğru", soak.badSum == 0, "bozuk=${soak.badSum}")
        Thread.sleep(300)
        r.gw.networkReset()
        val gone = waitUntil(12_000) { r.q.clear(); r.gw.stats().tcpFlows == 0 && r.gw.stats().udpFlows == 0 }
        T.check("ağ sıfırlama sonrası akış tablosu sıfırlanır", gone, "tcp=${r.gw.stats().tcpFlows} udp=${r.gw.stats().udpFlows}")
        T.check("ortak bellek tamamen geri verildi", r.gw.mem.used == 0, "kullanım=${r.gw.mem.used}")
        T.check("dosya tanıtıcısı sızmaz ($fd0 → ${fdCount()}, en çok +10)", fdSettles(fd0 + 10, 15_000), "başlangıç=$fd0 şimdi=${fdCount()}")
        val st = r.gw.stats()
        T.check("beklenmeyen iç hata yok", st.internalErrors == 0L, "sayaç=${st.internalErrors} son=${r.gw.lastInternalError()}")
        T.check("hiçbir iş parçacığında yakalanmamış istisna yok", uncaught.isEmpty(), uncaught.take(2).joinToString { "${it.javaClass.simpleName}: ${it.message} @ ${it.stackTrace.firstOrNull()}" })
        cfg.dpi = false; cfg.ads = null; cfg.adsSource = null; cfg.blockDoh = false
        val c = GCli(r, sv.echo.port); c.connect(); c.write("saglik".toByteArray())
        T.check("ayar fırtınasından sonra yeni akış çalışır", String(c.read(6, 5000)) == "saglik")
    } finally {
        stopCtl.set(true); ctl?.join(2000)
        FilterLive.keepNames = oldKeep
        Thread.setDefaultUncaughtExceptionHandler(oldH)
        sv.close(); r.close()
    }
    T.check("ağ geçidi iş parçacığı durdurulunca ölür (sızıntı yok)", waitUntil(4000) { Thread.getAllStackTraces().keys.none { it.name == "gw-io" && it.isAlive && it !in gwBefore } })
}
