package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** 1.34: bağlantı sonrası kesinti algılama (CutWatch/Planner.cut) ve engel sayfası adresleri (BlockPages). */
private fun ipv4(s: String) = BlockPages.parse(s)!!

/** [q] DNS sorgusuna A cevabı: verilen adresler, isteğe bağlı önce bir CNAME (sıkıştırma işaretçisiyle). */
private fun aReply(q: ByteArray, ips: List<String>, cname: Boolean = false, aaaa: Boolean = false, response: Boolean = true): ByteArray {
    val rr = java.io.ByteArrayOutputStream()
    var n = 0
    if (cname) { rr.write(byteArrayOf(0xC0.toByte(), 0x0C, 0, 5, 0, 1, 0, 0, 0, 30, 0, 2, 0xC0.toByte(), 0x0C)); n++ }
    if (aaaa) { rr.write(byteArrayOf(0xC0.toByte(), 0x0C, 0, 28, 0, 1, 0, 0, 0, 30, 0, 16)); rr.write(ByteArray(16) { 1 }); n++ }
    for (s in ips) {
        rr.write(byteArrayOf(0xC0.toByte(), 0x0C, 0, 1, 0, 1, 0, 0, 0, 30, 0, 4))
        s.split('.').forEach { rr.write(it.toInt()) }
        n++
    }
    // Cevap bölümü SORUDAN hemen sonra gelir (iletici sorguya EDNS OPT ekleyebilir; o ek bölümde kalır, cevapta yoktur).
    val qEnd = Dns.skipName(q, 12, q.size) + 4
    val out = q.copyOf(qEnd) + rr.toByteArray()
    out[10] = 0; out[11] = 0
    out[2] = (if (response) 0x81 else 0x01).toByte(); out[3] = 0x80.toByte()
    out[6] = (n ushr 8).toByte(); out[7] = n.toByte()
    return out
}

private fun udpQuery(id: Int, name: String): ByteArray {
    val dns = Dns.buildQuery(id, name)
    val b = ByteArray(Packets.HDR + dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size); Packets.put16(b, 6, 0x4000)
    b[8] = 64; b[9] = 17
    Packets.put32(b, 12, 0x0A000002); Packets.put32(b, 16, 0x0A000001)
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, 40001); Packets.put16(b, 22, 53); Packets.put16(b, 24, 8 + dns.size)
    System.arraycopy(dns, 0, b, 28, dns.size)
    return b
}

/** Her sorguya önce [first], [gapMs] sonra [second] (null değilse) ile cevap veren sahte düz DNS sunucusu. */
private class RaceSrv(val first: String, val second: String?, val gapMs: Long = 80) : AutoCloseable {
    val socket = DatagramSocket(0, InetAddress.getByName("127.0.0.1"))
    val addr = InetSocketAddress("127.0.0.1", socket.localPort)
    init {
        Thread({
            val buf = ByteArray(1500)
            while (!socket.isClosed) {
                val p = DatagramPacket(buf, buf.size)
                try { socket.receive(p) } catch (_: Exception) { break }
                val q = buf.copyOf(p.length)
                val to = InetSocketAddress(p.address, p.port)
                try {
                    val a = aReply(q, listOf(first)); socket.send(DatagramPacket(a, a.size, to))
                    if (second != null) { Thread.sleep(gapMs); val b = aReply(q, listOf(second)); socket.send(DatagramPacket(b, b.size, to)) }
                } catch (_: Exception) {}
            }
        }, "race-srv").apply { isDaemon = true; start() }
    }
    override fun close() = socket.close()
}

fun runCut134Tests() {
    T.group("1.35 Android 17 ECH seçeneği")
    run {
        FilterRuntime.reset(); FilterRuntime.setGateway(FilterLevel.MEDIUM)
        FilterRuntime.updateNow(FilterLevel.BASIC, emptyList(), emptyList())
        val before = FilterRuntime.dropHttpsRr
        FilterRuntime.echAllow = true
        val allowed = !FilterRuntime.dropHttpsRr
        FilterRuntime.echAllow = false
        val back = FilterRuntime.dropHttpsRr
        FilterRuntime.reset()
        T.check("Reklam+ açıkken HTTPS kaydı düşer; ECH izniyle geçer; izin kalkınca yine düşer", before && allowed && back)
        T.check("ECH izni varsayılan kapalı", !AppSettings().echAllow)
        T.check("ECH izni kayıtta korunur", SettingsCodec.decode(SettingsCodec.encode(AppSettings(echAllow = true))).echAllow)
        T.check("ECH izni dışa/içe aktarmada korunur", SettingsCodec.import(SettingsCodec.export(AppSettings(echAllow = true)), AppSettings())?.echAllow == true)
        for ((sdk, shown) in listOf(0 to false, 34 to false, 36 to false, 37 to true, 38 to true)) {
            val rig = Rig(Rig.base())
            rig.host.sdk = sdk
            rig.scene.openSection(Section.EXPERIMENTAL); rig.settle(900)
            repeat(12) { if (rig.find(Strings.ECH_ALLOW) == null) rig.drag(180f, rig.h * 0.7f, rig.h * 0.7f - 220f, 8) }
            T.check("Android API $sdk: ECH satırı ${if (shown) "görünür" else "hiç yok"}", (rig.find(Strings.ECH_ALLOW) != null) == shown)
        }
        val rig = Rig(Rig.base())
        rig.host.sdk = 37
        rig.scene.openSection(Section.EXPERIMENTAL); rig.settle(900)
        repeat(12) { if (rig.find(Strings.ECH_ALLOW) == null) rig.drag(180f, rig.h * 0.7f, rig.h * 0.7f - 220f, 8) }
        rig.tapText(Strings.ECH_ALLOW, settleMs = 600)
        T.check("ECH satırına dokununca ayar açılır", rig.model.settings.echAllow)
    }

    T.group("1.38 QUIC Initial (RFC 9001) yeniden kurma")
    run {
        val pkt = QuicVectors.bytes(QuicVectors.INITIAL)
        val k = QuicInitial.clientKeys(QuicVectors.bytes("8394c8f03e515708"))
        T.check("RFC 9001 A.1 istemci anahtarları (key, iv, hp)", k.key.contentEquals(QuicVectors.bytes("1f369613dd76d5467730efcbe3b1a22d")) && k.iv.contentEquals(QuicVectors.bytes("fa044b2f42a3fd3b46fb255c")) && k.hp.contentEquals(QuicVectors.bytes("9f50449e04a0e810283a1e9933adedd2")))
        val pk = QuicInitial.parse(pkt, 0, pkt.size)
        T.check("bağımsız üretilmiş Initial çözülür: paket no 2, DCID", pk != null && pk.pn == 2L && pk.dcid.contentEquals(QuicVectors.bytes("8394c8f03e515708")) && pk.total == pkt.size)
        val hello = pk?.let { QuicInitial.frames(it.plain) }?.let { QuicInitial.assemble(it) }
        T.check("ClientHello doğru birleşir ve SNI discord.com", hello != null && hello.contentEquals(QuicVectors.bytes(QuicVectors.HELLO)) && QuicInitial.sni(hello!!)!!.let { String(hello, it[0], it[1]) } == "discord.com")
        val re = QuicInitial.reorder(pkt, 0, pkt.size)
        val rp = re?.let { QuicInitial.parse(it, 0, it.size) }
        val rf = rp?.let { QuicInitial.frames(it.plain) }
        T.check("reorder: aynı boyut, aynı paket no, farklı bayt", re != null && re.size == pkt.size && rp != null && rp.pn == 2L && !re.contentEquals(pkt))
        T.check("reorder: iki CRYPTO çerçevesi ters sırada (önce SNI ortasından sonrası)", rf != null && rf.size == 2 && rf[0].offset > 0 && rf[1].offset == 0 && rf[0].offset == rf[1].data.size)
        T.check("reorder: sunucunun göreceği birleşik ClientHello özgünle aynı", rf != null && QuicInitial.assemble(rf)!!.contentEquals(hello))
        T.check("reorder: SNI hiçbir çerçevede bütün değil", rf != null && rf.none { f -> String(f.data, Charsets.ISO_8859_1).contains("discord.com") })
        val fk = QuicInitial.fake(pkt, 0, pkt.size)
        val fh = fk?.let { QuicInitial.parse(it, 0, it.size) }?.let { QuicInitial.frames(it.plain) }?.let { QuicInitial.assemble(it) }
        val si = QuicInitial.sni(hello!!)!!
        T.check("fake: aynı boyut, SNI aynı uzunlukta iana.org alt alanı", fk != null && fk.size == pkt.size && fh != null && fh.size == hello.size && String(fh, si[0], si[1]).endsWith("iana.org"))
        T.check("fake: SNI dışındaki bütün ClientHello baytları aynı", fh != null && hello.indices.all { it in si[0] until si[0] + si[1] || fh[it] == hello[it] })
        val bad = pkt.copyOf().also { it[600] = (it[600].toInt() xor 1).toByte() }
        T.check("bozuk etiket (GCM doğrulaması) null döner", QuicInitial.parse(bad, 0, bad.size) == null && QuicInitial.reorder(bad, 0, bad.size) == null)
        val v2 = pkt.copyOf().also { it[4] = 2 }
        T.check("sürüm 1 dışı, kısa, uzun başlıksız paket null", QuicInitial.parse(v2, 0, v2.size) == null && QuicInitial.parse(pkt, 0, 1199) == null && QuicInitial.parse(ByteArray(1300) { 0x40 }, 0, 1300) == null)
        val rnd = java.util.Random(7)
        var threw = false
        for (i in 0 until 3000) {
            val b = if (i % 2 == 0) ByteArray(1200).also { rnd.nextBytes(it); it[0] = 0xC3.toByte(); it[1] = 0; it[2] = 0; it[3] = 0; it[4] = 1; it[5] = 8 } else pkt.copyOf().also { x -> repeat(1 + rnd.nextInt(6)) { x[rnd.nextInt(x.size)] = rnd.nextInt().toByte() } }
            try { QuicInitial.parse(b, 0, b.size); QuicInitial.reorder(b, 0, b.size); QuicInitial.fake(b, 0, b.size) } catch (_: Throwable) { threw = true }
        }
        T.check("3000 rastgele/bozuk pakette istisna fırlatmaz", !threw)
        val shifted = ByteArray(pkt.size + 7); System.arraycopy(pkt, 0, shifted, 7, pkt.size)
        T.check("ofset: datagram dizinin ortasından başlasa da çalışır", QuicInitial.reorder(shifted, 7, pkt.size)?.contentEquals(re) == true)
    }

    T.group("1.36 TLS yöntemi 12 (sahte ClientHello)")
    run {
        val h = testHello("engelli.ornek.com")
        val parts = Dpi.split(Dpi.TLS, 12, h, h.size)
        val joined = parts.fold(ByteArray(0)) { a, p -> a + p.data }
        val f = parts[0].fake
        val hi = Dpi.Hello().also { Dpi.parseHello(h, h.size, it) }
        T.check("yöntem 13 son, 12 sondan bir önce; 12 kayıt bölmez", Dpi.TLS_ORDER.last() == 13 && Dpi.TLS_ORDER.dropLast(1).last() == 12 && 12 !in Dpi.TLS_RECORD_SPLIT_PLANS)
        T.check("yöntem 12: parçalar birleşince veri aynı", joined.contentEquals(h) && parts.size == 2)
        T.check("yöntem 12: sahte kopya var, aynı uzunlukta, SNI sonuna dek", f != null && f.size == parts[0].data.size && f.size == hi.sniOff + hi.sniLen)
        T.check("yöntem 12: sahte yalnızca SNI baytlarında farklı", f != null && f.indices.all { i -> i in hi.sniOff until hi.sniOff + hi.sniLen || f[i] == parts[0].data[i] } && f.indices.any { f[it] != parts[0].data[it] })
        val fh = Dpi.Hello().also { if (f != null) Dpi.parseHello(f + ByteArray(8), f.size + 8, it) }
        T.check("yöntem 12: sahtedeki ad iana.org alt alanı ve aynı uzunlukta", f != null && fh.host(f + ByteArray(8))?.endsWith(".iana.org") == true && fh.sniLen == hi.sniLen)
        T.check("yöntem 12: gerçek parça sahteyle değil gerçek bayt taşır", parts[0].data.contentEquals(h.copyOfRange(0, parts[0].data.size)) && parts[1].fake == null)
        for (len in 1..14) {
            val z = Dpi.fakeHello(ByteArray(40) { 7 }, 10, len)
            T.check("sahte ad uzunluğu $len korunur ve yalnızca ad bölgesi değişir", z.size == 40 && (0 until 40).all { i -> i in 10 until 10 + len || z[i] == 7.toByte() })
        }
        val noSni = byteArrayOf(0x16, 3, 1, 0, 40) + ByteArray(60) { 1 }
        T.check("SNI okunamazsa sahte yok, veri korunur", Dpi.split(Dpi.TLS, 12, noSni, noSni.size).let { l -> l.all { it.fake == null } && l.fold(ByteArray(0)) { a, p -> a + p.data }.contentEquals(noSni) })
        val pm = PlanMemory()
        val k = PlanMemory.key(NetKind.WIFI, "")
        pm.put(k, Dpi.TLS, 12)
        val pm2 = PlanMemory(); pm2.decode(pm.encode())
        T.check("yöntem 12 plan belleğinde saklanır ve geri okunur", pm2.get(k)?.first == 12)
    }

    T.group("1.35 TLS yöntemi 11 (kayıt sürüm baytı)")
    run {
        val h = testHello("minor.example.net")
        val parts = Dpi.split(Dpi.TLS, 11, h, h.size)
        val joined = parts.fold(ByteArray(0)) { a, p -> a + p.data }
        val rec1 = 5 + (Packets.u16(joined, 3))
        T.check("yöntem 11 sondan iki önce ve kayıt bölen yöntemler arasında", Dpi.TLS_ORDER.dropLast(2).last() == 11 && 11 in Dpi.TLS_RECORD_SPLIT_PLANS && Dpi.TLS_PLANS == 14)
        T.check("yöntem 11: iki kayıt, ikincinin sürüm minör baytı değişik, gövde aynı", joined.size == h.size + 5 && joined[rec1].toInt() == 0x16 && joined[rec1 + 2].toInt() == 3 && h[2].toInt() == 1 &&
            joined.copyOfRange(rec1 + 5, joined.size).contentEquals(h.copyOfRange(5 + Packets.u16(joined, 3), h.size)))
        val tiny = byteArrayOf(0x16, 3, 1, 0, 2, 1, 0)
        T.check("yöntem 11: bölünemeyen küçük girdide çökmez, veri korunur", Dpi.split(Dpi.TLS, 11, tiny, tiny.size).fold(ByteArray(0)) { a, p -> a + p.data }.size >= tiny.size)
        val pm = PlanMemory()
        val k = PlanMemory.key(NetKind.WIFI, "")
        pm.decode("$k=11,7")
        T.check("kalıcı bellekte 11 geçerli bir yöntemdir", pm.get(k)?.first == 11)
        pm.decode("$k=12,7")
        T.check("kalıcı bellekte 12 geçerli bir yöntemdir", pm.get(k)?.first == 12)
        pm.decode("$k=13,7")
        T.check("kalıcı bellekte 13 geçerli bir yöntemdir", pm.get(k)?.first == 13)
        pm.decode("$k=14,7")
        T.check("14 ve üstü yöntem numarası kalıcı bellekte -1 olur", pm.get(k)?.first == -1)
    }

    T.group("1.34 kesinti: TLS kayıt izleyici (TlsTrack)")
    run {
        fun rec(type: Int, len: Int) = byteArrayOf(type.toByte(), 3, 3, (len ushr 8).toByte(), len.toByte()) + ByteArray(len) { 5 }
        val t = TlsTrack()
        T.check("başlangıçta kayıt ortasında değil", !t.midRecord && !t.lost)
        val r = rec(0x16, 100)
        t.follow(r, 0, 3)
        T.check("başlık yarımken kayıt ortasında", t.midRecord)
        t.follow(r, 3, 50)
        T.check("gövde yarımken kayıt ortasında", t.midRecord)
        t.follow(r, 53, r.size - 53)
        T.check("kayıt bitince ortada değil", !t.midRecord && !t.lost)
        // bir parçada birden çok kayıt + yarım kayıt; bayt bayt besleme aynı sonucu vermeli
        val two = rec(0x16, 7) + rec(0x17, 300)
        val a = TlsTrack(); a.follow(two, 0, two.size - 10)
        val b = TlsTrack(); for (i in 0 until two.size - 10) b.follow(two, i, 1)
        T.check("iki kayıt + yarım: ortada; bayt bayt besleme aynı", a.midRecord && b.midRecord && a.lost == b.lost)
        a.follow(two, two.size - 10, 10); b.follow(two, two.size - 10, 10)
        T.check("kalan gelince ikisi de ortada değil", !a.midRecord && !b.midRecord)
        val bad = TlsTrack(); bad.follow(byteArrayOf(0x48, 0x54, 0x54, 0x50, 0x2F, 0x31), 0, 6)
        T.check("TLS olmayan akış (HTTP) izlemeyi bırakır, ortada sayılmaz", bad.lost && !bad.midRecord)
        val zero = TlsTrack(); zero.follow(byteArrayOf(0x16, 3, 3, 0, 0), 0, 5)
        T.check("sıfır uzunluklu kayıt geçersiz sayılır", zero.lost)
        val ver = TlsTrack(); ver.follow(byteArrayOf(0x16, 9, 9, 0, 4), 0, 5)
        T.check("sürüm baytı 3 değilse izleme bırakılır", ver.lost)
        val rnd = java.util.Random(134)
        var ok = true
        repeat(3000 * FUZZ_X) {
            val z = TlsTrack(); val buf = ByteArray(rnd.nextInt(80)).also { rnd.nextBytes(it) }
            try { var o = 0; while (o < buf.size) { val n = 1 + rnd.nextInt(buf.size - o); z.follow(buf, o, n); o += n } } catch (_: Exception) { ok = false }
        }
        T.check("rastgele akışta çökmez", ok)
    }

    T.group("1.34 kesinti: CutWatch")
    run {
        fun rec(len: Int) = byteArrayOf(0x16, 3, 3, (len ushr 8).toByte(), len.toByte()) + ByteArray(len) { 5 }
        val w = CutWatch(0)
        val full = rec(50)
        w.down(full, 0, full.size, 100)
        T.check("tam kayıt + sessizlik: kesinti yok", w.poll(100 + 60_000) == CutWatch.Cut.NONE)
        val s = CutWatch(0)
        val half = rec(200)
        s.down(half, 0, 100, 1000)
        T.check("kayıt ortasında 8 sn dolmadan: yok", s.poll(1000 + CutWatch.STALL_MS - 1) == CutWatch.Cut.NONE)
        T.check("kayıt ortasında 8 sn: STALL", s.poll(1000 + CutWatch.STALL_MS) == CutWatch.Cut.STALL)
        T.check("her bağlantı en çok bir kez bildirir", s.poll(1000 + 99_000) == CutWatch.Cut.NONE && s.reset() == CutWatch.Cut.NONE)
        val n = CutWatch(0)
        n.down(full, 0, full.size, 100)
        n.up(200, 80)
        T.check("küçük istemci yazması (el sıkışma bitişi) cevap beklemez", n.poll(200 + CutWatch.NOREPLY_MS * 4) == CutWatch.Cut.NONE)
        n.up(300, 250)       // toplam 330 bayt: gerçek istek
        T.check("istek 15 sn dolmadan: yok", n.poll(300 + CutWatch.NOREPLY_MS - 1) == CutWatch.Cut.NONE)
        T.check("gerçek istek 15 sn cevapsız: NOREPLY", n.poll(300 + CutWatch.NOREPLY_MS) == CutWatch.Cut.NOREPLY)
        val a = CutWatch(0)
        a.down(full, 0, full.size, 100); a.up(200, 400)
        a.down(full, 0, full.size, 5000)           // cevap geldi: bekleme biter
        T.check("cevap gelince bekleme sıfırlanır", a.poll(5000 + 60_000) == CutWatch.Cut.NONE)
        val r1 = CutWatch(0); r1.down(full, 0, full.size, 10)
        T.check("iş bittikten sonra sıfırlama kesinti değil", r1.reset() == CutWatch.Cut.NONE)
        val r2 = CutWatch(0); r2.down(half, 0, 40, 10)
        T.check("kayıt ortasında sıfırlama kesinti", r2.reset() == CutWatch.Cut.RESET)
        val r3 = CutWatch(0); r3.down(full, 0, full.size, 10); r3.up(20, 500)
        T.check("cevabı beklenen istekle sıfırlama kesinti", r3.reset() == CutWatch.Cut.RESET)
        val big = CutWatch(0)
        val chunk = rec(1000)
        var t = 0L
        while (big.bytesDown < CutWatch.MAX_BYTES + 100) { big.down(chunk, 0, chunk.size, ++t) }
        big.down(half, 0, 10, t)
        T.check("64 KB'tan sonra izleme kapanır (uzun indirmeler kesinti sayılmaz)", big.poll(t + 100_000) == CutWatch.Cut.NONE && big.reset() == CutWatch.Cut.NONE)
        val custom = CutWatch(0, stallMs = 200, noreplyMs = 100)
        custom.down(half, 0, 20, 0)
        T.check("süreler özelleştirilebilir", custom.poll(199) == CutWatch.Cut.NONE && custom.poll(200) == CutWatch.Cut.STALL)
    }

    T.group("1.34 kesinti: Planner.cut")
    run {
        val p = Dpi.Planner()
        val k = "kesen.example"
        p.worked(k, Dpi.TLS, Dpi.TLS_ORDER[0])
        T.check("puan 2 (tek susma) yöntemi değiştirmez", p.cut(k, Dpi.TLS, Dpi.TLS_ORDER[0], 2, 1000) == -1 && p.first(k, Dpi.TLS) == Dpi.TLS_ORDER[0])
        T.check("puan 2+1=3 yöntemi sıradakine geçirir", p.cut(k, Dpi.TLS, Dpi.TLS_ORDER[0], 1, 2000) == Dpi.TLS_ORDER[1] && p.first(k, Dpi.TLS) == Dpi.TLS_ORDER[1])
        T.check("geçişten sonra sayaç sıfırlanır (tek susma yine geçirmez)", p.cut(k, Dpi.TLS, Dpi.TLS_ORDER[1], 2, 3000) == -1)
        val q = Dpi.Planner()
        q.cut("pencere.example", Dpi.TLS, Dpi.TLS_ORDER[0], 2, 0)
        T.check("10 dk geçince eski puan unutulur", q.cut("pencere.example", Dpi.TLS, Dpi.TLS_ORDER[0], 2, Dpi.CUT_WINDOW_MS + 1) == -1 && q.first("pencere.example", Dpi.TLS) != Dpi.TLS_ORDER[1])
        val z = Dpi.Planner()
        val last = Dpi.TLS_ORDER.last()
        T.check("sırada yöntem kalmadıysa değişmez", z.cut("son.example", Dpi.TLS, last, 3, 0) == -1 && z.first("son.example", Dpi.TLS) == z.first("baska.example", Dpi.TLS))
        T.check("plan < 0 (bölme uygulanmayan bağlantı) puan yazmaz", Dpi.Planner().cut("x", Dpi.TLS, -1, 5, 0) == -1)
        val h = Dpi.Planner()
        h.cut("h.example", Dpi.HTTP, 0, 3, 0)
        T.check("HTTP için de sıradaki yönteme geçer", h.first("h.example", Dpi.HTTP) == 1)
        val b = Dpi.Planner()
        for (i in 0 until 2000) b.cut("host$i.example", Dpi.TLS, Dpi.TLS_ORDER[0], 1, i.toLong())
        T.check("bellek sınırlı: 2000 hedef sonrası eski kayıtlar atılır (çökme/sızıntı yok)", b.cut("host0.example", Dpi.TLS, Dpi.TLS_ORDER[0], 1, 3000) == -1)
        val f = Dpi.Planner()
        f.cut("f.example", Dpi.TLS, Dpi.TLS_ORDER[0], 2, 0); f.forget()
        T.check("forget() kesinti belleğini de siler", f.cut("f.example", Dpi.TLS, Dpi.TLS_ORDER[0], 1, 1) == -1)
    }

    T.group("1.34 engel sayfası adresleri (BlockPages)")
    run {
        T.check("liste yüklendi (150+ adres)", BlockPages.size >= 150, "n=${BlockPages.size}")
        T.check("Türkiye engel sayfası (195.175.254.2) tanınır", BlockPages.isBlockPage(ipv4("195.175.254.2")) && BlockPages.countryOf(ipv4("195.175.254.2")) == "TR")
        T.check("Çin'in sahte havuzu tanınır", BlockPages.countryOf(ipv4("8.7.198.45")) == "CN")
        T.check("sıradan adresler tanınmaz (8.8.8.8, 1.1.1.1, 93.184.216.34)", listOf("8.8.8.8", "1.1.1.1", "93.184.216.34").none { BlockPages.isBlockPage(ipv4(it)) })
        T.check("ortak bulut (Hetzner 167.233.14.14) listede yok", !BlockPages.isBlockPage(ipv4("167.233.14.14")))
        T.check("DNS süzme hizmetleri (AdGuard 94.140.14.35, CleanBrowsing 185.228.168.254) listede yok", !BlockPages.isBlockPage(ipv4("94.140.14.35")) && !BlockPages.isBlockPage(ipv4("185.228.168.254")))
        T.check("adres ayrıştırıcı geçersiz girdiyi reddeder", listOf("1.2.3", "256.1.1.1", "a.b.c.d", "1.2.3.4.5", "").all { BlockPages.parse(it) == null })
        T.check("yüksek bitli adresler (>=128.x) işaretli Int'te de bulunur", BlockPages.isBlockPage(ipv4("203.98.7.65")) && BlockPages.isBlockPage(ipv4("190.85.224.131")))

        val q = Dns.buildQuery(0x1234, "yasakli.example")
        val forged = aReply(q, listOf("195.175.254.2"))
        T.check("cevapta engel sayfası A kaydı bulunur", BlockPages.inAnswer(forged, 0, forged.size))
        val real = aReply(q, listOf("93.184.216.34"))
        T.check("gerçek adres temiz", !BlockPages.inAnswer(real, 0, real.size))
        val chained = aReply(q, listOf("195.175.254.2"), cname = true)
        T.check("CNAME + A zincirinde de bulunur", BlockPages.inAnswer(chained, 0, chained.size))
        val multi = aReply(q, listOf("93.184.216.34", "193.192.98.45"))
        T.check("birden çok A kaydından biri engel sayfasıysa bulunur", BlockPages.inAnswer(multi, 0, multi.size))
        val v6 = aReply(q, listOf("93.184.216.34"), aaaa = true)
        T.check("AAAA kaydı yok sayılır", !BlockPages.inAnswer(v6, 0, v6.size))
        val query = aReply(q, listOf("195.175.254.2"), response = false)
        T.check("cevap bayrağı olmayan paket (sorgu) sayılmaz", !BlockPages.inAnswer(query, 0, query.size))
        val none = q.copyOf().also { it[2] = 0x81.toByte() }
        T.check("cevap bölümü boş: temiz", !BlockPages.inAnswer(none, 0, none.size))
        val off = ByteArray(7) + forged
        T.check("başlangıç kayması (base) doğru çalışır", BlockPages.inAnswer(off, 7, forged.size))
        T.check("sınır dışı base/uzunluk çökmeden false", !BlockPages.inAnswer(forged, -1, forged.size) && !BlockPages.inAnswer(forged, 0, forged.size + 5) && !BlockPages.inAnswer(forged, 0, 5))
        var ok = true
        val rnd = java.util.Random(7)
        repeat(20000 * FUZZ_X) {
            val m = forged.copyOf()
            repeat(1 + rnd.nextInt(4)) { m[rnd.nextInt(m.size)] = rnd.nextInt(256).toByte() }
            val len = if (rnd.nextInt(4) == 0) rnd.nextInt(m.size + 1) else m.size
            try { BlockPages.inAnswer(m, 0, len) } catch (_: Exception) { ok = false }
        }
        T.check("20000 bozulmuş cevapta çökmez", ok)
    }

    T.group("1.34 engel sayfası: düz DNS iletici")
    run {
        val srv = RaceSrv(first = "195.175.254.2", second = "93.184.216.34")
        val tun = LinkedBlockingQueue<ByteArray>()
        val fw = DnsForwarder(listOf(srv.addr), { b, o, l -> tun.add(b.copyOfRange(o, o + l)) }, retryAfterMs = 1200, giveUpAfterMs = 3000, sweepMs = 50).also { it.start() }
        val p = udpQuery(0x2222, "yasakli.example")
        fw.onPacket(p, p.size)
        val r = tun.poll(3, TimeUnit.SECONDS)
        val ip = r?.let { (it.size - 4 until it.size).joinToString(".") { i -> (it[i].toInt() and 0xFF).toString() } }
        T.check("enjekte edilen engel sayfası atılır, gerçek cevap istemciye gider", ip == "93.184.216.34", "ip=$ip")
        T.check("atılan cevap sayılır", fw.stats().blockPages >= 1L, "blockPages=${fw.stats().blockPages}")
        val p2 = udpQuery(0x2223, "yasakli.example")
        fw.onPacket(p2, p2.size)
        val r2 = tun.poll(3, TimeUnit.SECONDS)
        T.check("ikinci sorgu önbellekten gerçek adresle döner (sahte önbelleğe girmedi)", r2 != null && (r2.size - 4 until r2.size).joinToString(".") { i -> (r2[i].toInt() and 0xFF).toString() } == "93.184.216.34")
        fw.close(); srv.close()
    }
    run {
        val srv = RaceSrv(first = "195.175.254.2", second = null)
        val tun = LinkedBlockingQueue<ByteArray>()
        val fw = DnsForwarder(listOf(srv.addr), { b, o, l -> tun.add(b.copyOfRange(o, o + l)) }, retryAfterMs = 400, giveUpAfterMs = 1500, sweepMs = 50).also { it.start() }
        val p = udpQuery(0x3333, "yasakli2.example")
        fw.onPacket(p, p.size)
        val r = tun.poll(4, TimeUnit.SECONDS)
        val leaked = r != null && r.size > 28 && BlockPages.inAnswer(r, 28, r.size - 28)
        T.check("yalnızca sahte cevap gelirse istemciye sahte adres ASLA verilmez", !leaked)
        T.check("sahte cevaplar sayıldı", fw.stats().blockPages >= 1L)
        fw.close(); srv.close()
    }
}
