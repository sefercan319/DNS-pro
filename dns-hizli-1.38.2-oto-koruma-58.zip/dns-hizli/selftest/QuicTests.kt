package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*
import java.io.File
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.MGF1ParameterSpec
import java.security.spec.PSSParameterSpec
import java.util.concurrent.TimeUnit
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/**
 * QUIC / DoQ / DoH3 testleri. Gerçek bir QUIC sunucusuyla (python3 + aioquic, bkz. selftest/quic/server.py) uçtan uca denenir; python3 ya da
 * aioquic yoksa yalnızca bu birlikte çalışma bölümü atlanır (açıkça yazılır), saf birim testleri her zaman çalışır.
 */
private class QuicEnv(val dir: File) : AutoCloseable {
    val procs = ArrayList<Process>()

    fun py(vararg args: String): Process = ProcessBuilder(listOf("python3") + args).redirectErrorStream(true).start()

    fun freePort(): Int = DatagramSocket(0, InetAddress.getByName("127.0.0.1")).use { it.localPort }

    fun cert(kind: String): String {
        val p = py("selftest/quic/mkcert.py", kind).also { it.waitFor(30, TimeUnit.SECONDS) }
        check(p.exitValue() == 0) { "mkcert başarısız" }
        // mkcert.py çalışma klasörüne yazar: geçici klasöre taşı
        val c = File("$kind.crt"); val k = File("$kind.key")
        val out = File(dir, kind)
        c.copyTo(File(dir, "$kind.crt"), true); k.copyTo(File(dir, "$kind.key"), true)
        c.delete(); k.delete()
        return out.path
    }

    /** HTTP/2 (h2) test sunucusu; mode: both (h2 seçer) ya da h1 (yalnızca HTTP/1.1). READY satırını bekler. */
    fun h2Server(cert: String, mode: String): Int {
        val port = freePort()
        val p = py("selftest/quic/h2server.py", cert, port.toString(), mode); procs.add(p)
        val r = p.inputStream.bufferedReader()
        val end = System.currentTimeMillis() + 15000
        while (System.currentTimeMillis() < end) {
            if (r.ready()) { if (r.readLine()?.startsWith("READY") == true) return port } else Thread.sleep(30)
            if (!p.isAlive) break
        }
        throw IllegalStateException("h2 sunucusu başlamadı")
    }

    /** Sunucuyu başlatır; READY satırını bekler. */
    fun server(mode: String, cert: String, big: Boolean = false): Int {
        val port = freePort()
        val args = arrayListOf("selftest/quic/server.py", mode, cert, port.toString()) + (if (big) listOf("big") else emptyList())
        val p = py(*args.toTypedArray()); procs.add(p)
        val r = p.inputStream.bufferedReader()
        val end = System.currentTimeMillis() + 15000
        while (System.currentTimeMillis() < end) {
            if (r.ready()) { if (r.readLine()?.startsWith("READY") == true) return port } else Thread.sleep(30)
            if (!p.isAlive) break
        }
        throw IllegalStateException("sunucu başlamadı")
    }

    fun lossy(listen: Int, target: Int, loss: Double, seed: Int) {
        val p = py("selftest/quic/lossy.py", listen.toString(), target.toString(), loss.toString(), seed.toString()); procs.add(p)
        Thread.sleep(700)
    }

    override fun close() { for (p in procs) p.destroyForcibly() }

    companion object {
        fun available(): Boolean = try {
            val p = ProcessBuilder("python3", "-c", "import aioquic, cryptography").redirectErrorStream(true).start()
            p.waitFor(20, TimeUnit.SECONDS) && p.exitValue() == 0
        } catch (_: Exception) { false }
    }
}

private fun trustOf(pem: String): X509TrustManager {
    val cert = CertificateFactory.getInstance("X.509").generateCertificate(File(pem).inputStream())
    val ks = KeyStore.getInstance(KeyStore.getDefaultType()); ks.load(null); ks.setCertificateEntry("t", cert)
    val f = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()); f.init(ks)
    return f.trustManagers.filterIsInstance<X509TrustManager>().first()
}

private fun udp(r: InetSocketAddress): DatagramSocket = DatagramSocket().also { it.connect(r) }

private fun dnsQuery(name: String = "www.example.com"): ByteArray {
    val o = java.io.ByteArrayOutputStream()
    o.write(byteArrayOf(0x12, 0x34, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0))
    for (l in name.split('.')) { o.write(l.length); o.write(l.toByteArray()) }
    o.write(0); o.write(byteArrayOf(0, 1, 0, 1))
    return o.toByteArray()
}

private fun doqMsg(q: ByteArray): ByteArray = byteArrayOf((q.size shr 8).toByte(), q.size.toByte()) + q.copyOf().also { it[0] = 0; it[1] = 0 }

/** Sorgunun IPv4/UDP paketi (yönlendiriciye tünelden gelen biçim). */
private fun ipUdpQuery(id: Int, name: String): ByteArray {
    val dns = Dns.buildQuery(id, name)
    val b = ByteArray(Packets.HDR + dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size); Packets.put16(b, 6, 0x4000)
    b[8] = 64; b[9] = 17
    Packets.put32(b, 12, 0x0A000002); Packets.put32(b, 16, 0x0A000001)
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, 40001); Packets.put16(b, 22, 53); Packets.put16(b, 24, 8 + dns.size)
    System.arraycopy(dns, 0, b, 28, dns.size)
    return b
}

private fun lastIp(r: ByteArray) = r.takeLast(4).joinToString(".") { (it.toInt() and 0xFF).toString() }

fun runQuicTests() {
    T.group("QUIC: saf birim testleri")
    run {
        for (v in longArrayOf(0, 1, 63, 64, 16383, 16384, 1073741823, 1073741824, 4611686018427387903L)) {
            val b = QuicClient.varBytes(v)
            T.check("değişken uzunluklu tamsayı $v gidiş-dönüş", QuicInitial.readVar(b, 0, b.size) == v && QuicInitial.varLen(b[0].toInt() and 0xFF) == b.size)
        }
        // RFC 8446 §7.1 HKDF-Expand-Label bağlamlı sürüm: boş bağlam eski sürümle aynı sonucu verir
        val sec = ByteArray(32) { it.toByte() }
        T.check("bağlamsız ve boş bağlamlı HKDF-Expand-Label aynı", QuicInitial.expandLabel(sec, "quic key", 16).contentEquals(QuicInitial.expandLabel(sec, "quic key", ByteArray(0), 16)))
        T.check("bağlam değişince çıktı değişir", !QuicInitial.expandLabel(sec, "x", byteArrayOf(1), 32).contentEquals(QuicInitial.expandLabel(sec, "x", byteArrayOf(2), 32)))

        // CertificateVerify imzaları: RSA-PSS (SHA-256/384) ve ECDSA, doğru anahtar/yanlış veri/yanlış algoritma
        val msg = ByteArray(100) { (it * 7).toByte() }
        val rsa = KeyPairGenerator.getInstance("RSA").also { it.initialize(2048) }.generateKeyPair()
        val ec = KeyPairGenerator.getInstance("EC").also { it.initialize(256) }.generateKeyPair()
        fun pss(md: String, salt: Int, spec: MGF1ParameterSpec): ByteArray = Signature.getInstance("RSASSA-PSS").also {
            it.setParameter(PSSParameterSpec(md, "MGF1", spec, salt, 1)); it.initSign(rsa.private); it.update(msg)
        }.sign()
        val s256 = pss("SHA-256", 32, MGF1ParameterSpec.SHA256)
        val s384 = pss("SHA-384", 48, MGF1ParameterSpec.SHA384)
        val e256 = Signature.getInstance("SHA256withECDSA").also { it.initSign(ec.private); it.update(msg) }.sign()
        val ec384 = KeyPairGenerator.getInstance("EC").also { it.initialize(384) }.generateKeyPair()
        val e384 = Signature.getInstance("SHA384withECDSA").also { it.initSign(ec384.private); it.update(msg) }.sign()
        T.check("rsa_pss_rsae_sha256 imzası doğrulanır", QuicTls.verifySig(0x0804, rsa.public, msg, s256))
        T.check("rsa_pss_rsae_sha384 imzası doğrulanır", QuicTls.verifySig(0x0805, rsa.public, msg, s384))
        T.check("ecdsa_secp256r1_sha256 imzası doğrulanır", QuicTls.verifySig(0x0403, ec.public, msg, e256))
        T.check("ecdsa_secp384r1_sha384 imzası doğrulanır", QuicTls.verifySig(0x0503, ec384.public, msg, e384))
        T.check("eğri/algoritma uyuşmazlığı reddedilir (P-256 anahtarı ile 0x0503, P-384 ile 0x0403)", !QuicTls.verifySig(0x0503, ec.public, msg, Signature.getInstance("SHA384withECDSA").also { it.initSign(ec.private); it.update(msg) }.sign()) && !QuicTls.verifySig(0x0403, ec384.public, msg, Signature.getInstance("SHA256withECDSA").also { it.initSign(ec384.private); it.update(msg) }.sign()))
        val tampered = msg.copyOf().also { it[5] = (it[5].toInt() xor 1).toByte() }
        T.check("değişmiş veride hiçbir imza geçmez", !QuicTls.verifySig(0x0804, rsa.public, tampered, s256) && !QuicTls.verifySig(0x0403, ec.public, tampered, e256))
        T.check("yanlış algoritma / anahtar türü reddedilir", !QuicTls.verifySig(0x0804, ec.public, msg, s256) && !QuicTls.verifySig(0x0403, rsa.public, msg, e256) && !QuicTls.verifySig(0x0805, rsa.public, msg, s256))
        T.check("bilinmeyen imza algoritması (ed25519, rsa_pkcs1) reddedilir", !QuicTls.verifySig(0x0807, ec.public, msg, e256) && !QuicTls.verifySig(0x0401, rsa.public, msg, s256))
        T.check("bozuk imza baytları istisna fırlatmaz", !QuicTls.verifySig(0x0403, ec.public, msg, ByteArray(3)) && !QuicTls.verifySig(0x0804, rsa.public, msg, ByteArray(256)))
    }

    T.group("QUIC: HTTP/3 yanıt çözümü (QPACK yalnızca statik tablo)")
    run {
        fun frame(t: Int, p: ByteArray) = byteArrayOf(t.toByte(), p.size.toByte()) + p
        val dns = ByteArray(40) { 9 }
        val ok = frame(1, byteArrayOf(0, 0, 0xD9.toByte())) + frame(0, dns)                       // :status 200 (statik 25), DATA
        T.check("200 + gövde", Http3Client.parseResponse(ok).contentEquals(dns))
        val two = frame(1, byteArrayOf(0, 0, 0xD9.toByte())) + frame(0, dns.copyOf(10)) + frame(0, dns.copyOf(30))
        T.check("birden çok DATA çerçevesi birleşir", Http3Client.parseResponse(two).size == 40)
        T.check("bilinmeyen çerçeve türü atlanır", Http3Client.parseResponse(frame(0x21, byteArrayOf(1, 2)) + ok).contentEquals(dns))
        fun fails(b: ByteArray) = try { Http3Client.parseResponse(b); false } catch (_: java.io.IOException) { true }
        T.check("404 hata", fails(frame(1, byteArrayOf(0, 0, 0xDB.toByte())) + frame(0, dns)))
        T.check("durum yoksa hata", fails(frame(0, dns)))
        T.check("dinamik tabloya başvuru (gerekli ekleme sayısı ≠ 0) hata", fails(frame(1, byteArrayOf(1, 0, 0xD9.toByte())) + frame(0, dns)))
        T.check("dinamik tablo dizini hata", fails(frame(1, byteArrayOf(0, 0, 0x80.toByte())) + frame(0, dns)))
        T.check("kesik çerçeve hata (istisna değil IOException)", fails(byteArrayOf(0, 50, 1, 2)))
        val lit = byteArrayOf(0, 0, 0x5F, 0x09, 0x03, '2'.code.toByte(), '0'.code.toByte(), '0'.code.toByte())   // adı statik 24.. dizinli, değer "200"
        T.check("adı dizinli düz değerli :status okunur", Http3Client.parseResponse(frame(1, lit) + frame(0, dns)).contentEquals(dns))
        T.check("önce 103 sonra 200 başlıkları", Http3Client.parseResponse(frame(1, byteArrayOf(0, 0, 0xD8.toByte())) + ok).contentEquals(dns))
        val rnd = java.util.Random(11)
        var threw = false
        repeat(3000 * FUZZ_X) {
            val b = ByteArray(rnd.nextInt(60)).also { rnd.nextBytes(it) }
            try { Http3Client.parseResponse(b) } catch (_: java.io.IOException) {} catch (_: Throwable) { threw = true }
        }
        T.check("3000 rastgele yanıtta IOException dışında istisna yok", !threw)
    }

    T.group("QUIC: sertifika adı eşleşmesi (keytool ile üretilmiş sertifika)")
    run {
        val dir = File(System.getProperty("java.io.tmpdir"), "dnshizli-quic-" + System.nanoTime()).also { it.mkdirs() }
        val keytool = File(System.getProperty("java.home"), "bin/keytool").path
        fun sh(vararg a: String) = ProcessBuilder(listOf(keytool) + a).redirectErrorStream(true).start().also { it.inputStream.readBytes(); it.waitFor(30, TimeUnit.SECONDS) }.exitValue()
        val ks = File(dir, "k.jks").path
        val ok = sh("-genkeypair", "-alias", "a", "-keyalg", "EC", "-groupname", "secp256r1", "-dname", "CN=ornek", "-ext", "san=dns:dns.ornek.test,dns:*.joker.test,ip:10.1.2.3",
            "-keystore", ks, "-storepass", "changeit", "-validity", "5") == 0 &&
            sh("-exportcert", "-rfc", "-alias", "a", "-keystore", ks, "-storepass", "changeit", "-file", File(dir, "c.pem").path) == 0
        if (!ok) println("  (keytool kullanılamadı: ad eşleşmesi testleri atlandı)") else {
            val c = CertificateFactory.getInstance("X.509").generateCertificate(File(dir, "c.pem").inputStream()) as X509Certificate
            T.check("tam ad eşleşir", QuicTls.hostMatches(c, "dns.ornek.test") && QuicTls.hostMatches(c, "DNS.Ornek.Test") && QuicTls.hostMatches(c, "dns.ornek.test."))
            T.check("başka ad eşleşmez", !QuicTls.hostMatches(c, "evil.test") && !QuicTls.hostMatches(c, "dns.ornek.test.evil.com") && !QuicTls.hostMatches(c, "xdns.ornek.test"))
            T.check("joker tek etiketi kapsar", QuicTls.hostMatches(c, "a.joker.test") && !QuicTls.hostMatches(c, "a.b.joker.test") && !QuicTls.hostMatches(c, "joker.test") && !QuicTls.hostMatches(c, ".joker.test"))
            T.check("IP adresi yalnızca iPAddress SAN'ıyla eşleşir", QuicTls.hostMatches(c, "10.1.2.3") && !QuicTls.hostMatches(c, "10.1.2.4") && !QuicTls.hostMatches(c, "10.1.2.30"))
            T.check("CN (ornek) SAN yokmuş gibi sayılmaz", !QuicTls.hostMatches(c, "ornek"))
        }
        dir.deleteRecursively()
    }

    T.group("QUIC: yöntem planı ve ayar")
    run {
        val ag = Catalog.byId("adguard")!!
        val cf = Catalog.byId("cloudflare")!!
        val q9 = Catalog.byId("quad9")!!
        T.check("QUIC kapalıyken plan eskisi gibi (AdGuard: DoT, DoH, düz)", Encryption.AUTO.plan(ag) == listOf(Proto.DOT, Proto.DOH, Proto.PLAIN))
        T.check("QUIC açık: AdGuard önce DoQ, DoH3, sonra eski sıra", Encryption.AUTO.plan(ag, quic = true) == listOf(Proto.DOQ, Proto.DOH3, Proto.DOT, Proto.DOH, Proto.PLAIN))
        T.check("QUIC açık: Cloudflare yalnızca DoH3 ekler (DoQ yok)", Encryption.AUTO.plan(cf, quic = true) == listOf(Proto.DOH3, Proto.DOT, Proto.DOH, Proto.PLAIN))
        T.check("QUIC desteklemeyen sunucu etkilenmez", Encryption.AUTO.plan(q9, quic = true) == Encryption.AUTO.plan(q9))
        T.check("sıkı şifreleme: QUIC dahil düz DNS'e düşmez", Proto.PLAIN !in Encryption.AUTO.plan(ag, strict = true, quic = true))
        T.check("şifreleme KAPALI: QUIC eklenmez", Encryption.OFF.plan(ag, quic = true) == listOf(Proto.PLAIN))
        T.check("DoT seçiliyken QUIC önce, yedek DoT", Encryption.DOT.plan(ag, quic = true) == listOf(Proto.DOQ, Proto.DOH3, Proto.DOT))
        T.check("ayar varsayılan kapalı", !AppSettings().quicDns)
        T.check("ayar kayıtta korunur", SettingsCodec.decode(SettingsCodec.encode(AppSettings(quicDns = true))).quicDns)
        T.check("AppSettings.plan QUIC'i kullanır", AppSettings(quicDns = true).plan(ag).first() == Proto.DOQ && AppSettings().plan(ag).first() == Proto.DOT)
        T.check("ODoH yedeğiyle birlikte sıra: önce ODoH, sonra QUIC", AppSettings(quicDns = true, odoh = OdohMode.FALLBACK).plan(ag).take(2) == listOf(Proto.ODOH, Proto.DOQ))
        T.check("DoQ sertifika adı katalogdan, DoH3 adı DoH adresinden", ag.tlsHost(Proto.DOQ, 0) == "dns.adguard-dns.com" && ag.tlsHost(Proto.DOH3, 0) == "dns.adguard-dns.com" && cf.tlsHost(Proto.DOQ, 0) == null)
        T.check("protokol adları", Strings.protoName(Proto.DOQ) == "DoQ" && Strings.protoName(Proto.DOH3) == "DoH3")
        val t = Targets.secure(ag, Proto.DOQ, IpMode.BOTH, NetFamilies(true, true))
        T.check("DoQ hedefleri DoQ adıyla kurulur", t.isNotEmpty() && t.all { it.host == "dns.adguard-dns.com" })
        run {
            val rig = Rig(Rig.base())
            rig.scene.openSection(Section.DNS)
            rig.settle(900)
            repeat(14) { if (rig.find(Strings.QUIC_DNS) == null) rig.drag(180f, rig.h * 0.7f, rig.h * 0.7f - 220f, 8) }
            T.check("DNS ayarlarında QUIC satırı görünür", rig.find(Strings.QUIC_DNS) != null)
            rig.tapText(Strings.QUIC_DNS, settleMs = 600)
            T.check("QUIC satırına dokununca ayar açılır", rig.model.settings.quicDns)
        }
    }

    T.group("QUIC: engelli ağda geri çekilme (UDP engelli ağda her bağlanışta beklenmez)")
    run {
        var t = 1_000L
        val b = QuicBackoff({ t })
        val plan = listOf(Proto.DOQ, Proto.DOH3, Proto.DOT, Proto.DOH)
        T.check("başlangıçta plan değişmez", b.filter(plan) == plan && !b.skipping)
        b.failed()
        T.check("başarısızlıktan sonra QUIC yöntemleri çıkarılır, sıra korunur", b.filter(plan) == listOf(Proto.DOT, Proto.DOH))
        t += QuicBackoff.HOLD_MS - 1
        T.check("süre dolmadan hâlâ atlanır", b.skipping)
        t += 2
        T.check("süre dolunca QUIC yeniden denenir", !b.skipping && b.filter(plan) == plan)
        b.failed(); b.reset()
        T.check("ağ değişince (reset) hemen yeniden denenir", !b.skipping)
        b.failed()
        T.check("yalnızca QUIC yöntemi kalmışsa plan boşalmaz", b.filter(listOf(Proto.DOQ)) == listOf(Proto.DOQ))
    }

    T.group("QUIC: çerçeve ayrıştırıcı rastgele girdi (1-RTT, akışlı)")
    run {
        val rnd = java.util.Random(31337)
        fun vb(): ByteArray = when (rnd.nextInt(5)) {
            0 -> QuicClient.varBytes(rnd.nextInt(64).toLong())
            1 -> QuicClient.varBytes(rnd.nextInt(5000).toLong())
            2 -> QuicClient.varBytes(rnd.nextLong() and 0x3FFFFFFFFFFFFFFFL)
            3 -> QuicClient.varBytes((rnd.nextLong() and 0x3FFFFFFFL))
            else -> QuicClient.varBytes(rnd.nextInt(3).toLong())
        }
        var bad: Throwable? = null
        var calls = 0
        val t0 = System.currentTimeMillis()
        repeat(40) {
            val c = QuicClient("localhost", InetSocketAddress(InetAddress.getByName("127.0.0.1"), 9), "doq", ::udp)
            val streams = listOf(c.debugStream(0), c.debugStream(4), c.debugStream(8))
            repeat(400) {
                val o = java.io.ByteArrayOutputStream()
                repeat(1 + rnd.nextInt(4)) {
                    when (rnd.nextInt(12)) {
                        0, 1, 2 -> { o.write(0x08 or rnd.nextInt(8)); o.write(vb()); if (rnd.nextBoolean()) o.write(vb()); val d = ByteArray(rnd.nextInt(60)).also { b -> rnd.nextBytes(b) }; if (rnd.nextBoolean()) o.write(QuicClient.varBytes(d.size.toLong())); o.write(d) }
                        3 -> { o.write(0x02); repeat(4 + rnd.nextInt(6)) { o.write(vb()) } }
                        4 -> { o.write(0x04); repeat(3) { o.write(vb()) } }
                        5 -> { o.write(0x07); o.write(vb()); o.write(ByteArray(rnd.nextInt(10))) }
                        6 -> { o.write(0x18); repeat(2) { o.write(vb()) }; o.write(rnd.nextInt(30)); o.write(ByteArray(rnd.nextInt(40))) }
                        7 -> { o.write(0x10 + rnd.nextInt(10)); repeat(rnd.nextInt(3)) { o.write(vb()) } }
                        8 -> { o.write(0x1a); o.write(ByteArray(rnd.nextInt(10))) }
                        9 -> o.write(rnd.nextInt(256))
                        10 -> { o.write(0x06); o.write(vb()); o.write(vb()) }
                        else -> { o.write(0x00); o.write(0x01) }
                    }
                }
                calls++
                try { c.debugFrames(2, o.toByteArray()) }
                catch (_: java.io.IOException) {}
                catch (_: QuicTlsException) {}
                catch (e: Throwable) { if (bad == null) bad = e }
            }
            c.close()
        }
        T.check("$calls rastgele 1-RTT yükünde yalnızca IOException/QuicTlsException çıkar", bad == null, bad?.stackTraceToString()?.take(500) ?: "")
        T.check("ayrıştırıcı hızlı (CPU/döngü tuzağı yok)", System.currentTimeMillis() - t0 < 20000, "${System.currentTimeMillis() - t0} ms")
        val c = QuicClient("localhost", InetSocketAddress(InetAddress.getByName("127.0.0.1"), 9), "doq", ::udp)
        val s0 = c.debugStream(0)
        for (i in 0 until 50) {
            val d = ByteArray(1000)
            val f = byteArrayOf(0x0e.toByte()) + QuicClient.varBytes(0) + QuicClient.varBytes((i * 1000L + 5_000_000L)) + QuicClient.varBytes(d.size.toLong()) + d    // çok ileri ofsetler
            try { c.debugFrames(2, f) } catch (_: java.io.IOException) {}
        }
        T.check("çok ileri ofsetli akış verisi tamponu şişirmez (akış hata verir)", s0.received == 0 && c.failure != null)
        c.close()
    }

    T.group("QUIC: TLS el sıkışma iletileri rastgele girdi")
    run {
        val rnd = java.util.Random(4711)
        val tm = object : javax.net.ssl.X509TrustManager {
            override fun checkClientTrusted(c: Array<X509Certificate>?, a: String?) {}
            override fun checkServerTrusted(c: Array<X509Certificate>?, a: String?) { throw java.security.cert.CertificateException("test") }
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        var bad: Throwable? = null
        var typed = 0
        repeat(3000 * FUZZ_X) {
            val t = QuicTls("localhost", "doq", ByteArray(8), tm)
            t.clientHello()
            val n = 1 + rnd.nextInt(4)
            try {
                repeat(n) { i ->
                    val body = ByteArray(rnd.nextInt(200)).also { rnd.nextBytes(it) }
                    val type = if (rnd.nextInt(3) == 0) rnd.nextInt(256) else intArrayOf(2, 8, 11, 15, 20)[minOf(i, 4)]
                    val declared = if (rnd.nextInt(5) == 0) rnd.nextInt(300) else body.size
                    if (rnd.nextInt(4) == 0 && body.size >= 40) { body[0] = 3; body[1] = 3 }
                    val msg = byteArrayOf(type.toByte(), (declared shr 16).toByte(), (declared shr 8).toByte(), declared.toByte()) + body
                    t.feed(if (type == 2 || rnd.nextInt(4) == 0) 0 else 1, msg)
                }
            } catch (_: QuicTlsException) { typed++ }
            catch (e: Throwable) { if (bad == null) bad = e }
        }
        T.check("3000 rastgele el sıkışma dizisi: yalnızca QuicTlsException (istisna sızmaz)", bad == null, bad?.stackTraceToString()?.take(500) ?: "")
        T.check("rastgele iletilerin çoğu açıkça reddedilir ($typed)", typed > 1500)
    }

    T.group("QUIC: sahte paketlere karşı sertlik (saldırgan sunucu, python gerekmez)")
    run {
        val lo = InetAddress.getByName("127.0.0.1")
        fun hex(h: String) = ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        val salt = hex("38762cf7f55934b34d179ae6a4c80cadccbb7f0a")
        fun varb(v: Int) = QuicClient.varBytes(v.toLong())
        // sunucu yönü Initial (anahtarlar herkesçe türetilebilir: yol üstü bir saldırganın yapabileceği)
        fun serverInitial(odcid: ByteArray, clientScid: ByteArray, serverScid: ByteArray, frames: ByteArray, pn: Long = 0): ByteArray {
            val ss = QuicInitial.expandLabel(QuicInitial.hmac(salt, odcid), "server in", 32)
            val k = QuicInitial.Keys(QuicInitial.expandLabel(ss, "quic key", 16), QuicInitial.expandLabel(ss, "quic iv", 12), QuicInitial.expandLabel(ss, "quic hp", 16))
            val plain = frames + ByteArray(maxOf(0, 24 - frames.size))
            val h = java.io.ByteArrayOutputStream()
            h.write(0xC3); h.write(byteArrayOf(0, 0, 0, 1))
            h.write(clientScid.size); h.write(clientScid); h.write(serverScid.size); h.write(serverScid); h.write(0)
            val l = 4 + plain.size + 16; h.write(0x40 or (l shr 8)); h.write(l and 0xFF)
            val pnOff = h.size()
            for (i in 3 downTo 0) h.write((pn shr (8 * i)).toInt() and 0xFF)
            val hdr = h.toByteArray()
            val ct = QuicInitial.gcm(javax.crypto.Cipher.ENCRYPT_MODE, k, pn, hdr, plain, 0, plain.size)
            val pkt = hdr + ct
            val mask = QuicInitial.aesEcb(k.hp, pkt.copyOfRange(pnOff + 4, pnOff + 20))
            pkt[0] = (pkt[0].toInt() xor (mask[0].toInt() and 0x0F)).toByte()
            for (i in 0 until 4) pkt[pnOff + i] = (pkt[pnOff + i].toInt() xor mask[1 + i].toInt()).toByte()
            return pkt
        }
        val retryKeys = QuicInitial.Keys(hex("be0c690b9f66575a1d766b54e368c84e"), hex("461599d35d632bf2239825bb"), ByteArray(16))
        fun retry(odcid: ByteArray, clientScid: ByteArray, goodTag: Boolean): ByteArray {
            val body = java.io.ByteArrayOutputStream()
            body.write(0xF0); body.write(byteArrayOf(0, 0, 0, 1)); body.write(clientScid.size); body.write(clientScid)
            body.write(8); body.write(ByteArray(8) { 9 }); body.write(byteArrayOf(1, 2, 3, 4))
            val b = body.toByteArray()
            val tag = if (goodTag) QuicInitial.gcm(javax.crypto.Cipher.ENCRYPT_MODE, retryKeys, 0, byteArrayOf(odcid.size.toByte()) + odcid + b, ByteArray(0), 0, 0) else ByteArray(16) { 7 }
            return b + tag
        }
        fun versionNeg(clientScid: ByteArray, odcid: ByteArray, versions: List<Long>): ByteArray {
            val o = java.io.ByteArrayOutputStream()
            o.write(0x80 or 0x2A); o.write(byteArrayOf(0, 0, 0, 0))
            o.write(clientScid.size); o.write(clientScid); o.write(odcid.size); o.write(odcid)
            for (v in versions) for (i in 3 downTo 0) o.write((v shr (8 * i)).toInt() and 0xFF)
            return o.toByteArray()
        }
        /** İstemcinin ilk Initial'ını alır, [forge] ile cevap(lar) üretir; istemcinin connect() hata iletisini döner (başarı: "OK"). */
        fun attack(forge: (odcid: ByteArray, cscid: ByteArray) -> List<ByteArray>): String {
            val srv = DatagramSocket(0, lo)
            srv.soTimeout = 3000
            val t = Thread {
                try {
                    val buf = ByteArray(2048); val pk = java.net.DatagramPacket(buf, buf.size)
                    srv.receive(pk)
                    val dl = buf[5].toInt() and 0xFF; val odcid = buf.copyOfRange(6, 6 + dl)
                    val sl = buf[6 + dl].toInt() and 0xFF; val cscid = buf.copyOfRange(7 + dl, 7 + dl + sl)
                    for (r in forge(odcid, cscid)) srv.send(java.net.DatagramPacket(r, r.size, pk.socketAddress))
                } catch (_: Exception) {}
            }
            t.isDaemon = true; t.start()
            val c = QuicClient("localhost", InetSocketAddress(lo, srv.localPort), "doq", ::udp)
            return try { c.connect(1300); "OK" } catch (e: java.io.IOException) { e.message ?: "?" } finally { c.close(); srv.close() }
        }
        val ver = 0x2A2A2A2AL
        T.check("sahte sürüm pazarlığı (kimlikler yansımıyor) bağlantıyı düşürmez", attack { o, c -> listOf(versionNeg(ByteArray(8), o, listOf(ver))) }.contains("zaman aşımı"))
        T.check("sürüm pazarlığı v1'i listeliyorsa yok sayılır", attack { o, c -> listOf(versionNeg(c, o, listOf(1L, ver))) }.contains("zaman aşımı"))
        T.check("gerçek sürüm pazarlığı (v1 yok) açık hata verir", attack { o, c -> listOf(versionNeg(c, o, listOf(ver))) }.contains("sürüm pazarlığı"))
        T.check("etiketi yanlış Retry yok sayılır (bağlantı düşürülemez)", attack { o, c -> listOf(retry(o, c, false)) }.contains("zaman aşımı"))
        T.check("doğru etiketli Retry açıkça bildirilir", attack { o, c -> listOf(retry(o, c, true)) }.contains("Retry"))
        val sc = ByteArray(8) { 5 }
        T.check("Initial'da uygulama CONNECTION_CLOSE (0x1d) yok sayılır", attack { o, c -> listOf(serverInitial(o, c, sc, byteArrayOf(0x1d, 0, 0))) }.contains("zaman aşımı"))
        T.check("Initial'da taşıma CONNECTION_CLOSE (0x1c) kabul edilir", attack { o, c -> listOf(serverInitial(o, c, sc, byteArrayOf(0x1c, 0, 0, 0))) }.contains("kapattı"))
        T.check("Initial'da sahte STREAM çerçevesi yok sayılır (bağlantı ölmez)", attack { o, c -> listOf(serverInitial(o, c, sc, byteArrayOf(0x0b, 0, 2, 1, 2))) }.contains("zaman aşımı"))
        val bigCrypto = byteArrayOf(0x06) + varb(5_000_000) + varb(4) + byteArrayOf(1, 2, 3, 4)
        T.check("uç CRYPTO ofseti el sıkışma tamponunu şişirmez (bağlantı reddedilir)", attack { o, c -> listOf(serverInitial(o, c, sc, bigCrypto)) }.contains("CRYPTO sınırı"))
        T.check("bozuk CRYPTO uzunluğu (devasa) çökertmeden hata olur", attack { o, c -> listOf(serverInitial(o, c, sc, byteArrayOf(0x06, 0, 0xC0.toByte(), 0, 0, 1, 0, 0, 0, 5))) }.let { it.contains("bozuk") || it.contains("zaman aşımı") })
        T.check("NEW_TOKEN çerçevesinde taşan uzunluk sonsuz döngü yapmaz", attack { o, c -> listOf(serverInitial(o, c, sc, byteArrayOf(0x07, 0xC0.toByte(), 0, 0, 1, 0, 0, 0, 0))) }.let { it.contains("zaman aşımı") || it.contains("bozuk") })
        // Rastgele ama kimliği doğrulanmış (Initial anahtarıyla şifreli) çerçeveler: ayrıştırıcı takılmaz, çökmez, IOException dışında hata sızmaz
        run {
            val rnd = java.util.Random(99)
            fun randVar(): ByteArray = when (rnd.nextInt(4)) {
                0 -> varb(rnd.nextInt(64))
                1 -> varb(rnd.nextInt(16384))
                2 -> QuicClient.varBytes(rnd.nextLong() and 0x3FFFFFFFFFFFFFFFL)
                else -> QuicClient.varBytes(rnd.nextLong() and 0x3FFFFFFFL)
            }
            fun frame(): ByteArray {
                val o = java.io.ByteArrayOutputStream()
                when (rnd.nextInt(6)) {
                    0 -> { o.write(0x02); repeat(4) { o.write(randVar()) }; repeat(rnd.nextInt(6)) { o.write(randVar()) } }
                    1 -> { o.write(0x06); o.write(randVar()); val d = ByteArray(rnd.nextInt(40)).also { rnd.nextBytes(it) }; o.write(varb(d.size)); o.write(d) }
                    2 -> o.write(0x01)
                    3 -> o.write(ByteArray(rnd.nextInt(30)))
                    4 -> { o.write(0x06); o.write(randVar()); o.write(randVar()) }
                    else -> { o.write(if (rnd.nextBoolean()) 0x03 else 0x02); repeat(rnd.nextInt(10)) { o.write(randVar()) } }
                }
                return o.toByteArray()
            }
            var leaked: Throwable? = null
            val t0 = System.currentTimeMillis()
            val msg = try {
                attack { o, c ->
                    (0 until 300).map { i ->
                        val f = java.io.ByteArrayOutputStream(); repeat(1 + rnd.nextInt(3)) { f.write(frame()) }
                        serverInitial(o, c, sc, f.toByteArray(), pn = i.toLong())
                    }
                }
            } catch (e: Throwable) { leaked = e; "" }
            T.check("300 rastgele (doğrulanmış) çerçeveli Initial: hata IOException'dır, sızan istisna yok", leaked == null, leaked?.toString() ?: msg)
            T.check("rastgele çerçeveler ayrıştırıcıyı takmaz (en çok birkaç sn)", System.currentTimeMillis() - t0 < 6000, "${System.currentTimeMillis() - t0} ms")
            // kimliği doğrulanamayan rastgele datagramlar atılır, bağlantı hâlâ zaman aşımıyla biter
            val junk = attack { o, c -> (0 until 400).map { ByteArray(20 + rnd.nextInt(1300)).also { b -> rnd.nextBytes(b); if (rnd.nextBoolean()) b[0] = (b[0].toInt() or 0xC0).toByte() } } }
            T.check("400 rastgele datagram: yok sayılır, bağlantı zaman aşımıyla düşer", junk.contains("zaman aşımı"), junk)
        }
        // Http3: uzun yol/yetki değerleri doğru kodlanır (eskiden 126'da kesilirdi)
        for (n in intArrayOf(0, 1, 126, 127, 128, 300, 20000)) {
            val enc = Http3Client.qpackString("a".repeat(n))
            val pos = Http3Client.Companion.Pos(0)
            val len = Http3Client.prefInt(enc, pos, 7)
            T.check("QPACK düz değer uzunluğu $n doğru kodlanır", len == n && enc.size - pos.p == n)
        }
        // Gemini #3: QPACK tamsayı taşması ve geriye saran uzunluklar
        run {
            val bad = byteArrayOf(0x7F, 0x80.toByte(), 0x80.toByte(), 0x80.toByte(), 0x80.toByte(), 0x7F)       // 2^31'i aşan değer
            val r = try { Http3Client.prefInt(bad, Http3Client.Companion.Pos(0), 7); "kabul" } catch (_: java.io.IOException) { "ret" }
            T.check("QPACK tamsayısı 32 bit taşması reddedilir", r == "ret")
            val hb = byteArrayOf(0, 0, 0x20, 0x7F, 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0x0F)             // adı düz, dev uzunluk
            val r2 = try { Http3Client.statusOf(hb); "kabul" } catch (_: java.io.IOException) { "ret" } catch (_: Exception) { "başka" }
            T.check("QPACK dev alan uzunluğu IOException ile reddedilir", r2 == "ret")
        }
        T.check("QuicTls.isIpLiteral: gerçek IP'ler evet, ad/biçimsiz hayır",
            QuicTls.isIpLiteral("1.2.3.4") && QuicTls.isIpLiteral("2606:4700::1111") && !QuicTls.isIpLiteral("1.2.3.4.5") && !QuicTls.isIpLiteral("dns.example") && !QuicTls.isIpLiteral("999.1.1.1"))
    }

    if (!QuicEnv.available()) {
        println("\n  (python3 + aioquic yok: gerçek QUIC sunucusuyla birlikte çalışma testleri ATLANDI. Kurulum: pip install aioquic)")
        return
    }

    val dir = File(System.getProperty("java.io.tmpdir"), "dnshizli-quicenv-" + System.nanoTime()).also { it.mkdirs() }
    QuicEnv(dir).use { env ->
        val ec = env.cert("ec"); val rsa = env.cert("rsa")
        val doqEc = env.server("doq", ec)
        val doqRsa = env.server("doq", rsa)
        val doqBig = env.server("doq", ec, big = true)
        val h3 = env.server("h3", ec)
        val lo = InetAddress.getByName("127.0.0.1")

        fun client(port: Int, host: String, alpn: String, cert: String?): QuicClient =
            QuicClient(host, InetSocketAddress(lo, port), alpn, ::udp, if (cert != null) trustOf("$cert.crt") else QuicClient.systemTrust())

        T.group("QUIC: DoQ birlikte çalışma (aioquic sunucusu)")
        run {
            val c = client(doqEc, "localhost", "doq", ec)
            c.connect(5000)
            T.check("el sıkışma tamamlanır (ECDSA sertifika)", c.isOpen)
            val replies = (1..5).map { c.request(doqMsg(dnsQuery()), 3000) }
            T.check("5 sorgu aynı bağlantıda cevaplanır, A kaydı 1.2.3.4", replies.all { it.size == 2 + 49 && lastIp(it) == "1.2.3.4" && ((it[0].toInt() and 0xFF) shl 8 or (it[1].toInt() and 0xFF)) == it.size - 2 })
            T.check("cevap kimliği 0 (RFC 9250)", replies.all { it[2].toInt() == 0 && it[3].toInt() == 0 })
            c.close()
            T.check("kapatılınca açık değil", !c.isOpen)
            // Boşta bekleyen bağlantı bayat sayılır (sunucu sessizce atmış olabilir): yeni soru ona yazılıp asılı kalmasın
            val skew = java.util.concurrent.atomic.AtomicLong(0)
            val cs = QuicClient("localhost", InetSocketAddress(lo, doqEc), "doq", ::udp, trustOf("$ec.crt"), nowMs = { System.nanoTime() / 1_000_000 + skew.get() })
            cs.connect(5000)
            T.check("yeni kurulan bağlantı kullanılabilir", cs.isOpen && cs.usable)
            skew.addAndGet(25_000)
            T.check("25 sn sessizlikten sonra açık ama bayat (kullanılabilir değil)", cs.isOpen && !cs.usable)
            cs.close()
            val c2 = client(doqRsa, "localhost", "doq", rsa)
            c2.connect(5000)
            T.check("RSA sertifika (rsa_pss_rsae_sha256) ile el sıkışma ve sorgu", c2.isOpen && lastIp(c2.request(doqMsg(dnsQuery()), 3000)) == "1.2.3.4")
            c2.close()
            val c3 = client(doqBig, "localhost", "doq", ec)
            c3.connect(5000)
            val big = c3.request(doqMsg(dnsQuery()), 4000)
            T.check("çok paketli büyük cevap (3 KB) eksiksiz birleşir", big.size == 2 + 49 + 3000 && big.drop(2 + 49).all { it.toInt() == 0 })
            c3.close()
            val cc = client(doqEc, "localhost", "doq", ec); cc.connect(5000)
            val results = java.util.concurrent.CopyOnWriteArrayList<String>()
            val th = (1..12).map { Thread { try { repeat(4) { results.add(lastIp(cc.request(doqMsg(dnsQuery()), 4000))) } } catch (e: Exception) { results.add("hata:" + e.message) } } }
            th.forEach { it.start() }; th.forEach { it.join(15000) }
            T.check("12 iş parçacığı × 4 eşzamanlı sorgu tek bağlantıda doğru cevaplanır", results.size == 48 && results.all { it == "1.2.3.4" }, results.toString().take(200))
            cc.close()

            // DoH: HTTP/2 çoklama (python h2 sunucusu) ve HTTP/1.1'e geri dönüş
            run {
                val h2ok = try { ProcessBuilder("python3", "-c", "import h2").redirectErrorStream(true).start().let { it.waitFor(20, TimeUnit.SECONDS) && it.exitValue() == 0 } } catch (_: Exception) { false }
                if (!h2ok) {
                    println("  (python3 + h2 yok: HTTP/2 DoH testleri ATLANDI. Kurulum: pip install h2)")
                } else {
                    val factory = javax.net.ssl.SSLContext.getInstance("TLS").also { it.init(null, arrayOf(trustOf("$ec.crt")), null) }.socketFactory
                    val anyHost = javax.net.ssl.HostnameVerifier { _, _ -> true }    // ad denetimi değil, HTTP/2 test ediliyor (sertifika zinciri yukarıda doğrulandı)
                    fun doh(port: Int, n: Int, sequential: Boolean): Pair<Int, SecureForwarder> {
                        val got = java.util.concurrent.atomic.AtomicInteger()
                        val f = SecureForwarder(Proto.DOH, listOf(SecureTarget(InetSocketAddress(lo, port), "localhost", "/dns-query")),
                            { _, _, _ -> got.incrementAndGet() }, tls = factory, verifier = anyHost, timeoutMs = if (sequential) 4000 else 12000, maxLanes = 4, burstLanes = 8, giveUpMs = if (sequential) 6000 else 20000).also { it.start() }
                        if (sequential) {
                            for (i in 1..n) {
                                val pk = ipUdpQuery(0x500 + i, "seq$i.example.com"); f.onPacket(pk, pk.size)
                                val until = System.nanoTime() + 8_000_000_000L
                                while (got.get() < i && System.nanoTime() < until) Thread.sleep(10)
                            }
                        } else {
                            for (i in 1..n) { val pk = ipUdpQuery(0x500 + i, "h2-$i.example.com"); f.onPacket(pk, pk.size) }
                            val until = System.nanoTime() + 15_000_000_000L
                            while (got.get() < n && System.nanoTime() < until) Thread.sleep(20)
                        }
                        return Pair(got.get(), f)
                    }
                    val h2port = env.h2Server(ec, "both")
                    val (ans, fw2) = doh(h2port, 20, sequential = false)
                    T.check("HTTP/2 DoH: 20 eşzamanlı sorgu cevaplanır", ans == 20, "cevap=$ans ${fw2.stats()}")
                    T.check("HTTP/2 DoH: tüm şeritler TEK TLS bağlantısını çoklar", fw2.openConnections() == 1, "açık=${fw2.openConnections()}")
                    fw2.close()
                    val h1port = env.h2Server(ec, "h1")
                    val (ans1, fw1) = doh(h1port, 3, sequential = true)
                    T.check("sunucu HTTP/2 seçmezse HTTP/1.1 ile sorgular cevaplanır", ans1 == 3, "cevap=$ans1")
                    fw1.close()
                }
            }
            // Paylaşımlı QUIC (SecureForwarder): şeritler tek bağlantıyı çoklar; her soru ayrı akışta cevaplanır
            val answered = java.util.concurrent.atomic.AtomicInteger()
            val fwq = SecureForwarder(Proto.DOQ, listOf(SecureTarget(InetSocketAddress(lo, doqEc), "localhost")),
                { _, _, _ -> answered.incrementAndGet() }, openUdp = ::udp, quicTrust = trustOf("$ec.crt"),
                maxLanes = 4, burstLanes = 8, timeoutMs = 4000).also { it.start() }
            for (i in 1..24) { val pk = ipUdpQuery(0x300 + i, "s$i.example.com"); fwq.onPacket(pk, pk.size) }
            val until = System.nanoTime() + 15_000_000_000L
            while (answered.get() < 24 && System.nanoTime() < until) Thread.sleep(20)
            T.check("24 eşzamanlı DoQ sorusu paylaşımlı bağlantıda cevaplanır", answered.get() == 24, "cevap=${answered.get()}")
            T.check("tüm şeritler TEK QUIC bağlantısını paylaşır", fwq.openConnections() == 1, "açık=${fwq.openConnections()}")
            fwq.close()
        }

        T.group("QUIC: sertifika doğrulaması (saldırgan sunucu senaryoları)")
        run {
            fun fails(host: String, trust: String?, want: String): Boolean {
                val c = client(doqEc, host, "doq", trust)
                return try { c.connect(4000); c.close(); false } catch (e: java.io.IOException) { c.close(); e.message?.contains(want) == true }
            }
            T.check("yanlış sunucu adı reddedilir (hiçbir veri gitmez)", fails("evil.example", ec, "ait değil"))
            T.check("sistem güven deposunda olmayan sertifika reddedilir", fails("localhost", null, "güvenilmez"))
            val w = client(doqEc, "a.wild.test", "doq", ec)
            T.check("joker sertifika adı kabul edilir", try { w.connect(4000); w.isOpen } catch (_: Exception) { false })
            w.close()
            T.check("iki etiketli joker eşleşmesi reddedilir", fails("a.b.wild.test", ec, "ait değil"))
            val a = client(doqEc, "localhost", "h3", ec)
            T.check("ALPN uyuşmazlığı (sunucu doq, biz h3) bağlantıyı kurmaz", try { a.connect(3000); a.close(); false } catch (_: java.io.IOException) { a.close(); true })
            val dead = QuicClient("localhost", InetSocketAddress(lo, env.freePort()), "doq", ::udp, trustOf("$ec.crt"))
            val t0 = System.currentTimeMillis()
            T.check("yanıt vermeyen sunucuda zaman aşımı (≈1,5 sn), askıda kalmaz", try { dead.connect(1500); false } catch (_: java.io.IOException) { System.currentTimeMillis() - t0 < 4000 })
            dead.close()
        }

        T.group("QUIC: paket kaybı altında (UDP aktarıcı %20 kayıp, her iki yönde)")
        run {
            val p = env.freePort()
            env.lossy(p, doqEc, 0.20, 3)
            var okConn = 0; var okQ = 0; var total = 0
            repeat(6) {
                val c = client(p, "localhost", "doq", ec)
                try {
                    c.connect(9000); okConn++
                    repeat(4) { total++; try { if (lastIp(c.request(doqMsg(dnsQuery()), 6000)) == "1.2.3.4") okQ++ } catch (_: Exception) {} }
                } catch (_: Exception) {}
                c.close()
            }
            T.check("6 bağlantıdan en az 5'i kurulur", okConn >= 5, "kurulan=$okConn")
            T.check("kurulan bağlantılarda sorguların tamamına yakını cevaplanır (yeniden gönderim)", total > 0 && okQ >= total - 2, "$okQ/$total")
        }

        T.group("QUIC: DoH3 birlikte çalışma (aioquic HTTP/3 sunucusu)")
        run {
            val c = client(h3, "localhost", "h3", ec)
            c.connect(5000)
            val h = Http3Client(c, "localhost")
            val rs = (1..4).map { h.post("/dns-query", "application/dns-message", dnsQuery().also { it[0] = 0; it[1] = 0 }, 3000) }
            T.check("4 POST aynı bağlantıda cevaplanır, A kaydı 5.6.7.8", rs.all { it.size == 49 && lastIp(it) == "5.6.7.8" })
            T.check("yanlış yol 400 → IOException", try { h.post("/yok", "application/dns-message", dnsQuery(), 3000); false } catch (e: java.io.IOException) { e.message?.contains("400") == true })
            T.check("hatadan sonra bağlantı sağlam, sorgu yine çalışır", lastIp(h.post("/dns-query", "application/dns-message", dnsQuery(), 3000)) == "5.6.7.8")
            c.close()
        }

        T.group("QUIC: SecureForwarder uçtan uca (DoQ ve DoH3)")
        run {
            val tm = trustOf("$ec.crt")
            fun harness(proto: Proto, port: Int) = SecHarness(proto, listOf(SecureTarget(InetSocketAddress(lo, port), "localhost", "/dns-query")), quicTrust = tm, openUdp = ::udp)
            harness(Proto.DOQ, doqEc).use { h ->
                h.send(7)
                val r = h.reply(5000)
                T.check("DoQ: sorgu cevaplanır, istemci kimliği korunur", r != null && checkReply(r, 7) == null, r?.let { checkReply(it, 7) } ?: "cevap yok")
                T.check("DoQ: protokol", h.fw.proto == Proto.DOQ)
                h.send(8)
                val r2 = h.reply(3000)
                T.check("DoQ: aynı soru önbellekten", r2 != null && checkReply(r2, 8) == null && h.fw.stats().cacheHits == 1L)
                for (i in 0 until 12) h.send(100 + i, "n$i.example.com", 41000 + i)
                var got = 0
                repeat(12) { val x = h.reply(5000); if (x != null) got++ }
                T.check("DoQ: 12 farklı sorgu eşzamanlı, hepsi cevaplanır", got == 12, "got=$got")
                T.check("DoQ: şerit başına tek QUIC bağlantısı (en çok 4)", h.fw.openConnections() in 1..4, "bağlantı=${h.fw.openConnections()}")
            }
            harness(Proto.DOH3, h3).use { h ->
                h.send(9)
                val r = h.reply(5000)
                T.check("DoH3: sorgu cevaplanır (5.6.7.8), kimlik korunur", r != null && checkReply(r, 9, byteArrayOf(5, 6, 7, 8)) == null, r?.let { checkReply(it, 9, byteArrayOf(5, 6, 7, 8)) } ?: "cevap yok")
            }
            // yanlış ada sahip sunucu: hiçbir cevap gelmez, çökme yok
            SecHarness(Proto.DOQ, listOf(SecureTarget(InetSocketAddress(lo, doqEc), "evil.example", "/dns-query")), quicTrust = tm, openUdp = ::udp, timeoutMs = 800).use { h ->
                h.send(5)
                val r = h.reply(3500)
                T.check("DoQ: sertifika adı uyuşmazsa cevap verilmez (sahte sunucuya güvenilmez)", r == null || checkReply(r, 5) != null)
                T.check("DoQ: sertifika hatası güven hatası olarak sayılır (tlsFailures)", h.fw.stats().tlsFailures >= 1 && h.fw.stats().answered == 0L, "tlsFailures=${h.fw.stats().tlsFailures}")
            }
        }
    }
    dir.deleteRecursively()
}
