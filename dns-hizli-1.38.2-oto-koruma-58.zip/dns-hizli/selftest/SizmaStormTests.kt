package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.IOException
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Sızma 3 — iki kampanya:
 *  1) Düşmanca HTTP/2 (DoH) sunucusu: betiklenebilir ham çerçeve sunucusuyla dolgulu DATA (akış denetimi), CONTINUATION seli,
 *     HPACK bombaları, PING/SETTINGS seli, rastgele bölünmüş/sıra dışı yanıtlar ve çöp çerçeveler.
 *  2) Şerit tıkama: yavaş çözülen adlardan oluşan bir sel (tek alan ve çok alan), aynı anda hızlı sorgular soran "mağdur" uygulama.
 */

private val h2lo: InetAddress = InetAddress.getLoopbackAddress()
private fun nowMs(): Long = System.nanoTime() / 1_000_000

private fun h2f(type: Int, flags: Int, sid: Int, p: ByteArray): ByteArray {
    val h = ByteArray(9)
    h[0] = (p.size shr 16).toByte(); h[1] = (p.size shr 8).toByte(); h[2] = p.size.toByte()
    h[3] = type.toByte(); h[4] = flags.toByte()
    h[5] = (sid shr 24).toByte(); h[6] = (sid shr 16).toByte(); h[7] = (sid shr 8).toByte(); h[8] = sid.toByte()
    return h + p
}

private val H2_STATUS_200 = byteArrayOf(0x88.toByte())

/**
 * Betiklenebilir HTTP/2 "sunucu": tek bağlantı kabul eder, istemci çerçevelerini ayrıştırır, tamamlanan her isteği [onReq] ile bildirir.
 * Gerçek bir sunucu gibi AKIŞ DENETİMİNE uyar: bağlantı penceresi ([connWindow]) yetmiyorsa DATA göndermez (istemci WINDOW_UPDATE
 * vermezse yanıt asla gelmez).
 */
private class H2Peer(private val onReq: (H2Peer, Int, ByteArray) -> Unit) : AutoCloseable {
    val ss = ServerSocket(0, 8, h2lo)
    @Volatile var sock: Socket? = null
    @Volatile private var out: OutputStream? = null
    private val wl = Any()
    val connWindow = AtomicLong(65535)
    val pingAcks = AtomicInteger()
    val settingsAcks = AtomicInteger()
    val requests = AtomicInteger()
    @Volatile var readPaused = false
    private val exec = Executors.newCachedThreadPool { r -> Thread(r, "h2peer-iş").apply { isDaemon = true } }

    init {
        Thread({
            try {
                val c = ss.accept()
                sock = c
                out = c.getOutputStream()
                val inp = DataInputStream(BufferedInputStream(c.getInputStream(), 65536))
                inp.readFully(ByteArray(24))                                  // preface
                write(h2f(Http2Client.TYPE_SETTINGS, 0, 0, ByteArray(0)))
                val hdr = ByteArray(9)
                val bodies = HashMap<Int, ByteArrayOutputStream>()
                while (true) {
                    while (readPaused) Thread.sleep(20)
                    inp.readFully(hdr)
                    val len = ((hdr[0].toInt() and 0xFF) shl 16) or ((hdr[1].toInt() and 0xFF) shl 8) or (hdr[2].toInt() and 0xFF)
                    val type = hdr[3].toInt() and 0xFF
                    val flags = hdr[4].toInt() and 0xFF
                    val sid = ((hdr[5].toInt() and 0x7F) shl 24) or ((hdr[6].toInt() and 0xFF) shl 16) or ((hdr[7].toInt() and 0xFF) shl 8) or (hdr[8].toInt() and 0xFF)
                    val pay = ByteArray(len)
                    inp.readFully(pay)
                    when (type) {
                        Http2Client.TYPE_DATA -> {
                            val b = bodies.getOrPut(sid) { ByteArrayOutputStream() }
                            b.write(pay)
                            if (flags and Http2Client.FLAG_END_STREAM != 0) { bodies.remove(sid); requests.incrementAndGet(); val bb = b.toByteArray(); exec.execute { try { onReq(this, sid, bb) } catch (_: Exception) {} } }
                        }
                        Http2Client.TYPE_SETTINGS -> if (flags and Http2Client.FLAG_ACK != 0) settingsAcks.incrementAndGet()
                        Http2Client.TYPE_PING -> if (flags and Http2Client.FLAG_ACK != 0) pingAcks.incrementAndGet()
                        Http2Client.TYPE_WINDOW_UPDATE -> if (sid == 0 && len == 4) {
                            val inc = ((pay[0].toInt() and 0x7F) shl 24) or ((pay[1].toInt() and 0xFF) shl 16) or ((pay[2].toInt() and 0xFF) shl 8) or (pay[3].toInt() and 0xFF)
                            connWindow.addAndGet(inc.toLong())
                        }
                    }
                }
            } catch (_: Exception) {}
        }, "h2peer").also { it.isDaemon = true; it.start() }
    }

    fun write(b: ByteArray) { synchronized(wl) { val o = out ?: return; o.write(b); o.flush() } }

    /** Bağlantı penceresinden [n] bayt ayırır (yetmiyorsa [waitMs] boyunca bekler); ayıramazsa false. */
    private fun reserve(n: Int, waitMs: Long): Boolean {
        val end = System.currentTimeMillis() + waitMs
        while (true) {
            val cur = connWindow.get()
            if (cur >= n) { if (connWindow.compareAndSet(cur, cur - n)) return true; continue }
            if (System.currentTimeMillis() > end) return false
            Thread.sleep(3)
        }
    }

    /**
     * [sid] akışına 200 + [body] yanıtı. [pad] > 0 ise DATA dolgulu gider (dolgu bayt sayısı akış denetimine dahildir, RFC 9113 §6.1).
     * [chunkMax] > 0 ise bayt akışı 1..chunkMax baytlık parçalarla yazılır. Pencere yetmezse yanıt gönderilmez (false).
     */
    fun respond(sid: Int, body: ByteArray, pad: Int = 0, chunkMax: Int = 0, rnd: Random? = null, windowWaitMs: Long = 4000): Boolean {
        val payload = if (pad > 0) byteArrayOf(pad.toByte()) + body + ByteArray(pad) else body
        if (!reserve(payload.size, windowWaitMs)) return false
        val bytes = h2f(Http2Client.TYPE_HEADERS, Http2Client.FLAG_END_HEADERS, sid, H2_STATUS_200) +
            h2f(Http2Client.TYPE_DATA, Http2Client.FLAG_END_STREAM or (if (pad > 0) Http2Client.FLAG_PADDED else 0), sid, payload)
        synchronized(wl) {
            val o = out ?: return false
            if (chunkMax <= 0) { o.write(bytes); o.flush() }
            else {
                val r = rnd ?: Random(1)
                var i = 0
                while (i < bytes.size) { val n = minOf(bytes.size - i, 1 + r.nextInt(chunkMax)); o.write(bytes, i, n); o.flush(); i += n }
            }
        }
        return true
    }

    override fun close() { try { sock?.close() } catch (_: Exception) {}; try { ss.close() } catch (_: Exception) {}; exec.shutdownNow() }
}

private class H2Link(handler: (H2Peer, Int, ByteArray) -> Unit) : AutoCloseable {
    val peer = H2Peer(handler)
    val sock = Socket(h2lo, peer.ss.localPort)
    val cli = Http2Client(sock.getInputStream(), sock.getOutputStream(), "x.test") { nowMs() }.also { it.start() }
    fun post(body: ByteArray, timeoutMs: Int = 3000): Http2Client.Response = cli.post("/dns-query", "application/dns-message", body, timeoutMs)
    override fun close() { try { cli.close() } catch (_: Exception) {}; try { sock.close() } catch (_: Exception) {}; peer.close() }
}

private val DNS4 = byteArrayOf(0, 0, 0x81.toByte(), 0x80.toByte())

/** HPACK önekli tamsayı (RFC 7541 §5.1). */
private fun hpackInt(v: Int, prefix: Int, high: Int): ByteArray {
    val o = ByteArrayOutputStream(); val max = (1 shl prefix) - 1
    if (v < max) { o.write(high or v); return o.toByteArray() }
    o.write(high or max)
    var r = v - max
    while (r >= 128) { o.write((r and 0x7F) or 0x80); r = r ushr 7 }
    o.write(r)
    return o.toByteArray()
}

/** [f] bir istisnayla biter mi? (Hangi türde olduğu döner; hiç atmazsa null.) */
private inline fun thrown(f: () -> Unit): Throwable? = try { f(); null } catch (e: Throwable) { e }

fun runHostileH2Tests() {
    T.group("Sızma 3 / HTTP/2 düşman sunucu: dolgulu DATA bağlantı penceresini tüketemez (RFC 9113 §6.1: dolgu da akış denetimine dahil)")
    run {
        H2Link { p, sid, _ -> p.respond(sid, DNS4, pad = 255) }.use { l ->
            var ok = 0
            var err: String? = null
            val t0 = nowMs()
            for (i in 1..400) {
                try { val r = l.post(byteArrayOf(1, 2, 3), 2500); if (r.status == 200 && r.body.size == 4) ok++ else { err = "durum ${r.status} gövde ${r.body.size}"; break } }
                catch (e: Exception) { err = "${i}. istek: ${e.javaClass.simpleName} ${e.message}"; break }
            }
            T.check("400 dolgulu yanıt (toplam ≈104 KB > 64 KB pencere) hepsi alınır, pencere sızmaz", ok == 400, "ok=$ok err=$err pencere=${l.peer.connWindow.get()} (${nowMs() - t0} ms)")
            T.check("bağlantı hâlâ canlı", l.cli.alive)
        }
        // Yalnızca dolgudan oluşan (veri baytı 0) DATA da pencereyi geri vermeli
        H2Link { p, sid, _ -> p.respond(sid, ByteArray(0), pad = 200); }.use { l ->
            // gövdesiz yanıt: istemci boş cevap alır; amaç yalnız pencerenin geri verilmesi
            var got = 0
            for (i in 1..400) { try { l.post(byteArrayOf(1), 1500); got++ } catch (_: Exception) { break } }
            T.check("gövdesiz, yalnız dolgulu 400 yanıt (≈80 KB) pencereyi tüketmez", got == 400, "alınan=$got")
        }
    }

    T.group("Sızma 3 / HTTP/2 düşman sunucu: rastgele bölünmüş, sıra dışı, gürültülü çerçeveler arasında 240 eşzamanlı istek (kâhin: gövde tersine çevrilmiş)")
    run {
        val pool = Executors.newCachedThreadPool { r -> Thread(r).apply { isDaemon = true } }
        val rnd = Random(77)
        val rl = Any()
        fun r(n: Int): Int = synchronized(rl) { rnd.nextInt(n) }
        H2Link { p, sid, body ->
            pool.execute { try { Thread.sleep(r(25).toLong()); p.respond(sid, body.reversedArray(), pad = r(9), chunkMax = 1 + r(9), rnd = Random(sid.toLong())) } catch (_: Exception) {} }
        }.use { l ->
            val noiseStop = AtomicBoolean(false)
            val pings = AtomicInteger()
            val noise = Thread {
                val nr = Random(5)
                while (!noiseStop.get()) {
                    try {
                        when (nr.nextInt(5)) {
                            0 -> { l.peer.write(h2f(Http2Client.TYPE_PING, 0, 0, ByteArray(8).also { nr.nextBytes(it) })); pings.incrementAndGet() }
                            1 -> l.peer.write(h2f(Http2Client.TYPE_WINDOW_UPDATE, 0, 0, byteArrayOf(0, 0, 0, 1)))
                            2 -> l.peer.write(h2f(2, 0, 1 + 2 * nr.nextInt(50), byteArrayOf(0, 0, 0, 0, 16)))          // PRIORITY
                            3 -> l.peer.write(h2f(0xEE, nr.nextInt(256), nr.nextInt(5), ByteArray(nr.nextInt(40)).also { nr.nextBytes(it) }))   // bilinmeyen tür: yok sayılmalı
                            else -> l.peer.write(h2f(Http2Client.TYPE_SETTINGS, 0, 0, ByteArray(0)))
                        }
                        Thread.sleep(2)
                    } catch (_: Exception) { break }
                }
            }.also { it.isDaemon = true; it.start() }
            val bad = AtomicInteger(); val good = AtomicInteger(); val firstErr = java.util.concurrent.atomic.AtomicReference<String?>(null)
            val ths = (1..8).map { k -> Thread {
                val lr = Random(1000L + k)
                repeat(30) {
                    val body = ByteArray(1 + lr.nextInt(300)).also { lr.nextBytes(it) }
                    try {
                        val resp = l.post(body, 6000)
                        if (resp.status == 200 && resp.body.contentEquals(body.reversedArray())) good.incrementAndGet() else { bad.incrementAndGet(); firstErr.compareAndSet(null, "gövde uyuşmadı") }
                    } catch (e: Exception) { bad.incrementAndGet(); firstErr.compareAndSet(null, "${e.javaClass.simpleName}: ${e.message}") }
                }
            }.also { t -> t.start() } }
            ths.forEach { it.join(60_000) }
            noiseStop.set(true); noise.join(2000)
            T.check("240 istek: hepsi kendi (tersine çevrilmiş) gövdesini alır, karışma/kayıp yok", good.get() == 240 && bad.get() == 0, "iyi=${good.get()} kötü=${bad.get()} ilk=${firstErr.get()}")
            val settle = System.currentTimeMillis() + 3000
            while (l.peer.pingAcks.get() < pings.get() && System.currentTimeMillis() < settle) Thread.sleep(10)
            T.check("sunucunun gönderdiği her PING ($pings) cevaplandı (ACK)", pings.get() > 20 && l.peer.pingAcks.get() == pings.get(), "ping=${pings.get()} ack=${l.peer.pingAcks.get()}")
            T.check("bağlantı sağlam", l.cli.alive)
        }
        pool.shutdownNow()
    }

    T.group("Sızma 3 / HTTP/2 düşman sunucu: bitmeyen başlık bloğu (CONTINUATION seli) sınırlı bayt ve çerçeveyle kesilir")
    run {
        fun flood(frames: Int, size: Int, label: String, maxMs: Long) {
            H2Link { p, sid, _ ->
                Thread {
                    try {
                        p.write(h2f(Http2Client.TYPE_HEADERS, 0, sid, H2_STATUS_200))                  // END_HEADERS yok
                        repeat(frames) { p.write(h2f(Http2Client.TYPE_CONTINUATION, 0, sid, ByteArray(size))) }
                    } catch (_: Exception) {}
                }.also { it.isDaemon = true; it.start() }
            }.use { l ->
                val t0 = nowMs()
                val e = thrown { l.post(byteArrayOf(1, 2, 3), 6000) }
                val ms = nowMs() - t0
                T.check("$label: istek hızlı ve hata ile biter (zaman aşımı değil)", e is IOException && e !is SocketTimeoutException && ms < maxMs, "${e?.javaClass?.simpleName} ${e?.message} ($ms ms)")
                T.check("$label: bağlantı kesilmiş sayılır", !l.cli.alive)
            }
        }
        flood(40, 16384, "40 × 16 KB CONTINUATION", 2500)
        flood(5000, 0, "5000 boş CONTINUATION (bayt sayısı artmaz, çerçeve sayısı artar)", 2500)
        flood(200, 1, "200 × 1 baytlık CONTINUATION", 2500)
    }

    T.group("Sızma 3 / HTTP/2 düşman sunucu: HPACK bombaları (liste/tablo/tamsayı/dizin/Huffman) bağlantıyı hızlı ve temiz keser")
    run {
        fun bomb(label: String, block: () -> ByteArray) {
            H2Link { p, sid, _ -> p.write(h2f(Http2Client.TYPE_HEADERS, Http2Client.FLAG_END_HEADERS, sid, block())) }.use { l ->
                val t0 = nowMs()
                val e = thrown { l.post(byteArrayOf(1, 2, 3), 6000) }
                val ms = nowMs() - t0
                T.check("$label: hata ile ve hızlı biter", e is IOException && e !is SocketTimeoutException && ms < 2500, "${e?.javaClass?.simpleName} ${e?.message} ($ms ms)")
                T.check("$label: bağlantı kesilir", !l.cli.alive)
            }
        }
        bomb("2000 indeksli alan (liste sınırı)") { ByteArray(2000) { 0x82.toByte() } }
        bomb("tablo boyutu güncellemesi 1 MB (> 4096)") { byteArrayOf(0x3F, 0xE1.toByte(), 0xFF.toByte(), 0x3F, 0x88.toByte()) }
        bomb("devasa HPACK tamsayısı") { byteArrayOf(0x3F, 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0x7F, 0x88.toByte()) }
        bomb("var olmayan dinamik dizin") { byteArrayOf(0xBE.toByte(), 0x88.toByte()) }
        bomb("16370 baytlık Huffman değeri (şişme)") { byteArrayOf(0x40, 0x01, 0x61) + hpackInt(16370, 7, 0x80) + ByteArray(16370) }
        bomb("bildirilen uzunluk > veri") { byteArrayOf(0x40, 0x7F, 0xFF.toByte(), 0x7F, 0x61) }
        bomb("geç tablo boyutu güncellemesi") { byteArrayOf(0x88.toByte(), 0x20) }
    }
    run {
        // geçerli ama zorlayıcı: 3000 ayrı "dizinli literal" başlık bloğu (tablo sürekli döner); ardından normal yanıt
        H2Link { p, sid, _ ->
            val rnd = Random(3)
            for (i in 0 until 3000) {
                val nm = "x-h${rnd.nextInt(100000)}".toByteArray(); val v = "v${rnd.nextInt(100000)}".toByteArray()
                val blk = byteArrayOf(0x40, nm.size.toByte()) + nm + byteArrayOf(v.size.toByte()) + v
                p.write(h2f(Http2Client.TYPE_HEADERS, Http2Client.FLAG_END_HEADERS, 2 * i + 2, blk))          // var olmayan (sunucu) akışlar: yok sayılır, tablo yine eşitlenir
            }
            p.respond(sid, DNS4)
        }.use { l ->
            val t0 = nowMs()
            val r = try { l.post(byteArrayOf(1, 2, 3), 6000) } catch (e: Exception) { null }
            T.check("3000 tablo-döndüren başlık bloğundan sonra yanıt alınır (${nowMs() - t0} ms)", r != null && r.status == 200 && r.body.size == 4)
            T.check("bağlantı canlı", l.cli.alive)
        }
    }

    T.group("Sızma 3 / HTTP/2 düşman sunucu: PING ve SETTINGS seli — her biri cevaplanır, istek aç kalmaz")
    run {
        H2Link { p, sid, _ ->
            Thread {
                try {
                    val bo = ByteArrayOutputStream()
                    for (i in 0 until 20_000) { bo.write(h2f(Http2Client.TYPE_PING, 0, 0, ByteArray(8))); bo.write(h2f(Http2Client.TYPE_SETTINGS, 0, 0, ByteArray(0))) }
                    p.write(bo.toByteArray())
                    p.respond(sid, DNS4)
                } catch (_: Exception) {}
            }.also { it.isDaemon = true; it.start() }
        }.use { l ->
            val t0 = nowMs()
            val r = try { l.post(byteArrayOf(1, 2, 3), 15_000) } catch (e: Exception) { null }
            T.check("40 000 kontrol çerçevesinden sonra yanıt gelir (${nowMs() - t0} ms)", r != null && r.status == 200)
            val settle = System.currentTimeMillis() + 5000
            while ((l.peer.pingAcks.get() < 20_000 || l.peer.settingsAcks.get() < 20_001) && System.currentTimeMillis() < settle) Thread.sleep(20)
            T.check("20 000 PING ve 20 000 SETTINGS'in hepsi onaylandı", l.peer.pingAcks.get() == 20_000 && l.peer.settingsAcks.get() >= 20_000, "ping=${l.peer.pingAcks.get()} settings=${l.peer.settingsAcks.get()}")
        }
    }

    T.group("Sızma 3 / HTTP/2 düşman sunucu: 60 bağlantıda rastgele çöp çerçeveler — asılma yok, okuyucu iş parçacığı sızmaz")
    run {
        fun readers() = Thread.getAllStackTraces().keys.count { it.name == "doh2-okuyucu" && it.isAlive }
        val before = readers()
        val rnd = Random(424242)
        var hung = 0; var okN = 0; var errN = 0
        val longest = AtomicLong()
        for (round in 0 until 60) {
            val seed = rnd.nextLong()
            H2Link { p, sid, _ ->
                val r = Random(seed)
                try {
                    val bo = ByteArrayOutputStream()
                    repeat(1 + r.nextInt(12)) {
                        val type = if (r.nextInt(3) == 0) r.nextInt(256) else r.nextInt(10)
                        val len = if (r.nextInt(8) == 0) r.nextInt(40) else r.nextInt(6)
                        val sidr = if (r.nextBoolean()) sid else r.nextInt(8)
                        bo.write(h2f(type, r.nextInt(256), sidr, ByteArray(len).also { r.nextBytes(it) }))
                    }
                    if (r.nextInt(3) != 0) bo.write(h2f(Http2Client.TYPE_HEADERS, Http2Client.FLAG_END_HEADERS, sid, H2_STATUS_200))
                    if (r.nextInt(3) != 0) bo.write(h2f(Http2Client.TYPE_DATA, Http2Client.FLAG_END_STREAM, sid, DNS4))
                    p.write(bo.toByteArray())
                } catch (_: Exception) {}
            }.use { l ->
                val t0 = nowMs()
                val e = thrown { l.post(byteArrayOf(1, 2, 3), 400) }
                val ms = nowMs() - t0
                longest.set(maxOf(longest.get(), ms))
                if (ms > 2500) hung++
                if (e == null) okN++ else errN++
            }
        }
        Thread.sleep(600)
        val after = readers()
        T.check("hiçbir istek zaman aşımının çok ötesinde asılı kalmadı (en uzun ${longest.get()} ms)", hung == 0, "asılı=$hung")
        T.check("çöp çerçeveli bağlantılardan bazıları başarıyla, bazıları hata ile bitti (çeşitlilik: ok=$okN hata=$errN)", okN > 0 && errN > 0)
        T.check("okuyucu iş parçacığı sızıntısı yok (önce $before, sonra $after)", after <= before + 1, "önce=$before sonra=$after")
    }
}

// =============================================================================================================== şerit tıkama

private class StormResult(val lat: LongArray, val answered: Int, val total: Int, val dropped: Long = 0, val lanesPeak: Int = 0) {
    fun pct(p: Int): Long {
        val ok = lat.filter { it >= 0 }.sorted()
        if (ok.isEmpty()) return Long.MAX_VALUE
        return ok[minOf(ok.size - 1, (ok.size * p) / 100)]
    }
    fun within(ms: Long): Int = lat.count { it in 0..ms }
}

private fun cidOf(r: ByteArray) = Packets.u16(r, 28)

/**
 * Yavaş adlardan oluşan sel ([slowNames], her biri [slowMs] geç cevaplanır; istemci zaman aşımı [timeoutMs]) sürerken [victims] hızlı sorgu
 * [gapMs] arayla gönderilir. Her mağdur sorgunun cevap süresi (ms; cevap gelmediyse -1) döner.
 */
private fun stormRun(doh: Boolean, slowNames: List<String>, victims: Int, gapMs: Long, slowMs: Long, timeoutMs: Int, maxLanes: Int = 4, settleMs: Long = 9000, probe: ((SecHarness) -> Unit)? = null): StormResult {
    FakeTlsDns(doh).use { srv ->
        srv.slowMs = slowMs
        SecHarness(if (doh) Proto.DOH else Proto.DOT, listOf(srv.target), maxLanes = maxLanes, timeoutMs = timeoutMs, idleMs = 3000).use { h ->
            h.send(1, "warm.good.test"); h.reply(4000)                      // sunucu "sağlıklı": sonraki zaman aşımları yavaş ad sayılır
            val sentAt = ConcurrentHashMap<Int, Long>(); val gotAt = ConcurrentHashMap<Int, Long>()
            val stop = AtomicBoolean(false)
            val rd = Thread { while (!stop.get()) { val r = h.tun.poll(20, TimeUnit.MILLISECONDS) ?: continue; gotAt.putIfAbsent(cidOf(r), nowMs()) } }.also { it.isDaemon = true; it.start() }
            slowNames.forEachIndexed { i, n -> sentAt[1000 + i] = nowMs(); h.send(1000 + i, n) }
            Thread.sleep(150)
            for (v in 0 until victims) { sentAt[5000 + v] = nowMs(); h.send(5000 + v, "victim$v.good.test"); Thread.sleep(gapMs) }
            val end = nowMs() + settleMs
            var peak = h.fw.laneCount()
            while (nowMs() < end && (0 until victims).any { !gotAt.containsKey(5000 + it) }) { peak = maxOf(peak, h.fw.laneCount()); Thread.sleep(20) }
            stop.set(true); rd.join(500)
            val lat = LongArray(victims) { v -> val g = gotAt[5000 + v]; if (g == null) -1L else g - sentAt[5000 + v]!! }
            probe?.invoke(h)
            return StormResult(lat, lat.count { it >= 0 }, victims, h.fw.stats().dropped, peak)
        }
    }
}

fun runLaneStormTests() {
    T.group("Sızma 3 / şerit tıkama: tek alandan 30 yavaş ad, aynı anda hızlı sorgular (DoT) — mağdur aç kalmaz")
    run {
        val slow = (0 until 30).map { "slow$it.flood.test" }
        val r = stormRun(doh = false, slowNames = slow, victims = 15, gapMs = 100, slowMs = 2500, timeoutMs = 900)
        T.check("tüm mağdur sorgular cevaplandı (${r.answered}/${r.total})", r.answered == r.total, r.lat.joinToString(","))
        T.check("mağdurların %90'ı 700 ms içinde (≤ zaman aşımı 900 ms): p50=${r.pct(50)} p90=${r.pct(90)} en çok=${r.lat.maxOrNull()} ms", r.within(700) >= 14, r.lat.joinToString(","))
    }
    T.group("Sızma 3 / şerit tıkama: tek alandan 30 yavaş ad (DoH/1.1)")
    run {
        val slow = (0 until 30).map { "slow$it.flood.test" }
        val r = stormRun(doh = true, slowNames = slow, victims = 15, gapMs = 100, slowMs = 2500, timeoutMs = 900)
        T.check("tüm mağdur sorgular cevaplandı (${r.answered}/${r.total})", r.answered == r.total, r.lat.joinToString(","))
        T.check("mağdurların %90'ı 700 ms içinde: p50=${r.pct(50)} p90=${r.pct(90)} en çok=${r.lat.maxOrNull()} ms", r.within(700) >= 14, r.lat.joinToString(","))
    }
    T.group("Sızma 3 / şerit tıkama: tek alandan 300 yavaş ad kuyruğu (256) dolduramaz — alan payı 64, fazlası düşer, mağdur etkilenmez")
    run {
        val slow = (0 until 300).map { "slow$it.flood.test" }
        var suspectAtEnd = false
        val r = stormRun(doh = false, slowNames = slow, victims = 15, gapMs = 100, slowMs = 2500, timeoutMs = 900, probe = { h -> suspectAtEnd = h.fw.zoneSuspect("flood.test") })
        T.check("tüm mağdur sorgular cevaplandı (${r.answered}/${r.total})", r.answered == r.total, r.lat.joinToString(","))
        T.check("mağdurların %90'ı 700 ms içinde: p50=${r.pct(50)} p90=${r.pct(90)} en çok=${r.lat.maxOrNull()} ms", r.within(700) >= 14, r.lat.joinToString(","))
        T.check("fazla gelen sel sorguları kuyruğa alınmadı (düşenler: ${r.dropped})", r.dropped >= 150, "düşen=${r.dropped}")
        T.check("sel alanı şüpheli işaretlendi (zaman aşımı + yavaş çalışan iş)", suspectAtEnd)
        T.check("şerit sayısı ek şerit tavanını (12) aşmadı: tepe=${r.lanesPeak}", r.lanesPeak <= 12, "tepe=${r.lanesPeak}")
    }
    T.group("Sızma 3 / şerit tıkama: kısmen yavaş alan — bir yavaş ad yanında aynı alanın hızlı adları aç kalmaz (sınırın bedeli yalnızca sel sınırında)")
    run {
        FakeTlsDns(false).use { srv ->
            srv.slowMs = 2500
            SecHarness(Proto.DOT, listOf(srv.target), maxLanes = 4, timeoutMs = 900, idleMs = 3000).use { h ->
                h.send(1, "warm.good.test"); h.reply(4000)
                val sentAt = ConcurrentHashMap<Int, Long>(); val gotAt = ConcurrentHashMap<Int, Long>()
                val stop = AtomicBoolean(false)
                val rd = Thread { while (!stop.get()) { val r = h.tun.poll(20, TimeUnit.MILLISECONDS) ?: continue; gotAt.putIfAbsent(cidOf(r), nowMs()) } }.also { it.isDaemon = true; it.start() }
                fun lat(id: Int): Long = gotAt[id]?.let { it - sentAt[id]!! } ?: -1
                sentAt[100] = nowMs(); h.send(100, "slow0.mix.test")                         // yavaş ad (zaman aşımına gidecek)
                Thread.sleep(300)
                for (i in 0 until 8) { sentAt[200 + i] = nowMs(); h.send(200 + i, "fast$i.mix.test"); Thread.sleep(30) }
                Thread.sleep(300)
                val before = (0 until 8).map { lat(200 + it) }
                T.check("yavaş ad çalışırken aynı alanın 8 hızlı adı da ≤ 400 ms'de cevaplandı: ${before.joinToString(",")}", before.all { it in 0..400 })
                Thread.sleep(900)                                                           // yavaş ad zaman aşımına uğradı: alan bayraklı
                T.check("zaman aşımından sonra alan şüpheli işaretli", h.fw.zoneSuspect("mix.test"))
                for (i in 8 until 16) { sentAt[200 + i] = nowMs(); h.send(200 + i, "fast$i.mix.test"); Thread.sleep(30) }
                Thread.sleep(400)
                val after = (8 until 16).map { lat(200 + it) }
                T.check("bayraklı alanın hızlı adları (1 yavaş iş çalışıyor/yok) yine ≤ 400 ms: ${after.joinToString(",")}", after.all { it in 0..400 })
                stop.set(true); rd.join(500)
            }
        }
    }
    T.group("Sızma 3 / şerit tıkama: sağlıklı hatta aynı alandan 60 hızlı ad gerilemez (hepsi cevaplanır, kuyruk ve alan kaydı temizlenir)")
    run {
        FakeTlsDns(false).use { srv ->
            SecHarness(Proto.DOT, listOf(srv.target), maxLanes = 4, timeoutMs = 900, idleMs = 3000).use { h ->
                h.send(1, "warm.good.test"); h.reply(4000)
                val t0 = nowMs()
                for (i in 0 until 60) h.send(300 + i, "n$i.cdn.test")
                var got = 0
                val seen = HashSet<Int>()
                while (got < 60 && nowMs() - t0 < 5000) { val r = h.tun.poll(50, TimeUnit.MILLISECONDS) ?: continue; if (seen.add(cidOf(r))) got++ }
                T.check("60 sorgunun 60 cevabı ${nowMs() - t0} ms'de geldi", got == 60)
                T.check("şerit sayısı ek şerit tavanını (12) aşmadı", h.fw.laneCount() <= 12, "şerit=${h.fw.laneCount()}")
                T.check("kuyruk boş, alan kaydı kalmadı", waitUntil(1000) { h.fw.queuedJobs() == 0 && h.fw.trackedZones() == 0 }, "kuyruk=${h.fw.queuedJobs()} alan=${h.fw.trackedZones()}")
            }
        }
    }
    T.group("Sızma 3 / şerit tıkama: 14 AYRI alandan yavaş adlar (belgelenmiş sınır: ek şerit tavanı 12) — mağdur sonunda cevap alır")
    run {
        val slow = (0 until 14).map { "slow$it.zone$it.test" }
        val r = stormRun(doh = false, slowNames = slow, victims = 15, gapMs = 100, slowMs = 2500, timeoutMs = 900)
        T.check("çok alanlı selde de mağdurların tamamı cevaplanır (${r.answered}/${r.total}; p90=${r.pct(90)} ms)", r.answered == r.total, r.lat.joinToString(","))
    }
}
