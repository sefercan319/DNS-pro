package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.Random

/**
 * Sızma 23 — büyük bozulmalar: bozuk/kesik/kötü niyetli liste dosyaları, bellek bombası başlıkları, yarım kalan güncelleme (güç kesintisi
 * her adımda), diskte çürüyen önbellek, saatin geri sarılması. Amaç: hiçbir bozulma çökme, belleğin tükenmesi ya da engellemenin sessizce
 * kapanması olarak sonuçlanmamalı; her durumda ya düzgün bir durum ya da paketteki yedek devreye girmeli.
 */
internal fun runFaultTests() {
    // ---------------------------------------------------------------- yardımcılar
    fun enc(hashes: LongArray): ByteArray {
        val o = ByteArrayOutputStream()
        o.write("DNF1".toByteArray())
        val n = hashes.size
        o.write(n ushr 24); o.write(n ushr 16); o.write(n ushr 8); o.write(n)
        var prev = 0L
        for (h in hashes) {
            var d = h - prev; prev = h
            while (true) { val b = (d and 0x7F).toInt(); d = d ushr 7; if (d == 0L) { o.write(b); break } else o.write(b or 0x80) }
        }
        return o.toByteArray()
    }
    fun sortedHashes(n: Int, seed: Long): LongArray {
        val r = Random(seed)
        val s = java.util.TreeSet<Long>()
        while (s.size < n) s.add((r.nextLong() ushr 16) and ((1L shl 48) - 1))
        return s.toLongArray()
    }
    fun header(n: Long): ByteArray = byteArrayOf('D'.code.toByte(), 'N'.code.toByte(), 'F'.code.toByte(), '1'.code.toByte(),
        (n ushr 24).toByte(), (n ushr 16).toByte(), (n ushr 8).toByte(), n.toByte())
    val tmx = java.lang.management.ManagementFactory.getThreadMXBean() as com.sun.management.ThreadMXBean
    fun allocated(): Long = tmx.getThreadAllocatedBytes(Thread.currentThread().id)

    /** Sonuç: null = geçerli katman, "IO" = IOException; başka her şey (çalışma zamanı hatası, OOM) "X:<sınıf>". */
    fun tryRead(b: ByteArray): Pair<String?, FilterTier?> = try {
        null to FilterTier.read(ByteArrayInputStream(b))
    } catch (e: IOException) { "IO" to null } catch (e: Throwable) { ("X:" + e.javaClass.simpleName) to null }

    // ---------------------------------------------------------------- 1. FilterTier.read
    T.group("Sızma 23 / FilterTier.read: büyüme sınırlarında (65535…131073 ad) kayıpsız gidiş-dönüş")
    run {
        var bad = ""
        for (n in listOf(0, 1, 2, 65_535, 65_536, 65_537, 98_303, 98_304, 98_305, 131_071, 131_072, 131_073, 200_000)) {
            val hs = sortedHashes(n, 2300L + n)
            val (err, t) = tryRead(enc(hs))
            if (err != null || t == null) { bad += " n=$n:$err"; continue }
            val back = t.hashes
            if (t.size != n || !back.contentEquals(hs)) bad += " n=$n içerik"
            else if (n > 0 && (!t.contains(hs[0]) || !t.contains(hs[n - 1]) || !t.contains(hs[n / 2]))) bad += " n=$n contains"
        }
        T.check("tüm sınır boyutlarında okunan katman yazılanla birebir aynı", bad.isEmpty(), bad)
    }

    T.group("Sızma 23 / FilterTier.read: bellek bombası — başlık dev sayı söylese de ayırma gerçek veriyle sınırlı")
    run {
        val bombs = listOf(30_000_000L, 29_999_999L, 5_000_000L, 1_000_000L, 98_304L, 98_303L)
        var worst = 0L; var wrongErr = ""
        for (n in bombs) {
            val b = header(n) + ByteArray(10) { 1 }               // başlık + 10 baytlık veri
            System.gc()
            val before = allocated()
            val (err, _) = tryRead(b)
            val used = allocated() - before
            if (used > worst) worst = used
            if (err != "IO") wrongErr += " n=$n:$err"
        }
        T.check("dev başlık + 10 bayt veri: IOException (başka hata yok)", wrongErr.isEmpty(), wrongErr)
        T.check("ayrılan bellek 4 MB'ın altında (eskiden ~120 MB+)", worst < 4L shl 20, "en çok=${worst shr 10} KB")

        for (n in listOf(0x7FFFFFFFL, 0xFFFFFFFFL, 30_000_001L, 0x80000000L)) {
            val (err, _) = tryRead(header(n) + ByteArray(8) { 1 })
            T.check("geçersiz sayı 0x${java.lang.Long.toHexString(n)} reddedilir", err == "IO", "$err")
        }
        val (e0, _) = tryRead(header(5))
        T.check("başlık var ama veri yok: IOException", e0 == "IO")
    }

    T.group("Sızma 23 / FilterTier.read: kesilme — her önek (küçük) ve rastgele önekler (büyük) yalnızca IOException verir")
    run {
        val small = enc(sortedHashes(300, 2310))
        var wrong = 0; var accepted = 0; var first = ""
        for (len in 0 until small.size) {
            val (err, t) = tryRead(small.copyOf(len))
            if (err != "IO") { if (err == null && t != null) accepted++ else { wrong++; if (first.isEmpty()) first = "len=$len $err" } }
        }
        T.check("küçük dosyanın ${small.size} öneki: hepsi IOException", wrong == 0 && accepted == 0, "yanlış=$wrong kabul=$accepted $first")
        val big = enc(sortedHashes(120_000, 2311))
        val rnd = Random(2312)
        var bw = 0; var bf = ""
        repeat(400) {
            val len = if (it < 4) it else rnd.nextInt(big.size)
            val (err, _) = tryRead(big.copyOf(len))
            if (err != "IO") { bw++; if (bf.isEmpty()) bf = "len=$len $err" }
        }
        T.check("büyük (kompakt) dosyada 400 rastgele önek: hepsi IOException", bw == 0, "yanlış=$bw $bf")
        T.check("tam dosya hâlâ okunur", tryRead(big).first == null && tryRead(small).first == null)
    }

    T.group("Sızma 23 / FilterTier.read: bit çevirme (3000 küçük + 300 büyük) — IOException ya da tutarlı katman; asla başka hata")
    run {
        val rnd = Random(2320)
        fun run(src: ByteArray, count: Int, label: String) {
            var other = 0; var io = 0; var ok = 0; var incons = 0; var first = ""
            repeat(count) {
                val b = src.copyOf()
                val bit = rnd.nextInt(b.size * 8)
                b[bit / 8] = (b[bit / 8].toInt() xor (1 shl (bit % 8))).toByte()
                val (err, t) = tryRead(b)
                when {
                    err == "IO" -> io++
                    err != null -> { other++; if (first.isEmpty()) first = "bit=$bit $err" }
                    t != null -> {
                        ok++
                        // Geçerli görünen katman iç tutarlı olmalı: sıralı, boyu başlıktaki sayıya eşit, contains çökmez.
                        val h = t.hashes
                        var sorted = h.size == t.size
                        for (i in 1 until h.size) if (h[i] < h[i - 1]) { sorted = false; break }
                        if (!sorted) { incons++; if (first.isEmpty()) first = "tutarsız bit=$bit" }
                        for (probe in longArrayOf(0L, 1L, (1L shl 48) - 1, rnd.nextLong() ushr 16)) t.contains(probe)
                    }
                }
            }
            T.check("$label: başka hata yok, tutarsız katman yok", other == 0 && incons == 0, "diğer=$other tutarsız=$incons $first")
            T.check("$label: bozulmaların bir kısmı yakalanır, bir kısmı geçerli kalır (io=$io geçerli=$ok)", io + ok == count)
        }
        run(enc(sortedHashes(400, 2321)), 3000, "küçük dosya")
        run(enc(sortedHashes(110_000, 2322)), 300, "büyük dosya")
    }

    T.group("Sızma 23 / FilterTier.read: rastgele çöp, uzun varint, taşan fark, artık bayt, bozuk akış")
    run {
        val rnd = Random(2330)
        var other = 0; var first = ""
        repeat(3000) {
            val body = ByteArray(rnd.nextInt(400)); rnd.nextBytes(body)
            val n = rnd.nextInt(60)
            val (err, _) = tryRead(header(n.toLong()) + body)
            if (err != null && err != "IO") { other++; if (first.isEmpty()) first = err }
        }
        T.check("3000 rastgele gövde: IOException ya da geçerli; başka hata yok", other == 0, first)
        var garbage = 0
        repeat(2000) { val b = ByteArray(rnd.nextInt(60)); rnd.nextBytes(b); val (e, _) = tryRead(b); if (e != "IO" && e != null) garbage++ }
        T.check("2000 tamamen rastgele dosya: başlık tanınmaz → IOException", garbage == 0)
        T.check("sıfır uzunluklu dosya (güç kesintisi sonrası) → IOException", tryRead(ByteArray(0)).first == "IO")
        T.check("yalnızca sihirli bayt → IOException", tryRead("DNF1".toByteArray()).first == "IO")
        T.check("yanlış sihir 'DNF2' → IOException", tryRead(header(1).also { it[3] = '2'.code.toByte() } + byteArrayOf(5)).first == "IO")
        val longVarint = header(1) + ByteArray(11) { 0x80.toByte() } + byteArrayOf(0x01)
        T.check("11 baytlık varint → IOException", tryRead(longVarint).first == "IO")
        val over = header(2) + ByteArray(8) { 0xFF.toByte() } + byteArrayOf(0x7F) + byteArrayOf(0x01)
        T.check("fark 2^63'ü aşar (taşma) → IOException", tryRead(over).first == "IO")
        val oneHash = enc(longArrayOf(77))
        T.check("artık bayt → IOException", tryRead(oneHash + byteArrayOf(0)).first == "IO")
        T.check("48 bit üstü özet → IOException", tryRead(header(1) + byteArrayOf(0x80.toByte(), 0x80.toByte(), 0x80.toByte(), 0x80.toByte(), 0x80.toByte(), 0x80.toByte(), 0x80.toByte(), 0x01)).first == "IO")

        class Flaky(val data: ByteArray, val failAt: Int) : InputStream() {
            var p = 0
            override fun read(): Int = if (p >= failAt) throw IOException("disk hatası") else if (p < data.size) data[p++].toInt() and 0xFF else -1
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                if (p >= failAt) throw IOException("disk hatası")
                if (p >= data.size) return -1
                val n = minOf(len, 1 + (p % 3), data.size - p, failAt - p)      // küçük, düzensiz parçalar
                System.arraycopy(data, p, b, off, n); p += n; return n
            }
        }
        val good = enc(sortedHashes(500, 2331))
        var flakyBad = 0
        for (fa in listOf(0, 3, 8, 9, 50, good.size - 1)) {
            try { FilterTier.read(Flaky(good, fa)); flakyBad++ } catch (e: IOException) { } catch (e: Throwable) { flakyBad++ }
        }
        T.check("okuma ortasında disk hatası: IOException yayılır", flakyBad == 0)
        val dripped = try { FilterTier.read(Flaky(good, Int.MAX_VALUE)).size } catch (e: Throwable) { -1 }
        T.check("1–3 baytlık düzensiz parçalarla tam dosya doğru okunur", dripped == 500, "$dripped")
    }

    // ---------------------------------------------------------------- 2. FilterRuntime bozuk kaynaklarla
    T.group("Sızma 23 / FilterRuntime: her katman için bozuk kaynak türleri — paketteki yedek devreye girer, engelleme kapanmaz")
    run {
        val assets = File("app/src/main/assets/filter")
        val packaged = FilterSource { name -> File(assets, name).inputStream() }
        val probes = listOf("doubleclick.net", "googlesyndication.com", "adnxs.com", "criteo.com", "example.org")
        val real = File(assets, "basic.bin").readBytes()
        val rnd = Random(2340)
        val kinds: List<Pair<String, (String) -> InputStream>> = listOf(
            "rastgele çöp" to { _ -> ByteArrayInputStream(ByteArray(300) { rnd.nextInt().toByte() }) },
            "sıfır uzunluk" to { _ -> ByteArrayInputStream(ByteArray(0)) },
            "yarıda kesik" to { n -> ByteArrayInputStream(File(assets, n).readBytes().let { it.copyOf(it.size / 2) }) },
            "artık bayt" to { n -> ByteArrayInputStream(File(assets, n).readBytes() + byteArrayOf(1, 2, 3)) },
            "bomba başlık" to { _ -> ByteArrayInputStream(header(30_000_000L) + ByteArray(20)) },
            "IOException" to { _ -> throw IOException("okunamadı") },
            "çalışma zamanı hatası" to { _ -> throw IllegalStateException("depolama bozuk") },
            "güvenlik istisnası" to { _ -> throw SecurityException("izin yok") },
        )
        try {
            FilterRuntime.reset()
            FilterRuntime.fallbackSource = packaged
            FilterRuntime.source = packaged
            FilterRuntime.updateNow(FilterLevel.STRICT, emptyList(), emptyList())
            val healthy = probes.map { FilterRuntime.engine!!.verdictOf(it) }
            T.check("sağlam kaynakla ölçüt: reklam adları engelli", healthy.count { it == FilterVerdict.LIST } >= 3, "$healthy")
            T.check("sağlam kaynakla bozuk durum yok", FilterRuntime.listsLive() && !FilterRuntime.degraded)

            var bad = ""
            for ((label, mk) in kinds) for (tier in listOf("basic.bin", "medium.bin", "strict.bin")) {
                val broken = FilterSource { n -> if (n == tier) mk(n) else File(assets, n).inputStream() }
                FilterRuntime.source = broken
                FilterRuntime.reloadListsNow()
                val v = FilterRuntime.engine?.let { e -> probes.map { e.verdictOf(it) } }
                if (v != healthy || !FilterRuntime.listsLive()) bad += " [$label/$tier]"
            }
            T.check("8 bozulma türü × 3 katman: kararlar sağlamla birebir aynı, motor 'canlı'", bad.isEmpty(), bad)

            // Korunan ad listesi (protected.txt) ve PSL de bozuk/okunamaz: motor yine paket yedeğiyle canlı kalır
            for ((label, mk) in kinds) {
                val broken = FilterSource { n -> if (n == "protected.txt" || n == "psl.txt") mk(n) else File(assets, n).inputStream() }
                FilterRuntime.source = broken
                FilterRuntime.reloadListsNow()
                val v = FilterRuntime.engine?.let { e -> probes.map { e.verdictOf(it) } }
                if (v != healthy || !FilterRuntime.listsLive()) bad += " [$label/protected]"
            }
            T.check("protected.txt bozukken de (8 tür) motor canlı ve kararlar aynı", !bad.contains("/protected]"), bad)

            // Tüm katmanlar aynı anda bozuk
            val allBroken = FilterSource { _ -> ByteArrayInputStream(ByteArray(40) { 7 }) }
            FilterRuntime.source = allBroken
            FilterRuntime.reloadListsNow()
            T.check("üç katman da bozukken paket yedeğiyle yine aynı kararlar", FilterRuntime.engine?.let { e -> probes.map { e.verdictOf(it) } } == healthy)

            // Yedek de bozuk: güvenli başarısızlık (çökme yok, motor var, 'bozuk' işaretli), sonra onarılınca iyileşir
            FilterRuntime.fallbackSource = allBroken
            FilterRuntime.reloadListsNow()
            T.check("hem kaynak hem yedek bozuk: motor yine de var (engelleme kapalı), 'bozuk' işaretlenir",
                FilterRuntime.engine != null && FilterRuntime.degraded && !FilterRuntime.listsLive() && FilterRuntime.engine!!.verdictOf("doubleclick.net") == FilterVerdict.PASS)
            T.check("bu durumda kullanıcı engeli yine çalışır", run {
                FilterRuntime.updateNow(FilterLevel.STRICT, emptyList(), listOf("benim-engelim.example"))
                FilterRuntime.engine!!.verdictOf("benim-engelim.example") == FilterVerdict.USER
            })
            FilterRuntime.source = packaged
            FilterRuntime.fallbackSource = packaged
            val kicked = FilterRuntime.heal(10_000_000L)
            var live = false
            for (i in 0 until 100) { if (FilterRuntime.listsLive()) { live = true; break }; Thread.sleep(50) }
            T.check("depolama düzelince heal() motoru yeniden kurar", kicked && live)
            T.check("iyileşme sonrası kararlar sağlamla aynı", FilterRuntime.engine?.let { e -> probes.map { e.verdictOf(it) } } == healthy)

            // Bellek yetmezse
            FilterRuntime.reset()
            FilterRuntime.fallbackSource = packaged
            FilterRuntime.source = FilterSource { n -> if (n == "strict.bin") throw OutOfMemoryError("sahte") else File(assets, n).inputStream() }
            FilterRuntime.updateNow(FilterLevel.STRICT, emptyList(), emptyList())
            T.check("sıkı katman belleğe sığmazsa daha hafif katmanlarla sürer (çökme yok)",
                FilterRuntime.engine != null && FilterRuntime.engine!!.verdictOf("doubleclick.net") == FilterVerdict.LIST)
            FilterRuntime.source = FilterSource { _ -> throw OutOfMemoryError("sahte") }
            FilterRuntime.reloadListsNow()
            T.check("hiçbir katman sığmazsa da motor var ve çökme yok", FilterRuntime.engine != null)
        } finally {
            FilterRuntime.reset()
            FilterRuntime.fallbackSource = null
            FilterRuntime.source = packaged
            FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), emptyList())
        }
        T.check("gerçek basic.bin bozulmadan okunur (referans)", tryRead(real).first == null)
    }

    // ---------------------------------------------------------------- 3. ListStore: kesinti ve bozuk önbellek
    T.group("Sızma 23 / ListStore: güncellemenin her adımında güç kesintisi — recover() sonrası tek, tutarlı sürüm")
    run {
        fun tmp(): File = java.nio.file.Files.createTempDirectory("sizma23").toFile()
        val names = ListUpdate.UPDATABLE.toList()
        fun put(dir: File, tag: Int, only: Int = names.size) { dir.mkdirs(); for (n in names.take(only)) File(dir, n).writeBytes(ByteArray(300) { tag.toByte() }) }
        fun tagsOf(dir: File): Set<Int> = names.map { n -> File(dir, n).takeIf { it.isFile }?.readBytes()?.firstOrNull()?.toInt() ?: -1 }.toSet()
        val rnd = Random(2350)
        var bad = ""
        // 5 kesinti noktası × 40 rastgele yarım dosya durumu
        for (iter in 0 until 200) {
            val root = tmp()
            put(File(root, ListStore.DIR), 1)
            val crash = iter % 5
            val stage = File(root, ListStore.STAGE); val cur = File(root, ListStore.DIR); val old = File(root, ListStore.BACKUP)
            // install() adımlarını elle, 'crash' adımında kes
            put(stage, 2, if (crash == 0) rnd.nextInt(0, names.size + 1) else names.size)       // 0: yazım sırasında kesildi
            if (crash >= 1) {                                                                  // 1: yazım bitti, yeniden adlandırma öncesi
                if (crash >= 2) cur.renameTo(old)                                              // 2: kurulu → yedek yapıldı
                if (crash >= 3) stage.renameTo(cur)                                            // 3: yeni → kurulu yapıldı
                if (crash >= 4) old.deleteRecursively()                                        // 4: yedek silindi (tamam)
            }
            ListStore.recover(root)
            val t = if (cur.exists()) tagsOf(cur) else emptySet()
            val consistent = t.size <= 1 && (t.isEmpty() || t.first() in listOf(1, 2))
            val clean = !stage.exists() && !old.exists()
            val expected = when (crash) { 0, 1, 2 -> setOf(1); else -> setOf(2) }
            if (!consistent || !clean || t != expected) bad += " [it=$iter crash=$crash t=$t clean=$clean]"
            ListStore.recover(root); ListStore.recover(root)                                   // idempotent
            if ((if (cur.exists()) tagsOf(cur) else emptySet<Int>()) != t) bad += " [it=$iter idempotent değil]"
            root.deleteRecursively()
        }
        T.check("200 kesinti senaryosu: sürüm karışmaz (1 ya da 2), artık dizin kalmaz, recover tekrar çalışır", bad.isEmpty(), bad.take(300))

        // Özel durumlar
        val r1 = tmp()
        put(File(r1, ListStore.STAGE), 9)
        ListStore.recover(r1)
        T.check("yalnızca yarım yeni dizin varsa silinir, kurulu liste oluşmaz", !File(r1, ListStore.STAGE).exists() && !File(r1, ListStore.DIR).exists())
        val r2 = tmp()
        put(File(r2, ListStore.BACKUP), 5); put(File(r2, ListStore.STAGE), 6)
        ListStore.recover(r2)
        T.check("kurulu yok + yedek + yeni: yedek geri gelir, yeni silinir", tagsOf(File(r2, ListStore.DIR)) == setOf(5) && !File(r2, ListStore.STAGE).exists() && !File(r2, ListStore.BACKUP).exists())
        val r3 = tmp()
        put(File(r3, ListStore.DIR), 3); put(File(r3, ListStore.BACKUP), 4)
        ListStore.recover(r3)
        T.check("kurulu + yedek birlikte: kurulu kalır, yedek silinir", tagsOf(File(r3, ListStore.DIR)) == setOf(3) && !File(r3, ListStore.BACKUP).exists())
        val r4 = File(tmp(), "yok/olmayan"); ListStore.recover(r4)
        T.check("kök dizin yokken recover sessizce döner", true)
        val rf = File.createTempFile("sizma23", ".dosya")
        T.check("kök bir DOSYAYSA install false döner, çökmez", !ListStore.install(rf, ListUpdate.UPDATABLE.associateWith { ByteArray(10) }))
        val r5 = tmp(); ListStore.install(r5, ListUpdate.UPDATABLE.associateWith { ByteArray(500) { 1 } })
        val before = tagsOf(File(r5, ListStore.DIR))
        val badSets = listOf(
            emptyMap<String, ByteArray>(),
            mapOf("../kacis.bin" to ByteArray(10)),
            mapOf("basic.bin" to ByteArray(10), "../../x" to ByteArray(10)),
            mapOf("psl.txt" to ByteArray(10)),
        )
        T.check("geçersiz kümeler (boş, yol geçişi, güncellenemeyen) reddedilir; kurulu liste değişmez",
            badSets.none { ListStore.install(r5, it) } && tagsOf(File(r5, ListStore.DIR)) == before && !File(r5, ListStore.STAGE).exists() && !File(r5, ListStore.BACKUP).exists())
        T.check("yol geçişi dışarıya dosya yazmadı", !File(r5.parentFile, "kacis.bin").exists() && !File(r5.parentFile.parentFile, "x").exists())
    }

    T.group("Sızma 23 / Diskte çürüyen önbellek: gerçek liste dosyaları kurulduktan sonra bozulursa paket yedeği (uçtan uca)")
    run {
        val assets = File("app/src/main/assets/filter")
        val packaged = FilterSource { name -> File(assets, name).inputStream() }
        val probes = listOf("doubleclick.net", "googlesyndication.com", "adnxs.com", "criteo.com")
        val rnd = Random(2360)
        val root = java.nio.file.Files.createTempDirectory("sizma23-disk").toFile()
        val files = ListUpdate.UPDATABLE.associateWith { File(assets, it).readBytes() }
        try {
            FilterRuntime.reset()
            FilterRuntime.fallbackSource = packaged
            val cache = FilterSource { n -> if (n in ListUpdate.UPDATABLE) File(ListStore.dir(root), n).inputStream() else File(assets, n).inputStream() }
            FilterRuntime.source = cache
            T.check("önbellek kurulur (fsync'li yazım)", ListStore.install(root, files))
            FilterRuntime.updateNow(FilterLevel.STRICT, emptyList(), emptyList())
            val healthy = probes.map { FilterRuntime.engine!!.verdictOf(it) }
            T.check("sağlam önbellekle reklam adları engelli", healthy.count { it == FilterVerdict.LIST } >= 3 && FilterRuntime.listsLive(), "$healthy")

            fun corrupt(label: String, mutate: (File) -> Unit): Boolean {
                ListStore.install(root, files)
                for (n in ListUpdate.UPDATABLE) mutate(File(ListStore.dir(root), n))
                FilterRuntime.reloadListsNow()
                val v = FilterRuntime.engine?.let { e -> probes.map { e.verdictOf(it) } }
                return v == healthy && FilterRuntime.listsLive()
            }
            T.check("güç kesintisi: dosyalar sıfır uzunluklu", corrupt("sıfır") { it.writeBytes(ByteArray(0)) })
            T.check("güç kesintisi: dosyalar yarı yazılmış", corrupt("yarım") { it.writeBytes(it.readBytes().let { b -> b.copyOf(b.size / 2) }) })
            T.check("dosyalar silinmiş", corrupt("silinmiş") { it.delete() })
            T.check("dosya yerine dizin", corrupt("dizin") { it.delete(); it.mkdirs() })
            T.check("bozuk blok: ortası sıfırlanmış (başlık sağlam, gövde bozuk, boy aynı)", corrupt("sıfırlı") {
                val b = it.readBytes(); for (i in b.size / 3 until b.size / 3 + 4096) b[i] = 0; it.writeBytes(b)
            })
            T.check("başlık sayısı bozulmuş (dev sayı)", corrupt("başlık") { val b = it.readBytes(); b[4] = 0x01; b[5] = 0x70; it.writeBytes(b) })
            T.check("sonuna çöp eklenmiş", corrupt("çöp") { it.appendBytes(ByteArray(100) { rnd.nextInt().toByte() }) })
            val sample = File(ListStore.dir(root), "basic.bin")
            T.check("yukarıdaki durumlardan sonra motor yine canlı ve kararlar aynı", run {
                ListStore.install(root, files); FilterRuntime.reloadListsNow()
                FilterRuntime.engine?.let { e -> probes.map { e.verdictOf(it) } } == healthy && sample.isFile
            })
        } finally {
            FilterRuntime.reset()
            FilterRuntime.fallbackSource = null
            FilterRuntime.source = packaged
            FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), emptyList())
            root.deleteRecursively()
        }
    }

    T.group("Sızma 23 / ListUpdate.parse + imza: bozuk manifest ve imza çöküşe yol açmaz (bit çevirme, kesme, çöp)")
    run {
        val kp = java.security.KeyPairGenerator.getInstance("EC").run { initialize(java.security.spec.ECGenParameterSpec("secp256r1")); generateKeyPair() }
        val payload = ByteArray(200_000) { (it * 7).toByte() }
        val sb = StringBuilder("DNSHIZLI-LISTE 1\nsurum=5\n")
        for (n in ListUpdate.UPDATABLE) sb.append("$n ${ListUpdate.sha256Hex(payload)} ${payload.size}\n")
        val manifest = sb.toString().toByteArray()
        val sig = java.security.Signature.getInstance("SHA256withECDSA").run { initSign(kp.private); update(manifest); sign() }
        val rnd = Random(2370)
        var thrown = 0; var accepted = 0; var sigAccepted = 0; var first = ""
        repeat(3000) {
            val b = manifest.copyOf(); val bit = rnd.nextInt(b.size * 8); b[bit / 8] = (b[bit / 8].toInt() xor (1 shl (bit % 8))).toByte()
            try {
                ListUpdate.parse(b)?.let { accepted++ }
                if (ListUpdate.verifySignature(b, sig, kp.public)) sigAccepted++
            } catch (e: Throwable) { thrown++; if (first.isEmpty()) first = e.toString() }
        }
        repeat(2000) {
            val b = ByteArray(rnd.nextInt(600)); rnd.nextBytes(b)
            val s = ByteArray(rnd.nextInt(100)); rnd.nextBytes(s)
            try { ListUpdate.parse(b); ListUpdate.verifySignature(manifest, s, kp.public); ListUpdate.publicKey(b) } catch (e: Throwable) { thrown++; if (first.isEmpty()) first = e.toString() }
        }
        for (len in 0 until manifest.size step 7) try { ListUpdate.parse(manifest.copyOf(len)) } catch (e: Throwable) { thrown++; if (first.isEmpty()) first = e.toString() }
        T.check("5000+ bozuk manifest/imza/anahtar: hiçbiri istisna fırlatmaz", thrown == 0, "$thrown $first")
        T.check("tek bit çevrilmiş imzalı manifest imzayı geçemez", sigAccepted == 0, "kabul=$sigAccepted")
        val sigFlips = (0 until 500).count {
            val s = sig.copyOf(); val bit = rnd.nextInt(s.size * 8); s[bit / 8] = (s[bit / 8].toInt() xor (1 shl (bit % 8))).toByte()
            ListUpdate.verifySignature(manifest, s, kp.public)
        }
        T.check("tek bit çevrilmiş imza geçersiz", sigFlips == 0, "kabul=$sigFlips")
        T.check("bozulmamış manifest ve imza kabul edilir (referans)", ListUpdate.parse(manifest) != null && ListUpdate.verifySignature(manifest, sig, kp.public))
    }

    // ---------------------------------------------------------------- 4. Saat geri sarılması
    T.group("Sızma 23 / DnsCache: saat geri giderse kayıt atılır (yaşı bilinemez); normal akış bozulmaz")
    run {
        var now = 5_000_000L
        val c = DnsCache(8, { now }, 8192)
        val q = Dns.buildQuery(0x1, "geri.example.com")
        val r = ByteArray(q.size + 16); System.arraycopy(q, 0, r, 0, q.size)
        Packets.put16(r, 2, 0x8180); Packets.put16(r, 6, 1)
        val o = q.size; Packets.put16(r, o, 0xC00C); Packets.put16(r, o + 2, 1); Packets.put16(r, o + 4, 1); Packets.put32(r, o + 6, 60); Packets.put16(r, o + 10, 4)
        val out = ByteArray(512)

        c.put("a", r, r.size, 60); c.put("b", r, r.size, 60); c.put("c", r, r.size, 60)
        now += 10_000
        T.check("ileri akış: 10 sn sonra taze, TTL 50", c.get("a", 7, out, 0) == r.size && Packets.i32(out, o + 6) == 50)
        now = 5_000_000L - 1
        T.check("saat 1 ms geri: taze sorgu -1 (kayıt atılır)", c.get("a", 7, out, 0) == -1 && c.size() == 2)
        T.check("saat geri: bayat sorgu -1 ve kayıt atılır", c.getStale("b", 7, out, 0) == -1 && c.size() == 1)
        T.check("saat geri: ön yenileme istenmez", !c.prefetchDue("c"))
        now = 5_000_000L + 5_000
        T.check("saat tekrar ilerleyince atılan kayıt dirilmez; bayt sayacı tutarlı", c.get("a", 7, out, 0) == -1 && c.get("b", 7, out, 0) == -1 && c.byteSize() == c.size() * r.size, "boyut=${c.size()} bayt=${c.byteSize()}")

        // Kaos: saat rastgele ileri-geri; hiçbir cevap kayıt süresinin dışında verilmez, sayaçlar tutarlı kalır
        val rnd = Random(2380)
        var t = 10_000_000L
        val c2 = DnsCache(5, { t }, 4096)
        val stored = HashMap<String, LongArray>()      // key → [storedAt, expiresAt]
        var violations = 0; var first = ""
        repeat(30_000) {
            val key = "k${rnd.nextInt(7)}"
            when (rnd.nextInt(5)) {
                0 -> { val ttl = 1 + rnd.nextInt(120); c2.put(key, r, r.size, ttl); stored[key] = longArrayOf(t, t + ttl * 1000L) }
                1 -> { val n = c2.get(key, 3, out, 0); val s = stored[key]
                    if (n >= 0 && (s == null || t < s[0] || t >= s[1])) { violations++; if (first.isEmpty()) first = "get t=$t s=${s?.toList()}" }
                    if (n >= 0 && Packets.i32(out, o + 6) !in 0..120) { violations++; if (first.isEmpty()) first = "ttl=${Packets.i32(out, o + 6)}" } }
                2 -> { val n = c2.getStale(key, 3, out, 0); val s = stored[key]
                    if (n >= 0 && (s == null || t < s[1])) { violations++; if (first.isEmpty()) first = "stale t=$t s=${s?.toList()}" } }
                3 -> c2.prefetchDue(key)
                else -> t += rnd.nextInt(-300_000, 300_000).toLong()
            }
            if (c2.size() > 5 || c2.byteSize() != c2.size() * r.size) { violations++; if (first.isEmpty()) first = "sayaç size=${c2.size()} bayt=${c2.byteSize()}" }
        }
        T.check("30 000 işlem, saat ±5 dk sıçrıyor: süre dışı cevap yok, TTL 0..120, sayaçlar tutarlı", violations == 0, "$violations $first")
    }

    T.group("Sızma 23 / RollingCounter ve Immune: saat geri giderse pencere baştan kurulur, değerler negatif/şişkin olmaz")
    run {
        val rc = RollingCounter(60_000L, 1_000L)
        rc.record(1_000_000L, 100); rc.record(1_030_000L, 160)
        T.check("ileri akış: son pencerede 60 artış", rc.recent() == 60L, "${rc.recent()}")
        rc.record(10_000L, 200)                                   // saat dakikalarca geri
        T.check("saat geri: eski örnekler atılır (artış 0), negatif yok", rc.recent() == 0L, "${rc.recent()}")
        rc.record(20_000L, 230)
        T.check("yeni zaman çizgisinde pencere çalışır (30 artış)", rc.recent() == 30L, "${rc.recent()}")
        rc.record(1_000_000L, 300); rc.record(1_000_500L, 305)     // ileri sıçrama sonra geri küçük titreme
        rc.record(999_000L, 310)
        T.check("küçük geri titreme de güvenle işlenir (negatif yok)", rc.recent() >= 0L)

        val rnd = Random(2390)
        var neg = 0; var tt = 5_000_000L; var total = 0L
        val rc2 = RollingCounter(120_000L, 2_000L)
        repeat(50_000) {
            if (rnd.nextInt(8) == 0) tt += rnd.nextInt(-3_000_000, 3_000_000).toLong() else tt += rnd.nextInt(0, 4_000)
            total += rnd.nextInt(0, 50)
            if (rnd.nextInt(500) == 0) total = rnd.nextInt(0, 100).toLong()      // sayaç sıfırlanması
            rc2.record(tt, total)
            val v = rc2.recent()
            if (v < 0 || v > total) neg++
        }
        T.check("50 000 kayıt, saat ±50 dk sıçrıyor, sayaç sıfırlanıyor: değer hep 0..toplam", neg == 0, "ihlal=$neg")

        class NoExplore : Random() { override fun nextInt(bound: Int): Int = bound - 1 }
        val im = Immune(NoExplore())
        var crashed = ""
        var t2 = 100_000_000L
        try {
            repeat(3000) {
                t2 += if (rnd.nextInt(10) == 0) rnd.nextInt(-90_000_000, 5_000_000).toLong() else rnd.nextInt(0, 90_000).toLong()
                if (t2 < 1) t2 = 1
                if (rnd.nextBoolean()) im.report(Threat.values()[rnd.nextInt(Threat.values().size)], rnd.nextDouble() * 6, t2)
                else im.tick(t2)
            }
        } catch (e: Throwable) { crashed = e.toString() }
        T.check("Immune: 3000 rastgele rapor/tick, zaman geri-ileri sıçrıyor → istisna yok", crashed.isEmpty(), crashed)
        T.check("Immune: geri sarılma sonrası kendini toparlar (tick çalışır, kod döner)", im.tick(t2 + 60_000) != null)
    }

    // ---------------------------------------------------------------- 5. Disk dolu / izin hatası enjeksiyonu ve kalıcı özet denetimi
    T.group("Sızma 23 / ListStore.install: disk dolu, kısa yazım, yeniden adlandırma hatası her noktada — eski liste bozulmadan kalır")
    run {
        fun tmp(): File = java.nio.file.Files.createTempDirectory("sizma23io").toFile()
        val names = ListUpdate.UPDATABLE.toList()
        fun mk(tag: Int) = names.associateWith { ByteArray(2000) { tag.toByte() } }
        fun tagsOf(root: File): Set<Int> = names.map { n -> File(ListStore.dir(root), n).takeIf { it.isFile }?.readBytes()?.firstOrNull()?.toInt() ?: -1 }.toSet()
        fun allVerified(root: File) = names.all { ListStore.verified(root, it) }
        val total = names.size + 1                              // 3 liste + özet dosyası
        var bad = ""
        // Yazım hataları: k. yazımda "ENOSPC" istisnası / sessiz kısa yazım / hiç yazmama
        for (mode in 0 until 3) for (k in 0 until total) for (fresh in listOf(false, true)) {
            val root = tmp()
            if (!fresh) check(ListStore.install(root, mk(1)))
            var count = 0
            val io = ListStore.Io(write = { f, b ->
                if (count++ == k) when (mode) {
                    0 -> throw IOException("No space left on device")
                    1 -> f.writeBytes(b.copyOf(b.size / 2))                  // sessiz kısa yazım
                    else -> f.writeBytes(ByteArray(0))                       // sıfır bayt
                } else f.writeBytes(b)
            })
            val ok = ListStore.install(root, mk(2), io)
            val expect = if (fresh) emptySet<Int>() else setOf(1)
            val t = if (File(ListStore.dir(root), names[0]).exists()) tagsOf(root) else emptySet()
            val clean = !File(root, ListStore.STAGE).exists() && !File(root, ListStore.BACKUP).exists()
            if (ok || t != expect || !clean || (!fresh && !allVerified(root))) bad += " [mode=$mode k=$k fresh=$fresh ok=$ok t=$t clean=$clean]"
            // sonraki normal kurulum zehirlenmemiş olmalı
            if (!ListStore.install(root, mk(3)) || tagsOf(root) != setOf(3) || !allVerified(root)) bad += " [mode=$mode k=$k sonraki kurulum]"
            root.deleteRecursively()
        }
        T.check("3 hata türü × 4 yazım noktası × (yeni/güncelleme): kurulum false, eski sürüm sağlam ve doğrulanır, artık yok, sonraki kurulum çalışır", bad.isEmpty(), bad.take(400))

        // Yeniden adlandırma hataları: 1. (kurulu→yedek), 2. (yeni→kurulu) çağrıda false ya da istisna
        var bad2 = ""
        for (failAt in 0..1) for (throwing in listOf(false, true)) {
            val root = tmp(); check(ListStore.install(root, mk(1)))
            var c = 0
            val io = ListStore.Io(rename = { a, b -> if (c++ == failAt) { if (throwing) throw SecurityException("izin yok") else false } else a.renameTo(b) })
            val ok = ListStore.install(root, mk(2), io)
            val clean = !File(root, ListStore.STAGE).exists() && !File(root, ListStore.BACKUP).exists()
            if (ok || tagsOf(root) != setOf(1) || !clean || !allVerified(root)) bad2 += " [failAt=$failAt throwing=$throwing ok=$ok t=${tagsOf(root)} clean=$clean]"
            root.deleteRecursively()
        }
        T.check("yeniden adlandırma 1./2. adımda false ya da istisna: eski sürüm geri gelir, doğrulanır, artık yok", bad2.isEmpty(), bad2)
        val root = tmp()
        T.check("başarılı kurulum: özet dosyası dizinde ve üç liste doğrulanır", ListStore.install(root, mk(7)) && File(ListStore.dir(root), ListStore.DIGESTS).isFile && allVerified(root))
        root.deleteRecursively()
    }

    T.group("Sızma 23 / Kalıcı özet denetimi: diskte sessizce bozulan (bit çürümesi) liste dosyası motora verilmez")
    run {
        fun tmp(): File = java.nio.file.Files.createTempDirectory("sizma23dg").toFile()
        val names = ListUpdate.UPDATABLE.toList()
        val rnd = Random(2400)
        fun data() = names.associateWith { n -> ByteArray(5000).also { rnd.nextBytes(it) } }
        fun fresh(): File = tmp().also { check(ListStore.install(it, data())) }
        fun f(root: File, n: String) = File(ListStore.dir(root), n)
        var bad = ""
        fun case(label: String, mutate: (File) -> Unit, affected: Set<String>) {
            val root = fresh(); mutate(root)
            for (n in names) {
                val v = ListStore.verified(root, n)
                val want = n !in affected
                if (v != want) bad += " [$label/$n v=$v]"
            }
            root.deleteRecursively()
        }
        case("bit çevirme", { r -> val b = f(r, names[0]).readBytes(); b[2500] = (b[2500].toInt() xor 1).toByte(); f(r, names[0]).writeBytes(b) }, setOf(names[0]))
        case("bir bayt kısa", { r -> val b = f(r, names[1]).readBytes(); f(r, names[1]).writeBytes(b.copyOf(b.size - 1)) }, setOf(names[1]))
        case("bir bayt fazla", { r -> f(r, names[2]).appendBytes(byteArrayOf(0)) }, setOf(names[2]))
        case("sıfırlanmış", { r -> f(r, names[0]).writeBytes(ByteArray(5000)) }, setOf(names[0]))
        case("sıfır uzunluk", { r -> f(r, names[1]).writeBytes(ByteArray(0)) }, setOf(names[1]))
        case("silinmiş", { r -> f(r, names[2]).delete() }, setOf(names[2]))
        case("özet dosyası yok (eski sürüm önbelleği)", { r -> f(r, ListStore.DIGESTS).delete() }, names.toSet())
        case("özet dosyası boş", { r -> f(r, ListStore.DIGESTS).writeBytes(ByteArray(0)) }, names.toSet())
        case("özet dosyası devasa", { r -> f(r, ListStore.DIGESTS).writeBytes(ByteArray(10_000) { 'a'.code.toByte() }) }, names.toSet())
        case("özet dosyası geçerli ama şişirilmiş (>4 KB)", { r -> f(r, ListStore.DIGESTS).appendText("x\n".repeat(3000)) }, names.toSet())
        case("özet başlığı yanlış", { r -> f(r, ListStore.DIGESTS).let { it.writeText(it.readText().replace("OZET 1", "OZET 2")) } }, names.toSet())
        case("özet hex'i bozuk", { r -> f(r, ListStore.DIGESTS).let { d -> val t = d.readText(); val i = t.indexOf(names[0]) + names[0].length + 1; d.writeText(t.substring(0, i) + (if (t[i] == '0') '1' else '0') + t.substring(i + 1)) } }, setOf(names[0]))
        case("özetteki boy yanlış", { r -> f(r, ListStore.DIGESTS).let { d -> d.writeText(d.readText().replace(Regex("${names[1]} ([0-9a-f]{64}) 5000"), "${names[1]} $1 4999")) } }, setOf(names[1]))
        case("özetten bir satır eksik", { r -> f(r, ListStore.DIGESTS).let { d -> d.writeText(d.readLines().filterNot { it.startsWith(names[2]) }.joinToString("\n") + "\n") } }, setOf(names[2]))
        case("özet dosyası çöp", { r -> f(r, ListStore.DIGESTS).writeBytes(ByteArray(300) { rnd.nextInt().toByte() }) }, names.toSet())
        case("dosya yerine dizin", { r -> f(r, names[0]).delete(); f(r, names[0]).mkdirs() }, setOf(names[0]))
        case("hiçbiri bozuk değil", { }, emptySet())
        T.check("16 bozulma biçimi: yalnızca etkilenen dosya reddedilir, diğerleri doğrulanır", bad.isEmpty(), bad.take(400))

        // 600 rastgele tek bit çevirme: hiçbiri sessizce geçmez
        var passed = 0
        repeat(600) {
            val root = fresh()
            val n = names[rnd.nextInt(names.size)]
            val b = f(root, n).readBytes(); val bit = rnd.nextInt(b.size * 8)
            b[bit / 8] = (b[bit / 8].toInt() xor (1 shl (bit % 8))).toByte(); f(root, n).writeBytes(b)
            if (ListStore.verified(root, n)) passed++
            root.deleteRecursively()
        }
        T.check("600 rastgele tek bit çevirme: hiçbiri doğrulamayı geçmez", passed == 0, "geçen=$passed")

        // Bellek önbelleği: doğrulanmış dosya sonradan değişirse (boy aynı, zaman farklı) yeniden özetlenir
        run {
            val r = fresh()
            val ok1 = ListStore.verified(r, names[0])
            val b = f(r, names[0]).readBytes(); b[10] = (b[10].toInt() xor 4).toByte()
            f(r, names[0]).writeBytes(b); f(r, names[0]).setLastModified(f(r, names[0]).lastModified() + 5000)
            T.check("doğrulanıp sonra değişen dosya (aynı boy, yeni zaman) yeniden denetlenir ve reddedilir", ok1 && !ListStore.verified(r, names[0]))
            r.deleteRecursively()
        }
        // Yeni sürüm kurulunca sonuç yenilenir; güncellenemeyen ad ve olmayan dosya false
        val root = fresh()
        check(names.all { ListStore.verified(root, it) })
        check(ListStore.install(root, data()))
        T.check("yeni sürüm kurulunca doğrulama yeni dosyalar için geçer", names.all { ListStore.verified(root, it) })
        T.check("güncellenemeyen ad (psl.txt, ../x) ve olmayan dosya doğrulanmaz", !ListStore.verified(root, "psl.txt") && !ListStore.verified(root, "../x") && !ListStore.verified(File(root, "yok"), names[0]))
        root.deleteRecursively()
    }

    T.group("Sızma 23 / Uçtan uca: yapısı geçerli ama içeriği sessizce bozulan liste — özet denetimi paket listesine düşürür")
    run {
        val assets = File("app/src/main/assets/filter")
        val packaged = FilterSource { name -> File(assets, name).inputStream() }
        val probes = listOf("doubleclick.net", "googlesyndication.com", "adnxs.com", "criteo.com")
        val files = ListUpdate.UPDATABLE.associateWith { File(assets, it).readBytes() }
        val root = java.nio.file.Files.createTempDirectory("sizma23e2e").toFile()
        val rnd = Random(2410)
        try {
            check(ListStore.install(root, files))
            // Gövdede, okunduğunda HÂLÂ geçerli kalan ama içeriği değiştiren bir bit bul (özet denetimi olmadan fark edilmez)
            val orig = files["basic.bin"]!!
            val origTier = FilterTier.read(ByteArrayInputStream(orig))
            var pos = -1
            for (i in 0 until 500) {
                val p = 20 + rnd.nextInt(orig.size - 40)
                val m = orig.copyOf(); m[p] = (m[p].toInt() xor 1).toByte()
                val (err, t) = tryRead(m)
                if (err == null && t != null && !t.hashes.contentEquals(origTier.hashes)) { pos = p; break }
            }
            T.check("deney düzeneği: yapısı geçerli kalan, içeriği değişen bir bozulma bulundu", pos > 0, "pos=$pos")
            val sm = orig.copyOf(); sm[pos] = (sm[pos].toInt() xor 1).toByte()
            File(ListStore.dir(root), "basic.bin").writeBytes(sm)
            T.check("okuyucu bu bozuk dosyayı hata vermeden kabul ediyor (özetsiz savunma yetmez)", tryRead(sm).first == null)
            T.check("ama özet denetimi onu reddeder", !ListStore.verified(root, "basic.bin") && ListStore.verified(root, "medium.bin"))

            val guarded = FilterSource { n ->
                if (n in ListUpdate.UPDATABLE && ListStore.verified(root, n)) File(ListStore.dir(root), n).inputStream() else File(assets, n).inputStream()
            }
            FilterRuntime.reset()
            FilterRuntime.fallbackSource = packaged
            FilterRuntime.source = packaged
            FilterRuntime.updateNow(FilterLevel.BASIC, emptyList(), emptyList())
            val healthy = probes.map { FilterRuntime.engine!!.verdictOf(it) }
            FilterRuntime.source = guarded
            FilterRuntime.reloadListsNow()
            T.check("özet denetimli kaynakla kararlar paketle birebir aynı", FilterRuntime.engine?.let { e -> probes.map { e.verdictOf(it) } } == healthy && FilterRuntime.listsLive())
        } finally {
            FilterRuntime.reset()
            FilterRuntime.fallbackSource = null
            FilterRuntime.source = packaged
            FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), emptyList())
            root.deleteRecursively()
        }
    }
}
