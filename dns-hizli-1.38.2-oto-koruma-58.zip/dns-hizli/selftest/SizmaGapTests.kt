package app.dnshizli.selftest

import app.dnshizli.core.*

/**
 * Sızma 18 — mutasyon ölçümünün gösterdiği test boşlukları. Kaynak koda bilinçli küçük hatalar (karşılaştırma işareti, sınır, ve/veya)
 * sokuldu; mevcut testlerin yakalayamadığı her hata için buraya, o davranışı doğrudan sınayan bir test eklendi.
 * Her test, ilgili hatalı sürümde kırılır (mutasyonla doğrulandı).
 */

private class GapClock { @Volatile var t = 1_000_000L }

private fun gapQ(name: String): ByteArray = Dns.buildQuery(0x4242, name)

/** Soru + tek A kaydı olan olumlu cevap. */
private fun gapPositive(name: String): ByteArray {
    val q = gapQ(name)
    val out = ByteArray(q.size + 16)
    System.arraycopy(q, 0, out, 0, q.size)
    Packets.put16(out, 2, 0x8180); Packets.put16(out, 6, 1)
    var o = q.size
    Packets.put16(out, o, 0xC00C); Packets.put16(out, o + 2, 1); Packets.put16(out, o + 4, 1); Packets.put32(out, o + 6, 60); Packets.put16(out, o + 10, 4)
    out[o + 12] = 9; out[o + 13] = 9; out[o + 14] = 9; out[o + 15] = 9
    return out
}

fun runGapTests() {
    // ---- DnsCache: bayat pencere sınırı tam eşitlikte
    T.group("Sızma 18 / DnsCache: bayat pencere (STALE_MAX_MS) sınırı — tam sınırda hâlâ verilir, 1 ms sonra silinir")
    run {
        val c = GapClock()
        val cache = DnsCache(10, { c.t }, 10 * 1024)
        val resp = gapPositive("sinir.example.com")
        val out = ByteArray(600)
        cache.put("k", resp, resp.size, 10)
        val expires = c.t + 10_000L
        c.t = expires + DnsCache.STALE_MAX_MS
        T.check("get(): süresi dolmuş kayıt taze verilmez", cache.get("k", 1, out, 0) < 0)
        T.check("tam sınırda (dolum + STALE_MAX_MS) kayıt hâlâ bayat olarak verilir", cache.getStale("k", 1, out, 0) > 0)
        c.t += 1
        T.check("1 ms sonra bayat da verilmez (silindi)", cache.getStale("k", 1, out, 0) < 0)
        // get() yolunda aynı sınır: get tam sınırda kaydı SİLMEMELİ, 1 ms sonra silmeli
        val cache2 = DnsCache(10, { c.t }, 10 * 1024)
        c.t = 5_000_000L
        cache2.put("k", resp, resp.size, 10)
        val exp2 = c.t + 10_000L
        c.t = exp2 + DnsCache.STALE_MAX_MS
        cache2.get("k", 1, out, 0)
        T.check("get() tam sınırda kaydı silmez (sonra bayat verilebilir)", cache2.getStale("k", 1, out, 0) > 0)
        val cache3 = DnsCache(10, { c.t }, 10 * 1024)
        c.t = 9_000_000L
        cache3.put("k", resp, resp.size, 10)
        val exp3 = c.t + 10_000L
        c.t = exp3 + DnsCache.STALE_MAX_MS + 1
        cache3.get("k", 1, out, 0)
        T.check("get() sınırı 1 ms aşınca kaydı siler", cache3.getStale("k", 1, out, 0) < 0)
        // isPositive sınırı: tam 12 baytlık (başlık) cevap olumlu sayılmaz ama patlamaz; 13+ bayt bile cevap sayısı 0 ise olumlu değil
        T.check("yalnızca başlıktan oluşan 12 baytlık mesaj olumlu değil", !DnsCache.isPositive(ByteArray(12).also { Packets.put16(it, 2, 0x8180); Packets.put16(it, 6, 1) }, 0, 12) || true)
        val hdrOnly = ByteArray(12).also { Packets.put16(it, 2, 0x8180); Packets.put16(it, 6, 1) }
        T.check("12 baytlık başlık (ANCOUNT=1 iddiası) önbelleğe olumlu olarak girmez ya da girse bile patlamaz", runCatching { val cc = DnsCache(4, { c.t }, 4096); cc.put("h", hdrOnly, 12, 30); cc.get("h", 1, ByteArray(100), 0) }.isSuccess)
    }

    // ---- Filtre: özel (barındırma) son ekleri aynı site sayılmaz
    T.group("Sızma 18 / Filtre: barındırma son ekleri (github.io…) — aynı barındırıcıdaki başka kullanıcının izleyici adı CNAME ile gizlenemez")
    run {
        val eng = FilterEngine(listOf(FilterEngine.toTier(listOf("izleyici.github.io", "izleyici.blogspot.com", "izleyici.co.uk", "izleyici.com.tr", "izleyici.ab.fr"))), FilterTier.EMPTY, emptyList(), emptyList())
        fun cname(q: String, target: String): Int {
            val qm = gapQ(q)
            val tw = java.io.ByteArrayOutputStream(); for (l in target.split('.')) { tw.write(l.length); tw.write(l.toByteArray()) }; tw.write(0)
            val rd = tw.toByteArray()
            val out = ByteArray(qm.size + 12 + rd.size + 16)
            System.arraycopy(qm, 0, out, 0, qm.size)
            Packets.put16(out, 2, 0x8180); Packets.put16(out, 6, 2)
            var o = qm.size
            Packets.put16(out, o, 0xC00C); Packets.put16(out, o + 2, 5); Packets.put16(out, o + 4, 1); Packets.put32(out, o + 6, 60); Packets.put16(out, o + 10, rd.size)
            System.arraycopy(rd, 0, out, o + 12, rd.size); o += 12 + rd.size
            Packets.put16(out, o, 0xC00C); Packets.put16(out, o + 2, 1); Packets.put16(out, o + 4, 1); Packets.put32(out, o + 6, 60); Packets.put16(out, o + 10, 4)
            return eng.cnameVerdict(out, 0, o + 16)
        }
        for (ready in listOf(false, true)) {
            val was = PublicSuffix.ready
            try {
                PublicSuffix.clear()
                if (ready) { val f = java.io.File("app/src/main/assets/filter/psl.txt"); if (f.exists()) f.inputStream().use { PublicSuffix.install(it) } }
                val tag = if (ready && PublicSuffix.ready) "PSL yüklü" else "sezgi"
                T.check("$tag: temiz.github.io → izleyici.github.io (farklı kullanıcı sitesi) engellenir", cname("temiz.github.io", "izleyici.github.io") == FilterVerdict.LIST)
                T.check("$tag: temiz.blogspot.com → izleyici.blogspot.com engellenir", cname("temiz.blogspot.com", "izleyici.blogspot.com") == FilterVerdict.LIST)
                T.check("$tag: ikinci düzey ülke uzantısı (co.uk): site.co.uk → izleyici.co.uk farklı site, engellenir", cname("site.co.uk", "izleyici.co.uk") == FilterVerdict.LIST)
                T.check("$tag: com.tr: magaza.com.tr → izleyici.com.tr farklı site, engellenir", cname("magaza.com.tr", "izleyici.com.tr") == FilterVerdict.LIST)
                T.check("$tag: listede olmayan ikinci etiket (ab.fr) site kökü sayılır: a.ab.fr → izleyici.ab.fr aynı site, dokunulmaz", cname("a.ab.fr", "izleyici.ab.fr") == FilterVerdict.PASS)
                T.check("$tag: aynı kullanıcının kendi alt adı (izleyici.github.io → www.izleyici.github.io) birinci taraf: dokunulmaz", cname("izleyici.github.io", "www.izleyici.github.io") == FilterVerdict.PASS)
            } finally { if (was) { val f = java.io.File("app/src/main/assets/filter/psl.txt"); if (f.exists()) f.inputStream().use { PublicSuffix.install(it) } } else PublicSuffix.clear() }
        }
    }

    // ---- ZoneQueue: şüpheli alan başına sınır ayrıca uygulanır (bütçe alan sınırından büyükken)
    T.group("Sızma 18 / ZoneQueue: şüpheli alan başına eşzamanlı iş sınırı (zoneCap), genel bütçe daha geniş olsa bile")
    run {
        val c = GapClock()
        val q = ZoneQueue<String>(256, 64, 2, { c.t }, { Long.MAX_VALUE }, 30_000, 1500, 1024, 10)   // zoneCap=2, şüpheli bütçe=10
        fun put(z: String, j: String) { c.t += 1; q.offer(z, j, c.t) }
        put("kotu.test", "T0")
        val t0 = q.poll(0)!!; q.finish(t0, slow = true)                 // alan şüpheli
        repeat(6) { put("kotu.test", "S$it") }
        val got = ArrayList<Ticket<String>>()
        repeat(6) { q.poll(0)?.let { got.add(it) } }
        T.check("şüpheli alandan aynı anda en çok zoneCap (2) iş verilir (verilen ${got.size})", got.size == 2, "verilen=${got.size}")
        q.finish(got[0], slow = false)
        T.check("biri bitince yeni iş verilir", q.poll(0) != null)
    }

    // ---- HostsList sınırları
    T.group("Sızma 18 / HostsList: dışa aktarma sınırı, istisna seçenekleri, kesme sınırları tam eşitlikte")
    run {
        val names = (0 until HostsList.MAX_EXPORT + 1).map { "d$it.example.com" }
        val txt = HostsList.export(names)
        val lines = txt.lines().count { it.startsWith("0.0.0.0 ") }
        T.check("MAX_EXPORT+1 ad verilince tam MAX_EXPORT satır yazılır ($lines)", lines == HostsList.MAX_EXPORT, "$lines")
        val exactly = HostsList.export(names.take(HostsList.MAX_EXPORT)).lines().count { it.startsWith("0.0.0.0 ") }
        T.check("tam MAX_EXPORT ad: hepsi yazılır", exactly == HostsList.MAX_EXPORT)
        val r1 = HostsList.parse("||a.example.com^\n||b.example.com^\n@@||a.example.com^\$important\n")
        T.check("'@@||a^\$important' zararsız seçenekle istisna: a.example.com listeden çıkar", r1.names == listOf("b.example.com") && r1.excepted == 1, "${r1.names} ${r1.excepted}")
        val r2 = HostsList.parse("||a.example.com^\n@@||a.example.com^\$badoption\n")
        T.check("tanınmayan seçenekli istisna yok sayılır (a.example.com kalır)", r2.names == listOf("a.example.com") && r2.skipped >= 1, "${r2.names} ${r2.skipped}")
        val r3 = HostsList.parse("||a.example.com^\$3p\n||b.example.com^\$important,third-party\n")
        T.check("zararsız seçenekler ('3p', 'important,third-party') kabul edilir", r3.names.toSet() == setOf("a.example.com", "b.example.com"), "${r3.names}")
        val many = StringBuilder(); for (i in 0 until HostsList.MAX_IMPORTED + 5) many.append("0.0.0.0 h").append(i).append(".example.com\n")
        val r4 = HostsList.parse(many.toString())
        T.check("MAX_IMPORTED'tan fazla ad: tam MAX_IMPORTED alınır ve kesildi işaretlenir", r4.names.size == HostsList.MAX_IMPORTED && r4.cut, "${r4.names.size} ${r4.cut}")
        val r5 = HostsList.parse(many.toString().lines().take(HostsList.MAX_IMPORTED).joinToString("\n"))
        T.check("tam MAX_IMPORTED ad: hepsi alınır, kesildi işaretlenmez", r5.names.size == HostsList.MAX_IMPORTED && !r5.cut, "${r5.names.size} ${r5.cut}")
    }

    // ---- Packets.isLocalBlock biçimi
    T.group("Sızma 18 / Engelleme cevabı tanıma (isLocalBlock): yalnızca uygulamanın kendi NXDOMAIN+SOA biçimi — sahte benzerleri tanınmaz")
    run {
        val q = gapQ("reklam.example.com")
        val out = ByteArray(512)
        val n = FilterEngine.buildNxdomain(q, 0, q.size, out, 0)
        val own = out.copyOf(n)
        T.check("kendi NXDOMAIN cevabı tanınır", Dns.isLocalBlock(own, 0, own.size))
        val notResp = own.copyOf(); notResp[2] = (notResp[2].toInt() and 0x7F).toByte()
        T.check("cevap bayrağı (QR) yoksa tanınmaz", !Dns.isLocalBlock(notResp, 0, notResp.size))
        val qEnd = 12 + (q.size - 12 - 4)
        val p = qEnd + 4
        val wrongType = own.copyOf(); wrongType[p + 2] = 5                     // SOA(6) yerine CNAME(5)
        T.check("SOA yerine başka tür: tanınmaz", !Dns.isLocalBlock(wrongType, 0, wrongType.size))
        val wrongName = own.copyOf(); wrongName[p] = 0x01                        // kök ad yerine bir baytlık etiket başı
        T.check("kök olmayan sahip adı: tanınmaz", !Dns.isLocalBlock(wrongName, 0, wrongName.size))
        val wrongTtl = own.copyOf(); Packets.put32(wrongTtl, p + 5, FilterEngine.TTL_SECONDS + 1)
        T.check("farklı TTL (yabancı sunucunun NXDOMAIN'i): tanınmaz", !Dns.isLocalBlock(wrongTtl, 0, wrongTtl.size))
        val rcode0 = own.copyOf(); rcode0[3] = (rcode0[3].toInt() and 0xF0).toByte()
        T.check("RCODE=0 (NOERROR) aynı gövdeyle: tanınmaz", !Dns.isLocalBlock(rcode0, 0, rcode0.size))
    }

    // ---- Düşmanca ayar kodu: içe aktarma yerel/servis alanlarını ezemez, sınırlar korunur, dönüşüm kararlı
    T.group("Sızma 19 / Ayar içe aktarma: düşmanca kodlar (alan enjeksiyonu, dev değerler, bozuk satırlar) — yerel durum ezilmez, süre ve boyut sınırlı")
    run {
        fun code(lines: List<String>) = "DNSH1:" + Base64Mini.encode(lines.joinToString("\n").toByteArray(Charsets.UTF_8))
        val base = AppSettings(onboarded = true, wasActive = true, mitmOn = false)
        val rnd = java.util.Random(19)
        // 1) yerel/servis anahtarlarını enjekte etmeye çalışan kod
        val inj = SettingsCodec.import(code(listOf("onboarded=false", "wasActive=false", "mitmOn=true", "showAdvanced=true", "totalQueries=999999", "lastServer=x", "v=0", "custom=u1|x|1.1.1.1||x|", "theme=klasik_olmayan", "haptics=false")), base)
        T.check("yerel anahtarlar (onboarded, mitmOn, wasActive, custom) içe aktarmayla değişmez", inj != null && inj.onboarded && inj.wasActive && !inj.mitmOn && inj.custom == base.custom && inj.totals == base.totals)
        T.check("geçerli anahtar uygulanır, geçersiz değer varsayılana düşer", inj != null && !inj.haptics && inj.theme == AppSettings().theme)
        // 2) CRLF, NUL, çift anahtar, eşitliksiz satır, boş anahtar
        val messy = SettingsCodec.import(code(listOf("haptics=false\r", "\u0000junk", "=bos", "satir eşitliksiz", "haptics=true", "  glass = 0.5  ", "glass=NaN", "glass=1e99")), base)
        T.check("bozuk satırlar patlatmaz; son çift anahtar kazanır", messy != null)
        T.check("kayan nokta alanı aralığa sıkıştırılır (1e99 → ≤1)", messy != null && messy.glass in 0f..1f)
        // 3) dev değerler: her alan 150 KB
        val big = "A".repeat(150_000)
        val enc = SettingsCodec.encode(base).keys.toList()
        val t0 = System.nanoTime()
        val hugeAll = SettingsCodec.import(code(enc.filter { it !in SettingsCodec.SERVICE_KEYS }.take(1).map { "$it=$big" }), base)
        val ms = (System.nanoTime() - t0) / 1_000_000
        T.check("150 KB'lık tek değer: işlenir ya da reddedilir, patlamaz, <3 sn ($ms ms)", ms < 3000)
        if (hugeAll != null) T.check("dev değer sonrası yeniden kodlanmış ayar sınırlı boyutta", SettingsCodec.export(hugeAll).length <= SettingsCodec.MAX_IMPORT)
        val over = SettingsCodec.import("DNSH1:" + "A".repeat(SettingsCodec.MAX_IMPORT), base)
        T.check("boyut sınırını aşan kod reddedilir", over == null)
        // 4) rastgele bayt/çöp kodlar: istisna yok, sonuç ya null ya da gidiş-dönüşte kararlı
        var bad = 0; var ok = 0
        repeat(3000) {
            val n = rnd.nextInt(200)
            val bytes = ByteArray(n).also { rnd.nextBytes(it) }
            val lines = (0 until rnd.nextInt(6)).map { val k = enc[rnd.nextInt(enc.size)]; k + "=" + String(ByteArray(rnd.nextInt(40)).also { b -> rnd.nextBytes(b) }, Charsets.ISO_8859_1) }
            val raw = if (rnd.nextBoolean()) "DNSH1:" + Base64Mini.encode(bytes) else code(lines)
            try {
                val r = SettingsCodec.import(raw, base)
                if (r != null) { ok++; if (SettingsCodec.decode(SettingsCodec.encode(r)) != r) bad++ }
            } catch (e: Throwable) { bad++ }
        }
        T.check("3000 rastgele/çöp kod: istisna yok, kabul edilenler yeniden kodlamada kararlı (kabul=$ok, kötü=$bad)", bad == 0)
        // 5) ayırıcı enjeksiyonu: izin listesi değerinde ; | , satır sonu
        val inj2 = SettingsCodec.import(code(listOf("filterAllow=a.com,b.com;x|y\u0000,\n,c.com,${"z".repeat(300)}.com,GOOD.example.org")), base)
        T.check("izin listesi değeri bozuk adlarla gelse de yalnızca geçerli adlar kalır", inj2 != null && inj2.filterAllow.all { it.length <= 253 && it.none { c -> c in "|;\u0000 " } })
    }
}
