package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.Random
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Test için JDK AES-GCM ile çalışan sarmalayıcı (Android'de aynı arayüzü Keystore uygular). */
private class JdkWrapper(keyByte: Int, private val failWrap: Boolean = false) : KeyWrapper {
    private val key = SecretKeySpec(ByteArray(32) { keyByte.toByte() }, "AES")
    private val rnd = Random(keyByte.toLong())
    override fun wrap(plain: ByteArray): ByteArray? {
        if (failWrap) return null
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return iv + c.doFinal(plain)
    }
    override fun unwrap(blob: ByteArray): ByteArray? = try {
        if (blob.size < 12 + 16) null else {
            val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, blob, 0, 12))
            c.doFinal(blob, 12, blob.size - 12)
        }
    } catch (_: Exception) { null }
}

/**
 * Sızma 21 — platform sınırındaki mantık: CA anahtarı sarma (KeyVault) ve platform bileşenlerinin karar kuralları
 * (BootPolicy, IntentPolicy). Android kodu yerelde derlenemediği için bu kurallar core'a alındı ve burada sınanır.
 */
internal fun runPlatformLogicTests() {
    // ---------------------------------------------------------------- KeyVault
    T.group("Sızma 21 / KeyVault: CA özel anahtarı sarılı saklanır; kurcalama, yanlış anahtar, kesik dosya, eski düz dosya göçü, sarma başarısızlığı")
    run {
        val ca = MitmCa.generate(null)
        val plain = ca.keyBytes()
        val w = JdkWrapper(7)
        val stored = KeyVault.store(plain, w)
        T.check("saklanan içerik düz anahtarı içermez (sarılı, DHK1 başlıklı)", KeyVault.isSealed(stored) && stored.size > plain.size && indexOf(stored, plain.copyOfRange(0, 24)) < 0)
        val back = KeyVault.load(stored, w)
        T.check("sarılı dosya geri açılır, yeniden yazma gerekmez", back.plain != null && back.plain!!.contentEquals(plain) && back.rewrite == null)
        T.check("açılan anahtarla CA yüklenir ve aynı sertifikayı verir", MitmCa.load(back.plain!!, ca.certDer(), ca.interDer())?.certDer()?.contentEquals(ca.certDer()) == true)
        T.check("aynı anahtar iki kez sarılınca farklı çıktı (rastgele IV)", !KeyVault.store(plain, w).contentEquals(KeyVault.store(plain, w)))
        // saldırılar
        var tamperOk = 0
        val rnd = Random(2101)
        repeat(300) {
            val t = stored.copyOf(); val i = 4 + rnd.nextInt(t.size - 4); t[i] = (t[i].toInt() xor (1 shl rnd.nextInt(8))).toByte()
            if (KeyVault.load(t, w).plain != null) tamperOk++
        }
        T.check("300 rastgele bit çevirme: hiçbiri kabul edilmez (GCM etiketi)", tamperOk == 0, "kabul=$tamperOk")
        T.check("yanlış Keystore anahtarı: açılmaz (CA yeniden üretilir)", KeyVault.load(stored, JdkWrapper(8)).plain == null)
        var trunc = 0
        for (n in 0 until stored.size step 7) if (KeyVault.load(stored.copyOf(n), w).plain != null) trunc++
        T.check("kesik dosya (her boyutta): kabul edilmez, istisna yok", trunc == 0)
        T.check("boş dosya ve çöp: anahtar yok", KeyVault.load(ByteArray(0), w).plain == null && KeyVault.load(ByteArray(64) { 0x41 }, w).plain == null)
        // eski düz dosya göçü
        val mig = KeyVault.load(plain, w)
        T.check("eski düz PKCS#8 dosyası okunur ve sarılı biçime çevirmek üzere 'rewrite' verilir", mig.plain!!.contentEquals(plain) && mig.rewrite != null && KeyVault.isSealed(mig.rewrite!!))
        T.check("göç çıktısı sonraki okumada açılır", KeyVault.load(mig.rewrite!!, w).plain!!.contentEquals(plain))
        // sarma çalışmıyorsa özellik bozulmaz
        val bad = JdkWrapper(7, failWrap = true)
        T.check("sarma başarısızsa düz yazılır (eski davranış), okunur", KeyVault.store(plain, bad).contentEquals(plain) && KeyVault.load(plain, bad).plain!!.contentEquals(plain) && KeyVault.load(plain, bad).rewrite == null)
        val thrower = object : KeyWrapper { override fun wrap(plain: ByteArray): ByteArray? = throw IllegalStateException("x"); override fun unwrap(blob: ByteArray): ByteArray? = throw IllegalStateException("y") }
        T.check("sarmalayıcı istisna fırlatsa da çökmez", runCatching { KeyVault.store(plain, thrower); KeyVault.load(stored, thrower); KeyVault.load(plain, thrower) }.isSuccess && KeyVault.load(stored, thrower).plain == null)
    }

    // ---------------------------------------------------------------- BootPolicy
    T.group("Sızma 21 / BootPolicy: açılış alıcısı kararı — eski satır-satır mantıkla 200 bin rastgele durumda aynı; QUICKBOOT sahteciliği")
    run {
        // Eski BootReceiver mantığının birebir kopyası (kâhin)
        fun old(action: String?, uptime: Long, cob: Boolean, was: Boolean, onb: Boolean, ready: Boolean, paused: Long, now: Long): BootPolicy.Act {
            action ?: return BootPolicy.Act.NONE
            val justBooted = uptime < 10 * 60_000L
            val boot = action == "android.intent.action.BOOT_COMPLETED" || (action == "android.intent.action.QUICKBOOT_POWERON" && justBooted)
            if (action == "android.intent.action.QUICKBOOT_POWERON" && !justBooted) return BootPolicy.Act.NONE
            if (paused > 0L && (boot || action == "android.intent.action.MY_PACKAGE_REPLACED")) {
                if (!ready || !onb) return BootPolicy.Act.CLEAR_PAUSE
                val left = paused - now
                return if (left <= 0L || left > 24L * 60 * 60_000L) BootPolicy.Act.RESUME_NOW else BootPolicy.Act.SCHEDULE_ALARM
            }
            val wanted = when { boot -> cob; action == "android.intent.action.MY_PACKAGE_REPLACED" -> was; else -> false }
            return if (!wanted || !onb || !ready) BootPolicy.Act.NONE else BootPolicy.Act.CONNECT
        }
        val rnd = Random(2102); var diff = 0; var first = ""
        val actions = listOf(null, BootPolicy.BOOT_COMPLETED, BootPolicy.QUICKBOOT, BootPolicy.PACKAGE_REPLACED, "android.intent.action.USER_PRESENT", "app.baska.SAHTE", "")
        repeat(200_000) {
            val a = actions[rnd.nextInt(actions.size)]
            val up = when (rnd.nextInt(4)) { 0 -> 0L; 1 -> BootPolicy.BOOT_WINDOW_MS + rnd.nextInt(-2, 3); 2 -> rnd.nextInt(2_000_000).toLong(); else -> rnd.nextLong().ushr(20) }
            val now = 1_700_000_000_000L + rnd.nextInt(1_000_000)
            val paused = when (rnd.nextInt(5)) { 0 -> 0L; 1 -> now + rnd.nextInt(-5, 5); 2 -> now + 24L * 60 * 60_000L + rnd.nextInt(-2, 3); 3 -> now + rnd.nextInt(100_000_000); else -> rnd.nextInt(10).toLong() }
            val cob = rnd.nextBoolean(); val was = rnd.nextBoolean(); val onb = rnd.nextBoolean(); val rd = rnd.nextBoolean()
            val e = old(a, up, cob, was, onb, rd, paused, now); val g = BootPolicy.decide(a, up, cob, was, onb, rd, paused, now)
            if (e != g) { diff++; if (first.isEmpty()) first = "$a up=$up paused=$paused → eski=$e yeni=$g" }
        }
        T.check("200 bin durumda eski mantıkla birebir aynı", diff == 0, "fark=$diff $first")
        val now = 1_700_000_000_000L
        T.check("sahte QUICKBOOT (açılıştan 1 saat sonra) hiçbir şey yapmaz, duraklatmaya da dokunmaz", BootPolicy.decide(BootPolicy.QUICKBOOT, 3_600_000, true, true, true, true, now + 1000, now) == BootPolicy.Act.NONE)
        T.check("yabancı eylem adı asla bağlanmaz", listOf("app.baska.SAHTE", "android.intent.action.USER_PRESENT", "").all { BootPolicy.decide(it, 0, true, true, true, true, 0, now) == BootPolicy.Act.NONE })
        T.check("duraklatma 24 saati aşıyorsa (saat sıfırlanmış) alarm kurulmaz, devam edilir", BootPolicy.decide(BootPolicy.BOOT_COMPLETED, 1000, true, false, true, true, now + 30L * 3600_000, now) == BootPolicy.Act.RESUME_NOW)
        T.check("izin yoksa duraklatma silinir, bağlanılmaz", BootPolicy.decide(BootPolicy.BOOT_COMPLETED, 1000, true, true, true, false, now + 60_000, now) == BootPolicy.Act.CLEAR_PAUSE)
    }

    // ---------------------------------------------------------------- IntentPolicy
    T.group("Sızma 21 / IntentPolicy: güvenilmeyen (dışarıdan gelen) niyet sunucu seçemez, duraklatamaz, bağlantıyı doğrudan kesemez — tüm girdi birleşimleri taranır")
    run {
        val known = setOf("a", "b")
        var violations = 0; var combos = 0; var first = ""
        for (kind in IntentPolicy.Kind.values()) for (trusted in listOf(false, true)) for (extra in listOf(null, "a", "b", "zz", "")) for (min in listOf(Int.MIN_VALUE, -5, 0, 1, 15, 1440, 1441, Int.MAX_VALUE))
            for (running in listOf(false, true)) for (active in listOf(false, true)) for (cid in listOf(null, "a", "b")) for (ac in listOf(false, true)) for (onb in listOf(false, true)) {
                combos++
                val p = IntentPolicy.plan(kind, trusted, extra, { it in known }, min, running, active, cid, ac, onb)
                var bad = false
                if (!trusted && (p.what == IntentPolicy.Do.TAP_SERVER || p.what == IntentPolicy.Do.DISCONNECT_NOW || p.what == IntentPolicy.Do.PAUSE || p.what == IntentPolicy.Do.WARN_NOT_CONNECTED)) bad = true
                if (p.what == IntentPolicy.Do.TAP_SERVER && (p.serverId == null || p.serverId !in known)) bad = true
                if (p.what == IntentPolicy.Do.PAUSE && p.minutes !in 1..1440) bad = true
                if (p.what == IntentPolicy.Do.DISCONNECT_NOW && !(trusted && running && kind == IntentPolicy.Kind.DISCONNECT)) bad = true
                if (p.what == IntentPolicy.Do.CONFIRM_DISCONNECT && (trusted || !running || kind != IntentPolicy.Kind.DISCONNECT)) bad = true
                if (kind == IntentPolicy.Kind.OTHER && p.what != IntentPolicy.Do.NOTHING && !(ac && onb && !active && p.what == IntentPolicy.Do.TAP_ORB)) bad = true
                if (bad) { violations++; if (first.isEmpty()) first = "$kind trusted=$trusted extra=$extra min=$min running=$running active=$active → ${p.what}" }
            }
        T.check("$combos girdi birleşiminde güvenlik değişmezleri korunur", violations == 0, "ihlal=$violations $first")
        fun pl(k: IntentPolicy.Kind, tr: Boolean, extra: String? = null, min: Int = 15, run: Boolean = true, act: Boolean = true, cid: String? = null) = IntentPolicy.plan(k, tr, extra, { it in known }, min, run, act, cid, false, true)
        T.check("güvenilen 'bağlan b' → b'ye geç; zaten b'ye bağlıysa hiçbir şey", pl(IntentPolicy.Kind.CONNECT, true, "b", cid = "a").what == IntentPolicy.Do.TAP_SERVER && pl(IntentPolicy.Kind.CONNECT, true, "b", cid = "b").what == IntentPolicy.Do.NOTHING)
        T.check("güvenilmeyen 'bağlan b' sunucu seçemez; bağlı değilse yalnızca küre (kullanıcı onaylı) dokunuşu", pl(IntentPolicy.Kind.CONNECT, false, "b", act = false).what == IntentPolicy.Do.TAP_ORB && pl(IntentPolicy.Kind.CONNECT, false, "b", act = true).what == IntentPolicy.Do.NOTHING)
        T.check("güvenilmeyen 'kes' → kullanıcıya sor; güvenilen 'kes' → hemen", pl(IntentPolicy.Kind.DISCONNECT, false).what == IntentPolicy.Do.CONFIRM_DISCONNECT && pl(IntentPolicy.Kind.DISCONNECT, true).what == IntentPolicy.Do.DISCONNECT_NOW)
        T.check("duraklatma süresi 1..1440 dakikaya sıkıştırılır", pl(IntentPolicy.Kind.PAUSE, true, min = Int.MAX_VALUE).minutes == 1440 && pl(IntentPolicy.Kind.PAUSE, true, min = -9).minutes == 1 && pl(IntentPolicy.Kind.PAUSE, true, min = 30).minutes == 30)
    }
}

private fun indexOf(h: ByteArray, n: ByteArray): Int {
    outer@ for (i in 0..h.size - n.size) { for (j in n.indices) if (h[i + j] != n[j]) continue@outer; return i }
    return -1
}
