package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

/**
 * Sızma 2 — yeni özelliklerdeki hatalar: DNS yarışı anahtarı bağlıyken hemen uygulanmıyordu; "Otomatik DPI" kapatılınca açık kalmış otomatik DPI
 * kapanmıyordu (ve ağ geçidi canlı ayarı almıyordu).
 */
fun runFeatureFixTests() {
    fun on(s: AppSettings = Rig.base(), gw: Boolean = false): Pair<AppModel, FakeHost> {
        val h = FakeHost(); val m = AppModel(h, s)
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 0, 0, 20, gwActive = gw))
        return m to h
    }
    fun FakeHost.n(call: String) = calls.count { it == call }

    T.group("Yeni özellik hatası: DNS yarışı anahtarı bağlıyken hemen uygulanır (yeniden bağlanmak gerekmez)")
    run {
        val (m, h) = on(Rig.base().copy(dnsRace = true))
        m.update { it.copy(dnsRace = false) }
        T.check("bağlıyken DNS yarışı kapatılınca servise 'uygula' gider", h.n("reapply") == 1 && !m.settings.dnsRace, h.calls.toString())
        m.update { it.copy(dnsRace = true) }
        T.check("yeniden açılınca da", h.n("reapply") == 2 && m.settings.dnsRace)
        m.update { it.copy(dnsRace = true) }
        T.check("değişmeyen ayar servise bir şey göndermez", h.n("reapply") == 2)
        val (m2, h2) = on(Rig.base().copy(autoShield = true))
        m2.update { it.copy(autoShield = false) }
        T.check("kontrol: bağlantıyı etkilemeyen ayar 'uygula' göndermez", h2.n("reapply") == 0)
        val h3 = FakeHost(); val m3 = AppModel(h3, Rig.base().copy(dnsRace = true))
        m3.update { it.copy(dnsRace = false) }
        T.check("bağlı değilken 'uygula' gitmez, ayar yalnızca kaydedilir", h3.n("reapply") == 0 && h3.saved?.dnsRace == false)
        val (m4, h4) = on(Rig.base())
        m4.update { it.copy(cache = if (it.cache == CacheLevel.OFF) CacheLevel.NORMAL else CacheLevel.OFF) }
        m4.update { it.copy(odoh = if (it.odoh == OdohMode.OFF) OdohMode.FALLBACK else OdohMode.OFF) }
        T.check("kontrol: önbellek ve ODoH değişimi hâlâ 'uygula' gönderir", h4.n("reapply") == 2)
    }

    T.group("Yeni özellik hatası: 'Otomatik DPI' anahtarı ağ geçidine canlı uygulanır; kapatınca açık kalmış otomatik DPI kapanır")
    run {
        val (m, h) = on(Rig.base().copy(autoDpi = true), gw = true)
        m.update { it.copy(autoDpi = false) }
        T.check("ağ geçidi çalışırken Otomatik DPI değişince modüller yeniden uygulanır", h.calls.any { it.startsWith("modules:") }, h.calls.toString())
        val (m2, h2) = on(Rig.base().copy(autoDpi = true), gw = false)
        m2.update { it.copy(autoDpi = false) }
        T.check("ağ geçidi yokken (yalnızca DNS) modül uygulanmaz", h2.calls.none { it.startsWith("modules:") })
        val acts = setOf(Act.DPI_ON, Act.QUIC_OFF)
        T.check("DPI kararı: kullanıcı açtıysa her zaman açık", dpiWanted(true, true, acts) && dpiWanted(true, false, acts) && dpiWanted(true, true, emptySet()) && dpiWanted(true, false, emptySet()))
        T.check("DPI kararı: kullanıcı kapalı + Otomatik DPI açık + önlem aktif → açık", dpiWanted(false, true, acts))
        T.check("DPI kararı: Otomatik DPI anahtarı kapatılınca önlem aktif olsa da KAPALI (eski hata: açık kalıyordu)", !dpiWanted(false, false, acts))
        T.check("DPI kararı: önlem aktif değilse kapalı", !dpiWanted(false, true, emptySet()) && !dpiWanted(false, true, setOf(Act.QUIC_OFF)) && !dpiWanted(false, false, emptySet()))
    }
}
