package app.dnshizli.selftest

import app.dnshizli.core.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.Random
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ScheduledThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Sızma 10 — düz (UDP) DNS yönlendiricisi:
 *  1) tarpit: cevap vermeyen tek alandan yüzlerce farklı ad bekleyen tabloyu ([DnsForwarder.MAX_PENDING]) dolduramaz; alan sayacı her yolda
 *     tam bir kez düşer (cevap, zaman aşımı, birleşme, ağ sıfırlama);
 *  2) hata enjeksiyonu: tünel yazması / günlük işlevi atarsa alıcı iş parçacıkları ve süpürücü ölmez;
 *  3) düşman üst sunucu: kimliği ve sorusu tutan ama gövdesi bozuk (kesik, yalan sayaç, döngülü işaretçi, çöp) cevaplar.
 */
fun runUdpResilienceTests() {
    udpTarpitTests()
    udpFaultTests()
    udpHostileUpstreamTests()
}

/** Sorgunun ad bölümünü noktalı küçük harfli metne çevirir (bozuksa ""). */
private fun qnameOf(q: ByteArray, len: Int): String {
    val sb = StringBuilder()
    var i = 12
    while (i < len) {
        val l = q[i].toInt() and 0xFF
        if (l == 0) break
        if (l > 63 || i + 1 + l > len) return ""
        if (sb.isNotEmpty()) sb.append('.')
        sb.append(String(q, i + 1, l, Charsets.ISO_8859_1))
        i += 1 + l
    }
    return sb.toString().lowercase()
}

/** Üst sunucu: ".slow.test" altındaki adlara hiç cevap vermez (tarpit), ".late.test" 120 ms geç cevaplar, ötekilere hemen. */
private class Tarpit : AutoCloseable {
    private val loop = InetAddress.getLoopbackAddress()
    val socket = DatagramSocket(0, loop)
    val addr: InetSocketAddress get() = InetSocketAddress(loop, socket.localPort)
    val received = AtomicInteger()
    val swallowed = AtomicInteger()
    private val pool = ScheduledThreadPoolExecutor(2)

    init {
        Thread {
            val buf = ByteArray(2048)
            val p = DatagramPacket(buf, buf.size)
            while (!socket.isClosed) {
                try { p.length = buf.size; socket.receive(p) } catch (_: Exception) { return@Thread }
                received.incrementAndGet()
                val q = buf.copyOf(p.length)
                val name = qnameOf(q, q.size)
                val to = p.socketAddress
                if (name.endsWith(".slow.test")) { swallowed.incrementAndGet(); continue }
                val resp = buildAnswer(q, q.size, aRecord(byteArrayOf(1, 2, 3, 4), 60), 1)
                if (name.endsWith(".late.test")) {
                    try { pool.schedule(Runnable { try { socket.send(DatagramPacket(resp, resp.size, to)) } catch (_: Exception) { } }, 120, TimeUnit.MILLISECONDS) } catch (_: Exception) { }
                } else {
                    try { socket.send(DatagramPacket(resp, resp.size, to)) } catch (_: Exception) { return@Thread }
                }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    override fun close() { socket.close(); pool.shutdownNow() }
}

/** [id] kimlikli cevap gelene dek (en çok [ms]) tünele yazılanları okur; diğer cevaplar atılır. Süre (ms) ya da -1. */
private fun waitReply(h: Harness, id: Int, ms: Long): Long {
    val t0 = System.nanoTime()
    val end = System.currentTimeMillis() + ms
    while (System.currentTimeMillis() < end) {
        val r = h.reply(20) ?: continue
        if (Packets.u16(r, 28) == id) return (System.nanoTime() - t0) / 1_000_000
    }
    return -1
}

private fun udpTarpitTests() {
    T.group("Sızma 10 / UDP DNS: cevapsız (tarpit) tek alandan 400 farklı ad, sonra sürekli sel — bekleyen tablo alan sınırında kalır, komşu alanlar etkilenmez")
    run {
        val up = Tarpit()
        val h = Harness(listOf(up.addr), retryAfterMs = 400, giveUpAfterMs = 1500, sweepMs = 50)
        try {
            for (i in 0 until 400) h.send(clientPacket(1000 + i, "x$i.slow.test", srcPort = 40000 + i % 40))
            val peak = h.fw.pendingCount()
            T.check("bekleyen tablo alan sınırında (1..${DnsForwarder.ZONE_PENDING}, şimdi $peak)", peak in 1..DnsForwarder.ZONE_PENDING, "$peak")
            T.check("fazlası düşürüldü (alan sınırı ${h.fw.zoneDropped()} ≥ ${400 - DnsForwarder.ZONE_PENDING - 4})", h.fw.zoneDropped() >= 400L - DnsForwarder.ZONE_PENDING - 4, "${h.fw.zoneDropped()}")
            val ids = (0 until 20).map { 5000 + it }
            for ((k, id) in ids.withIndex()) h.send(clientPacket(id, "v$k.fast$k.test", srcPort = 41000 + k))
            val got = HashSet<Int>()
            val t0 = System.currentTimeMillis()
            while (got.size < ids.size && System.currentTimeMillis() - t0 < 1500) { val r = h.reply(50) ?: continue; got.add(Packets.u16(r, 28)) }
            T.check("20 komşu alan sorgusunun hepsi cevaplandı (${System.currentTimeMillis() - t0} ms)", got.containsAll(ids), "${got.size}/20")

            // sürekli sel: 1,5 sn boyunca her turda 20 yeni cevapsız ad + 1 komşu sorgu
            val lat = ArrayList<Long>()
            var n = 0
            var peakPending = 0
            var victim = 20_000
            val end = System.currentTimeMillis() + 1500
            while (System.currentTimeMillis() < end) {
                for (k in 0 until 20) { n++; h.send(clientPacket(2000 + (n and 0x7FF), "f$n.slow.test", srcPort = 42000 + k)) }
                peakPending = maxOf(peakPending, h.fw.pendingCount())
                val id = victim++
                h.send(clientPacket(id, "w$id.neigh${id % 7}.test", srcPort = 43000 + id % 50))
                lat.add(waitReply(h, id, 400))
                Thread.sleep(4)
            }
            lat.sort()
            val lost = lat.count { it < 0 }
            val p95 = if (lat.isEmpty()) 0L else lat[(lat.size * 95 / 100).coerceAtMost(lat.size - 1)]
            T.check("sel sürerken ${lat.size} komşu sorgudan kaybolan yok ($lost), %95 gecikme ≤ 250 ms ($p95 ms)", lost == 0 && p95 <= 250, "kayıp=$lost p95=$p95")
            T.check("sel sürerken bekleyen tablo sınırı aşmadı (≤ ${DnsForwarder.ZONE_PENDING + 12}, en çok $peakPending)", peakPending <= DnsForwarder.ZONE_PENDING + 12, "$peakPending")
            T.check("sel sonrası tablo ve alan sayaçları boşalır (zaman aşımı yolu)", waitUntil(6000) { h.fw.pendingCount() == 0 && h.fw.zonePendingCount() == 0 }, "bekleyen=${h.fw.pendingCount()} alan=${h.fw.zonePendingCount()}")
            h.send(clientPacket(9999, "again.slow.test", srcPort = 44000))
            T.check("sel bitince aynı alan yeniden kabul edilir", h.fw.pendingCount() == 1, "${h.fw.pendingCount()}")
            T.check("iç hata yok", h.fw.internalErrors() == 0L, h.fw.lastInternalError())
        } finally { h.close(); up.close() }
    }

    T.group("Sızma 10 / UDP DNS: alan sayacı her yolda tam bir kez düşer (cevap, zaman aşımı, birleşme, ağ sıfırlama) — 3000 rastgele sorgu")
    run {
        val up = Tarpit()
        val h = Harness(listOf(up.addr), retryAfterMs = 200, giveUpAfterMs = 700, sweepMs = 30)
        try {
            val rnd = Random(77)
            val zones = listOf("slow.test", "late.test", "fast.test", "mix.test", "z.test")
            for (i in 0 until 3000) {
                val name = (if (rnd.nextInt(4) == 0) "dup${rnd.nextInt(20)}" else "n$i") + "." + zones[rnd.nextInt(zones.size)]     // tekrarlar birleşme yolunu sınar
                h.send(clientPacket(i and 0xFFFF, name, srcPort = 40000 + rnd.nextInt(30)))
                if (i % 97 == 0) Thread.sleep(3)
                if (i == 1500) h.fw.resetNetwork("test")
                if (i % 211 == 0) h.reply(0)
            }
            val settled = waitUntil(9000) { h.fw.pendingCount() == 0 }
            T.check("her sorgu bitti: bekleyen 0", settled, "bekleyen=${h.fw.pendingCount()}")
            T.check("alan sayaçları 0 (sızıntı ya da çift düşüş yok)", h.fw.zonePendingCount() == 0, "alan=${h.fw.zonePendingCount()}")
            val st = h.fw.stats()
            T.check("sel gerçekten uygulandı: ağa ${st.forwarded} sorgu, alan sınırından ${h.fw.zoneDropped()} düşen, birleşen ${st.merged}", st.forwarded > 500 && st.merged > 0, "forwarded=${st.forwarded} merged=${st.merged}")
            T.check("iç hata yok", h.fw.internalErrors() == 0L, h.fw.lastInternalError())
            // sayaç eksiye düşmüş olsaydı sınır işlevsiz kalırdı: 100 cevapsız ad yine 64'te kesilmeli
            val before = h.fw.zoneDropped()
            for (i in 0 until 100) h.send(clientPacket(30000 + i, "p$i.slow.test", srcPort = 45000 + i % 20))
            T.check("sayaç doğru kalmış: yeni 100 cevapsız addan ${h.fw.zoneDropped() - before} tanesi düşürüldü (≥ ${100 - DnsForwarder.ZONE_PENDING})", h.fw.zoneDropped() - before >= 100L - DnsForwarder.ZONE_PENDING, "${h.fw.zoneDropped() - before}")
        } finally { h.close(); up.close() }
    }
}

private fun udpFaultTests() {
    T.group("Sızma 10 / UDP DNS: tünel yazması ilk 8 cevapta atar — alıcı iş parçacıkları ölmez, sonraki 40 sorgu cevaplanır")
    run {
        val up = FakeDns()
        val tun = LinkedBlockingQueue<ByteArray>()
        val fail = AtomicInteger(8)
        val fw = DnsForwarder(listOf(up.addr), { b, o, l ->
            if (fail.getAndDecrement() > 0) throw IllegalStateException("tünel yazma hatası (enjekte)")
            tun.add(b.copyOfRange(o, o + l))
        }, retryAfterMs = 300, giveUpAfterMs = 1500, sweepMs = 50).also { it.start() }
        try {
            for (i in 0 until 8) { val p = clientPacket(100 + i, "e$i.test", srcPort = 40500 + i); fw.onPacket(p, p.size); Thread.sleep(25) }
            T.check("başarısız teslimlerde bekleyen kayıt kalmaz", waitUntil(2500) { fw.pendingCount() == 0 && fw.zonePendingCount() == 0 }, "bekleyen=${fw.pendingCount()} alan=${fw.zonePendingCount()}")
            tun.clear()
            val ids = (0 until 40).map { 200 + it }
            for ((k, id) in ids.withIndex()) { val p = clientPacket(id, "ok$k.test", srcPort = 40100 + k); fw.onPacket(p, p.size) }
            val got = HashSet<Int>()
            val end = System.currentTimeMillis() + 4000
            while (got.size < ids.size && System.currentTimeMillis() < end) { val r = tun.poll(100, TimeUnit.MILLISECONDS) ?: continue; got.add(Packets.u16(r, 28)) }
            T.check("tünel hatalarından sonra 40 sorgunun hepsi cevaplandı (iki yuvanın alıcısı da yaşıyor)", got.containsAll(ids), "${got.size}/40")
            T.check("teslim hataları sayıldı (≥ 8)", fw.internalErrors() >= 8L, "sayaç=${fw.internalErrors()} ${fw.lastInternalError()}")
        } finally { fw.close(); up.close() }
    }

    T.group("Sızma 10 / UDP DNS: günlük işlevi zaman aşımında atar — süpürücü ölmez, tüm bekleyen sorgular zaman aşımına uğrar")
    run {
        val up = Tarpit()
        val fw = DnsForwarder(listOf(up.addr), { _, _, _ -> }, retryAfterMs = 100, giveUpAfterMs = 500, sweepMs = 30,
            log = { m -> if (m.startsWith("zaman aşımı")) throw IllegalStateException("günlük yazma hatası (enjekte)") }).also { it.start() }
        try {
            for (i in 0 until 6) { val p = clientPacket(300 + i, "t$i.slow.test", srcPort = 41500 + i); fw.onPacket(p, p.size); Thread.sleep(40) }
            T.check("6 cevapsız sorgunun hepsi zaman aşımıyla temizlendi", waitUntil(4000) { fw.pendingCount() == 0 }, "bekleyen=${fw.pendingCount()}")
            T.check("alan sayaçları 0", fw.zonePendingCount() == 0, "${fw.zonePendingCount()}")
            T.check("zaman aşımı sayıldı (6)", fw.stats().timeouts == 6L, "${fw.stats().timeouts}")
        } finally { fw.close(); up.close() }
    }
}

/**
 * Düşman üst sunucu: kimlik ve soru bölümü doğru (yönlendirici cevabı kabul eder) ama gövde bozuk.
 * [hostile] false ise hep sağlam cevap verir.
 */
private class FuzzDns(seed: Long) : AutoCloseable {
    private val loop = InetAddress.getLoopbackAddress()
    val socket = DatagramSocket(0, loop)
    val addr: InetSocketAddress get() = InetSocketAddress(loop, socket.localPort)
    @Volatile var hostile = true
    val sentBad = AtomicInteger()
    private val rnd = Random(seed)

    private fun mutate(a: ByteArray, qEnd: Int): ByteArray {
        val m = a.copyOf()
        when (rnd.nextInt(9)) {
            0 -> return a                                                                            // sağlam
            1 -> return a.copyOf(qEnd + rnd.nextInt(maxOf(1, a.size - qEnd + 1)))                    // kesik
            2, 3, 4 -> repeat(1 + rnd.nextInt(8)) { if (m.size > qEnd) m[qEnd + rnd.nextInt(m.size - qEnd)] = rnd.nextInt().toByte() }   // gövde bayt bozma
            5 -> { Packets.put16(m, 6, rnd.nextInt(65536)); Packets.put16(m, 8, rnd.nextInt(65536)); Packets.put16(m, 10, rnd.nextInt(65536)) }   // yalan sayaçlar
            6 -> return m + ByteArray(1 + rnd.nextInt(200)).also { rnd.nextBytes(it) }              // çöp kuyruk
            7 -> {                                                                                    // kendine işaret eden / döngülü sıkıştırma
                val off = qEnd
                if (m.size >= off + 12) { m[off] = 0xC0.toByte(); m[off + 1] = off.toByte(); m[off + 2] = 0; m[off + 3] = if (rnd.nextBoolean()) 5 else 1; m[off + 4] = 0; m[off + 5] = 1 }
                Packets.put16(m, 6, 1 + rnd.nextInt(30))
            }
            else -> { Packets.put16(m, 2, rnd.nextInt(65536) or 0x8000); for (k in qEnd until m.size) m[k] = rnd.nextInt().toByte() }   // rastgele bayraklar / rcode, rastgele gövde
        }
        return m
    }

    init {
        Thread {
            val buf = ByteArray(2048)
            val p = DatagramPacket(buf, buf.size)
            while (!socket.isClosed) {
                try { p.length = buf.size; socket.receive(p) } catch (_: Exception) { return@Thread }
                val q = buf.copyOf(p.length)
                val qEnd = Dns.questionEnd(q, 0, q.size)
                if (qEnd < 17) continue
                val a = buildAnswer(q, q.size, aRecord(byteArrayOf(1, 2, 3, 4), 60), 1)
                val r = if (hostile) mutate(a, qEnd).also { sentBad.incrementAndGet() } else a
                try { socket.send(DatagramPacket(r, r.size, p.socketAddress)) } catch (_: Exception) { return@Thread }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    override fun close() = socket.close()
}

private fun udpHostileUpstreamTests() {
    T.group("Sızma 10 / UDP DNS: düşman üst sunucu — 4000 sorguya kesik / yalan sayaçlı / döngülü işaretçili / çöp kuyruklu cevaplar")
    run {
        val up = FuzzDns(0xBADD)
        val h = Harness(listOf(up.addr), retryAfterMs = 150, giveUpAfterMs = 600, sweepMs = 30, cacheEntries = 64)
        try {
            val rnd = Random(4242)
            for (i in 0 until 4000) {
                h.send(clientPacket(i and 0xFFFF, "h$i.${listOf("a", "b", "c", "d").get(rnd.nextInt(4))}.test", srcPort = 40000 + rnd.nextInt(40)))
                if (i % 50 == 0) { Thread.sleep(2); while (h.reply(0) != null) { } }
            }
            val shed = h.fw.zoneDropped()
            T.check("düşman cevaplar gerçekten gönderildi (${up.sentBad.get()})", up.sentBad.get() > 2000, "${up.sentBad.get()}")
            T.check("her sorgu ya üst sunucuya gitti ya alan sınırında bilerek düşürüldü (sessiz kayıp yok): ${up.sentBad.get()} + $shed ≥ 4000", up.sentBad.get() + shed >= 4000L, "gönderilen=${up.sentBad.get()} düşürülen=$shed")
            T.check("her sorgu bitti (cevaplandı ya da zaman aşımı): bekleyen 0, alan sayacı 0", waitUntil(6000) { h.fw.pendingCount() == 0 && h.fw.zonePendingCount() == 0 }, "bekleyen=${h.fw.pendingCount()} alan=${h.fw.zonePendingCount()}")
            T.check("beklenmeyen iç hata yok (cevap ayrıştırıcıları bozuk girdide atmaz)", h.fw.internalErrors() == 0L, "sayaç=${h.fw.internalErrors()} ${h.fw.lastInternalError()}")
            up.hostile = false
            while (h.reply(0) != null) { }
            h.fw.clearCache()
            val ids = (0 until 40).map { 50_000 + it }
            for ((k, id) in ids.withIndex()) h.send(clientPacket(id, "temiz$k.test", srcPort = 41000 + k))
            val got = HashSet<Int>()
            val end = System.currentTimeMillis() + 4000
            while (got.size < ids.size && System.currentTimeMillis() < end) { val r = h.reply(100) ?: continue; got.add(Packets.u16(r, 28)) }
            T.check("saldırı sonrası sağlam sorgular eksiksiz cevaplanır (alıcı iş parçacıkları yaşıyor)", got.containsAll(ids), "${got.size}/40")
        } finally { h.close(); up.close() }
    }
}
