package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.Random

private const val MIN = 60_000L

/** Oto onarım simülasyonu: tohumlu rastgele olay akışı + değişmezler (her turda denetlenir). */
private class Sim(seed: Long, val scope: Boolean = true) {
    val rnd = Random(seed)
    val im = Immune(Random(seed + 1))
    val model = HashSet<Act>()                // değişikliklerden kurulan etkin küme
    val problems = ArrayList<String>()
    val onTimes = ArrayList<Pair<Long, Act>>()
    var now = 1_000_000L
    var ticks = 0
    var maxEncoded = 0
    var onPerTick = 0
    val canBlock = HashSet<Act>()

    fun note(s: String) { if (problems.size < 6) problems += "t=${(now - 1_000_000L) / MIN}dk: $s" }

    fun step(dtMs: Long, reports: Int, weight: Double) {
        now += dtMs
        repeat(reports) { im.report(Threat.values()[rnd.nextInt(Threat.values().size)], weight * (0.2 + rnd.nextDouble() * 2), now - rnd.nextInt(500)) }
        if (rnd.nextInt(40) == 0) im.harm(1.0 + rnd.nextInt(8), now)
        if (rnd.nextInt(60) == 0) im.hold(now, rnd.nextInt(5) * MIN)
        if (scope && rnd.nextInt(80) == 0) im.setScope(listOf("", "wifi", "mobil", "kablo")[rnd.nextInt(4)])
        val ch = im.tick(now) { a -> a !in canBlock }
        ticks++
        var on = 0
        for (c in ch) {
            if (c.on) {
                on++
                if (c.act in canBlock) note("uygulanamaz denen önlem açıldı: ${c.act}")
                if (c.act.sticky) { if (!model.add(c.act)) note("zaten açık önlem yeniden açıldı: ${c.act}") } else onTimes += now to c.act
            } else if (c.act.sticky && !model.remove(c.act)) note("açık olmayan önlem kapatıldı: ${c.act}")
        }
        onPerTick = maxOf(onPerTick, on)
        val act = im.active()
        if (act != model) note("etkin küme model ile uyuşmuyor: $act vs $model")
        if (act.any { !it.sticky }) note("sürekli olmayan önlem etkin kümede")
        for (t in Threat.values()) for (a in t.ladder) {
            val e = im.efficacy(t, a)
            if (e.isNaN() || e < 0.0 || e > 1.0) note("verimlilik aralık dışı $t/$a=$e")
        }
        for (t in Threat.values()) { val th = im.threshold(t); val sc = im.score(t, now); if (th.isNaN() || th.isInfinite() || sc.isNaN() || sc < 0) note("eşik/puan bozuk $t th=$th sc=$sc") }
        if (ticks % 25 == 0) { val e = im.encodeAll(now); maxEncoded = maxOf(maxEncoded, e.length) }
    }
}

fun runDeepImmuneTests() {
    T.group("Derin oto onarım: tohumlu uzun simülasyonlar (günler) ve değişmezler")
    for (seed in 1L..(6L * DEEP_X)) {
        val s = Sim(seed)
        // 3 gün: sakin, saldırı patlamaları, ağ değişimi, uygulanamaz önlemler
        repeat(3 * 24 * 60) { m ->
            val burst = (m / 90) % 5 == 2
            s.step(MIN, if (burst) 1 + s.rnd.nextInt(8) else if (s.rnd.nextInt(10) == 0) 1 else 0, if (burst) 2.5 else 0.5)
            if (m % 500 == 499) { s.canBlock.clear(); if (s.rnd.nextBoolean()) s.canBlock.add(Act.values()[s.rnd.nextInt(Act.values().size)]) }
        }
        T.check("tohum $seed: 4320 turda hiçbir değişmez bozulmadı", s.problems.isEmpty(), s.problems.toString())
        T.check("tohum $seed: tek turda en çok 2 önlem açıldı (yalnızca çok şiddetli saldırıda ikincisi)", s.onPerTick <= 2, "enÇok=${s.onPerTick}")
        // kesintili (sürekli olmayan) önlemler: kayan 60 dk'da sınırı aşmaz
        var worst = 0
        val l = s.onTimes
        for (i in l.indices) { var c = 0; var j = i; while (j < l.size && l[j].first - l[i].first < 60 * MIN) { c++; j++ }; worst = maxOf(worst, c) }
        T.check("tohum $seed: kesintili önlem saatte ≤ ${Immune.MAX_DISRUPTIVE_PER_HOUR}", worst <= Immune.MAX_DISRUPTIVE_PER_HOUR, "en kötü=$worst")
        T.check("tohum $seed: kalıcı durum metni ${8192} bayt sınırında (yüklenebilir)", s.maxEncoded in 1..8192, "en büyük=${s.maxEncoded}")
        // sakinlik: olaysız 90 dk sonra etkin önlem kalmaz
        repeat(90) { s.step(MIN, 0, 0.0) }
        T.check("tohum $seed: 90 dk sakinlikten sonra tüm sürekli önlemler geri alındı", s.im.active().isEmpty() && s.model.isEmpty(), "etkin=${s.im.active()}")
        T.check("tohum $seed: sakinlikte değişmez ihlali yok", s.problems.isEmpty(), s.problems.toString())
    }

    T.group("Derin oto onarım: kalıcılık gidiş-dönüş ve bozulmuş kayıt")
    for (seed in 1L..(8L * DEEP_X)) {
        val s = Sim(seed * 13)
        repeat(240) { m -> s.step(MIN, if ((m / 40) % 2 == 1) 3 else 0, 3.0) }
        val saved = s.im.encodeAll(s.now)
        val back = Immune(Random(5))
        val ch = back.decodeAll(saved, s.now + 5 * MIN)
        T.check("seed $seed: yüklenen etkin küme kaydedilenle aynı (ya da onun alt kümesi)", s.im.active().containsAll(back.active()) && back.active().size >= s.im.active().size - 0, "kayıt=${s.im.active()} yüklenen=${back.active()}")
        T.check("seed $seed: geri yüklenen değişiklikler yalnızca 'açıldı'", ch.all { it.on && it.act.sticky })
        // bozma: rastgele bayt/karakter değişimi, kesme, çoğaltma
        val rnd = Random(seed)
        var threw: String? = null
        repeat(40) {
            val sb = StringBuilder(saved)
            when (rnd.nextInt(5)) {
                0 -> if (sb.isNotEmpty()) sb.setCharAt(rnd.nextInt(sb.length), (rnd.nextInt(95) + 32).toChar())
                1 -> sb.setLength(rnd.nextInt(sb.length + 1))
                2 -> sb.append(saved)
                3 -> sb.insert(rnd.nextInt(sb.length + 1), listOf("|", ";", ".", "A.X.Y", "B.SPOOF.REFRESH.99999999999999999999.5", "NaN", "-1")[rnd.nextInt(7)])
                else -> sb.append(String(CharArray(rnd.nextInt(300)) { (rnd.nextInt(255) + 1).toChar() }))
            }
            try {
                val im = Immune(Random(1)); val c = im.decodeAll(sb.toString(), s.now)
                if (!c.all { it.on && it.act.sticky && it.act in it.threat.ladder }) threw = "geçersiz değişiklik $c"
                if (!im.active().all { it.sticky }) threw = "etkin kümede geçersiz önlem"
                im.tick(s.now + MIN); im.selfCheck(s.now + 2 * MIN); im.describe(s.now); im.encodeAll(s.now)
            } catch (e: Throwable) { threw = "${e.javaClass.simpleName}: ${e.message}" }
        }
        T.check("seed $seed: 40 bozuk kayıt çökertmez, geçersiz önlem üretmez", threw == null, threw ?: "")
    }

    T.group("Derin oto onarım: zaman sıçramaları, NaN/sonsuz ağırlık, saat geri sarması")
    for (seed in 1L..(4L * DEEP_X)) {
        val rnd = Random(seed)
        val im = Immune(Random(seed))
        var t = 5_000_000L
        var err: String? = null
        repeat(400) {
            try {
                t += when (rnd.nextInt(8)) { 0 -> -rnd.nextInt(3 * 3600_000).toLong(); 1 -> rnd.nextInt(30) * 86_400_000L; 2 -> Long.MAX_VALUE / 16; else -> rnd.nextInt(120_000).toLong() }
                if (t < 0) t = 1000
                if (t > Long.MAX_VALUE / 4) t = 5_000_000L
                val w = when (rnd.nextInt(8)) { 0 -> Double.NaN; 1 -> Double.POSITIVE_INFINITY; 2 -> -5.0; 3 -> 1e300; else -> rnd.nextDouble() * 4 }
                im.report(Threat.values()[rnd.nextInt(Threat.values().size)], w, t - rnd.nextInt(1000))
                if (rnd.nextInt(10) == 0) im.harm(w, t)
                if (rnd.nextInt(15) == 0) im.hold(t, rnd.nextLong() % (1L shl 40))
                im.tick(t); im.selfCheck(t)
                for (th in Threat.values()) { val sc = im.score(th, t); if (sc.isNaN() || sc.isInfinite()) err = "puan sonsuz/NaN $th" }
                if (!im.active().all { it.sticky }) err = "etkin küme"
                im.encodeAll(t).also { if (it.length > 8192) err = "kayıt büyük ${it.length}" }
            } catch (e: Throwable) { err = "${e.javaClass.simpleName}: ${e.message} @ ${e.stackTrace.firstOrNull()}" }
        }
        T.check("tohum $seed: 400 uç değerli adımda çökme/NaN/taşma yok", err == null, err ?: "")
        // toparlanma: normal akışta yeniden çalışır
        val re = Immune(Random(1)); var tt = 9_000_000L
        re.report(Threat.AD_LEAK, 9.0, tt); val on = re.tick(tt + MIN)
        T.check("tohum $seed: yeni örnek normal akışta önlem açar (kontrol)", on.any { it.act == Act.DOH_BLOCK && it.on })
        // sıçramalı örnek sakin bir saatten sonra hâlâ geri alabilir ve yeni saldırıya yanıt verir
        im.reset(); tt = 20_000_000L
        im.report(Threat.AD_LEAK, 9.0, tt); val o2 = im.tick(tt + MIN)
        T.check("tohum $seed: reset sonrası sıçramalı örnek yeniden normal çalışır", o2.any { it.on }, o2.toString())
    }

    T.group("Derin oto onarım: uygulanamayan önlem ve yan etki katmanı")
    for (seed in 1L..(6L * DEEP_X)) {
        val im = Immune(Random(seed))
        var t = 1_000_000L
        val seen = HashSet<Act>()
        // QUIC_OFF ve DPI_ON uygulanamaz: NET_BLOCK ENCRYPT/BACKUP'a düşmeli; hiçbir zaman uygulanamayanı açmamalı
        repeat(240) {
            t += MIN
            im.report(Threat.NET_BLOCK, 5.0, t - 1000)
            for (c in im.tick(t) { it != Act.QUIC_OFF && it != Act.DPI_ON }) if (c.on) seen += c.act
        }
        T.check("seed $seed: NET_BLOCK uygulanamayan önlemleri seçmedi", Act.QUIC_OFF !in seen && Act.DPI_ON !in seen, seen.toString())
        T.check("seed $seed: uygulanabilir basamaklara (ENCRYPT/BACKUP) geçildi", seen.isNotEmpty() && seen.all { it == Act.ENCRYPT || it == Act.BACKUP }, seen.toString())
        // uygulama başarısız: failed() önlemi geri alır; hemen tekrar seçilmez
        val f = Immune(Random(seed)); var t2 = 1_000_000L
        f.report(Threat.AD_LEAK, 9.0, t2); val c1 = f.tick(t2 + MIN)
        val first = c1.firstOrNull { it.on }
        if (first != null) {
            f.failed(first.threat, first.act, t2 + MIN)
            T.check("seed $seed: failed() sonrası önlem etkin kümeden çıkar", first.act !in f.active(), f.active().toString())
            t2 += 2 * MIN; f.report(Threat.AD_LEAK, 9.0, t2)
            val again = f.tick(t2)
            T.check("seed $seed: başarısız önlem bir sonraki turda aynı anda yeniden açılmaz", again.none { it.on && it.act == first.act && it.threat == first.threat } || f.banned(first.threat, first.act, t2) == false)
        } else T.check("seed $seed: ilk tur önlem açtı", false, c1.toString())
    }
}

// ------------------------------------------------------------------ Denetim

private fun sample(rnd: Random, at: Long, prev: AuditSample?, attack: Boolean): AuditSample {
    fun grow(old: Long, rate: Int) = old + rnd.nextInt(rate + 1)
    fun p(f: (AuditSample) -> Long) = prev?.let(f) ?: 0L
    val bool = { x: Int -> rnd.nextInt(x) == 0 }
    return AuditSample(
        at = at, vpnUp = !bool(20), wanted = !bool(30), online = !bool(25), gwUp = !bool(5), dnsOn = !bool(6), dpiOn = bool(2), adsPlus = bool(2), echOn = bool(4),
        dohBlock = bool(2), failClosed = bool(8), passthrough = bool(30),
        queries = grow(p { it.queries }, 60), timeouts = grow(p { it.timeouts }, if (attack) 40 else 2), retries = grow(p { it.retries }, 20),
        rejected = grow(p { it.rejected }, if (attack) 4 else 0), tlsFailures = grow(p { it.tlsFailures }, if (attack) 3 else 0), clockFailures = grow(p { it.clockFailures }, if (attack && bool(10)) 2 else 0),
        failovers = grow(p { it.failovers }, if (attack) 2 else 0),
        opened = if (bool(200)) 0 else grow(p { it.opened }, if (attack) 3000 else 100), connectFail = grow(p { it.connectFail }, if (attack) 100 else 3),
        blockedHosts = grow(p { it.blockedHosts }, 30), dnsBlocked = grow(p { it.dnsBlocked }, 30), dohBlocked = grow(p { it.dohBlocked }, 10), cuts = grow(p { it.cuts }, if (attack) 8 else 0), exhaustSkipped = grow(p { it.exhaustSkipped }, if (attack) 8 else 0),
        recentOk = rnd.nextInt(100), recentFail = rnd.nextInt(100), recentDpiOk = rnd.nextInt(50), recentDpiFail = rnd.nextInt(50),
        tcpFlows = rnd.nextInt(2000), udpFlows = rnd.nextInt(500), flowCap = if (bool(3)) 0 else 1000 + rnd.nextInt(1000),
        plainDnsRedirected = grow(p { it.plainDnsRedirected }, 2), listsLive = !bool(10), listsDegraded = bool(10),
        immuneActive = rnd.nextInt(4), netChanges = grow(p { it.netChanges }, if (attack) 4 else 0), connects = grow(p { it.connects }, if (attack) 2 else 0),
        brokenApp = if (bool(12)) "com.x.app" else "", brokenName = "App", brokenCount = rnd.nextInt(9), leakProbe = rnd.nextInt(3),
    )
}

fun runDeepAuditTests() {
    T.group("Derin denetim: rastgele ölçüm akışları (günler) ve değişmezler")
    val langs = Lang.values()
    for (seed in 1L..(8L * DEEP_X)) {
        val rnd = Random(seed); val au = Audit(); var prev: AuditSample? = null; var at = 1_000_000L
        var err: String? = null
        val announcedAt = HashMap<String, Long>(); var repeated: String? = null
        repeat(2880) { i ->
            at += 30_000L + rnd.nextInt(5000)
            if (rnd.nextInt(300) == 0) at -= 3 * 3600_000L          // saat geri sarması
            val s = sample(rnd, at, prev, attack = (i / 200) % 4 == 2)
            prev = if (rnd.nextInt(150) == 0) null else s           // sayaç sıfırlanması
            try {
                val fresh = au.feed(s)
                val act = au.active()
                if (act.map { it.code }.toSet().size != act.size) err = "yinelenen kod ${act.map { it.code }}"
                if (!fresh.all { f -> act.any { it.code == f.code } }) err = "bildirilen bulgu etkin değil"
                if (au.score() !in 0..100) err = "puan ${au.score()}"
                for (f in act) { if (!AuditText.has(f.code)) err = "metni olmayan kod ${f.code}"
                    for (l in langs) { val tx = f.text(l); if (tx.isBlank() || "{" in tx) err = "bozuk metin ${f.code}/$l: $tx" } }
                for (f in fresh) { // aynı ağırlıkta yeniden bildirim ≥ 5 dk sonra olmalı
                    val last = announcedAt[f.code]
                    if (last != null && s.at >= last && s.at - last < 5 * 60_000L && f.sev != Sev.CRIT) repeated = "${f.code} ${(s.at - last) / 1000} sn"
                    announcedAt[f.code] = s.at
                }
            } catch (e: Throwable) { err = "${e.javaClass.simpleName}: ${e.message} @ ${e.stackTrace.firstOrNull()}" }
        }
        T.check("tohum $seed: 2880 ölçümde çökme yok, kodlar tekil, puan 0..100, 12 dilde metin tam", err == null, err ?: "")
        T.check("tohum $seed: aynı bulgu 5 dk içinde tekrar bildirilmedi (ağırlık artışı hariç)", repeated == null, repeated ?: "")
    }

    T.group("Derin denetim: saldırı → tespit → toparlanma (gecikme sınırları)")
    for (seed in 1L..(4L * DEEP_X)) {
        val rnd = Random(seed); val au = Audit()
        var at = 1_000_000L
        var s = AuditSample(at, gwUp = true, dnsOn = true, dpiOn = true, dohBlock = true)
        fun adv(spoof: Long, tls: Long, to: Long, q: Long): AuditSample {
            at += 30_000L
            s = AuditSample(at, gwUp = true, dnsOn = true, dpiOn = true, dohBlock = true, queries = s.queries + q, timeouts = s.timeouts + to, rejected = s.rejected + spoof, tlsFailures = s.tlsFailures + tls, opened = s.opened + 20)
            return s
        }
        repeat(12) { au.feed(adv(0, 0, 0, 50)) }
        T.check("seed $seed: sakin ağda bulgu yok, puan 100", au.active().none { it.cat == AuditCat.INTRUSION } && au.score() == 100, au.active().map { it.code }.toString())
        var detectedAfter = -1
        for (i in 1..40) { au.feed(adv(1 + rnd.nextInt(2).toLong(), 1, 0, 50)); if (detectedAfter < 0 && au.active().any { it.code == "sec.spoof" }) detectedAfter = i }
        T.check("seed $seed: sürekli sahte cevap ≤ 6 ölçümde (3 dk) CRIT olarak yakalanır", detectedAfter in 1..6, "ölçüm=$detectedAfter")
        T.check("seed $seed: TLS hataları da yakalanır", au.active().any { it.code == "sec.tls" })
        T.check("seed $seed: puan düştü", au.score() <= 40, au.score().toString())
        var cleared = -1
        for (i in 1..40) { au.feed(adv(0, 0, 0, 50)); if (cleared < 0 && au.active().none { it.code == "sec.spoof" || it.code == "sec.tls" }) cleared = i }
        T.check("seed $seed: saldırı bitince bulgu ≤ 14 ölçümde (7 dk) kapanır", cleared in 1..14, "ölçüm=$cleared")
        T.check("seed $seed: toparlanınca puan yeniden 100", au.score() == 100, au.score().toString())
    }
}

fun runDeepExperimentalAuditTests() {
    T.group("Derin denetim: deneysel özellik bulguları (yarış, tarayıcı kipi, oto DPI, listeli DPI)")
    fun feedSeq(n: Int, mk: (Int, Long) -> AuditSample): Audit { val a = Audit(); var at = 1_000_000L; for (i in 0 until n) { at += 30_000L; a.feed(mk(i, at)) }; return a }
    val noGw = feedSeq(6) { _, at -> AuditSample(at, gwUp = false, mitmOn = true) }
    T.check("tarayıcı kipi açık, ağ geçidi kapalı → mitm.nogw", noGw.active().any { it.code == "mitm.nogw" })
    val gw = feedSeq(6) { _, at -> AuditSample(at, gwUp = true, mitmOn = true, adsPlus = true, dohBlock = true) }
    T.check("ağ geçidi açıkken mitm.nogw yok", gw.active().none { it.code == "mitm.nogw" })
    val rej = feedSeq(12) { i, at -> AuditSample(at, gwUp = true, mitmOn = true, adsPlus = true, dohBlock = true, mitmRejects = i * 2L) }
    T.check("sertifika reddi sürerse mitm.cert (WARN)", rej.active().any { it.code == "mitm.cert" && it.sev == Sev.WARN })
    val flat = feedSeq(12) { _, at -> AuditSample(at, gwUp = true, mitmOn = true, adsPlus = true, dohBlock = true, mitmRejects = 5) }
    T.check("reddetme sayısı artmıyorsa mitm.cert yok", flat.active().none { it.code == "mitm.cert" })
    val off = feedSeq(12) { i, at -> AuditSample(at, gwUp = true, mitmOn = false, adsPlus = true, dohBlock = true, mitmRejects = i * 5L) }
    T.check("kip kapalıyken eski sayaçlar bulgu üretmez", off.active().none { it.code == "mitm.cert" })
    val race = feedSeq(12) { i, at -> AuditSample(at, queries = i * 100L, races = i * 40L) }
    T.check("sorguların %40'ı yarışırsa stab.race (bilgi, puanı düşürmez)", race.active().any { it.code == "stab.race" && it.sev == Sev.INFO } && race.score() == 100, race.active().map { it.code }.toString())
    val few = feedSeq(12) { i, at -> AuditSample(at, queries = i * 100L, races = i * 2L) }
    T.check("az yarış (%2) bulgu üretmez", few.active().none { it.code == "stab.race" })
    val auto = feedSeq(4) { _, at -> AuditSample(at, dpiOn = false, autoDpi = true, gwUp = true, dohBlock = true) }
    T.check("oto-koruma DPI'yı açtıysa dpi.auto", auto.active().any { it.code == "dpi.auto" })
    val auto2 = feedSeq(4) { _, at -> AuditSample(at, dpiOn = true, autoDpi = true, gwUp = true, dohBlock = true) }
    T.check("kullanıcı DPI'yı zaten açtıysa dpi.auto yok", auto2.active().none { it.code == "dpi.auto" })
    val le = feedSeq(4) { _, at -> AuditSample(at, dpiOn = true, listedOnly = true, blockedListSize = 0, gwUp = true, dohBlock = true) }
    val ln = feedSeq(4) { _, at -> AuditSample(at, dpiOn = true, listedOnly = true, blockedListSize = 120, gwUp = true, dohBlock = true) }
    T.check("listeyle sınırlı DPI + boş liste → dpi.listed-empty; liste doluysa yok", le.active().any { it.code == "dpi.listed-empty" } && ln.active().none { it.code == "dpi.listed-empty" })
    val langs = Lang.values()
    for (code in listOf("dpi.auto", "mitm.nogw", "mitm.cert", "stab.race", "dpi.listed-empty")) {
        val row = AuditText.row(code)
        T.check("$code: 12 dilde dolu metin, değişkenler (placeholder) dillerde aynı", row != null && row.size == langs.size && row.all { it.isNotBlank() } &&
            row.map { AuditText.placeholders(it) }.toSet().size == 1, code)
    }
}

fun runDeepImmuneExperimentalTests() {
    T.group("Derin oto onarım: tarayıcı kipi hatasında vekili söker; aynı anda saldırıda sınır")
    val im = Immune(Random(1))
    var t = 1_000_000L
    val seen = ArrayList<Immune.Change>()
    repeat(6) { t += MIN; if (Act.MITM_OFF !in im.active()) im.report(Threat.PROXY_FAIL, 5.0, t - 500); seen += im.tick(t) { true } }      // vekil sökülünce hata akışı durur
    T.check("art arda vekil/sertifika hatası → MITM_OFF açılır", seen.any { it.act == Act.MITM_OFF && it.on && it.threat == Threat.PROXY_FAIL } && Act.MITM_OFF in im.active(), seen.toString())
    val q = Immune(Random(1)); q.decodeAll(im.encodeAll(t), t + MIN)
    T.check("MITM_OFF kalıcı durumda saklanır ve geri yüklenir", Act.MITM_OFF in q.active())
    val idle = ArrayList<Immune.Change>(); var tt = t
    repeat(60) { tt += MIN; idle += im.tick(tt) { true } }
    T.check("sakinlikte MITM_OFF geri alınır (kip yeniden denenebilir)", idle.any { it.act == Act.MITM_OFF && !it.on } && im.active().isEmpty())
    val no = Immune(Random(2)); var t3 = 1_000_000L; var bad = false
    repeat(10) { t3 += MIN; no.report(Threat.PROXY_FAIL, 5.0, t3 - 500); if (no.tick(t3) { it != Act.MITM_OFF }.any { it.on }) bad = true }
    T.check("kip kapalıyken (uygulanamaz) MITM_OFF seçilmez", !bad && no.active().isEmpty())

    for (seed in 1L..(6L * DEEP_X)) {
        val s = Immune(Random(seed)); var now = 1_000_000L
        repeat(8) { now += MIN; for (th in Threat.values()) s.report(th, 40.0, now - 300); s.tick(now) { true } }
        now += MIN; for (th in Threat.values()) s.report(th, 80.0, now - 100)
        val ch = s.tick(now) { true }.filter { it.on }
        T.check("seed $seed: tüm tehditler aynı anda aşırı şiddetliyken tek turda ≤ ${Immune.MAX_SEVERE_PER_TICK} önlem", ch.size <= Immune.MAX_SEVERE_PER_TICK, ch.toString())
    }
}
