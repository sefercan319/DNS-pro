package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.KeyStore
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLServerSocket
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManagerFactory

private val LOOP: InetAddress = InetAddress.getLoopbackAddress()

private fun trustCtx(ca: MitmCa?): SSLContext {
    val ks = KeyStore.getInstance(KeyStore.getDefaultType()); ks.load(null, null)
    // Gerçek istemci CA'mızı bilmese de başka güvenilir CA'ları vardır (boş güven deposu JDK'da internal_error uyarısı üretir, gerçekçi değil).
    ks.setCertificateEntry("ca", (ca ?: MitmCa.generate()).cert)
    val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()); tmf.init(ks)
    return SSLContext.getInstance("TLS").also { it.init(null, tmf.trustManagers, null) }
}

/** Sahte "gerçek sunucu": [host] için [originCa] imzalı sertifikayla TLS konuşur, [handler] ham isteği alıp cevabı yazar. */
private class Origin(originCa: MitmCa, host: String, val handler: (java.io.InputStream, java.io.OutputStream, ByteArray) -> Unit) : AutoCloseable {
    val ss = originCa.serverContext(host)!!.serverSocketFactory.createServerSocket(0, 20, LOOP) as SSLServerSocket
    val requests = java.util.concurrent.LinkedBlockingQueue<String>()
    init {
        Thread({
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (_: Exception) { break }
                Thread({
                    try {
                        s.soTimeout = 5000
                        val ins = s.getInputStream(); val buf = ByteArray(8192); val n = ins.read(buf)
                        if (n > 0) { requests.add(String(buf, 0, n, Charsets.ISO_8859_1)); handler(ins, s.getOutputStream(), buf.copyOf(n)); s.getOutputStream().flush() }
                    } catch (_: Exception) {} finally { try { s.close() } catch (_: Exception) {} }
                }).also { it.isDaemon = true }.start()
            }
        }).also { it.isDaemon = true }.start()
    }
    override fun close() { ss.close() }
}

private fun http(status: String, ctype: String, body: String, extra: String = "") =
    ("HTTP/1.1 $status\r\nContent-Type: $ctype\r\nContent-Length: ${body.toByteArray(Charsets.UTF_8).size}\r\n$extra\r\n").toByteArray(Charsets.ISO_8859_1) + body.toByteArray(Charsets.UTF_8)

private fun chunkedHtml(body: String, extra: String = ""): ByteArray {
    val o = ByteArrayOutputStream()
    o.write("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nTransfer-Encoding: chunked\r\n$extra\r\n".toByteArray())
    var i = 0
    while (i < body.length) { val c = body.substring(i, minOf(body.length, i + 37)); o.write("${c.toByteArray().size.toString(16)}\r\n$c\r\n".toByteArray()); i += 37 }
    o.write("0\r\n\r\n".toByteArray())
    return o.toByteArray()
}

/** [clientTrust] güvenen bir istemci olarak vekile bağlanıp [req] gönderir; (el sıkışma başarılı mı, ham cevap) döner. */
private fun viaProxy(p: MitmProxy, host: String, clientTrust: MitmCa?, req: String): Pair<Boolean, String> {
    val raw = Socket()
    raw.bind(InetSocketAddress(LOOP, 0))
    p.expect(raw.localPort, host, LOOP, 443)
    raw.connect(InetSocketAddress(LOOP, p.port), 3000)
    val s = trustCtx(clientTrust).socketFactory.createSocket(raw, host, p.port, true) as SSLSocket
    val prm = s.sslParameters; prm.endpointIdentificationAlgorithm = "HTTPS"; s.sslParameters = prm
    s.soTimeout = 6000
    try { s.startHandshake() } catch (e: Exception) { try { s.close() } catch (_: Exception) {}; return false to e.javaClass.simpleName }
    s.outputStream.write(req.toByteArray()); s.outputStream.flush()
    val o = ByteArrayOutputStream(); val b = ByteArray(8192)
    try { while (true) { val n = s.inputStream.read(b); if (n < 0) break; o.write(b, 0, n) } } catch (_: Exception) {}
    try { s.close() } catch (_: Exception) {}
    return true to String(o.toByteArray(), Charsets.ISO_8859_1)
}

private fun bodyOf(r: String) = r.substringAfter("\r\n\r\n", "")
private fun headOf(r: String) = r.substringBefore("\r\n\r\n")

fun runMitmTests() {
    T.group("Tarayıcı kipi: yerel CA")
    run {
        val on = AppSettings().copy(mitmOn = true, dpiListedOnly = true)
        val code = SettingsCodec.export(on)
        val back = SettingsCodec.import(code, AppSettings())
        T.check("dpiListedOnly dışa/içe aktarımda korunur", back != null && back.dpiListedOnly)
        T.check("mitmOn dışa aktarılmaz, içe aktarımla açılamaz (kullanıcı onayı yalnızca bu cihazda)", back != null && !back.mitmOn &&
            SettingsCodec.import(code, AppSettings().copy(mitmOn = true))?.mitmOn == true)
        T.check("mitmOn yerel depoya yazılıp okunur", SettingsCodec.decode(SettingsCodec.encode(on)).mitmOn)
    }
    val ca = MitmCa.generate()
    T.check("CA kendi kendine imzalı ve CA:TRUE", ca.cert.basicConstraints >= 0 && ca.cert.subjectX500Principal == ca.cert.issuerX500Principal)
    ca.cert.verify(ca.cert.publicKey)
    T.check("CA anahtar kullanımı: yalnızca sertifika imzalama", ca.cert.keyUsage?.let { it[5] && !it[0] } == true, ca.cert.keyUsage?.toList().toString())
    val chain = ca.leaf("site.example.com")!!
    chain[0].verify(chain[1].publicKey); chain[1].verify(ca.cert.publicKey)
    T.check("yaprak ara CA'nın, ara CA kökün imzasıyla doğrulanır (kök anahtarı cihazda yok)", chain.size == 2 && chain[1].basicConstraints == 0 && ca.cert.basicConstraints == 1)
    T.check("yaprak CA:FALSE ve sunucu kimlik doğrulama", chain[0].basicConstraints == -1 && chain[0].extendedKeyUsage?.contains("1.3.6.1.5.5.7.3.1") == true)
    T.check("yaprakta SAN adı var", chain[0].subjectAlternativeNames?.any { it[0] == 2 && it[1] == "site.example.com" } == true)
    T.check("yaprak ömrü ≤ 31 gün", chain[0].notAfter.time - chain[0].notBefore.time <= 32 * MitmCa.DAY)
    T.check("geçersiz adlar reddedilir", listOf("", "x", "a b.com", "evil.com\r\n", "-a.com", "a..com", "*.example.com", "a".repeat(300) + ".com", "ü.com").all { ca.leaf(it) == null })
    T.check("PEM biçimi", ca.pem().startsWith("-----BEGIN CERTIFICATE-----\n") && ca.pem().trimEnd().endsWith("-----END CERTIFICATE-----"))
    val back = MitmCa.load(ca.keyBytes(), ca.certDer(), ca.interDer())
    T.check("kayıtlı anahtar+sertifika geri yüklenir ve aynı sertifikayı üretir", back != null && back.cert == ca.cert)
    T.check("başka CA'nın anahtarıyla yükleme reddedilir", MitmCa.load(MitmCa.generate().keyBytes(), ca.certDer(), ca.interDer()) == null)
    T.check("bozuk veri çökertmez", MitmCa.load(ByteArray(10), ByteArray(10), ByteArray(10)) == null && MitmCa.load(ByteArray(0), ByteArray(0), ByteArray(0)) == null)
    T.check("süresi dolmak üzere olan CA yenilenmek üzere reddedilir", MitmCa.load(ca.keyBytes(), ca.certDer(), ca.interDer(), System.currentTimeMillis() + 3640 * MitmCa.DAY) == null)

    T.group("Tarayıcı kipi: kozmetik kurallar")
    val c = Cosmetic.parse("""
        ! yorum
        example.com##.ad-banner
        example.com###top
        a.example.org,b.example.org##div[data-ad="x"] > span
        ##.genel
        ~example.com##.ters
        example.com#@#.istisna
        example.com##.k{color:red}
        example.com##</style><script>alert(1)</script>
        example.com##.a;b
        example.com##+js(abort)
        *.example.com##.joker
    """.trimIndent())
    T.check("güvenli kurallar okunur", c.has("example.com") && c.has("a.example.org") && c.has("b.example.org"))
    T.check("genel/ters/istisna/joker kuralı alınmaz", !c.has("ters") && c.domains().none { it.startsWith("~") || it.startsWith("*") || it.isEmpty() })
    val css = c.css("www.example.com")
    T.check("alt alan adı üst alanın kurallarını alır", css.contains(".ad-banner{display:none!important}") && css.contains("#top{"), css)
    T.check("tehlikeli seçiciler (kural/etiket enjeksiyonu) reddedilir", !css.contains("<") && !css.contains("color:red") && !css.contains("alert") && !css.contains(";b") && !css.contains("abort"), css)
    T.check("kuralı olmayan ad için boş", c.css("other.net").isEmpty() && !c.has("other.net"))
    T.check("yerleşik kurallar: mobil YouTube ve Reddit", Cosmetic.BUILTIN.css("m.youtube.com").contains("ytm-promoted-video-renderer") && Cosmetic.BUILTIN.has("www.reddit.com"))
    T.check("yerleşik kurallar YouTube için var", Cosmetic.BUILTIN.has("m.youtube.com") && Cosmetic.BUILTIN.css("www.youtube.com").contains("ytd-ad-slot-renderer"))
    T.check("tarayıcı paket adları geçerli", Cosmetic.BROWSERS.all { AppScopes.validPkg(it) })
    T.check("dev girdi sınırlıdır", Cosmetic.parse("a.com##.x\n".repeat(300_000)).size() == 0 && Cosmetic.parse((1..2000).joinToString("\n") { "a.com##.s$it" }).css("a.com").split("}").size <= Cosmetic.MAX_SELECTORS + 1)
    T.check("inject: </head> öncesine, nonce'lu", String(MitmProxy.inject("<html><head><title>x</title></head><body>ü</body></html>".toByteArray(), "p{}", "abc"), Charsets.UTF_8)
        .contains("<style nonce=\"abc\">p{}</style></head><body>ü</body>"))
    val nh = "plain".toByteArray()
    T.check("inject: yer yoksa girdi aynen", MitmProxy.inject(nh, "p{}", null) === nh)

    T.group("Tarayıcı kipi: TLS vekili (uçtan uca)")
    val originCa = MitmCa.generate()
    val host = "site.example.com"
    val rules = Cosmetic.parse("example.com##.ad-banner")
    val page = "<html><head><title>t</title></head><body><div class=\"ad-banner\">reklam</div><p>Merhaba ü</p></body></html>"
    var hits = 0
    Origin(originCa, host) { _, out, _ -> hits++; out.write(http("200 OK", "text/html; charset=utf-8", page, "Connection: keep-alive\r\nContent-Security-Policy: default-src 'self'; style-src 'nonce-QWJD123'\r\n")) }.use { origin ->
        MitmProxy(ca, rules, { _, _ -> Socket(LOOP, origin.ss.localPort) }, { trustCtx(originCa).socketFactory }).use { p ->
            p.start()
            val (ok, r) = viaProxy(p, host, ca, "GET /index.html HTTP/1.1\r\nHost: $host\r\nAccept-Encoding: gzip, br\r\nConnection: keep-alive\r\n\r\n")
            T.check("güvenen istemci el sıkışır, 200 alır", ok && r.startsWith("HTTP/1.1 200"), r.take(80))
            val body = bodyOf(r); val head = headOf(r)
            T.check("CSS </head> öncesine, CSP nonce'uyla eklenir", body.contains("<style nonce=\"QWJD123\">") && body.contains(".ad-banner{display:none!important}</style></head>"), body)
            T.check("özgün gövde korunur (UTF-8 dahil)", String(body.toByteArray(Charsets.ISO_8859_1), Charsets.UTF_8).contains("<p>Merhaba ü</p>"))
            T.check("Content-Length yeni gövdeyle uyumlu, Connection: close", Regex("(?i)content-length: (\\d+)").find(head)?.groupValues?.get(1)?.toInt() == body.toByteArray(Charsets.ISO_8859_1).size && head.contains("Connection: close"), head)
            T.check("CSP başlığı silinmez", head.contains("Content-Security-Policy"))
            val up = origin.requests.poll()
            T.check("sunucuya sıkıştırma istenmez, bağlantı kapalı istenir", up != null && up.contains("Accept-Encoding: identity") && !up.contains("gzip") && up.contains("Connection: close"), up)
            T.check("sayaç: 1 enjekte", p.injected() == 1L && p.handled() == 1L)

            val (ok2, r2) = viaProxy(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n")
            T.check("ikinci bağlantı (yeni TLS) de çalışır", ok2 && bodyOf(r2).contains("display:none"))
        }
    }
    Origin(originCa, host) { _, out, _ -> out.write(chunkedHtml(page)) }.use { origin ->
        MitmProxy(ca, rules, { _, _ -> Socket(LOOP, origin.ss.localPort) }, { trustCtx(originCa).socketFactory }).use { p ->
            p.start()
            val (_, r) = viaProxy(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n")
            T.check("chunked HTML çözülüp enjekte edilir, tek parça Content-Length ile", bodyOf(r).contains("display:none") && bodyOf(r).contains("<p>Merhaba") && !headOf(r).lowercase().contains("transfer-encoding"), r.take(200))
        }
    }
    val json = "{\"a\":1}"
    Origin(originCa, host) { _, out, _ -> out.write(http("200 OK", "application/json", json)) }.use { origin ->
        MitmProxy(ca, rules, { _, _ -> Socket(LOOP, origin.ss.localPort) }, { trustCtx(originCa).socketFactory }).use { p ->
            p.start()
            val (_, r) = viaProxy(p, host, ca, "GET /api HTTP/1.1\r\nHost: $host\r\n\r\n")
            T.check("HTML olmayan cevap aynen geçer, enjekte yok", bodyOf(r) == json && p.injected() == 0L, r)
        }
    }
    Origin(originCa, host) { _, out, _ -> out.write(http("404 Not Found", "text/html", page)) }.use { origin ->
        MitmProxy(ca, rules, { _, _ -> Socket(LOOP, origin.ss.localPort) }, { trustCtx(originCa).socketFactory }).use { p ->
            p.start()
            val (_, r) = viaProxy(p, host, ca, "GET /yok HTTP/1.1\r\nHost: $host\r\n\r\n")
            T.check("200 dışı cevaba dokunulmaz (404 aynen)", r.startsWith("HTTP/1.1 404") && !bodyOf(r).contains("display:none"), r.take(60))
            val (_, r2) = viaProxy(p, host, ca, "POST /f HTTP/1.1\r\nHost: $host\r\nContent-Length: 3\r\n\r\nabc")
            T.check("POST cevabına dokunulmaz", !bodyOf(r2).contains("display:none"))
        }
    }

    T.group("Tarayıcı kipi: güvenlik (vekil kendisi saldırı yüzeyi olmamalı)")
    // 1) İstemci CA'ya güvenmiyor (ör. tarayıcı olmayan uygulama): el sıkışma başarısız, ad muaf tutulur
    Origin(originCa, host) { _, out, _ -> out.write(http("200 OK", "text/html", page)) }.use { origin ->
        val dbg = java.util.concurrent.CopyOnWriteArrayList<String>()
        MitmProxy(ca, rules, { _, _ -> Socket(LOOP, origin.ss.localPort) }, { trustCtx(originCa).socketFactory }, log = { dbg.add(it) }).use { p ->
            p.start()
            T.check("başlangıçta ad vekile yönlendirilebilir", p.wantsHost(host))
            val (ok, why) = viaProxy(p, host, null, "GET / HTTP/1.1\r\n\r\n")
            Thread.sleep(150)
            T.check("güvenmeyen istemci el sıkışamaz", !ok, why)
            T.check("başarısız ad vekilden muaf (uygulama kendini toparlar)", !p.wantsHost(host) && p.failed() >= 1L, p.summary() + " ret=" + p.certRejects() + " why=" + why + " log=" + dbg)
            T.check("kuralı olmayan ad zaten istenmez", !p.wantsHost("other.net"))
        }
    }
    // 2) Gerçek sunucunun sertifikası güvenilmez zincirden: vekil istemciye HİÇBİR cevap vermez, enjekte etmez
    val rogue = MitmCa.generate()
    Origin(rogue, host) { _, out, _ -> out.write(http("200 OK", "text/html", page)) }.use { origin ->
        MitmProxy(ca, rules, { _, _ -> Socket(LOOP, origin.ss.localPort) }, { trustCtx(originCa).socketFactory }).use { p ->
            p.start()
            val (ok, r) = viaProxy(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n")
            T.check("güvenilmeyen sunucu sertifikasında istemciye sahte içerik verilmez", !ok || !r.startsWith("HTTP/1.1 200"), r.take(60))
            T.check("hata sayıldı, enjekte yok", p.failed() >= 1L && p.injected() == 0L)
        }
    }
    // 3) Sertifika ADI uymuyor (doğru zincir, başka alan adı)
    Origin(originCa, "baska.example.com") { _, out, _ -> out.write(http("200 OK", "text/html", page)) }.use { origin ->
        MitmProxy(ca, rules, { _, _ -> Socket(LOOP, origin.ss.localPort) }, { trustCtx(originCa).socketFactory }).use { p ->
            p.start()
            val (ok, r) = viaProxy(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n")
            T.check("sertifika adı uyuşmayan sunucu reddedilir (ad doğrulaması açık)", !ok || !r.startsWith("HTTP/1.1 200"), r.take(60))
        }
    }
    // 4) Beklenmeyen bağlantı: kayıtsız yerel port vekile bağlanırsa kapatılır
    MitmProxy(ca, rules, { _, _ -> throw java.io.IOException("olmamalı") }).use { p ->
        p.start()
        val s = Socket(LOOP, p.port)
        s.soTimeout = 3000
        val n = try { s.getInputStream().read() } catch (_: Exception) { -1 }
        T.check("kayıtsız bağlantı hemen kapatılır", n == -1)
        s.close()
    }
    // 5) Aşırı büyük başlık / sahte uzunluk çökertmez
    Origin(originCa, host) { _, out, _ -> out.write("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 99999999\r\n\r\n<html>".toByteArray()) }.use { origin ->
        MitmProxy(ca, rules, { _, _ -> Socket(LOOP, origin.ss.localPort) }, { trustCtx(originCa).socketFactory }).use { p ->
            p.start()
            val (_, r) = viaProxy(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n")
            T.check("devasa Content-Length gövde belleğe alınmaz (aynen geçer)", !r.contains("display:none"), r.take(60))
        }
    }
    Origin(originCa, host) { _, out, _ -> out.write(http("200 OK", "text/html; charset=utf-16", page)) }.use { origin ->
        MitmProxy(ca, rules, { _, _ -> Socket(LOOP, origin.ss.localPort) }, { trustCtx(originCa).socketFactory }).use { p ->
            p.start()
            val (_, r) = viaProxy(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n")
            T.check("UTF-16 gibi uyumsuz karakter kümesi bozulmaz (enjekte yok)", !bodyOf(r).contains("display:none"))
        }
    }
    val ctr = java.util.concurrent.atomic.AtomicInteger()
    Origin(originCa, host) { _, out, _ -> ctr.incrementAndGet(); out.write(http("200 OK", "text/html", page)) }.use { origin ->
        MitmProxy(ca, rules, { _, _ -> Socket(LOOP, origin.ss.localPort) }, { trustCtx(originCa).socketFactory }).use { p ->
            p.start()
            val rs = (1..30).map { i -> Thread { viaProxy(p, host, ca, "GET /$i HTTP/1.1\r\nHost: $host\r\n\r\n") }.also { it.start() } }
            rs.forEach { it.join(15000) }
            T.check("30 eşzamanlı bağlantı: hepsi işlendi", p.handled() == 30L && p.injected() == 30L, p.summary())
        }
    }
}

/** CA Ad Kısıtı: anahtar sızsa bile CA yalnızca kural alanları için geçerli sertifika üretebilir (JDK PKIX ile doğrulanır). */
fun runMitmNameConstraintTests() {
    T.group("Tarayıcı kipi: CA Ad Kısıtı (sızan anahtar başka siteleri taklit edemez)")
    val doms = Cosmetic.BUILTIN.domains()
    val ca = MitmCa.generate(doms)
    fun valid(host: String, c: MitmCa = ca): Boolean = try {
        val chain = c.leaf(host)!!
        val cf = java.security.cert.CertificateFactory.getInstance("X.509")
        val path = cf.generateCertPath(chain.toList())
        val params = java.security.cert.PKIXParameters(setOf(java.security.cert.TrustAnchor(c.cert, null))).also { it.isRevocationEnabled = false }
        java.security.cert.CertPathValidator.getInstance("PKIX").validate(path, params); true
    } catch (_: Exception) { false }
    T.check("kritik Ad Kısıtı ara sertifikada, kökte yok", ca.leaf("youtube.com")!![1].criticalExtensionOIDs?.contains("2.5.29.30") == true && ca.cert.criticalExtensionOIDs?.contains("2.5.29.30") != true)
    T.check("kural alanı ve alt alanı geçerli", valid("youtube.com") && valid("www.youtube.com") && valid("m.youtube.com") && valid("old.reddit.com"))
    T.check("başka site için imzalanan sertifika GEÇERSİZ (bank.example.com, google.com)", !valid("bank.example.com") && !valid("google.com") && !valid("accounts.google.com"), listOf("bank.example.com", "google.com", "accounts.google.com").filter { valid(it) }.toString())
    T.check("sonek tuzağı: notyoutube.com ve youtube.com.evil.net geçersiz", !valid("notyoutube.com") && !valid("youtube.com.evil.net") && !valid("xreddit.com"), listOf("notyoutube.com", "youtube.com.evil.net", "xreddit.com").filter { valid(it) }.toString())
    val open = MitmCa.generate()
    T.check("kıyas: kısıtsız CA her siteyi imzalar (kısıt gerçekten işe yarıyor)", valid("google.com", open))
    T.check("yükleme: aynı liste kabul", MitmCa.load(ca.keyBytes(), ca.certDer(), ca.interDer(), domains = doms) != null)
    T.check("yükleme: liste değiştiyse eski CA reddedilir (yenisi üretilir)", MitmCa.load(ca.keyBytes(), ca.certDer(), ca.interDer(), domains = doms + "yeni.example.org") == null)
    T.check("yükleme: kısıtsız eski CA, kısıt beklenirken reddedilir", MitmCa.load(open.keyBytes(), open.certDer(), open.interDer(), domains = doms) == null)
    T.check("liste sırası/büyük harf kararlılığı", MitmCa.load(ca.keyBytes(), ca.certDer(), ca.interDer(), domains = doms.reversed().map { it.uppercase() }) != null)
}

/**
 * Sızma girişimleri (saldırgan gözüyle): kötü niyetli ORIJIN sunucu (sıkıştırılmış gövde, CSP nonce ile enjeksiyon, bitmeyen başlık),
 * kötü niyetli İSTEMCI/yerel uygulama (hedef değiştirme, vekili bağlantıyla tıkama, dev başlık).
 */
fun runRedTeamMitmTests() {
    T.group("Sızma girişimi: tarayıcı kipi vekili (kötü sunucu, kötü istemci, yerel uygulama)")
    val ca = MitmCa.generate(); val originCa = MitmCa.generate(); val host = "site.example.com"
    val rules = Cosmetic.parse("example.com##.ad-banner")
    val page = "<html><head><title>t</title></head><body><div class=\"ad-banner\">x</div></body></html>"
    fun withProxy(handler: (java.io.InputStream, java.io.OutputStream, ByteArray) -> Unit, connects: MutableList<Pair<java.net.InetAddress, Int>>? = null, body: (MitmProxy, Origin) -> Unit) {
        Origin(originCa, host, handler).use { o ->
            MitmProxy(ca, rules, { a, pt -> connects?.add(a to pt); Socket(LOOP, o.ss.localPort) }, { trustCtx(originCa).socketFactory }).use { p -> p.start(); body(p, o) }
        }
    }

    // 1) Sıkıştırılmış gövde: "identity" istenmesine rağmen sunucu gzip gönderirse gövdeye DOKUNULMAZ (bozuk bayt üretilmez)
    val fakeGz = "GZIP-garbage-bytes</head>more"
    withProxy({ _, out, _ -> out.write(http("200 OK", "text/html", fakeGz, "Content-Encoding: gzip\r\n")) }) { p, _ ->
        val (_, r) = viaProxy(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n")
        T.check("gzip cevabına enjekte edilmez, bayt bayt aynı", bodyOf(r) == fakeGz && !r.contains("display:none") && p.injected() == 0L)
    }
    // 2) Kötü CSP nonce'u: tırnak/etiket içeren nonce, enjekte edilen <style> etiketinden KAÇAMAZ
    val evilNonce = "abc\"><img src=x onerror=alert(1)>"
    withProxy({ _, out, _ -> out.write(http("200 OK", "text/html", page, "Content-Security-Policy: style-src 'nonce-$evilNonce'\r\n")) }) { p, _ ->
        val (_, r) = viaProxy(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n")
        val b = bodyOf(r)
        T.check("CSP nonce'undan etiket kaçışı yok (onerror/<img sızmaz)", !b.contains("onerror") && !b.contains("<img src=x"), b.take(200))
    }
    // 3) İstemci hedef değiştirmeye çalışır (mutlak URI, farklı Host): vekil YALNIZCA ağ geçidinin bildirdiği hedefe bağlanır
    val connects = java.util.concurrent.CopyOnWriteArrayList<Pair<java.net.InetAddress, Int>>()
    withProxy({ _, out, _ -> out.write(http("200 OK", "text/html", page)) }, connects) { p, o ->
        viaProxy(p, host, ca, "GET https://evil.example.net:8443/steal HTTP/1.1\r\nHost: evil.example.net\r\n\r\n")
        T.check("tek bağlantı, yalnızca beklenen adres:port (443)", connects.size == 1 && connects[0].second == 443 && connects[0].first == LOOP, connects.toString())
    }
    // 4) Yerel kötü niyetli uygulama: kayıtsız bağlantılarla vekili tıkamaya çalışır; meşru istek yine çalışır
    withProxy({ _, out, _ -> out.write(http("200 OK", "text/html", page)) }) { p, _ ->
        val rogue = ArrayList<Socket>()
        try {
            repeat(400) { try { rogue += Socket(LOOP, p.port).also { s -> if (it % 2 == 0) s.getOutputStream().write(ByteArray(64) { b -> b.toByte() }) } } catch (_: Exception) {} }
            val t0 = System.nanoTime()
            val (ok, r) = viaProxy(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n")
            T.check("400 kayıtsız bağlantıdan sonra meşru istek enjekte edilmiş cevap alır", ok && bodyOf(r).contains("display:none"), r.take(60))
            T.check("gecikme makul (< 4 sn)", (System.nanoTime() - t0) / 1_000_000 < 4000)
        } finally { rogue.forEach { try { it.close() } catch (_: Exception) {} } }
    }
    // 5) Dev istek başlığı (200 KB): sunucuya hiç gitmez, vekil ayakta kalır
    withProxy({ _, out, _ -> out.write(http("200 OK", "text/html", page)) }) { p, o ->
        val (ok0, _) = try { viaProxy(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\nX-Big: " + "A".repeat(200_000) + "\r\n\r\n") } catch (_: Exception) { false to "" }
        Thread.sleep(150)
        T.check("dev başlık sunucuya iletilmedi", o.requests.isEmpty() || !o.requests.peek().contains("AAAAAAAAAAAAAAAAAAAAAAAA"), ok0.toString())
        val (ok, r) = viaProxy(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n")
        T.check("saldırıdan sonra vekil çalışmaya devam eder", ok && bodyOf(r).contains("display:none"))
    }
    // 6) Kötü sunucu: bitmeyen başlık (CRLFCRLF yok, 3 MB) — vekil bellekte biriktirmeden keser
    withProxy({ _, out, _ -> val junk = ByteArray(65536) { 'A'.code.toByte() }; try { out.write("HTTP/1.1 200 OK\r\nX: ".toByteArray()); repeat(48) { out.write(junk) } } catch (_: Exception) {} }) { p, _ ->
        val t0 = System.nanoTime()
        val (_, r) = try { viaProxy(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n") } catch (_: Exception) { false to "" }
        T.check("bitmeyen başlık istemciye geçmez/enjekte edilmez, hızlı biter", !r.contains("display:none") && (System.nanoTime() - t0) / 1_000_000 < 8000, "${r.length} bayt")
    }
    // 7) Beklenti tablosu şişirilemez
    withProxy({ _, out, _ -> out.write(http("200 OK", "text/html", page)) }) { p, _ ->
        repeat(20_000) { p.expect(10_000 + it, "a$it.example.com", LOOP, 443) }
        val (ok, _) = viaProxy(p, host, ca, "GET / HTTP/1.1\r\nHost: $host\r\n\r\n")
        T.check("20 bin beklenti sonrası vekil çökmez (üst sınır korur)", ok)
    }
}
