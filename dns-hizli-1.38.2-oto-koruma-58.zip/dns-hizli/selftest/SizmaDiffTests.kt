package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.lang.reflect.InvocationHandler
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Proxy
import java.nio.ByteBuffer
import java.util.Random

/**
 * Sızma 12 — çapraz doğrulama (differential) testleri. Kod kendi kodu ya da kendi anlayışımla değil BAĞIMSIZ bir referansla karşılaştırılır:
 *  1) HPACK: JDK'nın kendi HPACK kodlayıcı/çözücüsü (java.net.http iç sınıfları, yansıma ile) gerçek sunucuların yaptığı gibi dinamik tablo,
 *     Huffman, duyarlı alan ve tablo boyutu güncellemeleriyle başlık blokları üretir; çözücümüz birebir aynısını vermeli. Huffman tablomuz
 *     256 baytın hepsi için JDK çözücüsüne okutulur (tek bir yazım hatası bile yakalanır). Bozuk bloklarda çözücümüz, RFC 7541'den bağımsız
 *     yazılmış bir referansla (bit bit Huffman çözücü + blok tarayıcı) ve JDK ile karşılaştırılır. JDK iki yerde RFC'den GEVŞEKTİR (7 bitten uzun /
 *     EOS olmayan Huffman doldurmasını ve blok ortasındaki tablo boyutu güncellemesini kabul eder); biz RFC'ye göre sıkıyız (nghttp2 ve Go da öyle):
 *     bu fark yalnızca referans o ihlali gösteriyorsa ve doğru nedenle reddettiysek kabul edilir.
 *  2) Public Suffix List: `registrableStart` / `isIcannSuffix`, psl.txt'den spesifikasyona göre yazılmış saf bir referansla (listeyi tarayan,
 *     özet kullanmayan) karşılaştırılır.
 *  3) Süzgeç: izin > kanarya > engel > korunan > liste önceliği ve etiket sınırında son-ek eşleşmesi küme modeliyle (hem metin hem tel biçimi
 *     yolu); büyük (kova dizinli) katman düz kümeyle karşılaştırılır.
 * HPACK bölümü JDK iç sınıflarına erişim ister (`--add-exports java.net.http/jdk.internal.net.http.hpack=ALL-UNNAMED`, run-tests.sh ekler);
 * erişilemezse bölüm atlanır (başarısız sayılmaz) ve nedeni yazılır.
 */
fun runDifferentialTests() {
    hpackDifferentialTests()
    pslDifferentialTests()
    filterDifferentialTests()
}

// =============================================================================================== HPACK

private class JdkHpack private constructor(
    private val encCtor: java.lang.reflect.Constructor<*>,
    private val headerM: java.lang.reflect.Method,
    private val encodeM: java.lang.reflect.Method,
    private val capM: java.lang.reflect.Method,
    private val decCtor: java.lang.reflect.Constructor<*>,
    private val decodeM: java.lang.reflect.Method,
    private val cbCls: Class<*>,
) {
    /** JDK çözücüsünün geri çağırmalarından sayılanlar: Huffman bayraklı dizgiler ve tablo boyutu güncellemeleri (kapsama kanıtı). */
    var huffSeen = 0
    var sizeUpdates = 0

    companion object {
        var whyNot = ""

        /** JDK iç HPACK'e erişilemezse (sürüm ya da --add-exports yok) null; nedeni [whyNot]. */
        fun open(): JdkHpack? = try {
            val pkg = "jdk.internal.net.http.hpack."
            val enc = Class.forName(pkg + "Encoder")
            val dec = Class.forName(pkg + "Decoder")
            val cb = Class.forName(pkg + "DecodingCallback")
            val int = Int::class.javaPrimitiveType
            val j = JdkHpack(
                enc.getConstructor(int),
                enc.getMethod("header", CharSequence::class.java, CharSequence::class.java, Boolean::class.javaPrimitiveType),
                enc.getMethod("encode", ByteBuffer::class.java),
                enc.getMethod("setMaxCapacity", int),
                dec.getConstructor(int),
                dec.getMethod("decode", ByteBuffer::class.java, Boolean::class.javaPrimitiveType, cb),
                cb,
            )
            j.smoke()
            j
        } catch (e: Throwable) { whyNot = "${e.javaClass.simpleName}: ${e.message}"; null }
    }

    /** Referansın kendisi çalışıyor mu: JDK ile kodla, JDK ile çöz. */
    private fun smoke() {
        val hs = listOf(Triple("x-a", "bcd", false), Triple("x-a", "bcd", false), Triple("x-b", "k".repeat(40), true))
        val block = encode(newEncoder(4096), hs, 64)
        val got = decode(newDecoder(4096), block)
        check(got == hs.map { it.first to it.second }) { "JDK HPACK kendi bloğunu geri veremedi: $got" }
    }

    fun newEncoder(cap: Int): Any = encCtor.newInstance(cap)
    fun newDecoder(cap: Int): Any = decCtor.newInstance(cap)
    fun setCapacity(enc: Any, cap: Int) { try { capM.invoke(enc, cap) } catch (e: InvocationTargetException) { throw e.targetException } }

    /** Başlıkları (ad, değer, duyarlı) JDK kodlayıcısıyla tek bir blokta kodlar; çıktı arabelleği küçük (kısmi yazma yolları da çalışsın). */
    fun encode(enc: Any, hs: List<Triple<String, String, Boolean>>, bufSize: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteBuffer.allocate(bufSize)
        for ((n, v, sens) in hs) {
            try { headerM.invoke(enc, n, v, sens) } catch (e: InvocationTargetException) { throw e.targetException }
            var guard = 0
            do {
                buf.clear()
                val done = try { encodeM.invoke(enc, buf) as Boolean } catch (e: InvocationTargetException) { throw e.targetException }
                buf.flip()
                out.write(buf.array(), 0, buf.limit())
                if (++guard > 100_000) throw IllegalStateException("JDK kodlayıcısı bitmiyor")
            } while (!done)
        }
        return out.toByteArray()
    }

    /** Bir bloğu JDK çözücüsüyle çözer; hata atarsa istisnayı olduğu gibi fırlatır. */
    fun decode(dec: Any, block: ByteArray): List<Pair<String, String>> {
        val got = ArrayList<Pair<String, String>>()
        val cb = Proxy.newProxyInstance(cbCls.classLoader, arrayOf(cbCls), InvocationHandler { proxy, m, args ->
            val a: Array<Any?> = args ?: arrayOfNulls(0)
            when {
                m.declaringClass == Any::class.java -> when (m.name) { "hashCode" -> System.identityHashCode(proxy); "equals" -> proxy === a.getOrNull(0); else -> "cb" }
                m.name == "onDecoded" && a.size == 2 -> { got.add(a[0].toString() to a[1].toString()); null }
                else -> {
                    if (m.name.startsWith("onLiteral")) for (x in a) if (x == true) huffSeen++
                    if (m.name == "onSizeUpdate") sizeUpdates++
                    if (m.isDefault) InvocationHandler.invokeDefault(proxy, m, *a) else null
                }
            }
        })
        try { decodeM.invoke(dec, ByteBuffer.wrap(block), true, cb) } catch (e: InvocationTargetException) { throw e.targetException }
        return got
    }
}

private class HdrGen(val rnd: Random) {
    private val history = ArrayList<Pair<String, String>>()
    private val common = listOf(":status", "content-type", "content-length", "cache-control", "date", "server", "vary", "etag", "age", "alt-svc",
        "access-control-allow-origin", "strict-transport-security", "content-encoding", "set-cookie", "location", "x-request-id")
    private val nameChars = "abcdefghijklmnopqrstuvwxyz0123456789-"

    private fun name(): String =
        if (rnd.nextInt(3) > 0) common[rnd.nextInt(common.size)] else String(CharArray(1 + rnd.nextInt(24)) { nameChars[rnd.nextInt(nameChars.length)] })

    private fun value(): String = when (rnd.nextInt(10)) {
        0 -> ""
        1 -> String(CharArray(100 + rnd.nextInt(800)) { (0x20 + rnd.nextInt(0xE0)).toChar() })                // uzun, Latin-1 (yüksek baytlar dahil)
        2, 3 -> rnd.nextInt(1_000_000).toString()
        4 -> String(CharArray(1 + rnd.nextInt(40)) { (0x80 + rnd.nextInt(0x80)).toChar() })                   // yalnızca yüksek baytlar (uzun Huffman kodları)
        else -> String(CharArray(1 + rnd.nextInt(60)) { (0x20 + rnd.nextInt(0x5F)).toChar() })
    }

    fun header(): Triple<String, String, Boolean> {
        val r = rnd.nextInt(10)
        val (n, v) = when {
            r < 4 && history.isNotEmpty() -> history[rnd.nextInt(history.size)]                                // aynı çift: indeksli alan
            r < 6 && history.isNotEmpty() -> history[rnd.nextInt(history.size)].first to value()               // aynı ad, yeni değer
            else -> name() to value()
        }
        history.add(n to v); if (history.size > 60) history.removeAt(0)
        return Triple(n, v, rnd.nextInt(12) == 0)
    }
}

private fun hex(b: ByteArray, n: Int = 48): String = b.take(n).joinToString("") { "%02x".format(it) } + if (b.size > n) "…(${b.size})" else ""

/** HPACK Huffman kodlayıcısı (RFC 7541 Ek B): tablo [HpackData]'dan; son bayt EOS önekiyle (1'ler) doldurulur. */
private fun huffEncode(src: ByteArray): ByteArray {
    val out = ByteArrayOutputStream()
    var acc = 0L
    var nb = 0
    for (x in src) {
        val c = x.toInt() and 0xFF
        val bits = HpackData.HUFF_BITS[c]
        acc = (acc shl bits) or (HpackData.HUFF_CODE[c].toLong() and ((1L shl bits) - 1))
        nb += bits
        while (nb >= 8) { out.write(((acc ushr (nb - 8)) and 0xFF).toInt()); nb -= 8 }
        acc = acc and ((1L shl nb) - 1)
    }
    if (nb > 0) { val pad = (1L shl (8 - nb)) - 1; out.write((((acc shl (8 - nb)) or pad) and 0xFF).toInt()) }
    return out.toByteArray()
}

/** HPACK tamsayısı (RFC 7541 §5.1): [flags] ilk baytın üst bitleri, [prefix] önek bit sayısı. */
private fun writeInt(o: ByteArrayOutputStream, flags: Int, prefix: Int, value: Int) {
    val max = (1 shl prefix) - 1
    if (value < max) { o.write(flags or value); return }
    o.write(flags or max)
    var v = value - max
    while (v >= 128) { o.write((v and 0x7F) or 0x80); v = v ushr 7 }
    o.write(v)
}

/** "x: <değer>" tek alanlı blok (ekleme yapmayan literal, yeni ad); değer Huffman ile ([huff] true) ya da düz kodlanır. */
private fun literalBlock(value: ByteArray, huff: Boolean): ByteArray {
    val v = if (huff) huffEncode(value) else value
    val o = ByteArrayOutputStream()
    o.write(0x00); o.write(0x01); o.write('x'.code)
    writeInt(o, if (huff) 0x80 else 0, 7, v.size); o.write(v)
    return o.toByteArray()
}

/** "x: <Huffman yükü>" bloğu; yük olduğu gibi (geçerli olmayabilir) konur. */
private fun rawHuffBlock(payload: ByteArray): ByteArray {
    val o = ByteArrayOutputStream()
    o.write(0x00); o.write(0x01); o.write('x'.code); writeInt(o, 0x80, 7, payload.size); o.write(payload)
    return o.toByteArray()
}

/**
 * RFC 7541 Ek B'ye göre, bizim çözücüden BAĞIMSIZ (ağaç yerine bit bit + özet tablosu) sıkı Huffman çözücü. Yalnızca kod tablosu ortak;
 * tablonun kendisi JDK'ya 256 sembolün hepsi okutularak ayrıca doğrulanır. §5.2: EOS içeren dizgi, 7 bitten uzun doldurma ve EOS öneki
 * (hep 1) olmayan doldurma hatadır.
 */
private object HuffRef {
    sealed class R {
        class Ok(val bytes: ByteArray) : R()
        object Pad : R()
        object Eos : R()
        object Code : R()
    }

    private val bySym = HashMap<Long, Int>()                          // (bit sayısı shl 32 | kod) → sembol

    init { for (s in 0..256) bySym[(HpackData.HUFF_BITS[s].toLong() shl 32) or HpackData.HUFF_CODE[s].toLong()] = s }

    fun decode(src: ByteArray, off: Int = 0, len: Int = src.size): R {
        val out = ByteArrayOutputStream()
        var code = 0L; var bits = 0; var allOnes = true
        for (i in off until off + len) for (k in 7 downTo 0) {
            val bit = (src[i].toInt() ushr k) and 1
            code = (code shl 1) or bit.toLong(); bits++
            if (bit == 0) allOnes = false
            if (bits > 30) return R.Code
            val sym = bySym[(bits.toLong() shl 32) or code] ?: continue
            if (sym == 256) return R.Eos
            out.write(sym); code = 0; bits = 0; allOnes = true
        }
        if (bits > 7 || (bits > 0 && !allOnes)) return R.Pad
        return R.Ok(out.toByteArray())
    }
}

/** [scanBlock] sonucu: bloğun RFC 7541'e göre hata sayılan yapısal özellikleri. */
private class BlockScan(val lateSize: Boolean, val badPad: Boolean, val eos: Boolean, val hStrings: List<IntArray>) {
    val violation: Boolean get() = lateSize || badPad || eos
}

/**
 * Bir HPACK bloğunu çözücüden BAĞIMSIZ, yalnızca sözdizimi düzeyinde tarar (dinamik tabloya bakmaz): alanlardan sonra gelen tablo boyutu
 * güncellemesi (§4.2/§6.3) ile geçersiz Huffman dizgilerini (§5.2) bulur. Blok kesik ya da tamsayısı bozuksa null.
 */
private fun scanBlock(b: ByteArray): BlockScan? {
    var pos = 0
    var sawField = false; var late = false; var badPad = false; var eos = false
    val hStrings = ArrayList<IntArray>()                              // Huffman dizgilerinin (başlangıç, uzunluk) konumları
    fun int(prefix: Int): Long {                                      // -1 = bozuk
        if (pos >= b.size) return -1
        val max = (1 shl prefix) - 1
        var v = (b[pos++].toInt() and max).toLong()
        if (v < max) return v
        var shift = 0
        while (true) {
            if (pos >= b.size || shift > 28) return -1
            val x = b[pos++].toInt() and 0xFF
            v += (x and 0x7F).toLong() shl shift
            if (v > Int.MAX_VALUE) return -1
            if (x and 0x80 == 0) return v
            shift += 7
        }
    }
    fun str(): Boolean {                                              // false = bozuk
        if (pos >= b.size) return false
        val huff = b[pos].toInt() and 0x80 != 0
        val n = int(7)
        if (n < 0 || pos + n > b.size) return false
        if (huff) {
            hStrings.add(intArrayOf(pos, n.toInt()))
            when (HuffRef.decode(b, pos, n.toInt())) { is HuffRef.R.Pad -> badPad = true; is HuffRef.R.Eos -> eos = true; else -> {} }
        }
        pos += n.toInt()
        return true
    }
    while (pos < b.size) {
        val f = b[pos].toInt() and 0xFF
        when {
            f and 0x80 != 0 -> { if (int(7) < 0) return null; sawField = true }                             // indeksli alan
            f and 0xE0 == 0x20 -> { if (int(5) < 0) return null; if (sawField) late = true }                  // tablo boyutu güncellemesi
            else -> {                                                                                         // literal (ekleyerek: 6 bit önek; ekleme yok / asla: 4 bit)
                val idx = int(if (f and 0x40 != 0) 6 else 4)
                if (idx < 0) return null
                if (idx == 0L && !str()) return null
                if (!str()) return null
                sawField = true
            }
        }
    }
    return BlockScan(late, badPad, eos, hStrings)
}

private sealed class Dec {
    class Ok(val fields: List<Pair<String, String>>) : Dec()
    class Err(val why: String) : Dec()
}

private fun oursDecode(block: ByteArray, cap: Int = 4096): Dec = try {
    Dec.Ok(HpackDecoder(cap).decode(block).map { it.name to it.value })
} catch (e: java.io.IOException) { Dec.Err("IOException ${e.message}") } catch (e: Throwable) { Dec.Err("ÇÖKME ${e.javaClass.simpleName}: ${e.message}") }

private fun jdkDecode(j: JdkHpack, block: ByteArray, cap: Int = 4096): Dec = try {
    Dec.Ok(j.decode(j.newDecoder(cap), block))
} catch (e: Throwable) { Dec.Err("${e.javaClass.simpleName}: ${e.message}") }

private class HuffStats {
    var n = 0; var refOk = 0; var oursBad = 0; var jdkBad = 0; var jdkLenient = 0
    var first = ""
}

/** Tek bir Huffman yükünü bağımsız referansa (karar ve çıktı), bizim çözücüye ve JDK'ya okutur. */
private fun huffCompare(j: JdkHpack, payload: ByteArray, st: HuffStats) {
    val block = rawHuffBlock(payload)
    val r = HuffRef.decode(payload)
    val mine = oursDecode(block)
    val theirs = jdkDecode(j, block)
    st.n++
    if (r is HuffRef.R.Ok) {
        st.refOk++
        val want = listOf("x" to String(r.bytes, Charsets.ISO_8859_1))
        if (!(mine is Dec.Ok && mine.fields == want)) { st.oursBad++; if (st.first.isEmpty()) st.first = "biz geçerli dizgiyi çözemedi: ${(mine as? Dec.Err)?.why ?: "farklı çıktı"} ${hex(block)}" }
        if (!(theirs is Dec.Ok && theirs.fields == want)) { st.jdkBad++; if (st.first.isEmpty()) st.first = "JDK geçerli dizgiyi çözemedi ya da farklı çözdü: ${(theirs as? Dec.Err)?.why ?: "farklı çıktı"} ${hex(block)}" }
    } else {                                                           // RFC'ye göre geçersiz: biz reddetmeliyiz; JDK kabul ederse gevşektir
        if (mine !is Dec.Err || mine.why.startsWith("ÇÖKME")) { st.oursBad++; if (st.first.isEmpty()) st.first = "geçersiz dizgi kabul edildi/çöktü ($r): ${hex(block)} → ${(mine as? Dec.Err)?.why ?: "kabul"}" }
        if (theirs is Dec.Ok) st.jdkLenient++
    }
}

private fun hpackDifferentialTests() {
    val j = JdkHpack.open()
    if (j == null) {
        println("  (JDK iç HPACK sınıflarına erişilemedi: ${JdkHpack.whyNot}; --add-exports java.net.http/jdk.internal.net.http.hpack=ALL-UNNAMED gerekir: HPACK çapraz doğrulaması atlandı)")
        return
    }

    // ---------------------------------------------------------------- 1) JDK kodlayıcı → bizim çözücü
    T.group("Sızma 12 / HPACK: JDK kodlayıcısı gerçek sunucu gibi (dinamik tablo, Huffman, duyarlı alan, boyut güncellemesi) → bizim çözücü birebir aynısını çözer")
    run {
        val rnd = Random(0x4A9ACC)
        val sessions = 400 + 100 * DEEP_X
        var blocks = 0; var fields = 0; var oursBad = 0; var jdkBad = 0; var agreeBad = 0
        var first = ""
        val huff0 = j.huffSeen; val upd0 = j.sizeUpdates
        for (s in 0 until sessions) {
            val cap = intArrayOf(0, 32, 128, 512, 1024, 4096)[rnd.nextInt(6)]
            val enc = j.newEncoder(cap)
            val ours = HpackDecoder(4096)
            val ref = j.newDecoder(4096)
            val gen = HdrGen(rnd)
            for (b in 0 until 1 + rnd.nextInt(30)) {
                if (rnd.nextInt(8) == 0) j.setCapacity(enc, intArrayOf(0, 64, 256, 1000, 4096)[rnd.nextInt(5)])
                val hs = (0 until 1 + rnd.nextInt(10)).map { gen.header() }
                val block = j.encode(enc, hs, intArrayOf(16, 64, 1024)[rnd.nextInt(3)])
                val want = hs.map { it.first to it.second }
                blocks++; fields += hs.size
                val mine = try { ours.decode(block).map { it.name to it.value } } catch (e: Throwable) { null }
                val theirs = try { j.decode(ref, block) } catch (e: Throwable) { null }
                if (theirs != want) { jdkBad++; if (first.isEmpty()) first = "JDK kendi bloğunu bozdu (oturum $s blok $b) ${hex(block)}" }
                if (mine != want) {
                    oursBad++
                    if (first.isEmpty()) first = "oturum $s blok $b: beklenen ${want.take(3)} bizim ${mine?.take(3) ?: "HATA"} blok ${hex(block)}"
                    break                                          // dinamik tablo ayrıştı: bu oturumun devamı anlamsız
                }
                if (mine != theirs) agreeBad++
            }
        }
        val huffs = j.huffSeen - huff0; val upds = j.sizeUpdates - upd0
        println("    (JDK kodlayıcı istatistiği: $blocks blok, $fields başlık, $huffs Huffman'lı dizgi, $upds tablo boyutu güncellemesi)")
        T.check("JDK → bizim: $blocks blok / $fields başlık birebir aynı ($sessions oturum)", oursBad == 0, first)
        T.check("referans sağlam: JDK çözücüsü kendi kodladığını aynen geri verdi", jdkBad == 0, first)
        T.check("iki çözücü her blokta aynı sonucu verdi", agreeBad == 0, "$agreeBad")
        T.check("saldırı gerçekten uygulandı: binlerce blok, yüzlerce Huffman dizgisi ve tablo boyutu güncellemesi görüldü", blocks > 3000 && huffs > 500 && upds > 50, "blok=$blocks huffman=$huffs güncelleme=$upds")
    }

    // ---------------------------------------------------------------- 2) Huffman tablosu: 256 sembolün hepsi JDK çözücüsüne okutulur
    T.group("Sızma 12 / HPACK Huffman: 256 sembol JDK'ya okutulur; tüm 1-2 baytlık ve 40 bin rastgele yük bağımsız RFC referansıyla (karar + çıktı) aynı; JDK'nın gevşekliği ayrı sayılır")
    run {
        var badSym = 0; var firstSym = ""
        for (b in 0..255) {
            val v = byteArrayOf(b.toByte())
            val block = literalBlock(v, huff = true)
            val want = listOf("x" to String(v, Charsets.ISO_8859_1))
            val theirs = jdkDecode(j, block); val mine = oursDecode(block)
            val okTheirs = theirs is Dec.Ok && theirs.fields == want
            val okMine = mine is Dec.Ok && mine.fields == want
            if (!okTheirs || !okMine) {
                badSym++
                if (firstSym.isEmpty()) firstSym = "bayt $b: JDK ${if (okTheirs) "ok" else (theirs as? Dec.Err)?.why ?: "farklı"} bizim ${if (okMine) "ok" else (mine as? Dec.Err)?.why ?: "farklı"}"
            }
        }
        T.check("256 sembolün her biri (tek bayt) JDK ve bizim çözücüde doğru", badSym == 0, firstSym)
        val rnd = Random(0xB0FF)
        var bad = 0; var firstBad = ""
        for (i in 0 until 20_000) {
            val n = 1 + rnd.nextInt(60)
            val v = ByteArray(n) { if (rnd.nextInt(3) == 0) (rnd.nextInt(256)).toByte() else ('a'.code + rnd.nextInt(26)).toByte() }
            val block = literalBlock(v, huff = true)
            val want = listOf("x" to String(v, Charsets.ISO_8859_1))
            val mine = oursDecode(block); val theirs = jdkDecode(j, block)
            if (!(mine is Dec.Ok && mine.fields == want) || !(theirs is Dec.Ok && theirs.fields == want)) { bad++; if (firstBad.isEmpty()) firstBad = hex(block) }
        }
        T.check("20 bin rastgele Huffman dizgisi (1-60 bayt, yüksek baytlar dahil) iki çözücüde de aynen çıkar", bad == 0, firstBad)

        // Tüm 1 ve 2 baytlık yükler (65 792): doldurma/EOS/kesik kod sınırlarının tamamı
        val ex = HuffStats()
        for (b in 0..255) huffCompare(j, byteArrayOf(b.toByte()), ex)
        for (v in 0..65535) huffCompare(j, byteArrayOf((v ushr 8).toByte(), v.toByte()), ex)
        println("    (tüm 1-2 baytlık yükler: ${ex.n} yük, RFC'ye göre geçerli ${ex.refOk}, JDK'nın RFC'den gevşek kabul ettiği ${ex.jdkLenient})")
        T.check("tüm 1-2 baytlık Huffman yükleri (65 792): bizim karar ve çıktı bağımsız RFC referansıyla birebir", ex.oursBad == 0, ex.first)
        T.check("tüm 1-2 baytlık yükler: JDK her geçerli dizgiyi referansla aynı çözer (referans sağlam)", ex.jdkBad == 0, ex.first)
        T.check("saldırı gerçekten uygulandı: hem geçerli hem geçersiz yükler görüldü", ex.refOk > 1000 && ex.n - ex.refOk > 1000, "geçerli=${ex.refOk} toplam=${ex.n}")

        // 3-12 baytlık rastgele yükler (çoğu geçersiz; 1'lerle dolu olanlar EOS ve doldurma sınırlarını zorlar)
        val st = HuffStats()
        for (i in 0 until 40_000) {
            val n = 3 + rnd.nextInt(10)
            val payload = ByteArray(n).also { rnd.nextBytes(it) }
            if (rnd.nextInt(3) == 0) for (k in 0 until payload.size) if (rnd.nextBoolean()) payload[k] = 0xFF.toByte()
            huffCompare(j, payload, st)
        }
        println("    (rastgele Huffman yükü: ${st.n} deneme, RFC'ye göre geçerli ${st.refOk}, JDK'nın RFC'den gevşek kabul ettiği ${st.jdkLenient})")
        T.check("40 bin rastgele Huffman yükü: bizim karar ve çıktı bağımsız RFC referansıyla birebir; çökme yok", st.oursBad == 0, st.first)
        T.check("40 bin rastgele Huffman yükü: JDK her geçerli dizgiyi referansla aynı çözer", st.jdkBad == 0, st.first)
        T.check("saldırı gerçekten uygulandı: geçerli ve geçersiz yük karışımı", st.refOk > 3000 && st.n - st.refOk > 3000, "geçerli=${st.refOk} toplam=${st.n}")
    }

    // ---------------------------------------------------------------- 3) bozulmuş bloklarda karar karşılaştırması
    T.group("Sızma 12 / HPACK: yapı-bilinçli bozulmuş bloklar (bit çevirme, kesme, araya ekleme) — bağımsız blok tarayıcı + JDK ile aynı karar; ikisi de kabul edince çıktı aynıdır")
    run {
        val rnd = Random(0x5EEDB10C)
        var total = 0; var bothOk = 0; var bothErr = 0; var diffOut = 0; var rejectValid = 0; var acceptInvalid = 0; var crash = 0; var capRej = 0
        var strictLate = 0; var strictPad = 0; var padBoth = 0; var lenientBad = 0; var scanNull = 0
        var firstDiff = ""; var firstRej = ""; var firstAcc = ""; var firstCrash = ""; var firstLen = ""
        for (i in 0 until 12_000 + 3000 * DEEP_X) {
            val enc = j.newEncoder(intArrayOf(0, 256, 4096)[rnd.nextInt(3)])
            val gen = HdrGen(rnd)
            // geçerli bir ön blok ve hedef blok: önce ön blokla iki çözücüyü ısıt (dinamik tablo dolu olsun), sonra bozulmuş hedefi ver
            val warm = j.encode(enc, (0 until 1 + rnd.nextInt(6)).map { gen.header() }, 1024)
            val target = j.encode(enc, (0 until 1 + rnd.nextInt(6)).map { gen.header() }, 1024)
            var mutated = target.copyOf()
            when (rnd.nextInt(7)) {
                0 -> { val k = rnd.nextInt(mutated.size); mutated[k] = (mutated[k].toInt() xor (1 shl rnd.nextInt(8))).toByte() }        // bit çevir
                1 -> mutated = mutated.copyOf(rnd.nextInt(mutated.size + 1))                                                            // kes
                2 -> { val at = rnd.nextInt(mutated.size + 1); mutated = mutated.copyOfRange(0, at) + byteArrayOf(rnd.nextInt(256).toByte()) + mutated.copyOfRange(at, mutated.size) }   // bayt ekle
                3 -> { val at = rnd.nextInt(mutated.size + 1); mutated = mutated.copyOfRange(0, at) + byteArrayOf((0x20 or rnd.nextInt(32)).toByte()) + mutated.copyOfRange(at, mutated.size) }   // araya boyut güncellemesi
                4 -> { val k = rnd.nextInt(mutated.size); mutated[k] = rnd.nextInt(256).toByte() }                                      // bayt değiştir
                5 -> { val at = rnd.nextInt(mutated.size + 1); mutated = mutated.copyOfRange(0, at) + byteArrayOf(0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0x7F) + mutated.copyOfRange(at, mutated.size) }   // dev tamsayı
                else -> {                                                                                                                // bir Huffman dizgisinin doldurma bitlerini boz
                    val hs = scanBlock(mutated)?.hStrings
                    if (hs != null && hs.isNotEmpty()) { val h = hs[rnd.nextInt(hs.size)]; val last = h[0] + h[1] - 1; if (h[1] > 0) mutated[last] = (mutated[last].toInt() xor (1 shl rnd.nextInt(3))).toByte() }
                }
            }
            val ours = HpackDecoder(4096); val ref = j.newDecoder(4096)
            val w1 = try { ours.decode(warm); true } catch (_: Throwable) { false }
            val w2 = try { j.decode(ref, warm); true } catch (_: Throwable) { false }
            if (!w1 || !w2) continue                                                                                   // ısınma bloğu kendi bloğumuz: yine de çözülmeli
            val mine = try { Dec.Ok(ours.decode(mutated).map { it.name to it.value }) } catch (e: java.io.IOException) { Dec.Err("IO ${e.message}") } catch (e: Throwable) { Dec.Err("ÇÖKME ${e.javaClass.simpleName}: ${e.message}") }
            val theirs = try { Dec.Ok(j.decode(ref, mutated)) } catch (e: Throwable) { Dec.Err("${e.javaClass.simpleName}: ${e.message}") }
            val scan = scanBlock(mutated)
            total++
            if (mine is Dec.Err && mine.why.startsWith("ÇÖKME")) { crash++; if (firstCrash.isEmpty()) firstCrash = "${mine.why} ${hex(mutated)}" }
            if (mine is Dec.Ok) {                                                                                      // kabul ettiğimiz blok bağımsız tarayıcıya göre geçerli olmalı
                if (scan == null) { scanNull++; if (firstLen.isEmpty()) firstLen = "kabul ettik ama bağımsız tarayıcı çözemedi: ${hex(mutated)}" }
                else if (scan.violation) { lenientBad++; if (firstLen.isEmpty()) firstLen = "RFC ihlali kabul edildi (geç boyut=${scan.lateSize} doldurma=${scan.badPad} EOS=${scan.eos}): ${hex(mutated)}" }
            }
            when {
                mine is Dec.Ok && theirs is Dec.Ok -> { bothOk++; if (mine.fields != theirs.fields) { diffOut++; if (firstDiff.isEmpty()) firstDiff = "ısınma ${hex(warm, 24)} blok ${hex(mutated)}: bizim ${mine.fields.take(3)} JDK ${theirs.fields.take(3)}" } }
                mine is Dec.Err && theirs is Dec.Err -> { bothErr++; if (scan != null && (scan.badPad || scan.eos)) padBoth++ }   // JDK de doldurma/EOS hatasını reddeder: ikisi aynı kararda
                mine is Dec.Err && theirs is Dec.Ok -> {
                    if (mine.why.contains("çok büyük")) capRej++                                                      // başlık listesi sınırı: bilerek JDK'dan sıkı (HPACK bombası koruması)
                    else if (scan != null && scan.lateSize && mine.why.contains("geç tablo")) strictLate++            // RFC 7541 §4.2: blok ortasında boyut güncellemesi hatadır (JDK kabul eder)
                    else if (scan != null && (scan.badPad || scan.eos) && mine.why.contains("Huffman")) strictPad++    // RFC 7541 §5.2: geçersiz doldurma / EOS (JDK kabul eder)
                    else { rejectValid++; if (firstRej.isEmpty()) firstRej = "biz: ${mine.why} tarayıcı=${scan?.let { "geç=${it.lateSize} doldurma=${it.badPad} eos=${it.eos}" } ?: "çözemedi"} blok ${hex(mutated)} ısınma ${hex(warm, 24)}" }
                }
                mine is Dec.Ok && theirs is Dec.Err -> { acceptInvalid++; if (firstAcc.isEmpty()) firstAcc = "JDK: ${theirs.why} blok ${hex(mutated)} ısınma ${hex(warm, 24)}" }
            }
        }
        println("    (bozulmuş blok istatistiği: $total deneme, ikisi de kabul $bothOk, ikisi de ret $bothErr, çıktı farkı $diffOut; biz reddettik/JDK kabul: RFC-sıkı geç boyut güncellemesi $strictLate, geçersiz Huffman $strictPad, liste sınırı $capRej, açıklanamayan $rejectValid; biz kabul/JDK reddetti $acceptInvalid)")
        T.check("bozuk blokta çözücü çökmez (yalnızca IOException; $total deneme)", crash == 0, firstCrash)
        T.check("ikisi de kabul ettiğinde çıktı aynı ($bothOk blok)", diffOut == 0, firstDiff)
        T.check("JDK'nın kabul ettiği bloğu yalnızca RFC ihlali (geç boyut güncellemesi, geçersiz Huffman) ya da liste sınırı yüzünden reddederiz, doğru nedenle", rejectValid == 0, firstRej)
        T.check("kabul ettiğimiz her blok bağımsız tarayıcıya göre de geçerli (RFC ihlali kabul edilmez)", lenientBad == 0 && scanNull == 0, firstLen)
        T.check("saldırı gerçekten uygulandı: hem kabul hem ret yolları, RFC-sıkı ret örnekleri ve binlerce deneme", total > 8000 && bothOk > 300 && bothErr > 300 && strictLate > 100 && padBoth > 50, "deneme=$total kabul=$bothOk ret=$bothErr geç=$strictLate doldurma=$padBoth")
        if (acceptInvalid > 0) println("    (bilgi: $acceptInvalid blokta biz JDK'dan gevşek davrandık; ilk örnek: $firstAcc)")
    }
}

// =============================================================================================== PSL

private class PslRef(file: File) {
    class Rule(val labels: List<String>, val exception: Boolean, val icann: Boolean)

    val byLast = HashMap<String, MutableList<Rule>>()
    val rules = ArrayList<Rule>()

    init {
        var priv = false
        for (raw in file.readLines(Charsets.US_ASCII)) {
            val l = raw.trim()
            if (l == "#PRIVATE") priv = true
            if (l.isEmpty() || l.startsWith("#")) continue
            val exc = l.startsWith("!")
            val body = if (exc) l.substring(1) else l
            val labels = body.split('.')
            val r = Rule(labels, exc, !priv)
            rules.add(r)
            byLast.getOrPut(labels.last()) { ArrayList() }.add(r)
        }
    }

    /** Spesifikasyon (publicsuffix.org/list): eşleşen kurallar arasında istisna varsa o, yoksa en çok etiketlisi; hiçbiri yoksa "*". Dönüş: son ekin etiket sayısı. */
    fun suffixLabels(labels: List<String>, icannOnly: Boolean): Int {
        val n = labels.size
        var best = 1
        var exc = -1
        val cands = byLast[labels.last()] ?: return 1
        for (r in cands) {
            if (icannOnly && !r.icann) continue
            val m = r.labels.size
            if (m > n) continue
            var ok = true
            for (i in 0 until m) { val rl = r.labels[m - 1 - i]; if (rl != "*" && rl != labels[n - 1 - i]) { ok = false; break } }
            if (!ok) continue
            if (r.exception) exc = maxOf(exc, m) else best = maxOf(best, m)
        }
        return if (exc >= 0) exc - 1 else best
    }

    /** Kayıt edilebilir alan adının başlangıç konumu (0 = adın tamamı). */
    fun registrableStart(name: String): Int {
        val labels = name.split('.')
        val n = labels.size
        if (n == 1) return 0
        val s = suffixLabels(labels, icannOnly = false)
        if (n <= s) return 0
        val reg = labels.takeLast(s + 1).joinToString(".")
        return name.length - reg.length
    }

    /** İsim ICANN bölümünde ortak bir son ek mi (≥ 2 etiketli adlar için). */
    fun isIcannSuffix(name: String): Boolean {
        val labels = name.split('.')
        return labels.size >= 2 && labels.size <= suffixLabels(labels, icannOnly = true)
    }
}

private fun pslDifferentialTests() {
    val f = File("app/src/main/assets/filter/psl.txt")
    if (!f.exists()) { println("  (psl.txt bulunamadı: PSL çapraz doğrulaması atlandı)"); return }
    val was = PublicSuffix.ready
    try {
        f.inputStream().use { PublicSuffix.install(it) }
        val ref = PslRef(f)
        T.group("Sızma 12 / Public Suffix List: registrableStart ve isIcannSuffix ↔ spesifikasyondan yazılmış saf referans (psl.txt'deki ${ref.rules.size} kural, 80 bin ad)")
        val rnd = Random(0x95CA11)
        val common = listOf("a", "b", "c", "www", "com", "co", "uk", "jp", "kobe", "ck", "city", "github", "io", "blogspot", "de", "tr", "com", "net", "org", "x1", "my-site")
        fun lbl(): String = if (rnd.nextInt(3) == 0) common[rnd.nextInt(common.size)] else String(CharArray(1 + rnd.nextInt(8)) { "abcdefghijklmnopqrstuvwxyz0123456789"[rnd.nextInt(36)] })
        fun fill(labels: List<String>): List<String> = labels.map { if (it == "*") lbl() else it }
        fun prefix(maxN: Int): List<String> = (0 until rnd.nextInt(maxN)).map { lbl() }
        var n = 0; var badReg = 0; var badIcann = 0; var firstReg = ""; var firstIcann = ""
        var viaWild = 0; var viaExc = 0; var viaPriv = 0
        var regWhole = 0; var regSub = 0; var icannTrue = 0
        for (i in 0 until 80_000) {
            val labels: List<String> = when (rnd.nextInt(10)) {
                0, 1, 2, 3 -> {                                                                              // kuralın kendisi (önüne rastgele etiketler)
                    val r = ref.rules[rnd.nextInt(ref.rules.size)]
                    if (r.labels.contains("*")) viaWild++
                    if (r.exception) viaExc++
                    if (!r.icann) viaPriv++
                    prefix(4) + fill(r.labels)
                }
                4, 5 -> { val r = ref.rules[rnd.nextInt(ref.rules.size)]; prefix(4) + fill(r.labels).drop(1) }  // kuralın bir üstü (en soldaki etiket düşer)
                6 -> fill(ref.rules[rnd.nextInt(ref.rules.size)].labels)                                    // tam kural adı
                else -> (0 until 1 + rnd.nextInt(5)).map { lbl() }
            }.ifEmpty { listOf(lbl()) }
            val name = labels.joinToString(".")
            if (name.length > 250) continue
            n++
            val shown = when (rnd.nextInt(6)) { 0 -> name.uppercase(); 1 -> "$name."; else -> name }
            val bytes = shown.toByteArray(Charsets.US_ASCII)
            val got = PublicSuffix.registrableStart(bytes, bytes.size)
            val want = ref.registrableStart(name)
            if (want == 0) regWhole++ else regSub++
            if (got != want) { badReg++; if (firstReg.isEmpty()) firstReg = "ad=$name got=$got want=$want" }
            if (labels.size >= 2) {
                val g = PublicSuffix.isIcannSuffix(name)
                val w = ref.isIcannSuffix(name)
                if (w) icannTrue++
                if (g != w) { badIcann++; if (firstIcann.isEmpty()) firstIcann = "ad=$name got=$g want=$w" }
            }
        }
        T.check("registrableStart: $n adın hepsi referansla aynı (joker ≈$viaWild, istisna ≈$viaExc, özel bölüm ≈$viaPriv kuraldan türetilen adlar dahil)", badReg == 0, "$badReg fark; ilk: $firstReg")
        T.check("isIcannSuffix: $n adın hepsi referansla aynı", badIcann == 0, "$badIcann fark; ilk: $firstIcann")
        T.check("saldırı gerçekten uygulandı: hem 'adın tamamı' ($regWhole) hem 'alt alan' ($regSub) sonuçları ve ICANN son ekleri ($icannTrue) görüldü", regWhole > 2000 && regSub > 2000 && icannTrue > 500 && viaWild > 500 && viaExc > 10,
            "tam=$regWhole alt=$regSub icann=$icannTrue joker=$viaWild istisna=$viaExc")
        // bilinen köşe örnekleri (spesifikasyon sayfasındaki tablo): elle doğrulanmış
        fun reg(name: String): String { val b = name.toByteArray(); val s = PublicSuffix.registrableStart(b, b.size); return name.substring(s) }
        T.check("spesifikasyon örnekleri: co.uk, joker (*.ck), istisna (!www.ck), özel bölüm (github.io)",
            reg("a.b.example.co.uk") == "example.co.uk" && reg("www.ck") == "www.ck" && reg("a.b.ck") == "a.b.ck" && reg("x.a.b.ck") == "a.b.ck" &&
                reg("foo.github.io") == "foo.github.io" && reg("example.com") == "example.com" && reg("www.example.com") == "example.com",
            listOf("a.b.example.co.uk", "www.ck", "a.b.ck", "x.a.b.ck", "foo.github.io").joinToString { reg(it) })
    } finally { if (!was) PublicSuffix.clear() }
}

// =============================================================================================== süzgeç

/** Tel biçiminde tek soruluk DNS sorgusu (A / IN). */
private fun wireQuery(name: String): ByteArray {
    val o = ByteArrayOutputStream()
    o.write(byteArrayOf(0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
    for (l in name.trimEnd('.').split('.')) { o.write(l.length); o.write(l.toByteArray(Charsets.ISO_8859_1)) }
    o.write(0); o.write(byteArrayOf(0, 1, 0, 1))
    return o.toByteArray()
}

private fun filterDifferentialTests() {
    T.group("Sızma 12 / süzgeç: izin > kanarya > engel > korunan > liste önceliği ve etiket sınırında son-ek eşleşmesi ↔ küme modeli (metin ve tel biçimi yolu, yoğun alt alan ilişkileri)")
    run {
        val rnd = Random(0xF117E2)
        val alpha = listOf("a", "b", "c", "ab", "x1", "x-y", "tr", "com")
        fun randName(minL: Int, maxL: Int): String = (0 until minL + rnd.nextInt(maxL - minL + 1)).joinToString(".") { alpha[rnd.nextInt(alpha.size)] }
        fun suffixes(name: String): List<String> { val l = name.split('.'); return (0..l.size - 2).map { l.drop(it).joinToString(".") } }   // ≥ 2 etiketli son ekler
        fun tierOf(names: Collection<String>) = FilterTier(names.map { FilterHash.hash(it) }.distinct().sorted().toLongArray())
        val canary = "use-application-dns.net"
        var n = 0; var bad = 0; var badWire = 0; var first = ""; var firstWire = ""
        val seen = IntArray(4)
        for (round in 0 until 120) {
            val allow = HashSet<String>(); val block = HashSet<String>(); val list = HashSet<String>(); val prot = HashSet<String>()
            repeat(rnd.nextInt(8)) { allow.add(randName(2, 4)) }
            repeat(1 + rnd.nextInt(12)) { block.add(randName(2, 4)) }
            repeat(rnd.nextInt(14)) { list.add(randName(2, 4)) }
            repeat(rnd.nextInt(5)) { prot.add(randName(2, 3)) }
            if (round % 10 == 0) block.add(canary)                                     // kanarya ad kullanıcı engel listesinde de olsa kanarya sayılır (engelden önce)
            val eng = FilterEngine(listOf(tierOf(list)), tierOf(prot), allow.toList(), block.toList())
            val pool = ArrayList<String>()
            for (s in allow + block + list + prot) { pool.add(s); pool.add(randName(1, 2) + "." + s) }
            repeat(40) { pool.add(randName(1, 5)) }
            pool.add(canary); pool.add("x.$canary")
            for (q in pool) for (variant in 0 until 3) {
                val shown = when (variant) { 1 -> q.uppercase(); 2 -> "$q."; else -> q }
                val sfx = suffixes(q)
                val want = when {
                    sfx.isEmpty() -> FilterVerdict.PASS
                    sfx.any { it in allow } -> FilterVerdict.PASS
                    q == canary -> FilterVerdict.CANARY
                    sfx.any { it in block } -> FilterVerdict.USER
                    sfx.any { it in prot } -> FilterVerdict.PASS
                    sfx.any { it in list } -> FilterVerdict.LIST
                    else -> FilterVerdict.PASS
                }
                val got = eng.verdictOf(shown)
                n++; seen[want]++
                if (got != want) { bad++; if (first.isEmpty()) first = "ad=$shown want=$want got=$got allow=$allow block=$block list=$list prot=$prot" }
                val pkt = wireQuery(shown)
                val gw = eng.verdict(pkt, 0, pkt.size)
                if (gw != want) { badWire++; if (firstWire.isEmpty()) firstWire = "ad=$shown want=$want tel=$gw" }
            }
        }
        T.check("$n sorgunun hepsi küme modeliyle aynı (PASS ${seen[0]}, LIST ${seen[1]}, USER ${seen[2]}, CANARY ${seen[3]})", bad == 0 && seen[1] > 500 && seen[2] > 500 && seen[3] > 20, "$bad fark; ilk: $first")
        T.check("aynı sorgular tel biçimi yolunda (verdict) da aynı karar", badWire == 0, "$badWire fark; ilk: $firstWire")
    }

    T.group("Sızma 12 / süzgeç katmanı: büyük (kova dizinli) ve küçük (düz dizi) katman düz kümeyle aynı — her kova dağılımı dahil (kötü niyetli liste yavaşlatamaz)")
    run {
        val rnd = Random(0x71E4)
        fun distinctOf(n: Int, gen: () -> Long): LongArray {
            val s = HashSet<Long>(n * 2)
            while (s.size < n) s.add(gen())
            return s.toLongArray()
        }
        fun r48() = rnd.nextLong() ushr 16
        fun tierCase(label: String, hashes: LongArray, probes: Int) {
            val sorted = hashes.sortedArray()
            val tier = FilterTier(sorted)
            val set = HashSet<Long>(sorted.size * 2); for (h in sorted) set.add(h)
            var bad = 0; var first = ""
            val t0 = System.nanoTime()
            for (i in 0 until probes) {
                val h: Long = when (rnd.nextInt(4)) {
                    0 -> sorted[rnd.nextInt(sorted.size)]                                        // üye
                    1 -> sorted[rnd.nextInt(sorted.size)] xor (1L shl rnd.nextInt(48))           // üyeye bir bit uzak
                    2 -> r48()                                                                   // rastgele 48 bit
                    else -> longArrayOf(0L, 1L, (1L shl 48) - 1, 1L shl 32, (1L shl 32) - 1, (1L shl 48) - 2, 1L shl 47, -1L, Long.MIN_VALUE, 1L shl 48)[rnd.nextInt(10)]   // uçlar ve 48 bit dışı
                }
                if (tier.contains(h) != (h in set)) { bad++; if (first.isEmpty()) first = "h=$h" }
            }
            val ms = (System.nanoTime() - t0) / 1_000_000
            val compact = tier.idxArr != null
            T.check("$label: ${sorted.size} özet (${if (compact) "kova dizinli" else "düz dizi"}), $probes sorgu düz kümeyle aynı ($ms ms)",
                bad == 0 && ms < 8000 && compact == (sorted.size >= FilterTier.COMPACT_MIN) && tier.size == sorted.size, "$bad fark $first süre=$ms ms kompakt=$compact boyut=${tier.size}")
        }
        tierCase("küçük katman", distinctOf(50_000, ::r48), 150_000)
        tierCase("kova eşiğinin hemen altı", distinctOf(FilterTier.COMPACT_MIN - 1, ::r48), 150_000)
        tierCase("kova eşiği", distinctOf(FilterTier.COMPACT_MIN, ::r48), 150_000)
        tierCase("büyük katman", distinctOf(300_000, ::r48), 300_000)
        tierCase("hepsi tek kovada (saldırgan liste: üst 16 bit aynı)", distinctOf(120_000) { (0x1234L shl 32) or (rnd.nextLong() and 0xFFFFFFFFL) }, 200_000)
        var flip = false
        tierCase("hepsi ilk ve son kovada", distinctOf(120_000) { flip = !flip; if (flip) (rnd.nextLong() and 0xFFFFFFFFL) else (0xFFFFL shl 32) or (rnd.nextLong() and 0xFFFFFFFFL) }, 200_000)
        tierCase("alt 32 bitin işaret sınırı (0x7fffffff / 0x80000000) çevresinde yığılmış", distinctOf(120_000) { (rnd.nextInt(65536).toLong() shl 32) or (0x7FFFFFF0L + rnd.nextInt(32)) }, 200_000)
    }
}
