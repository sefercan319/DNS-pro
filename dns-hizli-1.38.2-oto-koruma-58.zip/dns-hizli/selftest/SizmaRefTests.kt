package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.Random

/**
 * Sızma 20 — hata bulma aracı: bağımsız referansla karşılaştırmalı rastgele testler. Aynı girdiyi hem uygulamanın kodundan
 * hem de JDK'dan / ayrı yazılmış basit bir modelden geçirir; ayrılan her durum ya uygulamada ya referansta hatadır ve incelenir.
 */
internal fun runReferenceTests() {
    // ---------------------------------------------------------------- Base64Mini ↔ java.util.Base64
    T.group("Sızma 20 / Base64Mini ↔ JDK: kodlama birebir, çözme yalnızca JDK'nın da kabul ettiği (ve aynı sonucu veren) girdileri kabul eder")
    run {
        val rnd = Random(2001)
        var encBad = 0; var decBad = 0; var lenient = 0; var firstLenient = ""
        repeat(4000) {
            val b = ByteArray(rnd.nextInt(80)).also { rnd.nextBytes(it) }
            val e = java.util.Base64.getEncoder().encodeToString(b)
            if (Base64Mini.encode(b) != e) encBad++
            if (!(Base64Mini.decode(e) ?: ByteArray(1)).contentEquals(b)) decBad++
            // mutasyon: bir karakteri değiştir / araya '=' koy / kes
            val chars = e.toCharArray()
            if (chars.isNotEmpty()) {
                when (rnd.nextInt(3)) {
                    0 -> chars[rnd.nextInt(chars.size)] = "=+/A_-!\n "[rnd.nextInt(9)]
                    1 -> { val i = rnd.nextInt(chars.size); chars[i] = '=' }
                    else -> {}
                }
            }
            var m = String(chars)
            if (rnd.nextInt(4) == 0) m += "=".repeat(1 + rnd.nextInt(3))
            val ours = Base64Mini.decode(m)
            val clean = m.filter { !it.isWhitespace() }
            val theirs = try { java.util.Base64.getDecoder().decode(clean) } catch (_: IllegalArgumentException) { null }
            if (ours != null && (theirs == null || !ours.contentEquals(theirs))) { lenient++; if (firstLenient.isEmpty()) firstLenient = "'$m' → ${ours.size} bayt, JDK=${theirs?.size}" }
        }
        T.check("kodlama 4000 rastgele girdide JDK ile birebir", encBad == 0)
        T.check("kodlanmış her girdi geri çözülür", decBad == 0)
        T.check("çözücü, JDK'nın reddettiği ya da farklı çözdüğü girdiyi kabul etmez", lenient == 0, "gevşek=$lenient örnek: $firstLenient")
        T.check("'====' ve 'A===' reddedilir", Base64Mini.decode("====") == null && Base64Mini.decode("A===") == null)
        T.check("ortada dolgu ('AA==AAAA') reddedilir", Base64Mini.decode("AA==AAAA") == null)
    }

    // ---------------------------------------------------------------- Ip ↔ JDK / referans
    T.group("Sızma 20 / Ip.parse6 ↔ JDK: 60 bin dilbilgisine yakın IPv6 yazımı (kabul/ret ve bayt)")
    run {
        val rnd = Random(2002)
        val hex = "0123456789abcdefABCDEF"
        fun grp(): String = (0 until 1 + rnd.nextInt(4)).map { hex[rnd.nextInt(hex.length)] }.joinToString("")
        fun gen(): String {
            val n = rnd.nextInt(10)
            val parts = (0 until n).map { if (rnd.nextInt(14) == 0) "${rnd.nextInt(300)}.${rnd.nextInt(256)}.${rnd.nextInt(256)}.${rnd.nextInt(256)}" else grp() }
            var s = parts.joinToString(":")
            when (rnd.nextInt(7)) {
                0 -> if (parts.isNotEmpty()) { val k = rnd.nextInt(parts.size + 1); s = parts.take(k).joinToString(":") + "::" + parts.drop(k).joinToString(":") }
                1 -> s = ":$s"
                2 -> s = "$s:"
                3 -> s = s.replaceFirst(":", ":::")
                4 -> s = "::$s"
                5 -> s = "$s::"
            }
            return s
        }
        var diff = 0; var shown = 0; var accepted = 0
        val samples = ArrayList<String>()
        repeat(60_000) {
            val s = gen()
            if (s.length < 2 || s.length > 45) return@repeat
            val ours = Ip.parse6(s)
            val jdk: ByteArray? = try {
                if (!s.contains(':')) null else java.net.InetAddress.getByName(s).address
            } catch (_: Exception) { null }
            val jdk16 = jdk?.let { if (it.size == 4) ByteArray(16).also { o -> o[10] = -1; o[11] = -1; System.arraycopy(it, 0, o, 12, 4) } else it }
            // JDK "::ffff:a.b.c.d" yazımını Inet4Address'e indirger; "::a.b.c.d" (uyumlu) biçimini de. Bayt karşılaştırması bu yüzden gevşektir.
            val same = if (ours == null && jdk == null) true
                else if (ours != null && jdk != null) {
                    ours.contentEquals(jdk16) || (jdk.size == 4 && ours.copyOfRange(12, 16).contentEquals(jdk))
                } else false
            if (ours != null) accepted++
            if (!same) { diff++; if (shown < 8) { shown++; samples.add("'$s' bizim=${ours?.let { Ip.format(it) }} jdk=${jdk?.joinToString(",")}") } }
        }
        T.check("kabul edilen yazım sayısı anlamlı (>2000)", accepted > 2000, "kabul=$accepted")
        T.check("JDK ile kabul/ret ve bayt farkı yok", diff == 0, "fark=$diff ${samples.joinToString(" | ")}")
    }
    T.group("Sızma 20 / Ip.format: RFC 5952 referansıyla birebir; parse(format(x)) == x")
    run {
        val rnd = Random(2003)
        fun ref(b: ByteArray): String {   // bağımsız yazım: en uzun (≥2) sıfır dizisi, eşitse ilki
            val w = IntArray(8) { ((b[2 * it].toInt() and 0xFF) shl 8) or (b[2 * it + 1].toInt() and 0xFF) }
            var bs = -1; var bl = 0; var i = 0
            while (i < 8) { if (w[i] != 0) { i++; continue }; var j = i; while (j < 8 && w[j] == 0) j++; if (j - i > bl) { bs = i; bl = j - i }; i = j }
            if (bl < 2) { bs = -1 }
            val l = w.map { Integer.toHexString(it) }
            return if (bs < 0) l.joinToString(":") else l.subList(0, bs).joinToString(":") + "::" + l.subList(bs + bl, 8).joinToString(":")
        }
        var bad = 0; var rt = 0
        repeat(40_000) {
            val b = ByteArray(16)
            for (g in 0 until 8) { val z = rnd.nextInt(3) == 0 || (rnd.nextInt(2) == 0 && g in 2..5); if (!z) { b[2 * g] = rnd.nextInt(256).toByte(); b[2 * g + 1] = rnd.nextInt(256).toByte() } else if (rnd.nextInt(5) == 0) b[2 * g + 1] = 1 }
            if (Ip.format(b) != ref(b)) bad++
            if (!(Ip.parse6(Ip.format(b)) ?: ByteArray(0)).contentEquals(b)) rt++
        }
        T.check("40 bin adres: yazım RFC 5952 referansıyla aynı", bad == 0, "fark=$bad")
        T.check("40 bin adres: yazılıp geri ayrıştırılınca aynı", rt == 0, "fark=$rt")
        val v4 = Random(2004)
        var b4 = 0
        repeat(20_000) {
            val x = ByteArray(4).also { v4.nextBytes(it) }
            val s = Ip.format(x)
            if (!(Ip.parse4(s) ?: ByteArray(0)).contentEquals(x) || s != java.net.InetAddress.getByAddress(x).hostAddress) b4++
        }
        T.check("20 bin IPv4: yazım JDK ile aynı ve gidiş-dönüş tam", b4 == 0)
    }
    T.group("Sızma 20 / Ip.parse4 ↔ sıkı düzenli ifade: 80 bin rastgele nokta-ondalık yazım")
    run {
        val rnd = Random(2005)
        val strict = Regex("^(0|[1-9][0-9]{0,2})(\\.(0|[1-9][0-9]{0,2})){3}$")
        var diff = 0; var shown = ""
        repeat(80_000) {
            val parts = (0 until 3 + rnd.nextInt(3)).map { when (rnd.nextInt(8)) { 0 -> "0" + rnd.nextInt(100); 1 -> ""; 2 -> rnd.nextInt(1000).toString(); 3 -> " ${rnd.nextInt(256)}"; 4 -> "${rnd.nextInt(256)}x"; else -> rnd.nextInt(256).toString() } }
            val s = parts.joinToString(".")
            val ref = strict.matches(s) && s.split('.').all { it.toInt() <= 255 }
            if ((Ip.parse4(s) != null) != ref) { diff++; if (shown.isEmpty()) shown = s }
        }
        T.check("kabul/ret düzenli ifade referansıyla aynı", diff == 0, "fark=$diff örnek='$shown'")
    }

    // ---------------------------------------------------------------- IPv4 sağlama toplamı
    T.group("Sızma 20 / Packets.checksum ↔ referans (64-bit toplam + katlama); geçerli başlıkta doğrulama 0")
    run {
        val rnd = Random(2006)
        var bad = 0; var ver = 0
        repeat(30_000) {
            val len = 2 * (1 + rnd.nextInt(40)); val off = rnd.nextInt(5)
            val b = ByteArray(off + len + 3).also { rnd.nextBytes(it) }
            if (rnd.nextInt(5) == 0) java.util.Arrays.fill(b, off, off + len, 0xFF.toByte())
            var s = 0L; var i = off; while (i < off + len) { s += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF); i += 2 }
            while (s ushr 16 != 0L) s = (s and 0xFFFF) + (s ushr 16)
            if (Packets.checksum(b, off, len) != (s.inv().toInt() and 0xFFFF)) bad++
            // alanı 0'layıp yaz, yeniden doğrula
            if (len >= 4) { b[off + 2] = 0; b[off + 3] = 0; val c = Packets.checksum(b, off, len); b[off + 2] = (c ushr 8).toByte(); b[off + 3] = c.toByte(); if (Packets.checksum(b, off, len) != 0) ver++ }
        }
        T.check("30 bin rastgele blok referansla aynı", bad == 0, "fark=$bad")
        T.check("yazılan sağlama toplamı geçerli (doğrulama 0)", ver == 0, "fark=$ver")
    }

    // ---------------------------------------------------------------- DnsCache ↔ model
    T.group("Sızma 20 / DnsCache ↔ bağımsız model: 400 tohum × 500 işlem (put/get/getStale/prefetch, saat atlamaları, kayıt+bayt sınırı, LRU sırası)")
    run {
        class M(val data: ByteArray, val storedAt: Long, val expiresAt: Long, val staleOk: Boolean)
        var fails = 0; var firstFail = ""
        fun fail(msg: String) { fails++; if (firstFail.isEmpty()) firstFail = msg }
        fun resp(name: String, extra: Int, positive: Boolean, ttl: Int): ByteArray {
            val q = Dns.buildQuery(0x1111, name)
            val out = ByteArray(q.size + 16 + extra)
            System.arraycopy(q, 0, out, 0, q.size)
            Packets.put16(out, 2, if (positive) 0x8180 else 0x8183); Packets.put16(out, 6, if (positive) 1 else 0)
            if (positive) { val o = q.size; Packets.put16(out, o, 0xC00C); Packets.put16(out, o + 2, 1); Packets.put16(out, o + 4, 1); Packets.put32(out, o + 6, ttl); Packets.put16(out, o + 10, 4); out[o + 12] = 1; out[o + 13] = 2; out[o + 14] = 3; out[o + 15] = 4 }
            return out
        }
        for (seed in 0 until 400) {
            val rnd = Random(seed.toLong())
            var now = 1_000_000L
            val maxE = 1 + rnd.nextInt(6); val maxB = 120 + rnd.nextInt(700)
            val cache = DnsCache(maxE, { now }, maxB)
            val model = LinkedHashMap<String, M>()      // eski → yeni; erişimde yeniye taşınır
            var mBytes = 0
            val out = ByteArray(8192)
            fun touch(k: String) { val v = model.remove(k)!!; model[k] = v }
            fun mTrim() { while (model.isNotEmpty() && (model.size > maxE || mBytes > maxB)) { val k = model.keys.first(); mBytes -= model.remove(k)!!.data.size } }
            for (step in 0 until 500) {
                val key = "k${rnd.nextInt(9)}"
                when (rnd.nextInt(6)) {
                    0, 1 -> {
                        val pos = rnd.nextInt(4) != 0; val ttl = rnd.nextInt(-1, 700)
                        val r = resp("a$key.example.com", rnd.nextInt(0, 120), pos, 60)
                        cache.put(key, r, r.size, ttl)
                        val ok = ttl >= 1 && r.isNotEmpty() && r.size <= DnsCache.MAX_ENTRY_BYTES && r.size <= maxB
                        if (ok) {
                            model.remove(key)?.let { mBytes -= it.data.size }
                            val life = minOf(ttl, DnsCache.MAX_TTL_S) * 1000L
                            model[key] = M(r, now, now + life, pos); mBytes += r.size; mTrim()
                        }
                    }
                    2, 3 -> {
                        val n = cache.get(key, 0x7777, out, 0)
                        val m = model[key]
                        var exp = -1
                        if (m != null) {
                            touch(key)
                            if (now >= m.expiresAt) { if (!m.staleOk || now - m.expiresAt > DnsCache.STALE_MAX_MS) { model.remove(key); mBytes -= m.data.size } }
                            else exp = m.data.size
                        }
                        if (n != exp) fail("seed=$seed adım=$step get($key)=$n beklenen=$exp")
                        else if (n > 0 && Packets.u16(out, 0) != 0x7777) fail("seed=$seed get kimlik değişmedi")
                    }
                    4 -> {
                        val n = cache.getStale(key, 0x5555, out, 0)
                        val m = model[key]
                        var exp = -1
                        if (m != null) {
                            touch(key)
                            if (now >= m.expiresAt && m.staleOk) { if (now - m.expiresAt > DnsCache.STALE_MAX_MS) { model.remove(key); mBytes -= m.data.size } else exp = m.data.size }
                        }
                        if (n != exp) fail("seed=$seed adım=$step getStale($key)=$n beklenen=$exp")
                    }
                    else -> now += when (rnd.nextInt(4)) { 0 -> rnd.nextInt(1, 3000).toLong(); 1 -> rnd.nextInt(1, 400_000).toLong(); 2 -> DnsCache.STALE_MAX_MS + rnd.nextInt(-2, 3); else -> rnd.nextInt(1, 30_000_000).toLong() }
                }
                if (cache.size() != model.size || cache.byteSize() != mBytes) { fail("seed=$seed adım=$step boyut ${cache.size()}/${cache.byteSize()} beklenen ${model.size}/$mBytes"); break }
            }
        }
        T.check("200 bin işlemde önbellek modelle birebir (boyut, bayt, isabet, bayat, LRU)", fails == 0, "fark=$fails $firstFail")
    }
    T.group("Sızma 20 / DnsCache: önbellekten verilen cevabın TTL'i geçen süre kadar azalır, 0'ın altına inmez; bayatta 30 sn")
    run {
        var now = 5_000_000L
        val c = DnsCache(4, { now }, 4096)
        val q = Dns.buildQuery(0x1, "ttl.example.com")
        val r = ByteArray(q.size + 16); System.arraycopy(q, 0, r, 0, q.size)
        Packets.put16(r, 2, 0x8180); Packets.put16(r, 6, 1)
        val o = q.size; Packets.put16(r, o, 0xC00C); Packets.put16(r, o + 2, 1); Packets.put16(r, o + 4, 1); Packets.put32(r, o + 6, 100); Packets.put16(r, o + 10, 4)
        c.put("t", r, r.size, 100)
        val out = ByteArray(512)
        val rnd = Random(2007); var bad = 0
        for (age in listOf(0, 1, 2, 37, 99)) {
            now = 5_000_000L + age * 1000L + rnd.nextInt(900)
            val n = c.get("t", 9, out, 0)
            val ttl = Packets.i32(out, o + 6)
            if (n != r.size || ttl != 100 - age) bad++
        }
        T.check("TTL = 100 − geçen sn (0, 1, 2, 37, 99)", bad == 0, "hatalı=$bad")
        now = 5_000_000L + 100_500
        T.check("süre dolunca taze cevap yok, bayat var (TTL=30)", c.get("t", 9, out, 0) == -1 && c.getStale("t", 9, out, 0) == r.size && Packets.i32(out, o + 6) == DnsCache.STALE_TTL_S)
    }

    // ---------------------------------------------------------------- RollingCounter ↔ model
    T.group("Sızma 20 / RollingCounter ↔ naif model: 300 tohum × 800 örnek (sıfırlanan sayaç, sık çağrı, pencere kayması)")
    run {
        var fails = 0; var first = ""
        for (seed in 0 until 300) {
            val rnd = Random(seed.toLong() * 7919)
            val win = 60_000L; val gap = 5_000L
            val rc = RollingCounter(win, gap)
            // model: taban örnekleri (zaman, değer); ≥gap aralıkla eklenir; pencereden eskiyenler atılır ama pencereye en yakın olan kalır
            val base = ArrayList<Pair<Long, Long>>(); var last = 0L
            var now = 0L; var total = 0L
            for (step in 0 until 800) {
                now += when (rnd.nextInt(5)) { 0 -> 0L; 1 -> rnd.nextInt(1, 500).toLong(); 2 -> gap; 3 -> rnd.nextInt(1, 20_000).toLong(); else -> rnd.nextInt(1, 200_000).toLong() }
                total = if (rnd.nextInt(40) == 0) rnd.nextInt(0, 50).toLong() else total + rnd.nextInt(0, 30)
                rc.record(now, total)
                if (base.isNotEmpty() && total < last) base.clear()
                last = total
                if (base.isEmpty() || now - base.last().first >= gap) base.add(now to total)
                while (base.size > 1 && now - base[1].first >= win) base.removeAt(0)
                val exp = if (base.isEmpty()) 0L else maxOf(0L, last - base[0].second)
                if (rc.recent() != exp) { fails++; if (first.isEmpty()) first = "seed=$seed adım=$step now=$now total=$total beklenen=$exp bizim=${rc.recent()}"; break }
            }
        }
        T.check("240 bin örnekte sayaç modelle aynı", fails == 0, "fark=$fails $first")
    }

    // ---------------------------------------------------------------- HostsList: kural türü tablosu (kural → beklenen sonuç)
    T.group("Sızma 20 / HostsList: AdBlock kozmetik/betik kuralları alan adını ENGELLEMEZ; her kural türü için beklenen sonuç tablosu")
    run {
        fun names(vararg lines: String) = HostsList.parse(lines.joinToString("\n")).names
        // Kozmetik/betik kuralları bir sayfanın öğesini gizler, siteyi engellemez
        T.check("site.com##.banner → engellenmez", names("site.com##.banner").isEmpty())
        T.check("site.com#@#.banner → engellenmez", names("site.com#@#.banner").isEmpty())
        T.check("site.com#?#div:has(.ad) → engellenmez", names("site.com#?#div:has(.ad)").isEmpty())
        T.check("site.com#\$#body { x: y } → engellenmez", names("site.com#\$#body { x: y }").isEmpty())
        T.check("site.com#%#//scriptlet('x') → engellenmez", names("site.com#%#//scriptlet('x')").isEmpty())
        T.check("a.com,b.com##.ad → engellenmez", names("a.com,b.com##.ad").isEmpty())
        T.check("##.genel-kural (alansız) → engellenmez", names("##.reklam").isEmpty())
        // Gerçek engel kuralları etkilenmez
        T.check("hosts satırı sonundaki yorum: '0.0.0.0 ads.com # not' → ads.com", names("0.0.0.0 ads.com # not") == listOf("ads.com"))
        T.check("'0.0.0.0 ads.com #not' → ads.com", names("0.0.0.0 ads.com #not") == listOf("ads.com"))
        T.check("||ads.com^ → ads.com", names("||ads.com^") == listOf("ads.com"))
        T.check("||ads.com^\$third-party → ads.com; \$script → atlanır", names("||ads.com^\$third-party") == listOf("ads.com") && names("||ads.com^\$script").isEmpty())
        T.check("karışık dosyada yalnızca gerçek engeller kalır", names("! baslik", "site.com##.x", "||ads.com^", "good.org#@#.y", "0.0.0.0 t.net") == listOf("ads.com", "t.net"))
        T.check("dnsmasq address=/a.com/0.0.0.0 → a.com; yönlendirme server=/a.com/1.1.1.1 → atlanır", names("address=/a.com/0.0.0.0") == listOf("a.com") && names("server=/a.com/1.1.1.1").isEmpty())
        T.check("RPZ 'x.com CNAME .' → x.com; Unbound local-zone always_nxdomain → u.com", names("x.com CNAME .") == listOf("x.com") && names("local-zone: \"u.com.\" always_nxdomain") == listOf("u.com"))
        T.check("genel son ek (co.uk, com) engellenmez", names("0.0.0.0 co.uk", "||com^").isEmpty())
        T.check("@@||ok.com^ istisnası ok.com ve alt adlarını listeden çıkarır", HostsList.parse("||ok.com^\n||a.ok.com^\n||x.com^\n@@||ok.com^").names == listOf("x.com"))
    }
}
