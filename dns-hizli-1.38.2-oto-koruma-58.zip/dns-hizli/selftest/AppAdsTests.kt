package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.io.File

/** Uygulama bazlı reklam istatistiği/kipleri, bozulan uygulama kurtarma, liste güncelleme sağlık denetimi (ListCanary). */
fun runAppAdsTests() {
    T.group("Uygulama bazlı reklam: kural kaydı, istatistik, bozulma tespiti")
    run {
        AppAds.reset()
        val m = mapOf("com.banka.app" to AppMode.EXEMPT, "com.oyun.app" to AppMode.STRICT, "com.x.normal" to AppMode.NORMAL, "bozuk paket" to AppMode.EXEMPT)
        val enc = AppAds.encode(m)
        T.check("kayıt: geçersiz paket ve NORMAL atılır", enc == "com.banka.app=E,com.oyun.app=S", enc)
        T.check("kayıt: çözme gidiş-dönüş", AppAds.decode(enc) == mapOf("com.banka.app" to AppMode.EXEMPT, "com.oyun.app" to AppMode.STRICT))
        T.check("kayıt: bozuk girdi yok sayılır", AppAds.decode("com.a.b=X,=E,com.c.d,com.e.f=EE,com.g.h=S,junk===S").keys == setOf("com.g.h"), AppAds.decode("com.a.b=X,=E,com.c.d,com.e.f=EE,com.g.h=S").toString())
        T.check("kayıt: çok uzun metin reddedilir", AppAds.decode("a.b=E,".repeat(30_000)).isEmpty())
        T.check("ayar kaydı: AppSettings gidiş-dönüş", SettingsCodec.decode(SettingsCodec.encode(AppSettings(appAds = enc))).appAds == enc)
        T.check("ayar kaydı: varsayılan boş", AppSettings().appAds == "")

        var now = 1_000_000L
        AppAds.clock = { now }
        fun hit(pkg: String, name: String, n: Int) { repeat(n) { AppAds.record(pkg, name) } }
        hit("com.reklam.oyun", "ads.sdk.example", 5)
        hit("com.reklam.oyun", "banner.example", 2)
        hit("com.sessiz.app", "t.example", 1)
        val top = AppAds.top(5)
        T.check("en çok engelleten uygulama başta", top.first().pkg == "com.reklam.oyun" && top.first().blocked == 7 && top.size == 2)
        T.check("en çok engellenen ad başta", top.first().top.first().first == "ads.sdk.example")
        T.check("az engelde bozulma uyarısı yok", AppAds.suspects().isEmpty())
        hit("com.firtina.app", "api.example", AppAds.STORM)
        val s = AppAds.suspects()
        T.check("aynı ad bir dakikada çok engellenirse şüphe", s.size == 1 && s[0].pkg == "com.firtina.app" && s[0].name == "api.example" && s[0].count >= AppAds.STORM)
        T.check("kurtarma adları", AppAds.namesOf("com.firtina.app") == listOf("api.example"))
        AppAds.dismiss("com.firtina.app")
        T.check("yok sayınca şüphe kalkar", AppAds.suspects().isEmpty())
        hit("com.firtina.app", "api.example", AppAds.STORM)
        T.check("aynı uygulama+ad için yok sayma kalıcı (tekrar uyarı yok)", AppAds.suspects().isEmpty())
        hit("com.firtina.app", "baska.example", AppAds.STORM)
        T.check("başka ad için yeniden şüphe", AppAds.suspects().singleOrNull()?.name == "baska.example")
        AppAds.setRules(mapOf("com.firtina.app" to AppMode.EXEMPT))
        T.check("muaf tutulan uygulamanın şüphesi kalkar", AppAds.suspects().isEmpty())
        AppAds.setRules(emptyMap())
        // pencere: yavaş dağılan engeller fırtına sayılmaz
        AppAds.clearStats()
        repeat(AppAds.STORM * 2) { now += 3_000L; AppAds.record("com.yavas.app", "x.example") }
        T.check("pencere dışına yayılan engeller fırtına sayılmaz", AppAds.suspects().isEmpty())
        T.check("toplam sayaç", AppAds.totalBlocked() == AppAds.STORM * 2)
        // sınırlar
        AppAds.clearStats()
        for (i in 0 until AppAds.MAX_PKGS + 50) AppAds.record("com.p$i.app", "n.example")
        T.check("uygulama tablosu sınırlı", AppAds.top(1000).size <= AppAds.MAX_PKGS)
        for (i in 0 until 100) AppAds.record("com.cok.ad", "n$i.example")
        T.check("uygulama başına ad tablosu sınırlı", AppAds.namesOf("com.cok.ad", 1000).size <= AppAds.MAX_NAMES)
        AppAds.reset()
    }

    T.group("Uygulama bazlı reklam: motor seçimi")
    run {
        AppAds.reset()
        val base = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("a.example"))
        val strict = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("a.example", "b.example"))
        val owners = HashMap<Int, String?>()
        val src = byteArrayOf(10, 0, 0, 2); val dst = byteArrayOf(8, 8, 8, 8)
        var calls = 0
        AppAds.owner = { _, _, sport, _, _ -> calls++; owners[sport] }
        fun pick(sport: Int, b: FilterEngine? = base, st: FilterEngine? = strict) = AppAds.pick(b, st, 17, src, sport, dst, 53)
        owners[1] = "com.banka.app"; owners[2] = "com.oyun.app"; owners[3] = "com.diger.app"; owners[4] = null
        T.check("kural yokken sahip sorulmaz, genel motor", pick(1) === base && calls == 0)
        AppAds.setRules(mapOf("com.banka.app" to AppMode.EXEMPT, "com.oyun.app" to AppMode.STRICT))
        T.check("muaf: motor yok", pick(1) == null)
        T.check("sıkı: sıkı motor", pick(2) === strict)
        T.check("sıkı ama sıkı motor henüz yok: genel motor", pick(2, st = null) === base)
        T.check("kuralsız uygulama: genel motor", pick(3) === base)
        T.check("sahibi bilinmeyen: genel motor (asla yanlışlıkla muaf değil)", pick(4) === base && pick(5) === base)
        T.check("reklam engelleme kapalıyken (motor yok) kipler hiçbir şeyi açmaz", pick(2, b = null) == null)
        val c0 = calls
        pick(1); pick(1); pick(1)
        T.check("aynı soket kısa süre önbellekten (sahip yeniden sorulmaz)", calls == c0)
        AppAds.owner = { _, _, _, _, _ -> throw SecurityException("izin yok") }
        T.check("sahip çözücü hata verirse genel motor", AppAds.pick(base, strict, 6, src, 999, dst, 443) === base)
        T.check("wantsStrict yalnızca sıkı kural varken", AppAds.wantsStrict() && run { AppAds.setRules(mapOf("a.b" to AppMode.EXEMPT)); !AppAds.wantsStrict() })
        // blocked(): sahibine yazar
        AppAds.owner = { _, _, sport, _, _ -> owners[sport] }
        AppAds.blocked(17, src, 2, dst, 53, "x.example")
        AppAds.blocked(17, src, 4, dst, 53, "x.example")
        AppAds.blocked(17, src, 2, dst, 53, null)
        T.check("blocked(): sahip bilinirse yazılır, bilinmezse/adsızsa atlanır", AppAds.totalBlocked() == 1 && AppAds.top(5).single().pkg == "com.oyun.app")
        AppAds.reset()
    }

    T.group("Uygulama bazlı reklam: sıkı motor ve Model (kurtarma)")
    run {
        // Sıkı motor: FilterRuntime yalnızca sıkı kural varken ek motor kurar ve yedek motorda yoktur.
        val dir = File("app/src/main/assets/filter")
        FilterRuntime.reset()
        FilterRuntime.source = FilterSource { n -> File(dir, n).inputStream() }
        FilterRuntime.fallbackSource = FilterRuntime.source
        FilterRuntime.setGateway(FilterLevel.BASIC)
        FilterRuntime.updateNow(FilterLevel.BASIC, emptyList(), emptyList())
        T.check("sıkı kural yokken sıkı motor kurulmaz", FilterRuntime.strictEngine == null && FilterRuntime.strictGwEngine == null && FilterRuntime.engine != null)
        FilterRuntime.setStrictApps(true)
        // setStrictApps arka planda yeniden kurar: bitmesini bekle
        val end = System.currentTimeMillis() + 15_000
        while (FilterRuntime.strictEngine == null && System.currentTimeMillis() < end) Thread.sleep(50)
        val se = FilterRuntime.strictEngine
        val be = FilterRuntime.engine
        T.check("sıkı kural varken sıkı motor kurulur (DNS ve geçit ayrı örnek)", se != null && FilterRuntime.strictGwEngine != null && FilterRuntime.strictGwEngine !== se)
        // Sıkı motor, temel motorun engellediği her şeyi engeller ve daha fazlasını.
        val sample = listOf("doubleclick.net", "googlesyndication.com", "adnxs.com", "criteo.com")
        T.check("sıkı motor temel motorun engellediklerini de engeller", sample.all { be!!.verdictOf(it) == FilterVerdict.PASS || se!!.verdictOf(it) != FilterVerdict.PASS })
        FilterRuntime.setStrictApps(false)
        val end2 = System.currentTimeMillis() + 15_000
        while (FilterRuntime.strictEngine != null && System.currentTimeMillis() < end2) Thread.sleep(50)
        T.check("sıkı kural kalkınca sıkı motor bırakılır", FilterRuntime.strictEngine == null)
        FilterRuntime.reset()
    }

    T.group("Denetim: bozulan uygulama bulgusu")
    run {
        val a = Audit()
        a.feed(AuditSample(at = 1L, adsPlus = true, dohBlock = true, brokenApp = "Oyun", brokenName = "api.example", brokenCount = 55))
        val f = a.active().firstOrNull { it.code == "app.broken" }
        T.check("bozulan uygulama bulgusu üretilir ve bilgi düzeyindedir (puanı düşürmez)", f != null && f.sev == Sev.INFO && a.score() == 100)
        T.check("bulgu metni uygulama, ad ve sayıyı taşır", f != null && f.text(Lang.TR).contains("Oyun") && f.text(Lang.EN).contains("api.example") && f.text(Lang.DE).contains("55"))
        val b = Audit()
        b.feed(AuditSample(at = 1L, adsPlus = false, brokenApp = "Oyun", brokenName = "api.example", brokenCount = 55))
        T.check("reklam engelleme kapalıyken bulgu yok", b.active().none { it.code == "app.broken" })
    }

    T.group("Uygulama bazlı reklam: 12 dil")
    run {
        for (k in AppAdsText.codes().sorted()) {
            val row = AppAdsText.M[k]!!
            T.check("$k: 12 dil dolu", row.size == Lang.values().size && row.all { it.isNotBlank() })
            val ph = Regex("\\{\\d\\}").findAll(row[0]).map { it.value }.toSet()
            T.check("$k: değişkenler tüm dillerde aynı", row.all { r -> Regex("\\{\\d\\}").findAll(r).map { it.value }.toSet() == ph })
        }
        T.check("değişken yerine konur", AppAdsText.t("rescueAllow", Lang.EN, "3") == "Allow the blocked names (3)")
        T.check("bilinmeyen anahtar anahtarın kendisi", AppAdsText.t("yok") == "yok")
        T.check("her dil farklı başlık", Lang.values().map { AppAdsText.t("title", it) }.toSet().size == Lang.values().size)
    }

    runListCanaryTests()
}

private fun encodeTier(hashes: LongArray): ByteArray {
    val s = hashes.sorted().distinct()
    val o = ByteArrayOutputStream()
    o.write("DNF1".toByteArray())
    o.write(byteArrayOf((s.size ushr 24).toByte(), (s.size ushr 16).toByte(), (s.size ushr 8).toByte(), s.size.toByte()))
    var prev = 0L
    for (h in s) {
        var v = h - prev; prev = h
        while (true) { val b = (v and 0x7F).toInt(); v = v ushr 7; if (v == 0L) { o.write(b); break } else o.write(b or 0x80) }
    }
    return o.toByteArray()
}

fun runListCanaryTests() {
    T.group("Liste güncelleme sağlık denetimi (ListCanary)")
    val dir = File("app/src/main/assets/filter")
    val names = ListUpdate.UPDATABLE
    val real = names.associateWith { File(dir, it).readBytes() }
    val prot = ListCanary.protectedOf(File(dir, "protected.txt").readText())
    val ref = names.associateWith { FilterTier.read(java.io.ByteArrayInputStream(real[it]!!)).size }
    val t0 = ListCanary.check(real, prot, ref)
    T.check("pakettteki gerçek listeler denetimden geçer", t0 == null, t0 ?: "")
    T.check("korunan küme olmadan da geçer (liste kendi başına güvenli)", ListCanary.check(real, FilterTier.EMPTY, ref) == null, ListCanary.check(real, FilterTier.EMPTY, ref) ?: "")

    // popüler siteyi içeren zehirli liste
    val poison = real.toMutableMap()
    poison["basic.bin"] = encodeTier(longArrayOf(FilterHash.hash("google.com")))
    T.check("popüler siteyi (google.com) engelleyen liste reddedilir", ListCanary.check(poison, prot, null)?.startsWith("engelli:") == true, ListCanary.check(poison, prot, null) ?: "null")
    val poison2 = real.toMutableMap()
    poison2["strict.bin"] = encodeTier(longArrayOf(FilterHash.hash("whatsapp.com"), FilterHash.hash("doubleclick.net")))
    T.check("alt tabakadaki zehir de yakalanır (en sıkı seviyede kurulur)", ListCanary.check(poison2, prot, null)?.startsWith("engelli:") == true)
    // boş / etkisiz liste
    val empty = names.associateWith { encodeTier(longArrayOf(FilterHash.hash("ornek.example"))) }
    T.check("reklam ağlarını engellemeyen (etkisiz) liste reddedilir", ListCanary.check(empty, prot, null)?.startsWith("zayif:") == true, ListCanary.check(empty, prot, null) ?: "null")
    // bozuk / eksik
    val cut = real.toMutableMap(); cut["medium.bin"] = real["medium.bin"]!!.copyOf(1000)
    T.check("kesik dosya reddedilir", ListCanary.check(cut, prot, null)?.startsWith("bozuk:") == true)
    val miss = real.toMutableMap(); miss.remove("strict.bin")
    T.check("eksik dosya reddedilir", ListCanary.check(miss, prot, null) == "eksik:strict.bin")
    val junk = real.toMutableMap(); junk["basic.bin"] = ByteArray(5000) { 7 }
    T.check("tanınmayan biçim reddedilir", ListCanary.check(junk, prot, null)?.startsWith("bozuk:") == true)
    // boyut denetimi
    val tiny = real.toMutableMap(); tiny["medium.bin"] = encodeTier(LongArray(10) { FilterHash.hash("x$it.example") })
    T.check("paketteki sürümün yarısından küçük liste (kırpılmış) reddedilir", ListCanary.check(tiny, prot, ref)?.startsWith("kirpilmis:") == true, ListCanary.check(tiny, prot, ref) ?: "null")
    val small = ref.mapValues { maxOf(1, it.value / 10) }
    T.check("paketteki sürümün 4 katından büyük liste (şişmiş) reddedilir", ListCanary.check(real, prot, small)?.startsWith("sismis:") == true)
    T.check("MUST_PASS listesi geniş ve yinelenmesiz", ListCanary.MUST_PASS.size >= 40 && ListCanary.MUST_PASS.toSet().size == ListCanary.MUST_PASS.size)
}

fun runDpiQualityTests() {
    T.group("DPI: yöntem puanı, hız ölçümü, site belleği")
    run {
        val p = Dpi.Planner()
        // iki yöntem oy olarak yakın; biri belirgin daha hızlı: hızlı olan tercih edilir
        repeat(8) { p.worked("a.example:443", Dpi.TLS, 1, 0, 400L) }
        repeat(7) { p.worked("b.example:443", Dpi.TLS, 0, 0, 90L) }
        val stats = p.methodStats()
        T.check("yöntem tablosu kazanç ve süre taşır", stats.any { it.plan == 1 && it.wins == 8 && it.avgMs in 380..420 } && stats.any { it.plan == 0 && it.wins == 7 && it.avgMs in 80..100 })
        T.check("ölçülmemiş yöntem tabloda yok", stats.none { it.plan == 5 })
        T.check("oylar yakınsa daha hızlı yöntem ağ önceliği olur", p.first("yeni.example:443", Dpi.TLS) == 0, p.first("yeni.example:443", Dpi.TLS).toString())
        val q = Dpi.Planner()
        repeat(8) { q.worked("a.example:443", Dpi.TLS, 1, 0, 100L) }
        repeat(2) { q.worked("b.example:443", Dpi.TLS, 0, 0, 10L) }
        T.check("oyu çok az olan hızlı yöntem öne geçmez", q.first("yeni.example:443", Dpi.TLS) == 1)
        // başarısız denemeler sayılır
        val w = Dpi.Planner()
        w.worked("x.example:443", Dpi.TLS, 3, (1 shl 1) or (1 shl 0), 50L)
        T.check("başarısız denenen yöntemler tabloya yazılır", w.methodStats().filter { it.fails == 1 }.map { it.plan }.toSet() == setOf(0, 1))
        // site belleği dışa/içe aktarma
        val e = Dpi.Planner()
        e.worked("gizli.site.example:443", Dpi.TLS, 6, 0, 80L)
        val ex = e.siteExport()
        T.check("site belleği özet anahtarlı (ad yok)", ex.keys.single() == Dpi.siteKey("gizli.site.example:443") && ex.keys.none { it.contains("gizli") })
        val f = Dpi.Planner()
        f.siteImport(ex)
        T.check("içe aktarılan site belleği o siteyi doğru yöntemle başlatır", f.first("gizli.site.example:443", Dpi.TLS) == 6 && f.first("baska.example:443", Dpi.TLS) != 6)
        f.worked("gizli.site.example:443", Dpi.TLS, 2, 0, 40L)
        f.siteImport(ex)
        T.check("içe aktarma canlı öğrenileni ezmez", f.first("gizli.site.example:443", Dpi.TLS) == 2)
        f.forget()
        T.check("forget tabloyu ve belleği temizler", f.methodStats().isEmpty() && f.siteExport().isEmpty())
    }

    T.group("DPI: kalıcı site belleği (PlanMemory)")
    run {
        var now = 1_000_000L
        val m = PlanMemory()
        m.clock = { now }
        val saved = ArrayList<String>()
        m.onChange = { saved.add(it) }
        val key = PlanMemory.key(NetKind.MOBILE, "28603")
        m.put(key, Dpi.TLS, 4)
        val n0 = saved.size
        m.putSite(key, "abc123", 7)
        T.check("ilk site yazımı kaydedilir", saved.size == n0 + 1 && m.sites(key)["abc123"] == 7)
        m.putSite(key, "def456", 2)
        T.check("kayıt en sık dakikada bir (aşırı yazma yok)", saved.size == n0 + 1)
        now += PlanMemory.SITE_SAVE_MS + 1
        m.putSite(key, "0f0f0f", 3)
        T.check("süre dolunca yeniden kaydedilir", saved.size == n0 + 2)
        val enc = m.encode()
        val m2 = PlanMemory(); m2.decode(enc)
        T.check("kodlama gidiş-dönüş (yöntemler + siteler)", m2.get(key) == (4 to -1) && m2.sites(key) == m.sites(key), enc)
        val old = PlanMemory(); old.decode("WIFI|=3,1;MOBILE|28603=4,2")
        T.check("eski (siteler olmayan) kayıt okunur", old.get("WIFI|") == (3 to 1) && old.sites("WIFI|").isEmpty())
        val bad = PlanMemory(); bad.decode("WIFI|=3,1,zzz.9/abc.99/ABC.1/12345678901234.1/ab.3")
        T.check("bozuk site girdileri atlanır", bad.sites("WIFI|") == mapOf("ab" to 3), bad.sites("WIFI|").toString())
        val cap = PlanMemory(); now += 1
        repeat(PlanMemory.SITES_PER_NET + 20) { cap.putSite("WIFI|", Integer.toHexString(it + 1), 1) }
        T.check("ağ başına site sayısı sınırlı, en eski atılır", cap.sites("WIFI|").size == PlanMemory.SITES_PER_NET && !cap.sites("WIFI|").containsKey("1"))
        cap.putSite("WIFI|", "ff", 99)
        T.check("aralık dışı yöntem yazılmaz", !cap.sites("WIFI|").containsKey("ff"))
    }

    T.group("DNS sızıntı testi (LeakProbe) ve denetim bulgusu")
    run {
        val pkt = ByteArray(64)
        T.check("test yokken etkin değil", !LeakProbe.active)
        val name = LeakProbe.begin()
        T.check("test adı .invalid ve benzersiz", name.endsWith(".invalid") && name != run { LeakProbe.end(); LeakProbe.begin() }.also { })
        val nm = LeakProbe.begin()
        val tok = nm.removeSuffix(".invalid").toByteArray()
        LeakProbe.check(pkt, 0, pkt.size)
        T.check("ad geçmediyse görülmez", !LeakProbe.seen())
        System.arraycopy(tok, 0, pkt, 20, tok.size)
        LeakProbe.check(pkt, 0, pkt.size)
        T.check("paket içinde ad görülürse işaretlenir", LeakProbe.seen())
        T.check("end: tünelden geçti, test kapanır", LeakProbe.end() && !LeakProbe.active)
        LeakProbe.begin(); LeakProbe.check(pkt, 0, 3); LeakProbe.check(pkt, 60, 10); LeakProbe.check(pkt, -1, 5)
        T.check("sınır dışı/kısa girdi güvenli", !LeakProbe.seen())
        T.check("end: geçmedi", !LeakProbe.end())
        val a = Audit()
        a.feed(AuditSample(at = 1L, dnsOn = true, dohBlock = true, leakProbe = 2))
        val f = a.active().firstOrNull { it.code == "leak.private-dns" }
        T.check("sızıntı testi başarısızsa bulgu (uyarı, sızıntı kategorisi)", f != null && f.sev == Sev.WARN && f.cat == AuditCat.LEAK)
        val b = Audit(); b.feed(AuditSample(at = 1L, dnsOn = true, dohBlock = true, leakProbe = 1))
        T.check("test başarılıysa bulgu yok", b.active().none { it.code == "leak.private-dns" })
        val c = Audit(); c.feed(AuditSample(at = 1L, vpnUp = false, wanted = false, leakProbe = 2))
        T.check("tünel yokken bulgu yok", c.active().none { it.code == "leak.private-dns" })
    }

    T.group("Durum özeti ve rapor")
    run {
        val none = emptyList<Finding>()
        val ok = HealthSummary.rows(true, true, true, true, none, Lang.TR)
        T.check("sorunsuz: dört satır da çalışıyor", ok.size == 4 && ok.all { it.state == Health.OK && it.detail == "Çalışıyor" })
        val off = HealthSummary.rows(false, true, true, true, none, Lang.EN)
        T.check("bağlı değilken hepsi kapalı", off.all { it.state == Health.OFF && it.detail == "Not connected" })
        val mixed = HealthSummary.rows(true, true, false, true, listOf(Finding(AuditCat.STABILITY, Sev.WARN, "stab.timeouts", listOf("40", "8", "20")), Finding(AuditCat.LEAK, Sev.CRIT, "leak.tunnel-down"), Finding(AuditCat.DPI, Sev.WARN, "dpi.failing", listOf("50", "10", "20"))), Lang.EN)
        val by = mixed.associateBy { it.key }
        T.check("DNS bulgusu DNS satırına, kritik sızıntı bağlantı satırına", by["dns"]!!.state == Health.WARN && by["net"]!!.state == Health.BAD)
        T.check("kapalı modülün satırı kapalı (bulgu görünmez)", by["dpi"]!!.state == Health.OFF && by["dpi"]!!.detail == "Off")
        T.check("reklam satırı bulgusuz çalışıyor", by["ads"]!!.state == Health.OK)
        val info = HealthSummary.rows(true, true, true, true, listOf(Finding(AuditCat.ADS, Sev.INFO, "app.broken", listOf("Oyun", "x", "50"))), Lang.TR)
        T.check("bilgi düzeyi bulgu satırı bozmaz (yeşil kalır, metin görünür)", info[2].state == Health.OK && info[2].detail.contains("Oyun"))

        val rep = DiagReport.build(DiagInput(appVersion = "1", versionCode = 1, androidSdk = 34, deviceModel = "x", netKind = "wifi", vpnActive = true, encryption = "dot", odoh = "", ipMode = "auto",
            failClosed = false, strictEncryption = false, filterMem = "", problems = 0, crashCount = 0, lastCrash = null, dpi = listOf("TLS 1: 12 kazanç, 0 başarısız, ort 140 ms")))
        T.check("rapor DPI yöntem tablosunu içerir", rep.contains("DPI yöntemleri (bu ağ):") && rep.contains("TLS 1: 12 kazanç"), rep.take(200))
        val rep2 = DiagReport.build(DiagInput(appVersion = "1", versionCode = 1, androidSdk = 34, deviceModel = "x", netKind = "wifi", vpnActive = true, encryption = "dot", odoh = "", ipMode = "auto",
            failClosed = false, strictEncryption = false, filterMem = "", problems = 0, crashCount = 0, lastCrash = null))
        T.check("tablo yoksa bölüm yok", !rep2.contains("DPI yöntemleri"))
    }
}

/** Oto-koruma 25: kod çözücüler rastgele girdide çökmez, günlük kategorileri yanlış etiketlemez. */
fun runTruthfulnessTests() {
    T.group("Sertleştirme: kod çözücü fuzz + günlük doğruluğu")
    val rnd = java.util.Random(25)
    val alpha = "abcdef0123456789=,;/.|-_ SEN\u0000é"
    var ok = true
    repeat(3000 * FUZZ_X) {
        val s = String(CharArray(rnd.nextInt(200)) { alpha[rnd.nextInt(alpha.length)] })
        try { AppAds.decode(s); PlanMemory().decode(s); PlanMemory().decode("WIFI|=1,2,${s}") } catch (e: Throwable) { ok = false }
    }
    T.check("AppAds/PlanMemory.decode rastgele girdide çökmez", ok)
    val big = PlanMemory().also { it.decode("WIFI|=1,2," + "abc.1/".repeat(500)) }
    T.check("PlanMemory: site sayısı sınırlı", big.sites("WIFI|").size <= PlanMemory.SITES_PER_NET)
    var ok2 = true
    repeat(200) {
        val b = ByteArray(rnd.nextInt(3000)).also { rnd.nextBytes(it) }
        try { ListCanary.check(mapOf("ads.txt" to b)) } catch (e: Throwable) { ok2 = false }
    }
    T.check("ListCanary.check rastgele baytta çökmez", ok2)
    T.check("kategori: 'ağ engeli' reklam sayılmaz", Journal.categorize("ağ engeli algılandı") != "REKLAM")
    T.check("kategori: 'ech' alt dizgesi DPI sayılmaz", Journal.categorize("technical bech") != "DPI")
    T.check("kategori: ECH kelimesi DPI", Journal.categorize("ECH kapalı") == "DPI")
    val im = Immune()
    val ch = im.decodeAll("|A.NET_BLOCK.QUIC_OFF;A.AD_LEAK.QUIC_OFF", 1000)
    T.check("oto-koruma: aynı sürekli önlem iki tehdide yazılmaz", ch.size == 1 && im.active() == setOf(Act.QUIC_OFF))
    var ok3 = true
    val al = "ABSPOOFNETLQUICFLOWHARD_.;|0123456789-"
    repeat(3000 * FUZZ_X) {
        val t = String(CharArray(rnd.nextInt(300)) { al[rnd.nextInt(al.length)] })
        try { val i = Immune(); i.decodeAll(t, 5000); i.decode(t); i.tick(6000); i.tick(900_000); i.selfCheck(10) } catch (e: Throwable) { ok3 = false }
    }
    T.check("Immune.decode/decodeAll/tick bozuk girdide çökmez", ok3)
        T.check("kategori: engellendi reklam", Journal.categorize("3 alan adı engellendi") == "REKLAM")
}

/** Düz HTTP'de enjekte edilmiş engel sayfası yönlendirmesi tespiti (Dpi.looksLikeBlockRedirect). */
fun runBlockRedirectTests() {
    T.group("DPI: enjekte edilmiş HTTP yönlendirmesi (engel sayfası IP'si)")
    fun r(s: String) = s.toByteArray(Charsets.ISO_8859_1).let { Dpi.looksLikeBlockRedirect(it, it.size) }
    T.check("bilinen engel sayfası IP'sine 302 → enjekte", r("HTTP/1.1 302 Found\r\nLocation: http://195.175.254.2/\r\nContent-Length: 0\r\n\r\n"))
    T.check("başlık adı büyük/küçük harf fark etmez", r("HTTP/1.1 301 Moved\r\nServer: x\r\nLOCATION: HTTP://195.175.254.2:80/a\r\n\r\n"))
    T.check("https adresi de eşleşir", r("HTTP/1.0 302 Found\r\nLocation: https://195.175.254.2\r\n\r\n"))
    T.check("sıradan bir IP'ye yönlendirme enjekte sayılmaz", !r("HTTP/1.1 302 Found\r\nLocation: http://93.184.216.34/\r\n\r\n"))
    T.check("ad ile yönlendirme (IP değil) sayılmaz", !r("HTTP/1.1 302 Found\r\nLocation: http://example.org/\r\n\r\n"))
    T.check("200 cevabı sayılmaz", !r("HTTP/1.1 200 OK\r\nLocation: http://195.175.254.2/\r\n\r\n"))
    T.check("bozuk adres (256, eksik oktet, uzun) sayılmaz", !r("HTTP/1.1 302 F\r\nLocation: http://195.175.254.256/\r\n\r\n") &&
        !r("HTTP/1.1 302 F\r\nLocation: http://195.175.254/\r\n\r\n") && !r("HTTP/1.1 302 F\r\nLocation: http://1950.175.254.2/\r\n\r\n"))
    val rnd = java.util.Random(7)
    var ok = true
    repeat(20_000 * FUZZ_X) {
        val b = ByteArray(rnd.nextInt(300)).also { rnd.nextBytes(it) }
        if (b.size > 12 && rnd.nextBoolean()) { val h = "HTTP/1.1 302 F\r\nLocation: http://".toByteArray(); System.arraycopy(h, 0, b, 0, minOf(h.size, b.size)) }
        try { Dpi.looksLikeBlockRedirect(b, b.size); Dpi.looksLikeBlockRedirect(b, b.size + 50) } catch (e: Throwable) { ok = false }
    }
    T.check("rastgele girdide çökmez, sınır dışına okumaz", ok)
}

/** Engelli site listesi: ayrıştırma, imza, geri alma sürümü, alt alan adı eşleşmesi, seçici QUIC için SNI. */
fun runBlockedSitesTests() {
    T.group("Engelli site listesi (OONI): ayrıştırma, imza, eşleşme")
    fun b(s: String) = s.toByteArray()
    val txt = "# surum=1760000000\nengel.example\nSub.Engel2.example\nbad name.com\n1.2.3.4\n-x.com\ncom\n\n" + "a".repeat(70) + ".com\n"
    val p = BlockedSites.parse(b(txt))
    T.check("geçerli adlar alınır, geçersizler atlanır", p != null && p.version == 1760000000L && p.names == setOf("engel.example", "sub.engel2.example"), p?.names.toString())
    T.check("sürüm satırı yoksa / bozuksa reddedilir", BlockedSites.parse(b("engel.example\n")) == null && BlockedSites.parse(b("# surum=abc\nx.example\n")) == null && BlockedSites.parse(b("# surum=0\nx.example\n")) == null)
    T.check("boş ve çok büyük dosya reddedilir", BlockedSites.parse(ByteArray(0)) == null && BlockedSites.parse(ByteArray(BlockedSites.MAX_BYTES + 1) { 'a'.code.toByte() }) == null)
    BlockedSites.set(p!!.names)
    T.check("alt alan adı eşleşir", BlockedSites.matches("www.engel.example") && BlockedSites.matches("a.b.sub.engel2.example") && BlockedSites.matches("ENGEL.example."))
    T.check("üst alan adı ve başka ad eşleşmez", !BlockedSites.matches("example") && !BlockedSites.matches("engel2.example") && !BlockedSites.matches("notengel.example") && !BlockedSites.matches(""))
    BlockedSites.reset()
    T.check("liste boşken hiçbir şey eşleşmez", !BlockedSites.any() && !BlockedSites.matches("engel.example"))
    val kp = java.security.KeyPairGenerator.getInstance("EC").run { initialize(java.security.spec.ECGenParameterSpec("secp256r1")); generateKeyPair() }
    val other = java.security.KeyPairGenerator.getInstance("EC").run { initialize(java.security.spec.ECGenParameterSpec("secp256r1")); generateKeyPair() }
    fun sign(d: ByteArray, k: java.security.PrivateKey) = java.security.Signature.getInstance("SHA256withECDSA").run { initSign(k); update(d); sign() }
    val data = b(txt)
    T.check("doğru imza kabul", BlockedSites.verified(data, sign(data, kp.private), kp.public) != null)
    T.check("başka anahtarın imzası reddedilir", BlockedSites.verified(data, sign(data, other.private), kp.public) == null)
    T.check("değiştirilmiş liste reddedilir", BlockedSites.verified(b(txt + "ek.example\n"), sign(data, kp.private), kp.public) == null)
    val rnd = java.util.Random(11)
    var ok = true
    repeat(5_000 * FUZZ_X) {
        val x = ByteArray(rnd.nextInt(400)).also { rnd.nextBytes(it) }
        if (x.size > 12 && rnd.nextBoolean()) System.arraycopy(b("# surum=5\n"), 0, x, 0, 10)
        try { BlockedSites.parse(x) } catch (e: Throwable) { ok = false }
    }
    T.check("rastgele girdide ayrıştırıcı çökmez", ok)
}
