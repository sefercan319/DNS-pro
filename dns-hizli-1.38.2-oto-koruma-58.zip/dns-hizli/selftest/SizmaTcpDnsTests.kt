package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.util.Random
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger

/**
 * Sızma 14 — TcpDns (tünelin kendi DNS-over-TCP durum makinesi) düşman istemciye karşı.
 *
 * Her çıkış paketi bağımsız RFC denetçisinden ([wireViolations]) geçer. Saldırılar: SYN seli, yavaş bağlantılar, boru hattı
 * bombası, bozuk uzunluk, sıra numarası saldırıları (kör RST, sahte SYN, tekrar/çakışma/FIN sonrası veri), %25 kayıplı ağda
 * yüzlerce konuşma (RTO), rastgele çöp paket yağmuru ve gerçek zamanlayıcı iş parçacığı altında çok iş parçacıklı yarış.
 */

private val TD_FAKE4 = byteArrayOf(10, 111, 222.toByte(), 2)
private val TD_VIRT4 = byteArrayOf(10, 111, 222.toByte(), 3)
private val TD_VIRT6 = SelfTest.FAKE6.copyOf().also { it[15] = 3 }
private fun tdIp(a: ByteArray) = Packets.ip(a[0].toInt() and 0xFF, a[1].toInt() and 0xFF, a[2].toInt() and 0xFF, a[3].toInt() and 0xFF)

private const val TD_FIN = TcpDns.FIN
private const val TD_SYN = TcpDns.SYN
private const val TD_RST = TcpDns.RST
private const val TD_PSH = TcpDns.PSH
private const val TD_ACK = TcpDns.ACK

private class TdSeg(val flags: Int, val seq: Int, val ack: Int, val win: Int, val data: ByteArray, val cport: Int, val mss: Int)

private fun tdParse(p: ByteArray): TdSeg {
    val six = (p[0].toInt() ushr 4) == 6
    val ip = if (six) 40 else 20
    val total = if (six) 40 + Packets.u16(p, 4) else Packets.u16(p, 2)
    val doff = (p[ip + 12].toInt() and 0xF0) ushr 2
    var mss = 0
    if (doff >= 24 && p[ip + 20].toInt() == 2) mss = Packets.u16(p, ip + 22)
    return TdSeg(p[ip + 13].toInt() and 0xFF, Packets.i32(p, ip + 4), Packets.i32(p, ip + 8), Packets.u16(p, ip + 14), p.copyOfRange(ip + doff, total), Packets.u16(p, ip + 2), mss)
}

private fun tdPkt(v6: Boolean, src: ByteArray, dst: ByteArray, sport: Int, dport: Int, seq: Int, ack: Int, flags: Int, data: ByteArray = ByteArray(0), mss: Int = 0, win: Int = 65535): ByteArray {
    val ipLen = if (v6) 40 else 20
    val tcpLen = 20 + (if (mss > 0) 4 else 0)
    val total = ipLen + tcpLen + data.size
    val p = ByteArray(total)
    if (v6) {
        p[0] = 0x60; Packets.put16(p, 4, tcpLen + data.size); p[6] = 6; p[7] = 64
        System.arraycopy(src, 0, p, 8, 16); System.arraycopy(dst, 0, p, 24, 16)
    } else {
        p[0] = 0x45; Packets.put16(p, 2, total); Packets.put16(p, 6, 0x4000); p[8] = 64; p[9] = 6
        System.arraycopy(src, 0, p, 12, 4); System.arraycopy(dst, 0, p, 16, 4)
        Packets.put16(p, 10, Packets.checksum(p, 0, 20))
    }
    val t = ipLen
    Packets.put16(p, t, sport); Packets.put16(p, t + 2, dport)
    Packets.put32(p, t + 4, seq); Packets.put32(p, t + 8, ack)
    p[t + 12] = ((tcpLen / 4) shl 4).toByte(); p[t + 13] = flags.toByte(); Packets.put16(p, t + 14, win)
    if (mss > 0) { p[t + 20] = 2; p[t + 21] = 4; Packets.put16(p, t + 22, mss) }
    System.arraycopy(data, 0, p, t + tcpLen, data.size)
    Packets.put16(p, t + 16, TcpDns.tcpChecksum(p, t, tcpLen + data.size, src, dst))
    return p
}

private fun tdFramed(dns: ByteArray): ByteArray = ByteArray(2 + dns.size).also { Packets.put16(it, 0, dns.size); System.arraycopy(dns, 0, it, 2, dns.size) }

/** Soru iletisinden TXT kayıtlı cevap üretir ([txt] bayt veri; 255'lik parçalara bölünür). */
private fun tdAnswer(q: ByteArray, txt: Int): ByteArray {
    var i = 12
    while (i < q.size && q[i].toInt() != 0) i += (q[i].toInt() and 0xFF) + 1
    val qEnd = i + 1 + 4
    val chunks = (txt + 254) / 255
    val rdLen = txt + chunks
    val out = ByteArray(qEnd + 12 + rdLen)
    System.arraycopy(q, 0, out, 0, qEnd)
    out[2] = (out[2].toInt() or 0x80).toByte()                         // QR
    Packets.put16(out, 6, 1)                                             // ANCOUNT
    Packets.put16(out, 10, 0)                                            // ARCOUNT (OPT yok)
    var o = qEnd
    Packets.put16(out, o, 0xC00C); Packets.put16(out, o + 2, 16); Packets.put16(out, o + 4, 1); Packets.put32(out, o + 6, 60); Packets.put16(out, o + 10, rdLen)
    o += 12
    var left = txt
    while (left > 0) { val n = minOf(255, left); out[o++] = n.toByte(); for (k in 0 until n) out[o++] = ('a'.code + k % 26).toByte(); left -= n }
    return out
}

private class TdQ(val v6: Boolean, val port: Int, val dns: ByteArray)

private class TdRig(seed: Long, timer: Boolean = false, clock: (() -> Long)? = null, val demux: Boolean = false) {
    @Volatile var now = 1_000_000L
    val outs = ConcurrentLinkedQueue<ByteArray>()
    val ports = java.util.concurrent.ConcurrentHashMap<Int, ConcurrentLinkedQueue<ByteArray>>()
    val bad = ConcurrentLinkedQueue<String>()
    val sent = AtomicInteger()
    val queries = ArrayList<TdQ>()
    val tcp: TcpDns = TcpDns(
        { b, o, l ->
            val p = b.copyOfRange(o, o + l)
            sent.incrementAndGet()
            if (bad.size < 40) for (v in wireViolations(p)) bad.add(v)
            if (demux) ports.computeIfAbsent(tdParse(p).cport) { ConcurrentLinkedQueue() }.add(p) else outs.add(p)
        },
        { p, n ->
            val six = (p[0].toInt() ushr 4) == 6
            val q = if (six) TdQ(true, Packets.u16(p, 40), p.copyOfRange(Packets.HDR6, n)) else TdQ(false, Packets.u16(p, 20), p.copyOfRange(Packets.HDR, n))
            synchronized(queries) { queries.add(q) }
        },
        clock ?: { now }, Random(seed), timer,
    )

    fun drain(): List<ByteArray> { val l = ArrayList<ByteArray>(); while (true) l.add(outs.poll() ?: break); return l }

    fun drainPort(port: Int): List<TdSeg> {
        val q = ports[port] ?: return emptyList()
        val l = ArrayList<TdSeg>()
        while (true) l.add(tdParse(q.poll() ?: break))
        return l
    }

    fun takeQueries(): List<TdQ> = synchronized(queries) { val l = ArrayList(queries); queries.clear(); l }

    fun reply(q: TdQ, dns: ByteArray) {
        val scratch = ByteArray(2200)
        if (q.v6) {
            val out = ByteArray(Packets.HDR + dns.size + Packets.ROOM)
            System.arraycopy(dns, 0, out, Packets.HDR, dns.size)
            Packets.writeReply6(out, scratch, 77, SelfTest.FAKE6, TD_VIRT6, 53, q.port, dns.size) { b, o, l -> tcp.offer(b, o, l) }
        } else {
            val out = ByteArray(Packets.HDR + dns.size)
            System.arraycopy(dns, 0, out, Packets.HDR, dns.size)
            Packets.writeReply(out, scratch, Packets.nextIdent(), tdIp(TD_FAKE4), tdIp(TD_VIRT4), 53, q.port, dns.size) { b, o, l -> tcp.offer(b, o, l) }
        }
    }
}

/** Tek bir sahte istemci bağlantısı: ham paket kurar; gelen segmentleri kendi bağlantı portuna göre ayıklar. */
private class TdCli(val r: TdRig, val v6: Boolean, val addr: ByteArray, val port: Int) {
    val srv: ByteArray = if (v6) SelfTest.FAKE6 else TD_FAKE4
    var seq = 5000
    var rcv = 0
    val stream = ByteArrayOutputStream()

    fun pkt(flags: Int, data: ByteArray = ByteArray(0), seq: Int = this.seq, ack: Int = rcv, mss: Int = 0, win: Int = 65535) =
        tdPkt(v6, addr, srv, port, 53, seq, ack, flags, data, mss, win)

    fun send(flags: Int, data: ByteArray = ByteArray(0), seq: Int = this.seq, ack: Int = rcv, mss: Int = 0) {
        val p = pkt(flags, data, seq, ack, mss); r.tcp.onPacket(p, p.size)
    }

    fun sendData(data: ByteArray) { send(TD_ACK or TD_PSH, data); seq += data.size }

    /** Bu istemciye giden ve kuyrukta bekleyen segmentler (başkalarının segmentleri atılır; denetçi zaten hepsini gördü). */
    fun recv(): List<TdSeg> = r.drain().map { tdParse(it) }.filter { it.cport == port }

    fun connect(mss: Int = 1460): TdSeg? {
        send(TD_SYN, seq = seq, ack = 0, mss = mss)
        seq++
        val sa = recv().firstOrNull { it.flags and (TD_SYN or TD_ACK) == (TD_SYN or TD_ACK) } ?: return null
        rcv = sa.seq + 1
        send(TD_ACK)
        return sa
    }

    /** Gelen sıralı veriyi toplar ve onaylar; toplanan bayt sayısı. */
    fun collect(): Int {
        var n = 0
        for (s in recv()) {
            if (s.data.isNotEmpty() && s.seq == rcv) { stream.write(s.data); rcv += s.data.size; n += s.data.size }
            if (s.flags and TD_FIN != 0 && s.seq + s.data.size == rcv) rcv++
        }
        if (n > 0) send(TD_ACK)
        return n
    }
}

private fun tdCliAddr(v6: Boolean, i: Int): ByteArray =
    if (v6) SelfTest.CLIENT6.copyOf().also { it[15] = (i and 0xFF).toByte(); it[14] = ((i ushr 8) and 0xFF).toByte() }
    else byteArrayOf(10, 111, 222.toByte(), (2 + i % 250).toByte())

fun runTcpDnsHostileTests() {
    println("\nSızma 14 — TcpDns düşman istemci testleri\n")
    for (v6 in listOf(false, true)) {
        val fam = if (v6) "IPv6" else "IPv4"
        tdFlood(v6, fam)
        tdPipeline(v6, fam)
        tdMalformed(v6, fam)
        tdSeqAttacks(v6, fam)
    }
    tdLossy()
    tdGarbage()
    tdThreads()
    tdMss()
}

// ====================================================================================================== sel

private fun tdFlood(v6: Boolean, fam: String) {
    T.group("Sızma 14 / $fam: SYN seli ve yavaş bağlantılar — tablo sınırlı, sorgusu süren bağlantı atılmaz, çıkışlar RFC'ye uygun")
    val r = TdRig(11)
    val legit = TdCli(r, v6, tdCliAddr(v6, 0), 40000)
    val sa = legit.connect()
    T.check("$fam: meşru bağlantı kuruldu", sa != null && r.tcp.connectionCount == 1)
    val q = Dns.buildQuery(0x1111, "legit.example")
    legit.sendData(tdFramed(q))
    legit.recv()
    val mine = r.takeQueries()
    T.check("$fam: meşru soru yönlendiriciye verildi", mine.size == 1)
    var maxConns = 0
    val rnd = Random(5)
    for (i in 1..6000) {
        r.now += 1
        val c = TdCli(r, v6, tdCliAddr(v6, i), 1024 + (i % 60000))
        c.send(TD_SYN, seq = 777 + i, ack = 0, mss = 1460)
        if (rnd.nextInt(4) == 0) {                                      // bir kısmı el sıkışmayı tamamlar ve boşta bekler
            val sa2 = r.drain().map { tdParse(it) }.firstOrNull { it.cport == c.port && it.flags and TD_SYN != 0 }
            if (sa2 != null) c.send(TD_ACK, seq = 778 + i, ack = sa2.seq + 1)
        } else r.drain()
        maxConns = maxOf(maxConns, r.tcp.connectionCount)
    }
    T.check("$fam: 6000 SYN sonrası tablo sınırda (en çok ${maxConns} ≤ ${TcpDns.MAX_CONNS})", maxConns <= TcpDns.MAX_CONNS, "en çok=$maxConns")
    r.reply(mine[0], tdAnswer(q, 400))
    val got = r.drain().map { tdParse(it) }.filter { it.cport == legit.port }
    var stream = ByteArrayOutputStream()
    for (s in got) if (s.data.isNotEmpty()) stream.write(s.data)
    T.check("$fam: sel sırasında sorgusu süren meşru bağlantı atılmadı, cevabı eksiksiz geldi", stream.size() == 2 + tdAnswer(q, 400).size, "gelen=${stream.size()}")
    T.check("$fam: seldeki bütün çıkış paketleri RFC denetçisinden geçti (${r.sent.get()} paket)", r.bad.isEmpty(), r.bad.take(3).joinToString(" | "))
    // yavaş bağlantılar: 30 sn sessizlik → hepsi temizlenir (zamanlayıcı thread'i yok; tick ile)
    r.now += TcpDns.IDLE_MS + 1000
    r.tcp.tick(r.now)
    T.check("$fam: sessiz kalan bütün bağlantılar boşta süresi dolunca temizlendi", r.tcp.connectionCount == 0, "kalan=${r.tcp.connectionCount}")
}

private fun tdPipeline(v6: Boolean, fam: String) {
    T.group("Sızma 14 / $fam: boru hattı bombası — bağlantı başına ≤ ${TcpDns.MAX_PENDING} bekleyen soru, toplam ≤ ${TcpDns.MAX_PENDING_ALL}")
    val r = TdRig(12)
    val c = TdCli(r, v6, tdCliAddr(v6, 1), 41000)
    c.connect()
    // 600 küçük soru, pencereye aldırmadan arka arkaya
    val burst = ByteArrayOutputStream()
    for (i in 0 until 600) burst.write(tdFramed(Dns.buildQuery(0x2000 + i, "b$i.example.com")))
    val all = burst.toByteArray()
    var off = 0
    while (off < all.size) { val n = minOf(1200, all.size - off); c.sendData(all.copyOfRange(off, off + n)); off += n; r.drain() }
    val qs = r.takeQueries()
    T.check("$fam: tek bağlantıdan en çok ${TcpDns.MAX_PENDING} soru iletildi (${qs.size})", qs.size in 1..TcpDns.MAX_PENDING, "iletilen=${qs.size}")
    // çok bağlantı: her biri 20 soru
    val r2 = TdRig(13)
    for (k in 0 until 30) {
        val cc = TdCli(r2, v6, tdCliAddr(v6, 100 + k), 42000 + k)
        cc.connect()
        for (i in 0 until 20) cc.sendData(tdFramed(Dns.buildQuery(0x3000 + i, "m$k-$i.example.com")))
        r2.drain()
    }
    val q2 = r2.takeQueries()
    T.check("$fam: 30 bağlantı × 20 soru → toplam bekleyen ≤ ${TcpDns.MAX_PENDING_ALL} (${q2.size})", q2.size <= TcpDns.MAX_PENDING_ALL, "iletilen=${q2.size}")
    T.check("$fam: boru hattı saldırısında çıkışlar RFC'ye uygun", r.bad.isEmpty() && r2.bad.isEmpty(), (r.bad + r2.bad).take(3).joinToString(" | "))
}

private fun tdMalformed(v6: Boolean, fam: String) {
    T.group("Sızma 14 / $fam: bozuk uzunluk önekleri — RST ile kapanır, tablo temizlenir, sonraki bağlantı etkilenmez")
    for ((label, prefix) in listOf("0" to 0, "5 (<12)" to 5, "11" to 11, "65535" to 65535, "dev (MAX_DNS+1)" to DnsForwarder.MAX_DNS + 1)) {
        val r = TdRig(14)
        val c = TdCli(r, v6, tdCliAddr(v6, 7), 43000)
        c.connect()
        val pre = ByteArray(2); Packets.put16(pre, 0, prefix)
        c.sendData(pre + ByteArray(20))
        val segs = c.recv()
        T.check("$fam: uzunluk öneki $label → RST", segs.any { it.flags and TD_RST != 0 } && r.tcp.connectionCount == 0 && r.takeQueries().isEmpty(), "bayraklar=${segs.map { it.flags }}")
        val c2 = TdCli(r, v6, tdCliAddr(v6, 8), 43001)
        c2.connect()
        c2.sendData(tdFramed(Dns.buildQuery(0x4444, "ok.example")))
        T.check("$fam: ardından gelen meşru bağlantı soru iletir", r.takeQueries().size == 1)
        T.check("$fam: çıkışlar RFC'ye uygun", r.bad.isEmpty(), r.bad.take(3).joinToString(" | "))
    }
}

// ====================================================================================================== sıra numarası saldırıları

private fun tdSeqAttacks(v6: Boolean, fam: String) {
    T.group("Sızma 14 / $fam: sıra numarası saldırıları — kör RST/SYN, tekrar, çakışma, FIN sonrası veri, uydurma ACK")
    val bads = ArrayList<String>()
    // (a) pencere dışı RST yok sayılır
    run {
        val r = TdRig(21); val c = TdCli(r, v6, tdCliAddr(v6, 1), 44000); c.connect()
        c.send(TD_RST, seq = c.seq + 1_000_000, ack = 0)
        T.check("$fam: pencere dışı RST bağlantıyı öldürmez", r.tcp.connectionCount == 1)
        bads.addAll(r.bad)
    }
    // (b) RFC 5961 §3.2: yalnızca tam eşleşen RST bağlantıyı kapatır; pencere içi ama tam eşleşmeyen RST'ye meydan okuma ACK'i gider
    run {
        val r = TdRig(22); val c = TdCli(r, v6, tdCliAddr(v6, 1), 44001); c.connect(); c.recv()
        c.send(TD_RST, seq = c.seq + 100, ack = 0)
        val challenge = c.recv()
        T.check("$fam: pencere içi ama tam eşleşmeyen RST bağlantıyı öldürmez (kör RST: 64K tahmin yerine 4 milyar)", r.tcp.connectionCount == 1, "bağlantı=${r.tcp.connectionCount}")
        T.check("$fam: ...ve meydan okuma ACK'i döner (RFC 5961 §3.2)", challenge.any { it.flags == TD_ACK })
        c.send(TD_RST, seq = c.seq, ack = 0)
        T.check("$fam: tam eşleşen RST bağlantıyı kapatır", r.tcp.connectionCount == 0)
        bads.addAll(r.bad)
    }
    // (c) kurulu bağlantıya sahte SYN (RFC 5961 §4.2): bağlantı kaybolmaz, meydan okuma ACK'i
    run {
        val r = TdRig(23); val c = TdCli(r, v6, tdCliAddr(v6, 1), 44002); c.connect(); c.recv()
        val q = Dns.buildQuery(0x5151, "syn-attack.example")
        c.sendData(tdFramed(q)); c.recv()
        val mine = r.takeQueries()
        c.send(TD_SYN, seq = 123456, ack = 0, mss = 1460)
        val ch = c.recv()
        T.check("$fam: kurulu bağlantıya gelen sahte SYN bağlantıyı sıfırlamaz", r.tcp.connectionCount == 1, "bağlantı=${r.tcp.connectionCount}")
        T.check("$fam: ...meydan okuma ACK'i (SYN+ACK değil) döner", ch.isNotEmpty() && ch.none { it.flags and TD_SYN != 0 } && ch.any { it.flags and TD_ACK != 0 && it.flags and TD_RST == 0 }, "bayraklar=${ch.map { it.flags }}")
        r.reply(mine[0], tdAnswer(q, 100))
        c.collect()
        T.check("$fam: sahte SYN sonrası bekleyen cevap yine de teslim edildi", c.stream.size() == 2 + tdAnswer(q, 100).size, "gelen=${c.stream.size()}")
        bads.addAll(r.bad)
    }
    // (d) aynı segmentin tekrarı: soru bir kez iletilir
    run {
        val r = TdRig(24); val c = TdCli(r, v6, tdCliAddr(v6, 1), 44003); c.connect(); c.recv()
        val f = tdFramed(Dns.buildQuery(0x6161, "dup.example"))
        val s0 = c.seq
        repeat(5) { c.send(TD_ACK or TD_PSH, f, seq = s0) }
        c.seq = s0 + f.size
        T.check("$fam: aynı segment 5 kez gelse de soru bir kez iletilir", r.takeQueries().size == 1)
        bads.addAll(r.bad)
    }
    // (e) çakışan parçalar: soru üç çakışan segmentle gelir → bir soru
    run {
        val r = TdRig(25); val c = TdCli(r, v6, tdCliAddr(v6, 1), 44004); c.connect(); c.recv()
        val f = tdFramed(Dns.buildQuery(0x7171, "overlap.example.com"))
        val s0 = c.seq
        c.send(TD_ACK or TD_PSH, f.copyOfRange(0, 10), seq = s0)
        c.send(TD_ACK or TD_PSH, f.copyOfRange(5, 20), seq = s0 + 5)
        c.send(TD_ACK or TD_PSH, f.copyOfRange(0, f.size), seq = s0)
        val qs = r.takeQueries()
        T.check("$fam: çakışan segmentlerden tek ve bozulmamış soru çıkar", qs.size == 1 && qs[0].dns.size >= f.size - 2, "soru=${qs.size}")
        bads.addAll(r.bad)
    }
    // (f) boşluklu (ileri) veri alınmaz, yinelenen ACK gelir; sonra boşluk doldurulunca tek soru
    run {
        val r = TdRig(26); val c = TdCli(r, v6, tdCliAddr(v6, 1), 44005); c.connect(); c.recv()
        val f = tdFramed(Dns.buildQuery(0x8181, "gap.example.com"))
        val s0 = c.seq
        c.send(TD_ACK or TD_PSH, f.copyOfRange(10, f.size), seq = s0 + 10)
        val dup = c.recv()
        T.check("$fam: boşluklu segment yinelenen ACK getirir, soru iletilmez", dup.any { it.flags == TD_ACK && it.ack == s0 } && r.takeQueries().isEmpty())
        c.send(TD_ACK or TD_PSH, f.copyOfRange(0, 10), seq = s0)
        c.send(TD_ACK or TD_PSH, f.copyOfRange(10, f.size), seq = s0 + 10)
        T.check("$fam: boşluk dolunca soru bir kez iletilir", r.takeQueries().size == 1)
        bads.addAll(r.bad)
    }
    // (g) FIN sonrası veri okunmaz; uydurma ACK (gönderilmemiş baytları onaylayan) durumu bozmaz
    run {
        val r = TdRig(27); val c = TdCli(r, v6, tdCliAddr(v6, 1), 44006); c.connect(); c.recv()
        val q = Dns.buildQuery(0x9191, "fin.example")
        val f = tdFramed(q)
        c.send(TD_ACK or TD_FIN or TD_PSH, f); c.seq += f.size + 1
        val mine = r.takeQueries()
        T.check("$fam: FIN taşıyan segmentteki soru iletilir", mine.size == 1)
        c.send(TD_ACK or TD_PSH, tdFramed(Dns.buildQuery(0x9192, "late.example")))
        T.check("$fam: FIN'den sonra gelen veri okunmaz", r.takeQueries().isEmpty())
        c.send(TD_ACK, ack = c.rcv + 5_000_000)                          // hiç göndermediğimiz baytları onaylar
        r.reply(mine[0], tdAnswer(q, 50))
        val segs = c.recv()
        T.check("$fam: uydurma ACK sonrası cevap yine teslim edilir", segs.any { it.data.isNotEmpty() })
        bads.addAll(r.bad)
    }
    T.check("$fam: sıra numarası saldırılarında bütün çıkışlar RFC'ye uygun", bads.isEmpty(), bads.take(3).joinToString(" | "))
}

// ====================================================================================================== kayıplı ağ (RTO)

private fun tdLossy() {
    T.group("Sızma 14 / %25 kayıplı ağ: yüzlerce DNS-over-TCP konuşması — cevaplar bayt bayt tam gelir (RTO, hızlı yeniden iletim, FIN)")
    for (v6 in listOf(false, true)) {
        val fam = if (v6) "IPv6" else "IPv4"
        var ok = 0; var timedOut = 0; var bad = 0; var violations = 0; var lateRst = 0
        var firstBad = ""
        var retransTotal = 0L
        val N = 150
        for (seed in 1..N) {
            val rnd = Random(seed.toLong() * 7919)
            val r = TdRig(seed.toLong())
            val addr = tdCliAddr(v6, seed)
            val srv = if (v6) SelfTest.FAKE6 else TD_FAKE4
            val cport = 30000 + seed
            var cseq = 9000 + seed * 13
            var rcv = 0
            var synAck = false
            var nextSyn = 0L
            val nq = 1 + rnd.nextInt(3)
            val sizes = IntArray(nq) { listOf(50, 300, 1500, 3500)[rnd.nextInt(4)] }
            val qs = Array(nq) { Dns.buildQuery(0xA000 + seed * 4 + it, "c$seed-$it.example.com") }
            val expect = ByteArrayOutputStream()
            for (i in 0 until nq) expect.write(tdFramed(tdAnswer(qs[i], sizes[i])))
            val want = expect.toByteArray()
            val got = ByteArrayOutputStream()
            var queryBytes = ByteArray(0); for (qq in qs) queryBytes += tdFramed(qq)
            var csnd = 0                                                  // istemcinin bir sonraki göndereceği bayt numarası
            var queryAckedUpTo = -1
            var nextQuerySend = 0L
            var finSent = false; var finAcked = false; var nextFin = 0L
            val answered = HashSet<Int>()
            var rstSeen = false
            val pd = 0.2; val ps = 0.25
            val start = r.now
            val firstSeq = cseq
            fun toServer(p: ByteArray) { if (rnd.nextDouble() >= pd) r.tcp.onPacket(p, p.size) }
            var done = false
            var steps = 0
            while (!done && steps++ < 4000) {                             // 4000 × 50 ms = 200 sn
                r.now += 50
                r.tcp.tick(r.now)
                if (!synAck && r.now >= nextSyn) { toServer(tdPkt(v6, addr, srv, cport, 53, firstSeq, 0, TD_SYN, mss = 1460)); nextSyn = r.now + 1000 }
                // sunucudan gelenler (%25 kayıp)
                for (raw in r.drain()) {
                    val s = tdParse(raw)
                    if (s.cport != cport || rnd.nextDouble() < ps) continue
                    if (s.flags and TD_RST != 0) { rstSeen = true; continue }
                    if (s.flags and (TD_SYN or TD_ACK) == (TD_SYN or TD_ACK) && !synAck) { synAck = true; rcv = s.seq + 1; cseq = firstSeq + 1; csnd = cseq; toServer(tdPkt(v6, addr, srv, cport, 53, csnd, rcv, TD_ACK)); continue }
                    if (!synAck) continue
                    if (s.flags and TD_SYN != 0) { toServer(tdPkt(v6, addr, srv, cport, 53, csnd, rcv, TD_ACK)); continue }   // yinelenen SYN+ACK
                    if (s.flags and TD_ACK != 0) {
                        val ackedBytes = s.ack - (firstSeq + 1)
                        if (ackedBytes > queryAckedUpTo) queryAckedUpTo = ackedBytes
                        if (finSent && s.ack == firstSeq + 1 + queryBytes.size + 1) finAcked = true
                    }
                    val end = s.seq + s.data.size
                    if (s.data.isNotEmpty() || s.flags and TD_FIN != 0) {
                        if (s.seq == rcv && s.data.isNotEmpty()) { got.write(s.data); rcv += s.data.size }
                        else if (s.seq - rcv < 0 && end - rcv > 0) { val skip = rcv - s.seq; got.write(s.data, skip, s.data.size - skip); rcv += s.data.size - skip }
                        if (s.flags and TD_FIN != 0 && s.seq + s.data.size == rcv) rcv++
                        toServer(tdPkt(v6, addr, srv, cport, 53, csnd, rcv, TD_ACK))
                    }
                }
                // sorgu gönder / yeniden gönder (istemcinin kendi zamanlayıcısı: 1 sn)
                if (synAck && queryAckedUpTo < queryBytes.size && r.now >= nextQuerySend) {
                    val from = maxOf(0, queryAckedUpTo)
                    toServer(tdPkt(v6, addr, srv, cport, 53, firstSeq + 1 + from, rcv, TD_ACK or TD_PSH, queryBytes.copyOfRange(from, queryBytes.size)))
                    csnd = maxOf(csnd, firstSeq + 1 + queryBytes.size)
                    nextQuerySend = r.now + 1000
                }
                // sunucudaki sorulara cevap ver (her biri bir kez)
                for (q in r.takeQueries()) {
                    val idx = qs.indexOfFirst { Packets.u16(it, 0) == Packets.u16(q.dns, 0) }
                    if (idx >= 0 && answered.add(idx)) r.reply(q, tdAnswer(qs[idx], sizes[idx]))
                }
                // hepsi geldiyse FIN gönder
                if (synAck && got.size() >= want.size && !finSent) { finSent = true; nextFin = 0 }
                if (finSent && !finAcked && r.now >= nextFin) {
                    toServer(tdPkt(v6, addr, srv, cport, 53, firstSeq + 1 + queryBytes.size, rcv, TD_ACK or TD_FIN))
                    csnd = firstSeq + 1 + queryBytes.size + 1
                    nextFin = r.now + 1000
                }
                if (finSent && r.tcp.connectionCount == 0) done = true
                if (rstSeen && r.tcp.timedOut > 0) { done = true }
            }
            violations += r.bad.size
            if (r.bad.isNotEmpty() && firstBad.isEmpty()) firstBad = "tohum=$seed ${r.bad.first()}"
            retransTotal += r.tcp.retransmits
            val full = got.toByteArray().contentEquals(want)
            when {
                full && done && (!rstSeen || r.tcp.timedOut > 0L) -> { ok++; if (rstSeen) lateRst++ }   // veri tam geldi; kapanışta yeniden iletim hakkı bitince RST tasarım gereği
                r.tcp.timedOut > 0L && !full -> timedOut++            // sınırlı deneme dolunca RST: tasarım gereği
                else -> { bad++; if (firstBad.isEmpty()) firstBad = "tohum=$seed ok=$full done=$done rst=$rstSeen gelen=${got.size()}/${want.size} bağlantı=${r.tcp.connectionCount} süre=${(r.now - start) / 1000}s" }
            }
        }
        T.check("$fam: $N konuşmanın ${ok} tanesi eksiksiz bitti, $timedOut tanesi sınırlı denemeden sonra RST ile kapandı (tasarım gereği); $lateRst tanesinde veri tam geldikten sonra kapanışta RST", bad == 0 && ok >= N * 95 / 100, "kötü=$bad ok=$ok zaman_aşımı=$timedOut $firstBad")
        T.check("$fam: kayıplı ağda yeniden iletim gerçekten çalıştı ($retransTotal)", retransTotal > 100)
        T.check("$fam: kayıplı ağdaki bütün çıkış paketleri RFC denetçisinden geçti", violations == 0, firstBad)
    }
}

// ====================================================================================================== çöp yağmuru

private fun tdGarbage() {
    T.group("Sızma 14 / çöp yağmuru: rastgele ve bozulmuş paketler — atmaz, tablo ve bekleyenler sınırda, çıkışlar RFC'ye uygun")
    for (v6 in listOf(false, true)) {
        val fam = if (v6) "IPv6" else "IPv4"
        val r = TdRig(31)
        val rnd = Random(77)
        var thrown = 0
        var maxConns = 0
        // tohum paketler: geçerli SYN, ACK, veri, FIN
        val addr = tdCliAddr(v6, 3)
        val srv = if (v6) SelfTest.FAKE6 else TD_FAKE4
        val seeds = listOf(
            tdPkt(v6, addr, srv, 5000, 53, 100, 0, TD_SYN, mss = 1460),
            tdPkt(v6, addr, srv, 5000, 53, 101, 1, TD_ACK),
            tdPkt(v6, addr, srv, 5000, 53, 101, 1, TD_ACK or TD_PSH, tdFramed(Dns.buildQuery(0x1234, "g.example"))),
            tdPkt(v6, addr, srv, 5000, 53, 130, 1, TD_ACK or TD_FIN),
            tdPkt(v6, addr, srv, 5000, 853, 100, 0, TD_SYN),
            tdPkt(v6, addr, srv, 5000, 53, 100, 0, TD_RST),
        )
        val N = 30000
        for (i in 0 until N) {
            r.now += 1
            val p: ByteArray = when (rnd.nextInt(4)) {
                0 -> ByteArray(rnd.nextInt(120)).also { rnd.nextBytes(it) }                          // saf çöp
                1 -> seeds[rnd.nextInt(seeds.size)].copyOf().also { b -> repeat(1 + rnd.nextInt(4)) { b[rnd.nextInt(b.size)] = rnd.nextInt(256).toByte() } }   // bayt bozma
                2 -> seeds[rnd.nextInt(seeds.size)].let { s -> s.copyOf(rnd.nextInt(s.size + 1)) }   // kesme
                else -> seeds[rnd.nextInt(seeds.size)].copyOf().also { b ->                          // rastgele bayrak/sıra numarası, yeni kaynak portu
                    val t = if (v6) 40 else 20
                    if (b.size > t + 14) { Packets.put16(b, t, 1024 + rnd.nextInt(64)); Packets.put32(b, t + 4, rnd.nextInt()); Packets.put32(b, t + 8, rnd.nextInt()); b[t + 13] = rnd.nextInt(64).toByte() }
                }
            }
            try { r.tcp.onPacket(p, p.size) } catch (e: Throwable) { thrown++; if (thrown == 1) println("    TcpDns çöp paketle attı: $e") }
            if (i % 500 == 0) { r.takeQueries(); r.drain(); maxConns = maxOf(maxConns, r.tcp.connectionCount) }
            if (i % 5000 == 4999) r.tcp.tick(r.now)
        }
        T.check("$fam: $N çöp/bozulmuş pakette TcpDns hiç atmadı", thrown == 0, "atılan=$thrown")
        T.check("$fam: tablo sınırda (en çok $maxConns ≤ ${TcpDns.MAX_CONNS})", maxConns <= TcpDns.MAX_CONNS)
        T.check("$fam: çöp yağmurunda üretilen ${r.sent.get()} çıkış paketinin hepsi RFC'ye uygun", r.bad.isEmpty(), r.bad.take(3).joinToString(" | "))
    }
}

// ====================================================================================================== çok iş parçacığı + gerçek zamanlayıcı

private fun tdThreads() {
    T.group("Sızma 14 / çok iş parçacığı: gerçek RTO zamanlayıcısı + paralel konuşmalar + cevap yazıcıları — kilitlenme yok, cevaplar tam")
    val uncaught = AtomicInteger()
    val r = TdRig(41, timer = true, clock = { System.nanoTime() / 1_000_000L }, demux = true)
    val okConvs = AtomicInteger(); val badConvs = AtomicInteger()
    val firstErr = java.util.concurrent.atomic.AtomicReference<String>("")
    val threads = (0 until 4).map { ti ->
        Thread({
            try {
                val rnd = Random(1000L + ti)
                val dropRnd = Random(2000L + ti)
                val v6 = ti % 2 == 1
                for (k in 0 until 25) {
                    val cport = 20000 + ti * 1000 + k
                    val c = TdCli(r, v6, tdCliAddr(v6, ti * 100 + k), cport)
                    c.seq = 4000 + k
                    c.send(TD_SYN, seq = c.seq, ack = 0, mss = 1460); c.seq++
                    var sa: TdSeg? = null
                    val t0 = System.nanoTime()
                    while (sa == null && System.nanoTime() - t0 < 5_000_000_000L) {
                        sa = r.drainPort(cport).firstOrNull { it.flags and TD_SYN != 0 }
                        if (sa == null) Thread.sleep(1)
                    }
                    if (sa == null) { badConvs.incrementAndGet(); firstErr.compareAndSet("", "t$ti k$k SYN-ACK gelmedi"); continue }
                    c.rcv = sa.seq + 1
                    c.send(TD_ACK)
                    val q = Dns.buildQuery(0xB000 + ti * 100 + k, "t$ti-$k.example.com")
                    c.sendData(tdFramed(q))
                    // sorumuz yönlendiriciye varana dek bekle
                    var mine: TdQ? = null
                    val t1 = System.nanoTime()
                    while (mine == null && System.nanoTime() - t1 < 5_000_000_000L) {
                        synchronized(r.queries) { mine = r.queries.firstOrNull { it.port != 0 && it.dns.size >= 12 && Packets.u16(it.dns, 0) == 0xB000 + ti * 100 + k }; if (mine != null) r.queries.remove(mine) }
                        if (mine == null) Thread.sleep(1)
                    }
                    if (mine == null) { badConvs.incrementAndGet(); firstErr.compareAndSet("", "t$ti k$k soru iletilmedi"); continue }
                    val ans = tdAnswer(q, listOf(40, 900, 3000)[rnd.nextInt(3)])
                    r.reply(mine!!, ans)
                    // gelen veriyi topla; her segmenti %30 olasılıkla "kaybet" (sunucu RTO ile kurtarmalı); gerçek zamanlı
                    val want = tdFramed(ans)
                    val t2 = System.nanoTime()
                    while (c.stream.size() < want.size && System.nanoTime() - t2 < 20_000_000_000L) {
                        var progressed = false
                        for (s in r.drainPort(cport)) {
                            if (dropRnd.nextInt(100) < 30) continue
                            if (s.data.isNotEmpty() && s.seq == c.rcv) { c.stream.write(s.data); c.rcv += s.data.size; progressed = true }
                        }
                        if (progressed) c.send(TD_ACK)
                        Thread.sleep(2)
                    }
                    if (c.stream.toByteArray().contentEquals(want)) okConvs.incrementAndGet()
                    else { badConvs.incrementAndGet(); firstErr.compareAndSet("", "t$ti k$k eksik cevap ${c.stream.size()}/${want.size}") }
                    c.send(TD_RST, seq = c.seq, ack = 0)
                }
            } catch (e: Throwable) { uncaught.incrementAndGet(); firstErr.compareAndSet("", "iş parçacığı $ti: $e") }
        }, "td-atak-$ti")
    }
    threads.forEach { it.isDaemon = true; it.start() }
    var hung = false
    for (t in threads) { t.join(120_000); if (t.isAlive) hung = true }
    T.check("kilitlenme yok: dört saldırı iş parçacığı da bitti", !hung)
    T.check("iş parçacıklarında beklenmeyen hata yok", uncaught.get() == 0, firstErr.get())
    T.check("100 paralel konuşmanın hepsinde cevap bayt bayt tam geldi (kayıplı, gerçek zamanlayıcıyla): ok=${okConvs.get()} kötü=${badConvs.get()}", okConvs.get() == 100 && badConvs.get() == 0, firstErr.get())
    T.check("gerçek zamanlayıcı yeniden iletim yaptı (${r.tcp.retransmits})", r.tcp.retransmits > 0)
    T.check("paralel saldırıda bütün çıkış paketleri RFC denetçisinden geçti (${r.sent.get()})", r.bad.isEmpty(), r.bad.take(3).joinToString(" | "))
    Thread.sleep(300)
    r.tcp.tick(System.nanoTime() / 1_000_000L + TcpDns.IDLE_MS + 1000)
    T.check("saldırı bitince bağlantı tablosu temizlenir", r.tcp.connectionCount == 0, "kalan=${r.tcp.connectionCount}")
}

// ====================================================================================================== MSS (mutasyon boşluğu)

/** İstemcinin SYN'deki MSS seçeneği, cevap segmentlerinin boyunu belirler (100..MSS aralığına kırpılarak). Mutasyon ölçümü bunu hiçbir testin sınamadığını gösterdi. */
private fun tdMss() {
    for (v6 in listOf(false, true)) {
        val fam = if (v6) "IPv6" else "IPv4"
        T.group("Sızma 18 / $fam: TcpDns istemci MSS'ine uyar (SYN seçeneği → cevap segmenti boyu), uç değerler kırpılır")
        for ((mss, want) in listOf(300 to 300, 536 to 536, 1000 to 1000, 1200 to 1200, 1460 to 1200, 5000 to 1200, 50 to 100, 1 to 100)) {
            val r = TdRig(900L + mss)
            val c = TdCli(r, v6, tdCliAddr(v6, 7), 43000 + (mss % 1000))
            c.connect(mss)
            c.sendData(tdFramed(Dns.buildQuery(0x4141, "mss.example.com")))
            val q = r.takeQueries().firstOrNull()
            if (q == null) { T.check("$fam: MSS $mss: soru iletildi", false); continue }
            r.reply(q, tdAnswer(q.dns, 3000))
            var maxSeg = 0; var total = 0
            for (round in 0 until 40) {
                val segs = r.drain().map { tdParse(it) }.filter { it.cport == c.port }
                for (sg in segs) { if (sg.data.isNotEmpty()) { maxSeg = maxOf(maxSeg, sg.data.size); if (sg.seq == c.rcv) { c.stream.write(sg.data); c.rcv += sg.data.size; total += sg.data.size } } }
                if (segs.isNotEmpty()) c.send(TD_ACK)
                if (total >= 3000) break
            }
            T.check("$fam: MSS $mss → en büyük cevap segmenti tam $want bayt (ölçülen $maxSeg)", maxSeg == want, "maxSeg=$maxSeg")
            T.check("$fam: MSS $mss → cevap eksiksiz ($total ≥ 3000)", total >= 3000, "$total")
            T.check("$fam: MSS $mss → çıkışlar RFC'ye uygun", r.bad.isEmpty(), r.bad.take(2).joinToString())
        }
    }
}
