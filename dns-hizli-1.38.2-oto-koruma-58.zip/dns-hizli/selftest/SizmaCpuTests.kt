package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File
import java.util.Random

/**
 * Sızma 15 — algoritmik karmaşıklık / CPU ve bellek yükseltme saldırıları.
 *
 * Saldırgan küçük bir girdiyle çok iş yaptırmaya çalışır: milyon noktalı liste satırı (karesel temizleyici), 127 etiketli adlar
 * (etiket başına özet), 32 adımlı ve 64 KB'lık CNAME cevapları, kendine dönen sıkıştırma işaretçileri, hashCode'u çakışan önbellek
 * anahtarları, tek satırda yüz binlerce ad taşıyan liste dosyaları. Her saldırıda iki şey denetlenir: süre (cömert, CI makinesinde
 * kararlı bir üst sınır) ve doğruluk (hızlı yol, saf bir referansla aynı sonucu verir).
 */

private inline fun cpuMs(f: () -> Unit): Long { val t = System.nanoTime(); f(); return (System.nanoTime() - t) / 1_000_000 }

private fun cpuWire(name: String): ByteArray {
    val o = java.io.ByteArrayOutputStream()
    if (name.isNotEmpty()) for (l in name.split('.')) { val b = l.toByteArray(Charsets.ISO_8859_1); o.write(b.size); o.write(b) }
    o.write(0)
    return o.toByteArray()
}

private fun cpuQuery(name: String, type: Int = 1): ByteArray {
    val w = cpuWire(name)
    val q = ByteArray(12 + w.size + 4)
    Packets.put16(q, 0, 0x1234); Packets.put16(q, 2, 0x0100); Packets.put16(q, 4, 1)
    System.arraycopy(w, 0, q, 12, w.size)
    Packets.put16(q, 12 + w.size, type); Packets.put16(q, 14 + w.size, 1)
    return q
}

/** rr: (ad — null ise soru adına işaretçi, tür, veri). */
private class CpuRr(val name: String?, val type: Int, val data: ByteArray)

private fun cpuResp(qname: String, rrs: List<CpuRr>, qtype: Int = 1): ByteArray {
    val o = java.io.ByteArrayOutputStream()
    val h = ByteArray(12)
    Packets.put16(h, 0, 0x1234); Packets.put16(h, 2, 0x8180); Packets.put16(h, 4, 1); Packets.put16(h, 6, rrs.size)
    o.write(h); o.write(cpuWire(qname)); o.write(byteArrayOf((qtype ushr 8).toByte(), qtype.toByte(), 0, 1))
    for (r in rrs) {
        if (r.name == null) { o.write(0xC0); o.write(12) } else o.write(cpuWire(r.name))
        o.write(byteArrayOf((r.type ushr 8).toByte(), r.type.toByte(), 0, 1, 0, 0, 0, 60, (r.data.size ushr 8).toByte(), r.data.size.toByte()))
        o.write(r.data)
    }
    return o.toByteArray()
}

/** Etiket sayısı en yüksek (127 etiket, 253 karakter) ad: bir harfli etiketlerle, sonunda [tail]. */
private fun cpuDeep(tail: String): String {
    val need = (253 - tail.length - 1)
    val sb = StringBuilder()
    while (sb.length + 2 <= need) { sb.append("a."); }
    return sb.toString() + tail
}

fun runComplexityAttackTests() {
    // ---- 1. Liste satırı temizleyici: karesel süre ----
    T.group("Sızma 15 / Liste ad temizleyici: milyon noktalı / '*.' satırlar doğrusal sürede, sonuç eski davranışla aynı")
    run {
        val dots = ".".repeat(1_000_000) + "a.com"
        val stars = "*.".repeat(500_000) + "a.com"
        val mix = "*..".repeat(300_000) + "a.com"
        var r1: String? = null; var r2: String? = null; var r3: String? = null
        val ms = cpuMs { r1 = FilterNames.normalize(dots); r2 = FilterNames.normalize(stars); r3 = FilterNames.normalize(mix) }
        println("    (3 milyon karakterlik 3 satır: $ms ms)")
        T.check("noktalar atlanır, ad kurtulur", r1 == "a.com" && r2 == "a.com" && r3 == "a.com", "$r1 $r2 $r3")
        T.check("üç saldırı satırı toplam < 6 sn (önceden dakikalar)", ms < 6000, "$ms ms")
        T.check("sonu nokta dolu devasa satır da hızlı", cpuMs { FilterNames.normalize("a.com" + ".".repeat(2_000_000)) } < 4000)
        T.check("devasa geçersiz satır (tek etiket, 3 MB) hızlı ve null", run { var r: String? = "x"; val t = cpuMs { r = FilterNames.normalize("a".repeat(3_000_000)) }; r == null && t < 4000 })
        T.check("devasa '://' ve '@' yığını hızlı", cpuMs { FilterNames.normalize("http://".repeat(300_000) + "a.com"); FilterNames.normalize("@".repeat(2_000_000) + "a.com") } < 6000)
        // eski döngüyle birebir aynı: rastgele '.' / '*' önekleri
        fun oldStrip(x: String): String { var s = x; while (s.startsWith("*.") || s.startsWith(".")) s = s.removePrefix("*.").removePrefix("."); return s }
        val rnd = Random(0x515A15)
        var diff = 0
        repeat(20_000) {
            val pre = String(CharArray(rnd.nextInt(10)) { ".*a"[rnd.nextInt(3)] })
            val s = pre + "b.com"
            val want = oldStrip(s).let { FilterNames.normalize(it) }
            if (FilterNames.normalize(s) != want) diff++
        }
        T.check("20 bin rastgele '.'/'*' öneki: eski davranışla aynı sonuç", diff == 0, "$diff fark")
    }

    // ---- 2. İçe aktarma dosyası: tek satırda yüz binlerce ad, tek satırda 4 MB ----
    T.group("Sızma 15 / Liste içe aktarma (HostsList): devasa tek satırlar, istisna seli, bellek/CPU tavanı")
    run {
        fun parseMs(text: String): Pair<HostsList.Result, Long> { var r: HostsList.Result? = null; val t = cpuMs { r = HostsList.parse(text) }; return r!! to t }
        val (r0, t0) = parseMs("." .repeat(4_000_000))
        T.check("4 MB'lık nokta satırı: boş sonuç, < 8 sn", r0.names.isEmpty() && t0 < 8000, "${t0} ms")
        val dn = StringBuilder("address=/"); for (i in 0 until 200_000) dn.append("t").append(i).append(".x.com/"); dn.append("0.0.0.0")
        val (r1, t1) = parseMs(dn.toString())
        T.check("dnsmasq tek satır 200 bin ad: MAX_IMPORTED'a kesilir, < 20 sn", r1.names.size <= HostsList.MAX_IMPORTED && r1.names.size > 1000 && t1 < 20000, "${r1.names.size} ad ${t1} ms")
        val hn = StringBuilder("0.0.0.0"); for (i in 0 until 200_000) hn.append(" h").append(i).append(".y.com")
        val (r2, t2) = parseMs(hn.toString())
        T.check("hosts tek satır 200 bin ad: kesilir, < 20 sn", r2.names.size <= HostsList.MAX_IMPORTED && r2.names.size > 1000 && t2 < 20000, "${r2.names.size} ad ${t2} ms")
        val sl = "address=/" + "/".repeat(3_000_000)
        val (r3, t3) = parseMs(sl)
        T.check("3 milyon '/' : boş, < 12 sn", r3.names.isEmpty() && t3 < 12000, "$t3 ms")
        val opt = "||a.com$" + "important,".repeat(300_000)
        val (r4, t4) = parseMs(opt)
        T.check("300 bin seçenekli AdBlock satırı: < 12 sn", t4 < 12000, "$t4 ms")
        // istisna seli: derin adlar + çok istisna → coveredBy her ad için etiket sayısı kadar kopya
        val sb = StringBuilder()
        for (i in 0 until 50_000) sb.append("||").append("a.".repeat(100)).append("n").append(i).append(".z.com^\n")
        for (i in 0 until 20_000) sb.append("@@||ok").append(i).append(".z.org^\n")
        val (r5, t5) = parseMs(sb.toString())
        T.check("50 bin derin ad + 20 bin istisna: < 24 sn (ad başına etiket kopyası)", t5 < 24000 && r5.names.size <= HostsList.MAX_IMPORTED, "${r5.names.size} ad ${t5} ms")
        println("    (ölçüm: nokta ${t0} ms, dnsmasq ${t1} ms, hosts ${t2} ms, '/' ${t3} ms, seçenek ${t4} ms, istisna ${t5} ms)")
        // ilk satırlardaki saldırı sonraki meşru satırları engellemez
        val (r6, _) = parseMs("." .repeat(100_000) + "\n0.0.0.0 gercek.reklam.net\n")
        T.check("saldırı satırından sonraki meşru satır yine okunur", "gercek.reklam.net" in r6.names, r6.names.toString())
    }

    // ---- 3. Süzgeç motoru: 127 etiketli adlar, saf referansla fark testi ----
    T.group("Sızma 15 / Süzgeç motoru: en derin adlar (127 etiket) saf son-ek referansıyla aynı karar, sabit zaman")
    run {
        val rnd = Random(0xDEE9)
        fun lbl(): String = String(CharArray(1 + rnd.nextInt(3)) { "abc".get(rnd.nextInt(3)) })
        val blockSet = HashSet<String>(); val allowSet = HashSet<String>(); val tierSet = HashSet<String>()
        repeat(60) { blockSet.add(lbl() + "." + lbl()) }
        repeat(60) { allowSet.add(lbl() + "." + lbl() + "." + lbl()) }
        repeat(400) { tierSet.add(lbl() + "." + lbl()) }
        tierSet.removeAll(blockSet); tierSet.removeAll(allowSet)
        val eng = FilterEngine(listOf(FilterEngine.toTier(tierSet)), FilterTier.EMPTY, allowSet.toList(), blockSet.toList())
        fun suffixes(n: String): List<String> { val p = n.split('.'); return (0 until p.size - 1).map { p.subList(it, p.size).joinToString(".") } }
        fun model(n: String): Int {
            val s = suffixes(n)
            return when { s.any { it in allowSet } -> FilterVerdict.PASS; s.any { it in blockSet } -> FilterVerdict.USER; s.any { it in tierSet } -> FilterVerdict.LIST; else -> FilterVerdict.PASS }
        }
        var bad = 0; var tested = 0; var hits = 0
        val depths = intArrayOf(2, 3, 10, 60, 100, 120, 126)
        repeat(30_000) {
            val d = depths[rnd.nextInt(depths.size)]
            val labels = (0 until d).map { if (rnd.nextInt(4) == 0) lbl() else "a" }
            var name = labels.joinToString(".")
            if (name.length > 253) name = name.substring(name.length - 253).trimStart('.')
            if (name.isEmpty()) return@repeat
            if (rnd.nextInt(3) == 0) name = name.uppercase()
            val q = cpuQuery(name)
            val got = eng.verdict(q, 0, q.size)
            val want = model(name.lowercase())
            tested++; if (want != FilterVerdict.PASS) hits++
            if (got != want) { bad++; if (bad <= 3) println("    FARK: $name got=$got want=$want") }
        }
        T.check("$tested derin ad ($hits engelli): motor = referans", bad == 0 && tested > 29_000 && hits > 1000, "bad=$bad hits=$hits")
        val deepBlocked = cpuDeep("tracker.com").let { it }
        val big = FilterEngine(listOf(FilterEngine.toTier(listOf("tracker.com"))), FilterTier.EMPTY, emptyList(), emptyList())
        val qd = cpuQuery(deepBlocked); val qs = cpuQuery("www.example.org")
        T.check("253 karakterlik derin ad sonunda engelli etki alanı: engellenir", deepBlocked.length in 250..253 && big.verdict(qd, 0, qd.size) == FilterVerdict.LIST, "${deepBlocked.length}")
        val msD = cpuMs { repeat(20_000) { big.verdict(qd, 0, qd.size) } }
        val msS = cpuMs { repeat(20_000) { big.verdict(qs, 0, qs.size) } }
        println("    (20 bin sorgu: en derin ad $msD ms, sıradan ad $msS ms)")
        T.check("20 bin en-derin-ad sorgusu < 8 sn", msD < 8000, "$msD ms")
        // RFC dışı uzunluklar: 254-255 karakter ve 64 baytlık etiket; hata olmadan ve süzgeçten kaçmadan
        val big255 = "a.".repeat(126) + "tracker.com"            // 252+...
        val over = "a.".repeat(130) + "tracker.com"                // 271 karakter
        val qo = cpuQuery(over)
        T.check("253 karakteri aşan ad: bozuk sayılır (üst sunucuya gitmez)", big.isMalformed(qo, 0, qo.size) || big.verdict(qo, 0, qo.size) == FilterVerdict.LIST)
        val q64 = cpuQuery("a".repeat(64) + ".tracker.com")
        T.check("64 baytlık etiket: bozuk", cpuWire("a".repeat(64) + ".tracker.com").size > 0 && (q64[12].toInt() == 64) && (big.isMalformed(q64, 0, q64.size) || big.verdict(q64, 0, q64.size) == FilterVerdict.PASS))
        T.check("254-255 karakterli adlar patlamaz", runCatching { for (len in 250..256) { val nm = ("a.".repeat(len / 2)).trimEnd('.') + ".tracker.com"; val qq = cpuQuery(nm); big.verdict(qq, 0, qq.size); big.isMalformed(qq, 0, qq.size) } }.isSuccess)
        T.check("(bilgi) ${big255.length} karakter", true)
    }

    // ---- 4. CNAME / SVCB / rebind cevapları ----
    T.group("Sızma 15 / Cevap tarayıcıları: 32 adımlı derin-ad zincirleri, 64 KB cevaplar, döngüye giren işaretçiler")
    run {
        val eng = FilterEngine(listOf(FilterEngine.toTier(listOf("tracker.com"))), FilterTier.EMPTY, emptyList(), emptyList())
        val deepOk = cpuDeep("fine.example")
        val deepBad = cpuDeep("tracker.com")
        // a) en kötü durum: soru adı da hedefler de 253 karakter; 30 CNAME adımı, hepsi temiz → tam tarama
        fun cnameData(n: String) = cpuWire(n)
        val clean = cpuResp(deepOk, (0 until 30).map { CpuRr(null, 5, cnameData(deepOk.replaceFirst("a.", "b$it."))) } + CpuRr(null, 1, byteArrayOf(1, 2, 3, 4)))
        val msC = cpuMs { repeat(2000) { eng.cnameVerdict(clean, 0, clean.size) } }
        T.check("30 adımlı 253 karakterlik zincir ×2000: < 12 sn, geçer", eng.cnameVerdict(clean, 0, clean.size) == FilterVerdict.PASS && msC < 12000, "$msC ms")
        // b) zincirin sonunda izleyici
        val dirty = cpuResp(deepOk, (0 until 29).map { CpuRr(null, 5, cnameData(deepOk.replaceFirst("a.", "b$it."))) } + CpuRr(null, 5, cnameData(deepBad)) + CpuRr(null, 1, byteArrayOf(1, 2, 3, 4)))
        T.check("zincirin son halkasındaki izleyici (derin adla) yakalanır", eng.cnameVerdict(dirty, 0, dirty.size) == FilterVerdict.LIST)
        // c) 33+ adım → kapatılır
        val longChain = cpuResp("x.fine.example", (0 until 40).map { CpuRr(null, 5, cnameData("c$it.fine.example")) } + CpuRr(null, 1, byteArrayOf(1, 2, 3, 4)))
        T.check("40 adımlı zincir kapatılır (süzgeci uzatarak aşma yok)", eng.cnameVerdict(longChain, 0, longChain.size) == FilterVerdict.LIST)
        // d) 64 KB'a kadar dolgu kayıtlarıyla (A) tarama, 5 bin kayıt
        val many = cpuResp("x.fine.example", (0 until 5000).map { CpuRr(null, 1, byteArrayOf(1, 2, 3, it.toByte())) })
        val msM = cpuMs { repeat(300) { eng.cnameVerdict(many, 0, many.size); eng.rebindVerdict(many, 0, many.size) } }
        T.check("5 bin kayıtlı cevap ×300 (cname+rebind): < 12 sn", msM < 12000, "$msM ms (${many.size} bayt)")
        // e) kendine dönen / uzun işaretçi zincirleri: asla takılmaz
        val hdr = ByteArray(12); Packets.put16(hdr, 2, 0x8180); Packets.put16(hdr, 4, 1); Packets.put16(hdr, 6, 3)
        val body = java.io.ByteArrayOutputStream(); body.write(hdr)
        val qn = cpuWire("x.fine.example"); body.write(qn); body.write(byteArrayOf(0, 1, 0, 1))
        val loopAt = body.size()
        // CNAME kaydı: rdata = kendine işaret eden (loopAt'ın içinden loopAt'a) işaretçi
        repeat(3) {
            body.write(0xC0); body.write(12)
            body.write(byteArrayOf(0, 5, 0, 1, 0, 0, 0, 60, 0, 2))
            val here = body.size()
            body.write(0xC0 or (here ushr 8)); body.write(here and 0xFF)
        }
        val loopMsg = body.toByteArray()
        val msL = cpuMs { repeat(20_000) { eng.cnameVerdict(loopMsg, 0, loopMsg.size); eng.rebindVerdict(loopMsg, 0, loopMsg.size) } }
        T.check("kendine işaret eden rdata ×20 bin: takılmaz, < 8 sn, geçer", eng.cnameVerdict(loopMsg, 0, loopMsg.size) == FilterVerdict.PASS && msL < 8000, "$msL ms (konum $loopAt)")
        // 9 işaretçilik zincir
        val ch = java.io.ByteArrayOutputStream(); ch.write(hdr); Packets.put16(hdr, 6, 2)
        val c2 = java.io.ByteArrayOutputStream(); c2.write(hdr); c2.write(qn); c2.write(byteArrayOf(0, 1, 0, 1))
        for (k in 0 until 2) { c2.write(0xC0); c2.write(12); c2.write(byteArrayOf(0, 5, 0, 1, 0, 0, 0, 60, 0, 2)); val p0 = c2.size() + 2 + if (k == 0) 0 else 0; c2.write(0xC0); c2.write(12) }
        val chained = c2.toByteArray()
        T.check("işaretçi → soru adı: izleyici değilse geçer", eng.cnameVerdict(chained, 0, chained.size) == FilterVerdict.PASS)
        // f) rastgele bozuk cevap yağmuru: istisna yok, süre sınırlı
        val rnd = Random(0xC0FFEE)
        var ex = 0
        val msF = cpuMs {
            repeat(60_000) {
                val n = 12 + rnd.nextInt(600)
                val b = ByteArray(n); rnd.nextBytes(b)
                if (rnd.nextBoolean()) { Packets.put16(b, 2, 0x8180); Packets.put16(b, 4, 1); Packets.put16(b, 6, 1 + rnd.nextInt(65000)) }
                try { eng.cnameVerdict(b, 0, n); eng.rebindVerdict(b, 0, n); Dns.ageTtls(b, 0, n, 5); Dns.setTtls(b, 0, n, 9); Dns.isBlocked(b, n) } catch (_: Throwable) { ex++ }
            }
        }
        T.check("60 bin rastgele bozuk cevap (an=65000'e kadar): istisna yok, < 20 sn", ex == 0 && msF < 20000, "ex=$ex $msF ms")
        // g) 64 KB mesajda TTL işlemleri
        val big = cpuResp("x.fine.example", (0 until 4000).map { CpuRr(null, 1, byteArrayOf(1, 2, 3, 4)) })
        val msT = cpuMs { repeat(2000) { Dns.ageTtls(big, 0, big.size, 1); Dns.setTtls(big, 0, big.size, 30) } }
        T.check("4 bin kayıtlı cevapta TTL eskitme ×2000: < 12 sn", msT < 12000, "$msT ms")
        println("    (cname zinciri $msC ms, 5k kayıt $msM ms, döngü $msL ms, bozuk $msF ms, ttl $msT ms)")
    }

    // ---- 5. Public Suffix en kötü durum ----
    T.group("Sızma 15 / Public Suffix: 127 etiketli adlarda registrableStart süresi")
    run {
        val f = File("app/src/main/assets/filter/psl.txt")
        val was = PublicSuffix.ready
        try {
            if (f.exists()) f.inputStream().use { PublicSuffix.install(it) }
            val nm = cpuDeep("co.uk").toByteArray(Charsets.ISO_8859_1)
            var r = 0
            val ms = cpuMs { repeat(50_000) { r = PublicSuffix.registrableStart(nm, nm.size) } }
            T.check("50 bin çağrı (253 karakter / ~125 etiket): < 16 sn", ms < 16000, "$ms ms (psl=${PublicSuffix.ready})")
            T.check("doğru eTLD+1 (a.co.uk)", r >= 0 && String(nm, r, nm.size - r, Charsets.ISO_8859_1) == "a.co.uk" || !PublicSuffix.ready, "r=$r")
        } finally { if (!was) PublicSuffix.clear() }
    }

    // ---- 6. DNS önbelleği ----
    T.group("Sızma 15 / DnsCache: hashCode'u çakışan 131 bin anahtar, bellek tavanı, sınır değerleri")
    run {
        // "Aa" ve "BB" aynı hashCode'a sahip: 17 çiftten 2^17 çakışan anahtar
        val keys = ArrayList<String>(1 shl 17)
        fun gen(prefix: String, depth: Int) { if (depth == 17) { keys.add(prefix); return }; gen(prefix + "Aa", depth + 1); gen(prefix + "BB", depth + 1) }
        gen("", 0)
        T.check("anahtarlar gerçekten çakışıyor", keys.size == 131_072 && keys.map { it.hashCode() }.toSet().size == 1)
        var now = 1_000_000L
        val cache = DnsCache(1000, { now }, 1000 * 1024)
        val resp = ByteArray(300) { 7 }
        Packets.put16(resp, 2, 0x8180)
        val ms = cpuMs { for (k in keys) cache.put(k, resp, resp.size, 60) }
        T.check("131 bin çakışan anahtar eklemek: < 20 sn", ms < 20000, "$ms ms")
        val out = ByteArray(512)
        var present = 0
        for (k in keys) if (cache.get(k, 0x7777, out, 0) > 0) present++
        T.check("tavan: en çok 1000 kayıt kalır (bulunan $present)", present in 1..1000, "$present")
        T.check("en yeni anahtar durur, en eski atılmış", cache.get(keys.last(), 1, out, 0) > 0 && cache.get(keys.first(), 1, out, 0) < 0)
        val ms2 = cpuMs { repeat(2) { for (k in keys) cache.get(k, 1, out, 0) } }
        T.check("çakışan anahtarlarla 262 bin okuma: < 20 sn", ms2 < 20000, "$ms2 ms")
        // bayt tavanı: 100 KB tavanda 4000 baytlık kayıtlar
        val c2 = DnsCache(100_000, { now }, 100 * 1024)
        val fat = ByteArray(4000) { 1 }; Packets.put16(fat, 2, 0x8180)
        for (i in 0 until 5000) c2.put("k$i", fat, fat.size, 60)
        var kept = 0; val ob = ByteArray(5000)
        for (i in 0 until 5000) if (c2.get("k$i", 1, ob, 0) > 0) kept++
        T.check("bayt tavanı: 100 KB'ta ≤ 25 dev kayıt (bulunan $kept)", kept in 1..26, "$kept")
        // sınır değerleri
        c2.put("neg", fat, fat.size, -5); c2.put("zero", fat, fat.size, 0); c2.put("max", fat, fat.size, Int.MAX_VALUE)
        c2.put("empty", fat, 0, 60); c2.put("big", ByteArray(DnsCache.MAX_ENTRY_BYTES + 1), DnsCache.MAX_ENTRY_BYTES + 1, 60)
        T.check("TTL ≤ 0, boş, devasa cevap saklanmaz", c2.get("neg", 1, ob, 0) < 0 && c2.get("zero", 1, ob, 0) < 0 && c2.get("empty", 1, ob, 0) < 0 && c2.get("big", 1, ob, 0) < 0)
        T.check("TTL = Int.MAX tavana (300 sn) çekilir", c2.get("max", 1, ob, 0) > 0)
        now += 301_000
        T.check("300 sn sonra düşer (sonsuz TTL ile kalıcı zehirleme yok)", c2.get("max", 1, ob, 0) < 0)
        T.check("çıkış tamponu küçükse -1 (taşma yok)", run { c2.put("s", fat, fat.size, 60); c2.get("s", 1, ByteArray(100), 0) < 0 && c2.get("s", 1, ob, 4500) < 0 && c2.get("s", 1, ob, -1) < 0 })
        // çok iş parçacıklı çakışan anahtar seli
        val c3 = DnsCache(500, { System.currentTimeMillis() }, 500 * 1024)
        val errs = java.util.concurrent.atomic.AtomicInteger()
        val ths = (0 until 8).map { t -> Thread {
            val r = Random(t.toLong()); val o = ByteArray(512)
            try { repeat(20_000) { val k = keys[r.nextInt(keys.size)]; if (r.nextBoolean()) c3.put(k, resp, resp.size, 30) else { c3.get(k, 1, o, 0); c3.getStale(k, 1, o, 0); c3.prefetchDue(k) } } } catch (_: Throwable) { errs.incrementAndGet() }
        } }
        val mt = cpuMs { ths.forEach { it.start() }; ths.forEach { it.join(30_000) } }
        T.check("8 iş parçacığı × 20 bin işlem, çakışan anahtarlar: istisna yok, < 60 sn", errs.get() == 0 && mt < 60000, "err=${errs.get()} $mt ms")
        println("    (çakışan ekleme $ms ms, okuma $ms2 ms, çok iş parçacıklı $mt ms)")
    }

    // ---- 7. Özet işlevi: dağılım ----
    T.group("Sızma 15 / FilterHash: 48 bitlik özet dağılımı (kaba çakışma saldırısı yok), liste sızıntı oranı")
    run {
        val rnd = Random(0x4A5)
        val set = HashSet<Long>()
        var coll = 0
        val n = 600_000
        for (i in 0 until n) {
            val s = "x" + Integer.toString(rnd.nextInt(), 36) + "." + i + ".tld"
            if (!set.add(FilterHash.hash(s))) coll++
        }
        T.check("600 bin farklı ad: 48 bitte çakışma ≤ 3 (beklenen ≈ ${(n.toDouble() * n / 2 / 2.8e14).let { String.format("%.4f", it) }})", coll <= 3, "coll=$coll")
        // her çıkış bitinin ~%50 olması (kaba çığ testi)
        val ones = IntArray(48)
        val m = 50_000
        for (i in 0 until m) { val h = FilterHash.hash("a$i.com"); for (b in 0 until 48) if ((h ushr b) and 1L == 1L) ones[b]++ }
        T.check("her çıkış biti %49-%51 arası (tek sayıdan farklı girişlerle)", ones.all { it in (m * 49 / 100)..(m * 51 / 100) }, ones.minOrNull().toString() + ".." + ones.maxOrNull())
        // bir bit farklı giriş → ortalama 24 bit fark
        var tot = 0L
        for (i in 0 until 20_000) { val a = "site$i.com".toByteArray(); val b = a.copyOf(); b[i % b.size] = (b[i % b.size].toInt() xor 1).toByte(); tot += java.lang.Long.bitCount(FilterHash.hash(a, 0, a.size) xor FilterHash.hash(b, 0, b.size)) }
        val avg = tot / 20_000.0
        T.check("çığ: 1 bit giriş değişimi ≈ 24 çıkış biti (ortalama %.1f)".format(avg), avg in 22.5..25.5, "$avg")
        // 1 milyon girişli bir katmanda rastgele 1 milyon ad: yanlış pozitif ≈ 1e6/2.8e14
        val big = LongArray(1_000_000) { FilterHash.hash("b$it.blocked.example") }; big.sort()
        val tier = FilterTier(big)
        var fp = 0
        repeat(1_000_000) { if (tier.contains(FilterHash.hash("q${it}x.ok.example"))) fp++ }
        T.check("1 milyon girişli katmanda 1 milyon yabancı ad: yanlış pozitif ≤ 2", fp <= 2, "fp=$fp")
        T.check("katmandaki girişler bulunur", (0 until 1000).all { tier.contains(FilterHash.hash("b${it * 997}.blocked.example")) })
    }
}
