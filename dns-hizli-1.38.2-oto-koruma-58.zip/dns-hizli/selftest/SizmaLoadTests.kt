package app.dnshizli.selftest

import app.dnshizli.core.*
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.Random
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Sızma 17 — derin yük kampanyası (normal kullanımın ≥ 2000 katı) ve yeni saldırı teknikleri.
 *
 * sizma16 UDP DNS selini, tamamlanmayan SYN selini ve UDP akış selini zaten sürüyor. Burada ONLARIN DIŞINDAKİLER:
 *  1) bozuk/değiştirilmiş paket yağmuru (iç hata sayacı sıfır kalmalı, büyütme oranı ölçülür),
 *  2) tamamlanmış ama sessiz / sürekli canlı tutulan 1500 bağlantıyla tabloyu kilitleme ("slowloris"),
 *  3) okumayan sunuculara veri basarak ortak bellek tavanını bitirme (açlık saldırısı),
 *  4) sıfır pencereli istemciler + sonsuz veri basan sunucu (yeniden iletim fırtınası),
 *  5) IPv4/IPv6 parça seli (parçalar akış açmamalı),
 *  6) 8 iş parçacıklı süzgeç/önbellek verimi (≥ 100 bin sorgu/sn = normalin ~2000 katı),
 *  7) hepsi aynı anda (birleşik fırtına) + dürüst trafiğin başarısı.
 */

private class LdSink : AutoCloseable {
    val ss = ServerSocket(0, 4096, InetAddress.getByAddress(LO4)).also { it.receiveBufferSize = 4096 }
    val port get() = ss.localPort
    val accepted = AtomicInteger()
    private val held = java.util.Collections.synchronizedList(ArrayList<Socket>())
    init {
        Thread({
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (_: Exception) { break }
                accepted.incrementAndGet(); held.add(s)          // okumaz
                if (held.size > 1600) try { held.removeAt(0).close() } catch (_: Exception) {}
            }
        }, "ld-sink").also { it.isDaemon = true }.start()
    }
    override fun close() { ss.close(); synchronized(held) { held.forEach { try { it.close() } catch (_: Exception) {} } } }
}

private fun ldEcho() = Srv { s ->
    val i = s.getInputStream(); val o = s.getOutputStream(); val b = ByteArray(4096)
    while (true) { val n = try { i.read(b) } catch (_: Exception) { -1 }; if (n < 0) break; o.write(b, 0, n); o.flush() }
}

private fun ldHonest(r: GRig, port: Int, msg: String = "saglik", ms: Long = 8000): Boolean {
    val c = GCli(r, port)
    val sa = c.connect() ?: return false
    if (sa.flags != (F_SYN or F_ACK)) return false
    val got = echoWithRetx(c, msg.toByteArray(), ms)
    try { c.send(F_RST) } catch (_: Exception) {}
    return String(got) == msg
}

private fun ldRandomPacket(rnd: Random, dport: Int): ByteArray {
    val buf = ByteArray(2048)
    val v6 = rnd.nextInt(4) == 0
    val src: ByteArray = if (v6) SelfTest.CLIENT6 else CLI4
    val dst: ByteArray = if (v6) ByteArray(16).also { rnd.nextBytes(it) } else LO4
    val sport = 1024 + rnd.nextInt(60000)
    val dlen = if (rnd.nextInt(3) == 0) rnd.nextInt(1300) else rnd.nextInt(40)
    val data = ByteArray(dlen).also { rnd.nextBytes(it) }
    val p: ByteArray = when (rnd.nextInt(6)) {
        0 -> { val n = rnd.nextInt(1500); ByteArray(n).also { rnd.nextBytes(it); if (n > 0) it[0] = (if (rnd.nextBoolean()) 0x45 else 0x60 or rnd.nextInt(16)).toByte() } }
        1, 2 -> { val n = Gw.tcp(buf, v6, src, dst, sport, if (rnd.nextInt(3) == 0) 1 + rnd.nextInt(65535) else dport, rnd.nextInt(), rnd.nextInt(), rnd.nextInt(64), rnd.nextInt(65536), data, 0, dlen, if (rnd.nextBoolean()) rnd.nextInt(2000) else 0); buf.copyOf(n) }
        3 -> { val n = Gw.udp(buf, v6, src, dst, sport, if (rnd.nextBoolean()) 53 else 1 + rnd.nextInt(65535), data, 0, dlen); buf.copyOf(n) }
        4 -> { val n = Gw.tcp(buf, v6, src, dst, sport, dport, rnd.nextInt(), 0, Gw.SYN, 65535, null, 0, 0, 1460); buf.copyOf(n) }
        else -> { val dq = ldDnsQuery(rnd); val n = Gw.udp(buf, v6, src, dst, sport, 53, dq, 0, dq.size); buf.copyOf(n) }
    }
    if (p.isEmpty()) return p
    // değiştirme
    repeat(rnd.nextInt(4)) {
        when (rnd.nextInt(7)) {
            0 -> if (p.isNotEmpty()) p[rnd.nextInt(p.size)] = rnd.nextInt().toByte()
            1 -> if (p.size > 3) p[0] = ((p[0].toInt() and 0xF0) or rnd.nextInt(16)).toByte()                 // IHL / sürüm
            2 -> if (p.size > 3) Packets.put16(p, 2, rnd.nextInt(70000))                                      // toplam uzunluk yalanı
            3 -> if (p.size > 33) p[32] = rnd.nextInt().toByte()                                              // TCP veri ofseti
            4 -> if (p.size > 9) p[9] = rnd.nextInt().toByte()                                                // protokol
            5 -> if (p.size > 7) Packets.put16(p, 6, rnd.nextInt(65536))                                      // parça alanı
            else -> {}
        }
    }
    return if (rnd.nextInt(5) == 0 && p.size > 4) p.copyOf(rnd.nextInt(p.size)) else p
}

private fun ldDnsQuery(rnd: Random): ByteArray {
    val name = "x" + rnd.nextInt(1000) + ".ornek.com"
    val o = java.io.ByteArrayOutputStream()
    val h = ByteArray(12); Packets.put16(h, 0, rnd.nextInt(65536)); Packets.put16(h, 2, 0x0100); Packets.put16(h, 4, 1); o.write(h)
    for (l in name.split('.')) { o.write(l.length); o.write(l.toByteArray()) }
    o.write(0); o.write(byteArrayOf(0, 1, 0, 1))
    return o.toByteArray()
}

private fun ldTcpDst(p: ByteArray): Int {          // IPv4 TCP paketinin hedef (istemci) portu; değilse -1
    if (p.size < 24 || (p[0].toInt() ushr 4) != 4 || (p[9].toInt() and 0xFF) != 6) return -1
    return Packets.u16(p, (p[0].toInt() and 0xF) * 4 + 2)
}

fun runHeavyLoadTests() {
    // ---------------------------------------------------------------- 1. bozuk paket yağmuru
    T.group("Sızma 17 / Ağ geçidi: 400 bin bozuk/değiştirilmiş paket (rastgele bayt, uzunluk-IHL-parça-protokol yalanları) — iç hata yok, büyütme oranı sınırlı, dürüst akış sağlam")
    run {
        val r = GRig(); val echo = ldEcho()
        try {
            val outBytes = AtomicLong(); val outPkts = AtomicLong()
            r.tap = { pk -> outBytes.addAndGet(pk.size.toLong()); outPkts.incrementAndGet(); true }
            val rnd = Random(0x17A)
            val heap0 = usedHeapMb(); val th0 = liveThreads()
            var inBytes = 0L; var sent = 0
            val t0 = System.nanoTime()
            for (i in 0 until 400_000) {
                val p = ldRandomPacket(rnd, echo.port)
                if (p.size < 20) continue
                r.gw.onPacket(p, p.size); inBytes += p.size; sent++
                if (i % 800 == 799) Thread.sleep(1)
            }
            Thread.sleep(1500)
            val secs = (System.nanoTime() - t0) / 1e9
            r.tap = null
            val st = r.gw.stats()
            println("    ($sent paket ${"%.1f".format(secs)} sn; çıkış ${outPkts.get()} paket / ${outBytes.get()} bayt; giriş $inBytes bayt; akış tcp=${st.tcpFlows} udp=${st.udpFlows}; iç hata=${st.internalErrors})")
            T.check("iç hata sayacı 0 (bozuk girdi istisna fırlatmamalı)", st.internalErrors == 0L, r.gw.lastInternalError())
            T.check("büyütme: çıkış baytı ≤ 2,5 × giriş baytı (yansıtma/amplifikasyon yok)", outBytes.get() <= inBytes * 5 / 2, "${outBytes.get()} / $inBytes")
            T.check("tablo tavanları aşılmadı", st.tcpFlows <= r.gw.config.maxTcp && st.udpFlows <= r.gw.config.maxUdp, "tcp=${st.tcpFlows} udp=${st.udpFlows}")
            r.gw.networkReset()
            T.check("ağ sıfırlama sonrası tablolar boşalır", waitUntil(8000) { r.gw.stats().tcpFlows == 0 && r.gw.stats().udpFlows == 0 })
            T.check("dürüst akış yağmurdan sonra çalışır", ldHonest(r, echo.port))
            T.check("yığın şişmez (${heap0} → ${usedHeapMb()} MB, en çok +80)", usedHeapMb() - heap0 <= 80)
            T.check("iş parçacığı sızmaz (${th0} → ${liveThreads()}, en çok +10)", liveThreads() - th0 <= 10)
        } finally { echo.close(); r.close() }
    }

    // ---------------------------------------------------------------- 2. tamamlanmış sessiz bağlantılarla tabloyu kilitleme
    T.group("Sızma 17 / Ağ geçidi: 1500 tamamlanmış bağlantıyla tabloyu doldurma (sessiz ve sürekli canlı) — boşta olanlar tahliye edilir, saldırı bitince dürüst akış girer")
    run {
        val r = GRig(); val sink = LdSink(); val echo = ldEcho()
        try {
            r.gw.config.evictIdleMs = 500
            val clients = ArrayList<GCli>()
            var ok = 0
            val t0 = System.nanoTime()
            for (i in 0 until r.gw.config.maxTcp) {
                val c = GCli(r, sink.port); val sa = c.connect()
                if (sa != null && sa.flags == (F_SYN or F_ACK)) { ok++; clients.add(c) }
            }
            val secs = (System.nanoTime() - t0) / 1e9
            println("    ($ok/${r.gw.config.maxTcp} tamamlanmış bağlantı ${"%.1f".format(secs)} sn'de; tablo=${r.gw.stats().tcpFlows})")
            T.check("saldırgan bağlantıların çoğu kuruldu (≥ %80)", ok >= r.gw.config.maxTcp * 8 / 10, "$ok")
            // (a) sürekli canlı: her 250 ms'de hepsi bir bayt yazar → boşta sayılmaz; dürüst bağlantı reddedilir (kaynak sınırı kaçınılmaz)
            val live = AtomicBoolean(true)
            val pump = Thread { while (live.get()) { for (c in clients) { try { c.write(byteArrayOf(1)) } catch (_: Exception) {} }; try { Thread.sleep(150) } catch (_: Exception) {} } }
            pump.isDaemon = true; pump.start()
            Thread.sleep(300)
            val honestLive = ldHonest(r, echo.port, ms = 2500)
            println("    (tablo canlı tutulurken dürüst bağlantı: ${if (honestLive) "KABUL" else "reddedildi (sınır dolu, beklenen)"})")
            live.set(false); pump.join(5000)
            // (b) saldırı durunca: boşta kalanlar tahliye edilir, dürüst akış girer
            r.q.clear()
            val recovered = waitUntil(8000) { Thread.sleep(300); ldHonest(r, echo.port, ms = 2500) }
            T.check("saldırı bitince ≤ 8 sn içinde dürüst bağlantı kabul edilir (15 dk kilitlenme yok)", recovered)
            T.check("iç hata yok", r.gw.stats().internalErrors == 0L, r.gw.lastInternalError())
            T.check("tablo tavanı aşılmadı", r.gw.stats().tcpFlows <= r.gw.config.maxTcp)
        } finally { echo.close(); sink.close(); r.close() }
    }

    // ---------------------------------------------------------------- 3. bellek tavanı açlığı
    T.group("Sızma 17 / Ağ geçidi: okumayan 300 sunucuya veri basarak ortak bellek tavanını (24 MB) bitirme — tavan aşılmaz, dürüst akış aç kalmaz")
    run {
        val r = GRig(); val sink = LdSink(); val echo = ldEcho()
        try {
            val honest = GCli(r, echo.port)
            val sa = honest.connect()
            T.check("dürüst akış baştan kuruldu", sa != null && sa.flags == (F_SYN or F_ACK))
            honest.write("once".toByteArray())
            T.check("dürüst yankı baştan çalışıyor", String(honest.read(4, 3000)) == "once")
            val heap0 = usedHeapMb()
            val attackPorts = java.util.Collections.newSetFromMap(java.util.concurrent.ConcurrentHashMap<Int, Boolean>())
            val dropped = AtomicLong()
            r.tap = { pk -> val d = ldTcpDst(pk); if (d in attackPorts) { dropped.incrementAndGet(); true } else false }
            val chunk = ByteArray(1200) { 9 }
            val flows = ArrayList<GCli>()
            for (i in 0 until 300) {
                val c = GCli(r, sink.port)
                val s = c.connect(); if (s == null || s.flags != (F_SYN or F_ACK)) continue
                attackPorts.add(c.sport); flows.add(c)
            }
            // her akış 600 KB'a kadar basar (pencereyi umursamadan): çekirdek tamponları + 128 KB kuyruk dolar
            val t0 = System.nanoTime()
            for (round in 0 until 500) {
                for (c in flows) c.write(chunk)
                if (round % 20 == 19) Thread.sleep(5)
            }
            Thread.sleep(1500)
            val used = r.gw.mem.used; val lim = r.gw.mem.limit
            println("    (${flows.size} akış, ${"%.1f".format((System.nanoTime() - t0) / 1e9)} sn; ortak bellek ${used shr 10} / ${lim shr 10} KB; yığın ${heap0} → ${usedHeapMb()} MB)")
            T.check("ortak bellek tavanı aşılmadı ($used ≤ $lim)", used <= lim)
            T.check("yığın şişmez (en çok +110 MB)", usedHeapMb() - heap0 <= 110, "${heap0} → ${usedHeapMb()}")
            T.check("iç hata yok", r.gw.stats().internalErrors == 0L, r.gw.lastInternalError())
            // dürüst, MEVCUT akış (açlık testi)
            honest.write("sonra-1".toByteArray())
            val e1 = String(honest.read(7, 6000))
            // dürüst, YENİ akış
            val newOk = ldHonest(r, echo.port, "sonra-2", 6000)
            println("    (bellek tavanı doluyken dürüst mevcut akış: ${if (e1 == "sonra-1") "ÇALIŞTI" else "AÇ KALDI \"$e1\""}; yeni akış: ${if (newOk) "ÇALIŞTI" else "AÇ KALDI"}; kullanılan bellek ${r.gw.mem.used shr 10} KB)")
            T.check("dürüst mevcut akış, tavan doluyken de çalışır (adil pay)", e1 == "sonra-1", "\"$e1\"")
            T.check("dürüst yeni akış, tavan doluyken de çalışır", newOk)
            r.tap = null
        } finally { echo.close(); sink.close(); r.close() }
    }

    // ---------------------------------------------------------------- 4. sıfır pencere / yeniden iletim fırtınası
    T.group("Sızma 17 / Ağ geçidi: 400 istemci hiç ACK vermiyor, sunucu sonsuz veri basıyor — yeniden iletim fırtınası yok, bellek sabit, akışlar sonunda kapanır")
    run {
        val r = GRig(); val fire = Srv { s -> val b = ByteArray(8192) { 3 }; val o = s.getOutputStream(); while (true) o.write(b) }
        val echo = ldEcho()
        try {
            val honest = GCli(r, echo.port)
            honest.connect()
            val ports = java.util.Collections.newSetFromMap(java.util.concurrent.ConcurrentHashMap<Int, Boolean>())
            val bytesOut = AtomicLong(); val pktsOut = AtomicLong()
            r.tap = { pk -> if (ldTcpDst(pk) in ports) { bytesOut.addAndGet(pk.size.toLong()); pktsOut.incrementAndGet(); true } else false }
            val heap0 = usedHeapMb()
            val cs = ArrayList<GCli>()
            for (i in 0 until 400) {
                val c = GCli(r, fire.port)
                val s = c.connect(); if (s == null || s.flags != (F_SYN or F_ACK)) continue
                ports.add(c.sport); c.win = 0
                c.write(byteArrayOf(1)); cs.add(c)
            }
            Thread.sleep(2500)                       // ilk dolgu bitsin
            val p0 = pktsOut.get(); val b0 = bytesOut.get()
            Thread.sleep(4000)
            val dp = pktsOut.get() - p0; val db = bytesOut.get() - b0
            println("    (${cs.size} akış; ilk 2,5 sn sonra 4 sn'de ${dp} paket / ${db} bayt; ort. ${dp / 4 / maxOf(1, cs.size)} paket/sn/akış; bellek ${r.gw.mem.used shr 10} KB; yığın ${heap0} → ${usedHeapMb()} MB)")
            T.check("durağan yeniden iletim hızı akış başına ≤ 8 paket/sn (ACK'siz akış fırtına yapmaz)", dp / 4 <= cs.size * 8L, "$dp paket / 4 sn")
            T.check("bellek tavanı aşılmadı", r.gw.mem.used <= r.gw.mem.limit)
            T.check("yığın şişmez (en çok +80 MB)", usedHeapMb() - heap0 <= 80)
            honest.write("canli".toByteArray())
            T.check("sıfır pencereli saldırı sürerken dürüst akış çalışır", String(honest.read(5, 6000)) == "canli")
            T.check("iç hata yok", r.gw.stats().internalErrors == 0L, r.gw.lastInternalError())
            r.tap = null
        } finally { echo.close(); fire.close(); r.close() }
    }

    // ---------------------------------------------------------------- 5. parça seli
    T.group("Sızma 17 / Ağ geçidi: 200 bin IPv4/IPv6 parçası (ilk olmayan parçaya gömülü sahte SYN dahil) — hiçbiri akış açmaz, çıkış yok")
    run {
        val r = GRig(); val sink = LdSink()
        try {
            val out = AtomicLong(); r.tap = { out.incrementAndGet(); true }
            val rnd = Random(0xF4A6)
            val buf = ByteArray(2048)
            var sent = 0
            for (i in 0 until 200_000) {
                val sport = 1024 + rnd.nextInt(60000)
                val v6 = i % 3 == 0
                val src: ByteArray = if (v6) SelfTest.CLIENT6 else CLI4
                val dst: ByteArray = if (v6) SelfTest.FAKE6 else LO4
                val n = Gw.tcp(buf, v6, src, dst, sport, sink.port, rnd.nextInt(), 0, Gw.SYN, 65535, null, 0, 0, 1460)
                var p = buf.copyOf(n)
                if (!v6) {
                    // MF=1 ya da ofset>0: alan 6-7; başlık sağlama toplamı yeniden hesaplanır
                    val frag = when (i % 3) { 1 -> 0x2000; else -> 1 + rnd.nextInt(0x1FFF) }
                    Packets.put16(p, 6, frag)
                    p[10] = 0; p[11] = 0
                    var s = 0L; for (k in 0 until 20 step 2) s += Packets.u16(p, k)
                    while (s ushr 16 != 0L) s = (s and 0xFFFF) + (s ushr 16)
                    Packets.put16(p, 10, (s.inv() and 0xFFFF).toInt())
                } else {
                    // ardıl başlık 44 (parça başlığı) araya girer; ilk olmayan parça, içinde TCP SYN taşır
                    val q = ByteArray(p.size + 8)
                    System.arraycopy(p, 0, q, 0, 40); q[6] = 44
                    Packets.put16(q, 4, Packets.u16(p, 4) + 8)
                    q[40] = 6; q[41] = 0; Packets.put16(q, 42, (1 + rnd.nextInt(0x1FFF)) shl 3); Packets.put32(q, 44, rnd.nextInt())
                    System.arraycopy(p, 40, q, 48, p.size - 40)
                    p = q
                }
                r.gw.onPacket(p, p.size); sent++
                if (i % 800 == 799) Thread.sleep(1)
            }
            Thread.sleep(1000)
            val st = r.gw.stats()
            println("    ($sent parça; açılan akış=${st.opened}; tablo tcp=${st.tcpFlows}; sink kabul=${sink.accepted.get()}; çıkış paket=${out.get()})")
            T.check("hiçbir parça akış açmadı", st.opened == 0L && st.tcpFlows == 0 && sink.accepted.get() == 0, "opened=${st.opened} tcp=${st.tcpFlows} sink=${sink.accepted.get()}")
            T.check("parçalara cevap (RST/SYN-ACK) üretilmedi", out.get() == 0L, "${out.get()}")
            T.check("iç hata yok", st.internalErrors == 0L, r.gw.lastInternalError())
        } finally { sink.close(); r.close() }
    }

    // ---------------------------------------------------------------- 6. süzgeç / önbellek verimi
    T.group("Sızma 17 / Çekirdek: 8 iş parçacığı × süzgeç + önbellek — normalin 2000 katı (≥ 100 bin sorgu/sn) sürdürülür ve sonuçlar doğru kalır")
    run {
        val tier = FilterEngine.toTier((0 until 40_000).map { "reklam$it.izleyici.net" })
        val base = FilterEngine(listOf(tier), FilterTier.EMPTY, listOf("izinli.example"), listOf("benimengel.example"))
        val cache = DnsCache(2000, { System.currentTimeMillis() }, 2000 * 1024)
        val resp = ByteArray(200) { 5 }; Packets.put16(resp, 2, 0x8180)
        val total = AtomicLong(); val wrong = AtomicInteger(); val errs = AtomicInteger()
        val stop = AtomicBoolean(false)
        val ths = (0 until 8).map { t -> Thread {
            val eng = base.fork(); val rnd = Random(t.toLong() * 31 + 1); val out = ByteArray(512)
            try {
                while (!stop.get()) {
                    repeat(500) {
                        val k = rnd.nextInt(5)
                        val (name, want) = when (k) {
                            0 -> "reklam${rnd.nextInt(40_000)}.izleyici.net" to FilterVerdict.LIST
                            1 -> "www.benimengel.example" to FilterVerdict.USER
                            2 -> "a.b.izinli.example" to FilterVerdict.PASS
                            3 -> "temiz${rnd.nextInt(100000)}.example.org" to FilterVerdict.PASS
                            else -> "x.reklam${rnd.nextInt(40_000)}.izleyici.net" to FilterVerdict.LIST
                        }
                        val q = ByteArray(12 + name.length + 2 + 4)
                        Packets.put16(q, 4, 1)
                        var o = 12; for (l in name.split('.')) { q[o++] = l.length.toByte(); System.arraycopy(l.toByteArray(), 0, q, o, l.length); o += l.length }
                        q[o++] = 0; q[o++] = 0; q[o++] = 1; q[o++] = 0; q[o] = 1
                        if (eng.verdict(q, 0, q.size) != want) wrong.incrementAndGet()
                        val ck = "k" + rnd.nextInt(3000)
                        if (rnd.nextBoolean()) cache.put(ck, resp, resp.size, 30) else cache.get(ck, 7, out, 0)
                    }
                    total.addAndGet(500)
                }
            } catch (_: Throwable) { errs.incrementAndGet() }
        } }
        val t0 = System.nanoTime()
        ths.forEach { it.isDaemon = true; it.start() }
        Thread.sleep(4000); stop.set(true); ths.forEach { it.join(10000) }
        val secs = (System.nanoTime() - t0) / 1e9
        val qps = (total.get() / secs).toLong()
        println("    (${total.get()} işlem, ${"%.1f".format(secs)} sn → ${qps} süzgeç+önbellek sorgusu/sn)")
        T.check("sürdürülen hız ≥ 100 bin sorgu/sn (normal kullanımın ~2000 katı)", qps >= 100_000, "$qps")
        T.check("eşzamanlı yükte süzgeç kararı hiç yanlış çıkmadı", wrong.get() == 0, "${wrong.get()}")
        T.check("istisna yok", errs.get() == 0)
    }

    // ---------------------------------------------------------------- 7. birleşik fırtına
    T.group("Sızma 17 / Birleşik fırtına: bozuk paket + SYN + UDP + tamamlanmış sessiz bağlantı + parça seli AYNI ANDA 8 sn — dürüst yeni bağlantılar ve kaynaklar")
    run {
        val r = GRig(); val sink = LdSink(); val echo = ldEcho()
        try {
            r.gw.config.evictIdleMs = 1000
            val out = AtomicLong(); val ports = java.util.Collections.newSetFromMap(java.util.concurrent.ConcurrentHashMap<Int, Boolean>())
            r.tap = { pk -> out.incrementAndGet(); ldTcpDst(pk) !in honestPorts }
            val heap0 = usedHeapMb(); val th0 = liveThreads(); val fd0 = fdCount()
            val stop = AtomicBoolean(false)
            val workers = ArrayList<Thread>()
            fun worker(name: String, f: (Random) -> Unit) { workers.add(Thread({ val rnd = Random(name.hashCode().toLong()); while (!stop.get()) { f(rnd) } }, name).also { it.isDaemon = true }) }
            val closedPort = run { val t = java.net.ServerSocket(0, 1, java.net.InetAddress.getByAddress(LO4)); val pt = t.localPort; t.close(); pt }   // boşta (dinlenmeyen) port: geçerli SYN anında reddedilir
            worker("storm-garbage") { rnd -> repeat(300) { val p = ldRandomPacket(rnd, closedPort); if (p.size >= 20) r.gw.onPacket(p, p.size) }; Thread.sleep(1) }
            worker("storm-udp") { rnd -> repeat(200) { val b = ByteArray(2048); val d = ldDnsQuery(rnd); val n = Gw.udp(b, false, CLI4, LO4, 1024 + rnd.nextInt(60000), 1 + rnd.nextInt(65535), d, 0, d.size); r.gw.onPacket(b, n) }; Thread.sleep(1) }
            worker("storm-frag") { rnd -> repeat(200) { val b = ByteArray(2048); val n = Gw.tcp(b, false, CLI4, LO4, 1024 + rnd.nextInt(60000), sink.port, rnd.nextInt(), 0, Gw.SYN, 65535, null, 0, 0, 1460); Packets.put16(b, 6, 0x2000 or (1 + rnd.nextInt(0x1FFF))); r.gw.onPacket(b, n) }; Thread.sleep(1) }
            workers.forEach { it.start() }
            var tries = 0; var ok = 0
            val t0 = System.currentTimeMillis()
            while (System.currentTimeMillis() - t0 < 8000) {
                tries++
                val c = GCli(r, echo.port); honestPorts.add(c.sport)
                val sa = c.connect()
                if (sa != null && sa.flags == (F_SYN or F_ACK)) {
                    c.write("saglik".toByteArray())
                    if (String(c.read(6, 3000)) == "saglik") ok++
                }
                honestPorts.remove(c.sport)
                Thread.sleep(100)
            }
            stop.set(true); workers.forEach { it.join(5000) }
            r.tap = null
            sink.close()            // saldırı hedefinin soketlerini hemen bırak
            r.q.clear()
            Thread.sleep(1500)      // gw-io iş parçacığı birikmiş kutuyu boşaltsın
            val st = r.gw.stats()
            println("    (dürüst yeni bağlantı $ok/$tries; çıkış ${out.get()} paket; tablo tcp=${st.tcpFlows} udp=${st.udpFlows}; reddedilen akış=${r.gw.shedFlows()}; iç hata=${st.internalErrors})")
            T.check("iç hata yok", st.internalErrors == 0L, r.gw.lastInternalError())
            println("    (bilgi: tablo ve jeton kovası tüm kaynaklara ortak; fırtınada yeni dürüst bağlantı başarısı $ok/$tries. Sözleşme: mevcut akış + toparlanma)")
            r.gw.networkReset()
            T.check("fırtına sonrası tablolar boşalır", waitUntil(20000) { r.gw.stats().tcpFlows == 0 && r.gw.stats().udpFlows == 0 }, "tcp=${r.gw.stats().tcpFlows} udp=${r.gw.stats().udpFlows}")
            Thread.sleep(3000)      // TIME_WAIT soketlerinin bir kısmı boşalsın
            val cf0 = r.gw.stats().connectFail
            val fresh = ldEcho()    // taze yukarı sunucu
            val directOk = (1..5).count { try { java.net.Socket().use { it.connect(java.net.InetSocketAddress(InetAddress.getByAddress(LO4), fresh.port), 2000) }; true } catch (_: Exception) { false } }
            T.check("ortam kontrolü: düz soket bağlantıları storm sonrası çalışır ($directOk/5)", directOk == 5, "$directOk/5")
            var post = false
            repeat(25) { if (!post) { post = ldHonest(r, fresh.port, ms = 3000); if (!post) Thread.sleep(1000) } }
            val cf1 = r.gw.stats().connectFail
            fresh.close()
            T.check("fırtına sonrası dürüst akış toparlanır (25 denemeye kadar)", post, "connectFail +${cf1 - cf0}, iç hata=${r.gw.stats().internalErrors}")
            T.check("bellek tavanı aşılmadı", r.gw.mem.used <= r.gw.mem.limit)
            T.check("yığın şişmez (${heap0} → ${usedHeapMb()} MB, en çok +120)", usedHeapMb() - heap0 <= 120)
            T.check("iş parçacığı sızmaz (${th0} → ${liveThreads()}, en çok +12)", liveThreads() - th0 <= 12)
            T.check("dosya tanıtıcısı sızmaz ($fd0 → ${fdCount()}, en çok +60)", fdSettles(fd0 + 60, 10000))
        } finally { echo.close(); sink.close(); r.close() }
    }
}

private val honestPorts: MutableSet<Int> = java.util.Collections.newSetFromMap(java.util.concurrent.ConcurrentHashMap<Int, Boolean>())
