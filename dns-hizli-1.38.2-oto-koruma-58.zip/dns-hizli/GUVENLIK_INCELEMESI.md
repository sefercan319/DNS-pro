# Güvenlik incelemesi (v1.23.0, kaynak kodu okuma)

Kapsam: manifest ve dışa açık bileşenler, ayar içe aktarma, dosya/fotoğraf okuma, DNS/paket ayrıştırıcılar, ODoH ve şifreli ağ katmanı.
Yöntem: kodu okuma + var olan testler (6154 kontrol, 0 hata). Dinamik test (çalışan uygulamaya saldırı), cihaz ve gerçek ağ YAPILMADI.

## Bulgular
| # | Önem | Konu | Durum |
|---|------|------|-------|
| 1 | Düşük | `OdohNode.path` HTTP isteğine doğrudan yazılıyordu; denetim karakteri/boşluk içeren bir yol istek bölmeye yol açabilirdi. Yollar şu an koda gömülü sabitlerdir, yani sömürülebilir değildi (savunma derinliği). | Düzeltildi + test |
| 2 | Düşük | `MiniHttps`: okuma zaman aşımı bir kez kuruluyordu; damlatan bir hedef toplam süreyi (8 sn) ~2 katına çıkarabiliyordu. | Düzeltildi (v1.24.0): zaman aşımı her okumadan önce kalan bütçeye göre yeniden kurulur; test: "yavaş damlatan hedef toplam bütçeyi aşmaz" |
| 3 | Bilgi | Ayar kodu ile `odoh=strict` içe aktarılırsa bağlantı kurulamayabilir (hizmet aksatma). Ayar gevşemediği için uyarı listesinde değil. | Bilinçli |
| 4 | Bilgi | ODoH yapılandırma alımında hedef, kullanıcının IP'sini görür (soru görmez). Röle/hedef anlaşırsa ODoH'un gizliliği biter. İpucu IP'leri zamanla eskir. | Belgelendi (GIZLILIK.md) |

## Temiz çıkanlar
- Manifest: yedekleme kapalı, düz HTTP yasak, VPN servisi dışa kapalı, widget/bildirim alıcıları dışa kapalı; dışa açık ana etkinlik "kes" isteğini kullanıcıya sorar, "bağlan"da sunucu seçemez; BootReceiver sahte QUICKBOOT yayınına karşı korumalı.
- Ayar içe aktarma: boyut sınırı, bilinmeyen/yerel anahtarlar atılır, gevşeme özeti gösterilir, geri alma var. Özel DNS sunucuları dışa/içe aktarılmaz.
- Dosya okuma: karakter sınırı; fotoğraf: örnekleme ile boyut sınırı.
- DNS ayrıştırıcılar: sıkıştırma işaretçisi sınırlı, uzunluklar denetli, rastgele bozma testleri (yüz binlerce girdi) var; sahte cevap soru/kimlik denetimiyle reddedilir.
- ODoH: sertifika adı doğrulanır; cevap AEAD ile doğrulanır, dolgu sıfır olmalı; yapılandırma doğrudan hedeften alınır (röle anahtarı değiştiremez); 401 yenilemesi hız sınırlı; ölü/sahte röle yolu kesilir; ODoH Sıkı'da başka yönteme düşülmez.

## Kapsam dışı / yapılamayan
Cihazda çalışma zamanı davranışı, gerçek ağ saldırıları, bağımsız şifreleme denetimi (X25519/HPKE kendi gerçeklemedir; RFC vektörleri ve JDK ile doğrulandı ama uzman gözden geçirmesi yok), bağımlılık/derleme zinciri. Yayından önce APK'ya MobSF gibi bir araç ya da ücretli bağımsız pentest önerilir.

## HPKE çapraz doğrulama (ek inceleme)
- Bağımsız referans: pyhpke (RFC 9180). Yön 1 (pyhpke gönderir, Kotlin alır) ve yön 2 (Kotlin gönderir, pyhpke açar), 50 rastgele vektörde tutarlı.
- Testler: `selftest/HpkeInteropTests.kt` (grup "hpke"), vektörler `selftest/HpkeVectors.kt`, araçlar `tools/hpke-referans/`.
- Nonce/anahtar kuralları: her kurulumda yeni efemer anahtar, 3000 ardışık şifrelemede nonce tekrarı yok, sıra dışı mesaj reddedilir.
- Bozuk girdi fuzzing: 4000 bit çevirme/kırpma/uzatma; istisna yok, kabul yok, alıcı durumu korunuyor.
- Kapsam dışı: kütüphane (Tink/Bouncy Castle) üretimde kullanılmadı; Maven erişimi bu ortamda kapalı. Coverage-guided fuzzing (Jazzer) ve zamanlama (yan kanal) ölçümü yapılmadı. Zamanlama testi JVM'de güvenilir değildir; kod dallanmasızdır (TweetNaCl yaklaşımı), ama ölçülmedi.

## Ek inceleme (1.28.x): DPI, reklam engeli, şifreli DNS (kripto), IPv4/IPv6

Yöntem: kaynak kodu okuma, hedefli arama (IPv6 başlıkları, Host ayrıştırma, yanıt eşleştirme, rastgelelik, ayar
kodlama) ve yeni testler. Dinamik test ve gerçek ağ YAPILMADI. Kapsam dışı: tam bir sızma testi.

| # | Önem | Konu | Durum |
|---|------|------|-------|
| 1 | Yüksek (ağ geçidi açıkken) | IPv4 tünelinde IPv6 izni verilince (`allowFamily(AF_INET6)`) uygulamaların IPv6 trafiği tünelin dışından çıkıyordu; reklam, DoH ve DPI denetimi bu trafikte atlanıyordu. | Düzeltildi: ağ geçidi açık ve IPv6 tünelde değilse IPv6 izin verilmez, uygulamalar IPv4'e düşer. DNS modunda davranış değişmedi (bilinçli). Android tarafı derlenmedi (bkz. aşağı). |
| 2 | Orta | IPv6 uzantı başlıkları (hop-by-hop, yönlendirme, hedef seçenekleri) desteklenmediği için bu paketler sessizce düşüyordu; bağlantılar takılabiliyordu. | Düzeltildi: `Gw.ipv6Transport` uzantıları atlar; parçalama (44) ve kimlik doğrulama (51) bilinçli olarak düşürülür; zincir en çok 8. Testler eklendi. |
| 3 | Düşük | HTTP `Host` başlığında IPv6 değişmezi (`[2001:db8::1]:8080`) yanlış ayrıştırılıyordu (`[2001`). Reklam/engel eşleşmesi kaçabiliyordu. | Düzeltildi + test. |
| 4 | Düşük (test kararlılığı) | ODoH "anahtar alınamazsa" testi, arka plan ısıtması ile yarışıyordu; bazı çalıştırmalarda başarısız oluyordu. | Test düzeltildi: ağ en baştan kapalı başlatılıyor. Üretim kodu değişmedi. |

Kontrol edilip sorun bulunmayanlar: DNS yanıtı eşleştirme (kimlik + soru + yanıt bayrağı), CNAME gizli izleyici koruması,
ad normalizasyonu (IDN, sonda nokta, şema, bağlantı noktası), çok noktaya yayın ve genel yayın filtresi, IPv6 UDP sağlama
toplamı, TCP başlangıç sıra numarası (SecureRandom), ODoH kimlikleri (SecureRandom), HPKE/AES-GCM kullanımı (önceki incelemedeki
doğrulamalar geçerli).

Bilinen sınırlar (değiştirilmedi):
- DNS modunda yalnızca sistem çözümleyicisi tünele girer. Bir uygulama 8.8.8.8:53 gibi sabit bir sunucuya doğrudan sorarsa
  o sorgu tünelden geçmez. Bu, DNS modunun tasarımıdır; istenirse sabit DNS trafiğini engelleyen ayrı bir seçenek eklenebilir.
- Ağ geçidi açıkken IPv6 kapalı olduğunda IPv6'ya bağımlı (IPv6-only) bir ağda bağlantı zayıflayabilir; IPv6 normal modda açıktır.
- Android tarafındaki değişiklik (DnsVpnService) bu ortamda derlenmedi. Derleme hatası çıkarsa bu bölüme bakılmalı.
- Gerçek telefonda sızıntı testi (örn. IPv6 sızıntı sayfası) yapılmadı; yapılmasını öneririm.


## Ek inceleme (1.29.0): filtre sağlamlığı, Reklam+/DPI adları, liste güncelleme

Yöntem: kaynak okuma, bayt düzeyinde hedefli testler (8 bayt değeri, çoklu soru, işaretçi, kesik paket), çökme benzetimleri. Dinamik test, gerçek ağ ve tam sızma testi YAPILMADI.

| # | Önem | Konu | Durum |
|---|------|------|-------|
| 1 | Yüksek | Etiketlerde 0x80+ ya da ≤0x20 bayt, ad okuyucuda reddedilince sorgu "geçer" sayılıp doğrudan yönlendiriliyordu; engellenecek ad kaçabiliyordu. | Düzeltildi: bayt değerinden bağımsız okunur; test eklendi. |
| 2 | Yüksek | Çoklu soru, sıkıştırma işaretçisi, ayrılmış etiket, kesik soru gibi bozuk sorgular filtreden geçip yukarı sunucuya gidiyordu (sunucu ile filtre farklı soruyu görebilirdi). | Düzeltildi: filtre açıkken bu sorgular yönlendirilmez, FORMERR döner (IPv4 ve IPv6). |
| 3 | Orta | Reklam+/DPI'da SNI/Host adı katı normalizasyondan geçemeyince engel denetimi atlanıyordu. | Düzeltildi: ağdan gelen adlar için gevşek temizleme (`FilterNames.lenient`). |
| 4 | Düşük | Günlüğe denetim karakterli ad yazılabiliyordu. | Düzeltildi: görünmeyen baytlar "?" olur. |
| 5 | Orta | Liste güncellemesi dosya dosya yazılıyordu; yarım kalırsa eski/yeni liste karışabilirdi. Uygulama güncellenince eski önbellek paketteki yeni listeyi gölgeliyordu. | Düzeltildi: `ListStore` dizin değişimi + kurtarma, uygulama sürümüne bağlı önbellek. |
| 6 | Düşük | Yavaş damlatan sunucu indirmeyi uzun süre tutabilirdi; eşzamanlı çift güncelleme mümkündü. | Düzeltildi: 90 sn toplam süre, tek seferde tek güncelleme. |

Bilinen sınırlar: Android tarafı (ListUpdater) bu ortamda derlenmedi; gerçek telefonda sızıntı/DPI testi yapılmadı; liste güncelleme `PUBLIC_KEY_B64` tanımlanana dek kapalıdır; tam sızma testi ve bağımsız denetim yapılmadı.


### 1.29.1 eki: ağ geçidi / DNS yolu

| # | Önem | Konu | Durum |
|---|------|------|-------|
| 7 | Yüksek | Ağ geçidi açıkken sabit DNS sunucusuna (8.8.8.8 vb.) soran uygulamaların sorguları seçilen şifreli DNS'i atlıyor, düz metin çıkıyordu. | Düzeltildi: genel hedefe giden UDP/53 sorguları seçilen DNS'e ve süzgece yönlenir; yerel hedefler hariç. |
| 8 | Orta | TCP/53 DNS soruları ve sabit sunucudan gelen CNAME cevapları süzülmüyordu (yalnızca UDP sorgusu adı). | Düzeltildi: TCP/53 soruları geçitte cevaplanır/engellenir; UDP cevaplarında CNAME denetimi. |
| 9 | Orta | Ağ geçidi yolunda biçimi bozuk sorgular (çoklu soru, işaretçi) yeni FORMERR korumasından geçiyordu. | Düzeltildi: aynı kontrol ağ geçidinde de var. |
| 10 | Orta | Sınıfı IN olmayan soruyla engelli ad üst sunucuya iletilebiliyordu (cevap kurulamayınca "geçir"). | Düzeltildi: kurulamazsa REFUSED; engelli ad asla iletilmez (DNS, ağ geçidi, CNAME denetimi). |
| 11 | Orta | ECH kullanan sitelerde gerçek ad (SNI) görünmediğinden Reklam+ engeli atlanıyordu. | Hafifletildi: Reklam+ açıkken HTTPS/SVCB kaydı verilmez. ECH'i sunucu anahtarı olmadan kullanan uygulamalar (nadir) hâlâ görünmez. |
| 12 | Düşük | Kök ad sorgusu FORMERR alıyordu; HTTP gövdesindeki "Host:" satırı Host sayılabiliyordu. | Düzeltildi. |

Bilinen sınırlar: DoH'u kendi alan adıyla (bilinen listede olmayan) kullanan uygulamalar ve ECH anahtarını DNS dışından alan uygulamalar görünmez. DNS kapalı (yalnızca modül) kipinde sabit DNS yönlendirilemez (seçilmiş bir DNS yoktur). Android tarafındaki değişiklik (DnsVpnService) bu ortamda derlenmedi.


## Ek inceleme (1.30.0): şifreli DNS, ODoH, kriptografi, ağ geçidi kaynakları

Yöntem: Hpke, Odoh*, MiniHttps, SecureForwarder, DnsForwarder, DnsCache, ListUpdate, Dpi, Gateway ve VPN kurulumu baştan okundu;
her bulguya test yazıldı ve testin düzeltme olmadan başarısız olduğu doğrulandı (soket bağlama ve bellek tavanı testlerinde).
Dinamik test, gerçek ağ, cihaz ve bağımsız sızma testi YAPILMADI.

| # | Önem | Konu | Durum |
|---|------|------|-------|
| 1 | Orta | Ağ geçidi kuyrukları yalnızca bağlantı başına sınırlıydı (96 + 128 KB × 1500 bağlantı ≈ 330 MB). Okumayan bir uygulama ya da hızlı basan sunucular servisi bellekten öldürebilirdi. | Düzeltildi: ortak 24 MB tavan (`MemBudget`), TCP geri basıncı; tavan boşalınca duran akışlar zamanlayıcıyla yeniden açılır. Uçtan uca test. |
| 2 | Orta | İstemci penceresi dolunca `onSegment` erken dönüyor, sunucudan gelmiş veri istemciye gitmiyordu; iki yön birbirini bekleyip bağlantı kilitlenebiliyordu. | Düzeltildi: erken dönüşte de veri akıtılır; zamanlayıcı bekleyen veriyi yoklar. |
| 3 | Orta | Reklam+ yalnızca Host başlığına bakıyordu; mutlak biçimli istek satırı (`GET http://engelli/…`, sunucunun asıl kullandığı ad) ve CONNECT hedefi denetlenmiyordu. | Düzeltildi: ikisinden biri engelliyse bağlantı kesilir. Uçtan uca test. |
| 4 | Düşük | Düz DNS: bekleyen kimlikler iki soket arasında ortaktı; cevabın hangi sokete geldiği denetlenmiyordu (sahte cevap için tahmin alanı ½). | Düzeltildi: cevap sorunun gönderildiği soketten gelmeli. |
| 5 | Düşük | HTTP ayrıştırıcıları gevşekti: katlanmış başlık, boşluklu ad, "gzip, chunked", parça sonu CRLF denetimi yoktu; 1xx ara cevap bağlantıyı bozuyordu. Kalıcı bağlantıda çerçeve kayması mümkündü (soru denetimi yakalardı). | Düzeltildi: ortak `HttpRules`, iki ayrıştırıcı aynı kuralları kullanır. |
| 6 | Düşük | ODoH cevap anahtarı/nonce doğrulama hatasında silinmiyordu; sorgunun düz metni bellekte kalıyordu; sorgu nesnesi ikinci kez açılabiliyordu. | Düzeltildi: tek kullanım + `finally` ile silme. |
| 7 | Bilgi | HPKE/HKDF ara sırları silinmiyordu (JVM'de çöp toplayıcı kopyaları yüzünden tam silme garanti edilemez; savunma derinliği). | Düzeltildi. |
| 8 | Bilgi | Liste manifestinde ikinci "surum=" satırı son değeri kullanıyordu; anahtar eğrisi denetlenmiyordu. | Düzeltildi. |

Temiz çıkanlar: HPKE nonce/sayaç yönetimi, X25519 sıfır sonucu reddi, ODoH dolgu ve yapı denetimi, yapılandırma alımının hız
sınırı, DoT/DoH cevap eşleştirme (kimlik + soru + QR + OPCODE), TLS 1.2+ zorunluluğu ve ana makine adı doğrulaması, kullanıcı
sertifika yetkililerine güvenilmemesi (network_security_config), önbellek sınırları, TCP/53 yerel katman sınırları, VPN'de
`allowBypass` kullanılmaması, dışa açık bileşenler.

Bilinen sınırlar (değiştirilmedi): ClientHello birden çok TLS kaydına bölünürse SNI okunamaz (uygulamanın kendisi atlatmak isterse);
aynı HTTP bağlantısındaki sonraki istekler denetlenmez; ODoH hedefi "Snowstorm" Cloudflare altyapısında barınıyor (röle Fastly,
yani yine bağımsız), yapılandırma alımında hedef IP'nizi görür; JVM'de bellek silme en iyi çabadır.


## Ek inceleme (1.38.1): QUIC/TLS istemcisi, sahte paket kodu, ağ geçidi sayaçları

Yöntem: 1.35–1.38'de eklenen kod (QuicClient, QuicTls, QuicInitial, Http3, FakeSender, Gateway'in UDP/QUIC/sahte-ClientHello yolları,
SecureForwarder'ın QUIC kolu) baştan okundu; her bulgu için saldırgan sunucu davranışı taklit eden bir test yazıldı
(`selftest/QuicTests.kt`, "sahte paketlere karşı sertlik"; python gerekmez). Dinamik test, gerçek ağ, cihaz ve bağımsız sızma testi YAPILMADI.

| # | Önem | Konu | Durum |
|---|------|------|-------|
| 1 | Yüksek | Initial/Handshake paketlerinde her çerçeve türü kabul ediliyordu ve Initial okuma anahtarı el sıkışmadan sonra da tutuluyordu. Initial anahtarı herkesçe türetilebildiğinden yol üstü bir saldırgan (DPI cihazı) Initial paketine koyduğu sahte STREAM çerçevesiyle DoQ/DoH3 cevabını değiştirebilirdi. | Düzeltildi: bu seviyelerde yalnızca PADDING/PING/ACK/CRYPTO/taşıma CONNECTION_CLOSE; Initial anahtarları ilk Handshake paketinde, Handshake anahtarları HANDSHAKE_DONE'da atılır. |
| 2 | Orta | Doğrulanmamış sürüm pazarlığı ya da Retry paketi bağlantıyı düşürüyordu (yol dışı saldırgan, port tahminiyle hizmet reddi). | Düzeltildi: sürüm pazarlığı yalnızca kimliklerimizi yansıtıyor ve v1'i listelemiyorsa; Retry yalnızca bütünlük etiketi (RFC 9001 §5.8) doğruysa hata sayılır, aksi halde yok sayılır. |
| 3 | Orta | Sıra dışı CRYPTO/STREAM tamponları uzak ofsete göre sınırsız büyüyebiliyordu (bellek şişirme). | Düzeltildi: CRYPTO ≤ 128 KB ve ≤ 64 parça; akış verisi ≤ 128 KB. |
| 4 | Düşük | Çerçeve uzunlukları `toInt()` ile daraltılıyordu: NEW_TOKEN'da negatif uzunluk kilit altında sonsuz döngü, ACK aralığı başına 100 bin yineleme (CPU). | Düzeltildi: uzunluklar ≤ 1 milyon, ACK yalnızca gönderilmiş paketler üzerinde gezer. |
| 5 | Düşük | Sahte datagram "son alım" saatini ilerletip bağlantıyı canlı tutuyordu; kısa başlıkta hedef kimliği, uzun başlıkta sunucu kimliği değişimi denetlenmiyordu; pencere altı eski paket numarası yeniden işlenebiliyordu. | Düzeltildi. |
| 6 | Düşük | Joker sertifika adı tek etiketli alanlarda (`*.com`) eşleşiyordu; ServerHello'da sıkıştırma ve legacy_version denetlenmiyordu. | Düzeltildi. |
| 7 | Düşük | `FakeSender` sayfa dosyası son bağlantıların GERÇEK ClientHello'larını (gezilen alan adları) uygulama önbelleğinde diskte bırakıyordu. | Düzeltildi: tünel kapanınca sıfırlanıp silinir. |
| 8 | Orta | Ağ geçidi UDP akış sayacı, açılamayan her akışta (korunamayan soket, ulaşılamayan ağ) eksiye kayıyordu; sayaç eksiye kayınca 400 akış sınırı işlevsiz kalıyordu. TCP `forget` aynı akış için iki kez çağrılırsa aynı kayma olabilirdi. | Düzeltildi: sayaç yalnızca gerçekten tabloya girip çıkan akışta oynar. |
| 9 | Bilgi | QUIC sertifika/imza hataları "güven hatası" sayılmıyordu (MITM uyarı sayacı artmıyordu). | Düzeltildi. |

Temiz çıkanlar: sertifika zinciri + SAN ad denetimi + CertificateVerify + Finished, x25519 sıfır sonucu reddi, `original_destination_connection_id` /
`initial_source_connection_id` doğrulaması, `VpnService.protect` başarısızsa UDP yuvasının açılmaması, dışa açık bileşenler ve ağ güvenliği yapılandırması.

Bilinen sınırlar (değiştirilmedi): Retry, 0-RTT, anahtar güncelleme ve bağlantı taşıma desteklenmez; QUIC hızlı yolunda sahte Initial düşük TTL'e
güvenir (sunucu 8 sekmeden yakınsa sahte paket sunucuya varıp QUIC'i bozabilir; özellik varsayılan kapalı, tarayıcı TCP'ye düşer).

## Ek inceleme (1.38.2): ikinci tur

Yöntem: kullanıcı "hâlâ çok açık ve hata var" dediği hâlde somut belirti vermediği için tüm uygulama yeniden tarandı (QUIC yığını, ağ geçidi TCP durum makinesi, receiver'lar, manifest, liste güncelleme, önbellek). Her şüphe için ya saldırgan davranışı taklit eden bir test ya da rastgele girdi (fuzz) testi yazıldı.

- Düzeltilen: UDP engelli ağda QUIC'in her bağlanışta ~10 sn beklemesi (hizmet kesintisi gibi görünürdü); sunucu akış sınırı dolunca yanlışlıkla "sunucu hatası" sayılması; boşta bağlantının gereksiz uyanması; TLS ileti ayrıştırıcısında beklenmeyen istisna.
- Fuzz sonucu: kurulu TCP bağlantısına bozuk segmentler, yetkili rastgele QUIC çerçeveleri, rastgele datagram ve TLS iletileri çökme veya takılma üretmedi.
- Değişiklik gerektirmeyen: AndroidManifest ve ağ güvenliği yapılandırması (dışa açık bileşenler korumalı), BootReceiver, ActionReceiver, intent işleme, ListUpdate/ListStore, DnsCache, CustomDns, CrashLog, CutWatch, UdpDecoy.
- Sınır: bu inceleme cihazda, gerçek operatörde ve Gradle ile yapılmadı; sızma testi yerine kod okuma + otomatik testtir.

## Ek inceleme (oto-koruma 15): DNS sızıntı kalkanı ve arayüz tutarlılığı

Yöntem: kaynak okuma, manifest/alıcı/pano/yönlendirme denetimi, uzun rastgele kullanım testi. Dinamik test ve gerçek ağ YAPILMADI; Android tarafı bu ortamda derlenmedi.

| # | Önem | Konu | Durum |
|---|------|------|-------|
| 1 | Orta | DNS modunda (ağ geçidi kapalı) sabit bir sunucuya doğrudan soran uygulama (8.8.8.8:53), DoT (853) ya da DoH bağlantısı tünelin dışından çıkıyordu. | Düzeltildi: "DoH koruması" açıkken bilinen herkese açık çözümleyici adresleri tünele alınır (`Dpi.knownResolverAddresses`, `addResolverRoutes`). Düz DNS şifreli DNS'e gider, DoH/DoT reddedilir. Yalnızca bu adresler yönlendirilir. |
| 2 | Düşük | "Kilit ekranında gizle" açıkken son uygulamalar önizlemesinde içerik görünüyordu (Android 13+). | Düzeltildi: `setRecentsScreenshotEnabled`. |
| 3 | Düşük | Yalnızca DPI/Reklam+ açıkken widget "Kapalı" gösteriyor, durum yoklaması durduğu için sayaçlar donuyordu. | Düzeltildi (`VpnUi.running`). |
| 4 | Düşük | Kişisel sürümde paylaş/puanla bağlantıları var olmayan mağaza sayfasına gidiyordu. | Kişisel sürümde gizlendi. |

Bilinen sınır: kalkan yalnızca bilinen çözümleyici adreslerini kapsar. Bilinmeyen bir sunucuya (kişisel DoT/DoH) giden trafik DNS modunda yine tünelden geçmez; tam kapsam için ağ geçidi modu (DPI ya da Reklam+) gerekir.

Ek bulgular (aynı tur):
- **Yüksek (APK'yı mağaza dışında dağıtırken) — 5:** `apk.yml` debug APK üretir ve bu APK herkese açık bir anahtarla imzalıdır: aynı anahtarla imzalı sahte bir APK, kullanıcının telefonunda "güncelleme" gibi kurulabilir. Durum: Çözüm: `anahtar-uret.yml` ile kendi gizli anahtarın üretilir, `release.yml` artık imzalı yayın APK'sı da üretir. itch.io gibi yerlerde yalnızca bu APK dağıtılmalıdır.
- **Orta — 6:** DPI atlatma ağdaki TLS el sıkışmalarını bozarsa (bağlantı açılıyor ama sayfa yüklenmiyor) güvenlik vanası devreye girmiyordu; vana yalnızca "hiçbir bağlantı açılmıyor" durumuna bakıyordu. Durum: Düzeltildi: DPI uygulanan el sıkışmaların tamamı başarısızsa yalnızca DPI kapatılır, 5/15/45/60 dk ile kendiliğinden yeniden denenir.
