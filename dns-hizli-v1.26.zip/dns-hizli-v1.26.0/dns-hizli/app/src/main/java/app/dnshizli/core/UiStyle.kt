package app.dnshizli.core

/**
 * Arayüzün genel iskeleti (malzeme, şekil, hareket). Renk teması ([AeroTheme]) bundan bağımsızdır:
 * her stil seçili renk temasıyla çalışır.
 *  - AQUA: ilk tasarım (camsı, parlak, kabarcıklı); olduğu gibi korunur.
 *  - AERO: gerçek Frutiger Aero: gökyüzü, yeşil çimen tepeler, cam yüzeyler, su damlaları.
 *  - METRO: şehir, müzik ve gençlik vektör sanatı zemini; düğmeler temel cam çizim.
 *  - ECO: doğa: yapraklar, organik yuvarlak biçimler, yumuşak yeşil ışık.
 *  - Y2K: holografik pastel, krom kalpler, baloncuklar, piksel pencereler, canlı yaylı hareket.
 *  - AURORA: turkuaz-yeşil-sarı ışık geçişi, parlak ışık hüzmesi, saydam tel kafes dalgalar.
 *  - LIQUID: Liquid Glass: bulanık mavi-mor ışık lekeleri, kalın yansımalı saydam cam, parlak kenar ışığı, kırılan ışık.
 *  - DEEP: Deep / DeepSeek: modern, sade, minimalist koyu füme/lacivert cam, elektrik mavisi neon hatlar ve hassas tipografi.
 */
enum class UiStyle(val id: String, val label: String) {
    AQUA("aqua", "Aqua"), AERO("aero", "Aero"), METRO("metro", "Metro"), ECO("eco", "Eco"),
    Y2K("y2k", "Y2K"), AURORA("aurora", "Aurora"), LIQUID("liquid", "Liquid Glass"),
    DEEP("deep", "Deep");

    companion object {
        fun byId(id: String?): UiStyle? = values().firstOrNull { it.id == id }
    }
}

/** Süs parçacıklarının hareketi: yükselen, düşen ya da yerinde parlayıp sönen; NONE: hiç yok. */
enum class ParticleMode { NONE, RISE, FALL, TWINKLE }

/** Sayfa geçişi biçimi. */
enum class PageMotion { SLIDE, FADE_SCALE, TURNSTILE, POP }

/** Dokunma ve bağlanma kutlaması efektinin biçimi (stile özgü). */
enum class FxKind { NONE, RING, DROP, SLICE, LEAF, SPARK, SWEEP, GLASS, DEEP }

/**
 * Bir stilin hareket kişiliği. [stagger]: liste satırlarının girişte art arda gecikmesi (sn, 0 = hepsi birlikte).
 * [spring]: anahtar, çip ve basma hareketlerinde geri sekme payı (0 = sönümlü, 1 = belirgin).
 * Yeni motor alanları: [depth] basma derinliği çarpanı, [tilt] dokunulan noktaya doğru eğilme (derece),
 * [down]/[up] basma ve bırakma yayları, [toggle] anahtar ve çip yayı, [fx] dokunma/kutlama efekti.
 */
class StyleMotion(
    val page: PageMotion,
    val pageSec: Float,
    val stagger: Float,
    val spring: Float,
    val depth: Float = 1f,
    val tilt: Float = 0f,
    val down: SpringSpec = SpringSpec.DOWN,
    val up: SpringSpec = SpringSpec.SNAP,
    val toggle: SpringSpec = SpringSpec.SNAP,
    val fx: FxKind = FxKind.RING,
) {
    companion object {
        val AQUA = StyleMotion(PageMotion.SLIDE, 0.34f, 0f, 0f)
    }
}

/** Stile göre çizici üretir. */
object ArtFactory {
    fun create(style: UiStyle, theme: AeroTheme, glass: Float): AeroArt = when (style) {
        UiStyle.AQUA -> AeroArt(theme, glass)
        UiStyle.AERO -> AeroSkyArt(theme, glass)
        UiStyle.METRO -> MetroArt(theme, glass)
        UiStyle.ECO -> EcoArt(theme, glass)
        UiStyle.Y2K -> Y2kArt(theme, glass)
        UiStyle.AURORA -> AuroraArt(theme, glass)
        UiStyle.LIQUID -> LiquidArt(theme, glass)
        UiStyle.DEEP -> DeepArt(theme, glass)
    }
}
