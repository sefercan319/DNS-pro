package app.dnshizli.ui

import app.dnshizli.core.*

/** Sıvı ve dalga önizlemesi: seçili şekil, renk ve dalga animasyonuyla çalışan canlı küre. */
class LiquidPreview(private val model: AppModel) : Node() {
    override fun layout(env: Env, maxW: Float) { w = maxW; h = 170f }
    override fun tick(dt: Float, env: Env): Boolean = env.ambient
    override fun draw(g: Gfx, env: Env) {
        val art = env.art
        art.orbShape = model.orbShapeFor(model.shownThemeId)
        art.liquidColor = model.liquidColorArgb
        art.liquidWave = model.settings.liquidWave
        art.liquidTintAmt = 0f
        art.orb(g, w / 2f, h / 2f - 4f, 52f, 0.66f, env.time * 1.5f, 0.5f, 0f, 0f)
    }
    override fun a11y(): A11y? = null
}

/** 10 özgün dalga animasyonu seçimi çipleri (1 klasik + 9 yeni mod). */
class LiquidWaveGrid(private val model: AppModel) : Node() {
    private val chips = LiquidWave.values().map { wave ->
        Chip(Strings.waveName(wave)) { model.setLiquidWave(wave) }
    }

    init { for (c in chips) add(c) }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        val pad = 12f
        var curX = pad
        var curY = pad
        val rowH = M.CHIP_H + 8f
        for (c in chips) {
            c.layout(env, maxW - pad * 2f)
            if (curX + c.w > maxW - pad && curX > pad) {
                curX = pad
                curY += rowH
            }
            c.x = curX
            c.y = curY
            curX += c.w + 8f
        }
        h = curY + M.CHIP_H + pad
        sync(env, false)
    }

    private fun sync(env: Env, animate: Boolean) {
        val cur = model.settings.liquidWave
        for ((i, wave) in LiquidWave.values().withIndex()) {
            chips[i].setSelected(wave == cur, env, animate)
        }
    }

    private var seen = -1
    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version) { seen = model.version; sync(env, true) }
        return tickKids(dt, env)
    }

    override fun draw(g: Gfx, env: Env) = drawKids(g, env)
}

/** Tek bir sıvı rengi örneği; [argb] 0 ise temanın kendi rengi. */
class ColorSwatch(private val argb: Int, private val name: String, private val onPick: () -> Unit) : PressNode() {
    private val sel = Anim(0f)
    var radius = 17f
    private var slop = 4f
    private var fill: Fill? = null
    private var fillR = -1f
    override fun layout(env: Env, maxW: Float) {
        w = radius * 2f + 10f; h = w
        slop = maxOf(4f, (M.MIN_TAP - w) / 2f)
    }
    override val hitSlop: Float get() = slop
    fun setSelected(v: Boolean, env: Env?, animate: Boolean) {
        val tgt = if (v) 1f else 0f
        if (sel.target == tgt && !sel.active) return
        sel.go(tgt, if (animate && env != null) env.dur(0.25f) else 0f)
    }
    val isSelected: Boolean get() = sel.target > 0.5f
    override fun tick(dt: Float, env: Env): Boolean = sel.step(dt) or super.tick(dt, env)
    override fun draw(g: Gfx, env: Env) {
        val t = env.theme
        val c = if (argb == 0) t.accent else argb
        if (fill == null || fillR != radius || argb == 0) {
            val light = if (argb == 0) t.accentLight else Rgb.lerp(c, Rgb.WHITE, 0.40f)
            val deep = if (argb == 0) t.accentDeep else Rgb.lerp(c, 0xFF000000.toInt(), 0.40f)
            fill = Fill.linear(0f, -radius, 0f, radius, light, c, deep, 0.45f); fillR = radius
        }
        g.save()
        pressScale(g, w / 2f, h / 2f, 0.1f)
        g.translate(w / 2f, h / 2f)
        g.paint(Rgb.alpha(t.shadow, if (t.dark) 0.40f else 0.20f)); g.circle(0f, 1.8f, radius + 0.8f)
        g.paint(fill!!); g.circle(0f, 0f, radius)
        g.paint(Rgb.alpha(Rgb.WHITE, 0.50f)); g.oval(-radius * 0.62f, -radius * 0.86f, radius * 0.18f, -radius * 0.34f)
        g.strokeWidth(1.4f); g.paint(Rgb.alpha(Rgb.WHITE, 0.90f)); g.strokeCircle(0f, 0f, radius - 0.7f)
        val s = sel.value
        if (s > 0.001f) { g.save(); g.alpha(s); g.strokeWidth(2.4f); g.paint(t.link); g.strokeCircle(0f, 0f, radius + 4.2f); g.restore() }
        g.restore()
    }
    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) { super.onUp(lx, ly, tap, env); if (tap) { env.tap(false, app.dnshizli.core.Sfx.SELECT); onPick() } }
    override fun a11y(): A11y = A11y(name, Role.BUTTON, checked = isSelected)
}

/** "Temaya göre" çipi ve 50 renk örneği. */
class LiquidColorGrid(private val model: AppModel) : Node() {
    private val auto = Chip(Strings.LIQUID_THEME) { model.setLiquidColor("") }
    private val swatches = LiquidColors.PALETTE.mapIndexed { i, rgb ->
        ColorSwatch((0xFF shl 24) or rgb, Strings.liquidColorN(i + 1)) { model.setLiquidColor(LiquidColors.id(rgb)) }
    }

    init { add(auto); for (s in swatches) add(s) }

    override fun layout(env: Env, maxW: Float) {
        w = maxW
        auto.layout(env, maxW); auto.x = 16f; auto.y = 12f
        val n = swatches.size
        val fit = maxOf(4, ((w - 32f) / 46f).toInt())
        val rows = (n + fit - 1) / fit
        val perRow = (n + rows - 1) / rows
        val spacing = (w - 32f) / perRow
        val r = minOf(17f, spacing / 2f - 5f)
        val rowH = r * 2f + 10f + 4f
        val top = 12f + M.CHIP_H + 10f
        for ((i, b) in swatches.withIndex()) {
            b.radius = r
            b.layout(env, maxW)
            b.x = 16f + spacing * (i % perRow + 0.5f) - b.w / 2f
            b.y = top + (i / perRow) * rowH
        }
        h = top + rows * rowH + 10f
        sync(env, false)
    }

    private fun sync(env: Env, animate: Boolean) {
        val cur = LiquidColors.indexOf(model.settings.liquidColor)
        auto.setSelected(cur < 0, env, animate)
        for ((i, b) in swatches.withIndex()) b.setSelected(i == cur, env, animate)
    }

    private var seen = -1
    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version) { seen = model.version; sync(env, true) }
        return tickKids(dt, env)
    }

    override fun draw(g: Gfx, env: Env) = drawKids(g, env)
}

/** Sıvı ve Dalga sayfası: canlı önizleme, 10 dalga animasyonu ve 50 renk seçeneği. */
class LiquidColorPage(model: AppModel, nav: Nav) : ScrollPage(Strings.LIQUID_COLOR, true, nav) {
    init {
        col.add(LiquidPreview(model))
        col.add(SettingsCard().also {
            it.add(Label(Strings.LIQUID_WAVE, 14f, ink = Ink.TITLE, maxLines = 1))
            it.add(LiquidWaveGrid(model))
        })
        col.add(SettingsCard().also {
            it.add(Label(Strings.COLOR_WORD, 14f, ink = Ink.TITLE, maxLines = 1))
            it.add(LiquidColorGrid(model))
        })
        col.add(Label(Strings.LIQUID_NOTE, 13f, ink = Ink.SOFT, maxLines = 0))
        finish()
    }
}
