package app.dnshizli.core

import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Deep (DeepSeek esintili stil): Modern, sade ve minimalist koyu füme/gece mavisi yüzeyler,
 * elektrik mavisi hassas neon kenarlar, kristal netliğinde tipografi ve dengeli yay hareketleri.
 */
class DeepArt(theme: AeroTheme, glass: Float) : AeroArt(theme, glass) {
    override val style: UiStyle get() = UiStyle.DEEP
    override val particleMode: ParticleMode get() = ParticleMode.NONE
    override val liveSky: Boolean get() = true
    override val motion: StyleMotion = StyleMotion(
        page = PageMotion.FADE_SCALE,
        pageSec = 0.34f,
        stagger = 0.025f,
        spring = 0.40f,
        depth = 0.82f,
        tilt = 1.8f,
        down = SpringSpec.DOWN,
        up = SpringSpec.SNAP,
        toggle = SpringSpec.SNAP,
        fx = FxKind.DEEP,
    )

    // DeepSeek özel renk paleti
    private val deepSlate = 0xFF0B0F19.toInt()
    private val deepNavy = 0xFF111827.toInt()
    private val electricBlue = 0xFF2563EB.toInt()
    private val cyanGlow = 0xFF38BDF8.toInt()
    private val surfaceCard = 0xFF141C2E.toInt()
    private val borderStroke = 0xFF1E293B.toInt()

    private class Scene(val w: Float, val h: Float, art: DeepArt) {
        private val dk = art.dark
        private val th = art.theme
        val base = if (dk)
            Fill.linear(0f, 0f, 0f, h, 0xFF080C14.toInt(), 0xFF0D1322.toInt(), 0xFF121B2F.toInt(), 0.6f)
        else
            Fill.linear(0f, 0f, 0f, h, 0xFFEDF2F7.toInt(), 0xFFE2E8F0.toInt(), 0xFFCBD5E1.toInt(), 0.6f)

        val neuralAura = Fill.radial(
            w * 0.5f, h * 0.28f, w * 0.85f,
            Rgb.alpha(art.electricBlue, if (dk) 0.32f else 0.18f),
            Rgb.alpha(art.electricBlue, 0f)
        )
        val ambientBottom = Fill.radial(
            w * 0.5f, h * 0.95f, w * 0.9f,
            Rgb.alpha(art.cyanGlow, if (dk) 0.16f else 0.10f),
            Rgb.alpha(art.cyanGlow, 0f)
        )
        val subtleGrid = Fill.linear(
            0f, 0f, 0f, h,
            Rgb.alpha(Rgb.WHITE, if (dk) 0.04f else 0.10f),
            Rgb.alpha(Rgb.WHITE, 0f)
        )
    }

    private var scene: Scene? = null

    private fun scene(w: Float, h: Float): Scene {
        var s = scene
        if (s == null || s.w != w || s.h != h) { s = Scene(w, h, this); scene = s }
        return s
    }

    override fun sky(g: Gfx, w: Float, h: Float) = skyFrame(g, w, h, false, 0f)

    override fun skyFrame(g: Gfx, w: Float, h: Float, live: Boolean, time: Float) {
        val s = scene(w, h)
        val t = if (live) time else 0f
        g.paint(s.base); g.rect(0f, 0f, w, h)

        // Merkezde canlı nefes alan elektrik mavisi aura
        val auraPulse = 1f + 0.06f * sin(t * 0.8f)
        g.save()
        g.translate(w * 0.5f, h * 0.28f)
        g.scale(auraPulse, auraPulse)
        g.translate(-w * 0.5f, -h * 0.28f)
        g.paint(s.neuralAura); g.rect(0f, 0f, w, h)
        g.restore()

        g.paint(s.ambientBottom); g.rect(0f, 0f, w, h)
        g.paint(s.subtleGrid); g.rect(0f, 0f, w, h)
    }

    override fun bubble(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float) {}
    override fun particle(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float, phase: Float) {}

    /** Modern minimalist kart: Hassas kenar çizgisi, koyu füme mat cam yüzey, seçiliyken elektrik mavisi ışıma. */
    override fun card(g: Gfx, l: Float, t: Float, r: Float, b: Float, rad: Float, selected: Float, press: Float, strong: Float, shadow: Float) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        val rr = min(rad, min(w, h) / 2f)
        g.save(); g.translate(l, t)

        // Derin gölge
        if (shadow > 0f) {
            g.paint(Rgb.alpha(0xFF000511.toInt(), (if (dark) 0.50f else 0.18f) * shadow))
            g.roundRect(0f, 4f, w, h + 4f, rr)
        }

        // Seçim aurası
        if (selected > 0.01f) {
            g.paint(Rgb.alpha(electricBlue, 0.28f * selected))
            g.roundRect(-2.5f, -2.5f, w + 2.5f, h + 2.5f, rr + 2.5f)
        }

        // Gövde mat füme yüzey
        val bodyColor = if (dark) {
            Rgb.alpha(surfaceCard, (0.82f + 0.12f * strong + 0.06f * press).coerceIn(0f, 1f))
        } else {
            Rgb.alpha(Rgb.WHITE, (0.92f + 0.08f * strong).coerceIn(0f, 1f))
        }
        g.paint(bodyColor); g.roundRect(0f, 0f, w, h, rr)

        // Tema vurgusu hafif katkı
        if (selected > 0.01f || press > 0.01f) {
            g.paint(Rgb.alpha(electricBlue, 0.08f * selected + 0.08f * press))
            g.roundRect(0f, 0f, w, h, rr)
        }

        // Hassas 1dp kenar çizgisi
        val strokeColor = if (selected > 0.01f) {
            Rgb.lerp(if (dark) borderStroke else 0xFFCBD5E1.toInt(), cyanGlow, selected)
        } else {
            if (dark) Rgb.alpha(borderStroke, 0.90f) else Rgb.alpha(0xFFCBD5E1.toInt(), 0.90f)
        }
        g.strokeWidth(1.2f)
        g.paint(strokeColor)
        g.strokeRoundRect(0.6f, 0.6f, w - 0.6f, h - 0.6f, max(0f, rr - 0.6f))

        // Üst kenarda çok zarif modern mikro-parıltı
        if (dark) {
            g.paint(Rgb.alpha(Rgb.WHITE, 0.12f))
            g.roundRect(rr * 0.8f, 1.0f, w - rr * 0.8f, 2.2f, 1.0f)
        }

        g.restore()
    }

    /** Modern minimalist hap anahtar (DeepSeek stili düzgün elektrik mavisi geçiş). */
    override fun switch(g: Gfx, l: Float, t: Float, w: Float, h: Float, on: Float, press: Float) {
        val k = on.coerceIn(0f, 1f)
        g.save(); g.translate(l, t)

        // Açıkken hafif neon ışıma
        if (k > 0.01f) {
            g.paint(Rgb.alpha(electricBlue, 0.35f * k))
            g.roundRect(-2.5f, -2.5f, w + 2.5f, h + 2.5f, h / 2f + 2.5f)
        }

        // Yuva rengi
        val offBg = if (dark) 0xFF1E293B.toInt() else 0xFFCBD5E1.toInt()
        val onBg = electricBlue
        g.paint(Rgb.lerp(offBg, onBg, k)); g.roundRect(0f, 0f, w, h, h / 2f)

        // İnce yuva kenarlığı
        g.strokeWidth(1.1f)
        g.paint(Rgb.alpha(if (dark) 0xFF334155.toInt() else 0xFF94A3B8.toInt(), 0.6f * (1f - k)))
        g.strokeRoundRect(0.5f, 0.5f, w - 0.5f, h - 0.5f, h / 2f - 0.5f)

        // Tutamaç (Thumb): Net beyaz, basınca hafif genişleyen
        val cx = h / 2f + (w - h) * k
        val rad = h / 2f - 2.0f + press * 1.2f
        g.paint(Rgb.alpha(0xFF000511.toInt(), 0.35f)); g.circle(cx, h / 2f + 1.2f, rad + 0.5f) // küçük gölge
        g.paint(Rgb.WHITE); g.circle(cx, h / 2f, rad)
        if (k > 0.1f) {
            g.paint(Rgb.alpha(cyanGlow, 0.45f * k)); g.circle(cx, h / 2f, rad * 0.45f) // merkez mavi odak noktası
        }
        g.restore()
    }
}
