package app.dnshizli.core

/** Bahasa Indonesia. */
object TxId : Tx() {
    override val lang = Lang.ID

    override val decimalSep = ','
    override val thousand = " rb"
    override val million = " jt"
    override fun percent(n: Int) = "$n%"
    override val dayU = "hr"
    override val hourU = "jam"
    override val minU = "mnt"
    override val secU = "dtk"
    override val justNow = "baru saja"
    override fun ago(span: String) = "$span lalu"

    override val OFF = "Tidak terhubung"
    override val CONNECTING = "Menghubungkan…"
    override val ON = "Terhubung"
    override val ERROR = "Gagal terhubung"
    override val PAUSED = "Dijeda"
    override val HINT_OFF = "Ketuk bola untuk terhubung"
    override val HINT_CONNECTING = "Mungkin perlu beberapa detik"
    override val HINT_ERROR = "Ketuk untuk mencoba lagi"
    override val HINT_PAUSED = "Ketuk untuk lanjut sekarang"
    override val ERR_DEFAULT = "Koneksi gagal"
    override fun selected(name: String) = "$name dipilih"
    override fun pausedUntil(time: String) = "Lanjut pukul $time"
    override fun blockedShort(n: String) = "$n diblokir"
    override fun queriesShort(n: String) = "$n kueri"
    override fun cacheShort(pct: String) = "$pct cache"

    override val SERVERS = "Server"
    override val FILTER_ALL = "Semua"
    override val FILTER_FAV = "Favorit"
    override val FILTER_RECENT = "Terakhir"
    override val EMPTY_FAV = "Belum ada favorit. Ketuk bintang pada server."
    override val EMPTY_RECENT = "Kamu belum pernah terhubung ke server."
    override val EMPTY_FILTER = "Tidak ada server di kategori ini."
    override val MEASURE = "Ukur kecepatan"
    override val MEASURING = "Mengukur…"
    override val SORT = "Urutan"
    override val PULL_TO_MEASURE = "Tarik untuk mengukur kecepatan"
    override val RELEASE_TO_MEASURE = "Lepas untuk mengukur"
    override fun serversCount(n: Int) = "$n server"
    override fun showAllServers(n: Int) = "Tampilkan semua ($n)"
    override val SHOW_LESS = "Tampilkan lebih sedikit"
    override val TAG_FAST = "Cepat"
    override val TAG_PRIVACY = "Privasi"
    override val TAG_ADS = "Blokir iklan"
    override val TAG_FAMILY = "Keluarga"
    override val TAG_SECURITY = "Keamanan"
    override val VAR_OPEN = "Tanpa Filter"
    override val VAR_ADS = "Blokir Iklan"
    override val VAR_SECURITY = "Keamanan"
    override val VAR_FAMILY = "Keluarga"
    override val A11Y_CONNECTED = "terhubung"
    override val A11Y_ENCRYPTED = "terenkripsi"
    override fun favA11y(name: String) = "$name favorit"

    override val COPIED = "Disalin ke papan klip"
    override val DISCONNECTED = "Koneksi terputus"
    override val BACKUP = "Beralih ke server cadangan"
    override val NO_REPLY = "Tidak ada server yang merespons"
    override val MEASURE_FIRST = "Ukur kecepatan dulu"
    override val CONNECT = "Hubungkan"
    override val UNDO = "Urungkan"
    override fun fastest(name: String, ms: Int) = "Tercepat: $name · $ms ms"
    override fun switched(name: String) = "Beralih ke $name"
    override fun hiddenToast(name: String) = "$name disembunyikan"

    override val PRIMARY = "Utama"
    override val SECONDARY = "Sekunder"
    override val COPY = "Salin"
    override fun addressA11y(label: String, ip: String) = "Alamat $label: $ip"
    override val CONNECT_TO_THIS = "Hubungkan ke server ini"
    override val SWITCH_TO_THIS = "Beralih ke server ini"
    override val CONNECTED_NOW = "Sedang terhubung"
    override val ADD_FAV = "Tambah ke favorit"
    override val REMOVE_FAV = "Hapus dari favorit"
    override val MEASURE_THIS = "Ukur kecepatan"
    override val HIDE = "Sembunyikan dari daftar"
    override val UNHIDE = "Tampilkan di daftar"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Cek terakhir: tak ada respons · $ago" else "Cek terakhir: $ms ms · $ago"
    override val NEVER_MEASURED = "Belum diukur"
    override val ENC_SUPPORT = "DNS terenkripsi"
    override val ENC_NONE = "Tidak didukung"
    override val ENC_ONLY = "Hanya menerima koneksi terenkripsi"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Terbaik $best ms · median $median ms · hilang $lossPct%"
    override val HISTORY = "Riwayat kecepatan"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: $n pengukuran, tak ada respons" else "$HISTORY: $n pengukuran, median $median ms"

    override val QUICK_TITLE = "Ganti cepat"
    override val QUICK_FAVORITES = "Favorit"
    override val QUICK_RECENT = "Terakhir dipakai"
    override val PAUSE_FOR = "Jeda"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} jam" else "$n mnt"
    override val RESUME = "Lanjutkan"

    override val SETTINGS = "Pengaturan"
    override val MENU = "Menu"
    override val PERSONALIZE = "Personalisasi"
    override val PZ_BACKGROUND = "Latar"
    override val PZ_AUTO = "Tema otomatis"
    override val PZ_FEEL = "Kaca, teks, dan gerak"
    override val PZ_ACCESS = "Aksesibilitas dan daya"
    override val DNS_SETTINGS = "Pengaturan DNS"
    override val CONN_APPS = "Koneksi & aplikasi"
    override val STATS_HISTORY = "Statistik & riwayat"
    override val SEC_LOOK = "Tampilan"
    override val SEC_LIST = "Daftar server"
    override val SEC_DATA = "Data"
    override val ABOUT = "Tentang"
    override val LANGUAGE = "Bahasa"
    override val LANG_AUTO = "Otomatis (bahasa sistem)"
    override val THEME = "Tema"
    override val THEME_AUTO = "Otomatis"
    override val THEME_AUTO_NOTE = "Otomatis · ikuti mode terang/gelap sistem"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Rumput"
        "ocean" -> "Samudra"
        "sunset" -> "Senja"
        "lavender" -> "Lavender"
        "coral" -> "Koral"
        "mint" -> "Mint"
        "sakura" -> "Sakura"
        "honey" -> "Madu"
        "night" -> "Malam"
        "amoled" -> "Hitam (AMOLED)"
        "aurora" -> "Aurora"
        "dynamic" -> "Wallpaper"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Tema: $name"
    override val THEME_SCHEDULE = "Tema malam terjadwal"
    override val THEME_SCHEDULE_NOTE = "Di mode Otomatis, tema gelap pada jam pilihanmu"
    override val GLASS = "Transparansi kaca"
    override val BUBBLES = "Gelembung"
    override val STYLE = "Gaya"
    override val STYLE_NOTES = listOf(
        "Seperti kaca, mengilap, bergelembung: tampilan asli.",
        "Langit, rumput hijau, tetesan kaca, dan tombol gel.",
        "Kota, musik, dan anak muda: gedung pencakar langit, speaker, cincin, bintang, dan sinar.",
        "Alam bertemu teknologi: Bumi hijau, turbin angin, panel surya, dan daun.",
        "Pink dan ungu holografik, hati krom, gelembung, kilauan, dan jendela piksel.",
        "Cahaya toska, hijau, dan kuning, seberkas sinar terang, dan gelombang jaring transparan.",
        "Kaca biru-nila tembus pandang dengan cahaya tepi putih terang dan kilau bias.",
            "Kaca abu-abu gelap modern dan minimalis dengan aksen neon biru elektrik.",
    )
    override val WALLPAPER = "Foto latar"
    override val WP_OFF = "Tidak ada"
    override val WP_ON = "Foto"
    override val WP_PICK = "Pilih foto dari galeri"
    override val WP_PICK_NOTE = "Tetap di ponsel Anda, tidak pernah diunggah. Lapisan akan menguat otomatis bila perlu agar teks tetap terbaca."
    override val WP_PRESETS = "Gambar bawaan"
    override val WP_PRESETS_NOTE = "8 gambar bawaan aplikasi. Tanpa internet."
    override val WP_REMOVE = "Hapus foto"
    override val WP_DIM = "Kekuatan lapisan"
    override val WP_BLUR = "Blur"
    override val OPT_WP_BLUR = listOf("Mati", "Halus", "Kuat")
    override val WP_SAVED = "Latar diterapkan"
    override val WP_FAILED = "Foto tidak dapat dibuka"
    override val WP_REMOVED = "Latar dihapus"
    override val APP_ICON = "Ikon aplikasi"
    override val ICON_NOTES = listOf(
        "Bola kaca: ikon asli.",
        "Tetes kaca di atas langit dan rumput.",
        "Kota hijau limau-toska dengan sinar matahari dan tombol daya.",
        "Bumi hijau mengilap dengan daun yang bertunas.",
        "Hati krom mengilap di atas pink dan ungu holografik.",
        "Bola kaca di atas cahaya toska-kuning dan gelombang cahaya.",
        "Bola kaca buram dengan tepi terang di atas cahaya biru-nila.",
            "Perisai biru bercahaya minimalis di atas latar belakang biru malam.",
    )
    override val ICON_SET = "Ikon berubah setelah keluar"
    override val ICON_NOTE = "Jika pintasan di layar utama hilang, tambahkan aplikasinya lagi."
    override val ICON_FAILED = "Ikon tidak bisa diganti"
    override val HELP_WHY_TITLE = "Mengapa aplikasi ini?"
    override val HELP_WHY_BODY = "DNS Hızlı kecil dan sederhana, dibuat oleh satu orang tanpa perusahaan besar di belakangnya. Tanpa akun dan iklan: kamu memilih DNS, enkripsi, aplikasi mana yang memakainya, dan tampilannya."
    override val HELP_WHY_TAIL = "Mungkin tidak lebih baik dari para pesaing, tetapi aplikasi ini berfungsi dan layak dicoba."
    override val TROUBLE = "Pecahkan masalah"
    override val TROUBLE_RECHECK = "Periksa lagi"
    override val TROUBLE_ALL_OK = "Semuanya tampak baik. Jika tetap tidak terhubung, coba server lain."
    override val TROUBLE_SOME = "Hal yang perlu diperhatikan:"
    override val T_NET = "Internet"
    override val NET_OK = "terhubung."
    override val NET_BAD = "tidak ada atau terbatas. Periksa Wi-Fi atau data seluler."
    override val T_PERM = "Izin VPN"
    override val PERM_OK = "diberikan."
    override val PERM_BAD = "belum diberikan. Android akan menanyakan saat menyambung; izinkan."
    override val T_VPN = "VPN lain"
    override val VPN_OK = "tidak ada."
    override val VPN_BAD = "tampaknya aktif. Android hanya mengizinkan satu VPN dalam satu waktu; matikan."
    override val T_DNS = "DNS Pribadi Android"
    override val PDNS_OK = "mati atau otomatis, tidak masalah."
    override val PDNS_BAD = "dikunci ke satu server dan dapat melewati DNS aplikasi ini. Di Pengaturan > Jaringan > DNS Pribadi pilih Otomatis atau Mati."
    override val SEARCH = "Cari"
    override val SEARCH_HINT = "Nama atau pemilik server"
    override val SEARCH_CLEAR = "Hapus"
    override val SHARE_RESULTS = "Bagikan hasil pengukuran"
    override val SHARE_RESULTS_HEAD = "Pengukuran DNS Hızlı (tercepat dulu)"
    override val NO_RESULTS = "Lakukan pengukuran dulu"
    override val CUSTOM_EDIT = "Ubah"
    override fun customUpdated(name: String) = "$name diperbarui"
    override val KEEP_HISTORY = "Simpan riwayat"
    override val KEEP_HISTORY_NOTE = "Jika mati, server terbaru, riwayat, dan pengukuran tidak dicatat. Data yang ada tetap tersimpan."
    override val MOTION = "Animasi"
    override val TEXT_SIZE = "Ukuran teks"
    override val HIGH_CONTRAST = "Kontras tinggi"
    override val HIGH_CONTRAST_NOTE = "Kaca lebih pekat dan teks lebih gelap"
    override val MINIMAL = "Tampilan minimal"
    override val MINIMAL_NOTE = "Sembunyikan filter dan baris statistik"
    override val LOW_POWER = "Mode hemat daya"
    override val LOW_POWER_NOTE = "Matikan semua gerakan, hemat baterai"
    override val HAPTICS = "Getaran"
    override val HAPTICS_NOTE = "Getar ringan saat disentuh"
    override val ENCRYPTION = "DNS terenkripsi"
    override val ENCRYPTION_NOTE = "Otomatis: DoT dulu, lalu DoH, terakhir DNS biasa"
    override val AUTO_CONNECT = "Hubungkan saat app dibuka"
    override val AUTO_CONNECT_NOTE = "Terhubung ke server terakhir saat kamu membuka aplikasi"
    override val CONNECT_ON_BOOT = "Hubungkan saat ponsel aktif"
    override val CONNECT_ON_BOOT_NOTE = "Terhubung otomatis setelah ponsel dimulai ulang"
    override val AUTO_FASTEST = "Hubungkan ke yang tercepat"
    override val AUTO_FASTEST_NOTE = "Ketuk bola untuk memilih server tercepat dari cek terakhir"
    override val REFRESH_ON_NET = "Perbarui saat ganti jaringan"
    override val REFRESH_ON_NET_NOTE = "DNS diperbarui saat beralih antara Wi-Fi dan data seluler"
    override val NOTIFY_DROP = "Beri tahu jika koneksi putus"
    override val NOTIFY_DROP_NOTE = "Notifikasi dengan tombol sambung ulang saat putus tiba-tiba"
    override val NOTIFY_CONNECT = "Beri tahu saat tersambung"
    override val NOTIFY_CONNECT_NOTE = "Notifikasi singkat saat koneksi terjalin"
    override val NOTIFY_STOP = "Beri tahu saat diputus"
    override val NOTIFY_STOP_NOTE = "Notifikasi singkat saat kamu memutus koneksi"
    override val NOTIFY_TIMEOUT = "Beri tahu jika waktu habis"
    override val NOTIFY_TIMEOUT_NOTE = "Notifikasi jika server DNS tidak menjawab"
    override val NOTIF_PERM = "Izin notifikasi sistem"
    override val PERM_ALLOWED = "Diizinkan"
    override val PERM_BLOCKED = "Mati · perbaiki"
    override val NOTIF_CONNECTED_TITLE = "DNS tersambung"
    override val NOTIF_STOPPED_TITLE = "DNS terputus"
    override val NOTIF_STOPPED_TEXT = "Perlindungan mati"
    override val NOTIF_TIMEOUT_TITLE = "DNS kehabisan waktu"
    override val FAIL_CLOSED = "Blokir DNS jika terputus"
    override val FAIL_CLOSED_NOTE = "Jika koneksi putus, kueri DNS tidak bocor ke operator; kueri gagal sampai tersambung lagi"
    override val FILTER_MEM = "Memori filter"
    override val OPT_FILTER_MEM = listOf("Otomatis", "Ringan", "Penuh")
    override val FILTER_MEM_NOTE = "Otomatis: tanpa daftar besar saat memori kecil. Ringan: tanpa. Penuh: dengan"
    override val ERR_NO_APPS = "Tidak ada aplikasi dipilih, perlindungan tidak dimulai. Pilih aplikasi atau ganti ke “Semua aplikasi”."
    override val NOTIF_SEALED = "DNS diblokir saat menyambung ulang"
    override val ERR_SEALED = "Gagal tersambung. DNS diblokir agar kueri tidak bocor. Ketuk Hentikan untuk melepasnya."
    override val SEALED_INFO = "DNS diblokir sampai koneksi kembali"
    override val LATENCY_TITLE = "Latensi per kueri"
    override val LATENCY_EMPTY = "Tampil langsung setelah tersambung dan ada kueri"
    override val FILTER_MINE = "Daftar saya sendiri"
    override val MINE_PASTE = "Impor dari papan klip"
    override val MINE_PASTE_NOTE = "Berkas hosts atau satu domain per baris"
    override val MINE_FILE = "Impor dari berkas"
    override val MINE_FILE_NOTE = "Berkas .txt atau hosts di ponsel"
    override val MINE_EXPORT = "Salin daftar blokir saya"
    override val MINE_EXPORT_NOTE = "Ke papan klip, format hosts"
    override val MINE_CLEAR = "Hapus daftar impor"
    override val MINE_FOOT = "Membaca baris hosts (0.0.0.0 domain), daftar domain biasa, dan aturan ||domain^. Maksimal 50.000 nama. Daftar izin selalu diutamakan."
    override val MINE_NOTHING = "Tidak ada domain yang valid"
    override val MINE_CLIP_EMPTY = "Papan klip kosong"
    override val MINE_FILE_ERR = "Berkas tidak bisa dibaca"
    override val MINE_CLEARED = "Daftar impor dihapus"
    override val MINE_CLEAR_ASK = "Hapus daftar impor?"
    override val MINE_CUT = "Batas tercapai, sisanya dilewati"
    override fun notifTimeout(name: String) = "$name tidak menjawab. Mencoba lagi."
    override val MOD_DPI = "Lewati DPI"
    override val MOD_ADS = "Iklan+"
    override val MOD_DPI_SUB = "Buka situs terblokir"
    override val MOD_ADS_SUB = "Blokir di luar DNS"
    override val MOD_ON = "Aktif"
    override val MOD_OFF = "Mati"
    override val BLOCK_QUIC = "Blokir QUIC"
    override val BLOCK_QUIC_NOTE = "Aplikasi kembali ke TCP, jadi Lewati DPI dan Iklan+ juga mencakupnya"
    override val GW_TRIPPED = "Masalah koneksi terdeteksi: Lewati DPI dan Iklan+ dimatikan"
    override val MOD_FAILED = "Gagal diaktifkan. Izin VPN ditolak atau VPN lain aktif."
    override fun gwOn(modules: String) = "Gateway aktif: $modules"
    override fun gwOnStats(modules: String, blocked: String) = "Gateway aktif: $modules · $blocked diblokir"
    override fun modOn(name: String) = "$name dinyalakan"
    override fun modOff(name: String) = "$name dimatikan"
    override fun modAdsCount(n: String) = "$n diblokir"
    override fun modDpiCount(n: String) = "$n koneksi dipecah"
    override fun latencyLine(avg: String, max: String, timeouts: Int) = "rata-rata $avg · maks $max" + (if (timeouts > 0) " · $timeouts waktu habis" else "")
    override fun mineCount(n: Int) = "$n domain"
    override fun mineAdded(n: Int) = "$n domain ditambahkan"
    override fun mineCopied(n: Int) = "$n domain disalin"
    override val CACHE = "Cache DNS"
    override val CLEAR_CACHE = "Hapus cache"
    override val CACHE_CLEARED = "Cache dihapus"
    override val ONLY_CONNECTED = "Tersedia saat terhubung"
    override val RULE_WIFI = "Server Wi-Fi"
    override val RULE_MOBILE = "Server data seluler"
    override val RULE_AUTO = "Otomatis"
    override val RULE_AUTO_NOTE = "Server yang terakhir kamu pakai"
    override val COMPACT = "Daftar ringkas"
    override val COMPACT_NOTE = "Baris lebih pendek tanpa deskripsi"
    override val HIDDEN = "Server tersembunyi"
    override val HIDDEN_NONE = "Tidak ada"
    override val STAT_QUERIES = "Total kueri"
    override val STAT_HITS = "Dijawab dari cache"
    override val STAT_BLOCKED = "Diblokir (perkiraan)"
    override val STAT_TIME = "Total waktu terhubung"
    override val WEEK = "7 hari terakhir"
    override fun weekA11y(total: String) = "$total kueri dalam 7 hari terakhir"
    override val WEEKDAYS = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")
    override val EXPORT = "Ekspor pengaturan"
    override val IMPORT = "Impor pengaturan"
    override val EXPORTED = "Kode pengaturan disalin ke papan klip"
    override val IMPORTED = "Pengaturan dimuat"
    override val IMPORT_BAD = "Tidak ada kode pengaturan yang valid di papan klip"
    override val RESET_SETTINGS = "Reset pengaturan"
    override val RESET_STATS = "Reset statistik"
    override val CONFIRM = "Kamu yakin?"
    override val RESET = "Reset"
    override val RESET_DONE = "Berhasil direset"
    override val LOG = "Log diagnostik"
    override val HELP = "Bagaimana cara kerjanya?"
    override val VPN_SETTINGS = "Setelan VPN sistem"
    override val SHARE_APP = "Bagikan aplikasi"
    override val RATE_APP = "Beri nilai aplikasi"
    override val FEEDBACK = "Kirim masukan"
    override fun shareAppText(url: String) = "$APP menghubungkanmu ke server DNS populer dengan sekali ketuk: $url"
    override val VERSION = "Versi"
    override val OPT_BUBBLES = listOf("Mati", "Sedikit", "Banyak")
    override val OPT_MOTION = listOf("Penuh", "Sedikit", "Mati")
    override val OPT_CACHE = listOf("Mati", "Kecil", "Normal", "Besar")
    override val OPT_ENCRYPTION = listOf("Otomatis", "DoT", "DoH", "Mati")
    override val PLAIN_DNS = "DNS biasa"

    override val LOG_NOTE = "Hanya peristiwa koneksi yang disimpan. Nama kueri dan data pribadi tidak pernah disimpan."
    override val LOG_EMPTY = "Belum ada catatan."
    override val SHARE = "Bagikan"
    override val CLEAR = "Hapus"
    override val CLEARED = "Dihapus"
    override val HELP_SECTIONS = listOf(
        "Apa itu DNS?" to
            "DNS adalah layanan yang mengubah alamat internet (seperti example.com) menjadi angka yang dipahami perangkat. " +
            "DNS yang kamu pakai bisa memengaruhi kecepatan, privasi, dan konten apa saja yang diblokir.",
        "Apa fungsi aplikasi ini?" to
            "Aplikasi ini memakai server DNS pilihanmu di semua aplikasi. Untuk itu, aplikasi membuka antarmuka VPN lokal di ponselmu, " +
            "tetapi lalu lintasmu tidak dikirim ke server VPN. Hanya kueri DNS yang dikirim ke server pilihanmu; " +
            "selebihnya tetap lewat jalur biasa.",
        "DNS terenkripsi (DoT / DoH)" to
            "Di server yang mendukung, kueri dikirim terenkripsi: tak seorang pun di jaringan (pemilik Wi-Fi, operator) bisa melihat " +
            "situs yang kamu kunjungi atau mengubah jawabannya. Di mode Otomatis, DoT dicoba lebih dulu, lalu DoH; jika keduanya gagal, " +
            "DNS biasa dipakai. Kamu akan diberi tahu saat itu terjadi, dan aplikasi mencoba kembali ke enkripsi setiap kali " +
            "jaringan berganti dan setiap 10 menit. Jika \"Enkripsi ketat\" aktif, DNS biasa tidak pernah dipakai. " +
            "Layar utama menunjukkan metode yang sedang dipakai.",
        "Tes koneksi" to
            "☰ > Pengaturan DNS > Tes koneksi mengirim pertanyaan DNS sungguhan melalui terowongan. Hasilnya menunjukkan " +
            "bahwa DNS benar-benar dijawab oleh server pilihanmu, seberapa cepat, apakah server memvalidasi tanda tangan DNSSEC, " +
            "dan apakah server memblokir domain iklan yang terkenal.",
        "Privasi" to
            "Tanpa akun, tanpa pengumpulan data, tanpa iklan. Aplikasi tidak menyimpan nama kueri dan tidak mengirim apa pun atas kemauannya sendiri. " +
            "Kueri kamu hanya dikirim ke penyedia DNS pilihanmu, sesuai kebijakan privasi penyedia tersebut. " +
            "DNS terenkripsi (DoT/DoH) mencegah siapa pun di jaringan membaca atau mengubah kuerimu. Sebelum dikirim, aplikasi membuang data tambahan yang bisa mengenali perangkatmu (subjaringan klien, cookie, ID perangkat), mengisi pesan agar panjangnya tersamar, dan membuang tiket sesi TLS saat jaringan berganti. " +
            "Jujur saja: tanpa relai, penyedia DNS tetap melihat alamat IP publikmu (ia harus menjawabmu), dan galat sertifikat bisa berarti ada yang mengganggu koneksi. " +
            "Log diagnostik hanya berisi peristiwa koneksi.",
        "Baterai dan sumber daya" to
            "Pemakaian sumber daya di latar belakang sangat kecil. Tidak ada proses yang terus berputar saat layar mati; " +
            "aplikasi hanya bekerja saat ada kueri DNS masuk. Koneksi terenkripsi tertutup sendiri saat tidak dipakai.",
        "Perlu diketahui" to
            "Android hanya mengizinkan satu VPN dalam satu waktu; aplikasi ini tidak bisa terhubung saat aplikasi VPN lain aktif. " +
            "Setelan \"DNS aman\" di browser dan \"DNS Pribadi\" Android yang diatur ke nama host tertentu memakai server sendiri " +
            "dan bisa melewati pengalihan ini; cukup biarkan di \"Otomatis\" atau \"Nonaktif\". " +
            "Tekan lama bola untuk cepat beralih ke server yang biasa kamu pakai atau menjeda koneksi sebentar.",
    )

    override val NOTIF_CHANNEL = "Status koneksi"
    override val NOTIF_CHANNEL_NOTE = "Ditampilkan saat koneksi DNS aktif"
    override val NOTIF_ALERT_CHANNEL = "Peringatan koneksi"
    override val NOTIF_CONNECTING = "Menghubungkan…"
    override val NOTIF_STOP = "Putuskan"
    override val NOTIF_NEXT = "Berikutnya"
    override val NOTIF_DROP_TITLE = "Koneksi DNS terputus"
    override val NOTIF_RECONNECT = "Sambung ulang"
    override fun notifOn(name: String, proto: String) = "Terhubung ke $name · $proto"
    override fun notifPaused(time: String) = "Dijeda · lanjut pukul $time"
    override val TILE_ON = "Terhubung"
    override val TILE_OFF = "Mati"
    override val WIDGET_TAP = "Ketuk: hubungkan / putuskan"
    override val ERR_PERMISSION = "Izin VPN tidak diberikan"
    override val ERR_ESTABLISH = "Antarmuka VPN tidak bisa dibuka. Mungkin ada VPN lain yang aktif."
    override fun errNoReply(name: String) = "$name tidak merespons"
    override val PHONE_BYPASS = "Ponsel tidak memakai DNS ini (DNS Pribadi?)"
    override fun errNoProto(name: String, proto: String) = "$name tidak mendukung $proto"
    override val ERR_SOCKET = "Tidak dapat menjangkau jaringan"
    override fun errPrivateDns(host: String) = "DNS Pribadi Android diatur ke $host dan melewati aplikasi ini. Ubah Setelan > Jaringan > DNS Pribadi ke Otomatis atau Nonaktif."
    override val ERR_REVOKED = "Koneksi ditutup oleh sistem"
    override val ERR_TUNNEL = "Terowongan tertutup secara tak terduga"
    override val ERR_UNKNOWN = "Terjadi kesalahan tak terduga"

    override val CONSENT_TITLE = "Sebelum terhubung"
    override val CONSENT_BODY = listOf(
        "$APP memakai antarmuka VPN Android untuk mengarahkan kueri DNS kamu (nama situs yang kamu kunjungi) ke server DNS pilihanmu.",
        "Lalu lintasmu tidak dikirim ke server VPN; hanya kueri DNS yang dikirim ke penyedia pilihanmu. Di server yang mendukung, " +
            "kueri dienkripsi (DoT/DoH); jika tidak, kueri dikirim tanpa enkripsi. Kebijakan privasi penyedia tersebut berlaku." +
            " Jika kamu mengaktifkan “$MOD_DPI” atau “$MOD_ADS”, seluruh lalu lintas melewati relai yang hanya berjalan di dalam ponselmu; tetap tidak dikirim ke tempat lain.",
        "Aplikasi ini tidak mengumpulkan data pribadi, tidak menyimpan nama kueri, dan tidak membagikan apa pun kepada siapa pun.",
        "Jika lanjut, Android akan menampilkan permintaan koneksi VPN; kamu perlu mengetuk \"OK\".",
    )
    override val CONSENT_OK = "Mengerti, lanjutkan"
    override val CLOSE = "Tutup"
    override val BACK = "Kembali"

    override val RESUMING = "Melanjutkan…"
    override val DOWNGRADED = "Gagal mengenkripsi, pakai DNS biasa"
    override val UPGRADED = "Kembali ke DNS terenkripsi"
    override val ODOH = "Oblivious DoH (ODoH)"
    override val OPT_ODOH = listOf("Mati", "Cadangan", "Ketat")
    override val ODOH_NOTE = "Relai melihat IP Anda, bukan pertanyaan; server sebaliknya."
    override val DOWNGRADED_ODOH = "ODoH tidak tersedia, memakai koneksi terenkripsi biasa"
    override val NOTIF_ODOH_TITLE = "ODoH tidak aktif"
    override fun notifOdoh(name: String) = "Relai ODoH tidak terjangkau. Memakai koneksi biasa ke $name; aplikasi terus mencoba kembali ke ODoH."
    override val ERR_NO_ODOH = "Tidak dapat terhubung lewat ODoH: relai atau target tidak merespons"
    override val NOTIF_DOWNGRADE_TITLE = "DNS tidak terenkripsi"
    override fun notifDowngrade(name: String) = "Tidak bisa membuat koneksi terenkripsi ke $name. DNS biasa sedang dipakai; aplikasi akan mencoba kembali ke enkripsi."
    override fun backupUsed(failed: String, used: String) = "$failed tidak merespons, terhubung ke $used"
    override val NOTIF_RETRYING = "Koneksi putus, mencoba lagi…"
    override fun errNoEncrypted(name: String) = "Tidak bisa membuat koneksi terenkripsi ke $name"
    override fun errUntrusted(name: String) = "Sertifikat $name tidak bisa diverifikasi; jaringan atau perangkat lunak mungkin mengganggu koneksi terenkripsi"
    override val APPLYING = "Menerapkan pengaturan baru ke koneksi"
    override val CONFIRM_DISCONNECT = "Putuskan koneksi?"
    override val DISCONNECT = "Putuskan"

    override val SEC_NOTIF = "Notifikasi"
    override val STRICT_ENC = "Enkripsi ketat"
    override val STRICT_ENC_NOTE = "Jangan pernah beralih ke DNS biasa"
    override val IP_MODE = "Versi IP"
    override val IP_MODE_NOTE = "Yang dimiliki jaringanmu dicoba dulu, yang lain jadi cadangan"
    override val OPT_IP_MODE = listOf("IPv4 + IPv6", "IPv4 saja")
    override val FILTER = "Pemblokiran"
    override val FILTER_LEVEL = "Blokir iklan dan pelacak"
    override val OPT_FILTER = listOf(
        "Mati",
        "Dasar",
        "Sedang",
        "Ketat",
    )
    override val FILTER_NOTES = listOf(
        "Tidak ada yang diblokir.",
        "Situs iklan, phishing, dan malware yang dikenal. Risiko rusak sangat kecil.",
        "Dasar ditambah lebih banyak pelacak dan analitik. Beberapa situs bisa bermasalah.",
        "Daftar terluas, termasuk penipuan, penyalahgunaan, dan pengalihan. Sering ada masalah.",
    )
    override val FILTER_INFO = "Pemblokiran sepenuhnya di ponsel Anda: bila situs dalam daftar ditanyakan, jawabannya NXDOMAIN, kueri tidak dikirim ke server mana pun dan tidak ada nama yang disimpan. Hanya aktif saat tersambung. Pengaturan DNS aman milik peramban bisa melewatinya. Jika situs rusak, izinkan dari Baru diblokir."
    override val FILTER_LAST = "Baru diblokir"
    override val FILTER_RECENT_NOTE = "Ketuk: izinkan"
    override val FILTER_RECENT_EMPTY = "Belum ada yang diblokir di sesi ini. Nama muncul di sini saat tersambung dan tingkat aktif."
    override val FILTER_RECENT_FOOT = "Hanya di memori untuk sesi ini; tidak pernah disimpan, dihapus saat terputus."
    override val FILTER_ALLOW = "Diizinkan"
    override val FILTER_BLOCK = "Daftar blokir saya"
    override val FILTER_ADD = "Tambah…"
    override val FILTER_REMOVE = "Ketuk: hapus"
    override val FILTER_ALLOW_ADD = "Domain yang diizinkan"
    override val FILTER_BLOCK_ADD = "Domain yang diblokir"
    override val FILTER_ERR = "Masukkan domain yang valid, mis. contoh.com"
    override val FILTER_ERR_LIMIT = "Maksimal 200 domain"
    override val FILTER_ALLOW_EMPTY = "Belum ada domain diizinkan. Jika situs rusak, tambahkan di sini."
    override val FILTER_BLOCK_EMPTY = "Daftar blokir Anda kosong."
    override val FILTER_ALLOW_FOOT = "Domain dan semua subdomainnya tidak pernah diblokir. Izin mengalahkan semua daftar dan daftar blokir Anda."
    override val FILTER_BLOCK_FOOT = "Domain dan semua subdomainnya selalu diblokir (juga saat tingkat mati)."
    override val FILTER_REMOVE_BTN = "Hapus"
    override fun filterAllowed(name: String) = "$name diizinkan"
    override fun filterBlocked(name: String) = "$name akan diblokir"
    override fun filterRemoved(name: String) = "$name dihapus"
    override fun filterRemoveAsk(name: String) = "Hapus $name dari daftar?"
    override val TEST_IPV6 = "Jalur IPv6"
    override val AUTO_RECONNECT = "Sambung ulang otomatis"
    override val AUTO_RECONNECT_NOTE = "Jika koneksi putus, coba lagi setelah 5 dtk, 30 dtk, dan 2 mnt"
    override val BACKUP_SERVER = "Server cadangan"
    override val BACKUP_OFF = "Mati"
    override val BACKUP_OFF_NOTE = "Jangan terhubung jika server pilihan tidak merespons"
    override val BACKUP_FASTEST = "Tercepat"
    override val BACKUP_FASTEST_NOTE = "Server lain yang tercepat dari cek terakhir"
    override val CONFIRM_OFF = "Tanya sebelum memutuskan"
    override val CONFIRM_OFF_NOTE = "Ketukan tak sengaja pada bola tidak memutus koneksi"
    override val LOCK_HIDE = "Sembunyikan di layar kunci"
    override val LOCK_HIDE_NOTE = "Nama server tidak tampil di notifikasi layar kunci"
    override val QUIET_NOTIF = "Notifikasi senyap"
    override val QUIET_NOTIF_NOTE = "Tanpa ikon di bilah status, tanpa suara"
    override val REMEMBER_FILTER = "Ingat filter terakhir"
    override val REMEMBER_FILTER_NOTE = "Filter yang terakhir kamu pilih muncul lagi saat aplikasi dibuka"
    override val AUTO_MEASURE = "Ukur saat dibuka"
    override val AUTO_MEASURE_NOTE = "Ukur otomatis jika cek terakhir sudah lebih dari sehari"
    override val MEASURE_ENC = "Pengukuran terenkripsi"
    override val MEASURE_ENC_NOTE = "Ukur kecepatan lewat DoT, lebih mirip pemakaian terenkripsi"
    override val OPT_SORT = listOf("Bawaan", "Kecepatan", "Nama")
    override fun sortA11y(mode: String) = "Urutkan: $mode"
    override val AUTO_LIGHT = "Otomatis: tema terang"
    override val AUTO_DARK = "Otomatis: tema gelap"
    override val NIGHT_HOURS = "Jam malam"
    override val FILTER_ENCRYPTED = "Terenkripsi"
    override val FILTER_UNFILTERED = "Tanpa filter"

    override val TEST = "Tes koneksi"
    override val TEST_NOTE = "DNS, DNSSEC, dan blokir iklan"
    override val TESTING = "Menguji…"
    override val TEST_TITLE = "Tes koneksi"
    override val TEST_OK = "DNS berfungsi"
    override val TEST_FAIL = "Tidak ada respons"
    override val TEST_SERVER = "Server"
    override val TEST_METHOD = "Metode"
    override val TEST_LATENCY = "Waktu respons"
    override val TEST_DNSSEC = "Validasi DNSSEC"
    override val TEST_ADS = "Blokir iklan"
    override val DNSSEC_YES = "Memvalidasi"
    override val DNSSEC_NO = "Tidak memvalidasi"
    override val ADS_YES = "Aktif"
    override val ADS_NO = "Nonaktif"
    override val UNKNOWN = "Tidak diketahui"
    override val TEST_EXPLAIN = "Pertanyaan dikirim melalui terowongan, sama seperti saat sebuah aplikasi bertanya; jawabannya datang dari server pilihanmu."
    override val TEST_AGAIN = "Tes lagi"

    override val RECOMMEND = "Carikan server untukku"
    override val RECOMMEND_NOTE = "Pilih tujuanmu, kami hubungkan ke yang cocok dan tercepat"
    override val GOAL_SPEED = "Kecepatan"
    override val GOAL_SPEED_NOTE = "Server tercepat menurut pengukuranmu"
    override val GOAL_PRIVACY_NOTE = "Tanpa log, fokus privasi"
    override val GOAL_ADS_NOTE = "Memblokir iklan dan pelacak"
    override val GOAL_FAMILY_NOTE = "Memblokir konten dewasa"
    override val GOAL_SECURITY_NOTE = "Memblokir situs berbahaya dan phishing"
    override fun recommended(name: String) = "Rekomendasi: $name"

    override val PRIVATE_DNS = "Nama DNS Pribadi"
    override val PRIVATE_DNS_NOTE = "Kamu bisa menempelkannya di setelan DNS Pribadi Android. Sistem lalu memakai server ini secara langsung dan aplikasi ini dilewati."
    override val CLEAR_HISTORY = "Hapus riwayat kecepatan"
    override val HISTORY_CLEARED = "Pengukuran dihapus"

    override val GUARD = "Perlindungan selalu aktif"
    override val GUARD_NOTE = "VPN selalu aktif"
    override val GUARD_BODY = listOf(
        "Saat aplikasi tidak terhubung (dimatikan, dijeda, atau setelah putus), kueri DNS kamu dikirim ke server penyedia internetmu.",
        "Untuk mencegahnya, aktifkan \"VPN selalu aktif\" untuk aplikasi ini di setelan VPN Android. Jika \"Blokir koneksi tanpa VPN\" juga aktif, internet sama sekali tidak berfungsi saat aplikasi tidak terhubung: tidak ada kebocoran, tapi menjeda juga berarti tanpa internet.",
        "Dengan VPN selalu aktif, sistem menjalankan aplikasi secara otomatis saat ponsel menyala dan setelah aplikasi berhenti.",
    )
    override val GUARD_BUTTON = "Buka setelan VPN sistem"
    override val BATTERY = "Setelan baterai"
    override val BATTERY_OK = "Tidak dibatasi"
    override val BATTERY_LIMITED = "Mungkin dibatasi"
    override val BATTERY_BODY = listOf(
        "Android biasanya melindungi aplikasi VPN. Namun, beberapa produsen (Xiaomi, Huawei, Oppo, Vivo, beberapa versi Samsung) bisa menutup aplikasi di latar belakang untuk menghemat baterai.",
        "Jika koneksi sering putus sendiri, atur penggunaan baterai aplikasi ini ke \"Tidak dibatasi\" atau \"Tidak dioptimalkan\"; di beberapa ponsel, izinkan juga \"Mulai otomatis\".",
    )
    override val BATTERY_BUTTON = "Buka setelan baterai"

    override val BOOT_TAP = "Gagal terhubung saat ponsel menyala. Ketuk untuk terhubung."
    override val REBIND = "Perlindungan jaringan lokal"
    override val REBIND_NOTE = "Mencegah situs menjangkau router dan perangkat rumah lewat trik DNS"
    override val STAT_AVG = "Rata-rata waktu respons"
    override val STAT_SAVED = "Waktu yang dihemat cache"
    override val STAT_TRAFFIC = "Lalu lintas DNS"
    override val SESSIONS = "Riwayat koneksi"
    override val SESSIONS_NOTE = "30 koneksi terakhir; nama kueri tidak pernah disimpan"
    override val SESSIONS_EMPTY = "Belum ada koneksi yang tercatat."
    override val MOST_USED = "Paling sering dipakai"
    override val TODAY = "Hari ini"
    override val ORB_SHAPE = "Bentuk bola"
    override val ORB_SHAPE_EACH = "Bentuk per tema"
    override val ORB_SHAPE_NAMES = listOf("Bola", "Segitiga", "Persegi", "Segi enam", "Bintang", "Segi delapan", "Segi lima", "Persegi panjang", "Segitiga terbalik", "Berlian", "Bunga", "Bintang segi enam")
    override val SHIELD_WORD = "Perisai"
    override val LIQUID_WAVE = "Animasi gelombang"
    override val LIQUID_WAVE_NOTE = "Pilih salah satu dari 10 model dinamika fluida di dalam bola."
    override val LIQUID_COLOR = "Warna cairan"
    override val LIQUID_THEME = "Sesuai tema"
    override val COLOR_WORD = "Warna"
    override val LIQUID_NOTE = "Warna pilihan menggantikan rona kecepatan; kecepatan gelombang tetap mengikuti kecepatan server."
    override val YESTERDAY = "Kemarin"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Kamu putuskan"
        EndReason.PAUSE -> "Dijeda"
        EndReason.SWITCH -> "Server diganti"
        EndReason.DROP -> "Terputus"
        EndReason.REVOKED -> "Ditutup sistem"
        EndReason.FAILED -> "Tak merespons"
        EndReason.NETWORK -> "Jaringan berganti"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries kueri"

    override val SOUND_MOTION = "Suara dan gerak"
    override val SEC_SOUND = "Suara"
    override val SOUND_ON = "Efek suara"
    override val SOUND_ON_NOTE = "Bunyi singkat dan lembut saat mengetuk dan menyambung. Tidak berbunyi saat ponsel senyap."
    override val SOUND_UI = "Suara ketukan"
    override val SOUND_UI_NOTE = "Tombol, sakelar, dan pergantian halaman"
    override val SOUND_CONN = "Suara sambungan"
    override val SOUND_CONN_NOTE = "Bunyi berbeda untuk tersambung, terputus, dan galat"
    override val SOUND_VOL = "Volume"
    override val SOUND_PACK = "Paket suara"
    override val SOUND_TEST = "Coba suara sambungan"
    override val QUIET_HOURS = "Jam tenang"
    override val QUIET_NOTE = "Tanpa suara dan getaran pada jam ini"
    override val QUIET_RANGE = "Rentang jam tenang"
    override val SEC_MOTION_FX = "Gerak dan efek"
    override val ANIM_SPEED = "Kecepatan animasi"
    override val TAP_FX = "Efek ketukan"
    override val TAP_FX_NOTE = "Efek kecil khas gaya di tempat kamu menyentuh"
    override val CELEBRATE = "Perayaan saat tersambung"
    override val CELEBRATE_NOTE = "Pertunjukan khas gaya di sekitar bola saat tersambung"
    override val HAPTIC_LEVEL = "Kekuatan getaran"
    override val REMEMBER_MODS = "Ingat modul"
    override val REMEMBER_MODS_NOTE = "Saat tersambung, Lewati DPI dan Iklan+ menyala seperti terakhir kamu biarkan"
    override val PROFILES = "Profil"
    override val COPY_STATUS = "Salin ringkasan status"
    override val OPT_PACK = listOf("Otomatis", "Lembut", "Kaca", "Klasik")
    override val SOUND_PACK_NOTE = "Otomatis: suara dari gaya yang dipakai"
    override val SOUND_OUT = "Keluaran suara"
    override val OPT_SOUND_OUT = listOf("Otomatis", "Sistem", "Media")
    override val SOUND_OUT_NOTES = listOf("Memakai volume media jika suara sistem mati", "Saluran yang sama dengan suara sentuhan", "Tetap berbunyi saat ponsel bergetar")
    override val SOUND_BLOCK_RINGER = "Ponsel dalam mode senyap atau getar. Pilih Keluaran suara: Media."
    override val SOUND_BLOCK_ZERO = "Volume ponsel mati, suara tidak diputar."
    override val PACK_SPACE = "Antariksa"
    override val PACKS_NOTE = "Paket baru (termasuk Liquid Glass) membawa suara sendiri dan sepuluh animasi: ketuk, sakelar, sambung, putus, galat, selesai, panel, kembali, pilih, dan segarkan."
    override val OPT_HAPTIC = listOf("Ringan", "Normal", "Kuat")
    override val PROFILE_NAMES = listOf("Kecepatan", "Privasi", "Keluarga", "Perlindungan penuh")
    override val PROFILE_NOTES = listOf("Server tercepat, cache besar, tanpa pemblokiran", "Enkripsi ketat, blokir pelacak, Iklan+", "Server dengan filter keluarga, pemblokiran sedang", "Blokir iklan dan pelacak, Lewati DPI, Iklan+")
    override fun profileApplied(name: String) = "Profil diterapkan: $name"

    override val WHATS_NEW = "Apa yang baru?"
    override val WHATS_NEW_TOAST = "Aplikasi telah diperbarui"
    override val SHOW = "Lihat"
    override val WHATS_NEW_ITEMS = listOf(
        "Baru: suara kini tetap berbunyi saat ponsel bergetar (lewat media); hanya diam di mode senyap penuh. ☰ > Suara dan gerakan.",
        "Baru: Keluaran suara untuk ponsel senyap (☰ > Suara & gerak), perlindungan jaringan lokal, pemblokiran 5x lebih cepat, pengaturan baterai pabrikan.",
        "Baru: Oblivious DoH (ODoH) opsional: relai melihat IP Anda, server DNS melihat pertanyaan, tak pernah keduanya. ☰ > Pengaturan DNS.",
        "Baru: efek suara, mesin animasi mulus yang ditulis ulang, efek ketukan khas tiap gaya, profil, jam tenang, dan lainnya. ☰ > Suara dan gerak.",
        "Baru: tombol Lewati DPI dan Iklan+. Bisa bersama DNS atau sendiri; keduanya mati secara bawaan.",
        "Baru: impor daftar blokir sendiri, notifikasi tersambung/putus/waktu habis, grafik latensi per kueri, dan blokir DNS jika koneksi putus.",
        "Baru: daftar server tampil 8 dulu (Tampilkan semua / Tampilkan lebih sedikit), Tambah DNS khusus di atas, bilah gulir tipis.",
        "Baru: pemblokir iklan, pelacak, dan malware (Mati/Dasar/Sedang/Ketat) dengan daftar izin dan blokir sendiri. ☰ > Pemblokiran. Semua di ponsel.",
        "Baru: gaya Frutiger Aurora; Y2K kini holografik dan Metro bertema kota dan musik. Pilih di ☰ > Personalisasi > Gaya.",
        "Baru: IPv4 dan IPv6 bersamaan, deteksi gangguan lebih cepat; demi privasi, jejak perangkat dihapus dari kueri dan panjang pesan disamarkan.",
        "Baru: Pengaturan dipisah per topik. Di menu ☰: DNS, Koneksi dan aplikasi, Notifikasi, Daftar server, Statistik dan riwayat, Data.",
        "Baru: jendela Personalisasi (di menu ☰): bahasa, tema, gaya, latar, ikon, teks, dan aksesibilitas.",
        "Baru: menu ☰ di layar utama dan jendela Tentang (berita, bantuan, log, bagikan, versi).",
        "Perbaikan: foto sendiri dan gambar bawaan kini bisa jadi latar (ukuran foto salah terbaca).",
        "Perbaikan: uji koneksi membedakan masalah server dari ponsel yang tidak memakai DNS, dan memberi peringatan.",
        "Perbaikan: gaya Metro, Eco, dan Y2K digambar ulang; ganti ikon kini berlaku setelah keluar aplikasi.",
        "Baru: 8 gambar latar bawaan (☰ → Personalisasi → Foto latar → Gambar bawaan).",
        "Baru: pemecah masalah, pencarian server, bagikan hasil pengukuran, ubah server khusus, dan opsi tanpa riwayat.",
        "Ikon aplikasi: pilih satu dari lima ikon yang cocok dengan kelima gaya.",
        "Foto latar: gunakan gambar Anda sendiri sebagai latar, dengan lapisan dan blur yang dapat diatur; teks selalu tetap terbaca.",
        "Lima gaya tampilan: Aqua (klasik), Aero (langit dan rumput), Metro (ubin datar), Eco (alam), dan Y2K merah muda, masing-masing dengan animasinya sendiri serta transisi yang lebih halus.",
        "Pilihan aplikasi: terapkan DNS hanya ke aplikasi pilihan atau kecualikan sebagian.",
        "Tambahkan server DNS sendiri (maks. 8), 10 server baru, dan bagian info di setiap server: kegunaan, pemilik, ping rata-rata.",
        "Koneksi lebih aman: pemeriksaan tambahan terhadap jawaban DNS palsu, peringatan saat beralih ke DNS biasa, opsi enkripsi ketat, dan kembali ke enkripsi secara otomatis.",
        "Tes koneksi: cek dengan sekali ketuk bahwa DNS dijawab oleh server pilihanmu, plus validasi DNSSEC dan blokir iklan.",
        "Server cadangan dan sambung ulang otomatis: aplikasi pulih sendiri jika server pilihan tidak merespons atau koneksi putus.",
        "Riwayat koneksi, server yang paling sering dipakai, rata-rata waktu respons, dan lalu lintas DNS.",
        "Filter baru (Terenkripsi, Tanpa filter), urutkan menurut nama, \"Carikan server untukku\", dan pengukuran saat dibuka.",
        "Penghitung langsung di notifikasi, tombol jeda 15 menit, sembunyikan di layar kunci, dan opsi notifikasi senyap.",
        "Tiga tema baru (Sakura, Madu, Aurora), tema dari wallpaper, dan pilihan terang/gelap untuk tema otomatis.",
        "Empat bahasa baru: Indonesia, Vietnam, Polandia, dan Ukraina.",
    )
    override fun importedWith(changes: String) = "Pengaturan dimuat · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "enkripsi melemah"
        SensitiveChange.AUTO_START -> "sambung otomatis diaktifkan"
        SensitiveChange.RULES -> "aturan server diubah"
        SensitiveChange.PRIVACY -> "pengaturan privasi atau peringatan dilonggarkan"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries kueri · $blocked diblokir"
    override val NOTIF_LOCKED = "Perlindungan DNS aktif"
    override val NOTIF_QUIET_CHANNEL = "Status koneksi (senyap)"
    override fun widgetToday(queries: String) = "Hari ini $queries kueri"
    override fun pauseAction(minutes: Int) = "Jeda ${minutes(minutes)}"

    override val CUSTOM_NOTE = "Server yang kamu tambahkan"
    override val CUSTOM_ADD = "Tambah DNS khusus"
    override val CUSTOM_F_NAME = "Nama"
    override val CUSTOM_F_IP1 = "Alamat IPv4 (mis. 1.2.3.4)"
    override val CUSTOM_F_IP2 = "IPv4 kedua (opsional)"
    override val CUSTOM_F_DOT = "Nama DoT (opsional)"
    override val CUSTOM_F_DOH = "Alamat DoH, https://… (opsional)"
    override val CUSTOM_SAVE = "Tambah"
    override val CUSTOM_CANCEL = "Batal"
    override val CUSTOM_HINT = "Isi DoT atau DoH untuk koneksi terenkripsi; jika kosong, DNS tanpa enkripsi dipakai."
    override val CUSTOM_ERR_NAME = "Nama harus 1–24 karakter (tanpa | ; , =)"
    override val CUSTOM_ERR_IP = "Masukkan alamat IPv4 yang valid (mis. 1.2.3.4)"
    override val CUSTOM_ERR_DOT = "Nama DoT harus berupa nama domain yang valid"
    override val CUSTOM_ERR_DOH = "Alamat DoH harus diawali https://"
    override val CUSTOM_ERR_LIMIT = "Maksimal 8 server khusus"
    override fun customAdded(name: String) = "$name ditambahkan"
    override val CUSTOM_DELETE = "Hapus server ini"
    override val CUSTOM_IN_USE = "Tidak bisa dihapus saat terhubung"
    override fun customDeleted(name: String) = "$name dihapus"
    override val INFO_PURPOSE = "Kegunaannya"
    override val INFO_OWNER = "Pemilik"
    override val INFO_AVG = "Ping rata-rata"
    override fun avgPing(ms: Int, n: Int) = "$ms $msU · $n pengukuran"

    override val APPS = "Aplikasi"
    override val APPS_ALL = "Semua"
    override fun appsOnly(n: Int) = "Hanya yang dipilih ($n)"
    override fun appsExcept(n: Int) = "Semua kecuali yang dipilih ($n)"
    override val APPS_MODE = "Aplikasi mana yang memakai DNS ini?"
    override val OPT_APPS = listOf("Semua", "Dipilih", "Kecuali dipilih")
    override val APPS_NOTE = "Aplikasi lain memakai DNS bawaan ponsel. Hanya satu server DNS berjalan sekaligus; tidak bisa memilih server berbeda per aplikasi."
    override val APPS_LOADING = "Memuat aplikasi…"
    override val APPS_EMPTY = "Aplikasi tidak ditemukan"
    override val APPS_NONE_SELECTED = "Belum ada aplikasi dipilih: perlindungan tidak akan dimulai. Pilih aplikasi atau ganti ke “Semua aplikasi”."
    override val APPS_APPLY = "Terapkan sekarang"
    override val APPS_PENDING = "Perubahan berlaku saat koneksi diperbarui (putus satu-dua detik)."

    override val NOTES = mapOf(
        "cloudflare" to "Cepat, fokus privasi",
        "google" to "Stabil, banyak dipakai",
        "quad9" to "Memblokir domain berbahaya",
        "adguard" to "Memblokir iklan dan pelacak",
        "controld" to "Tanpa filter, cepat",
        "opendns" to "Cisco, perlindungan phishing",
        "dnssb" to "Fokus privasi, cepat",
        "dns4eu" to "DNS Uni Eropa, anti-malware",
        "uncensored" to "Tanpa filter atau pengalihan",
        "quad9-open" to "Tanpa pemblokiran",
        "adguard-open" to "Tanpa blokir, fokus privasi",
        "dns4eu-open" to "DNS Uni Eropa, tanpa filter",
        "controld-ads" to "Iklan, pelacak, malware",
        "dns4eu-ads" to "DNS Uni Eropa, iklan dan malware",
        "cloudflare-security" to "Memblokir situs berbahaya",
        "controld-malware" to "Memblokir situs berbahaya",
        "cleanbrowsing-security" to "Phishing dan situs berbahaya",
        "cloudflare-family" to "Filter malware dan konten dewasa",
        "opendns-family" to "Filter konten dewasa",
        "adguard-family" to "Filter iklan dan konten dewasa",
        "cleanbrowsing-family" to "Konten dewasa, pencarian aman",
        "dns4eu-child" to "DNS Uni Eropa, perlindungan anak",
        "controld-family" to "Filter konten dewasa",
        "nextdns" to "Filter dapat diatur, cepat",
        "cira-private" to "Kanada, tanpa filter, privasi",
        "cira-protected" to "Kanada, blokir situs berbahaya",
        "libredns" to "Independen, tanpa filter",
        "switch" to "Swiss, blokir situs berbahaya",
        "wikimedia" to "DNS Wikimedia, fokus privasi",
        "digitale" to "Nirlaba Swiss, tanpa filter",
        "quad101" to "Taiwan, cepat",
        "alidns" to "Tiongkok, cepat",
    )
}
