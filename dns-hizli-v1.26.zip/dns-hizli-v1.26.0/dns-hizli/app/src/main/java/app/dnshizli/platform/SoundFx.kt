package app.dnshizli.platform

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.ToneGenerator
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import app.dnshizli.core.AudioState
import app.dnshizli.core.Journal
import app.dnshizli.core.Ringer
import app.dnshizli.core.Sfx
import app.dnshizli.core.SoundBackend
import app.dnshizli.core.SoundBlock
import app.dnshizli.core.SoundCompat
import app.dnshizli.core.SoundOutput
import app.dnshizli.core.SoundPath
import app.dnshizli.core.SoundRoute
import app.dnshizli.core.SoundWarmup
import app.dnshizli.core.Synth
import app.dnshizli.core.Voice
import java.util.concurrent.atomic.AtomicInteger

/**
 * Sentezlenmiş ses efektlerini çalar. Dosya yoktur: [Synth] sesleri üretir. Cihazlar (ve ROM'lar) ses API'sini farklı uygular;
 * bu sınıf bilinen sessizlik nedenlerinin her birine ayrı önlem alır:
 *
 *  1. **Kanal kısık ama API "çalıyor" diyor.** Sistem kanalı (dokunma sesleri) titreşim/sessiz modda ve sistem ses seviyesi
 *     sıfırken duyulmaz. Çalmadan önce ses durumu okunur ([SoundRoute]): sistem kanalı kısıksa medya kanalına geçilir ya da
 *     neden çalınmadığı ([SoundBlock]) üst katmana bildirilir ("Sesi dene" bunu kullanıcıya söyler).
 *  2. **Hoparlör ısınması.** Çıkış birkaç saniye boşta kalınca ilk 60–150 ms yutulur; kısa efektler tamamen kaybolur.
 *     Soğuk çıkışta sesin önüne kısa bir sessizlik eklenir ([SoundWarmup]).
 *  3. **Erken bırakma.** Akış yolu, ses bitmeden (Bluetooth, yüksek gecikmeli çıkış) bırakılıyordu. Artık çalma kafası izlenir;
 *     ses gerçekten bitince (ya da cömert bir üst sınırda) bırakılır.
 *  4. **Sessiz başarı.** API "çalıyor" der ama çalma kafası hiç ilerlemezse yol bozuk sayılır ve sıradakine geçilir ([SoundCompat]).
 *  5. **Cihaz farkları.** Dört çalma yolu; çalışan kalıcı hatırlanır, bozulursa sıradakine geçilir, her oturumda üst yol bir kez
 *     yeniden denenir.
 *
 * Tüm ses işi ayrı bir iş parçacığında yapılır. Bekleyen çalma sayısı sınırlıdır.
 */
class SoundFx(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("dnshizli_sound", Context.MODE_PRIVATE)
    private val worker = HandlerThread("dns-sound").also { it.isDaemon = true; it.start() }
    private val handler = Handler(worker.looper)
    private val pending = AtomicInteger()
    private val am = try { context.applicationContext.getSystemService(AudioManager::class.java) } catch (_: Exception) { null }
    @Volatile private var diagSent = false
    @Volatile private var closed = false

    // yalnızca [worker] iş parçacığı kullanır
    private val pcmCache = HashMap<Int, ShortArray>()
    private val statics = HashMap<Int, AudioTrack>()
    private val staticTokens = HashMap<Int, Long>()
    private val streams = ArrayList<AudioTrack>()
    private var voice: Voice = Voice.values()[0]
    private var voiceSet = false
    private var tone: ToneGenerator? = null
    private var toneVol = -1
    private val warm = SoundWarmup()
    private var lastBlock = SoundBlock.NONE

    private val compat = SoundCompat(
        backend = Backend(),
        initial = readSaved(),
        remember = { p -> try { prefs.edit().putString(KEY, p.name).apply() } catch (_: Exception) {} },
        log = { Journal.add(it) },
    )

    private fun readSaved(): SoundPath? = try {
        prefs.getString(KEY, null)?.let { s -> SoundPath.values().firstOrNull { it.name == s } }
    } catch (_: Exception) { null }

    /** Eski çağrı biçimi: otomatik çıkış. */
    fun play(e: Sfx, v: Voice, volume: Float) { play(e, v, volume, SoundOutput.AUTO) }

    /**
     * Ana iş parçacığından çağrılır; hemen döner. Ses durumu yüzünden çalınmayacaksa nedenini döner (çalma yine kuyruğa
     * alınmaz). Ses durumunu okumak birkaç hafif sistem çağrısıdır.
     */
    fun play(e: Sfx, v: Voice, volume: Float, output: SoundOutput): SoundBlock {
        if (closed) return SoundBlock.NONE
        val plan = SoundRoute.plan(audioState(), output)
        if (plan.block != SoundBlock.NONE) {
            if (plan.block != lastBlock) { lastBlock = plan.block; Journal.add("ses: çalınmadı (${plan.block.name}, çıkış=${output.id})") }
            return plan.block
        }
        lastBlock = SoundBlock.NONE
        if (pending.incrementAndGet() > MAX_PENDING) { pending.decrementAndGet(); return SoundBlock.NONE }   // artır-sonra-denetle
        val queued = handler.post {
            try { playNow(e, v, volume, plan.paths) } finally { pending.decrementAndGet() }
        }
        if (!queued) pending.decrementAndGet()
        return SoundBlock.NONE
    }

    /** AudioManager'dan anlık durum; okunamazsa null (o zaman tüm yollar sırayla denenir). */
    private fun audioState(): AudioState? {
        val m = am ?: return null
        return try {
            val ringer = when (m.ringerMode) {
                AudioManager.RINGER_MODE_SILENT -> Ringer.SILENT
                AudioManager.RINGER_MODE_VIBRATE -> Ringer.VIBRATE
                else -> Ringer.NORMAL
            }
            AudioState(
                ringer = ringer,
                systemVol = m.getStreamVolume(AudioManager.STREAM_SYSTEM),
                systemMuted = try { m.isStreamMute(AudioManager.STREAM_SYSTEM) } catch (_: Exception) { false },
                mediaVol = m.getStreamVolume(AudioManager.STREAM_MUSIC),
                mediaMuted = try { m.isStreamMute(AudioManager.STREAM_MUSIC) } catch (_: Exception) { false },
            )
        } catch (_: Exception) { null }
    }

    private fun playNow(e: Sfx, v: Voice, volume: Float, paths: List<SoundPath>) {
        try {
            if (!voiceSet || voice != v) { releaseNow(); voice = v; voiceSet = true }
            compat.play(e, volume.coerceIn(0f, 1f), paths)
        } catch (ex: Throwable) {
            Journal.add("ses: beklenmeyen hata ${ex.javaClass.simpleName}")
        }
    }

    /** Çalma sırasındaki işlerden sonra çalışır (sıra korunur); ana iş parçacığını bekletmez. */
    fun release() { handler.post { releaseNow() } }

    /** Etkinlik yok olurken: bekleyen işler bitince sesleri bırakır ve iş parçacığını kapatır. */
    fun shutdown() {
        closed = true
        handler.post { releaseNow(); try { tone?.release() } catch (_: Exception) {}; tone = null; worker.quitSafely() }
    }

    private fun releaseNow() {
        for (t in statics.values) safe { t.release() }
        statics.clear()
        for (t in streams) safe { t.release() }
        streams.clear()
        pcmCache.clear()
    }

    /** Ön sessizlikli ya da sessizliksiz PCM ([pre] ms). Anahtar: efekt × (ön sessizlik var mı). */
    private fun pcm(e: Sfx, pre: Int): ShortArray {
        val key = e.ordinal * 2 + (if (pre > 0) 1 else 0)
        pcmCache[key]?.let { return it }
        val base = pcmCache[e.ordinal * 2] ?: Synth.render(e, voice).also { peakLog(e, it); pcmCache[e.ordinal * 2] = it }
        if (pre <= 0) return base
        val lead = pre * Synth.RATE / 1000
        val out = ShortArray(lead + base.size)
        System.arraycopy(base, 0, out, lead, base.size)
        pcmCache[key] = out
        return out
    }

    /** Sentezlenen sesin tepe genliği: sessizse (hepsi sıfır) sorun sentezde demektir. Her efekt için bir kez yazılır. */
    private val peaked = HashSet<Sfx>()
    private fun peakLog(e: Sfx, d: ShortArray) {
        if (!peaked.add(e)) return
        var peak = 0
        for (x in d) { val a = kotlin.math.abs(x.toInt()); if (a > peak) peak = a }
        Journal.add("ses tanı: ${e.name} örnek=${d.size} tepe=$peak")
    }

    /** Sistem ses durumu: sistem/medya seviyesi, sessize alma, zil modu. Her oturumda bir kez, ilk başarılı çalmada yazılır. */
    private fun diagOnce(t: AudioTrack?) {
        if (diagSent) return
        diagSent = true
        try {
            val m = am ?: run { Journal.add("ses tanı: AudioManager yok"); return }
            val sys = m.getStreamVolume(AudioManager.STREAM_SYSTEM)
            val sysMax = m.getStreamMaxVolume(AudioManager.STREAM_SYSTEM)
            val med = m.getStreamVolume(AudioManager.STREAM_MUSIC)
            val medMax = m.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val sysMute = try { m.isStreamMute(AudioManager.STREAM_SYSTEM) } catch (_: Exception) { false }
            val musicMute = try { m.isStreamMute(AudioManager.STREAM_MUSIC) } catch (_: Exception) { false }
            val dev = try { t?.routedDevice?.type ?: -1 } catch (_: Exception) { -2 }
            Journal.add("ses tanı: sistem=$sys/$sysMax sessiz=$sysMute, medya=$med/$medMax sessiz=$musicMute, zil=${m.ringerMode}, çıkış=$dev, yol=${compat.best?.name}")
        } catch (ex: Exception) {
            Journal.add("ses tanı hatası: ${ex.javaClass.simpleName}")
        }
    }

    private fun audio(usage: Int, content: Int) = AudioAttributes.Builder().setUsage(usage).setContentType(content).build()

    private fun format() = AudioFormat.Builder()
        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
        .setSampleRate(Synth.RATE)
        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
        .build()

    private fun durationMs(frames: Int): Long = frames * 1000L / Synth.RATE

    /**
     * Çalma kafasını izler: ses bittiyse (ya da [deadline] geçtiyse) [done] çağrılır. Kafa hiç ilerlemediyse yol "sessiz başarı"
     * sayılır. Ölü iş parçacığında (kapatıldıysa) sessizce biter.
     */
    private fun watch(t: AudioTrack, path: SoundPath, frames: Int, firstCheckMs: Long, deadline: Long, tokenKey: Int = -1, tokenVal: Long = 0L, done: () -> Unit) {
        val check = object : Runnable {
            var reported = false
            override fun run() {
                if (tokenKey >= 0 && staticTokens[tokenKey] != tokenVal) {
                    done(); return   // daha yeni bir dokunuş başladı: eski çalmanın sıfırlanan kafası sahte arıza sayılmaz
                }
                val head = try { t.playbackHeadPosition } catch (_: Exception) { -1 }
                if (!reported && head > 0) { reported = true; compat.rendered(path) }
                val now = SystemClock.uptimeMillis()
                if (head >= frames || head < 0 || now >= deadline) {
                    if (!reported && head == 0) compat.stalled(path)
                    done()
                    return
                }
                handler.postDelayed(this, WATCH_STEP_MS)
            }
        }
        handler.postDelayed(check, firstCheckMs)
    }

    private inner class Backend : SoundBackend {
        override fun play(path: SoundPath, e: Sfx, volume: Float): Boolean {
            val now = SystemClock.uptimeMillis()
            val pre = if (path == SoundPath.TONE) 0 else warm.preRoll(now)
            val ok = when (path) {
                SoundPath.STATIC_RELOAD -> playStatic(e, volume, pre)
                SoundPath.STREAM_SONIFICATION -> playStream(e, volume, AudioAttributes.USAGE_ASSISTANCE_SONIFICATION, path, pre)
                SoundPath.STREAM_MEDIA -> playStream(e, volume, AudioAttributes.USAGE_MEDIA, path, pre)
                SoundPath.TONE -> playTone(volume)
            }
            if (ok) warm.played(now, if (path == SoundPath.TONE) 90L else durationMs(pcm(e, pre).size))
            return ok
        }

        /**
         * Statik tampon. Başa sarmak için yalnızca durdurup yeniden yüklemek kullanılır (setPlaybackHeadPosition bazı cihazlarda
         * istisna atar; eski sürümde bu istisna play() çağrısını atlatıp sessizliğe yol açıyordu). Her adım ayrı kontrol edilir.
         */
        private fun playStatic(e: Sfx, volume: Float, pre: Int): Boolean {
            val key = e.ordinal * 2 + (if (pre > 0) 1 else 0)
            val t: AudioTrack = statics[key]?.takeIf { it.state == AudioTrack.STATE_INITIALIZED } ?: buildStatic(e, pre, key) ?: return false
            if (t.playState == AudioTrack.PLAYSTATE_PLAYING) safe { t.stop() }
            val rl = t.reloadStaticData()
            if (rl != AudioTrack.SUCCESS) { Journal.add("statik: yeniden yükleme $rl"); dropStatic(key); return false }
            t.setVolume(volume)
            t.play()
            val ok = t.playState == AudioTrack.PLAYSTATE_PLAYING
            if (!ok) { Journal.add("statik: play sonrası durum ${t.playState}"); return false }
            diagOnce(t)
            val frames = pcm(e, pre).size
            val dur = durationMs(frames)
            // Statik izde kafa sona ulaşınca durur; izlemenin tek amacı "sessiz başarıyı" yakalamak.
            val curToken = SystemClock.uptimeMillis()
            staticTokens[key] = curToken
            watch(t, SoundPath.STATIC_RELOAD, frames, minOf(dur, 250L) + 120L, SystemClock.uptimeMillis() + dur + 1500L, key, curToken) {}
            return true
        }

        private fun buildStatic(e: Sfx, pre: Int, key: Int): AudioTrack? {
            val data = pcm(e, pre)
            val t = try {
                AudioTrack.Builder()
                    .setAudioAttributes(audio(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION, AudioAttributes.CONTENT_TYPE_SONIFICATION))
                    .setAudioFormat(format())
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
            } catch (_: Exception) { return null }
            if (t.state != AudioTrack.STATE_INITIALIZED || t.write(data, 0, data.size) != data.size) { safe { t.release() }; return null }
            statics[key] = t
            return t
        }

        private fun dropStatic(key: Int) {
            statics.remove(key)?.let { t -> safe { t.release() } }
        }

        /**
         * Her çalmada yeni akış: en uyumlu yol. Önce veri yazılır (tampon dolu başlar, ilk anda boşluk olmaz), sonra çalınır.
         * İz, çalma kafası sona varınca bırakılır; yüksek gecikmeli çıkışta (Bluetooth) sesin sonu kesilmez.
         */
        private fun playStream(e: Sfx, volume: Float, usage: Int, path: SoundPath, pre: Int): Boolean {
            val data = pcm(e, pre)
            val t = try {
                AudioTrack.Builder()
                    .setAudioAttributes(audio(usage, AudioAttributes.CONTENT_TYPE_SONIFICATION))
                    .setAudioFormat(format())
                    .setBufferSizeInBytes(maxOf(data.size * 2, minBuffer()))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } catch (_: Exception) { return false }
            if (t.state != AudioTrack.STATE_INITIALIZED) { safe { t.release() }; return false }
            streams.add(t)
            t.setVolume(volume)
            val n = try { t.write(data, 0, data.size, AudioTrack.WRITE_NON_BLOCKING) } catch (_: Exception) { -1 }
            if (n <= 0) { Journal.add("akış: yazma $n"); finishStream(t); return false }
            t.play()
            if (t.playState != AudioTrack.PLAYSTATE_PLAYING) { Journal.add("akış: play sonrası durum ${t.playState}"); finishStream(t); return false }
            if (n < data.size) {                       // tampon küçük kaldıysa kalan, çalarken yazılır (iş parçacığında, bloklayarak)
                safe { t.write(data, n, data.size - n) }
            }
            diagOnce(t)
            val dur = durationMs(data.size)
            watch(t, path, data.size, dur + 60L, SystemClock.uptimeMillis() + dur + STREAM_SLACK_MS) { finishStream(t) }
            return true
        }

        private fun finishStream(t: AudioTrack) {
            if (!streams.remove(t)) return
            safe { t.stop() }
            safe { t.release() }
        }

        /** Son çare: sistemin bip sesi. Sentezlenmiş tını yok, ama yanıt verildiği duyulur. */
        private fun playTone(volume: Float): Boolean {
            val vol = (volume * 100).toInt().coerceIn(1, 100)
            var g = tone
            if (g == null || toneVol != vol) {             // ses seviyesi yalnızca oluştururken verilir: değişince yeniden kurulur
                safe { g?.release() }
                g = try { ToneGenerator(AudioManager.STREAM_MUSIC, vol) } catch (_: Exception) { null } ?: return false
                tone = g; toneVol = vol
            }
            return g.startTone(ToneGenerator.TONE_PROP_BEEP, 90)
        }
    }

    private fun minBuffer(): Int = try {
        AudioTrack.getMinBufferSize(Synth.RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(0)
    } catch (_: Exception) { 0 }

    private inline fun safe(block: () -> Unit) { try { block() } catch (_: Exception) {} }

    private companion object {
        const val MAX_PENDING = 4
        const val KEY = "path"
        const val WATCH_STEP_MS = 60L
        /** Akış izinin en geç bırakılacağı süre (ses süresinin üstüne). Bluetooth gecikmesi 300 ms'yi bulabilir. */
        const val STREAM_SLACK_MS = 1_500L
    }
}
