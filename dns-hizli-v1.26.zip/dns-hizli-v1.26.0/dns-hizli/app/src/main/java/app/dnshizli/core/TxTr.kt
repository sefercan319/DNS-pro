package app.dnshizli.core

/** Türkçe (varsayılan ve kaynak dil). */
object TxTr : Tx() {
    override val lang = Lang.TR

    override val decimalSep = ','
    override val thousand = " bin"
    override val million = " mn"
    override fun percent(n: Int) = "%$n"
    override val dayU = "gün"
    override val hourU = "sa"
    override val minU = "dk"
    override val secU = "sn"
    override val justNow = "az önce"
    override fun ago(span: String) = "$span önce"

    override val OFF = "Bağlı değil"
    override val CONNECTING = "Bağlanıyor…"
    override val ON = "Bağlı"
    override val ERROR = "Bağlanamadı"
    override val PAUSED = "Duraklatıldı"
    override val HINT_OFF = "Bağlanmak için küreye dokun"
    override val HINT_CONNECTING = "Birkaç saniye sürebilir"
    override val HINT_ERROR = "Tekrar denemek için dokun"
    override val HINT_PAUSED = "Hemen devam etmek için dokun"
    override val ERR_DEFAULT = "Bağlantı kurulamadı"
    override fun selected(name: String) = "$name seçili"
    override fun pausedUntil(time: String) = "Devam: $time"
    override fun blockedShort(n: String) = "$n engellendi"
    override fun queriesShort(n: String) = "$n sorgu"
    override fun cacheShort(pct: String) = "$pct önbellek"

    override val SERVERS = "Sunucular"
    override val FILTER_ALL = "Tümü"
    override val FILTER_FAV = "Favoriler"
    override val FILTER_RECENT = "Son kullanılan"
    override val EMPTY_FAV = "Henüz favori yok. Bir sunucunun yıldızına dokun."
    override val EMPTY_RECENT = "Henüz bir sunucuya bağlanmadın."
    override val EMPTY_FILTER = "Bu kategoride sunucu yok."
    override val MEASURE = "Hızları ölç"
    override val MEASURING = "Ölçülüyor…"
    override val SORT = "Sıralama"
    override val PULL_TO_MEASURE = "Hızları ölçmek için çek"
    override val RELEASE_TO_MEASURE = "Bırak, ölçülsün"
    override fun serversCount(n: Int) = "$n sunucu"
    override fun showAllServers(n: Int) = "Tümünü göster ($n)"
    override val SHOW_LESS = "Daha az göster"
    override val TAG_FAST = "Hızlı"
    override val TAG_PRIVACY = "Gizlilik"
    override val TAG_ADS = "Reklam"
    override val TAG_FAMILY = "Aile"
    override val TAG_SECURITY = "Güvenlik"
    override val VAR_OPEN = "Filtresiz"
    override val VAR_ADS = "Reklam"
    override val VAR_SECURITY = "Güvenlik"
    override val VAR_FAMILY = "Aile"
    override val A11Y_CONNECTED = "bağlı"
    override val A11Y_ENCRYPTED = "şifreli"
    override fun favA11y(name: String) = "$name favori"

    override val COPIED = "Panoya kopyalandı"
    override val DISCONNECTED = "Bağlantı kesildi"
    override val BACKUP = "Yedek sunucuya geçildi"
    override val NO_REPLY = "Hiçbir sunucu yanıt vermedi"
    override val MEASURE_FIRST = "Önce hızları ölç"
    override val CONNECT = "Bağlan"
    override val UNDO = "Geri al"
    override fun fastest(name: String, ms: Int) = "En hızlı: $name · $ms ms"
    override fun switched(name: String) = "$name sunucusuna geçiliyor"
    override fun hiddenToast(name: String) = "$name gizlendi"

    override val PRIMARY = "Birincil"
    override val SECONDARY = "İkincil"
    override val COPY = "Kopyala"
    override fun addressA11y(label: String, ip: String) = "$label adres: $ip"
    override val CONNECT_TO_THIS = "Bu sunucuya bağlan"
    override val SWITCH_TO_THIS = "Bu sunucuya geç"
    override val CONNECTED_NOW = "Şu an bağlı"
    override val ADD_FAV = "Favori yap"
    override val REMOVE_FAV = "Favoriden çıkar"
    override val MEASURE_THIS = "Hızı ölç"
    override val HIDE = "Listeden gizle"
    override val UNHIDE = "Listede göster"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Son ölçüm: yanıt yok · $ago" else "Son ölçüm: $ms ms · $ago"
    override val NEVER_MEASURED = "Henüz ölçülmedi"
    override val ENC_SUPPORT = "Şifreli DNS"
    override val ENC_NONE = "Desteklemiyor"
    override val ENC_ONLY = "Yalnızca şifreli bağlantı kabul eder"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "En iyi $best ms · ortanca $median ms · kayıp %$lossPct"
    override val HISTORY = "Ölçüm geçmişi"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: $n ölçüm, yanıt yok" else "$HISTORY: $n ölçüm, ortanca $median ms"

    override val QUICK_TITLE = "Hızlı seçim"
    override val QUICK_FAVORITES = "Favoriler"
    override val QUICK_RECENT = "Son kullanılanlar"
    override val PAUSE_FOR = "Duraklat"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} sa" else "$n dk"
    override val RESUME = "Devam et"

    override val SETTINGS = "Ayarlar"
    override val MENU = "Menü"
    override val PERSONALIZE = "Kişiselleştirme"
    override val PZ_BACKGROUND = "Arka plan"
    override val PZ_AUTO = "Otomatik tema"
    override val PZ_FEEL = "Cam, yazı ve hareket"
    override val PZ_ACCESS = "Erişilebilirlik ve güç"
    override val DNS_SETTINGS = "DNS ayarları"
    override val CONN_APPS = "Bağlantı ve uygulamalar"
    override val STATS_HISTORY = "İstatistikler ve geçmiş"
    override val SEC_LOOK = "Görünüm"
    override val SEC_LIST = "Sunucu listesi"
    override val SEC_DATA = "Veriler"
    override val ABOUT = "Hakkında"
    override val LANGUAGE = "Dil"
    override val LANG_AUTO = "Otomatik (sistem dili)"
    override val THEME = "Tema"
    override val THEME_AUTO = "Otomatik"
    override val THEME_AUTO_NOTE = "Otomatik · sistemin açık/koyu ayarını izler"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Aqua"
        "meadow" -> "Çimen"
        "ocean" -> "Okyanus"
        "sunset" -> "Gün batımı"
        "lavender" -> "Lavanta"
        "coral" -> "Mercan"
        "mint" -> "Nane"
        "sakura" -> "Sakura"
        "honey" -> "Bal"
        "night" -> "Gece"
        "amoled" -> "Siyah (AMOLED)"
        "aurora" -> "Kuzey ışıkları"
        "dynamic" -> "Duvar kağıdı"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Tema: $name"
    override val THEME_SCHEDULE = "Gece temasını saate bağla"
    override val THEME_SCHEDULE_NOTE = "Otomatik temada seçtiğin saatlerde koyu tema"
    override val GLASS = "Cam şeffaflığı"
    override val BUBBLES = "Kabarcıklar"
    override val STYLE = "Stil"
    override val STYLE_NOTES = listOf(
        "Camsı, parlak, kabarcıklı: ilk tasarım.",
        "Gökyüzü, yeşil çimen, cam damlaları ve jel düğmeler.",
        "Şehir, müzik ve gençlik: gökdelenler, hoparlör, halkalar, yıldızlar ve ışınlar.",
        "Doğa ve teknoloji: yeşil Dünya, rüzgâr türbinleri, güneş panelleri ve yapraklar.",
        "Holografik pembe ve mor, krom kalpler, baloncuklar, parıltılar ve piksel pencereler.",
        "Turkuaz, yeşil ve sarı ışık, parlak ışık hüzmesi ve saydam tel kafes dalgalar.",
        "Yarı saydam mavi-mor cam, parlak beyaz kenar ışığı ve kırılan ışık parıltıları.",
            "Modern ve sade koyu füme cam, elektrik mavisi neon hatlar (DeepSeek esintisi).",
    )
    override val WALLPAPER = "Arka plan fotoğrafı"
    override val WP_OFF = "Yok"
    override val WP_ON = "Fotoğraf"
    override val WP_PICK = "Galeriden fotoğraf seç"
    override val WP_PICK_NOTE = "Yalnızca telefonda kalır, internete gitmez. Yazılar okunsun diye perde gerekirse kendiliğinden güçlenir."
    override val WP_PRESETS = "Hazır görseller"
    override val WP_PRESETS_NOTE = "Uygulamayla gelen 8 görsel. İnternet gerekmez."
    override val WP_REMOVE = "Fotoğrafı kaldır"
    override val WP_DIM = "Perde yoğunluğu"
    override val WP_BLUR = "Bulanıklık"
    override val OPT_WP_BLUR = listOf("Yok", "Hafif", "Güçlü")
    override val WP_SAVED = "Arka plan ayarlandı"
    override val WP_FAILED = "Fotoğraf açılamadı"
    override val WP_REMOVED = "Arka plan kaldırıldı"
    override val APP_ICON = "Uygulama simgesi"
    override val ICON_NOTES = listOf(
        "Cam küre: ilk simge.",
        "Gökyüzü ve çimen üstünde cam damla.",
        "Lime-turkuaz şehir, güneş ışınları ve güç düğmesi.",
        "Filiz veren yapraklı parlak yeşil Dünya.",
        "Holografik pembe-mor zeminde parlak krom kalp.",
        "Turkuazdan sarıya ışık ve dalgalar üstünde cam küre.",
        "Mavi-mor ışık üstünde parlak kenarlı buzlu cam küre.",
            "Koyu gece mavisi zeminde elektrik mavisi parlayan minimalist kalkan.",
    )
    override val ICON_SET = "Simge uygulamadan çıkınca değişir"
    override val ICON_NOTE = "Ana ekrandaki kısayol kaybolursa uygulamayı yeniden ekle."
    override val ICON_FAILED = "Simge değiştirilemedi"
    override val HELP_WHY_TITLE = "Neden bu uygulama?"
    override val HELP_WHY_BODY = "DNS Hızlı küçük ve sade bir uygulama; tek bir kişi yapıyor, arkasında büyük bir şirket yok. Hesap ve reklam yok: DNS'ini, şifrelemeyi, hangi uygulamalara uygulanacağını ve görünümünü sen seçersin."
    override val HELP_WHY_TAIL = "Belki rakiplerinden daha iyi değil, ama işe yarıyor; en azından denemeye değer."
    override val TROUBLE = "Sorun gider"
    override val TROUBLE_RECHECK = "Yeniden denetle"
    override val TROUBLE_ALL_OK = "Her şey yolunda görünüyor. Yine de bağlanamıyorsan başka bir sunucu dene."
    override val TROUBLE_SOME = "Dikkat gereken şeyler var:"
    override val T_NET = "İnternet"
    override val NET_OK = "bağlantı var."
    override val NET_BAD = "yok ya da sınırlı görünüyor. Wi-Fi veya mobil veriyi kontrol et."
    override val T_PERM = "VPN izni"
    override val PERM_OK = "verilmiş."
    override val PERM_BAD = "henüz verilmedi. Bağlanmayı denediğinde Android soracak; onay ver."
    override val T_VPN = "Başka VPN"
    override val VPN_OK = "yok."
    override val VPN_BAD = "açık görünüyor. Android aynı anda tek VPN'e izin verir; onu kapat."
    override val T_DNS = "Android Özel DNS"
    override val PDNS_OK = "kapalı ya da otomatik, sorun yok."
    override val PDNS_BAD = "belirli bir sunucuya sabitlenmiş; bu uygulamanın DNS'ini atlayabilir. Ayarlar > Ağ > Özel DNS'te Otomatik ya da Kapalı seç."
    override val SEARCH = "Ara"
    override val SEARCH_HINT = "Sunucu adı ya da sahibi"
    override val SEARCH_CLEAR = "Temizle"
    override val SHARE_RESULTS = "Ölçüm sonuçlarını paylaş"
    override val SHARE_RESULTS_HEAD = "DNS Hızlı ölçümleri (en hızlıdan)"
    override val NO_RESULTS = "Önce bir ölçüm yap"
    override val CUSTOM_EDIT = "Düzenle"
    override fun customUpdated(name: String) = "$name güncellendi"
    override val KEEP_HISTORY = "Geçmişi tut"
    override val KEEP_HISTORY_NOTE = "Kapalıyken son kullanılanlar, geçmiş ve ölçümler kaydedilmez. Var olanlar silinmez."
    override val MOTION = "Animasyonlar"
    override val TEXT_SIZE = "Yazı boyutu"
    override val HIGH_CONTRAST = "Yüksek kontrast"
    override val HIGH_CONTRAST_NOTE = "Daha opak cam ve daha koyu yazılar"
    override val MINIMAL = "Sade görünüm"
    override val MINIMAL_NOTE = "Süzgeçleri ve istatistik satırını gizler"
    override val LOW_POWER = "Düşük güç modu"
    override val LOW_POWER_NOTE = "Tüm hareketleri kapatır, pil dostu"
    override val HAPTICS = "Titreşim"
    override val HAPTICS_NOTE = "Dokunuşlarda hafif geri bildirim"
    override val ENCRYPTION = "Şifreli DNS"
    override val ENCRYPTION_NOTE = "Otomatik: önce DoT, olmazsa DoH, en son düz DNS"
    override val AUTO_CONNECT = "Uygulama açılınca bağlan"
    override val AUTO_CONNECT_NOTE = "Uygulamayı açtığında son sunucuya bağlanır"
    override val CONNECT_ON_BOOT = "Telefon açılınca bağlan"
    override val CONNECT_ON_BOOT_NOTE = "Telefon yeniden başlayınca kendiliğinden bağlanır"
    override val AUTO_FASTEST = "En hızlıya bağlan"
    override val AUTO_FASTEST_NOTE = "Küreye dokununca son ölçüme göre en hızlı sunucu seçilir"
    override val REFRESH_ON_NET = "Ağ değişince yenile"
    override val REFRESH_ON_NET_NOTE = "Wi-Fi ve mobil veri arasında geçişte DNS yenilenir"
    override val NOTIFY_DROP = "Bağlantı koparsa bildir"
    override val NOTIFY_DROP_NOTE = "Beklenmedik kopmada yeniden bağlan düğmeli bildirim"
    override val NOTIFY_CONNECT = "Bağlanınca bildir"
    override val NOTIFY_CONNECT_NOTE = "Bağlantı kurulunca kısa bir bildirim"
    override val NOTIFY_STOP = "Kesilince bildir"
    override val NOTIFY_STOP_NOTE = "Bağlantıyı sen kesince kısa bir bildirim"
    override val NOTIFY_TIMEOUT = "Zaman aşımında bildir"
    override val NOTIFY_TIMEOUT_NOTE = "DNS sunucusu yanıt vermezse bildirim"
    override val NOTIF_PERM = "Sistem bildirim izni"
    override val PERM_ALLOWED = "Açık"
    override val PERM_BLOCKED = "Kapalı · düzelt"
    override val NOTIF_CONNECTED_TITLE = "DNS bağlandı"
    override val NOTIF_STOPPED_TITLE = "DNS bağlantısı kesildi"
    override val NOTIF_STOPPED_TEXT = "Koruma kapalı"
    override val NOTIF_TIMEOUT_TITLE = "DNS zaman aşımına uğradı"
    override val FAIL_CLOSED = "Kapalı kalırsa dur"
    override val FAIL_CLOSED_NOTE = "Bağlantı koparsa DNS sorguları operatöre sızmaz; yeniden bağlanana dek cevapsız kalır"
    override val FILTER_MEM = "Filtre belleği"
    override val OPT_FILTER_MEM = listOf("Otomatik", "Hafif", "Tam")
    override val FILTER_MEM_NOTE = "Otomatik: az bellekte büyük liste atlanır. Hafif: hep atlanır. Tam: hep yüklenir"
    override val ERR_NO_APPS = "Seçili uygulama yok, koruma başlatılmadı. Uygulama seçin ya da “Tüm uygulamalar”a geçin."
    override val NOTIF_SEALED = "Yeniden bağlanırken DNS durduruldu"
    override val ERR_SEALED = "Bağlanılamadı. Sorgular sızmasın diye DNS durduruldu; serbest bırakmak için Kes'e dokun."
    override val SEALED_INFO = "Bağlantı dönene dek DNS durduruldu"
    override val LATENCY_TITLE = "Sorgu başına gecikme"
    override val LATENCY_EMPTY = "Bağlanınca ve sorgular geldikçe canlı görünür"
    override val FILTER_MINE = "Kendi listem"
    override val MINE_PASTE = "Panodan içe aktar"
    override val MINE_PASTE_NOTE = "hosts dosyası ya da satır başına bir alan adı"
    override val MINE_FILE = "Dosyadan içe aktar"
    override val MINE_FILE_NOTE = "Telefondaki .txt ya da hosts dosyası"
    override val MINE_EXPORT = "Engel listemi kopyala"
    override val MINE_EXPORT_NOTE = "hosts biçiminde panoya"
    override val MINE_CLEAR = "İçe aktarılanları sil"
    override val MINE_FOOT = "hosts satırları (0.0.0.0 alanadı), düz alan adı listeleri ve ||alanadı^ kuralları okunur. En çok 50.000 ad. İzin listen her zaman üstündür."
    override val MINE_NOTHING = "Geçerli alan adı bulunamadı"
    override val MINE_CLIP_EMPTY = "Pano boş"
    override val MINE_FILE_ERR = "Dosya okunamadı"
    override val MINE_CLEARED = "İçe aktarılan liste silindi"
    override val MINE_CLEAR_ASK = "İçe aktarılan liste silinsin mi?"
    override val MINE_CUT = "Sınıra ulaşıldı, fazlası alınmadı"
    override fun notifTimeout(name: String) = "$name yanıt vermiyor. Yeniden deneniyor."
    override val MOD_DPI = "DPI atlatma"
    override val MOD_ADS = "Reklam+"
    override val MOD_DPI_SUB = "Engelli siteleri açar"
    override val MOD_ADS_SUB = "DNS'ten bağımsız keser"
    override val MOD_ON = "Açık"
    override val MOD_OFF = "Kapalı"
    override val BLOCK_QUIC = "QUIC'i engelle"
    override val BLOCK_QUIC_NOTE = "Uygulamalar TCP'ye döner; DPI atlatma ve Reklam+ onları da kapsar"
    override val GW_TRIPPED = "Bağlantı sorunu algılandı: DPI atlatma ve Reklam+ kapatıldı"
    override val MOD_FAILED = "Açılamadı. VPN izni verilmedi ya da başka bir VPN açık."
    override fun gwOn(modules: String) = "Ağ geçidi açık: $modules"
    override fun gwOnStats(modules: String, blocked: String) = "Ağ geçidi açık: $modules · $blocked engellendi"
    override fun modOn(name: String) = "$name açıldı"
    override fun modOff(name: String) = "$name kapatıldı"
    override fun modAdsCount(n: String) = "$n engellendi"
    override fun modDpiCount(n: String) = "$n bağlantı bölündü"
    override fun latencyLine(avg: String, max: String, timeouts: Int) = "ort. $avg · en çok $max" + (if (timeouts > 0) " · $timeouts zaman aşımı" else "")
    override fun mineCount(n: Int) = "$n alan adı"
    override fun mineAdded(n: Int) = "$n alan adı eklendi"
    override fun mineCopied(n: Int) = "$n alan adı kopyalandı"
    override val CACHE = "DNS önbelleği"
    override val CLEAR_CACHE = "Önbelleği temizle"
    override val CACHE_CLEARED = "Önbellek temizlendi"
    override val ONLY_CONNECTED = "Bağlıyken kullanılabilir"
    override val RULE_WIFI = "Wi-Fi sunucusu"
    override val RULE_MOBILE = "Mobil veri sunucusu"
    override val RULE_AUTO = "Otomatik"
    override val RULE_AUTO_NOTE = "Son kullandığın sunucu"
    override val COMPACT = "Sıkı liste"
    override val COMPACT_NOTE = "Daha kısa satırlar, açıklamasız"
    override val HIDDEN = "Gizlenen sunucular"
    override val HIDDEN_NONE = "Yok"
    override fun modWindow(count: String) = "Son 10 dk: $count"
    override val STAT_QUERIES = "Toplam sorgu"
    override val STAT_HITS = "Önbellekten yanıt"
    override val STAT_BLOCKED = "Engellenen (tahmini)"
    override val STAT_TIME = "Toplam bağlı kalma"
    override val WEEK = "Son 7 gün"
    override fun weekA11y(total: String) = "Son 7 günde $total sorgu"
    override val WEEKDAYS = listOf("Pt", "Sa", "Ça", "Pe", "Cu", "Ct", "Pz")
    override val EXPORT = "Ayarları dışa aktar"
    override val IMPORT = "Ayarları içe aktar"
    override val EXPORTED = "Ayar kodu panoya kopyalandı"
    override val IMPORTED = "Ayarlar yüklendi"
    override val IMPORT_BAD = "Panoda geçerli bir ayar kodu yok"
    override val RESET_SETTINGS = "Ayarları sıfırla"
    override val RESET_STATS = "İstatistikleri sıfırla"
    override val CONFIRM = "Emin misin?"
    override val RESET = "Sıfırla"
    override val RESET_DONE = "Sıfırlandı"
    override val LOG = "Tanılama günlüğü"
    override val HELP = "Nasıl çalışır?"
    override val VPN_SETTINGS = "Sistem VPN ayarları"
    override val SHARE_APP = "Uygulamayı paylaş"
    override val RATE_APP = "Uygulamayı değerlendir"
    override val FEEDBACK = "Geri bildirim gönder"
    override fun shareAppText(url: String) = "Popüler DNS sunucularına tek dokunuşla bağlanmak için $APP: $url"
    override val VERSION = "Sürüm"
    override val OPT_BUBBLES = listOf("Kapalı", "Az", "Çok")
    override val OPT_MOTION = listOf("Tam", "Az", "Kapalı")
    override val OPT_CACHE = listOf("Kapalı", "Küçük", "Normal", "Büyük")
    override val OPT_ENCRYPTION = listOf("Otomatik", "DoT", "DoH", "Kapalı")
    override val PLAIN_DNS = "Düz DNS"

    override val LOG_NOTE = "Yalnızca bağlantı olayları tutulur. Sorgu adları ve kişisel veri kaydedilmez."
    override val LOG_EMPTY = "Henüz kayıt yok."
    override val SHARE = "Paylaş"
    override val CLEAR = "Temizle"
    override val CLEARED = "Temizlendi"
    override val HELP_SECTIONS = listOf(
        "DNS nedir?" to
            "DNS, internet adreslerini (örneğin ornek.com) cihazların anladığı numaralara çeviren servistir. " +
            "Kullandığın DNS; hızı, gizliliği ve engellenen içerikleri etkileyebilir.",
        "Uygulama ne yapar?" to
            "Seçtiğin DNS sunucusunu tüm uygulamalarda kullanır. Bunun için telefonunda yerel bir VPN arayüzü açar; " +
            "ama trafiğin bir VPN sunucusuna gitmez. Yalnızca DNS sorguları seçtiğin sunucuya yönlendirilir, " +
            "diğer her şey normal yolundan devam eder.",
        "Şifreli DNS (DoT / DoH)" to
            "Destekleyen sunucularda sorgular şifreli gönderilir: ağdaki kimse (Wi-Fi sahibi, operatör) hangi sitelere " +
            "girdiğini göremez ve sorgularla oynayamaz. Otomatik ayarda önce DoT, olmazsa DoH denenir; ikisi de olmazsa düz " +
            "DNS'e geçilir, bu durumda uyarılırsın ve uygulama her ağ değişiminde ve 10 dakikada bir şifreli yönteme " +
            "dönmeyi dener. \"Sıkı şifreleme\" açıksa şifresiz DNS'e hiç geçilmez. Ana ekranda hangi yöntemin kullanıldığı yazar.",
        "Bağlantı testi" to
            "☰ > DNS ayarları > Bağlantıyı test et: tünelin içinden gerçek DNS soruları gönderir. DNS'in gerçekten " +
            "seçtiğin sunucudan cevap verdiğini, yanıt süresini, sunucunun DNSSEC imzalarını doğrulayıp doğrulamadığını ve " +
            "bilinen bir reklam alan adını engelleyip engellemediğini gösterir.",
        "Gizlilik" to
            "Hesap istemez, veri toplamaz, reklam göstermez. Uygulama sorgu adlarını kaydetmez ve kendi adına hiçbir yere göndermez. " +
            "Sorguların yalnızca seçtiğin DNS sağlayıcısına gider; sağlayıcının kendi gizlilik politikası geçerlidir. " +
            "Şifreli DNS'te (DoT/DoH) ağdaki kimse sorgularını okuyamaz, değiştiremez. Uygulama göndermeden önce cihazını ele verebilecek ek verileri (istemci alt ağı, çerez, cihaz kimliği) siler, mesaj uzunluklarını doldurarak gizler ve ağ değişince TLS oturum biletlerini atar. " +
            "Dürüst olmak gerekirse: araya bir röle koymadığımız için DNS sağlayıcısı herkese açık IP adresini yine görür (sana cevap vermesi gerek); sertifika hatası da birinin bağlantıya karıştığı anlamına gelebilir. " +
            "Tanılama günlüğünde yalnızca bağlantı olayları bulunur.",
        "Pil ve kaynak" to
            "Arka planda çok az kaynak kullanır. Ekran kapalıyken sürekli çalışan bir döngüsü yoktur; " +
            "yalnızca DNS sorgusu geldiğinde iş yapar. Şifreli bağlantılar boşta kalınca kendiliğinden kapanır.",
        "Bilmen gerekenler" to
            "Android aynı anda yalnızca bir VPN'e izin verir; başka bir VPN uygulaması açıkken bu uygulama bağlanamaz. " +
            "Bazı tarayıcılardaki \"güvenli DNS\" ayarı ve Android'in belirli bir sunucu adına sabitlenmiş \"Özel DNS\" ayarı, " +
            "kendi sunucusunu kullandığı için bu yönlendirmeyi atlayabilir; \"Otomatik\" ya da \"Kapalı\" bırakman yeterli. " +
            "Küreye uzun basarak sık kullandığın sunuculara hızla geçebilir ya da bağlantıyı kısa süre duraklatabilirsin.",
    )

    override val NOTIF_CHANNEL = "Bağlantı durumu"
    override val NOTIF_CHANNEL_NOTE = "DNS bağlantısı açıkken gösterilen bildirim"
    override val NOTIF_ALERT_CHANNEL = "Bağlantı uyarıları"
    override val NOTIF_CONNECTING = "Bağlanıyor…"
    override val NOTIF_STOP = "Kes"
    override val NOTIF_NEXT = "Sonraki"
    override val NOTIF_DROP_TITLE = "DNS bağlantısı koptu"
    override val NOTIF_RECONNECT = "Yeniden bağlan"
    override fun notifOn(name: String, proto: String) = "$name sunucusuna bağlı · $proto"
    override fun notifPaused(time: String) = "Duraklatıldı · devam: $time"
    override val TILE_ON = "Bağlı"
    override val TILE_OFF = "Kapalı"
    override val WIDGET_TAP = "Dokun: bağlan / kes"
    override val ERR_PERMISSION = "VPN izni verilmedi"
    override val ERR_ESTABLISH = "VPN arayüzü açılamadı. Başka bir VPN açık olabilir."
    override fun errNoReply(name: String) = "$name yanıt vermedi"
    override val PHONE_BYPASS = "Telefon bu DNS'i kullanmıyor (Özel DNS?)"
    override fun errNoProto(name: String, proto: String) = "$name, $proto desteklemiyor"
    override val ERR_SOCKET = "Ağ bağlantısı kurulamadı"
    override fun errPrivateDns(host: String) = "Android'in Özel DNS ayarı $host adına sabit; bu yönlendirmeyi atlıyor. Ayarlar > Ağ > Özel DNS: Otomatik ya da Kapalı yap."
    override val ERR_REVOKED = "Bağlantı sistem tarafından kapatıldı"
    override val ERR_TUNNEL = "Tünel beklenmedik şekilde kapandı"
    override val ERR_UNKNOWN = "Beklenmeyen bir hata oldu"

    override val CONSENT_TITLE = "Bağlanmadan önce"
    override val CONSENT_BODY = listOf(
        "$APP, DNS sorgularını (girdiğin sitelerin adlarını) seçtiğin DNS sunucusuna yönlendirmek için Android'in VPN arayüzünü kullanır.",
        "Trafiğin bir VPN sunucusuna gönderilmez; yalnızca DNS sorguları seçtiğin sağlayıcıya iletilir. Destekleyen sunucularda " +
            "sorgular şifrelenir (DoT/DoH); desteklemeyenlerde şifresiz gider. Sağlayıcının kendi gizlilik politikası geçerlidir." +
            " \"$MOD_DPI\" ya da \"$MOD_ADS\" modüllerini açarsan tüm trafik yalnızca telefonun içinde çalışan bir aktarıcıdan geçer; yine hiçbir yere gönderilmez.",
        "Uygulama kişisel veri toplamaz, sorgu adlarını kaydetmez ve kimseyle paylaşmaz.",
        "Devam edersen Android bir VPN bağlantı isteği gösterecek; \"Tamam\" demen gerekir.",
    )
    override val CONSENT_OK = "Anladım, devam et"
    override val CLOSE = "Kapat"
    override val BACK = "Geri"

    override val RESUMING = "Devam ediliyor…"
    override val DOWNGRADED = "Şifreli bağlantı kurulamadı, şifresiz DNS kullanılıyor"
    override val UPGRADED = "Şifreli bağlantıya dönüldü"
    override val ODOH = "Oblivious DoH (ODoH)"
    override val OPT_ODOH = listOf("Kapalı", "Yedekli", "Sıkı")
    override val ODOH_NOTE = "Röle IP'nizi görür ama soruyu görmez; sunucu soruyu görür ama sizi görmez."
    override val DOWNGRADED_ODOH = "ODoH kurulamadı, normal şifreli bağlantı kullanılıyor"
    override val NOTIF_ODOH_TITLE = "ODoH etkin değil"
    override fun notifOdoh(name: String) = "ODoH rölelerine ulaşılamadı. $name ile normal bağlantı kullanılıyor; uygulama ODoH'a dönmeyi denemeye devam edecek."
    override val ERR_NO_ODOH = "ODoH ile bağlanılamadı: röleler ya da hedefler yanıt vermiyor"
    override val NOTIF_DOWNGRADE_TITLE = "DNS şifrelenmiyor"
    override fun notifDowngrade(name: String) = "$name ile şifreli bağlantı kurulamadı. Şifresiz DNS kullanılıyor; uygulama şifreli yönteme dönmeyi deneyecek."
    override fun backupUsed(failed: String, used: String) = "$failed yanıt vermedi, $used sunucusuna bağlanıldı"
    override val NOTIF_RETRYING = "Bağlantı koptu, yeniden deneniyor…"
    override fun errNoEncrypted(name: String) = "$name ile şifreli bağlantı kurulamadı"
    override fun errUntrusted(name: String) = "$name sertifikası doğrulanamadı; ağ ya da bir yazılım şifreli bağlantıya karışıyor olabilir"
    override val APPLYING = "Yeni ayar bağlantıya uygulanıyor"
    override val CONFIRM_DISCONNECT = "Bağlantı kesilsin mi?"
    override val DISCONNECT = "Kes"

    override val SEC_NOTIF = "Bildirimler"
    override val STRICT_ENC = "Sıkı şifreleme"
    override val STRICT_ENC_NOTE = "Şifreli bağlantı kurulamazsa şifresiz DNS'e geçme"
    override val IP_MODE = "IP sürümü"
    override val IP_MODE_NOTE = "Ağında hangisi varsa o önce denenir, öbürü yedek olur"
    override val OPT_IP_MODE = listOf("IPv4 + IPv6", "Yalnız IPv4")
    override val FILTER = "Engelleme"
    override val FILTER_LEVEL = "Reklam ve izleyici engelleme"
    override val OPT_FILTER = listOf(
        "Kapalı",
        "Basit",
        "Orta",
        "Sıkı",
    )
    override val FILTER_NOTES = listOf(
        "Hiçbir şey engellenmez.",
        "Bilinen reklam, oltalama ve zararlı yazılım siteleri. Bozulma riski çok düşük.",
        "Basit'e ek olarak daha çok izleyici ve analitik. Bazı sitelerde sorun çıkabilir.",
        "En geniş liste: dolandırıcılık, kötüye kullanım ve yönlendirmeler de. Sık bozulma beklenir.",
    )
    override val FILTER_INFO = "Engelleme tamamen telefonda yapılır: listedeki bir sitenin adı sorulunca NXDOMAIN cevabı verilir, sorgu hiçbir sunucuya gitmez ve hiçbir ad kaydedilmez. Yalnızca bağlıyken çalışır. Tarayıcının kendi güvenli DNS ayarı açıksa bunu atlayabilir. Bir site bozulursa Son engellenenler'den izin verin."
    override val FILTER_LAST = "Son engellenenler"
    override val FILTER_RECENT_NOTE = "Dokun: izin ver"
    override val FILTER_RECENT_EMPTY = "Bu oturumda engellenen yok. Bağlıyken ve seviye açıkken burada görünür."
    override val FILTER_RECENT_FOOT = "Yalnızca bu oturumda, bellekte tutulur; kaydedilmez, bağlantı kesilince silinir."
    override val FILTER_ALLOW = "İzin verilenler"
    override val FILTER_BLOCK = "Kendi engel listem"
    override val FILTER_ADD = "Ekle…"
    override val FILTER_REMOVE = "Dokun: kaldır"
    override val FILTER_ALLOW_ADD = "İzin verilecek alan adı"
    override val FILTER_BLOCK_ADD = "Engellenecek alan adı"
    override val FILTER_ERR = "Geçerli bir alan adı yazın, ör. ornek.com"
    override val FILTER_ERR_LIMIT = "En çok 200 alan adı eklenebilir"
    override val FILTER_ALLOW_EMPTY = "İzin verilen alan adı yok. Bir site bozulursa buraya ekleyin."
    override val FILTER_BLOCK_EMPTY = "Kendi engel listeniz boş."
    override val FILTER_ALLOW_FOOT = "Alan adı ve tüm alt alan adları engellenmez. İzin, bütün listelerden ve kendi engel listenizden güçlüdür."
    override val FILTER_BLOCK_FOOT = "Alan adı ve tüm alt alan adları her zaman engellenir (seviye kapalıyken de)."
    override val FILTER_REMOVE_BTN = "Kaldır"
    override fun filterAllowed(name: String) = "$name için izin verildi"
    override fun filterBlocked(name: String) = "$name engellenecek"
    override fun filterRemoved(name: String) = "$name kaldırıldı"
    override fun filterRemoveAsk(name: String) = "$name listeden kaldırılsın mı?"
    override val TEST_IPV6 = "IPv6 yolu"
    override val AUTO_RECONNECT = "Kendiliğinden yeniden bağlan"
    override val AUTO_RECONNECT_NOTE = "Bağlantı koparsa 5 sn, 30 sn ve 2 dk sonra yeniden dener"
    override val BACKUP_SERVER = "Yedek sunucu"
    override val BACKUP_OFF = "Kapalı"
    override val BACKUP_OFF_NOTE = "Seçili sunucu yanıt vermezse bağlanılmaz"
    override val BACKUP_FASTEST = "En hızlı"
    override val BACKUP_FASTEST_NOTE = "Son ölçüme göre en hızlı başka sunucu"
    override val CONFIRM_OFF = "Kesmeden önce sor"
    override val CONFIRM_OFF_NOTE = "Küreye yanlışlıkla dokununca bağlantı kesilmez"
    override val LOCK_HIDE = "Kilit ekranında gizle"
    override val LOCK_HIDE_NOTE = "Kilit ekranındaki bildirimde sunucu adı görünmez"
    override val QUIET_NOTIF = "Sade bildirim"
    override val QUIET_NOTIF_NOTE = "Durum çubuğunda simge göstermez, sessiz"
    override val REMEMBER_FILTER = "Son süzgeci hatırla"
    override val REMEMBER_FILTER_NOTE = "Uygulama açılınca son seçtiğin süzgeç gelir"
    override val AUTO_MEASURE = "Açılışta hızları ölç"
    override val AUTO_MEASURE_NOTE = "Son ölçüm bir günden eskiyse kendiliğinden ölçer"
    override val MEASURE_ENC = "Şifreli ölçüm"
    override val MEASURE_ENC_NOTE = "Hızı DoT ile ölçer; şifreli kullanımdaki gerçek süreye daha yakın"
    override val OPT_SORT = listOf("Varsayılan", "Hız", "Ad")
    override fun sortA11y(mode: String) = "Sıralama: $mode"
    override val AUTO_LIGHT = "Otomatik: açık tema"
    override val AUTO_DARK = "Otomatik: koyu tema"
    override val NIGHT_HOURS = "Gece saatleri"
    override val FILTER_ENCRYPTED = "Şifreli"
    override val FILTER_UNFILTERED = "Filtresiz"

    override val TEST = "Bağlantıyı test et"
    override val TEST_NOTE = "DNS, DNSSEC ve reklam engelleme"
    override val TESTING = "Test ediliyor…"
    override val TEST_TITLE = "Bağlantı testi"
    override val TEST_OK = "DNS çalışıyor"
    override val TEST_FAIL = "Cevap gelmedi"
    override val TEST_SERVER = "Sunucu"
    override val TEST_METHOD = "Yöntem"
    override val TEST_LATENCY = "Yanıt süresi"
    override val TEST_DNSSEC = "DNSSEC doğrulama"
    override val TEST_ADS = "Reklam engelleme"
    override val DNSSEC_YES = "Doğrulanıyor"
    override val DNSSEC_NO = "Doğrulanmıyor"
    override val ADS_YES = "Etkin"
    override val ADS_NO = "Etkin değil"
    override val UNKNOWN = "Bilinmiyor"
    override val TEST_EXPLAIN = "Sorular tünelin içinden, bir uygulamanın soracağı gibi gönderildi; cevaplar seçtiğin sunucudan geldi."
    override val TEST_AGAIN = "Yeniden test et"

    override val RECOMMEND = "Bana uygun sunucu"
    override val RECOMMEND_NOTE = "Amacını seç, en hızlı uygun sunucuya bağlanalım"
    override val GOAL_SPEED = "Hız"
    override val GOAL_SPEED_NOTE = "Ölçümlere göre en hızlı sunucu"
    override val GOAL_PRIVACY_NOTE = "Kayıt tutmayan, gizlilik odaklı"
    override val GOAL_ADS_NOTE = "Reklam ve takipçileri engelleyen"
    override val GOAL_FAMILY_NOTE = "Yetişkin içeriği engelleyen"
    override val GOAL_SECURITY_NOTE = "Zararlı ve oltalama sitelerini engelleyen"
    override fun recommended(name: String) = "Önerilen: $name"

    override val PRIVATE_DNS = "Özel DNS adı"
    override val PRIVATE_DNS_NOTE = "Android'in Özel DNS ayarına yapıştırabilirsin. O zaman sistem bu sunucuyu doğrudan kullanır ve bu uygulama devre dışı kalır."
    override val CLEAR_HISTORY = "Ölçüm geçmişini temizle"
    override val HISTORY_CLEARED = "Ölçümler temizlendi"

    override val GUARD = "Kesintisiz koruma"
    override val GUARD_NOTE = "Her zaman açık VPN"
    override val GUARD_BODY = listOf(
        "Uygulama bağlı değilken (kapatıldığında, duraklatıldığında ya da bağlantı koptuğunda) DNS sorguların internet sağlayıcının sunucusuna gider.",
        "Bunu önlemek için Android'in VPN ayarlarında bu uygulamaya \"Her zaman açık VPN\" seçeneğini aç. \"VPN olmadan bağlantıları engelle\" de açılırsa, uygulama bağlı değilken internet hiç çalışmaz: sızıntı olmaz ama duraklatma da internetsiz kalmak demektir.",
        "Her zaman açık VPN'de uygulama, telefon açılınca ve kapandıktan sonra sistem tarafından kendiliğinden başlatılır.",
    )
    override val GUARD_BUTTON = "Sistem VPN ayarlarını aç"
    override val BATTERY = "Pil ayarları"
    override val BATTERY_OK = "Kısıtlanmıyor"
    override val BATTERY_LIMITED = "Kısıtlanabilir"
    override val BATTERY_BODY = listOf(
        "VPN uygulamaları Android tarafından genellikle korunur. Yine de bazı üreticiler (Xiaomi, Huawei, Oppo, Vivo, Samsung'un bazı sürümleri) pil tasarrufu için arka plandaki uygulamaları kapatabilir.",
        "Bağlantı kendiliğinden kopuyorsa bu uygulamanın pil kullanımını \"Kısıtlanmamış\" ya da \"Optimize edilmemiş\" yap; bazı telefonlarda ayrıca \"Otomatik başlatma\" iznini aç.",
    )
    override val BATTERY_BUTTON = "Pil ayarlarını aç"

    override val BOOT_TAP = "Telefon açılınca bağlanılamadı. Bağlanmak için dokun."
    override val REBIND = "Yerel ağ koruması"
    override val REBIND_NOTE = "Sitelerin modemine ve evdeki cihazlara DNS hilesiyle ulaşmasını engeller"
    override val STAT_AVG = "Ortalama yanıt süresi"
    override val STAT_SAVED = "Önbellekle kazanılan süre"
    override val STAT_TRAFFIC = "DNS trafiği"
    override val SESSIONS = "Bağlantı geçmişi"
    override val SESSIONS_NOTE = "Son 30 bağlantı; sorgu adları tutulmaz"
    override val SESSIONS_EMPTY = "Henüz kaydedilmiş bağlantı yok."
    override val MOST_USED = "En çok kullanılanlar"
    override val TODAY = "Bugün"
    override val ORB_SHAPE = "Küre şekli"
    override val ORB_SHAPE_EACH = "Temaya göre şekil"
    override val ORB_SHAPE_NAMES = listOf("Küre", "Üçgen", "Kare", "Altıgen", "Yıldız", "Sekizgen", "Beşgen", "Dikdörtgen", "Ters üçgen", "Elmas", "Çiçek", "Altı köşeli yıldız")
    override val SHIELD_WORD = "Kalkan"
    override val LIQUID_WAVE = "Dalga animasyonu"
    override val LIQUID_WAVE_NOTE = "Küre içindeki sıvının 10 dinamik dalga modelinden birini seçin."
    override val LIQUID_COLOR = "Sıvı rengi"
    override val LIQUID_THEME = "Temaya göre"
    override val COLOR_WORD = "Renk"
    override val LIQUID_NOTE = "Renk seçince sıvı hızla renk değiştirmez; dalga hızı yine sunucu hızına göre değişir."
    override val YESTERDAY = "Dün"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Sen kestin"
        EndReason.PAUSE -> "Duraklatıldı"
        EndReason.SWITCH -> "Sunucu değişti"
        EndReason.DROP -> "Koptu"
        EndReason.REVOKED -> "Sistem kapattı"
        EndReason.FAILED -> "Yanıt vermedi"
        EndReason.NETWORK -> "Ağ değişti"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries sorgu"

    override val SOUND_MOTION = "Ses ve hareket"
    override val SEC_SOUND = "Ses"
    override val SOUND_ON = "Ses efektleri"
    override val SOUND_ON_NOTE = "Dokunuşta ve bağlanırken kısa, hafif sesler. Telefon sessizdeyse çalmaz."
    override val SOUND_UI = "Dokunuş sesleri"
    override val SOUND_UI_NOTE = "Düğmeler, anahtarlar ve sayfa geçişleri"
    override val SOUND_CONN = "Bağlantı sesleri"
    override val SOUND_CONN_NOTE = "Bağlanınca, kesilince ve hatada ayrı sesler"
    override val SOUND_VOL = "Ses seviyesi"
    override val SOUND_PACK = "Ses paketi"
    override val SOUND_TEST = "Bağlanma sesini dene"
    override val QUIET_HOURS = "Sessiz saatler"
    override val QUIET_NOTE = "Bu saatlerde ses ve titreşim olmaz"
    override val QUIET_RANGE = "Sessiz saat aralığı"
    override val SEC_MOTION_FX = "Hareket ve efektler"
    override val ANIM_SPEED = "Animasyon hızı"
    override val TAP_FX = "Dokunma efekti"
    override val TAP_FX_NOTE = "Dokunduğun yerde stile özgü küçük bir efekt"
    override val CELEBRATE = "Bağlanma kutlaması"
    override val CELEBRATE_NOTE = "Bağlanınca kürenin çevresinde stile özgü bir gösteri"
    override val HAPTIC_LEVEL = "Titreşim şiddeti"
    override val REMEMBER_MODS = "Modülleri hatırla"
    override val REMEMBER_MODS_NOTE = "Bağlanınca DPI atlatma ve Reklam+ son bıraktığın durumda açılır"
    override val PROFILES = "Profiller"
    override val COPY_STATUS = "Durum özetini kopyala"
    override val OPT_PACK = listOf("Oto", "Yumuşak", "Cam", "Klasik")
    override val SOUND_PACK_NOTE = "Oto: görünüm stilinin kendi sesi"
    override val SOUND_OUT = "Ses çıkışı"
    override val OPT_SOUND_OUT = listOf("Otomatik", "Sistem", "Medya")
    override val SOUND_OUT_NOTES = listOf("Sistem sesi kısıksa medya sesinden çalar", "Dokunma sesleriyle aynı kanal", "Telefon titreşimdeyken de çalar")
    override val SOUND_BLOCK_RINGER = "Telefon sessiz ya da titreşimde. Duymak için Ses çıkışı: Medya seç."
    override val SOUND_BLOCK_ZERO = "Telefonun ses seviyesi kapalı, ses çalmadı."
    override val PACK_SPACE = "Uzay"
    override val PACKS_NOTE = "Yeni paketler (Liquid Glass dâhil) kendi seslerini ve onar animasyonunu getirir: dokunma, anahtar, bağlanma, kesilme, hata, tamamlanma, panel, geri, seçim ve yenileme."
    override val OPT_HAPTIC = listOf("Hafif", "Normal", "Güçlü")
    override val PROFILE_NAMES = listOf("Hız", "Gizlilik", "Aile", "Tam koruma")
    override val PROFILE_NOTES = listOf("En hızlı sunucu, büyük önbellek, engelleme yok", "Sıkı şifreleme, izleyici engelleme, Reklam+", "Aile süzgeçli sunucu, orta düzey engelleme", "Reklam ve izleyici engelleme, DPI atlatma, Reklam+")
    override fun profileApplied(name: String) = "Profil uygulandı: $name"

    override val WHATS_NEW = "Neler yeni?"
    override val WHATS_NEW_TOAST = "Uygulama güncellendi"
    override val SHOW = "Göster"
    override val WHATS_NEW_ITEMS = listOf(
        "Yeni: dokunma ve bağlanma sesleri artık telefon titreşimdeyken de çalıyor (medya kanalından); yalnızca tam sessizde susar. ☰ > Ses ve hareket.",
        "Yeni: sessiz kalan telefonlar için Ses çıkışı (☰ > Ses ve hareket), yerel ağ koruması, 5 kat hızlı engelleme, üretici pil ayarlarına kısayol.",
        "Yeni: isteğe bağlı Oblivious DoH (ODoH): röle IP'nizi, DNS sunucusu soruları görür; ikisi bir arada asla. Kendini onarır. ☰ > DNS ayarları.",
        "Yeni: ses efektleri, baştan yazılan akıcı animasyon motoru, stile özgü dokunma efektleri, profiller, sessiz saatler ve daha fazlası. ☰ > Ses ve hareket.",
        "Yeni: DPI atlatma ve Reklam+ düğmeleri. DNS ile birlikte ya da tek başına çalışır; ikisi de varsayılan kapalı.",
        "Yeni: kendi engel listeni içe aktar, bağlandı/kesildi/zaman aşımı bildirimleri, sorgu gecikme grafiği ve Kapalı kalırsa dur (DNS sızmasın).",
        "Yeni: sunucu listesi ilk 8 ile açılır (Tümünü göster / Daha az göster), Özel DNS ekle en üstte, ince kaydırma çubuğu.",
        "Yeni: Reklam, izleyici ve zararlı site engelleme (Kapalı/Basit/Orta/Sıkı), izin ve kendi engel listesi. ☰ > Engelleme. Her şey telefonda.",
        "Yeni: Frutiger Aurora stili; Y2K holografik, Metro şehir ve müzik temalı yeniden çizildi. Seçmek için ☰ > Kişiselleştirme > Stil.",
        "Yeni: IPv4 ve IPv6 birlikte, hızlı hata tespiti; gizlilik için sorgulardan cihaz izleri silinir ve mesaj uzunlukları gizlenir.",
        "Yeni: Ayarlar konulara ayrıldı. ☰ menüsünden DNS ayarları, Bağlantı ve uygulamalar, Bildirimler, Sunucu listesi, İstatistikler ve geçmiş, Veriler ayrı açılır.",
        "Yeni: Kişiselleştirme penceresi (☰ menüsünde): dil, tema, stil, arka plan, simge, yazı ve erişilebilirlik seçenekleri burada.",
        "Yeni: ana ekranda ☰ menüsü ve yeni Hakkında penceresi (yenilikler, yardım, günlük, paylaş, sürüm).",
        "Düzeltme: kendi fotoğrafını ve hazır görselleri arka plan yapma artık çalışıyor (fotoğraf boyutu yanlış okunuyordu).",
        "Düzeltme: bağlantı sınaması sunucu sorununu telefonun DNS'i kullanmamasından ayırıyor; ikincisinde uyarı çıkıyor.",
        "Düzeltme: Metro, Eco ve Y2K stilleri baştan çizildi; simge değişimi artık uygulamadan çıkınca uygulanır.",
        "Yeni: 8 hazır arka plan görseli (☰ → Kişiselleştirme → Arka plan fotoğrafı → Hazır görseller).",
        "Yeni: sorun giderici, sunucu arama, ölçüm sonuçlarını paylaşma, özel sunucuyu düzenleme ve geçmişi tutmama seçeneği.",
        "Uygulama simgesi: beş stile uygun beş simgeden birini seç.",
        "Arka plan fotoğrafı: galeriden kendi fotoğrafını arka plan yap; perde yoğunluğu ve bulanıklık ayarlı, yazılar hep okunur kalır.",
        "Beş görünüm stili: Aqua (klasik), Aero (gökyüzü ve çimen), Metro (düz karolar), Eco (doğa) ve pembe Y2K; her birinin kendi animasyonları ve daha akıcı geçişler.",
        "Uygulama seçimi: DNS'i yalnızca seçtiğin uygulamalara uygula ya da bazılarını dışarıda bırak.",
        "Özel DNS ekleme (en fazla 8), 10 yeni hazır sunucu ve her sunucuda bilgi bölümü: ne işe yarar, sahibi, ortalama ping.",
        "Daha güvenli bağlantı: sahte DNS cevaplarına karşı ek denetimler, şifresiz DNS'e düşünce uyarı, sıkı şifreleme seçeneği ve şifreli yönteme kendiliğinden dönüş.",
        "Bağlantı testi: DNS'in gerçekten seçtiğin sunucudan cevap verdiğini, DNSSEC doğrulamasını ve reklam engellemeyi tek dokunuşla sına.",
        "Yedek sunucu ve kendiliğinden yeniden bağlanma: seçili sunucu yanıt vermezse ya da bağlantı koparsa uygulama kendisi toparlar.",
        "Bağlantı geçmişi, en çok kullanılan sunucular, ortalama yanıt süresi ve DNS trafiği.",
        "Yeni süzgeçler (Şifreli, Filtresiz), ada göre sıralama, \"Bana uygun sunucu\" önerisi ve açılışta otomatik ölçüm.",
        "Bildirimde canlı sayaçlar, 15 dakika duraklatma düğmesi, kilit ekranında gizleme ve sade bildirim seçeneği.",
        "Üç yeni tema (Sakura, Bal, Kuzey ışıkları), duvar kağıdı renginden tema ve otomatik tema için açık/koyu seçimi.",
        "Dört yeni dil: Endonezce, Vietnamca, Lehçe ve Ukraynaca.",
    )
    override fun importedWith(changes: String) = "Ayarlar yüklendi · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "şifreleme zayıfladı"
        SensitiveChange.AUTO_START -> "otomatik bağlanma açıldı"
        SensitiveChange.RULES -> "sunucu kuralları değişti"
        SensitiveChange.PRIVACY -> "gizlilik veya uyarı ayarları gevşedi"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries sorgu · $blocked engellendi"
    override val NOTIF_LOCKED = "DNS koruması açık"
    override val NOTIF_QUIET_CHANNEL = "Bağlantı durumu (sade)"
    override fun widgetToday(queries: String) = "Bugün $queries sorgu"
    override fun pauseAction(minutes: Int) = "${minutes(minutes)} duraklat"

    override val CUSTOM_NOTE = "Senin eklediğin sunucu"
    override val CUSTOM_ADD = "Özel DNS ekle"
    override val CUSTOM_F_NAME = "Ad"
    override val CUSTOM_F_IP1 = "IPv4 adresi (örn. 1.2.3.4)"
    override val CUSTOM_F_IP2 = "İkinci IPv4 adresi (isteğe bağlı)"
    override val CUSTOM_F_DOT = "DoT adı (isteğe bağlı)"
    override val CUSTOM_F_DOH = "DoH adresi, https://… (isteğe bağlı)"
    override val CUSTOM_SAVE = "Ekle"
    override val CUSTOM_CANCEL = "Vazgeç"
    override val CUSTOM_HINT = "Şifreli bağlantı için DoT veya DoH alanını doldur; boş bırakırsan şifresiz DNS kullanılır."
    override val CUSTOM_ERR_NAME = "Ad 1–24 karakter olmalı (| ; , = olmasın)"
    override val CUSTOM_ERR_IP = "Geçerli bir IPv4 adresi yaz (örn. 1.2.3.4)"
    override val CUSTOM_ERR_DOT = "DoT adı geçerli bir alan adı olmalı"
    override val CUSTOM_ERR_DOH = "DoH adresi https:// ile başlamalı"
    override val CUSTOM_ERR_LIMIT = "En fazla 8 özel sunucu eklenebilir"
    override fun customAdded(name: String) = "$name eklendi"
    override val CUSTOM_DELETE = "Bu sunucuyu sil"
    override val CUSTOM_IN_USE = "Bağlıyken silinemez"
    override fun customDeleted(name: String) = "$name silindi"
    override val INFO_PURPOSE = "Ne işe yarar"
    override val INFO_OWNER = "Sahibi"
    override val INFO_AVG = "Ortalama ping"
    override fun avgPing(ms: Int, n: Int) = "$ms $msU · $n ölçüm"

    override val APPS = "Uygulamalar"
    override val APPS_ALL = "Hepsi"
    override fun appsOnly(n: Int) = "Yalnızca seçilenler ($n)"
    override fun appsExcept(n: Int) = "Seçilenler hariç ($n)"
    override val APPS_MODE = "DNS hangi uygulamalara uygulansın?"
    override val OPT_APPS = listOf("Hepsi", "Sadece seçili", "Seçili hariç")
    override val APPS_NOTE = "Seçilmeyen uygulamalar telefonun kendi DNS'ini kullanır. Aynı anda tek bir DNS sunucusu çalışır; uygulama başına farklı sunucu seçilemez."
    override val APPS_LOADING = "Uygulamalar yükleniyor…"
    override val APPS_EMPTY = "Uygulama bulunamadı"
    override val APPS_NONE_SELECTED = "Hiç uygulama seçilmedi: koruma başlamaz. Uygulama seç ya da “Tüm uygulamalar”a geç."
    override val APPS_APPLY = "Şimdi uygula"
    override val APPS_PENDING = "Değişiklik, bağlantı yenilenince geçerli olur (bir iki saniye kesilir)."

    override val NOTES = mapOf(
        "cloudflare" to "Hızlı, gizlilik odaklı",
        "google" to "Kararlı, yaygın",
        "quad9" to "Zararlı alan adlarını engeller",
        "adguard" to "Reklam ve takipçi engeller",
        "controld" to "Filtresiz, hızlı",
        "opendns" to "Cisco, oltalama koruması",
        "dnssb" to "Gizlilik odaklı, hızlı",
        "dns4eu" to "AB'nin DNS'i, zararlı site koruması",
        "uncensored" to "Filtre ve yönlendirme yok",
        "quad9-open" to "Engelleme yapmaz",
        "adguard-open" to "Engelleme yok, gizlilik odaklı",
        "dns4eu-open" to "AB'nin DNS'i, filtresiz",
        "controld-ads" to "Reklam, takipçi, zararlı site",
        "dns4eu-ads" to "AB'nin DNS'i, reklam ve zararlı site",
        "cloudflare-security" to "Zararlı siteleri engeller",
        "controld-malware" to "Zararlı siteleri engeller",
        "cleanbrowsing-security" to "Oltalama ve zararlı siteler",
        "cloudflare-family" to "Zararlı ve yetişkin içerik filtresi",
        "opendns-family" to "Yetişkin içerik filtresi",
        "adguard-family" to "Reklam ve yetişkin içerik filtresi",
        "cleanbrowsing-family" to "Yetişkin içerik, güvenli arama",
        "dns4eu-child" to "AB'nin DNS'i, çocuk koruması",
        "controld-family" to "Yetişkin içerik filtresi",
        "nextdns" to "Ayarlanabilir filtre, hızlı",
        "cira-private" to "Kanada, filtresiz, gizlilik odaklı",
        "cira-protected" to "Kanada, zararlı site koruması",
        "libredns" to "Bağımsız, filtresiz",
        "switch" to "İsviçre, zararlı site koruması",
        "wikimedia" to "Wikimedia'nın DNS'i, gizlilik odaklı",
        "digitale" to "İsviçre kâr amacı gütmeyen, filtresiz",
        "quad101" to "Tayvan, hızlı",
        "alidns" to "Çin, hızlı",
    )
}
