# DNS Hızlı

**Şifreli DNS ve ağ güvenliği aracı (Android).** Telefonun DNS sorgularını, seçtiğin sağlayıcıya şifreli kanaldan (DNS-over-TLS / DNS-over-HTTPS) tek dokunuşla iletir; istersen zararlı, kimlik avı ve izleyici alan adlarına karşı koruma ekler.

Sürüm: **1.26.0** (versionCode 44) · minSdk 26 (Android 8.0) · hedef SDK 36 · Kotlin · dış bağımlılık yok · 12 dil

> **Durum:** Çekirdek mantık ve arayüz sahnesi bilgisayarda **6153 otomatik kontrolle** sınanır (`./run-tests.sh`). Android'e özgü kısımlar (VPN servisi, bildirim, widget, ses) gerçek telefonda uzun süreli denenmedi; görünüm ve ses beğenisi de cihazda doğrulanmadı. Önizleme görselleri cihaz ekran görüntüsü değildir, aynı çizim kodunun bilgisayarda üretilmiş halidir.

## Ne yapar?

- **Tek dokunuş:** Küreye dokun, bağlan. Başka sunucuya dokun, bağlantı kopmadan geç.
- **32 hazır DNS sunucusu** (Cloudflare, Google, Quad9, AdGuard, Control D, OpenDNS, DNS4EU, CleanBrowsing…) ve kendi ekleyeceğin en fazla 8 sunucu.
- **Şifreli DNS:** DoT ve DoH, otomatik seçim, IPv4 + IPv6, şifreleme düşerse uyarı.
- **Oblivious DoH (ODoH, isteğe bağlı):** röle IP'nizi görür ama soruyu görmez, DNS sunucusu soruyu görür ama sizi görmez. Kendini onaran çok yollu motor; Kapalı / Yedekli / Sıkı.
- **Koruma:** zararlı, kimlik avı ve izleyici alan adlarına karşı dört seviye (Kapalı / Basit / Orta / Sıkı), kendi izin ve engel listen, son engellenenler. Listeler uygulamayla gelir, her şey telefonda çalışır. Gömülü Public Suffix List ile "aynı site" kararı doğru verilir.
- **Filtre belleği:** Otomatik / Hafif / Tam; az belleği olan telefonda en büyük liste atlanır.
- **Uygulama kapsamı:** DNS'in hangi uygulamalara uygulanacağını seç (hepsi, yalnızca seçilenler, seçilenler hariç).
- **Kendini onarma**, yedek sunucu, otomatik yeniden bağlanma, hız ölçümü ve geçmiş grafiği, bağlantı testi (DNS, DNSSEC, koruma), sorun giderici.
- **Wi-Fi ve mobil için ayrı sunucu**, açılışta bağlan, widget, hızlı ayarlar kutucuğu, bildirim düğmeleri.
- **Gizlilik:** hesap yok, reklam yok, analitik yok; sorgu adları kaydedilmez, geliştiriciye hiçbir şey gönderilmez. Android VpnService yalnızca yerelde, DNS sorgularını iletmek için kullanılır; trafiğin başka bir VPN sunucusuna gitmez.

## Tasarım

Sıfırdan çizilmiş şeffaf cam arayüz. **8 stil**, her birinin kendi animasyonları, ses paketi ve uygulama simgesi var:

| Stil | Görünüm |
|---|---|
| Aqua | Camsı, parlak, kabarcıklı (ilk tasarım) |
| Aero | Gökyüzü, çimen, cam damlaları |
| Metro | Şehir, müzik, düz karolar |
| Eco | Doğa, yapraklar, yeşil ışık |
| Y2K | Holografik pembe-mor, krom kalpler |
| Aurora | Turkuaz-yeşil-sarı ışık, tel kafes dalgalar |
| Liquid Glass | Yarı saydam mavi-indigo cam, parlak beyaz kenar ışığı |
| **Deep** (yeni) | Modern, sade koyu füme/lacivert cam, elektrik mavisi neon hatlar (DeepSeek esintisi) |

12 renk teması, kendi fotoğrafını arka plan yapma, otomatik/saatli koyu mod, düşük güç modu, yüksek kontrast, yazı boyutu, TalkBack desteği. Ses paketlerinde 10 animasyon (dokunma, anahtar, bağlanma, kesilme, hata, tamamlanma, panel, geri, seçim, yenileme) ve 11 ses olayı vardır; hepsi kodla üretilir, ek dosya yoktur.

Diller: Türkçe, English, Deutsch, Español, Français, Português, Русский, Italiano, Bahasa Indonesia, Tiếng Việt, Polski, Українська.

## Derleme

**Bilgisayarla:** Android Studio ile klasörü aç, senkronize et, çalıştır. Gradle 9.8.0, AGP 9.4.0, JDK 25 (17+ ile de çalışır).

**Telefondan (GitHub Actions):** `.github/workflows/apk.yml` bulutta debug APK derler. Ayrıntılı adımlar için [OKUBENI.md](OKUBENI.md) bölüm 0. Play'e imzalı `bundleRelease` (.aab) gider; imza anahtarı depoya konmaz (`keystore.properties.example`).

**Testler (Android gerekmez):**

```sh
./run-tests.sh            # tümü
./run-tests.sh core ui    # seçili gruplar
```

Kotlin derleyicisi (`kotlinc`) ve JDK 17+ gerekir. Beklenen: `6153 kontrol, 0 başarısız`.

## Proje yapısı

| Yol | İçerik |
|---|---|
| `app/src/main/java/app/dnshizli/core/` | DNS yönlendirici, filtre motoru, şifreli DNS, çizim (Art*), ses sentezi, animasyonlar, metinler (12 dil) |
| `app/src/main/java/app/dnshizli/ui/` | Sahne, sayfalar, bileşenler, model |
| `app/src/main/java/app/dnshizli/platform/` | Android bağları: VpnService, bildirim, widget, kutucuk, simge değiştirici |
| `app/src/main/assets/filter/` | Gömülü engel listeleri ve Public Suffix List (kaynaklar ve lisanslar: `KAYNAKLAR.txt`) |
| `selftest/` | JVM testleri (Gradle'a bağlı değil, APK'ya girmez) |
| `tools/` | Liste, PSL ve simge üreticileri (`build_filter.py`, `build_psl.py`, `icons.py`) |
| `store/` | Mağaza metni (12 dil) ve Play beyan taslağı |

## Belgeler

- [SURUM_NOTLARI.md](SURUM_NOTLARI.md): sürüm sürüm değişiklikler
- [OZELLIKLER.md](OZELLIKLER.md): özellik listesi ve nasıl doğrulandığı
- [INCELEME.md](INCELEME.md): kod inceleme rehberi
- [DNS_HIZLI_TARIHCE.txt](DNS_HIZLI_TARIHCE.txt): ayrıntılı geliştirme tarihçesi ve kararlar
- [GIZLILIK.md](GIZLILIK.md): gizlilik politikası şablonu
- [YOLHARITASI.md](YOLHARITASI.md): yol haritası

## Bilinen sınırlar

- Koruma yalnızca DNS düzeyindedir; aynı alan adından gelen sayfa içi içeriği engelleyemez. Seviye yükseldikçe (özellikle Sıkı) bazı siteler bozulabilir; Son engellenenler'den izin verilir.
- Bazı tarayıcıların "güvenli DNS" ayarı ve belirli bir ada sabitlenmiş Android "Özel DNS" ayarı kendi sunucusunu kullanır, bu uygulamayı atlayabilir.
- Android aynı anda tek VPN'e izin verir; başka bir VPN açıkken bu uygulama bağlanamaz.
- Şifreleme kapalıyken bazı ağlar DNS trafiğini kendi sunucusuna yönlendirebilir.
- Katalog adresleri `tools/catalog_check.py` ile kendi ağında doğrulanmalıdır.

## Lisans

Henüz seçilmedi: depoya bir `LICENSE` dosyası ekleyene kadar tüm hakları saklıdır. Gömülü listelerin kendi lisansları (MIT, Unlicense, MPL 2.0) `app/src/main/assets/filter/KAYNAKLAR.txt` içinde yazılıdır.

---

## English summary

**DNS Fast** is an Android network security tool: it sends your DNS queries over encrypted channels (DoT/DoH, optionally Oblivious DoH) to a provider you choose, with one tap, and can shield you from malicious, phishing and tracking domains using lists bundled in the app (everything runs on-device). 32 built-in servers plus 8 custom, per-app scope, self-repair, connection tests, seven glass-style UI styles (incl. the new Liquid Glass) with their own sounds, animations and icons, 12 languages, no account, no analytics, no third-party libraries. The VPN interface is used locally only, to forward DNS queries. Tests run on a plain JVM: `./run-tests.sh` (6153 checks). Not yet verified long-term on a physical device.
