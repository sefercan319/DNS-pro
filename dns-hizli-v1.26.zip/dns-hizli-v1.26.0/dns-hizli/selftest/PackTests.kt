package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*
import java.awt.image.BufferedImage
import kotlin.math.abs

private val NEW_PACKS = SoundPack.values().filter { it.animated }

private fun frame(pack: SoundPack, slot: FxSlot, times: FloatArray, th: AeroTheme = Themes.aqua): BufferedImage {
    val c = AwtCanvas(200, 200, 1f)
    c.gfx.paint(0xFF1B2433.toInt()); c.gfx.rect(0f, 0f, 200f, 200f)
    for (t in times) PackFx.draw(pack, slot, c.gfx, th, 100f, 100f, if (slot.atOrb) 110f else 44f, t)
    c.dispose()
    return c.image
}

private fun diff(a: BufferedImage, b: BufferedImage): Int {
    var n = 0
    for (y in 0 until a.height) for (x in 0 until a.width) if (a.getRGB(x, y) != b.getRGB(x, y)) n++
    return n
}

/** Yeni ses paketleri: 9 yeni tını (11 olay), 100 animasyon, ayarlar, sahne bağlantısı, metinler. */
fun runPackTests() {
    T.group("Ses paketleri: liste ve eşleme")
    run {
        T.check("13 paket: 4 klasik + 9 yeni; yalnızca yeniler animasyonlu", SoundPack.values().size == 14 && NEW_PACKS.size == 10 && SoundPack.values().take(4).none { it.animated })
        T.check("paket kimlikleri benzersiz", SoundPack.values().map { it.id }.toSet().size == 14)
        T.check("her yeni paket kendi tınısına bağlı, tınılar farklı", NEW_PACKS.map { Synth.voiceFor(it, UiStyle.AQUA) }.toSet().size == 10)
        T.check("yeni paketler stilden bağımsız", NEW_PACKS.all { p -> UiStyle.values().map { Synth.voiceFor(p, it) }.toSet().size == 1 })
        T.check("15 tını, 9'u kendi ezgilerini taşır", Voice.values().size == 15 && Voice.values().count { it.hasOwnMelodies } == 9)
    }

    T.group("Ses paketleri: ses sentezi")
    run {
        val voices = NEW_PACKS.map { Synth.voiceFor(it, UiStyle.AQUA) }
        val all = ArrayList<Triple<Sfx, Voice, ShortArray>>()
        for (v in voices) for (e in Sfx.values()) all.add(Triple(e, v, Synth.render(e, v)))
        T.check("9 × 11 = 99 ses", all.size == 99)
        T.check("hiçbiri boş değil, hepsi 0,9 sn'den kısa", all.all { it.third.size in 100..(Synth.RATE * 0.91f).toInt() })
        T.check("uçlar sıfıra iner", all.all { (_, _, a) -> abs(a.first().toInt()) < 400 && abs(a.last().toInt()) < 400 })
        T.check("DC kayması küçük", all.all { (_, _, a) -> abs(a.map { it.toInt() }.average()) < 1500 })
        T.check("dokunuş sesi ≤ 0,2 sn", voices.all { Synth.render(Sfx.TAP, it).size <= Synth.RATE * 0.2f })
        T.check("her tınıda 11 olay birbirinden farklı", voices.all { v -> Sfx.values().map { Synth.render(it, v).toList().hashCode() }.toSet().size == 11 })
        T.check("her olayda 9 tını birbirinden farklı", Sfx.values().all { e -> voices.map { Synth.render(e, it).toList().hashCode() }.toSet().size == 10 })
        T.check("aynı girdi aynı sesi verir", voices.all { Synth.render(Sfx.CONNECT, it).contentEquals(Synth.render(Sfx.CONNECT, it)) })
        T.check("tepe genliği hedefte", all.all { (e, _, a) -> val pk = a.maxOf { abs(it.toInt()) } / 32767f; if (e.isConnection) pk in 0.74f..0.82f else pk in 0.50f..0.58f })
        T.check("gerçek ses: RMS tepenin 1/12'sinden büyük", all.all { (_, _, a) -> Math.sqrt(a.map { it.toDouble() * it }.average()) > a.maxOf { abs(it.toInt()) } / 12.0 })
    }

    T.group("Ses paketleri: animasyonlar")
    run {
        val slots = FxSlot.values()
        T.check("10 yuva; küçükler dokunuşta, büyükler kürede", slots.size == 10 && slots.count { it.atOrb } == 5 && !FxSlot.TAP.atOrb && !FxSlot.TOGGLE.atOrb && !FxSlot.SHEET.atOrb && !FxSlot.BACK.atOrb && !FxSlot.SELECT.atOrb && FxSlot.REFRESH.atOrb)
        var ok = true; var mid = true; var edge = true
        for (p in NEW_PACKS) for (s in slots) {
            val g = CountingGfx()
            for (i in 0..40) {
                g.reset(); PackFx.draw(p, s, g, Themes.aqua, 120f, 240f, if (s.atOrb) 120f else 44f, i / 40f)
                if (g.bad > 0 || g.underflow || g.depth != 0) ok = false
                if (i == 20 && g.shapes == 0) mid = false
            }
            g.reset(); PackFx.draw(p, s, g, Themes.aqua, 1f, 1f, 40f, 0f); PackFx.draw(p, s, g, Themes.aqua, 1f, 1f, 40f, 1f); PackFx.draw(p, s, g, Themes.aqua, 1f, 1f, 40f, 1.5f)
            if (g.calls != 0) edge = false
        }
        T.check("48 animasyon: sonlu, save/restore dengeli", ok)
        T.check("48 animasyon: ilerlemenin ortasında bir şey çizer", mid)
        T.check("48 animasyon: başta ve sonda çizmez", edge)
        val gOff = CountingGfx()
        for (p in SoundPack.values().filter { !it.animated }) for (s in slots) PackFx.draw(p, s, gOff, Themes.aqua, 50f, 50f, 40f, 0.5f)
        T.check("klasik paketler animasyon çizmez", gOff.calls == 0)
        val gAll = CountingGfx()
        for (th in Themes.all) for (p in NEW_PACKS) for (s in slots) for (sz in floatArrayOf(1f, 44f, 300f)) for (t in floatArrayOf(0.05f, 0.5f, 0.95f)) PackFx.draw(p, s, gAll, th, -50f, 900f, sz, t)
        T.check("tüm temalar, boyutlar ve konumlarda sonlu", gAll.bad == 0 && !gAll.underflow && gAll.depth == 0)

        val times = floatArrayOf(0.2f, 0.4f, 0.6f, 0.8f)
        val imgs = ArrayList<Pair<String, BufferedImage>>()
        for (p in NEW_PACKS) for (s in slots) imgs.add("${p.id}/$s" to frame(p, s, times))
        val twins = ArrayList<String>()
        for (i in imgs.indices) for (j in i + 1 until imgs.size) if (diff(imgs[i].second, imgs[j].second) < 60) twins.add(imgs[i].first + "~" + imgs[j].first)
        T.check("48 animasyon görsel olarak birbirinden farklı", twins.isEmpty(), twins.take(4).toString())
        T.check("her animasyon yeterince görünür (≥150 piksel)", imgs.all { (_, im) -> diff(im, frame(SoundPack.AQUA, FxSlot.TAP, floatArrayOf())) >= 150 })
        T.check("aynı kare her seferinde aynı (rastgelelik yok)", NEW_PACKS.all { p -> slots.all { s -> diff(frame(p, s, times), frame(p, s, times)) == 0 } })
    }
    run {
        // Çizim bellek ayırmaz (ısınmadan sonra)
        val mx = java.lang.management.ManagementFactory.getThreadMXBean() as? com.sun.management.ThreadMXBean
        if (mx != null && mx.isThreadAllocatedMemorySupported) {
            val g = CountingGfx()
            fun pass() { for (p in NEW_PACKS) for (s in FxSlot.values()) for (i in 1..9) PackFx.draw(p, s, g, Themes.aqua, 100f, 100f, 60f, i / 10f) }
            repeat(3) { pass() }
            val tid = Thread.currentThread().id
            val b0 = mx.getThreadAllocatedBytes(tid)
            repeat(20) { pass() }
            val per = (mx.getThreadAllocatedBytes(tid) - b0) / (20L * 8 * 6 * 9)
            T.check("çizim kare başına bellek ayırmaz (≤ 64 bayt/çizim)", per <= 64, "$per bayt")
        }
    }

    T.group("Ses paketleri: ayar ve sahne")
    run {
        T.check("her paket ayar kodlayıcıdan sağ çıkar", SoundPack.values().all { p -> SettingsCodec.decode(SettingsCodec.encode(AppSettings(soundPack = p))).soundPack == p })
        T.check("dışa/içe aktarmada yeni paket korunur", SettingsCodec.import(SettingsCodec.export(AppSettings(soundPack = SoundPack.SPACE)), AppSettings())?.soundPack == SoundPack.SPACE)
        fun conn(rig: Rig, st: OrbState) = rig.model.onVpn(VpnUi(state = st, serverId = "cloudflare", sinceMs = rig.host.now))
        // sesin çaldığı tını pakete uyar
        val rig = Rig(AppSettings(soundPack = SoundPack.RETRO))
        rig.model.sfx(Sfx.TAP)
        T.check("Retro paketi 8-bit tınıyı çalar", rig.host.sounds.last().second == Voice.CHIP)

        // olay → animasyon tetikleyicisi
        val r = Rig(AppSettings(soundPack = SoundPack.AQUA))
        val s0 = r.model.packFxSeq
        r.model.sfx(Sfx.TAP)
        T.check("dokunuş sesi paket tetikleyicisi vermez", r.model.packFxSeq == s0)
        r.model.sfx(Sfx.SHEET); T.check("panel → SHEET", r.model.packFxSeq == s0 + 1 && r.model.packFxSlot == FxSlot.SHEET)
        r.model.sfx(Sfx.BACK); T.check("geri → BACK", r.model.packFxSeq == s0 + 2 && r.model.packFxSlot == FxSlot.BACK)
        r.model.sfx(Sfx.SELECT); T.check("seçim → SELECT", r.model.packFxSeq == s0 + 3 && r.model.packFxSlot == FxSlot.SELECT)
        r.model.sfx(Sfx.REFRESH); T.check("yenile → REFRESH", r.model.packFxSeq == s0 + 4 && r.model.packFxSlot == FxSlot.REFRESH)
        val s2 = r.model.packFxSeq
        r.model.sfx(Sfx.TOGGLE_ON); T.check("anahtar → TOGGLE", r.model.packFxSeq == s2 + 1 && r.model.packFxSlot == FxSlot.TOGGLE)
        r.model.sfx(Sfx.TOGGLE_OFF); T.check("anahtar kapat → TOGGLE", r.model.packFxSeq == s2 + 2 && r.model.packFxSlot == FxSlot.TOGGLE)
        r.model.sfx(Sfx.ERROR); T.check("hata → ERROR", r.model.packFxSlot == FxSlot.ERROR)
        r.model.sfx(Sfx.DONE); T.check("tamam → DONE", r.model.packFxSlot == FxSlot.DONE)
        r.model.update { it.copy(soundOn = false) }
        val s1 = r.model.packFxSeq; r.model.sfx(Sfx.DISCONNECT)
        T.check("ses kapalıyken de animasyon tetiklenir", r.model.packFxSeq == s1 + 1 && r.model.packFxSlot == FxSlot.DISCONNECT)
        val auto = Rig(AppSettings(soundPack = SoundPack.AUTO)); auto.model.sfx(Sfx.CONNECT)
        T.check("klasik pakette tetikleyici yok", auto.model.packFxSeq == 0)

        // sahne: bağlanınca animasyon çizilir ve biter
        fun shapesNow(rg: Rig): Int { val g = CountingGfx(); rg.scene.draw(g); return g.shapes }
        val sc = Rig(AppSettings(soundPack = SoundPack.AQUA, bubbles = BubbleLevel.OFF)); sc.settle()
        conn(sc, OrbState.OFF); sc.advance(300)
        val calm = shapesNow(sc)
        conn(sc, OrbState.ON); sc.advance(500)
        val during = shapesNow(sc)
        T.check("bağlanınca küre çevresinde animasyon çizilir", during > calm, "$calm -> $during")
        sc.advance(2500)
        T.check("animasyon biter ve sahne durağanlaşır", sc.tick1() <= 33L || sc.lastDelay == -1L)
        fun connectedShapes(pack: SoundPack, cele: Boolean): Int {
            val rg = Rig(AppSettings(soundPack = pack, celebrate = cele, bubbles = BubbleLevel.OFF)); rg.settle()
            conn(rg, OrbState.OFF); rg.advance(300); conn(rg, OrbState.ON); rg.advance(500)
            return shapesNow(rg)
        }
        T.check("kutlama kapalıyken bağlanma animasyonu yok (çizim klasik paketle aynı)", connectedShapes(SoundPack.AQUA, false) == connectedShapes(SoundPack.SOFT, false))
        T.check("kutlama açıkken animasyon fark yaratır", connectedShapes(SoundPack.AQUA, true) > connectedShapes(SoundPack.SOFT, true))
        val still = Rig(AppSettings(soundPack = SoundPack.AQUA, bubbles = BubbleLevel.OFF)); still.settle()
        still.model.sfx(Sfx.CONNECT); still.advance(1)
        T.check("olay sonrası kare istenir", still.tick1() != -1L)
    }

    T.group("Ses paketleri: seçim sayfası ve metinler")
    run {
        val rig = Rig()
        rig.model.update { it.copy(onboarded = true) }
        rig.tapText(Strings.MENU, exact = true, settleMs = 900)
        rig.tapText(Strings.SOUND_MOTION, exact = true, settleMs = 900)
        rig.tapText(Strings.SOUND_PACK, exact = false, settleMs = 900)
        T.check("paket listesi açılır, ilk satırlar görünür", rig.find(Strings.packName(SoundPack.AUTO)) != null)
        rig.tapText("Frutiger Aero", exact = false, settleMs = 600)
        T.check("Frutiger Aero seçilir", rig.model.settings.soundPack == SoundPack.AERO)
        T.check("seçince örnek ses çalındı", rig.host.sounds.any { it.second == Voice.CHIME })
    }
    run {
        val langs = Lang.values()
        var ok = true; val bad = ArrayList<String>()
        for (l in langs) {
            L.set(l)
            val names = SoundPack.values().map { Strings.packName(it) }
            if (names.toSet().size != 13 || names.any { it.isBlank() } || Strings.PACKS_NOTE.length < 20) { ok = false; bad.add(l.name) }
        }
        L.set(Lang.TR)
        T.check("12 dilde 13 paket adı ve not var", ok && langs.size == 12, bad.toString())
    }

    run {
        // Elle bakmak için önizleme: her paket bir sayfa, satırlar yuvalar, sütunlar zaman (testin geçmesi buna bağlı değil)
        val dir = java.io.File(System.getProperty("java.io.tmpdir"), "dnshizli-packs").also { it.mkdirs() }
        val ts = floatArrayOf(0.12f, 0.30f, 0.50f, 0.70f, 0.88f)
        for (p in NEW_PACKS) {
            val sheet = BufferedImage(160 * ts.size, 160 * 10, BufferedImage.TYPE_INT_ARGB)
            val g2 = sheet.createGraphics()
            FxSlot.values().forEachIndexed { r, sl ->
                ts.forEachIndexed { c, t ->
                    val cv = AwtCanvas(160, 160, 1f)
                    cv.gfx.paint(0xFF1B2433.toInt()); cv.gfx.rect(0f, 0f, 160f, 160f)
                    PackFx.draw(p, sl, cv.gfx, Themes.aqua, 80f, 80f, if (sl.atOrb) 90f else 44f, t)
                    cv.dispose(); g2.drawImage(cv.image, c * 160, r * 160, null)
                }
            }
            g2.dispose()
            javax.imageio.ImageIO.write(sheet, "png", java.io.File(dir, "paket-${p.id}.png"))
        }
        T.check("animasyon önizlemeleri üretildi", java.io.File(dir, "paket-space.png").length() > 1000)
    }
}
