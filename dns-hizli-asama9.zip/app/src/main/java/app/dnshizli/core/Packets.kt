package app.dnshizli.core

/**
 * IPv4 + UDP paketleri için küçük, bellek ayırmayan (allocation-free) yardımcılar.
 * Android'e bağlı değil, bu yüzden normal JVM'de test edilebilir.
 */
internal object Packets {
    const val IP_HDR = 20
    const val UDP_HDR = 8
    const val HDR = IP_HDR + UDP_HDR
    const val DNS_HDR = 12
    const val DNS_PORT = 53

    fun u16(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    fun put16(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 8).toByte()
        b[o + 1] = v.toByte()
    }

    fun i32(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xFF) shl 24) or
            ((b[o + 1].toInt() and 0xFF) shl 16) or
            ((b[o + 2].toInt() and 0xFF) shl 8) or
            (b[o + 3].toInt() and 0xFF)

    fun put32(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 24).toByte()
        b[o + 1] = (v ushr 16).toByte()
        b[o + 2] = (v ushr 8).toByte()
        b[o + 3] = v.toByte()
    }

    /** Standart IPv4 başlık sağlama toplamı. Başlıktaki checksum alanı dahilse geçerli paket için 0 döner. */
    fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0
        var i = off
        while (i + 1 < off + len) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
        }
        while ((sum ushr 16) != 0) sum = (sum and 0xFFFF) + (sum ushr 16)
        return sum.inv() and 0xFFFF
    }

    /**
     * Paket "IPv4 + UDP + hedef port 53 + parçalı değil" ise IP başlık uzunluğunu döner,
     * aksi halde -1 (paket yok sayılır).
     */
    fun queryHeaderLen(p: ByteArray, len: Int): Int {
        if (len < HDR + DNS_HDR) return -1
        if (((p[0].toInt() and 0xF0) shr 4) != 4) return -1
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (ihl < IP_HDR || len < ihl + UDP_HDR + DNS_HDR) return -1
        if ((p[9].toInt() and 0xFF) != 17) return -1          // UDP değil
        if ((u16(p, 6) and 0x3FFF) != 0) return -1            // parçalı paket
        if (u16(p, 2) > len) return -1                        // kesik paket
        if (u16(p, ihl + 2) != DNS_PORT) return -1            // DNS değil
        return ihl
    }

    /** UDP verisinin (DNS mesajı) uzunluğu. Negatif çıkarsa paket bozuktur. */
    fun dnsLength(p: ByteArray, ihl: Int): Int {
        val total = u16(p, 2)
        val udp = u16(p, ihl + 4) - UDP_HDR
        return minOf(udp, total - ihl - UDP_HDR)
    }

    fun ip(a: Int, b: Int, c: Int, d: Int): Int = (a shl 24) or (b shl 16) or (c shl 8) or d

    // Tünele yazılan IP paketlerinin kimlik (Identification) sayacı: süreç genelinde TEK sayaç. Aynı anda çalışan
    // yönlendiriciler (ör. sunucu değişirken emekliye ayrılan eskisi) aynı kimliği üretmesin; aksi halde iki büyük
    // cevabın IP parçaları işletim sisteminde yanlış birleştirilebilir. Rastgele bir değerden başlar.
    private val ident = java.util.concurrent.atomic.AtomicInteger(java.security.SecureRandom().nextInt(0x10000))

    /** Sıradaki IP kimliği (1..65535). Nesne ayırmaz, her iş parçacığından çağrılabilir. */
    fun nextIdent(): Int {
        val v = ident.incrementAndGet() and 0xFFFF
        return if (v == 0) ident.incrementAndGet() and 0xFFFF else v
    }

    /**
     * UDP sağlama toplamı (RFC 768): sözde başlık (kaynak/hedef IP, protokol, uzunluk) + UDP başlığı + veri.
     * [udpOff] konumundaki UDP başlığının checksum alanı hesaplama sırasında 0 sayılır. Sonuç 0 çıkarsa 0xFFFF yazılır
     * (0, "checksum yok" anlamına gelir). İstemci, bozulmuş ya da yanlış birleştirilmiş bir cevabı böylece fark eder.
     */
    fun udpChecksum(b: ByteArray, udpOff: Int, udpLen: Int, srcIp: Int, dstIp: Int): Int {
        var sum = 0L
        sum += (srcIp ushr 16) and 0xFFFF
        sum += srcIp and 0xFFFF
        sum += (dstIp ushr 16) and 0xFFFF
        sum += dstIp and 0xFFFF
        sum += 17
        sum += udpLen
        var i = udpOff
        val end = udpOff + udpLen
        while (i + 1 < end) {
            if (i != udpOff + 6) sum += (((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)).toLong()
            i += 2
        }
        if (i < end) sum += ((b[i].toInt() and 0xFF) shl 8).toLong()
        while ((sum ushr 16) != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
        val c = sum.toInt().inv() and 0xFFFF
        return if (c == 0) 0xFFFF else c
    }

    /** UDP sağlama toplamı geçerli mi? (Alan 0 ise "hesaplanmamış" sayılır ve geçerli kabul edilir.) */
    fun udpChecksumOk(b: ByteArray, udpOff: Int, udpLen: Int, srcIp: Int, dstIp: Int): Boolean {
        val stored = u16(b, udpOff + 6)
        return stored == 0 || stored == udpChecksum(b, udpOff, udpLen, srcIp, dstIp)
    }

    /**
     * [out] içinde HDR (28) bayttan sonra DNS verisi hazırsa, öndeki IPv4 + UDP başlıklarını doldurur
     * (UDP sağlama toplamı dahil).
     */
    fun writeHeaders(out: ByteArray, srcIp: Int, dstIp: Int, srcPort: Int, dstPort: Int, dnsLen: Int, ident: Int = 0) {
        writeIp(out, srcIp, dstIp, HDR + dnsLen, ident, 0x4000)
        put16(out, 20, srcPort)
        put16(out, 22, dstPort)
        put16(out, 24, UDP_HDR + dnsLen)
        put16(out, 26, udpChecksum(out, IP_HDR, UDP_HDR + dnsLen, srcIp, dstIp))
    }

    /** IPv4 başlığı (20 bayt) yazar. [flagsFrag]: bayraklar (DF/MF) + 8 baytlık birimlerle parça konumu. */
    private fun writeIp(out: ByteArray, srcIp: Int, dstIp: Int, total: Int, ident: Int, flagsFrag: Int) {
        out[0] = 0x45
        out[1] = 0
        put16(out, 2, total)
        put16(out, 4, ident)
        put16(out, 6, flagsFrag)
        out[8] = 64                    // TTL
        out[9] = 17                    // UDP
        put16(out, 10, 0)
        put32(out, 12, srcIp)
        put32(out, 16, dstIp)
        put16(out, 10, checksum(out, 0, IP_HDR))
    }

    /** Tünel MTU'su: tek bir IP paketinin en büyük boyu. */
    const val MTU = 1500

    /**
     * DNS cevabını tünele yazar. [out]: ilk [HDR] bayt boş, ardından [dnsLen] bayt DNS verisi.
     * Tek pakete sığmayan büyük cevaplar (ör. çok kayıtlı ya da şifreli DNS'ten gelen) IP parçalarına bölünür;
     * işletim sistemi parçaları birleştirip uygulamaya tek cevap olarak verir. [scratch] en az [MTU] bayt olmalı.
     */
    fun writeReply(
        out: ByteArray, scratch: ByteArray, ident: Int,
        srcIp: Int, dstIp: Int, srcPort: Int, dstPort: Int, dnsLen: Int,
        write: (ByteArray, Int, Int) -> Unit,
    ) {
        if (HDR + dnsLen <= MTU) {
            writeHeaders(out, srcIp, dstIp, srcPort, dstPort, dnsLen, ident and 0xFFFF)
            write(out, 0, HDR + dnsLen)
            return
        }
        // UDP başlığını verinin hemen önüne (out[20..27]) yaz: IP yükü = out[20 ..< 20+8+dnsLen].
        // Sağlama toplamı parçalamadan ÖNCE bütün UDP verisi üzerinden hesaplanır.
        put16(out, 20, srcPort)
        put16(out, 22, dstPort)
        put16(out, 24, UDP_HDR + dnsLen)
        put16(out, 26, udpChecksum(out, IP_HDR, UDP_HDR + dnsLen, srcIp, dstIp))
        val payload = UDP_HDR + dnsLen
        val chunk = (MTU - IP_HDR) and 7.inv()          // 1480: parça yükü 8'in katı olmalı
        var off = 0
        while (off < payload) {
            val n = minOf(chunk, payload - off)
            val more = off + n < payload
            writeIp(scratch, srcIp, dstIp, IP_HDR + n, ident and 0xFFFF, (if (more) 0x2000 else 0) or (off / 8))
            System.arraycopy(out, IP_HDR + off, scratch, IP_HDR, n)
            write(scratch, 0, IP_HDR + n)
            off += n
        }
    }
}

internal object Dns {

    /**
     * DNS cevabı önbelleğe alınabilir mi? Alınabilirse cevap bölümündeki en kısa TTL'i (saniye),
     * alınamazsa 0 döner. Hatalı, kesilmiş (TC) veya cevapsız mesajlar önbelleğe girmez.
     */
    fun cacheTtl(b: ByteArray, len: Int): Int = cacheTtl(b, 0, len)

    /** [b] içinde [base] konumundan başlayan [n] baytlık mesaj için [cacheTtl]. */
    fun cacheTtl(b: ByteArray, base: Int, n: Int): Int {
        if (n < Packets.DNS_HDR || base < 0 || base + n > b.size) return 0
        val end = base + n
        val flags = Packets.u16(b, base + 2)
        if ((flags and 0x8000) == 0) return 0      // cevap değil
        if ((flags and 0x0200) != 0) return 0      // TC: kesilmiş
        if ((flags and 0x000F) != 0) return 0      // NOERROR değil
        val qd = Packets.u16(b, base + 4)
        val an = Packets.u16(b, base + 6)
        if (an == 0) return 0

        var p = base + Packets.DNS_HDR
        for (i in 0 until qd) {
            p = skipName(b, p, end)
            if (p < 0 || p + 4 > end) return 0
            p += 4
        }
        var lowest = Int.MAX_VALUE
        for (i in 0 until an) {
            p = skipName(b, p, end)
            if (p < 0 || p + 10 > end) return 0
            val ttl = Packets.i32(b, p + 4)
            val rdLen = Packets.u16(b, p + 8)
            p += 10
            if (p + rdLen > end) return 0
            p += rdLen
            lowest = minOf(lowest, if (ttl < 0) 0 else ttl)
        }
        return if (lowest == Int.MAX_VALUE) 0 else lowest
    }

    /** Alan adını atlar (sıkıştırma işaretçisi dahil). Bozuksa -1. */
    internal fun skipName(b: ByteArray, start: Int, end: Int): Int {
        var i = start
        while (true) {
            if (i >= end) return -1
            val l = b[i].toInt() and 0xFF
            if (l == 0) return i + 1
            if ((l and 0xC0) == 0xC0) return if (i + 2 <= end) i + 2 else -1
            if ((l and 0xC0) != 0) return -1
            i += 1 + l
        }
    }

    /**
     * Cevap bir engelleme cevabı mı (tahmini)? Engelleyen sunucuların yaygın yanıtları:
     *  - A kaydı 0.0.0.0 ya da AAAA kaydı :: ("boş adres"),
     *  - Genişletilmiş DNS Hatası (RFC 8914) kodu 15 Blocked, 16 Censored, 17 Filtered, 18 Prohibited.
     * Sıradan "böyle bir alan adı yok" (NXDOMAIN) cevapları sayılmaz.
     */
    fun isBlocked(b: ByteArray, len: Int): Boolean = isBlocked(b, 0, len)

    /** [b] içinde [base] konumundan başlayan [n] baytlık DNS mesajı için [isBlocked]. Nesne ayırmaz. */
    fun isBlocked(b: ByteArray, base: Int, n: Int): Boolean {
        if (n < Packets.DNS_HDR || base < 0 || base + n > b.size) return false
        val end = base + n
        val flags = Packets.u16(b, base + 2)
        if ((flags and 0x8000) == 0) return false
        val qd = Packets.u16(b, base + 4)
        val an = Packets.u16(b, base + 6)
        val ns = Packets.u16(b, base + 8)
        val ar = Packets.u16(b, base + 10)
        var p = base + Packets.DNS_HDR
        for (i in 0 until qd) {
            p = skipName(b, p, end)
            if (p < 0 || p + 4 > end) return false
            p += 4
        }
        var nullAnswer = false
        val total = an + ns + ar
        for (i in 0 until total) {
            p = skipName(b, p, end)
            if (p < 0 || p + 10 > end) return nullAnswer
            val type = Packets.u16(b, p)
            val rdLen = Packets.u16(b, p + 8)
            val rd = p + 10
            if (rd + rdLen > end) return nullAnswer
            if (i < an) {
                if ((type == 1 && rdLen == 4 || type == 28 && rdLen == 16) && allZero(b, rd, rdLen)) nullAnswer = true
            } else if (i >= an + ns && type == 41) {
                // OPT kaydı: seçenekler (kod, uzunluk, veri). Kod 15 = Genişletilmiş DNS Hatası.
                var o = rd
                while (o + 4 <= rd + rdLen) {
                    val code = Packets.u16(b, o)
                    val olen = Packets.u16(b, o + 2)
                    if (code == 15 && olen >= 2 && o + 6 <= rd + rdLen) {
                        val info = Packets.u16(b, o + 4)
                        if (info in 15..18) return true
                    }
                    o += 4 + olen
                }
            }
            p = rd + rdLen
        }
        return nullAnswer
    }

    private fun allZero(b: ByteArray, off: Int, n: Int): Boolean {
        for (i in off until off + n) if (b[i].toInt() != 0) return false
        return true
    }

    /** Cevaptaki A kayıtlarının adresleri ("1.2.3.4"). Bozuksa boş liste. */
    fun aRecords(b: ByteArray, len: Int): List<String> {
        if (len < Packets.DNS_HDR) return emptyList()
        val flags = Packets.u16(b, 2)
        if ((flags and 0x8000) == 0 || (flags and 0x000F) != 0) return emptyList()
        val qd = Packets.u16(b, 4)
        val an = Packets.u16(b, 6)
        var p = Packets.DNS_HDR
        for (i in 0 until qd) {
            p = skipName(b, p, len)
            if (p < 0 || p + 4 > len) return emptyList()
            p += 4
        }
        val out = ArrayList<String>(2)
        for (i in 0 until an) {
            p = skipName(b, p, len)
            if (p < 0 || p + 10 > len) break
            val type = Packets.u16(b, p)
            val rdLen = Packets.u16(b, p + 8)
            val rd = p + 10
            if (rd + rdLen > len) break
            if (type == 1 && rdLen == 4) {
                out.add("${b[rd].toInt() and 0xFF}.${b[rd + 1].toInt() and 0xFF}.${b[rd + 2].toInt() and 0xFF}.${b[rd + 3].toInt() and 0xFF}")
            }
            p = rd + rdLen
        }
        return out
    }

    /**
     * İlk soru bölümünün bittiği konum ([base]'den bağımsız, mutlak konum): başlık + ad + tür + sınıf.
     * Soru yoksa ya da bozuksa -1. Sıkıştırma işaretçisi soru adında geçersizdir (sorgularda bulunmaz).
     */
    fun questionEnd(b: ByteArray, base: Int, n: Int): Int {
        if (n < Packets.DNS_HDR || base < 0 || base + n > b.size) return -1
        if (Packets.u16(b, base + 4) < 1) return -1
        val end = base + n
        var i = base + Packets.DNS_HDR
        while (true) {
            if (i >= end) return -1
            val l = b[i].toInt() and 0xFF
            if (l == 0) { i++; break }
            if ((l and 0xC0) != 0) return -1
            i += 1 + l
        }
        return if (i + 4 <= end) i + 4 else -1
    }

    /**
     * Cevap gerçekten bu sorunun cevabı mı? (RFC 5452: sahte cevaplara karşı.) Kimlik eşleşmesinin yanında:
     *  - QR=1 (cevap), OPCODE sorguyla aynı,
     *  - soru sayısı 1 ve soru bölümü (ad büyük/küçük harf duyarsız; tür ve sınıf birebir) sorguyla aynı.
     * Sorgu tek sorulu değilse yalnızca QR/OPCODE denetlenir. Nesne ayırmaz.
     *
     * [q]: sorgu, [qBase] başlangıcı, [qEnd] soru bölümünün sonu ([questionEnd]); [r]: cevap, [rBase], [rLen].
     */
    fun sameQuestion(q: ByteArray, qBase: Int, qEnd: Int, r: ByteArray, rBase: Int, rLen: Int): Boolean {
        if (rLen < Packets.DNS_HDR || rBase < 0 || rBase + rLen > r.size) return false
        val rf = Packets.u16(r, rBase + 2)
        if ((rf and 0x8000) == 0) return false
        val qf = Packets.u16(q, qBase + 2)
        if (((rf ushr 11) and 0xF) != ((qf ushr 11) and 0xF)) return false
        if (qEnd < 0 || Packets.u16(q, qBase + 4) != 1) return true
        // Bazı sunucular hatalı biçimli (FORMERR) ya da reddedilen sorularda soru bölümünü boş döner: kabul edilir,
        // ama kimlik dışında hiçbir şey taşımadığı için önbelleğe girmez (cevap sayısı 0).
        val rq = Packets.u16(r, rBase + 4)
        if (rq == 0) return Packets.u16(r, rBase + 6) == 0 && (rf and 0x000F) != 0
        if (rq != 1) return false
        val len = qEnd - (qBase + Packets.DNS_HDR)
        if (Packets.DNS_HDR + len > rLen) return false
        val nameEnd = qEnd - 4
        var i = 0
        while (i < len) {
            val qi = qBase + Packets.DNS_HDR + i
            val a = q[qi].toInt() and 0xFF
            val c = r[rBase + Packets.DNS_HDR + i].toInt() and 0xFF
            if (a != c) {
                // Ad içinde yalnızca ASCII harflerde büyük/küçük farkı kabul edilir (0x20 karıştırması).
                if (qi >= nameEnd) return false
                val la = if (a in 0x41..0x5A) a + 32 else a
                val lc = if (c in 0x41..0x5A) c + 32 else c
                if (la != lc) return false
            }
            i++
        }
        return true
    }

    /**
     * Önbellekten verilen cevaptaki TTL'leri geçen süre kadar azaltır (en az 0): istemci cevabı kalan süreden fazla
     * saklamasın. OPT (EDNS) kaydının TTL alanı başka anlam taşıdığı için atlanır. Bozuk mesajda dokunmadan durur.
     */
    fun ageTtls(b: ByteArray, base: Int, n: Int, elapsedSec: Int) {
        if (elapsedSec <= 0 || n < Packets.DNS_HDR || base < 0 || base + n > b.size) return
        val end = base + n
        val qd = Packets.u16(b, base + 4)
        val total = Packets.u16(b, base + 6) + Packets.u16(b, base + 8) + Packets.u16(b, base + 10)
        var p = base + Packets.DNS_HDR
        for (i in 0 until qd) {
            p = skipName(b, p, end)
            if (p < 0 || p + 4 > end) return
            p += 4
        }
        for (i in 0 until total) {
            p = skipName(b, p, end)
            if (p < 0 || p + 10 > end) return
            val type = Packets.u16(b, p)
            if (type != 41) {
                val ttl = Packets.i32(b, p + 4)
                val next = if (ttl <= elapsedSec) 0 else ttl - elapsedSec
                Packets.put32(b, p + 4, next)
            }
            val rdLen = Packets.u16(b, p + 8)
            p += 10 + rdLen
            if (p > end) return
        }
    }

    /** Cevaba "kesildi" (TC) bayrağı koyar: istemci tam cevabın gelmediğini bilsin. */
    fun setTruncated(b: ByteArray, base: Int) {
        b[base + 2] = (b[base + 2].toInt() or 0x02).toByte()
    }

    /**
     * Herkese açık, tek noktaya yayın (global unicast) IPv4 adresi mi? İlk çözümlemede (bootstrap) sahte ya da
     * yanlış yapılandırılmış bir cevabın bağlantıyı yerel ağa, döngüye ya da çok noktaya yayın adresine yöneltmesini engeller.
     */
    fun isGlobalIpv4(a: Int, b: Int, c: Int, d: Int): Boolean = when {
        a == 0 || a == 10 || a == 127 || a >= 224 -> false               // "bu ağ", özel, döngü, çoklu yayın, ayrılmış
        a == 100 && b in 64..127 -> false                                // operatör NAT'ı (CGNAT)
        a == 169 && b == 254 -> false                                    // bağlantı-yerel
        a == 172 && b in 16..31 -> false                                 // özel
        a == 192 && b == 168 -> false                                    // özel
        a == 192 && b == 0 && c == 0 -> false                            // IETF protokol atamaları
        a == 192 && b == 0 && c == 2 -> false                            // belgeleme
        a == 198 && (b == 18 || b == 19) -> false                        // karşılaştırma testleri
        a == 198 && b == 51 && c == 100 -> false                         // belgeleme
        a == 203 && b == 0 && c == 113 -> false                          // belgeleme
        else -> true
    }

    /** "name" için A kaydı sorgusu üretir (RD biti açık). */
    fun buildQuery(id: Int, name: String): ByteArray {
        val labels = name.split('.')
        var size = Packets.DNS_HDR + 1 + 4
        for (l in labels) size += 1 + l.length
        val b = ByteArray(size)
        Packets.put16(b, 0, id)
        Packets.put16(b, 2, 0x0100)
        Packets.put16(b, 4, 1)
        var p = Packets.DNS_HDR
        for (l in labels) {
            b[p++] = l.length.toByte()
            for (ch in l) b[p++] = ch.code.toByte()
        }
        b[p++] = 0
        Packets.put16(b, p, 1)       // A
        Packets.put16(b, p + 2, 1)   // IN
        return b
    }
}
