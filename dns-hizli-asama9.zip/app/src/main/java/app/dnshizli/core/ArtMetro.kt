package app.dnshizli.core

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Frutiger Metro: düz, gölgesiz, keskin köşeli karolar; cam, parlama ve kabarcık yok. Renk teması aynen çalışır:
 * zemin düz tek renk, karolar tema renginde yarı saydam düz yüzeyler, seçili öğe kalın vurgu çerçevesi ve sol şerit.
 * Hareket: karolar yana yatarak girer (turnike), basılınca karo içeri çöker, küre düz halka + düz dolgu.
 */
class MetroArt(theme: AeroTheme, glass: Float) : AeroArt(theme, glass) {
    override val style: UiStyle get() = UiStyle.METRO
    override val particleMode: ParticleMode get() = ParticleMode.NONE
    override val motion: StyleMotion = StyleMotion(PageMotion.TURNSTILE, 0.32f, 0.035f, 0f)
    override val titleScale: Float get() = 1.22f

    private val bg: Int = if (dark) Rgb.lerp(theme.skyTop, 0xFF000000.toInt(), 0.25f)
        else Rgb.lerp(Rgb.lerp(theme.skyTop, theme.skyMid, 0.5f), Rgb.WHITE, 0.62f)
    private val line: Int = Rgb.alpha(if (dark) Rgb.WHITE else theme.shadow, if (dark) 0.16f else 0.16f)
    private val trackLine: Int = Rgb.alpha(theme.textSoft, 0.75f)

    override fun sky(g: Gfx, w: Float, h: Float) {
        g.paint(bg); g.rect(0f, 0f, w, h)
    }

    override fun skyFrame(g: Gfx, w: Float, h: Float, live: Boolean, time: Float) = sky(g, w, h)

    override fun bubble(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float) {}
    override fun particle(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float, phase: Float) {}

    private fun pressK(g: Gfx, l: Float, t: Float, r: Float, b: Float, press: Float) {
        if (press > 0f) {
            val k = 1f - 0.04f * press
            val cx = (l + r) / 2f
            val cy = (t + b) / 2f
            g.translate(cx, cy); g.scale(k, k); g.translate(-cx, -cy)
        }
    }

    override fun card(
        g: Gfx, l: Float, t: Float, r: Float, b: Float, rad: Float,
        selected: Float, press: Float, strong: Float, shadow: Float,
    ) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        g.save()
        pressK(g, l, t, r, b, press)
        g.translate(l, t)
        val a = min(1f, (aTop + aBot) / 2f + 0.14f)
        val body = a + (1f - a) * strong.coerceIn(0f, 1f)
        g.paint(tint(body)); g.rect(0f, 0f, w, h)
        g.strokeWidth(1f); g.paint(line); g.strokeRoundRect(0.5f, 0.5f, w - 0.5f, h - 0.5f, 0f)
        if (selected > 0f) {
            g.save(); g.alpha(selected)
            g.paint(Rgb.alpha(theme.accent, 0.16f)); g.rect(0f, 0f, w, h)
            g.strokeWidth(2.4f); g.paint(theme.accent); g.strokeRoundRect(1.2f, 1.2f, w - 1.2f, h - 1.2f, 0f)
            g.paint(theme.accent); g.rect(0f, 0f, 5f, h)
            g.restore()
        }
        if (press > 0f) { g.save(); g.alpha(press); g.paint(Rgb.alpha(theme.accent, 0.14f)); g.rect(0f, 0f, w, h); g.restore() }
        g.restore()
    }

    override fun pill(g: Gfx, l: Float, t: Float, r: Float, b: Float, press: Float, shadow: Float) {
        if (r - l <= 1f || b - t <= 1f) return
        g.paint(theme.control); g.roundRect(l, t, r, b, 2f)
        if (press > 0f) { g.save(); g.alpha(press); g.paint(Rgb.alpha(theme.shadow, 0.25f)); g.roundRect(l, t, r, b, 2f); g.restore() }
    }

    override fun orb(g: Gfx, cx: Float, cy: Float, r: Float, level: Float, phase: Float, glow: Float, error: Float, press: Float) {
        val lv = level.coerceIn(0f, 1f)
        val er = error.coerceIn(0f, 1f)
        val col = Rgb.lerp(theme.control, ERR_MID, er)
        g.save()
        g.translate(cx, cy)
        val k = 1f - 0.05f * press
        g.scale(k, k)
        // dıştan dışa yayılan ince halka (bağlıyken)
        if (glow > 0.02f) {
            val pulse = 0.5f + 0.5f * sin(phase * 1.2f)
            g.save(); g.alpha(glow * (0.55f - 0.30f * pulse))
            g.strokeWidth(2f); g.paint(col); g.strokeCircle(0f, 0f, r + 5f + 5f * pulse)
            g.restore()
        }
        g.paint(if (dark) white(0.08f) else white(0.60f)); g.circle(0f, 0f, r)
        if (lv > 0.01f) {
            g.save(); g.clipCircle(0f, 0f, r - 4f)
            g.paint(col); g.rect(-r, r - 2f * r * lv, r, r)
            g.restore()
        }
        g.strokeWidth(5f); g.paint(col); g.strokeCircle(0f, 0f, r - 2.5f)
        val mix = Easing.clamp01((lv - 0.38f) / 0.20f)
        val off = if (dark) theme.accentLight else theme.controlDeep
        Icons.draw(g, Icon.POWER, 0f, r * 0.04f, r * 0.62f, Rgb.lerp(off, Rgb.WHITE, mix), 3.2f)
        g.restore()
    }

    override fun switch(g: Gfx, l: Float, t: Float, w: Float, h: Float, on: Float, press: Float) {
        val o = on.coerceIn(0f, 1f)
        g.save(); g.translate(l, t)
        g.strokeWidth(2f); g.paint(Rgb.lerp(trackLine, theme.control, o)); g.strokeRoundRect(1f, 1f, w - 1f, h - 1f, 1f)
        if (o > 0.001f) { g.save(); g.alpha(o); g.paint(theme.control); g.rect(3.5f, 3.5f, w - 3.5f, h - 3.5f); g.restore() }
        val kw = 7f + press * 2f
        val kx = 5f + (w - 10f - kw) * o
        g.paint(Rgb.lerp(theme.text, Rgb.WHITE, o)); g.rect(kx, 5f, kx + kw, h - 5f)
        g.restore()
    }

    override fun slider(g: Gfx, l: Float, cy: Float, w: Float, v: Float, press: Float) {
        val kx = l + 7f + (w - 14f) * v.coerceIn(0f, 1f)
        g.paint(Rgb.alpha(theme.textSoft, 0.35f)); g.rect(l, cy - 2f, l + w, cy + 2f)
        g.paint(theme.control); g.rect(l, cy - 2f, kx, cy + 2f)
        val hw = 6f + press * 1.5f
        g.paint(theme.text); g.rect(kx - hw, cy - 13f, kx + hw, cy + 13f)
    }

    override fun segmented(g: Gfx, l: Float, t: Float, r: Float, b: Float, n: Int, pos: Float) {
        val w = r - l
        g.strokeWidth(1.5f); g.paint(trackLine); g.strokeRoundRect(l + 0.75f, t + 0.75f, r - 0.75f, b - 0.75f, 0f)
        val inset = 3f
        val sw = (w - inset * 2f) / n
        val x = inset + sw * pos.coerceIn(0f, (n - 1).toFloat())
        g.paint(theme.control); g.rect(l + x, t + inset, l + x + sw, b - inset)
    }

    override fun bars(g: Gfx, x: Float, bottom: Float, level: Int, active: Boolean, colored: Boolean) {
        val on = when {
            colored && level >= 3 -> if (dark) 0xFF5BD47A.toInt() else 0xFF1E7F3A.toInt()
            colored && level == 2 -> if (dark) 0xFFF2B544.toInt() else 0xFF9A5B00.toInt()
            colored && level == 1 -> if (dark) 0xFFFF8A7A.toInt() else 0xFFB3261E.toInt()
            active -> theme.link
            else -> Rgb.alpha(theme.textSoft, 0.85f)
        }
        val off = Rgb.alpha(theme.textSoft, 0.22f)
        for (i in 0 until 4) {
            val bh = 5f + i * 3f
            g.paint(if (i < level) on else off)
            g.rect(x + i * 5.2f, bottom - bh, x + i * 5.2f + 3.4f, bottom)
        }
    }

    override fun swatch(g: Gfx, cx: Float, cy: Float, r: Float, t: AeroTheme?, selected: Float) {
        val a = t ?: Themes.aqua
        g.paint(if (t == null) Themes.aqua.skyMid else a.skyMid); g.circle(cx, cy, r)
        if (t == null) { g.save(); g.clipCircle(cx, cy, r); g.paint(Themes.night.skyMid); g.rect(cx, cy - r, cx + r, cy + r); g.restore() }
        g.paint(a.accent); g.circle(cx, cy, r * 0.46f)
        g.strokeWidth(1.2f); g.paint(Rgb.alpha(theme.textSoft, 0.55f)); g.strokeCircle(cx, cy, r - 0.6f)
        if (selected > 0.001f) {
            g.save(); g.alpha(selected)
            g.strokeWidth(2.6f); g.paint(theme.link); g.strokeCircle(cx, cy, r + 4.2f)
            g.restore()
        }
    }

    override fun iconDisc(g: Gfx, cx: Float, cy: Float, r: Float) {
        g.paint(Rgb.alpha(theme.accent, if (dark) 0.30f else 0.22f)); g.roundRect(cx - r, cy - r, cx + r, cy + r, 2f)
    }

    override fun badge(g: Gfx, cx: Float, cy: Float, r: Float) {
        g.paint(theme.control); g.circle(cx, cy, r)
        Icons.draw(g, Icon.CHECK, cx, cy, r * 1.35f, Rgb.WHITE, 2.6f)
    }

    override fun bar(g: Gfx, w: Float, h: Float, a: Float, skyH: Float) {
        if (a <= 0.01f) return
        g.save(); g.alpha(a)
        g.paint(bg); g.rect(0f, 0f, w, h)
        g.paint(line); g.rect(0f, h - 1f, w, h)
        g.restore()
    }

    override fun grabber(g: Gfx, cx: Float, y: Float) {
        g.paint(Rgb.alpha(theme.textSoft, 0.6f)); g.rect(cx - 18f, y, cx + 18f, y + 3f)
    }
}
