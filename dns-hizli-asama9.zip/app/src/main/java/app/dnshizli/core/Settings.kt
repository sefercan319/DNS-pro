package app.dnshizli.core

enum class Motion(val id: String) {
    FULL("full"), REDUCED("reduced"), OFF("off");

    /** Animasyon sürelerinin çarpanı. */
    val scale: Float get() = when (this) { FULL -> 1f; REDUCED -> 0.5f; OFF -> 0f }
}

enum class BubbleLevel(val id: String, val count: Int) {
    OFF("off", 0), FEW("few", 7), MANY("many", 15)
}

enum class CacheLevel(val id: String, val entries: Int) {
    OFF("off", 0), SMALL("small", 64), NORMAL("normal", 256), LARGE("large", 1024)
}

/** Sunucu listesinin sırası. */
enum class SortMode(val id: String) { DEFAULT("default"), SPEED("speed"), NAME("name") }

/** "Gece temasını saate bağla" için saat aralığı ([from]:00'dan [to]:00'a). */
enum class NightHours(val id: String, val from: Int, val to: Int) {
    H22_07("22-07", 22, 7), H21_06("21-06", 21, 6), H23_08("23-08", 23, 8), H20_06("20-06", 20, 6);

    fun isNight(hour: Int): Boolean = if (from > to) hour >= from || hour < to else hour in from until to

    /** "22–07" biçiminde (rakamlar her dilde aynı). */
    val label: String get() = String.format(java.util.Locale.ROOT, "%02d–%02d", from, to)
}

/** Uygulama içi yazı boyutu; sistemin yazı ölçeğiyle çarpılır, sonuç 0,9..1,3 aralığında kalır. */
enum class TextScale(val id: String, val factor: Float) {
    SMALL("small", 0.9f), NORMAL("normal", 1f), LARGE("large", 1.15f), XLARGE("xlarge", 1.3f)
}

/** Kullanıcının tüm seçimleri. Değişmez; her değişiklik yeni bir kopya üretir. */
data class AppSettings(
    // Görünüm
    val lang: String = L.AUTO,
    val theme: String = Themes.AUTO_ID,
    val themeSchedule: Boolean = false,
    val glass: Float = 0.55f,
    val bubbles: BubbleLevel = BubbleLevel.FEW,
    val motion: Motion = Motion.FULL,
    val textScale: TextScale = TextScale.NORMAL,
    val highContrast: Boolean = false,
    val minimal: Boolean = false,
    val haptics: Boolean = true,
    val lowPower: Boolean = false,
    /** "Otomatik" temanın açık ve koyu modda kullanacağı temalar. */
    val autoLight: String = "aqua",
    val autoDark: String = "night",
    val nightHours: NightHours = NightHours.H22_07,
    // Bağlantı
    val encryption: Encryption = Encryption.AUTO,
    /** Otomatik şifrelemede şifreli bağlantı kurulamazsa şifresiz DNS'e düşme (bağlanma). */
    val strictEncryption: Boolean = false,
    val autoConnect: Boolean = false,
    val connectOnBoot: Boolean = false,
    val autoFastest: Boolean = false,
    val refreshOnNetwork: Boolean = true,
    val notifyDrop: Boolean = true,
    /** Bağlantı beklenmedik koparsa artan aralıklarla kendiliğinden yeniden bağlan. */
    val autoReconnect: Boolean = true,
    /** Seçili sunucu yanıt vermezse bağlanılacak yedek: null kapalı, [AppSettings.BACKUP_AUTO] en hızlı, ya da sunucu kimliği. */
    val backupServer: String? = null,
    /** Bağlantıyı kesmeden önce onay iste. */
    val confirmDisconnect: Boolean = false,
    /** Kilit ekranındaki bildirimde sunucu adını gizle. */
    val hideOnLockscreen: Boolean = false,
    /** Durum bildirimi sessiz ve küçük (durum çubuğunda simge yok). */
    val quietNotification: Boolean = false,
    val cache: CacheLevel = CacheLevel.NORMAL,
    val wifiServer: String? = null,
    val mobileServer: String? = null,
    // Liste
    val lastServer: String? = null,
    val favorites: Set<String> = emptySet(),
    val recent: List<String> = emptyList(),
    val hidden: Set<String> = emptySet(),
    val sortMode: SortMode = SortMode.DEFAULT,
    val compact: Boolean = false,
    /** Ana ekran açılınca son seçilen süzgeç geri gelsin. */
    val rememberFilter: Boolean = true,
    val lastFilter: String = "all",
    /** Uygulama açılınca, son ölçüm 1 günden eskiyse hızları kendiliğinden ölç. */
    val autoMeasure: Boolean = false,
    /** Hız ölçümü şifreli yöntemle (DoT) yapılsın. */
    val measureEncrypted: Boolean = false,
    // İlk açılış bilgilendirmesi gösterildi ve kabul edildi mi
    val onboarded: Boolean = false,
    /** "Neler yeni" en son hangi sürüm için gösterildi. */
    val lastSeenVersion: Int = 0,
    // Durum (servis yazar)
    val wasActive: Boolean = false,
    // Kalıcı toplam istatistik (servis yazar)
    val totalQueries: Long = 0,
    val totalHits: Long = 0,
    val totalBlocked: Long = 0,
    val totalSeconds: Long = 0,
    /** Günlük sorgu sayıları: "yyyymmdd=sayı;…" (en çok [DailyStats.KEEP] gün). */
    val daily: String = "",
    /** Ağdan cevaplanan sorgu sayısı ve bunların toplam bekleme süresi (ortalama yanıt süresi için). */
    val totalAnswered: Long = 0,
    val totalLatencyMs: Long = 0,
    /** Sunucuya gönderilen / sunucudan alınan DNS verisi (bayt). */
    val bytesUp: Long = 0,
    val bytesDown: Long = 0,
    /** Sunucu başına bağlı kalma süresi ([UsageStats] biçimi). */
    val usage: String = "",
    /** Son bağlantı oturumları ([SessionLog] biçimi). */
    val sessions: String = "",
    /** Kullanıcının eklediği DNS sunucuları ([CustomDns] biçimi). Dışa aktarılmaz. */
    val custom: String = "",
    /** DNS'in uygulanacağı uygulamalar. Cihaza özgüdür: dışa/içe aktarılmaz. */
    val appScope: AppScope = AppScope.ALL,
    val apps: Set<String> = emptySet(),
    /** Arayüz iskeleti ([UiStyle]). */
    val style: UiStyle = UiStyle.AQUA,
    /** Arka plan fotoğrafı var mı. Dosya cihazdadır; ayar dışa/içe aktarılmaz ([wpRev] ile birlikte). */
    val wallpaper: Boolean = false,
    /** Fotoğraf değiştikçe artar: sahne yeniden yükler. Cihaza özgüdür. */
    val wpRev: Int = 0,
    /** Fotoğraf üzerindeki perde yoğunluğu (0..0.8); okunabilirlik için gerekirse otomatik artırılır. */
    val wpDim: Float = WallpaperMath.DIM_DEFAULT,
    val wpBlur: WpBlur = WpBlur.OFF,
    /** Başlatıcıda görünen uygulama simgesi (stil adıyla). Bu telefona özgüdür: dışa/içe aktarılmaz. */
    val appIcon: UiStyle = UiStyle.AQUA,
    /** Kapalıyken son kullanılanlar, bağlantı geçmişi, ölçüm grafiği ve sunucu süreleri kaydedilmez. */
    val keepHistory: Boolean = true,
) {
    /** Hıza göre sıralama açık mı (eski arayüzle uyum). */
    val sortBySpeed: Boolean get() = sortMode == SortMode.SPEED

    /** Bu sunucuyla, şifreleme tercihleri altında sırayla denenecek yöntemler. Boşsa bağlanılamaz. */
    fun plan(s: DnsServer): List<Proto> = encryption.plan(s, strictEncryption)

    /** Ağdan gelen cevapların tüm zamanlar ortalaması (ms); veri yoksa null. */
    val avgLatencyMs: Int? get() = if (totalAnswered <= 0) null else (totalLatencyMs / totalAnswered).toInt()

    /** Önbellek sayesinde beklenmeyen tahmini süre (sn): önbellekten cevaplanan × ortalama yanıt süresi. */
    val savedSeconds: Long get() = (avgLatencyMs ?: 0).toLong() * totalHits / 1000
    /** Düşük güç modu animasyonları ve kabarcıkları kapatır. */
    val effectiveMotion: Motion get() = if (lowPower) Motion.OFF else motion
    val effectiveBubbles: BubbleLevel get() = if (lowPower) BubbleLevel.OFF else bubbles

    /** [id] son kullanılanların başına alınır (en çok [RECENT_MAX]). */
    fun withRecent(id: String): AppSettings =
        copy(recent = (listOf(id) + recent.filter { it != id }).take(RECENT_MAX))

    companion object {
        const val RECENT_MAX = 5
        const val BACKUP_AUTO = "auto"
    }
}

/** Ayarları düz metin sözlüğüne çevirir ve geri okur. Bozuk veya bilinmeyen değerler varsayılana düşer. */
object SettingsCodec {

    /** Kayıt biçiminin sürümü. Eski biçimdeki değerler [decode] sırasında yenisine taşınır. */
    const val VERSION = 2

    /** Servisin sahip olduğu alanlar: arayüz bunları yazmaz, dışa aktarmaya girmez. */
    val SERVICE_KEYS = setOf(
        "wasActive", "totalQueries", "totalHits", "totalBlocked", "totalSeconds", "daily",
        "totalAnswered", "totalLatencyMs", "bytesUp", "bytesDown", "usage", "sessions",
    )

    /** Dışa aktarılmayan yerel durum: onay, görülen sürüm, son süzgeç. */
    private val LOCAL_KEYS = setOf("onboarded", "lastSeenVersion", "lastFilter", "v", "lastServer", "recent", "custom", "appScope", "apps", "wallpaper", "wpRev", "appIcon")

    /** Eski sürümlerin anahtarları: depodan okunurken taşınmak için yüklenir, artık yazılmaz. */
    val LEGACY_KEYS = setOf("sortBySpeed")

    fun encode(s: AppSettings): Map<String, String> = linkedMapOf(
        "lang" to s.lang,
        "theme" to s.theme,
        "themeSchedule" to s.themeSchedule.toString(),
        "glass" to s.glass.toString(),
        "bubbles" to s.bubbles.id,
        "motion" to s.motion.id,
        "textScale" to s.textScale.id,
        "highContrast" to s.highContrast.toString(),
        "minimal" to s.minimal.toString(),
        "haptics" to s.haptics.toString(),
        "lowPower" to s.lowPower.toString(),
        "autoLight" to s.autoLight,
        "autoDark" to s.autoDark,
        "nightHours" to s.nightHours.id,
        "encryption" to s.encryption.id,
        "strictEncryption" to s.strictEncryption.toString(),
        "autoConnect" to s.autoConnect.toString(),
        "connectOnBoot" to s.connectOnBoot.toString(),
        "autoFastest" to s.autoFastest.toString(),
        "refreshOnNetwork" to s.refreshOnNetwork.toString(),
        "notifyDrop" to s.notifyDrop.toString(),
        "autoReconnect" to s.autoReconnect.toString(),
        "backupServer" to (s.backupServer ?: ""),
        "confirmDisconnect" to s.confirmDisconnect.toString(),
        "hideOnLockscreen" to s.hideOnLockscreen.toString(),
        "quietNotification" to s.quietNotification.toString(),
        "cache" to s.cache.id,
        "wifiServer" to (s.wifiServer ?: ""),
        "mobileServer" to (s.mobileServer ?: ""),
        "lastServer" to (s.lastServer ?: ""),
        "favorites" to s.favorites.joinToString(","),
        "recent" to s.recent.joinToString(","),
        "hidden" to s.hidden.joinToString(","),
        "sortMode" to s.sortMode.id,
        "compact" to s.compact.toString(),
        "rememberFilter" to s.rememberFilter.toString(),
        "lastFilter" to s.lastFilter,
        "autoMeasure" to s.autoMeasure.toString(),
        "measureEncrypted" to s.measureEncrypted.toString(),
        "onboarded" to s.onboarded.toString(),
        "lastSeenVersion" to s.lastSeenVersion.toString(),
        "v" to VERSION.toString(),
        "wasActive" to s.wasActive.toString(),
        "totalQueries" to s.totalQueries.toString(),
        "totalHits" to s.totalHits.toString(),
        "totalBlocked" to s.totalBlocked.toString(),
        "totalSeconds" to s.totalSeconds.toString(),
        "daily" to s.daily,
        "totalAnswered" to s.totalAnswered.toString(),
        "totalLatencyMs" to s.totalLatencyMs.toString(),
        "bytesUp" to s.bytesUp.toString(),
        "bytesDown" to s.bytesDown.toString(),
        "usage" to s.usage,
        "sessions" to s.sessions,
        "custom" to s.custom,
        "appScope" to s.appScope.id,
        "apps" to AppScopes.encode(s.apps),
        "style" to s.style.id,
        "wallpaper" to s.wallpaper.toString(),
        "wpRev" to s.wpRev.toString(),
        "wpDim" to s.wpDim.toString(),
        "wpBlur" to s.wpBlur.id,
        "appIcon" to s.appIcon.id,
        "keepHistory" to s.keepHistory.toString(),
    )

    fun decode(m: Map<String, String?>): AppSettings {
        val d = AppSettings()
        // Özel sunucular önce yüklenir: aşağıdaki kimlik doğrulamaları (favori, son, kural) onları da tanısın.
        val customList = CustomDns.decode(m["custom"])
        Catalog.setCustom(customList)
        fun bool(k: String, def: Boolean) = when (m[k]) { "true" -> true; "false" -> false; else -> def }
        fun long(k: String) = m[k]?.toLongOrNull()?.coerceAtLeast(0) ?: 0L
        fun server(k: String) = m[k]?.takeIf { Catalog.byId(it) != null }
        fun ids(k: String) = m[k]?.split(',')?.filter { Catalog.byId(it) != null } ?: emptyList()
        fun theme(k: String, def: String) = m[k]?.takeIf { it != Themes.AUTO_ID && Themes.isValidId(it) } ?: def
        // Sürüm 1: sıralama tek bir açık/kapalı değerdi ("sortBySpeed").
        val sort = SortMode.values().firstOrNull { it.id == m["sortMode"] }
            ?: if (m["sortBySpeed"] == "true") SortMode.SPEED else d.sortMode
        return AppSettings(
            lang = m["lang"]?.takeIf { L.isValidSetting(it) } ?: d.lang,
            theme = m["theme"]?.takeIf { Themes.isValidId(it) } ?: d.theme,
            themeSchedule = bool("themeSchedule", d.themeSchedule),
            glass = m["glass"]?.toFloatOrNull()?.takeIf { !it.isNaN() }?.coerceIn(0f, 1f) ?: d.glass,
            bubbles = BubbleLevel.values().firstOrNull { it.id == m["bubbles"] } ?: d.bubbles,
            motion = Motion.values().firstOrNull { it.id == m["motion"] } ?: d.motion,
            textScale = TextScale.values().firstOrNull { it.id == m["textScale"] } ?: d.textScale,
            highContrast = bool("highContrast", d.highContrast),
            minimal = bool("minimal", d.minimal),
            haptics = bool("haptics", d.haptics),
            lowPower = bool("lowPower", d.lowPower),
            autoLight = theme("autoLight", d.autoLight),
            autoDark = theme("autoDark", d.autoDark),
            nightHours = NightHours.values().firstOrNull { it.id == m["nightHours"] } ?: d.nightHours,
            encryption = Encryption.values().firstOrNull { it.id == m["encryption"] } ?: d.encryption,
            strictEncryption = bool("strictEncryption", d.strictEncryption),
            autoConnect = bool("autoConnect", d.autoConnect),
            connectOnBoot = bool("connectOnBoot", d.connectOnBoot),
            autoFastest = bool("autoFastest", d.autoFastest),
            refreshOnNetwork = bool("refreshOnNetwork", d.refreshOnNetwork),
            notifyDrop = bool("notifyDrop", d.notifyDrop),
            autoReconnect = bool("autoReconnect", d.autoReconnect),
            backupServer = m["backupServer"]?.takeIf { it == AppSettings.BACKUP_AUTO || Catalog.byId(it) != null },
            confirmDisconnect = bool("confirmDisconnect", d.confirmDisconnect),
            hideOnLockscreen = bool("hideOnLockscreen", d.hideOnLockscreen),
            quietNotification = bool("quietNotification", d.quietNotification),
            cache = CacheLevel.values().firstOrNull { it.id == m["cache"] } ?: d.cache,
            wifiServer = server("wifiServer"),
            mobileServer = server("mobileServer"),
            lastServer = server("lastServer"),
            favorites = ids("favorites").toSet(),
            recent = ids("recent").distinct().take(AppSettings.RECENT_MAX),
            hidden = ids("hidden").toSet(),
            sortMode = sort,
            compact = bool("compact", d.compact),
            rememberFilter = bool("rememberFilter", d.rememberFilter),
            lastFilter = m["lastFilter"]?.takeIf { it.length in 1..16 && it.all { c -> c in 'a'..'z' } } ?: d.lastFilter,
            autoMeasure = bool("autoMeasure", d.autoMeasure),
            measureEncrypted = bool("measureEncrypted", d.measureEncrypted),
            onboarded = bool("onboarded", d.onboarded),
            lastSeenVersion = m["lastSeenVersion"]?.toIntOrNull()?.coerceIn(0, 1_000_000) ?: d.lastSeenVersion,
            wasActive = bool("wasActive", d.wasActive),
            totalQueries = long("totalQueries"),
            totalHits = long("totalHits"),
            totalBlocked = long("totalBlocked"),
            totalSeconds = long("totalSeconds"),
            daily = DailyStats.encode(DailyStats.decode(m["daily"])),
            totalAnswered = long("totalAnswered"),
            totalLatencyMs = long("totalLatencyMs"),
            bytesUp = long("bytesUp"),
            bytesDown = long("bytesDown"),
            usage = UsageStats.encode(UsageStats.decode(m["usage"])),
            sessions = SessionLog.encode(SessionLog.decode(m["sessions"])),
            custom = CustomDns.encode(customList),
            appScope = AppScope.values().firstOrNull { it.id == m["appScope"] } ?: d.appScope,
            apps = AppScopes.decode(m["apps"]),
            style = UiStyle.byId(m["style"]) ?: d.style,
            wallpaper = bool("wallpaper", d.wallpaper),
            wpRev = m["wpRev"]?.toIntOrNull()?.coerceIn(0, 1_000_000_000) ?: d.wpRev,
            wpDim = m["wpDim"]?.toFloatOrNull()?.takeIf { !it.isNaN() }?.coerceIn(WallpaperMath.DIM_MIN, WallpaperMath.DIM_MAX) ?: d.wpDim,
            wpBlur = WpBlur.byId(m["wpBlur"]) ?: d.wpBlur,
            appIcon = UiStyle.byId(m["appIcon"]) ?: d.appIcon,
            keepHistory = bool("keepHistory", d.keepHistory),
        )
    }

    // ------------------------------------------------------------------ dışa / içe aktarma

    private const val PREFIX = "DNSH1:"

    /** İçe aktarılan kodun en büyük boyu: panodaki dev bir metin bellek tüketmesin. */
    const val MAX_IMPORT = 16 * 1024

    /**
     * Ayarları tek satırlık bir koda çevirir (panoya kopyalanır). Servis alanları, istatistikler ve
     * ilk açılış onayı koda girmez. Biçim: "DNSH1:" + Base64(anahtar=değer satırları).
     */
    fun export(s: AppSettings): String {
        val body = encode(s).filterKeys { it !in SERVICE_KEYS && it !in LOCAL_KEYS }
            .entries.joinToString("\n") { (k, v) -> "$k=$v" }
        return PREFIX + Base64Mini.encode(body.toByteArray(Charsets.UTF_8))
    }

    /** [export] kodunu okur ve [base] üzerine uygular. Geçersizse null. Bilinmeyen anahtarlar yok sayılır. */
    fun import(code: String, base: AppSettings): AppSettings? {
        if (code.length > MAX_IMPORT) return null
        val t = code.trim()
        if (!t.startsWith(PREFIX)) return null
        val raw = Base64Mini.decode(t.removePrefix(PREFIX)) ?: return null
        val text = try { String(raw, Charsets.UTF_8) } catch (_: Exception) { return null }
        val incoming = HashMap<String, String>()
        for (line in text.split('\n')) {
            val eq = line.indexOf('=')
            if (eq <= 0) continue
            val k = line.substring(0, eq)
            if (k in SERVICE_KEYS || k in LOCAL_KEYS) continue
            incoming[k] = line.substring(eq + 1)
        }
        if (incoming.isEmpty()) return null
        val merged = HashMap<String, String?>(encode(base))
        merged.putAll(incoming)
        return decode(merged)
    }
}

/**
 * İçe aktarmada güvenliği etkileyen değişiklikler: kullanıcıya özet olarak gösterilir (paylaşılan bir kod sessizce
 * şifrelemeyi kapatmasın ya da otomatik bağlanmayı açmasın).
 */
enum class SensitiveChange { ENCRYPTION_WEAKER, AUTO_START, RULES, PRIVACY }

object ImportReview {
    fun changes(before: AppSettings, after: AppSettings): List<SensitiveChange> {
        val out = ArrayList<SensitiveChange>(3)
        val weaker = (after.encryption == Encryption.OFF && before.encryption != Encryption.OFF) ||
            (before.strictEncryption && !after.strictEncryption)
        if (weaker) out.add(SensitiveChange.ENCRYPTION_WEAKER)
        if ((after.autoConnect && !before.autoConnect) || (after.connectOnBoot && !before.connectOnBoot)) out.add(SensitiveChange.AUTO_START)
        if (after.wifiServer != before.wifiServer || after.mobileServer != before.mobileServer || after.backupServer != before.backupServer) {
            out.add(SensitiveChange.RULES)
        }
        // Uyarıları sustur / sunucu adını kilit ekranında göster: koruma sessizce gevşemesin.
        if ((before.notifyDrop && !after.notifyDrop) || (before.hideOnLockscreen && !after.hideOnLockscreen)) out.add(SensitiveChange.PRIVACY)
        return out
    }
}

/** Bağımlılıksız, küçük Base64 (Android ve JVM'de aynı sonuç). */
object Base64Mini {
    private const val A = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    fun encode(b: ByteArray): String {
        val sb = StringBuilder((b.size + 2) / 3 * 4)
        var i = 0
        while (i < b.size) {
            val n = ((b[i].toInt() and 0xFF) shl 16) or
                ((if (i + 1 < b.size) b[i + 1].toInt() and 0xFF else 0) shl 8) or
                (if (i + 2 < b.size) b[i + 2].toInt() and 0xFF else 0)
            sb.append(A[(n ushr 18) and 63]).append(A[(n ushr 12) and 63])
            sb.append(if (i + 1 < b.size) A[(n ushr 6) and 63] else '=')
            sb.append(if (i + 2 < b.size) A[n and 63] else '=')
            i += 3
        }
        return sb.toString()
    }

    fun decode(s: String): ByteArray? {
        val clean = s.filter { !it.isWhitespace() }
        if (clean.length % 4 != 0) return null
        val out = java.io.ByteArrayOutputStream(clean.length / 4 * 3)
        var i = 0
        while (i < clean.length) {
            var n = 0
            var pad = 0
            for (j in 0 until 4) {
                val c = clean[i + j]
                val v = if (c == '=') { pad++; 0 } else A.indexOf(c).also { if (it < 0) return null }
                if (c != '=' && pad > 0) return null
                n = (n shl 6) or v
            }
            out.write((n ushr 16) and 0xFF)
            if (pad < 2) out.write((n ushr 8) and 0xFF)
            if (pad < 1) out.write(n and 0xFF)
            i += 4
        }
        return out.toByteArray()
    }
}

/** Son 7 günün sorgu sayıları (haftalık grafik). Gün anahtarı yyyymmdd (cihazın yerel takvimiyle). */
object DailyStats {
    const val KEEP = 7

    fun decode(s: String?): Map<Int, Long> {
        if (s.isNullOrBlank()) return emptyMap()
        val out = java.util.TreeMap<Int, Long>()
        for (p in s.split(';')) {
            val eq = p.indexOf('=')
            if (eq <= 0) continue
            val day = p.substring(0, eq).toIntOrNull() ?: continue
            val n = p.substring(eq + 1).toLongOrNull() ?: continue
            if (day in 19700101..29991231 && n >= 0) out[day] = n
        }
        return out
    }

    fun encode(m: Map<Int, Long>): String =
        m.entries.sortedBy { it.key }.takeLast(KEEP).joinToString(";") { "${it.key}=${it.value}" }

    /** [day] gününe [n] sorgu ekler; en eski günler atılır. */
    fun add(s: String, day: Int, n: Long): String {
        if (n <= 0) return encode(decode(s))
        val m = java.util.TreeMap(decode(s))
        m[day] = (m[day] ?: 0L) + n
        return encode(m)
    }

    /** Bugünle biten 7 gün (eskiden yeniye): (yyyymmdd, haftanın günü 0=Pzt..6=Paz, sayı). */
    fun lastWeek(s: String, todayMs: Long, tz: java.util.TimeZone = java.util.TimeZone.getDefault()): List<Triple<Int, Int, Long>> {
        val m = decode(s)
        val cal = java.util.Calendar.getInstance(tz)
        cal.timeInMillis = todayMs
        cal.add(java.util.Calendar.DAY_OF_MONTH, -(KEEP - 1))
        val out = ArrayList<Triple<Int, Int, Long>>(KEEP)
        repeat(KEEP) {
            val key = dayKey(cal)
            val dow = (cal.get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7   // Pazartesi=0
            out.add(Triple(key, dow, m[key] ?: 0L))
            cal.add(java.util.Calendar.DAY_OF_MONTH, 1)
        }
        return out
    }

    fun dayKey(cal: java.util.Calendar): Int =
        cal.get(java.util.Calendar.YEAR) * 10000 + (cal.get(java.util.Calendar.MONTH) + 1) * 100 + cal.get(java.util.Calendar.DAY_OF_MONTH)

    fun today(nowMs: Long, tz: java.util.TimeZone = java.util.TimeZone.getDefault()): Int {
        val cal = java.util.Calendar.getInstance(tz)
        cal.timeInMillis = nowMs
        return dayKey(cal)
    }
}

/** Sunucu başına toplam bağlı kalma süresi (sn). Biçim: "id=saniye;…". En çok [KEEP] sunucu (en çok kullanılanlar) tutulur. */
object UsageStats {
    const val KEEP = 30

    fun decode(s: String?): Map<String, Long> {
        if (s.isNullOrBlank()) return emptyMap()
        val out = LinkedHashMap<String, Long>()
        for (p in s.split(';')) {
            val eq = p.indexOf('=')
            if (eq <= 0) continue
            val id = p.substring(0, eq)
            if (Catalog.byId(id) == null) continue
            val n = p.substring(eq + 1).toLongOrNull() ?: continue
            if (n > 0) out[id] = (out[id] ?: 0L) + n
        }
        return out
    }

    fun encode(m: Map<String, Long>): String =
        m.entries.filter { it.value > 0 }.sortedByDescending { it.value }.take(KEEP).joinToString(";") { "${it.key}=${it.value}" }

    fun add(s: String, id: String?, seconds: Long): String {
        if (id == null || seconds <= 0 || Catalog.byId(id) == null) return encode(decode(s))
        val m = LinkedHashMap(decode(s))
        m[id] = (m[id] ?: 0L) + seconds
        return encode(m)
    }

    /** En çok kullanılan [n] sunucu (çoktan aza). */
    fun top(s: String, n: Int): List<Pair<String, Long>> =
        decode(s).entries.sortedByDescending { it.value }.take(n).map { it.key to it.value }
}

/** Bir bağlantı oturumunun nasıl bittiği. */
enum class EndReason(val id: String) {
    USER("user"), PAUSE("pause"), SWITCH("switch"), DROP("drop"), REVOKED("revoked"), FAILED("failed"), NETWORK("network");

    companion object {
        fun byId(id: String?): EndReason? = values().firstOrNull { it.id == id }
    }
}

/** Bağlantı geçmişindeki bir oturum. */
data class Session(
    val serverId: String,
    val proto: Proto,
    val startMs: Long,
    val endMs: Long,
    val end: EndReason,
    val queries: Long,
) {
    val seconds: Long get() = maxOf(0L, (endMs - startMs) / 1000)
}

/** Son [KEEP] oturum. Biçim: "id,yöntem,başlangıç,bitiş,neden,sorgu|…" (en yeni sonda). */
object SessionLog {
    const val KEEP = 30

    fun decode(s: String?): List<Session> {
        if (s.isNullOrBlank()) return emptyList()
        val out = ArrayList<Session>()
        for (p in s.split('|')) {
            val f = p.split(',')
            if (f.size != 6) continue
            val id = f[0].takeIf { Catalog.byId(it) != null } ?: continue
            val proto = Proto.values().firstOrNull { it.name == f[1] } ?: continue
            val start = f[2].toLongOrNull() ?: continue
            val end = f[3].toLongOrNull() ?: continue
            val reason = EndReason.byId(f[4]) ?: continue
            val q = f[5].toLongOrNull()?.coerceAtLeast(0) ?: continue
            if (start <= 0 || end < start) continue
            out.add(Session(id, proto, start, end, reason, q))
        }
        return out.takeLast(KEEP)
    }

    fun encode(l: List<Session>): String =
        l.takeLast(KEEP).joinToString("|") { "${it.serverId},${it.proto.name},${it.startMs},${it.endMs},${it.end.id},${it.queries}" }

    fun add(s: String, session: Session): String = encode(decode(s) + session)
}
