package app.dnshizli.platform

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import app.dnshizli.core.NetInfo
import app.dnshizli.core.NetKind
import app.dnshizli.core.Rules

/**
 * Fiziksel ağlardaki (VPN hariç) değişiklikleri izler: Wi-Fi <-> mobil geçişi, ağın kaybolması, doğrulanması.
 * Değişiklik 0,5 sn beklenip tek olay olarak bildirilir ([onChanged], ana iş parçacığında). Sistem olay
 * üretmedikçe hiçbir şey çalışmaz: elle yoklama veya zamanlayıcı yoktur.
 */
class NetworkWatcher(context: Context, private val onChanged: (NetKind) -> Unit) {
    private val cm = context.applicationContext.getSystemService(ConnectivityManager::class.java)
    private val main = Handler(Looper.getMainLooper())

    // Aşağıdakilere yalnızca ana iş parçacığından dokunulur.
    private val nets = LinkedHashMap<Network, NetworkCapabilities>()
    private var lastSig: String? = null
    private var registered = false

    private val evaluate = Runnable { evaluateNow() }

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            nets[network] = caps
            schedule()
        }

        override fun onLost(network: Network) {
            nets.remove(network)
            schedule()
        }
    }

    fun start() {
        main.post {
            if (registered || cm == null) return@post
            nets.clear()
            lastSig = null
            try {
                val req = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                    .build()
                cm.registerNetworkCallback(req, callback, main)
                registered = true
                schedule()          // ilk değerlendirme başlangıç durumunu (taban çizgisini) belirler
            } catch (_: Exception) {
                // izin yok ya da sistem reddetti: ağ izleme olmadan devam
            }
        }
    }

    fun stop() {
        main.post {
            main.removeCallbacks(evaluate)
            if (registered) {
                try { cm?.unregisterNetworkCallback(callback) } catch (_: Exception) {}
                registered = false
            }
            nets.clear()
            lastSig = null
        }
    }

    private fun schedule() {
        main.removeCallbacks(evaluate)
        main.postDelayed(evaluate, DEBOUNCE_MS)
    }

    private fun evaluateNow() {
        val kind = Rules.pick(nets.values.map { info(it) })
        val sig = buildString {
            for ((n, c) in nets) {
                append(n.toString()).append(if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) "+" else "-").append(';')
            }
            append(kind)
        }
        if (sig == lastSig) return
        val baseline = lastSig == null
        lastSig = sig
        if (!baseline) onChanged(kind)
    }

    companion object {
        private const val DEBOUNCE_MS = 500L

        private fun info(c: NetworkCapabilities) = NetInfo(
            wifi = c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI),
            cellular = c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR),
            ethernet = c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET),
            validated = c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED),
        )

        /** Şu an hangi tür ağın kullanıldığı (tek seferlik okuma; izleme gerektirmez). */
        @Suppress("DEPRECATION")
        fun currentKind(context: Context): NetKind {
            val cm = context.applicationContext.getSystemService(ConnectivityManager::class.java) ?: return NetKind.NONE
            return try {
                val list = ArrayList<NetInfo>()
                for (n in cm.allNetworks) {
                    val c = cm.getNetworkCapabilities(n) ?: continue
                    if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                    if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN).not()) continue
                    list.add(info(c))
                }
                Rules.pick(list)
            } catch (_: Exception) {
                NetKind.NONE
            }
        }
    }
}
