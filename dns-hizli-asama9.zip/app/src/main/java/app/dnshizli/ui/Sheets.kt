package app.dnshizli.ui

import app.dnshizli.core.ALIGN_LEFT
import app.dnshizli.core.ALIGN_RIGHT
import app.dnshizli.core.Catalog
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Format
import app.dnshizli.core.GPath
import app.dnshizli.core.Gfx
import app.dnshizli.core.Icon
import app.dnshizli.core.LatencyHistory
import app.dnshizli.core.AdBlockResult
import app.dnshizli.core.DnssecResult
import app.dnshizli.core.OrbState
import app.dnshizli.core.Rgb
import app.dnshizli.core.Tag
import app.dnshizli.core.TextFit

/**
 * Alttan açılan cam panel (modal). İçerik [body] bir sütundur; panel içeriğe göre büyür, ekrana sığmazsa kayar.
 * Boş yere (panelin dışına) dokunmak veya geri tuşu kapatır.
 */
class Sheet(private val body: Column, private val onDismiss: () -> Unit) : Node() {
    val open = Anim(0f)
    var closing = false
        private set
    private val scroll = ScrollView()
    private var px = 0f
    private var pw = 0f
    private var ptop = 0f
    private var pbottom = 0f

    override val tappable: Boolean get() = true

    init {
        scroll.setContent(body)
        add(scroll)
    }

    fun layoutSheet(env: Env) {
        x = 0f; y = 0f
        w = env.width; h = env.height
        val cw = minOf(w, M.MAX_W)
        pw = cw - 24f
        px = (w - pw) / 2f
        body.layout(env, pw)
        val maxH = env.height - env.insetTop - env.insetBottom - 64f
        val vh = minOf(body.h, maxH)
        scroll.setViewport(env, pw, vh)
        pbottom = env.height - env.insetBottom - 12f
        ptop = pbottom - vh - 22f
        scroll.x = px
        scroll.y = ptop + 22f
    }

    fun show(env: Env) { closing = false; open.set(0f); open.go(1f, env.dur(0.34f)) }

    /** İçerik boyu değişti (ör. yeni ölçüm grafiği): paneli yeniden yerleştir. */
    fun relayout(env: Env) { layoutSheet(env) }

    fun close(env: Env) {
        if (closing) return
        closing = true
        open.go(0f, env.dur(0.24f), Ease.IN_OUT)
        if (env.motion <= 0f) open.set(0f)
    }

    val finished: Boolean get() = closing && !open.active && open.value <= 0.001f

    override fun contains(lx: Float, ly: Float): Boolean = !(lx >= px && lx <= px + pw && ly >= ptop && ly <= pbottom)

    override fun hit(lx: Float, ly: Float): Node? {
        if (open.active || closing) return this
        return super.hit(lx, ly)
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) { if (tap && !closing) onDismiss() }

    override fun tick(dt: Float, env: Env): Boolean {
        val a = open.step(dt)
        val b = tickKids(dt, env)
        return a || b
    }

    override fun draw(g: Gfx, env: Env) {
        val o = open.value
        if (o <= 0.001f) return
        g.paint(Rgb.alpha(env.theme.shadow, 0.42f * o)); g.rect(0f, 0f, w, h)
        g.save()
        g.translate(0f, (1f - o) * (h - ptop + 24f))
        env.art.card(g, px, ptop, px + pw, pbottom, 28f, strong = 1f, shadow = 1f)
        env.art.grabber(g, px + pw / 2f, ptop + 8f)
        drawKids(g, env)
        g.restore()
    }

    override fun a11y(): A11y? = null
}

/** Alt panel başlığı: solda başlık, sağda kapat düğmesi. */
class SheetTitle(private val text: String, onClose: () -> Unit) : Node() {
    private val label = Label(text, 22f, bold = true, maxLines = 2)
    private val close = IconButton(Icon.CLOSE, Strings.CLOSE, 40f, onClose)
    init { add(close) }
    override fun layout(env: Env, maxW: Float) {
        w = maxW
        close.layout(env, maxW)
        label.layout(env, w - close.w - 12f)
        h = maxOf(44f, label.h)
        close.x = w - close.w; close.y = (h - close.h) / 2f
        label.x = 0f; label.y = (h - label.h) / 2f
    }
    override fun draw(g: Gfx, env: Env) {
        g.save(); g.translate(label.x, label.y); label.draw(g, env); g.restore()
        drawKids(g, env)
    }
    override fun a11y(): A11y = A11y(text, Role.HEADING)
}

/** Küçük, dokunulmayan etiket hapı (ör. "Gizlilik"). */
class TagPill(private val text: String) : Node() {
    override fun layout(env: Env, maxW: Float) { w = env.metrics.textWidth(text, env.sz(12f), true) + 22f; h = 26f }
    override fun draw(g: Gfx, env: Env) {
        env.art.card(g, 0f, 0f, w, h, h / 2f, shadow = 0f)
        val fs = env.sz(12f)
        g.paint(env.theme.text)
        g.text(text, w / 2f, centerBaseline(h / 2f, fs), fs, true, app.dnshizli.core.ALIGN_CENTER)
    }
}

/** "Birincil  1.1.1.1  [kopyala]" satırı. */
class AddressRow(private val label: String, private val ip: String, private val model: AppModel) : Node() {
    private val copy = IconButton(Icon.COPY, Strings.COPY + " " + ip, 40f) { model.copy(ip) }
    init { add(copy) }
    override fun layout(env: Env, maxW: Float) {
        w = maxW; h = 60f
        copy.layout(env, maxW)
        copy.x = w - copy.w - 10f; copy.y = (h - copy.h) / 2f
    }
    override fun draw(g: Gfx, env: Env) {
        env.art.card(g, 0f, 0f, w, h, 18f, shadow = 0.4f)
        g.paint(env.theme.textSoft)
        g.text(label, 16f, h / 2f - 6f, env.sz(12.5f), false, ALIGN_LEFT)
        g.paint(env.theme.text)
        g.text(ip, 16f, h / 2f + 15f, env.sz(17f), true, ALIGN_LEFT)
        drawKids(g, env)
    }
    override fun a11y(): A11y = A11y(Strings.addressA11y(label, ip), Role.TEXT)
}

/** Tek satır bilgi: solda soluk başlık, sağda değer (ayrıntı panelinde). */
class KeyValueRow(private val key: String, var value: String) : Node() {
    override fun layout(env: Env, maxW: Float) { w = maxW; h = 30f }
    override fun draw(g: Gfx, env: Env) {
        val s = env.sz(14f)
        g.paint(env.theme.textSoft)
        g.text(key, 4f, centerBaseline(h / 2f, s), s, false, ALIGN_LEFT)
        g.paint(env.theme.text)
        val avail = w - 12f - env.metrics.textWidth(key, s, false)
        g.text(TextFit.ellipsize(env.metrics, value, avail, s, true), w - 4f, centerBaseline(h / 2f, s), s, true, ALIGN_RIGHT)
    }
    override fun a11y(): A11y = A11y("$key: $value", Role.TEXT)
}

/**
 * Son ölçümlerin küçük grafiği: her ölçüm bir nokta, cevapsızlar alt çizgide küçük işaret. Altında özet
 * (en iyi · ortanca · kayıp). Ölçüm yoksa hiç yer kaplamaz.
 */
class HistoryChart(private val serverId: String) : Node() {
    private var seen = -1
    private var values: List<Int?> = emptyList()
    private var summary = ""
    private val line = GPath()
    private var minV = 0
    private var span = 10

    private fun refresh(env: Env) {
        if (seen == env.model.version) return
        seen = env.model.version
        values = env.model.history[serverId] ?: emptyList()
        val best = LatencyHistory.best(values)
        val med = LatencyHistory.median(values)
        summary = if (best == null || med == null) "" else Strings.measureSummary(best, med, LatencyHistory.lossPct(values))
        val ok = values.filterNotNull()
        val maxV = maxOf(20, ok.maxOrNull() ?: 20)
        minV = ok.minOrNull() ?: 0
        span = maxOf(10, maxV - minV)
    }

    override fun layout(env: Env, maxW: Float) {
        seen = -1
        refresh(env)
        w = maxW
        h = if (values.isEmpty()) 0f else 96f
    }

    override fun tick(dt: Float, env: Env): Boolean { refresh(env); return false }

    override fun draw(g: Gfx, env: Env) {
        if (values.isEmpty()) return
        env.art.card(g, 0f, 0f, w, h, 18f, shadow = 0.4f)
        val s = env.sz(12.5f)
        g.paint(env.theme.textSoft)
        g.text(Strings.HISTORY, 16f, 20f, s, false, ALIGN_LEFT)
        val left = 18f
        val right = w - 18f
        val top = 30f
        val bottom = h - 30f
        val n = LatencyHistory.KEEP
        val step = (right - left) / (n - 1)
        val start = n - values.size
        line.reset()
        var first = true
        for (i in values.indices) {
            val v = values[i] ?: continue
            val x = left + (start + i) * step
            val y = bottom - (bottom - top) * ((v - minV).toFloat() / span)
            if (first) line.moveTo(x, y) else line.lineTo(x, y)
            first = false
        }
        g.strokeWidth(2.4f)
        g.paint(Rgb.alpha(env.theme.accentDeep, 0.9f))
        if (!first) g.strokePath(line)
        for (i in values.indices) {
            val x = left + (start + i) * step
            val v = values[i]
            if (v == null) {
                g.paint(Rgb.alpha(env.theme.textSoft, 0.8f))
                g.rect(x - 4f, bottom - 1f, x + 4f, bottom + 1f)
            } else {
                val y = bottom - (bottom - top) * ((v - minV).toFloat() / span)
                g.paint(env.theme.accentDeep)
                g.circle(x, y, 3.2f)
            }
        }
        if (summaryFor != w || summaryFs != env.fs || summarySrc !== summary) {
            summaryFor = w; summaryFs = env.fs; summarySrc = summary
            summaryShown = TextFit.ellipsize(env.metrics, summary, w - 32f, s, false)
        }
        g.paint(env.theme.text)
        g.text(summaryShown, 16f, h - 10f, s, false, ALIGN_LEFT)
    }

    private var summaryShown = ""
    private var summarySrc: String? = null
    private var summaryFor = -1f
    private var summaryFs = 0f

    override fun a11y(): A11y? =
        if (values.isEmpty()) null else A11y(Strings.historyA11y(values.size, LatencyHistory.median(values)) + ". " + summary, Role.TEXT)
}

/** Sunucu ayrıntıları: etiketler, adresler, şifreleme, ölçümler ve eylemler. Model değişince kendini günceller. */
class DetailsContent(
    private val server: DnsServer,
    private val model: AppModel,
    private val close: () -> Unit,
) : Column(gap = 12f, padL = 20f, padT = 4f, padR = 20f, padB = 22f) {
    private val note = Label(server.note, 15f, ink = Ink.SOFT, maxLines = 0)
    private val lat = Label("", 14f, ink = Ink.SOFT)
    private val enc = KeyValueRow(Strings.ENC_SUPPORT, encText())
    private val avg = KeyValueRow(Strings.INFO_AVG, "")
    private val delBtn = ActionButton(Strings.CUSTOM_DELETE, false) { if (model.removeCustom(server.id)) close() }
    private val editBtn = ActionButton(Strings.CUSTOM_EDIT, false) { close(); model.editCustom(server.id) }
    private val history = HistoryChart(server.id)
    private val connectBtn = ActionButton("", true) { model.tapServer(server.id); close() }
    private val favBtn = ActionButton("", false) { model.toggleFavorite(server.id) }
    private val measureBtn = ActionButton(Strings.MEASURE_THIS, false) { model.measure(listOf(server.id)) }
    private val hideBtn = ActionButton("", false) {
        if (server.id in model.settings.hidden) model.unhide(server.id) else { model.hide(server.id); close() }
    }
    private var seen = -1

    init {
        add(SheetTitle(server.name, close))
        if (server.tags.isNotEmpty()) {
            val tags = Row(gap = 8f)
            for (t in server.tags) tags.add(TagPill(t.label))
            add(tags)
        }
        add(AddressRow(Strings.PRIMARY, server.primary, model))
        server.secondary?.let { add(AddressRow(Strings.SECONDARY, it, model)) }
        add(enc)
        if (!server.plain) add(Label(Strings.ENC_ONLY, 13f, ink = Ink.SOFT, maxLines = 0))
        // DoT adı Android'in "Özel DNS" ayarına yazılabilecek addır.
        server.dot?.let {
            add(AddressRow(Strings.PRIVATE_DNS, it, model))
            add(Label(Strings.PRIVATE_DNS_NOTE, 13f, ink = Ink.SOFT, maxLines = 0))
        }
        add(lat)
        add(history)
        add(connectBtn)
        add(ButtonsRow(listOf(favBtn, measureBtn)))
        add(hideBtn)
        if (server.custom) { add(editBtn); add(delBtn) }
        // Bilgi bölümü (altta, kaydırınca): ne işe yarar, sahibi, ortalama ping. Üstte eylemler görünür kalır.
        add(Spacer(4f))
        add(Label(Strings.INFO_PURPOSE, 13f, ink = Ink.SOFT))
        add(note)
        server.owner?.let { add(KeyValueRow(Strings.INFO_OWNER, it)) }
        add(avg)
        refresh(true)
    }

    private fun encText(): String {
        val p = listOfNotNull(if (server.dot != null) "DoT" else null, if (server.doh != null) "DoH" else null)
        return if (p.isEmpty()) Strings.ENC_NONE else p.joinToString(" · ")
    }

    private fun refresh(force: Boolean) {
        if (!force && seen == model.version) return
        seen = model.version
        val connectedHere = model.vpn.active && model.vpn.serverId == server.id
        connectBtn.text = when {
            connectedHere -> Strings.CONNECTED_NOW
            model.vpn.active -> Strings.SWITCH_TO_THIS
            else -> Strings.CONNECT_TO_THIS
        }
        connectBtn.enabled = !connectedHere && model.canUse(server)
        favBtn.text = if (server.id in model.settings.favorites) Strings.REMOVE_FAV else Strings.ADD_FAV
        measureBtn.enabled = !model.measuring
        hideBtn.text = if (server.id in model.settings.hidden) Strings.UNHIDE else Strings.HIDE
        val mean = LatencyHistory.mean(model.history[server.id] ?: emptyList())
        avg.value = if (mean == null) Strings.NEVER_MEASURED else Strings.avgPing(mean.first, mean.second)
        val l = model.latencies[server.id]
        lat.text = if (l == null) Strings.NEVER_MEASURED else Strings.lastMeasure(l.ms, Format.ago(model.host.now() - l.at))
    }

    override fun tick(dt: Float, env: Env): Boolean {
        val before = model.history[server.id]?.size ?: 0
        val shown = history.h
        refresh(false)
        val a = super.tick(dt, env)
        // İlk ölçüm geldiğinde grafik yer kaplamaya başlar: paneli yeniden yerleştir.
        if (shown == 0f && before > 0) (parent?.parent as? Sheet)?.relayout(env)
        return a
    }
}

/** Seçenek satırı (radyo işaretli). */
class ChoiceRow(
    private val id: String?,
    private val name: String,
    private val note: String,
    private val selected: Boolean,
    private val onPick: (String?) -> Unit,
) : PressNode() {
    override fun layout(env: Env, maxW: Float) { w = maxW; relay(env) }

    // Kısaltılmış yazılar yalnızca genişlik/yazı ölçeği değişince yeniden hesaplanır (her karede bellek ayırmasın).
    private var shownName = name
    private var noteLines: List<String> = emptyList()
    private var laidW = -1f
    private var laidFs = 0f

    /** Açıklama sığmazsa en çok 2 satıra sarar (ikincisi gerekirse "…" ile kısalır); satır ona göre yükselir. */
    private fun relay(env: Env) {
        val avail = w - 52f - 12f
        shownName = TextFit.ellipsize(env.metrics, name, avail, env.sz(16f), true)
        noteLines = if (note.isEmpty()) emptyList() else {
            val l = TextFit.wrap(env.metrics, note, avail, env.sz(13f), false)
            if (l.size > 2) listOf(l[0], TextFit.ellipsize(env.metrics, l[1] + " …", avail, env.sz(13f), false)) else l
        }
        h = if (noteLines.size >= 2) 60f + env.sz(13f) * 1.32f else 60f
        laidW = w; laidFs = env.fs
    }

    override fun draw(g: Gfx, env: Env) {
        if (laidW != w || laidFs != env.fs) relay(env)
        if (press.value > 0.01f) {
            g.save(); g.alpha(press.value); g.paint(Rgb.alpha(env.theme.accent, 0.16f)); g.roundRect(0f, 2f, w, h - 2f, 16f); g.restore()
        }
        val cy = h / 2f
        g.strokeWidth(2f)
        g.paint(if (selected) env.theme.link else env.theme.textSoft)
        g.strokeCircle(22f, cy, 10f)
        if (selected) { g.paint(env.theme.link); g.circle(22f, cy, 5.2f) }
        g.paint(env.theme.text)
        if (noteLines.isEmpty()) {
            g.text(shownName, 52f, centerBaseline(cy, env.sz(16f)), env.sz(16f), true, ALIGN_LEFT)
            return
        }
        val lh = env.sz(13f) * 1.32f
        val top = cy - 3f - (noteLines.size - 1) * lh / 2f
        g.text(shownName, 52f, top, env.sz(16f), true, ALIGN_LEFT)
        g.paint(env.theme.textSoft)
        for (i in noteLines.indices) g.text(noteLines[i], 52f, top + 18f + i * lh, env.sz(13f), false, ALIGN_LEFT)
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        super.onUp(lx, ly, tap, env)
        if (tap) { env.tap(); onPick(id) }
    }

    override fun a11y(): A11y = A11y(if (note.isEmpty()) name else "$name, $note", Role.BUTTON, checked = selected)
}

/** "Otomatik" + tüm sunucular: Wi-Fi/mobil kuralı seçici. */
class ChoiceContent(
    title: String,
    current: String?,
    private val onPick: (String?) -> Unit,
    close: () -> Unit,
) : Column(gap = 2f, padL = 20f, padT = 4f, padR = 20f, padB = 18f) {
    init {
        add(SheetTitle(title, close))
        add(Spacer(6f))
        add(ChoiceRow(null, Strings.RULE_AUTO, Strings.RULE_AUTO_NOTE, current == null) { onPick(null); close() })
        for (s in Catalog.all) add(ChoiceRow(s.id, s.name, s.note, current == s.id) { onPick(s.id); close() })
    }
}

/** Genel seçim paneli: başlık + seçenekler. Hiç seçenek yoksa [empty] yazısı. */
class OptionsContent(
    title: String,
    options: List<Option>,
    empty: String,
    footer: String,
    private val onPick: (String?) -> Unit,
    close: () -> Unit,
) : Column(gap = 2f, padL = 20f, padT = 4f, padR = 20f, padB = 18f) {
    init {
        add(SheetTitle(title, close))
        add(Spacer(6f))
        if (options.isEmpty() && empty.isNotEmpty()) add(Label(empty, 15f, ink = Ink.SOFT, maxLines = 0))
        for (o in options) add(ChoiceRow(o.id, o.name, o.note, o.selected) { close(); onPick(o.id) })
        if (footer.isNotEmpty()) { add(Spacer(8f)); add(Label(footer, 13f, ink = Ink.SOFT, maxLines = 0)) }
    }
}

/**
 * Küreye uzun basınca açılan hızlı seçim: favoriler ve son kullanılanlar (tek dokunuşla geç),
 * bağlıyken "duraklat" süreleri, duraklatılmışken "devam et".
 */
class QuickContent(
    private val model: AppModel,
    close: () -> Unit,
    private val openTest: () -> Unit = {},
) : Column(gap = 6f, padL = 20f, padT = 4f, padR = 20f, padB = 20f) {
    init {
        add(SheetTitle(Strings.QUICK_TITLE, close))
        val cur = model.connectedId() ?: model.selectedId()
        val fav = Catalog.all.filter { it.id in model.settings.favorites && it.id !in model.settings.hidden }.take(6)
        val rec = model.settings.recent.mapNotNull { Catalog.byId(it) }
            .filter { it !in fav && it.id !in model.settings.hidden }.take(4)
        fun row(s: DnsServer) = ChoiceRow(s.id, s.name, s.note, s.id == cur) { model.tapServer(s.id); close() }
        if (fav.isNotEmpty()) { add(SectionTitle(Strings.QUICK_FAVORITES)); for (s in fav) add(row(s)) }
        if (rec.isNotEmpty()) { add(SectionTitle(Strings.QUICK_RECENT)); for (s in rec) add(row(s)) }
        if (fav.isEmpty() && rec.isEmpty()) add(Label(Strings.EMPTY_FAV, 14f, ink = Ink.SOFT, maxLines = 0))
        when {
            model.vpn.active -> {
                add(SectionTitle(Strings.PAUSE_FOR))
                // Beş süre iki sıraya bölünür: dar ekranda da düğme yazıları kısalmaz.
                val opts = AppModel.PAUSE_OPTIONS
                val half = (opts.size + 1) / 2
                add(ButtonsRow(opts.take(half).map { m -> ActionButton(Strings.minutes(m), false) { model.pause(m); close() } }))
                add(ButtonsRow(opts.drop(half).map { m -> ActionButton(Strings.minutes(m), false) { model.pause(m); close() } }))
                if (model.vpn.state == OrbState.ON) {
                    add(Spacer(4f))
                    add(ActionButton(Strings.TEST, false, Icon.CHECK) { close(); openTest() })
                }
            }
            model.paused -> {
                add(Spacer(6f))
                add(ActionButton(Strings.RESUME, true, Icon.POWER) { model.tapOrb(); close() })
            }
        }
    }
}

/** İlk açılış bilgilendirmesi: Google Play VPN politikası için açık, sade metin. */
class ConsentContent(private val model: AppModel, close: () -> Unit) : Column(gap = 12f, padL = 20f, padT = 4f, padR = 20f, padB = 22f) {
    init {
        add(SheetTitle(Strings.CONSENT_TITLE, close))
        for (p in Strings.CONSENT_BODY) add(Label(p, 15f, ink = Ink.TEXT, maxLines = 0))
        add(Spacer(4f))
        add(ActionButton(Strings.CONSENT_OK, true, Icon.CHECK) { model.acceptConsent() })
    }
}

/**
 * Bağlantı testi paneli: test sürerken "Test ediliyor…", sonuç gelince satırlar (DNS çalışıyor mu, sunucu, yöntem,
 * yanıt süresi, DNSSEC, reklam engelleme) ve "Yeniden test et". Model değişince kendini yeniden kurar.
 */
class TestContent(private val model: AppModel, private val close: () -> Unit) : Column(gap = 8f, padL = 20f, padT = 4f, padR = 20f, padB = 22f) {
    private var seen = -1
    private var envRef: Env? = null

    init { rebuild() }

    private fun rebuild() {
        removeAll()
        add(SheetTitle(Strings.TEST_TITLE, close))
        val r = model.testResult
        if (model.testing || r == null) {
            add(Label(if (model.testing) Strings.TESTING else Strings.ONLY_CONNECTED, 16f, ink = Ink.SOFT, maxLines = 0))
        } else {
            add(Label(if (r.ok) Strings.TEST_OK else Strings.TEST_FAIL, 20f, bold = true, maxLines = 0))
            add(KeyValueRow(Strings.TEST_SERVER, model.nameOf(r.serverId)))
            add(KeyValueRow(Strings.TEST_METHOD, r.proto?.let { Strings.protoName(it) } ?: Strings.UNKNOWN))
            add(KeyValueRow(Strings.TEST_LATENCY, r.ms?.let { Format.ms(it) } ?: Strings.TEST_FAIL))
            add(KeyValueRow(Strings.TEST_DNSSEC, when (r.dnssec) {
                DnssecResult.VALIDATING -> Strings.DNSSEC_YES
                DnssecResult.NOT_VALIDATING -> Strings.DNSSEC_NO
                DnssecResult.UNKNOWN -> Strings.UNKNOWN
            }))
            add(KeyValueRow(Strings.TEST_ADS, when (r.ads) {
                AdBlockResult.BLOCKED -> Strings.ADS_YES
                AdBlockResult.NOT_BLOCKED -> Strings.ADS_NO
                AdBlockResult.UNKNOWN -> Strings.UNKNOWN
            }))
            if (r.ok) add(Label(Strings.TEST_EXPLAIN, 13f, ink = Ink.SOFT, maxLines = 0))
        }
        add(Spacer(4f))
        add(ActionButton(Strings.TEST_AGAIN, true, Icon.REFRESH) { model.testConnection() }.also {
            it.enabled = !model.testing && model.vpn.state == OrbState.ON
        })
        seen = signature()
    }

    /** Yalnızca testin durumu değişince yeniden kurulur (her saniyelik canlı sayaç güncellemesinde değil). */
    private fun signature(): Int = model.testSeq * 4 + (if (model.testing) 1 else 0) + (if (model.vpn.state == OrbState.ON) 2 else 0)

    override fun layout(env: Env, maxW: Float) { envRef = env; super.layout(env, maxW) }

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != signature()) {
            rebuild()
            (parent?.parent as? Sheet)?.relayout(env)
        }
        return super.tick(dt, env)
    }
}

/** "Bana uygun sunucu": amaç seçilince en hızlı uygun sunucuya bağlanılır. */
class RecommendContent(private val model: AppModel, close: () -> Unit) : Column(gap = 2f, padL = 20f, padT = 4f, padR = 20f, padB = 18f) {
    init {
        add(SheetTitle(Strings.RECOMMEND, close))
        add(Label(Strings.RECOMMEND_NOTE, 14f, ink = Ink.SOFT, maxLines = 0))
        add(Spacer(6f))
        val goals = listOf<Tag?>(null, Tag.PRIVACY, Tag.ADS, Tag.FAMILY, Tag.SECURITY)
        for (gl in goals) {
            add(ChoiceRow(gl?.id ?: "speed", Strings.goal(gl), Strings.goalNote(gl), false) { close(); model.recommend(gl) })
        }
    }
}

/** Başlık, paragraflar ve isteğe bağlı birincil düğme: rehberler (kesintisiz koruma, pil). */
class InfoContent(
    title: String,
    paragraphs: List<String>,
    button: String?,
    action: (() -> Unit)?,
    close: () -> Unit,
) : Column(gap = 12f, padL = 20f, padT = 4f, padR = 20f, padB = 22f) {
    init {
        add(SheetTitle(title, close))
        for (p in paragraphs) add(Label(p, 15f, ink = Ink.TEXT, maxLines = 0))
        if (button != null && action != null) {
            add(Spacer(4f))
            add(ActionButton(button, true) { close(); action() })   // önce kapat: eylem yeni bir panel açabilir
        }
    }
}
