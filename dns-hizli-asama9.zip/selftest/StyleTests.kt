package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*
import java.lang.management.ManagementFactory

private val mx = ManagementFactory.getThreadMXBean() as com.sun.management.ThreadMXBean
private fun allocNow(): Long = mx.getThreadAllocatedBytes(Thread.currentThread().id)

private fun styled(style: UiStyle, theme: String = "aqua") = Rig(Rig.base(theme).copy(style = style))

/** Aşama 5: görünüm stilleri (Aqua, Aero, Metro, Eco, Y2K). */
fun testUiStyles() {
    T.group("Stiller: model, fabrika, ayar")
    T.check("beş stil var, kimlikler ve adlar benzersiz",
        UiStyle.values().size == 5 && UiStyle.values().map { it.id }.toSet().size == 5 && UiStyle.values().map { it.label }.toSet().size == 5)
    T.check("byId gidiş-dönüş, bilinmeyen null", UiStyle.values().all { UiStyle.byId(it.id) == it } && UiStyle.byId("x") == null && UiStyle.byId(null) == null)
    T.check("varsayılan stil Aqua", AppSettings().style == UiStyle.AQUA)
    for (st in UiStyle.values()) {
        val art = ArtFactory.create(st, Themes.aqua, 0.55f)
        T.check("${st.label}: fabrika doğru stili üretir", art.style == st)
    }
    T.check("Aqua: özgün çizici sınıfı ve özgün hareket (dokunulmadı)",
        ArtFactory.create(UiStyle.AQUA, Themes.aqua, 0.55f).javaClass == AeroArt::class.java && ArtFactory.create(UiStyle.AQUA, Themes.aqua, 0.55f).motion === StyleMotion.AQUA)
    T.check("parçacık davranışları: Aqua yükselir, Aero yükselir, Metro yok, Eco düşer, Y2K parıldar",
        UiStyle.values().map { ArtFactory.create(it, Themes.aqua, 0.5f).particleMode } ==
            listOf(ParticleMode.RISE, ParticleMode.RISE, ParticleMode.NONE, ParticleMode.FALL, ParticleMode.TWINKLE))
    T.check("sayfa geçişleri: kaydır, kaydır, turnike, solarak büyü, pop",
        UiStyle.values().map { ArtFactory.create(it, Themes.aqua, 0.5f).motion.page } ==
            listOf(PageMotion.SLIDE, PageMotion.SLIDE, PageMotion.TURNSTILE, PageMotion.FADE_SCALE, PageMotion.POP))
    T.check("yalnızca Metro büyük başlık kullanır", UiStyle.values().map { ArtFactory.create(it, Themes.aqua, 0.5f).titleScale > 1f } == listOf(false, false, true, false, false))

    for (st in UiStyle.values()) {
        val s = AppSettings(style = st)
        T.check("${st.label}: ayar kodlayıcı gidiş-dönüş", SettingsCodec.decode(SettingsCodec.encode(s)).style == st)
    }
    T.check("bozuk stil değeri varsayılana düşer", SettingsCodec.decode(mapOf("style" to "zzz")).style == UiStyle.AQUA)
    val exp = SettingsCodec.export(AppSettings(style = UiStyle.Y2K))
    T.check("stil dışa/içe aktarılır (cihaza özel değil)", SettingsCodec.import(exp, AppSettings())?.style == UiStyle.Y2K)

    T.group("Stiller: her dilde metinler")
    val saved = L.lang
    try {
        for (lang in Lang.values()) {
            L.set(lang)
            val n = Strings.STYLE_NOTES
            T.check("${lang.native}: stil başlığı ve 5 açıklama", Strings.STYLE.isNotBlank() && n.size == 5 && n.all { it.length in 12..90 } && n.toSet().size == 5, n.toString())
            T.check("${lang.native}: yenilikler ilk maddesi stilleri anlatır", Strings.WHATS_NEW_ITEMS.any { it.contains("Y2K") && it.contains("Aero") })
        }
    } finally { L.set(saved) }

    T.group("Stiller: çizim ve sayfalar")
    val g = CountingGfx()
    for (st in UiStyle.values()) for (th in listOf("aqua", "night", "sakura", "meadow", "amoled")) {
        val rig = styled(st, th)
        rig.connectOk()
        val where = "${st.label}/$th"
        g.reset(); rig.scene.draw(g)
        T.check("$where ana ekran: geçerli çizim, dengeli kayıt, bütçe içinde", g.bad == 0 && !g.underflow && g.depth == 0 && g.calls < 4200, "bad=${g.bad} d=${g.depth} calls=${g.calls}")
        rig.scene.openSettings(); rig.settle(900)
        g.reset(); rig.scene.draw(g)
        T.check("$where ayarlar: geçerli çizim", g.bad == 0 && !g.underflow && g.depth == 0 && g.calls < 4200, "bad=${g.bad} d=${g.depth} calls=${g.calls}")
        rig.scene.back(); rig.settle(900)
        rig.scene.openDetails(Catalog.byId("quad9")!!); rig.settle(700)
        g.reset(); rig.scene.draw(g)
        T.check("$where ayrıntı paneli: geçerli çizim", g.bad == 0 && !g.underflow && g.depth == 0, "bad=${g.bad} d=${g.depth}")
        rig.scene.closeSheet(); rig.settle(500)
        rig.model.onVpn(VpnUi(OrbState.ERROR, "google", 0, error = "hata")); rig.settle(500)
        g.reset(); rig.scene.draw(g)
        T.check("$where hata durumu: geçerli çizim", g.bad == 0 && !g.underflow && g.depth == 0, "bad=${g.bad}")
    }

    T.group("Stiller: erişilebilirlik aynı kalır")
    val base = Rig().let { r -> r.connectOk(); r.items().map { it.info.label } }
    for (st in UiStyle.values()) {
        val r = styled(st); r.connectOk(); r.settle(1200)
        T.check("${st.label}: ana ekran etiketleri Aqua ile aynı (başlık dahil)", r.items().map { it.info.label } == base)
    }

    T.group("Stiller: sayfa geçişleri ve açılış belirmesi")
    for (st in UiStyle.values()) {
        val r = styled(st)
        r.scene.openSettings()
        r.advance(120)
        T.check("${st.label}: geçiş sürerken sayfa çizilir", run { g.reset(); r.scene.draw(g); g.bad == 0 && !g.underflow && g.depth == 0 && r.scene.transitioning() })
        r.settle(1500)
        T.check("${st.label}: geçiş biter, ayarlar açık", r.scene.pageCount == 2 && !r.scene.transitioning())
        r.scene.back(); r.advance(120)
        T.check("${st.label}: geri geçişi çizilir", run { g.reset(); r.scene.draw(g); g.bad == 0 && !g.underflow && g.depth == 0 })
        r.settle(1500)
        T.check("${st.label}: geri dönüldü", r.scene.pageCount == 1 && !r.scene.transitioning())
        T.check("${st.label}: durağan ekranda kare istenmez ya da yalnızca süs (33 ms)",
            r.lastDelay == -1L || (r.lastDelay == 33L && st != UiStyle.METRO), "${r.lastDelay}")
    }
    run {
        val m = styled(UiStyle.METRO); m.settle(1500)
        T.check("Metro: süs animasyonu yok, ekran durağanken kare istenmez", m.lastDelay == -1L, "${m.lastDelay}")
    }
    for (st in UiStyle.values()) {
        val r = Rig(Rig.base().copy(style = st, motion = Motion.OFF))
        r.scene.openSettings()
        T.check("${st.label}: hareket kapalıyken geçiş ve belirme anında biter", r.scene.pageCount == 2 && !r.scene.transitioning())
        g.reset(); r.scene.draw(g)
        T.check("${st.label}: hareket kapalı, tam görünür sayfa", g.bad == 0 && g.texts >= 10, "${g.texts}")
        r.settle(300)
        T.check("${st.label}: hareket kapalı, kare gerekmez", r.lastDelay == -1L, "${r.lastDelay}")
    }
    run {
        // açılışta satırlar art arda belirir: ilk karede ana ekranın alt satırları henüz tam görünmez, sonra tamamlanır
        val r = Rig(Rig.base().copy(style = UiStyle.Y2K))
        val q = Rig(Rig.base().copy(style = UiStyle.AQUA))
        r.scene.openSettings(); q.scene.openSettings()
        r.settle(1500); q.settle(1500)
        val late = CountingGfx().also { r.scene.draw(it) }
        val ref = CountingGfx().also { q.scene.draw(it) }
        T.check("Y2K: açılış belirmesi bitince içerik Aqua ile aynı yazı sayısında çizilir", late.texts == ref.texts && late.texts >= 10, "${ref.texts} <> ${late.texts}")
    }

    T.group("Stiller: ayarlardan seçim")
    run {
        val r = Rig()
        r.scene.openSettings(); r.settle(900)
        fun shown(w: String) = TextRecorder().also { r.scene.draw(it) }.runs.any { it.s == w }
        T.check("ayarlarda Stil satırı var ve geçerli adı gösterir", r.find(Strings.STYLE) != null && shown("Aqua"))
        r.tapText(Strings.STYLE, settleMs = 800)
        T.check("seçici beş stili ve açıklamalarını listeler", UiStyle.values().all { r.find(it.label, exact = false) != null } && r.find(Strings.STYLE_NOTES[2]) != null)
        r.tapText(Strings.STYLE_NOTES[2], settleMs = 1200)
        T.check("Metro seçilince ayar kaydedilir", r.model.settings.style == UiStyle.METRO, r.model.settings.style.toString())
        T.check("sahnede Metro çizici etkin ve başlık büyür", r.scene.env.art.style == UiStyle.METRO && r.scene.env.art.titleScale > 1f)
        T.check("seçici kapandı", !r.scene.hasSheet)
        T.check("satır yeni adı gösterir", shown("Metro") && !shown("Aero"))
        r.tapText(Strings.STYLE, settleMs = 800)
        r.tapText(Strings.STYLE_NOTES[0], settleMs = 1200)
        T.check("Aqua'ya dönüş: özgün çizici", r.model.settings.style == UiStyle.AQUA && r.scene.env.art.javaClass == AeroArt::class.java)
        val gg = CountingGfx(); r.scene.draw(gg)
        T.check("dönüşten sonra çizim geçerli", gg.bad == 0 && gg.depth == 0)
    }

    T.group("Stiller: kare başına bellek")
    for (st in UiStyle.values()) {
        for ((name, make) in listOf<Pair<String, () -> Rig>>(
            "ana (bağlı)" to { styled(st).also { it.connectOk() } },
            "ayarlar" to { styled(st).also { it.scene.openSettings(); it.settle(1400) } },
        )) {
            var best = Double.MAX_VALUE
            for (attempt in 1..3) {
                val r = make()
                repeat(150) { r.host.now += 16; r.scene.tick(r.host.now); g.reset(); r.scene.draw(g) }
                val before = allocNow()
                repeat(300) { r.host.now += 16; r.scene.tick(r.host.now); g.reset(); r.scene.draw(g) }
                best = minOf(best, (allocNow() - before) / 300.0)
                if (best <= 96.0) break
            }
            println("        bilgi: ${st.label} $name ≈ %.1f bayt/kare".format(best))
            T.check("${st.label} $name: kare başına en çok 96 bayt ayırır", best <= 96.0, "%.1f bayt".format(best))
        }
    }
}
