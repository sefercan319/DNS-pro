package app.dnshizli.selftest

import app.dnshizli.core.AppEntry
import app.dnshizli.core.AppSettings
import app.dnshizli.core.CustomDns
import app.dnshizli.core.Pic
import app.dnshizli.core.WpBlur
import app.dnshizli.core.UiStyle
import app.dnshizli.core.NetCheck
import app.dnshizli.core.PrivateDns
import app.dnshizli.core.Gfx
import app.dnshizli.core.Fill
import app.dnshizli.core.GPath
import app.dnshizli.core.Latency
import app.dnshizli.core.Motion
import app.dnshizli.core.OrbState
import app.dnshizli.core.TextMetrics
import app.dnshizli.ui.A11yItem
import app.dnshizli.ui.AppModel
import app.dnshizli.ui.Host
import app.dnshizli.ui.Node
import app.dnshizli.ui.Scene
import app.dnshizli.ui.ScrollView
import app.dnshizli.ui.VpnUi

/** Deterministik, temkinli yazı ölçüsü: testler gerçek yazı tipine bağlı olmasın (gerçek Inter/Roboto'dan biraz geniştir). */
object FixedMetrics : TextMetrics {
    override fun textWidth(s: String, size: Float, bold: Boolean): Float = s.length * size * (if (bold) 0.58f else 0.52f)
}

/**
 * Çizim yapmayan [Gfx]: çağrıları sayar, save/restore dengesini ve koordinatların sonlu olmasını denetler.
 * Kendisi hiçbir çağrıda bellek ayırmaz, bu yüzden kare başına bellek ölçümünde kullanılabilir.
 */
class CountingGfx : Gfx {
    var calls = 0
    var texts = 0
    var shapes = 0
    var depth = 0
    var maxDepth = 0
    var underflow = false
    var bad = 0
    var clipDepthViolations = 0
    var images = 0
    var lastImage: FloatArray? = null

    fun reset() { calls = 0; texts = 0; shapes = 0; depth = 0; maxDepth = 0; underflow = false; bad = 0; images = 0 }

    private fun f(a: Float) { if (!a.isFinite()) bad++ }

    override fun save() { calls++; depth++; if (depth > maxDepth) maxDepth = depth }
    override fun restore() { calls++; depth--; if (depth < 0) { underflow = true; depth = 0 } }
    override fun translate(dx: Float, dy: Float) { calls++; f(dx); f(dy) }
    override fun scale(sx: Float, sy: Float) { calls++; f(sx); f(sy) }
    override fun rotate(deg: Float) { calls++; f(deg) }
    override fun alpha(a: Float) { calls++; f(a) }
    override fun clipRect(l: Float, t: Float, r: Float, b: Float) { calls++; f(l); f(t); f(r); f(b) }
    override fun clipRoundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) { calls++; f(l); f(t); f(r); f(b); f(rad) }
    override fun clipCircle(cx: Float, cy: Float, r: Float) { calls++; f(cx); f(cy); f(r) }
    override fun paint(color: Int) { calls++ }
    override fun paint(fill: Fill) { calls++ }
    override fun strokeWidth(w: Float) { calls++; f(w) }
    override fun rect(l: Float, t: Float, r: Float, b: Float) { calls++; shapes++; f(l); f(t); f(r); f(b) }
    override fun roundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) { calls++; shapes++; f(l); f(t); f(r); f(b); f(rad) }
    override fun circle(cx: Float, cy: Float, r: Float) { calls++; shapes++; f(cx); f(cy); f(r) }
    override fun oval(l: Float, t: Float, r: Float, b: Float) { calls++; shapes++; f(l); f(t); f(r); f(b) }
    override fun path(p: GPath) { calls++; shapes++ }
    override fun strokeRoundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) { calls++; shapes++; f(l); f(t); f(r); f(b); f(rad) }
    override fun strokeCircle(cx: Float, cy: Float, r: Float) { calls++; shapes++; f(cx); f(cy); f(r) }
    override fun strokePath(p: GPath) { calls++; shapes++ }
    override fun line(x0: Float, y0: Float, x1: Float, y1: Float) { calls++; shapes++; f(x0); f(y0); f(x1); f(y1) }
    override fun image(p: Pic, sl: Float, st: Float, sr: Float, sb: Float, dl: Float, dt: Float, dr: Float, db: Float) {
        calls++; images++; f(sl); f(st); f(sr); f(sb); f(dl); f(dt); f(dr); f(db)
        lastImage = floatArrayOf(sl, st, sr, sb, dl, dt, dr, db)
    }
    override fun text(s: String, x: Float, baseline: Float, size: Float, bold: Boolean, align: Int) { calls++; texts++; f(x); f(baseline); f(size) }
    override fun textWidth(s: String, size: Float, bold: Boolean): Float = FixedMetrics.textWidth(s, size, bold)
}

/** Testlerde ve önizlemede kullanılan sahte platform: çağrıları kaydeder, saati elle ilerletir. */
class FakeHost : Host {
    var now = 1_700_000_000_000L
    val calls = ArrayList<String>()
    var saved: AppSettings? = null
    var savedCount = 0
    var savedLatencies: Map<String, Latency>? = null
    var clipboard: String? = null
    var shared: String? = null
    var diag = "12:00:01 Servis başladı\n12:00:02 Tünel açıldı (Cloudflare)\n12:00:09 Ağ değişti: Wi-Fi → mobil\n12:00:10 DNS yenilendi"
    var frames = 0
    var haptics = 0
    var strongHaptics = 0
    var lastMeasureIds: List<String> = emptyList()

    var savedHistory: Map<String, List<Int?>>? = null
    var language = "auto"
    var localHourValue = 12

    override fun connect(serverId: String) { calls.add("connect:$serverId") }
    override fun disconnect() { calls.add("disconnect") }
    override fun pause(minutes: Int) { calls.add("pause:$minutes") }
    override fun resume() { calls.add("resume") }
    override fun clearCache() { calls.add("clearCache") }
    override fun saveHistory(h: Map<String, List<Int?>>) { savedHistory = HashMap(h) }
    override fun resetTotals() { calls.add("resetTotals") }
    override fun readClipboard(): String? = clipboard
    override fun shareApp() { calls.add("shareApp") }
    override fun rateApp() { calls.add("rateApp") }
    override fun applyLanguage(setting: String) {
        language = setting
        calls.add("lang:$setting")
        app.dnshizli.core.L.set(app.dnshizli.core.L.resolve(setting, listOf("tr")))
    }
    override fun localHour(): Int = localHourValue
    override fun measure(serverIds: List<String>) { calls.add("measure:${serverIds.size}"); lastMeasureIds = serverIds }
    override fun saveSettings(s: AppSettings) { saved = s; savedCount++ }

    /** Test: "telefonda kayıtlı arka plan fotoğrafı". [wpFactory] yüklenen [Pic]'i üretir (önizlemede gerçek görüntü verir). */
    var wpStored = false
    var wpLuma: Pair<Float, Float> = 0.4f to 0.6f
    var wpFactory: (WpBlur) -> Pic? = { _ -> Pic(360, 780, Any(), wpLuma.first, wpLuma.second) }
    var wpReleased = 0
    var wpLoaded = 0
    override fun pickWallpaper() { calls.add("pickWallpaper") }
    override fun usePresetWallpaper(index: Int) { calls.add("preset:$index") }
    /** Test: simge değiştirme sonucu ([false]: platform reddetti). */
    var iconOk = true
    override fun setAppIcon(style: UiStyle): Boolean { calls.add("icon:${style.id}"); return iconOk }
    override fun removeWallpaper() { calls.add("removeWallpaper"); wpStored = false }
    /** Test: doluysa yükleme hemen bitmez, geri çağrı bu işleve verilir (yarış durumlarını denemek için). */
    var deferLoad: (((Pic?) -> Unit) -> Unit)? = null
    override fun loadWallpaper(blur: WpBlur, onDone: (Pic?) -> Unit) {
        calls.add("loadWallpaper:${blur.id}")
        deferLoad?.let { d -> d(onDone); return }
        if (!wpStored) { onDone(null); return }
        wpLoaded++
        val p = wpFactory(blur)
        onDone(p?.let { Pic(it.w, it.h, it.handle, it.lumaLo, it.lumaHi) { wpReleased++ } })
    }
    /** Test: "yüklü uygulamalar". */
    var installedApps: List<AppEntry> = listOf(AppEntry("com.example.mail", "Mail"), AppEntry("org.example.browser", "Browser"), AppEntry("com.example.game", "Game"))
    override fun loadApps(onDone: (List<AppEntry>) -> Unit) { calls.add("loadApps"); onDone(installedApps) }
    override fun applyApps() { calls.add("applyApps") }
    /** Test: özel DNS penceresinde "kullanıcının" gireceği değerler; null ise pencere iptal edilir. */
    var customDraft: CustomDns.Draft? = null
    var customError: String? = null
    /** Test: düzenleme penceresinin açıldığı andaki başlangıç değerleri (ekleme için null). */
    var lastInitial: CustomDns.Draft? = null
    var textAnswer: String? = null
    var lastTextInitial: String? = null
    var net = NetCheck(permission = true, online = true, otherVpn = false, privateDns = PrivateDns.AUTO)
    override fun networkCheck(): NetCheck { calls.add("networkCheck"); return net }
    override fun promptText(title: String, hint: String, initial: String, onDone: (String) -> Unit) {
        calls.add("promptText"); lastTextInitial = initial
        textAnswer?.let { onDone(it) }
    }
    override fun promptCustomServer(validate: (CustomDns.Draft) -> String?, initial: CustomDns.Draft?, onDone: (CustomDns.Draft) -> Unit) {
        calls.add("promptCustom")
        lastInitial = initial
        val d = customDraft ?: return
        customError = validate(d)
        if (customError == null) onDone(d)
    }
    override fun saveLatencies(m: Map<String, Latency>) { savedLatencies = HashMap(m) }
    override fun copyText(text: String) { clipboard = text; calls.add("copy") }
    override fun shareText(text: String) { shared = text; calls.add("share") }
    override fun haptic(strong: Boolean) { haptics++; if (strong) strongHaptics++ }
    override fun openVpnSettings() { calls.add("vpnSettings") }
    override fun diagnostics(): String = diag
    override fun clearDiagnostics() { diag = ""; calls.add("clearLog") }
    override fun versionName(): String = "1.0.0"
    override fun now(): Long = now
    override fun requestFrame() { frames++ }

    var accent: Int? = null
    var restricted: Boolean? = null
    var shortcuts: List<String> = emptyList()
    override fun runTest() { calls.add("test") }
    override fun reapply() { calls.add("reapply") }
    override fun updateShortcuts(serverIds: List<String>) { shortcuts = serverIds; calls.add("shortcuts:${serverIds.size}") }
    override fun systemAccent(): Int? = accent
    override fun openBatterySettings() { calls.add("battery") }
    override fun batteryRestricted(): Boolean? = restricted

    fun count(prefix: String): Int = calls.count { it.startsWith(prefix) }
}

/**
 * Gerçek [Scene] ve [AppModel] kodunu sahte platform üzerinde çalıştıran düzenek: zamanı elle ilerletir,
 * dokunma/kaydırma üretir, ekrandaki öğeleri erişilebilirlik etiketleriyle bulur (kullanıcının gördüğü gibi).
 */
class Rig(
    settings: AppSettings = base(),
    val w: Int = 360,
    val h: Int = 780,
    metrics: TextMetrics = FixedMetrics,
    insetTop: Float = 28f,
    insetBottom: Float = 24f,
    latencies: Map<String, Latency>? = null,
    fontScale: Float = 1f,
) {
    val host = FakeHost()
    val model: AppModel
    val scene: Scene

    init {
        val lat = LinkedHashMap<String, Latency>()
        if (latencies != null) lat.putAll(latencies)
        else {
            val demo = mapOf("cloudflare" to 18, "google" to 24, "quad9" to 41, "adguard" to 33, "controld" to 29, "opendns" to 62, "mullvad" to 88, "dnssb" to 47)
            for ((id, ms) in demo) lat[id] = Latency(ms, host.now - 300_000)
            lat["uncensored"] = Latency(null, host.now - 300_000)
        }
        model = AppModel(host, settings, lat)
        scene = Scene(model, metrics)
        if (fontScale != 1f) scene.setFontScale(fontScale)
        scene.resize(w.toFloat(), h.toFloat(), insetTop, insetBottom)
        settle()
    }

    // ------------------------------------------------------------------ zaman

    /** Son [advance] çağrısındaki son karenin önerdiği gecikme (ms): 16, 33 ya da -1 (kare gerekmiyor). */
    var lastDelay = 0L

    fun advance(ms: Long, step: Long = 16) {
        var t = 0L
        while (t < ms) { host.now += step; lastDelay = scene.tick(host.now); t += step }
    }

    fun settle(ms: Long = 1500) = advance(ms)

    /** Tek kare (16 ms) ilerletir ve sahnenin önerdiği gecikmeyi döndürür. */
    fun tick1(): Long { host.now += 16; lastDelay = scene.tick(host.now); return lastDelay }

    // ------------------------------------------------------------------ dokunma

    fun down(x: Float, y: Float) { scene.touch(Scene.DOWN, x, y, host.now) }
    fun move(x: Float, y: Float) { host.now += 16; scene.touch(Scene.MOVE, x, y, host.now); scene.tick(host.now) }
    fun up(x: Float, y: Float) { scene.touch(Scene.UP, x, y, host.now) }

    fun tap(x: Float, y: Float, settleMs: Long = 400) {
        down(x, y)
        advance(60)
        up(x, y)
        advance(settleMs)
    }

    /** Uzun bas: parmak [holdMs] boyunca durur. */
    fun longPress(x: Float, y: Float, holdMs: Long = 600) {
        down(x, y)
        advance(holdMs)
        up(x, y)
        advance(500)
    }

    /** Parmağı durdurup bırakır (fırlatma yok). */
    fun drag(x: Float, y0: Float, y1: Float, steps: Int = 12) {
        down(x, y0)
        for (i in 1..steps) move(x, y0 + (y1 - y0) * i / steps)
        host.now += 200
        scene.tick(host.now)
        up(x, y1)
        advance(300)
    }

    /** Hareket ederken bırakır (fırlatma): kaydırma sürtünmeyle sürer. */
    fun fling(x: Float, y0: Float, y1: Float, steps: Int = 6) {
        down(x, y0)
        for (i in 1..steps) move(x, y0 + (y1 - y0) * i / steps)
        up(x, y1)
        advance(40)
    }

    fun dragX(y: Float, x0: Float, x1: Float, steps: Int = 10) {
        down(x0, y)
        for (i in 1..steps) move(x0 + (x1 - x0) * i / steps, y)
        host.now += 150
        scene.tick(host.now)
        up(x1, y)
        advance(300)
    }

    // ------------------------------------------------------------------ erişilebilirlik üzerinden bulma

    fun items(): List<A11yItem> = scene.a11yItems()

    /** Etiketi [text] içeren ilk öğe (yoksa null). [exact] doğruysa tam eşleşme. */
    fun find(text: String, exact: Boolean = false): A11yItem? =
        items().firstOrNull { if (exact) it.info.label == text else it.info.label.contains(text) }

    fun findAll(text: String): List<A11yItem> = items().filter { it.info.label.contains(text) }

    fun need(text: String, exact: Boolean = false): A11yItem =
        find(text, exact) ?: reveal(text, exact) ?: throw IllegalStateException("Ekranda \"$text\" yok. Görünenler: " + items().joinToString(" | ") { it.info.label.take(30) })

    // ---- kaydırarak bulma (kullanıcının yaptığı gibi)

    private fun insideScroll(i: A11yItem): Boolean {
        var n: Node? = i.node
        while (n != null) { if (n is ScrollView) return true; n = n.parent }
        return false
    }

    /** Öğe kaydırılan alanda değilse ya da üst çubuğun/alt kenarın arasında tamamen görünüyorsa true. */
    fun comfortable(i: A11yItem): Boolean {
        if (!insideScroll(i) || scene.hasSheet) return true
        return i.t >= scene.env.insetTop + 58f && i.b <= h - 8f
    }

    /** Öğe görünmüyorsa (ya da çubuğun/kenarın altında kalıyorsa) sayfayı kaydırarak getirir; bulamazsa son halini döndürür. */
    fun reveal(text: String, exact: Boolean = false): A11yItem? =
        revealWhere { if (exact) it.info.label == text else it.info.label.contains(text) }

    fun revealWhere(pred: (A11yItem) -> Boolean): A11yItem? {
        var cur = items().firstOrNull(pred)
        if (cur != null && comfortable(cur)) return cur
        for (dir in intArrayOf(-1, 1)) {
            for (n in 0 until 40) {
                val y0 = h * 0.62f
                drag(w / 2f, y0, y0 + dir * h * 0.25f, 8)
                cur = items().firstOrNull(pred)
                if (cur != null && comfortable(cur)) return cur
            }
        }
        return items().firstOrNull(pred)
    }

    fun cx(i: A11yItem) = (i.l + i.r) / 2f
    fun cy(i: A11yItem) = (i.t + i.b) / 2f

    fun tapItem(i: A11yItem, settleMs: Long = 400) {
        val cur = if (comfortable(i)) i else (reveal(i.info.label, true) ?: i)
        tap(cx(cur), cy(cur), settleMs)
    }
    fun tapText(text: String, exact: Boolean = false, settleMs: Long = 400) = tapItem(need(text, exact), settleMs)

    // ------------------------------------------------------------------ durum yardımcıları

    fun connectOk(server: String = "cloudflare", ms: Int = 23) {
        model.onVpn(VpnUi(OrbState.ON, server, host.now - 754_000, 1342, 511, ms))
        settle(1200)
    }

    fun draw(g: Gfx) = scene.draw(g)

    companion object {
        fun base(theme: String = "aqua") = AppSettings(
            theme = theme, onboarded = true, lastServer = "cloudflare",
            favorites = setOf("cloudflare", "quad9"), totalQueries = 48_210, totalHits = 17_330, totalSeconds = 93_600,
            motion = Motion.FULL,
        )
    }
}

/**
 * Yazı çağrılarını kaydeden [Gfx]: her yazının ekrandaki (mutlak) sınır kutusunu hesaplar. Çizim yapmaz.
 * Üst üste binen ya da ekran dışına taşan yazıları yakalamak için kullanılır. Yalnızca öteleme ve ölçek izlenir.
 */
class TextRecorder : Gfx {
    class Run(val s: String, val l: Float, val t: Float, val r: Float, val b: Float, val size: Float, val color: Int = 0)
    private var cur = 0

    val runs = ArrayList<Run>()
    private var tx = 0f
    private var ty = 0f
    private var sx = 1f
    private var sy = 1f
    private var al = 1f
    private var rot = 0
    private val st = FloatArray(6 * 256)
    private var sp = 0

    override fun save() {
        val o = sp * 6
        st[o] = tx; st[o + 1] = ty; st[o + 2] = sx; st[o + 3] = sy; st[o + 4] = al; st[o + 5] = rot.toFloat()
        sp++
    }
    override fun restore() {
        sp--
        val o = sp * 6
        tx = st[o]; ty = st[o + 1]; sx = st[o + 2]; sy = st[o + 3]; al = st[o + 4]; rot = st[o + 5].toInt()
    }
    override fun translate(dx: Float, dy: Float) { tx += dx * sx; ty += dy * sy }
    override fun scale(sx: Float, sy: Float) { this.sx *= sx; this.sy *= sy }
    override fun rotate(deg: Float) { rot++ }
    override fun alpha(a: Float) { al *= a }
    override fun clipRect(l: Float, t: Float, r: Float, b: Float) {}
    override fun clipRoundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) {}
    override fun clipCircle(cx: Float, cy: Float, r: Float) {}
    override fun paint(color: Int) { cur = color }
    override fun paint(fill: Fill) {}
    override fun strokeWidth(w: Float) {}
    override fun rect(l: Float, t: Float, r: Float, b: Float) {}
    override fun roundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) {}
    override fun circle(cx: Float, cy: Float, r: Float) {}
    override fun oval(l: Float, t: Float, r: Float, b: Float) {}
    override fun path(p: GPath) {}
    override fun strokeRoundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) {}
    override fun strokeCircle(cx: Float, cy: Float, r: Float) {}
    override fun strokePath(p: GPath) {}
    override fun line(x0: Float, y0: Float, x1: Float, y1: Float) {}
    override fun textWidth(s: String, size: Float, bold: Boolean): Float = FixedMetrics.textWidth(s, size, bold)

    override fun text(s: String, x: Float, baseline: Float, size: Float, bold: Boolean, align: Int) {
        if (s.isEmpty() || al < 0.05f || rot > 0) return
        val wd = FixedMetrics.textWidth(s, size, bold) * sx
        val px = x * sx + tx
        val l = when (align) { 1 -> px - wd / 2f; 2 -> px - wd; else -> px }
        val by = baseline * sy + ty
        runs.add(Run(s, l, by - 0.80f * size * sy, l + wd, by + 0.20f * size * sy, size * sy, cur))
    }

    /** Üst üste binen yazı çiftleri (sınır kutusu kesişimi iki yönde de [tol] dp'den büyükse). */
    fun overlaps(tol: Float = 0.75f): List<Pair<Run, Run>> {
        val out = ArrayList<Pair<Run, Run>>()
        for (i in 0 until runs.size) for (j in i + 1 until runs.size) {
            val a = runs[i]; val b = runs[j]
            val ox = minOf(a.r, b.r) - maxOf(a.l, b.l)
            val oy = minOf(a.b, b.b) - maxOf(a.t, b.t)
            if (ox > tol && oy > tol) out.add(a to b)
        }
        return out
    }
}
