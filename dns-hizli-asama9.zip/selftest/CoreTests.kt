package app.dnshizli.selftest

import app.dnshizli.core.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.Random
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.system.exitProcess

/** Çok küçük test çerçevesi: bağımlılık yok. Hata yoksa grup başına tek satır, hata varsa ayrıntı basar. */
object T {
    var total = 0
    var failures = 0
    private var name = ""
    private var count = 0
    private var failed = 0
    private val verbose = System.getenv("VERBOSE") == "1"

    fun group(n: String) {
        flush()
        name = n; count = 0; failed = 0
    }

    fun check(what: String, ok: Boolean, detail: String = "") {
        total++; count++
        if (!ok) {
            failures++; failed++
            println("  FAIL  [$name] $what  $detail")
        } else if (verbose) println("  ok    $what")
    }

    fun flush() {
        if (name.isNotEmpty()) println((if (failed == 0) "  ✓ " else "  ✗ ") + "$name ($count kontrol)")
        name = ""
    }
}

private val loopback: InetAddress = InetAddress.getLoopbackAddress()
private val CLIENT_IP = Packets.ip(10, 111, 222, 1)
private val FAKE_DNS = Packets.ip(10, 111, 222, 2)

/** Gerçek bir UDP DNS sunucusu taklidi: her sorguya A kaydı (1.2.3.4) ile cevap verir. */
private class FakeDns(
    private val respond: Boolean = true,
    private val ttl: Int = 60,
    private val answerIp: ByteArray = byteArrayOf(1, 2, 3, 4),
    private val delayMs: Long = 0,
    private val dropFirst: Int = 0,
) : AutoCloseable {
    val socket = DatagramSocket(0, loopback)
    val received = AtomicInteger()
    val addr: InetSocketAddress get() = InetSocketAddress(loopback, socket.localPort)

    init {
        Thread {
            val buf = ByteArray(2048)
            val p = DatagramPacket(buf, buf.size)
            while (!socket.isClosed) {
                try {
                    p.length = buf.size
                    socket.receive(p)
                } catch (_: Exception) {
                    return@Thread
                }
                val n = received.incrementAndGet()
                if (!respond || n <= dropFirst) continue
                if (delayMs > 0) Thread.sleep(delayMs)
                val resp = makeResponse(buf, p.length)
                try { socket.send(DatagramPacket(resp, resp.size, p.socketAddress)) } catch (_: Exception) { return@Thread }
            }
        }.apply { isDaemon = true; start() }
    }

    fun makeResponse(q: ByteArray, len: Int, ip: ByteArray = answerIp): ByteArray {
        val out = ByteArray(len + 16)
        System.arraycopy(q, 0, out, 0, len)
        Packets.put16(out, 2, 0x8180)       // QR, RD, RA
        Packets.put16(out, 6, 1)            // ANCOUNT
        var p = len
        out[p++] = 0xC0.toByte(); out[p++] = 0x0C
        Packets.put16(out, p, 1); p += 2    // A
        Packets.put16(out, p, 1); p += 2    // IN
        Packets.put32(out, p, ttl); p += 4
        Packets.put16(out, p, 4); p += 2
        System.arraycopy(ip, 0, out, p, 4); p += 4
        return out.copyOf(p)
    }

    override fun close() = socket.close()
}

private fun clientPacket(
    id: Int,
    name: String = "example.com",
    srcPort: Int = 40000,
    dstPort: Int = 53,
    proto: Int = 17,
): ByteArray {
    val dns = Dns.buildQuery(id, name)
    val b = ByteArray(Packets.HDR + dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size)
    Packets.put16(b, 6, 0x4000)
    b[8] = 64
    b[9] = proto.toByte()
    Packets.put32(b, 12, CLIENT_IP)
    Packets.put32(b, 16, FAKE_DNS)
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, srcPort)
    Packets.put16(b, 22, dstPort)
    Packets.put16(b, 24, 8 + dns.size)
    System.arraycopy(dns, 0, b, 28, dns.size)
    return b
}

private class Harness(
    upstreams: List<InetSocketAddress>,
    nowMs: () -> Long = { System.nanoTime() / 1_000_000 },
    retryAfterMs: Long = 1200,
    giveUpAfterMs: Long = 4000,
    sweepMs: Long = 50,
    cacheEntries: Int = 256,
    protect: (DatagramSocket) -> Boolean = { true },
) : AutoCloseable {
    val tunWrites = LinkedBlockingQueue<ByteArray>()
    val logs = ArrayList<String>()
    val fw = DnsForwarder(
        upstreams = upstreams,
        writeToTun = { b, off, len -> tunWrites.add(b.copyOfRange(off, off + len)) },
        protect = protect,
        nowMs = nowMs,
        retryAfterMs = retryAfterMs,
        giveUpAfterMs = giveUpAfterMs,
        sweepMs = sweepMs,
        cacheEntries = cacheEntries,
        log = { synchronized(logs) { logs.add(it) } },
    ).also { it.start() }

    fun send(pkt: ByteArray) = fw.onPacket(pkt, pkt.size)
    fun reply(timeoutMs: Long = 2000): ByteArray? = tunWrites.poll(timeoutMs, TimeUnit.MILLISECONDS)
    override fun close() = fw.close()
}

private fun replyOk(r: ByteArray, id: Int, dstPort: Int = 40000, ip: ByteArray = byteArrayOf(1, 2, 3, 4)): String? {
    if ((r[0].toInt() and 0xF0) != 0x40) return "IP sürümü"
    if (Packets.checksum(r, 0, 20) != 0) return "IP checksum geçersiz"
    if ((r[9].toInt() and 0xFF) != 17) return "UDP değil"
    if (Packets.i32(r, 12) != FAKE_DNS) return "kaynak IP"
    if (Packets.i32(r, 16) != CLIENT_IP) return "hedef IP"
    if (Packets.u16(r, 2) != r.size) return "toplam uzunluk"
    if (Packets.u16(r, 20) != 53) return "kaynak port"
    if (Packets.u16(r, 22) != dstPort) return "hedef port ${Packets.u16(r, 22)}"
    if (Packets.u16(r, 24) != r.size - 20) return "UDP uzunluk"
    if (Packets.u16(r, 26) == 0 || !Packets.udpChecksumOk(r, 20, r.size - 20, FAKE_DNS, CLIENT_IP)) return "UDP sağlama toplamı"
    if (Packets.u16(r, 28) != id) return "DNS id ${Packets.u16(r, 28)} != $id"
    for (i in 0 until 4) if (r[r.size - 4 + i] != ip[i]) return "cevap IP'si"
    return null
}

// ---------------------------------------------------------------- paket ve DNS

private fun testPacketHelpers() {
    T.group("Paket yardımcıları")
    val hdr = byteArrayOf(
        0x45, 0x00, 0x00, 0x73, 0x00, 0x00, 0x40, 0x00, 0x40, 0x11, 0x00, 0x00,
        0xC0.toByte(), 0xA8.toByte(), 0x00, 0x01, 0xC0.toByte(), 0xA8.toByte(), 0x00, 0xC7.toByte(),
    )
    T.check("IP checksum bilinen örnekle eşleşiyor", Packets.checksum(hdr, 0, 20) == 0xB861)
    val out = ByteArray(Packets.HDR + 10)
    Packets.writeHeaders(out, FAKE_DNS, CLIENT_IP, 53, 1234, 10)
    T.check("üretilen başlığın checksum'u doğrulanıyor", Packets.checksum(out, 0, 20) == 0)
    T.check("başlıkta toplam uzunluk doğru", Packets.u16(out, 2) == out.size)

    val ok = clientPacket(1)
    T.check("geçerli DNS sorgusu kabul ediliyor", Packets.queryHeaderLen(ok, ok.size) == 20)
    T.check("DNS uzunluğu doğru hesaplanıyor", Packets.dnsLength(ok, 20) == ok.size - Packets.HDR)
    T.check("kısa paket reddediliyor", Packets.queryHeaderLen(ok, 30) == -1)
    T.check("TCP reddediliyor", clientPacket(1, proto = 6).let { Packets.queryHeaderLen(it, it.size) } == -1)
    T.check("53 dışı port reddediliyor", clientPacket(1, dstPort = 80).let { Packets.queryHeaderLen(it, it.size) } == -1)
    val v6 = ok.copyOf().also { it[0] = 0x60 }
    T.check("IPv6 reddediliyor", Packets.queryHeaderLen(v6, v6.size) == -1)
    val frag = ok.copyOf().also { Packets.put16(it, 6, 0x2000) }
    T.check("parçalı paket reddediliyor", Packets.queryHeaderLen(frag, frag.size) == -1)
    val cut = ok.copyOf().also { Packets.put16(it, 2, ok.size + 50) }
    T.check("toplam uzunluğu paketten büyük olan reddediliyor", Packets.queryHeaderLen(cut, cut.size) == -1)
}

private fun testCacheTtl() {
    T.group("DNS TTL ayrıştırma")
    FakeDns().use { fake ->
        val q = Dns.buildQuery(7, "example.com")
        val good = fake.makeResponse(q, q.size)
        T.check("normal cevap TTL=60 olarak okunuyor", Dns.cacheTtl(good, good.size) == 60)
        val nx = good.copyOf().also { Packets.put16(it, 2, 0x8183) }
        T.check("NXDOMAIN önbelleğe alınmıyor", Dns.cacheTtl(nx, nx.size) == 0)
        val tc = good.copyOf().also { Packets.put16(it, 2, 0x8380) }
        T.check("kesilmiş (TC) cevap önbelleğe alınmıyor", Dns.cacheTtl(tc, tc.size) == 0)
        val empty = good.copyOf().also { Packets.put16(it, 6, 0) }
        T.check("cevapsız mesaj önbelleğe alınmıyor", Dns.cacheTtl(empty, empty.size) == 0)
        T.check("yarım kesilmiş cevap hata vermeden reddediliyor", Dns.cacheTtl(good, good.size - 6) == 0)
        val notAnswer = good.copyOf().also { Packets.put16(it, 2, 0x0100) }
        T.check("sorgu (QR=0) önbelleğe alınmıyor", Dns.cacheTtl(notAnswer, notAnswer.size) == 0)
    }
}

private fun testDnsCache() {
    T.group("Önbellek")
    var now = 0L
    val c = DnsCache(maxEntries = 3, nowMs = { now })
    val resp = ByteArray(40).also { Packets.put16(it, 0, 0x1111) }
    val out = ByteArray(100)

    c.put("a", resp, resp.size, 60)
    val n = c.get("a", 0x2222, out, 28)
    T.check("kayıt bulunuyor ve doğru uzunlukta", n == 40)
    T.check("istemcinin id'si yazılıyor", Packets.u16(out, 28) == 0x2222)
    now = 59_000
    T.check("süre dolmadan hâlâ geçerli", c.get("a", 1, out, 0) == 40)
    now = 61_000
    T.check("TTL dolunca düşüyor", c.get("a", 1, out, 0) == -1)

    c.put("zero", resp, resp.size, 0)
    T.check("TTL=0 saklanmıyor", c.get("zero", 1, out, 0) == -1)

    now = 0
    c.put("long", resp, resp.size, 86_400)
    now = (DnsCache.MAX_TTL_S + 1) * 1000L
    T.check("çok uzun TTL 5 dakikayla sınırlanıyor", c.get("long", 1, out, 0) == -1)

    now = 0
    c.clear()
    for (k in listOf("k1", "k2", "k3")) c.put(k, resp, resp.size, 60)
    c.get("k1", 1, out, 0)
    c.put("k4", resp, resp.size, 60)
    T.check("LRU: boyut sınırı korunuyor", c.size() == 3)
    T.check("LRU: en eski kayıt atıldı", c.get("k2", 1, out, 0) == -1)
    T.check("LRU: yakın zamanda kullanılan korundu", c.get("k1", 1, out, 0) == 40)

    val off = DnsCache(maxEntries = 0, nowMs = { now })
    off.put("x", resp, resp.size, 60)
    T.check("kapalı önbellek (0 kayıt) hiçbir şey saklamıyor", off.get("x", 1, out, 0) == -1 && off.size() == 0)
}

// ---------------------------------------------------------------- yönlendirici

private fun testForwardRoundTrip() {
    T.group("Yönlendirici: uçtan uca")
    FakeDns().use { fake ->
        var protectCalls = 0
        Harness(listOf(fake.addr), protect = { protectCalls++; true }).use { h ->
            T.check("soketler protect() ile korundu (her yuva bir kez)", protectCalls == DnsForwarder.SLOTS, "protect=$protectCalls")
            h.send(clientPacket(0x1234, srcPort = 41000))
            val r = h.reply()
            T.check("cevap tünele yazıldı", r != null)
            if (r != null) {
                val err = replyOk(r, 0x1234, dstPort = 41000)
                T.check("cevap paketi geçerli (başlıklar, portlar, id, veri)", err == null, err ?: "")
            }
            T.check("bekleyen sorgu kalmadı", h.fw.pendingCount() == 0)
            val st = h.fw.stats()
            T.check("istatistik: 1 sorgu, 1 cevap", st.queries == 1L && st.answered == 1L && st.forwarded == 1L)
        }
    }
}

private fun testCacheHitAvoidsNetwork() {
    T.group("Yönlendirici: önbellek")
    FakeDns(ttl = 60).use { fake ->
        var now = 1_000L
        Harness(listOf(fake.addr), nowMs = { now }).use { h ->
            h.send(clientPacket(0x0001, srcPort = 40001))
            h.reply() ?: run { T.check("ilk sorgu cevaplandı", false); return }
            T.check("ilk sorgu upstream'e gitti", fake.received.get() == 1)

            h.send(clientPacket(0x0BAD, srcPort = 40002))
            val r = h.reply(200)
            T.check("ikinci sorgu önbellekten cevaplandı (ağ yok)", r != null && fake.received.get() == 1)
            if (r != null) {
                val err = replyOk(r, 0x0BAD, dstPort = 40002)
                T.check("önbellek cevabında yeni id ve port var", err == null, err ?: "")
            }
            T.check("istatistik: 1 önbellek isabeti, %50", h.fw.stats().cacheHits == 1L && h.fw.stats().hitPercent == 50)

            now += 61_000
            h.send(clientPacket(0x0002, srcPort = 40003))
            h.reply()
            T.check("TTL dolunca tekrar upstream'e gidiyor", fake.received.get() == 2)

            h.send(clientPacket(0x0003, name = "baska.example.org", srcPort = 40004))
            h.reply()
            T.check("farklı alan adı önbellekten gelmiyor", fake.received.get() == 3)
        }
    }
    FakeDns().use { fake ->
        Harness(listOf(fake.addr), cacheEntries = 0).use { h ->
            h.send(clientPacket(1)); h.reply()
            h.send(clientPacket(2)); h.reply()
            T.check("önbellek kapalıyken her sorgu upstream'e gidiyor", fake.received.get() == 2)
        }
    }
}

private fun testConcurrentQueries() {
    T.group("Yönlendirici: eşzamanlı sorgular")
    FakeDns().use { fake ->
        Harness(listOf(fake.addr)).use { h ->
            val n = 80
            for (i in 0 until n) h.send(clientPacket(0x4001 + i, name = "host$i.example.com", srcPort = 30000 + i))
            val got = HashSet<Int>()
            var bad = 0
            repeat(n) {
                val r = h.reply(3000) ?: return@repeat
                val id = Packets.u16(r, 28)
                got.add(id)
                if (Packets.u16(r, 22) != 30000 + (id - 0x4001)) bad++
            }
            T.check("80 sorgunun 80'i cevaplandı", got.size == n, "gelen=${got.size}")
            T.check("her cevap kendi istemci portuna döndü", bad == 0, "hatalı=$bad")
            T.check("bekleyen sorgu kalmadı", h.fw.pendingCount() == 0)
        }
    }
}

private fun testFailover() {
    T.group("Yönlendirici: yedek sunucu ve yeniden deneme")
    DatagramSocket(0, loopback).use { silent ->
        FakeDns().use { backup ->
            val primary = InetSocketAddress(loopback, silent.localPort)
            Harness(listOf(primary, backup.addr), retryAfterMs = 120, giveUpAfterMs = 2000).use { h ->
                h.send(clientPacket(0x7777, srcPort = 42000))
                val r = h.reply(2500)
                T.check("birincil cevapsızken ikincil cevap verdi", r != null)
                if (r != null) T.check("yedekten gelen cevap geçerli", replyOk(r, 0x7777, 42000) == null)
                T.check("istatistik: 1 yeniden deneme", h.fw.stats().retries == 1L)
                T.check("bekleyen sorgu kalmadı", h.fw.pendingCount() == 0)
            }
        }
    }
    FakeDns(dropFirst = 1).use { flaky ->
        Harness(listOf(flaky.addr), retryAfterMs = 100, giveUpAfterMs = 2000).use { h ->
            h.send(clientPacket(0x7778, srcPort = 42001))
            val r = h.reply(2500)
            T.check("tek sunucuda kaybolan sorgu aynı sunucuya yeniden gönderilip cevaplandı", r != null)
            T.check("tek sunucu: 2 sorgu alındı, 1 yeniden deneme", flaky.received.get() == 2 && h.fw.stats().retries == 1L)
        }
    }
}

private fun testPersistentFailover() {
    T.group("Yönlendirici: kalıcı yedek geçişi")
    FakeDns(respond = false).use { dead ->
        FakeDns().use { backup ->
            Harness(listOf(dead.addr, backup.addr), retryAfterMs = 80, giveUpAfterMs = 2000).use { h ->
                T.check("başlangıçta yedek kullanılmıyor", !h.fw.stats().backup && h.fw.stats().failovers == 0L)
                h.send(clientPacket(0x1001, name = "a.example.com", srcPort = 46001))
                h.send(clientPacket(0x1002, name = "b.example.com", srcPort = 46002))
                val got = (0 until 2).count { h.reply(2500) != null }
                T.check("iki sorgu da yedekten cevaplandı", got == 2, "gelen=$got")
                val st = h.fw.stats()
                T.check("2 sorgu birincilde cevapsız kalınca yedeğe geçildi", st.backup && st.failovers == 1L, "backup=${st.backup} geçiş=${st.failovers}")
                T.check("geçiş günlüğe yazıldı", synchronized(h.logs) { h.logs.any { it.contains("yedek sunucuya geçildi") } })

                val deadBefore = dead.received.get()
                val backupBefore = backup.received.get()
                val t0 = System.nanoTime()
                h.send(clientPacket(0x1003, name = "c.example.com", srcPort = 46003))
                val r = h.reply(2500)
                val ms = (System.nanoTime() - t0) / 1_000_000
                T.check("geçişten sonra sorgu doğrudan yedeğe gitti", r != null && backup.received.get() == backupBefore + 1 && dead.received.get() == deadBefore)
                T.check("ve yeniden deneme beklemeden cevaplandı", ms < 70, "süre=${ms}ms")
                if (r != null) T.check("cevap geçerli", replyOk(r, 0x1003, 46003) == null)

                h.fw.resetNetwork("test")
                T.check("ağ değişince birincile dönüldü", !h.fw.stats().backup)
                val deadAfter = dead.received.get()
                h.send(clientPacket(0x1004, name = "d.example.com", srcPort = 46004))
                h.reply(2500)
                T.check("sonraki sorgu yine birincile gitti", dead.received.get() == deadAfter + 1)
            }
        }
    }

    // Tek seferlik kayıp geçişe yol açmaz; birincilden gelen cevap sayacı sıfırlar.
    FakeDns(dropFirst = 1).use { flaky ->
        FakeDns().use { backup ->
            Harness(listOf(flaky.addr, backup.addr), retryAfterMs = 80, giveUpAfterMs = 2000).use { h ->
                h.send(clientPacket(0x2001, name = "e.example.com", srcPort = 46101))
                T.check("kayıp sorgu yedekten cevaplandı", h.reply(2500) != null)
                T.check("tek kayıp geçişe yol açmadı", !h.fw.stats().backup && h.fw.stats().failovers == 0L)
                h.send(clientPacket(0x2002, name = "f.example.com", srcPort = 46102))
                T.check("birincil sağlıklıyken doğrudan ondan cevap geldi", h.reply(2500) != null && flaky.received.get() == 2)
                T.check("hâlâ birincilde", !h.fw.stats().backup)
            }
        }
    }

    // Tek sunucuda geçiş yoktur.
    FakeDns(dropFirst = 2).use { one ->
        Harness(listOf(one.addr), retryAfterMs = 60, giveUpAfterMs = 2000).use { h ->
            h.send(clientPacket(0x3001, name = "g.example.com", srcPort = 46201))
            h.send(clientPacket(0x3002, name = "h.example.com", srcPort = 46202))
            repeat(2) { h.reply(2500) }
            T.check("tek sunucuda yedek durumu yok", !h.fw.stats().backup && h.fw.stats().failovers == 0L)
        }
    }
}

private fun testTimeout() {
    T.group("Yönlendirici: zaman aşımı")
    DatagramSocket(0, loopback).use { s1 ->
        DatagramSocket(0, loopback).use { s2 ->
            val ups = listOf(InetSocketAddress(loopback, s1.localPort), InetSocketAddress(loopback, s2.localPort))
            Harness(ups, retryAfterMs = 100, giveUpAfterMs = 300).use { h ->
                h.send(clientPacket(0x9999, srcPort = 43000))
                Thread.sleep(900)
                T.check("hiç cevap yazılmadı", h.tunWrites.isEmpty())
                T.check("bekleyen sorgu temizlendi (sızıntı yok)", h.fw.pendingCount() == 0)
                T.check("istatistik: 1 zaman aşımı", h.fw.stats().timeouts == 1L)
                T.check("zaman aşımı günlüğe yazıldı", synchronized(h.logs) { h.logs.any { it.contains("zaman aşımı") } })
            }
        }
    }
}

private fun testSpoofedReplyIgnored() {
    T.group("Güvenlik: sahte cevap")
    DatagramSocket(0, loopback).use { legit ->
        DatagramSocket(0, loopback).use { rogue ->
            FakeDns(respond = false).use { fake ->
                Harness(listOf(InetSocketAddress(loopback, legit.localPort))).use { h ->
                    val srv = Thread {
                        val buf = ByteArray(2048)
                        val p = DatagramPacket(buf, buf.size)
                        legit.receive(p)
                        val fromWhere = p.socketAddress
                        val forged = fake.makeResponse(buf, p.length, byteArrayOf(6, 6, 6, 6))
                        rogue.send(DatagramPacket(forged, forged.size, fromWhere))
                        Thread.sleep(80)
                        val good = fake.makeResponse(buf, p.length)
                        legit.send(DatagramPacket(good, good.size, fromWhere))
                    }.apply { isDaemon = true; start() }

                    h.send(clientPacket(0x5151, srcPort = 44000))
                    val r = h.reply(2000)
                    srv.join(1000)
                    T.check("cevap geldi", r != null)
                    if (r != null) T.check("sahte (6.6.6.6) değil gerçek cevap iletildi", replyOk(r, 0x5151, 44000) == null)
                    T.check("ikinci (sahte) cevap yazılmadı", h.reply(300) == null)
                }
            }
        }
    }
}

private fun testFuzz() {
    T.group("Dayanıklılık: bozuk paketler")
    FakeDns().use { fake ->
        Harness(listOf(fake.addr)).use { h ->
            val rnd = Random(42)
            var thrown = 0
            val base = clientPacket(1)
            repeat(20_000) {
                val len = rnd.nextInt(120)
                val junk = ByteArray(len).also { rnd.nextBytes(it) }
                val mutated = base.copyOf().also { b -> repeat(1 + rnd.nextInt(4)) { b[rnd.nextInt(b.size)] = rnd.nextInt().toByte() } }
                try {
                    h.fw.onPacket(junk, junk.size)
                    h.fw.onPacket(mutated, mutated.size)
                    h.fw.onPacket(base, minOf(rnd.nextInt(base.size + 5), base.size))
                } catch (e: Throwable) {
                    thrown++
                }
            }
            T.check("60 bin bozuk paket hata fırlatmadı", thrown == 0, "hata=$thrown")
        }
    }
}

private fun testResetNetwork() {
    T.group("Ağ değişimi: soket yenileme")
    FakeDns(dropFirst = 1).use { fake ->
        var protects = 0
        Harness(
            listOf(fake.addr), retryAfterMs = 10_000, giveUpAfterMs = 20_000,
            protect = { protects++; true },
        ).use { h ->
            h.send(clientPacket(0x3333, srcPort = 45000))
            Thread.sleep(150)
            T.check("ilk sorgu cevapsız, bekliyor", h.fw.pendingCount() == 1 && h.tunWrites.isEmpty())
            h.fw.resetNetwork("test")
            val r = h.reply(2000)
            T.check("reset sonrası bekleyen sorgu yeni soketten yeniden gönderilip cevaplandı", r != null)
            if (r != null) T.check("cevap geçerli", replyOk(r, 0x3333, 45000) == null)
            T.check("soketler iki kez korundu (açılış + reset)", protects == 2 * DnsForwarder.SLOTS, "protect=$protects")
            T.check("istatistik: 1 reset", h.fw.stats().resets == 1L)
            T.check("reset günlüğe yazıldı", synchronized(h.logs) { h.logs.any { it.contains("soket yenilendi") } })
        }
    }
    FakeDns().use { fake ->
        Harness(listOf(fake.addr)).use { h ->
            h.send(clientPacket(1, srcPort = 45001)); h.reply()
            h.send(clientPacket(2, srcPort = 45002)); h.reply(200)
            T.check("reset öncesi ikinci sorgu önbellekten geldi", fake.received.get() == 1)
            h.fw.resetNetwork()
            h.send(clientPacket(3, srcPort = 45003)); h.reply()
            T.check("reset önbelleği boşalttı: sorgu yeniden upstream'e gitti", fake.received.get() == 2)
            h.fw.resetNetwork(); h.fw.resetNetwork()
            h.send(clientPacket(4, srcPort = 45004))
            T.check("art arda reset sonrası yönlendirici çalışmaya devam ediyor", h.reply(2000) != null)
        }
    }
    FakeDns().use { fake ->
        val h = Harness(listOf(fake.addr))
        h.close()
        h.fw.resetNetwork()
        T.check("kapalı yönlendiricide reset hata vermiyor", true)
    }
    DatagramSocket(0, loopback).use { silent ->
        var allow = true
        val fw = DnsForwarder(
            upstreams = listOf(InetSocketAddress(loopback, silent.localPort)),
            writeToTun = { _, _, _ -> },
            protect = { allow },
        )
        fw.start()
        allow = false
        fw.resetNetwork("protect reddedildi")
        T.check("protect başarısızsa reset eski soketle devam ediyor, hata fırlatmıyor", fw.localPort() > 0)
        fw.close()
    }
}

private fun testAverageLatency() {
    T.group("İstatistik: ortalama yanıt süresi")
    FakeDns(delayMs = 40).use { fake ->
        Harness(listOf(fake.addr), cacheEntries = 0).use { h ->
            repeat(3) { i -> h.send(clientPacket(10 + i, srcPort = 46000 + i)); h.reply() }
            val st = h.fw.stats()
            T.check("ortalama süre gecikmeyi yansıtıyor (>= 35 ms)", st.avgMs in 35..500, "avg=${st.avgMs}")
            T.check("3 cevap sayıldı", st.answered == 3L)
        }
    }
    T.check("cevap yokken ortalama 0", Stats().avgMs == 0 && Stats().hitPercent == 0)
}

private fun testConnectionCheck() {
    T.group("Bağlantı testi")
    FakeDns().use { fake ->
        Harness(listOf(fake.addr)).use { h ->
            val ok = ConnectionCheck.run(h.fw, resolve = { h.send(clientPacket(0x0A0A, srcPort = 47000)) }, timeoutMs = 2000)
            T.check("çalışan DNS: Ok", ok is CheckResult.Ok, ok.toString())
            val cached = ConnectionCheck.run(h.fw, resolve = { h.send(clientPacket(0x0A0B, srcPort = 47001)) }, timeoutMs = 2000)
            T.check("önbellekten gelen cevap da testi geçiyor", cached is CheckResult.Ok, cached.toString())
        }
    }
    FakeDns(respond = false).use { silent ->
        Harness(listOf(silent.addr), giveUpAfterMs = 5000).use { h ->
            val r = ConnectionCheck.run(h.fw, resolve = { h.send(clientPacket(0x0A0C, srcPort = 47002)) }, timeoutMs = 300)
            T.check("cevapsız DNS: NoAnswer", r is CheckResult.NoAnswer, r.toString())
            val r2 = ConnectionCheck.run(h.fw, resolve = { throw IllegalStateException("çözümleyici hatası") }, timeoutMs = 200)
            T.check("çözümleyici hata fırlatsa da test çökmüyor", r2 is CheckResult.NoAnswer)
        }
    }
}

private fun testProbe() {
    T.group("Gecikme ölçümü")
    FakeDns().use { fake ->
        val ms = DnsProbe.measure("127.0.0.1", fake.socket.localPort, timeoutMs = 1000, attempts = 2)
        T.check("cevap veren sunucu ölçülüyor", ms != null && ms < 500, "ms=$ms")
    }
    FakeDns(respond = false).use { silent ->
        val ms = DnsProbe.measure("127.0.0.1", silent.socket.localPort, timeoutMs = 300, attempts = 1)
        T.check("cevap vermeyen sunucu için null dönüyor", ms == null)
    }
    T.check("çözülemeyen adres için null dönüyor", DnsProbe.measure("bu-adres-yok.invalid", timeoutMs = 300, attempts = 1) == null)
}

private fun testPerformanceAndMemory() {
    T.group("Performans ve bellek")
    FakeDns().use { fake ->
        Harness(listOf(fake.addr)).use { h ->
            h.send(clientPacket(1))
            h.reply() ?: run { T.check("ısınma sorgusu", false); return }
            val pkt = clientPacket(2, srcPort = 40500)
            repeat(20_000) { h.send(pkt) }
            h.tunWrites.clear()

            System.gc(); Thread.sleep(100)
            val rt = Runtime.getRuntime()
            val before = rt.totalMemory() - rt.freeMemory()
            val count = 200_000
            val t0 = System.nanoTime()
            repeat(count) {
                h.send(pkt)
                if ((it and 0x3FF) == 0) h.tunWrites.clear()
            }
            val secs = (System.nanoTime() - t0) / 1e9
            System.gc(); Thread.sleep(100)
            h.tunWrites.clear()
            System.gc(); Thread.sleep(100)
            val after = rt.totalMemory() - rt.freeMemory()
            val perSec = (count / secs).toLong()
            println("        bilgi: önbellek isabeti yolu ≈ $perSec paket/sn, bellek farkı ≈ ${(after - before) / 1024} KB")
            T.check("önbellek yolu saniyede 20 binden fazla paket işliyor", perSec > 20_000, "paket/sn=$perSec")
            T.check("200 bin sorgudan sonra bellek 4 MB'tan fazla artmadı", after - before < 4L * 1024 * 1024)
            T.check("200 bin sorgu upstream'e hiç gitmedi", fake.received.get() == 1)
        }
    }
}

private fun testThreadsStop() {
    T.group("Kaynak temizliği")
    Thread.sleep(600)
    FakeDns().use { fake ->
        val h = Harness(listOf(fake.addr))
        h.send(clientPacket(3))
        h.reply()
        val running = Thread.getAllStackTraces().keys.count { it.isAlive && it.name.startsWith("dns-") }
        val want = DnsForwarder.SLOTS + 1
        T.check("çalışırken yalnızca $want dns thread'i var (yuva başına alıcı + zamanlayıcı)", running == want, "thread=$running")
        h.fw.resetNetwork()
        Thread.sleep(200)
        val afterReset = Thread.getAllStackTraces().keys.count { it.isAlive && it.name.startsWith("dns-") }
        T.check("reset yeni thread biriktirmiyor", afterReset == want, "thread=$afterReset")
        h.close()
        Thread.sleep(500)
        val left = Thread.getAllStackTraces().keys.count { it.isAlive && it.name.startsWith("dns-") }
        T.check("kapatınca tüm dns thread'leri bitiyor", left == 0, "kalan=$left")
        h.send(clientPacket(4))
        T.check("kapalı yönlendirici paketi sessizce yok sayıyor", h.reply(200) == null)
    }
}

// ---------------------------------------------------------------- katalog ve liste

private fun testCatalog() {
    T.group("Katalog")
    val all = Catalog.builtin
    T.check("36 hazır sunucu var", all.size == 36, "n=${all.size}")
    T.check("her hazır sunucunun sahibi yazılı", all.all { !it.owner.isNullOrBlank() && !it.custom }, all.filter { it.owner.isNullOrBlank() }.joinToString { it.id })
    T.check("DoH adresleri https ve geçerli ad", all.all { it.doh == null || (it.doh.startsWith("https://") && CustomDns.validDoh(it.doh)) }, all.filter { it.doh != null && !CustomDns.validDoh(it.doh) }.joinToString { it.id })
    T.check("DoT adları geçerli", all.all { it.dot == null || CustomDns.validDot(it.dot) }, all.filter { it.dot != null && !CustomDns.validDot(it.dot) }.joinToString { it.id })
    T.check("kimlikler benzersiz", all.map { it.id }.toSet().size == all.size)
    T.check("adlar benzersiz", all.map { it.name }.toSet().size == all.size)
    T.check("tüm birincil adresler geçerli IPv4", all.all { Catalog.isIpv4(it.primary) }, all.filter { !Catalog.isIpv4(it.primary) }.joinToString { it.id })
    T.check("tüm ikincil adresler geçerli IPv4", all.all { it.secondary == null || Catalog.isIpv4(it.secondary) })
    T.check("birincil ve ikincil aynı değil", all.all { it.secondary != it.primary })
    T.check("hiçbir adres iki sunucuda tekrar etmiyor", all.flatMap { it.addresses }.let { it.size == it.toSet().size })
    T.check("her sunucunun en az bir etiketi var", all.all { it.tags.isNotEmpty() })
    T.check("her etikette en az 3 sunucu var", Tag.values().all { t -> all.count { t in it.tags } >= 3 },
        Tag.values().joinToString { t -> "${t.id}=${all.count { s -> t in s.tags }}" })
    T.check("not metinleri 40 karakteri geçmiyor", all.all { it.note.length <= 40 }, all.filter { it.note.length > 40 }.joinToString { it.id })
    T.check("ad ve not boş değil", all.all { it.name.isNotBlank() && it.note.isNotBlank() })
    T.check("varsayılan sunucu katalogda", Catalog.byId(Catalog.DEFAULT_ID) != null && Catalog.default.id == "cloudflare")
    T.check("bilinmeyen kimlik null", Catalog.byId("yok") == null && Catalog.byId(null) == null)
    T.check("IPv4 doğrulama: geçersizler reddediliyor",
        listOf("", "1.2.3", "1.2.3.4.5", "256.1.1.1", "a.b.c.d", "1..2.3", "1.2.3.-4", "1.2.3.4444").none { Catalog.isIpv4(it) })
    T.check("IPv4 doğrulama: geçerliler kabul ediliyor", listOf("0.0.0.0", "255.255.255.255", "1.1.1.1").all { Catalog.isIpv4(it) })
    T.check("etiket kimlikleri çözülüyor", Tag.byId("ads") == Tag.ADS && Tag.byId("x") == null)
}

private fun testCustomDns() {
    T.group("Özel DNS")
    fun d(n: String = "Evim", a: String = "192.168.1.2", b: String = "", dot: String = "", doh: String = "") = CustomDns.Draft(n, a, b, dot, doh)
    T.check("geçerli: yalnızca ad ve adres", CustomDns.validate(d()) == null)
    T.check("geçerli: DoT ve DoH ile", CustomDns.validate(d(b = "192.168.1.3", dot = "dns.example.com", doh = "https://dns.example.com/dns-query")) == null)
    T.check("ad boş ya da çok uzun", CustomDns.validate(d(n = "  ")) == CustomDns.Error.NAME && CustomDns.validate(d(n = "x".repeat(25))) == CustomDns.Error.NAME)
    T.check("adda ayırıcı karakterler reddedilir", listOf("a|b", "a;b", "a,b", "a=b").all { CustomDns.validate(d(n = it)) == CustomDns.Error.NAME })
    T.check("adres: geçersizler", listOf("", "1.2.3", "300.1.1.1", "0.0.0.0", "127.0.0.1", "224.0.0.1", "255.255.255.255", "10.111.222.2", "a.b.c.d").all { CustomDns.validate(d(a = it)) == CustomDns.Error.IP }, "")
    T.check("ikinci adres kopya ya da geçersiz", CustomDns.validate(d(b = "192.168.1.2")) == CustomDns.Error.IP2 && CustomDns.validate(d(b = "x")) == CustomDns.Error.IP2)
    T.check("DoT adı: IP ve bozuk adlar reddedilir", listOf("1.2.3.4", "a", "-a.com", "a b.com", "a..com", "a.com/x").all { CustomDns.validate(d(dot = it)) == CustomDns.Error.DOT })
    T.check("DoH: http, kimlik, port, sorgu, boşluk reddedilir",
        listOf("http://a.com/x", "https://u@a.com/x", "https://a.com:8443/x", "https://a.com/x?y=1", "https://a.com/x y", "https://1.2.3.4/x", "https://", "ftp://a.com").all { CustomDns.validate(d(doh = it)) == CustomDns.Error.DOH })
    T.check("DoH: yol olmadan ve yolla geçerli", CustomDns.validate(d(doh = "https://dns0.eu")) == null && CustomDns.validate(d(doh = "https://a.com/doh/fam/")) == null)
    T.check("sınır: 8 sunucudan sonra LIMIT", CustomDns.validate(d(), CustomDns.MAX) == CustomDns.Error.LIMIT && CustomDns.validate(d(), CustomDns.MAX - 1) == null)
    val a = CustomDns.build("u1", d(n = " Ev  DNS ", b = "192.168.1.3", dot = "dns.example.com"))
    T.check("build: ad temizlenir, alanlar yerinde", a.custom && a.name == "Ev DNS" && a.secondary == "192.168.1.3" && a.dot == "dns.example.com" && a.doh == null && a.owner == null)
    T.check("özel sunucuda not ve şifreleme planı", a.note == L.tx.CUSTOM_NOTE && Encryption.AUTO.plan(a) == listOf(Proto.DOT, Proto.PLAIN))
    val b = CustomDns.build("u2", d(n = "Ofis", a = "10.0.0.5"))
    val enc = CustomDns.encode(listOf(a, b))
    val back = CustomDns.decode(enc)
    T.check("kodlama gidiş-dönüş", back.map { it.id } == listOf("u1", "u2") && back[0].dot == "dns.example.com" && back[1].primary == "10.0.0.5" && back.all { it.custom })
    T.check("bozuk satırlar atlanır", CustomDns.decode("x|a|1.1.1.1|||;u3|ok|9.9.9.9|||;u4|a|999.1.1.1|||;u5|a|1.2.3.4").map { it.id } == listOf("u3"))
    T.check("hazır kimlikle çakışan ve tekrar eden atlanır", CustomDns.decode("cloudflare|a|1.2.3.4|||;u1|a|1.2.3.4|||;u1|b|1.2.3.5|||").map { it.id } == listOf("u1"))
    T.check("çok uzun kayıt yok sayılır", CustomDns.decode("u1|a|1.2.3.4|||".repeat(400)).isEmpty())
    T.check("yeni kimlikler çakışmaz", CustomDns.newId(1_800_000_000_000, listOf("u" + java.lang.Long.toString(1_800_000_000L, 36))) != "u" + java.lang.Long.toString(1_800_000_000L, 36))
    // Ayarlarla bütünleşme
    try {
        val s = AppSettings(custom = enc, favorites = setOf("u1"), lastServer = "u2")
        val m = SettingsCodec.encode(s)
        val dec = SettingsCodec.decode(m)
        T.check("ayarlar özel sunucuyu yükler: katalog ve kimlik doğrulaması", Catalog.byId("u1") != null && Catalog.all.size == 38 && dec.favorites == setOf("u1") && dec.lastServer == "u2")
        T.check("özel sunucu dışa aktarılmaz", !SettingsCodec.export(dec).let { c -> String(Base64Mini.decode(c.removePrefix("DNSH1:"))!!, Charsets.UTF_8) }.contains("Ofis"))
        val imp = SettingsCodec.import(SettingsCodec.export(dec.copy(theme = "night")), dec)
        T.check("içe aktarma mevcut özel sunucuları korur", imp != null && imp.custom == dec.custom && Catalog.byId("u2") != null)
        val hostile = "DNSH1:" + Base64Mini.encode("custom=u9|Kotu|6.6.6.6|||\ntheme=night".toByteArray())
        val hi = SettingsCodec.import(hostile, dec)
        T.check("paylaşılan kod özel sunucu ekleyemez", hi != null && hi.custom == dec.custom && Catalog.byId("u9") == null)
        val gone = SettingsCodec.decode(SettingsCodec.encode(dec.copy(custom = "")))
        T.check("silinince katalog hazır listeye döner ve kimlikler düşer", Catalog.all.size == 36 && gone.favorites.isEmpty() && gone.lastServer == null)
    } finally { Catalog.setCustom(emptyList()) }
    T.check("ortalama ping", LatencyHistory.mean(listOf(10, null, 20, 31)) == Pair(20, 3) && LatencyHistory.mean(listOf(null, null)) == null && LatencyHistory.mean(emptyList()) == null)
}

private fun testAppScope() {
    T.group("Uygulama seçimi")
    T.check("paket adı doğrulama", listOf("com.a.b", "org.x_y.z1", "a.b").all { AppScopes.validPkg(it) } &&
        listOf("", "abc", "1a.b", "a..b", "a.b c", "a.b;c", ".a.b", "a.b,").none { AppScopes.validPkg(it) })
    T.check("kodlama: bozuklar ve tekrarlar atılır, sıralı", AppScopes.encode(setOf("b.b", "a.a", "bozuk")) == "a.a,b.b" && AppScopes.decode("a.a,bozuk,a.a,b.b,;x") == setOf("a.a", "b.b"))
    T.check("çok uzun / çok fazla kayıt sınırlanır", AppScopes.decode((1..1000).joinToString(",") { "p.a$it" }).size == AppScopes.MAX_APPS && AppScopes.decode("p.a,".repeat(40000)).isEmpty())
    val all = AppSettings()
    val inst = { p: String -> p != "yok.paket" }
    T.check("hepsi: tüm uygulamalar", AppScopes.plan(all.copy(apps = setOf("a.a")), "me.app", inst).kind == ScopePlan.Kind.ALL)
    val only = AppScopes.plan(all.copy(appScope = AppScope.ONLY, apps = setOf("a.a", "b.b", "yok.paket", "me.app")), "me.app", inst)
    T.check("yalnızca: seçililer + kendimiz, yüklü olmayan atlanır", only.kind == ScopePlan.Kind.ALLOW && only.packages == listOf("a.a", "b.b", "me.app"), only.packages.toString())
    val ex = AppScopes.plan(all.copy(appScope = AppScope.EXCEPT, apps = setOf("a.a", "me.app", "yok.paket")), "me.app", inst)
    T.check("hariç: kendimiz asla dışarıda kalmaz", ex.kind == ScopePlan.Kind.DENY && ex.packages == listOf("a.a"), ex.packages.toString())
    T.check("seçim boşsa ya da hiçbiri yüklü değilse: hepsi",
        AppScopes.plan(all.copy(appScope = AppScope.ONLY), "me.app", inst).kind == ScopePlan.Kind.ALL &&
        AppScopes.plan(all.copy(appScope = AppScope.EXCEPT, apps = setOf("yok.paket")), "me.app", inst).kind == ScopePlan.Kind.ALL &&
        AppScopes.plan(all.copy(appScope = AppScope.ONLY, apps = setOf("me.app")), "me.app", inst).kind == ScopePlan.Kind.ALL)
    val s = AppSettings(appScope = AppScope.EXCEPT, apps = setOf("a.a", "b.b"))
    val back = SettingsCodec.decode(SettingsCodec.encode(s))
    T.check("ayar gidiş-dönüş", back.appScope == AppScope.EXCEPT && back.apps == setOf("a.a", "b.b"))
    T.check("bozuk mod varsayılana düşer", SettingsCodec.decode(mapOf("appScope" to "xx", "apps" to "a.a")).appScope == AppScope.ALL)
    val code = SettingsCodec.export(s)
    val body = String(Base64Mini.decode(code.removePrefix("DNSH1:"))!!, Charsets.UTF_8)
    T.check("uygulama seçimi dışa aktarılmaz", !body.contains("appScope") && !body.contains("a.a"))
    val hostile = "DNSH1:" + Base64Mini.encode("appScope=only\napps=x.y\ntheme=night".toByteArray())
    val imp = SettingsCodec.import(hostile, AppSettings())
    T.check("paylaşılan kod uygulama seçimini değiştiremez", imp != null && imp.appScope == AppScope.ALL && imp.apps.isEmpty())
}

private fun testServerList() {
    T.group("Sunucu listesi")
    val all = Catalog.all
    val none = emptyMap<String, Latency>()
    T.check("filtresiz liste katalogla aynı", ServerList.visible(all, null, emptySet(), none, false) == all)
    val ads = ServerList.visible(all, Tag.ADS, emptySet(), none, false)
    T.check("reklam filtresi yalnızca reklam etiketlilerini veriyor", ads.isNotEmpty() && ads.all { Tag.ADS in it.tags })
    val fav = ServerList.visible(all, null, setOf("quad9", "mullvad"), none, false)
    T.check("favoriler en üstte, katalog sırasıyla", fav.take(2).map { it.id } == listOf("quad9", "mullvad"))
    T.check("favoriden sonrası katalog sırasını koruyor", fav.drop(2).map { it.id } == all.map { it.id }.filter { it != "quad9" && it != "mullvad" })
    val adsFav = ServerList.visible(all, Tag.ADS, setOf("controld-ads", "cloudflare"), none, false)
    T.check("filtre dışı favori listede görünmüyor", adsFav.none { it.id == "cloudflare" } && adsFav.first().id == "controld-ads")

    val lat = mapOf(
        "google" to Latency(30, 1), "cloudflare" to Latency(12, 1), "quad9" to Latency(null, 1), "adguard" to Latency(55, 1),
    )
    val sorted = ServerList.visible(all, null, emptySet(), lat, true)
    T.check("hıza göre: ölçülmüşler hızlıdan yavaşa", sorted.take(3).map { it.id } == listOf("cloudflare", "google", "adguard"))
    T.check("hıza göre: ölçülmemişler katalog sırasıyla ortada", sorted[3].id == "controld" && sorted[4].id == "opendns")
    T.check("hıza göre: cevapsız en sonda", sorted.last().id == "quad9")
    T.check("hıza göre sıralama liste uzunluğunu değiştirmiyor", sorted.size == all.size)
    val favSorted = ServerList.visible(all, null, setOf("adguard"), lat, true)
    T.check("favori hıza göre sıralamada da en üstte", favSorted.first().id == "adguard" && favSorted[1].id == "cloudflare")
    val f = ServerList.fastest(all, lat)
    T.check("en hızlı sunucu bulunuyor", f?.first?.id == "cloudflare" && f.second == 12)
    T.check("ölçüm yoksa en hızlı null", ServerList.fastest(all, none) == null)
    T.check("yalnızca cevapsızlar varsa en hızlı null", ServerList.fastest(all, mapOf("quad9" to Latency(null, 1))) == null)
    T.check("sinyal çubukları", ServerList.bars(null) == 0 && ServerList.bars(10) == 4 && ServerList.bars(25) == 4 &&
        ServerList.bars(40) == 3 && ServerList.bars(80) == 2 && ServerList.bars(300) == 1)

    val enc = LatencyCodec.encode(lat)
    val dec = LatencyCodec.decode(enc)
    T.check("gecikme kodlama gidiş-dönüş", dec == lat, enc)
    T.check("bozuk gecikme verisi yok sayılıyor", LatencyCodec.decode("xx;=1@2;cloudflare=abc@1;cloudflare=5@z;yok=3@4;google=7@9") == mapOf("google" to Latency(7, 9)))
    T.check("boş/null gecikme verisi boş sözlük", LatencyCodec.decode(null).isEmpty() && LatencyCodec.decode("").isEmpty())
}

private fun testSettings() {
    T.group("Ayarlar")
    val d = AppSettings()
    T.check("boş sözlük varsayılan ayarları veriyor", SettingsCodec.decode(emptyMap()) == d)
    T.check("varsayılan ayarlar gidiş-dönüş", SettingsCodec.decode(SettingsCodec.encode(d)) == d)
    val custom = AppSettings(
        theme = "sunset", glass = 0.9f, bubbles = BubbleLevel.MANY, motion = Motion.REDUCED, haptics = false, lowPower = true,
        autoConnect = true, connectOnBoot = true, refreshOnNetwork = false, cache = CacheLevel.LARGE,
        wifiServer = "quad9", mobileServer = "adguard", lastServer = "mullvad", favorites = setOf("google", "dns4eu"),
        sortMode = SortMode.SPEED, wasActive = true, totalQueries = 123_456, totalHits = 7_890, totalSeconds = 86_400,
        autoLight = "honey", autoDark = "aurora", nightHours = NightHours.H23_08, strictEncryption = true, autoReconnect = false,
        backupServer = "quad9", confirmDisconnect = true, hideOnLockscreen = true, quietNotification = true, rememberFilter = false,
        lastFilter = "encrypted", autoMeasure = true, measureEncrypted = true, lastSeenVersion = 3, totalAnswered = 50, totalLatencyMs = 1500,
        bytesUp = 1234, bytesDown = 56789, usage = "google=120;quad9=60",
        sessions = SessionLog.encode(listOf(Session("cloudflare", Proto.DOT, 1_000, 61_000, EndReason.USER, 42))),
    )
    T.check("özel ayarlar gidiş-dönüş", SettingsCodec.decode(SettingsCodec.encode(custom)) == custom)
    T.check("eski sürüm: sortBySpeed=true hız sıralamasına taşınır", SettingsCodec.decode(mapOf("sortBySpeed" to "true")).sortMode == SortMode.SPEED &&
        SettingsCodec.decode(mapOf("sortBySpeed" to "true", "sortMode" to "name")).sortMode == SortMode.NAME)
    T.check("yedek sunucu doğrulanır", SettingsCodec.decode(mapOf("backupServer" to "yok")).backupServer == null &&
        SettingsCodec.decode(mapOf("backupServer" to "auto")).backupServer == AppSettings.BACKUP_AUTO)
    T.check("otomatik temada yalnızca gerçek temalar", SettingsCodec.decode(mapOf("autoLight" to "auto", "autoDark" to "yok")).let {
        it.autoLight == "aqua" && it.autoDark == "night" })
    T.check("ortalama yanıt ve kazanılan süre", AppSettings(totalAnswered = 10, totalLatencyMs = 300, totalHits = 1000).let {
        it.avgLatencyMs == 30 && it.savedSeconds == 30L } && AppSettings().avgLatencyMs == null)
    val bad = mapOf(
        "theme" to "yok", "glass" to "NaN", "bubbles" to "çok", "motion" to "x", "haptics" to "evet", "cache" to "dev",
        "wifiServer" to "yok", "lastServer" to "", "favorites" to "google,yok,,quad9", "totalQueries" to "-5", "totalSeconds" to "abc",
    )
    val dec = SettingsCodec.decode(bad)
    T.check("geçersiz tema varsayılana düşüyor", dec.theme == Themes.AUTO_ID)
    T.check("NaN cam değeri varsayılana düşüyor", dec.glass == d.glass)
    T.check("geçersiz sayımlar/boolean varsayılana düşüyor", dec.bubbles == d.bubbles && dec.motion == d.motion &&
        dec.haptics == d.haptics && dec.cache == d.cache)
    T.check("bilinmeyen sunucu kimlikleri temizleniyor", dec.wifiServer == null && dec.lastServer == null &&
        dec.favorites == setOf("google", "quad9"))
    T.check("negatif ve bozuk toplamlar 0", dec.totalQueries == 0L && dec.totalSeconds == 0L)
    T.check("cam değeri 0..1'e kırpılıyor", SettingsCodec.decode(mapOf("glass" to "7")).glass == 1f &&
        SettingsCodec.decode(mapOf("glass" to "-3")).glass == 0f)
    T.check("düşük güç modu hareketi ve kabarcıkları kapatıyor",
        AppSettings(lowPower = true).effectiveMotion == Motion.OFF && AppSettings(lowPower = true).effectiveBubbles == BubbleLevel.OFF &&
            d.effectiveMotion == Motion.FULL && d.effectiveBubbles == BubbleLevel.FEW)
    T.check("önbellek boyutları", CacheLevel.OFF.entries == 0 && CacheLevel.SMALL.entries < CacheLevel.NORMAL.entries &&
        CacheLevel.NORMAL.entries < CacheLevel.LARGE.entries)
    T.check("hareket çarpanları", Motion.FULL.scale == 1f && Motion.REDUCED.scale in 0.1f..0.9f && Motion.OFF.scale == 0f)
}

private fun testRules() {
    T.group("Ağa göre DNS")
    fun net(w: Boolean = false, c: Boolean = false, e: Boolean = false, v: Boolean = true) = NetInfo(w, c, e, v)
    T.check("ağ yok", Rules.pick(emptyList()) == NetKind.NONE)
    T.check("yalnızca mobil", Rules.pick(listOf(net(c = true))) == NetKind.MOBILE)
    T.check("Wi-Fi ve mobil birlikte: Wi-Fi", Rules.pick(listOf(net(c = true), net(w = true))) == NetKind.WIFI)
    T.check("doğrulanmamış Wi-Fi varken doğrulanmış mobil seçiliyor", Rules.pick(listOf(net(w = true, v = false), net(c = true))) == NetKind.MOBILE)
    T.check("hepsi doğrulanmamışsa yine de Wi-Fi", Rules.pick(listOf(net(w = true, v = false), net(c = true, v = false))) == NetKind.WIFI)
    T.check("ethernet", Rules.pick(listOf(net(e = true))) == NetKind.ETHERNET)
    T.check("bilinmeyen tür", Rules.pick(listOf(net())) == NetKind.OTHER)
    val s = AppSettings(wifiServer = "quad9", mobileServer = "adguard", lastServer = "google")
    T.check("Wi-Fi kuralı", Rules.ruleFor(s, NetKind.WIFI) == "quad9" && Rules.initialServer(s, NetKind.WIFI) == "quad9")
    T.check("mobil kuralı", Rules.ruleFor(s, NetKind.MOBILE) == "adguard" && Rules.initialServer(s, NetKind.MOBILE) == "adguard")
    T.check("kural yoksa son kullanılan", Rules.ruleFor(s, NetKind.ETHERNET) == null && Rules.initialServer(s, NetKind.ETHERNET) == "google")
    T.check("hiçbiri yoksa varsayılan", Rules.initialServer(AppSettings(), NetKind.WIFI) == Catalog.DEFAULT_ID)
}

private fun testFormat() {
    T.group("Biçimleme")
    T.check("saat biçimi", Format.clock(754) == "12:34" && Format.clock(3725) == "1:02:05" && Format.clock(-5) == "00:00" && Format.clock(0) == "00:00")
    T.check("uzun süre", Format.span(45) == "45 sn" && Format.span(600) == "10 dk" && Format.span(7500) == "2 sa 5 dk" &&
        Format.span(7200) == "2 sa" && Format.span(200_000) == "2 gün 7 sa" && Format.span(172_800) == "2 gün")
    T.check("sayı biçimi", Format.count(950) == "950" && Format.count(1250) == "1,2 bin" && Format.count(48_000) == "48 bin" &&
        Format.count(3_400_000) == "3,4 mn" && Format.count(12_000_000) == "12 mn" && Format.count(0) == "0")
    T.check("geçen süre", Format.ago(10_000) == "az önce" && Format.ago(5 * 60_000L) == "5 dk önce" &&
        Format.ago(3 * 3_600_000L) == "3 sa önce" && Format.ago(3 * 86_400_000L) == "3 gün önce" && Format.ago(-1) == "az önce")
    T.check("ms", Format.ms(12) == "12 ms")
}

private fun testDiagLog() {
    T.group("Tanılama günlüğü")
    var t = 1_700_000_000_000L
    val log = DiagLog(capacity = 3, clock = { t })
    for (i in 1..5) { log.add("olay $i"); t += 1000 }
    T.check("kapasite aşılınca en eskiler düşüyor", log.size() == 3)
    val dump = log.dump()
    T.check("dökümde son 3 olay var, ilk ikisi yok", dump.contains("olay 5") && dump.contains("olay 3") && !dump.contains("olay 2"))
    T.check("her satır saatle başlıyor", dump.lines().all { Regex("""^\d\d:\d\d:\d\d .+""").matches(it) })
    log.clear()
    T.check("temizleme", log.size() == 0 && log.dump().isEmpty())
    val threads = (1..4).map { n -> Thread { repeat(500) { log.add("t$n-$it") } } }
    threads.forEach { it.start() }; threads.forEach { it.join() }
    T.check("eşzamanlı yazma kapasiteyi aşmıyor", log.size() == 3)
}

// ---------------------------------------------------------------- tema ve hareket

private fun testColors() {
    T.group("Renk matematiği")
    T.check("beyaz/siyah kontrastı 21", Math.abs(Rgb.contrast(Rgb.WHITE, 0xFF000000.toInt()) - 21.0) < 0.01)
    T.check("aynı renk kontrastı 1", Rgb.contrast(0xFF336699.toInt(), 0xFF336699.toInt()) == 1.0)
    T.check("lerp uçları", Rgb.lerp(0xFF000000.toInt(), Rgb.WHITE, 0f) == 0xFF000000.toInt() && Rgb.lerp(0xFF000000.toInt(), Rgb.WHITE, 1f) == Rgb.WHITE)
    T.check("lerp ortası gri", Rgb.lerp(0xFF000000.toInt(), Rgb.WHITE, 0.5f) == 0xFF808080.toInt())
    T.check("alpha() RGB'yi koruyor", Rgb.alpha(0xFF123456.toInt(), 0.5f) == 0x80123456.toInt())
    T.check("opak üst renk alttakini örtüyor", Rgb.over(0xFF112233.toInt(), 0xFFAABBCC.toInt()) == 0xFF112233.toInt())
    T.check("yarı saydam beyaz siyahı griye çeviriyor", Rgb.over(Rgb.alpha(Rgb.WHITE, 0.5f), 0xFF000000.toInt()) == 0xFF808080.toInt())
    T.check("tam saydam üst renk alttakini bırakıyor", Rgb.over(0x00FFFFFF, 0xFF336699.toInt()) == 0xFF336699.toInt())
}

private fun testThemes() {
    T.group("Temalar")
    val all = Themes.all
    T.check("12 tema, kimlikler benzersiz", all.size == 12 && all.map { it.id }.toSet().size == 12)
    T.check("üç koyu tema: Gece, AMOLED, Kuzey ışıkları", all.count { it.dark } == 3 && Themes.night.dark && Themes.amoled.dark && Themes.aurora.dark)
    T.check("otomatik tema seçilen açık/koyu temayı kullanır", Themes.resolve("auto", false, "honey", "aurora", null) === Themes.honey &&
        Themes.resolve("auto", true, "honey", "aurora", null) === Themes.aurora)
    T.check("duvar kağıdı teması: renk yoksa Aqua/Gece, varsa üretilir ve önbellekte",
        Themes.resolve("dynamic", false, "aqua", "night", null) === Themes.aqua &&
            Themes.resolve("dynamic", true, "aqua", "night", 0xFF3366CC.toInt()).let { it.id == "dynamic" && it.dark } &&
            Themes.dynamic(0xFF3366CC.toInt(), true) === Themes.dynamic(0xFF3366CC.toInt(), true))
    T.check("gece saatleri aralıkları", NightHours.H22_07.isNight(23) && NightHours.H22_07.isNight(3) && !NightHours.H22_07.isNight(7) &&
        !NightHours.H22_07.isNight(12) && NightHours.H20_06.isNight(20) && !NightHours.H23_08.isNight(22) && NightHours.H23_08.label == "23–08")
    T.check("otomatik tema sistem moduna göre çözülüyor", Themes.resolve(Themes.AUTO_ID, true) === Themes.night &&
        Themes.resolve(Themes.AUTO_ID, false) === Themes.aqua)
    T.check("kimlikle çözümleme, bilinmeyen kimlik Aqua", Themes.resolve("sunset", true) === Themes.sunset && Themes.resolve("yok", false) === Themes.aqua)
    T.check("geçerli kimlik denetimi", Themes.isValidId("auto") && Themes.isValidId("ocean") && !Themes.isValidId("x"))
    T.check("tema geçişi uçları", AeroTheme.lerp(Themes.aqua, Themes.night, 0f) === Themes.aqua &&
        AeroTheme.lerp(Themes.aqua, Themes.night, 1f) === Themes.night)
    val mid = AeroTheme.lerp(Themes.aqua, Themes.night, 0.5f)
    T.check("tema geçişi ortası iki rengin arasında", mid.skyTop == Rgb.lerp(Themes.aqua.skyTop, Themes.night.skyTop, 0.5f))
    T.check("gökyüzü örneği uçları", Themes.aqua.skyAt(0f) == Themes.aqua.skyTop && Themes.aqua.skyAt(1f) == Themes.aqua.skyBottom &&
        Themes.aqua.skyAt(AeroTheme.SKY_MID_POS) == Themes.aqua.skyMid)
    T.check("cam şeffaflığı kaydırıcıyla artıyor, koyuda daha düşük",
        GlassMath.top(1f) > GlassMath.top(0f) && GlassMath.bottom(1f) > GlassMath.bottom(0f) &&
            GlassMath.top(0.5f, dark = true) < GlassMath.top(0.5f) && GlassMath.top(0.5f) > GlassMath.bottom(0.5f))
}

/** Okunabilirlik: her temada metinler cam kartın ve gökyüzünün üzerinde en az 4.5:1 kontrast vermeli. */
private fun testContrast() {
    T.group("Okunabilirlik (WCAG kontrast)")
    for (t in Themes.all) {
        var worstText = 99.0
        var worstSoft = 99.0
        var worstLink = 99.0
        var where = ""
        for (g in listOf(0f, 0.55f, 1f)) {
            for (y in listOf(0.3f, 0.45f, 0.6f, 0.75f, 0.9f, 1.0f)) {
                for (top in listOf(true, false)) {
                    val a = if (top) GlassMath.top(g, t.dark) else GlassMath.bottom(g, t.dark)
                    val card = Rgb.over(Rgb.alpha(t.tint, a), t.skyAt(y))
                    val ct = Rgb.contrast(t.text, card)
                    if (ct < worstText) { worstText = ct; where = "g=$g y=$y top=$top" }
                    worstSoft = minOf(worstSoft, Rgb.contrast(t.textSoft, card))
                    worstLink = minOf(worstLink, Rgb.contrast(t.link, card))
                }
            }
        }
        T.check("${t.name}: kart üstü metin >= 4.5", worstText >= 4.5, "en kötü %.2f (%s)".format(worstText, where))
        T.check("${t.name}: kart üstü soluk metin >= 4.5", worstSoft >= 4.5, "en kötü %.2f".format(worstSoft))
        T.check("${t.name}: kart üstü vurgu yazısı >= 4.5", worstLink >= 4.5, "en kötü %.2f".format(worstLink))
        val onSky = listOf(0.04f, 0.15f, 0.3f, 0.45f, 0.6f).minOf { Rgb.contrast(t.text, t.skyAt(it)) }
        T.check("${t.name}: gökyüzü üstü metin >= 4.5", onSky >= 4.5, "en kötü %.2f".format(onSky))
        val ctl = minOf(Rgb.contrast(t.onControl, t.control), Rgb.contrast(t.onControl, t.controlDeep))
        T.check("${t.name}: seçili düğme üstü beyaz yazı >= 4.5", ctl >= 4.5, "en kötü %.2f".format(ctl))
        T.check("${t.name}: vurgu renkleri canlı sıralı (açık > orta > koyu)",
            Rgb.luminance(t.accentLight) > Rgb.luminance(t.accent) && Rgb.luminance(t.accent) > Rgb.luminance(t.accentDeep))
    }
}

private fun testMotion() {
    T.group("Hareket matematiği")
    T.check("easing uçları", listOf(Easing::outCubic, Easing::inOutCubic).all { it(0f) == 0f && Math.abs(it(1f) - 1f) < 1e-6f })
    T.check("easing dışarıyı kırpıyor", Easing.outCubic(-1f) == 0f && Easing.outCubic(2f) == 1f && Easing.clamp01(5f) == 1f)
    var mono = true
    var prev = 0f
    for (i in 1..100) { val v = Easing.outCubic(i / 100f); if (v < prev) mono = false; prev = v }
    prev = 0f
    for (i in 1..100) { val v = Easing.inOutCubic(i / 100f); if (v < prev) mono = false; prev = v }
    T.check("easing eğrileri artan", mono)
    T.check("outBack bir noktada 1'i aşıp 1'e dönüyor", (1..99).any { Easing.outBack(it / 100f) > 1f } && Math.abs(Easing.outBack(1f) - 1f) < 1e-5f)

    val a = BubbleField(5L).also { it.setCount(10) }
    val b = BubbleField(5L).also { it.setCount(10) }
    repeat(300) { a.update(0.033f); b.update(0.033f) }
    T.check("aynı tohum aynı kabarcıkları üretiyor", a.items.zip(b.items).all { (p, q) -> p.x == q.x && p.y == q.y && p.r == q.r })
    T.check("kabarcık sayısı ayarlanıyor", a.items.size == 10 && BubbleField().also { it.setCount(0) }.items.isEmpty())
    a.setCount(4)
    T.check("sayı azaltılabiliyor", a.items.size == 4)
    val f = BubbleField(9L).also { it.setCount(15) }
    var inRange = true
    var respawned = false
    var prevYs = f.items.map { it.y }
    repeat(3000) {
        f.update(0.05f, 3f)
        for ((i, bb) in f.items.withIndex()) {
            if (bb.y < -0.2f || bb.y > 1.4f || bb.x < 0f || bb.x > 1f || bb.r < 4f || bb.r > 40f) inRange = false
            if (bb.y > prevYs[i] + 0.5f) respawned = true
        }
        prevYs = f.items.map { it.y }
    }
    T.check("kabarcıklar sınırlar içinde kalıyor", inRange)
    T.check("ekrandan çıkan kabarcıklar altta yeniden doğuyor", respawned)
    val before = f.items.map { it.y }
    f.update(0f)
    T.check("dt=0 kabarcığı oynatmıyor", f.items.map { it.y } == before)

    T.check("sıvı hedefleri sıralı", OrbMath.targetLevel(OrbState.OFF) < OrbMath.targetLevel(OrbState.CONNECTING) &&
        OrbMath.targetLevel(OrbState.CONNECTING) < OrbMath.targetLevel(OrbState.ON) && OrbMath.targetLevel(OrbState.OFF) == 0f)
    var cur = 0f
    var over = false
    var steps = 0
    while (!OrbMath.settled(cur, 0.66f) && steps < 1000) { cur = OrbMath.approach(cur, 0.66f, 0.016f); if (cur > 0.66f) over = true; steps++ }
    T.check("sıvı seviyesi hedefe aşmadan yaklaşıyor ve duruyor", !over && steps < 200 && OrbMath.settled(cur, 0.66f), "adım=$steps")
    T.check("büyük dt hedefi aşmıyor", OrbMath.approach(0f, 1f, 100f) <= 1f && OrbMath.approach(0f, 1f, 0f) == 0f && OrbMath.approach(0.5f, 1f, -1f) == 0.5f)
    T.check("dalga genliği sınırlı", (0..100).all { Math.abs(OrbMath.wave(it / 100f, it * 0.3f, 4f)) <= 4.0001f })
}

fun runCoreTests() {
    println("DNS Hızlı çekirdek testleri\n")
    testPacketHelpers()
    testCacheTtl()
    testDnsCache()
    testForwardRoundTrip()
    testCacheHitAvoidsNetwork()
    testConcurrentQueries()
    testFailover()
    testPersistentFailover()
    testTimeout()
    testSpoofedReplyIgnored()
    testFuzz()
    testResetNetwork()
    testAverageLatency()
    testConnectionCheck()
    testProbe()
    testCatalog()
    testCustomDns()
    testAppScope()
    testServerList()
    testSettings()
    testRules()
    testFormat()
    testDiagLog()
    testColors()
    testThemes()
    testContrast()
    testMotion()
    testPerformanceAndMemory()
    testThreadsStop()
}

