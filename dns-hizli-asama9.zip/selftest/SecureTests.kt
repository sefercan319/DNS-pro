package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyStore
import java.security.cert.X509Certificate
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLServerSocket
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManagerFactory

// =================================================================================== yerel TLS altyapısı

private val lo: InetAddress = InetAddress.getLoopbackAddress()
private val CIP = Packets.ip(10, 111, 222, 1)
private val FIP = Packets.ip(10, 111, 222, 2)

/**
 * Testler için kendi imzalı sertifikalar: "dns.test" (doğru) ve "wrong.test" (yanlış ad). JDK'nın keytool aracıyla
 * çalışma anında üretilir; istemci yalnızca bu sertifikalara güvenir (gerçek bir sertifika yetkilisi gerekmez).
 */
private object TestTls {
    private val dir: File = kotlin.io.path.createTempDirectory("dnshizli-tls").toFile().also { it.deleteOnExit() }
    private const val PASS = "testpass"

    private fun keystore(name: String): KeyStore {
        val f = File(dir, "$name.p12")
        if (!f.exists()) {
            val keytool = File(System.getProperty("java.home"), "bin/keytool").path
            val p = ProcessBuilder(
                keytool, "-genkeypair", "-alias", "s", "-keyalg", "EC", "-groupname", "secp256r1",
                "-dname", "CN=$name", "-ext", "SAN=dns:$name", "-validity", "3650",
                "-keystore", f.path, "-storetype", "PKCS12", "-storepass", PASS, "-keypass", PASS,
            ).redirectErrorStream(true).start()
            p.inputStream.readBytes()
            check(p.waitFor() == 0) { "keytool başarısız" }
        }
        return KeyStore.getInstance("PKCS12").also { ks -> f.inputStream().use { ks.load(it, PASS.toCharArray()) } }
    }

    val good: KeyStore by lazy { keystore("dns.test") }
    val wrong: KeyStore by lazy { keystore("wrong.test") }

    fun serverContext(ks: KeyStore): SSLContext {
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, PASS.toCharArray())
        return SSLContext.getInstance("TLS").also { it.init(kmf.keyManagers, null, null) }
    }

    /** İstemci: iki test sertifikasına da güvenir (ad denetimini [verifier] yapar). */
    val client: SSLSocketFactory by lazy {
        val trust = KeyStore.getInstance(KeyStore.getDefaultType()).also { it.load(null, null) }
        trust.setCertificateEntry("good", good.getCertificate("s"))
        trust.setCertificateEntry("wrong", wrong.getCertificate("s"))
        val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        tmf.init(trust)
        SSLContext.getInstance("TLS").also { it.init(null, tmf.trustManagers, null) }.socketFactory
    }

    /** Android'deki varsayılan doğrulayıcının yaptığı gibi: sertifikanın DNS adları arasında [host] var mı? */
    val verifier = HostnameVerifier { host, session ->
        val cert = session.peerCertificates.firstOrNull() as? X509Certificate ?: return@HostnameVerifier false
        (cert.subjectAlternativeNames ?: emptyList()).any { it.size >= 2 && it[0] == 2 && it[1] == host }
    }
}

/** DNS cevabı üretir: sorgunun kendisi + [ips] adresleriyle A kayıtları (her biri TTL [ttl]). */
private fun answer(q: ByteArray, len: Int, ips: List<ByteArray>, ttl: Int = 60): ByteArray {
    val out = java.io.ByteArrayOutputStream()
    out.write(q, 0, len)
    val b = out.toByteArray()
    Packets.put16(b, 2, 0x8180)
    Packets.put16(b, 6, ips.size)
    val o = java.io.ByteArrayOutputStream()
    o.write(b)
    for (ip in ips) {
        o.write(byteArrayOf(0xC0.toByte(), 0x0C, 0, 1, 0, 1))
        o.write(byteArrayOf((ttl ushr 24).toByte(), (ttl ushr 16).toByte(), (ttl ushr 8).toByte(), ttl.toByte(), 0, 4))
        o.write(ip)
    }
    return o.toByteArray()
}

/** Sorgudaki adı okur (testte hangi cevabın verileceğini seçmek için). */
private fun qname(q: ByteArray): String {
    val sb = StringBuilder()
    var p = 12
    while (p < q.size) {
        val l = q[p].toInt() and 0xFF
        if (l == 0) break
        if (sb.isNotEmpty()) sb.append('.')
        sb.append(String(q, p + 1, l, Charsets.ISO_8859_1))
        p += 1 + l
    }
    return sb.toString()
}

/**
 * Yerel DoT/DoH sunucusu taklidi. "blocked.test" için 0.0.0.0, "big.test" için 150 A kaydı (MTU'yu aşan cevap),
 * diğer adlar için 1.2.3.4 döner. Davranışlar: cevap verme, her N cevaptan sonra bağlantıyı kapat, HTTP durum kodu,
 * parçalı (chunked) gövde, "Connection: close".
 */
private class FakeTlsDns(val doh: Boolean, ks: KeyStore = TestTls.good) : AutoCloseable {
    private val ctx = TestTls.serverContext(ks)
    val server = ctx.serverSocketFactory.createServerSocket(0, 50, lo) as SSLServerSocket
    val accepted = AtomicInteger()
    val queries = AtomicInteger()
    @Volatile var respond = true
    @Volatile var closeEvery = 0
    @Volatile var status = 200
    @Volatile var chunked = false
    @Volatile var connClose = false
    val requests = CopyOnWriteArrayList<String>()
    val zeroIds = AtomicInteger()
    /** "slow" ile başlayan adlar bu kadar geç cevaplanır (yavaş yetkili sunucu taklidi). */
    @Volatile var slowMs = 0L
    /** DoH: doluysa normal cevap yerine bu ham HTTP cevabı yazılır (bozuk sunucu taklidi). */
    @Volatile var rawHttp: ByteArray? = null
    /** DoH: cevabı bayt bayt bu aralıkla yaz (yavaş yavaş damlatan sunucu). */
    @Volatile var trickleMs = 0L
    private val socks = CopyOnWriteArrayList<Socket>()

    val target: SecureTarget get() = SecureTarget(InetSocketAddress(lo, server.localPort), "dns.test", "/dns-query")

    init {
        Thread {
            while (!server.isClosed) {
                val s = try { server.accept() } catch (_: Exception) { return@Thread }
                accepted.incrementAndGet()
                socks.add(s)
                Thread { try { serve(s) } catch (_: Exception) {} finally { try { s.close() } catch (_: Exception) {} } }
                    .apply { isDaemon = true; start() }
            }
        }.apply { isDaemon = true; start() }
    }

    private fun reply(q: ByteArray): ByteArray {
        val name = qname(q)
        if (name == "wrongq.test") {
            // Kimlik aynı ama soru bölümü başka bir ada ait: sahte ya da bozuk cevap.
            val other = Dns.buildQuery(Packets.u16(q, 0), "evil.test")
            return answer(other, other.size, listOf(byteArrayOf(6, 6, 6, 6)))
        }
        val ips = when (name) {
            "blocked.test" -> listOf(byteArrayOf(0, 0, 0, 0))
            "big.test" -> (1..150).map { byteArrayOf(10, 0, (it / 256).toByte(), (it % 256).toByte()) }
            else -> listOf(byteArrayOf(1, 2, 3, 4))
        }
        return answer(q, q.size, ips)
    }

    private fun serve(s: Socket) {
        val i = BufferedInputStream(s.getInputStream())
        val o = s.getOutputStream()
        var answered = 0
        while (true) {
            val q = if (doh) readHttp(i) ?: return else readDot(i) ?: return
            queries.incrementAndGet()
            if (Packets.u16(q, 0) == 0) zeroIds.incrementAndGet()
            if (!respond) continue
            if (slowMs > 0 && qname(q).startsWith("slow")) Thread.sleep(slowMs)
            val r = reply(q)
            val raw = rawHttp
            if (doh && raw != null) { o.write(raw); o.flush() }
            else if (doh) writeHttp(o, r) else { o.write(byteArrayOf((r.size ushr 8).toByte(), r.size.toByte())); o.write(r); o.flush() }
            answered++
            if (connClose && doh) return
            if (closeEvery > 0 && answered % closeEvery == 0) return
        }
    }

    private fun readDot(i: InputStream): ByteArray? {
        val hi = i.read(); val lo2 = i.read()
        if (hi < 0 || lo2 < 0) return null
        val n = (hi shl 8) or lo2
        val b = ByteArray(n)
        var got = 0
        while (got < n) { val r = i.read(b, got, n - got); if (r < 0) return null; got += r }
        return b
    }

    private fun line(i: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val c = i.read()
            if (c < 0) return null
            if (c == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(c.toChar())
        }
    }

    private fun readHttp(i: InputStream): ByteArray? {
        val req = line(i) ?: return null
        var len = 0
        var host = ""
        while (true) {
            val l = line(i) ?: return null
            if (l.isEmpty()) break
            val k = l.substringBefore(':').trim().lowercase()
            val v = l.substringAfter(':').trim()
            if (k == "content-length") len = v.toInt()
            if (k == "host") host = v
        }
        requests.add("$req|$host")
        val b = ByteArray(len)
        var got = 0
        while (got < len) { val r = i.read(b, got, len - got); if (r < 0) return null; got += r }
        return b
    }

    private fun writeHttp(o: OutputStream, body: ByteArray) {
        val head = StringBuilder("HTTP/1.1 $status X\r\nContent-Type: application/dns-message\r\n")
        if (connClose) head.append("Connection: close\r\n")
        if (chunked) {
            head.append("Transfer-Encoding: chunked\r\n\r\n")
            o.write(head.toString().toByteArray())
            val half = body.size / 2
            for ((a, b) in listOf(0 to half, half to body.size)) {
                o.write("${Integer.toHexString(b - a)}\r\n".toByteArray()); o.write(body, a, b - a); o.write("\r\n".toByteArray())
            }
            o.write("0\r\n\r\n".toByteArray())
        } else {
            head.append("Content-Length: ${body.size}\r\n\r\n")
            val all = head.toString().toByteArray() + body
            if (trickleMs > 0) for (b in all) { o.write(b.toInt()); o.flush(); Thread.sleep(trickleMs) }
            else o.write(all)
        }
        o.flush()
    }

    /** Açık bağlantıların hepsini sunucu tarafından kapatır (ör. sunucunun boşta kapatması). */
    fun dropConnections() { for (s in socks) try { s.close() } catch (_: Exception) {} ; socks.clear() }

    override fun close() { try { server.close() } catch (_: Exception) {}; dropConnections() }
}

private fun qpacket(id: Int, name: String = "example.com", srcPort: Int = 40000): ByteArray {
    val dns = Dns.buildQuery(id, name)
    val b = ByteArray(Packets.HDR + dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size)
    Packets.put16(b, 6, 0x4000)
    b[8] = 64
    b[9] = 17
    Packets.put32(b, 12, CIP)
    Packets.put32(b, 16, FIP)
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, srcPort)
    Packets.put16(b, 22, 53)
    Packets.put16(b, 24, 8 + dns.size)
    System.arraycopy(dns, 0, b, 28, dns.size)
    return b
}

private class SecHarness(
    proto: Proto,
    targets: List<SecureTarget>,
    idleMs: Long = 20_000,
    maxLanes: Int = 4,
    timeoutMs: Int = 1500,
    cacheEntries: Int = 256,
) : AutoCloseable {
    val tun = LinkedBlockingQueue<ByteArray>()
    val logs = CopyOnWriteArrayList<String>()
    val fw = SecureForwarder(
        proto = proto, targets = targets,
        writeToTun = { b, off, len -> tun.add(b.copyOfRange(off, off + len)) },
        tls = TestTls.client, verifier = TestTls.verifier,
        timeoutMs = timeoutMs, connectTimeoutMs = 1500, giveUpMs = 6000, idleMs = idleMs, maxLanes = maxLanes,
        cacheEntries = cacheEntries, log = { logs.add(it) },
    ).also { it.start() }

    fun send(id: Int, name: String = "example.com", port: Int = 40000) { val p = qpacket(id, name, port); fw.onPacket(p, p.size) }
    fun reply(ms: Long = 3000): ByteArray? = tun.poll(ms, TimeUnit.MILLISECONDS)
    override fun close() = fw.close()
}

/** Tünele yazılan cevap doğru mu: başlıklar, istemci kimliği, son A kaydı. Sorun yoksa null. */
private fun checkReply(r: ByteArray, id: Int, ip: ByteArray = byteArrayOf(1, 2, 3, 4), port: Int = 40000): String? {
    if (Packets.checksum(r, 0, 20) != 0) return "IP checksum"
    if (Packets.i32(r, 12) != FIP || Packets.i32(r, 16) != CIP) return "adresler"
    if (Packets.u16(r, 20) != 53 || Packets.u16(r, 22) != port) return "portlar"
    if (Packets.u16(r, 28) != id) return "kimlik ${Packets.u16(r, 28)} != $id"
    for (k in 0 until 4) if (r[r.size - 4 + k] != ip[k]) return "cevap IP"
    return null
}

private fun waitUntil(ms: Long, cond: () -> Boolean): Boolean {
    val end = System.currentTimeMillis() + ms
    while (System.currentTimeMillis() < end) { if (cond()) return true; Thread.sleep(10) }
    return cond()
}

// =================================================================================== testler

fun runSecureTests() {
    println("\nŞifreli DNS ve yeni çekirdek özellikleri\n")
    testDot()
    testDotFailover()
    testDoh()
    testFragments()
    testBlockedAndRecords()
    testBootstrapAndProbe()
    testSecureHardening()
    testEncryptionPlan()
    testNewCodecs()
    testLanguages()
}

private fun testDot() {
    T.group("Şifreli DNS: DoT (yerel TLS sunucusu)")
    FakeTlsDns(doh = false).use { srv ->
        SecHarness(Proto.DOT, listOf(srv.target), idleMs = 400).use { h ->
            h.send(7)
            val r = h.reply()
            T.check("sorgu TLS üzerinden cevaplanır", r != null && checkReply(r, 7) == null, r?.let { checkReply(it, 7) } ?: "cevap yok")
            T.check("protokol DoT", h.fw.proto == Proto.DOT)
            h.send(8)
            val r2 = h.reply()
            T.check("aynı soru önbellekten (sunucuya gitmez)", r2 != null && checkReply(r2, 8) == null && srv.queries.get() == 1 && h.fw.stats().cacheHits == 1L)
            T.check("tek bağlantı yeniden kullanılır", srv.accepted.get() == 1)

            for (i in 0 until 24) h.send(100 + i, "n$i.example.com", 41000 + i)
            var got = 0
            while (got < 24 && h.reply(3000) != null) got++
            T.check("24 eşzamanlı soru cevaplanır", got == 24, "gelen=$got")
            T.check("şerit sayısı sınırı aşılmaz (en çok 4)", srv.accepted.get() <= 5, "bağlantı=${srv.accepted.get()}")
            T.check("boşta kalınca şeritler ve bağlantılar kapanır", waitUntil(3000) { h.fw.laneCount() == 0 && h.fw.openConnections() == 0 },
                "şerit=${h.fw.laneCount()} bağlantı=${h.fw.openConnections()}")
            h.send(9, "after-idle.example.com")
            T.check("boşta kapandıktan sonra yeniden bağlanır", h.reply()?.let { checkReply(it, 9) } == null)
            val st = h.fw.stats()
            T.check("istatistikler tutarlı", st.answered >= 26 && st.queries == st.answered + st.cacheHits && st.timeouts == 0L, st.toString())
        }
    }

    T.group("Şifreli DNS: bayat bağlantı ve ağ değişimi")
    FakeTlsDns(doh = false).use { srv ->
        srv.closeEvery = 1          // sunucu her cevaptan sonra bağlantıyı kapatır (boşta kapatma gibi)
        SecHarness(Proto.DOT, listOf(srv.target)).use { h ->
            var ok = 0
            for (i in 1..5) { h.send(i, "s$i.example.com"); if (h.reply()?.let { checkReply(it, i) } == null) ok++; Thread.sleep(30) }
            T.check("sunucu bağlantıyı kapatsa da sorular cevaplanır", ok == 5, "ok=$ok")
            T.check("bayat bağlantı sunucu hatası sayılmaz (yedeğe geçilmez)", h.fw.stats().failovers == 0L && !h.fw.stats().backup)
        }
        srv.closeEvery = 0
        SecHarness(Proto.DOT, listOf(srv.target)).use { h ->
            val q0 = srv.queries.get()
            h.send(1); h.reply()
            T.check("bağlantı açık", h.fw.openConnections() == 1)
            h.fw.resetNetwork("test")
            T.check("ağ değişince bağlantılar kapanır", h.fw.openConnections() == 0 && h.fw.stats().resets == 1L)
            h.send(2, "x.example.com")
            T.check("ağ değişiminden sonra yeni bağlantıyla çalışır", h.reply()?.let { checkReply(it, 2) } == null)
            h.send(3)                                    // önbellek boşaltıldı: yine sunucuya gider
            h.reply()
            T.check("ağ değişiminde önbellek boşaltılır", srv.queries.get() - q0 == 3, "sorgu=${srv.queries.get() - q0}")
        }
    }

    T.group("Şifreli DNS: sertifika doğrulama")
    FakeTlsDns(doh = false, ks = TestTls.wrong).use { srv ->
        SecHarness(Proto.DOT, listOf(srv.target), timeoutMs = 800).use { h ->
            h.send(5)
            T.check("başka ada ait sertifikalı sunucuya sorgu gönderilmez", h.reply(2500) == null && srv.queries.get() == 0, "sorgu=${srv.queries.get()}")
            T.check("cevap sayılmaz, bağlantı tutulmaz", h.fw.stats().answered == 0L && h.fw.openConnections() == 0)
        }
    }
}

private fun testDotFailover() {
    T.group("Şifreli DNS: yedek sunucuya geçiş")
    FakeTlsDns(doh = false).use { good ->
        good.closeEvery = 1            // her soruda yeni bağlantı gereksin: birincil her seferinde yeniden denenir
        // Birincil: dinlenmeyen bir port (bağlantı reddedilir).
        val dead = java.net.ServerSocket(0, 1, lo).let { val p = it.localPort; it.close(); SecureTarget(InetSocketAddress(lo, p), "dns.test") }
        SecHarness(Proto.DOT, listOf(dead, good.target), maxLanes = 1).use { h ->
            var ok = 0
            for (i in 1..4) { h.send(i, "f$i.example.com"); if (h.reply()?.let { checkReply(it, i) } == null) ok++; Thread.sleep(20) }
            T.check("birincil kapalıyken yedek cevaplar", ok == 4, "ok=$ok")
            T.check("üst üste hatadan sonra kalıcı yedek", h.fw.stats().backup && h.fw.stats().failovers == 1L, h.fw.stats().toString())
            h.fw.resetNetwork("test")
            T.check("ağ değişince yeniden birincille başlar", !h.fw.stats().backup)
        }
    }
}

private fun testDoh() {
    T.group("Şifreli DNS: DoH (HTTP/1.1)")
    FakeTlsDns(doh = true).use { srv ->
        SecHarness(Proto.DOH, listOf(srv.target)).use { h ->
            h.send(4242)
            val r = h.reply()
            T.check("sorgu HTTPS POST ile cevaplanır", r != null && checkReply(r, 4242) == null, r?.let { checkReply(it, 4242) } ?: "cevap yok")
            T.check("istek satırı ve Host doğru", srv.requests.firstOrNull() == "POST /dns-query HTTP/1.1|dns.test", srv.requests.toString())
            T.check("RFC 8484: sorgu kimliği 0 gönderilir, istemciye kendi kimliği döner", srv.zeroIds.get() == 1)
            for (i in 1..3) { h.send(i, "k$i.example.com"); h.reply() }
            T.check("bağlantı açık tutulur (keep-alive)", srv.accepted.get() == 1, "bağlantı=${srv.accepted.get()}")
        }
        srv.chunked = true
        SecHarness(Proto.DOH, listOf(srv.target)).use { h ->
            h.send(77, "chunk.example.com")
            T.check("parçalı (chunked) gövde okunur", h.reply()?.let { checkReply(it, 77) } == null)
        }
        srv.chunked = false
        srv.connClose = true
        SecHarness(Proto.DOH, listOf(srv.target)).use { h ->
            var ok = 0
            for (i in 1..3) { h.send(i, "c$i.example.com"); if (h.reply()?.let { checkReply(it, i) } == null) ok++ }
            T.check("\"Connection: close\" sonrası yeni bağlantıyla devam", ok == 3)
        }
        srv.connClose = false
        srv.status = 500
        SecHarness(Proto.DOH, listOf(srv.target), timeoutMs = 800).use { h ->
            h.send(9)
            T.check("HTTP 500 cevap sayılmaz, tünele bir şey yazılmaz", h.reply(2500) == null && h.fw.stats().answered == 0L)
        }
    }
}

private fun testFragments() {
    T.group("Büyük cevaplar: IP parçalama")
    val dnsLen = 3000
    val out = ByteArray(Packets.HDR + dnsLen)
    for (i in 0 until dnsLen) out[Packets.HDR + i] = (i * 7).toByte()
    val frags = ArrayList<ByteArray>()
    Packets.writeReply(out, ByteArray(Packets.MTU), 0x1234, FIP, CIP, 53, 40000, dnsLen) { b, o, l -> frags.add(b.copyOfRange(o, o + l)) }
    T.check("3000 baytlık cevap 3 parçaya bölünür", frags.size == 3, "n=${frags.size}")
    T.check("her parça MTU'ya sığar ve başlık sağlaması geçerli", frags.all { it.size <= Packets.MTU && Packets.checksum(it, 0, 20) == 0 })
    T.check("kimlik aynı, son parça hariç 'devamı var' bayrağı",
        frags.all { Packets.u16(it, 4) == 0x1234 } && frags.dropLast(1).all { (Packets.u16(it, 6) and 0x2000) != 0 } && (Packets.u16(frags.last(), 6) and 0x2000) == 0)
    val payload = java.io.ByteArrayOutputStream()
    var expectOff = 0
    var offsetsOk = true
    for (f in frags) {
        val off = (Packets.u16(f, 6) and 0x1FFF) * 8
        if (off != expectOff) offsetsOk = false
        payload.write(f, 20, f.size - 20)
        expectOff += f.size - 20
    }
    val p = payload.toByteArray()
    T.check("parça konumları 8'in katı ve ardışık", offsetsOk)
    T.check("birleşince UDP başlığı + veri eksiksiz", p.size == 8 + dnsLen && Packets.u16(p, 4) == 8 + dnsLen &&
        (0 until dnsLen).all { p[8 + it] == (it * 7).toByte() })
    val small = ArrayList<ByteArray>()
    Packets.writeReply(ByteArray(Packets.HDR + 100), ByteArray(Packets.MTU), 1, FIP, CIP, 53, 40000, 100) { b, o, l -> small.add(b.copyOfRange(o, o + l)) }
    T.check("küçük cevap tek paket (DF bayrağıyla)", small.size == 1 && (Packets.u16(small[0], 6) and 0x4000) != 0)

    FakeTlsDns(doh = false).use { srv ->
        SecHarness(Proto.DOT, listOf(srv.target)).use { h ->
            h.send(31, "big.test")
            val parts = ArrayList<ByteArray>()
            while (true) { val r = h.reply(if (parts.isEmpty()) 3000 else 300) ?: break; parts.add(r) }
            val total = parts.sumOf { it.size - 20 }
            val want = 8 + Dns.buildQuery(0, "big.test").size + 16 * 150
            T.check("şifreli DNS'ten gelen 150 kayıtlı cevap parçalarla tünele yazılır", parts.size >= 2 && total == want, "parça=${parts.size} toplam=$total beklenen=$want")
            T.check("parçalı cevapta istemci kimliği korunur", parts.isNotEmpty() && Packets.u16(parts[0], 28) == 31)
        }
    }
}

private fun testBlockedAndRecords() {
    T.group("Engelleme tahmini ve A kayıtları")
    val q = Dns.buildQuery(1, "x.test")
    val normal = answer(q, q.size, listOf(byteArrayOf(1, 2, 3, 4)))
    val zero = answer(q, q.size, listOf(byteArrayOf(0, 0, 0, 0)))
    T.check("normal cevap engel sayılmaz", !Dns.isBlocked(normal, normal.size))
    T.check("0.0.0.0 cevabı engel sayılır", Dns.isBlocked(zero, zero.size))
    // AAAA ::
    val aaaa = q.copyOf(q.size + 28)
    Packets.put16(aaaa, 2, 0x8180); Packets.put16(aaaa, 6, 1)
    var p = q.size
    aaaa[p++] = 0xC0.toByte(); aaaa[p++] = 0x0C
    Packets.put16(aaaa, p, 28); Packets.put16(aaaa, p + 2, 1); Packets.put32(aaaa, p + 4, 60); Packets.put16(aaaa, p + 8, 16)
    T.check(":: (AAAA) cevabı engel sayılır", Dns.isBlocked(aaaa, aaaa.size))
    fun nxWithEde(code: Int?): ByteArray {
        val head = q.copyOf()
        Packets.put16(head, 2, 0x8183)                 // QR, RD, RA, NXDOMAIN
        if (code == null) return head
        Packets.put16(head, 10, 1)                     // ARCOUNT = 1
        val opt = byteArrayOf(
            0,                                          // kök ad
            0, 41,                                      // OPT
            0x04, 0xD0.toByte(),                        // UDP boyutu 1232
            0, 0, 0, 0,                                 // genişletilmiş rcode / sürüm / bayraklar
            0, 6,                                       // RDLEN
            0, 15, 0, 2, 0, code.toByte(),              // seçenek 15 (EDE), uzunluk 2, bilgi kodu
        )
        return head + opt
    }
    val nx = nxWithEde(null)
    T.check("sıradan NXDOMAIN engel sayılmaz", !Dns.isBlocked(nx, nx.size))
    val ede17 = nxWithEde(17)
    T.check("EDE 17 (Filtered) engel sayılır", Dns.isBlocked(ede17, ede17.size))
    val ede6 = nxWithEde(6)
    T.check("başka EDE kodu (6) engel sayılmaz", !Dns.isBlocked(ede6, ede6.size))
    T.check("ofsetli okuma aynı sonucu verir", run { val b = ByteArray(28 + zero.size); System.arraycopy(zero, 0, b, 28, zero.size); Dns.isBlocked(b, 28, zero.size) })
    val rnd = java.util.Random(5)
    var crash = false
    repeat(3000) {
        val b = ByteArray(rnd.nextInt(80)); rnd.nextBytes(b)
        try { Dns.isBlocked(b, b.size); Dns.aRecords(b, b.size); Dns.cacheTtl(b, b.size) } catch (e: Exception) { crash = true }
    }
    T.check("rastgele baytlar çökertmez", !crash)
    val multi = answer(q, q.size, listOf(byteArrayOf(9, 9, 9, 9), byteArrayOf(-107, 112, 112, 112)))
    T.check("A kayıtları okunur", Dns.aRecords(multi, multi.size) == listOf("9.9.9.9", "149.112.112.112"))

    FakeTlsDns(doh = false).use { srv ->
        SecHarness(Proto.DOT, listOf(srv.target)).use { h ->
            h.send(1, "blocked.test"); h.reply()
            h.send(2, "blocked.test"); h.reply()          // önbellekten
            h.send(3, "fine.test"); h.reply()
            T.check("engellenen sayacı (ağdan ve önbellekten)", h.fw.stats().blocked == 2L, h.fw.stats().toString())
        }
    }
}

private fun testBootstrapAndProbe() {
    T.group("İlk çözümleme ve gecikme ölçümü")
    val udp = DatagramSocket(0, lo)
    val got = AtomicInteger()
    Thread {
        val buf = ByteArray(1500)
        val pk = DatagramPacket(buf, buf.size)
        while (!udp.isClosed) {
            try { pk.length = buf.size; udp.receive(pk) } catch (_: Exception) { return@Thread }
            got.incrementAndGet()
            val r = answer(buf, pk.length, listOf(byteArrayOf(5, 6, 7, 8)))
            try { udp.send(DatagramPacket(r, r.size, pk.socketAddress)) } catch (_: Exception) {}
        }
    }.apply { isDaemon = true; start() }
    T.check("bootstrap: sağlayıcının düz DNS'inden A kaydı", Bootstrap.resolveA("dns.test", lo.hostAddress, udp.localPort) == listOf("5.6.7.8"))
    var made = 0
    Bootstrap.resolveA("dns.test", lo.hostAddress, udp.localPort, newSocket = { made++; DatagramSocket() })
    T.check("bootstrap soketi korunan fabrikadan alınır", made == 1)
    val silent = DatagramSocket(0, lo)
    T.check("cevap yoksa boş liste", Bootstrap.resolveA("dns.test", lo.hostAddress, silent.localPort, timeoutMs = 200).isEmpty())
    val pr = DnsProbe.probe(lo.hostAddress, udp.localPort, 800, 3)
    T.check("ölçüm: 3 deneme, kayıp %0", pr.times.size == 3 && pr.lossPct == 0 && pr.best != null && pr.median != null)
    val pr2 = DnsProbe.probe(lo.hostAddress, silent.localPort, 200, 2)
    T.check("cevapsız: kayıp %100, en iyi yok", pr2.lossPct == 100 && pr2.best == null)
    T.check("ortanca ve kayıp hesabı", ProbeResult(listOf(30, 10, 20), 4).median == 20 && ProbeResult(listOf(30, 10, 20), 4).lossPct == 25 &&
        ProbeResult(listOf(5, 9), 2).median == 5)
    udp.close(); silent.close()
    FakeTlsDns(doh = false).use { srv ->
        val r = DnsProbe.probeTls(lo.hostAddress, "dns.test", srv.server.localPort, 1500, 3, TestTls.client, TestTls.verifier)
        T.check("DoT ölçümü: el sıkışmadan sonra 3 soru", r.times.size == 3 && srv.queries.get() == 3, "n=${r.times.size}")
        val bad = DnsProbe.probeTls(lo.hostAddress, "other.test", srv.server.localPort, 1500, 2, TestTls.client, TestTls.verifier)
        T.check("DoT ölçümü: ad uyuşmazsa sorgu yok", bad.times.isEmpty() && srv.queries.get() == 3)
    }
}

/** Pentest bulgularının şifreli yönlendiricideki karşılıkları: yavaş adlar, birleştirme, bozuk HTTP, soru denetimi. */
private fun testSecureHardening() {
    T.group("Şifreli DNS: yavaş adlar diğer soruları kilitlemez")
    FakeTlsDns(doh = false).use { srv ->
        srv.slowMs = 2500
        SecHarness(Proto.DOT, listOf(srv.target), timeoutMs = 900).use { h ->
            h.send(1, "warm.example.com"); h.reply()           // bağlantı kurulsun, hedef "sağlıklı" bilinsin
            for (i in 0 until 4) h.send(10 + i, "slow$i.example.com", 42000 + i)
            Thread.sleep(150)
            val t0 = System.nanoTime()
            for (i in 0 until 5) h.send(20 + i, "fast$i.example.com", 42100 + i)
            val fast = HashSet<Int>()
            val end = System.currentTimeMillis() + 2500
            while (fast.size < 5 && System.currentTimeMillis() < end) {
                val r = h.reply(200) ?: continue
                val id = Packets.u16(r, 28)
                if (id in 20..24) fast.add(id)
            }
            val ms = (System.nanoTime() - t0) / 1_000_000
            T.check("4 yavaş ad şeritleri meşgul ederken 5 normal soru cevaplanır", fast.size == 5, "cevaplanan=${fast.size} süre=${ms}ms")
            T.check("yavaş adlar yedeğe geçişe yol açmaz", h.fw.stats().failovers == 0L && !h.fw.stats().backup, h.fw.stats().toString())
        }
    }

    T.group("Şifreli DNS: özdeş soruların birleşmesi")
    FakeTlsDns(doh = false).use { srv ->
        srv.slowMs = 400
        SecHarness(Proto.DOT, listOf(srv.target), timeoutMs = 1500).use { h ->
            for (i in 0 until 4) h.send(300 + i, "slow-merge.example.com", 43000 + i)
            val got = HashMap<Int, Int>()
            repeat(4) { val r = h.reply(3000) ?: return@repeat; got[Packets.u16(r, 28)] = Packets.u16(r, 22) }
            T.check("4 özdeş soru tek sorguyla cevaplanır", srv.queries.get() == 1 && got.size == 4, "sorgu=${srv.queries.get()} cevap=${got.size}")
            T.check("her istemci kendi kimliği ve portuyla", (0 until 4).all { got[300 + it] == 43000 + it }, got.toString())
            T.check("birleştirme sayacı", h.fw.stats().merged == 3L, h.fw.stats().toString())
        }
    }

    T.group("Şifreli DNS: cevabın sorusu denetlenir")
    FakeTlsDns(doh = false).use { srv ->
        SecHarness(Proto.DOT, listOf(srv.target), timeoutMs = 800).use { h ->
            h.send(5, "wrongq.test")
            T.check("başka bir adın cevabı istemciye iletilmez", h.reply(1500) == null)
            T.check("reddedilen cevap sayılır", h.fw.stats().rejected >= 1L, h.fw.stats().toString())
            h.send(6, "ok.example.com")
            T.check("sonraki doğru cevap iletilir", h.reply()?.let { checkReply(it, 6) } == null)
        }
    }
    FakeTlsDns(doh = true).use { srv ->
        SecHarness(Proto.DOH, listOf(srv.target), timeoutMs = 800).use { h ->
            h.send(7, "wrongq.test")
            T.check("DoH: başka bir adın cevabı iletilmez (kimlik 0 olsa da)", h.reply(1500) == null && h.fw.stats().rejected >= 1L)
        }
    }

    T.group("Şifreli DNS: bozuk HTTP cevapları")
    fun rawCase(what: String, raw: String) {
        FakeTlsDns(doh = true).use { srv ->
            srv.rawHttp = raw.toByteArray(Charsets.ISO_8859_1)
            SecHarness(Proto.DOH, listOf(srv.target), timeoutMs = 700).use { h ->
                var crashed = false
                try { h.send(9, "raw.example.com") } catch (_: Throwable) { crashed = true }
                val r = h.reply(1200)
                T.check(what, !crashed && r == null && h.fw.stats().answered == 0L, h.fw.stats().toString())
            }
        }
    }
    val ct = "HTTP/1.1 200 OK\r\nContent-Type: application/dns-message\r\n"
    rawCase("negatif parça boyu reddedilir", ct + "Transfer-Encoding: chunked\r\n\r\n-1\r\nxx\r\n0\r\n\r\n")
    rawCase("işaretli parça boyu reddedilir", ct + "Transfer-Encoding: chunked\r\n\r\n+20\r\nxx\r\n0\r\n\r\n")
    rawCase("taşan parça boyu reddedilir", ct + "Transfer-Encoding: chunked\r\n\r\n7fffffff\r\nxx\r\n0\r\n\r\n")
    rawCase("negatif Content-Length reddedilir", ct + "Content-Length: -5\r\n\r\n")
    rawCase("çok fazla başlık reddedilir", ct + (1..200).joinToString("") { "X-$it: a\r\n" } + "Content-Length: 0\r\n\r\n")
    rawCase("bozuk durum satırı reddedilir", "HTTP/9 OK\r\nContent-Length: 0\r\n\r\n")

    T.group("Şifreli DNS: damlatan sunucu şeridi tutamaz")
    FakeTlsDns(doh = true).use { srv ->
        srv.trickleMs = 150
        SecHarness(Proto.DOH, listOf(srv.target), timeoutMs = 700).use { h ->
            val t0 = System.nanoTime()
            h.send(11, "trickle.example.com")
            val freed = waitUntil(7000) { h.fw.stats().timeouts >= 1L }
            val ms = (System.nanoTime() - t0) / 1_000_000
            T.check("yavaş damlatılan cevap süre sınırında bırakılır (sonsuza dek beklenmez)", freed, "süre=${ms}ms")
            T.check("damlatılan cevap istemciye iletilmez", h.reply(200) == null && h.fw.stats().answered == 0L)
            T.check("bağlantılar kapanır", waitUntil(3000) { h.fw.openConnections() == 0 })
        }
    }

    T.group("Tünel paketleri: UDP sağlama toplamı")
    FakeTlsDns(doh = false).use { srv ->
        SecHarness(Proto.DOT, listOf(srv.target)).use { h ->
            h.send(12, "sum.example.com")
            val r = h.reply()
            T.check("şifreli cevabın UDP sağlaması geçerli ve sıfır değil",
                r != null && Packets.u16(r, 26) != 0 && Packets.udpChecksumOk(r, 20, r.size - 20, FIP, CIP))
            h.send(13, "big.test")
            val parts = ArrayList<ByteArray>()
            while (true) { val x = h.reply(if (parts.isEmpty()) 3000 else 300) ?: break; parts.add(x) }
            val udp = java.io.ByteArrayOutputStream()
            for (f in parts) udp.write(f, 20, f.size - 20)
            val u = udp.toByteArray()
            T.check("parçalı cevap birleşince UDP sağlaması geçerli", parts.size >= 2 && Packets.udpChecksumOk(u, 0, u.size, FIP, CIP))
            T.check("parçaların IP kimliği aynı", parts.map { Packets.u16(it, 4) }.toSet().size == 1)
        }
    }
}

private fun testEncryptionPlan() {
    T.group("Şifreleme planı ve katalog")
    val cf = Catalog.byId("cloudflare")!!
    val mull = Catalog.byId("mullvad")!!
    val unc = Catalog.byId("uncensored")!!
    val odns = Catalog.byId("opendns")!!
    T.check("Otomatik: DoT, DoH, düz", Encryption.AUTO.plan(cf) == listOf(Proto.DOT, Proto.DOH, Proto.PLAIN))
    T.check("Kapalı: düz", Encryption.OFF.plan(cf) == listOf(Proto.PLAIN))
    T.check("Yalnızca şifreli sunucu (Mullvad) kapalıda da şifreli", Encryption.OFF.plan(mull) == listOf(Proto.DOT, Proto.DOH) &&
        Encryption.AUTO.plan(mull) == listOf(Proto.DOT, Proto.DOH))
    T.check("DoT seçiliyken DoT'suz sunucu (OpenDNS) kullanılamaz", Encryption.DOT.plan(odns).isEmpty() && Encryption.DOH.plan(odns) == listOf(Proto.DOH))
    T.check("DoH seçiliyken DoH'suz sunucu (UncensoredDNS) kullanılamaz", Encryption.DOH.plan(unc).isEmpty())
    T.check("ikincil adrese özel sertifika adı", unc.tlsHost(Proto.DOT, 0) == "anycast.censurfridns.dk" && unc.tlsHost(Proto.DOT, 1) == "unicast.censurfridns.dk")
    T.check("DoH adresinden ad ve yol", DohUrl.host("https://freedns.controld.com/p0") == "freedns.controld.com" &&
        DohUrl.path("https://freedns.controld.com/p0") == "/p0" && DohUrl.path("https://doh.cleanbrowsing.org/doh/family-filter/") == "/doh/family-filter/")
    val all = Catalog.all
    T.check("yalnızca şifreli sunucuların şifreli adresi var", all.filter { !it.plain }.all { it.dot != null || it.doh != null })
    T.check("tüm DoH adresleri https://", all.mapNotNull { it.doh }.all { it.startsWith("https://") && DohUrl.host(it).contains('.') })
    T.check("tüm DoT adları geçerli alan adı", all.mapNotNull { it.dot }.all { it.matches(Regex("[a-z0-9.-]+\\.[a-z]{2,}")) })
    T.check("en az 20 sunucu şifreli DNS destekliyor", all.count { it.encrypted } >= 20, "n=${all.count { it.encrypted }}")
    T.check("artık çalışmayan sunucular katalogda yok", Catalog.byId("verisign") == null && Catalog.byId("alternate") == null)
    T.check("Mullvad sunucuları düz DNS kullanmaz", all.filter { it.brand == "Mullvad" }.all { !it.plain })
}

private fun testNewCodecs() {
    T.group("Yeni ayarlar, dışa/içe aktarma, günlük sayılar")
    val s = AppSettings(
        lang = "de", theme = "coral", themeSchedule = true, textScale = TextScale.LARGE, highContrast = true, minimal = true,
        encryption = Encryption.DOH, autoFastest = true, notifyDrop = false, recent = listOf("google", "quad9"),
        hidden = setOf("opendns"), compact = true, totalBlocked = 77, daily = "20261001=5;20261002=9",
    )
    T.check("yeni alanlar gidiş-dönüş", SettingsCodec.decode(SettingsCodec.encode(s)) == s)
    val bad = SettingsCodec.decode(mapOf("lang" to "xx", "textScale" to "dev", "encryption" to "quic", "recent" to "google,yok,google", "hidden" to "yok"))
    T.check("bozuk yeni alanlar varsayılana düşer", bad.lang == L.AUTO && bad.textScale == TextScale.NORMAL && bad.encryption == Encryption.AUTO &&
        bad.recent == listOf("google") && bad.hidden.isEmpty())
    T.check("son kullanılanlar başa alınır, en çok 5", AppSettings().withRecent("a1").let { var x = it; for (id in listOf("google", "quad9", "adguard", "mullvad", "dnssb", "google")) x = x.withRecent(id); x.recent } ==
        listOf("google", "dnssb", "mullvad", "adguard", "quad9"))

    val code = SettingsCodec.export(s.copy(onboarded = true, wasActive = true, totalQueries = 99))
    T.check("ayar kodu tek satır ve önekli", code.startsWith("DNSH1:") && '\n' !in code)
    val imported = SettingsCodec.import(code, AppSettings())
    T.check("içe aktarma kullanıcı ayarlarını getirir", imported != null && imported.theme == "coral" && imported.encryption == Encryption.DOH &&
        imported.hidden == setOf("opendns") && imported.lang == "de")
    T.check("içe aktarma istatistik/onay/servis alanlarını taşımaz", imported != null && !imported.onboarded && !imported.wasActive &&
        imported.totalQueries == 0L && imported.totalBlocked == 0L && imported.daily == "")
    T.check("geçersiz kodlar reddedilir", SettingsCodec.import("merhaba", AppSettings()) == null && SettingsCodec.import("DNSH1:@@@", AppSettings()) == null &&
        SettingsCodec.import("DNSH1:", AppSettings()) == null)
    val rnd = java.util.Random(3)
    var b64 = true
    repeat(200) { val b = ByteArray(rnd.nextInt(60)); rnd.nextBytes(b)
        val e = Base64Mini.encode(b)
        if (e != java.util.Base64.getEncoder().encodeToString(b) || !Base64Mini.decode(e)!!.contentEquals(b)) b64 = false }
    T.check("Base64: JDK ile aynı, gidiş-dönüş", b64)

    var d = ""
    for (day in 20260920..20260930) d = DailyStats.add(d, day, (day % 100).toLong())
    val m = DailyStats.decode(d)
    T.check("günlük sayılar: yalnızca son 7 gün tutulur", m.size == 7 && m.keys.first() == 20260924 && m[20260930] == 30L)
    T.check("aynı güne ekleme toplanır", DailyStats.decode(DailyStats.add("20261002=4", 20261002, 3))[20261002] == 7L)
    val tz = java.util.TimeZone.getTimeZone("Europe/Istanbul")
    val cal = java.util.Calendar.getInstance(tz).apply { set(2026, 9, 2, 12, 0, 0) }          // 2 Ekim 2026 Cuma
    val week = DailyStats.lastWeek("20261002=10;20260926=3;20260925=99", cal.timeInMillis, tz)
    T.check("haftalık grafik: bugünle biten 7 gün", week.size == 7 && week.last().first == 20261002 && week.first().first == 20260926)
    T.check("haftanın günleri (Pazartesi=0)", week.last().second == 4 && week.first().second == 5)
    T.check("haftalık değerler", week.first().third == 3L && week.last().third == 10L && week.sumOf { it.third } == 13L)
    T.check("bugünün anahtarı", DailyStats.today(cal.timeInMillis, tz) == 20261002)

    var h = emptyMap<String, List<Int?>>()
    repeat(15) { h = LatencyHistory.add(h, "google", if (it % 5 == 4) null else 10 + it) }
    T.check("ölçüm geçmişi en çok 12", h["google"]!!.size == 12)
    T.check("geçmiş kodlama gidiş-dönüş", LatencyHistory.decode(LatencyHistory.encode(h)) == h)
    T.check("ortanca/en iyi/kayıp", LatencyHistory.median(listOf(30, null, 10, 20)) == 20 && LatencyHistory.best(listOf(null, 7, 3)) == 3 &&
        LatencyHistory.lossPct(listOf(1, null, null, 4)) == 50)
    T.check("bilinmeyen sunucu geçmişi atılır", LatencyHistory.decode("yok=1,2;google=3").keys == setOf("google"))
    val lat = mapOf("google" to Latency(12, 5, 33), "quad9" to Latency(null, 6))
    T.check("gecikme kodlama kaybı da taşır", LatencyCodec.decode(LatencyCodec.encode(lat)) == lat)
    T.check("eski biçim (kayıpsız) okunur", LatencyCodec.decode("google=7@9") == mapOf("google" to Latency(7, 9, 0)))
}

private fun testLanguages() {
    T.group("Diller: eksiksiz ve tutarlı")
    val saved = L.lang
    try {
        for (lang in Lang.values()) {
            val t = L.of(lang)
            val probs = ArrayList<String>()
            if (t.lang != lang) probs.add("lang alanı")
            if (t.OPT_BUBBLES.size != BubbleLevel.values().size) probs.add("OPT_BUBBLES")
            if (t.OPT_MOTION.size != Motion.values().size) probs.add("OPT_MOTION")
            if (t.OPT_CACHE.size != CacheLevel.values().size) probs.add("OPT_CACHE")
            if (t.OPT_TEXT.size != TextScale.values().size) probs.add("OPT_TEXT")
            if (t.OPT_ENCRYPTION.size != Encryption.values().size) probs.add("OPT_ENCRYPTION")
            if (t.WEEKDAYS.size != 7) probs.add("WEEKDAYS")
            if (t.CONSENT_BODY.size != 4 || t.HELP_SECTIONS.size < 5) probs.add("uzun metinler")
            for (srv in Catalog.all) {
                val n = t.NOTES[srv.id]
                if (n.isNullOrBlank()) probs.add("not yok: ${srv.id}") else if (n.length > 42) probs.add("not uzun: ${srv.id} (${n.length})")
            }
            for (th in Themes.all) if (t.themeName(th.id) == t.THEME_AUTO || t.themeName(th.id).isBlank()) probs.add("tema adı: ${th.id}")
            if (t.CONSENT_BODY.none { "DoT" in it }) probs.add("onay metni şifrelemeden söz etmiyor")
            if (t.NOTES.keys != Catalog.all.map { it.id }.toSet()) probs.add("fazla not: ${t.NOTES.keys - Catalog.all.map { it.id }.toSet()}")
            T.check("${lang.native}: tüm metinler ve notlar", probs.isEmpty(), probs.take(5).joinToString())
            // Metin işlevleri boş dönmez ve yer tutucuları doldurur
            val f = listOf(t.selected("X"), t.fastest("X", 12), t.switched("X"), t.errNoReply("X"), t.errNoProto("X", "DoT"),
                t.notifOn("X", "DoT"), t.serversCount(3), t.hiddenToast("X"), t.lastMeasure(5, "1"), t.lastMeasure(null, "1"),
                t.measureSummary(1, 2, 3), t.themeA11y("X"), t.favA11y("X"), t.addressA11y("A", "1.1.1.1"), t.pausedUntil("12:00"),
                t.notifPaused("12:00"), t.weekA11y("5"), t.shareAppText("http://u"), t.minutes(15), t.minutes(60))
            T.check("${lang.native}: biçimli metinler", f.all { it.isNotBlank() && !it.contains("\$") } &&
                t.fastest("X", 12).contains("12") && t.minutes(60) != t.minutes(15))
            // 3. sürüm metinleri: sayılar, yer tutucular, seçenek listeleri
            val g = listOf(t.notifDowngrade("X"), t.backupUsed("X", "Y"), t.errNoEncrypted("X"), t.sortA11y("X"), t.recommended("X"),
                t.sessionLine("1 h", "5"), t.importedWith("x"), t.notifOnStats("X", "DoT", "1", "2"), t.widgetToday("3"),
                t.pauseAction(15), t.traffic("1 KB", "2 KB"), t.minutes(30), t.minutes(120))
            val probs3 = ArrayList<String>()
            if (!g.all { it.isNotBlank() && !it.contains("\$") }) probs3.add("boş/eksik yer tutucu")
            if (!t.backupUsed("XA", "YB").let { "XA" in it && "YB" in it }) probs3.add("backupUsed adları")
            if (!t.notifOnStats("XA", "DoT", "11", "22").let { "XA" in it && "11" in it && "22" in it }) probs3.add("notifOnStats")
            if (t.OPT_SORT.size != 3) probs3.add("OPT_SORT")
            if (t.GUARD_BODY.size != 3 || t.BATTERY_BODY.size != 2) probs3.add("rehber paragrafları")
            if (t.WHATS_NEW_ITEMS.size != TxEn.WHATS_NEW_ITEMS.size) probs3.add("WHATS_NEW_ITEMS")
            if (t.HELP_SECTIONS.size != TxEn.HELP_SECTIONS.size) probs3.add("HELP_SECTIONS sayısı")
            if (app.dnshizli.core.EndReason.values().map { t.endReason(it) }.toSet().size != app.dnshizli.core.EndReason.values().size) probs3.add("endReason")
            if (app.dnshizli.core.SensitiveChange.values().any { t.sensitive(it).isBlank() }) probs3.add("sensitive")
            if (t.themeName("dynamic") == t.THEME_AUTO) probs3.add("tema adı: dynamic")
            if (t.byteUnits.size != 4) probs3.add("byteUnits")
            // İngilizce dışındaki dillerde uzun metinler çevrilmiş olmalı (İngilizce yer tutucu kalmasın).
            if (lang != Lang.EN) {
                val same = listOf(
                    "TEST_EXPLAIN" to (t.TEST_EXPLAIN == TxEn.TEST_EXPLAIN), "GUARD_BODY" to (t.GUARD_BODY == TxEn.GUARD_BODY),
                    "BATTERY_BODY" to (t.BATTERY_BODY == TxEn.BATTERY_BODY), "STRICT_ENC_NOTE" to (t.STRICT_ENC_NOTE == TxEn.STRICT_ENC_NOTE),
                    "RECOMMEND_NOTE" to (t.RECOMMEND_NOTE == TxEn.RECOMMEND_NOTE), "WHATS_NEW_ITEMS" to (t.WHATS_NEW_ITEMS == TxEn.WHATS_NEW_ITEMS),
                    "AUTO_RECONNECT_NOTE" to (t.AUTO_RECONNECT_NOTE == TxEn.AUTO_RECONNECT_NOTE), "PRIVATE_DNS_NOTE" to (t.PRIVATE_DNS_NOTE == TxEn.PRIVATE_DNS_NOTE),
                    "HELP_SECTIONS" to (t.HELP_SECTIONS == TxEn.HELP_SECTIONS), "CONSENT_BODY" to (t.CONSENT_BODY == TxEn.CONSENT_BODY),
                    "THEME_SCHEDULE_NOTE" to (t.THEME_SCHEDULE_NOTE == TxEn.THEME_SCHEDULE_NOTE), "APPLYING" to (t.APPLYING == TxEn.APPLYING),
                ).filter { it.second }.map { it.first }
                if (same.isNotEmpty()) probs3.add("çevrilmemiş: " + same.joinToString())
            }
            T.check("${lang.native}: yeni (3. sürüm) metinler", probs3.isEmpty(), probs3.take(6).joinToString())
        }

        T.group("Diller: seçim ve biçimler")
        T.check("otomatik: sistemin ilk desteklenen dili", L.resolve(L.AUTO, listOf("xx", "de", "en")) == Lang.DE)
        T.check("desteklenmeyen sistem dili -> İngilizce", L.resolve(L.AUTO, listOf("ja", "zh")) == Lang.EN)
        T.check("açık seçim sistem dilinin önüne geçer", L.resolve("fr", listOf("de")) == Lang.FR)
        T.check("bölge kodlu sistem dili (pt-BR, tr_TR)", L.resolve(L.AUTO, listOf("pt-BR")) == Lang.PT && Lang.byCode("tr_TR") == Lang.TR)
        T.check("ayar doğrulama", L.isValidSetting("auto") && L.isValidSetting("ru") && !L.isValidSetting("xx") && !L.isValidSetting(null) && !L.isValidSetting("tur"))
        L.set(Lang.EN)
        T.check("İngilizce biçimler", Format.count(1250) == "1.2K" && Format.count(48_000) == "48K" && Format.span(7500) == "2 h 5 min" &&
            Format.ago(10 * 60_000L) == "10 min ago" && TxEn.percent(35) == "35%", "${Format.count(1250)} ${Format.span(7500)} ${Format.ago(600_000)}")
        T.check("İngilizce sunucu adı ve etiket", Catalog.byId("adguard-family")!!.name == "AdGuard Family" && Tag.ADS.label == "Ad-block" &&
            Catalog.byId("quad9-open")!!.note == "No blocking")
        L.set(Lang.DE)
        T.check("Almanca biçimler", Format.count(1250) == "1,2 Tsd." && Format.ago(3 * 3600_000L) == "vor 3 Std." && TxDe.percent(35) == "35 %")
        L.set(Lang.RU)
        T.check("Rusça milisaniye birimi", Format.ms(23) == "23 мс" && TxRu.onLine("X", "DoT", 23) == "X · DoT · 23 мс")
        L.set(Lang.TR)
        T.check("Türkçe biçimler değişmedi", Format.count(1250) == "1,2 bin" && Format.span(200_000) == "2 gün 7 sa" && TxTr.percent(35) == "%35" &&
            Catalog.byId("adguard-family")!!.name == "AdGuard Aile")
        T.check("protokol adları", TxTr.protoName(Proto.DOT) == "DoT" && TxTr.protoName(Proto.PLAIN) == "Düz DNS" && TxEn.protoName(Proto.PLAIN) == "Plain DNS")
        T.check("durum satırı engellenenle", TxTr.statsLine(754, 1250, 38, 25) == "12:34 · 1,2 bin sorgu · %38 önbellek · 25 engellendi" &&
            TxTr.statsLine(754, 1250, 38, 0) == "12:34 · 1,2 bin sorgu · %38 önbellek")
    } finally {
        L.set(saved)
    }
}
