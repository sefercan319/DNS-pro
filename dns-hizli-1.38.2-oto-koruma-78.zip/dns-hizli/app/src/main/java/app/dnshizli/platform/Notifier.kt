package app.dnshizli.platform

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import app.dnshizli.R
import app.dnshizli.core.AppSettings
import app.dnshizli.ui.Strings

/**
 * Bildirimler:
 *  - Durum bildirimi (önplan servisi için zorunlu): bağlıyken sunucu, şifreleme, canlı sayaçlar ve süre (sistem
 *    kronometresi, uygulama her saniye uyanmaz); "Kes", "Sonraki", "15 dk duraklat". Duraklatılmışken geri sayım ve "Devam et".
 *    "Sade bildirim" açıksa en düşük önemdeki kanal (durum çubuğunda simge yok); "Kilit ekranında gizle" açıksa kilit
 *    ekranında sunucu adı yerine yalnızca "DNS koruması açık" görünür.
 *  - Uyarılar: bağlantı beklenmedik koptu (yeniden bağlan), şifreli bağlantı kurulamadı, VPN izni için uygulamayı aç.
 *
 * Tüm düğmeler dışa kapalı [ActionReceiver]'a gider; o da servisi ancak VPN izni varken başlatır.
 */
object Notifier {
    private const val CHANNEL_ID = "status"
    private const val QUIET_CHANNEL_ID = "status_quiet"
    private const val ALERT_CHANNEL_ID = "alerts"
    const val NOTIF_ID = 1
    const val ALERT_ID = 2
    const val DOWNGRADE_ID = 3
    const val NEED_APP_ID = 4
    const val EVENT_ID = 5
    const val TIMEOUT_ID = 6
    const val AUDIT_ID = 7
    const val LINK_ALERT_ID = 8
    private const val EVENT_MS = 8_000L

    /** Kanalları (yoksa) oluşturur; adlarını etkin dile göre günceller. */
    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val ch = NotificationChannel(CHANNEL_ID, Strings.NOTIF_CHANNEL, NotificationManager.IMPORTANCE_LOW)
        ch.description = Strings.NOTIF_CHANNEL_NOTE
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
        val quiet = NotificationChannel(QUIET_CHANNEL_ID, Strings.NOTIF_QUIET_CHANNEL, NotificationManager.IMPORTANCE_MIN)
        quiet.description = Strings.NOTIF_CHANNEL_NOTE
        quiet.setShowBadge(false)
        nm.createNotificationChannel(quiet)
        val alert = NotificationChannel(ALERT_CHANNEL_ID, Strings.NOTIF_ALERT_CHANNEL, NotificationManager.IMPORTANCE_DEFAULT)
        alert.setShowBadge(false)
        nm.createNotificationChannel(alert)
    }

    /** Uygulamayı açan niyet: içeriden (dışa kapalı takma ad) gönderilir; [action] doluysa uygulama onu güvenle işler. */
    fun appIntent(ctx: Context, action: String? = null): Intent =
        Intent().setClassName(ctx, MainActivity.INTERNAL_ALIAS).also { if (action != null) it.action = action }
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)

    private fun openApp(ctx: Context, code: Int = 0, action: String? = null): PendingIntent = PendingIntent.getActivity(
        ctx, code, appIntent(ctx, action), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun act(ctx: Context, code: Int, action: String, minutes: Int = 0): PendingIntent = PendingIntent.getBroadcast(
        ctx, code,
        Intent(ctx, ActionReceiver::class.java).setAction(action).also { if (minutes > 0) it.putExtra(ActionReceiver.EXTRA_MINUTES, minutes) },
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun button(ctx: Context, text: String, pi: PendingIntent): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(ctx, R.drawable.ic_stat_dns), text, pi)
            .setAuthenticationRequired(true)                  // kilit ekranından durdur/duraklat için önce kilit açılır (API 31+)
            .build()

    private fun channel(s: AppSettings) = if (s.quietNotification) QUIET_CHANNEL_ID else CHANNEL_ID

    /** Kilit ekranında gösterilecek genel sürüm (sunucu adı yok). */
    private fun lockVersion(ctx: Context, s: AppSettings, text: String): Notification =
        Notification.Builder(ctx, channel(s))
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.APP)
            .setContentText(text)
            .build()

    private fun privacy(ctx: Context, b: Notification.Builder, s: AppSettings, lockText: String) {
        if (s.hideOnLockscreen) {
            b.setVisibility(Notification.VISIBILITY_PRIVATE)
            b.setPublicVersion(lockVersion(ctx, s, lockText))
        }
    }

    /**
     * Durum bildirimi. [text] ikinci satırdır (ör. "Cloudflare · DoT · 1,2 bin sorgu · 34 engellendi"). [sinceMs] > 0 ise
     * sistem bildirimde bağlantı süresini kendisi sayar. [connected] ise "Kes", "15 dk duraklat" ve (favori/son kullanılan
     * varsa) "Sonraki" eklenir.
     */
    fun build(ctx: Context, s: AppSettings, text: String, connected: Boolean, sinceMs: Long = 0L, canNext: Boolean = false): Notification {
        val b = Notification.Builder(ctx, channel(s))
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.APP)
            .setContentText(text)
            .setContentIntent(openApp(ctx))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
        if (sinceMs > 0L) b.setWhen(sinceMs).setShowWhen(true).setUsesChronometer(true) else b.setShowWhen(false)
        if (connected) {
            b.addAction(button(ctx, Strings.NOTIF_STOP, act(ctx, 1, ActionReceiver.ACTION_STOP)))
            if (canNext) b.addAction(button(ctx, Strings.NOTIF_NEXT, act(ctx, 3, ActionReceiver.ACTION_NEXT)))
            b.addAction(button(ctx, Strings.pauseAction(PAUSE_MIN), act(ctx, 5, ActionReceiver.ACTION_PAUSE, PAUSE_MIN)))
        }
        privacy(ctx, b, s, if (connected) Strings.NOTIF_LOCKED else Strings.NOTIF_CONNECTING)
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }

    /** WireGuard kipi bildirimi: tek eylem "Kes" ([stop] doğrudan WireGuard servisine gider). */
    fun wireGuard(ctx: Context, s: AppSettings, text: String, connected: Boolean, sinceMs: Long, stop: PendingIntent): Notification {
        val b = Notification.Builder(ctx, channel(s))
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.WG_TITLE)
            .setContentText(text)
            .setContentIntent(openApp(ctx))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(button(ctx, Strings.NOTIF_STOP, stop))
        if (sinceMs > 0L) b.setWhen(sinceMs).setShowWhen(true).setUsesChronometer(true) else b.setShowWhen(false)
        privacy(ctx, b, s, if (connected) Strings.NOTIF_LOCKED else Strings.NOTIF_CONNECTING)
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }

    /** Duraklatılmışken gösterilen bildirim: bitiş saati, geri sayım, "Devam et" ve "Kes". */
    fun paused(ctx: Context, s: AppSettings, untilMs: Long, untilText: String): Notification {
        val b = Notification.Builder(ctx, channel(s))
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.APP)
            .setContentText(Strings.notifPaused(untilText))
            .setContentIntent(openApp(ctx))
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setWhen(untilMs).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true)
            .setCategory(Notification.CATEGORY_STATUS)
            .addAction(button(ctx, Strings.RESUME, act(ctx, 4, ActionReceiver.ACTION_RESUME)))
            .addAction(button(ctx, Strings.NOTIF_STOP, act(ctx, 1, ActionReceiver.ACTION_STOP)))
        b.setVisibility(Notification.VISIBILITY_PRIVATE)
        b.setPublicVersion(lockVersion(ctx, s, Strings.APP))
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }

    /** Beklenmedik kopma uyarısı. "Yeniden bağlan" uygulamayı açar (VPN izni geri alınmışsa orada yeniden istenir). */
    fun drop(ctx: Context, reason: String) {
        val n = Notification.Builder(ctx, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.NOTIF_DROP_TITLE)
            .setContentText(reason)
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_ERROR)
            .addAction(button(ctx, Strings.NOTIF_RECONNECT, openApp(ctx, 6, DnsVpnService.ACTION_CONNECT)))
            .build()
        notify(ctx, ALERT_ID, n)
    }

    /** Güvenlik denetimi kritik bulgu bildirimi (sızıntı, sahte DNS cevabı, sertifika uyuşmazlığı…). [text] alan adı/IP içermez. */
    fun audit(ctx: Context, text: String) {
        val n = Notification.Builder(ctx, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.APP)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_STATUS)
            .build()
        notify(ctx, AUDIT_ID, n)
    }

    /** Bağlantı kuruldu: kısa süre sonra kendiliğinden kaybolan sessiz bir bildirim. */
    fun connected(ctx: Context, s: AppSettings, name: String, proto: String) {
        val n = Notification.Builder(ctx, channel(s))
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.NOTIF_CONNECTED_TITLE)
            .setContentText(Strings.notifOn(name, proto))
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .setTimeoutAfter(EVENT_MS)
            .setShowWhen(true)
            .setCategory(Notification.CATEGORY_STATUS)
        privacy(ctx, n, s, Strings.NOTIF_LOCKED)
        notify(ctx, EVENT_ID, n.build())
    }

    /** Bağlantıyı kullanıcı kesti: kısa süre sonra kendiliğinden kaybolan sessiz bir bildirim. */
    fun stopped(ctx: Context, s: AppSettings) {
        val n = Notification.Builder(ctx, channel(s))
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.NOTIF_STOPPED_TITLE)
            .setContentText(Strings.NOTIF_STOPPED_TEXT)
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .setTimeoutAfter(EVENT_MS)
            .setShowWhen(true)
            .setCategory(Notification.CATEGORY_STATUS)
        privacy(ctx, n, s, Strings.NOTIF_STOPPED_TEXT)
        notify(ctx, EVENT_ID, n.build())
    }

    /** DNS sunucusu yanıt vermiyor (zaman aşımı). Bağlantı düzelince ya da kesilince kaldırılır. */
    fun timeout(ctx: Context, name: String) {
        val n = Notification.Builder(ctx, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.NOTIF_TIMEOUT_TITLE)
            .setContentText(Strings.notifTimeout(name))
            .setStyle(Notification.BigTextStyle().bigText(Strings.notifTimeout(name)))
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_STATUS)
            .build()
        notify(ctx, TIMEOUT_ID, n)
    }

    /** "Kapalı kalırsa dur": bağlantı yokken DNS durduruldu; "Kes" ile serbest bırakılır. */
    fun sealed(ctx: Context, s: AppSettings): Notification {
        val b = Notification.Builder(ctx, channel(s))
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.APP)
            .setContentText(Strings.NOTIF_SEALED)
            .setContentIntent(openApp(ctx))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(button(ctx, Strings.NOTIF_STOP, act(ctx, 1, ActionReceiver.ACTION_STOP)))
        privacy(ctx, b, s, Strings.NOTIF_SEALED)
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }

    /** Mesaj bildiriminde tehlikeli bağlantı (bildirim denetimi açıkken). */
    fun linkAlert(ctx: Context, r: app.dnshizli.core.LinkCheck.Result) {
        val body = (r.host ?: r.url) + "\n" + r.findings.take(3).joinToString("\n") { "• " + Strings.linkReason(it.reason.name, it.detail) }
        val n = Notification.Builder(ctx, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.LINK_ALERT_TITLE)
            .setContentText(Strings.LINK_DANGER + ": " + (r.host ?: r.url))
            .setStyle(Notification.BigTextStyle().bigText(Strings.LINK_DANGER + "\n" + body))
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_STATUS)
            .build()
        notify(ctx, LINK_ALERT_ID, n)
    }

    /** Otomatik şifrelemede şifreli yöntem kurulamadı, şifresiz DNS kullanılıyor. */
    fun downgrade(ctx: Context, name: String, odoh: Boolean = false) {
        val title = if (odoh) Strings.NOTIF_ODOH_TITLE else Strings.NOTIF_DOWNGRADE_TITLE
        val body = if (odoh) Strings.notifOdoh(name) else Strings.notifDowngrade(name)
        val n = Notification.Builder(ctx, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_STATUS)
            .build()
        notify(ctx, DOWNGRADE_ID, n)
    }

    /** Bir işlem için VPN izni gerekiyor ama arka planda istenemez: uygulamayı açmaya davet eden bildirim. */
    fun needApp(ctx: Context, text: String = Strings.ERR_PERMISSION) {
        val n = Notification.Builder(ctx, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_dns)
            .setContentTitle(Strings.APP)
            .setContentText(text)
            .setContentIntent(openApp(ctx, 8, DnsVpnService.ACTION_CONNECT))
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_ERROR)
            .build()
        notify(ctx, NEED_APP_ID, n)
    }

    fun update(ctx: Context, n: Notification) = notify(ctx, NOTIF_ID, n)

    private fun notify(ctx: Context, id: Int, n: Notification) {
        try {
            ctx.getSystemService(NotificationManager::class.java)?.notify(id, n)
        } catch (_: Exception) {
            // bildirim izni yoksa sessizce geçilir; servis yine çalışır
        }
    }

    fun cancel(ctx: Context) = cancelId(ctx, NOTIF_ID)
    fun cancelAlert(ctx: Context) = cancelId(ctx, ALERT_ID)
    fun cancelDowngrade(ctx: Context) = cancelId(ctx, DOWNGRADE_ID)
    fun cancelTimeout(ctx: Context) = cancelId(ctx, TIMEOUT_ID)

    private fun cancelId(ctx: Context, id: Int) {
        try { ctx.getSystemService(NotificationManager::class.java)?.cancel(id) } catch (_: Exception) {}
    }

    /** Bildirimdeki duraklatma düğmesinin süresi (dakika). */
    const val PAUSE_MIN = 15
}
