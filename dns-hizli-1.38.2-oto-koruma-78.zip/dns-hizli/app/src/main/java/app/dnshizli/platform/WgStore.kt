package app.dnshizli.platform

import android.content.Context
import app.dnshizli.core.Journal
import app.dnshizli.core.KeyVault
import app.dnshizli.core.WgPath
import app.dnshizli.core.HopPlan
import app.dnshizli.core.Shaper
import java.io.File

/**
 * WireGuard yapılandırması (özel anahtarı içerir): uygulamanın özel klasöründe, Android Keystore AES-GCM anahtarıyla sarılı tek dosya.
 * Sarma yapılamazsa KAYDEDİLMEZ (düz metne düşülmez). Yedeklemeye girmez (files/wg, backup kuralları dışında).
 */
internal object WgStore {
    private object Wrap : AndroidKeystoreWrapper("dnshizli_wg_cfg_wrap")
    private fun file(ctx: Context) = File(File(ctx.noBackupFilesDir, "wg").also { it.mkdirs() }, "wg0.conf.sealed")

    @Synchronized fun save(ctx: Context, text: String): Boolean {
        clearPq(ctx)                                             // yeni yapılandırma: eski kuantum sonrası PSK geçersiz
        val blob = KeyVault.sealStrict(text.toByteArray(Charsets.UTF_8), Wrap) ?: return false
        val f = file(ctx)
        val tmp = File(f.parentFile, f.name + ".tmp")
        return try { tmp.writeBytes(blob); tmp.renameTo(f) || run { f.writeBytes(blob); tmp.delete(); true } }
        catch (e: Exception) { Journal.add("WireGuard yapılandırması yazılamadı: ${e.javaClass.simpleName}"); tmp.delete(); false }
    }

    @Synchronized fun load(ctx: Context): String? {
        val f = file(ctx)
        if (!f.exists()) return null
        val plain = try { KeyVault.openStrict(f.readBytes(), Wrap) } catch (_: Exception) { null } ?: return null
        return String(plain, Charsets.UTF_8).also { plain.fill(0) }
    }

    // ---- kuantum sonrası PSK (son başarılı değişimin sonucu; sunucu da bunu kullanır). İstemci ortak anahtarına bağlı saklanır.
    private fun pqFile(ctx: Context) = File(File(ctx.noBackupFilesDir, "wg").also { it.mkdirs() }, "pq.sealed")

    @Synchronized fun savePq(ctx: Context, clientPub: ByteArray, psk: ByteArray) {
        val blob = KeyVault.sealStrict(clientPub + psk, Wrap) ?: return
        try { pqFile(ctx).writeBytes(blob) } catch (_: Exception) {}
    }

    @Synchronized fun loadPq(ctx: Context, clientPub: ByteArray): ByteArray? {
        val f = pqFile(ctx)
        if (!f.exists()) return null
        val b = try { KeyVault.openStrict(f.readBytes(), Wrap) } catch (_: Exception) { null } ?: return null
        if (b.size != 64 || !b.copyOfRange(0, 32).contentEquals(clientPub)) return null
        return b.copyOfRange(32, 64)
    }

    @Synchronized fun clearPq(ctx: Context) { val f = pqFile(ctx); if (f.exists()) { try { f.writeBytes(ByteArray(f.length().toInt())) } catch (_: Exception) {}; f.delete() } }

    // ---- çoklu atlama: giriş sunucusu yapılandırması (ayrı dosya, aynı sıkı sarma) ve kip
    private fun entryFile(ctx: Context) = File(File(ctx.noBackupFilesDir, "wg").also { it.mkdirs() }, "giris.conf.sealed")

    @Synchronized fun saveEntry(ctx: Context, text: String): Boolean {
        val blob = KeyVault.sealStrict(text.toByteArray(Charsets.UTF_8), Wrap) ?: return false
        return try { entryFile(ctx).writeBytes(blob); true } catch (_: Exception) { false }
    }

    @Synchronized fun loadEntry(ctx: Context): String? {
        val f = entryFile(ctx)
        if (!f.exists()) return null
        val plain = try { KeyVault.openStrict(f.readBytes(), Wrap) } catch (_: Exception) { null } ?: return null
        return String(plain, Charsets.UTF_8).also { plain.fill(0) }
    }

    @Synchronized fun deleteEntry(ctx: Context) { val f = entryFile(ctx); if (f.exists()) { try { f.writeBytes(ByteArray(f.length().toInt())) } catch (_: Exception) {}; f.delete() } }

    fun shapeLevel(ctx: Context): Shaper.Level = Shaper.Level.of(ctx.getSharedPreferences("wg", Context.MODE_PRIVATE).getString("gizleme", null))
    fun setShapeLevel(ctx: Context, l: Shaper.Level) { ctx.getSharedPreferences("wg", Context.MODE_PRIVATE).edit().putString("gizleme", l.id).apply() }

    fun hopMode(ctx: Context): HopPlan.Mode = HopPlan.Mode.of(ctx.getSharedPreferences("wg", Context.MODE_PRIVATE).getString("atlama", null))
    fun setHopMode(ctx: Context, m: HopPlan.Mode) { ctx.getSharedPreferences("wg", Context.MODE_PRIVATE).edit().putString("atlama", m.id).apply() }

    /** Bağlantı yolu kipi (Otomatik / UDP / Stealth); sır değildir, düz tercih dosyasında. */
    fun mode(ctx: Context): WgPath.Mode = WgPath.Mode.of(ctx.getSharedPreferences("wg", Context.MODE_PRIVATE).getString("yol", null))
    fun setMode(ctx: Context, m: WgPath.Mode) { ctx.getSharedPreferences("wg", Context.MODE_PRIVATE).edit().putString("yol", m.id).apply() }

    @Synchronized fun delete(ctx: Context) {
        clearPq(ctx)
        val f = file(ctx)
        if (f.exists()) { try { f.writeBytes(ByteArray(f.length().toInt())) } catch (_: Exception) {}; f.delete() }
    }
}
