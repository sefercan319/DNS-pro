package app.dnshizli.core

import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Sunucu küresinin kara noktaları. Fibonacci küresi üzerindeki [N] eşit aralıklı noktadan karada olanlar bit kümesiyle gömülüdür
 * (tools/kure/kara.py; kaynak: GLOBE/NOAA 1 km kara maskesi, kamu malı). Noktalar ilk kullanımda üretilir ve önbelleğe alınır.
 */
object GlobeLand {
    const val N = 9000
    private const val BITS = "AABACAgLISMhLIWEhJA3EnNCpkrIkZkZIAdi7sjevpl5efdt7v3dv7/39v/+zt/ff3v/f+3t/P+9v//3Vv7+ytv5eyt79++t/L21k/N3Vv7Oy0u5Oys75+b03JyRn3N3cnbO3O25OTk/5+b33JyV23Nzen5Oze27OT035+b03Jyem3Nzem5Oze25OT0np+b23Jyam/Nzek5Ozcm5GT03p+b03Jyak3Nzam5Ozeg5GT2n52bUnJya0TMyck5Pzak5OTGn5uTknJyaU3NyckdNyKk5OTGnZuTknJ6SUzNiakZNyek5OTWnZ8TUjJyQ0zNiakZPyOgZMSWjZ8TUjJ6SUXNiSkZNyKk5NSWnJsSUnJqSU3NqSk5NiSk5NSWnpsSUnJqSU3NKSk5JiSk5JSWnpJSUnJISU3NKSk5BqSkpJSWnpJSUnJJSU3BKCk5JKSk4JaWnppRUnJJSU1NKCkxNKSkoNaWmppRUmZJSU0FqCgwJKakgNYWCpJRUGZJSU0FqKg9JqSkgJYWGgtQUEJJSU0BKCg8BqSkgNKWGgNQUFoJSQkBoCgsBqSkgFKWEgFAUFoJSQkAoCgsBKagoBKWEgJAUFgJSUkEoKgkBIaEgBLSEgtBQFgpSUkEoKAsFIaEoFLSEohBQFgpSUkEIKAkFIaAoBJSEohBQFgpaUlEAKElFJaAgFJSEogBQEIoKUEEAKEhFBaAgEBWgggBQFIoKUEEgKkBFBaAoFBWgokBUAIoKQEEgKkZFBaAoFBWgokJUhAqKUFEpKkJFxaCIFBWhgmJUBI6KQBEhKkJFxaCAFBShAmJQQIqKQAExKAAFxaiAHBShAmJQQAqKUAEhKAAFxaiAFBSBI2JUQAqKQAEpKABFhKCAFBWAAmJQAIoKQQEpKAAFhKAIFBSBAkJQAAoKQREoKAAFhKBoFBSBIlJQAIoKQVEoKAJFpKAIFBWBolBQAIoMwFEoKgJFpaAIVBmBolBQBIoKQBEoIgJFIagIFBGBolBEFIoKUBEoIgJHoagIFBWhIlBEBIqCUBEoIkJFoKgIFAWhIlBEBIrCUREoAkJFoIgIFAWhIlAEBIrAEREoAkJFoAgIFAEjIlAEhIrAEREoAkJFoAgIFAEjIlAEhIpAERAoAkZEoAgIFAEiIFAEhIhAERAoAEZAoAAIEQAiIFAAjIBAARAgAARCgAAIAAACIUAACAAAARAAAARAgAAYAAACAUAACAAAAQAAAAQCAAAQAAACIAAACAQAADAAAAQAAAAQCAAAIAAACAAAACAQAAQAAAAQAAAAQCAACAAAACAAAAAAAAAQAAAAQAAAAAAAACAAAACAAAAAAAACQAAAAAAAACAAAACAAAAQAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQACAgRISUgBISUiJKSkjJKSk9paW19JyW1tNzenrPz/n5Pb/v5//9vt//8/t/f///////"

    /** Kara noktalarının enlemi ve boylamı (radyan) ile önceden hesaplanmış sin/cos(enlem). */
    class Points(val lat: FloatArray, val lon: FloatArray, val sinLat: FloatArray, val cosLat: FloatArray) { val size get() = lat.size }

    val points: Points by lazy {
        val bits = java.util.Base64.getDecoder().decode(BITS)
        val golden = Math.PI * (3 - sqrt(5.0))
        val la = ArrayList<Float>(3200); val lo = ArrayList<Float>(3200)
        for (i in 0 until N) {
            if ((bits[i ushr 3].toInt() ushr (i and 7)) and 1 == 0) continue
            val y = 1 - (i + 0.5) * 2 / N
            la.add(asin(y).toFloat())
            lo.add(((i * golden) % (2 * Math.PI) - Math.PI).toFloat())
        }
        val lat = la.toFloatArray(); val lon = lo.toFloatArray()
        Points(lat, lon, FloatArray(lat.size) { sin(lat[it]) }, FloatArray(lat.size) { cos(lat[it]) })
    }

    /** Test/araç: [i]. Fibonacci noktası karada mı? */
    fun isLandIndex(i: Int): Boolean { val bits = java.util.Base64.getDecoder().decode(BITS); return (bits[i ushr 3].toInt() ushr (i and 7)) and 1 == 1 }
}
