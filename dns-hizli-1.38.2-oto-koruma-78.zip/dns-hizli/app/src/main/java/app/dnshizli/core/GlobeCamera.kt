package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

/**
 * Küre kamerası ve dik izdüşüm (orthographic). Saf matematik: arayüzden bağımsız sınanır.
 *  - [lon0]/[lat0]: ekran merkezindeki nokta (radyan); [zoom] 1..[MAX_ZOOM].
 *  - Sürükleme küreyi parmakla birlikte döndürür, bırakınca atalet sürer; boşta yavaşça kendiliğinden döner (hareket açıksa).
 */
class GlobeCamera(var lon0: Double = Math.toRadians(30.0), var lat0: Double = Math.toRadians(30.0), var zoom: Double = 1.0) {
    private var vLon = 0.0
    private var vLat = 0.0
    private var idle = 0.0
    var dragging = false; private set

    /** İzdüşüm sonucu: ekran x, y (merkezli, yarıçap 1) ve derinlik z (> 0 görünür yüz). */
    class P { var x = 0.0; var y = 0.0; var z = 0.0 }

    fun project(lat: Double, lon: Double, out: P): P {
        val sl = sin(lat); val cl = cos(lat)
        return projectSc(sl, cl, lon, out)
    }

    fun projectSc(sinLat: Double, cosLat: Double, lon: Double, out: P): P {
        val d = lon - lon0
        val cd = cos(d)
        val s0 = sin(lat0); val c0 = cos(lat0)
        out.x = cosLat * sin(d)
        out.y = c0 * sinLat - s0 * cosLat * cd
        out.z = s0 * sinLat + c0 * cosLat * cd
        return out
    }

    fun beginDrag() { dragging = true; vLon = 0.0; vLat = 0.0; idle = 0.0 }

    /** Ekran pikseli (dp) cinsinden sürükleme; [r] kürenin ekrandaki yarıçapı. [dtSec] hız tahmini için. */
    fun dragBy(dx: Double, dy: Double, r: Double, dtSec: Double) {
        val dl = -dx / r; val dp = dy / r
        lon0 = wrap(lon0 + dl)
        lat0 = (lat0 + dp).coerceIn(-MAX_TILT, MAX_TILT)
        if (dtSec > 0.0) { vLon = 0.7 * vLon + 0.3 * (dl / dtSec); vLat = 0.7 * vLat + 0.3 * (dp / dtSec) }
    }

    fun endDrag() { dragging = false; idle = 0.0 }

    fun zoomBy(f: Double) { zoom = (zoom * f).coerceIn(1.0, MAX_ZOOM); idle = 0.0 }

    /** Çift dokunma: 1 → 2 → 4 → 1. */
    fun zoomStep() { zoom = when { zoom < 1.9 -> 2.0; zoom < 3.9 -> 4.0; else -> 1.0 }; idle = 0.0 }

    /** [lat]/[lon]'u merkeze getirir (seçilen sunucu). */
    fun focus(lat: Double, lon: Double) { lon0 = wrap(lon); lat0 = lat.coerceIn(-MAX_TILT, MAX_TILT); vLon = 0.0; vLat = 0.0; idle = 0.0 }

    /** Atalet ve boşta dönme. Hareket sürüyorsa true. */
    fun tick(dt: Double, autoSpin: Boolean): Boolean {
        if (dragging) return true
        var moving = false
        if (abs(vLon) > 1e-3 || abs(vLat) > 1e-3) {
            lon0 = wrap(lon0 + vLon * dt); lat0 = (lat0 + vLat * dt).coerceIn(-MAX_TILT, MAX_TILT)
            val k = exp(-dt * 3.0); vLon *= k; vLat *= k
            moving = true; idle = 0.0
        } else { vLon = 0.0; vLat = 0.0; idle += dt }
        if (autoSpin && idle > IDLE_SPIN_AFTER && zoom < 1.5) { lon0 = wrap(lon0 - SPIN * dt); moving = true }
        return moving
    }

    /** Görünür noktalardan ekran konumu (merkez cx, cy; yarıçap r) [x],[y]'ye en yakın olanın sırası; [maxDist] içinde yoksa -1. */
    fun pick(x: Double, y: Double, cx: Double, cy: Double, r: Double, lats: DoubleArray, lons: DoubleArray, maxDist: Double): Int {
        val p = P(); var best = -1; var bd = maxDist * maxDist
        for (i in lats.indices) {
            project(Math.toRadians(lats[i]), Math.toRadians(lons[i]), p)
            if (p.z <= 0.05) continue
            val dx = cx + r * p.x - x; val dy = cy - r * p.y - y
            val d = dx * dx + dy * dy
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    companion object {
        const val MAX_ZOOM = 5.0
        val MAX_TILT = Math.toRadians(75.0)
        const val SPIN = 0.06                // rad/sn
        const val IDLE_SPIN_AFTER = 4.0      // sn
        fun wrap(a: Double): Double { var v = a % (2 * PI); if (v > PI) v -= 2 * PI; if (v < -PI) v += 2 * PI; return v }
    }
}
