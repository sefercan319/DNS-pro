package app.dnshizli.ui

import app.dnshizli.core.ALIGN_CENTER
import app.dnshizli.core.Catalog
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Gfx
import app.dnshizli.core.GlobeCamera
import app.dnshizli.core.GlobeLand
import app.dnshizli.core.GlobeSites
import app.dnshizli.core.Rgb
import kotlin.math.sqrt

/**
 * Sunucu küresi: sürükleyerek döndür, iki parmakla (ya da çift dokunarak) yakınlaştır, noktaya dokununca o sağlayıcının
 * sunucuları altta listelenir; listeden dokununca bağlanır. Anycast sağlayıcılar merkezlerinde halka ile, tek konumlular dolu nokta ile.
 */
class GlobePage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.GLOBE, true, nav) {
    private val globe = GlobeNode(model) { onPick(it) }
    private val hint = Label(Strings.GLOBE_HINT, 13f, ink = Ink.SOFT, align = ALIGN_CENTER, maxLines = 2)
    private val title = Label("", 18f, bold = true, maxLines = 1, shrink = true)
    private val place = Label("", 13f, ink = Ink.SOFT, maxLines = 2)
    private val rows = Column(gap = M.ROW_GAP)
    private val unknownHead = Label(Strings.GLOBE_UNKNOWN, 15f, bold = true)
    private val unknown = Column(gap = M.ROW_GAP)
    private val rowCache = HashMap<String, ServerRow>()
    private var seen = -1
    private var picked: String? = null

    init {
        col.add(globe)
        col.add(hint)
        col.add(title)
        col.add(place)
        col.add(rows)
        col.add(unknownHead)
        col.add(unknown)
        finish()
        // Başlangıçta bağlı/seçili sunucunun markası seçili gelir.
        Catalog.byId(model.selectedId())?.let { s -> if (GlobeSites.of(s) != null) picked = s.brand }
        picked?.let { b -> GlobeSites.siteOfBrand(b)?.let { globe.camera.focus(Math.toRadians(it.lat), Math.toRadians(it.lon)) } }
    }

    private fun row(s: DnsServer) = rowCache.getOrPut(s.id) { ServerRow(s) { nav.openDetails(it) } }

    private fun onPick(brand: String?) { picked = brand; seen = -1 }

    val selectedBrand: String? get() = picked

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version || globe.selected != picked) {
            seen = model.version
            globe.selected = picked
            val visible = model.visibleServers()
            rows.removeAll()
            val b = picked
            if (b != null) {
                val site = GlobeSites.siteOfBrand(b)
                title.text = b
                place.text = site?.let { Strings.globePlace(it.place) + " · " + (if (it.anycast) Strings.GLOBE_ANYCAST else Strings.GLOBE_UNICAST) } ?: ""
                for (s in visible) if (s.brand == b && GlobeSites.of(s) != null) rows.add(row(s))
            } else { title.text = Strings.GLOBE_PICK; place.text = "" }
            unknown.removeAll()
            for (s in visible) if (GlobeSites.of(s) == null) unknown.add(row(s))
            unknownHead.visible = unknown.children.isNotEmpty()
            relayoutContent(env)
        }
        return super.tick(dt, env)
    }
}

class GlobeNode(private val model: AppModel, private val onPick: (String?) -> Unit) : Node(), Pinchable {
    val camera = GlobeCamera()
    var selected: String? = null
    private val p = GlobeCamera.P()
    private var lastX = 0f; private var lastY = 0f; private var lastT = 0f
    private var downX = 0f; private var downY = 0f
    private var active = false
    private var lastTapAt = -10f
    private var clock = 0f
    private var brands: List<String> = emptyList()
    private var lats = DoubleArray(0); private var lons = DoubleArray(0)
    private var brandsVersion = -1

    override val dragCapture: Boolean get() = true
    override val dragActive: Boolean get() = active
    override val dragAll: Boolean get() = true
    override val tappable: Boolean get() = true

    private val cx get() = w / 2f
    private val cy get() = h / 2f
    /** Kürenin ekrandaki yarıçapı (yakınlaştırmayla büyür; görünüm dışına taşan kısım kırpılır). */
    val radius: Float get() = (minOf(w, h) / 2f - 10f) * camera.zoom.toFloat()

    override fun layout(env: Env, maxW: Float) { w = maxW; h = minOf(maxW, 420f) }

    private fun syncBrands() {
        if (brandsVersion == model.version) return
        brandsVersion = model.version
        brands = GlobeSites.brands(model.visibleServers())
        lats = DoubleArray(brands.size) { GlobeSites.siteOfBrand(brands[it])!!.lat }
        lons = DoubleArray(brands.size) { GlobeSites.siteOfBrand(brands[it])!!.lon }
    }

    /** Noktanın ekran konumu (yerel dp); arka yüzdeyse null. Test ve dokunma için. */
    fun screenOf(brand: String): Pair<Float, Float>? {
        val s = GlobeSites.siteOfBrand(brand) ?: return null
        camera.project(Math.toRadians(s.lat), Math.toRadians(s.lon), p)
        if (p.z <= 0.05) return null
        return (cx + radius * p.x.toFloat()) to (cy - radius * p.y.toFloat())
    }

    override fun tick(dt: Float, env: Env): Boolean {
        clock += dt
        val moving = camera.tick(dt.toDouble(), env.ambient && env.motion > 0f)
        return moving || active
    }

    override fun ambient(env: Env): Boolean = env.ambient && env.motion > 0f

    override fun onDown(lx: Float, ly: Float, env: Env) {
        active = true
        downX = lx; downY = ly; lastX = lx; lastY = ly; lastT = clock
        camera.beginDrag()
    }

    override fun onDrag(lx: Float, ly: Float, env: Env) {
        val dt = (clock - lastT).toDouble()
        camera.dragBy((lx - lastX).toDouble(), (ly - lastY).toDouble(), radius.toDouble(), if (dt > 0) dt else 1.0 / 60)
        lastX = lx; lastY = ly; lastT = clock
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        active = false
        camera.endDrag()
        val moved = (lx - downX) * (lx - downX) + (ly - downY) * (ly - downY) > 100f
        if (!tap || moved) return
        // Çift dokunma: yakınlaştır
        if (clock - lastTapAt < 0.3f) { camera.zoomStep(); lastTapAt = -10f; return }
        lastTapAt = clock
        syncBrands()
        val i = camera.pick(lx.toDouble(), ly.toDouble(), cx.toDouble(), cy.toDouble(), radius.toDouble(), lats, lons, 28.0)
        if (i >= 0) { env.tap(); onPick(brands[i]) }
    }

    override fun onCancel(env: Env) { active = false; camera.endDrag() }

    override fun onPinch(f: Float, cx: Float, cy: Float, env: Env) { camera.zoomBy(f.toDouble()) }

    override fun draw(g: Gfx, env: Env) {
        syncBrands()
        val r = radius
        val dark = env.theme.dark
        g.save()
        g.clipRect(0f, 0f, w, h)
        // okyanus + hale
        g.paint(Rgb.alpha(env.theme.link, 0.10f)); g.circle(cx, cy, r + 6f)
        g.paint(if (dark) 0xFF0B2240.toInt() else 0xFF1D4E7E.toInt()); g.circle(cx, cy, r)
        // yumuşak ışık: sol üstte, iç içe sönen halkalar (tek renk sınırı görünmez)
        for (k in 1..6) { g.paint(Rgb.alpha(0xFFFFFFFF.toInt(), 0.022f)); g.circle(cx - r * 0.28f, cy - r * 0.3f, r * (0.72f - k * 0.1f)) }
        // kara noktaları: kenara doğru söner (kenar kararması)
        val pts = GlobeLand.points
        val spacing = (sqrt(4 * Math.PI / GlobeLand.N) * r).toFloat()
        val dot = (spacing * 0.32f).coerceIn(0.7f, 4f)
        var i = 0
        while (i < pts.size) {
            camera.projectSc(pts.sinLat[i].toDouble(), pts.cosLat[i].toDouble(), pts.lon[i].toDouble(), p)
            if (p.z > 0) {
                val x = cx + r * p.x.toFloat(); val y = cy - r * p.y.toFloat()
                if (x > -dot && x < w + dot && y > -dot && y < h + dot) {
                    val a = (0.35f + 0.65f * p.z.toFloat())
                    g.paint(Rgb.alpha(0xFFE8F4FF.toInt(), a)); g.circle(x, y, dot)
                }
            }
            i++
        }
        g.strokeWidth(1.5f); g.paint(Rgb.alpha(0xFFFFFFFF.toInt(), 0.35f)); g.strokeCircle(cx, cy, r)
        // sunucu noktaları
        val connected = Catalog.byId(model.selectedId())?.brand
        val on = model.vpn.active
        for (k in brands.indices) {
            camera.project(Math.toRadians(lats[k]), Math.toRadians(lons[k]), p)
            if (p.z <= 0.05) continue
            val x = cx + r * p.x.toFloat(); val y = cy - r * p.y.toFloat()
            val b = brands[k]
            val anycast = GlobeSites.siteOfBrand(b)!!.anycast
            val sel = b == selected
            val live = on && b == connected
            val col = if (live) 0xFF3DDC84.toInt() else if (sel) env.theme.link else 0xFFFFD166.toInt()
            val rr = if (sel) 8f else 5.5f
            if (live) { val pulse = (clock % 1.6f) / 1.6f; g.paint(Rgb.alpha(col, 0.5f * (1 - pulse))); g.circle(x, y, rr + 14f * pulse) }
            g.paint(Rgb.alpha(0xFF000000.toInt(), 0.35f)); g.circle(x, y + 1f, rr + 1.5f)
            if (anycast) { g.strokeWidth(2.4f); g.paint(col); g.strokeCircle(x, y, rr); g.circle(x, y, rr * 0.38f) }
            else { g.paint(col); g.circle(x, y, rr) }
            if (sel || live) {
                val fs = env.sz(12f)
                val tw = env.metrics.textWidth(b, fs, true)
                g.paint(Rgb.alpha(0xFF000000.toInt(), 0.55f)); g.roundRect(x - tw / 2 - 6f, y - rr - fs - 10f, x + tw / 2 + 6f, y - rr - 3f, 6f)
                g.paint(Rgb.WHITE); g.text(b, x, y - rr - 7f, fs, true, ALIGN_CENTER)
            }
        }
        g.restore()
    }

    override fun a11y(): A11y = A11y(Strings.GLOBE + ": " + (selected ?: Strings.GLOBE_PICK), Role.TEXT)
}
