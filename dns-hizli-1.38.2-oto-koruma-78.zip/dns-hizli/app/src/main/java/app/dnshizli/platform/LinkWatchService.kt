package app.dnshizli.platform

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.provider.Telephony
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.FilterVerdict
import app.dnshizli.core.LinkCheck

/**
 * Dolandırıcılık mesajı koruması (isteğe bağlı): kullanıcı bildirim erişimi verip ayarı açtıysa, mesajlaşma uygulamalarının
 * bildirimlerindeki bağlantılar cihazda denetlenir; TEHLİKELİ olan varsa uyarı bildirimi gösterilir. Bildirim metni saklanmaz,
 * hiçbir yere gönderilmez; yalnızca mesaj bildirimlerine bakılır (kategori "mesaj", varsayılan SMS uygulaması ya da bilinen mesajlaşma
 * uygulamaları). Aynı alan için 10 dk içinde tekrar uyarılmaz.
 */
class LinkWatchService : NotificationListenerService() {
    private val warned = LinkedHashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn ?: return
        if (!enabled(this) || n.packageName == packageName) return
        val x = n.notification ?: return
        if (!isMessage(n.packageName, x)) return
        val e = x.extras ?: return
        val text = buildString {
            e.getCharSequence(Notification.EXTRA_TEXT)?.let { append(it).append('\n') }
            e.getCharSequence(Notification.EXTRA_BIG_TEXT)?.let { append(it).append('\n') }
            e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.forEach { append(it).append('\n') }
        }
        if (text.isBlank()) return
        val urls = LinkCheck.extract(text, 5)
        if (urls.isEmpty()) return
        val eng = FilterRuntime.engine?.fork()
        val now = System.currentTimeMillis()
        for (u in urls) {
            val r = LinkCheck.check(u) { h -> eng?.verdictOf(h) ?: -1 }
            if (r.level != LinkCheck.Level.DANGER) continue
            val key = r.registrable ?: r.host ?: u
            synchronized(warned) {
                if ((warned[key] ?: 0L) > now - 600_000L) return
                warned[key] = now
                if (warned.size > 64) warned.remove(warned.keys.first())
            }
            Notifier.linkAlert(this, r)
            return
        }
    }

    private fun isMessage(pkg: String, n: Notification): Boolean {
        if (n.category == Notification.CATEGORY_MESSAGE) return true
        if (pkg in MESSENGERS) return true
        return try { pkg == Telephony.Sms.getDefaultSmsPackage(this) } catch (_: Exception) { false }
    }

    companion object {
        private val MESSENGERS = setOf(
            "com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms", "com.whatsapp", "com.whatsapp.w4b",
            "org.telegram.messenger", "org.thoughtcrime.securesms", "com.facebook.orca", "com.viber.voip",
        )
        private fun prefs(ctx: Context) = ctx.getSharedPreferences("linkwatch", Context.MODE_PRIVATE)
        fun enabled(ctx: Context): Boolean = prefs(ctx).getBoolean("on", false)
        fun setEnabled(ctx: Context, on: Boolean) { prefs(ctx).edit().putBoolean("on", on).apply() }
        fun component(ctx: Context) = ComponentName(ctx, LinkWatchService::class.java)
        fun hasAccess(ctx: Context): Boolean = try {
            ctx.getSystemService(android.app.NotificationManager::class.java)?.isNotificationListenerAccessGranted(component(ctx)) == true
        } catch (_: Exception) { false }
    }
}
