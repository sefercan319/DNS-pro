#!/usr/bin/env python3
"""Sunucu küresinin kara noktaları: Fibonacci küresi üzerindeki N noktadan karada olanların bit kümesi (base64).

Kaynak: global-land-mask (pip; GLOBE/NOAA 1 km kara maskesi, kamu malı veri). Çıktı app/.../core/GlobeLand.kt içine gömülür.
Kotlin aynı formülle noktaları üretir: y = 1 - (i + 0.5) * 2 / N, boylam = (i * altın_açı) mod 2π - π.
Kıyıda kaba çözünürlük kaybı olmasın diye nokta merkezi ve çevresindeki 4 yakın örnekten biri karadaysa nokta kara sayılır.
Kullanım: python3 tools/kure/kara.py > /tmp/kara.txt
"""
import base64, math
from global_land_mask import globe

N = 9000
GOLDEN = math.pi * (3 - math.sqrt(5))
step = math.degrees(math.sqrt(4 * math.pi / N)) * 0.35  # nokta aralığının ~üçte biri

bits = bytearray((N + 7) // 8)
land = 0
for i in range(N):
    y = 1 - (i + 0.5) * 2 / N
    lat = math.degrees(math.asin(y))
    lon = math.degrees((i * GOLDEN) % (2 * math.pi) - math.pi)
    hit = False
    for dlat, dlon in ((0, 0), (step, 0), (-step, 0), (0, step), (0, -step)):
        la = max(-89.99, min(89.99, lat + dlat))
        lo = ((lon + dlon + 180) % 360) - 180
        if globe.is_land(la, lo):
            hit = True
            break
    if hit:
        bits[i >> 3] |= 1 << (i & 7)
        land += 1
print(N, land)
print(base64.b64encode(bytes(bits)).decode())
