package main

import (
	"bufio"
	"bytes"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"fmt"
	"io"
	"net"
	"strings"
	"testing"
	"time"
)

func maskedFrame(op byte, p []byte, fin bool) []byte {
	b0 := op
	if fin {
		b0 |= 0x80
	}
	out := []byte{b0}
	if len(p) < 126 {
		out = append(out, 0x80|byte(len(p)))
	} else {
		out = append(out, 0x80|126, byte(len(p)>>8), byte(len(p)))
	}
	m := []byte{1, 2, 3, 4}
	out = append(out, m...)
	for i, c := range p {
		out = append(out, c^m[i&3])
	}
	return out
}

func TestFrameRoundTrip(t *testing.T) {
	buf := make([]byte, maxPayload)
	for _, n := range []int{0, 1, 125, 126, 1500, 65535} {
		p := make([]byte, n)
		_, _ = rand.Read(p)
		op, got, err := readFrame(bytes.NewReader(maskedFrame(opBinary, p, true)), buf)
		if err != nil || op != opBinary || !bytes.Equal(got, p) {
			t.Fatalf("n=%d: err=%v", n, err)
		}
	}
}

func TestFrameRejects(t *testing.T) {
	buf := make([]byte, maxPayload)
	cases := map[string][]byte{
		"parçalı":        maskedFrame(opBinary, []byte("x"), false),
		"maskesiz":       {0x82, 0x01, 'x'},
		"ayrılmış bit":   append([]byte{0xC2}, maskedFrame(opBinary, []byte("x"), true)[1:]...),
		"64 bit uzunluk": {0x82, 0xFF, 0, 0, 0, 0, 0, 0, 0, 1},
		"uzun ping":      maskedFrame(opPing, make([]byte, 126), true),
		"kısa 126":       {0x82, 0x80 | 126, 0, 5, 1, 2, 3, 4, 0, 0, 0, 0, 0},
		"metin çerçeve":  maskedFrame(0x1, []byte("x"), true),
	}
	for name, f := range cases {
		if _, _, err := readFrame(bytes.NewReader(f), buf); err == nil {
			t.Fatalf("%s kabul edildi", name)
		}
	}
}

func TestAcceptKeyRFC(t *testing.T) {
	// RFC 6455 §1.3 örneği
	if got := acceptKey("dGhlIHNhbXBsZSBub25jZQ=="); got != "s3pPLMBiTxaQ9kYGzzhZRbK+xOo=" {
		t.Fatal(got)
	}
}

type harness struct {
	addr string
	pin  string
	path string
	wg   *net.UDPConn
	ln   net.Listener
}

func start(t *testing.T) *harness {
	dir := t.TempDir()
	pin, err := generate(dir)
	if err != nil {
		t.Fatal(err)
	}
	cfg, pin2, err := loadTLS(dir)
	if err != nil || pin2 != pin {
		t.Fatalf("pin uyuşmadı %v", err)
	}
	wg, _ := net.ListenUDP("udp", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1)})
	go func() { // sahte WireGuard: gelen her paketi "R:" önekiyle geri yollar
		b := make([]byte, 70000)
		for {
			n, a, err := wg.ReadFromUDP(b)
			if err != nil {
				return
			}
			_, _ = wg.WriteToUDP(append([]byte("R:"), b[:n]...), a)
		}
	}()
	ln, _ := tls.Listen("tcp", "127.0.0.1:0", cfg)
	p := randomPath()
	s := &server{path: p, wg: wg.LocalAddr().(*net.UDPAddr), limit: 4, logf: t.Logf}
	go serve(ln, s)
	t.Cleanup(func() { ln.Close(); wg.Close() })
	return &harness{addr: ln.Addr().String(), pin: pin, path: p, wg: wg, ln: ln}
}

func dialPinned(t *testing.T, h *harness, pin string) (*tls.Conn, error) {
	return tls.Dial("tcp", h.addr, &tls.Config{
		InsecureSkipVerify: true, ServerName: "www.example.com", NextProtos: []string{"http/1.1"},
		VerifyPeerCertificate: func(raw [][]byte, _ [][]*x509.Certificate) error {
			c, err := x509.ParseCertificate(raw[0])
			if err != nil {
				return err
			}
			s := sha256.Sum256(c.RawSubjectPublicKeyInfo)
			if base64.StdEncoding.EncodeToString(s[:]) != pin {
				return fmt.Errorf("pin")
			}
			return nil
		},
	})
}

func upgrade(c io.ReadWriter, path string) (string, *bufio.Reader) {
	fmt.Fprintf(c, "GET %s HTTP/1.1\r\nHost: www.example.com\r\nUpgrade: websocket\r\nConnection: keep-alive, Upgrade\r\nSec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\nSec-WebSocket-Version: 13\r\n\r\n", path)
	br := bufio.NewReader(c)
	var sb strings.Builder
	for {
		l, err := br.ReadString('\n')
		sb.WriteString(l)
		if err != nil || l == "\r\n" {
			break
		}
	}
	return sb.String(), br
}

func TestRelayEndToEnd(t *testing.T) {
	h := start(t)
	c, err := dialPinned(t, h, h.pin)
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	resp, br := upgrade(c, h.path)
	if !strings.HasPrefix(resp, "HTTP/1.1 101 ") || !strings.Contains(resp, "s3pPLMBiTxaQ9kYGzzhZRbK+xOo=") {
		t.Fatalf("yükseltme: %q", resp)
	}
	for _, n := range []int{1, 148, 1420, 3000} {
		p := bytes.Repeat([]byte{byte(n)}, n)
		_, _ = c.Write(maskedFrame(opBinary, p, true))
		_ = c.SetReadDeadline(time.Now().Add(3 * time.Second))
		var hdr [4]byte
		if _, err := io.ReadFull(br, hdr[:2]); err != nil {
			t.Fatal(err)
		}
		ln := int(hdr[1])
		if ln == 126 {
			_, _ = io.ReadFull(br, hdr[2:4])
			ln = int(hdr[2])<<8 | int(hdr[3])
		}
		got := make([]byte, ln)
		_, _ = io.ReadFull(br, got)
		if hdr[0] != 0x82 || hdr[1]&0x80 != 0 || !bytes.Equal(got, append([]byte("R:"), p...)) {
			t.Fatalf("n=%d yanlış cevap", n)
		}
	}
	_, _ = c.Write(maskedFrame(opPing, []byte("hi"), true))
	var pong [4]byte
	_, _ = io.ReadFull(br, pong[:])
	if pong[0] != 0x8A || pong[1] != 2 || string(pong[2:]) != "hi" {
		t.Fatalf("pong: %x", pong)
	}
}

func TestDecoyAndProbing(t *testing.T) {
	h := start(t)
	for _, path := range []string{"/", h.path + "x", h.path[:len(h.path)-1], "/favicon.ico"} {
		c, err := dialPinned(t, h, h.pin)
		if err != nil {
			t.Fatal(err)
		}
		resp, _ := upgrade(c, path)
		c.Close()
		if !strings.HasPrefix(resp, "HTTP/1.1 404 Not Found") || !strings.Contains(resp, "Server: nginx") {
			t.Fatalf("%s: %q", path, resp)
		}
	}
	// doğru yol ama WebSocket başlıkları yok → yine 404 (yol tek başına yetmez)
	c, _ := dialPinned(t, h, h.pin)
	fmt.Fprintf(c, "GET %s HTTP/1.1\r\nHost: x\r\n\r\n", h.path)
	b, _ := io.ReadAll(c)
	c.Close()
	if !strings.HasPrefix(string(b), "HTTP/1.1 404") {
		t.Fatalf("başlıksız istek: %q", b)
	}
	// çöp istek → 400
	c, _ = dialPinned(t, h, h.pin)
	fmt.Fprintf(c, "\x16\x03\x01 rastgele\r\n\r\n")
	b, _ = io.ReadAll(c)
	c.Close()
	if !strings.HasPrefix(string(b), "HTTP/1.1 400") {
		t.Fatalf("çöp: %q", b)
	}
	// yanlış pin → istemci reddeder
	if _, err := dialPinned(t, h, base64.StdEncoding.EncodeToString(make([]byte, 32))); err == nil {
		t.Fatal("yanlış pin kabul edildi")
	}
}

func TestOversizedHeader(t *testing.T) {
	h := start(t)
	c, _ := dialPinned(t, h, h.pin)
	defer c.Close()
	fmt.Fprintf(c, "GET / HTTP/1.1\r\nX: %s\r\n\r\n", strings.Repeat("a", 9000))
	b, _ := io.ReadAll(c)
	if !strings.HasPrefix(string(b), "HTTP/1.1 400") {
		t.Fatalf("büyük başlık: %q", b)
	}
}

func TestConnectionLimit(t *testing.T) {
	h := start(t) // azami 4
	var held []*tls.Conn
	for i := 0; i < 4; i++ {
		c, err := dialPinned(t, h, h.pin)
		if err != nil {
			t.Fatal(err)
		}
		resp, _ := upgrade(c, h.path)
		if !strings.HasPrefix(resp, "HTTP/1.1 101") {
			t.Fatalf("%d: %q", i, resp)
		}
		held = append(held, c)
	}
	c, err := dialPinned(t, h, h.pin)
	if err == nil {
		resp, _ := upgrade(c, h.path)
		if strings.HasPrefix(resp, "HTTP/1.1 101") {
			t.Fatal("sınır aşıldı")
		}
		c.Close()
	}
	for _, c := range held {
		c.Close()
	}
}
