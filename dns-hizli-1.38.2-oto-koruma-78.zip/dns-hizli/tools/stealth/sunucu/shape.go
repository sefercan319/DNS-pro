package main

// Trafik gizleme (SHP1): istemci "0xF4 SHP1 <seviye>" denetim iletisiyle sunucu → istemci yönünde dolgu ve örtü ister.
// Bundan sonra WireGuard'dan gelen her paket "0xF5 ‖ uzunluk(2) ‖ paket ‖ dolgu" çerçevesiyle, örtü paketleri uzunluk 0 ile gider.
// Seviye 1 (düşük): sabit kalıplara dolgu, 1,5-6 sn'de bir örtü. Seviye 2 (yüksek): hep en büyük boy, gerçek trafik yokken ~10/sn örtü.

import (
	"bytes"
	"crypto/rand"
	"encoding/binary"
	mrand "math/rand/v2"
	"sync/atomic"
	"time"
)

var shapeMagic = []byte{0xF4, 'S', 'H', 'P', '1'}

const (
	shapeFrame = 0xF5
	shapeMax   = 1452 // MTU 1420 + WireGuard 32
)

var shapeBuckets = []int{160, 288, 544, 1056, shapeMax}

func isShapeReq(p []byte) bool { return len(p) == 6 && bytes.Equal(p[:5], shapeMagic) && p[5] <= 2 }

type shaper struct {
	level    atomic.Int32
	lastReal atomic.Int64 // unix ms
	started  atomic.Bool
}

// padTo: [n] baytlık WireGuard iletisi için çerçevenin hedef yük boyu (başlık 3 bayt dahil).
func (s *shaper) padTo(n int) int {
	switch s.level.Load() {
	case 1:
		for _, b := range shapeBuckets {
			if b >= n {
				return b + 3
			}
		}
		return n + 3
	case 2:
		if n > shapeMax {
			return n + 3
		}
		return shapeMax + 3
	}
	return 0
}

// frame [p]'yi dolgulu çerçeveye koyar ([out] yeniden kullanılır). Dolgu rastgele baytlardır (şifreli trafikten ayırt edilmesin).
func (s *shaper) frame(p []byte, out []byte) []byte {
	size := s.padTo(len(p))
	if size == 0 {
		return p
	}
	out = out[:0]
	out = append(out, shapeFrame)
	out = binary.BigEndian.AppendUint16(out, uint16(len(p)))
	out = append(out, p...)
	if pad := size - len(out); pad > 0 {
		start := len(out)
		out = append(out, make([]byte, pad)...)
		_, _ = rand.Read(out[start:])
	}
	return out
}

func (s *shaper) cover() []byte {
	var n int
	switch s.level.Load() {
	case 1:
		n = shapeBuckets[1+mrand.IntN(3)]
	case 2:
		n = shapeMax
	default:
		return nil
	}
	out := make([]byte, 3+n)
	out[0] = shapeFrame
	_, _ = rand.Read(out[3:])
	return out
}

func (s *shaper) nextDelay() time.Duration {
	if s.level.Load() == 2 {
		return time.Duration(80+mrand.IntN(41)) * time.Millisecond
	}
	return time.Duration(1500+mrand.IntN(4500)) * time.Millisecond
}

// coverLoop örtü çerçevelerini gönderir; [done] kapanınca biter. Seviye değişince bekleme hemen yeniden hesaplanır.
func (s *shaper) coverLoop(done <-chan struct{}, write func([]byte) error) {
	lv := s.level.Load()
	due := time.Now().Add(s.nextDelay())
	tick := time.NewTicker(20 * time.Millisecond)
	defer tick.Stop()
	for {
		select {
		case <-done:
			return
		case <-tick.C:
		}
		if cur := s.level.Load(); cur != lv {
			lv = cur
			due = time.Now().Add(s.nextDelay())
		}
		if lv == 0 || time.Now().Before(due) {
			continue
		}
		due = time.Now().Add(s.nextDelay())
		if lv == 2 && time.Now().UnixMilli()-s.lastReal.Load() < 80 {
			continue
		}
		if write(s.cover()) != nil {
			return
		}
	}
}
