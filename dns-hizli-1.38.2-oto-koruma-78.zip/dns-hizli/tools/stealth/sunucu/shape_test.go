package main

import (
	"bufio"
	"bytes"
	"io"
	"strings"
	"testing"
	"time"
)

func readServerFrame(t *testing.T, br *bufio.Reader) []byte {
	t.Helper()
	var h [4]byte
	if _, err := io.ReadFull(br, h[:2]); err != nil {
		t.Fatal(err)
	}
	n := int(h[1] & 0x7F)
	if n == 126 {
		_, _ = io.ReadFull(br, h[2:4])
		n = int(h[2])<<8 | int(h[3])
	}
	p := make([]byte, n)
	_, _ = io.ReadFull(br, p)
	return p
}

func TestShapingFramesAndCover(t *testing.T) {
	h := start(t)
	c, err := dialPinned(t, h, h.pin)
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	resp, br := upgrade(c, h.path)
	if !strings.HasPrefix(resp, "HTTP/1.1 101") {
		t.Fatal(resp)
	}
	_, _ = c.Write(maskedFrame(opBinary, []byte{0xF4, 'S', 'H', 'P', '1', 1}, true))
	p := bytes.Repeat([]byte{7}, 100)
	_, _ = c.Write(maskedFrame(opBinary, p, true))
	_ = c.SetReadDeadline(time.Now().Add(3 * time.Second))
	f := readServerFrame(t, br)
	// yanıt "R:" + 100 bayt = 102 → kova 160, çerçeve 163
	if f[0] != 0xF5 || int(f[1])<<8|int(f[2]) != 102 || len(f) != 163 || !bytes.Equal(f[3:105], append([]byte("R:"), p...)) {
		t.Fatalf("dolgulu çerçeve: len=%d başlık=%x", len(f), f[:3])
	}
	// yüksek seviye: gerçek trafik yokken örtü çerçeveleri (uzunluk 0, en büyük boy) gelir
	_, _ = c.Write(maskedFrame(opBinary, []byte{0xF4, 'S', 'H', 'P', '1', 2}, true))
	got := 0
	for got < 3 {
		g := readServerFrame(t, br)
		if g[0] == 0xF5 && g[1] == 0 && g[2] == 0 && len(g) == 3+shapeMax {
			got++
		}
	}
}

func TestShapeRequestValidation(t *testing.T) {
	if isShapeReq([]byte{0xF4, 'S', 'H', 'P', '1', 3}) || isShapeReq([]byte{0xF4, 'S', 'H', 'P', '1'}) || !isShapeReq([]byte{0xF4, 'S', 'H', 'P', '1', 0}) {
		t.Fatal("istek doğrulama")
	}
	s := &shaper{}
	s.level.Store(1)
	for _, c := range []struct{ n, want int }{{1, 163}, {160, 163}, {161, 291}, {1056, 1059}, {1400, 1455}, {1500, 1503}} {
		if got := s.padTo(c.n); got != c.want {
			t.Fatalf("düşük %d: %d != %d", c.n, got, c.want)
		}
	}
	s.level.Store(2)
	if s.padTo(10) != shapeMax+3 {
		t.Fatal("yüksek")
	}
	s.level.Store(0)
	if out := s.frame([]byte{1, 2, 3}, nil); !bytes.Equal(out, []byte{1, 2, 3}) {
		t.Fatal("kapalıyken çerçeve değişmemeli")
	}
}
