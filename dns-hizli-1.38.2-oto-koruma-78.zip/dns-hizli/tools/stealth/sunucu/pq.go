package main

// Kuantum sonrası PSK (PQ1): istemci, Stealth kanalı içinde ML-KEM-768 ile bu aktarıcıyla yeni bir sır üretir; aktarıcı sunucudaki
// WireGuard eşinin PresharedKey'ini bu sırdan türetilen değere ayarlar. WireGuard'ın X25519'u ileride kuantum bilgisayarla kırılsa da
// kaydedilmiş trafik açılamaz (PSK hem UDP hem Stealth yolunda geçerlidir).
//
//	istek  (0xF0 "PQ1"): zaman (8, BE) ‖ istemci WG ortak anahtarı (32) ‖ ML-KEM-768 ek (1184) ‖ HMAC-SHA256(temel_psk, "dhs-pq1-istek" ‖ önceki)
//	cevap  (0xF1 "PQ1"): kapsül (1088) ‖ HMAC-SHA256(temel_psk, "dhs-pq1-cevap" ‖ önceki ‖ istek_mac)
//	hata   (0xF2 "PQ1"): kod (1)  — 1 eş/mac, 2 saat, 3 wg ayarlanamadı, 4 biçim, 5 kalıcı anahtar yok (PQ2)
//	oturum PSK = HMAC-SHA256(temel_psk, "dhs-pq1-psk" ‖ ss ‖ istemci_ortak ‖ istek_mac)
// Temel PSK istemci yapılandırmasındaki PresharedKey'dir (kur.sh her istemciye ayrı üretir); istek onunla doğrulanır.

import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/mlkem"
	"crypto/sha256"
	"encoding/base64"
	"encoding/binary"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const (
	pqReqLen = 4 + 8 + 32 + mlkem.EncapsulationKeySize768 + 32
	pqSkew   = 120 * time.Second
)

// PQ2 (kuantum sonrası SUNUCU KİMLİĞİ): aktarıcının kalıcı ML-KEM-768 anahtarı vardır; istemci onun özetini (PqPin) sabitler.
// İstemci önce anahtarı ister (KEY2), özeti denetler; sonra hem geçici anahtarını gönderir hem de kalıcı anahtara bir kapsül koyar.
// Cevabın doğrulama anahtarı kalıcı kapsülün sırrından türetilir: yalnızca gerçek aktarıcı (açma anahtarı elinde olan) doğru cevap
// üretebilir — imza (ML-DSA) yerine KEM ile kimlik doğrulama (KEMTLS / Rosenpass yöntemi); Go standart kütüphanesiyle, ek bağımlılık yok.
//
//	KEY2 isteği : 0xF6 "KEY2"                          → 0xF7 "KEY2" ‖ kalıcı ek (1184)
//	PQ2 isteği  : 0xF0 "PQ2" ‖ zaman (8) ‖ istemci ortak (32) ‖ geçici ek (1184) ‖ kalıcı kapsül (1088) ‖ HMAC(temel_psk, "dhs-pq2-istek" ‖ önceki)
//	PQ2 cevabı  : 0xF1 "PQ2" ‖ geçici kapsül (1088) ‖ HMAC(HMAC(temel_psk, "dhs-pq2-kimlik" ‖ ss_kalıcı), "dhs-pq2-cevap" ‖ önceki ‖ istek_mac)
//	oturum PSK  = HMAC(temel_psk, "dhs-pq2-psk" ‖ ss_geçici ‖ ss_kalıcı ‖ istemci_ortak ‖ istek_mac)

var (
	pqMagicReq2  = []byte{0xF0, 'P', 'Q', '2'}
	pqMagicResp2 = []byte{0xF1, 'P', 'Q', '2'}
	keyMagicReq  = []byte{0xF6, 'K', 'E', 'Y', '2'}
	keyMagicResp = []byte{0xF7, 'K', 'E', 'Y', '2'}
)

const pqReqLen2 = 4 + 8 + 32 + mlkem.EncapsulationKeySize768 + mlkem.CiphertextSize768 + 32

func isPQ2(p []byte) bool  { return len(p) >= 4 && bytes.Equal(p[:4], pqMagicReq2) }
func isKey2(p []byte) bool { return len(p) == 5 && bytes.Equal(p, keyMagicReq) }

// staticKeyFile: aktarıcının kalıcı ML-KEM tohumu (64 bayt).
const staticKeyFile = "pq.anahtar"

func loadStatic(dir string) *mlkem.DecapsulationKey768 {
	b, err := os.ReadFile(filepath.Join(dir, staticKeyFile))
	if err != nil || len(b) != mlkem.SeedSize {
		return nil
	}
	k, err := mlkem.NewDecapsulationKey768(b)
	if err != nil {
		return nil
	}
	return k
}

// genStatic yoksa kalıcı anahtar üretir; sabitleme özetini (PqPin) döner.
func genStatic(dir string) (string, error) {
	if k := loadStatic(dir); k != nil {
		return staticPin(k), nil
	}
	k, err := mlkem.GenerateKey768()
	if err != nil {
		return "", err
	}
	if err := os.WriteFile(filepath.Join(dir, staticKeyFile), k.Bytes(), 0o600); err != nil {
		return "", err
	}
	return staticPin(k), nil
}

func staticPin(k *mlkem.DecapsulationKey768) string {
	h := sha256.Sum256(k.EncapsulationKey().Bytes())
	return base64.StdEncoding.EncodeToString(h[:])
}

func (q *pqState) handleKey2() []byte {
	if q.static == nil {
		return errResp(5)
	}
	return append(append([]byte{}, keyMagicResp...), q.static.EncapsulationKey().Bytes()...)
}

// fresh tekrar ve saat denetimi (PQ1 ve PQ2 ortak).
func (q *pqState) fresh(ts time.Time, reqMac []byte) bool {
	now := q.now()
	if d := now.Sub(ts); d > pqSkew || d < -pqSkew {
		return false
	}
	q.mu.Lock()
	defer q.mu.Unlock()
	for k, t := range q.seen {
		if now.Sub(t) > 2*pqSkew {
			delete(q.seen, k)
		}
	}
	if _, dup := q.seen[string(reqMac)]; dup {
		return false
	}
	q.seen[string(reqMac)] = now
	return true
}

func (q *pqState) handle2(p []byte) []byte {
	if q.static == nil {
		return errResp(5)
	}
	if len(p) != pqReqLen2 {
		return errResp(4)
	}
	body := p[:pqReqLen2-32]
	ts := time.Unix(int64(binary.BigEndian.Uint64(p[4:12])), 0)
	pub := p[12:44]
	ekb := p[44 : 44+mlkem.EncapsulationKeySize768]
	cts := p[44+mlkem.EncapsulationKeySize768 : 44+mlkem.EncapsulationKeySize768+mlkem.CiphertextSize768]
	reqMac := p[pqReqLen2-32:]
	base := q.basePSK(pub)
	if base == nil || !hmac.Equal(mac(base, "dhs-pq2-istek", body), reqMac) {
		return errResp(1)
	}
	if !q.fresh(ts, reqMac) {
		return errResp(2)
	}
	ssS, err := q.static.Decapsulate(cts)
	if err != nil {
		return errResp(4)
	}
	ek, err := mlkem.NewEncapsulationKey768(ekb)
	if err != nil {
		return errResp(4)
	}
	ssE, ct := ek.Encapsulate()
	psk := mac(base, "dhs-pq2-psk", ssE, ssS, pub, reqMac)
	if err := q.setPSK(pub, psk); err != nil {
		return errResp(3)
	}
	resp := append(append([]byte{}, pqMagicResp2...), ct...)
	authKey := mac(base, "dhs-pq2-kimlik", ssS)
	return append(resp, mac(authKey, "dhs-pq2-cevap", resp, reqMac)...)
}

var (
	pqMagicReq  = []byte{0xF0, 'P', 'Q', '1'}
	pqMagicResp = []byte{0xF1, 'P', 'Q', '1'}
	pqMagicErr  = []byte{0xF2, 'P', 'Q', '1'}
)

type pqState struct {
	dir    string                     // istemci-*/pub ve psk dosyaları
	static *mlkem.DecapsulationKey768 // PQ2 kalıcı anahtar (yoksa PQ2 kapalı)
	wgCmd  string
	wgIf   string
	mu     sync.Mutex
	seen   map[string]time.Time // tekrar koruması (istek mac → görülme)
	now    func() time.Time
}

func isPQ(p []byte) bool { return len(p) >= 4 && bytes.Equal(p[:4], pqMagicReq) }

func mac(key []byte, label string, parts ...[]byte) []byte {
	h := hmac.New(sha256.New, key)
	h.Write([]byte(label))
	for _, p := range parts {
		h.Write(p)
	}
	return h.Sum(nil)
}

// basePSK istemci ortak anahtarına ait temel PSK'yi bulur.
func (q *pqState) basePSK(pub []byte) []byte {
	want := base64.StdEncoding.EncodeToString(pub)
	dirs, _ := filepath.Glob(filepath.Join(q.dir, "istemci-*"))
	for _, d := range dirs {
		pb, err := os.ReadFile(filepath.Join(d, "pub"))
		if err != nil || strings.TrimSpace(string(pb)) != want {
			continue
		}
		kb, err := os.ReadFile(filepath.Join(d, "psk"))
		if err != nil {
			return nil
		}
		k, err := base64.StdEncoding.DecodeString(strings.TrimSpace(string(kb)))
		if err != nil || len(k) != 32 {
			return nil
		}
		return k
	}
	return nil
}

func errResp(code byte) []byte { return append(append([]byte{}, pqMagicErr...), code) }

// handle isteği işler, gönderilecek cevabı döner.
func (q *pqState) handle(p []byte) []byte {
	if len(p) != pqReqLen {
		return errResp(4)
	}
	body := p[:pqReqLen-32]
	ts := time.Unix(int64(binary.BigEndian.Uint64(p[4:12])), 0)
	pub := p[12:44]
	ekb := p[44 : 44+mlkem.EncapsulationKeySize768]
	reqMac := p[pqReqLen-32:]
	base := q.basePSK(pub)
	if base == nil || !hmac.Equal(mac(base, "dhs-pq1-istek", body), reqMac) {
		return errResp(1)
	}
	if !q.fresh(ts, reqMac) {
		return errResp(2)
	}
	ek, err := mlkem.NewEncapsulationKey768(ekb)
	if err != nil {
		return errResp(4)
	}
	ss, ct := ek.Encapsulate()
	psk := mac(base, "dhs-pq1-psk", ss, pub, reqMac)
	if err := q.setPSK(pub, psk); err != nil {
		return errResp(3)
	}
	resp := append(append([]byte{}, pqMagicResp...), ct...)
	return append(resp, mac(base, "dhs-pq1-cevap", resp, reqMac)...)
}

func (q *pqState) setPSK(pub, psk []byte) error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, q.wgCmd, "set", q.wgIf, "peer", base64.StdEncoding.EncodeToString(pub), "preshared-key", "/dev/stdin")
	cmd.Stdin = strings.NewReader(base64.StdEncoding.EncodeToString(psk) + "\n")
	return cmd.Run()
}
