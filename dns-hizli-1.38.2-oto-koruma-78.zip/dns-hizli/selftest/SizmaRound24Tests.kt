package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

/** sizma48: kuantum sonrası SUNUCU KİMLİĞİ (PQ2: kalıcı ML-KEM anahtarıyla, KEMTLS/Rosenpass yöntemi) — Go aktarıcısıyla uçtan uca. */
internal fun runRound24Tests() {
    configTests()
    goTests()
    staticTests()
}

private fun b64(b: ByteArray) = java.util.Base64.getEncoder().encodeToString(b)

private fun configTests() {
    T.group("sizma48: PqPin alanı")
    fun c(extra: String) = WgConfig.parse("[Interface]\nPrivateKey = ${b64(Wg.generatePrivate())}\nAddress = 10.7.0.2/32\n[Peer]\nPublicKey = ${b64(Wg.publicKey(Wg.generatePrivate()))}\nPresharedKey = ${b64(ByteArray(32) { 1 })}\nAllowedIPs = 0.0.0.0/0\n[Stealth]\nEndpoint = r.example:443\nPin = ${b64(ByteArray(32))}\nPath = /AbCdEfGhIjKlMnOpQr\n$extra")
    val ok = (c("PqPin = ${b64(ByteArray(32) { 5 })}") as? WgConfig.Companion.Result.Ok)?.cfg?.stealth
    T.check("PqPin okunur ve kuantum sonrası değişimi açar", ok?.pqPin?.contentEquals(ByteArray(32) { 5 }) == true && ok.pq)
    T.check("geçersiz PqPin reddedilir", c("PqPin = kisa") is WgConfig.Companion.Result.Err)
    T.check("PqPin yoksa PQ1 (yalnız gizlilik), kimlik doğrulaması yok", (c("PQ = 1") as? WgConfig.Companion.Result.Ok)?.cfg?.stealth?.pqPin == null)
}

private fun goTests() {
    T.group("sizma48: Go aktarıcısıyla PQ2")
    val bin = relayBinary()
    if (bin == null) { T.check("Go yok: atlandı", true); return }
    val dir = File.createTempFile("dhspq2", "").also { it.delete(); it.mkdirs() }
    val g = ProcessBuilder(bin.path, "-sertifika-uret", "-dizin", dir.path).redirectErrorStream(true).start()
    val out = g.inputStream.bufferedReader().readText(); g.waitFor(30, TimeUnit.SECONDS)
    val pinS = Regex("Pin = (\\S+)").find(out)!!.groupValues[1]; val path = Regex("Path = (\\S+)").find(out)!!.groupValues[1]
    val pqPinS = Regex("PqPin = (\\S+)").find(out)?.groupValues?.get(1)
    T.check("sertifika üretimi kalıcı ML-KEM anahtarını ve PqPin'i de üretir", pqPinS != null && File(dir, "pq.anahtar").length() == 64L)
    if (pqPinS == null) return
    val pqPin = java.util.Base64.getDecoder().decode(pqPinS)
    val rng = SecureRandom()
    val cPriv = Wg.generatePrivate(); val sPriv = Wg.generatePrivate(); val cPub = Wg.publicKey(cPriv)
    val base = ByteArray(32).also { rng.nextBytes(it) }
    File(dir, "istemci-2").also { it.mkdirs(); File(it, "pub").writeText(b64(cPub) + "\n"); File(it, "psk").writeText(b64(base) + "\n") }
    val log = File(dir, "wg.log")
    val fakeWg = File(dir, "wg").also { it.writeText("#!/bin/sh\necho \"$@\" >> ${log.path}\ncat >> ${log.path}\n"); it.setExecutable(true) }
    var srvPsk = base
    val udp = DatagramSocket(0, InetAddress.getLoopbackAddress())
    val th = Thread {
        val b = ByteArray(70000)
        while (!udp.isClosed) {
            val dp = DatagramPacket(b, b.size); try { udp.receive(dp) } catch (_: Exception) { break }
            val m = b.copyOf(dp.length)
            if (m[0].toInt() == Wg.TYPE_INITIATION) {
                val res = WgResponder(sPriv).also { it.addPeer(WgResponder.Peer(cPub, srvPsk)) }
                val i = res.consumeInitiation(m, 0, m.size) ?: continue
                val (r, _) = res.respond(i, 5, System.currentTimeMillis())!!
                try { udp.send(DatagramPacket(r, r.size, dp.socketAddress)) } catch (_: Exception) {}
            }
        }
    }.also { it.isDaemon = true; it.start() }
    val port = ServerSocket(0, 1, InetAddress.getLoopbackAddress()).use { it.localPort }
    fun startRelay() = ProcessBuilder(bin.path, "-dinle", "127.0.0.1:$port", "-dizin", dir.path, "-wg", "127.0.0.1:${udp.localPort}", "-wg-komut", fakeWg.path).redirectErrorStream(true).start()
    var proc = startRelay()
    val addr = InetSocketAddress(InetAddress.getLoopbackAddress(), port)
    fun waitUp() { var up = false; repeat(50) { if (!up) up = try { Socket().use { s -> s.connect(addr, 200) }; true } catch (_: Exception) { Thread.sleep(100); false } } }
    try {
        waitUp()
        val st = StealthCfg("127.0.0.1", port, null, path, java.util.Base64.getDecoder().decode(pinS), pq = true, pqPin = pqPin)
        val plain: (InetSocketAddress) -> Socket = { a -> Socket().also { it.connect(a, 3000) } }
        val sess = StealthClient.open(st, addr, plain)
        val r = PqPsk.exchange2(sess, base, cPub, pqPin, System.currentTimeMillis() / 1000)
        val ok = r as? PqPsk.Result.Ok
        val lines = if (log.isFile) log.readLines() else emptyList()
        T.check("PQ2: kalıcı anahtar doğrulandı, değişim başarılı, aktarıcı aynı PSK'yi ayarladı", ok != null && lines.size == 2 && lines[1] == b64(ok.psk), "$r")
        if (ok != null) srvPsk = ok.psk
        val conf = (WgConfig.parse("[Interface]\nPrivateKey = ${b64(cPriv)}\nAddress = 10.77.0.2/32\n[Peer]\nPublicKey = ${b64(Wg.publicKey(sPriv))}\nPresharedKey = ${b64(base)}\nAllowedIPs = 0.0.0.0/0\nEndpoint = 127.0.0.1:1") as WgConfig.Companion.Result.Ok).cfg
        val tunnel = WgTunnel(conf, { sess.send(it) }, { _, _, _ -> })
        Thread { val b = ByteArray(70000); try { while (true) { val n = sess.receive(b); if (n < 0) break; tunnel.fromNet(b, 0, n) } } catch (_: Exception) {} }.also { it.isDaemon = true; it.start() }
        if (ok != null) tunnel.setPsk(ok.psk, fromPq = true)
        val d = System.currentTimeMillis() + 6000
        while (!tunnel.connected && System.currentTimeMillis() < d) Thread.sleep(20)
        T.check("PQ2 PSK'siyle WireGuard el sıkışması tamamlandı", tunnel.connected)
        sess.close(); tunnel.close()
        val n0 = log.readLines().size
        val s2 = StealthClient.open(st, addr, plain)
        val wrong = PqPsk.exchange2(s2, base, cPub, ByteArray(32) { 9 }, System.currentTimeMillis() / 1000)
        T.check("sabitlenen kimlik özeti uyuşmazsa: kimlik hatası, istek hiç gönderilmez, wg çağrılmaz", (wrong as? PqPsk.Result.Fail)?.code == PqPsk.FAIL_IDENTITY && log.readLines().size == n0)
        s2.close()
        // kalıcı anahtarı olmayan (eski) aktarıcı: kod 5
        proc.destroy(); proc.waitFor(5, TimeUnit.SECONDS)
        File(dir, "pq.anahtar").delete()
        proc = startRelay(); waitUp()
        val s3 = StealthClient.open(st, addr, plain)
        val none = PqPsk.exchange2(s3, base, cPub, pqPin, System.currentTimeMillis() / 1000)
        T.check("kalıcı anahtarı olmayan aktarıcı: kod 5 (kimlik doğrulanamaz, PQ yükseltmesi yapılmaz)", (none as? PqPsk.Result.Fail)?.code == 5)
        val v1 = PqPsk.exchange(s3, base, cPub, System.currentTimeMillis() / 1000)
        T.check("PQ1 hâlâ çalışır (geri uyum)", v1 is PqPsk.Result.Ok)
        s3.close()
    } finally {
        proc.destroy(); proc.waitFor(5, TimeUnit.SECONDS); proc.destroyForcibly(); udp.close(); th.join(1000); dir.deleteRecursively()
    }
}

private fun staticTests() {
    T.group("sizma48: servis ve kurulum")
    fun src(p: String) = listOf(p, "../$p").map { File(it) }.firstOrNull { it.isFile }?.readText() ?: ""
    val w = src("app/src/main/java/app/dnshizli/platform/WgVpnService.kt")
    T.check("PqPin varsa PQ2 kullanılır; kimlik hatasında oturum kullanılmaz ve PQ'suza düşülmez", w.contains("PqPsk.exchange2(") &&
        w.contains("if (!ok && lastPqCode == PqPsk.FAIL_IDENTITY)") && w.indexOf("lastPqCode == PqPsk.FAIL_IDENTITY") < w.indexOf("skipPqOnce = true; continue"))
    val k = src("tools/stealth/kur.sh")
    T.check("kur.sh: kalıcı anahtar üretilir (eski kurulumda da), aktarıcı okur, istemciye PqPin yazılır", k.contains("-pq-anahtar-uret") && k.contains("chmod 640 \"\$DIR/sunucu.key\" \"\$DIR/yol\" \"\$DIR/pq.anahtar\"") && k.contains("echo \"PqPin = \$pqpin\""))
}
