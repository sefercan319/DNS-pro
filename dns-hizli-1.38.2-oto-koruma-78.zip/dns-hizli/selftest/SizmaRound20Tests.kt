package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.GlobeNode
import app.dnshizli.ui.GlobePage
import app.dnshizli.ui.Strings
import java.io.File
import kotlin.math.abs

/** sizma44: etkileşimli sunucu küresi — izdüşüm, kara verisi, döndürme/yakınlaştırma/dokunma, sayfa, iki parmak. */
internal fun runRound20Tests() {
    mathTests()
    landTests()
    uiTests()
}

private fun mathTests() {
    T.group("sizma44: küre izdüşümü ve kamera")
    val c = GlobeCamera(0.0, 0.0, 1.0); val p = GlobeCamera.P()
    c.project(0.0, 0.0, p)
    T.check("merkezdeki nokta (0,0) ekran merkezinde, önde", abs(p.x) < 1e-9 && abs(p.y) < 1e-9 && abs(p.z - 1) < 1e-9)
    c.project(0.0, Math.toRadians(90.0), p)
    T.check("90° doğu: sağ kenarda", abs(p.x - 1) < 1e-9 && abs(p.z) < 1e-9)
    c.project(Math.toRadians(90.0), 0.0, p)
    T.check("kuzey kutbu: üstte", abs(p.y - 1) < 1e-9)
    c.project(0.0, Math.toRadians(180.0), p)
    T.check("arka yüz görünmez (z < 0)", p.z < 0)
    val ist = GlobeCamera(); ist.focus(Math.toRadians(41.0), Math.toRadians(29.0)); ist.project(Math.toRadians(41.0), Math.toRadians(29.0), p)
    T.check("focus: hedef merkeze gelir", abs(p.x) < 1e-9 && abs(p.y) < 1e-9)
    val d = GlobeCamera(0.0, 0.0, 1.0)
    d.beginDrag(); d.dragBy(100.0, 0.0, 100.0, 0.016); d.endDrag()
    T.check("sağa sürükleme: küre parmakla döner (merkez batıya kayar)", abs(d.lon0 - (-1.0)) < 1e-9)
    d.beginDrag(); d.dragBy(0.0, 1000.0, 100.0, 0.016)
    T.check("eğim ±75° ile sınırlı", abs(d.lat0 - GlobeCamera.MAX_TILT) < 1e-9)
    val z = GlobeCamera(); z.zoomBy(100.0)
    T.check("yakınlaştırma 1..5 arası", z.zoom == GlobeCamera.MAX_ZOOM && GlobeCamera().also { it.zoomBy(0.01) }.zoom == 1.0)
    val s = GlobeCamera(); s.zoomStep(); val a = s.zoom; s.zoomStep(); val b = s.zoom; s.zoomStep()
    T.check("çift dokunma: 1 → 2 → 4 → 1", a == 2.0 && b == 4.0 && s.zoom == 1.0)
    val f = GlobeCamera(0.0, 0.0); f.beginDrag(); repeat(5) { f.dragBy(-20.0, 0.0, 100.0, 0.016) }; f.endDrag()
    val l0 = f.lon0; f.tick(0.1, autoSpin = false); val l1 = f.lon0
    var t = 0.0; while (t < 5) { f.tick(0.016, false); t += 0.016 }
    val l2 = f.lon0; f.tick(1.0, false)
    T.check("bırakınca atalet sürer, sonra durur", abs(l1 - l0) > 1e-4 && abs(f.lon0 - l2) < 1e-6)
    val sp = GlobeCamera(0.0, 0.0); sp.tick(5.0, autoSpin = true); val before = sp.lon0; sp.tick(1.0, true)
    T.check("boşta yavaşça kendiliğinden döner (hareket açıksa)", abs(sp.lon0 - before) > 0.01 && GlobeCamera(0.0, 0.0).also { it.tick(10.0, false) }.lon0 == 0.0)
    T.check("boylam sarmalanır (-π..π)", abs(GlobeCamera.wrap(3 * Math.PI) - Math.PI) < 1e-9 || abs(GlobeCamera.wrap(3 * Math.PI) + Math.PI) < 1e-9)
    val pk = GlobeCamera(0.0, 0.0, 1.0)
    val i = pk.pick(150.0 + 100.0 * kotlin.math.sin(Math.toRadians(10.0)), 150.0, 150.0, 150.0, 100.0, doubleArrayOf(0.0, 0.0, 0.0), doubleArrayOf(-170.0, 10.0, 60.0), 20.0)
    T.check("dokunulan noktaya en yakın görünür sunucu seçilir; arkadaki seçilmez", i == 1 && pk.pick(50.0, 150.0, 150.0, 150.0, 100.0, doubleArrayOf(0.0), doubleArrayOf(-170.0), 20.0) == -1)
}

private fun landTests() {
    T.group("sizma44: kara verisi")
    val pts = GlobeLand.points
    T.check("kara noktaları ~%30-35 (dünyanın kara oranı ~%29)", pts.size in 2500..3300, "${pts.size}")
    fun landNear(lat: Double, lon: Double): Boolean {
        val la = Math.toRadians(lat); val lo = Math.toRadians(lon)
        return (0 until pts.size).any { k -> val dl = pts.lat[k] - la; var dn = abs(pts.lon[k] - lo); if (dn > Math.PI) dn = 2 * Math.PI - dn; dl * dl + (dn * kotlin.math.cos(la)) * (dn * kotlin.math.cos(la)) < 0.0012 }
    }
    T.check("Ankara, Paris, Avustralya ortası, Brezilya karada", landNear(39.9, 32.8) && landNear(48.85, 2.35) && landNear(-25.0, 135.0) && landNear(-10.0, -55.0))
    T.check("Atlas okyanusu ortası, Pasifik ortası denizde", !landNear(0.0, -30.0) && !landNear(-20.0, -140.0))
    T.check("her katalog markasının konumu ya karada ya kıyıda (koordinat yazım hatası yok)", Catalog.builtin.mapNotNull { GlobeSites.of(it) }.all { landNear(it.lat, it.lon) || landNear(it.lat + 1, it.lon) || landNear(it.lat, it.lon + 1) || landNear(it.lat - 1, it.lon - 1) })
    T.check("özel sunucular kürede yok (konum uydurulmaz)", Catalog.builtin.first().let { GlobeSites.of(it) != null })
}

private fun findGlobe(n: app.dnshizli.ui.Node): GlobeNode? = (n as? GlobeNode) ?: n.children.firstNotNullOfOrNull { findGlobe(it) }

private fun uiTests() {
    T.group("sizma44: küre sayfası")
    val rig = Rig(Rig.base())
    rig.tapText(Strings.GLOBE, settleMs = 900)
    val page = rig.scene.currentPage as? GlobePage
    T.check("ana sayfadaki küre düğmesi sayfayı açar", page != null)
    if (page == null) return
    val g = findGlobe(page)!!
    T.check("bağlı/seçili sunucunun markası (Cloudflare) seçili ve merkezde", page.selectedBrand == "Cloudflare" && g.screenOf("Cloudflare")?.let { abs(it.first - g.w / 2) < 2 && abs(it.second - g.h / 2) < 2 } == true)
    T.check("seçili markanın sunucuları altta listelenir", rig.find("Cloudflare") != null && rig.findAll("Cloudflare").size >= 3)
    // Quad9'a dokun (önce Zürih'i merkeze getir)
    g.camera.focus(Math.toRadians(47.37), Math.toRadians(8.54)); rig.settle(100)
    val q = g.screenOf("Quad9")!!
    rig.tap(g.absX() + q.first, g.absY() + q.second, settleMs = 500)
    T.check("noktaya dokununca o marka seçilir, sunucuları listelenir", page.selectedBrand == "Quad9" || page.selectedBrand == "SWITCH", "${page.selectedBrand}")
    val lon0 = g.camera.lon0
    val gx = g.absX() + g.w / 2; val gy = g.absY() + g.h / 2
    rig.scene.touch(app.dnshizli.ui.Scene.DOWN, gx, gy, rig.host.now); rig.advance(32)
    for (k in 1..10) { rig.scene.touch(app.dnshizli.ui.Scene.MOVE, gx, gy + k * 8f, rig.host.now); rig.advance(16) }
    rig.scene.touch(app.dnshizli.ui.Scene.UP, gx, gy + 80f, rig.host.now); rig.advance(32)
    T.check("dikey sürükleme sayfayı kaydırmaz, küreyi eğer", page.scrollOffset == 0f && g.camera.lat0 != Math.toRadians(47.37))
    rig.scene.touch(app.dnshizli.ui.Scene.DOWN, gx, gy, rig.host.now); rig.advance(16)
    for (k in 1..10) { rig.scene.touch(app.dnshizli.ui.Scene.MOVE, gx + k * 10f, gy, rig.host.now); rig.advance(16) }
    rig.scene.touch(app.dnshizli.ui.Scene.UP, gx + 100f, gy, rig.host.now); rig.advance(16)
    T.check("yatay sürükleme döndürür", abs(g.camera.lon0 - lon0) > 0.1)
    val z0 = g.camera.zoom
    rig.scene.touch(app.dnshizli.ui.Scene.DOWN, gx, gy, rig.host.now)
    rig.scene.pinch(1.5f, gx, gy); rig.scene.pinch(1.2f, gx, gy)
    rig.scene.touch(app.dnshizli.ui.Scene.CANCEL, 0f, 0f, rig.host.now); rig.advance(32)
    T.check("iki parmakla yakınlaştırma", abs(g.camera.zoom - z0 * 1.8) < 1e-3)
    T.check("Scene.pinch yalnız Pinchable'a gider (başka sayfada etkisiz, çökme yok)", run { val r2 = Rig(Rig.base()); r2.scene.pinch(2f, 100f, 300f); true })
    // ön izleme görseli (açık ve koyu)
    for ((theme, name) in listOf("aqua" to "kure-acik", "night" to "kure-koyu")) {
        val r = Rig(Rig.base(theme)); r.tapText(Strings.GLOBE, settleMs = 900)
        val cv = AwtCanvas(r.w, r.h); r.draw(cv.gfx); cv.savePng("build/onizleme/$name.png"); cv.dispose()
    }
    run { val r = Rig(Rig.base()); val cv = AwtCanvas(r.w, 140); r.draw(cv.gfx); cv.savePng("build/onizleme/kure-dugme.png"); cv.dispose() }
    T.check("ön izleme görselleri üretildi", File("build/onizleme/kure-acik.png").isFile && File("build/onizleme/kure-koyu.png").isFile)
    T.check("Türkçe metinler", Strings.GLOBE == "Sunucu küresi" && Strings.globePlace("ch-zrh") == "Zürih, İsviçre")
}
