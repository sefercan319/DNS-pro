package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.Strings
import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.Random
import java.util.concurrent.TimeUnit

/** sizma47: trafik gizleme — boy dolgusu, örtü paketleri, zaman karıştırma, standart WireGuard uyumu, Go aktarıcısıyla iki yönlü dolgu. */
internal fun runRound23Tests() {
    shaperTests()
    tunnelTests()
    jitterTests()
    relayTests()
    uiTests()
}

private fun b64(b: ByteArray) = java.util.Base64.getEncoder().encodeToString(b)

private fun shaperTests() {
    T.group("sizma47: gizleme seviyeleri")
    val lo = Shaper(Shaper.Level.LOW, Random(1)); val hi = Shaper(Shaper.Level.HIGH, Random(1)); val off = Shaper(Shaper.Level.OFF)
    T.check("düşük: kalıplar 128/256/512/1024/MTU", lo.padSize(60, 1420) == 128 && lo.padSize(129, 1420) == 256 && lo.padSize(900, 1420) == 1024 && lo.padSize(1100, 1420) == 1420 && lo.padSize(1300, 1280) == 1280)
    T.check("yüksek: hep MTU", hi.padSize(40, 1420) == 1420 && hi.padSize(1400, 1420) == 1420)
    T.check("kapalı: dolgu yok, örtü yok", off.padSize(60, 1420) == 0 && off.nextCoverDelayMs() == -1L && !off.coverWanted(10_000, 0))
    T.check("düşük örtü 1,5-6 sn; yüksek ~10/sn", (1..200).all { lo.nextCoverDelayMs() in 1500..6000 } && (1..200).all { hi.nextCoverDelayMs() in 80..120 })
    T.check("yüksek: gerçek trafik akarken örtü gerekmez", !hi.coverWanted(1000, 950) && hi.coverWanted(1000, 900))
    T.check("zaman karıştırma yalnız yüksekte, 0-12 ms", (1..200).all { hi.jitterMs() in 0..12 } && (1..50).all { lo.jitterMs() == 0 })
}

private fun tunnelTests() {
    T.group("sizma47: tünelde dolgu ve örtü (standart WireGuard alıcısıyla)")
    val cPriv = Wg.generatePrivate(); val sPriv = Wg.generatePrivate()
    val cfg = (WgConfig.parse("[Interface]\nPrivateKey = ${b64(cPriv)}\nAddress = 10.7.0.2/32\nMTU = 1420\n[Peer]\nPublicKey = ${b64(Wg.publicKey(sPriv))}\nAllowedIPs = 0.0.0.0/0\nEndpoint = 203.0.113.1:51820") as WgConfig.Companion.Result.Ok).cfg
    val res = WgResponder(sPriv).also { it.addPeer(WgResponder.Peer(Wg.publicKey(cPriv))) }
    var srv: WgSession? = null
    val wire = ArrayList<ByteArray>()
    val got = ArrayList<ByteArray>()
    val t = WgTunnel(cfg, { m ->
        wire.add(m)
        when (m[0].toInt()) {
            Wg.TYPE_INITIATION -> res.consumeInitiation(m, 0, m.size)?.let { i -> val (r, s) = res.respond(i, 3, 1000L)!!; srv = s; pending.add(r) }
            Wg.TYPE_DATA -> srv?.decrypt(m, 0, m.size, 1000L)?.let { got.add(it) }
        }
    }, { _, _, _ -> }, now = { 1000L })
    t.shaper = Shaper(Shaper.Level.LOW, Random(3))
    val p = ByteArray(60).also { it[0] = 0x45; Packets.put16(it, 2, 60); it[9] = 17; System.arraycopy(byteArrayOf(10, 7, 0, 2), 0, it, 12, 4); System.arraycopy(byteArrayOf(1, 1, 1, 1), 0, it, 16, 4) }
    t.fromTun(p, p.size)
    while (pending.isNotEmpty()) { val r = pending.removeAt(0); t.fromNet(r, 0, r.size) }
    val data = wire.filter { it[0].toInt() == Wg.TYPE_DATA }
    T.check("60 baytlık paket 128'e dolduruldu (tel boyu 16+128+16)", data.any { it.size == 16 + 128 + 16 })
    T.check("alıcı asıl paketi IP başlığından çıkarır (dolgu atılır)", got.any { pt -> pt.size == 128 && WgTunnel.innerLength(pt) == 60 && pt.copyOf(60).contentEquals(p) })
    val before = got.size
    T.check("örtü paketi gönderilir", t.sendCover() && t.coverSent == 1L)
    val cover = got.drop(before).lastOrNull()
    T.check("örtü: sıfır dolgulu, IP değil (alıcı atar), boyu kalıplardan", cover != null && cover.all { it == 0.toByte() } && cover.size in listOf(256, 512, 1024) && WgTunnel.innerLength(cover) == null)
    val rx = WgTunnel(cfg, {}, { _, _, _ -> }, now = { 1000L })
    T.check("bizim tünelimiz örtüyü tün'e yazmaz (innerLength null → düşer)", WgTunnel.innerLength(ByteArray(256)) == null)
    t.shaper = Shaper(Shaper.Level.HIGH)
    t.fromTun(p, p.size)
    T.check("yüksek: her veri paketi MTU boyunda", wire.last().size == 16 + 1424 + 16 || wire.last().size == 16 + 1420 + 16)
    t.shaper = null
    t.fromTun(p, p.size)
    T.check("kapalı: standart 16'ya dolgu (64)", wire.last().size == 16 + 64 + 16)
    T.check("örtü ölü eş algılamasını tetiklemez (veri sayılmaz)", run { val c0 = t.lastRealSentMs; t.shaper = Shaper(Shaper.Level.LOW); t.sendCover(); t.lastRealSentMs == c0 })
    rx.close()
}
private val pending = ArrayList<ByteArray>()

private fun jitterTests() {
    T.group("sizma47: zaman karıştırma sırayı korur")
    val out = java.util.Collections.synchronizedList(ArrayList<Int>())
    val r = Random(5)
    val j = JitterSender({ out.add(it[0].toInt()) }, { r.nextInt(13) })
    for (i in 0 until 60) j.offer(byteArrayOf(i.toByte()))
    val d = System.currentTimeMillis() + 3000
    while (out.size < 60 && System.currentTimeMillis() < d) Thread.sleep(5)
    j.close()
    T.check("60 paket gecikmeli ama sırayla gitti", out.size == 60 && out == (0 until 60).toList(), out.take(10).toString())
    val direct = ArrayList<Int>()
    val j0 = JitterSender({ direct.add(1) }, { 0 }); j0.offer(ByteArray(1)); j0.close()
    T.check("gecikme 0 ise doğrudan gider", direct.size == 1)
}

private fun relayTests() {
    T.group("sizma47: Go aktarıcısı — sunucu → telefon yönünde dolgu ve örtü")
    val bin = relayBinary()
    if (bin == null) { T.check("Go yok: atlandı", true); return }
    val dir = File.createTempFile("dhsshp", "").also { it.delete(); it.mkdirs() }
    val gen = ProcessBuilder(bin.path, "-sertifika-uret", "-dizin", dir.path).redirectErrorStream(true).start()
    val o = gen.inputStream.bufferedReader().readText(); gen.waitFor(30, TimeUnit.SECONDS)
    val pin = java.util.Base64.getDecoder().decode(Regex("Pin = (\\S+)").find(o)!!.groupValues[1]); val path = Regex("Path = (\\S+)").find(o)!!.groupValues[1]
    val udp = DatagramSocket(0, InetAddress.getLoopbackAddress())
    val echo = Thread { val b = ByteArray(70000); while (!udp.isClosed) { val dp = DatagramPacket(b, b.size); try { udp.receive(dp) } catch (_: Exception) { break }; try { udp.send(DatagramPacket(b, dp.length, dp.socketAddress)) } catch (_: Exception) {} } }.also { it.isDaemon = true; it.start() }
    val port = ServerSocket(0, 1, InetAddress.getLoopbackAddress()).use { it.localPort }
    val proc = ProcessBuilder(bin.path, "-dinle", "127.0.0.1:$port", "-dizin", dir.path, "-wg", "127.0.0.1:${udp.localPort}").redirectErrorStream(true).start()
    try {
        val addr = InetSocketAddress(InetAddress.getLoopbackAddress(), port)
        var up = false
        repeat(50) { if (!up) up = try { Socket().use { s -> s.connect(addr, 200) }; true } catch (_: Exception) { Thread.sleep(100); false } }
        val sess = StealthClient.open(StealthCfg("127.0.0.1", port, null, path, pin), addr, { a -> Socket().also { it.connect(a, 3000) } })
        sess.setReadTimeout(4000)
        val buf = ByteArray(70000)
        val msg = ByteArray(100) { 4 }.also { it[0] = 4 }
        sess.send(msg)
        val n0 = sess.receive(buf)
        T.check("gizleme istenmeden çerçeveler değişmez (geri uyum)", n0 == 100 && buf.copyOf(100).contentEquals(msg))
        sess.requestShaping(2)
        sess.send(msg)
        val n1 = sess.receive(buf)
        T.check("dolgulu çerçeve açılır: asıl WireGuard iletisi döner", n1 == 100 && buf.copyOf(100).contentEquals(msg))
        val c0 = sess.coverReceived
        val until = System.currentTimeMillis() + 1500
        sess.setReadTimeout(500)
        try { while (System.currentTimeMillis() < until) sess.receive(buf) } catch (_: java.io.IOException) {}
        T.check("yüksek seviyede boşta örtü çerçeveleri gelir ve atılır (tünele verilmez)", sess.coverReceived - c0 >= 5, "${sess.coverReceived - c0}")
        sess.close()
    } finally {
        proc.destroy(); proc.waitFor(5, TimeUnit.SECONDS); proc.destroyForcibly(); udp.close(); echo.join(1000); dir.deleteRecursively()
    }
}

private fun uiTests() {
    T.group("sizma47: arayüz ve servis yapısı")
    val rig = Rig(Rig.base())
    rig.model.wgSetShapeLevel(Shaper.Level.HIGH)
    T.check("seviye platforma iletilir", rig.host.wgShapeId == "high" && rig.model.wgShapeLevel() == Shaper.Level.HIGH)
    T.check("Türkçe metinler ve veri bedeli uyarısı", Strings.WG_SHAPE == "Trafik gizleme" && Strings.WG_SHAPE_FOOT.contains("45 MB") && Strings.WG_SHAPE_FOOT.contains("Mixnet değildir"))
    val w = listOf("app/src/main/java/app/dnshizli/platform/WgVpnService.kt", "../app/src/main/java/app/dnshizli/platform/WgVpnService.kt").map { File(it) }.first { it.isFile }.readText()
    T.check("servis: seviye ağ tüneline uygulanır, örtü döngüsü, zaman karıştırma, Stealth'te aktarıcıdan istenir, kip değişince canlı",
        w.contains("t.shaper = if (lvl == Shaper.Level.OFF) null else Shaper(lvl)") && w.contains("fun coverLoop(my: Int)") && w.contains("JitterSender(") &&
            w.contains("sess.requestShaping(l.code)") && Regex("""ACTION_MODE[\s\S]{0,400}applyShaping\(\)""").containsMatchIn(w))
}
