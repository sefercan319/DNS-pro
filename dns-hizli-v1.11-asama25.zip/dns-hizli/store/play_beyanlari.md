# Play Console beyanları — hazır cevap taslakları (v1.9.11)

Hukuki tavsiye değildir. Formlardaki seçimler **senin** beyanındır; Play Console'daki güncel soru metni esastır. Aşağıdakiler
uygulamanın gerçekte yaptığına göre yazıldı. Emin olmadığın yerde olduğu gibi anlat, abartma.

## 1) Veri güvenliği formu

Uygulama kendi sunucusuna veri **göndermez**, analitik/reklam SDK'sı yok. Tek veri hareketi: DNS sorguları (alan adları), senin
seçtiğin DNS sağlayıcısına gider (varsayılan olarak DoT/DoH ile şifreli).

| Soru | Önerilen cevap | Not |
|---|---|---|
| Uygulama kullanıcı verisi **topluyor** mu? | Hayır (geliştirici olarak toplamıyor, saklamıyor) | Sorgular geliştiriciye gelmez. |
| Uygulama kullanıcı verisi **paylaşıyor** mu? | Değerlendir: DNS sorguları kullanıcının seçtiği üçüncü taraf sağlayıcıya iletiliyor | Play'in "paylaşma" tanımında kullanıcının kendi seçtiği hizmete aktarım için muafiyetler var; hangisinin uyduğuna sen karar ver. En güvenlisi: web gezinti geçmişi benzeri veri → "paylaşılıyor, isteğe bağlı değil çünkü uygulamanın çekirdek işlevi" diye işaretleyip politikada anlatmak. |
| Veri türü (paylaşılıyorsa) | Web gezinti geçmişi (ziyaret edilen alan adları) | Başka tür yok: konum, kişi, kimlik, finans, mesaj, fotoğraf (arka plan fotoğrafı cihazdan çıkmaz) toplanmıyor. |
| Aktarım sırasında şifreleniyor mu? | Evet (varsayılan DoT/DoH). Kullanıcı kapatırsa düz DNS | Politika ve mağaza metninde yazıyor. |
| Kullanıcı verinin silinmesini isteyebilir mi? | Geliştiricide veri yok; sağlayıcıdaki veri için sağlayıcıya başvurulur | |
| Güvenlik uygulamaları | Hesap yok, yedekleme kapalı, kendi sunucu yok | |

## 2) VPN hizmeti beyanı (VpnService)

Metin (formda İngilizce istenirse):

> The app uses Android's VpnService locally and only to forward DNS queries from the device to the public DNS server the user chooses (Cloudflare, Google, Quad9, AdGuard and others, or a custom server). It is not a remote VPN service: no traffic is tunnelled to a VPN server operated by the developer or anyone else. By default the tunnel only captures DNS queries to a private virtual address and all other traffic uses its normal route. If the user switches on one of two optional features ("DPI bypass" or "Ads+", both off by default), all of the device's traffic is routed through the tunnel into a relay that runs inside the app on the device and is forwarded directly from there to its destination; it is never sent to the developer or any other party. The relay reads only the host name in the first packet of a connection (TLS SNI or HTTP Host), in memory, to match it against an on-device blocklist or to split the packet; it stores and logs nothing and does not decrypt or alter encrypted content. DNS queries are encrypted by default (DNS-over-TLS / DNS-over-HTTPS); the user can switch encryption off in settings and the app says so. The app shows a prominent disclosure on first launch before the system VPN permission dialog and does not collect or share user data for advertising or analytics.

Gerekenler: uygulama içi açık bilgilendirme (ilk açılış ekranı bunu yapar), kısa video (≤ 90 sn): uygulamayı aç → bilgilendirmeyi göster →
küreye dokun → Android VPN izin penceresini göster → bağlı + bildirim → Ayarlar'da şifreleme seçeneği.

## 3) Önplan hizmeti (foreground service) beyanı

- Hizmet türü: `systemExempted` (VPN hizmeti için Android belgelerinde izinli tür).
- Neden: kullanıcı bağlandığı sürece DNS yönlendirmesi çalışmalı; bildirim her zaman görünür (Kes / Sonraki / Duraklat).
- Video: uygulamayı aç → bağlan → bildirim çubuğunda kalıcı bildirimi göster.

## 4) Diğer Uygulama içeriği formları

- Reklamlar: **Yok**. Hedef kitle: 18 yaş ve üzeri / çocuklara yönelik değil. Haberler uygulaması: Hayır. Sağlık: Hayır.
- Uygulama erişimi: tüm işlevler giriş gerektirmeden açık.
- İçerik derecelendirme anketi: şiddet/cinsellik/kumar yok; kullanıcı etkileşimi ve konum paylaşımı yok.
- Finansal özellikler: Yok. Devlet uygulaması: Hayır.
- İzinler (manifest): INTERNET, ACCESS_NETWORK_STATE, FOREGROUND_SERVICE (+ SYSTEM_EXEMPTED), RECEIVE_BOOT_COMPLETED (isteğe bağlı "telefon açılınca bağlan"),
  POST_NOTIFICATIONS (durum bildirimi). Hepsinin nedeni `GIZLILIK.md` "İzinler" bölümünde.

## 5) Yayından önce yapacakların

1. Benzersiz `applicationId` seç (`app/build.gradle.kts`, bir kez; sonradan değişmez).
2. Kendi yükleme anahtarını üret, **depoya ve yapay zekalara verme** (`OKUBENI.md` §4); GitHub'da dört gizli değer olarak tanımla; Actions → *Yayin AAB derle*.
3. `GIZLILIK.md`'deki köşeli yerleri doldur, herkese açık bir adrese koy.
4. Gerçek telefonda tam deneme (özellikle sunucu değiştirme, kopma/yeniden bağlanma, kendini onarma).
5. Kişisel hesapsa: en az 12 test kullanıcısıyla 14 gün kapalı test.
