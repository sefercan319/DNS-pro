// Sürümler burada tek yerde (Ekim 2026'da resmî belgelerden doğrulanan uyumlu takım):
//   Gradle 9.8.0  -> JDK 25 ile çalışır (Gradle 9.1'den beri); AGP 9.4 için en az 9.6.0 gerekir.
//   AGP 9.4.0     -> en az Gradle 9.6.0, JDK 17+, compileSdk 37'ye kadar, Kotlin DESTEĞİ YERLEŞİK
//                    (org.jetbrains.kotlin.android eklentisi artık kullanılmaz).
//   Kotlin 2.4.20 -> AGP 9'un varsayılan (2.2.10) sürümü yerine aşağıdaki buildscript satırıyla seçilir.
//   JDK 25        -> hem Gradle'ı çalıştırır hem de kod hedefidir (app/build.gradle.kts içindeki JAVA_HEDEF).
// Güncelleme için: https://developer.android.com/build/releases/about-agp
buildscript {
    dependencies {
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.4.20")
    }
}
plugins {
    id("com.android.application") version "9.4.0" apply false
}
