package app.dnshizli.core

/**
 * DPI atlatma: bir bağlantının İLK uçuşunu (TLS ClientHello ya da HTTP isteği) ayrıştırır ve ağdaki derin paket denetimi
 * (DPI) cihazları şaşırsın diye parçalara böler. Hepsi sıradan soketlerle yapılabilen (kök gerektirmeyen) yöntemlerdir;
 * sahte paket / düşük TTL / bozuk sağlama toplamı gibi ham soket gerektirenler bilerek yoktur.
 *
 * Yöntemler (TLS): 0 = bayt 1'de ve SNI ortasında TCP bölme; 1 = ClientHello'yu iki TLS kaydına böl (+ TCP bölme);
 * 2 = SNI ortasında bölme + araya 1 bayt acil (OOB) veri (sunucu atar, DPI akışa katar); 3 = 1+2 birlikte.
 * Yöntemler (HTTP): 0 = Host başlığının içinde bölme; 1 = "hOsT" harf karışımı + bölme; 2 = iki nokta sonrası sekme + bölme;
 * 3 = metot içinde bölme + harf karışımı.
 * Hepsi sunucuya göre anlamca aynı veriyi taşır. Otomatik mod, çalışmayan yöntemde bir sonrakine geçer ([Planner]).
 */
internal object Dpi {
    const val NONE = 0
    const val TLS = 1
    const val HTTP = 2

    const val TLS_PLANS = 5
    const val HTTP_PLANS = 4

    /** TLS yöntemlerinin deneme sırası (bkz. [Planner]). */
    val TLS_ORDER = intArrayOf(1, 0, 3, 2, 4)

    /** DNS'i atlatan bilinen DoH sağlayıcı adları (Reklam+ DNS açıkken engeller: tarayıcı sistem DNS'ine döner). */
    private val DOH_HOSTS = listOf(
        "dns.google", "dns.google.com", "cloudflare-dns.com", "one.one.one.one", "dns.quad9.net", "dns9.quad9.net", "dns10.quad9.net",
        "dns11.quad9.net", "doh.opendns.com", "dns.adguard.com", "dns.adguard-dns.com", "dns.nextdns.io", "doh.dns.sb", "doh.cleanbrowsing.org",
        "dns.controld.com", "doh.mullvad.net", "doh.libredns.gr", "dns.alidns.com", "doh.pub",
    )

    /** [host] bilinen bir DoH sağlayıcısı mı (kendisi ya da alt alanı)? */
    fun isDohHost(host: String): Boolean = DOH_HOSTS.any { host == it || host.endsWith(".$it") }
    class Hello {
        var sniOff = -1          // SNI adının [b] içindeki konumu
        var sniLen = 0
        var recLen = 0           // ilk TLS kaydının yük uzunluğu
        var ech = false          // Encrypted ClientHello var: SNI gerçek ad değil olabilir
        fun host(b: ByteArray): String? =
            if (sniOff >= 0 && sniLen > 0) String(b, sniOff, sniLen, Charsets.ISO_8859_1).lowercase() else null
    }

    /** İlk baytlara bakıp TLS / HTTP / bilinmiyor ayırır. Karar için en az 3 bayt gerekir. */
    fun classify(b: ByteArray, len: Int): Int {
        if (len < 3) return NONE
        if (b[0].toInt() == 0x16 && b[1].toInt() == 3 && (b[2].toInt() and 0xFF) <= 4) return TLS
        val m = METHODS.any { m -> len >= m.length && m.indices.all { b[it].toInt() == m[it].code } }
        return if (m) HTTP else NONE
    }

    private val METHODS = listOf("GET ", "POST ", "HEAD ", "PUT ", "DELETE ", "OPTIONS ", "PATCH ", "CONNECT ")

    /** TLS: ilk kaydın tamamı için gereken toplam bayt (5 + yük). Başlık eksikse -1. */
    fun tlsNeed(b: ByteArray, len: Int): Int = if (len < 5) -1 else 5 + Packets.u16(b, 3)

    /** HTTP: başlıkların bittiği konum (\r\n\r\n sonrası) ya da -1. */
    fun httpEnd(b: ByteArray, len: Int): Int {
        var i = 3
        while (i < len) {
            if (b[i].toInt() == '\n'.code && b[i - 1].toInt() == '\r'.code && b[i - 2].toInt() == '\n'.code && b[i - 3].toInt() == '\r'.code) return i + 1
            i++
        }
        return -1
    }

    /** ClientHello'dan SNI'yı çıkarır. Bozuk/eksik ise false. */
    fun parseHello(b: ByteArray, len: Int, h: Hello): Boolean {
        h.sniOff = -1; h.sniLen = 0; h.ech = false
        if (len < 44 || b[0].toInt() != 0x16 || b[5].toInt() != 1) return false
        h.recLen = Packets.u16(b, 3)
        val end = minOf(len, 5 + h.recLen)
        var p = 5 + 4 + 2 + 32                         // kayıt başlığı, el sıkışma başlığı, sürüm, rastgele
        if (p + 1 > end) return false
        p += 1 + (b[p].toInt() and 0xFF)               // oturum kimliği
        if (p + 2 > end) return false
        p += 2 + Packets.u16(b, p)                     // şifre takımları
        if (p + 1 > end) return false
        p += 1 + (b[p].toInt() and 0xFF)               // sıkıştırma
        if (p + 2 > end) return false
        val extEnd = minOf(end, p + 2 + Packets.u16(b, p))
        p += 2
        while (p + 4 <= extEnd) {
            val t = Packets.u16(b, p)
            val l = Packets.u16(b, p + 2)
            val body = p + 4
            if (body + l > extEnd) return h.sniOff >= 0
            if (t == 0 && l >= 5) {
                val nl = Packets.u16(b, body + 3)
                if (b[body + 2].toInt() == 0 && nl > 0 && body + 5 + nl <= body + l) { h.sniOff = body + 5; h.sniLen = nl }
            } else if (t == 0xFE0D) h.ech = true
            p = body + l
        }
        return h.sniOff >= 0
    }

    /** HTTP isteğinde Host değerinin konumu ve uzunluğu (başlık adının başlangıcı [hdrOff] ile). */
    class HttpInfo { var hdrOff = -1; var valOff = -1; var valLen = 0; var get = false }

    fun parseHttp(b: ByteArray, len: Int, h: HttpInfo): Boolean {
        h.hdrOff = -1; h.valOff = -1; h.valLen = 0
        h.get = len >= 4 && (startsWith(b, "GET ") || startsWith(b, "HEAD"))
        var i = 0
        while (i < len) {
            val e = lineEnd(b, i, len)
            if (e < 0) break
            if (e - i >= 5 && lower(b[i]) == 'h' && lower(b[i + 1]) == 'o' && lower(b[i + 2]) == 's' && lower(b[i + 3]) == 't' && b[i + 4].toInt() == ':'.code) {
                var v = i + 5
                while (v < e && (b[v].toInt() == ' '.code || b[v].toInt() == '\t'.code)) v++
                var ve = e
                while (ve > v && (b[ve - 1].toInt() == ' '.code || b[ve - 1].toInt() == '\t'.code)) ve--
                h.hdrOff = i; h.valOff = v; h.valLen = ve - v
                return h.valLen > 0
            }
            i = e + 2
        }
        return false
    }

    fun httpHost(b: ByteArray, h: HttpInfo): String? {
        if (h.valOff < 0) return null
        val s = String(b, h.valOff, h.valLen, Charsets.ISO_8859_1).lowercase()
        return s.substringBefore(':').trim().ifEmpty { null }
    }

    private fun startsWith(b: ByteArray, s: String): Boolean = s.indices.all { b[it].toInt() == s[it].code }
    private fun lower(x: Byte): Char = (x.toInt() or 0x20).toChar()
    private fun lineEnd(b: ByteArray, from: Int, len: Int): Int {
        var i = from
        while (i + 1 < len) { if (b[i].toInt() == '\r'.code && b[i + 1].toInt() == '\n'.code) return i; i++ }
        return -1
    }

    /** Sunucuya sırayla yazılacak bir parça; [oobAfter] doğruysa arkasından 1 bayt acil veri gönderilir. */
    class Part(val data: ByteArray, val oobAfter: Boolean = false, val lowTtl: Boolean = false)

    private fun slice(b: ByteArray, from: Int, to: Int): ByteArray = b.copyOfRange(from, to)

    /**
     * [plan] numaralı yönteme göre ilk uçuşu parçalara böler. Veri tek parçaysa (bölünemiyorsa) tek elemanlı dizi döner.
     * [n] ilk uçuşun uzunluğudur (b'nin tamamı olmayabilir).
     */
    fun split(kind: Int, plan: Int, b: ByteArray, n: Int): List<Part> {
        return when (kind) {
            TLS -> splitTls(plan, b, n)
            HTTP -> splitHttp(plan, b, n)
            else -> listOf(Part(slice(b, 0, n)))
        }
    }

    private fun splitTls(plan: Int, b: ByteArray, n: Int): List<Part> {
        val h = Hello()
        val ok = parseHello(b, n, h)
        val mid = if (ok) h.sniOff + h.sniLen / 2 else n / 2
        val cut = mid.coerceIn(2, n - 1)
        if (n < 8) return listOf(Part(slice(b, 0, n)))
        return when (plan) {
            0 -> listOf(Part(slice(b, 0, 1)), Part(slice(b, 1, cut)), Part(slice(b, cut, n)))
            1 -> tlsRecordParts(b, n, cut)
            2 -> listOf(Part(slice(b, 0, cut), oobAfter = true), Part(slice(b, cut, n)))
            // 4 = "disorder": ilk bayt çok düşük TTL ile gider (DPI'a ya da sunucuya ulaşmaz), çekirdek biraz sonra normal TTL ile
            // yeniden yollar; DPI akışı sırasız görür. TTL ayarlanamazsa yalnızca 0 numaralı bölme gibi davranır.
            4 -> listOf(Part(slice(b, 0, 1), lowTtl = true), Part(slice(b, 1, cut)), Part(slice(b, cut, n)))
            else -> {
                val x = tlsRecordParts(b, n, cut)
                if (x.size >= 3) listOf(x[0], Part(x[1].data, oobAfter = true), x[2]) else listOf(Part(slice(b, 0, cut), oobAfter = true), Part(slice(b, cut, n)))
            }
        }
    }

    // --- TLS kaydı bölme

    /**
     * ClientHello'yu [cut] noktasında iki TLS kaydına bölüp üç TCP parçası verir: [0,1) [1, kayıt1 sonu) [kayıt2].
     * Birleşik akış geçerli iki ardışık el sıkışma kaydıdır; sunucu parçalı kaydı birleştirir (RFC 8446 §5.1).
     */
    fun tlsRecordParts(b: ByteArray, n: Int, cut: Int): List<Part> {
        val recEnd = 5 + Packets.u16(b, 3)
        if (n < recEnd || cut <= 5 || cut >= recEnd) return listOf(Part(slice(b, 0, 1)), Part(slice(b, 1, n)))
        val first = ByteArray(cut)                       // kayıt 1: başlık + yükün ilk kısmı
        System.arraycopy(b, 0, first, 0, cut)
        Packets.put16(first, 3, cut - 5)
        val second = ByteArray(5 + (recEnd - cut) + (n - recEnd))   // kayıt 2: yeni başlık + kalan yük (+ varsa sonrası)
        System.arraycopy(b, 0, second, 0, 3)
        Packets.put16(second, 3, recEnd - cut)
        System.arraycopy(b, cut, second, 5, n - cut)
        return listOf(Part(slice(first, 0, 1)), Part(slice(first, 1, first.size)), Part(second))
    }

    private fun splitHttp(plan: Int, b: ByteArray, n: Int): List<Part> {
        val h = HttpInfo()
        val ok = parseHttp(b, n, h)
        val d = b.copyOfRange(0, n)
        if (!ok) return listOf(Part(d))
        val cut: Int
        when (plan) {
            0 -> cut = h.hdrOff + 2
            1 -> { mixCase(d, h.hdrOff); cut = h.hdrOff + 2 }
            2 -> {
                // "Host:" ile değer arasına sekme: çoğu sunucu başlık değerindeki boşluğu yok sayar.
                val x = ByteArray(n + 1)
                System.arraycopy(d, 0, x, 0, h.hdrOff + 5)
                x[h.hdrOff + 5] = '\t'.code.toByte()
                System.arraycopy(d, h.hdrOff + 5, x, h.hdrOff + 6, n - h.hdrOff - 5)
                val c = (h.hdrOff + 2).coerceAtMost(x.size - 1)
                return listOf(Part(slice(x, 0, c)), Part(slice(x, c, x.size)))
            }
            else -> { mixCase(d, h.hdrOff); cut = 2 }
        }
        val c = cut.coerceIn(1, n - 1)
        return listOf(Part(slice(d, 0, c)), Part(slice(d, c, n)))
    }

    private fun mixCase(d: ByteArray, off: Int) {
        d[off] = 'h'.code.toByte(); d[off + 1] = 'O'.code.toByte(); d[off + 2] = 's'.code.toByte(); d[off + 3] = 'T'.code.toByte()
    }

    /**
     * Hedef başına çalışan yöntemi hatırlar (en çok [cap] hedef, en eski atılır). Yöntem çalışmazsa sıradakine geçilir.
     * İlk deneme TLS'te 1 (TLS kaydı bölme + TCP bölme: Türkiye'de en sık işe yarayan, sunucuya zararsız), HTTP'de 0'dır.
     * Sıra TLS için 1 → 0 → 3 → 2 → 4 (en son disorder: ~200 ms gecikme ekler).
     */
    class Planner(private val cap: Int = 512) {
        private val ok = object : LinkedHashMap<String, Int>(64, 0.75f, true) {
            override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Int>?) = size > cap
        }

        @Synchronized fun first(key: String, kind: Int = HTTP): Int = ok[key] ?: (if (kind == TLS) TLS_ORDER[0] else 0)
        @Synchronized fun worked(key: String, plan: Int) { ok[key] = plan }
        @Synchronized fun forget() = ok.clear()
        fun next(kind: Int, plan: Int): Int {
            if (kind == TLS) {
                val i = TLS_ORDER.indexOf(plan)
                return if (i >= 0 && i + 1 < TLS_ORDER.size) TLS_ORDER[i + 1] else -1
            }
            return if (plan + 1 < HTTP_PLANS) plan + 1 else -1
        }
    }
}
