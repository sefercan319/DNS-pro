package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Ana düğmenin şekli. [CIRCLE] özgün cam küredir (çizimi değişmedi); diğerleri aynı cam ve sıvı çizimini köşeleri
 * yumuşatılmış bir çokgenin içine kırpar. Hepsi merkezi (0,0) olan, dikeyde en çok yarıçap kadar uzanan şekillerdir,
 * bu yüzden ana ekranın yerleşimi değişmez. [topF]/[bottomF]: şeklin üst/alt ucu (yarıçapın katı), sıvı seviyesi bu aralığa
 * göre ölçülür. [iconDy]: güç simgesinin görsel merkeze kayması (yarıçapın katı).
 */
enum class OrbShape(
    val id: String, val topF: Float, val bottomF: Float, val iconDy: Float,
    val iconScale: Float = 1f, val shineScale: Float = 1f, val shineX: Float = 1f,
) {
    // Uçlar, köşeleri yuvarlatılmış gerçek çizginin ölçülmüş değerleridir (testte doğrulanır).
    CIRCLE("circle", -1f, 1f, 0f),
    TRIANGLE("triangle", -0.869f, 0.870f, 0.16f, 1f, 1f, 0.5f),
    SQUARE("square", -0.884f, 0.884f, 0f),
    HEXAGON("hexagon", -0.96f, 0.96f, 0f),
    STAR("star", -0.989f, 0.804f, 0.06f),
    OCTAGON("octagon", -0.94f, 0.94f, 0f),
    PENTAGON("pentagon", -0.882f, 0.931f, 0.06f),
    RECTANGLE("rectangle", -0.62f, 0.62f, 0f, 1f, 0.8f),
    INV_TRIANGLE("inv_triangle", -0.870f, 0.869f, -0.24f),
    // Büyük çizilen yeni şekiller: elmas, çiçek (5 yapraklı), altı köşeli yıldız; ardından 25 kalkan ([ShieldData]).
    DIAMOND("diamond", -0.976f, 0.976f, 0f, 1f, 0.6f, 0.5f),
    FLOWER("flower", -0.970f, 0.820f, 0f, 1f, 0.85f),
    STAR6("star6", -0.991f, 0.991f, 0f, 1f, 0.7f, 0.5f),
    SHIELD_1("shield_1", ShieldData.TOP[0], ShieldData.BOTTOM[0], ShieldData.ICON_DY[0], 1f, 0.9f),
    SHIELD_2("shield_2", ShieldData.TOP[1], ShieldData.BOTTOM[1], ShieldData.ICON_DY[1], 1f, 0.9f),
    SHIELD_3("shield_3", ShieldData.TOP[2], ShieldData.BOTTOM[2], ShieldData.ICON_DY[2], 1f, 0.9f),
    SHIELD_4("shield_4", ShieldData.TOP[3], ShieldData.BOTTOM[3], ShieldData.ICON_DY[3], 1f, 0.9f),
    SHIELD_5("shield_5", ShieldData.TOP[4], ShieldData.BOTTOM[4], ShieldData.ICON_DY[4], 1f, 0.9f),
    SHIELD_6("shield_6", ShieldData.TOP[5], ShieldData.BOTTOM[5], ShieldData.ICON_DY[5], 1f, 0.9f),
    SHIELD_7("shield_7", ShieldData.TOP[6], ShieldData.BOTTOM[6], ShieldData.ICON_DY[6], 1f, 0.9f),
    SHIELD_8("shield_8", ShieldData.TOP[7], ShieldData.BOTTOM[7], ShieldData.ICON_DY[7], 1f, 0.9f),
    SHIELD_9("shield_9", ShieldData.TOP[8], ShieldData.BOTTOM[8], ShieldData.ICON_DY[8], 1f, 0.9f),
    SHIELD_10("shield_10", ShieldData.TOP[9], ShieldData.BOTTOM[9], ShieldData.ICON_DY[9], 1f, 0.9f),
    SHIELD_11("shield_11", ShieldData.TOP[10], ShieldData.BOTTOM[10], ShieldData.ICON_DY[10], 1f, 0.9f),
    SHIELD_12("shield_12", ShieldData.TOP[11], ShieldData.BOTTOM[11], ShieldData.ICON_DY[11], 1f, 0.9f),
    SHIELD_13("shield_13", ShieldData.TOP[12], ShieldData.BOTTOM[12], ShieldData.ICON_DY[12], 1f, 0.9f),
    SHIELD_14("shield_14", ShieldData.TOP[13], ShieldData.BOTTOM[13], ShieldData.ICON_DY[13], 1f, 0.9f),
    SHIELD_15("shield_15", ShieldData.TOP[14], ShieldData.BOTTOM[14], ShieldData.ICON_DY[14], 1f, 0.9f),
    SHIELD_16("shield_16", ShieldData.TOP[15], ShieldData.BOTTOM[15], ShieldData.ICON_DY[15], 1f, 0.9f),
    SHIELD_17("shield_17", ShieldData.TOP[16], ShieldData.BOTTOM[16], ShieldData.ICON_DY[16], 1f, 0.9f),
    SHIELD_18("shield_18", ShieldData.TOP[17], ShieldData.BOTTOM[17], ShieldData.ICON_DY[17], 1f, 0.9f),
    SHIELD_19("shield_19", ShieldData.TOP[18], ShieldData.BOTTOM[18], ShieldData.ICON_DY[18], 1f, 0.9f),
    SHIELD_20("shield_20", ShieldData.TOP[19], ShieldData.BOTTOM[19], ShieldData.ICON_DY[19], 1f, 0.9f),
    SHIELD_21("shield_21", ShieldData.TOP[20], ShieldData.BOTTOM[20], ShieldData.ICON_DY[20], 1f, 0.9f),
    SHIELD_22("shield_22", ShieldData.TOP[21], ShieldData.BOTTOM[21], ShieldData.ICON_DY[21], 1f, 0.9f),
    SHIELD_23("shield_23", ShieldData.TOP[22], ShieldData.BOTTOM[22], ShieldData.ICON_DY[22], 1f, 0.9f),
    SHIELD_24("shield_24", ShieldData.TOP[23], ShieldData.BOTTOM[23], ShieldData.ICON_DY[23], 1f, 0.9f),
    SHIELD_25("shield_25", ShieldData.TOP[24], ShieldData.BOTTOM[24], ShieldData.ICON_DY[24], 1f, 0.9f);

    /** Kalkan şekilleri ([ShieldData]) listenin sonundadır. */
    val isShield: Boolean get() = ordinal >= FIRST_SHIELD

    /** 1..25: kalkanın sıra numarası (kalkan değilse sıfır veya eksi). */
    val shieldNumber: Int get() = ordinal - FIRST_SHIELD + 1

    /** Şeklin [r] yarıçaplı kapalı dış çizgisini [p]'ye kurar (önce sıfırlar) ve [p]'yi döndürür. */
    fun outline(p: GPath, r: Float): GPath {
        p.reset()
        when (this) {
            CIRCLE -> {
                p.arc(0f, 0f, r, r, 0f, 90f, false); p.arc(0f, 0f, r, r, 90f, 90f, true)
                p.arc(0f, 0f, r, r, 180f, 90f, true); p.arc(0f, 0f, r, r, 270f, 90f, true); p.close()
            }
            TRIANGLE -> roundedAbs(p, floatArrayOf(0f, 0.99f * r, -0.99f * r), floatArrayOf(-0.93f * r, 0.87f * r, 0.87f * r), 0.14f * r)
            SQUARE -> polygon(p, 4, r * 1.25f, -45f, 0.26f, 0f)
            HEXAGON -> polygon(p, 6, r, -90f, 0.16f, 0f)
            STAR -> star(p, r, 5, 1.01f, 0.606f, 0.08f)
            OCTAGON -> polygon(p, 8, r * 1.01747f, -22.5f, 0.20f, 0f)
            PENTAGON -> polygon(p, 5, r * 1.03f, -90f, 0.14f, r * 0.098f)
            RECTANGLE -> roundedAbs(p, floatArrayOf(-0.94f * r, 0.94f * r, 0.94f * r, -0.94f * r), floatArrayOf(-0.62f * r, -0.62f * r, 0.62f * r, 0.62f * r), 0.24f * r)
            DIAMOND -> roundedAbs(p, floatArrayOf(0f, 0.98f * r, 0f, -0.98f * r), floatArrayOf(-1.03f * r, 0f, 1.03f * r, 0f), 0.15f * r)
            FLOWER -> flower(p, r)
            STAR6 -> star(p, r, 6, 1.01f, 0.606f, 0.08f)
            INV_TRIANGLE -> roundedAbs(p, floatArrayOf(0f, 0.99f * r, -0.99f * r), floatArrayOf(0.93f * r, -0.87f * r, -0.87f * r), 0.14f * r)
            else -> ShieldData.outline(p, r, shieldNumber - 1)   // SHIELD_1 … SHIELD_25
        }
        return p
    }

    companion object {
        val DEFAULT = CIRCLE
        val FIRST_SHIELD: Int = SHIELD_1.ordinal

        fun byId(id: String?): OrbShape? = values().firstOrNull { it.id == id }

        /** Köşeleri yuvarlatılmış, düzgün [n] kenarlı çokgen. [t]: köşe yuvarlama payı (kenarın oranı). */
        private fun polygon(p: GPath, n: Int, radius: Float, startDeg: Float, t: Float, dy: Float) {
            val xs = FloatArray(n)
            val ys = FloatArray(n)
            for (i in 0 until n) {
                val a = (startDeg + 360f * i / n) * (PI / 180.0)
                xs[i] = (radius * cos(a)).toFloat()
                ys[i] = (radius * sin(a)).toFloat() + dy
            }
            rounded(p, xs, ys, t)
        }

        /** [points] köşeli yıldız: dış köşeler [outer]·r, iç köşeler [inner]·r uzakta, köşeler [t] oranında yuvarlanır. */
        private fun star(p: GPath, r: Float, points: Int, outer: Float, inner: Float, t: Float) {
            val n = points * 2
            val xs = FloatArray(n)
            val ys = FloatArray(n)
            for (i in 0 until n) {
                val a = (-90f + 360f * i / n) * (PI / 180.0)
                val rad = if (i % 2 == 0) r * outer else r * inner
                xs[i] = (rad * cos(a)).toFloat()
                ys[i] = (rad * sin(a)).toFloat()
            }
            rounded(p, xs, ys, t)
        }

        /** Beş yapraklı çiçek: yarıçap 0,80 ± 0,17 dalgalanır; bir yaprak yukarı bakar. */
        private fun flower(p: GPath, r: Float) {
            val n = 120
            for (i in 0 until n) {
                val th = 2.0 * PI * i / n
                val rad = r * (0.80f + 0.17f * cos(5.0 * (th + PI / 2.0)).toFloat())
                val x = (rad * cos(th)).toFloat(); val y = (rad * sin(th)).toFloat()
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            p.close()
        }

        /** Köşeleri, kenar uzunluğundan bağımsız sabit [d] uzunlukla yuvarlar (kenarın yarısını aşmaz). */
        private fun roundedAbs(p: GPath, xs: FloatArray, ys: FloatArray, d: Float) {
            val n = xs.size
            fun leg(i: Int, j: Int, out: FloatArray) {
                val dx = xs[j] - xs[i]; val dy = ys[j] - ys[i]
                val len = kotlin.math.sqrt(dx * dx + dy * dy)
                val k = minOf(d, len / 2f) / len
                out[0] = xs[i] + dx * k; out[1] = ys[i] + dy * k
            }
            val a = FloatArray(2); val b = FloatArray(2)
            for (i in 0 until n) {
                leg(i, (i + n - 1) % n, a); leg(i, (i + 1) % n, b)
                if (i == 0) p.moveTo(a[0], a[1]) else p.lineTo(a[0], a[1])
                p.quadTo(xs[i], ys[i], b[0], b[1])
            }
            p.close()
        }

        /** Her köşe, komşu kenarlar üzerinde [t] kadar içeriden başlayıp biten ikinci derece bir eğriyle yuvarlanır. */
        private fun rounded(p: GPath, xs: FloatArray, ys: FloatArray, t: Float) {
            val n = xs.size
            for (i in 0 until n) {
                val pr = (i + n - 1) % n
                val nx = (i + 1) % n
                val ax = xs[i] + (xs[pr] - xs[i]) * t
                val ay = ys[i] + (ys[pr] - ys[i]) * t
                val bx = xs[i] + (xs[nx] - xs[i]) * t
                val by = ys[i] + (ys[nx] - ys[i]) * t
                if (i == 0) p.moveTo(ax, ay) else p.lineTo(ax, ay)
                p.quadTo(xs[i], ys[i], bx, by)
            }
            p.close()
        }
    }
}

/**
 * Tema başına küre şekli. Ayarda "temaId=şekilId;…" olarak tutulur; kaydı olmayan tema küre kalır.
 * Bozuk ya da bilinmeyen girdiler atılır, en çok [MAX] kayıt tutulur.
 */
object OrbShapes {
    const val MAX = 24

    private fun okId(s: String) = s.isNotEmpty() && s.length <= 24 && s.all { it.isLetterOrDigit() || it == '_' || it == '-' }

    fun decode(s: String?): Map<String, OrbShape> {
        if (s.isNullOrBlank()) return emptyMap()
        val out = java.util.TreeMap<String, OrbShape>()
        for (part in s.split(';')) {
            val eq = part.indexOf('=')
            if (eq <= 0) continue
            val theme = part.substring(0, eq)
            val shape = OrbShape.byId(part.substring(eq + 1)) ?: continue
            if (okId(theme) && shape != OrbShape.DEFAULT && out.size < MAX) out[theme] = shape
        }
        return out
    }

    fun encode(m: Map<String, OrbShape>): String =
        m.entries.filter { okId(it.key) && it.value != OrbShape.DEFAULT }.sortedBy { it.key }.take(MAX)
            .joinToString(";") { it.key + "=" + it.value.id }

    fun get(s: String?, themeId: String): OrbShape = decode(s)[themeId] ?: OrbShape.DEFAULT

    /** [themeId] için şekli [shape] yapar; küre varsayılan olduğundan kaydı siler. */
    fun with(s: String, themeId: String, shape: OrbShape): String {
        val m = java.util.TreeMap(decode(s))
        if (shape == OrbShape.DEFAULT) m.remove(themeId) else if (okId(themeId)) m[themeId] = shape
        return encode(m)
    }
}
