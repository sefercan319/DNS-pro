package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Uygulamadaki tüm simgeler. 24x24'lük bir kutuda, çizgi tabanlı ve yuvarlak uçlu çizilir. */
enum class Icon {
    POWER, GEAR, BACK, STAR, CHECK, CLOSE, BOLT, LOCK, SHIELD, BLOCK, HEART, GLOBE,
    COPY, REFRESH, INFO, CHEVRON, WIFI, SIGNAL, SORT, LOG, MENU, PALETTE, BELL
}

object Icons {
    private val paths = HashMap<Icon, GPath>()

    private fun rad(deg: Double) = deg * PI / 180.0

    private fun build(icon: Icon): GPath {
        val p = GPath()
        when (icon) {
            Icon.POWER -> {
                p.moveTo(12f, 3.2f).lineTo(12f, 11.4f)
                p.arc(12f, 12.6f, 8f, 8f, -55f, 290f, false)
            }
            Icon.GEAR -> {
                val teeth = 8
                for (i in 0 until teeth) {
                    val base = i * 360.0 / teeth - 90.0
                    fun pt(offDeg: Double, r: Double): FloatArray {
                        val a = rad(base + offDeg)
                        return floatArrayOf((12 + r * cos(a)).toFloat(), (12 + r * sin(a)).toFloat())
                    }
                    val a = pt(-14.0, 6.9); val b = pt(-8.5, 9.4); val c = pt(8.5, 9.4); val d = pt(14.0, 6.9)
                    if (i == 0) p.moveTo(a[0], a[1]) else p.lineTo(a[0], a[1])
                    p.lineTo(b[0], b[1]).lineTo(c[0], c[1]).lineTo(d[0], d[1])
                }
                p.close()
                p.arc(12f, 12f, 3f, 3f, 0f, 360f, false).close()
            }
            Icon.BACK -> {
                p.moveTo(19f, 12f).lineTo(5f, 12f)
                p.moveTo(11f, 5.8f).lineTo(4.8f, 12f).lineTo(11f, 18.2f)
            }
            Icon.STAR -> {
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 9.6 else 4.2
                    val a = rad(-90.0 + i * 36.0)
                    val x = (12 + r * cos(a)).toFloat()
                    val y = (12.9 + r * sin(a)).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
            Icon.CHECK -> p.poly(5f, 12.6f, 10f, 17.4f, 19.4f, 7.2f)
            Icon.CLOSE -> {
                p.moveTo(6f, 6f).lineTo(18f, 18f)
                p.moveTo(18f, 6f).lineTo(6f, 18f)
            }
            Icon.BOLT -> p.poly(13.4f, 2.6f, 5.2f, 13.4f, 11.2f, 13.4f, 10.2f, 21.4f, 18.8f, 10.2f, 12.8f, 10.2f, closed = true)
            Icon.LOCK -> {
                p.roundRect(5.4f, 10.6f, 18.6f, 20.6f, 2.6f)
                p.moveTo(8.6f, 10.6f).lineTo(8.6f, 8f)
                p.arc(12f, 8f, 3.4f, 3.4f, 180f, 180f, true)
                p.lineTo(15.4f, 10.6f)
            }
            Icon.SHIELD -> {
                p.moveTo(12f, 3f).lineTo(19.5f, 6f).lineTo(19.5f, 11.8f)
                p.cubicTo(19.5f, 16.4f, 16.4f, 19.5f, 12f, 21.2f)
                p.cubicTo(7.6f, 19.5f, 4.5f, 16.4f, 4.5f, 11.8f)
                p.lineTo(4.5f, 6f).close()
                p.moveTo(8.6f, 12.1f).lineTo(11f, 14.5f).lineTo(15.6f, 9.6f)
            }
            Icon.BLOCK -> {
                p.arc(12f, 12f, 8.6f, 8.6f, 0f, 360f, false).close()
                p.moveTo(6f, 6f).lineTo(18f, 18f)
            }
            Icon.HEART -> {
                p.moveTo(12f, 20.4f)
                p.cubicTo(5.2f, 15.6f, 3f, 11.8f, 3f, 8.6f)
                p.cubicTo(3f, 5.9f, 5f, 4f, 7.4f, 4f)
                p.cubicTo(9.4f, 4f, 11f, 5.2f, 12f, 6.9f)
                p.cubicTo(13f, 5.2f, 14.6f, 4f, 16.6f, 4f)
                p.cubicTo(19f, 4f, 21f, 5.9f, 21f, 8.6f)
                p.cubicTo(21f, 11.8f, 18.8f, 15.6f, 12f, 20.4f)
                p.close()
            }
            Icon.GLOBE -> {
                p.arc(12f, 12f, 9f, 9f, 0f, 360f, false).close()
                p.arc(12f, 12f, 4.2f, 9f, 0f, 360f, false).close()
                p.moveTo(3f, 12f).lineTo(21f, 12f)
            }
            Icon.COPY -> {
                p.roundRect(9f, 9f, 19.6f, 19.6f, 2.6f)
                p.moveTo(15f, 9f).lineTo(15f, 6.8f)
                p.cubicTo(15f, 5.5f, 14.2f, 4.6f, 13f, 4.6f)
                p.lineTo(6.8f, 4.6f)
                p.cubicTo(5.5f, 4.6f, 4.6f, 5.5f, 4.6f, 6.8f)
                p.lineTo(4.6f, 13f)
                p.cubicTo(4.6f, 14.2f, 5.5f, 15f, 6.8f, 15f)
                p.lineTo(9f, 15f)
            }
            Icon.REFRESH -> {
                p.arc(12f, 12f, 7.6f, 7.6f, -40f, 280f, false)
                // Ok ucu: yayın bittiği noktada, teğet yönüne bakan "V"
                val end = rad(240.0)
                val tx = 12 + 7.6 * cos(end); val ty = 12 + 7.6 * sin(end)
                val dirx = -sin(end); val diry = cos(end)         // saat yönü teğeti
                for (s in doubleArrayOf(-1.0, 1.0)) {
                    val a = rad(Math.toDegrees(Math.atan2(diry, dirx)) + 180.0 + s * 38.0)
                    p.moveTo(tx.toFloat(), ty.toFloat())
                    p.lineTo((tx + 4.6 * cos(a)).toFloat(), (ty + 4.6 * sin(a)).toFloat())
                }
            }
            Icon.INFO -> {
                p.arc(12f, 12f, 9f, 9f, 0f, 360f, false).close()
                p.moveTo(12f, 11f).lineTo(12f, 16.6f)
            }
            Icon.CHEVRON -> p.poly(9f, 5f, 16f, 12f, 9f, 19f)
            Icon.WIFI -> {
                for (r in floatArrayOf(4.6f, 9.2f, 13.8f)) p.arc(12f, 18.6f, r, r, 225f, 90f, false)
            }
            Icon.SIGNAL -> {
                val xs = floatArrayOf(5f, 9.7f, 14.3f, 19f)
                val tops = floatArrayOf(16f, 12.4f, 8.8f, 5f)
                for (i in xs.indices) p.moveTo(xs[i], 20f).lineTo(xs[i], tops[i])
            }
            Icon.SORT -> {
                p.moveTo(4f, 7f).lineTo(20f, 7f)
                p.moveTo(4f, 12f).lineTo(15f, 12f)
                p.moveTo(4f, 17f).lineTo(10f, 17f)
            }
            Icon.MENU -> {
                p.moveTo(4.5f, 7f).lineTo(19.5f, 7f)
                p.moveTo(4.5f, 12f).lineTo(19.5f, 12f)
                p.moveTo(4.5f, 17f).lineTo(19.5f, 17f)
            }
            Icon.BELL -> {
                p.moveTo(5.8f, 17f).lineTo(18.2f, 17f).lineTo(17f, 15.4f).lineTo(17f, 10.8f)
                p.cubicTo(17f, 8f, 14.9f, 6f, 12f, 6f).cubicTo(9.1f, 6f, 7f, 8f, 7f, 10.8f)
                p.lineTo(7f, 15.4f).close()
                p.moveTo(12f, 6f).lineTo(12f, 4.2f)
                p.moveTo(10.2f, 19.6f).cubicTo(10.6f, 21.2f, 13.4f, 21.2f, 13.8f, 19.6f)
            }
            Icon.PALETTE -> {
                p.arc(12f, 12f, 9f, 9f, 0f, 360f, false).close()
                for ((x, y) in listOf(8f to 9.6f, 12f to 7.4f, 16f to 9.6f, 8.6f to 14.4f))
                    p.arc(x, y, 1.1f, 1.1f, 0f, 360f, false).close()
            }
            Icon.LOG -> {
                p.roundRect(5f, 3.6f, 19f, 20.4f, 2.8f)
                p.moveTo(8.8f, 9f).lineTo(15.2f, 9f)
                p.moveTo(8.8f, 12.6f).lineTo(15.2f, 12.6f)
                p.moveTo(8.8f, 16.2f).lineTo(12.6f, 16.2f)
            }
        }
        return p
    }

    fun path(icon: Icon): GPath = paths.getOrPut(icon) { build(icon) }

    /**
     * [icon]'u merkezi (cx, cy), kenarı [size] olacak şekilde çizer. [width] 24'lük kutudaki çizgi kalınlığıdır.
     * [fill] 0'dan farklıysa şekil o renkle doldurulur (ör. favori yıldızı). Nokta gerektiren simgelerin noktası da buradan gelir.
     */
    fun draw(g: Gfx, icon: Icon, cx: Float, cy: Float, size: Float, color: Int, width: Float = 2f, fill: Int = 0) {
        g.save()
        g.translate(cx - size / 2f, cy - size / 2f)
        g.scale(size / 24f, size / 24f)
        val p = path(icon)
        if (fill != 0) { g.paint(fill); g.path(p) }
        g.paint(color)
        g.strokeWidth(width)
        g.strokePath(p)
        when (icon) {
            Icon.INFO -> g.circle(12f, 7.6f, width * 0.62f)
            Icon.WIFI -> g.circle(12f, 18.9f, width * 0.78f)
            else -> {}
        }
        g.restore()
    }

    /** Sunucunun etiketlerinden satır simgesi: en ayırt edici etiket kazanır. */
    fun forTags(tags: Set<Tag>): Icon = when {
        Tag.FAMILY in tags -> Icon.HEART
        Tag.ADS in tags -> Icon.BLOCK
        Tag.SECURITY in tags -> Icon.SHIELD
        Tag.PRIVACY in tags -> Icon.LOCK
        Tag.FAST in tags -> Icon.BOLT
        else -> Icon.GLOBE
    }
}
