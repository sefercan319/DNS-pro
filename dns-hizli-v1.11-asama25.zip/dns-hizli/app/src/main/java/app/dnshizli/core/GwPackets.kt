package app.dnshizli.core

/**
 * Ağ geçidi için paket yardımcıları (IPv4 + IPv6, TCP + UDP). Android'e bağlı değildir.
 * Adresler 4 ya da 16 baytlık dizilerdir.
 */
internal object Gw {
    const val TCP = 6
    const val UDP = 17

    const val FIN = 0x01
    const val SYN = 0x02
    const val RST = 0x04
    const val PSH = 0x08
    const val ACK = 0x10

    /** Tünel MTU'su (servisle aynı) ve bundan çıkan en büyük TCP veri boyutu. */
    const val MTU = 1500
    const val MSS4 = MTU - 40
    const val MSS6 = MTU - 60

    fun sum(init: Long, b: ByteArray, off: Int, len: Int): Long {
        var s = init
        var i = off
        val end = off + len
        while (i + 1 < end) { s += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF); i += 2 }
        if (i < end) s += (b[i].toInt() and 0xFF) shl 8
        return s
    }

    fun fold(sum: Long): Int {
        var s = sum
        while (s ushr 16 != 0L) s = (s and 0xFFFF) + (s ushr 16)
        return s.toInt().inv() and 0xFFFF
    }

    private fun pseudo(src: ByteArray, dst: ByteArray, proto: Int, len: Int): Long {
        var s = sum(0, src, 0, src.size)
        s = sum(s, dst, 0, dst.size)
        return s + proto + len
    }

    private fun writeIp(out: ByteArray, v6: Boolean, src: ByteArray, dst: ByteArray, proto: Int, payload: Int): Int {
        if (!v6) {
            out[0] = 0x45; out[1] = 0
            Packets.put16(out, 2, 20 + payload)
            Packets.put16(out, 4, Packets.nextIdent())
            Packets.put16(out, 6, 0x4000)            // bölme yok (DF)
            out[8] = 64; out[9] = proto.toByte()
            out[10] = 0; out[11] = 0
            System.arraycopy(src, 0, out, 12, 4)
            System.arraycopy(dst, 0, out, 16, 4)
            Packets.put16(out, 10, checksum20(out))
            return 20
        }
        out[0] = 0x60; out[1] = 0; out[2] = 0; out[3] = 0
        Packets.put16(out, 4, payload)
        out[6] = proto.toByte(); out[7] = 64
        System.arraycopy(src, 0, out, 8, 16)
        System.arraycopy(dst, 0, out, 24, 16)
        return 40
    }

    private fun checksum20(b: ByteArray): Int = fold(sum(0, b, 0, 20))

    /** TCP segmenti yazar; toplam IP paket uzunluğunu döndürür. [mss] > 0 ise MSS seçeneği eklenir. */
    fun tcp(
        out: ByteArray, v6: Boolean, src: ByteArray, dst: ByteArray, sport: Int, dport: Int,
        seq: Int, ack: Int, flags: Int, win: Int, data: ByteArray?, dOff: Int, dLen: Int, mss: Int = 0,
    ): Int {
        val opt = if (mss > 0) 4 else 0
        val tcpLen = 20 + opt + dLen
        val ip = writeIp(out, v6, src, dst, TCP, tcpLen)
        val t = ip
        Packets.put16(out, t, sport); Packets.put16(out, t + 2, dport)
        Packets.put32(out, t + 4, seq); Packets.put32(out, t + 8, ack)
        out[t + 12] = (((20 + opt) / 4) shl 4).toByte()
        out[t + 13] = flags.toByte()
        Packets.put16(out, t + 14, win.coerceIn(0, 65535))
        out[t + 16] = 0; out[t + 17] = 0; out[t + 18] = 0; out[t + 19] = 0
        if (opt != 0) { out[t + 20] = 2; out[t + 21] = 4; Packets.put16(out, t + 22, mss) }
        if (dLen > 0 && data != null) System.arraycopy(data, dOff, out, t + 20 + opt, dLen)
        var s = pseudo(src, dst, TCP, tcpLen)
        s = sum(s, out, t, tcpLen)
        Packets.put16(out, t + 16, fold(s))
        return ip + tcpLen
    }

    fun udp(out: ByteArray, v6: Boolean, src: ByteArray, dst: ByteArray, sport: Int, dport: Int, data: ByteArray, dOff: Int, dLen: Int): Int {
        val udpLen = 8 + dLen
        val ip = writeIp(out, v6, src, dst, UDP, udpLen)
        Packets.put16(out, ip, sport); Packets.put16(out, ip + 2, dport)
        Packets.put16(out, ip + 4, udpLen); out[ip + 6] = 0; out[ip + 7] = 0
        System.arraycopy(data, dOff, out, ip + 8, dLen)
        var c = fold(pseudo(src, dst, UDP, udpLen).let { sum(it, out, ip, udpLen) })
        if (c == 0) c = 0xFFFF
        Packets.put16(out, ip + 6, c)
        return ip + udpLen
    }

    /** Alınan TCP/UDP paketinin sağlama toplamı doğru mu? (IPv4 başlığı da denetlenir.) */
    fun checksumOk(p: ByteArray, len: Int): Boolean {
        val v6 = (p[0].toInt() ushr 4) == 6
        val ip = if (v6) 40 else (p[0].toInt() and 0xF) * 4
        if (!v6 && fold(sum(0, p, 0, ip)) != 0) return false
        val proto = if (v6) p[6].toInt() and 0xFF else p[9].toInt() and 0xFF
        val l = if (v6) 40 + Packets.u16(p, 4) else Packets.u16(p, 2)
        if (l > len) return false
        val src = if (v6) p.copyOfRange(8, 24) else p.copyOfRange(12, 16)
        val dst = if (v6) p.copyOfRange(24, 40) else p.copyOfRange(16, 20)
        if (proto == UDP && Packets.u16(p, ip + 6) == 0 && !v6) return true
        return fold(sum(pseudo(src, dst, proto, l - ip), p, ip, l - ip)) == 0
    }

    fun seqLt(a: Int, b: Int) = (a - b) < 0
    fun seqLe(a: Int, b: Int) = (a - b) <= 0
}

/** Baştan tüketilen, sondan eklenen büyüyebilir bayt kuyruğu (sıfır kopya olmadan basit; tünel verisi için yeterli). */
internal class ByteQueue(private val cap: Int) {
    private var buf = ByteArray(0)
    private var head = 0
    var size = 0
        private set

    val free: Int get() = cap - size
    val isEmpty: Boolean get() = size == 0

    /** En çok [free] bayt ekler; eklenen sayıyı döndürür. */
    fun add(src: ByteArray, off: Int, len: Int): Int {
        val n = minOf(len, free)
        if (n <= 0) return 0
        if (head + size + n > buf.size) {
            if (head > 0 && size + n <= buf.size) {
                System.arraycopy(buf, head, buf, 0, size); head = 0
            } else {
                val nb = ByteArray(minOf(cap, maxOf(2048, (size + n) * 2)))
                System.arraycopy(buf, head, nb, 0, size)
                buf = nb; head = 0
            }
        }
        System.arraycopy(src, off, buf, head + size, n)
        size += n
        return n
    }

    /** Baştan [from] ofsetinden en çok [len] baytı [dst]'ye kopyalar. */
    fun copy(from: Int, dst: ByteArray, dOff: Int, len: Int): Int {
        val n = minOf(len, size - from)
        if (n <= 0) return 0
        System.arraycopy(buf, head + from, dst, dOff, n)
        return n
    }

    fun drop(n: Int) {
        val k = minOf(n, size)
        head += k; size -= k
        if (size == 0) head = 0
    }

    fun array(): ByteArray = buf
    fun start(): Int = head
    fun clear() { head = 0; size = 0 }
}
