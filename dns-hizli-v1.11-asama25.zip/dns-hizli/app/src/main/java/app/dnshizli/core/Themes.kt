package app.dnshizli.core

/** ARGB renk yardımcıları (Android'e bağlı değil, JVM'de test edilebilir). */
object Rgb {
    const val WHITE: Int = -1                       // 0xFFFFFFFF
    const val TRANSPARENT: Int = 0

    fun a(c: Int) = (c ushr 24) and 0xFF
    fun r(c: Int) = (c ushr 16) and 0xFF
    fun g(c: Int) = (c ushr 8) and 0xFF
    fun b(c: Int) = c and 0xFF

    fun argb(a: Int, r: Int, g: Int, b: Int): Int =
        (a.coerceIn(0, 255) shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    /** Rengin RGB'sini koruyup saydamlığını [alpha] (0..1) yapar. */
    fun alpha(c: Int, alpha: Float): Int =
        (c and 0x00FFFFFF) or ((alpha.coerceIn(0f, 1f) * 255f + 0.5f).toInt() shl 24)

    /** Rengin mevcut saydamlığını [k] ile çarpar. */
    fun scaleAlpha(c: Int, k: Float): Int = alpha(c, (a(c) / 255f) * k)

    fun lerp(x: Int, y: Int, t: Float): Int {
        val u = t.coerceIn(0f, 1f)
        fun m(p: Int, q: Int) = (p + (q - p) * u + 0.5f).toInt()
        return argb(m(a(x), a(y)), m(r(x), r(y)), m(g(x), g(y)), m(b(x), b(y)))
    }

    /** [top] rengini [bottom] üzerine koyar (standart alfa birleştirme). */
    fun over(top: Int, bottom: Int): Int {
        val ta = a(top) / 255.0
        val ba = a(bottom) / 255.0
        val ra = ta + ba * (1 - ta)
        if (ra <= 0.0) return 0
        fun ch(t: Int, b: Int) = ((t * ta + b * ba * (1 - ta)) / ra + 0.5).toInt()
        return argb((ra * 255 + 0.5).toInt(), ch(r(top), r(bottom)), ch(g(top), g(bottom)), ch(b(top), b(bottom)))
    }

    /** WCAG göreli parlaklık (opak renk varsayılır). */
    fun luminance(c: Int): Double {
        fun lin(v: Int): Double {
            val s = v / 255.0
            return if (s <= 0.03928) s / 12.92 else Math.pow((s + 0.055) / 1.055, 2.4)
        }
        return 0.2126 * lin(r(c)) + 0.7152 * lin(g(c)) + 0.0722 * lin(b(c))
    }

    /** WCAG kontrast oranı (1..21). */
    fun contrast(x: Int, y: Int): Double {
        val l1 = luminance(x)
        val l2 = luminance(y)
        return (maxOf(l1, l2) + 0.05) / (minOf(l1, l2) + 0.05)
    }

    /** RGB -> HSL (ton 0..360, doygunluk ve açıklık 0..1). */
    fun toHsl(c: Int): FloatArray {
        val r = r(c) / 255f
        val g = g(c) / 255f
        val b = b(c) / 255f
        val max = maxOf(r, g, b)
        val min = minOf(r, g, b)
        val l = (max + min) / 2f
        if (max == min) return floatArrayOf(0f, 0f, l)
        val d = max - min
        val s = if (l > 0.5f) d / (2f - max - min) else d / (max + min)
        val h = when (max) {
            r -> ((g - b) / d + (if (g < b) 6f else 0f))
            g -> ((b - r) / d + 2f)
            else -> ((r - g) / d + 4f)
        } * 60f
        return floatArrayOf(h, s, l)
    }

    /** HSL -> opak RGB. */
    fun fromHsl(h: Float, s: Float, l: Float): Int {
        val ss = s.coerceIn(0f, 1f)
        val ll = l.coerceIn(0f, 1f)
        val hh = ((h % 360f) + 360f) % 360f / 360f
        fun hue(p: Float, q: Float, t0: Float): Float {
            var t = t0
            if (t < 0f) t += 1f
            if (t > 1f) t -= 1f
            return when {
                t < 1f / 6f -> p + (q - p) * 6f * t
                t < 1f / 2f -> q
                t < 2f / 3f -> p + (q - p) * (2f / 3f - t) * 6f
                else -> p
            }
        }
        if (ss == 0f) { val v = (ll * 255f + 0.5f).toInt(); return argb(255, v, v, v) }
        val q = if (ll < 0.5f) ll * (1f + ss) else ll + ss - ll * ss
        val p = 2f * ll - q
        return argb(255, (hue(p, q, hh + 1f / 3f) * 255f + 0.5f).toInt(), (hue(p, q, hh) * 255f + 0.5f).toInt(), (hue(p, q, hh - 1f / 3f) * 255f + 0.5f).toInt())
    }
}

/**
 * Cam yüzeylerin dolgu şeffaflığı: kaydırıcı değeri [g] 0..1. Koyu temada cam rengi açık olduğu için
 * dolgu çok daha az opak tutulur (açık yazı okunaklı kalsın diye).
 */
object GlassMath {
    private const val DARK_SCALE = 0.20f
    fun top(g: Float, dark: Boolean = false): Float =
        (0.34f + (0.80f - 0.34f) * g.coerceIn(0f, 1f)) * (if (dark) DARK_SCALE else 1f)

    fun bottom(g: Float, dark: Boolean = false): Float =
        (0.22f + (0.52f - 0.22f) * g.coerceIn(0f, 1f)) * (if (dark) DARK_SCALE else 1f)
}

/**
 * Frutiger Aero renk teması: gökyüzü gradyanı, cam rengi, canlı vurgu rengi ve okunaklı metin renkleri.
 *  - accentLight/accent/accentDeep: sıvı, parıltı ve vurgular için canlı tonlar.
 *  - control/controlDeep: seçili düğme dolgusu; beyaz yazı bunların üzerinde okunur (>= 4.5:1).
 *  - text/textSoft/link: cam kartların üzerinde her cam yoğunluğunda >= 4.5:1 kontrast verir.
 */
class AeroTheme(
    val id: String,
    val dark: Boolean,
    val skyTop: Int,
    val skyMid: Int,
    val skyBottom: Int,
    val accentLight: Int,
    val accent: Int,
    val accentDeep: Int,
    val control: Int,
    val controlDeep: Int,
    val glow: Int,
    val text: Int,
    val textSoft: Int,
    val link: Int,
    val tint: Int,
    val shadow: Int,
) {
    val onControl: Int get() = Rgb.WHITE

    /** Etkin dildeki adı. */
    val name: String get() = L.tx.themeName(id)

    /**
     * Yüksek kontrast hali: ikincil yazı birincil kadar koyu (koyu temada açık), bağlantı rengi de yazı rengine yaklaşır.
     * Cam, sahnede tam opak çizilir ([Scene] cam değerini 1 yapar).
     */
    fun highContrast(): AeroTheme {
        val ink = if (dark) Rgb.WHITE else Rgb.lerp(text, 0xFF000000.toInt(), 0.45f)
        return AeroTheme(
            id = id, dark = dark, skyTop = skyTop, skyMid = skyMid, skyBottom = skyBottom,
            accentLight = accentLight, accent = accent, accentDeep = accentDeep,
            control = Rgb.lerp(control, 0xFF000000.toInt(), 0.18f), controlDeep = Rgb.lerp(controlDeep, 0xFF000000.toInt(), 0.18f),
            glow = glow, text = ink, textSoft = ink, link = if (dark) Rgb.WHITE else Rgb.lerp(link, 0xFF000000.toInt(), 0.35f),
            tint = tint, shadow = shadow,
        )
    }

    /** Gökyüzü gradyanındaki rengi [y] (0 üst, 1 alt) konumunda döner. */
    fun skyAt(y: Float): Int =
        if (y <= SKY_MID_POS) Rgb.lerp(skyTop, skyMid, y / SKY_MID_POS)
        else Rgb.lerp(skyMid, skyBottom, (y - SKY_MID_POS) / (1f - SKY_MID_POS))

    companion object {
        const val SKY_MID_POS = 0.55f

        /** İki tema arasında renk renk geçiş. [t]=0 -> a, [t]=1 -> b. */
        fun lerp(a: AeroTheme, b: AeroTheme, t: Float): AeroTheme {
            if (t <= 0f) return a
            if (t >= 1f) return b
            fun m(x: Int, y: Int) = Rgb.lerp(x, y, t)
            return AeroTheme(
                id = if (t < 0.5f) a.id else b.id,
                dark = if (t < 0.5f) a.dark else b.dark,
                skyTop = m(a.skyTop, b.skyTop), skyMid = m(a.skyMid, b.skyMid), skyBottom = m(a.skyBottom, b.skyBottom),
                accentLight = m(a.accentLight, b.accentLight), accent = m(a.accent, b.accent),
                accentDeep = m(a.accentDeep, b.accentDeep),
                control = m(a.control, b.control), controlDeep = m(a.controlDeep, b.controlDeep),
                glow = m(a.glow, b.glow), text = m(a.text, b.text), textSoft = m(a.textSoft, b.textSoft),
                link = m(a.link, b.link), tint = m(a.tint, b.tint), shadow = m(a.shadow, b.shadow),
            )
        }
    }
}

object Themes {
    const val AUTO_ID = "auto"

    private fun c(rgb: Int): Int = rgb or (0xFF shl 24)

    val aqua = AeroTheme(
        id = "aqua", dark = false,
        skyTop = c(0xDDF8FF), skyMid = c(0x9BE4F8), skyBottom = c(0x58BDEB),
        accentLight = c(0x7CF0E2), accent = c(0x19C6C0), accentDeep = c(0x0F8FB5),
        control = c(0x0B7E9B), controlDeep = c(0x08627E),
        glow = c(0x5FE3E8), text = c(0x06304A), textSoft = c(0x1F4A63), link = c(0x05526E),
        tint = Rgb.WHITE, shadow = c(0x0A4F7A),
    )

    val meadow = AeroTheme(
        id = "meadow", dark = false,
        skyTop = c(0xDFF7FF), skyMid = c(0xA9EBC4), skyBottom = c(0x62CF73),
        accentLight = c(0xB4F76A), accent = c(0x3DCC5A), accentDeep = c(0x1E9A4A),
        control = c(0x18813F), controlDeep = c(0x0F6A32),
        glow = c(0x8CF07A), text = c(0x0A3520), textSoft = c(0x244F36), link = c(0x0F5C2E),
        tint = Rgb.WHITE, shadow = c(0x0F6B3A),
    )

    val ocean = AeroTheme(
        id = "ocean", dark = false,
        skyTop = c(0xD6EEFF), skyMid = c(0x8EC3F8), skyBottom = c(0x5C97E8),
        accentLight = c(0x6FE0FF), accent = c(0x2B9DF5), accentDeep = c(0x1B62C9),
        control = c(0x1B62C9), controlDeep = c(0x154CA3),
        glow = c(0x6BC7FF), text = c(0x0A2547), textSoft = c(0x1F3E66), link = c(0x0C3A84),
        tint = Rgb.WHITE, shadow = c(0x1B4FA0),
    )

    val sunset = AeroTheme(
        id = "sunset", dark = false,
        skyTop = c(0xFFE9CC), skyMid = c(0xFFB59E), skyBottom = c(0xE88AB8),
        accentLight = c(0xFFD27A), accent = c(0xFF8A5B), accentDeep = c(0xD9487B),
        control = c(0xC23A68), controlDeep = c(0xA12C57),
        glow = c(0xFFB07A), text = c(0x3B1740), textSoft = c(0x5C2F58), link = c(0x82204A),
        tint = Rgb.WHITE, shadow = c(0x9A3A6A),
    )

    val lavender = AeroTheme(
        id = "lavender", dark = false,
        skyTop = c(0xF0E6FF), skyMid = c(0xC8B0F8), skyBottom = c(0x9A82E6),
        accentLight = c(0xD2B8FF), accent = c(0x9B6BF2), accentDeep = c(0x6D45D6),
        control = c(0x6B43D1), controlDeep = c(0x5532B0),
        glow = c(0xC4A6FF), text = c(0x2A1A55), textSoft = c(0x3C2D70), link = c(0x432596),
        tint = Rgb.WHITE, shadow = c(0x4B3A9A),
    )

    val coral = AeroTheme(
        id = "coral", dark = false,
        skyTop = c(0xFFEFE8), skyMid = c(0xFFC4B4), skyBottom = c(0xF2928A),
        accentLight = c(0xFFB59E), accent = c(0xFF7461), accentDeep = c(0xD8474F),
        control = c(0xB8333F), controlDeep = c(0x962634),
        glow = c(0xFF9E86), text = c(0x3D1216), textSoft = c(0x5E2A2E), link = c(0x8C1C2A),
        tint = Rgb.WHITE, shadow = c(0x9A3540),
    )

    val mint = AeroTheme(
        id = "mint", dark = false,
        skyTop = c(0xE8FFF7), skyMid = c(0xAEF0DC), skyBottom = c(0x62D3B6),
        accentLight = c(0x9EF7DE), accent = c(0x2CCBA0), accentDeep = c(0x14967A),
        control = c(0x0D7A62), controlDeep = c(0x0A624F),
        glow = c(0x72EFCB), text = c(0x07322A), textSoft = c(0x1D4B41), link = c(0x0A5746),
        tint = Rgb.WHITE, shadow = c(0x0D6A55),
    )

    val night = AeroTheme(
        id = "night", dark = true,
        skyTop = c(0x07122B), skyMid = c(0x0B2A55), skyBottom = c(0x0A4562),
        accentLight = c(0x8CF5E6), accent = c(0x2FD9C6), accentDeep = c(0x1197B5),
        control = c(0x0B7E9B), controlDeep = c(0x08627E),
        glow = c(0x37E0D0), text = c(0xEAF7FF), textSoft = c(0xC2DAEE), link = c(0x8CF5E6),
        tint = c(0xE4F2FF), shadow = c(0x000000),
    )

    /** Saf siyah gökyüzü: OLED ekranlarda en az pil harcar. */
    val amoled = AeroTheme(
        id = "amoled", dark = true,
        skyTop = c(0x000000), skyMid = c(0x000000), skyBottom = c(0x02121A),
        accentLight = c(0x8CF5E6), accent = c(0x2FD9C6), accentDeep = c(0x1197B5),
        control = c(0x0B7E9B), controlDeep = c(0x08627E),
        glow = c(0x37E0D0), text = c(0xEEF8FF), textSoft = c(0xC6DCEE), link = c(0x8CF5E6),
        tint = c(0xE4F2FF), shadow = c(0x000000),
    )

    /** Kiraz çiçeği: pembe-beyaz, yumuşak. */
    val sakura = AeroTheme(
        id = "sakura", dark = false,
        skyTop = c(0xFFF3F8), skyMid = c(0xFFD0E3), skyBottom = c(0xF2A3C6),
        accentLight = c(0xFFC4DC), accent = c(0xF0679F), accentDeep = c(0xC23A78),
        control = c(0xAD2F69), controlDeep = c(0x8F2456),
        glow = c(0xFF9DC6), text = c(0x3A0D26), textSoft = c(0x5A2443), link = c(0x8A1A52),
        tint = Rgb.WHITE, shadow = c(0x9A3A6A),
    )

    /** Bal: sıcak altın sarısı. */
    val honey = AeroTheme(
        id = "honey", dark = false,
        skyTop = c(0xFFF9E6), skyMid = c(0xFFE39A), skyBottom = c(0xF2BD55),
        accentLight = c(0xFFE07A), accent = c(0xF5A623), accentDeep = c(0xC27400),
        control = c(0x925400), controlDeep = c(0x784400),
        glow = c(0xFFD166), text = c(0x382400), textSoft = c(0x553A08), link = c(0x6E4200),
        tint = Rgb.WHITE, shadow = c(0x8A5A10),
    )

    /** Kuzey ışıkları: lacivert gökyüzünde yeşil-mor ışıltı (koyu). */
    val aurora = AeroTheme(
        id = "aurora", dark = true,
        skyTop = c(0x050A1C), skyMid = c(0x15204A), skyBottom = c(0x0B4A47),
        accentLight = c(0xA8FFD2), accent = c(0x3DDC97), accentDeep = c(0x1A9E78),
        control = c(0x11806A), controlDeep = c(0x0C6656),
        glow = c(0x5CF0B7), text = c(0xECFBF5), textSoft = c(0xC2E8DA), link = c(0x9EF5D0),
        tint = c(0xE2FFF4), shadow = c(0x000000),
    )

    val all: List<AeroTheme> = listOf(aqua, meadow, ocean, sunset, lavender, coral, mint, sakura, honey, night, amoled, aurora)

    /** Duvar kağıdı renginden üretilen tema (Android 12+); seçicide ayrıca gösterilir. */
    const val DYNAMIC_ID = "dynamic"

    fun isValidId(id: String): Boolean = id == AUTO_ID || id == DYNAMIC_ID || all.any { it.id == id }

    fun byId(id: String): AeroTheme? {
        val l = all
        for (i in 0 until l.size) { val t = l[i]; if (t.id == id) return t }
        return null
    }

    /** Kullanıcının seçimini ("auto" dahil) gerçek temaya çevirir. */
    fun resolve(id: String, systemDark: Boolean): AeroTheme =
        if (id == AUTO_ID) (if (systemDark) night else aqua) else (byId(id) ?: aqua)

    /**
     * Tam çözümleme: "auto" seçiliyse [autoLight] / [autoDark] (kullanıcının seçtiği açık ve koyu tema); "dynamic" ise
     * [seed] renginden üretilen tema (seed yoksa Aqua/Gece). Önbellekli: aynı girdiler için aynı nesne döner.
     */
    fun resolve(id: String, systemDark: Boolean, autoLight: String, autoDark: String, seed: Int?): AeroTheme {
        val pick = if (id == AUTO_ID) (if (systemDark) autoDark else autoLight) else id
        if (pick == DYNAMIC_ID) return dynamic(seed, systemDark)
        return byId(pick) ?: if (id == AUTO_ID) (if (systemDark) night else aqua) else aqua
    }

    private var dynKey = 0L
    private var dynTheme: AeroTheme? = null

    @Synchronized
    fun dynamic(seed: Int?, dark: Boolean): AeroTheme {
        if (seed == null) return if (dark) night else aqua
        val key = (seed.toLong() shl 1) or (if (dark) 1L else 0L)
        val cur = dynTheme
        if (cur != null && dynKey == key) return cur
        val t = fromSeed(seed, dark)
        dynKey = key; dynTheme = t
        return t
    }

    /**
     * Tek bir renkten (ör. duvar kağıdının vurgu rengi) okunaklı bir tema üretir. Renkler HSL'de türetilir; yazı,
     * soluk yazı, bağlantı ve düğme renkleri, [ThemeContrast] ile her cam yoğunluğunda en az 4,5:1 kontrast verene
     * kadar koyulaştırılır (koyu temada açılır). Gri bir renk bile geçerli bir tema verir.
     */
    fun fromSeed(seed: Int, dark: Boolean): AeroTheme {
        val hsl = Rgb.toHsl(seed or (0xFF shl 24))
        val h = hsl[0]
        val s = hsl[1].coerceIn(0f, 0.85f)
        val sky = if (dark) Triple(Rgb.fromHsl(h, s * 0.6f, 0.07f), Rgb.fromHsl(h, s * 0.6f, 0.15f), Rgb.fromHsl(h, s * 0.55f, 0.22f))
            else Triple(Rgb.fromHsl(h, s * 0.55f, 0.95f), Rgb.fromHsl(h, s * 0.65f, 0.82f), Rgb.fromHsl(h, s * 0.7f, 0.68f))
        val accentLight = Rgb.fromHsl(h, s, if (dark) 0.78f else 0.76f)
        val accent = Rgb.fromHsl(h, s, if (dark) 0.58f else 0.55f)
        val accentDeep = Rgb.fromHsl(h, s, if (dark) 0.40f else 0.38f)
        // Seçili düğme: beyaz yazı okunana kadar koyulaştır.
        var cl = 0.42f
        while (cl > 0.05f && Rgb.contrast(Rgb.WHITE, Rgb.fromHsl(h, s * 0.9f, cl)) < 4.7) cl -= 0.02f
        val control = Rgb.fromHsl(h, s * 0.9f, cl)
        val controlDeep = Rgb.fromHsl(h, s * 0.9f, maxOf(0.03f, cl - 0.07f))
        val tint = if (dark) Rgb.fromHsl(h, 0.35f, 0.94f) else Rgb.WHITE
        val shadow = if (dark) 0xFF000000.toInt() else Rgb.fromHsl(h, s * 0.6f, 0.30f)
        fun build(text: Int, soft: Int, link: Int) = AeroTheme(
            id = DYNAMIC_ID, dark = dark, skyTop = sky.first, skyMid = sky.second, skyBottom = sky.third,
            accentLight = accentLight, accent = accent, accentDeep = accentDeep, control = control, controlDeep = controlDeep,
            glow = Rgb.fromHsl(h, s, if (dark) 0.62f else 0.68f), text = text, textSoft = soft, link = link, tint = tint, shadow = shadow,
        )
        // Yazı renklerini kontrast tutana kadar ayarla (açık temada koyulaştır, koyu temada aç).
        fun fit(sat: Float, start: Float, ok: (Int) -> Boolean): Int {
            var l = start
            var c = Rgb.fromHsl(h, sat, l)
            var n = 0
            while (!ok(c) && n++ < 60) { l = if (dark) minOf(1f, l + 0.01f) else maxOf(0f, l - 0.01f); c = Rgb.fromHsl(h, sat, l) }
            return c
        }
        val probe = build(0, 0, 0)
        val text = fit(minOf(s, 0.6f) * 0.8f, if (dark) 0.90f else 0.17f) { ThemeContrast.minOnCards(probe, it) >= 4.7 && ThemeContrast.minOnSky(probe, it) >= 4.7 }
        val soft = fit(minOf(s, 0.6f) * 0.6f, if (dark) 0.82f else 0.27f) { ThemeContrast.minOnCards(probe, it) >= 4.7 }
        val link = fit(s * 0.9f, if (dark) 0.78f else 0.28f) { ThemeContrast.minOnCards(probe, it) >= 4.7 }
        return build(text, soft, link)
    }

    /** "Gece temasını saate bağla": 22:00–07:00 arası gece sayılır. */
    fun isNightHour(hour: Int): Boolean = NightHours.H22_07.isNight(hour)
}

/**
 * Bir temanın okunabilirlik ölçüleri (WCAG kontrastı): yazıların cam kartların (her cam yoğunluğunda, gökyüzünün
 * farklı yüksekliklerinde) ve gökyüzünün üzerinde aldığı en düşük kontrast. Testler ve dinamik tema üreticisi kullanır.
 */
object ThemeContrast {
    private val glass = floatArrayOf(0f, 0.55f, 1f)
    private val ys = floatArrayOf(0.3f, 0.45f, 0.6f, 0.75f, 0.9f, 1.0f)
    private val skyYs = floatArrayOf(0.04f, 0.15f, 0.3f, 0.45f, 0.6f)

    /** [color] yazısının tüm cam kartlar üzerindeki en düşük kontrastı. */
    fun minOnCards(t: AeroTheme, color: Int): Double {
        var worst = 99.0
        for (g in glass) for (y in ys) for (top in booleanArrayOf(true, false)) {
            val a = if (top) GlassMath.top(g, t.dark) else GlassMath.bottom(g, t.dark)
            val card = Rgb.over(Rgb.alpha(t.tint, a), t.skyAt(y))
            worst = minOf(worst, Rgb.contrast(color, card))
        }
        return worst
    }

    /** [color] yazısının gökyüzünün üst kısmındaki en düşük kontrastı (başlık, küre altı yazıları). */
    fun minOnSky(t: AeroTheme, color: Int): Double = skyYs.minOf { Rgb.contrast(color, t.skyAt(it)) }

    /** Seçili düğmedeki beyaz yazının en düşük kontrastı. */
    fun onControl(t: AeroTheme): Double = minOf(Rgb.contrast(t.onControl, t.control), Rgb.contrast(t.onControl, t.controlDeep))

    /** Tüm kurallar sağlanıyor mu (>= 4,5:1)? */
    fun ok(t: AeroTheme): Boolean =
        minOnCards(t, t.text) >= 4.5 && minOnCards(t, t.textSoft) >= 4.5 && minOnCards(t, t.link) >= 4.5 &&
            minOnSky(t, t.text) >= 4.5 && onControl(t) >= 4.5
}
