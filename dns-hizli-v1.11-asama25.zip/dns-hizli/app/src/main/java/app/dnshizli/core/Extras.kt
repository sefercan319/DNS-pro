package app.dnshizli.core

/** Android "Özel DNS" ayarı. */
enum class PrivateDns { OFF, AUTO, STRICT }

/**
 * Sorun gidericinin telefondan okuduğu durum. Bilinmeyen (okunamayan) değer null olur ve ilgili satır gösterilmez.
 * [online]: etkin ağda doğrulanmış internet var mı. [otherVpn]: bu uygulamadan başka bir VPN ağı var mı.
 */
class NetCheck(val permission: Boolean?, val online: Boolean?, val otherVpn: Boolean?, val privateDns: PrivateDns?)

/** Sorun gidericinin sonucu: bilgi paneli paragrafları ve uyarı sayısı. */
object Troubleshoot {
    class Report(val paragraphs: List<String>, val problems: Int)

    /** Tamam satırı "• ", uyarı satırı "! " ile başlar (yazı tipine bağlı simge kullanılmaz). */
    fun report(c: NetCheck, vpnActive: Boolean): Report {
        val lines = ArrayList<String>()
        var bad = 0
        fun add(ok: Boolean?, title: String, okText: String, badText: String) {
            if (ok == null) return
            if (!ok) bad++
            lines.add((if (ok) "• " else "! ") + title + ": " + (if (ok) okText else badText))
        }
        val t = L.tx
        add(c.online, t.T_NET, t.NET_OK, t.NET_BAD)
        add(c.permission, t.T_PERM, t.PERM_OK, t.PERM_BAD)
        // Bizim tünelimiz açıkken başka bir VPN ağı görünmesi bizim ağımızdır: o durumda denetlenmez.
        if (!vpnActive) add(c.otherVpn?.not(), t.T_VPN, t.VPN_OK, t.VPN_BAD)
        add(c.privateDns?.let { it != PrivateDns.STRICT }, t.T_DNS, t.PDNS_OK, t.PDNS_BAD)
        val head = if (bad == 0) t.TROUBLE_ALL_OK else t.TROUBLE_SOME
        return Report(listOf(head) + lines, bad)
    }
}

/** Sunucu listesi araması (ad, marka, sahip, adresler ve şifreli adlar içinde, büyük/küçük harf ayırmaz). */
object ServerSearch {
    const val MAX = 24

    fun clean(q: String): String = q.trim().replace(Regex("\\s+"), " ").take(MAX)

    fun matches(s: DnsServer, query: String): Boolean {
        val q = clean(query).lowercase()
        if (q.isEmpty()) return true
        val hay = listOfNotNull(s.name, s.brand, s.owner, s.primary, s.secondary, s.dot, s.doh)
        return hay.any { it.lowercase().contains(q) }
    }

    fun filter(list: List<DnsServer>, query: String): List<DnsServer> =
        if (clean(query).isEmpty()) list else list.filter { matches(it, query) }
}

/** Paylaşılacak ölçüm sonuçları metni: yalnızca hazır katalogdaki sunucular (kendi eklediklerin paylaşılmaz). */
object ResultsText {
    /** Boşsa (ölçüm yok) null. */
    fun build(head: String, servers: List<DnsServer>, latencies: Map<String, Latency>): String? {
        val rows = servers.filter { !it.custom }
            .mapNotNull { s -> latencies[s.id]?.ms?.let { s to it } }
            .sortedBy { it.second }
        if (rows.isEmpty()) return null
        val sb = StringBuilder(head)
        for ((i, r) in rows.withIndex()) sb.append('\n').append(i + 1).append(". ").append(r.first.name).append(" — ").append(r.second).append(" ms")
        return sb.toString()
    }
}
