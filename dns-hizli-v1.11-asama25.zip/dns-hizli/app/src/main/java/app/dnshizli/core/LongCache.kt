package app.dnshizli.core

/**
 * Long anahtarlı küçük önbellek. HashMap<Long, T> her aramada anahtarı kutular ve çöp üretir; çizim kodu
 * her karede yüzlerce arama yaptığı için burada anahtar kutulanmaz. Doluysa tamamen boşaltılır (basit ve
 * yeterli: boyutlar sınırlı sayıda değişir). İş parçacığı güvenli değildir; yalnızca arayüz iş parçacığı kullanır.
 */
class LongCache<T : Any>(private val maxEntries: Int) {
    private val cap: Int
    private val mask: Int
    private val keys: LongArray
    private val vals: Array<Any?>
    private var n = 0

    init {
        var c = 8
        while (c < maxEntries * 2) c = c shl 1
        cap = c
        mask = c - 1
        keys = LongArray(c)
        vals = arrayOfNulls(c)
    }

    val size: Int get() = n

    private fun slot(key: Long): Int = (((key * -7046029254386353131L) ushr 36).toInt()) and mask

    @Suppress("UNCHECKED_CAST")
    operator fun get(key: Long): T? {
        var i = slot(key)
        while (true) {
            val v = vals[i] ?: return null
            if (keys[i] == key) return v as T
            i = (i + 1) and mask
        }
    }

    /** [key] için değer yoksa ekler; varsa değiştirir. */
    operator fun set(key: Long, value: T) {
        if (n >= maxEntries) clear()
        var i = slot(key)
        while (true) {
            if (vals[i] == null) { keys[i] = key; vals[i] = value; n++; return }
            if (keys[i] == key) { vals[i] = value; return }
            i = (i + 1) and mask
        }
    }

    fun clear() {
        java.util.Arrays.fill(vals, null)
        n = 0
    }
}
