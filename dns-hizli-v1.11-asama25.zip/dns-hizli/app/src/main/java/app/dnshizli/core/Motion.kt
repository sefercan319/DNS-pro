package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

/** Animasyon eğrileri. Hepsi 0..1 aralığını 0..1'e eşler. */
object Easing {
    fun clamp01(t: Float): Float = if (t < 0f) 0f else if (t > 1f) 1f else t

    fun outCubic(t: Float): Float {
        val u = 1f - clamp01(t)
        return 1f - u * u * u
    }

    fun inOutCubic(t: Float): Float {
        val x = clamp01(t)
        return if (x < 0.5f) 4f * x * x * x else 1f - (-2f * x + 2f).pow(3) / 2f
    }

    /** Hafif geri sekmeli çıkış (düğme bırakma hissi). */
    fun outBack(t: Float, s: Float = 1.2f): Float {
        val x = clamp01(t) - 1f
        return 1f + (s + 1f) * x * x * x + s * x * x
    }

    /** Çok hızlı başlayıp uzun süre yavaşça oturan çıkış (sıvı his). */
    fun outExpo(t: Float): Float { val x = clamp01(t); return if (x >= 1f) 1f else 1f - 2f.pow(-10f * x) }

    fun outQuint(t: Float): Float { val u = 1f - clamp01(t); return 1f - u * u * u * u * u }

    /** Ucları sıfır eğimli yumuşak geçiş (Perlin'in smootherstep'i). */
    fun smooth(t: Float): Float { val x = clamp01(t); return x * x * x * (x * (x * 6f - 15f) + 10f) }

    /** Hedefi aşıp sönümlenerek titreyen çıkış (yaylı his). */
    fun outElastic(t: Float): Float {
        val x = clamp01(t)
        if (x <= 0f) return 0f
        if (x >= 1f) return 1f
        return 2f.pow(-10f * x) * sin((x * 10f - 0.75f) * (2f * PI.toFloat() / 3f)) + 1f
    }

    /** Zemine düşüp sekerek duran çıkış. */
    fun outBounce(t: Float): Float {
        var x = clamp01(t)
        val n = 7.5625f
        val d = 2.75f
        return when {
            x < 1f / d -> n * x * x
            x < 2f / d -> { x -= 1.5f / d; n * x * x + 0.75f }
            x < 2.5f / d -> { x -= 2.25f / d; n * x * x + 0.9375f }
            else -> { x -= 2.625f / d; n * x * x + 0.984375f }
        }
    }

    /**
     * CSS cubic-bezier(x1, y1, x2, y2) eğrisi: x'e göre t'yi Newton yöntemiyle çözer. Bellek ayırmaz.
     * Örnek: bezier(0.2f, 0f, 0f, 1f, t) = "standart" malzeme eğrisi.
     */
    fun bezier(x1: Float, y1: Float, x2: Float, y2: Float, x: Float): Float {
        val xx = clamp01(x)
        if (xx <= 0f || xx >= 1f) return xx
        fun cx(t: Float) = 3f * x1 * t * (1f - t) * (1f - t) + 3f * x2 * t * t * (1f - t) + t * t * t
        fun cy(t: Float) = 3f * y1 * t * (1f - t) * (1f - t) + 3f * y2 * t * t * (1f - t) + t * t * t
        var t = xx
        for (i in 0 until 6) {
            val e = cx(t) - xx
            if (abs(e) < 1e-4f) break
            val d = 3f * x1 * (1f - t) * (1f - t) + 6f * (x2 - x1) * t * (1f - t) + 3f * (1f - x2) * t * t
            if (abs(d) < 1e-5f) break
            t = (t - e / d).coerceIn(0f, 1f)
        }
        // Newton yetmediyse ikiye bölerek yakınsa
        if (abs(cx(t) - xx) > 1e-3f) {
            var lo = 0f; var hi = 1f
            for (i in 0 until 18) { t = (lo + hi) / 2f; if (cx(t) < xx) lo = t else hi = t }
        }
        return cy(t)
    }
}

/**
 * Yay (kütle-yay-sönümleyici) ayarı: [stiffness] sertlik, [damping] sönüm. Sönüm oranı = damping / (2·√stiffness):
 * 1 ve üstü geri sekmeden oturur, altında hedefi aşıp sallanır. Birim kütle, hedefe uzaklık 1 = tam hareket.
 */
class SpringSpec(@JvmField val stiffness: Float, @JvmField val damping: Float) {
    val dampingRatio: Float get() = damping / (2f * kotlin.math.sqrt(stiffness))

    companion object {
        /** Hızlı, neredeyse sekmeden oturan (anahtarlar, çipler). */
        val SNAP = SpringSpec(620f, 38f)
        /** Yumuşak ve sakin (sayfa, panel). */
        val SOFT = SpringSpec(240f, 25f)
        /** Hafif geri sekme (Aero, Eco). */
        val BOUNCY = SpringSpec(420f, 17f)
        /** Belirgin zıplama (Y2K). */
        val JELLY = SpringSpec(520f, 15f)
        /** Ağır, kararlı (Metro). */
        val CRISP = SpringSpec(900f, 60f)
        /** Basma anı: çabuk iner. */
        val DOWN = SpringSpec(1100f, 52f)
    }
}

/** Arka plandaki yükselen kabarcıklar. Koordinatlar 0..1 (y: 0 üst, 1 alt), yarıçap ve salınım dp cinsinden. */
class BubbleField(seed: Long = 11L) {
    class Bubble {
        var x = 0f
        var y = 0f
        var r = 0f
        var speed = 0f
        var phase = 0f
        var sway = 0f
        var alpha = 1f
    }

    private val rnd = java.util.Random(seed)
    private val list = ArrayList<Bubble>()
    val items: List<Bubble> get() = list

    /** Davranış: RISE kabarcık (varsayılan), FALL yaprak gibi süzülerek düşen, TWINKLE yerinde parlayıp sönen. */
    var mode: ParticleMode = ParticleMode.RISE
        private set

    fun setMode(m: ParticleMode) {
        if (m == mode) return
        mode = m
        for (b in list) reset(b, initial = true)
    }

    fun setCount(n: Int) {
        while (list.size > n) list.removeAt(list.size - 1)
        while (list.size < n) list.add(Bubble().also { reset(it, initial = true) })
    }

    private fun reset(b: Bubble, initial: Boolean) {
        when (mode) {
            ParticleMode.FALL -> {
                b.x = rnd.nextFloat()
                b.y = if (initial) rnd.nextFloat() else -0.08f - rnd.nextFloat() * 0.25f
                b.r = 7f + rnd.nextFloat() * 9f
                b.speed = 0.020f + rnd.nextFloat() * 0.030f
                b.phase = rnd.nextFloat() * (2f * PI.toFloat())
                b.sway = 14f + rnd.nextFloat() * 22f
                b.alpha = 0.55f + rnd.nextFloat() * 0.45f
                return
            }
            ParticleMode.TWINKLE -> {
                b.x = rnd.nextFloat()
                b.y = rnd.nextFloat()
                b.r = 3.5f + rnd.nextFloat() * rnd.nextFloat() * 9f
                b.speed = 0.6f + rnd.nextFloat() * 1.0f          // parıltı hızı (evre ilerlemesi)
                b.phase = rnd.nextFloat() * (2f * PI.toFloat())
                b.sway = 0f
                b.alpha = 0.6f + rnd.nextFloat() * 0.4f
                return
            }
            else -> {}
        }
        b.x = rnd.nextFloat()
        b.y = if (initial) rnd.nextFloat() else 1.06f + rnd.nextFloat() * 0.25f
        b.r = 5f + rnd.nextFloat() * rnd.nextFloat() * 30f      // çoğu küçük, birkaçı büyük
        b.speed = 0.018f + rnd.nextFloat() * 0.04f
        b.phase = rnd.nextFloat() * (2f * PI.toFloat())
        b.sway = 4f + rnd.nextFloat() * 10f
        b.alpha = 0.5f + rnd.nextFloat() * 0.5f
    }

    fun update(dtSec: Float, speedScale: Float = 1f) {
        val dt = dtSec.coerceIn(0f, 0.1f)
        var i = 0
        if (mode == ParticleMode.FALL) {
            while (i < list.size) {
                val b = list[i++]
                b.y += b.speed * speedScale * dt
                b.phase += dt * 0.7f
                if (b.y > 1.1f) reset(b, initial = false)
            }
            return
        }
        if (mode == ParticleMode.TWINKLE) {
            while (i < list.size) { val b = list[i++]; b.phase += dt * b.speed }
            return
        }
        while (i < list.size) {
            val b = list[i++]
            b.y -= b.speed * speedScale * dt
            b.phase += dt * 0.9f
            if (b.y < -0.12f) reset(b, initial = false)
        }
    }
}

enum class OrbState { OFF, CONNECTING, ON, ERROR }

object OrbMath {
    /** Küre içindeki sıvı seviyesi hedefi (0..1). */
    fun targetLevel(s: OrbState): Float = when (s) {
        OrbState.OFF -> 0f
        OrbState.CONNECTING -> 0.40f
        OrbState.ON -> 0.66f
        OrbState.ERROR -> 0.10f
    }

    /** Hedefe üstel yaklaşım: kare hızından bağımsız, asla aşmaz. */
    fun approach(current: Float, target: Float, dtSec: Float, rate: Float = 5f): Float =
        current + (target - current) * (1f - exp(-rate * dtSec.coerceAtLeast(0f)))

    fun settled(current: Float, target: Float): Boolean = abs(current - target) < 0.002f

    /**
     * Sıvı dalgasının hız çarpanı, bağlı sunucunun ortalama gecikmesine ([ms]) göre: hızlıda canlı (en çok 1,45),
     * yavaşta ağır (en az 0,55). Gecikme bilinmiyorsa (≤ 0) 1.
     */
    fun waveSpeed(ms: Int): Float = if (ms <= 0) 1f else (1.45f - ms / 220f).coerceIn(0.55f, 1.45f)

    /** Sıvıya karışan hız tonu: hızlıda yeşil, yavaşta turuncu. */
    fun tintColor(ms: Int): Int = if (ms <= 60) 0xFF3DDC84.toInt() else 0xFFFF9800.toInt()

    /**
     * Hız tonunun oranı (0..0.45): 60 ms'ye kadar hafif yeşil (hızlandıkça artar), 60–80 ms arası ton yok (temanın
     * kendi rengi), 80 ms'den sonra turuncu gitgide belirginleşir. Gecikme bilinmiyorsa (≤ 0) 0.
     */
    fun tintAmount(ms: Int): Float = when {
        ms <= 0 -> 0f
        ms < 60 -> 0.22f * (1f - ms / 60f)
        ms <= 80 -> 0f
        else -> ((ms - 80) / 120f * 0.45f).coerceIn(0f, 0.45f)
    }

    /** Sıvı yüzeyindeki dalga: [x01] 0..1 genişlik konumu, dönüş -amp..amp. */
    fun wave(x01: Float, phase: Float, amp: Float): Float =
        amp * sin((2.0 * PI * 1.5 * x01 + phase).toFloat())
}
