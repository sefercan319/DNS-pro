package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin

/** Ses olayları. İlk beşi arayüz sesidir, ötekiler bağlantı sesidir ([isConnection]). */
enum class Sfx(val isConnection: Boolean) {
    TAP(false), TOGGLE_ON(false), TOGGLE_OFF(false), BACK(false), SHEET(false),
    CONNECT(true), DISCONNECT(true), ERROR(true), DONE(true),
}

/** Ses tınısı (enstrüman). Hepsi kodla sentezlenir; dosya ya da ek boyut yoktur. */
enum class Voice { BUBBLE, GLASS, CLICK, WOOD, PIXEL, AIR }

/**
 * Ses efekti sentezleyici. Saf Kotlin: Android'e dokunmaz, bu yüzden bilgisayarda sınanır. Çıktı 16 bit mono PCM'dir;
 * tepe genliği olaya göre sabitlenmiştir (arayüz sesleri kısık, bağlantı sesleri biraz daha belirgin), uçları sıfıra
 * iner (tıkırtı yok), en çok [MAX_SEC] sürer. Ses seviyesi çalma anında verilir; bu yüzden aynı dizi yeniden kullanılır.
 */
object Synth {
    const val RATE = 22050
    const val MAX_SEC = 0.9f

    /** Ayarlardaki paket ve görünüm stilinden tınıyı seç. */
    fun voiceFor(pack: SoundPack, style: UiStyle): Voice = when (pack) {
        SoundPack.SOFT -> Voice.WOOD
        SoundPack.GLASS -> Voice.GLASS
        SoundPack.CLASSIC -> Voice.CLICK
        SoundPack.AUTO -> when (style) {
            UiStyle.AQUA -> Voice.BUBBLE
            UiStyle.AERO -> Voice.GLASS
            UiStyle.METRO -> Voice.CLICK
            UiStyle.ECO -> Voice.WOOD
            UiStyle.Y2K -> Voice.PIXEL
            UiStyle.AURORA -> Voice.AIR
        }
    }

    /** Bir nota: [hz] frekans, [at] başlangıç (sn), [len] süre (sn), [gain] bağıl ses. */
    private class Note(val hz: Float, val at: Float, val len: Float, val gain: Float = 1f)

    private fun n(hz: Float, at: Float, len: Float, gain: Float = 1f) = Note(hz, at, len, gain)

    // Notalar (Hz)
    private const val G4 = 392f; private const val A4 = 440f; private const val C5 = 523.25f; private const val E5 = 659.25f
    private const val F4 = 349.23f
    private const val G5 = 783.99f; private const val C6 = 1046.5f; private const val E6 = 1318.5f; private const val G6 = 1568f

    private fun notes(e: Sfx): List<Note> = when (e) {
        Sfx.TAP -> listOf(n(C6, 0f, 0.05f))
        Sfx.TOGGLE_ON -> listOf(n(G5, 0f, 0.05f), n(C6, 0.05f, 0.08f))
        Sfx.TOGGLE_OFF -> listOf(n(C6, 0f, 0.05f), n(G5, 0.05f, 0.08f))
        Sfx.BACK -> listOf(n(G5, 0f, 0.07f, 0.9f))
        Sfx.SHEET -> listOf(n(E5, 0f, 0.05f, 0.8f), n(G5, 0.04f, 0.07f))
        Sfx.CONNECT -> listOf(n(C5, 0f, 0.12f), n(E5, 0.085f, 0.12f), n(G5, 0.17f, 0.14f), n(C6, 0.255f, 0.40f))
        Sfx.DISCONNECT -> listOf(n(G5, 0f, 0.10f), n(E5, 0.075f, 0.10f), n(C5, 0.15f, 0.26f))
        Sfx.ERROR -> listOf(n(A4, 0f, 0.13f), n(F4, 0.11f, 0.30f))
        Sfx.DONE -> listOf(n(E6, 0f, 0.09f, 0.8f), n(G6, 0.075f, 0.22f))
    }

    /** Olay başına hedef tepe genliği (0..1). */
    private fun peak(e: Sfx): Float = if (e.isConnection) 0.80f else 0.55f

    /** [e] olayını [v] tınısıyla üret. Aynı girdi her zaman aynı diziyi verir. */
    fun render(e: Sfx, v: Voice): ShortArray {
        val list = notes(e)
        var end = 0f
        for (nt in list) end = maxOf(end, nt.at + nt.len + tail(v))
        val total = (minOf(end, MAX_SEC) * RATE).toInt().coerceAtLeast(64)
        val buf = FloatArray(total)
        for (nt in list) voiceNote(buf, v, nt)
        // 1 kutuplu alçak geçiren: sertliği alır (kulak yormasın). PIXEL ve CLICK biraz daha parlak kalır.
        val a = when (v) { Voice.PIXEL -> 0.55f; Voice.CLICK -> 0.6f; else -> 0.8f }
        var y = 0f
        for (i in buf.indices) { y += a * (buf[i] - y); buf[i] = y }
        // tepe sabitle
        var mx = 0f
        for (x in buf) mx = maxOf(mx, abs(x))
        val k = if (mx > 1e-6f) peak(e) / mx else 0f
        // uçlarda yumuşak giriş (2 ms) ve çıkış (son %12, en az 6 ms)
        val fin = (0.002f * RATE).toInt().coerceAtLeast(1)
        val fout = maxOf((0.006f * RATE).toInt(), (total * 0.12f).toInt()).coerceAtMost(total)
        val out = ShortArray(total)
        for (i in 0 until total) {
            var g = k
            if (i < fin) g *= i.toFloat() / fin
            if (i >= total - fout) g *= (total - 1 - i).toFloat() / fout
            out[i] = (buf[i] * g * 32767f).toInt().coerceIn(-32767, 32767).toShort()
        }
        return out
    }

    /** Notanın bittikten sonra kalan sönüm payı (sn). */
    private fun tail(v: Voice): Float = when (v) {
        Voice.GLASS -> 0.13f; Voice.AIR -> 0.14f; Voice.WOOD -> 0.07f; Voice.BUBBLE -> 0.05f; Voice.CLICK -> 0.02f; Voice.PIXEL -> 0.03f
    }

    private fun voiceNote(buf: FloatArray, v: Voice, nt: Note) {
        val start = (nt.at * RATE).toInt()
        val len = ((nt.len + tail(v)) * RATE).toInt()
        val tau = when (v) {
            Voice.GLASS -> 0.075f; Voice.AIR -> 0.12f; Voice.WOOD -> 0.035f; Voice.BUBBLE -> 0.04f; Voice.CLICK -> 0.012f; Voice.PIXEL -> 0.05f
        }
        val atk = when (v) { Voice.AIR -> 0.014f; Voice.GLASS -> 0.002f; else -> 0.003f }
        var phase = 0f
        var phase2 = 0f
        for (i in 0 until len) {
            val idx = start + i
            if (idx >= buf.size) break
            val t = i.toFloat() / RATE
            val env = (if (t < atk) t / atk else 1f) * exp(-t / tau)
            // BUBBLE: perde ilk 40 ms'de ×1,5'e süzülür ("blup")
            val f = if (v == Voice.BUBBLE) nt.hz * (1f + 0.5f * (1f - exp(-t / 0.018f))) else nt.hz
            phase += (2f * PI.toFloat()) * f / RATE
            val s = when (v) {
                Voice.BUBBLE -> sin(phase)
                Voice.GLASS -> {
                    phase2 += (2f * PI.toFloat()) * f * 2.76f / RATE
                    sin(phase) + 0.35f * sin(phase2) * exp(-t / 0.03f) + 0.12f * sin(phase * 5.4f) * exp(-t / 0.015f)
                }
                Voice.CLICK -> {
                    val click = if (i < 40) (if ((i * 7 + 3) % 4 < 2) 0.9f else -0.9f) * (1f - i / 40f) else 0f   // sabit "gürültü" kırıntısı
                    0.6f * sin(phase * 0.5f) + 0.5f * click
                }
                Voice.WOOD -> sin(phase) + 0.45f * sin(phase * 4f) * exp(-t / 0.012f)
                Voice.PIXEL -> {
                    val p = phase / (2f * PI.toFloat())
                    val fr = p - kotlin.math.floor(p)
                    (if (fr < 0.25f) 1.5f else -0.5f) * 0.6f
                }
                Voice.AIR -> {
                    phase2 += (2f * PI.toFloat()) * (f + 3f) / RATE
                    0.6f * sin(phase) + 0.6f * sin(phase2)
                }
            }
            buf[idx] += s * env * nt.gain
        }
    }
}
