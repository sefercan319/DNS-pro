package app.dnshizli.core

import kotlin.math.max
import kotlin.math.min

/**
 * Kullanıcının seçtiği arka plan fotoğrafı: ekranı kaplayacak biçimde hazırlanmış, platformun kendi görüntü nesnesini
 * ([handle]: Android'de Bitmap, önizlemede BufferedImage) sarar. [lumaLo] ve [lumaHi] fotoğrafın en koyu ve en açık
 * bölgelerinin parlaklığıdır (0..1; yüzde 10 ve 90'lık dilim): perde yoğunluğu bunlardan hesaplanır.
 * [onRelease] bellek geri vermek içindir (Bitmap.recycle).
 */
class Pic(
    val w: Int,
    val h: Int,
    val handle: Any,
    val lumaLo: Float,
    val lumaHi: Float,
    private val onRelease: (() -> Unit)? = null,
) {
    private var released = false

    fun release() {
        if (released) return
        released = true
        onRelease?.invoke()
    }

    val isReleased: Boolean get() = released
}

/** Arka plan bulanıklığı: fotoğraf küçültülüp büyütülerek yumuşatılır (gerçek zamanlı bulanıklık yok, kare maliyeti sıfır). */
enum class WpBlur(val id: String, val divisor: Int) {
    OFF("off", 1), SOFT("soft", 6), STRONG("strong", 16);

    companion object {
        fun byId(id: String?): WpBlur? = values().firstOrNull { it.id == id }
    }
}

/** Arka plan fotoğrafının saf hesapları (platformdan bağımsız, JVM'de test edilir). */
object WallpaperMath {
    /** Kullanıcının seçebileceği perde yoğunluğu aralığı. */
    const val DIM_MIN = 0f
    const val DIM_MAX = 0.80f
    const val DIM_DEFAULT = 0.35f

    /** Hazırlanan fotoğrafın en büyük genişliği (piksel) ve giriş görüntüsünün en çok piksel sayısı (bellek güvenliği). */
    const val MAX_WIDTH = 810
    const val MAX_HEIGHT = 2100
    const val MAX_INPUT_PIXELS = 120_000_000L

    /** Yazı rengiyle zeminin okunabilir kalması için hedef parlaklıklar. */
    private const val LIGHT_BG_MIN = 0.62f      // açık temada (koyu yazı) zemin en az bu açıklıkta
    private const val DARK_BG_MAX = 0.30f       // koyu temada (açık yazı) zemin en çok bu açıklıkta
    private const val VEIL_CAP = 0.85f

    fun luma(argb: Int): Float =
        (0.2126f * Rgb.r(argb) + 0.7152f * Rgb.g(argb) + 0.0722f * Rgb.b(argb)) / 255f

    /**
     * Fotoğrafı [dw]x[dh] alana "kaplama" biçiminde yerleştiren kaynak dikdörtgeni (sol, üst, sağ, alt; piksel):
     * en-boy oranı korunur, taşan kısım ortadan kırpılır.
     */
    fun cover(pw: Int, ph: Int, dw: Float, dh: Float): FloatArray {
        if (pw <= 0 || ph <= 0 || dw <= 0f || dh <= 0f) return floatArrayOf(0f, 0f, max(pw, 1).toFloat(), max(ph, 1).toFloat())
        val picAspect = pw.toFloat() / ph
        val dstAspect = dw / dh
        return if (picAspect > dstAspect) {
            val sw = ph * dstAspect
            val l = (pw - sw) / 2f
            floatArrayOf(l, 0f, l + sw, ph.toFloat())
        } else {
            val sh = pw / dstAspect
            val t = (ph - sh) / 2f
            floatArrayOf(0f, t, pw.toFloat(), t + sh)
        }
    }

    /**
     * Okunabilirlik için gereken en az perde yoğunluğu. Açık temada zemin beyaza, koyu temada siyaha doğru perdelenir;
     * perdenin ardındaki fotoğrafın en kötü bölgesi (açık temada en koyu, koyu temada en açık) yazıyı bozmayacak kadar
     * açık/koyu olana dek yoğunluk artar.
     */
    fun minVeil(dark: Boolean, lo: Float, hi: Float): Float {
        val v = if (dark) {
            if (hi <= DARK_BG_MAX) 0f else 1f - DARK_BG_MAX / hi
        } else {
            if (lo >= LIGHT_BG_MIN) 0f else (LIGHT_BG_MIN - lo) / (1f - lo)
        }
        return v.coerceIn(0f, VEIL_CAP)
    }

    /** Uygulanacak perde yoğunluğu: kullanıcının seçimi ile okunabilirlik alt sınırından büyüğü. */
    fun veil(dark: Boolean, lo: Float, hi: Float, user: Float, highContrast: Boolean): Float {
        val u = user.coerceIn(DIM_MIN, DIM_MAX)
        val floor = minVeil(dark, lo, hi)
        val v = max(u, floor)
        return (if (highContrast) max(v, 0.75f) else v).coerceIn(0f, VEIL_CAP)
    }

    /** Perde rengi: açık temada temanın en açık gökyüzü tonuna doğru beyaz, koyu temada siyaha yakın koyu ton. */
    fun veilColor(theme: AeroTheme): Int =
        if (theme.dark) Rgb.lerp(theme.skyTop, 0xFF000000.toInt(), 0.65f) else Rgb.lerp(theme.skyTop, Rgb.WHITE, 0.72f)

    /**
     * Girdi [sw]x[sh] iken ekran oranına kırpılıp küçültülmüş çıktı: (kırpma sol, üst, sağ, alt, çıktı genişliği, çıktı yüksekliği).
     * [aspect] ekranın genişlik/yükseklik oranı. Çıktı en çok [MAX_WIDTH]x[MAX_HEIGHT], asla büyütülmez.
     */
    fun prepare(sw: Int, sh: Int, aspect: Float): IntArray {
        val a = aspect.coerceIn(0.3f, 3.5f)
        var cw = sw
        var ch = (sw / a).toInt()
        if (ch > sh) { ch = sh; cw = (sh * a).toInt() }
        cw = cw.coerceIn(1, sw); ch = ch.coerceIn(1, sh)
        val l = (sw - cw) / 2
        val t = (sh - ch) / 2
        val k = min(1f, min(MAX_WIDTH.toFloat() / cw, MAX_HEIGHT.toFloat() / ch))
        return intArrayOf(l, t, l + cw, t + ch, max(1, (cw * k).toInt()), max(1, (ch * k).toInt()))
    }

    /** Küçük bir örnek dizisinden (parlaklıklar) yüzde [p] (0..1) değeri. */
    fun percentile(samples: FloatArray, p: Float): Float {
        if (samples.isEmpty()) return 0.5f
        val s = samples.copyOf(); s.sort()
        return s[((s.size - 1) * p.coerceIn(0f, 1f)).toInt()]
    }
}

/** Uygulamayla gelen hazır arka plan görselleri (assets/wallpapers/w1..w8.jpg). Adlar dilden bağımsız. */
object WallpaperPresets {
    val NAMES = listOf("Sakura", "Neon Roof", "Snow Dragon", "Rain Alley", "Night Mage", "Library", "Idol", "Sunset")
    fun asset(index: Int) = "wallpapers/w${index + 1}.jpg"
}
