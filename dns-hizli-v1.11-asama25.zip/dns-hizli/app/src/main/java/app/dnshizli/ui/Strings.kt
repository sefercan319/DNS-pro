package app.dnshizli.ui

import app.dnshizli.core.L
import app.dnshizli.core.Tx

/**
 * Etkin dilin tüm metinleri. Arayüz ve servis kodu metinleri yalnızca `Strings.X` ile okur; diller
 * `core/Tx*.kt` dosyalarındadır (Türkçe kaynak: `core/TxTr.kt`). Dil değişince bu değer kendiliğinden değişir.
 */
val Strings: Tx get() = L.tx
