package app.dnshizli.core

/**
 * Bu ağın kullanabildiği IP aileleri (cihazın ağ özelliklerinden; Android tarafı doldurur).
 * [UNKNOWN]: ağ yok ya da okunamadı; ikisi de denenir.
 */
class NetFamilies(val v4: Boolean, val v6: Boolean) {
    /** Yalnızca IPv6 olan ağ (ör. NAT64/DNS64 kullanan mobil ağlar). */
    val v6Only: Boolean get() = v6 && !v4

    override fun equals(other: Any?) = other is NetFamilies && other.v4 == v4 && other.v6 == v6
    override fun hashCode() = (if (v4) 1 else 0) * 2 + (if (v6) 1 else 0)
    override fun toString() = "v4=$v4 v6=$v6"

    companion object {
        val UNKNOWN = NetFamilies(true, true)
    }
}

/** Bir sunucu adresinin IPv4 ve IPv6 karşılığı (ikisinden biri yoksa null). */
class Endpoint(val v4: String?, val v6: String?)

/** Şifreli bağlantı hedefinin saf biçimi: [ip] önce, [alt] (öbür aile) ilk aile yanıt vermezse denenir. */
class TargetSpec(val ip: String, val alt: String?, val host: String, val path: String)

/**
 * Hangi adreslere hangi sırayla bağlanılacağı: IPv4 ve IPv6 birlikte. Android'e bağlı değildir ve ad çözümlemesi yapmaz.
 *
 * Kurallar:
 *  - [IpMode.V4]: yalnızca IPv4 (sunucunun yalnızca IPv6 adresi varsa, ki bunu kullanıcı kendisi yazmıştır, o kullanılır).
 *  - [IpMode.BOTH]: ağın kullanabildiği ailenin adresi önce; öbürü yedek. IPv4 ve IPv6'sı olan ağda IPv4 önce gelir
 *    (operatör NAT'ı ortak bir adres verir; IPv6'da ise cihazın kendi önekiyle görünürsünüz). Yalnızca IPv6 olan ağda IPv6 önce.
 */
object Targets {
    /** [server]'ın adres sırasına (birincil, ikincil) karşılık gelen uç noktalar. */
    fun endpoints(server: DnsServer): List<Endpoint> {
        val out = ArrayList<Endpoint>(2)
        val addrs = server.addresses
        for ((i, a) in addrs.withIndex()) {
            val counterpart = (if (i == 0) server.primary6 else server.secondary6)?.takeIf { Ip.isV6(it) }
            out.add(if (Ip.isV6(a)) Endpoint(null, a) else Endpoint(a, counterpart))
        }
        return out
    }

    /** Bir uç noktanın adresleri, denenme sırasıyla (en çok iki). */
    fun order(e: Endpoint, mode: IpMode, net: NetFamilies): List<String> {
        val v4 = e.v4
        val v6 = e.v6
        if (v4 == null && v6 == null) return emptyList()
        if (mode == IpMode.V4) return listOfNotNull(v4 ?: v6)
        return if (net.v6Only) listOfNotNull(v6, v4) else listOfNotNull(v4, v6)
    }

    /**
     * Düz DNS (UDP/53) yukarı akış listesi. Önce her uç noktanın ilk tercihi (birincil, ikincil), sonra yedek aileleri:
     * ilk aile bir yerde tıkanırsa öbür aileye geçilir. Yinelenen adres yoktur.
     */
    fun plain(server: DnsServer, mode: IpMode, net: NetFamilies): List<String> {
        val per = endpoints(server).map { order(it, mode, net) }
        val out = ArrayList<String>(4)
        for (round in 0..1) for (o in per) if (o.size > round && o[round] !in out) out.add(o[round])
        return out
    }

    /**
     * Şifreli (DoT/DoH) hedefler. [extraV4]: DoH için sağlayıcının kendi çözümlemesinden bulunan ek IPv4 adresleri
     * (yoksa boş); katalog adreslerinden önce denenirler. Her hedefin [TargetSpec.host] adı sertifika adıdır.
     */
    fun secure(server: DnsServer, proto: Proto, mode: IpMode, net: NetFamilies, extraV4: List<String> = emptyList()): List<TargetSpec> {
        require(proto != Proto.PLAIN)
        val path = server.doh?.let { DohUrl.path(it) } ?: "/dns-query"
        val base = ArrayList<TargetSpec>(2)
        for ((i, e) in endpoints(server).withIndex()) {
            val host = server.tlsHost(proto, i) ?: continue
            val o = order(e, mode, net)
            if (o.isEmpty()) continue
            base.add(TargetSpec(o[0], o.getOrNull(1), host, path))
        }
        if (base.isEmpty()) throw IllegalStateException("şifreli hedef yok")
        val known = server.addresses.toSet()
        val extra = extraV4.filter { it !in known && Ip.isV4(it) && Ip.isGlobalV4(Ip.parse4(it)!!) }.distinct().take(1)
            .map { TargetSpec(it, null, base[0].host, path) }
        return if (proto == Proto.DOH) extra + base else base + extra
    }
}
