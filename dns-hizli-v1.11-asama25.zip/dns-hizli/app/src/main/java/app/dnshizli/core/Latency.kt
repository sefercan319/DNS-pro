package app.dnshizli.core

/**
 * Son sorguların cevap süreleri için küçük, bellekteki halka (sorgu başına gecikme grafiği). Yalnızca süre tutulur; alan adı,
 * adres ya da zaman damgası yoktur. Diske yazılmaz, bağlantı kesilince (yönlendirici kapanınca) kaybolur.
 * Birden çok iş parçacığı yazabilir; okuma kopya alır. Ayırma yapmaz.
 */
class LatencyRing(capacity: Int = CAPACITY) {
    private val cap = capacity.coerceAtLeast(1)
    private val ring = IntArray(cap)
    private var next = 0
    private var count = 0

    /** [ms] ağdan gelen bir cevabın süresi; [TIMEOUT] zaman aşımına uğrayan bir sorgu. */
    @Synchronized
    fun add(ms: Int) {
        ring[next] = if (ms == TIMEOUT) TIMEOUT else ms.coerceIn(0, MAX_MS)
        next = (next + 1) % cap
        if (count < cap) count++
    }

    /** Eskiden yeniye, en çok [out] boyu kadar (en yeniler) kopyalar; yazılan sayıyı döner. */
    @Synchronized
    fun copyTo(out: IntArray): Int {
        val n = minOf(count, out.size)
        val start = (next - n + cap * 2) % cap
        for (i in 0 until n) out[i] = ring[(start + i) % cap]
        return n
    }

    @Synchronized
    fun size(): Int = count

    @Synchronized
    fun clear() { next = 0; count = 0 }

    companion object {
        const val CAPACITY = 120
        const val TIMEOUT = -1

        /** Bir cevap süresi bundan uzun görünmez (ms). */
        const val MAX_MS = 60_000
    }
}

/** Grafiğin özeti: ölçülen sorgular üzerinden. Zaman aşımları ortalamaya ve en büyük değere girmez. */
class LatencySummary(val answered: Int, val timeouts: Int, val avgMs: Int, val maxMs: Int, val lastMs: Int) {
    companion object {
        fun of(v: IntArray, n: Int): LatencySummary {
            var a = 0
            var t = 0
            var sum = 0L
            var mx = 0
            var last = -1
            for (i in 0 until n) {
                val x = v[i]
                if (x == LatencyRing.TIMEOUT) { t++; last = -1; continue }
                a++
                sum += x
                if (x > mx) mx = x
                last = x
            }
            return LatencySummary(a, t, if (a == 0) 0 else (sum / a).toInt(), mx, last)
        }
    }
}
