package app.dnshizli.core

/**
 * IPv4 + UDP paketleri için küçük, bellek ayırmayan (allocation-free) yardımcılar.
 * Android'e bağlı değil, bu yüzden normal JVM'de test edilebilir.
 */
internal object Packets {
    const val IP_HDR = 20
    const val UDP_HDR = 8
    const val HDR = IP_HDR + UDP_HDR
    const val DNS_HDR = 12
    const val DNS_PORT = 53

    fun u16(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    fun put16(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 8).toByte()
        b[o + 1] = v.toByte()
    }

    fun i32(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xFF) shl 24) or
            ((b[o + 1].toInt() and 0xFF) shl 16) or
            ((b[o + 2].toInt() and 0xFF) shl 8) or
            (b[o + 3].toInt() and 0xFF)

    fun put32(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 24).toByte()
        b[o + 1] = (v ushr 16).toByte()
        b[o + 2] = (v ushr 8).toByte()
        b[o + 3] = v.toByte()
    }

    /** Standart IPv4 başlık sağlama toplamı. Başlıktaki checksum alanı dahilse geçerli paket için 0 döner. */
    fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0
        var i = off
        while (i + 1 < off + len) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
        }
        while ((sum ushr 16) != 0) sum = (sum and 0xFFFF) + (sum ushr 16)
        return sum.inv() and 0xFFFF
    }

    /**
     * Paket "IPv4 + UDP + hedef port 53 + parçalı değil" ise IP başlık uzunluğunu döner,
     * aksi halde -1 (paket yok sayılır).
     */
    fun queryHeaderLen(p: ByteArray, len: Int): Int {
        if (len < HDR + DNS_HDR) return -1
        if (((p[0].toInt() and 0xF0) shr 4) != 4) return -1
        val ihl = (p[0].toInt() and 0x0F) * 4
        if (ihl < IP_HDR || len < ihl + UDP_HDR + DNS_HDR) return -1
        if ((p[9].toInt() and 0xFF) != 17) return -1          // UDP değil
        if ((u16(p, 6) and 0x3FFF) != 0) return -1            // parçalı paket
        if (u16(p, 2) > len) return -1                        // kesik paket
        if (u16(p, ihl + 2) != DNS_PORT) return -1            // DNS değil
        return ihl
    }

    /** UDP verisinin (DNS mesajı) uzunluğu. Negatif çıkarsa paket bozuktur. */
    fun dnsLength(p: ByteArray, ihl: Int): Int {
        val total = u16(p, 2)
        val udp = u16(p, ihl + 4) - UDP_HDR
        return minOf(udp, total - ihl - UDP_HDR)
    }

    fun ip(a: Int, b: Int, c: Int, d: Int): Int = (a shl 24) or (b shl 16) or (c shl 8) or d

    // Tünele yazılan IP paketlerinin kimlik (Identification) sayacı: süreç genelinde TEK sayaç. Aynı anda çalışan
    // yönlendiriciler (ör. sunucu değişirken emekliye ayrılan eskisi) aynı kimliği üretmesin; aksi halde iki büyük
    // cevabın IP parçaları işletim sisteminde yanlış birleştirilebilir. Rastgele bir değerden başlar.
    private val ident = java.util.concurrent.atomic.AtomicInteger(java.security.SecureRandom().nextInt(0x10000))

    /** Sıradaki IP kimliği (1..65535). Nesne ayırmaz, her iş parçacığından çağrılabilir. */
    fun nextIdent(): Int {
        val v = ident.incrementAndGet() and 0xFFFF
        return if (v == 0) ident.incrementAndGet() and 0xFFFF else v
    }

    /**
     * UDP sağlama toplamı (RFC 768): sözde başlık (kaynak/hedef IP, protokol, uzunluk) + UDP başlığı + veri.
     * [udpOff] konumundaki UDP başlığının checksum alanı hesaplama sırasında 0 sayılır. Sonuç 0 çıkarsa 0xFFFF yazılır
     * (0, "checksum yok" anlamına gelir). İstemci, bozulmuş ya da yanlış birleştirilmiş bir cevabı böylece fark eder.
     */
    fun udpChecksum(b: ByteArray, udpOff: Int, udpLen: Int, srcIp: Int, dstIp: Int): Int {
        var sum = 0L
        sum += (srcIp ushr 16) and 0xFFFF
        sum += srcIp and 0xFFFF
        sum += (dstIp ushr 16) and 0xFFFF
        sum += dstIp and 0xFFFF
        sum += 17
        sum += udpLen
        var i = udpOff
        val end = udpOff + udpLen
        while (i + 1 < end) {
            if (i != udpOff + 6) sum += (((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)).toLong()
            i += 2
        }
        if (i < end) sum += ((b[i].toInt() and 0xFF) shl 8).toLong()
        while ((sum ushr 16) != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
        val c = sum.toInt().inv() and 0xFFFF
        return if (c == 0) 0xFFFF else c
    }

    /** UDP sağlama toplamı geçerli mi? (Alan 0 ise "hesaplanmamış" sayılır ve geçerli kabul edilir.) */
    fun udpChecksumOk(b: ByteArray, udpOff: Int, udpLen: Int, srcIp: Int, dstIp: Int): Boolean {
        val stored = u16(b, udpOff + 6)
        return stored == 0 || stored == udpChecksum(b, udpOff, udpLen, srcIp, dstIp)
    }

    /**
     * [out] içinde HDR (28) bayttan sonra DNS verisi hazırsa, öndeki IPv4 + UDP başlıklarını doldurur
     * (UDP sağlama toplamı dahil).
     */
    fun writeHeaders(out: ByteArray, srcIp: Int, dstIp: Int, srcPort: Int, dstPort: Int, dnsLen: Int, ident: Int = 0) {
        writeIp(out, srcIp, dstIp, HDR + dnsLen, ident, 0x4000)
        put16(out, 20, srcPort)
        put16(out, 22, dstPort)
        put16(out, 24, UDP_HDR + dnsLen)
        put16(out, 26, udpChecksum(out, IP_HDR, UDP_HDR + dnsLen, srcIp, dstIp))
    }

    /** IPv4 başlığı (20 bayt) yazar. [flagsFrag]: bayraklar (DF/MF) + 8 baytlık birimlerle parça konumu. */
    private fun writeIp(out: ByteArray, srcIp: Int, dstIp: Int, total: Int, ident: Int, flagsFrag: Int) {
        out[0] = 0x45
        out[1] = 0
        put16(out, 2, total)
        put16(out, 4, ident)
        put16(out, 6, flagsFrag)
        out[8] = 64                    // TTL
        out[9] = 17                    // UDP
        put16(out, 10, 0)
        put32(out, 12, srcIp)
        put32(out, 16, dstIp)
        put16(out, 10, checksum(out, 0, IP_HDR))
    }

    /** Tünel MTU'su: tek bir IP paketinin en büyük boyu. */
    const val MTU = 1500

    /**
     * DNS cevabını tünele yazar. [out]: ilk [HDR] bayt boş, ardından [dnsLen] bayt DNS verisi.
     * Tek pakete sığmayan büyük cevaplar (ör. çok kayıtlı ya da şifreli DNS'ten gelen) IP parçalarına bölünür;
     * işletim sistemi parçaları birleştirip uygulamaya tek cevap olarak verir. [scratch] en az [MTU] bayt olmalı.
     */
    fun writeReply(
        out: ByteArray, scratch: ByteArray, ident: Int,
        srcIp: Int, dstIp: Int, srcPort: Int, dstPort: Int, dnsLen: Int,
        write: (ByteArray, Int, Int) -> Unit,
    ) {
        if (HDR + dnsLen <= MTU) {
            writeHeaders(out, srcIp, dstIp, srcPort, dstPort, dnsLen, ident and 0xFFFF)
            write(out, 0, HDR + dnsLen)
            return
        }
        // UDP başlığını verinin hemen önüne (out[20..27]) yaz: IP yükü = out[20 ..< 20+8+dnsLen].
        // Sağlama toplamı parçalamadan ÖNCE bütün UDP verisi üzerinden hesaplanır.
        put16(out, 20, srcPort)
        put16(out, 22, dstPort)
        put16(out, 24, UDP_HDR + dnsLen)
        put16(out, 26, udpChecksum(out, IP_HDR, UDP_HDR + dnsLen, srcIp, dstIp))
        val payload = UDP_HDR + dnsLen
        val chunk = (MTU - IP_HDR) and 7.inv()          // 1480: parça yükü 8'in katı olmalı
        var off = 0
        while (off < payload) {
            val n = minOf(chunk, payload - off)
            val more = off + n < payload
            writeIp(scratch, srcIp, dstIp, IP_HDR + n, ident and 0xFFFF, (if (more) 0x2000 else 0) or (off / 8))
            System.arraycopy(out, IP_HDR + off, scratch, IP_HDR, n)
            write(scratch, 0, IP_HDR + n)
            off += n
        }
    }

    // ------------------------------------------------------------------ IPv6

    /** IPv6 sabit başlığı (40 bayt) ve onunla birlikte UDP başlığı (48 bayt). */
    const val IP6_HDR = 40
    const val HDR6 = IP6_HDR + UDP_HDR

    /**
     * Cevap tamponları DNS verisini [HDR] (28) konumunda tutar; IPv6 başlıkları daha uzun olduğu için tamponların
     * sonunda bu kadar ek yer ayrılır ([HDR6] - [HDR]).
     */
    const val ROOM = HDR6 - HDR

    /** IPv6 parçalama başlığı (sonraki başlık 44) uzunluğu. */
    private const val FRAG_HDR = 8

    /**
     * Paket "IPv6 + doğrudan UDP + hedef port 53" ise [IP6_HDR] döner, aksi halde -1 (paket yok sayılır).
     * Uzantı başlıklı (ör. parçalı) paketler yok sayılır: işletim sistemi küçük DNS sorgularına uzantı eklemez.
     */
    fun queryHeaderLen6(p: ByteArray, len: Int): Int {
        if (len < HDR6 + DNS_HDR) return -1
        if (((p[0].toInt() and 0xF0) shr 4) != 6) return -1
        if ((p[6].toInt() and 0xFF) != 17) return -1                 // doğrudan UDP değil
        val payload = u16(p, 4)
        if (payload < UDP_HDR + DNS_HDR || IP6_HDR + payload > len) return -1
        if (u16(p, IP6_HDR + 2) != DNS_PORT) return -1
        if (u16(p, IP6_HDR + 4) > payload) return -1
        return IP6_HDR
    }

    /** IPv6 paketindeki UDP verisinin (DNS mesajı) uzunluğu. */
    fun dnsLength6(p: ByteArray): Int = minOf(u16(p, IP6_HDR + 4), u16(p, 4)) - UDP_HDR

    /**
     * IPv6 UDP sağlama toplamı (RFC 8200: sözde başlık = kaynak + hedef adres + UDP uzunluğu + sonraki başlık 17;
     * IPv6'da zorunludur). Veri [data] içinde [dOff] konumunda [dLen] bayttır; UDP başlığı alanlarından hesaplanır, bu
     * yüzden başlık ve veri ardışık olmak zorunda değildir. Sonuç 0 çıkarsa 0xFFFF döner.
     */
    fun udpChecksum6(src: ByteArray, dst: ByteArray, srcPort: Int, dstPort: Int, data: ByteArray, dOff: Int, dLen: Int): Int {
        val udpLen = UDP_HDR + dLen
        var sum = 0L
        for (i in 0 until 16 step 2) {
            sum += ((src[i].toInt() and 0xFF) shl 8) or (src[i + 1].toInt() and 0xFF)
            sum += ((dst[i].toInt() and 0xFF) shl 8) or (dst[i + 1].toInt() and 0xFF)
        }
        sum += (udpLen ushr 16) and 0xFFFF
        sum += udpLen and 0xFFFF
        sum += 17
        sum += srcPort
        sum += dstPort
        sum += udpLen
        var i = dOff
        val end = dOff + dLen
        while (i + 1 < end) {
            sum += ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (i < end) sum += (data[i].toInt() and 0xFF) shl 8
        while ((sum ushr 16) != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
        val c = sum.toInt().inv() and 0xFFFF
        return if (c == 0) 0xFFFF else c
    }

    /** IPv6 UDP sağlama toplamı geçerli mi? (IPv6'da 0 geçersizdir.) [p]: IPv6 başlığından başlayan paket. */
    fun udpChecksum6Ok(p: ByteArray, len: Int): Boolean {
        if (queryHeaderLen6(p, len) < 0) return false
        val src = p.copyOfRange(8, 24)
        val dst = p.copyOfRange(24, 40)
        val dLen = dnsLength6(p)
        if (dLen < 0 || IP6_HDR + UDP_HDR + dLen > len) return false
        val stored = u16(p, IP6_HDR + 6)
        return stored != 0 && stored == udpChecksum6(src, dst, u16(p, IP6_HDR), u16(p, IP6_HDR + 2), p, HDR6, dLen)
    }

    private fun writeIp6(out: ByteArray, src: ByteArray, dst: ByteArray, payload: Int, next: Int) {
        out[0] = 0x60
        out[1] = 0
        put16(out, 2, 0)                 // akış etiketi
        put16(out, 4, payload)
        out[6] = next.toByte()
        out[7] = 64                      // sıçrama sınırı
        System.arraycopy(src, 0, out, 8, 16)
        System.arraycopy(dst, 0, out, 24, 16)
    }

    /**
     * [out] içinde [HDR6] konumundan sonra DNS verisi hazırsa öndeki IPv6 + UDP başlıklarını (sağlama toplamı dahil)
     * doldurur. Bağlantı testi sorguları ve testler için.
     */
    fun writeHeaders6(out: ByteArray, src: ByteArray, dst: ByteArray, srcPort: Int, dstPort: Int, dnsLen: Int) {
        writeIp6(out, src, dst, UDP_HDR + dnsLen, 17)
        put16(out, IP6_HDR, srcPort)
        put16(out, IP6_HDR + 2, dstPort)
        put16(out, IP6_HDR + 4, UDP_HDR + dnsLen)
        put16(out, IP6_HDR + 6, udpChecksum6(src, dst, srcPort, dstPort, out, HDR6, dnsLen))
    }

    /**
     * DNS cevabını IPv6 olarak tünele yazar. DNS verisi [out] içinde [HDR] (28) konumunda hazırdır ve DEĞİŞTİRİLMEZ
     * (aynı cevap birden çok istemciye verilebilir); paketler [scratch] içinde kurulur (en az [MTU] bayt).
     * IPv6'da yönlendiriciler parçalamaz: tek pakete sığmayan cevap, kaynakta parçalama başlığıyla (RFC 8200) bölünür.
     */
    fun writeReply6(
        out: ByteArray, scratch: ByteArray, ident: Int,
        src: ByteArray, dst: ByteArray, srcPort: Int, dstPort: Int, dnsLen: Int,
        write: (ByteArray, Int, Int) -> Unit,
    ) {
        val csum = udpChecksum6(src, dst, srcPort, dstPort, out, HDR, dnsLen)
        if (HDR6 + dnsLen <= MTU) {
            writeIp6(scratch, src, dst, UDP_HDR + dnsLen, 17)
            put16(scratch, IP6_HDR, srcPort)
            put16(scratch, IP6_HDR + 2, dstPort)
            put16(scratch, IP6_HDR + 4, UDP_HDR + dnsLen)
            put16(scratch, IP6_HDR + 6, csum)
            System.arraycopy(out, HDR, scratch, HDR6, dnsLen)
            write(scratch, 0, HDR6 + dnsLen)
            return
        }
        // Yük = UDP başlığı (8) + DNS verisi. Her parça: IPv6 başlığı + parçalama başlığı + yükün bir dilimi.
        val payload = UDP_HDR + dnsLen
        val chunk = (MTU - IP6_HDR - FRAG_HDR) and 7.inv()          // 1448: parça yükü 8'in katı olmalı
        var off = 0
        while (off < payload) {
            val n = minOf(chunk, payload - off)
            val more = off + n < payload
            writeIp6(scratch, src, dst, FRAG_HDR + n, 44)
            scratch[IP6_HDR] = 17                                  // sonraki başlık: UDP
            scratch[IP6_HDR + 1] = 0
            put16(scratch, IP6_HDR + 2, ((off / 8) shl 3) or (if (more) 1 else 0))
            put32(scratch, IP6_HDR + 4, ident)
            var o = IP6_HDR + FRAG_HDR
            var from = off
            if (from < UDP_HDR) {
                // UDP başlığının (henüz yazılmamış) baytları ilk parçada
                put16(scratch, o, srcPort)
                put16(scratch, o + 2, dstPort)
                put16(scratch, o + 4, payload)
                put16(scratch, o + 6, csum)
                o += UDP_HDR
                from = UDP_HDR
            }
            val take = off + n - from
            if (take > 0) System.arraycopy(out, HDR + (from - UDP_HDR), scratch, o, take)
            write(scratch, 0, IP6_HDR + FRAG_HDR + n)
            off += n
        }
    }
}

internal object Dns {

    /**
     * DNS cevabı önbelleğe alınabilir mi? Alınabilirse cevap bölümündeki en kısa TTL'i (saniye),
     * alınamazsa 0 döner. Hatalı, kesilmiş (TC) veya cevapsız mesajlar önbelleğe girmez.
     */
    fun cacheTtl(b: ByteArray, len: Int): Int = cacheTtl(b, 0, len)

    /** [b] içinde [base] konumundan başlayan [n] baytlık mesaj için [cacheTtl]. */
    fun cacheTtl(b: ByteArray, base: Int, n: Int): Int {
        if (n < Packets.DNS_HDR || base < 0 || base + n > b.size) return 0
        val end = base + n
        val flags = Packets.u16(b, base + 2)
        if ((flags and 0x8000) == 0) return 0      // cevap değil
        if ((flags and 0x0200) != 0) return 0      // TC: kesilmiş
        val rcode = flags and 0x000F
        if (rcode != 0 && rcode != 3) return 0     // NOERROR ve NXDOMAIN dışındaki hatalar saklanmaz
        val qd = Packets.u16(b, base + 4)
        val an = Packets.u16(b, base + 6)
        if (an == 0 || rcode == 3) return negativeTtl(b, base, n, qd, an, Packets.u16(b, base + 8))

        var p = base + Packets.DNS_HDR
        for (i in 0 until qd) {
            p = skipName(b, p, end)
            if (p < 0 || p + 4 > end) return 0
            p += 4
        }
        var lowest = Int.MAX_VALUE
        for (i in 0 until an) {
            p = skipName(b, p, end)
            if (p < 0 || p + 10 > end) return 0
            val ttl = Packets.i32(b, p + 4)
            val rdLen = Packets.u16(b, p + 8)
            p += 10
            if (p + rdLen > end) return 0
            p += rdLen
            lowest = minOf(lowest, if (ttl < 0) 0 else ttl)
        }
        return if (lowest == Int.MAX_VALUE) 0 else lowest
    }

    /** Olumsuz cevabın (NXDOMAIN ya da "kayıt yok") en çok saklanacağı süre (saniye). */
    const val NEG_MAX_TTL_S = 60

    /**
     * Olumsuz cevap süresi (RFC 2308): yetki bölümündeki SOA kaydının TTL'i ile MINIMUM alanından küçüğü, en çok
     * [NEG_MAX_TTL_S]. SOA yoksa ya da mesaj bozuksa 0 (saklanmaz). Engelleme cevapları (0.0.0.0) bu yola girmez.
     */
    private fun negativeTtl(b: ByteArray, base: Int, n: Int, qd: Int, an: Int, ns: Int): Int {
        val end = base + n
        if (ns == 0 || ns > 16 || an > 16) return 0
        var p = base + Packets.DNS_HDR
        for (i in 0 until qd) {
            p = skipName(b, p, end)
            if (p < 0 || p + 4 > end) return 0
            p += 4
        }
        for (i in 0 until an + ns) {
            p = skipName(b, p, end)
            if (p < 0 || p + 10 > end) return 0
            val type = Packets.u16(b, p)
            val ttl = Packets.i32(b, p + 4)
            val rdLen = Packets.u16(b, p + 8)
            p += 10
            if (p + rdLen > end) return 0
            if (i >= an && type == 6) {
                var q = skipName(b, p, p + rdLen)
                if (q < 0) return 0
                q = skipName(b, q, p + rdLen)
                if (q < 0 || q + 20 > p + rdLen) return 0
                val minimum = Packets.i32(b, q + 16)
                val t = minOf(if (ttl < 0) 0 else ttl, if (minimum < 0) 0 else minimum)
                return minOf(t, NEG_MAX_TTL_S)
            }
            p += rdLen
        }
        return 0
    }

    /** Alan adını atlar (sıkıştırma işaretçisi dahil). Bozuksa -1. */
    internal fun skipName(b: ByteArray, start: Int, end: Int): Int {
        var i = start
        while (true) {
            if (i >= end) return -1
            val l = b[i].toInt() and 0xFF
            if (l == 0) return i + 1
            if ((l and 0xC0) == 0xC0) return if (i + 2 <= end) i + 2 else -1
            if ((l and 0xC0) != 0) return -1
            i += 1 + l
        }
    }

    /**
     * Cevap bir engelleme cevabı mı (tahmini)? Engelleyen sunucuların yaygın yanıtları:
     *  - A kaydı 0.0.0.0 ya da AAAA kaydı :: ("boş adres"),
     *  - Genişletilmiş DNS Hatası (RFC 8914) kodu 15 Blocked, 16 Censored, 17 Filtered, 18 Prohibited.
     * Sıradan "böyle bir alan adı yok" (NXDOMAIN) cevapları sayılmaz.
     */
    fun isBlocked(b: ByteArray, len: Int): Boolean = isBlocked(b, 0, len)

    /** [b] içinde [base] konumundan başlayan [n] baytlık DNS mesajı için [isBlocked]. Nesne ayırmaz. */
    fun isBlocked(b: ByteArray, base: Int, n: Int): Boolean {
        if (n < Packets.DNS_HDR || base < 0 || base + n > b.size) return false
        val end = base + n
        val flags = Packets.u16(b, base + 2)
        if ((flags and 0x8000) == 0) return false
        val qd = Packets.u16(b, base + 4)
        val an = Packets.u16(b, base + 6)
        val ns = Packets.u16(b, base + 8)
        val ar = Packets.u16(b, base + 10)
        var p = base + Packets.DNS_HDR
        for (i in 0 until qd) {
            p = skipName(b, p, end)
            if (p < 0 || p + 4 > end) return false
            p += 4
        }
        var nullAnswer = false
        val total = an + ns + ar
        for (i in 0 until total) {
            p = skipName(b, p, end)
            if (p < 0 || p + 10 > end) return nullAnswer
            val type = Packets.u16(b, p)
            val rdLen = Packets.u16(b, p + 8)
            val rd = p + 10
            if (rd + rdLen > end) return nullAnswer
            if (i < an) {
                if ((type == 1 && rdLen == 4 || type == 28 && rdLen == 16) && allZero(b, rd, rdLen)) nullAnswer = true
            } else if (i >= an + ns && type == 41) {
                // OPT kaydı: seçenekler (kod, uzunluk, veri). Kod 15 = Genişletilmiş DNS Hatası.
                var o = rd
                while (o + 4 <= rd + rdLen) {
                    val code = Packets.u16(b, o)
                    val olen = Packets.u16(b, o + 2)
                    if (code == 15 && olen >= 2 && o + 6 <= rd + rdLen) {
                        val info = Packets.u16(b, o + 4)
                        if (info in 15..18) return true
                    }
                    o += 4 + olen
                }
            }
            p = rd + rdLen
        }
        return nullAnswer
    }

    private fun allZero(b: ByteArray, off: Int, n: Int): Boolean {
        for (i in off until off + n) if (b[i].toInt() != 0) return false
        return true
    }

    /** Cevaptaki A kayıtlarının adresleri ("1.2.3.4"). Bozuksa boş liste. */
    fun aRecords(b: ByteArray, len: Int): List<String> {
        if (len < Packets.DNS_HDR) return emptyList()
        val flags = Packets.u16(b, 2)
        if ((flags and 0x8000) == 0 || (flags and 0x000F) != 0) return emptyList()
        val qd = Packets.u16(b, 4)
        val an = Packets.u16(b, 6)
        var p = Packets.DNS_HDR
        for (i in 0 until qd) {
            p = skipName(b, p, len)
            if (p < 0 || p + 4 > len) return emptyList()
            p += 4
        }
        val out = ArrayList<String>(2)
        for (i in 0 until an) {
            p = skipName(b, p, len)
            if (p < 0 || p + 10 > len) break
            val type = Packets.u16(b, p)
            val rdLen = Packets.u16(b, p + 8)
            val rd = p + 10
            if (rd + rdLen > len) break
            if (type == 1 && rdLen == 4) {
                out.add("${b[rd].toInt() and 0xFF}.${b[rd + 1].toInt() and 0xFF}.${b[rd + 2].toInt() and 0xFF}.${b[rd + 3].toInt() and 0xFF}")
            }
            p = rd + rdLen
        }
        return out
    }

    /**
     * İlk soru bölümünün bittiği konum ([base]'den bağımsız, mutlak konum): başlık + ad + tür + sınıf.
     * Soru yoksa ya da bozuksa -1. Sıkıştırma işaretçisi soru adında geçersizdir (sorgularda bulunmaz).
     */
    fun questionEnd(b: ByteArray, base: Int, n: Int): Int {
        if (n < Packets.DNS_HDR || base < 0 || base + n > b.size) return -1
        if (Packets.u16(b, base + 4) < 1) return -1
        val end = base + n
        var i = base + Packets.DNS_HDR
        while (true) {
            if (i >= end) return -1
            val l = b[i].toInt() and 0xFF
            if (l == 0) { i++; break }
            if ((l and 0xC0) != 0) return -1
            i += 1 + l
        }
        return if (i + 4 <= end) i + 4 else -1
    }

    /**
     * Cevap gerçekten bu sorunun cevabı mı? (RFC 5452: sahte cevaplara karşı.) Kimlik eşleşmesinin yanında:
     *  - QR=1 (cevap), OPCODE sorguyla aynı,
     *  - soru sayısı 1 ve soru bölümü (ad büyük/küçük harf duyarsız; tür ve sınıf birebir) sorguyla aynı.
     * Sorgu tek sorulu değilse yalnızca QR/OPCODE denetlenir. Nesne ayırmaz.
     *
     * [q]: sorgu, [qBase] başlangıcı, [qEnd] soru bölümünün sonu ([questionEnd]); [r]: cevap, [rBase], [rLen].
     */
    fun sameQuestion(q: ByteArray, qBase: Int, qEnd: Int, r: ByteArray, rBase: Int, rLen: Int): Boolean {
        if (rLen < Packets.DNS_HDR || rBase < 0 || rBase + rLen > r.size) return false
        val rf = Packets.u16(r, rBase + 2)
        if ((rf and 0x8000) == 0) return false
        val qf = Packets.u16(q, qBase + 2)
        if (((rf ushr 11) and 0xF) != ((qf ushr 11) and 0xF)) return false
        if (qEnd < 0 || Packets.u16(q, qBase + 4) != 1) return true
        // Bazı sunucular hatalı biçimli (FORMERR) ya da reddedilen sorularda soru bölümünü boş döner: kabul edilir,
        // ama kimlik dışında hiçbir şey taşımadığı için önbelleğe girmez (cevap sayısı 0).
        val rq = Packets.u16(r, rBase + 4)
        if (rq == 0) return Packets.u16(r, rBase + 6) == 0 && (rf and 0x000F) != 0
        if (rq != 1) return false
        val len = qEnd - (qBase + Packets.DNS_HDR)
        if (Packets.DNS_HDR + len > rLen) return false
        val nameEnd = qEnd - 4
        var i = 0
        while (i < len) {
            val qi = qBase + Packets.DNS_HDR + i
            val a = q[qi].toInt() and 0xFF
            val c = r[rBase + Packets.DNS_HDR + i].toInt() and 0xFF
            if (a != c) {
                // Ad içinde yalnızca ASCII harflerde büyük/küçük farkı kabul edilir (0x20 karıştırması).
                if (qi >= nameEnd) return false
                val la = if (a in 0x41..0x5A) a + 32 else a
                val lc = if (c in 0x41..0x5A) c + 32 else c
                if (la != lc) return false
            }
            i++
        }
        return true
    }

    /**
     * Önbellekten verilen cevaptaki TTL'leri geçen süre kadar azaltır (en az 0): istemci cevabı kalan süreden fazla
     * saklamasın. OPT (EDNS) kaydının TTL alanı başka anlam taşıdığı için atlanır. Bozuk mesajda dokunmadan durur.
     */
    fun ageTtls(b: ByteArray, base: Int, n: Int, elapsedSec: Int) {
        if (elapsedSec <= 0 || n < Packets.DNS_HDR || base < 0 || base + n > b.size) return
        val end = base + n
        val qd = Packets.u16(b, base + 4)
        val total = Packets.u16(b, base + 6) + Packets.u16(b, base + 8) + Packets.u16(b, base + 10)
        var p = base + Packets.DNS_HDR
        for (i in 0 until qd) {
            p = skipName(b, p, end)
            if (p < 0 || p + 4 > end) return
            p += 4
        }
        for (i in 0 until total) {
            p = skipName(b, p, end)
            if (p < 0 || p + 10 > end) return
            val type = Packets.u16(b, p)
            if (type != 41) {
                val ttl = Packets.i32(b, p + 4)
                val next = if (ttl <= elapsedSec) 0 else ttl - elapsedSec
                Packets.put32(b, p + 4, next)
            }
            val rdLen = Packets.u16(b, p + 8)
            p += 10 + rdLen
            if (p > end) return
        }
    }

    /** Cevaba "kesildi" (TC) bayrağı koyar: istemci tam cevabın gelmediğini bilsin. */
    fun setTruncated(b: ByteArray, base: Int) {
        b[base + 2] = (b[base + 2].toInt() or 0x02).toByte()
    }

    /**
     * Herkese açık, tek noktaya yayın (global unicast) IPv4 adresi mi? İlk çözümlemede (bootstrap) sahte ya da
     * yanlış yapılandırılmış bir cevabın bağlantıyı yerel ağa, döngüye ya da çok noktaya yayın adresine yöneltmesini engeller.
     */
    fun isGlobalIpv4(a: Int, b: Int, c: Int, d: Int): Boolean = when {
        a == 0 || a == 10 || a == 127 || a >= 224 -> false               // "bu ağ", özel, döngü, çoklu yayın, ayrılmış
        a == 100 && b in 64..127 -> false                                // operatör NAT'ı (CGNAT)
        a == 169 && b == 254 -> false                                    // bağlantı-yerel
        a == 172 && b in 16..31 -> false                                 // özel
        a == 192 && b == 168 -> false                                    // özel
        a == 192 && b == 0 && c == 0 -> false                            // IETF protokol atamaları
        a == 192 && b == 0 && c == 2 -> false                            // belgeleme
        a == 198 && (b == 18 || b == 19) -> false                        // karşılaştırma testleri
        a == 198 && b == 51 && c == 100 -> false                         // belgeleme
        a == 203 && b == 0 && c == 113 -> false                          // belgeleme
        else -> true
    }

    // ------------------------------------------------------------------ EDNS gizlilik süzgeci

    /** [sanitizeQuery] sonucu: sunucuya gidecek sorgu ve OPT kaydının bizim tarafımızdan eklenip eklenmediği. */
    class Sanitized(val query: ByteArray, val addedOpt: Boolean)

    /** EDNS seçenek kodları. */
    private const val OPT_ECS = 8
    private const val OPT_PADDING = 12

    /** RFC 8467: sorgular 128 baytın katına doldurulur. */
    const val PAD_BLOCK = 128

    /**
     * İstemcinin sorgusunu sunucuya göndermeden önce gizlilik için yeniden kurar:
     *  - İstemciden gelen TÜM EDNS seçenekleri atılır: istemci alt ağı (ECS), çerez (COOKIE; istemciyi ağlar arasında
     *    izlemeye yarar), cihaz/hesap kimlikleri (ör. sağlayıcıya özgü kodlar) ve tanıma amaçlı diğer seçenekler.
     *  - "İstemci alt ağını iletme" işareti konur: ECS seçeneği, kaynak önek uzunluğu 0 (RFC 7871 §7.1.2). Özyinelemeli
     *    sunucu bu durumda bizim adresimizi yetkili sunuculara aktarmaz.
     *  - [pad] açıksa sorgu, 128 baytın katına doldurulur (RFC 7830 + RFC 8467): şifreli kanalda bile uzunluktan alan adı
     *    tahmin edilmesini zorlaştırır.
     *  - OPT kaydı yoksa eklenir ([Sanitized.addedOpt]); cevaptaki OPT, istemci istemediği için [stripOpt] ile atılmalıdır.
     * Soru ve diğer kayıtlar (OPT dışı ek kayıtlar dahil) olduğu gibi korunur; EDNS sürümü ve DO biti de korunur.
     * Sorgu ayrıştırılamazsa ya da birden çok OPT içeriyorsa null (sorgu atılır).
     *
     * [absentPayload]: istemcinin OPT'si yoksa ilan edilecek UDP yük boyutu (varsa istemcinin kendi değeri korunur).
     */
    fun sanitizeQuery(q: ByteArray, off: Int, len: Int, pad: Boolean, absentPayload: Int): Sanitized? {
        if (len < Packets.DNS_HDR || off < 0 || off + len > q.size) return null
        val end = off + len
        val qd = Packets.u16(q, off + 4)
        val an = Packets.u16(q, off + 6)
        val ns = Packets.u16(q, off + 8)
        val ar = Packets.u16(q, off + 10)
        var p = off + Packets.DNS_HDR
        for (i in 0 until qd) {
            p = skipName(q, p, end)
            if (p < 0 || p + 4 > end) return null
            p += 4
        }
        for (i in 0 until an + ns) {
            p = skipName(q, p, end)
            if (p < 0 || p + 10 > end) return null
            val next = p + 10 + Packets.u16(q, p + 8)
            if (next > end) return null
            p = next
        }
        val arStart = p
        val keep = java.io.ByteArrayOutputStream()
        var kept = 0
        var haveOpt = false
        var payload = absentPayload
        var optTtl = 0
        for (i in 0 until ar) {
            val begin = p
            p = skipName(q, p, end)
            if (p < 0 || p + 10 > end) return null
            val type = Packets.u16(q, p)
            val rrEnd = p + 10 + Packets.u16(q, p + 8)
            if (rrEnd > end) return null
            if (type == 41) {
                if (haveOpt || p != begin + 1) return null               // ikinci OPT ya da köksüz ad: bozuk
                haveOpt = true
                payload = Packets.u16(q, p + 2).coerceAtLeast(512)
                optTtl = Packets.i32(q, p + 4)
            } else {
                keep.write(q, begin, rrEnd - begin)
                kept++
            }
            p = rrEnd
        }
        // Seçenekler: yalnızca "alt ağ iletme" işareti. Sonra (isteğe bağlı) dolgu.
        val opts = java.io.ByteArrayOutputStream()
        opts.write(byteArrayOf(0, OPT_ECS.toByte(), 0, 4, 0, 1, 0, 0))
        val fixed = (arStart - off) + keep.size() + 11 + opts.size()       // dolgu seçeneği hariç toplam uzunluk
        var padLen = 0
        if (pad) padLen = (PAD_BLOCK - (fixed + 4) % PAD_BLOCK) % PAD_BLOCK
        val total = fixed + (if (pad) 4 + padLen else 0)
        val out = ByteArray(total)
        System.arraycopy(q, off, out, 0, arStart - off)
        Packets.put16(out, 10, kept + 1)
        var o = arStart - off
        val k = keep.toByteArray()
        System.arraycopy(k, 0, out, o, k.size)
        o += k.size
        out[o++] = 0                                                       // kök ad
        Packets.put16(out, o, 41); o += 2
        Packets.put16(out, o, payload); o += 2
        Packets.put32(out, o, optTtl); o += 4
        val rdLen = opts.size() + (if (pad) 4 + padLen else 0)
        Packets.put16(out, o, rdLen); o += 2
        val ob = opts.toByteArray()
        System.arraycopy(ob, 0, out, o, ob.size)
        o += ob.size
        if (pad) {
            Packets.put16(out, o, OPT_PADDING); o += 2
            Packets.put16(out, o, padLen)                                  // dolgu baytları sıfırdır (diziler sıfırla başlar)
        }
        return Sanitized(out, !haveOpt)
    }

    /**
     * Cevaptaki OPT kaydını (cevabın SON kaydıysa) çıkarır ve ek kayıt sayısını azaltır; yeni uzunluğu döner.
     * İstemci EDNS istemediği halde biz ekledikse, cevabı istemcinin beklediği biçime geri çevirir. Başka bir
     * durumda ya da mesaj bozuksa dokunmaz ve [n]'i döner.
     */
    fun stripOpt(b: ByteArray, base: Int, n: Int): Int {
        if (n < Packets.DNS_HDR || base < 0 || base + n > b.size) return n
        val end = base + n
        val qd = Packets.u16(b, base + 4)
        val total = Packets.u16(b, base + 6) + Packets.u16(b, base + 8) + Packets.u16(b, base + 10)
        val ar = Packets.u16(b, base + 10)
        if (ar == 0) return n
        var p = base + Packets.DNS_HDR
        for (i in 0 until qd) {
            p = skipName(b, p, end)
            if (p < 0 || p + 4 > end) return n
            p += 4
        }
        var lastBegin = -1
        var lastType = -1
        var lastEnd = -1
        for (i in 0 until total) {
            val begin = p
            p = skipName(b, p, end)
            if (p < 0 || p + 10 > end) return n
            val rrEnd = p + 10 + Packets.u16(b, p + 8)
            if (rrEnd > end) return n
            lastBegin = begin; lastType = Packets.u16(b, p); lastEnd = rrEnd
            p = rrEnd
        }
        if (lastType != 41 || lastEnd != end) return n
        Packets.put16(b, base + 10, ar - 1)
        return lastBegin - base
    }

    /** "name" için A kaydı sorgusu üretir (RD biti açık). */
    fun buildQuery(id: Int, name: String): ByteArray {
        val labels = name.split('.')
        var size = Packets.DNS_HDR + 1 + 4
        for (l in labels) size += 1 + l.length
        val b = ByteArray(size)
        Packets.put16(b, 0, id)
        Packets.put16(b, 2, 0x0100)
        Packets.put16(b, 4, 1)
        var p = Packets.DNS_HDR
        for (l in labels) {
            b[p++] = l.length.toByte()
            for (ch in l) b[p++] = ch.code.toByte()
        }
        b[p++] = 0
        Packets.put16(b, p, 1)       // A
        Packets.put16(b, p + 2, 1)   // IN
        return b
    }
}
