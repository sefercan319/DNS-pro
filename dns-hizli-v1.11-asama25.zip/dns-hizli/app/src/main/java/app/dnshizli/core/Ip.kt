package app.dnshizli.core

/**
 * IP adresi (literal) yardımcıları: IPv4 ve IPv6. Android'e bağlı değildir ve ASLA ad çözümlemesi yapmaz
 * (`InetAddress.getByName` bir ad verilirse DNS'e sorar; burada yalnızca yazım biçimi ayrıştırılır).
 */
object Ip {
    /** "1.2.3.4" ya da IPv6 yazımı; geçersizse null. Dönen dizi 4 (IPv4) ya da 16 (IPv6) bayttır. */
    fun parse(s: String): ByteArray? = parse4(s) ?: parse6(s)

    /** Her parçası 0..255 olan, ondalık "a.b.c.d" (öndeki sıfır ve boşluk kabul edilmez). */
    fun parse4(s: String): ByteArray? {
        val parts = s.split('.')
        if (parts.size != 4) return null
        val out = ByteArray(4)
        for (i in 0 until 4) {
            val p = parts[i]
            if (p.isEmpty() || p.length > 3 || p.any { it !in '0'..'9' }) return null
            if (p.length > 1 && p[0] == '0') return null
            val v = p.toInt()
            if (v > 255) return null
            out[i] = v.toByte()
        }
        return out
    }

    /**
     * RFC 4291 yazımı: tam, "::" ile kısaltılmış ve sondaki IPv4 ("::ffff:1.2.3.4"). Köşeli parantez, "%bölge" eki,
     * boşluk kabul edilmez. Geçersizse null.
     */
    fun parse6(s: String): ByteArray? {
        if (s.length < 2 || s.length > 45) return null
        for (c in s) if (!(c in '0'..'9' || c in 'a'..'f' || c in 'A'..'F' || c == ':' || c == '.')) return null
        val dbl = s.indexOf("::")
        if (dbl >= 0 && s.indexOf("::", dbl + 1) >= 0) return null          // ikinci "::" ya da ":::"
        val head: List<String>
        val tail: List<String>
        if (dbl >= 0) {
            val h = s.substring(0, dbl)
            val t = s.substring(dbl + 2)
            head = if (h.isEmpty()) emptyList() else h.split(':')
            tail = if (t.isEmpty()) emptyList() else t.split(':')
        } else {
            head = s.split(':')
            tail = emptyList()
        }
        val hw = words(head, allowV4Last = dbl < 0) ?: return null
        val tw = words(tail, allowV4Last = true) ?: return null
        val total = hw.size + tw.size
        if (dbl < 0 && total != 8) return null
        if (dbl >= 0 && total > 7) return null
        val out = ByteArray(16)
        for (i in hw.indices) { out[2 * i] = (hw[i] ushr 8).toByte(); out[2 * i + 1] = hw[i].toByte() }
        val base = 8 - tw.size
        for (i in tw.indices) { out[2 * (base + i)] = (tw[i] ushr 8).toByte(); out[2 * (base + i) + 1] = tw[i].toByte() }
        return out
    }

    private fun words(groups: List<String>, allowV4Last: Boolean): List<Int>? {
        val out = ArrayList<Int>(8)
        for ((i, g) in groups.withIndex()) {
            if (g.contains('.')) {
                if (!allowV4Last || i != groups.size - 1) return null
                val v4 = parse4(g) ?: return null
                out.add(((v4[0].toInt() and 0xFF) shl 8) or (v4[1].toInt() and 0xFF))
                out.add(((v4[2].toInt() and 0xFF) shl 8) or (v4[3].toInt() and 0xFF))
            } else {
                if (g.isEmpty() || g.length > 4) return null
                out.add(g.toInt(16))
            }
        }
        return out
    }

    fun isV6(s: String): Boolean = parse6(s) != null
    fun isV4(s: String): Boolean = parse4(s) != null
    fun isAddress(s: String): Boolean = parse(s) != null

    /** Adresin yazımı: IPv4 "a.b.c.d"; IPv6 küçük harfli, en uzun sıfır dizisi "::" ile kısaltılmış (RFC 5952). */
    fun format(b: ByteArray): String {
        if (b.size == 4) return "${b[0].toInt() and 0xFF}.${b[1].toInt() and 0xFF}.${b[2].toInt() and 0xFF}.${b[3].toInt() and 0xFF}"
        require(b.size == 16) { "geçersiz adres uzunluğu" }
        val w = IntArray(8) { ((b[2 * it].toInt() and 0xFF) shl 8) or (b[2 * it + 1].toInt() and 0xFF) }
        var bestStart = -1
        var bestLen = 0
        var i = 0
        while (i < 8) {
            if (w[i] == 0) {
                var j = i
                while (j < 8 && w[j] == 0) j++
                if (j - i > bestLen) { bestStart = i; bestLen = j - i }
                i = j
            } else i++
        }
        if (bestLen < 2) bestStart = -1
        val sb = StringBuilder()
        var k = 0
        while (k < 8) {
            if (k == bestStart) {
                sb.append("::")
                k += bestLen
                continue
            }
            if (sb.isNotEmpty() && sb[sb.length - 1] != ':') sb.append(':')
            sb.append(Integer.toHexString(w[k]))
            k++
        }
        return sb.toString()
    }

    /**
     * Herkese açık, tek noktaya yayın (global unicast) IPv6 adresi mi? 2000::/3 aralığı; belgeleme (2001:db8::/32,
     * 3fff::/20), Teredo (2001::/32) ve 6to4 (2002::/16) hariç.
     */
    fun isGlobalV6(b: ByteArray): Boolean {
        if (b.size != 16) return false
        val b0 = b[0].toInt() and 0xFF
        val b1 = b[1].toInt() and 0xFF
        if ((b0 and 0xE0) != 0x20) return false
        if (b0 == 0x20 && b1 == 0x01) {
            val b2 = b[2].toInt() and 0xFF
            val b3 = b[3].toInt() and 0xFF
            if (b2 == 0x00 && b3 == 0x00) return false               // Teredo
            if (b2 == 0x0D && b3 == 0xB8) return false              // belgeleme
        }
        if (b0 == 0x20 && b1 == 0x02) return false                    // 6to4
        if (b0 == 0x3F && b1 == 0xFF && (b[2].toInt() and 0xF0) == 0) return false   // belgeleme
        return true
    }

    /** İki adresin ilk [bytes] baytı aynı mı (aynı ağ öneki)? Aileleri farklıysa false. */
    fun sameNet(a: ByteArray, b: ByteArray, bytes: Int): Boolean {
        if (a.size != b.size || bytes > a.size) return false
        for (i in 0 until bytes) if (a[i] != b[i]) return false
        return true
    }

    /** Herkese açık IPv4 mi ([Dns.isGlobalIpv4]). */
    fun isGlobalV4(b: ByteArray): Boolean =
        b.size == 4 && Dns.isGlobalIpv4(b[0].toInt() and 0xFF, b[1].toInt() and 0xFF, b[2].toInt() and 0xFF, b[3].toInt() and 0xFF)

    /** Herkese açık (IPv4 ya da IPv6) tek noktaya yayın adresi mi? */
    fun isGlobal(b: ByteArray): Boolean = if (b.size == 4) isGlobalV4(b) else isGlobalV6(b)
}
