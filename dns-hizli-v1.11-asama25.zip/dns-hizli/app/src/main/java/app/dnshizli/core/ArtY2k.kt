package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Y2K: holografik, yanardöner pastel pembe, mor, mavi ve nane; parlak krom kalpler, cam gibi baloncuklar, dört köşeli
 * parıltılar, piksel pencereler (yükleme çubuklu) ve hafif tane dokusu. Düğmeler yanardöner şeker, kartlar renk
 * değiştiren krom çerçeveli buzlu cam. Renk teması hafifçe karışır.
 * Hareket: yaylı (geri sekmeli) açılış; kürede ışık taraması ve dönen parıltı.
 */
class Y2kArt(theme: AeroTheme, glass: Float) : AeroArt(theme, glass) {
    override val style: UiStyle get() = UiStyle.Y2K
    override val particleMode: ParticleMode get() = ParticleMode.TWINKLE
    override val liveSky: Boolean get() = true
    override val motion: StyleMotion = StyleMotion(PageMotion.POP, 0.42f, 0.03f, 1f, depth = 1.6f, up = SpringSpec.JELLY, toggle = SpringSpec.JELLY, fx = FxKind.SPARK)

    private val ice = 0xFFFFE6F7.toInt()
    private val cyan = 0xFF7FE3FF.toInt()
    private val silver = 0xFFA99BD8.toInt()
    private val pop1 = 0xFFFF6FC8.toInt()   // sıcak pembe
    private val pop2 = 0xFFB28CFF.toInt()   // mor
    private val mint = 0xFFA6FFE0.toInt()

    // ------------------------------------------------------------------ parıltı (dört köşeli yıldız)

    private val star = GPath().apply {
        moveTo(0f, -1f)
        quadTo(0.13f, -0.13f, 1f, 0f)
        quadTo(0.13f, 0.13f, 0f, 1f)
        quadTo(-0.13f, 0.13f, -1f, 0f)
        quadTo(-0.13f, -0.13f, 0f, -1f)
        close()
    }
    private val starFill = Fill.radial(0f, 0f, 1f, white(1f), white(0.92f), Rgb.alpha(ice, 0.85f), 0.45f)
    private val starPink = Fill.radial(0f, 0f, 1f, white(1f), Rgb.alpha(pop1, 0.95f), Rgb.alpha(pop1, 0.80f), 0.40f)
    private val starCyan = Fill.radial(0f, 0f, 1f, white(1f), Rgb.alpha(cyan, 0.95f), Rgb.alpha(cyan, 0.80f), 0.40f)
    private val starGlow = Fill.radial(0f, 0f, 1f, white(if (dark) 0.40f else 0.55f), white(0f))

    private fun sparkle(g: Gfx, x: Float, y: Float, r: Float, a: Float, tone: Int = 0) {
        if (a <= 0.02f) return
        g.save(); g.translate(x, y); g.alpha(min(1f, a))
        g.save(); g.scale(r * 1.7f, r * 1.7f); g.paint(starGlow); g.circle(0f, 0f, 1f); g.restore()
        g.scale(r, r); g.paint(if (tone == 1) starPink else if (tone == 2) starCyan else starFill); g.path(star)
        g.restore()
    }

    override fun particle(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float, phase: Float) {
        val tw = 0.5f + 0.5f * sin(phase * 2f)
        val tone = ((phase * 3.1f).toInt() and 0x7fffffff) % 6
        sparkle(g, cx, cy, r * (0.45f + 0.65f * tw), alpha * (0.25f + 0.75f * tw), if (tone == 0) 1 else if (tone == 3) 2 else 0)
    }

    override fun bubble(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float) = particle(g, cx, cy, r, alpha, 0.8f)

    // ------------------------------------------------------------------ gökyüzü

    private class Backdrop(val w: Float, val h: Float, art: Y2kArt) {
        val th = art.theme
        val dk = art.dark
        private val p0 = if (dk) 0xFF2A0F55.toInt() else 0xFFFFD6F0.toInt()
        private val p1 = if (dk) 0xFF1B2A6B.toInt() else 0xFFCDB8FF.toInt()
        private val p2 = if (dk) 0xFF0E3A66.toInt() else 0xFFB4F0FF.toInt()
        // Tema rengi hafifçe karışır (%28); görünümü holografik pastel belirler.
        val base = Fill.linear(0f, 0f, 0f, h,
            Rgb.lerp(p0, th.skyTop, 0.28f), Rgb.lerp(p1, th.skyMid, 0.28f), Rgb.lerp(p2, th.skyBottom, 0.28f), 0.52f)
        private val ha = if (dk) 0.22f else 0.46f
        val holoA = Fill.linear(-w * 0.2f, 0f, w * 1.2f, h * 0.9f,
            Rgb.alpha(art.pop1, ha), Rgb.alpha(art.cyan, ha * 1.1f), Rgb.alpha(art.pop2, ha), 0.5f)
        val holoB = Fill.linear(w * 1.1f, 0f, -w * 0.1f, h,
            Rgb.alpha(art.mint, ha * 0.8f), Rgb.alpha(Rgb.WHITE, ha * 0.9f), Rgb.alpha(art.pop1, ha * 0.8f), 0.5f)
        val flare = Fill.radial(0f, 0f, 1f, Rgb.alpha(Rgb.WHITE, if (dk) 0.16f else 0.75f), Rgb.alpha(art.cyan, if (dk) 0.06f else 0.22f), Rgb.alpha(art.cyan, 0f), 0.45f)
        // parlak krom kalp: birim koordinatlarda
        val heart = GPath().apply {
            moveTo(0f, 0.92f)
            cubicTo(-1.35f, -0.05f, -1.05f, -1.05f, 0f, -0.38f)
            cubicTo(1.05f, -1.05f, 1.35f, -0.05f, 0f, 0.92f)
            close()
        }
        val heartFill = Fill.linear(-1f, -1f, 1f, 1f,
            Rgb.alpha(Rgb.WHITE, if (dk) 0.55f else 0.98f), Rgb.alpha(art.pop1, if (dk) 0.70f else 0.92f),
            Rgb.alpha(art.pop2, if (dk) 0.60f else 0.90f), 0.55f)
        val heartShine = Fill.radial(-0.40f, -0.50f, 0.60f, Rgb.alpha(Rgb.WHITE, if (dk) 0.55f else 0.97f), Rgb.alpha(Rgb.WHITE, 0f))
        val bubbleFill = Fill.radial(-0.30f, -0.35f, 1.25f, Rgb.alpha(Rgb.WHITE, if (dk) 0.40f else 0.85f),
            Rgb.alpha(art.cyan, if (dk) 0.18f else 0.30f), Rgb.alpha(art.pop1, if (dk) 0.30f else 0.42f), 0.62f)
        val winBar = Fill.linear(0f, 0f, 1f, 0f, Rgb.alpha(art.pop1, 0.92f), Rgb.alpha(art.pop2, 0.92f))
    }

    private var back: Backdrop? = null

    private fun backdrop(w: Float, h: Float): Backdrop {
        var b = back
        if (b == null || b.w != w || b.h != h) { b = Backdrop(w, h, this); back = b }
        return b
    }

    override fun sky(g: Gfx, w: Float, h: Float) = skyFrame(g, w, h, false, 0f)

    private fun chromeHeart(g: Gfx, b: Backdrop, x: Float, y: Float, r: Float, rot: Float) {
        g.save(); g.translate(x, y); g.rotate(rot); g.scale(r, r)
        g.paint(b.heartFill); g.path(b.heart)
        g.paint(b.heartShine); g.path(b.heart)
        g.strokeWidth(0.045f); g.paint(white(if (dark) 0.60f else 0.98f)); g.strokePath(b.heart)
        g.restore()
    }

    private fun glossBubble(g: Gfx, b: Backdrop, x: Float, y: Float, r: Float) {
        g.save(); g.translate(x, y); g.scale(r, r)
        g.paint(b.bubbleFill); g.circle(0f, 0f, 1f)
        g.strokeWidth(0.05f); g.paint(white(if (dark) 0.45f else 0.90f)); g.strokeCircle(0f, 0f, 0.97f)
        g.paint(white(if (dark) 0.55f else 0.95f)); g.oval(-0.62f, -0.70f, -0.08f, -0.38f)
        g.restore()
    }

    /** Piksel pencere: başlık çubuğu, üç nokta ve parça parça dolan yükleme çubuğu. */
    private fun pixelWindow(g: Gfx, b: Backdrop, x: Float, y: Float, w: Float, t: Float) {
        val h = w * 0.62f
        g.save(); g.translate(x, y)
        g.paint(white(if (dark) 0.14f else 0.55f)); g.rect(0f, 0f, w, h)
        g.paint(Rgb.alpha(pop2, if (dark) 0.75f else 0.85f)); g.rect(0f, 0f, w, h * 0.22f)
        val d = h * 0.07f
        for (i in 0 until 3) { g.paint(white(0.95f)); g.rect(h * 0.07f + i * d * 2.2f, h * 0.075f, h * 0.07f + i * d * 2.2f + d, h * 0.075f + d) }
        g.strokeWidth(1.6f); g.paint(white(if (dark) 0.60f else 0.98f)); g.strokeRoundRect(0.8f, 0.8f, w - 0.8f, h - 0.8f, 0f)
        // yükleme çubuğu
        val bx = w * 0.10f
        val bw = w * 0.80f
        val by = h * 0.58f
        val bh = h * 0.18f
        g.strokeWidth(1.3f); g.paint(white(if (dark) 0.70f else 0.98f)); g.strokeRoundRect(bx, by, bx + bw, by + bh, 0f)
        val n = 8
        val fill = ((t * 0.45f) % 1.25f / 1.25f * (n + 2)).toInt().coerceAtMost(n)
        val sw = (bw - 4f) / n
        for (i in 0 until fill) { g.paint(if (i % 2 == 0) pop1 else pop2); g.rect(bx + 2f + i * sw + 0.6f, by + 2f, bx + 2f + (i + 1) * sw - 0.6f, by + bh - 2f) }
        g.restore()
    }

    override fun skyFrame(g: Gfx, w: Float, h: Float, live: Boolean, time: Float) {
        val b = backdrop(w, h)
        g.paint(b.base); g.rect(0f, 0f, w, h)
        val t = if (live) time else 0f
        // iki yanardöner şerit zıt yönlerde yavaşça kayar
        g.save(); g.translate(sin(t * 0.22f) * w * 0.28f, 0f)
        g.paint(b.holoA); g.rect(-w * 0.6f, 0f, w * 1.8f, h)
        g.restore()
        g.save(); g.translate(cos(t * 0.17f) * w * 0.22f, 0f)
        g.paint(b.holoB); g.rect(-w * 0.6f, 0f, w * 1.8f, h)
        g.restore()
        // yumuşak ışık lekeleri
        for (i in 0 until 3) {
            val x = w * (0.2f + 0.3f * i) + sin(t * 0.25f + i * 2f) * w * 0.05f
            val y = h * (0.12f + 0.30f * i) + cos(t * 0.2f + i) * h * 0.03f
            g.save(); g.translate(x, y); g.scale(w * (0.55f - 0.08f * i), w * (0.55f - 0.08f * i)); g.paint(b.flare); g.circle(0f, 0f, 1f); g.restore()
        }
        // tane dokusu: sabit rastgele noktalar
        var s = 7919
        val ga = if (dark) 0.10f else 0.14f
        for (i in 0 until 110) {
            s = s * 1103515245 + 12345
            val fx = ((s ushr 8) and 0xFFFF) / 65535f
            s = s * 1103515245 + 12345
            val fy = ((s ushr 8) and 0xFFFF) / 65535f
            g.paint(if (i and 1 == 0) white(ga) else Rgb.alpha(pop2, ga))
            g.rect(fx * w, fy * h, fx * w + 1.6f, fy * h + 1.6f)
        }
        // piksel pencereler
        pixelWindow(g, b, w * 0.69f + sin(t * 0.2f) * 3f, h * 0.125f, w * 0.27f, t)
        // baloncuklar
        glossBubble(g, b, w * 0.12f + sin(t * 0.3f) * 5f, h * 0.30f, w * 0.07f)
        glossBubble(g, b, w * 0.90f, h * 0.52f + cos(t * 0.27f) * 6f, w * 0.10f)
        glossBubble(g, b, w * 0.72f + sin(t * 0.33f + 1f) * 4f, h * 0.90f, w * 0.055f)
        glossBubble(g, b, w * 0.30f, h * 0.60f + cos(t * 0.21f) * 5f, w * 0.035f)
        // krom kalpler
        chromeHeart(g, b, w * 0.06f + sin(t * 0.19f) * w * 0.015f, h * 0.15f + cos(t * 0.15f) * h * 0.012f, w * 0.14f, -14f + sin(t * 0.1f) * 5f)
        chromeHeart(g, b, w * 0.94f + cos(t * 0.17f) * w * 0.015f, h * 0.96f + sin(t * 0.13f) * h * 0.01f, w * 0.17f, 16f + cos(t * 0.1f) * 5f)
        chromeHeart(g, b, w * 0.80f, h * 0.31f + sin(t * 0.23f) * h * 0.01f, w * 0.06f, 12f)
        // sabit büyük parıltılar
        sparkle(g, w * 0.46f, h * 0.20f, w * 0.040f * (0.8f + 0.2f * sin(t * 1.9f)), 0.95f, 1)
        sparkle(g, w * 0.24f, h * 0.44f, w * 0.028f * (0.8f + 0.2f * sin(t * 2.3f + 1f)), 0.9f, 2)
        sparkle(g, w * 0.66f, h * 0.70f, w * 0.034f * (0.8f + 0.2f * sin(t * 2.1f + 2f)), 0.9f)
    }

    // ------------------------------------------------------------------ krom

    private val chromeCache = LongCache<Fill>(40)

    private fun chrome(h: Float, vertical: Boolean = true): Fill {
        val k = key(1f, h, if (vertical) 11f else 12f)
        var f = chromeCache[k]
        if (f == null) {
            val c0 = white(0.98f)
            val c1 = Rgb.alpha(silver, 0.92f)
            f = if (vertical) Fill.linear(0f, 0f, 0f, h, c0, c1, c0, 0.55f) else Fill.linear(0f, 0f, h, h, c0, c1, c0, 0.55f)
            chromeCache[k] = f
        }
        return f
    }

    // ------------------------------------------------------------------ kart

    private class CardP(val w: Float, val h: Float, art: Y2kArt) {
        val body = Fill.linear(0f, 0f, 0f, h, art.tint(art.aTop), art.tint(art.aBot))
        val bodyStrong = Fill.linear(0f, 0f, 0f, h, Rgb.alpha(art.theme.skyTop, 0.97f), Rgb.alpha(art.theme.skyMid, 0.97f))
        val holo = Fill.linear(0f, 0f, w, h, Rgb.alpha(art.pop1, 0.95f), Rgb.alpha(art.cyan, 0.95f), Rgb.alpha(art.pop2, 0.95f), 0.5f)
        val gloss = GPath()
        val glossFill: Fill

        init {
            val rr = min(14f, min(w, h) / 2f)
            gloss.arc(rr, rr, rr, rr, 180f, 90f, false)
            gloss.lineTo(w - rr, 0f)
            gloss.arc(w - rr, rr, rr, rr, -90f, 90f, true)
            gloss.lineTo(w, h * 0.38f)
            gloss.quadTo(w * 0.5f, h * 0.52f, 0f, h * 0.38f)
            gloss.close()
            glossFill = Fill.linear(0f, 0f, 0f, h * 0.5f, art.white(if (art.dark) 0.18f else 0.55f), art.white(0.04f))
        }
    }

    private val cardPs = LongCache<CardP>(80)

    override fun card(
        g: Gfx, l: Float, t: Float, r: Float, b: Float, rad: Float,
        selected: Float, press: Float, strong: Float, shadow: Float,
    ) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        val rr = min(rad, min(w, h) / 2f)
        val k = key(w, h, 13f)
        var p = cardPs[k]
        if (p == null) { p = CardP(w, h, this); cardPs[k] = p }
        g.save(); g.translate(l, t)
        if (shadow > 0f) {
            g.strokeWidth(2.2f)
            val base = (if (dark) 0.20f else 0.12f) * shadow
            for (i in 0 until 5) {
                val f = 1f - i / 5f
                g.paint(Rgb.alpha(if (dark) 0xFF000000.toInt() else 0xFF3B5E8C.toInt(), base * f * f))
                val e = 0.9f + i * 1.9f
                g.strokeRoundRect(-e, -e + 2f, w + e, h + e + 2f, rr + e)
            }
        }
        g.paint(p.body); g.roundRect(0f, 0f, w, h, rr)
        if (strong > 0f) { g.save(); g.alpha(strong); g.paint(p.bodyStrong); g.roundRect(0f, 0f, w, h, rr); g.restore() }
        if (selected > 0f) { g.save(); g.alpha(selected); g.paint(Rgb.alpha(theme.accent, 0.16f)); g.roundRect(0f, 0f, w, h, rr); g.restore() }
        g.paint(p.glossFill); g.path(p.gloss)
        // kalın krom kenar
        g.strokeWidth(2.4f); g.paint(p.holo); g.strokeRoundRect(1.2f, 1.2f, w - 1.2f, h - 1.2f, max(0f, rr - 1.2f))
        g.strokeWidth(1f); g.paint(white(if (dark) 0.30f else 0.85f)); g.strokeRoundRect(3f, 3f, w - 3f, h - 3f, max(0f, rr - 3f))
        if (selected > 0f) {
            g.save(); g.alpha(selected)
            g.strokeWidth(2.2f); g.paint(theme.accent); g.strokeRoundRect(1.2f, 1.2f, w - 1.2f, h - 1.2f, max(0f, rr - 1.2f))
            g.restore()
        }
        // köşe parıltıları: sönüp yanar
        if (strong <= 0.5f && w >= 80f && h >= 40f) {
            val n = min(3, 1 + (h / 120f).toInt())
            var s = (w * 5f).toInt() * 31 + (h * 5f).toInt()
            for (i in 0 until n) {
                s = s * 1103515245 + 12345
                val fx = ((s ushr 8) and 0xFFFF) / 65535f
                s = s * 1103515245 + 12345
                val fy = ((s ushr 8) and 0xFFFF) / 65535f
                val tw = 0.5f + 0.5f * sin(clock * 1.8f + i * 2.1f + fx * 6f)
                sparkle(g, w * (0.50f + 0.44f * fx), 6f + min(26f, h * 0.30f) * fy, 2.6f + 2.2f * tw, 0.35f + 0.65f * tw, if (i == 0 && fx > 0.6f) 1 else 0)
            }
        }
        if (press > 0f) { g.save(); g.alpha(press); g.paint(Rgb.alpha(theme.accent, 0.20f)); g.roundRect(0f, 0f, w, h, rr); g.restore() }
        g.restore()
    }

    // ------------------------------------------------------------------ şeker düğme

    private class CandyP(val w: Float, val h: Float, art: Y2kArt) {
        val body = Fill.linear(0f, 0f, 0f, h, art.theme.control, art.theme.controlDeep)
        val glow = Fill.radial(w * 0.5f, h * 1.1f, w * 0.55f, Rgb.alpha(art.theme.accentLight, 0.80f), Rgb.alpha(art.theme.accentLight, 0f))
        val holoOver = Fill.linear(0f, 0f, w, h, Rgb.alpha(art.pop1, 0.50f), Rgb.alpha(art.cyan, 0.42f), Rgb.alpha(art.pop2, 0.50f), 0.5f)
        val upper = GPath()
        val upperFill = Fill.linear(0f, 0f, 0f, h * 0.5f, art.white(0.78f), art.white(0.12f))

        init {
            val k = min(w, h) / 2f
            upper.arc(k, k, k, k, 180f, 90f, false)
            upper.lineTo(w - k, 0f)
            upper.arc(w - k, k, k, k, -90f, 90f, true)
            upper.lineTo(w, h * 0.5f)
            upper.quadTo(w * 0.5f, h * 0.60f, 0f, h * 0.5f)
            upper.close()
        }
    }

    private val candyPs = LongCache<CandyP>(40)

    private fun candy(g: Gfx, w: Float, h: Float, press: Float, shadow: Float) {
        val k = key(w, h, 14f)
        var p = candyPs[k]
        if (p == null) { p = CandyP(w, h, this); candyPs[k] = p }
        if (shadow > 0f) {
            g.strokeWidth(2.2f)
            for (i in 0 until 4) {
                val f = 1f - i / 4f
                g.paint(Rgb.alpha(theme.controlDeep, (if (dark) 0.26f else 0.16f) * shadow * f * f))
                val e = 1.1f + i * 1.9f
                g.strokeRoundRect(-e, -e + 2f, w + e, h + e + 2f, h / 2f + e)
            }
        }
        g.paint(p.body); g.roundRect(0f, 0f, w, h, h / 2f)
        g.paint(p.holoOver); g.roundRect(0f, 0f, w, h, h / 2f)
        g.save(); g.clipRoundRect(0f, 0f, w, h, h / 2f); g.paint(p.glow); g.rect(0f, h * 0.45f, w, h); g.restore()
        g.paint(p.upperFill); g.path(p.upper)
        g.strokeWidth(1.8f); g.paint(chrome(h)); g.strokeRoundRect(0.9f, 0.9f, w - 0.9f, h - 0.9f, h / 2f - 0.9f)
        if (w > 40f) sparkle(g, w * 0.82f, h * 0.30f, 2.4f + 1.6f * (0.5f + 0.5f * sin(clock * 2.2f + w * 0.07f)), 0.9f)
        if (press > 0f) { g.save(); g.alpha(press); g.paint(Rgb.alpha(theme.shadow, 0.24f)); g.roundRect(0f, 0f, w, h, h / 2f); g.restore() }
    }

    override fun pill(g: Gfx, l: Float, t: Float, r: Float, b: Float, press: Float, shadow: Float) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        g.save(); g.translate(l, t); candy(g, w, h, press, shadow); g.restore()
    }

    private val knobChrome = Fill.radial(-0.25f, -0.35f, 1.35f, white(1f), Rgb.alpha(silver, 0.95f), white(0.98f), 0.62f)

    private fun chromeKnob(g: Gfx, cx: Float, cy: Float, r: Float, press: Float) {
        g.paint(Rgb.alpha(theme.shadow, if (dark) 0.40f else 0.26f)); g.circle(cx, cy + 1.6f, r + 0.6f)
        g.save(); g.translate(cx, cy); g.scale(r, r); g.paint(knobChrome); g.circle(0f, 0f, 1f); g.restore()
        g.strokeWidth(1f); g.paint(white(0.95f)); g.strokeCircle(cx, cy, r - 0.5f)
        g.paint(Rgb.alpha(cyan, 0.60f)); g.oval(cx - r * 0.5f, cy - r * 0.78f, cx + r * 0.5f, cy - r * 0.2f)
        if (press > 0f) { g.save(); g.alpha(press); g.paint(Rgb.alpha(theme.accent, 0.25f)); g.circle(cx, cy, r); g.restore() }
    }

    override fun switch(g: Gfx, l: Float, t: Float, w: Float, h: Float, on: Float, press: Float) {
        val o = on.coerceIn(0f, 1f)
        g.save(); g.translate(l, t)
        g.paint(insetFill(h)); g.roundRect(0f, 0f, w, h, h / 2f)
        if (o > 0.001f) { g.save(); g.alpha(o); candy(g, w, h, 0f, 0f); g.restore() }
        else { g.strokeWidth(1.4f); g.paint(chrome(h)); g.strokeRoundRect(0.7f, 0.7f, w - 0.7f, h - 0.7f, h / 2f - 0.7f) }
        chromeKnob(g, h / 2f + (w - h) * on.coerceIn(-0.12f, 1.12f), h / 2f, h / 2f - 3.2f + press * 0.9f, press)
        g.restore()
    }

    override fun slider(g: Gfx, l: Float, cy: Float, w: Float, v: Float, press: Float) {
        val th = 8f
        val kx = l + 12f + (w - 24f) * v.coerceIn(0f, 1f)
        g.save(); g.translate(l, cy - th / 2f)
        g.paint(insetFill(th)); g.roundRect(0f, 0f, w, th, th / 2f)
        val fw = (kx - l).coerceAtLeast(th)
        g.paint(onFill(th)); g.roundRect(0f, 0f, fw, th, th / 2f)
        g.paint(white(0.45f)); g.roundRect(1f, 0.8f, max(1.5f, fw - 1f), th * 0.5f, th / 2f - 0.8f)
        g.strokeWidth(1f); g.paint(white(if (dark) 0.35f else 0.85f)); g.strokeRoundRect(0.5f, 0.5f, w - 0.5f, th - 0.5f, th / 2f - 0.5f)
        g.restore()
        chromeKnob(g, kx, cy, 12f + press * 1.5f, press)
    }

    private val ringCache = LongCache<Fill>(6)

    private fun ringFill(r: Float): Fill {
        val k = key(r, r, 15f)
        var f = ringCache[k]
        if (f == null) { f = Fill.linear(-r, -r, r, r, white(1f), Rgb.alpha(silver, 0.95f), white(1f), 0.5f); ringCache[k] = f }
        return f
    }

    // ------------------------------------------------------------------ küre: krom halka, ışık taraması, parıltı

    override fun orb(g: Gfx, cx: Float, cy: Float, r: Float, level: Float, phase: Float, glow: Float, error: Float, press: Float) {
        super.orb(g, cx, cy, r, level, phase, glow, error, press)
        if (r < 24f) return
        g.save(); g.translate(cx, cy)
        // ışık taraması: her birkaç saniyede bir çapraz bir parlama küreyi geçer
        val sweep = ((clock * 0.22f) % 1.7f) / 1.7f
        if (sweep < 0.62f) {
            val u = sweep / 0.62f
            g.save(); clipOrb(g, r, 2f); g.rotate(24f)
            g.translate(-r * 1.3f + u * r * 2.6f, 0f)
            g.alpha(0.34f * sin(u * PI.toFloat()))
            g.paint(white(1f)); g.rect(-r * 0.10f, -r * 1.5f, r * 0.10f, r * 1.5f)
            g.paint(white(0.45f)); g.rect(-r * 0.26f, -r * 1.5f, -r * 0.10f, r * 1.5f)
            g.restore()
        }
        // krom halka
        g.strokeWidth(3.2f); g.paint(ringFill(r))
        if (orbShape == OrbShape.CIRCLE) g.strokeCircle(0f, 0f, r + 1.2f) else g.strokePath(orbPath(r, 1.2f))
        g.restore()
        sparkle(g, cx + r * decoX(1), cy + r * decoY(1), r * 0.15f * (0.7f + 0.3f * sin(clock * 2.4f)), 0.95f)
        sparkle(g, cx + r * decoX(2), cy + r * decoY(2), r * 0.08f * (0.7f + 0.3f * sin(clock * 3.1f + 1f)), 0.8f)
    }
}
