package app.dnshizli.core

/**
 * Artan bir toplam sayaçtan ("bu oturumda N") son [windowMs] içindeki artışı çıkarır. Toplam sayaç düşerse (yeni oturum)
 * geçmiş atılır. Taban örnekleri en az [minGapMs] arayla tutulur; en son değer ayrıca saklanır, bu yüzden sık çağrı
 * tabanı bozmaz. Bellek sabittir ([CAP] örnek). Saf Kotlin, bilgisayarda sınanır.
 */
class RollingCounter(private val windowMs: Long = 10 * 60_000L, private val minGapMs: Long = 5_000L) {
    private val times = LongArray(CAP)
    private val values = LongArray(CAP)
    private var head = 0      // en eski taban örneğin yeri
    private var size = 0
    private var lastValue = 0L

    private fun at(i: Int) = (head + i) % CAP

    /** [total] şu anki toplam sayaç, [nowMs] saat. */
    fun record(nowMs: Long, total: Long) {
        if (size > 0 && total < lastValue) clear()
        lastValue = total
        if (size == 0 || nowMs - times[at(size - 1)] >= minGapMs) {
            if (size == CAP) { head = (head + 1) % CAP; size-- }
            val j = at(size)
            times[j] = nowMs; values[j] = total; size++
        }
        // Pencereden eskiyen tabanları at; pencereye en yakın (en az [windowMs] yaşında) olan taban kalır.
        while (size > 1 && nowMs - times[at(1)] >= windowMs) { head = (head + 1) % CAP; size-- }
    }

    /** Son pencere içindeki artış (0 = yok ya da veri yok). */
    fun recent(): Long = if (size == 0) 0L else (lastValue - values[head]).coerceAtLeast(0L)

    fun clear() { head = 0; size = 0; lastValue = 0L }

    private companion object { const val CAP = 130 }   // 10 dk / 5 sn = 120, biraz pay
}
