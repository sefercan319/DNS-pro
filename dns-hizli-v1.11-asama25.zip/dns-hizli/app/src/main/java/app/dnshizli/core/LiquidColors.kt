package app.dnshizli.core

/**
 * Ana düğmedeki sıvının rengi. Ayarda 6 haneli onaltılı renk olarak tutulur; boş = temanın kendi rengi (varsayılan).
 * Seçenekler [PALETTE]: 50 renk, kabaca renk çemberi sırasında, sonda nötrler. Paletin dışındaki girdiler atılır.
 */
object LiquidColors {
    val PALETTE: IntArray = intArrayOf(
        0xFF3B30, 0xE53935, 0xC62828, 0xFF5252, 0xFF6F61, 0xFF8A65, 0xFF7043, 0xFF9500, 0xFFA726, 0xFFB300,
        0xFFC107, 0xFFD600, 0xFFEB3B, 0xD4E157, 0xC0CA33, 0x9CCC65, 0x7CB342, 0x4CAF50, 0x2E7D32, 0x00C853,
        0x3DDC84, 0x1DE9B6, 0x00BFA5, 0x26A69A, 0x00ACC1, 0x00BCD4, 0x26C6DA, 0x4DD0E1, 0x29B6F6, 0x03A9F4,
        0x0288D1, 0x1E88E5, 0x2979FF, 0x3F51B5, 0x5C6BC0, 0x651FFF, 0x7C4DFF, 0x9575CD, 0xAB47BC, 0x8E24AA,
        0xD500F9, 0xE040FB, 0xFF4081, 0xF50057, 0xEC407A, 0xF48FB1, 0x8D6E63, 0x6D4C41, 0x90A4AE, 0x455A64,
    )

    const val COUNT = 50

    /** Palet rengi için ayar değeri ("RRGGBB", büyük harf). */
    fun id(rgb: Int): String = "%06X".format(rgb and 0xFFFFFF)

    /** Ayar değerini doğrular: palette olan renk aynen, aksi hâlde "" (temanın rengi). */
    fun clean(s: String?): String {
        if (s == null || s.length != 6) return ""
        val v = s.toIntOrNull(16) ?: return ""
        return if (PALETTE.contains(v) && id(v) == s.uppercase()) id(v) else ""
    }

    /** Çizim için opak ARGB; 0 = temanın rengi. */
    fun argb(s: String?): Int {
        val c = clean(s)
        return if (c.isEmpty()) 0 else (0xFF shl 24) or c.toInt(16)
    }

    /** Palet sırası (0..49) ya da -1. */
    fun indexOf(s: String?): Int { val c = clean(s); return if (c.isEmpty()) -1 else PALETTE.indexOf(c.toInt(16)) }
}
