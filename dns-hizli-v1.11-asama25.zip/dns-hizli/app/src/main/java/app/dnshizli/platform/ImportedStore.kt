package app.dnshizli.platform

import android.content.Context
import app.dnshizli.core.FilterNames
import app.dnshizli.core.HostsList
import java.io.File

/**
 * Kullanıcının içe aktardığı engel listesi: uygulamanın kendi klasöründe düz metin (satır başına bir alan adı). Ayarlara ya da
 * dışa aktarma koduna girmez, yedeklenmez, hiçbir yere gönderilmez. Yazma önce geçici dosyaya yapılıp yeniden adlandırılır;
 * yarım kalan yazma eski listeyi bozmaz.
 */
object ImportedStore {
    private const val FILE = "my-blocklist.txt"
    private const val TMP = "my-blocklist.tmp"

    private fun file(ctx: Context) = File(ctx.filesDir, FILE)

    /** Dosyadaki temiz, tekrarsız adlar; dosya yoksa ya da okunamıyorsa boş. */
    fun load(ctx: Context): List<String> = try {
        val f = file(ctx)
        if (!f.isFile) emptyList() else {
            val set = LinkedHashSet<String>()
            f.useLines(Charsets.UTF_8) { lines ->
                for (l in lines) {
                    if (set.size >= HostsList.MAX_IMPORTED) break
                    FilterNames.normalize(l)?.let { set.add(it) }
                }
            }
            set.toList()
        }
    } catch (_: Exception) { emptyList() }

    fun save(ctx: Context, names: List<String>): Boolean = try {
        if (names.isEmpty()) {
            file(ctx).delete()
            true
        } else {
            val tmp = File(ctx.filesDir, TMP)
            tmp.bufferedWriter(Charsets.UTF_8).use { w -> for (n in names.take(HostsList.MAX_IMPORTED)) { w.write(n); w.write("\n") } }
            val dst = file(ctx)
            if (!tmp.renameTo(dst)) { dst.delete(); tmp.renameTo(dst) } else true
        }
    } catch (_: Exception) { false }
}
