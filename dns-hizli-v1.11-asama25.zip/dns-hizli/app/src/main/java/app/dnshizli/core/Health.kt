package app.dnshizli.core

/**
 * Çalışan bağlantının sağlığını iki ölçüm arasındaki farktan anlar (saf mantık; zamanlayıcı ve onarma adımları servisin işidir).
 *
 * Şüpheli: iki ölçüm arasında en az [MIN_TIMEOUTS] sorgu zaman aşımına uğradı VE sunucudan hiç cevap gelmedi.
 * Sağlıklı: sunucudan en az bir cevap geldi. Önbellek ve engelleme cevapları sunucuyu sınamadığı için sayılmaz.
 * Yönlendirici değiştiyse (ya da sayaçlar geri gittiyse) karşılaştırma yeniden başlar.
 */
class HealthMonitor {
    enum class Verdict { IDLE, HEALTHY, SUSPECT }

    private var owner: Any? = null
    private var last: Stats? = null

    fun check(forwarder: Any, now: Stats): Verdict {
        val p = last
        val same = p != null && owner === forwarder && now.answered >= p.answered && now.timeouts >= p.timeouts
        owner = forwarder
        last = now
        if (!same) return Verdict.IDLE
        val answered = now.answered - p.answered
        val timeouts = now.timeouts - p.timeouts
        return when {
            answered > 0 -> Verdict.HEALTHY
            timeouts >= MIN_TIMEOUTS -> Verdict.SUSPECT
            else -> Verdict.IDLE
        }
    }

    fun reset() {
        owner = null
        last = null
    }

    companion object {
        const val MIN_TIMEOUTS = 3
    }
}

/**
 * Kendini onarma basamakları: her şüpheli ölçümde bir sonraki basamağa geçilir, sağlıklı ölçümde başa dönülür.
 * Basamaklar hafiften ağıra: 0 = aynı sunucuda yönlendiriciyi yenile, 1 = yedek sunucuya geç (ayarlıysa),
 * 2 = tüneli baştan kur. Sonrası seyrek tekrar (uzun bekleme) olur; kararsız bir ağda pil harcanmaz.
 */
object HealPlan {
    const val STEP_REFRESH = 0
    const val STEP_BACKUP = 1
    const val STEP_REBUILD = 2

    /** Bir onarma denemesinden sonra yenisi için en az beklenecek süre (ms). Üç basamaktan sonra uzar. */
    fun cooldownMs(step: Int): Long = if (step < 3) 60_000L else 10 * 60_000L
}
