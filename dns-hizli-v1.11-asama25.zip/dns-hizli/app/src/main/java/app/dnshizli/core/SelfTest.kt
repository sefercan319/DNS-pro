package app.dnshizli.core

import java.security.SecureRandom
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Bağlantı testinde DNSSEC doğrulamasının sonucu. */
enum class DnssecResult { VALIDATING, NOT_VALIDATING, UNKNOWN }

/** Bağlantı testinde reklam engellemenin sonucu. */
enum class AdBlockResult { BLOCKED, NOT_BLOCKED, UNKNOWN }

/**
 * Bağlantı testi sonucu: DNS gerçekten seçilen sunucudan cevap veriyor mu ([ok], [ms]), hangi yöntemle ([proto]),
 * sunucu DNSSEC doğruluyor mu, reklam alan adını engelliyor mu.
 */
data class SelfTestResult(
    val ok: Boolean,
    val ms: Int?,
    val proto: Proto?,
    val serverId: String?,
    val dnssec: DnssecResult,
    val ads: AdBlockResult,
    /** Tünelin IPv6 yolu sınandı mı ve cevap geldi mi? null: tünelde IPv6 yok (sınanmadı). */
    val v6: Boolean? = null,
)

/**
 * Tünelin içinden, gerçek bir uygulamanın soracağı gibi DNS soruları göndererek bağlantıyı sınar. Sorular sahte bir
 * istemci portundan ([PORT]) gelir; cevapları [Tap] yakalar (tünele yazılmaz, hiçbir uygulamaya gitmez).
 * Böylece test, sistemin çözümleyicisine ya da başka bir uygulamaya bağlı değildir ve JVM'de sınanabilir.
 *
 * Testler:
 *  - Rastgele bir ad: cevap geliyor mu, ne kadar sürede (NXDOMAIN da geçerli bir cevaptır).
 *  - [DNSSEC_FAIL_NAME]: imzası bilerek bozuk tutulan bir ad. Doğrulayan sunucu SERVFAIL döner; doğrulamayan adresi verir.
 *  - [AD_NAME]: yaygın bir reklam alan adı. Engelleyen sunucu 0.0.0.0 / NXDOMAIN / "engellendi" kodu döner.
 */
object SelfTest {
    /** Testin sahte istemci portu. Gerçek istemciler kaynak portu olarak ayrılmış düşük portları kullanmaz. */
    const val PORT = 7
    const val DNSSEC_FAIL_NAME = "dnssec-failed.org"
    const val AD_NAME = "pagead2.googlesyndication.com"
    /** Tünelin IPv4 adresleri (özel aralık; gerçek bir cihazla çakışmaz): istemci ve sahte DNS sunucusu. */
    const val CLIENT_ADDR = "10.111.222.1"
    const val FAKE_DNS = "10.111.222.2"
    const val CLIENT_ADDR6 = "fd6e:7368:a1c2::1"
    const val FAKE_DNS6 = "fd6e:7368:a1c2::2"
    private val CLIENT = Packets.ip(10, 111, 222, 1)
    private val FAKE = Packets.ip(10, 111, 222, 2)

    /** Tünelin IPv6 adresleri (ULA, fd00::/8): sahte istemci ve sahte DNS sunucusu. */
    val CLIENT6: ByteArray = Ip.parse6(CLIENT_ADDR6)!!
    val FAKE6: ByteArray = Ip.parse6(FAKE_DNS6)!!
    private val random = SecureRandom()

    /** Tünele yazılmak üzere olan paketlerden testin cevaplarını ayıklar. */
    class Tap {
        @Volatile private var q: LinkedBlockingQueue<ByteArray>? = null

        /** Paket testin cevabıysa yakalar ve true döner (tünele yazılmamalı). Her iş parçacığından çağrılabilir. */
        fun offer(b: ByteArray, off: Int, len: Int): Boolean {
            if (len >= Packets.HDR6 + Packets.DNS_HDR && ((b[off].toInt() and 0xF0) shr 4) == 6) {
                // IPv6: doğrudan UDP (parçalı ya da uzantı başlıklı cevaplar bu testte beklenmez)
                if ((b[off + 6].toInt() and 0xFF) != 17) return false
                if (Packets.u16(b, off + Packets.IP6_HDR + 2) != PORT) return false
                q?.offer(b.copyOfRange(off, off + len))
                return true
            }
            if (len < Packets.HDR + Packets.DNS_HDR) return false
            if ((b[off + 9].toInt() and 0xFF) != 17) return false
            if ((Packets.u16(b, off + 6) and 0x1FFF) != 0) return false       // ilk parça değil (UDP başlığı yok)
            if (Packets.u16(b, off + 22) != PORT) return false
            q?.offer(b.copyOfRange(off, off + len))
            return true
        }

        internal fun open(): LinkedBlockingQueue<ByteArray> = LinkedBlockingQueue<ByteArray>().also { q = it }
        internal fun close() { q = null }
    }

    /** Sahte istemciden sahte DNS adresine giden IPv4/UDP sorgu paketi. */
    fun packet(id: Int, name: String): ByteArray {
        val dns = Dns.buildQuery(id, name)
        val b = ByteArray(Packets.HDR + dns.size)
        System.arraycopy(dns, 0, b, Packets.HDR, dns.size)
        Packets.writeHeaders(b, CLIENT, FAKE, PORT, Packets.DNS_PORT, dns.size)
        return b
    }

    /** Sahte istemciden sahte IPv6 DNS adresine giden IPv6/UDP sorgu paketi. */
    fun packet6(id: Int, name: String): ByteArray {
        val dns = Dns.buildQuery(id, name)
        val b = ByteArray(Packets.HDR6 + dns.size)
        System.arraycopy(dns, 0, b, Packets.HDR6, dns.size)
        Packets.writeHeaders6(b, CLIENT6, FAKE6, PORT, Packets.DNS_PORT, dns.size)
        return b
    }

    /** Tünel paketinde DNS mesajının başladığı konum: IPv4'te 28, IPv6'da 48. */
    fun dnsOffset(packet: ByteArray): Int = if ((packet[0].toInt() and 0xF0) == 0x60) Packets.HDR6 else Packets.HDR

    /** DNSSEC sınamasının cevabını yorumlar ([reply]: tünel paketi, IP başlığından itibaren). */
    fun classifyDnssec(reply: ByteArray?): DnssecResult {
        if (reply == null) return DnssecResult.UNKNOWN
        val o = dnsOffset(reply)
        if (reply.size < o + Packets.DNS_HDR) return DnssecResult.UNKNOWN
        val flags = Packets.u16(reply, o + 2)
        val rcode = flags and 0xF
        val an = Packets.u16(reply, o + 6)
        return when {
            rcode == 2 -> DnssecResult.VALIDATING                         // SERVFAIL: bozuk imza reddedildi
            rcode == 0 && an > 0 -> DnssecResult.NOT_VALIDATING            // adres verildi: imza denetlenmedi
            else -> DnssecResult.UNKNOWN
        }
    }

    /** Reklam sınamasının cevabını yorumlar. */
    fun classifyAds(reply: ByteArray?): AdBlockResult {
        if (reply == null) return AdBlockResult.UNKNOWN
        val o = dnsOffset(reply)
        if (reply.size < o + Packets.DNS_HDR) return AdBlockResult.UNKNOWN
        val n = reply.size - o
        val flags = Packets.u16(reply, o + 2)
        val rcode = flags and 0xF
        val an = Packets.u16(reply, o + 6)
        return when {
            Dns.isBlocked(reply, o, n) -> AdBlockResult.BLOCKED
            rcode == 3 || rcode == 5 -> AdBlockResult.BLOCKED               // NXDOMAIN ya da REFUSED: var olan ad engellenmiş
            rcode == 0 && an > 0 -> AdBlockResult.NOT_BLOCKED
            else -> AdBlockResult.UNKNOWN
        }
    }

    /**
     * Testi çalıştırır: üç soru [inject] ile tünele (yönlendiricinin okuyucusuna) verilir, cevaplar [tap] ile toplanır.
     * [timeoutMs] içinde gelmeyen cevap "bilinmiyor" sayılır. Engelleyici bir çağrıdır (ana iş parçacığında çağırmayın).
     */
    fun run(
        inject: (ByteArray) -> Unit, tap: Tap, proto: Proto?, serverId: String?, timeoutMs: Long = 4000,
        nowMs: () -> Long = { System.nanoTime() / 1_000_000 },
        /** Tünelde IPv6 varsa dördüncü bir soru IPv6 yoluyla gönderilir ([SelfTestResult.v6]). */
        tunnelV6: Boolean = false,
    ): SelfTestResult {
        val queue = tap.open()
        try {
            val base = random.nextInt(0x10000 - 4)
            val idProbe = base
            val idSec = base + 1
            val idAds = base + 2
            val idV6 = base + 3
            val probeName = "dh" + java.lang.Long.toString(random.nextLong() ushr 1, 36) + ".example.com"
            val t0 = nowMs()
            inject(packet(idProbe, probeName))
            inject(packet(idSec, DNSSEC_FAIL_NAME))
            inject(packet(idAds, AD_NAME))
            if (tunnelV6) inject(packet6(idV6, "dh" + java.lang.Long.toString(random.nextLong() ushr 1, 36) + ".example.com"))
            var v6: ByteArray? = null
            var probe: ByteArray? = null
            var probeMs: Int? = null
            var sec: ByteArray? = null
            var ads: ByteArray? = null
            val deadline = t0 + timeoutMs
            while (probe == null || sec == null || ads == null || (tunnelV6 && v6 == null)) {
                val left = deadline - nowMs()
                if (left <= 0) break
                val r = queue.poll(left, TimeUnit.MILLISECONDS) ?: break
                when (Packets.u16(r, dnsOffset(r))) {
                    idProbe -> if (probe == null) { probe = r; probeMs = (nowMs() - t0).toInt() }
                    idSec -> sec = r
                    idAds -> ads = r
                    idV6 -> v6 = r
                }
            }
            return SelfTestResult(probe != null, probeMs, proto, serverId, classifyDnssec(sec), classifyAds(ads), if (tunnelV6) v6 != null else null)
        } finally {
            tap.close()
        }
    }
}
