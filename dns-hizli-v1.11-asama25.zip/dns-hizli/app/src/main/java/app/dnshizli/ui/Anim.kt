package app.dnshizli.ui

import app.dnshizli.core.Easing
import app.dnshizli.core.Gfx
import app.dnshizli.core.PageMotion
import app.dnshizli.core.SpringSpec
import kotlin.math.abs
import kotlin.math.exp

enum class Ease { LINEAR, OUT, IN_OUT, BACK, EXPO, QUINT, SMOOTH, ELASTIC, BOUNCE, STANDARD }

/**
 * Tek bir sayıyı zamanla hedefe götüren hafif animasyon. Süre 0 ise anında atlar; nesne ayırmaz.
 * İki kipi vardır:
 *  - Süreli ([go]): eğriye göre sabit sürede gider.
 *  - Yay ([springTo]): fizik kuralıyla hedefe çekilir; hedef değişince hız korunur, bu yüzden yarıda kesilen
 *    hareketler zıplamadan akıcı biçimde yön değiştirir. Hedefi aşıp sallanabilir ([value] 0..1 dışına çıkabilir).
 */
class Anim(initial: Float = 0f) {
    var value: Float = initial
        private set
    private var from = initial
    private var to = initial
    private var elapsed = 1f
    private var dur = 0f
    private var ease = Ease.OUT

    // yay kipi
    private var springing = false
    private var vel = 0f
    private var k = 0f
    private var c = 0f

    val active: Boolean get() = springing || elapsed < dur
    val target: Float get() = to

    /** Yaydaki anlık hız (birim/sn); süreli kipte 0. */
    val velocity: Float get() = if (springing) vel else 0f

    /** Animasyonsuz atla. */
    fun set(v: Float) { value = v; from = v; to = v; elapsed = 1f; dur = 0f; springing = false; vel = 0f }

    /** Mevcut değerden [target]'a [durSec] saniyede git. */
    fun go(target: Float, durSec: Float, e: Ease = Ease.OUT) {
        if (target == to && !active) return
        if (durSec <= 0.0001f) { set(target); return }
        springing = false; vel = 0f
        from = value; to = target; elapsed = 0f; dur = durSec; ease = e
    }

    /**
     * Mevcut değer ve hızla [target]'a yaylanarak git. [rate] zaman hızıdır (2 = iki kat hızlı, sertlik ×4, sönüm ×2).
     * Aynı hedefe tekrar çağrı hareketi sıfırlamaz.
     */
    fun springTo(target: Float, spec: SpringSpec, rate: Float = 1f) {
        val r = if (rate < 0.05f) 0.05f else rate
        if (target == to && springing) { k = spec.stiffness * r * r; c = spec.damping * r; return }
        if (target == to && !active && value == target) return
        to = target; elapsed = 1f; dur = 0f
        k = spec.stiffness * r * r; c = spec.damping * r
        springing = true
    }

    /** [dt] saniye ilerlet. Hâlâ sürüyorsa true. */
    fun step(dt: Float): Boolean {
        if (springing) return stepSpring(dt)
        if (!active) return false
        elapsed += dt
        val t = if (elapsed >= dur) 1f else elapsed / dur
        val k = when (ease) {
            Ease.LINEAR -> t
            Ease.OUT -> Easing.outCubic(t)
            Ease.IN_OUT -> Easing.inOutCubic(t)
            Ease.BACK -> Easing.outBack(t)
            Ease.EXPO -> Easing.outExpo(t)
            Ease.QUINT -> Easing.outQuint(t)
            Ease.SMOOTH -> Easing.smooth(t)
            Ease.ELASTIC -> Easing.outElastic(t)
            Ease.BOUNCE -> Easing.outBounce(t)
            Ease.STANDARD -> Easing.bezier(0.2f, 0f, 0f, 1f, t)
        }
        value = from + (to - from) * k
        if (elapsed >= dur) { value = to; elapsed = 1f; dur = 0f; return false }
        return true
    }

    /** Yarı örtük Euler, en çok 1/240 sn'lik adımlarla: sert yaylarda da kararlı. */
    private fun stepSpring(dtIn: Float): Boolean {
        var left = if (dtIn > 0.064f) 0.064f else dtIn
        while (left > 0f) {
            val h = if (left > SUB) SUB else left
            val acc = -k * (value - to) - c * vel
            vel += acc * h
            value += vel * h
            left -= h
        }
        if (abs(value - to) < REST_POS && abs(vel) < REST_VEL) {
            value = to; vel = 0f; springing = false; from = to
            return false
        }
        return true
    }

    private companion object {
        const val SUB = 1f / 240f
        const val REST_POS = 0.0006f
        const val REST_VEL = 0.01f
    }
}

/**
 * Parmakla sürükleme + bırakınca sürtünmeyle sönen kaydırma. Tek eksenli.
 * [pullable] açıksa en üstteyken aşağı çekilebilir (lastik gibi direnerek); bırakınca yaylanarak geri döner.
 */
class Scroller {
    var pos = 0f
        private set
    var min = 0f
    var max = 0f
    private var vel = 0f

    /** En üstte aşağı çekmeye izin ver ("çek, ölçülsün"). */
    var pullable = false

    /** Parmağın üst sınırın ötesine çektiği ham mesafe (dp). */
    private var rawPull = 0f

    /** Görünen çekme mesafesi (dp): içerik bu kadar aşağı kaymıştır. */
    val pull: Float get() = if (pos < min) min - pos else 0f

    val moving: Boolean get() = vel != 0f || pos < min

    fun clampNow() { if (rawPull == 0f) pos = pos.coerceIn(min, max) }

    fun jump(p: Float) { pos = p.coerceIn(min, max); vel = 0f; rawPull = 0f }

    /** Parmak [d] kadar hareket etti (içerik parmakla birlikte gider, bu yüzden konum azalır). */
    fun drag(d: Float) {
        vel = 0f
        if (pullable && pos <= min + 0.01f && (d > 0f || rawPull > 0f)) {
            rawPull = maxOf(0f, rawPull + d)
            pos = min - rubber(rawPull)
            return
        }
        rawPull = 0f
        pos = (pos - d).coerceIn(min, max)
    }

    private fun rubber(x: Float): Float = PULL_MAX * (1f - exp(-x / (PULL_MAX * 1.6f)))

    /** Parmağın bırakma hızı (dp/sn, parmak yönünde). */
    fun fling(fingerVel: Float) {
        if (rawPull > 0f) { rawPull = 0f; vel = 0f; return }      // çekilmişse yaylanarak geri döner
        vel = if (abs(fingerVel) < 60f) 0f else -fingerVel.coerceIn(-6000f, 6000f)
    }

    /** Kaymayı durdurur. @return kayıyorsa true (dokunarak durdurulan kaydırma tıklama sayılmaz). */
    fun stop(): Boolean { val m = vel != 0f; vel = 0f; return m }

    /** @return hâlâ kayıyorsa true */
    fun step(dt: Float): Boolean {
        val d = dt.coerceIn(0f, 0.05f)
        if (pos < min && rawPull == 0f) {
            pos += (min - pos) * (1f - exp(-14f * d))
            if (min - pos < 0.5f) pos = min
            return pos < min
        }
        if (vel == 0f) return false
        pos += vel * d
        vel *= exp(-3.6f * d)
        if (pos <= min) { pos = min; vel = 0f }
        else if (pos >= max) { pos = max; vel = 0f }
        if (abs(vel) < 12f) vel = 0f
        return vel != 0f
    }

    companion object {
        /** En fazla görünen çekme (dp). */
        const val PULL_MAX = 120f

        /** Bırakınca ölçüm başlatan çekme mesafesi (dp). */
        const val PULL_TRIGGER = 72f
    }
}

/**
 * Sayfa açılırken öğelerin art arda belirmesi. Biçim stilin hareketinden gelir ([PageMotion]); Aqua'da gecikme 0 olduğundan
 * hiç çalışmaz. Çizimde, öğenin yerel koordinatlarında (translate sonrası) çağrılır.
 */
object Reveal {
    const val DONE = Float.MAX_VALUE
    private const val MAX_INDEX = 14
    private const val ITEM_SEC = 0.34f

    fun limit(stagger: Float): Float = MAX_INDEX * stagger + ITEM_SEC + 0.06f

    /** [index]. öğenin ilerlemesi 0..1. */
    fun progress(t: Float, index: Int, stagger: Float): Float =
        Easing.clamp01((t - (if (index > MAX_INDEX) MAX_INDEX else index) * stagger) / ITEM_SEC)

    fun apply(g: Gfx, env: Env, u: Float, w: Float, h: Float) {
        if (u >= 1f) return
        val m = env.art.motion
        val e = Easing.outCubic(u)
        g.alpha(Easing.clamp01(u * 1.7f))
        when (m.page) {
            PageMotion.SLIDE -> g.translate(0f, (1f - e) * 18f)
            PageMotion.FADE_SCALE -> { g.translate(0f, (1f - e) * 10f); about(g, w, h, 0.96f + 0.04f * e) }
            PageMotion.TURNSTILE -> g.translate((1f - e) * 44f, 0f)
            PageMotion.POP -> about(g, w, h, 0.80f + 0.20f * Easing.outBack(u, 1f + 1.4f * m.spring))
        }
    }

    private fun about(g: Gfx, w: Float, h: Float, s: Float) {
        g.translate(w / 2f, h / 2f); g.scale(s, s); g.translate(-w / 2f, -h / 2f)
    }
}
