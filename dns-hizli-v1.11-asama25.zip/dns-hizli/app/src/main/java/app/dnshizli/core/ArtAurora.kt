package app.dnshizli.core

import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Frutiger Aurora: turkuazdan yeşile ve altta sarıya geçen yumuşak, bulanık zemin; altta parlayan beyaz ışık hüzmesi ve
 * akan renkli ışık şeritleri; üzerinde ince çizgilerden örülü, saydam, dalgalı tel kafes perdeler. Kartlar, düğmeler
 * ve küre temel cam çizimdir (Aero camı). Renk teması hafifçe karışır.
 * Hareket: yatay kayma, hafif yaylı; zemin hafifçe nefes alır (yalnızca hareket açıkken).
 */
class AuroraArt(theme: AeroTheme, glass: Float) : AeroArt(theme, glass) {
    override val style: UiStyle get() = UiStyle.AURORA
    override val particleMode: ParticleMode get() = ParticleMode.NONE
    override val liveSky: Boolean get() = true
    override val motion: StyleMotion = StyleMotion(PageMotion.SLIDE, 0.40f, 0.03f, 0.4f, depth = 0.9f, up = SpringSpec.SOFT, toggle = SpringSpec.SOFT, fx = FxKind.SWEEP)

    private val teal = 0xFF0E9FA6.toInt()
    private val green = 0xFF28C08A.toInt()
    private val lemon = 0xFFE4EE62.toInt()
    private val sea = 0xFF1FB4E6.toInt()

    private class Scene(val w: Float, val h: Float, art: AuroraArt) {
        private val dk = art.dark
        private val th = art.theme
        val base = if (dk)
            Fill.linear(0f, 0f, 0f, h, Rgb.lerp(0xFF021C26.toInt(), th.skyTop, 0.18f), Rgb.lerp(0xFF05423F.toInt(), th.skyMid, 0.18f),
                Rgb.lerp(0xFF1C4A22.toInt(), th.skyBottom, 0.15f), 0.58f)
        else
            Fill.linear(0f, 0f, 0f, h, Rgb.lerp(art.teal, th.skyTop, 0.26f), Rgb.lerp(art.green, th.skyMid, 0.26f),
                Rgb.lerp(art.lemon, th.skyBottom, 0.20f), 0.62f)
        val glowL = Fill.radial(w * 0.12f, h * 0.92f, w * 0.85f, Rgb.alpha(art.lemon, if (dk) 0.40f else 0.85f), Rgb.alpha(art.lemon, 0f))
        val glowR = Fill.radial(w * 0.95f, h * 0.78f, w * 0.80f, Rgb.alpha(art.sea, if (dk) 0.45f else 0.75f), Rgb.alpha(art.sea, 0f))
        val glowT = Fill.radial(w * 0.30f, h * 0.05f, w * 0.9f, Rgb.alpha(Rgb.WHITE, if (dk) 0.10f else 0.35f), Rgb.alpha(Rgb.WHITE, 0f))

        // tel kafes: iki kenar eğrisi arasında ara değerlenmiş eğriler
        val meshN = 26
        val meshA = Array(meshN) { GPath() }
        val meshB = Array(meshN) { GPath() }
        val streakMain = GPath()
        val streakGreen = GPath()
        val streakBlue = GPath()

        init {
            fun mesh(out: Array<GPath>, a: FloatArray, b: FloatArray) {
                for (k in 0 until meshN) {
                    val t = k / (meshN - 1f)
                    val p = FloatArray(8) { a[it] + (b[it] - a[it]) * t }
                    out[k].reset().moveTo(p[0] * w, p[1] * h).cubicTo(p[2] * w, p[3] * h, p[4] * w, p[5] * h, p[6] * w, p[7] * h)
                }
            }
            // sol-orta perde: yukarıdan aşağı kıvrılır
            mesh(meshA,
                floatArrayOf(0.40f, -0.05f, 0.55f, 0.30f, 0.80f, 0.35f, 1.05f, 0.30f),
                floatArrayOf(0.30f, -0.05f, 0.45f, 0.55f, 0.65f, 0.75f, 0.95f, 0.52f))
            // alt şerit perde: soldan sağa akar
            mesh(meshB,
                floatArrayOf(-0.05f, 0.62f, 0.25f, 0.50f, 0.55f, 0.82f, 1.05f, 0.62f),
                floatArrayOf(-0.05f, 0.80f, 0.30f, 0.66f, 0.60f, 1.02f, 1.05f, 0.80f))
            streakMain.moveTo(-0.05f * w, 0.84f * h).cubicTo(0.28f * w, 0.74f * h, 0.58f * w, 0.96f * h, 1.05f * w, 0.76f * h)
            streakGreen.moveTo(-0.05f * w, 0.52f * h).cubicTo(0.10f * w, 0.60f * h, 0.20f * w, 0.76f * h, 0.52f * w, 0.84f * h)
            streakBlue.moveTo(0.52f * w, 0.84f * h).cubicTo(0.72f * w, 0.90f * h, 0.90f * w, 0.70f * h, 1.05f * w, 0.50f * h)
        }
    }

    private var scene: Scene? = null

    private fun scene(w: Float, h: Float): Scene {
        var s = scene
        if (s == null || s.w != w || s.h != h) { s = Scene(w, h, this); scene = s }
        return s
    }

    override fun sky(g: Gfx, w: Float, h: Float) = skyFrame(g, w, h, false, 0f)

    override fun skyFrame(g: Gfx, w: Float, h: Float, live: Boolean, time: Float) {
        val s = scene(w, h)
        val t = if (live) time else 0f
        g.paint(s.base); g.rect(0f, 0f, w, h)
        g.paint(s.glowT); g.rect(0f, 0f, w, h)
        g.paint(s.glowL); g.rect(0f, 0f, w, h)
        g.paint(s.glowR); g.rect(0f, 0f, w, h)
        val br = 1f + 0.015f * sin(t * 0.35f)
        // tel kafes perdeler
        g.save(); g.translate(sin(t * 0.20f) * w * 0.02f, 0f)
        g.strokeWidth(1.4f); g.paint(white(if (dark) 0.22f else 0.46f))
        for (p in s.meshA) g.strokePath(p)
        g.restore()
        g.save(); g.translate(cos(t * 0.17f) * w * 0.02f, 0f)
        g.strokeWidth(1.2f); g.paint(white(if (dark) 0.16f else 0.34f))
        for (p in s.meshB) g.strokePath(p)
        g.restore()
        // ışık şeritleri
        g.paint(Rgb.alpha(lemon, if (dark) 0.35f else 0.60f)); g.strokeWidth(8f * br); g.strokePath(s.streakGreen)
        g.paint(Rgb.alpha(sea, if (dark) 0.35f else 0.55f)); g.strokeWidth(8f * br); g.strokePath(s.streakBlue)
        g.paint(white(if (dark) 0.10f else 0.20f)); g.strokeWidth(34f * br); g.strokePath(s.streakMain)
        g.paint(white(if (dark) 0.18f else 0.34f)); g.strokeWidth(16f * br); g.strokePath(s.streakMain)
        g.paint(white(if (dark) 0.55f else 0.85f)); g.strokeWidth(4.5f); g.strokePath(s.streakMain)
        g.paint(white(1f)); g.strokeWidth(1.4f); g.strokePath(s.streakMain)
    }

    override fun bubble(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float) {}
    override fun particle(g: Gfx, cx: Float, cy: Float, r: Float, alpha: Float, phase: Float) {}

    // ------------------------------------------------------------------ Aurora: ışıklı düğmeler

    /** Işıklı cam: yumuşak gövde, üstte parlak çizgi, seçiliyken açık renkli ışıma halkası. */
    override fun card(g: Gfx, l: Float, t: Float, r: Float, b: Float, rad: Float, selected: Float, press: Float, strong: Float, shadow: Float) {
        val w = r - l
        val h = b - t
        if (w <= 1f || h <= 1f) return
        val rr = min(rad, min(w, h) / 2f)
        g.save(); g.translate(l, t)
        if (selected > 0f) { g.paint(Rgb.alpha(theme.accentLight, 0.30f * selected)); g.roundRect(-3f, -3f, w + 3f, h + 3f, rr + 3f) }
        if (shadow > 0f) { g.paint(Rgb.alpha(theme.accentDeep, (if (dark) 0.30f else 0.12f) * shadow)); g.roundRect(0f, 3f, w, h + 3f, rr) }
        g.paint(Rgb.alpha(if (dark) 0xFF10242B.toInt() else Rgb.WHITE, (0.38f + 0.55f * strong).coerceIn(0f, 1f))); g.roundRect(0f, 0f, w, h, rr)
        g.paint(Rgb.alpha(theme.accentLight, 0.16f + 0.22f * press + 0.18f * selected)); g.roundRect(0f, 0f, w, h, rr)
        g.strokeWidth(1.4f); g.paint(Rgb.alpha(Rgb.WHITE, if (dark) 0.35f else 0.85f))
        g.strokeRoundRect(0.7f, 0.7f, w - 0.7f, h - 0.7f, max(0f, rr - 0.7f))
        g.paint(Rgb.alpha(Rgb.WHITE, 0.70f)); g.roundRect(rr, 1.2f, w - rr, 2.4f, 1.2f)
        g.restore()
    }

    /** Işıklı anahtar: açıkken ışıyan renkli yuva ve parlak tutamaç. */
    override fun switch(g: Gfx, l: Float, t: Float, w: Float, h: Float, on: Float, press: Float) {
        val k = on.coerceIn(0f, 1f)
        g.save(); g.translate(l, t)
        if (k > 0.01f) { g.paint(Rgb.alpha(theme.accentLight, 0.35f * k)); g.roundRect(-3f, -3f, w + 3f, h + 3f, h / 2f + 3f) }
        g.paint(Rgb.lerp(if (dark) 0xFF2A3F46.toInt() else 0xFFD3E4E8.toInt(), theme.accent, k)); g.roundRect(0f, 0f, w, h, h / 2f)
        g.strokeWidth(1.2f); g.paint(Rgb.alpha(Rgb.WHITE, 0.7f)); g.strokeRoundRect(0.6f, 0.6f, w - 0.6f, h - 0.6f, h / 2f - 0.6f)
        val cx = h / 2f + (w - h) * k
        g.paint(Rgb.alpha(Rgb.WHITE, 0.45f)); g.circle(cx, h / 2f, h / 2f - 1f + press)
        g.paint(Rgb.WHITE); g.circle(cx, h / 2f, h / 2f - 4f + press)
        g.restore()
    }
}
