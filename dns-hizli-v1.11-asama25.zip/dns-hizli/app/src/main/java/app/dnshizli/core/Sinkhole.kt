package app.dnshizli.core

import java.util.concurrent.atomic.AtomicLong

/**
 * "Kapalı kalırsa dur" kipinin yönlendiricisi: gerçek DNS bağlantısı yokken tünel açık tutulur ve her sorguya hemen
 * "sunucu hatası" (SERVFAIL) cevabı verilir. Sorgu hiçbir yere gitmez; yani bağlantı koptuğunda sorgular operatörün DNS'ine
 * sızmaz. Uygulamalar zaman aşımını beklemeden hızlıca hata alır. Bağlantı yeniden kurulunca gerçek yönlendirici devralır.
 * Tek iş parçacığından (tünel okuyucu) çağrılır; ayırma yapmaz.
 */
class SinkholeForwarder(private val writeToTun: (ByteArray, Int, Int) -> Unit) : Forwarder {
    override val proto: Proto get() = Proto.PLAIN

    private val parsed = ParsedQuery()
    private val out = ByteArray(Packets.HDR6 + MAX_QUERY)
    private val scratch = ByteArray(Packets.MTU)
    private val refused = AtomicLong()
    @Volatile private var closed = false

    /** Cevaplanan (engellenen) sorgu sayısı. */
    val count: Long get() = refused.get()

    override fun start() {}

    override fun onPacket(p: ByteArray, len: Int) {
        if (closed) return
        val q = parsed
        if (!q.parse(p, len, MAX_QUERY)) return
        val qEnd = Dns.questionEnd(p, q.dnsOff, q.dnsLen)
        // Soru bölümü ayrıştırılamadıysa yine de başlıkla cevap veririz (soru sayısı 0).
        val n = reply(p, q.dnsOff, q.dnsLen, qEnd, out, Packets.HDR)
        Packets.put16(out, Packets.HDR, q.clientId)
        refused.incrementAndGet()
        q.writeCached(out, scratch, n, writeToTun)
    }

    override fun stats(): Stats = Stats(queries = refused.get(), blocked = 0)
    override fun resetNetwork(reason: String) {}
    override fun clearCache() {}
    override fun close() { closed = true }

    companion object {
        const val MAX_QUERY = 512

        /** SERVFAIL cevabı: kimlik, sorunun kopyası (varsa), RCODE=2. Cevabın boyunu döner. */
        internal fun reply(q: ByteArray, qOff: Int, qLen: Int, qEnd: Int, out: ByteArray, outOff: Int): Int {
            val hasQ = qEnd > qOff + Packets.DNS_HDR && qEnd - qOff <= qLen
            val len = if (hasQ) qEnd - qOff else Packets.DNS_HDR
            System.arraycopy(q, qOff, out, outOff, len)
            val rd = Packets.u16(q, qOff + 2) and 0x0100
            Packets.put16(out, outOff + 2, 0x8000 or rd or 0x0080 or 2)
            Packets.put16(out, outOff + 4, if (hasQ) 1 else 0)
            Packets.put16(out, outOff + 6, 0)
            Packets.put16(out, outOff + 8, 0)
            Packets.put16(out, outOff + 10, 0)
            return len
        }
    }
}
