package app.dnshizli.core

/**
 * Hazır profiller: tek dokunuşla sunucu, şifreleme, önbellek, engelleme düzeyi ve ağ geçidi modülleri (DPI atlatma,
 * Reklam+) birlikte ayarlanır. Bildirim, tema, dil gibi kişisel ayarlara dokunmaz. Sıra [Strings.PROFILE_NAMES] ile aynıdır.
 */
class Profile(
    val id: String,
    val serverId: String,
    val encryptionStrict: Boolean,
    val cache: CacheLevel,
    val fastest: Boolean,
    val filter: FilterLevel,
    val dpi: Boolean,
    val ads: Boolean,
) {
    fun applyTo(s: AppSettings): AppSettings = s.copy(
        lastServer = serverId,
        strictEncryption = encryptionStrict,
        cache = cache,
        autoFastest = fastest,
        filterLevel = filter,
    )
}

object Profiles {
    val all: List<Profile> = listOf(
        // Hız: en hızlı sunucu, büyük önbellek, engelleme yok.
        Profile("speed", "cloudflare", false, CacheLevel.LARGE, true, FilterLevel.OFF, dpi = false, ads = false),
        // Gizlilik: sıkı şifreleme, izleyici engelleme, Reklam+.
        Profile("privacy", "quad9", true, CacheLevel.NORMAL, false, FilterLevel.BASIC, dpi = false, ads = true),
        // Aile: aile süzgeçli sunucu, orta düzey engelleme.
        Profile("family", "cloudflare-family", false, CacheLevel.NORMAL, false, FilterLevel.MEDIUM, dpi = false, ads = false),
        // Tam koruma: reklam/izleyici engelleme + DPI atlatma + Reklam+.
        Profile("full", "adguard", false, CacheLevel.NORMAL, false, FilterLevel.MEDIUM, dpi = true, ads = true),
    )

    fun byId(id: String?): Profile? = all.firstOrNull { it.id == id }
}
