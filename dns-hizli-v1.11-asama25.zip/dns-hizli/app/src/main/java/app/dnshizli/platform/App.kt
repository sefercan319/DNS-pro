package app.dnshizli.platform

import android.app.Application
import android.app.LocaleManager
import android.content.Context
import android.os.Build
import android.os.LocaleList
import app.dnshizli.core.FilterLive
import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.FilterSource
import app.dnshizli.core.L

/**
 * Uygulama süreci başlarken dili ayarlar: arayüz, servis, bildirim, kutucuk ve widget aynı dili konuşur.
 * Ayar "auto" ise sistemin (Android 13+: uygulamaya özel) dil sırası kullanılır.
 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val prefs = PrefsStore(this)
        val st = prefs.loadSettings()
        applyLanguage(this, st.lang)
        // Engelleme listeleri uygulamanın içindedir (assets/filter); seviye açıksa arka planda yüklenir.
        FilterRuntime.source = FilterSource { name -> assets.open("filter/$name") }
        FilterRuntime.update(st.filterLevel, st.filterAllow, st.filterBlock)
        // İçe aktarılan engel listesi arka planda okunur; yüklenince motor yeniden kurulur.
        if (prefs.importedCount() > 0) {
            val app = this
            Thread({ FilterRuntime.setImported(ImportedStore.load(app)) }, "dns-imported").also { it.isDaemon = true }.start()
        }
        FilterLive.keep(st.keepHistory)
        installCrashNote(prefs)
    }

    /**
     * Beklenmeyen bir çökmede kısa bir özet (hata türü ve uygulamanın kendi kodundaki ilk satır; kişisel veri yok)
     * saklanır; tanılama raporu ve geri bildirim bunu içerir. Ardından sistemin kendi işleyicisi çalışır (davranış değişmez).
     */
    private fun installCrashNote(prefs: PrefsStore) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val frame = e.stackTrace.firstOrNull { it.className.startsWith("app.dnshizli") }
                val stamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.ROOT).format(java.util.Date())
                prefs.setLastCrashNow("$stamp ${e.javaClass.simpleName} @ ${frame?.let { it.className.substringAfterLast('.') + ":" + it.lineNumber } ?: "?"} (${t.name})")
            } catch (_: Throwable) {}
            previous?.uncaughtException(t, e)
        }
    }

    companion object {
        /** Ayara göre etkin dili seçer. Bağlam yapılandırmasındaki dil listesini (sistem ya da uygulama dili) kullanır. */
        fun applyLanguage(ctx: Context, setting: String) {
            L.set(L.resolve(setting, localeCodes(ctx)))
        }

        fun localeCodes(ctx: Context): List<String> {
            val ls = ctx.resources.configuration.locales
            return (0 until ls.size()).map { ls[it].language }
        }

        /**
         * Android 13+: uygulama içi dil seçimini sistemin "uygulama dili" ayarına da yazar (Ayarlar > Uygulamalar > Dil
         * aynı seçimi gösterir). "auto" ise uygulamaya özel dil kaldırılır.
         */
        fun syncSystemLocale(ctx: Context, setting: String) {
            if (Build.VERSION.SDK_INT < 33) return
            try {
                val lm = ctx.getSystemService(LocaleManager::class.java) ?: return
                val want = if (setting == L.AUTO) LocaleList.getEmptyLocaleList() else LocaleList.forLanguageTags(setting)
                if (lm.applicationLocales.toLanguageTags() != want.toLanguageTags()) lm.applicationLocales = want
            } catch (_: Exception) {
                // eski ya da kısıtlı cihaz: yalnızca uygulama içi dil kullanılır
            }
        }

        /** Android 13+: kullanıcı sistem ayarlarından uygulama dilini değiştirdiyse onu ayar değerine çevirir; yoksa null. */
        fun systemAppLocale(ctx: Context): String? {
            if (Build.VERSION.SDK_INT < 33) return null
            return try {
                val ls = ctx.getSystemService(LocaleManager::class.java)?.applicationLocales ?: return null
                if (ls.isEmpty) L.AUTO else ls[0].language
            } catch (_: Exception) { null }
        }
    }
}
