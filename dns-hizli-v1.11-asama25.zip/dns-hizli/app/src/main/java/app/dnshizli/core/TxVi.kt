package app.dnshizli.core

/** Tiếng Việt */
object TxVi : Tx() {
    override val lang = Lang.VI

    override val decimalSep = ','
    override val thousand = "K"
    override val million = "M"
    override fun percent(n: Int) = "$n%"
    override val dayU = "ng"
    override val hourU = "h"
    override val minU = "p"
    override val secU = "s"
    override val justNow = "vừa xong"
    override fun ago(span: String) = "$span trước"

    override val OFF = "Chưa kết nối"
    override val CONNECTING = "Đang kết nối…"
    override val ON = "Đã kết nối"
    override val ERROR = "Không kết nối được"
    override val PAUSED = "Đã tạm dừng"
    override val HINT_OFF = "Chạm vào quả cầu để kết nối"
    override val HINT_CONNECTING = "Có thể mất vài giây"
    override val HINT_ERROR = "Chạm để thử lại"
    override val HINT_PAUSED = "Chạm để tiếp tục ngay"
    override val ERR_DEFAULT = "Kết nối thất bại"
    override fun selected(name: String) = "Đã chọn $name"
    override fun pausedUntil(time: String) = "Tiếp tục lúc $time"
    override fun blockedShort(n: String) = "$n đã chặn"
    override fun queriesShort(n: String) = "$n truy vấn"
    override fun cacheShort(pct: String) = "$pct từ bộ nhớ đệm"

    override val SERVERS = "Máy chủ"
    override val FILTER_ALL = "Tất cả"
    override val FILTER_FAV = "Yêu thích"
    override val FILTER_RECENT = "Gần đây"
    override val EMPTY_FAV = "Chưa có mục yêu thích. Chạm vào ngôi sao của máy chủ."
    override val EMPTY_RECENT = "Bạn chưa kết nối với máy chủ nào."
    override val EMPTY_FILTER = "Không có máy chủ nào trong danh mục này."
    override val MEASURE = "Đo tốc độ"
    override val MEASURING = "Đang đo…"
    override val SORT = "Thứ tự sắp xếp"
    override val PULL_TO_MEASURE = "Kéo xuống để đo tốc độ"
    override val RELEASE_TO_MEASURE = "Thả ra để đo"
    override fun serversCount(n: Int) = "$n máy chủ"
    override fun showAllServers(n: Int) = "Xem tất cả ($n)"
    override val SHOW_LESS = "Thu gọn"
    override val TAG_FAST = "Nhanh"
    override val TAG_PRIVACY = "Riêng tư"
    override val TAG_ADS = "Chặn quảng cáo"
    override val TAG_FAMILY = "Gia đình"
    override val TAG_SECURITY = "Bảo mật"
    override val VAR_OPEN = "Không lọc"
    override val VAR_ADS = "Chặn quảng cáo"
    override val VAR_SECURITY = "Bảo mật"
    override val VAR_FAMILY = "Gia đình"
    override val A11Y_CONNECTED = "đã kết nối"
    override val A11Y_ENCRYPTED = "đã mã hóa"
    override fun favA11y(name: String) = "$name yêu thích"

    override val COPIED = "Đã sao chép vào bộ nhớ tạm"
    override val DISCONNECTED = "Đã ngắt kết nối"
    override val BACKUP = "Đã chuyển sang máy chủ dự phòng"
    override val NO_REPLY = "Không có máy chủ nào phản hồi"
    override val MEASURE_FIRST = "Hãy đo tốc độ trước"
    override val CONNECT = "Kết nối"
    override val UNDO = "Hoàn tác"
    override fun fastest(name: String, ms: Int) = "Nhanh nhất: $name · $ms ms"
    override fun switched(name: String) = "Đang chuyển sang $name"
    override fun hiddenToast(name: String) = "Đã ẩn $name"

    override val PRIMARY = "Chính"
    override val SECONDARY = "Phụ"
    override val COPY = "Sao chép"
    override fun addressA11y(label: String, ip: String) = "Địa chỉ $label: $ip"
    override val CONNECT_TO_THIS = "Kết nối với máy chủ này"
    override val SWITCH_TO_THIS = "Chuyển sang máy chủ này"
    override val CONNECTED_NOW = "Đang kết nối"
    override val ADD_FAV = "Thêm vào yêu thích"
    override val REMOVE_FAV = "Bỏ yêu thích"
    override val MEASURE_THIS = "Đo tốc độ"
    override val HIDE = "Ẩn khỏi danh sách"
    override val UNHIDE = "Hiện trong danh sách"
    override fun lastMeasure(ms: Int?, ago: String) = if (ms == null) "Lần kiểm tra gần nhất: không phản hồi · $ago" else "Lần kiểm tra gần nhất: $ms ms · $ago"
    override val NEVER_MEASURED = "Chưa đo"
    override val ENC_SUPPORT = "DNS mã hóa"
    override val ENC_NONE = "Không hỗ trợ"
    override val ENC_ONLY = "Chỉ chấp nhận kết nối mã hóa"
    override fun measureSummary(best: Int, median: Int, lossPct: Int) = "Tốt nhất $best ms · trung vị $median ms · mất gói $lossPct%"
    override val HISTORY = "Lịch sử tốc độ"
    override fun historyA11y(n: Int, median: Int?) =
        if (median == null) "$HISTORY: $n lần kiểm tra, không phản hồi" else "$HISTORY: $n lần kiểm tra, trung vị $median ms"

    override val QUICK_TITLE = "Chuyển nhanh"
    override val QUICK_FAVORITES = "Yêu thích"
    override val QUICK_RECENT = "Dùng gần đây"
    override val PAUSE_FOR = "Tạm dừng"
    override fun minutes(n: Int) = if (n >= 60 && n % 60 == 0) "${n / 60} giờ" else "$n phút"
    override val RESUME = "Tiếp tục"

    override val SETTINGS = "Cài đặt"
    override val MENU = "Menu"
    override val PERSONALIZE = "Cá nhân hóa"
    override val PZ_BACKGROUND = "Hình nền"
    override val PZ_AUTO = "Giao diện tự động"
    override val PZ_FEEL = "Kính, chữ và chuyển động"
    override val PZ_ACCESS = "Hỗ trợ tiếp cận và pin"
    override val DNS_SETTINGS = "Cài đặt DNS"
    override val CONN_APPS = "Kết nối & ứng dụng"
    override val STATS_HISTORY = "Thống kê & lịch sử"
    override val SEC_LOOK = "Giao diện"
    override val SEC_LIST = "Danh sách máy chủ"
    override val SEC_DATA = "Dữ liệu"
    override val ABOUT = "Giới thiệu"
    override val LANGUAGE = "Ngôn ngữ"
    override val LANG_AUTO = "Tự động (ngôn ngữ hệ thống)"
    override val THEME = "Chủ đề"
    override val THEME_AUTO = "Tự động"
    override val THEME_AUTO_NOTE = "Tự động · theo chế độ sáng/tối của hệ thống"
    override fun themeName(id: String) = when (id) {
        "aqua" -> "Xanh nước"
        "meadow" -> "Đồng cỏ"
        "ocean" -> "Đại dương"
        "sunset" -> "Hoàng hôn"
        "lavender" -> "Oải hương"
        "coral" -> "San hô"
        "mint" -> "Bạc hà"
        "sakura" -> "Anh đào"
        "honey" -> "Mật ong"
        "night" -> "Đêm"
        "amoled" -> "Đen (AMOLED)"
        "aurora" -> "Cực quang"
        "dynamic" -> "Hình nền"
        else -> THEME_AUTO
    }
    override fun themeA11y(name: String) = "Chủ đề: $name"
    override val THEME_SCHEDULE = "Chủ đề tối theo lịch"
    override val THEME_SCHEDULE_NOTE = "Ở chế độ Tự động, dùng chủ đề tối trong khung giờ bạn chọn"
    override val GLASS = "Độ mờ của kính"
    override val BUBBLES = "Bong bóng"
    override val STYLE = "Kiểu giao diện"
    override val STYLE_NOTES = listOf(
        "Kính, bóng và bong bóng: giao diện gốc.",
        "Bầu trời, cỏ xanh, giọt kính và nút gel.",
        "Thành phố, âm nhạc và tuổi trẻ: nhà chọc trời, loa, vòng tròn, ngôi sao và tia sáng.",
        "Thiên nhiên và công nghệ: Trái Đất xanh, tuabin gió, tấm pin mặt trời và lá.",
        "Hồng và tím ánh ba chiều, trái tim chrome, bong bóng, lấp lánh và cửa sổ pixel.",
        "Ánh sáng xanh ngọc, xanh lá và vàng, chùm sáng rực và sóng lưới trong suốt.",
    )
    override val WALLPAPER = "Ảnh nền"
    override val WP_OFF = "Không"
    override val WP_ON = "Ảnh"
    override val WP_PICK = "Chọn ảnh từ thư viện"
    override val WP_PICK_NOTE = "Chỉ nằm trên điện thoại, không bao giờ tải lên. Lớp phủ tự tăng khi cần để chữ vẫn dễ đọc."
    override val WP_PRESETS = "Ảnh có sẵn"
    override val WP_PRESETS_NOTE = "8 ảnh có sẵn trong ứng dụng. Không cần internet."
    override val WP_REMOVE = "Xóa ảnh"
    override val WP_DIM = "Độ đậm lớp phủ"
    override val WP_BLUR = "Làm mờ"
    override val OPT_WP_BLUR = listOf("Tắt", "Nhẹ", "Mạnh")
    override val WP_SAVED = "Đã đặt ảnh nền"
    override val WP_FAILED = "Không mở được ảnh"
    override val WP_REMOVED = "Đã xóa ảnh nền"
    override val APP_ICON = "Biểu tượng ứng dụng"
    override val ICON_NOTES = listOf(
        "Quả cầu thủy tinh: biểu tượng ban đầu.",
        "Giọt thủy tinh trên nền trời và cỏ.",
        "Thành phố xanh chanh-ngọc với tia nắng và nút nguồn.",
        "Trái Đất xanh bóng với chiếc lá nảy mầm.",
        "Trái tim chrome bóng trên nền hồng và tím ánh ba chiều.",
        "Quả cầu thủy tinh trên ánh sáng ngọc-vàng và sóng ánh sáng.",
    )
    override val ICON_SET = "Đổi biểu tượng khi thoát"
    override val ICON_NOTE = "Nếu lối tắt trên màn hình chính biến mất, hãy thêm lại ứng dụng."
    override val ICON_FAILED = "Không đổi được biểu tượng"
    override val HELP_WHY_TITLE = "Vì sao có ứng dụng này?"
    override val HELP_WHY_BODY = "DNS Hızlı nhỏ gọn và đơn giản, do một người làm, không có công ty lớn đứng sau. Không tài khoản, không quảng cáo: bạn tự chọn DNS, mã hóa, ứng dụng nào được áp dụng và giao diện."
    override val HELP_WHY_TAIL = "Có thể nó không hơn các đối thủ, nhưng nó hoạt động và đáng để thử."
    override val TROUBLE = "Khắc phục sự cố"
    override val TROUBLE_RECHECK = "Kiểm tra lại"
    override val TROUBLE_ALL_OK = "Mọi thứ có vẻ ổn. Nếu vẫn không kết nối được, hãy thử máy chủ khác."
    override val TROUBLE_SOME = "Những điểm cần chú ý:"
    override val T_NET = "Internet"
    override val NET_OK = "đã kết nối."
    override val NET_BAD = "không có hoặc bị hạn chế. Kiểm tra Wi-Fi hoặc dữ liệu di động."
    override val T_PERM = "Quyền VPN"
    override val PERM_OK = "đã cấp."
    override val PERM_BAD = "chưa được cấp. Android sẽ hỏi khi bạn kết nối; hãy cho phép."
    override val T_VPN = "VPN khác"
    override val VPN_OK = "không có."
    override val VPN_BAD = "có vẻ đang bật. Android chỉ cho một VPN cùng lúc; hãy tắt nó."
    override val T_DNS = "DNS riêng tư của Android"
    override val PDNS_OK = "tắt hoặc tự động, không sao."
    override val PDNS_BAD = "bị cố định vào một máy chủ và có thể bỏ qua DNS của ứng dụng này. Trong Cài đặt > Mạng > DNS riêng tư hãy chọn Tự động hoặc Tắt."
    override val SEARCH = "Tìm"
    override val SEARCH_HINT = "Tên hoặc chủ sở hữu máy chủ"
    override val SEARCH_CLEAR = "Xóa"
    override val SHARE_RESULTS = "Chia sẻ kết quả đo"
    override val SHARE_RESULTS_HEAD = "Kết quả đo DNS Hızlı (nhanh nhất trước)"
    override val NO_RESULTS = "Hãy đo trước"
    override val CUSTOM_EDIT = "Sửa"
    override fun customUpdated(name: String) = "Đã cập nhật $name"
    override val KEEP_HISTORY = "Lưu lịch sử"
    override val KEEP_HISTORY_NOTE = "Khi tắt, máy chủ gần đây, lịch sử và số đo không được ghi. Dữ liệu hiện có vẫn giữ nguyên."
    override val MOTION = "Hiệu ứng chuyển động"
    override val TEXT_SIZE = "Cỡ chữ"
    override val HIGH_CONTRAST = "Độ tương phản cao"
    override val HIGH_CONTRAST_NOTE = "Kính đục hơn và chữ đậm hơn"
    override val MINIMAL = "Giao diện tối giản"
    override val MINIMAL_NOTE = "Ẩn bộ lọc và dòng thống kê"
    override val LOW_POWER = "Chế độ tiết kiệm pin"
    override val LOW_POWER_NOTE = "Tắt mọi chuyển động, tiết kiệm pin"
    override val HAPTICS = "Rung"
    override val HAPTICS_NOTE = "Phản hồi nhẹ khi chạm"
    override val ENCRYPTION = "DNS mã hóa"
    override val ENCRYPTION_NOTE = "Tự động: DoT trước, rồi DoH, cuối cùng là DNS thường"
    override val AUTO_CONNECT = "Kết nối khi mở ứng dụng"
    override val AUTO_CONNECT_NOTE = "Kết nối với máy chủ gần nhất khi bạn mở ứng dụng"
    override val CONNECT_ON_BOOT = "Kết nối khi khởi động"
    override val CONNECT_ON_BOOT_NOTE = "Tự động kết nối sau khi điện thoại khởi động lại"
    override val AUTO_FASTEST = "Kết nối máy chủ nhanh nhất"
    override val AUTO_FASTEST_NOTE = "Chạm vào quả cầu sẽ chọn máy chủ nhanh nhất theo lần kiểm tra gần nhất"
    override val REFRESH_ON_NET = "Làm mới khi đổi mạng"
    override val REFRESH_ON_NET_NOTE = "DNS được làm mới khi chuyển giữa Wi-Fi và dữ liệu di động"
    override val NOTIFY_DROP = "Báo khi mất kết nối"
    override val NOTIFY_DROP_NOTE = "Thông báo có nút kết nối lại khi kết nối bị ngắt bất ngờ"
    override val NOTIFY_CONNECT = "Báo khi đã kết nối"
    override val NOTIFY_CONNECT_NOTE = "Thông báo ngắn khi kết nối được thiết lập"
    override val NOTIFY_STOP = "Báo khi ngắt kết nối"
    override val NOTIFY_STOP_NOTE = "Thông báo ngắn khi bạn tự ngắt kết nối"
    override val NOTIFY_TIMEOUT = "Báo khi quá thời gian"
    override val NOTIFY_TIMEOUT_NOTE = "Thông báo nếu máy chủ DNS không phản hồi"
    override val NOTIF_PERM = "Quyền thông báo hệ thống"
    override val PERM_ALLOWED = "Đã bật"
    override val PERM_BLOCKED = "Đang tắt · sửa"
    override val NOTIF_CONNECTED_TITLE = "DNS đã kết nối"
    override val NOTIF_STOPPED_TITLE = "DNS đã ngắt"
    override val NOTIF_STOPPED_TEXT = "Bảo vệ đang tắt"
    override val NOTIF_TIMEOUT_TITLE = "DNS quá thời gian"
    override val FAIL_CLOSED = "Chặn DNS khi mất kết nối"
    override val FAIL_CLOSED_NOTE = "Nếu kết nối đứt, truy vấn DNS không rò rỉ sang nhà mạng; chúng thất bại cho đến khi kết nối lại"
    override val NOTIF_SEALED = "Đang chặn DNS khi kết nối lại"
    override val ERR_SEALED = "Không kết nối được. DNS bị chặn để truy vấn không rò rỉ. Chạm Dừng để gỡ chặn."
    override val SEALED_INFO = "DNS bị chặn cho đến khi có kết nối lại"
    override val LATENCY_TITLE = "Độ trễ mỗi truy vấn"
    override val LATENCY_EMPTY = "Hiện trực tiếp khi đã kết nối và có truy vấn"
    override val FILTER_MINE = "Danh sách của tôi"
    override val MINE_PASTE = "Nhập từ bộ nhớ tạm"
    override val MINE_PASTE_NOTE = "Tệp hosts hoặc mỗi dòng một tên miền"
    override val MINE_FILE = "Nhập từ tệp"
    override val MINE_FILE_NOTE = "Tệp .txt hoặc hosts trên điện thoại"
    override val MINE_EXPORT = "Sao chép danh sách chặn"
    override val MINE_EXPORT_NOTE = "Vào bộ nhớ tạm, dạng hosts"
    override val MINE_CLEAR = "Xóa danh sách đã nhập"
    override val MINE_FOOT = "Đọc dòng hosts (0.0.0.0 tên-miền), danh sách tên miền thường và quy tắc ||tên-miền^. Tối đa 50.000 tên. Danh sách cho phép luôn được ưu tiên."
    override val MINE_NOTHING = "Không tìm thấy tên miền hợp lệ"
    override val MINE_CLIP_EMPTY = "Bộ nhớ tạm trống"
    override val MINE_FILE_ERR = "Không đọc được tệp"
    override val MINE_CLEARED = "Đã xóa danh sách đã nhập"
    override val MINE_CLEAR_ASK = "Xóa danh sách đã nhập?"
    override val MINE_CUT = "Đã chạm giới hạn, phần còn lại bị bỏ qua"
    override fun notifTimeout(name: String) = "$name không phản hồi. Đang thử lại."
    override val MOD_DPI = "Vượt DPI"
    override val MOD_ADS = "Quảng cáo+"
    override val MOD_DPI_SUB = "Mở trang bị chặn"
    override val MOD_ADS_SUB = "Chặn ngoài DNS"
    override val MOD_ON = "Bật"
    override val MOD_OFF = "Tắt"
    override val BLOCK_QUIC = "Chặn QUIC"
    override val BLOCK_QUIC_NOTE = "Ứng dụng quay lại TCP, nên Vượt DPI và Quảng cáo+ cũng bao phủ chúng"
    override val GW_TRIPPED = "Phát hiện sự cố kết nối: đã tắt Vượt DPI và Quảng cáo+"
    override val MOD_FAILED = "Không bật được. Chưa cấp quyền VPN hoặc đang có VPN khác."
    override fun gwOn(modules: String) = "Cổng đang bật: $modules"
    override fun gwOnStats(modules: String, blocked: String) = "Cổng đang bật: $modules · đã chặn $blocked"
    override fun modOn(name: String) = "Đã bật $name"
    override fun modOff(name: String) = "Đã tắt $name"
    override fun modAdsCount(n: String) = "Đã chặn $n"
    override fun modDpiCount(n: String) = "Đã chia $n kết nối"
    override fun latencyLine(avg: String, max: String, timeouts: Int) = "TB $avg · tối đa $max" + (if (timeouts > 0) " · $timeouts lần quá thời gian" else "")
    override fun mineCount(n: Int) = "$n tên miền"
    override fun mineAdded(n: Int) = "Đã thêm $n tên miền"
    override fun mineCopied(n: Int) = "Đã sao chép $n tên miền"
    override val CACHE = "Bộ nhớ đệm DNS"
    override val CLEAR_CACHE = "Xóa bộ nhớ đệm"
    override val CACHE_CLEARED = "Đã xóa bộ nhớ đệm"
    override val ONLY_CONNECTED = "Chỉ dùng được khi đã kết nối"
    override val RULE_WIFI = "Máy chủ cho Wi-Fi"
    override val RULE_MOBILE = "Máy chủ cho dữ liệu di động"
    override val RULE_AUTO = "Tự động"
    override val RULE_AUTO_NOTE = "Máy chủ bạn dùng gần nhất"
    override val COMPACT = "Danh sách gọn"
    override val COMPACT_NOTE = "Hàng ngắn hơn, không có mô tả"
    override val HIDDEN = "Máy chủ đã ẩn"
    override val HIDDEN_NONE = "Không có"
    override val STAT_QUERIES = "Tổng số truy vấn"
    override val STAT_HITS = "Trả lời từ bộ nhớ đệm"
    override val STAT_BLOCKED = "Đã chặn (ước tính)"
    override val STAT_TIME = "Tổng thời gian kết nối"
    override val WEEK = "7 ngày qua"
    override fun weekA11y(total: String) = "$total truy vấn trong 7 ngày qua"
    override val WEEKDAYS = listOf("T2", "T3", "T4", "T5", "T6", "T7", "CN")
    override val EXPORT = "Xuất cài đặt"
    override val IMPORT = "Nhập cài đặt"
    override val EXPORTED = "Mã cài đặt đã được sao chép vào bộ nhớ tạm"
    override val IMPORTED = "Đã tải cài đặt"
    override val IMPORT_BAD = "Bộ nhớ tạm không có mã cài đặt hợp lệ"
    override val RESET_SETTINGS = "Đặt lại cài đặt"
    override val RESET_STATS = "Đặt lại thống kê"
    override val CONFIRM = "Bạn có chắc không?"
    override val RESET = "Đặt lại"
    override val RESET_DONE = "Đã đặt lại"
    override val LOG = "Nhật ký chẩn đoán"
    override val HELP = "Ứng dụng hoạt động thế nào?"
    override val VPN_SETTINGS = "Cài đặt VPN của hệ thống"
    override val SHARE_APP = "Chia sẻ ứng dụng"
    override val RATE_APP = "Đánh giá ứng dụng"
    override val FEEDBACK = "Gửi phản hồi"
    override fun shareAppText(url: String) = "$APP giúp bạn kết nối với các máy chủ DNS phổ biến chỉ bằng một chạm: $url"
    override val VERSION = "Phiên bản"
    override val OPT_BUBBLES = listOf("Tắt", "Ít", "Nhiều")
    override val OPT_MOTION = listOf("Đầy đủ", "Giảm bớt", "Tắt")
    override val OPT_CACHE = listOf("Tắt", "Nhỏ", "Vừa", "Lớn")
    override val OPT_ENCRYPTION = listOf("Tự động", "DoT", "DoH", "Tắt")
    override val PLAIN_DNS = "DNS thường"

    override val LOG_NOTE = "Chỉ lưu các sự kiện kết nối. Tên miền truy vấn và dữ liệu cá nhân không bao giờ được lưu."
    override val LOG_EMPTY = "Chưa có mục nào."
    override val SHARE = "Chia sẻ"
    override val CLEAR = "Xóa"
    override val CLEARED = "Đã xóa"
    override val HELP_SECTIONS = listOf(
        "DNS là gì?" to
            "DNS là dịch vụ chuyển địa chỉ internet (như example.com) thành những con số mà thiết bị hiểu được. " +
            "DNS bạn dùng có thể ảnh hưởng đến tốc độ, quyền riêng tư và nội dung nào bị chặn.",
        "Ứng dụng làm gì?" to
            "Ứng dụng dùng máy chủ DNS bạn chọn cho mọi ứng dụng khác. Để làm vậy, nó mở một giao diện VPN cục bộ trên điện thoại, " +
            "nhưng lưu lượng của bạn không đi qua máy chủ VPN nào. Chỉ các truy vấn DNS được gửi đến máy chủ bạn đã chọn; " +
            "mọi thứ khác vẫn đi theo đường thông thường.",
        "DNS mã hóa (DoT / DoH)" to
            "Với các máy chủ hỗ trợ, truy vấn được gửi đi dưới dạng mã hóa: không ai trên mạng (chủ Wi-Fi, nhà mạng) có thể thấy " +
            "bạn truy cập trang nào hay can thiệp vào kết quả trả về. Ở chế độ Tự động, DoT được thử trước, rồi đến DoH; nếu cả hai đều không được, " +
            "ứng dụng dùng DNS thường. Bạn sẽ được cảnh báo khi điều đó xảy ra, và ứng dụng sẽ thử quay lại mã hóa mỗi khi đổi " +
            "mạng và cứ 10 phút một lần. Khi bật \"Mã hóa nghiêm ngặt\", DNS thường sẽ không bao giờ được dùng. " +
            "Màn hình chính cho biết phương thức đang dùng.",
        "Kiểm tra kết nối" to
            "☰ > Cài đặt DNS > Kiểm tra kết nối sẽ gửi các câu hỏi DNS thật qua đường hầm. Nó cho biết " +
            "DNS có thật sự được trả lời từ máy chủ bạn đã chọn không, nhanh đến đâu, máy chủ có xác thực chữ ký DNSSEC không và " +
            "có chặn một tên miền quảng cáo nổi tiếng không.",
        "Quyền riêng tư" to
            "Không cần tài khoản, không thu thập dữ liệu, không quảng cáo. Ứng dụng không lưu tên miền truy vấn và tự nó không gửi gì đi đâu cả. " +
            "Truy vấn của bạn chỉ đến nhà cung cấp DNS bạn đã chọn, theo chính sách quyền riêng tư của nhà cung cấp đó. " +
            "DNS mã hóa (DoT/DoH) ngăn bất kỳ ai trong mạng đọc hoặc sửa truy vấn của bạn. Trước khi gửi, ứng dụng loại bỏ dữ liệu phụ có thể nhận diện thiết bị (mạng con của máy khách, cookie, mã định danh), đệm thông điệp để che độ dài và bỏ các vé phiên TLS khi đổi mạng. " +
            "Nói thật: không có rơ-le, nhà cung cấp DNS vẫn thấy địa chỉ IP công khai của bạn (họ phải trả lời bạn), và lỗi chứng chỉ có thể nghĩa là ai đó đang can thiệp vào kết nối. " +
            "Nhật ký chẩn đoán chỉ chứa các sự kiện kết nối.",
        "Pin và tài nguyên" to
            "Ứng dụng dùng rất ít tài nguyên khi chạy nền. Không có gì chạy lặp khi màn hình tắt; " +
            "nó chỉ hoạt động khi có truy vấn DNS đến. Các kết nối mã hóa tự đóng khi không dùng.",
        "Cần biết" to
            "Android chỉ cho phép một VPN tại một thời điểm; ứng dụng này không thể kết nối khi một ứng dụng VPN khác đang hoạt động. " +
            "Cài đặt \"DNS bảo mật\" của trình duyệt và \"DNS riêng tư\" của Android được đặt thành một tên máy chủ cụ thể sẽ dùng máy chủ riêng " +
            "và có thể bỏ qua định tuyến này; để chúng ở chế độ \"Tự động\" hoặc \"Tắt\" là đủ. " +
            "Nhấn giữ quả cầu để chuyển nhanh sang các máy chủ bạn hay dùng hoặc tạm dừng kết nối một lúc.",
    )

    override val NOTIF_CHANNEL = "Trạng thái kết nối"
    override val NOTIF_CHANNEL_NOTE = "Hiển thị khi kết nối DNS đang bật"
    override val NOTIF_ALERT_CHANNEL = "Cảnh báo kết nối"
    override val NOTIF_CONNECTING = "Đang kết nối…"
    override val NOTIF_STOP = "Ngắt kết nối"
    override val NOTIF_NEXT = "Tiếp theo"
    override val NOTIF_DROP_TITLE = "Mất kết nối DNS"
    override val NOTIF_RECONNECT = "Kết nối lại"
    override fun notifOn(name: String, proto: String) = "Đã kết nối với $name · $proto"
    override fun notifPaused(time: String) = "Đã tạm dừng · tiếp tục lúc $time"
    override val TILE_ON = "Đã kết nối"
    override val TILE_OFF = "Tắt"
    override val WIDGET_TAP = "Chạm: kết nối / ngắt kết nối"
    override val ERR_PERMISSION = "Quyền VPN chưa được cấp"
    override val ERR_ESTABLISH = "Không thể mở giao diện VPN. Có thể một VPN khác đang hoạt động."
    override fun errNoReply(name: String) = "$name không phản hồi"
    override val PHONE_BYPASS = "Điện thoại không dùng DNS này (DNS riêng?)"
    override fun errNoProto(name: String, proto: String) = "$name không hỗ trợ $proto"
    override val ERR_SOCKET = "Không thể truy cập mạng"
    override fun errPrivateDns(host: String) = "DNS riêng tư của Android đang được đặt thành $host và bỏ qua ứng dụng này. Hãy đặt Cài đặt > Mạng > DNS riêng tư thành Tự động hoặc Tắt."
    override val ERR_REVOKED = "Kết nối đã bị hệ thống đóng"
    override val ERR_TUNNEL = "Đường hầm bị đóng đột ngột"
    override val ERR_UNKNOWN = "Đã xảy ra sự cố bất ngờ"

    override val CONSENT_TITLE = "Trước khi kết nối"
    override val CONSENT_BODY = listOf(
        "$APP dùng giao diện VPN của Android để chuyển các truy vấn DNS của bạn (tên các trang web bạn truy cập) đến máy chủ DNS bạn chọn.",
        "Lưu lượng của bạn không được gửi đến máy chủ VPN; chỉ các truy vấn DNS đến nhà cung cấp bạn đã chọn. Với các máy chủ hỗ trợ, " +
            "truy vấn được mã hóa (DoT/DoH); nếu không, chúng được gửi không mã hóa. Chính sách quyền riêng tư của nhà cung cấp sẽ được áp dụng." +
            " Nếu bật “$MOD_DPI” hoặc “$MOD_ADS”, toàn bộ lưu lượng đi qua một bộ chuyển tiếp chỉ chạy bên trong điện thoại; vẫn không được gửi đến nơi nào khác.",
        "Ứng dụng không thu thập dữ liệu cá nhân, không lưu tên miền truy vấn và không chia sẻ gì với ai.",
        "Nếu tiếp tục, Android sẽ hiện yêu cầu kết nối VPN; bạn cần chạm \"OK\".",
    )
    override val CONSENT_OK = "Đã hiểu, tiếp tục"
    override val CLOSE = "Đóng"
    override val BACK = "Quay lại"

    override val RESUMING = "Đang tiếp tục…"
    override val DOWNGRADED = "Không mã hóa được, đang dùng DNS thường"
    override val UPGRADED = "Đã quay lại DNS mã hóa"
    override val NOTIF_DOWNGRADE_TITLE = "DNS không được mã hóa"
    override fun notifDowngrade(name: String) = "Không thể thiết lập kết nối mã hóa với $name. Đang dùng DNS thường; ứng dụng sẽ thử quay lại mã hóa."
    override fun backupUsed(failed: String, used: String) = "$failed không phản hồi, đã kết nối với $used"
    override val NOTIF_RETRYING = "Mất kết nối, đang thử lại…"
    override fun errNoEncrypted(name: String) = "Không thể thiết lập kết nối mã hóa với $name"
    override fun errUntrusted(name: String) = "Không xác minh được chứng chỉ của $name; mạng hoặc phần mềm có thể đang can thiệp vào kết nối mã hóa"
    override val APPLYING = "Đang áp dụng cài đặt mới cho kết nối"
    override val CONFIRM_DISCONNECT = "Ngắt kết nối?"
    override val DISCONNECT = "Ngắt kết nối"

    override val SEC_NOTIF = "Thông báo"
    override val STRICT_ENC = "Mã hóa nghiêm ngặt"
    override val STRICT_ENC_NOTE = "Không bao giờ chuyển sang DNS thường"
    override val IP_MODE = "Phiên bản IP"
    override val IP_MODE_NOTE = "Loại mạng bạn có được thử trước, loại kia làm dự phòng"
    override val OPT_IP_MODE = listOf("IPv4 + IPv6", "Chỉ IPv4")
    override val FILTER = "Chặn"
    override val FILTER_LEVEL = "Quảng cáo và theo dõi"
    override val OPT_FILTER = listOf(
        "Tắt",
        "Cơ bản",
        "Vừa",
        "Chặt",
    )
    override val FILTER_NOTES = listOf(
        "Không chặn gì cả.",
        "Các trang quảng cáo, lừa đảo và mã độc đã biết. Rất ít nguy cơ gây lỗi.",
        "Cơ bản thêm nhiều trình theo dõi và phân tích. Một số trang có thể gặp sự cố.",
        "Danh sách rộng nhất, gồm cả gian lận, lạm dụng và chuyển hướng. Hay gặp lỗi.",
    )
    override val FILTER_INFO = "Việc chặn diễn ra hoàn toàn trên điện thoại: khi một trang trong danh sách được hỏi, kết quả trả về là 0.0.0.0, truy vấn không đến máy chủ nào và không lưu tên nào. Chỉ hoạt động khi đang kết nối. DNS an toàn riêng của trình duyệt có thể bỏ qua. Nếu một trang bị lỗi, hãy cho phép nó trong Vừa bị chặn."
    override val FILTER_LAST = "Vừa bị chặn"
    override val FILTER_RECENT_NOTE = "Chạm: cho phép"
    override val FILTER_RECENT_EMPTY = "Phiên này chưa chặn gì. Tên sẽ hiện ở đây khi đang kết nối và đã bật một mức."
    override val FILTER_RECENT_FOOT = "Chỉ nằm trong bộ nhớ của phiên này; không bao giờ lưu, xóa khi ngắt kết nối."
    override val FILTER_ALLOW = "Được phép"
    override val FILTER_BLOCK = "Danh sách chặn của tôi"
    override val FILTER_ADD = "Thêm…"
    override val FILTER_REMOVE = "Chạm: xóa"
    override val FILTER_ALLOW_ADD = "Tên miền cho phép"
    override val FILTER_BLOCK_ADD = "Tên miền cần chặn"
    override val FILTER_ERR = "Nhập tên miền hợp lệ, ví dụ vidu.com"
    override val FILTER_ERR_LIMIT = "Tối đa 200 tên miền"
    override val FILTER_ALLOW_EMPTY = "Chưa có tên miền được phép. Nếu một trang bị lỗi, hãy thêm vào đây."
    override val FILTER_BLOCK_EMPTY = "Danh sách chặn của bạn đang trống."
    override val FILTER_ALLOW_FOOT = "Tên miền và mọi tên miền con không bao giờ bị chặn. Cho phép thắng mọi danh sách và danh sách chặn của bạn."
    override val FILTER_BLOCK_FOOT = "Tên miền và mọi tên miền con luôn bị chặn (kể cả khi mức đang tắt)."
    override val FILTER_REMOVE_BTN = "Xóa"
    override fun filterAllowed(name: String) = "Đã cho phép $name"
    override fun filterBlocked(name: String) = "$name sẽ bị chặn"
    override fun filterRemoved(name: String) = "Đã xóa $name"
    override fun filterRemoveAsk(name: String) = "Xóa $name khỏi danh sách?"
    override val TEST_IPV6 = "Đường IPv6"
    override val AUTO_RECONNECT = "Tự động kết nối lại"
    override val AUTO_RECONNECT_NOTE = "Nếu mất kết nối, thử lại sau 5 giây, 30 giây và 2 phút"
    override val BACKUP_SERVER = "Máy chủ dự phòng"
    override val BACKUP_OFF = "Tắt"
    override val BACKUP_OFF_NOTE = "Không kết nối nếu máy chủ đã chọn không phản hồi"
    override val BACKUP_FASTEST = "Nhanh nhất"
    override val BACKUP_FASTEST_NOTE = "Máy chủ khác nhanh nhất theo lần kiểm tra gần nhất"
    override val CONFIRM_OFF = "Hỏi trước khi ngắt kết nối"
    override val CONFIRM_OFF_NOTE = "Chạm nhầm vào quả cầu sẽ không ngắt kết nối"
    override val LOCK_HIDE = "Ẩn trên màn hình khóa"
    override val LOCK_HIDE_NOTE = "Tên máy chủ không hiện trong thông báo trên màn hình khóa"
    override val QUIET_NOTIF = "Thông báo yên lặng"
    override val QUIET_NOTIF_NOTE = "Không có biểu tượng trên thanh trạng thái, im lặng"
    override val REMEMBER_FILTER = "Nhớ bộ lọc gần nhất"
    override val REMEMBER_FILTER_NOTE = "Bộ lọc bạn chọn lần trước sẽ trở lại khi mở ứng dụng"
    override val AUTO_MEASURE = "Đo khi khởi động"
    override val AUTO_MEASURE_NOTE = "Tự động đo nếu lần kiểm tra gần nhất đã hơn một ngày"
    override val MEASURE_ENC = "Đo qua kết nối mã hóa"
    override val MEASURE_ENC_NOTE = "Đo tốc độ qua DoT, sát với thực tế dùng mã hóa hơn"
    override val OPT_SORT = listOf("Mặc định", "Tốc độ", "Tên")
    override fun sortA11y(mode: String) = "Sắp xếp: $mode"
    override val AUTO_LIGHT = "Tự động: chủ đề sáng"
    override val AUTO_DARK = "Tự động: chủ đề tối"
    override val NIGHT_HOURS = "Giờ ban đêm"
    override val FILTER_ENCRYPTED = "Mã hóa"
    override val FILTER_UNFILTERED = "Không lọc"

    override val TEST = "Kiểm tra kết nối"
    override val TEST_NOTE = "DNS, DNSSEC và chặn quảng cáo"
    override val TESTING = "Đang kiểm tra…"
    override val TEST_TITLE = "Kiểm tra kết nối"
    override val TEST_OK = "DNS đang hoạt động"
    override val TEST_FAIL = "Không phản hồi"
    override val TEST_SERVER = "Máy chủ"
    override val TEST_METHOD = "Phương thức"
    override val TEST_LATENCY = "Thời gian phản hồi"
    override val TEST_DNSSEC = "Xác thực DNSSEC"
    override val TEST_ADS = "Chặn quảng cáo"
    override val DNSSEC_YES = "Có xác thực"
    override val DNSSEC_NO = "Không xác thực"
    override val ADS_YES = "Bật"
    override val ADS_NO = "Tắt"
    override val UNKNOWN = "Không rõ"
    override val TEST_EXPLAIN = "Các câu hỏi được gửi qua đường hầm, giống hệt cách một ứng dụng sẽ hỏi; câu trả lời đến từ máy chủ bạn đã chọn."
    override val TEST_AGAIN = "Kiểm tra lại"

    override val RECOMMEND = "Tìm máy chủ cho tôi"
    override val RECOMMEND_NOTE = "Chọn mục tiêu của bạn và chúng tôi sẽ kết nối với máy chủ phù hợp nhanh nhất"
    override val GOAL_SPEED = "Tốc độ"
    override val GOAL_SPEED_NOTE = "Máy chủ nhanh nhất theo các lần kiểm tra của bạn"
    override val GOAL_PRIVACY_NOTE = "Không ghi log, ưu tiên riêng tư"
    override val GOAL_ADS_NOTE = "Chặn quảng cáo và trình theo dõi"
    override val GOAL_FAMILY_NOTE = "Chặn nội dung người lớn"
    override val GOAL_SECURITY_NOTE = "Chặn trang web độc hại và lừa đảo"
    override fun recommended(name: String) = "Đề xuất: $name"

    override val PRIVATE_DNS = "Tên DNS riêng tư"
    override val PRIVATE_DNS_NOTE = "Bạn có thể dán nó vào cài đặt DNS riêng tư của Android. Khi đó hệ thống sẽ dùng trực tiếp máy chủ này và ứng dụng này bị bỏ qua."
    override val CLEAR_HISTORY = "Xóa lịch sử tốc độ"
    override val HISTORY_CLEARED = "Đã xóa các kết quả đo"

    override val GUARD = "Bảo vệ luôn bật"
    override val GUARD_NOTE = "VPN luôn bật"
    override val GUARD_BODY = listOf(
        "Khi ứng dụng chưa kết nối (đã tắt, tạm dừng hoặc sau khi mất kết nối), các truy vấn DNS của bạn sẽ đến máy chủ của nhà mạng.",
        "Để tránh điều này, hãy bật \"VPN luôn bật\" cho ứng dụng này trong cài đặt VPN của Android. Nếu \"Chặn kết nối không dùng VPN\" cũng được bật, internet sẽ không hoạt động khi ứng dụng chưa kết nối: không có gì bị rò rỉ, nhưng tạm dừng cũng đồng nghĩa với mất internet.",
        "Với VPN luôn bật, hệ thống tự khởi động ứng dụng khi điện thoại bật nguồn và sau khi ứng dụng dừng lại.",
    )
    override val GUARD_BUTTON = "Mở cài đặt VPN của hệ thống"
    override val BATTERY = "Cài đặt pin"
    override val BATTERY_OK = "Không bị hạn chế"
    override val BATTERY_LIMITED = "Có thể bị hạn chế"
    override val BATTERY_BODY = listOf(
        "Android thường bảo vệ các ứng dụng VPN. Tuy nhiên, một số hãng (Xiaomi, Huawei, Oppo, Vivo, một số phiên bản Samsung) có thể đóng các ứng dụng chạy nền để tiết kiệm pin.",
        "Nếu kết nối cứ tự ngắt, hãy đặt mức dùng pin của ứng dụng này thành \"Không hạn chế\" hoặc \"Không tối ưu hóa\"; trên một số điện thoại, hãy cho phép cả \"Tự khởi động\".",
    )
    override val BATTERY_BUTTON = "Mở cài đặt pin"

    override val STAT_AVG = "Thời gian phản hồi trung bình"
    override val STAT_SAVED = "Thời gian tiết kiệm nhờ bộ nhớ đệm"
    override val STAT_TRAFFIC = "Lưu lượng DNS"
    override val SESSIONS = "Lịch sử kết nối"
    override val SESSIONS_NOTE = "30 kết nối gần nhất; tên miền truy vấn không bao giờ được lưu"
    override val SESSIONS_EMPTY = "Chưa ghi nhận kết nối nào."
    override val MOST_USED = "Dùng nhiều nhất"
    override val TODAY = "Hôm nay"
    override val ORB_SHAPE = "Hình dạng quả cầu"
    override val ORB_SHAPE_EACH = "Hình dạng theo chủ đề"
    override val ORB_SHAPE_NAMES = listOf("Quả cầu", "Tam giác", "Hình vuông", "Lục giác", "Ngôi sao", "Bát giác", "Ngũ giác", "Hình chữ nhật", "Tam giác ngược", "Hình thoi", "Hoa", "Sao sáu cánh")
    override val SHIELD_WORD = "Khiên"
    override val LIQUID_COLOR = "Màu chất lỏng"
    override val LIQUID_THEME = "Theo giao diện"
    override val COLOR_WORD = "Màu"
    override val LIQUID_NOTE = "Màu đã chọn thay cho sắc thái tốc độ; tốc độ sóng vẫn theo tốc độ máy chủ."
    override val YESTERDAY = "Hôm qua"
    override fun endReason(r: EndReason) = when (r) {
        EndReason.USER -> "Bạn đã ngắt kết nối"
        EndReason.PAUSE -> "Đã tạm dừng"
        EndReason.SWITCH -> "Đã đổi máy chủ"
        EndReason.DROP -> "Mất kết nối"
        EndReason.REVOKED -> "Bị hệ thống đóng"
        EndReason.FAILED -> "Không phản hồi"
        EndReason.NETWORK -> "Mạng đã thay đổi"
    }
    override fun sessionLine(duration: String, queries: String) = "$duration · $queries truy vấn"

    override val SOUND_MOTION = "Âm thanh và chuyển động"
    override val SEC_SOUND = "Âm thanh"
    override val SOUND_ON = "Hiệu ứng âm thanh"
    override val SOUND_ON_NOTE = "Âm ngắn, nhẹ khi chạm và khi kết nối. Không phát khi điện thoại ở chế độ im lặng."
    override val SOUND_UI = "Âm khi chạm"
    override val SOUND_UI_NOTE = "Nút, công tắc và chuyển trang"
    override val SOUND_CONN = "Âm kết nối"
    override val SOUND_CONN_NOTE = "Âm riêng khi kết nối, ngắt kết nối và khi lỗi"
    override val SOUND_VOL = "Âm lượng"
    override val SOUND_PACK = "Bộ âm thanh"
    override val SOUND_TEST = "Thử âm kết nối"
    override val QUIET_HOURS = "Giờ yên tĩnh"
    override val QUIET_NOTE = "Không âm thanh và rung trong khoảng giờ này"
    override val QUIET_RANGE = "Khoảng giờ yên tĩnh"
    override val SEC_MOTION_FX = "Chuyển động và hiệu ứng"
    override val ANIM_SPEED = "Tốc độ hoạt ảnh"
    override val TAP_FX = "Hiệu ứng chạm"
    override val TAP_FX_NOTE = "Hiệu ứng nhỏ riêng của từng kiểu tại chỗ bạn chạm"
    override val CELEBRATE = "Ăn mừng khi kết nối"
    override val CELEBRATE_NOTE = "Màn trình diễn riêng của kiểu quanh quả cầu khi đã kết nối"
    override val HAPTIC_LEVEL = "Độ mạnh rung"
    override val REMEMBER_MODS = "Nhớ các mô-đun"
    override val REMEMBER_MODS_NOTE = "Khi kết nối, Vượt DPI và Quảng cáo+ bật lại như lần cuối bạn để"
    override val PROFILES = "Hồ sơ"
    override val COPY_STATUS = "Sao chép tóm tắt trạng thái"
    override val OPT_PACK = listOf("Tự động", "Mềm", "Kính", "Cổ điển")
    override val SOUND_PACK_NOTE = "Tự động: âm thanh của kiểu đang dùng"
    override val PACK_SPACE = "Vũ trụ"
    override val PACKS_NOTE = "Các gói mới (từ Aqua đến Vũ trụ) có âm thanh riêng và sáu hiệu ứng: chạm, công tắc, kết nối, ngắt, lỗi và xong."
    override val OPT_HAPTIC = listOf("Nhẹ", "Vừa", "Mạnh")
    override val PROFILE_NAMES = listOf("Tốc độ", "Riêng tư", "Gia đình", "Bảo vệ toàn diện")
    override val PROFILE_NOTES = listOf("Máy chủ nhanh nhất, bộ nhớ đệm lớn, không chặn", "Mã hóa nghiêm ngặt, chặn trình theo dõi, Quảng cáo+", "Máy chủ lọc cho gia đình, chặn mức vừa", "Chặn quảng cáo và trình theo dõi, Vượt DPI, Quảng cáo+")
    override fun profileApplied(name: String) = "Đã áp dụng hồ sơ: $name"

    override val WHATS_NEW = "Có gì mới?"
    override val WHATS_NEW_TOAST = "Ứng dụng đã được cập nhật"
    override val SHOW = "Xem"
    override val WHATS_NEW_ITEMS = listOf(
        "Mới: hiệu ứng âm thanh, công cụ hoạt ảnh mượt được viết lại, hiệu ứng chạm riêng cho từng kiểu, hồ sơ, giờ yên tĩnh và hơn thế nữa. ☰ > Âm thanh và chuyển động.",
        "Mới: nút Vượt DPI và Quảng cáo+. Chạy cùng DNS hoặc riêng; mặc định đều tắt.",
        "Mới: nhập danh sách chặn riêng, thông báo kết nối/ngắt/quá thời gian, biểu đồ độ trễ từng truy vấn và chặn DNS khi mất kết nối.",
        "Mới: danh sách hiện 8 máy chủ đầu (Xem tất cả / Thu gọn), Thêm DNS tùy chỉnh ở trên cùng, thanh cuộn mỏng.",
        "Mới: chặn quảng cáo, trình theo dõi và mã độc (Tắt/Cơ bản/Vừa/Chặt) cùng danh sách cho phép và chặn riêng. ☰ > Chặn. Chạy ngay trên máy.",
        "Mới: kiểu Frutiger Aurora; Y2K nay ánh ba chiều, Metro mang phong cách thành phố và âm nhạc. Chọn ở ☰ > Cá nhân hóa > Kiểu giao diện.",
        "Mới: IPv4 và IPv6 cùng lúc, phát hiện lỗi nhanh hơn; vì quyền riêng tư, dấu vết thiết bị bị xóa khỏi truy vấn và độ dài thông điệp được che.",
        "Mới: Cài đặt được chia theo chủ đề. Menu ☰ mở Cài đặt DNS, Kết nối và ứng dụng, Thông báo, Danh sách máy chủ, Thống kê và lịch sử, Dữ liệu.",
        "Mới: cửa sổ Cá nhân hóa (trong menu ☰): ngôn ngữ, giao diện, kiểu, hình nền, biểu tượng, chữ và hỗ trợ tiếp cận.",
        "Mới: menu ☰ trên màn hình chính và cửa sổ Giới thiệu (tin mới, trợ giúp, nhật ký, chia sẻ, phiên bản).",
        "Sửa lỗi: đặt ảnh của bạn hoặc ảnh có sẵn làm nền đã hoạt động (kích thước ảnh bị đọc sai).",
        "Sửa lỗi: kiểm tra kết nối phân biệt lỗi máy chủ với việc điện thoại không dùng DNS và sẽ cảnh báo.",
        "Sửa lỗi: vẽ lại kiểu Metro, Eco và Y2K; đổi biểu tượng có hiệu lực khi bạn thoát ứng dụng.",
        "Mới: 8 ảnh nền có sẵn (☰ → Cá nhân hóa → Ảnh nền → Ảnh có sẵn).",
        "Mới: khắc phục sự cố, tìm máy chủ, chia sẻ kết quả đo, sửa máy chủ riêng và tùy chọn không lưu lịch sử.",
        "Biểu tượng ứng dụng: chọn một trong năm biểu tượng hợp với năm phong cách.",
        "Ảnh nền: dùng ảnh của bạn làm nền, chỉnh được lớp phủ và độ mờ; chữ luôn dễ đọc.",
        "Năm kiểu giao diện: Aqua (cổ điển), Aero (bầu trời và cỏ), Metro (ô phẳng), Eco (thiên nhiên) và Y2K hồng, mỗi kiểu có hoạt ảnh riêng, cùng chuyển cảnh mượt hơn.",
        "Chọn ứng dụng: chỉ áp dụng DNS cho ứng dụng bạn chọn hoặc loại trừ một số ứng dụng.",
        "Thêm máy chủ DNS riêng (tối đa 8), 10 máy chủ mới và mục thông tin cho mỗi máy chủ: dùng để làm gì, chủ sở hữu, ping trung bình.",
        "Kết nối an toàn hơn: kiểm tra thêm chống phản hồi DNS giả mạo, cảnh báo khi chuyển sang DNS thường, tùy chọn mã hóa nghiêm ngặt và tự động quay lại mã hóa.",
        "Kiểm tra kết nối: chỉ một chạm để xác nhận DNS được trả lời từ máy chủ bạn chọn, kèm xác thực DNSSEC và chặn quảng cáo.",
        "Máy chủ dự phòng và tự động kết nối lại: ứng dụng tự phục hồi nếu máy chủ đã chọn không phản hồi hoặc kết nối bị ngắt.",
        "Lịch sử kết nối, máy chủ dùng nhiều nhất, thời gian phản hồi trung bình và lưu lượng DNS.",
        "Bộ lọc mới (Mã hóa, Không lọc), sắp xếp theo tên, \"Tìm máy chủ cho tôi\" và đo khi khởi động.",
        "Bộ đếm trực tiếp trong thông báo, nút tạm dừng 15 phút, ẩn trên màn hình khóa và tùy chọn thông báo yên lặng.",
        "Ba chủ đề mới (Anh đào, Mật ong, Cực quang), chủ đề lấy từ hình nền và lựa chọn sáng/tối cho chủ đề tự động.",
        "Bốn ngôn ngữ mới: tiếng Indonesia, tiếng Việt, tiếng Ba Lan và tiếng Ukraina.",
    )
    override fun importedWith(changes: String) = "Đã tải cài đặt · $changes"
    override fun sensitive(c: SensitiveChange) = when (c) {
        SensitiveChange.ENCRYPTION_WEAKER -> "mã hóa bị giảm"
        SensitiveChange.AUTO_START -> "đã bật tự động kết nối"
        SensitiveChange.RULES -> "quy tắc máy chủ đã thay đổi"
        SensitiveChange.PRIVACY -> "đã nới lỏng cài đặt quyền riêng tư hoặc cảnh báo"
    }

    override fun notifOnStats(name: String, proto: String, queries: String, blocked: String) =
        "$name · $proto · $queries truy vấn · $blocked đã chặn"
    override val NOTIF_LOCKED = "Bảo vệ DNS đang bật"
    override val NOTIF_QUIET_CHANNEL = "Trạng thái kết nối (yên lặng)"
    override fun widgetToday(queries: String) = "Hôm nay $queries truy vấn"
    override fun pauseAction(minutes: Int) = "Tạm dừng ${minutes(minutes)}"

    override val CUSTOM_NOTE = "Máy chủ bạn đã thêm"
    override val CUSTOM_ADD = "Thêm DNS tùy chỉnh"
    override val CUSTOM_F_NAME = "Tên"
    override val CUSTOM_F_IP1 = "Địa chỉ IPv4 (vd. 1.2.3.4)"
    override val CUSTOM_F_IP2 = "IPv4 thứ hai (tùy chọn)"
    override val CUSTOM_F_DOT = "Tên DoT (tùy chọn)"
    override val CUSTOM_F_DOH = "Địa chỉ DoH, https://… (tùy chọn)"
    override val CUSTOM_SAVE = "Thêm"
    override val CUSTOM_CANCEL = "Hủy"
    override val CUSTOM_HINT = "Điền DoT hoặc DoH để kết nối mã hóa; để trống sẽ dùng DNS không mã hóa."
    override val CUSTOM_ERR_NAME = "Tên phải dài 1–24 ký tự (không có | ; , =)"
    override val CUSTOM_ERR_IP = "Nhập địa chỉ IPv4 hợp lệ (vd. 1.2.3.4)"
    override val CUSTOM_ERR_DOT = "Tên DoT phải là tên miền hợp lệ"
    override val CUSTOM_ERR_DOH = "Địa chỉ DoH phải bắt đầu bằng https://"
    override val CUSTOM_ERR_LIMIT = "Chỉ thêm được tối đa 8 máy chủ tùy chỉnh"
    override fun customAdded(name: String) = "Đã thêm $name"
    override val CUSTOM_DELETE = "Xóa máy chủ này"
    override val CUSTOM_IN_USE = "Không thể xóa khi đang kết nối"
    override fun customDeleted(name: String) = "Đã xóa $name"
    override val INFO_PURPOSE = "Dùng để làm gì"
    override val INFO_OWNER = "Chủ sở hữu"
    override val INFO_AVG = "Ping trung bình"
    override fun avgPing(ms: Int, n: Int) = "$ms $msU · $n lần đo"

    override val APPS = "Ứng dụng"
    override val APPS_ALL = "Tất cả"
    override fun appsOnly(n: Int) = "Chỉ ứng dụng đã chọn ($n)"
    override fun appsExcept(n: Int) = "Tất cả trừ đã chọn ($n)"
    override val APPS_MODE = "Ứng dụng nào dùng DNS này?"
    override val OPT_APPS = listOf("Tất cả", "Đã chọn", "Trừ đã chọn")
    override val APPS_NOTE = "Ứng dụng không thuộc phạm vi sẽ dùng DNS của điện thoại. Mỗi lúc chỉ chạy một máy chủ DNS; không thể chọn máy chủ riêng cho từng ứng dụng."
    override val APPS_LOADING = "Đang tải ứng dụng…"
    override val APPS_EMPTY = "Không tìm thấy ứng dụng"
    override val APPS_NONE_SELECTED = "Chưa chọn ứng dụng nào: DNS áp dụng cho tất cả."
    override val APPS_APPLY = "Áp dụng ngay"
    override val APPS_PENDING = "Thay đổi có hiệu lực khi kết nối được làm mới (ngắt một hai giây)."

    override val NOTES = mapOf(
        "cloudflare" to "Nhanh, ưu tiên riêng tư",
        "google" to "Ổn định, được dùng rộng rãi",
        "quad9" to "Chặn tên miền độc hại",
        "adguard" to "Chặn quảng cáo và trình theo dõi",
        "controld" to "Không lọc, nhanh",
        "opendns" to "Cisco, chống lừa đảo",
        "dnssb" to "Ưu tiên riêng tư, nhanh",
        "dns4eu" to "DNS của EU, chống mã độc",
        "uncensored" to "Không lọc, không chuyển hướng",
        "quad9-open" to "Không chặn",
        "adguard-open" to "Không chặn, ưu tiên riêng tư",
        "dns4eu-open" to "DNS của EU, không lọc",
        "controld-ads" to "Quảng cáo, theo dõi, mã độc",
        "dns4eu-ads" to "DNS của EU, quảng cáo và mã độc",
        "cloudflare-security" to "Chặn trang web độc hại",
        "controld-malware" to "Chặn trang web độc hại",
        "cleanbrowsing-security" to "Lừa đảo và trang web độc hại",
        "cloudflare-family" to "Lọc mã độc và nội dung người lớn",
        "opendns-family" to "Lọc nội dung người lớn",
        "adguard-family" to "Lọc quảng cáo và nội dung người lớn",
        "cleanbrowsing-family" to "Nội dung người lớn, tìm kiếm an toàn",
        "dns4eu-child" to "DNS của EU, bảo vệ trẻ em",
        "controld-family" to "Lọc nội dung người lớn",
        "nextdns" to "Bộ lọc tùy chỉnh, nhanh",
        "cira-private" to "Canada, không lọc, riêng tư",
        "cira-protected" to "Canada, chặn trang độc hại",
        "libredns" to "Độc lập, không lọc",
        "switch" to "Thụy Sĩ, chặn trang độc hại",
        "wikimedia" to "DNS của Wikimedia, riêng tư",
        "digitale" to "Phi lợi nhuận Thụy Sĩ, không lọc",
        "quad101" to "Đài Loan, nhanh",
        "alidns" to "Trung Quốc, nhanh",
    )
}
