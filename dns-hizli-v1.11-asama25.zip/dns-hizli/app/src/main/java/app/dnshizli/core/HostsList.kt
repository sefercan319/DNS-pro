package app.dnshizli.core

/**
 * Kullanıcının kendi engel listesini içe/dışa aktarma. Üç yaygın biçim okunur:
 *  - hosts: `0.0.0.0 reklam.example.com` ya da `127.0.0.1 a.example b.example` (yalnızca engelleme adresleri: 0.0.0.0, 127.0.0.1, ::, ::1, 0)
 *  - düz liste: satır başına bir alan adı (`reklam.example.com`, `*.example.com`, `https://example.com/yol` da olur)
 *  - AdBlock kuralı: `||reklam.example.com^` (seçenekli `$...` kurallar ve `@@` istisnalar atlanır)
 * `#` ve `!` ile başlayan satırlar ve satır sonu açıklamaları yok sayılır. Başka bir IP'ye yönlendiren hosts satırları
 * (ör. `192.168.1.5 yazici.lan`) engelleme olmadığı için atlanır. Her şey bellekte yapılır; hiçbir yere gönderilmez.
 */
object HostsList {
    /** Kendi listemizde tutulan en çok alan adı. */
    const val MAX_IMPORTED = 50_000

    /** Dışa aktarmada panoya yazılan en çok alan adı (Android'in pano/aktarım sınırı yüzünden). */
    const val MAX_EXPORT = 8_000

    /** Okunacak en büyük metin (karakter). Daha büyük dosyalar kesilir ve [Result.cut] işaretlenir. */
    const val MAX_CHARS = 4_000_000

    class Result(
        /** Temiz, tekrarsız, sıralı alan adları ([MAX_IMPORTED]'a kadar). */
        val names: List<String>,
        /** Okunamayan ya da blok olmayan (başka IP'ye giden, geçersiz) satırlar. */
        val skipped: Int,
        /** Liste ya da metin sınıra takıldı, fazlası alınmadı. */
        val cut: Boolean,
    )

    private val BLOCK_IPS = setOf("0.0.0.0", "127.0.0.1", "::", "::1", "0", "0:0:0:0:0:0:0:0", "0:0:0:0:0:0:0:1")
    private val SKIP_NAMES = setOf(
        "localhost", "local", "broadcasthost", "ip6-localhost", "ip6-loopback", "ip6-localnet", "ip6-mcastprefix",
        "ip6-allnodes", "ip6-allrouters", "ip6-allhosts", "0.0.0.0",
    )

    fun parse(text: String): Result {
        val set = LinkedHashSet<String>()
        var skipped = 0
        var cut = false
        val src = if (text.length > MAX_CHARS) { cut = true; text.substring(0, MAX_CHARS) } else text
        for (raw in src.lineSequence()) {
            if (set.size >= MAX_IMPORTED) { cut = true; break }
            var line = raw.trim()
            if (line.isEmpty() || line.startsWith("#") || line.startsWith("!") || line.startsWith("[")) continue
            val hash = line.indexOf('#')
            if (hash > 0) line = line.substring(0, hash).trim()
            if (line.isEmpty()) continue
            if (line.startsWith("@@")) { skipped++; continue }
            val found = ArrayList<String>(2)
            if (line.startsWith("||")) {
                val rule = line.substring(2)
                if (rule.contains('$')) { skipped++; continue }
                val d = FilterNames.normalize(rule.substringBefore('^'))
                if (d == null || '/' in rule.substringBefore('^')) { skipped++; continue }
                found.add(d)
            } else {
                val parts = line.split(' ', '\t').filter { it.isNotEmpty() }
                val first = parts[0].lowercase()
                val ipLike = first.contains(':') && !first.contains('.') || first.all { it in '0'..'9' || it == '.' }
                if (ipLike && parts.size >= 2) {
                    if (first !in BLOCK_IPS) { skipped++; continue }
                    for (i in 1 until parts.size) {
                        val n = parts[i]
                        if (n.lowercase() in SKIP_NAMES) continue
                        val d = FilterNames.normalize(n)
                        if (d == null) skipped++ else found.add(d)
                    }
                } else if (parts.size == 1) {
                    if (first in SKIP_NAMES) continue
                    val d = FilterNames.normalize(parts[0])
                    if (d == null) skipped++ else found.add(d)
                } else {
                    skipped++
                    continue
                }
            }
            for (d in found) {
                if (set.size >= MAX_IMPORTED) { cut = true; break }
                set.add(d)
            }
        }
        return Result(set.sorted(), skipped, cut)
    }

    /** Birleştirilmiş liste: önce el ile eklenenler, sonra içe aktarılanlar; tekrarsız. [MAX_IMPORTED] aşılmaz. */
    fun merge(existing: List<String>, added: List<String>): List<String> {
        val set = LinkedHashSet<String>(existing)
        for (a in added) { if (set.size >= MAX_IMPORTED) break; set.add(a) }
        return set.sorted()
    }

    /** hosts biçimi: her satır `0.0.0.0 alanadı`. En çok [MAX_EXPORT] satır. */
    fun export(names: List<String>): String {
        val sb = StringBuilder(names.size.coerceAtMost(MAX_EXPORT) * 28 + 64)
        sb.append("# DNS Hızlı\n")
        var n = 0
        for (d in names) {
            if (n >= MAX_EXPORT) break
            sb.append("0.0.0.0 ").append(d).append('\n')
            n++
        }
        return sb.toString()
    }
}
