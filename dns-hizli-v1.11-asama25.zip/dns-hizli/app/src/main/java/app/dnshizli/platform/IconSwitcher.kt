package app.dnshizli.platform

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import app.dnshizli.core.Journal
import app.dnshizli.core.UiStyle

/**
 * Başlatıcı simgesi: manifestte altı takma ad (activity-alias) vardır, her zaman yalnızca biri açıktır.
 * Değiştirmek, yenisini açıp ötekileri kapatmaktır; uygulama kapanmaz (DONT_KILL_APP). Bazı başlatıcılar yeni simgeyi
 * birkaç saniye sonra gösterir ve ana ekrana eklenmiş eski simge kaybolabilir (kullanıcı uygulamayı yeniden ekler).
 */
object IconSwitcher {
    private fun alias(st: UiStyle): String = "app.dnshizli.platform.Icon" + when (st) {
        UiStyle.AQUA -> "Aqua"
        UiStyle.AERO -> "Aero"
        UiStyle.METRO -> "Metro"
        UiStyle.ECO -> "Eco"
        UiStyle.Y2K -> "Y2k"
        UiStyle.AURORA -> "Aurora"
    }

    private fun comp(ctx: Context, st: UiStyle) = ComponentName(ctx.packageName, alias(st))

    /** Manifestteki varsayılan: yalnızca Aqua açık. */
    private fun enabled(ctx: Context, st: UiStyle): Boolean =
        when (ctx.packageManager.getComponentEnabledSetting(comp(ctx, st))) {
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
            PackageManager.COMPONENT_ENABLED_STATE_DEFAULT -> st == UiStyle.AQUA
            else -> false
        }

    /** Ayara göre doğru durumda mı? Değilse düzeltir (veri silindiyse ya da yarım kalmış değişiklik varsa). */
    fun sync(ctx: Context, want: UiStyle) {
        try {
            if (UiStyle.values().all { enabled(ctx, it) == (it == want) }) return
            apply(ctx, want)
        } catch (_: Exception) {}
    }

    /** Önce yenisi açılır, sonra ötekiler kapanır: hiçbir anda başlatıcıda simge olmayan bir durum kalmaz. */
    fun apply(ctx: Context, want: UiStyle): Boolean = try {
        val pm = ctx.packageManager
        pm.setComponentEnabledSetting(comp(ctx, want), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
        for (st in UiStyle.values()) if (st != want) {
            pm.setComponentEnabledSetting(comp(ctx, st), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
        }
        true
    } catch (e: Exception) {
        Journal.add("simge değiştirilemedi: ${e.javaClass.simpleName}")
        false
    }
}
