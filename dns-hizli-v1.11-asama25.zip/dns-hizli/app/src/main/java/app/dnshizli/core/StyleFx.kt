package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Stile özgü dokunma ve bağlanma kutlaması efektleri. Hepsi önceden hazırlanmış yollarla ve sabit parçacık tablosuyla
 * çizilir: kare başına bellek ayırmaz, rastgelelik kullanmaz (aynı dokunuş her zaman aynı görünür, test edilebilir).
 * Koordinatlar çağıranın yerel koordinatlarındadır; [t] 0..1 efekt ilerlemesidir.
 */
object StyleFx {
    /** Dokunma efektinin süresi (sn). */
    const val TAP_SEC = 0.55f

    /** Bağlanma kutlamasının süresi (sn). */
    const val CELEBRATE_SEC = 1.15f

    private const val GOLDEN = 2.3999631f      // altın açı (rad): parçacıklar eşit dağılır
    private val PASTEL = intArrayOf(0xFFFF7EB6.toInt(), 0xFFB388FF.toInt(), 0xFF7FDBFF.toInt(), 0xFFFFE066.toInt())

    private val leaf = GPath().apply {
        moveTo(0f, -1f); cubicTo(0.95f, -0.45f, 0.95f, 0.45f, 0f, 1f); cubicTo(-0.95f, 0.45f, -0.95f, -0.45f, 0f, -1f); close()
    }
    private val star = GPath().apply {
        moveTo(0f, -1f); quadTo(0.10f, -0.10f, 1f, 0f); quadTo(0.10f, 0.10f, 0f, 1f)
        quadTo(-0.10f, 0.10f, -1f, 0f); quadTo(-0.10f, -0.10f, 0f, -1f); close()
    }

    /** Küçük dokunma efekti: [x],[y] dokunulan nokta. */
    fun tap(kind: FxKind, g: Gfx, theme: AeroTheme, x: Float, y: Float, t: Float) {
        if (kind == FxKind.NONE || t <= 0f || t >= 1f) return
        burst(kind, g, theme, x, y, t, 44f, 8, false)
    }

    /** Büyük kutlama: [x],[y] merkez, [r] küre yarıçapı. */
    fun celebrate(kind: FxKind, g: Gfx, theme: AeroTheme, x: Float, y: Float, r: Float, t: Float) {
        if (kind == FxKind.NONE || t <= 0f || t >= 1f) return
        burst(kind, g, theme, x, y, t, r * 1.8f, 16, true)
    }

    private fun frac(v: Float): Float = v - kotlin.math.floor(v)

    private fun burst(kind: FxKind, g: Gfx, th: AeroTheme, x: Float, y: Float, t: Float, size: Float, count: Int, big: Boolean) {
        val rem = 1f - t
        val fade = rem * rem
        val ease = Easing.outCubic(t)
        g.save()
        when (kind) {
            FxKind.RING -> {
                for (i in 0 until (if (big) 3 else 2)) {
                    val u = Easing.clamp01((t - i * 0.14f) / (1f - i * 0.14f))
                    if (u <= 0f) continue
                    val rr = size * (0.25f + 0.85f * Easing.outCubic(u))
                    val a = 1f - u
                    g.paint(Rgb.alpha(th.accentLight, (a * 0.40f).coerceIn(0f, 1f))); g.circle(x, y, rr)
                    g.paint(Rgb.alpha(th.accent, (a * 0.95f).coerceIn(0f, 1f))); g.strokeWidth(3.2f * a + 1f); g.strokeCircle(x, y, rr)
                    g.paint(Rgb.alpha(Rgb.WHITE, (a * 0.8f).coerceIn(0f, 1f))); g.strokeWidth(1.2f); g.strokeCircle(x, y, rr - 2.5f)
                }
            }
            FxKind.DROP -> {
                val u = ease
                g.paint(Rgb.alpha(th.accent, (fade * 0.9f).coerceIn(0f, 1f))); g.strokeWidth(2.6f * fade + 0.8f); g.strokeCircle(x, y, size * 0.5f * u)
                for (i in 0 until count) {
                    val ang = -PI.toFloat() / 2f + (frac(i * 0.37f) - 0.5f) * 2.4f
                    val sp = 0.55f + 0.45f * frac(i * 0.618f)
                    val px = x + cos(ang) * size * sp * u * 1.1f
                    val py = y + sin(ang) * size * sp * u * 1.1f + size * 0.9f * t * t
                    val rr = size * (if (big) 0.11f else 0.10f) * (1f - 0.5f * t) * (0.7f + 0.5f * frac(i * 0.31f))
                    val a = 1f - t * t
                    g.paint(Rgb.alpha(Rgb.WHITE, (a).coerceIn(0f, 1f))); g.circle(px, py, rr)
                    g.paint(Rgb.alpha(th.accentDeep, (a).coerceIn(0f, 1f))); g.strokeWidth(1.4f); g.strokeCircle(px, py, rr)
                    g.paint(Rgb.alpha(th.accentLight, (a * 0.9f).coerceIn(0f, 1f))); g.circle(px + rr * 0.15f, py + rr * 0.2f, rr * 0.45f)
                }
            }
            FxKind.SLICE -> {
                val n = if (big) 3 else 1
                for (i in 0 until n) {
                    val u = Easing.clamp01((t - i * 0.12f) / (1f - i * 0.12f))
                    if (u <= 0f) continue
                    val half = size * (0.2f + 0.8f * Easing.outQuint(u)) * (if (big) 0.8f else 0.7f)
                    val a = 1f - u
                    g.paint(Rgb.alpha(th.accent, (a * 0.34f).coerceIn(0f, 1f))); g.rect(x - half, y - half, x + half, y + half)
                    g.paint(Rgb.alpha(th.accentDeep, (a * 0.95f).coerceIn(0f, 1f))); g.strokeWidth(2.5f)
                    g.line(x - half, y - half, x + half, y - half); g.line(x - half, y + half, x + half, y + half)
                }
            }
            FxKind.LEAF -> {
                for (i in 0 until count) {
                    val ang = i * GOLDEN
                    val sp = 0.5f + 0.5f * frac(i * 0.618f)
                    val sway = sin(t * 7f + i) * size * 0.07f
                    val px = x + cos(ang) * size * sp * ease + sway
                    val py = y + sin(ang) * size * sp * ease - size * 0.45f * t
                    val s = size * (if (big) 0.24f else 0.22f) * (0.6f + 0.5f * frac(i * 0.43f)) * (1f - 0.25f * t)
                    g.save(); g.translate(px, py); g.rotate(i * 51f + t * 220f * (if (i % 2 == 0) 1f else -1f)); g.scale(s * 0.55f, s)
                    g.paint(Rgb.alpha(if (i % 3 == 0) th.accentLight else th.accent, (1f - t * t).coerceIn(0f, 1f))); g.path(leaf)
                    g.restore()
                }
            }
            FxKind.SPARK -> {
                for (i in 0 until count) {
                    val ang = i * GOLDEN
                    val sp = 0.45f + 0.55f * frac(i * 0.618f)
                    val px = x + cos(ang) * size * sp * ease
                    val py = y + sin(ang) * size * sp * ease
                    val pop = sin(PI.toFloat() * Easing.clamp01(t * 1.05f))
                    val s = size * (if (big) 0.26f else 0.24f) * (0.55f + 0.6f * frac(i * 0.29f)) * pop
                    g.save(); g.translate(px, py); g.rotate(t * 160f * (if (i % 2 == 0) 1f else -1f)); g.scale(s, s)
                    g.paint(Rgb.alpha(PASTEL[i % PASTEL.size], (1f - t * t).coerceIn(0f, 1f))); g.path(star)
                    g.restore()
                }
                g.paint(Rgb.alpha(Rgb.WHITE, (fade * 0.5f).coerceIn(0f, 1f))); g.strokeWidth(2f); g.strokeCircle(x, y, size * 0.4f * ease)
            }
            FxKind.SWEEP -> {
                for (i in 0 until 3) {
                    g.paint(Rgb.alpha(th.accentLight, (fade * (0.34f - i * 0.09f)).coerceIn(0f, 1f))); g.circle(x, y, size * (0.35f + 0.3f * i) * (0.4f + ease))
                }
                val len = size * (if (big) 2.4f else 1.6f) * ease
                g.paint(Rgb.alpha(th.accentDeep, (fade * 0.8f).coerceIn(0f, 1f))); g.roundRect(x - len, y - 3f, x + len, y + 3f, 3f)
                g.paint(Rgb.alpha(Rgb.WHITE, (fade).coerceIn(0f, 1f))); g.roundRect(x - len * 0.9f, y - 1.6f, x + len * 0.9f, y + 1.6f, 1.6f)
                if (big) {
                    for (i in 0 until 6) {
                        val ang = i * (PI.toFloat() / 3f) + t * 0.6f
                        val d0 = size * 0.5f * ease
                        val d1 = size * (0.5f + 0.7f * ease)
                        g.paint(Rgb.alpha(Rgb.WHITE, (fade).coerceIn(0f, 1f))); g.strokeWidth(3f)
                        g.line(x + cos(ang) * d0, y + sin(ang) * d0, x + cos(ang) * d1, y + sin(ang) * d1)
                    }
                }
            }
            FxKind.NONE -> {}
        }
        // Kutlamada her stil, merkezden yayılan ince bir şok halkası da alır.
        if (big && kind != FxKind.RING) {
            g.paint(Rgb.alpha(th.accent, (fade * 0.8f).coerceIn(0f, 1f))); g.strokeWidth(2.5f); g.strokeCircle(x, y, size * 0.62f * ease)
        }
        g.restore()
    }
}
