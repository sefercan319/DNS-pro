#!/usr/bin/env python3
"""Filtre listelerini üretir: app/src/main/assets/filter/{basic,medium,strict}.bin ve KAYNAKLAR.txt.
Kaynaklar (lisanslar KAYNAKLAR.txt'te): StevenBlack/hosts (MIT), blocklistproject/Lists (MIT/Unlicense).
Ağ gerekir (raw.githubusercontent.com). Kullanım: python3 tools/build_filter.py [--cache klasör]
Her alan adı 48 bitlik bir özete (Filter.kt'deki `hash` ile birebir aynı) çevrilir; sıralı, tekrarsız, fark + LEB128 kodlanır.
Seviyeler birikimlidir: Basit = basic; Orta = basic + medium; Sıkı = hepsi.
"""
import os, re, struct, sys, urllib.request, datetime

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(ROOT, "app", "src", "main", "assets", "filter")
BLP = "https://raw.githubusercontent.com/blocklistproject/Lists/master/%s.txt"
SB = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"

# katman -> kaynaklar
TIERS = {
    "basic": [("StevenBlack/hosts (birleşik: reklam + zararlı yazılım)", SB, "MIT"),
              ("blocklistproject ads", BLP % "ads", "Unlicense"),
              ("blocklistproject phishing", BLP % "phishing", "MIT"),
              ("blocklistproject ransomware", BLP % "ransomware", "MIT"),
              ("blocklistproject scam", BLP % "scam", "MIT")],
    "medium": [("blocklistproject tracking", BLP % "tracking", "MIT")],
    "strict": [("blocklistproject fraud", BLP % "fraud", "Unlicense"),
               ("blocklistproject abuse", BLP % "abuse", "MIT"),
               ("blocklistproject redirect", BLP % "redirect", "MIT"),
               ("blocklistproject crypto", BLP % "crypto", "Unlicense")],
}
M = (1 << 64) - 1

def h64(name):
    x = 0xcbf29ce484222325
    for b in name.encode("ascii"):
        x ^= b
        x = (x * 0x100000001b3) & M
    x = ((x ^ (x >> 30)) * 0xbf58476d1ce4e5b9) & M
    x = ((x ^ (x >> 27)) * 0x94d049bb133111eb) & M
    x ^= x >> 31
    return x & 0xFFFFFFFFFFFF

LABEL = re.compile(r"^[a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9_])?$")
NOT_DOMAINS = {"localhost", "localhost.localdomain", "local", "broadcasthost", "0.0.0.0", "ip6-localhost", "ip6-loopback",
               "ip6-localnet", "ip6-mcastprefix", "ip6-allnodes", "ip6-allrouters", "ip6-allhosts"}
# alan adı sahibi yerine bölge olan (engellenirse bütün bölge gider) adlar: listeye alınmaz
PUBLIC_SUFFIXES = {"com.tr", "net.tr", "org.tr", "gen.tr", "web.tr", "biz.tr", "info.tr", "co.uk", "org.uk", "ac.uk", "gov.uk",
                   "com.br", "com.au", "co.jp", "co.in", "co.za", "com.cn", "com.mx", "com.ar", "co.id", "co.kr", "com.ru",
                   "github.io", "blogspot.com", "appspot.com", "herokuapp.com", "cloudfront.net", "amazonaws.com", "azurewebsites.net"}

def valid(d):
    if len(d) > 253 or d in NOT_DOMAINS or d in PUBLIC_SUFFIXES: return False
    parts = d.split(".")
    if len(parts) < 2: return False
    if all(p.isdigit() for p in parts): return False           # IP adresi
    return all(LABEL.match(p) for p in parts)

def parse(text):
    out = set()
    for ln in text.splitlines():
        ln = ln.split("#", 1)[0].strip()
        if not ln: continue
        p = ln.split()
        d = (p[1] if len(p) > 1 else p[0]).lower().rstrip(".")
        if valid(d): out.add(d)
    return out

def fetch(url, cache):
    fn = os.path.join(cache, re.sub(r"[^A-Za-z0-9]+", "_", url)) if cache else None
    if fn and os.path.exists(fn): return open(fn, encoding="utf-8", errors="ignore").read()
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "dns-hizli-build"}), timeout=120) as r:
        t = r.read().decode("utf-8", "ignore")
    if fn:
        os.makedirs(cache, exist_ok=True); open(fn, "w", encoding="utf-8").write(t)
    return t

def suffixes(d):
    p = d.split(".")
    return [".".join(p[i:]) for i in range(len(p) - 1)]       # kendisi dahil, en az iki etiket

def varint(n):
    b = bytearray()
    while True:
        c = n & 0x7F; n >>= 7
        if n: b.append(c | 0x80)
        else: b.append(c); return bytes(b)

def write_bin(path, hashes):
    hs = sorted(hashes)
    prev = 0; body = bytearray()
    for x in hs:
        body += varint(x - prev); prev = x
    with open(path, "wb") as fh:
        fh.write(b"DNF1" + struct.pack(">I", len(hs)) + bytes(body))
    return len(hs), 8 + len(body)

def main():
    cache = None
    if "--cache" in sys.argv: cache = sys.argv[sys.argv.index("--cache") + 1]
    prot = set()
    for ln in open(os.path.join(OUT, "protected.txt"), encoding="utf-8"):
        ln = ln.split("#", 1)[0].strip().lower()
        if ln: prot.add(ln)
    def is_protected(d): return any(s in prot for s in suffixes(d))
    sets, info = {}, []
    for tier, srcs in TIERS.items():
        s = set()
        for name, url, lic in srcs:
            got = parse(fetch(url, cache)); s |= got
            info.append((tier, name, lic, len(got)))
        sets[tier] = s
    # korunan adlar hiçbir katmanda olmaz (alt alan adları dahil)
    for t in sets: sets[t] = {d for d in sets[t] if not is_protected(d)}
    # katman içi ve alt katmanlara göre gereksizleri ele: üst alan adı zaten engelliyse alt alan adı gereksiz
    order = ["basic", "medium", "strict"]
    kept = {}
    lower = set()
    for t in order:
        cur = sets[t]
        allv = lower | cur
        res = set()
        for d in cur:
            if any(s in allv for s in suffixes(d)[1:]): continue      # bir üst alan adı zaten var
            if t != "basic" and d in lower: continue
            res.add(d)
        kept[t] = res
        lower |= res
    os.makedirs(OUT, exist_ok=True)
    stats = {}
    seen = {}
    for t in order:
        hs = {h64(d) for d in kept[t]}
        # 48 bit çakışmaları (çok nadir) ve katmanlar arası yinelenenler
        for other in order[:order.index(t)]: hs -= seen.get(other, set())
        seen[t] = hs
        stats[t] = write_bin(os.path.join(OUT, t + ".bin"), hs)
    today = datetime.date.today().isoformat()
    with open(os.path.join(OUT, "KAYNAKLAR.txt"), "w", encoding="utf-8") as fh:
        fh.write(f"Filtre listeleri ({today}), tools/build_filter.py ile üretildi.\n\n")
        for tier, name, lic, n in info: fh.write(f"[{tier}] {name} - lisans: {lic} - {n} alan adı\n")
        fh.write("\n")
        for t in order: fh.write(f"{t}.bin: {stats[t][0]} alan adı, {stats[t][1]} bayt\n")
        fh.write("\nKaynak projeler: StevenBlack/hosts (Steven Black, MIT) ve blocklistproject/Lists (The Block List Project, MIT / Unlicense).\n"
                 "MIT lisansı gereği telif ve izin bildirimi korunur: https://github.com/StevenBlack/hosts/blob/master/license.txt ve "
                 "https://github.com/blocklistproject/Lists/blob/master/LICENSE\n")
    for t in order: print(t, stats[t])

if __name__ == "__main__":
    main()
