#!/usr/bin/env python3
"""Uygulama simgelerini (Aero, Metro, Eco, Y2K, Aurora) tek kaynaktan üretir:
 - Android uyarlanabilir simge dosyaları (vektör XML): app/src/main/res/
 - Önizleme PNG'leri (cairosvg gerekir): <çıktı klasörü>
Aqua simgesi ilk tasarımdır, elle yazılmıştır (ic_launcher_*.xml) ve burada üretilmez.
Kullanım: python3 tools/icons.py [önizleme-klasörü]
"""
import math, os, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "res")

# ----------------------------------------------------------------------------- yardımcılar
def lin(x1, y1, x2, y2, *stops): return {"t": "lin", "x1": x1, "y1": y1, "x2": x2, "y2": y2, "stops": stops}
def rad(cx, cy, r, *stops): return {"t": "rad", "cx": cx, "cy": cy, "r": r, "stops": stops}

def P(d, fill=None, stroke=None, sw=0, cap="butt", join="miter"):
    return {"d": d, "fill": fill, "stroke": stroke, "sw": sw, "cap": cap, "join": join}

def circle(cx, cy, r):
    return f"M{cx - r},{cy}a{r},{r} 0 1,1 {2 * r},0a{r},{r} 0 1,1 {-2 * r},0z"

def ellipse(cx, cy, rx, ry):
    return f"M{cx - rx},{cy}a{rx},{ry} 0 1,1 {2 * rx},0a{rx},{ry} 0 1,1 {-2 * rx},0z"

def star(cx, cy, r, k=0.16):
    """Dört köşeli, içbükey kenarlı parıltı."""
    a = r * k
    return (f"M{cx},{cy - r}Q{cx + a},{cy - a} {cx + r},{cy}Q{cx + a},{cy + a} {cx},{cy + r}"
            f"Q{cx - a},{cy + a} {cx - r},{cy}Q{cx - a},{cy - a} {cx},{cy - r}z")

def f(v):
    return ("%.2f" % v).rstrip("0").rstrip(".")

# ----------------------------------------------------------------------------- tasarımlar (108x108, güvenli bölge 21..87)
def power_glyph(cx, cy, r, w, color, cap):
    a = math.radians(38)
    sx, sy = cx + r * math.sin(a), cy - r * math.cos(a)
    ex = cx - r * math.sin(a)
    return [P(f"M{f(sx)},{f(sy)}A{r},{r} 0 1 1 {f(ex)},{f(sy)}", stroke=color, sw=w, cap=cap),
            P(f"M{cx},{cy - r - 2}V{cy - 2}", stroke=color, sw=w, cap=cap)]

ICONS = {}

# AERO: gökyüzü, güneş, çimen tepeler; ön planda cam damla/küre ve çimen yaprakları
ICONS["aero"] = {
    "bg": [
        P("M0,0h108v108h-108z", lin(54, 0, 54, 108, (0, "#FF5EB8F2"), (0.55, "#FFB8E6FF"), (1, "#FFEAF9FF"))),
        P(circle(84, 24, 34), rad(84, 24, 34, (0, "#F2FFF6C4"), (0.35, "#80FFF0A0"), (1, "#00FFF0A0"))),
        P("M0,74Q26,58 54,70T108,62V108H0z", lin(54, 58, 54, 108, (0, "#FF8FD65E"), (1, "#FF3E9F3A"))),
        P("M0,88Q30,76 62,86T108,80V108H0z", lin(54, 76, 54, 108, (0, "#FF5DBE45"), (1, "#FF2C7E30"))),
        P("M25,90Q24,83 21,79M29,90Q29,82 31,77M33,90Q35,84 38,81", stroke="#FF2F8A2F", sw=2, cap="round"),
        P("M76,90Q76,83 74,78M80,90Q81,82 84,78M85,90Q88,85 91,84", stroke="#FF3FA03A", sw=2, cap="round"),
    ],
    "fg": [
        P(ellipse(54, 83, 21, 3.4), rad(54, 83, 21, (0, "#66083E20"), (1, "#00083E20"))),
        P(circle(54, 52, 25), rad(44, 40, 46, (0, "#FFE9FCFF"), (0.35, "#FF62D4F2"), (0.7, "#FF1E96D8"), (1, "#FF0F5FA8"))),
        P(ellipse(54, 41, 17, 10), lin(54, 31, 54, 51, (0, "#E6FFFFFF"), (1, "#00FFFFFF"))),
        P(ellipse(54, 68, 13, 5), rad(54, 68, 13, (0, "#59FFFFFF"), (1, "#00FFFFFF"))),
        P(circle(54, 52, 24.4), stroke="#80FFFFFF", sw=1.1),
    ],
    "mono": [
        P(circle(54, 52, 24), stroke="#FF000000", sw=3),
        P("M32,52Q54,57 76,52M54,28V76", stroke="#FF000000", sw=2.2, cap="round"),
        P("M30,82Q54,72 78,82", stroke="#FF000000", sw=3, cap="round"),
    ],
}

def flower(cx, cy, r, rot=0.0):
    """Beş yapraklı düz çiçek: her yaprak döndürülmüş bir elips (yay komutuyla)."""
    out = []
    for i in range(5):
        th = math.radians(rot + i * 72 - 90)
        ux, uy = math.cos(th), math.sin(th)
        mx, my = cx + ux * 0.56 * r, cy + uy * 0.56 * r
        ex, ey = ux * 0.44 * r, uy * 0.44 * r
        rr = f"{f(0.44 * r)},{f(0.27 * r)} {f(math.degrees(th))}"
        out.append(f"M{f(mx - ex)},{f(my - ey)}A{rr} 1,1 {f(mx + ex)},{f(my + ey)}A{rr} 1,1 {f(mx - ex)},{f(my - ey)}z")
    return "".join(out)

def wedges(cx, cy, n=9, half=5.0, length=140):
    """Güneş ışını kamaları (cx,cy merkezli, birbirinden eşit aralıklı)."""
    out = []
    for i in range(n):
        base = math.radians(i * 360 / n)
        p1 = (cx + length * math.sin(base - math.radians(half)), cy - length * math.cos(base - math.radians(half)))
        p2 = (cx + length * math.sin(base + math.radians(half)), cy - length * math.cos(base + math.radians(half)))
        out.append(f"M{cx},{cy}L{f(p1[0])},{f(p1[1])}L{f(p2[0])},{f(p2[1])}z")
    return "".join(out)

def skyline():
    """Pencereli gökdelen silueti (alt kenar y=100)."""
    d = ""
    for x, w, h in ((14, 12, 20), (27, 10, 30), (38, 12, 24), (51, 9, 38), (61, 12, 26), (74, 10, 32), (85, 12, 18)):
        d += f"M{x},100V{100 - h}H{x + w}V100z"
    return d

# METRO (Frutiger Metro): şehir ve müzik; lime-turkuaz zemin, güneş ışınları, gökdelen silueti, halkalar, yıldız, beyaz güç simgesi
ICONS["metro"] = {
    "bg": [
        P("M0,0h108v108h-108z", lin(54, 0, 54, 108, (0, "#FFC4EE4E"), (0.55, "#FF27D1C2"), (1, "#FF1F8BFF"))),
        P(wedges(54, 70), "#2EFFFFFF"),
        P(circle(90, 24, 13), "#FF081A2B"), P(circle(90, 24, 9.5), "#FFFFFFFF"), P(circle(90, 24, 6), "#FF081A2B"), P(circle(90, 24, 2.6), "#FFFF4FA3"),
        P(star(22, 30, 7, 0.4), "#FFFFFFFF", "#FF081A2B", 1.2, join="round"),
        P(skyline(), "#B3081A2B"),
        P("M0,92C28,80 56,104 108,86", stroke="#FFFF4FA3", sw=4, cap="round"),
    ],
    "fg": power_glyph(54, 50, 17, 6.4, "#FFFFFFFF", "round"),
    "mono": power_glyph(54, 56, 17, 6.4, "#FF000000", "round"),
}

# ECO: koyu yeşil zemin, yumuşak ışık, damarlı yaprak
LEAF = "M35,77C27,52 46,30 79,30C82,61 62,81 35,77z"
def leaf_veins():
    """Orta damar (ikinci derece Bezier) ve ona açılı yan damarlar."""
    p0, p1, p2 = (33, 79), (56, 58), (78, 32)
    segs = []
    for t, ln in ((0.30, 10), (0.50, 10), (0.70, 8)):
        x = (1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0]
        y = (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]
        dx = 2 * (1 - t) * (p1[0] - p0[0]) + 2 * t * (p2[0] - p1[0])
        dy = 2 * (1 - t) * (p1[1] - p0[1]) + 2 * t * (p2[1] - p1[1])
        n = math.hypot(dx, dy); dx, dy = dx / n, dy / n
        for sg in (1, -1):
            a = math.radians(48 * sg)
            vx, vy = dx * math.cos(a) - dy * math.sin(a), dx * math.sin(a) + dy * math.cos(a)
            segs.append(f"M{f(x)},{f(y)}L{f(x + vx * ln)},{f(y + vy * ln)}")
    return "".join(segs)

# kıtalar (Dünya) için birim şekiller: küre merkezi (54,56), yarıçap 27
LAND_A = "M38,48C40,41 49,40 53,44C58,41 64,44 63,50C69,52 67,59 61,60C60,66 54,69 51,63C46,64 42,60 43,56C37,56 36,51 38,48z"
LAND_B = "M62,70C66,68 70,70 69,74C67,77 63,76 62,73z"

ICONS["eco"] = {
    "bg": [
        P("M0,0h108v108h-108z", lin(54, 0, 54, 108, (0, "#FF4DB05A"), (1, "#FF135A3A"))),
        P(circle(36, 30, 52), rad(36, 30, 52, (0, "#66E6FFA8"), (1, "#00E6FFA8"))),
    ],
    "fg": [
        P(ellipse(54, 90, 22, 3.2), rad(54, 90, 22, (0, "#59062E1A"), (1, "#00062E1A"))),
        P(circle(54, 56, 28), rad(44, 42, 50, (0, "#FFBDEBFF"), (0.35, "#FF3AB0EC"), (0.75, "#FF1670B8"), (1, "#FF0B4A8A"))),
        P(LAND_A, lin(40, 40, 66, 68, (0, "#FFB9F27A"), (1, "#FF3FAE56"))),
        P(LAND_B, "#FF4FBB5C"),
        P(ellipse(54, 44, 19, 11), lin(54, 33, 54, 55, (0, "#D9FFFFFF"), (1, "#00FFFFFF"))),
        P(circle(54, 56, 27.4), stroke="#99FFFFFF", sw=1.2),
        P("M70,34C74,26 82,22 90,24C90,33 83,39 74,38z", lin(70, 38, 90, 24, (0, "#FF8EDB6C"), (1, "#FFE3FFA8"))),
        P("M72,37Q80,31 89,25", stroke="#FF1F7A40", sw=1.4, cap="round"),
    ],
    "mono": [
        P(circle(54, 56, 27), stroke="#FF000000", sw=3),
        P(LAND_A, "#FF000000"),
        P("M70,34C74,26 82,22 90,24C90,33 83,39 74,38z", "#FF000000"),
    ],
}

def rot_ellipse(cx, cy, rx, ry, deg):
    """Döndürülmüş elips: dört kübik Bezier parçası."""
    k = 0.5522847498
    t = math.radians(deg)
    c, sn = math.cos(t), math.sin(t)
    def pt(x, y): return (cx + x * c - y * sn, cy + x * sn + y * c)
    pts = [(rx, 0), (rx, k * ry), (k * rx, ry), (0, ry), (-k * rx, ry), (-rx, k * ry), (-rx, 0),
           (-rx, -k * ry), (-k * rx, -ry), (0, -ry), (k * rx, -ry), (rx, -k * ry), (rx, 0)]
    q = [pt(*p) for p in pts]
    d = f"M{f(q[0][0])},{f(q[0][1])}"
    for i in range(4):
        a, b, e = q[1 + 3 * i], q[2 + 3 * i], q[3 + 3 * i]
        d += f"C{f(a[0])},{f(a[1])} {f(b[0])},{f(b[1])} {f(e[0])},{f(e[1])}"
    return d + "z"

def grid_lines(step=18):
    return "".join(f"M{x},0V108M0,{x}H108" for x in range(step, 108, step))

def heart(cx, cy, r):
    return (f"M{f(cx)},{f(cy + 0.92 * r)}C{f(cx - 1.35 * r)},{f(cy - 0.05 * r)} {f(cx - 1.05 * r)},{f(cy - 1.05 * r)} {f(cx)},{f(cy - 0.38 * r)}"
            f"C{f(cx + 1.05 * r)},{f(cy - 1.05 * r)} {f(cx + 1.35 * r)},{f(cy - 0.05 * r)} {f(cx)},{f(cy + 0.92 * r)}z")

# Y2K: holografik pembe-mor-camgöbeği zemin, parlak krom kalp, baloncuklar ve dört köşeli parıltılar
ICONS["y2k"] = {
    "bg": [
        P("M0,0h108v108h-108z", lin(0, 0, 108, 108, (0, "#FFFFB4E6"), (0.5, "#FFC9B0FF"), (1, "#FF9CE6FF"))),
        P("M0,0h108v108h-108z", lin(108, 0, 0, 108, (0, "#66A6FFE0"), (0.5, "#33FFFFFF"), (1, "#66FF6FC8"))),
        P(circle(24, 26, 9), rad(20, 22, 12, (0, "#CCFFFFFF"), (0.6, "#4D9CE6FF"), (1, "#66FF6FC8")), "#B3FFFFFF", 0.8),
        P(circle(88, 78, 11), rad(84, 74, 14, (0, "#CCFFFFFF"), (0.6, "#4D9CE6FF"), (1, "#66FF6FC8")), "#B3FFFFFF", 0.8),
        P(star(86, 28, 8, 0.16), "#FFFFFFFF"), P(star(20, 76, 6, 0.16), "#FFFFFFFF"),
    ],
    "fg": [
        P(heart(54, 52, 30), lin(26, 24, 84, 84, (0, "#FFFFFFFF"), (0.35, "#FFFF6FC8"), (0.7, "#FFB28CFF"), (1, "#FFFFFFFF")), "#FFFFFFFF", 2, join="round"),
        P(rot_ellipse(42, 38, 9, 5, -35), "#E6FFFFFF"),
        P(star(70, 36, 7, 0.16), "#FFFFFFFF"),
    ],
    "mono": [
        P(heart(54, 54, 30), "#FF000000"),
        P(star(82, 26, 8, 0.16), "#FF000000"),
    ],
}

# AURORA: turkuaz-yeşil-sarı ışık geçişi, parlak ışık hüzmesi ve tel kafes dalgalar; ortada cam küre ve güç simgesi
def aurora_mesh():
    d = ""
    for k in range(9):
        t = k / 8
        a = (-5 + 30 * t, -5, 30 + 20 * t, 40 + 10 * t, 70 + 10 * t, 55 + 20 * t, 115, 40 + 30 * t)
        d += f"M{f(a[0])},{f(a[1])}C{f(a[2])},{f(a[3])} {f(a[4])},{f(a[5])} {f(a[6])},{f(a[7])}"
    return d

ICONS["aurora"] = {
    "bg": [
        P("M0,0h108v108h-108z", lin(54, 0, 54, 108, (0, "#FF0E9FA6"), (0.55, "#FF28C08A"), (1, "#FFE4EE62"))),
        P(circle(20, 100, 60), rad(20, 100, 60, (0, "#CCE4EE62"), (1, "#00E4EE62"))),
        P(circle(100, 84, 50), rad(100, 84, 50, (0, "#B31FB4E6"), (1, "#001FB4E6"))),
        P(aurora_mesh(), stroke="#80FFFFFF", sw=0.9),
        P("M-5,84C28,74 58,96 113,76", stroke="#33FFFFFF", sw=14),
        P("M-5,84C28,74 58,96 113,76", stroke="#99FFFFFF", sw=4.5),
        P("M-5,84C28,74 58,96 113,76", stroke="#FFFFFFFF", sw=1.4),
    ],
    "fg": [
        P(circle(54, 50, 26), rad(44, 38, 46, (0, "#F2FFFFFF"), (0.4, "#80BDF4EE"), (1, "#590E9FA6")), "#B3FFFFFF", 1.2),
        P(ellipse(54, 39, 17, 10), lin(54, 29, 54, 49, (0, "#D9FFFFFF"), (1, "#00FFFFFF"))),
    ] + power_glyph(54, 52, 13, 5, "#FF0B6E78", "round"),
    "mono": power_glyph(54, 56, 17, 6.4, "#FF000000", "round"),
}

# AQUA: ilk tasarım. Android dosyaları elle yazılmıştır (ic_launcher_*.xml); burada yalnızca önizleme için aynısı çizilir.
AQUA_PREVIEW = {
    "bg": [
        P("M0,0h108v108h-108z", lin(54, 0, 54, 108, (0, "#FFBDEEFF"), (0.5, "#FF55C4F1"), (1, "#FF1C7FD2"))),
        P("M0,40h108v68h-108z", rad(54, 108, 64, (0, "#59FFFFFF"), (1, "#00FFFFFF"))),
        P(circle(28, 34, 5.5), "#26FFFFFF", "#66FFFFFF", 0.8), P(circle(84, 74, 6), "#1FFFFFFF", "#59FFFFFF", 0.8),
    ],
    "fg": [
        P(ellipse(54, 84, 22, 3.6), rad(54, 84, 22, (0, "#66083E66"), (1, "#00083E66"))),
        P(circle(54, 52, 29), rad(44, 38, 48, (0, "#FFC9FFF6"), (0.34, "#FF4FE3D5"), (0.68, "#FF14A9C9"), (1, "#FF0A6E96"))),
        P(f"{ellipse(54, 52, 13, 29)}M54,23V81M29.2,37Q54,42 78.8,37M25,52Q54,57 83,52M29.2,67Q54,72 78.8,67", stroke="#61FFFFFF", sw=1.3, cap="round", join="round"),
        P(ellipse(54, 70, 18, 8), rad(54, 70, 18, (0, "#66FFFFFF"), (1, "#00FFFFFF"))),
        P(ellipse(54, 38, 22, 14), lin(54, 24, 54, 52, (0, "#D9FFFFFF"), (1, "#00FFFFFF"))),
        P(circle(54, 52, 28.4), stroke="#8CFFFFFF", sw=1.2),
    ],
}

# ----------------------------------------------------------------------------- Android XML
def argb(c):
    return c.upper()

def xml_fill(p, ind):
    out = []
    pad = " " * ind
    attrs = [f'android:pathData="{p["d"]}"']
    fl = p["fill"]
    if isinstance(fl, str): attrs.append(f'android:fillColor="{argb(fl)}"')
    if p["stroke"]:
        attrs.append(f'android:strokeColor="{argb(p["stroke"])}"')
        attrs.append(f'android:strokeWidth="{f(p["sw"])}"')
        if p["cap"] != "butt": attrs.append(f'android:strokeLineCap="{p["cap"]}"')
        if p["join"] != "miter": attrs.append(f'android:strokeLineJoin="{p["join"]}"')
    if isinstance(fl, dict):
        out.append(f"{pad}<path " + " ".join(attrs) + ">")
        out.append(f'{pad}    <aapt:attr name="android:fillColor">')
        if fl["t"] == "lin":
            out.append(f'{pad}        <gradient android:type="linear" android:startX="{f(fl["x1"])}" android:startY="{f(fl["y1"])}" android:endX="{f(fl["x2"])}" android:endY="{f(fl["y2"])}">')
        else:
            out.append(f'{pad}        <gradient android:type="radial" android:centerX="{f(fl["cx"])}" android:centerY="{f(fl["cy"])}" android:gradientRadius="{f(fl["r"])}">')
        for off, col in fl["stops"]:
            out.append(f'{pad}            <item android:offset="{f(off)}" android:color="{argb(col)}" />')
        out.append(f"{pad}        </gradient>")
        out.append(f"{pad}    </aapt:attr>")
        out.append(f"{pad}</path>")
    else:
        out.append(f"{pad}<path " + " ".join(attrs) + " />")
    return out

def vector(paths, comment):
    out = ['<?xml version="1.0" encoding="utf-8"?>',
           f"<!-- {comment} (tools/icons.py ile üretilir; elle değiştirme) -->",
           '<vector xmlns:android="http://schemas.android.com/apk/res/android"',
           '    xmlns:aapt="http://schemas.android.com/aapt"',
           '    android:width="108dp"', '    android:height="108dp"',
           '    android:viewportWidth="108"', '    android:viewportHeight="108">']
    for p in paths: out += xml_fill(p, 4)
    out.append("</vector>")
    return "\n".join(out) + "\n"

ADAPTIVE = """<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_bg_{n}" />
    <foreground android:drawable="@drawable/ic_launcher_fg_{n}" />
    <monochrome android:drawable="@drawable/ic_launcher_mono_{n}" />
</adaptive-icon>
"""

def write_android():
    os.makedirs(os.path.join(ROOT, "drawable"), exist_ok=True)
    os.makedirs(os.path.join(ROOT, "mipmap-anydpi-v26"), exist_ok=True)
    for n, ic in ICONS.items():
        for part, label in (("bg", "zemin"), ("fg", "ön plan"), ("mono", "temalı tek renk")):
            with open(os.path.join(ROOT, "drawable", f"ic_launcher_{part}_{n}.xml"), "w", encoding="utf-8") as fh:
                fh.write(vector(ic[part], f"Simge '{n}': {label}"))
        with open(os.path.join(ROOT, "mipmap-anydpi-v26", f"ic_launcher_{n}.xml"), "w", encoding="utf-8") as fh:
            fh.write(ADAPTIVE.format(n=n))

# ----------------------------------------------------------------------------- SVG önizleme
def rgba(c):
    c = c.lstrip("#")
    a = int(c[0:2], 16) / 255.0
    return "#" + c[2:], a

def svg_defs_and_body(paths, uid):
    defs, body = [], []
    for i, p in enumerate(paths):
        fl = p["fill"]
        fill_attr = 'fill="none"'
        if isinstance(fl, str):
            col, a = rgba(fl)
            fill_attr = f'fill="{col}" fill-opacity="{a:.3f}"'
        elif isinstance(fl, dict):
            gid = f"{uid}g{i}"
            if fl["t"] == "lin":
                defs.append(f'<linearGradient id="{gid}" gradientUnits="userSpaceOnUse" x1="{fl["x1"]}" y1="{fl["y1"]}" x2="{fl["x2"]}" y2="{fl["y2"]}">')
            else:
                defs.append(f'<radialGradient id="{gid}" gradientUnits="userSpaceOnUse" cx="{fl["cx"]}" cy="{fl["cy"]}" r="{fl["r"]}">')
            for off, col in fl["stops"]:
                c, a = rgba(col)
                defs.append(f'<stop offset="{off}" stop-color="{c}" stop-opacity="{a:.3f}"/>')
            defs.append("</linearGradient>" if fl["t"] == "lin" else "</radialGradient>")
            fill_attr = f'fill="url(#{gid})"'
        st = ""
        if p["stroke"]:
            c, a = rgba(p["stroke"])
            st = f' stroke="{c}" stroke-opacity="{a:.3f}" stroke-width="{p["sw"]}" stroke-linecap="{p["cap"]}" stroke-linejoin="{p["join"]}"'
        body.append(f'<path d="{p["d"]}" {fill_attr}{st}/>')
    return "".join(defs), "".join(body)

def svg_icon(n, ic, size=216):
    d1, b1 = svg_defs_and_body(ic["bg"], n + "b")
    d2, b2 = svg_defs_and_body(ic["fg"], n + "f")
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 108 108">'
            f'<defs>{d1}{d2}<clipPath id="m{n}"><rect x="9" y="9" width="90" height="90" rx="26"/></clipPath></defs>'
            f'<g clip-path="url(#m{n})">{b1}{b2}</g></svg>')

def write_previews(out, aqua_svg=None):
    import cairosvg
    os.makedirs(out, exist_ok=True)
    for n, ic in {"aqua": AQUA_PREVIEW, **ICONS}.items():
        cairosvg.svg2png(bytestring=svg_icon(n, ic).encode(), write_to=os.path.join(out, f"simge-{n}.png"))

if __name__ == "__main__":
    write_android()
    if len(sys.argv) > 1: write_previews(sys.argv[1])
    print("tamam")
