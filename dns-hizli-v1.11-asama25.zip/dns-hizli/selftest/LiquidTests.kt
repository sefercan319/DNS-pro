package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

/** Sıvı rengi: 50 renkli palet, ayar, her şekil ve stilde çizim, seçim sayfası, her dilde metinler. */
fun runLiquidColorTests() {
    T.group("Sıvı rengi: palet ve ayar")
    run {
        val p = LiquidColors.PALETTE
        T.check("tam 50 renk, hepsi farklı ve geçerli", p.size == 50 && LiquidColors.COUNT == 50 && p.toSet().size == 50 && p.all { it in 0..0xFFFFFF })
        T.check("her renk için kimlik gidiş-dönüş", p.all { LiquidColors.clean(LiquidColors.id(it)) == LiquidColors.id(it) && LiquidColors.indexOf(LiquidColors.id(it)) == p.indexOf(it) })
        T.check("boş ve bozuk girdiler temanın rengi sayılır", listOf("", null, "zzzzzz", "12345", "1234567", "123456", "#FF3B30").all { LiquidColors.clean(it) == "" && LiquidColors.argb(it) == 0 && LiquidColors.indexOf(it) == -1 })
        T.check("küçük harf kabul edilir, büyütülür", LiquidColors.clean("ff3b30") == "FF3B30")
        T.check("argb opak", LiquidColors.argb("FF3B30") == 0xFFFF3B30.toInt())
        val st = AppSettings(liquidColor = "2979FF")
        T.check("ayar kodlayıcı gidiş-dönüş", SettingsCodec.decode(SettingsCodec.encode(st)).liquidColor == "2979FF")
        T.check("varsayılan boş", AppSettings().liquidColor == "" && SettingsCodec.decode(emptyMap()).liquidColor == "")
        T.check("palet dışı değer temizlenir", SettingsCodec.decode(mapOf("liquidColor" to "123456")).liquidColor == "")
        T.check("dışa/içe aktarılır", SettingsCodec.import(SettingsCodec.export(st), AppSettings())?.liquidColor == "2979FF")
        val rig = Rig()
        rig.model.setLiquidColor("FF3B30")
        T.check("model rengi saklar", rig.model.settings.liquidColor == "FF3B30" && rig.model.liquidColorArgb == 0xFFFF3B30.toInt())
        rig.model.setLiquidColor("nope")
        T.check("geçersiz renk temaya döner", rig.model.settings.liquidColor == "" && rig.model.liquidColorArgb == 0)
    }

    T.group("Sıvı rengi: çizim")
    val r = 60f
    fun render(style: UiStyle, shape: OrbShape, color: Int, tint: Float = 0f): java.awt.image.BufferedImage {
        val c = AwtCanvas(200, 200, 1f)
        val art = ArtFactory.create(style, Themes.aqua, 0.55f)
        art.orbShape = shape
        art.liquidColor = color
        art.liquidTint = 0xFFFF9800.toInt(); art.liquidTintAmt = tint
        art.orb(c.gfx, 100f, 100f, r, 0.66f, 0.7f, 0f, 0f, 0f)
        c.dispose()
        return c.image
    }
    fun px(im: java.awt.image.BufferedImage, dx: Float, dy: Float) = im.getRGB((100 + dx * r).toInt(), (100 + dy * r).toInt())
    val red = 0xFFFF3B30.toInt()
    val blue = 0xFF2979FF.toInt()
    run {
        var bad = ArrayList<String>()
        for (st in UiStyle.values()) for (sh in OrbShape.values()) {
            // sıvının kesin dolu olduğu nokta: şeklin alt yarısında, merkezin biraz altı (simgeden uzak, yanda)
            val dx = if (sh == OrbShape.INV_TRIANGLE || sh == OrbShape.STAR || sh == OrbShape.TRIANGLE) 0.0f else -0.45f
            val dy = when (sh) { OrbShape.INV_TRIANGLE -> -0.05f; OrbShape.STAR -> 0.45f; OrbShape.RECTANGLE -> 0.35f; else -> 0.45f }
            val a = px(render(st, sh, red), dx, dy)
            val b = px(render(st, sh, blue), dx, dy)
            val ar = (a shr 16) and 0xFF; val ab = a and 0xFF
            val br = (b shr 16) and 0xFF; val bb = b and 0xFF
            if (!(ar > ab + 40 && bb > br + 40)) bad.add("${st.label}/${sh.id}: kırmızı=${Integer.toHexString(a)} mavi=${Integer.toHexString(b)}")
        }
        T.check("her stil ve şekilde sıvı seçilen renkte (kırmızı/mavi)", bad.isEmpty(), bad.take(3).toString())
    }
    run {
        // Seçili renk varken hız tonu uygulanmaz; renk yoksa uygulanır.
        val withColor = render(UiStyle.AQUA, OrbShape.CIRCLE, red, 0f)
        val withTint = render(UiStyle.AQUA, OrbShape.CIRCLE, red, 0.45f)
        var same = true
        for (y in 0 until 200 step 3) for (x in 0 until 200 step 3) if (withColor.getRGB(x, y) != withTint.getRGB(x, y)) same = false
        T.check("renk seçiliyken hız tonu etkisiz", same)
        val d0 = render(UiStyle.AQUA, OrbShape.CIRCLE, 0, 0f); val d1 = render(UiStyle.AQUA, OrbShape.CIRCLE, 0, 0.45f)
        T.check("renk yokken hız tonu çalışmaya devam eder", px(d0, 0.1f, 0.5f) != px(d1, 0.1f, 0.5f))
        T.check("renk yokken temanın kendi rengi (kırmızı değil)", ((px(d0, 0.1f, 0.5f) shr 16) and 0xFF) < (px(d0, 0.1f, 0.5f) and 0xFF))
    }
    run {
        // Dalga her renkte vardır: iki farklı evrede yüzey çizgisi değişir ve sıvı hâlâ hız ayarıyla (OrbMath) hızlanıp yavaşlar.
        fun at(color: Int, phase: Float): java.awt.image.BufferedImage {
            val c = AwtCanvas(200, 200, 1f)
            val art = ArtFactory.create(UiStyle.AQUA, Themes.aqua, 0.55f); art.liquidColor = color
            art.orb(c.gfx, 100f, 100f, r, 0.5f, phase, 0f, 0f, 0f); c.dispose(); return c.image
        }
        val flat = LiquidColors.PALETTE.filter { rgb ->
            val a = at((0xFF shl 24) or rgb, 0.3f); val b = at((0xFF shl 24) or rgb, 2.3f)
            var n = 0
            for (y in 60 until 140) for (x in 50 until 150) if (a.getRGB(x, y) != b.getRGB(x, y)) n++
            n < 40
        }
        T.check("50 rengin hepsinde dalga hareket eder", flat.isEmpty(), flat.map { LiquidColors.id(it) }.toString())
        T.check("dalga hızı renkten bağımsız, sunucu hızına bağlı", OrbMath.waveSpeed(15) > OrbMath.waveSpeed(300))
    }
    run {
        // Hata durumunda sıvı yine hata rengindedir.
        val c = AwtCanvas(200, 200, 1f)
        val art = ArtFactory.create(UiStyle.AQUA, Themes.aqua, 0.55f); art.liquidColor = blue
        art.orb(c.gfx, 100f, 100f, r, 0.66f, 0.7f, 0f, 1f, 0f); c.dispose()
        val a = px(c.image, -0.45f, 0.45f)
        T.check("hatada seçilen renk değil, hata rengi görünür", ((a shr 16) and 0xFF) > (a and 0xFF), Integer.toHexString(a))
    }

    T.group("Sıvı rengi: seçim sayfası")
    run {
        val rig = Rig()
        T.check("ilk durumda temanın rengi", rig.model.settings.liquidColor == "" && rig.scene.env.art.liquidColor == 0)
        rig.scene.openPersonalize(); rig.settle(900)
        T.check("kişiselleştirmede 'Sıvı rengi' satırı ve 'Temaya göre' değeri", rig.find(Strings.LIQUID_COLOR, exact = true) != null || runCatching { rig.need(Strings.LIQUID_COLOR, exact = true) }.isSuccess)
        rig.tapText(Strings.LIQUID_COLOR, exact = true, settleMs = 1200)
        T.check("sayfada 'Temaya göre' ve renk örnekleri var", rig.find(Strings.LIQUID_THEME, exact = true) != null && rig.find(Strings.liquidColorN(1), exact = true) != null)
        val g = CountingGfx(); rig.scene.draw(g)
        T.check("sayfa çizimi geçerli", g.bad == 0 && g.depth == 0)
        val missing = (1..50).filter { runCatching { rig.need(Strings.liquidColorN(it), exact = true) }.isFailure }
        T.check("50 renk örneğinin hepsine ulaşılır", missing.isEmpty(), missing.toString())
        rig.tapText(Strings.liquidColorN(5), exact = true, settleMs = 700)
        T.check("5. renk seçilir", rig.model.settings.liquidColor == LiquidColors.id(LiquidColors.PALETTE[4]), rig.model.settings.liquidColor)
        rig.settle(600)
        T.check("sahne sıvı rengini kullanır", rig.scene.env.art.liquidColor == LiquidColors.argb(rig.model.settings.liquidColor))
        rig.tapText(Strings.liquidColorN(50), exact = true, settleMs = 700)
        T.check("50. renk seçilir", rig.model.settings.liquidColor == LiquidColors.id(LiquidColors.PALETTE[49]), rig.model.settings.liquidColor)
        T.check("seçili renk erişilebilirlikte işaretli", rig.find(Strings.liquidColorN(50), exact = true)?.info?.checked == true && rig.find(Strings.liquidColorN(5), exact = true)?.info?.checked != true)
        rig.tapText(Strings.LIQUID_THEME, exact = true, settleMs = 700)
        T.check("'Temaya göre' rengi sıfırlar", rig.model.settings.liquidColor == "")
        val g2 = CountingGfx(); rig.scene.draw(g2)
        T.check("seçimden sonra çizim geçerli", g2.bad == 0 && g2.depth == 0)
    }
    run {
        // Bağlıyken ve kesikken, her şekil ve seçili renkle ana ekran geçerli çizilir.
        for (sh in OrbShape.values()) {
            val rig = Rig(Rig.base().copy(orbShapes = if (sh == OrbShape.CIRCLE) "" else "aqua=${sh.id}", liquidColor = "00C853"))
            val off = CountingGfx().also { rig.scene.draw(it) }
            rig.connectOk()
            val on = CountingGfx().also { rig.scene.draw(it) }
            T.check("${sh.id}: renkli sıvıyla kapalı ve bağlı çizim geçerli", off.bad == 0 && off.depth == 0 && on.bad == 0 && on.depth == 0 && rig.scene.env.art.liquidColor == 0xFF00C853.toInt())
        }
    }

    T.group("Sıvı rengi: her dilde metinler")
    val saved = L.lang
    try {
        val en = Lang.values().first { it.name == "EN" }
        for (lang in Lang.values()) {
            L.set(lang)
            T.check("${lang.native}: başlık, 'Temaya göre', renk sözcüğü ve not dolu",
                Strings.LIQUID_COLOR.isNotBlank() && Strings.LIQUID_THEME.isNotBlank() && Strings.COLOR_WORD.isNotBlank() && Strings.LIQUID_NOTE.length > 20 &&
                    Strings.LIQUID_COLOR != Strings.LIQUID_THEME && Strings.liquidColorN(7).endsWith(" 7"))
        }
        L.set(Lang.values().first { it.name == "TR" })
        T.check("Türkçe metinler", Strings.LIQUID_COLOR == "Sıvı rengi" && Strings.LIQUID_THEME == "Temaya göre" && Strings.liquidColorN(12) == "Renk 12")
        // Çevirisi olmayan dil kalmasın: İngilizce dışındaki her dil kendi metnini verir.
        val enTitle = run { L.set(en); Strings.LIQUID_COLOR }
        val untranslated = Lang.values().filter { it != en && run { L.set(it); Strings.LIQUID_COLOR == enTitle } }.map { it.native }
        T.check("İngilizce dışındaki her dil sıvı rengi başlığını çevirmiş", untranslated.isEmpty(), untranslated.toString())
    } finally { L.set(saved) }
}
