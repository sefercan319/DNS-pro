package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

/**
 * Aşama 22: sorgu gecikme halkası, kendi liste (hosts içe/dışa aktarma), "kapalı kalırsa dur" yönlendiricisi, yeni ayarlar,
 * bildirim metinleri ve ilgili arayüz.
 */
fun runStage22Tests() {
    println("\nAşama 22: liste içe aktarma, gecikme grafiği, kapalı kal, bildirimler\n")
    testLatencyRing()
    testHostsParse()
    testHostsMergeExport()
    testImportedEngine()
    testSinkhole()
    testStage22Settings()
    testStage22Model()
    testStage22Ui()
    testStage22Strings()
}

// ---------------------------------------------------------------- gecikme halkası

private fun testLatencyRing() {
    T.group("Gecikme halkası")
    val r = LatencyRing(4)
    val out = IntArray(10)
    T.check("boşken 0 örnek", r.copyTo(out) == 0 && r.size() == 0)
    r.add(10); r.add(20); r.add(30)
    T.check("eskiden yeniye sıralı", r.copyTo(out) == 3 && out[0] == 10 && out[1] == 20 && out[2] == 30)
    r.add(40); r.add(50); r.add(60)
    T.check("dolunca en eskiler düşer (4 örnek)", r.copyTo(out) == 4 && out.take(4) == listOf(30, 40, 50, 60))
    val small = IntArray(2)
    T.check("küçük diziye en yeniler yazılır", r.copyTo(small) == 2 && small[0] == 50 && small[1] == 60)
    r.clear()
    r.add(LatencyRing.TIMEOUT); r.add(-7); r.add(10_000_000)
    T.check("zaman aşımı -1 kalır, diğer eksiler 0, uç değer sınırlanır",
        r.copyTo(out) == 3 && out[0] == LatencyRing.TIMEOUT && out[1] == 0 && out[2] == LatencyRing.MAX_MS)
    val big = LatencyRing()
    val ts = (1..4).map { k -> Thread { for (i in 1..5000) big.add((i + k) % 300) } }
    ts.forEach { it.start() }; ts.forEach { it.join() }
    val all = IntArray(LatencyRing.CAPACITY)
    T.check("eşzamanlı yazma: boyut kapasitede, değerler geçerli", big.size() == LatencyRing.CAPACITY && big.copyTo(all) == LatencyRing.CAPACITY && all.all { it in 0..299 })

    val s = LatencySummary.of(intArrayOf(10, 30, -1, 20, -1), 5)
    T.check("özet: ortalama zaman aşımsız, en büyük, son", s.answered == 3 && s.timeouts == 2 && s.avgMs == 20 && s.maxMs == 30 && s.lastMs == -1)
    val e = LatencySummary.of(IntArray(3), 0)
    T.check("boş özet sıfır", e.answered == 0 && e.timeouts == 0 && e.avgMs == 0 && e.maxMs == 0)
    T.check("yalnızca zaman aşımı: ortalama 0", LatencySummary.of(intArrayOf(-1, -1), 2).let { it.answered == 0 && it.timeouts == 2 && it.avgMs == 0 })

    // sarmalayıcı yönlendirici örnekleri iletir
    val inner = object : Forwarder {
        override val proto: Proto get() = Proto.PLAIN
        override fun start() {}
        override fun onPacket(p: ByteArray, len: Int) {}
        override fun stats() = Stats()
        override fun resetNetwork(reason: String) {}
        override fun clearCache() {}
        override fun close() {}
        override fun latencies(out: IntArray): Int { out[0] = 42; return 1 }
    }
    val wrapped = FilteringForwarder(inner) { _, _, _ -> }
    val o = IntArray(4)
    T.check("engelleme sarmalayıcısı gecikme örneklerini içteki yönlendiriciden verir", wrapped.latencies(o) == 1 && o[0] == 42)
}

// ---------------------------------------------------------------- hosts ayrıştırma

private fun testHostsParse() {
    T.group("Kendi liste: ayrıştırma")
    val hosts = """
        # Başlık yorumu
        127.0.0.1 localhost
        ::1       localhost ip6-localhost
        255.255.255.255 broadcasthost
        0.0.0.0 reklam.example.com
        0.0.0.0 Izleyici.Example.NET   # satır sonu yorumu
        127.0.0.1 a.example.org b.example.org
        0.0.0.0 reklam.example.com
        :: ipv6-engel.example.com
        192.168.1.5 yazici.lan.example.com
        ||adblock.example.com^
        ||yol.example.com/yol^
        ||secenekli.example.com^${'$'}third-party
        @@||istisna.example.com^
        düz.example.com
        *.joker.example.com
        https://adres.example.com/yol?x=1
        gecersiz ad
        1.2.3.4
        tek
    """.trimIndent()
    val r = HostsList.parse(hosts)
    val want = setOf("reklam.example.com", "izleyici.example.net", "a.example.org", "b.example.org", "ipv6-engel.example.com",
        "adblock.example.com", "düz.example.com".let { "xn--" }, "joker.example.com", "adres.example.com")
    // "düz" ASCII dışı: geçersiz sayılır (IDN yok); aşağıda ayrıca denetlenir
    val names = r.names.toSet()
    T.check("hosts satırları: 0.0.0.0 ve 127.0.0.1 adları alındı", names.containsAll(listOf("reklam.example.com", "izleyici.example.net", "a.example.org", "b.example.org")), names.toString())
    T.check("küçük harfe çevrilir, yorum ve tekrar atılır, sıralı", r.names == r.names.sorted() && r.names.count { it == "reklam.example.com" } == 1)
    T.check("IPv6 engel adresi (::) kabul edilir", "ipv6-engel.example.com" in names)
    T.check("başka IP'ye yönlendiren satır alınmaz", "yazici.lan.example.com" !in names)
    T.check("localhost ve broadcasthost alınmaz", names.none { it.contains("localhost") || it.contains("broadcast") })
    T.check("||alan^ kuralı alınır", "adblock.example.com" in names)
    T.check("yollu kural ve seçenekli kural ve istisna alınmaz", "yol.example.com" !in names && "secenekli.example.com" !in names && "istisna.example.com" !in names)
    T.check("düz liste: joker, adres ve yol temizlenir", "joker.example.com" in names && "adres.example.com" in names)
    T.check("geçersiz ad, IP ve tek etiket alınmaz", names.none { it.contains(' ') || it == "tek" || it.startsWith("1.2") })
    T.check("atlanan satır sayısı verilir (>0)", r.skipped > 0)
    T.check("sınır aşılmadı", !r.cut && want.isNotEmpty())

    T.check("boş metin: boş sonuç", HostsList.parse("").names.isEmpty() && HostsList.parse("\n\n  \n# yalnız yorum\n").names.isEmpty())
    T.check("CRLF satır sonları", HostsList.parse("0.0.0.0 a.example.com\r\n0.0.0.0 b.example.com\r\n").names == listOf("a.example.com", "b.example.com"))
    T.check("sekme ayırıcı", HostsList.parse("0.0.0.0\tt.example.com").names == listOf("t.example.com"))
    T.check("tek IP ve ad dışı satır atlanır, çökmez", HostsList.parse("0.0.0.0\n::\n127.0.0.1   \n").names.isEmpty())

    // sınırlar
    val sb = StringBuilder()
    for (i in 0 until HostsList.MAX_IMPORTED + 25) sb.append("0.0.0.0 s").append(i).append(".example.com\n")
    val big = HostsList.parse(sb.toString())
    T.check("50.000 sınırında durur ve 'kesildi' işaretlenir", big.names.size == HostsList.MAX_IMPORTED && big.cut)
    val huge = "0.0.0.0 x.example.com\n" + " ".repeat(HostsList.MAX_CHARS + 10) + "\n0.0.0.0 y.example.com\n"
    val h = HostsList.parse(huge)
    T.check("aşırı büyük metin kesilir ve işaretlenir", h.cut && h.names == listOf("x.example.com"))

    // gürültü: çökmemeli
    val rnd = java.util.Random(7)
    var ok = true
    val alphabet = "0123456789.:|^@#!*/ \t\nçüabcdefXYZ-_$[]"
    try {
        for (k in 0 until 3000) {
            val s = StringBuilder()
            for (j in 0 until rnd.nextInt(80)) s.append(alphabet[rnd.nextInt(alphabet.length)])
            val rr = HostsList.parse(s.toString())
            if (rr.names.any { FilterNames.normalize(it) != it }) ok = false
        }
    } catch (e: Throwable) { ok = false }
    T.check("3000 rastgele metin: çökmez, her çıkış temiz alan adı", ok)
}

private fun testHostsMergeExport() {
    T.group("Kendi liste: birleştirme ve dışa aktarma")
    val m = HostsList.merge(listOf("b.example.com", "a.example.com"), listOf("c.example.com", "a.example.com"))
    T.check("birleştirme tekrarsız ve sıralı", m == listOf("a.example.com", "b.example.com", "c.example.com"))
    val many = (0 until HostsList.MAX_IMPORTED).map { "k$it.example.com" }
    T.check("birleştirme 50.000'i aşmaz", HostsList.merge(many, listOf("z.example.com")).size == HostsList.MAX_IMPORTED)
    val ex = HostsList.export(listOf("a.example.com", "b.example.com"))
    T.check("dışa aktarma: hosts satırları", ex.lines().filter { it.startsWith("0.0.0.0 ") } == listOf("0.0.0.0 a.example.com", "0.0.0.0 b.example.com"))
    T.check("dışa aktarılan metin yeniden okununca aynı adlar", HostsList.parse(ex).names == listOf("a.example.com", "b.example.com"))
    val cap = HostsList.export((0 until HostsList.MAX_EXPORT + 500).map { "e$it.example.com" })
    T.check("dışa aktarma ${HostsList.MAX_EXPORT} satırla sınırlı", cap.lines().count { it.startsWith("0.0.0.0 ") } == HostsList.MAX_EXPORT)
}

// ---------------------------------------------------------------- motor

private fun testImportedEngine() {
    T.group("Kendi liste: motor")
    FilterRuntime.source = null
    FilterRuntime.reset()
    FilterRuntime.setImported(listOf("benim-reklam.example.com"))      // henüz ayar verilmedi: yalnızca saklanır
    T.check("ayardan önce setImported çökmez, liste saklanır", FilterRuntime.imported == listOf("benim-reklam.example.com"))
    FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), emptyList())
    val e = FilterRuntime.engine!!
    T.check("içe aktarılan ad engellenir (kendi liste)", e.verdictOf("benim-reklam.example.com") == FilterVerdict.USER)
    T.check("alt alan adı da engellenir", e.verdictOf("cdn.benim-reklam.example.com") == FilterVerdict.USER)
    T.check("başka ad geçer", e.verdictOf("baska.example.com") == FilterVerdict.PASS)
    FilterRuntime.updateNow(FilterLevel.OFF, listOf("benim-reklam.example.com"), emptyList())
    T.check("izin listesi içe aktarılanın üstündedir", FilterRuntime.engine!!.verdictOf("benim-reklam.example.com") == FilterVerdict.PASS)
    FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), listOf("elle.example.com"))
    val e2 = FilterRuntime.engine!!
    T.check("el ile eklenen ve içe aktarılan birlikte çalışır", e2.verdictOf("elle.example.com") == FilterVerdict.USER && e2.verdictOf("benim-reklam.example.com") == FilterVerdict.USER)
    FilterRuntime.setImported(listOf("yeni.example.com"))
    // setImported motoru arka planda yeniden kurar: bitmesini bekle
    var ok = false
    for (i in 0 until 100) { if (FilterRuntime.engine?.verdictOf("yeni.example.com") == FilterVerdict.USER) { ok = true; break }; Thread.sleep(30) }
    T.check("setImported motoru yeniden kurar (son ayarlarla)", ok && FilterRuntime.engine!!.verdictOf("elle.example.com") == FilterVerdict.USER && FilterRuntime.engine!!.verdictOf("benim-reklam.example.com") == FilterVerdict.PASS)
    // büyük liste
    val big = (0 until HostsList.MAX_IMPORTED).map { "b$it.example.net" }
    val t0 = System.nanoTime()
    FilterRuntime.setImported(big)
    var ready = false
    for (i in 0 until 300) { if (FilterRuntime.engine?.verdictOf("b49999.example.net") == FilterVerdict.USER) { ready = true; break }; Thread.sleep(20) }
    val ms = (System.nanoTime() - t0) / 1_000_000
    T.check("50.000 adlık liste kurulur ve aranır ($ms ms)", ready && FilterRuntime.engine!!.verdictOf("b0.example.net") == FilterVerdict.USER && FilterRuntime.engine!!.verdictOf("b50000.example.net") == FilterVerdict.PASS)
    FilterRuntime.reset()
    T.check("reset içe aktarılanı da boşaltır", FilterRuntime.imported.isEmpty())
}

// ---------------------------------------------------------------- kapalı kalırsa dur

private fun v4Query(dns: ByteArray, srcPort: Int = 40001): ByteArray {
    val b = ByteArray(Packets.HDR + dns.size)
    System.arraycopy(dns, 0, b, Packets.HDR, dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size); Packets.put16(b, 6, 0x4000); b[8] = 64; b[9] = 17
    Packets.put32(b, 12, Packets.ip(10, 111, 222, 1)); Packets.put32(b, 16, Packets.ip(10, 111, 222, 2))
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, srcPort); Packets.put16(b, 22, 53); Packets.put16(b, 24, 8 + dns.size)
    return b
}

private fun v6Query(dns: ByteArray, srcPort: Int = 40002): ByteArray {
    val b = ByteArray(Packets.HDR6 + dns.size)
    System.arraycopy(dns, 0, b, Packets.HDR6, dns.size)
    Packets.writeHeaders6(b, Ip.parse6(SelfTest.CLIENT_ADDR6)!!, Ip.parse6(SelfTest.FAKE_DNS6)!!, srcPort, 53, dns.size)
    return b
}

private fun testSinkhole() {
    T.group("Kapalı kalırsa dur: DNS durdurucu")
    val writes = ArrayList<ByteArray>()
    val s = SinkholeForwarder { b, o, l -> writes.add(b.copyOfRange(o, o + l)) }
    s.start()
    val q = Dns.buildQuery(0x4321, "ornek.example.com")
    val p = v4Query(q)
    s.onPacket(p, p.size)
    T.check("IPv4 sorguya hemen cevap yazıldı", writes.size == 1)
    val r = writes[0]
    val dns = Packets.HDR
    T.check("cevap: QR=1, RCODE=2 (SERVFAIL), kimlik aynı", (Packets.u16(r, dns + 2) and 0x8000) != 0 && (Packets.u16(r, dns + 2) and 0xF) == 2 && Packets.u16(r, dns) == 0x4321)
    T.check("cevap: soru kopyalandı, cevap kaydı yok", Packets.u16(r, dns + 4) == 1 && Packets.u16(r, dns + 6) == 0 && Packets.u16(r, dns + 8) == 0 && Packets.u16(r, dns + 10) == 0)
    T.check("cevap: istemcinin portuna, 53'ten, geçerli IP ve UDP sağlama toplamı",
        Packets.u16(r, 22) == 40001 && Packets.u16(r, 20) == 53 && Packets.checksum(r, 0, 20) == 0 && Packets.i32(r, 12) == Packets.ip(10, 111, 222, 2) && Packets.i32(r, 16) == Packets.ip(10, 111, 222, 1))
    T.check("cevap soru bölümü aynı", Dns.sameQuestion(q, 0, q.size, r, dns, r.size - dns))
    T.check("RD biti korunur, RA eklenir", (Packets.u16(r, dns + 2) and 0x0100) == (Packets.u16(q, 2) and 0x0100) && (Packets.u16(r, dns + 2) and 0x0080) != 0)

    val p6 = v6Query(q, 40002)
    s.onPacket(p6, p6.size)
    T.check("IPv6 sorguya da cevap yazıldı", writes.size == 2 && (writes[1][0].toInt() ushr 4) == 6)
    T.check("IPv6 cevabı RCODE=2 ve kimlik", Packets.u16(writes[1], Packets.HDR6) == 0x4321 && (Packets.u16(writes[1], Packets.HDR6 + 2) and 0xF) == 2)

    val resp = v4Query(buildAnswer(q, q.size, ByteArray(0), 0))
    s.onPacket(resp, resp.size)
    T.check("cevap paketlerine (QR=1) karşılık verilmez", writes.size == 2)
    s.onPacket(ByteArray(5), 5)
    s.onPacket(ByteArray(0), 0)
    T.check("bozuk paketler sessizce atılır", writes.size == 2)
    T.check("sayaç cevaplanan sorgu sayısını verir", s.count == 2L && s.stats().queries == 2L)

    val rnd = java.util.Random(11)
    var ok = true
    try {
        for (k in 0 until 20000) {
            val len = rnd.nextInt(90)
            val b = ByteArray(len); rnd.nextBytes(b)
            if (len > 30 && rnd.nextBoolean()) { b[0] = 0x45; b[9] = 17; Packets.put16(b, 22, 53) }
            s.onPacket(b, len)
        }
    } catch (e: Throwable) { ok = false }
    T.check("20.000 rastgele paket: çökmez", ok)
    s.close()
    val before = writes.size
    s.onPacket(p, p.size)
    T.check("kapandıktan sonra cevap verilmez", writes.size == before)
    s.resetNetwork("x"); s.clearCache()
    T.check("proto düz DNS (arayüz için)", s.proto == Proto.PLAIN)
}

// ---------------------------------------------------------------- ayarlar

private fun testStage22Settings() {
    T.group("Aşama 22: ayarlar")
    val d = AppSettings()
    T.check("varsayılanlar: bağlanınca açık, kesilince kapalı, zaman aşımı açık, kapalı kal kapalı",
        d.notifyConnect && !d.notifyStop && d.notifyTimeout && d.notifyDrop && !d.failClosed)
    val s = d.copy(notifyConnect = false, notifyStop = true, notifyTimeout = false, failClosed = true)
    val back = SettingsCodec.decode(SettingsCodec.encode(s).mapValues { it.value })
    T.check("yazma/okuma gidiş dönüş", back.notifyConnect == false && back.notifyStop && !back.notifyTimeout && back.failClosed)
    T.check("eski kayıtta anahtarlar yoksa varsayılan", SettingsCodec.decode(emptyMap()).let { it.notifyConnect && !it.notifyStop && it.notifyTimeout && !it.failClosed })
    T.check("bozuk değer varsayılana düşer", SettingsCodec.decode(mapOf("failClosed" to "belki", "notifyStop" to "?")).let { !it.failClosed && !it.notifyStop })
    T.check("dışa aktarma kodu bu ayarları taşır", SettingsCodec.import(SettingsCodec.export(s), AppSettings())?.let { it.failClosed && it.notifyStop && !it.notifyConnect } == true)
    T.check("kapalı kalırsa durdu kapatmak gevşetme olarak işaretlenir", SensitiveChange.PRIVACY in ImportReview.changes(s, s.copy(failClosed = false)))
    T.check("açmak işaretlenmez", ImportReview.changes(d, d.copy(failClosed = true)).none { it == SensitiveChange.PRIVACY })
    T.check("bildirim türlerini kapatmak işaretlenmez", ImportReview.changes(d, d.copy(notifyConnect = false, notifyTimeout = false)).none { it == SensitiveChange.PRIVACY })
}

// ---------------------------------------------------------------- model

private fun testStage22Model() {
    T.group("Aşama 22: model (liste içe/dışa aktarma, gecikme)")
    val r = Rig()
    val m = r.model
    val h = r.host
    h.clipboard = null
    m.importFromClipboard()
    T.check("pano boşken uyarı, kayıt yok", m.toast?.text == Strings.MINE_CLIP_EMPTY && h.imported.isEmpty() && m.importedCount == 0)
    h.clipboard = "   \n  "
    m.importFromClipboard()
    T.check("yalnızca boşluk: yine boş uyarısı", m.toast?.text == Strings.MINE_CLIP_EMPTY)
    h.clipboard = "bu bir liste değil\n1.2.3.4"
    m.importFromClipboard()
    T.check("geçerli ad yoksa 'bulunamadı' uyarısı", m.toast?.text == Strings.MINE_NOTHING && h.imported.isEmpty())
    h.clipboard = "0.0.0.0 a.example.com\n0.0.0.0 b.example.com\n||c.example.com^"
    m.importFromClipboard()
    T.check("panodan 3 ad eklendi, sayaç ve toast", h.imported == listOf("a.example.com", "b.example.com", "c.example.com") && m.importedCount == 3 && m.toast?.text == Strings.mineAdded(3))
    h.clipboard = "0.0.0.0 b.example.com\n0.0.0.0 d.example.com"
    m.importFromClipboard()
    T.check("ikinci içe aktarma birleştirir (tekrar sayılmaz)", h.imported.size == 4 && m.importedCount == 4 && m.toast?.text == Strings.mineAdded(1))

    h.pickText = "0.0.0.0 dosya.example.com"
    m.importFromFile()
    T.check("dosyadan içe aktarma", h.count("pickFile") == 1 && "dosya.example.com" in h.imported && m.importedCount == 5)
    h.pickText = null
    m.importFromFile()
    T.check("dosya okunamazsa uyarı", m.toast?.text == Strings.MINE_FILE_ERR && m.importedCount == 5)
    h.pickCancel = true
    val calls = h.calls.size
    m.importFromFile()
    T.check("seçici iptal edilirse hiçbir şey olmaz", m.importedCount == 5 && h.calls.size == calls + 1)
    h.pickCancel = false

    h.importSaveOk = false
    h.clipboard = "0.0.0.0 yeni.example.com"
    m.importFromClipboard()
    T.check("kayıt başarısızsa uyarı verilir, sayaç değişmez", m.toast?.text == Strings.MINE_FILE_ERR && m.importedCount == 5)
    h.importSaveOk = true

    // sınır: dolu listeye ekleme
    h.imported = (0 until HostsList.MAX_IMPORTED).map { "m$it.example.com" }
    h.clipboard = "0.0.0.0 fazla.example.com"
    val rr = Rig()
    rr.host.imported = h.imported
    rr.host.clipboard = h.clipboard
    val m2 = rr.model
    m2.importFromClipboard()
    T.check("dolu listede 'sınır' uyarısı da gösterilir", (m2.toast?.text ?: "").contains(Strings.MINE_CUT))

    // dışa aktarma
    h.imported = listOf("a.example.com", "b.example.com", "c.example.com", "d.example.com")
    r.model.update { it.copy(filterBlock = listOf("elle.example.com")) }
    m.copyBlockList()
    val copied = h.clipboard ?: ""
    T.check("dışa aktarma: el ile eklenen + içe aktarılanlar, hosts biçiminde",
        "0.0.0.0 elle.example.com" in copied && "0.0.0.0 a.example.com" in copied && copied.lines().count { it.startsWith("0.0.0.0 ") } == h.imported.size + 1)
    T.check("dışa aktarma toast'u sayıyı söyler", m.toast?.text == Strings.mineCopied(h.imported.size + 1))
    val empty = Rig()
    empty.model.copyBlockList()
    T.check("liste boşken kopyalanacak bir şey yok uyarısı", empty.model.toast?.text == Strings.MINE_NOTHING && empty.host.clipboard == null)

    // silme
    m.askClearImported()
    T.check("silme önce sorar", m.toast?.text == Strings.MINE_CLEAR_ASK && h.imported.isNotEmpty())
    m.toast?.onAction?.invoke()
    T.check("onaylanınca liste silinir", h.imported.isEmpty() && m.importedCount == 0 && m.toast?.text == Strings.MINE_CLEARED)
    m.askClearImported()
    T.check("boşken silme sorusu çıkmaz", m.toast?.text == Strings.MINE_NOTHING)

    // gecikme örnekleri
    val g = Rig()
    g.host.latencyData = intArrayOf(10, 20, -1, 30)
    g.model.refreshLatencies()
    T.check("bağlı değilken örnek yok", g.model.latencyCount == 0)
    g.connectOk()
    g.model.refreshLatencies()
    T.check("bağlıyken örnekler alınır (eskiden yeniye)", g.model.latencyCount == 4 && g.model.latencySamples[0] == 10 && g.model.latencySamples[2] == -1 && g.model.latencySamples[3] == 30)
    g.host.latencyData = IntArray(500) { it % 90 }
    g.model.refreshLatencies()
    T.check("en çok halka kapasitesi kadar alınır", g.model.latencyCount == LatencyRing.CAPACITY)
}

// ---------------------------------------------------------------- arayüz

private fun shownTexts(r: Rig): List<String> {
    val rec = TextRecorder()
    r.draw(rec)
    return rec.runs.map { it.s }
}

private fun testStage22Ui() {
    T.group("Aşama 22: arayüz")
    // bildirimler
    run {
        val r = Rig()
        r.scene.openSection(Section.NOTIFICATIONS); r.settle(900)
        val its = r.items()
        for (l in listOf(Strings.NOTIFY_CONNECT, Strings.NOTIFY_DROP, Strings.NOTIFY_STOP, Strings.NOTIFY_TIMEOUT, Strings.LOCK_HIDE, Strings.QUIET_NOTIF))
            T.check("bildirim anahtarı: $l", (its.firstOrNull { it.info.label.startsWith(l) } ?: r.reveal(l))?.info?.role == Role.SWITCH)
        T.check("izin satırı 'Açık' der", r.reveal(Strings.NOTIF_PERM) != null && shownTexts(r).contains(Strings.PERM_ALLOWED))
        r.tapText(Strings.NOTIF_PERM, settleMs = 300)
        T.check("izin satırına dokununca sistem bildirim ayarları açılır", r.host.count("notifSettings") == 1)
        r.host.notifAllowed = false
        r.model.update { it.copy(compact = !it.compact) }
        r.settle(300)
        T.check("izin kapalıyken satır düzeltme çağrısı gösterir", r.reveal(Strings.NOTIF_PERM) != null && shownTexts(r).contains(Strings.PERM_BLOCKED))
        r.tapText(Strings.NOTIFY_STOP, settleMs = 300)
        T.check("Kesilince bildir anahtarı çalışır", r.model.settings.notifyStop)
        r.tapText(Strings.NOTIFY_CONNECT, settleMs = 300)
        r.tapText(Strings.NOTIFY_TIMEOUT, settleMs = 300)
        T.check("öbür anahtarlar da çalışır", !r.model.settings.notifyConnect && !r.model.settings.notifyTimeout)
    }
    // bağlantı: kapalı kal
    run {
        val r = Rig()
        r.scene.openSection(Section.CONNECTION); r.settle(900)
        val sw = r.need(Strings.FAIL_CLOSED)
        T.check("Kapalı kalırsa dur bir anahtardır, varsayılan kapalı", sw.info.role == Role.SWITCH && !r.model.settings.failClosed)
        r.tapText(Strings.FAIL_CLOSED, settleMs = 300)
        T.check("anahtar ayarı açar ve kaydeder", r.model.settings.failClosed && r.host.saved?.failClosed == true)
        T.check("bağlıyken ayar değişimi servise 'uygula' göndermez (kopma anında okunur)", r.host.count("reapply") == 0)
    }
    // kendi listem
    run {
        val r = Rig()
        r.scene.openSection(Section.FILTER); r.settle(900)
        T.check("Engelleme sayfasında Kendi listem satırı var", r.find(Strings.FILTER_MINE) != null || r.reveal(Strings.FILTER_MINE) != null)
        r.tapText(Strings.FILTER_MINE, settleMs = 900)
        val t = shownTexts(r)
        T.check("pencere dört seçeneği ve açıklamayı gösterir", listOf(Strings.MINE_PASTE, Strings.MINE_FILE, Strings.MINE_EXPORT, Strings.MINE_CLEAR).all { it in t })
        r.host.clipboard = "0.0.0.0 ui.example.com\n0.0.0.0 ui2.example.com"
        r.tapText(Strings.MINE_PASTE, settleMs = 900)
        T.check("panodan içe aktarma pencereden çalışır, pencere kapanır", r.host.imported.size == 2 && !r.scene.hasSheet)
        r.reveal(Strings.FILTER_MINE)
        T.check("satırın değeri ad sayısını gösterir", shownTexts(r).contains("2"), shownTexts(r).toString())
        r.tapText(Strings.FILTER_MINE, settleMs = 900)
        T.check("silme seçeneğinin altında ad sayısı yazar", shownTexts(r).contains(Strings.mineCount(2)))
        r.host.pickText = "0.0.0.0 dosya.example.com"
        r.tapText(Strings.MINE_FILE, settleMs = 900)
        T.check("dosyadan içe aktarma pencereden çalışır", r.host.imported.size == 3)
        r.tapText(Strings.FILTER_MINE, settleMs = 900)
        r.tapText(Strings.MINE_EXPORT, settleMs = 600)
        T.check("kopyalama pencereden çalışır", (r.host.clipboard ?: "").contains("0.0.0.0 dosya.example.com"))
        r.tapText(Strings.FILTER_MINE, settleMs = 900)
        r.tapText(Strings.MINE_CLEAR, settleMs = 600)
        T.check("silme onay ister, onaylanınca temizler", r.model.toast?.text == Strings.MINE_CLEAR_ASK && r.host.imported.size == 3)
        r.model.toast?.onAction?.invoke(); r.settle(400)
        T.check("liste temizlendi", r.host.imported.isEmpty())
    }
    // gecikme grafiği
    run {
        val r = Rig()
        r.scene.openSection(Section.STATS); r.settle(900)
        T.check("bağlı değilken grafik başlığı ve açıklaması görünür", shownTexts(r).contains(Strings.LATENCY_TITLE) && shownTexts(r).any { Strings.LATENCY_EMPTY.startsWith(it.removeSuffix("…")) && it.length > 8 })
        r.host.latencyData = intArrayOf(12, 18, 25, 400, -1, 20, 15)
        r.connectOk()
        r.settle(1500)
        val t = shownTexts(r)
        val s = LatencySummary.of(r.host.latencyData, 7)
        T.check("bağlıyken özet satırı (ort., en çok, zaman aşımı) yazılır",
            t.contains(Strings.latencyLine(Format.ms(s.avgMs), Format.ms(s.maxMs), s.timeouts)), t.filter { it.contains("·") }.toString())
        T.check("grafik erişilebilirlik etiketi başlığı ve özeti taşır", r.items().any { it.info.label.startsWith(Strings.LATENCY_TITLE) && it.info.label.contains(Format.ms(s.maxMs)) })
        // çizim: çubuklar çizilir, ayırma azdır
        val cg = CountingGfx()
        r.draw(cg)
        r.draw(cg)
        T.check("grafikle birlikte sayfa çizilir", cg.calls > 20)
        r.host.latencyData = IntArray(0)
        r.advance(1200)
        r.draw(TextRecorder())
        T.check("örnek kalmayınca açıklama geri gelir", shownTexts(r).any { Strings.LATENCY_EMPTY.startsWith(it.removeSuffix("…")) && it.length > 8 })
    }
}

// ---------------------------------------------------------------- metinler

private fun testStage22Strings() {
    T.group("Aşama 22: metinler (12 dil)")
    val saved = L.lang
    try {
        for (lang in Lang.values()) {
            L.set(lang)
            val n = lang.code
            val vals = listOf(
                Strings.NOTIFY_CONNECT, Strings.NOTIFY_CONNECT_NOTE, Strings.NOTIFY_STOP, Strings.NOTIFY_STOP_NOTE, Strings.NOTIFY_TIMEOUT,
                Strings.NOTIFY_TIMEOUT_NOTE, Strings.NOTIF_PERM, Strings.PERM_ALLOWED, Strings.PERM_BLOCKED, Strings.NOTIF_CONNECTED_TITLE,
                Strings.NOTIF_STOPPED_TITLE, Strings.NOTIF_STOPPED_TEXT, Strings.NOTIF_TIMEOUT_TITLE, Strings.FAIL_CLOSED, Strings.FAIL_CLOSED_NOTE,
                Strings.NOTIF_SEALED, Strings.ERR_SEALED, Strings.SEALED_INFO, Strings.LATENCY_TITLE, Strings.LATENCY_EMPTY, Strings.FILTER_MINE,
                Strings.MINE_PASTE, Strings.MINE_PASTE_NOTE, Strings.MINE_FILE, Strings.MINE_FILE_NOTE, Strings.MINE_EXPORT, Strings.MINE_EXPORT_NOTE,
                Strings.MINE_CLEAR, Strings.MINE_FOOT, Strings.MINE_NOTHING, Strings.MINE_CLIP_EMPTY, Strings.MINE_FILE_ERR, Strings.MINE_CLEARED,
                Strings.MINE_CLEAR_ASK, Strings.MINE_CUT,
            )
            T.check("$n: 35 yeni metin dolu, yer tutucu yok", vals.all { it.isNotBlank() && !it.contains("TODO") && !it.contains("\$") })
            T.check("$n: bildirim başlıkları kısa (≤ 36)", listOf(Strings.NOTIF_CONNECTED_TITLE, Strings.NOTIF_STOPPED_TITLE, Strings.NOTIF_TIMEOUT_TITLE).all { it.length <= 36 })
            T.check("$n: anahtar başlıkları kısa (≤ 34)", listOf(Strings.NOTIFY_CONNECT, Strings.NOTIFY_STOP, Strings.NOTIFY_TIMEOUT, Strings.FAIL_CLOSED, Strings.FILTER_MINE, Strings.MINE_PASTE, Strings.MINE_FILE, Strings.MINE_EXPORT, Strings.MINE_CLEAR, Strings.NOTIF_PERM).all { it.length <= 34 })
            T.check("$n: işlevler değişkenleri kullanır",
                Strings.notifTimeout("Cloudflare").contains("Cloudflare") &&
                    Strings.latencyLine("20 ms", "90 ms", 0).let { it.contains("20 ms") && it.contains("90 ms") } &&
                    Strings.latencyLine("20 ms", "90 ms", 4).contains("4") &&
                    Strings.mineCount(1234).contains("1234") && Strings.mineAdded(7).contains("7") && Strings.mineCopied(9).contains("9"))
            T.check("$n: zaman aşımı yokken özet daha kısa", Strings.latencyLine("1 ms", "2 ms", 0).length < Strings.latencyLine("1 ms", "2 ms", 3).length)
            T.check("$n: yeni 'neler yeni' maddesi 40..160 karakter", Strings.WHATS_NEW_ITEMS[0].length in 40..160, "${Strings.WHATS_NEW_ITEMS[0].length}")
        }
    } finally {
        L.set(saved)
    }
    T.check("12 dil de farklı dilde yazılmış (Türkçe ile İngilizce aynı değil)",
        run {
            L.set(Lang.values().first { it.code == "tr" }); val tr = Strings.FAIL_CLOSED
            L.set(Lang.values().first { it.code == "en" }); val en = Strings.FAIL_CLOSED
            L.set(saved); tr != en
        })
}
