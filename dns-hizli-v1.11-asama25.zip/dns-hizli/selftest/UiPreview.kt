package app.dnshizli.selftest

import app.dnshizli.core.AppSettings
import app.dnshizli.core.Catalog
import app.dnshizli.core.Encryption
import app.dnshizli.core.L
import app.dnshizli.core.Lang
import app.dnshizli.core.Themes
import app.dnshizli.core.Proto
import app.dnshizli.core.Session
import app.dnshizli.core.SessionLog
import app.dnshizli.core.EndReason
import app.dnshizli.core.SelfTestResult
import app.dnshizli.core.DnssecResult
import app.dnshizli.core.AdBlockResult
import app.dnshizli.ui.Section
import app.dnshizli.ui.Strings
import java.awt.image.BufferedImage

/**
 * Önizleme görselleri: gerçek sahne kodunu AWT üzerinde çizer ([Rig] ile aynı düzenek).
 * Cihaz ekran görüntüsü değildir: yazı tipi Inter'dir (Android'de Roboto kullanılır).
 */
object UiPreview {
    private val awt = AwtGfx(BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB).createGraphics())

    private fun rig(s: AppSettings, w: Int = 360, h: Int = 780) = Rig(s, w, h, metrics = awt)

    private fun Rig.render(file: String, scale: Float = 2f) {
        val cv = AwtCanvas(w, h, scale)
        scene.draw(cv.gfx)
        cv.savePng(file)
        cv.dispose()
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val out = args.getOrNull(0) ?: "."
        val which = args.getOrNull(1)
        fun want(n: String) = which == null || which == n

        if (want("home")) {
            for (th in Themes.all) {
                val r = rig(Rig.base(th.id)); r.connectOk()
                r.render("$out/ana-${th.id}.png")
            }
        }
        if (want("styles")) {
            // Stil önizlemeleri: her stil için ana (bağlı/kapalı), ayarlar ve ayrıntı sayfası; açık ve koyu tema.
            for (st in app.dnshizli.core.UiStyle.values()) {
                if (st == app.dnshizli.core.UiStyle.AQUA) continue
                for (th in listOf("aqua", "night", "sakura", "meadow")) {
                    val r = rig(Rig.base(th).copy(style = st)); r.connectOk()
                    r.render("$out/stil-${st.id}-$th-ana.png")
                }
                val off = rig(Rig.base("aqua").copy(style = st)); off.render("$out/stil-${st.id}-kapali.png")
                val se = rig(Rig.base("aqua").copy(style = st)); se.scene.openSection(Section.CONNECTION); se.settle(900)
                se.render("$out/stil-${st.id}-ayarlar.png")
                val sh = rig(Rig.base("night").copy(style = st)); sh.connectOk()
                sh.scene.openDetails(Catalog.byId("quad9")!!); sh.settle(700)
                sh.render("$out/stil-${st.id}-detay.png")
            }
        }
        if (want("liquid")) {
            // Sıvı rengi sayfası (seçili renkli) ve renkli ana ekran
            val r = rig(Rig.base("aqua").copy(orbShapes = "aqua=hexagon", liquidColor = "FF7043")); r.scene.openLiquidColor(); r.settle(900)
            r.render("$out/sivi-rengi-sayfa.png")
            for ((i, c) in listOf("2979FF", "00C853", "E040FB").withIndex()) {
                val h = rig(Rig.base("aqua").copy(liquidColor = c)); h.connectOk(); h.render("$out/sivi-rengi-ana$i.png")
            }
        }
        if (want("stylepick")) {
            val r = rig(Rig.base("sakura").copy(style = app.dnshizli.core.UiStyle.Y2K)); r.scene.openSection(Section.CONNECTION); r.settle(900)
            r.tapText(Strings.STYLE, settleMs = 900)
            r.render("$out/stil-secici.png")
        }
        if (want("extras")) {
            // Sunucu arama, sorun giderici, özel sunucuda Düzenle
            run {
                val r = rig(Rig.base()); r.model.setQuery("cloud"); r.settle(900)
                r.render("$out/arama.png")
            }
            run {
                val r = rig(Rig.base()); r.host.net = app.dnshizli.core.NetCheck(false, false, true, app.dnshizli.core.PrivateDns.STRICT)
                r.scene.openSection(Section.CONNECTION); r.settle(900)
                r.tapText(Strings.TROUBLE, settleMs = 1000)
                r.render("$out/sorun-gider.png")
            }
            run {
                val r = rig(Rig.base())
                app.dnshizli.core.Catalog.setCustom(emptyList())
                r.host.customDraft = app.dnshizli.core.CustomDns.Draft("Evim", "192.168.1.2", "", "dns.example.com", "")
                r.model.promptCustom()
                r.scene.openDetails(app.dnshizli.core.Catalog.custom.single()); r.settle(800)
                r.render("$out/ozel-duzenle.png")
                app.dnshizli.core.Catalog.setCustom(emptyList())
            }
        }
        if (want("menu")) {
            // ☰ menüsü ve Hakkında penceresi: dört stil, açık ve koyu tema
            for ((name, th, st) in listOf(Triple("aqua", "aqua", app.dnshizli.core.UiStyle.AQUA), Triple("metro", "night", app.dnshizli.core.UiStyle.METRO), Triple("metrol", "aqua", app.dnshizli.core.UiStyle.METRO), Triple("aurora", "aqua", app.dnshizli.core.UiStyle.AURORA), Triple("auroran", "night", app.dnshizli.core.UiStyle.AURORA), Triple("y2kd", "night", app.dnshizli.core.UiStyle.Y2K),
                Triple("eco", "meadow", app.dnshizli.core.UiStyle.ECO), Triple("y2k", "sakura", app.dnshizli.core.UiStyle.Y2K))) {
                val h = rig(Rig.base(th).copy(style = st)); h.connectOk(); h.render("$out/menu-$name-ana.png")
                val m = rig(Rig.base(th).copy(style = st)); m.scene.openMenu(); m.settle(900); m.render("$out/menu-$name-menu.png")
                val a = rig(Rig.base(th).copy(style = st)); a.scene.openMenu(); a.settle(900); a.scene.openAbout(); a.settle(900); a.render("$out/menu-$name-hakkinda.png")
                val k = rig(Rig.base(th).copy(style = st)); k.scene.openMenu(); k.settle(900); k.scene.openPersonalize(); k.settle(900); k.render("$out/menu-$name-kisisel1.png")
                k.drag(180f, 620f, 120f, 20); k.advance(900); k.render("$out/menu-$name-kisisel2.png")
                k.drag(180f, 620f, 120f, 20); k.advance(900); k.render("$out/menu-$name-kisisel3.png")
                for ((tag, sec) in listOf("dns" to Section.DNS, "baglanti" to Section.CONNECTION, "istatistik" to Section.STATS)) {
                    val q = rig(Rig.base(th).copy(style = st)); q.scene.openMenu(); q.settle(900); q.scene.openSection(sec); q.settle(900); q.render("$out/menu-$name-$tag.png")
                }
            }
        }
        if (want("filter")) {
            for ((tag, th) in listOf("a" to "aqua", "n" to "night")) {
                val b = Rig.base(th).copy(filterLevel = app.dnshizli.core.FilterLevel.MEDIUM, filterAllow = listOf("ornek.com", "magaza.example.org"))
                app.dnshizli.core.FilterLive.clear()
                for (n in listOf("ads.example.net", "tracker.example.com", "metrics.example.io")) app.dnshizli.core.FilterLive.note(n, false)
                val r = rig(b); r.scene.openSection(Section.FILTER); r.settle(900); r.render("$out/engelleme-$tag.png")
                r.tapText(Strings.FILTER_LAST, settleMs = 900); r.render("$out/engelleme-$tag-son.png")
                val q = rig(b); q.scene.openSection(Section.FILTER); q.settle(900); q.tapText(Strings.FILTER_ALLOW, settleMs = 900); q.render("$out/engelleme-$tag-izin.png")
            }
            app.dnshizli.core.FilterLive.clear()
        }
        if (want("liste")) {
            for ((tag, th) in listOf("a" to "aqua", "n" to "night")) {
                val c = rig(Rig.base(th)); c.settle(900); c.render("$out/liste-$tag-1.png")
                c.fling(180f, 700f, 330f, 6); c.advance(150); c.render("$out/liste-$tag-2-bar.png")
                c.advance(1500)
                repeat(4) { c.fling(180f, 700f, 200f, 5); c.advance(700) }
                c.render("$out/liste-$tag-3-dugme.png")
                c.model.toggleList(); c.advance(900)
                repeat(10) { c.fling(180f, 700f, 200f, 5); c.advance(700) }
                c.render("$out/liste-$tag-4-acik.png")
            }
        }
        if (want("icon")) {
            // Uygulama simgesi seçici ve yardım sayfasının yeşil kapanış cümlesi
            run {
                val r = rig(Rig.base()); r.scene.openSection(Section.CONNECTION); r.settle(900)
                r.tapText(Strings.APP_ICON, settleMs = 900)
                r.render("$out/simge-secici.png")
            }
            for ((name, th, st) in listOf(Triple("aqua", "aqua", app.dnshizli.core.UiStyle.AQUA), Triple("gece", "night", app.dnshizli.core.UiStyle.ECO), Triple("y2k", "sakura", app.dnshizli.core.UiStyle.Y2K))) {
                val r = rig(Rig.base(th).copy(style = st)); r.scene.openHelp(); r.settle(1200)
                val page = r.scene.currentPage as app.dnshizli.ui.ScrollPage
                var last = -1f
                repeat(40) { if (page.scrollOffset != last) { last = page.scrollOffset; r.drag(180f, r.h * 0.7f, r.h * 0.7f - 260f, 8); r.advance(300) } }
                r.render("$out/yardim-son-$name.png")
            }
        }
        if (want("wallpaper")) {
            // Arka plan fotoğrafı: parlak ve koyu iki sahte fotoğraf; açık/koyu tema; bulanıklık; farklı stiller.
            fun photo(bright: Boolean): BufferedImage {
                val w = 540; val h = 1170
                val im = BufferedImage(w, h, BufferedImage.TYPE_INT_RGB)
                val g = im.createGraphics()
                g.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON)
                val top = if (bright) java.awt.Color(0xFFB347) else java.awt.Color(0x0B1026)
                val bot = if (bright) java.awt.Color(0xFFF3C4) else java.awt.Color(0x3A1C4B)
                g.paint = java.awt.GradientPaint(0f, 0f, top, 0f, h * 0.7f, bot)
                g.fillRect(0, 0, w, h)
                g.color = if (bright) java.awt.Color(0xFFFFFF) else java.awt.Color(0xF2D58A)
                g.fillOval(w / 2 - 90, (h * 0.34f).toInt() - 90, 180, 180)
                g.color = if (bright) java.awt.Color(0x6A8F3A) else java.awt.Color(0x05060F)
                val poly = java.awt.Polygon()
                poly.addPoint(0, h); poly.addPoint(0, (h * 0.66f).toInt())
                var x = 0
                while (x <= w) { poly.addPoint(x, (h * (0.66f - 0.05f * Math.abs(Math.sin(x / 70.0)).toFloat() - 0.04f * Math.sin(x / 23.0).toFloat())).toInt()); x += 18 }
                poly.addPoint(w, h)
                g.fillPolygon(poly)
                g.dispose()
                return im
            }
            fun blurred(src: BufferedImage, div: Int): BufferedImage {
                if (div <= 1) return src
                val small = BufferedImage(src.width / div, src.height / div, BufferedImage.TYPE_INT_RGB)
                val g = small.createGraphics()
                g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, java.awt.RenderingHints.VALUE_INTERPOLATION_BILINEAR)
                g.drawImage(src, 0, 0, small.width, small.height, null); g.dispose()
                val big = BufferedImage(src.width / 2, src.height / 2, BufferedImage.TYPE_INT_RGB)
                val g2 = big.createGraphics()
                g2.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, java.awt.RenderingHints.VALUE_INTERPOLATION_BICUBIC)
                g2.drawImage(small, 0, 0, big.width, big.height, null); g2.dispose()
                return big
            }
            fun lumaOf(im: BufferedImage): Pair<Float, Float> {
                val s = FloatArray(576); var k = 0
                for (j in 0 until 24) for (i in 0 until 24) s[k++] = app.dnshizli.core.WallpaperMath.luma(im.getRGB(i * im.width / 24 + 1, j * im.height / 24 + 1))
                return app.dnshizli.core.WallpaperMath.percentile(s, 0.10f) to app.dnshizli.core.WallpaperMath.percentile(s, 0.90f)
            }
            fun wrig(theme: String, bright: Boolean, st: app.dnshizli.core.UiStyle, blur: app.dnshizli.core.WpBlur = app.dnshizli.core.WpBlur.OFF, dim: Float = 0.35f): Rig {
                val src = photo(bright)
                val r = Rig(Rig.base(theme).copy(style = st, wpBlur = blur, wpDim = dim), 360, 780, metrics = awt)
                val lm = lumaOf(src)
                r.host.wpStored = true
                r.host.wpFactory = { b -> val img = blurred(src, b.divisor); app.dnshizli.core.Pic(img.width, img.height, img, lm.first, lm.second) }
                r.model.update { it.copy(wallpaper = true, wpRev = it.wpRev + 1) }
                r.connectOk(); r.settle(900)
                return r
            }
            val U = app.dnshizli.core.UiStyle.values()
            wrig("aqua", true, U[0]).render("$out/arka-1-parlak-aqua.png")
            wrig("aqua", false, U[0]).render("$out/arka-2-koyu-foto-acik-tema.png")
            wrig("night", false, U[0]).render("$out/arka-3-gece.png")
            wrig("aqua", true, U[0], app.dnshizli.core.WpBlur.STRONG).render("$out/arka-4-bulanik.png")
            wrig("sakura", true, U[4]).render("$out/arka-5-y2k.png")
            wrig("meadow", false, U[3], app.dnshizli.core.WpBlur.SOFT, 0.1f).render("$out/arka-6-eco-az-perde.png")
            wrig("aqua", true, U[2]).render("$out/arka-7-metro.png")
            val st = wrig("aqua", true, U[1]); st.scene.openSection(Section.CONNECTION); st.settle(900); st.render("$out/arka-8-ayarlar.png")
        }
        if (want("off")) { rig(Rig.base()).render("$out/ana-kapali.png") }
        if (want("scroll")) {
            val r = rig(Rig.base()); r.connectOk()
            r.drag(180f, 600f, 250f, 14); r.drag(180f, 600f, 250f, 14)
            r.render("$out/ana-kaydirilmis.png")
        }
        if (want("settings")) {
            val r = rig(Rig.base()); r.scene.openSection(Section.CONNECTION); r.settle(900)
            r.render("$out/ayarlar-1.png")
            r.drag(180f, 600f, 150f, 14); r.drag(180f, 600f, 150f, 14)
            r.render("$out/ayarlar-2.png")
            val n = rig(Rig.base("night")); n.scene.openSection(Section.CONNECTION); n.settle(900)
            n.render("$out/ayarlar-gece.png")
        }
        if (want("sheet")) {
            val r = rig(Rig.base()); r.connectOk()
            r.scene.openDetails(Catalog.byId("quad9")!!); r.settle(700)
            r.render("$out/detay.png")
            val c = rig(Rig.base("sunset")); c.scene.openSection(Section.CONNECTION); c.settle(800)
            c.scene.openChoice(Strings.RULE_WIFI, null) {}; c.settle(700)
            c.render("$out/secici.png")
        }
        if (want("consent")) {
            val r = rig(Rig.base("ocean").copy(onboarded = false))
            r.model.tapOrb(); r.settle(900)
            r.render("$out/bilgilendirme.png")
        }
        if (want("pages")) {
            val r = rig(Rig.base("lavender")); r.scene.openSection(Section.CONNECTION); r.settle(700); r.scene.openLog(); r.settle(700)
            r.render("$out/gunluk.png")
            val h = rig(Rig.base("meadow")); h.scene.openSection(Section.CONNECTION); h.settle(700); h.scene.openHelp(); h.settle(700)
            h.render("$out/yardim.png")
        }
        if (want("toast")) {
            val r = rig(Rig.base()); r.connectOk()
            r.model.toast("En hızlı: Cloudflare · 18 ms", "Bağlan") {}; r.settle(500)
            r.render("$out/bildirim.png")
        }
        if (want("tablet")) {
            val r = rig(Rig.base("ocean"), 800, 1100); r.connectOk()
            r.render("$out/tablet.png", 1f)
        }
        if (want("large")) {
            val r = Rig(Rig.base("meadow"), 360, 780, metrics = awt, fontScale = 1.3f); r.connectOk()
            r.render("$out/buyuk-yazi.png")
        }
        if (want("lang")) {
            // Diğer dillerde ana ekran ve ayarlar.
            val saved = L.lang
            try {
                for ((lang, theme) in listOf(Lang.EN to "amoled", Lang.DE to "coral", Lang.RU to "mint", Lang.ES to "ocean",
                    Lang.ID to "sakura", Lang.VI to "honey", Lang.PL to "aurora", Lang.UK to "night")) {
                    L.set(lang)
                    val r = rig(Rig.base(theme).copy(lang = lang.code)); r.model.onLanguageChanged(); r.connectOk()
                    r.render("$out/dil-${lang.code}.png")
                }
                L.set(Lang.EN)
                val s = rig(Rig.base("coral").copy(lang = "en")); s.model.onLanguageChanged(); s.scene.openSection(Section.CONNECTION); s.settle(900)
                s.render("$out/dil-en-ayarlar.png")
            } finally { L.set(saved) }
        }
        if (want("new")) {
            // Yeni özellikler: hızlı seçim, geçmişli ayrıntı, şifreleme ayarı, yüksek kontrast, sade görünüm.
            val q = rig(Rig.base("mint")); q.connectOk(); q.scene.openQuickPick(); q.settle(700)
            q.render("$out/hizli-secim.png")
            val d = rig(Rig.base().copy(encryption = Encryption.DOT)); d.connectOk()
            for ((ms, loss) in listOf(21 to 0, 19 to 0, 26 to 0, 18 to 0, 33 to 20, 22 to 0, 20 to 0, 17 to 0)) d.model.onLatency("cloudflare", ms, loss)
            d.scene.openDetails(Catalog.byId("cloudflare")!!); d.settle(700)
            d.render("$out/detay-gecmis.png")
            val e = rig(Rig.base("amoled")); e.scene.openSection(Section.CONNECTION); e.settle(900)
            repeat(3) { e.drag(180f, 650f, 150f, 14) }; e.advance(1500)
            e.render("$out/ayarlar-gizlilik.png")
            val hc = rig(Rig.base().copy(highContrast = true)); hc.connectOk()
            hc.render("$out/yuksek-kontrast.png")
            val mn = rig(Rig.base("coral").copy(minimal = true, compact = true)); mn.connectOk()
            mn.render("$out/sade-gorunum.png")
        }
        if (want("v3")) {
            // 3. sürüm: bağlantı testi, oturum geçmişi, yenilikler, yeni temalar (ana ekranlar yukarıda), bildirim ayarları.
            val t = rig(Rig.base("aurora")); t.connectOk(); t.scene.openTest(); t.settle(700)
            t.model.onTestResult(SelfTestResult(true, 23, Proto.DOT, "cloudflare", DnssecResult.VALIDATING, AdBlockResult.NOT_BLOCKED))
            t.settle(700)
            t.render("$out/baglanti-testi.png")
            val now = 1_800_000_000_000L
            val list = listOf(
                Session("cloudflare", Proto.DOT, now - 7_200_000, now - 3_600_000, EndReason.USER, 1840),
                Session("quad9", Proto.DOH, now - 90_000_000, now - 86_400_000, EndReason.SWITCH, 920),
                Session("adguard", Proto.PLAIN, now - 200_000_000, now - 190_000_000, EndReason.DROP, 310),
            )
            val se = rig(Rig.base("sakura").copy(sessions = SessionLog.encode(list))); se.scene.openSection(Section.CONNECTION); se.settle(700)
            se.scene.openSessions(); se.settle(800)
            se.render("$out/oturumlar.png")
            val w = rig(Rig.base("honey")); w.scene.openSection(Section.CONNECTION); w.settle(700); w.scene.openWhatsNew(); w.settle(800)
            w.render("$out/yenilikler.png")
            val n = rig(Rig.base("aurora")); n.scene.openSection(Section.CONNECTION); n.settle(900)
            repeat(5) { n.drag(180f, 650f, 150f, 14) }; n.advance(1500)
            n.render("$out/ayarlar-bildirim.png")
        }
        println("önizlemeler: $out")
    }
}
