package app.dnshizli.selftest

import app.dnshizli.core.*

/** Kendini onarma: sağlık ölçümü kararları ve basamak süreleri. */
fun runHealthTests() {
    T.group("Kendini onarma: sağlık ölçümü")
    val m = HealthMonitor()
    val f1 = Any()
    val f2 = Any()
    fun st(answered: Long = 0, timeouts: Long = 0, hits: Long = 0, blocked: Long = 0) =
        Stats(queries = answered + timeouts + hits + blocked, answered = answered, timeouts = timeouts, cacheHits = hits, blocked = blocked)
    T.check("ilk ölçüm karar vermez", m.check(f1, st()) == HealthMonitor.Verdict.IDLE)
    T.check("cevap geldi: sağlıklı", m.check(f1, st(answered = 5)) == HealthMonitor.Verdict.HEALTHY)
    T.check("cevap yok, 2 zaman aşımı: henüz şüphe yok", m.check(f1, st(answered = 5, timeouts = 2)) == HealthMonitor.Verdict.IDLE)
    T.check("cevap yok, 3+ zaman aşımı: şüpheli", m.check(f1, st(answered = 5, timeouts = 6)) == HealthMonitor.Verdict.SUSPECT)
    T.check("önbellek ve engelleme cevapları sunucuyu sınamaz: yine şüpheli",
        m.check(f1, st(answered = 5, timeouts = 10, hits = 20, blocked = 20)) == HealthMonitor.Verdict.SUSPECT)
    T.check("cevap + zaman aşımı birlikte: sağlıklı sayılır", m.check(f1, st(answered = 8, timeouts = 14, hits = 20, blocked = 20)) == HealthMonitor.Verdict.HEALTHY)
    T.check("yönlendirici değişince karşılaştırma yeniden başlar", m.check(f2, st(timeouts = 9)) == HealthMonitor.Verdict.IDLE)
    T.check("sayaçlar geri giderse (yeni yönlendirici) karar verilmez", m.check(f2, st(timeouts = 1)) == HealthMonitor.Verdict.IDLE)
    m.reset()
    T.check("sıfırlamadan sonra ilk ölçüm karar vermez", m.check(f2, st(timeouts = 50)) == HealthMonitor.Verdict.IDLE)
    T.check("yalnızca önbellekten gelen trafik şüphe doğurmaz", m.check(f2, st(timeouts = 50, hits = 30)) == HealthMonitor.Verdict.IDLE)

    T.group("Kendini onarma: basamaklar")
    T.check("ilk üç basamakta 1 dk, sonra 10 dk bekleme",
        (0..2).all { HealPlan.cooldownMs(it) == 60_000L } && HealPlan.cooldownMs(3) == 600_000L && HealPlan.cooldownMs(9) == 600_000L)
    T.check("basamak sırası: yenile < yedek < baştan kur", HealPlan.STEP_REFRESH < HealPlan.STEP_BACKUP && HealPlan.STEP_BACKUP < HealPlan.STEP_REBUILD)
}
