package app.dnshizli.selftest

import app.dnshizli.core.*

/**
 * Test sunucularının cevabı: soru bölümü + [records] (cevap kayıtları) + sorgunun geri kalanı (ek kayıtlar, yani OPT).
 * Gerçek sunucular da sorgudaki OPT'ye OPT ile karşılık verir; bu yüzden sorguyu olduğu gibi yansıtıp sonuna kayıt eklemek
 * (eski yöntem) EDNS'li sorgularda bozuk cevap üretirdi. [count]: cevap kaydı sayısı.
 */
internal fun buildAnswer(q: ByteArray, len: Int, records: ByteArray, count: Int): ByteArray {
    val qEnd = Dns.questionEnd(q, 0, len).let { if (it < 0) len else it }
    val out = ByteArray(len + records.size)
    System.arraycopy(q, 0, out, 0, qEnd)
    System.arraycopy(records, 0, out, qEnd, records.size)
    System.arraycopy(q, qEnd, out, qEnd + records.size, len - qEnd)
    Packets.put16(out, 2, 0x8180)
    Packets.put16(out, 6, count)
    return out
}

/** Adı işaret eden (0xC00C) bir A kaydı: TTL [ttl], adres [ip]. */
internal fun aRecord(ip: ByteArray, ttl: Int = 60): ByteArray {
    val r = ByteArray(16)
    r[0] = 0xC0.toByte(); r[1] = 0x0C
    Packets.put16(r, 2, 1); Packets.put16(r, 4, 1)
    Packets.put32(r, 6, ttl)
    Packets.put16(r, 10, 4)
    System.arraycopy(ip, 0, r, 12, 4)
    return r
}
