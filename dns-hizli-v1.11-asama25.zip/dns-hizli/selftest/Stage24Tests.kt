package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.Anim
import app.dnshizli.ui.Ease
import app.dnshizli.ui.VpnUi
import app.dnshizli.ui.Strings
import kotlin.math.abs

/** Aşama 24: animasyon motoru (yaylar, eğriler), stile özgü efektler, ses sentezi, ses/titreşim ayarları, profiller. */
fun runStage24Tests() {
    // ------------------------------------------------------------------ eğriler
    T.group("Animasyon eğrileri")
    run {
        val fs = listOf<Pair<String, (Float) -> Float>>(
            "outExpo" to Easing::outExpo, "outQuint" to Easing::outQuint, "smooth" to Easing::smooth,
            "outElastic" to Easing::outElastic, "outBounce" to Easing::outBounce, "bezier" to { t -> Easing.bezier(0.2f, 0f, 0f, 1f, t) },
        )
        for ((n, f) in fs) T.check("$n: 0'da 0, 1'de 1", abs(f(0f)) < 1e-4f && abs(f(1f) - 1f) < 1e-3f, "${f(0f)} ${f(1f)}")
        T.check("outExpo, outQuint, smooth, bezier: tekdüze artar", listOf<(Float) -> Float>(Easing::outExpo, Easing::outQuint, Easing::smooth, { t -> Easing.bezier(0.2f, 0f, 0f, 1f, t) }).all { f ->
            var prev = -1f; var ok = true
            for (i in 0..100) { val v = f(i / 100f); if (v < prev - 1e-4f) ok = false; prev = v }
            ok
        })
        T.check("outElastic hedefi aşar", (0..100).any { Easing.outElastic(it / 100f) > 1.02f })
        T.check("outBounce 0..1 aralığında kalır", (0..100).all { Easing.outBounce(it / 100f) in -0.001f..1.001f })
        T.check("bezier doğrusal eğri (0,0,1,1) kimlik gibidir", (0..20).all { abs(Easing.bezier(0.25f, 0.25f, 0.75f, 0.75f, it / 20f) - it / 20f) < 0.01f })
        T.check("eğriler aralık dışı girdide sonlu kalır", fs.all { (_, f) -> f(-3f).isFinite() && f(7f).isFinite() })
        // süreli kip: her eğri hedefte biter
        for (e in Ease.values()) {
            val a = Anim(0f); a.go(1f, 0.3f, e)
            var n = 0; while (a.step(0.016f) && n++ < 100) {}
            T.check("Ease.$e: süre sonunda tam hedefte", a.value == 1f && !a.active, "${a.value}")
        }
    }

    // ------------------------------------------------------------------ yay fiziği
    T.group("Yay animasyonu")
    run {
        fun settle(spec: SpringSpec, rate: Float = 1f): Triple<Float, Float, Boolean> {
            val a = Anim(0f); a.springTo(1f, spec, rate)
            var t = 0f; var peak = 0f
            while (a.step(0.016f) && t < 5f) { t += 0.016f; peak = maxOf(peak, a.value) }
            return Triple(t, peak, a.value == 1f && !a.active)
        }
        val specs = listOf("SNAP" to SpringSpec.SNAP, "SOFT" to SpringSpec.SOFT, "BOUNCY" to SpringSpec.BOUNCY, "JELLY" to SpringSpec.JELLY, "CRISP" to SpringSpec.CRISP, "DOWN" to SpringSpec.DOWN)
        for ((n, sp) in specs) {
            val (t, _, ok) = settle(sp)
            T.check("$n: 1,2 sn içinde oturur ve durur", ok && t < 1.2f, "t=$t")
        }
        T.check("SNAP neredeyse hiç aşmaz (<%8)", settle(SpringSpec.SNAP).second < 1.08f, "${settle(SpringSpec.SNAP).second}")
        T.check("JELLY belirgin aşar (>%15)", settle(SpringSpec.JELLY).second > 1.15f, "${settle(SpringSpec.JELLY).second}")
        T.check("JELLY, SNAP'ten daha çok aşar", settle(SpringSpec.JELLY).second > settle(SpringSpec.SNAP).second)
        T.check("hız çarpanı 2: daha çabuk oturur", settle(SpringSpec.BOUNCY, 2f).first < settle(SpringSpec.BOUNCY, 1f).first)
        T.check("hız çarpanı 0,6: daha geç oturur", settle(SpringSpec.SOFT, 0.6f).first > settle(SpringSpec.SOFT, 1f).first)
        // hedef yarıda değişince değer sıçramaz, hız korunur
        run {
            val a = Anim(0f); a.springTo(1f, SpringSpec.SOFT)
            repeat(8) { a.step(0.016f) }
            val before = a.value; val v = a.velocity
            a.springTo(0f, SpringSpec.SOFT)
            a.step(0.001f)
            T.check("yarıda yön değişimi: değer sıçramaz", abs(a.value - before) < 0.02f, "$before -> ${a.value}")
            T.check("yarıda yön değişimi: hız korunur (anında sıfırlanmaz)", v > 0.5f && a.velocity > 0f && a.velocity > v * 0.5f, "v=$v yeni=${a.velocity}")
            var n = 0; while (a.step(0.016f) && n++ < 400) {}
            T.check("yarıda yön değişimi: yeni hedefte oturur", a.value == 0f)
        }
        // kararlılık: dev dt ve sert yay
        run {
            val a = Anim(0f); a.springTo(1f, SpringSpec(5000f, 150f))
            a.step(10f)
            T.check("dev dt: değer sonlu ve makul", a.value.isFinite() && a.value in -0.5f..1.5f, "${a.value}")
            var n = 0; while (a.step(0.016f) && n++ < 400) {}
            T.check("sert yay da oturur", a.value == 1f)
        }
        run {
            val a = Anim(0.5f); a.springTo(1f, SpringSpec.SNAP)
            a.set(0.2f)
            T.check("set(): yayı keser", !a.active && a.value == 0.2f && a.velocity == 0f)
            a.springTo(1f, SpringSpec.SNAP); a.step(0.016f); a.go(0f, 0.2f)
            var n = 0; while (a.step(0.016f) && n++ < 100) {}
            T.check("go(): yayı keser, süreli kip işler", a.value == 0f)
            T.check("aynı hedefe tekrar springTo hareketi sıfırlamaz", run {
                val b = Anim(0f); b.springTo(1f, SpringSpec.SNAP); repeat(5) { b.step(0.016f) }
                val v = b.value; b.springTo(1f, SpringSpec.SNAP); abs(b.value - v) < 1e-6f
            })
            T.check("hedefte duran animasyon etkin değil (kare istemez)", run { val b = Anim(1f); b.springTo(1f, SpringSpec.SNAP); !b.active })
        }
        T.check("sönüm oranı: BOUNCY/JELLY <1, SNAP/CRISP ≥0,7", SpringSpec.BOUNCY.dampingRatio < 1f && SpringSpec.JELLY.dampingRatio < 0.6f && SpringSpec.SNAP.dampingRatio >= 0.7f && SpringSpec.CRISP.dampingRatio >= 0.8f)
    }

    // ------------------------------------------------------------------ stil kişilikleri ve efektler
    T.group("Stile özgü hareket ve efektler")
    run {
        val kinds = UiStyle.values().map { ArtFactory.create(it, Themes.aqua, 0.55f).motion.fx }
        T.check("her stilin kendi efekti var (6 farklı)", kinds.toSet().size == 6 && FxKind.NONE !in kinds, kinds.toString())
        T.check("Aqua halka, Aero damla, Metro dilim, Eco yaprak, Y2K kıvılcım, Aurora ışık", kinds == listOf(FxKind.RING, FxKind.DROP, FxKind.SLICE, FxKind.LEAF, FxKind.SPARK, FxKind.SWEEP), kinds.toString())
        val ms = UiStyle.values().map { ArtFactory.create(it, Themes.aqua, 0.55f).motion }
        T.check("Y2K en derin basar, Metro en sığ ve eğilir", ms[4].depth > ms[0].depth && ms[2].depth < ms[0].depth && ms[2].tilt > 0f && ms.filterIndexed { i, _ -> i != 2 }.all { it.tilt == 0f })
        T.check("Y2K bırakışı en sıçrak, Metro en sert", ms[4].up.dampingRatio < ms[1].up.dampingRatio && ms[2].up.dampingRatio > ms[1].up.dampingRatio)
        T.check("tüm yaylar kararlı (oran 0,2..2)", ms.all { m -> listOf(m.down, m.up, m.toggle).all { it.dampingRatio in 0.2f..2f } })
        // çizim: her tür her ilerlemede sonlu, dengeli, ve uçlarda çizmez
        for (k in FxKind.values()) {
            val g = CountingGfx(); var finiteOk = true; var drew = false
            for (i in 0..40) {
                val t = i / 40f
                g.reset()
                StyleFx.tap(k, g, Themes.aqua, 100f, 200f, t)
                if (g.bad > 0 || g.underflow || g.depth != 0) finiteOk = false
                if (t in 0.1f..0.9f && g.shapes > 0) drew = true
                g.reset()
                StyleFx.celebrate(k, g, Themes.aqua, 180f, 150f, 80f, t)
                if (g.bad > 0 || g.underflow || g.depth != 0) finiteOk = false
            }
            T.check("$k: çizim sonlu ve save/restore dengeli", finiteOk)
            if (k != FxKind.NONE) T.check("$k: ortada bir şey çizer", drew)
            val g0 = CountingGfx(); StyleFx.tap(k, g0, Themes.aqua, 1f, 1f, 0f); StyleFx.tap(k, g0, Themes.aqua, 1f, 1f, 1f)
            T.check("$k: başta ve sonda çizmez", g0.calls == 0)
        }
        // koyu temada da sağlam
        run {
            val g = CountingGfx()
            for (th in Themes.all) for (k in FxKind.values()) { StyleFx.celebrate(k, g, th, 50f, 50f, 70f, 0.5f) }
            T.check("tüm temalarda kutlama çizimi sonlu", g.bad == 0 && !g.underflow && g.depth == 0)
        }
    }

    // ------------------------------------------------------------------ ses sentezi
    T.group("Ses sentezi")
    run {
        val all = ArrayList<Triple<Sfx, Voice, ShortArray>>()
        for (v in Voice.values()) for (e in Sfx.values()) all.add(Triple(e, v, Synth.render(e, v)))
        T.check("6 tını × 9 olay = 54 ses üretildi", all.size == 54)
        T.check("hiçbiri boş değil, hepsi 0,9 sn'den kısa", all.all { it.third.size in 100..(Synth.RATE * 0.91f).toInt() })
        T.check("tepe genliği hedefte: arayüz ≈0,55, bağlantı ≈0,80", all.all { (e, _, a) ->
            val pk = a.maxOf { abs(it.toInt()) } / 32767f
            if (e.isConnection) pk in 0.74f..0.82f else pk in 0.50f..0.58f
        })
        T.check("uçlar sıfıra iner (tıkırtı yok)", all.all { (_, _, a) -> abs(a.first().toInt()) < 400 && abs(a.last().toInt()) < 400 })
        T.check("ortalama kayması (DC) küçük", all.all { (_, _, a) -> abs(a.map { it.toInt() }.average()) < 1500 })
        T.check("aynı girdi aynı sesi verir", Voice.values().all { v -> Synth.render(Sfx.CONNECT, v).contentEquals(Synth.render(Sfx.CONNECT, v)) })
        T.check("tınılar birbirinden farklı", Voice.values().map { Synth.render(Sfx.CONNECT, it).toList().hashCode() }.toSet().size == 6)
        T.check("olaylar birbirinden farklı", Sfx.values().map { Synth.render(it, Voice.GLASS).toList().hashCode() }.toSet().size == 9)
        T.check("bağlan sesi kes sesinden uzun ve iki ses farklı", Synth.render(Sfx.CONNECT, Voice.BUBBLE).size > Synth.render(Sfx.TAP, Voice.BUBBLE).size * 3)
        T.check("dokunuş sesi kısa (≤ 0,2 sn)", Voice.values().all { Synth.render(Sfx.TAP, it).size <= Synth.RATE * 0.2f })
        T.check("gerçekten ses var: RMS tepe/5'ten büyük", all.all { (_, _, a) ->
            val rms = Math.sqrt(a.map { it.toDouble() * it }.average()); rms > a.maxOf { abs(it.toInt()) } / 12.0
        })
        T.check("AUTO paketi stile göre 6 farklı tını seçer", UiStyle.values().map { Synth.voiceFor(SoundPack.AUTO, it) }.toSet().size == 6)
        T.check("sabit paketler stilden bağımsızdır", SoundPack.values().filter { it != SoundPack.AUTO }.all { p -> UiStyle.values().map { Synth.voiceFor(p, it) }.toSet().size == 1 })
        T.check("yalnızca arayüz olayları arayüz, 4'ü bağlantı", Sfx.values().count { it.isConnection } == 4 && Sfx.values().count { !it.isConnection } == 5)
    }

    // ------------------------------------------------------------------ ayarlar
    T.group("Ses ve hareket ayarları")
    run {
        val d = AppSettings()
        T.check("varsayılanlar: ses açık, 0,5, hız 1, efektler açık, modül hatırlama kapalı", d.soundOn && d.soundUi && d.soundConn && d.soundVolume == 0.5f && d.animSpeed == 1f && d.tapFx && d.celebrate && !d.rememberModules && !d.quietHours)
        val s = d.copy(soundOn = false, soundUi = false, soundConn = false, soundVolume = 0.25f, soundPack = SoundPack.GLASS, quietHours = true,
            quietRange = NightHours.H21_06, animSpeed = 1.35f, tapFx = false, celebrate = false, hapticLevel = HapticLevel.STRONG, rememberModules = true, lastDpi = true, lastAds = true)
        val back = SettingsCodec.decode(SettingsCodec.encode(s))
        T.check("kodlama gidiş-dönüş: tüm yeni alanlar korunur", back == s)
        T.check("bozuk değerler varsayılana/aralığa düşer", run {
            val m = HashMap<String, String?>(SettingsCodec.encode(d))
            m["soundVolume"] = "NaN"; m["animSpeed"] = "99"; m["soundPack"] = "x"; m["hapticLevel"] = "?"; m["quietRange"] = "99"
            val r = SettingsCodec.decode(m)
            r.soundVolume == 0.5f && r.animSpeed == AppSettings.SPEED_MAX && r.soundPack == SoundPack.AUTO && r.hapticLevel == HapticLevel.NORMAL && r.quietRange == NightHours.H23_08
        })
        T.check("animSpeed alt sınırı", SettingsCodec.decode(SettingsCodec.encode(d).toMutableMap().also { it["animSpeed"] = "0.01" }).animSpeed == AppSettings.SPEED_MIN)
        T.check("sessiz saatler: 23–08 aralığı", run { val q = d.copy(quietHours = true, quietRange = NightHours.H23_08); q.quietNow(23) && q.quietNow(3) && !q.quietNow(12) && !q.quietNow(8) })
        T.check("sessiz saat kapalıyken hiçbir saatte sessiz değil", (0..23).none { d.quietNow(it) })
        T.check("soundAllowed: anahtar, seviye 0 ve sessiz saat", d.soundAllowed(12) && !d.copy(soundOn = false).soundAllowed(12) && !d.copy(soundVolume = 0f).soundAllowed(12) && !d.copy(quietHours = true).soundAllowed(0))
        val ex = SettingsCodec.export(s)
        val imp = SettingsCodec.import(ex, AppSettings())
        T.check("dışa aktarma: ses ayarları gider, cihaza özgü son modül durumu gitmez", imp != null && imp.soundPack == SoundPack.GLASS && imp.animSpeed == 1.35f && imp.quietHours && !imp.lastDpi && !imp.lastAds)
    }

    // ------------------------------------------------------------------ profiller
    T.group("Profiller")
    run {
        T.check("4 profil, kimlikler farklı", Profiles.all.size == 4 && Profiles.all.map { it.id }.toSet().size == 4)
        T.check("her profilin sunucusu katalogda var", Profiles.all.all { Catalog.byId(it.serverId) != null })
        T.check("her profil şifreli yöntem destekleyen sunucu seçer", Profiles.all.all { p -> Catalog.byId(p.serverId)!!.let { it.dot != null || it.doh != null } })
        val base = AppSettings(theme = "ocean", lang = "tr", style = UiStyle.Y2K, notifyConnect = false)
        for (p in Profiles.all) {
            val r = p.applyTo(base)
            T.check("${p.id}: kişisel ayarlara dokunmaz", r.theme == "ocean" && r.lang == "tr" && r.style == UiStyle.Y2K && !r.notifyConnect)
            T.check("${p.id}: sunucu ve süzgeç uygulanır", r.lastServer == p.serverId && r.filterLevel == p.filter && r.cache == p.cache)
        }
        T.check("Tam koruma iki modülü de açar, Hız hiçbirini", Profiles.byId("full")!!.let { it.dpi && it.ads } && Profiles.byId("speed")!!.let { !it.dpi && !it.ads })
        T.check("Gizlilik sıkı şifreleme ister", Profiles.byId("privacy")!!.encryptionStrict)
        T.check("bilinmeyen kimlik null", Profiles.byId("x") == null && Profiles.byId(null) == null)
    }

    // ------------------------------------------------------------------ 12 dil
    T.group("Aşama 24: metinler (12 dil)")
    run {
        val saved = L.lang
        try {
            for (lang in Lang.values()) {
                L.set(lang)
                val n = lang.native
                val one = listOf(Strings.SOUND_MOTION, Strings.SEC_SOUND, Strings.SOUND_ON, Strings.SOUND_ON_NOTE, Strings.SOUND_UI, Strings.SOUND_UI_NOTE, Strings.SOUND_CONN, Strings.SOUND_CONN_NOTE,
                    Strings.SOUND_VOL, Strings.SOUND_PACK, Strings.SOUND_PACK_NOTE, Strings.SOUND_TEST, Strings.QUIET_HOURS, Strings.QUIET_NOTE, Strings.QUIET_RANGE, Strings.SEC_MOTION_FX,
                    Strings.ANIM_SPEED, Strings.TAP_FX, Strings.TAP_FX_NOTE, Strings.CELEBRATE, Strings.CELEBRATE_NOTE, Strings.HAPTIC_LEVEL, Strings.REMEMBER_MODS, Strings.REMEMBER_MODS_NOTE,
                    Strings.PROFILES, Strings.COPY_STATUS)
                T.check("$n: 26 yeni metin dolu ve makul uzunlukta", one.all { it.isNotBlank() && it.length in 3..120 }, one.filter { it.isBlank() || it.length !in 3..120 }.toString())
                T.check("$n: ses paketi 4 farklı kısa seçenek (≤ 9 harf)", Strings.OPT_PACK.size == 4 && Strings.OPT_PACK.toSet().size == 4 && Strings.OPT_PACK.all { it.length in 2..9 }, Strings.OPT_PACK.toString())
                T.check("$n: titreşim 3 farklı seçenek", Strings.OPT_HAPTIC.size == 3 && Strings.OPT_HAPTIC.toSet().size == 3 && Strings.OPT_HAPTIC.all { it.length in 2..10 })
                T.check("$n: 4 profil adı ve açıklaması", Strings.PROFILE_NAMES.size == 4 && Strings.PROFILE_NAMES.toSet().size == 4 && Strings.PROFILE_NOTES.size == 4 && Strings.PROFILE_NOTES.all { it.length in 15..90 } && Strings.PROFILE_NAMES.all { it.length in 3..18 })
                T.check("$n: profil uygulandı adı içerir", Strings.profileApplied("XyZ").contains("XyZ"))
                T.check("$n: yenilikler ilk maddesi ses ve hareketi anlatır", Strings.WHATS_NEW_ITEMS.first().let { it.length in 40..160 && it.contains("☰") })
            }
        } finally { L.set(saved) }
    }

    // ------------------------------------------------------------------ model
    T.group("Ses ve titreşim: model davranışı")
    run {
        fun on(rig: Rig, state: OrbState = OrbState.ON) = rig.model.onVpn(VpnUi(state = state, serverId = "cloudflare", sinceMs = rig.host.now))
        run {
            val rig = Rig()
            rig.model.sfx(Sfx.TAP)
            T.check("varsayılanlarda dokunuş sesi çalar, tını stile uygun (Aqua → kabarcık)", rig.host.sounds.size == 1 && rig.host.sounds[0].second == Voice.BUBBLE && rig.host.lastVolume == 0.5f)
            rig.model.update { it.copy(style = UiStyle.Y2K) }; rig.host.sounds.clear(); rig.model.sfx(Sfx.TAP)
            T.check("stil değişince tını değişir (Y2K → piksel)", rig.host.sounds.single().second == Voice.PIXEL)
            rig.model.update { it.copy(soundPack = SoundPack.CLASSIC) }; rig.host.sounds.clear(); rig.model.sfx(Sfx.TAP)
            T.check("sabit paket stile bakmaz (Klasik → klik)", rig.host.sounds.single().second == Voice.CLICK)
        }
        run {
            val rig = Rig()
            rig.model.update { it.copy(soundOn = false) }; rig.model.sfx(Sfx.TAP); rig.model.sfx(Sfx.CONNECT)
            T.check("ana anahtar kapalı: hiç ses yok", rig.host.sounds.isEmpty())
            rig.model.update { it.copy(soundOn = true, soundUi = false) }; rig.model.sfx(Sfx.TAP); rig.model.sfx(Sfx.TOGGLE_ON)
            T.check("dokunuş sesleri kapalı: arayüz olayı yok", rig.host.sounds.isEmpty())
            rig.model.sfx(Sfx.CONNECT)
            T.check("…ama bağlantı sesi çalar", rig.host.sounds.size == 1)
            rig.host.sounds.clear(); rig.model.update { it.copy(soundUi = true, soundConn = false) }
            rig.model.sfx(Sfx.ERROR); rig.model.sfx(Sfx.DONE); rig.model.sfx(Sfx.BACK)
            T.check("bağlantı sesleri kapalı: yalnızca arayüz sesi çalar", rig.host.sounds.map { it.first } == listOf(Sfx.BACK))
            rig.host.sounds.clear(); rig.model.update { it.copy(soundConn = true, soundVolume = 0f) }; rig.model.sfx(Sfx.CONNECT)
            T.check("ses seviyesi 0: çalmaz", rig.host.sounds.isEmpty())
        }
        run {
            val rig = Rig()
            rig.model.update { it.copy(quietHours = true, quietRange = NightHours.H23_08) }
            rig.host.localHourValue = 2; rig.model.sfx(Sfx.CONNECT); rig.model.hapticEvent(Sfx.CONNECT); rig.model.tapFeedback(true, Sfx.TAP)
            T.check("sessiz saatte ses, desen ve dokunuş titreşimi yok", rig.host.sounds.isEmpty() && rig.host.patterns.isEmpty() && rig.host.haptics == 0)
            rig.host.localHourValue = 12; rig.model.sfx(Sfx.CONNECT); rig.model.hapticEvent(Sfx.CONNECT)
            T.check("sessiz saat dışında çalışır", rig.host.sounds.size == 1 && rig.host.patterns.size == 1)
        }
        run {
            val rig = Rig()
            fun pat(e: Sfx, l: HapticLevel): Triple<Int, Int, Boolean> {
                rig.model.update { it.copy(hapticLevel = l) }; rig.host.patterns.clear(); rig.model.hapticEvent(e); return rig.host.patterns.single()
            }
            T.check("normal: bağlanma 2, kesme 1, hata 3 vuruş", pat(Sfx.CONNECT, HapticLevel.NORMAL).first == 2 && pat(Sfx.DISCONNECT, HapticLevel.NORMAL).first == 1 && pat(Sfx.ERROR, HapticLevel.NORMAL).first == 3)
            T.check("hafif: hepsi tek vuruş, güçlü değil", listOf(Sfx.CONNECT, Sfx.ERROR, Sfx.DISCONNECT).all { pat(it, HapticLevel.LIGHT).let { p -> p.first == 1 && !p.third } })
            T.check("güçlü: bir vuruş fazla ve güçlü", pat(Sfx.CONNECT, HapticLevel.STRONG).let { it.first == 3 && it.third } && pat(Sfx.ERROR, HapticLevel.STRONG).first == 4)
            rig.model.update { it.copy(haptics = false) }; rig.host.patterns.clear(); rig.model.hapticEvent(Sfx.ERROR)
            T.check("titreşim kapalıyken desen de yok", rig.host.patterns.isEmpty())
            rig.model.update { it.copy(haptics = true, hapticLevel = HapticLevel.LIGHT) }; rig.host.haptics = 0; rig.host.strongHaptics = 0
            rig.model.tapFeedback(true, null)
            T.check("hafif seviyede güçlü dokunuş hafife iner", rig.host.haptics == 1 && rig.host.strongHaptics == 0)
        }
        run {
            val rig = Rig()
            on(rig, OrbState.ON)                                   // ilk bildirim: temel
            T.check("açılışta zaten bağlı: ses/kutlama/titreşim yok", rig.host.sounds.isEmpty() && rig.model.celebrateSeq == 0 && rig.host.patterns.isEmpty())
            on(rig, OrbState.OFF)
            T.check("bağlı → kapalı: kesme sesi", rig.host.sounds.map { it.first } == listOf(Sfx.DISCONNECT) && rig.host.patterns.size == 1)
            on(rig, OrbState.CONNECTING)
            T.check("bağlanıyor aşamasında ses yok", rig.host.sounds.size == 1)
            on(rig, OrbState.ON)
            T.check("bağlandı: bağlanma sesi, 2 vuruş, kutlama sayacı artar", rig.host.sounds.last().first == Sfx.CONNECT && rig.host.patterns.last().first == 2 && rig.model.celebrateSeq == 1)
            on(rig, OrbState.ON)
            T.check("aynı durum tekrarı ses çalmaz", rig.host.sounds.size == 2 && rig.model.celebrateSeq == 1)
            on(rig, OrbState.CONNECTING); on(rig, OrbState.ON)
            T.check("yeniden bağlanma (ağ değişimi) bağlandı sesi + kutlama verir; kesme sesi vermez", rig.host.sounds.map { it.first }.count { it == Sfx.DISCONNECT } == 1 && rig.model.celebrateSeq == 2)
            on(rig, OrbState.ERROR)
            T.check("hata: hata sesi ve 3 vuruş", rig.host.sounds.last().first == Sfx.ERROR && rig.host.patterns.last().first == 3)
            rig.model.update { it.copy(celebrate = false) }; on(rig, OrbState.ON)
            T.check("kutlama kapalı: sayaç artmaz ama ses çalar", rig.model.celebrateSeq == 2 && rig.host.sounds.last().first == Sfx.CONNECT)
        }
        run {
            val rig = Rig()
            rig.model.copyStatusSummary()
            T.check("durum özeti panoya kopyalanır ve uygulama adını içerir", rig.host.clipboard?.contains(Strings.APP) == true && rig.host.clipboard!!.length < 200)
        }
        run {
            val rig = Rig()
            rig.model.previewSound()
            T.check("önizleme bağlanma sesini ve desenini çalar", rig.host.sounds.single().first == Sfx.CONNECT && rig.host.patterns.size == 1)
        }
        run {
            val rig = Rig()
            rig.model.update { it.copy(onboarded = true) }
            rig.model.applyProfile("full")
            T.check("profil: ayarlar, modüller ve bağlanma birlikte", rig.model.settings.lastServer == "adguard" && rig.model.settings.filterLevel == FilterLevel.MEDIUM && rig.host.lastModules == (true to true) && rig.host.calls.contains("connect:adguard"))
            val rig2 = Rig(); rig2.model.update { it.copy(onboarded = true) }
            rig2.model.onVpn(VpnUi(state = OrbState.ON, serverId = "cloudflare", sinceMs = rig2.host.now)); rig2.host.calls.clear()
            rig2.model.applyProfile("privacy")
            T.check("profil: bağlıyken sunucu kesintisiz değişir ve Reklam+ açılır", rig2.host.calls.contains("connect:quad9") && rig2.host.lastModules == (false to true) && rig2.model.settings.strictEncryption)
            val rig3 = Rig(); rig3.model.applyProfile("nope")
            T.check("bilinmeyen profil hiçbir şey yapmaz", rig3.host.calls.isEmpty())
        }
        run {
            val rig = Rig()
            rig.model.update { it.copy(onboarded = true) }
            rig.model.onVpn(VpnUi(state = OrbState.ON, serverId = "cloudflare", sinceMs = rig.host.now))
            rig.model.toggleDpi()
            T.check("modül açma: bir kez 'açıldı' sesi, hatırlanan durum DPI", rig.host.sounds.map { it.first } == listOf(Sfx.TOGGLE_ON) && rig.model.settings.lastDpi && !rig.model.settings.lastAds)
            rig.model.toggleDpi()
            T.check("modül kapama: 'kapandı' sesi, hatırlanan durum kapalı", rig.host.sounds.last().first == Sfx.TOGGLE_OFF && !rig.model.settings.lastDpi)
        }
        run {
            val rig = Rig()
            rig.model.update { it.copy(onboarded = true, rememberModules = true, lastDpi = true, lastAds = false) }
            rig.model.onVpn(VpnUi(state = OrbState.OFF))
            rig.host.calls.clear()
            rig.model.onVpn(VpnUi(state = OrbState.ON, serverId = "cloudflare", sinceMs = rig.host.now))
            T.check("modülleri hatırla: bağlanınca DPI son durumunda açılır", rig.host.lastModules == (true to false))
            val rig2 = Rig()
            rig2.model.update { it.copy(onboarded = true, rememberModules = false, lastDpi = true) }
            rig2.model.onVpn(VpnUi(state = OrbState.OFF)); rig2.model.onVpn(VpnUi(state = OrbState.ON, serverId = "cloudflare", sinceMs = rig2.host.now))
            T.check("kapalıyken modüllere dokunmaz", rig2.host.lastModules == null)
            val rig3 = Rig()
            rig3.model.update { it.copy(onboarded = true, rememberModules = true, lastDpi = true) }
            rig3.model.onVpn(VpnUi(state = OrbState.OFF)); rig3.model.onVpn(VpnUi(state = OrbState.ON, serverId = "cloudflare", sinceMs = rig3.host.now, gwDpi = true, gwActive = true))
            T.check("modül zaten açıksa tekrar istemez", rig3.host.lastModules == null)
        }
    }

    // ------------------------------------------------------------------ arayüz
    T.group("Ses ve hareket: arayüz")
    run {
        val rig = Rig()
        rig.model.update { it.copy(tapFx = true, animSpeed = 1f) }
        rig.settle()
        val noFx = Rig(); noFx.model.update { it.copy(tapFx = false) }; noFx.settle()
        fun shapesAfterTap(r: Rig): Int {
            val g = CountingGfx()
            r.down(180f, 300f); r.up(180f, 300f)
            r.advance(80)
            g.reset(); r.scene.draw(g)
            return g.shapes
        }
        // boş bir noktaya dokunuş etki yaratmaz; bir düğmeye dokunuş yaratır
        val menuBtn = rig.model.let { 0 }
        T.check("sahne dokunma efekti durumunu sorunsuz taşır (çizim sonlu, dengeli)", run {
            val g = CountingGfx(); rig.scene.draw(g); g.bad == 0 && !g.underflow && g.depth == 0
        })
        T.check("yeni ayarlarla sahne kare planlar ve sonunda durağanlaşır", run {
            rig.advance(1500); rig.tick1() <= 33L || rig.lastDelay == -1L
        })
    }
    run {
        // Ses ve hareket sayfası menüden açılır ve satırları çalışır
        val rig = Rig()
        rig.model.update { it.copy(onboarded = true) }
        rig.tapText(Strings.MENU, exact = true, settleMs = 900)
        rig.tapText(Strings.SOUND_MOTION, exact = true, settleMs = 900)
        val items = rig.scene.a11yItems()
        T.check("sayfa açıldı: başlık 'başlık' rolünde", items.any { it.info.role == app.dnshizli.ui.Role.HEADING && it.info.label == Strings.SOUND_MOTION })
        T.check("ana ses anahtarı var ve açık", items.any { it.info.label.startsWith(Strings.SOUND_ON) && it.info.checked == true })
        rig.tapText(Strings.SOUND_ON, exact = false, settleMs = 500)
        T.check("anahtara dokunmak sesi kapatır", !rig.model.settings.soundOn)
    }
    run {
        // Anahtar bir yay ile hareket eder ve 0..1 dışına taşmaz
        val rig = Rig()
        rig.tapText(Strings.MENU, exact = true, settleMs = 900)
        rig.tapText(Strings.SOUND_MOTION, exact = true, settleMs = 900)
        rig.tapText(Strings.TAP_FX, exact = false, settleMs = 60)
        val g = CountingGfx(); var ok = true
        repeat(40) { rig.advance(16); g.reset(); rig.scene.draw(g); if (g.bad > 0 || g.underflow || g.depth != 0) ok = false }
        T.check("anahtar animasyonu sırasında çizim sonlu ve dengeli", ok)
        rig.settle()
        T.check("animasyon bitince kare istenmez", run { rig.tick1(); rig.tick1(); rig.lastDelay == -1L || rig.lastDelay == 33L })
    }
    run {
        // Hız ayarı: sayfa geçişi hızlı ayarda daha az karede biter, yavaşta daha çok karede
        fun frames(speed: Float): Int {
            val rig = Rig(); rig.model.update { it.copy(animSpeed = speed, bubbles = BubbleLevel.OFF) }; rig.settle()
            rig.tapText(Strings.MENU, exact = true, settleMs = 0)
            var n = 0
            while (n < 400) { rig.tick1(); if (rig.lastDelay == -1L) break; n++ }
            return n
        }
        val slow = frames(0.6f); val normal = frames(1f); val fast = frames(1.6f)
        T.check("animasyon hızı: yavaş > normal > hızlı (kare sayısı)", slow > normal && normal > fast, "$slow $normal $fast")
    }
    run {
        // Efekt kapalıyken dokunuş sahneye hiçbir şey eklemez; açıkken ekler
        fun shapes(fx: Boolean, style: UiStyle): Int {
            val rig = Rig(); rig.model.update { it.copy(tapFx = fx, style = style, bubbles = BubbleLevel.OFF) }; rig.settle()
            rig.tapText(Strings.MENU, exact = true, settleMs = 0)
            rig.advance(96, 16)
            val g = CountingGfx(); rig.scene.draw(g); return g.shapes
        }
        for (st in UiStyle.values()) T.check("${st.label}: dokunma efekti açıkken daha çok şekil çizilir", shapes(true, st) > shapes(false, st), "${shapes(true, st)} / ${shapes(false, st)}")
    }
    T.group("Modül hata mesajı ve kapatma")
    run {
        val rig = Rig(); rig.model.update { it.copy(onboarded = true) }
        rig.model.onVpn(VpnUi(state = OrbState.ON, serverId = "cloudflare", sinceMs = rig.host.now))
        rig.host.moduleFail = true; rig.host.sounds.clear()
        rig.model.toggleDpi()
        T.check("modül açılamayınca sade mesaj çıkar ve istek geri alınır", rig.model.toast?.text == Strings.MOD_FAILED && !rig.model.dpiOn && rig.host.sounds.any { it.first == Sfx.ERROR })
        rig.host.moduleFail = false
        rig.model.onVpn(VpnUi(state = OrbState.ON, serverId = "cloudflare", sinceMs = rig.host.now, gwDpi = true, gwActive = true))
        rig.host.calls.clear()
        rig.model.toggleDpi()
        T.check("modül kapanınca DNS bağlantısı kesilmez, yalnız modül isteği gider", !rig.host.calls.contains("disconnect") && !rig.host.calls.contains("disconnectDns") && rig.host.lastModules == (false to false) && rig.model.vpn.state == OrbState.ON)
    }
    T.group("Aşama 24: modül hata metni (12 dil)")
    run { val keep = L.lang; try { for (lang in Lang.values()) { L.set(lang); T.check("${lang.native}: MOD_FAILED dolu", Strings.MOD_FAILED.length in 20..100) } } finally { L.set(keep) } }
}
