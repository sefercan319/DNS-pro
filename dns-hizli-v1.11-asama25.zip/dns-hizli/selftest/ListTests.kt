package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

/** Çizimleri sayan, yalnızca kaydırma çubuğu biçimindeki (3 dp genişlik, 1,5 yarıçap) yuvarlak dikdörtgenleri kaydeden çizici. */
private class BarProbe(private val inner: CountingGfx = CountingGfx()) : Gfx by inner {
    val bars = ArrayList<FloatArray>()
    override fun roundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) {
        if (rad == 1.5f && Math.abs((r - l) - 3f) < 0.01f) bars.add(floatArrayOf(l, t, r, b))
        inner.roundRect(l, t, r, b, rad)
    }
}

private fun bars(r: Rig): List<FloatArray> = BarProbe().also { r.scene.draw(it) }.bars

fun runListTests() {
    T.group("Sunucu listesi: ilk 8 + Tümünü göster")
    run {
        val rig = Rig(Rig.base(), 360, 1000)
        val total = rig.model.visibleServers().size
        T.check("varsayılan listede en az 11 sunucu var (kısaltma gerekir)", total >= AppModel.LIST_LIMIT + AppModel.LIST_MIN_HIDDEN, total.toString())
        T.check("kapalıyken ilk 8 gösterilir, başlıktaki sayı tümünü söyler",
            rig.model.shownServers().size == AppModel.LIST_LIMIT && rig.model.shownServers() == rig.model.visibleServers().take(AppModel.LIST_LIMIT) &&
                rig.find(Strings.serversCount(total), exact = false) != null)
        val btn = Strings.showAllServers(total - AppModel.LIST_LIMIT)
        T.check("kapalıyken düğme metni kalan sayıyı yazar", btn.contains((total - AppModel.LIST_LIMIT).toString()) && rig.model.listCollapsible())
        val add = rig.find(Strings.CUSTOM_ADD, exact = true)
        val first = rig.items().firstOrNull { it.info.role == Role.BUTTON && it.info.label.contains(", ") && it.info.longClick }
        T.check("Özel DNS ekle düğmesi sunucu satırlarının üstünde", add != null && first != null && add.t < first.t, "${add?.t} / ${first?.t}")

        rig.model.toggleList(); rig.settle(700)
        T.check("açınca bütün sunucular gelir ve düğme Daha az göster olur",
            rig.model.shownServers().size == total && rig.model.listExpanded && (rig.find(Strings.SHOW_LESS, exact = true) != null || rig.model.listCollapsible()))
        rig.model.toggleList(); rig.settle(700)
        T.check("tekrar kapanır", !rig.model.listExpanded && rig.model.shownServers().size == AppModel.LIST_LIMIT)
    }
    run {
        val rig = Rig(Rig.base(), 360, 1000)
        val page = rig.scene.currentPage as ScrollPage
        // düğmeye gerçekten dokunarak aç/kapat
        repeat(6) { rig.fling(180f, 700f, 200f, 5); rig.advance(700) }
        val showAll = rig.model.visibleServers().size - AppModel.LIST_LIMIT
        rig.tapText(Strings.showAllServers(showAll), exact = true, settleMs = 900)
        T.check("düğmeye dokununca liste açılır", rig.model.listExpanded && rig.model.shownServers().size == rig.model.visibleServers().size)
        repeat(8) { rig.fling(180f, 700f, 200f, 5); rig.advance(700) }
        rig.tapText(Strings.SHOW_LESS, exact = true, settleMs = 900)
        T.check("Daha az göster ile kapanır ve sayfa içerik sınırında kalır", !rig.model.listExpanded && page.scrollOffset >= 0f)
        rig.fling(180f, 700f, 200f, 5); rig.advance(1500)
        T.check("kısaltılmış listede Tümünü göster yine görünür", rig.find(Strings.showAllServers(showAll), exact = true) != null)
    }
    run {
        val rig = Rig(Rig.base(), 360, 1000)
        var ok = true
        val bad = ArrayList<String>()
        for (f in Filter.values()) {
            rig.model.setFilter(f); rig.settle(300)
            val n = rig.model.visibleServers().size
            val sh = rig.model.shownServers().size
            val want = if (n >= AppModel.LIST_LIMIT + AppModel.LIST_MIN_HIDDEN) AppModel.LIST_LIMIT else n
            if (sh != want || rig.model.listCollapsible() != (n >= AppModel.LIST_LIMIT + AppModel.LIST_MIN_HIDDEN)) { ok = false; bad.add("${f.name}: $n/$sh") }
        }
        T.check("her süzgeçte kural aynı: 11 ve üstü kısalır, altı olduğu gibi", ok, bad.toString())
        rig.model.setFilter(Filter.FAVORITES); rig.settle(500)
        T.check("kısa listede düğme görünmez", rig.find("Tümünü göster", exact = false) == null && rig.find(Strings.SHOW_LESS, exact = true) == null)
    }
    run {
        // arama sonucu da aynı kurala uyar
        val rig = Rig(Rig.base(), 360, 1000)
        rig.model.setQuery("cloud"); rig.settle(500)
        T.check("az sonuç varsa düğme yok, sonuçların hepsi görünür", rig.model.shownServers() == rig.model.visibleServers() && !rig.model.listCollapsible())
    }
    T.group("Sunucu listesi: metinler (12 dil)")
    val saved = L.lang
    try {
        for (lang in Lang.values()) {
            L.set(lang)
            val a = Strings.showAllServers(24); val b = Strings.SHOW_LESS
            T.check("${lang.code}: düğme metinleri sayıyı taşır, kısa ve farklı", "24" in a && a.length in 8..34 && b.length in 4..30 && a != b && "{" !in a + b, "$a | $b")
        }
    } finally { L.set(saved) }

    T.group("Kaydırma çubuğu")
    run {
        val rig = Rig(Rig.base(), 360, 780)
        rig.settle(1500)
        T.check("kaymıyorken çubuk görünmez", bars(rig).isEmpty())
        rig.drag(180f, 600f, 300f, 8)
        val b1 = bars(rig)
        T.check("kayarken ince çubuk belirir (sağ kenarda, 3 dp)", b1.size == 1 && b1[0][0] > 340f && b1[0][2] < 358f, b1.joinToString { it.toList().toString() })
        val top = rig.scene.env.insetTop + M.HEADER_H
        T.check("çubuk başlığın altında başlar ve ekranın içinde kalır", b1.isNotEmpty() && b1[0][1] >= top - 1f && b1[0][3] <= 780f - 24f, b1.joinToString { it.toList().toString() })
        T.check("çubuk en az 36 dp uzunlukta", b1.isNotEmpty() && b1[0][3] - b1[0][1] >= 35.9f)
        val y1 = b1[0][1]
        repeat(8) { rig.fling(180f, 700f, 200f, 5); rig.advance(600) }
        rig.settle(2500)
        rig.drag(180f, 400f, 440f, 3)
        val b2 = bars(rig)
        T.check("sona doğru kaydırdıkça çubuk aşağı iner ve altta durur", b2.isNotEmpty() && b2[0][1] > y1 && b2[0][3] <= 780f - 24f + 0.5f, "${y1} -> ${b2.firstOrNull()?.toList()}")
        rig.settle(2500)
        T.check("kaydırma bitince çubuk söner", bars(rig).isEmpty())
    }
    run {
        val a = Rig(Rig.base(), 360, 780); a.settle(1200)
        val b = Rig(Rig.base(), 360, 780); b.settle(1200)
        b.model.toggleList(); b.settle(800)
        a.drag(180f, 600f, 560f, 3); b.drag(180f, 600f, 560f, 3)
        val la = bars(a).firstOrNull(); val lb = bars(b).firstOrNull()
        T.check("içerik uzadıkça çubuk kısalır (oransal uzunluk)", la != null && lb != null && (lb[3] - lb[1]) < (la[3] - la[1]), "${la?.toList()} / ${lb?.toList()}")
    }
    run {
        val s = Rig(Rig.base(), 360, 780)
        s.scene.openSection(Section.DATA); s.settle(1200)
        s.drag(180f, 600f, 300f, 4)
        T.check("sığan sayfada çubuk çıkmaz", bars(s).isEmpty())
    }
    run {
        val r = Rig(Rig.base().copy(motion = Motion.OFF), 360, 780)
        r.settle(1000); r.drag(180f, 600f, 300f, 6)
        val shown = bars(r).isNotEmpty()
        r.settle(1200)
        T.check("hareket kapalıyken çubuk yine belirir ve beklemeden söner", shown && bars(r).isEmpty())
    }
}
