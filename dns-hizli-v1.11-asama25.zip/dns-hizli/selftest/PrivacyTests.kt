package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * IPv4 + IPv6 ve gizlilik testleri: adres ayrıştırma, hedef sırası, IPv6 tünel paketleri (sağlama toplamı, parçalama),
 * sorgu temizliği (ECS / çerez / cihaz kimliği atılır, dolgu), çift aile bağlantısı, sertifika hatasında hızlı sonuç.
 *
 * Not: bu ortamda IPv6 ağ yığını yoktur; IPv6 TÜNEL paketleri baytlarla sınanır, IPv6 SOKETLERİ (::1) sınanamaz.
 */

private val loop: InetAddress = InetAddress.getLoopbackAddress()
private val CL6: ByteArray = Ip.parse6(SelfTest.CLIENT_ADDR6)!!
private val SV6: ByteArray = Ip.parse6(SelfTest.FAKE_DNS6)!!

fun runPrivacyTests() {
    println("\nIPv4 + IPv6 ve gizlilik\n")
    testIpParsing()
    testV6Packets()
    testTargets()
    testCatalogV6()
    testCustomV6()
    testSanitize()
    testPlainForwarder()
    testSecurePrivacy()
    testDualFamily()
    testFastFailure()
    testSelfTestV6()
    testIpModeSetting()
}

// =================================================================================== yardımcılar

private fun contains(hay: ByteArray, needle: ByteArray): Boolean {
    if (needle.isEmpty() || hay.size < needle.size) return false
    outer@ for (i in 0..hay.size - needle.size) {
        for (j in needle.indices) if (hay[i + j] != needle[j]) continue@outer
        return true
    }
    return false
}

/** Adı atlar: etiketler, kök (0) ya da işaretçi (2 bayt). Sonraki konumu döner. */
private fun skip(m: ByteArray, p0: Int): Int {
    var p = p0
    while (true) {
        val l = m[p].toInt() and 0xFF
        if (l == 0) return p + 1
        if ((l and 0xC0) == 0xC0) return p + 2
        p += 1 + l
    }
}

private class Edns(val payload: Int, val ttl: Int, val options: List<Pair<Int, ByteArray>>)

/** Testin kendi DNS okuyucusu (uygulamanın kodundan bağımsız). */
private class Msg(val m: ByteArray, val off: Int = 0, val len: Int = m.size - off) {
    val qd = Packets.u16(m, off + 4)
    val an = Packets.u16(m, off + 6)
    val ns = Packets.u16(m, off + 8)
    val ar = Packets.u16(m, off + 10)
    var qEnd = 0
    var edns: Edns? = null
    var optCount = 0
    var otherAdditional = 0
    val answerIps = ArrayList<String>()

    init {
        var p = off + 12
        for (i in 0 until qd) { p = skip(m, p) + 4 }
        qEnd = p - off
        for (i in 0 until an + ns + ar) {
            p = skip(m, p)
            val type = Packets.u16(m, p)
            val rdLen = Packets.u16(m, p + 8)
            val inAdd = i >= an + ns
            if (type == 41 && inAdd) {
                optCount++
                val opts = ArrayList<Pair<Int, ByteArray>>()
                var q = p + 10
                val end = p + 10 + rdLen
                while (q + 4 <= end) {
                    val code = Packets.u16(m, q)
                    val l = Packets.u16(m, q + 2)
                    opts.add(code to m.copyOfRange(q + 4, q + 4 + l))
                    q += 4 + l
                }
                edns = Edns(Packets.u16(m, p + 2), Packets.i32(m, p + 4), opts)
            } else if (inAdd) otherAdditional++
            if (type == 1 && i < an && rdLen == 4) {
                answerIps.add("${m[p + 10].toInt() and 0xFF}.${m[p + 11].toInt() and 0xFF}.${m[p + 12].toInt() and 0xFF}.${m[p + 13].toInt() and 0xFF}")
            }
            p += 10 + rdLen
        }
    }
}

private val ECS_DATA = byteArrayOf(0, 1, 24, 0, 192.toByte(), 0, 2)                       // 192.0.2.0/24
private val COOKIE = byteArrayOf(0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x7A)
private val DEVICE_ID = "device-1234-abcd".toByteArray()

/** OPT'li sorgu: [payload], [flags] (üst 16 bitin alt yarısı: DO = 0x8000), seçenekler; isteğe bağlı OPT dışı ek kayıt. */
private fun optQuery(
    id: Int, name: String = "www.example.com", payload: Int = 4096, flags: Int = 0x8000,
    opts: List<Pair<Int, ByteArray>> = listOf(8 to ECS_DATA, 10 to COOKIE, 65001 to DEVICE_ID), extraRr: Boolean = false,
): ByteArray {
    val base = Dns.buildQuery(id, name)
    val rd = ByteArrayOutputStream()
    for ((c, d) in opts) { rd.write(c shr 8); rd.write(c and 0xFF); rd.write(d.size shr 8); rd.write(d.size and 0xFF); rd.write(d) }
    val extra = if (extraRr) byteArrayOf(0, 0, 99, 0, 1, 0, 0, 0, 0, 0, 3, 7, 8, 9) else ByteArray(0)   // tür 99, 3 bayt veri
    val opt = ByteArray(11 + rd.size())
    Packets.put16(opt, 1, 41)
    Packets.put16(opt, 3, payload)
    Packets.put32(opt, 5, flags)
    Packets.put16(opt, 9, rd.size())
    System.arraycopy(rd.toByteArray(), 0, opt, 11, rd.size())
    val out = base + extra + opt
    Packets.put16(out, 10, (if (extraRr) 1 else 0) + 1)
    return out
}

private fun v4Packet(dns: ByteArray, srcPort: Int): ByteArray {
    val b = ByteArray(Packets.HDR + dns.size)
    System.arraycopy(dns, 0, b, Packets.HDR, dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size)
    Packets.put16(b, 6, 0x4000)
    b[8] = 64
    b[9] = 17
    Packets.put32(b, 12, Packets.ip(10, 111, 222, 1))
    Packets.put32(b, 16, Packets.ip(10, 111, 222, 2))
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, srcPort)
    Packets.put16(b, 22, 53)
    Packets.put16(b, 24, 8 + dns.size)
    return b
}

private fun v6Packet(dns: ByteArray, srcPort: Int): ByteArray {
    val b = ByteArray(Packets.HDR6 + dns.size)
    System.arraycopy(dns, 0, b, Packets.HDR6, dns.size)
    Packets.writeHeaders6(b, CL6, SV6, srcPort, 53, dns.size)
    return b
}

/** IPv6 UDP paketinin sağlama toplamı doğru mu (bağımsız başvuru uygulamasıyla; sorgu ya da cevap)? */
private fun udp6Ok(p: ByteArray): Boolean {
    val src = p.copyOfRange(8, 24)
    val dst = p.copyOfRange(24, 40)
    val udp = p.copyOfRange(40, p.size)
    val stored = Packets.u16(udp, 6)
    udp[6] = 0; udp[7] = 0
    return stored != 0 && stored == refUdp6(src, dst, udp)
}

/** Cevap paketi doğru mu? IPv6: başlıklar, adresler, portlar, sağlama toplamı. Sorun yoksa null. DNS verisini [dnsOut]'a koyar. */
private fun checkV6Reply(r: ByteArray, port: Int, id: Int): String? {
    if ((r[0].toInt() and 0xF0) != 0x60) return "IPv6 değil"
    if ((r[6].toInt() and 0xFF) != 17) return "sonraki başlık ${r[6]}"
    if (!r.copyOfRange(8, 24).contentEquals(SV6)) return "kaynak adres"
    if (!r.copyOfRange(24, 40).contentEquals(CL6)) return "hedef adres"
    if (Packets.u16(r, 4) != r.size - Packets.IP6_HDR) return "yük uzunluğu"
    if (Packets.u16(r, 40) != 53 || Packets.u16(r, 42) != port) return "portlar"
    if (!udp6Ok(r)) return "UDP sağlama toplamı"
    if (Packets.u16(r, Packets.HDR6) != id) return "kimlik"
    return null
}

private fun checkV4Reply(r: ByteArray, port: Int, id: Int): String? {
    if ((r[0].toInt() and 0xF0) != 0x40) return "IPv4 değil"
    if (Packets.checksum(r, 0, 20) != 0) return "IP sağlama toplamı"
    if (Packets.u16(r, 20) != 53 || Packets.u16(r, 22) != port) return "portlar"
    if (Packets.u16(r, 28) != id) return "kimlik"
    return null
}

/** Gelen sorguları kaydeden, cevaba sorgunun geri kalanını (OPT dahil) yansıtan UDP DNS sunucusu. */
private class CaptureDns : AutoCloseable {
    val socket = DatagramSocket(0, loop)
    val received = CopyOnWriteArrayList<ByteArray>()
    val addr: InetSocketAddress get() = InetSocketAddress(loop, socket.localPort)

    init {
        Thread {
            val buf = ByteArray(2048)
            val p = DatagramPacket(buf, buf.size)
            while (!socket.isClosed) {
                try { p.length = buf.size; socket.receive(p) } catch (_: Exception) { return@Thread }
                received.add(buf.copyOf(p.length))
                val r = buildAnswer(buf, p.length, aRecord(byteArrayOf(1, 2, 3, 4), 60), 1)
                try { socket.send(DatagramPacket(r, r.size, p.socketAddress)) } catch (_: Exception) { return@Thread }
            }
        }.apply { isDaemon = true; start() }
    }

    override fun close() = socket.close()
}

private class PlainHarness(upstreams: List<InetSocketAddress>) : AutoCloseable {
    val tun = LinkedBlockingQueue<ByteArray>()
    val fw = DnsForwarder(
        upstreams = upstreams, writeToTun = { b, off, len -> tun.add(b.copyOfRange(off, off + len)) },
        sweepMs = 50, cacheEntries = 64,
    ).also { it.start() }

    fun send(p: ByteArray) = fw.onPacket(p, p.size)
    fun reply(ms: Long = 2500): ByteArray? = tun.poll(ms, TimeUnit.MILLISECONDS)
    override fun close() = fw.close()
}

// =================================================================================== testler

private fun testIpParsing() {
    T.group("IP adresi ayrıştırma (IPv4 ve IPv6)")
    T.check("IPv4 geçerli", Ip.parse4("1.2.3.4")?.toList() == listOf<Byte>(1, 2, 3, 4) && Ip.parse4("255.255.255.255") != null)
    T.check("IPv4 geçersiz", listOf("1.2.3", "1.2.3.4.5", "256.1.1.1", "01.2.3.4", "1.2.3.", " 1.2.3.4", "a.b.c.d", "").none { Ip.parse4(it) != null })
    val full = Ip.parse6("2001:0db8:0000:0000:0000:0000:0000:0001")
    T.check("IPv6: tam ve kısaltılmış aynı adres", full != null && full.contentEquals(Ip.parse6("2001:db8::1")!!))
    T.check("IPv6: '::' ve '::1'", Ip.parse6("::")!!.all { it == 0.toByte() } && Ip.parse6("::1")!!.last() == 1.toByte())
    T.check("IPv6: sondaki IPv4", Ip.parse6("::ffff:1.2.3.4")!!.toList().takeLast(4) == listOf<Byte>(1, 2, 3, 4))
    T.check("IPv6 geçersiz", listOf("", ":", ":::", "1::2::3", "12345::1", "2001:db8", "[::1]", "::1%eth0", "g::1", "1:2:3:4:5:6:7:8:9", "1:2:3:4:5:6:7::8", " ::1").none { Ip.parse6(it) != null },
        listOf("", ":", ":::", "1::2::3", "12345::1", "2001:db8", "[::1]", "::1%eth0", "g::1", "1:2:3:4:5:6:7:8:9", "1:2:3:4:5:6:7::8", " ::1").filter { Ip.parse6(it) != null }.toString())
    T.check("tam sekiz grup ve '::' birlikte geçerli (en çok 7 grup)", Ip.parse6("1:2:3:4:5:6:7::") != null && Ip.parse6("::2:3:4:5:6:7:8") != null)
    T.check("yazım (RFC 5952): en uzun sıfır dizisi kısalır",
        Ip.format(Ip.parse6("2001:db8:0:0:1:0:0:1")!!) == "2001:db8::1:0:0:1" && Ip.format(Ip.parse6("2606:4700:4700:0:0:0:0:1111")!!) == "2606:4700:4700::1111")
    T.check("yazım: tek sıfır grubu kısaltılmaz, '::' ve IPv4", Ip.format(Ip.parse6("2001:db8:0:1:1:1:1:1")!!) == "2001:db8:0:1:1:1:1:1" &&
        Ip.format(Ip.parse6("::")!!) == "::" && Ip.format(Ip.parse4("9.9.9.9")!!) == "9.9.9.9")
    val rnd = java.util.Random(11)
    var rt = true
    repeat(300) {
        val b = ByteArray(16); rnd.nextBytes(b)
        if (rnd.nextBoolean()) for (i in 0 until rnd.nextInt(14)) b[2 + i] = 0
        if (!Ip.parse6(Ip.format(b))!!.contentEquals(b)) rt = false
    }
    T.check("rastgele 300 IPv6 adresi: yazıp geri okuma özdeş", rt)
    T.check("global IPv6: 2000::/3; belgeleme, Teredo, 6to4 ve ULA hariç",
        Ip.isGlobalV6(Ip.parse6("2606:4700:4700::1111")!!) && !Ip.isGlobalV6(Ip.parse6("2001:db8::1")!!) && !Ip.isGlobalV6(Ip.parse6("2001:0:1::1")!!) &&
            !Ip.isGlobalV6(Ip.parse6("2002::1")!!) && !Ip.isGlobalV6(Ip.parse6("fd00::1")!!) && !Ip.isGlobalV6(Ip.parse6("fe80::1")!!) && !Ip.isGlobalV6(Ip.parse6("::1")!!))
    T.check("global IPv4: özel/geri döngü/CGNAT hariç", Ip.isGlobalV4(Ip.parse4("1.1.1.1")!!) && !Ip.isGlobalV4(Ip.parse4("10.1.1.1")!!) &&
        !Ip.isGlobalV4(Ip.parse4("127.0.0.1")!!) && !Ip.isGlobalV4(Ip.parse4("192.168.1.1")!!) && !Ip.isGlobalV4(Ip.parse4("100.64.0.1")!!))
    T.check("sameNet", Ip.sameNet(CL6, SV6, 15) && !Ip.sameNet(CL6, SV6, 16) && !Ip.sameNet(CL6, byteArrayOf(1, 2, 3, 4), 2))
    T.check("tünel adresleri geçerli ULA ve birbirinden farklı", Ip.parse6(SelfTest.CLIENT_ADDR6) != null && !CL6.contentEquals(SV6) && (CL6[0].toInt() and 0xFE) == 0xFC)
}

/** UDP sağlama toplamı için bağımsız başvuru uygulaması (RFC 8200 §8.1 sözde başlığı). */
private fun refUdp6(src: ByteArray, dst: ByteArray, udp: ByteArray): Int {
    var sum = 0L
    fun add(b: ByteArray, from: Int, to: Int) { var i = from; while (i + 1 < to) { sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF); i += 2 }
        if (i < to) sum += (b[i].toInt() and 0xFF) shl 8 }
    add(src, 0, 16); add(dst, 0, 16)
    sum += udp.size.toLong()
    sum += 17
    add(udp, 0, udp.size)
    while (sum ushr 16 != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
    val c = (sum.inv() and 0xFFFF).toInt()
    return if (c == 0) 0xFFFF else c
}

private fun testV6Packets() {
    T.group("IPv6 tünel paketleri")
    val dns = Dns.buildQuery(0xBEEF, "ipv6.example.com")
    val p = v6Packet(dns, 51234)
    T.check("sorgu başlığı kabul edilir (IPv6 + UDP + 53)", Packets.queryHeaderLen6(p, p.size) == Packets.IP6_HDR && Packets.dnsLength6(p) == dns.size)
    val udp = p.copyOfRange(40, p.size)
    udp[6] = 0; udp[7] = 0
    T.check("UDP sağlama toplamı bağımsız başvuruyla aynı", Packets.u16(p, 46) == refUdp6(CL6, SV6, udp), "%04x vs %04x".format(Packets.u16(p, 46), refUdp6(CL6, SV6, udp)))
    T.check("sağlama toplamı doğrulanır; bit çevrilince geçersiz", Packets.udpChecksum6Ok(p, p.size) && p.copyOf().also { it[p.size - 1] = (it[p.size - 1].toInt() xor 1).toByte() }.let { !Packets.udpChecksum6Ok(it, it.size) })
    T.check("sağlama toplamı 0 olan paket geçersiz (IPv6'da zorunlu)", p.copyOf().also { it[46] = 0; it[47] = 0 }.let { !Packets.udpChecksum6Ok(it, it.size) })
    T.check("IPv6 sorgu: TCP, 53 dışı port ve parçalı paket reddedilir",
        p.copyOf().also { it[6] = 6 }.let { Packets.queryHeaderLen6(it, it.size) == -1 } &&
            p.copyOf().also { Packets.put16(it, 42, 80) }.let { Packets.queryHeaderLen6(it, it.size) == -1 } &&
            p.copyOf().also { it[6] = 44 }.let { Packets.queryHeaderLen6(it, it.size) == -1 } &&
            Packets.queryHeaderLen6(p, 50) == -1)

    // Cevap: sığarsa tek paket, sığmazsa parçalama başlığıyla (her parça <= MTU)
    fun reply(dnsLen: Int, collect: MutableList<ByteArray>) {
        val out = ByteArray(Packets.HDR + dnsLen + Packets.ROOM)
        for (i in 0 until dnsLen) out[Packets.HDR + i] = (i * 7 + 3).toByte()
        val scratch = ByteArray(Packets.MTU + 64)
        Packets.writeReply6(out, scratch, 0x1234ABCD, SV6, CL6, 53, 40000, dnsLen) { b, o, l -> collect.add(b.copyOfRange(o, o + l)) }
    }
    val small = ArrayList<ByteArray>()
    reply(300, small)
    T.check("küçük cevap: tek, geçerli IPv6 paketi", small.size == 1 && small[0].size == Packets.HDR6 + 300 && (small[0][6].toInt() and 0xFF) == 17 && udp6Ok(small[0]))
    val big = ArrayList<ByteArray>()
    reply(3000, big)
    T.check("büyük cevap: birden çok parça, her biri <= MTU", big.size >= 3 && big.all { it.size <= Packets.MTU }, big.map { it.size }.toString())
    T.check("parçalar: sonraki başlık 44, UDP bildirimi, aynı kimlik, yalnızca sonuncuda M=0",
        big.all { (it[6].toInt() and 0xFF) == 44 && (it[40].toInt() and 0xFF) == 17 && Packets.i32(it, 44) == 0x1234ABCD } &&
            big.dropLast(1).all { (Packets.u16(it, 42) and 1) == 1 } && (Packets.u16(big.last(), 42) and 1) == 0)
    // Yeniden birleştir
    val parts = big.map { Triple((Packets.u16(it, 42) ushr 3) * 8, it.copyOfRange(48, it.size), it) }.sortedBy { it.first }
    var contiguous = true
    var expect = 0
    val re = ByteArrayOutputStream()
    for ((o, data, _) in parts) { if (o != expect) contiguous = false; re.write(data); expect += data.size }
    val joined = re.toByteArray()
    T.check("parçalar bitişik ve 8'in katı konumlarda", contiguous && parts.dropLast(1).all { it.second.size % 8 == 0 })
    T.check("birleşen UDP: uzunluk, portlar, veri ve sağlama toplamı doğru", joined.size == 8 + 3000 && Packets.u16(joined, 4) == joined.size &&
        Packets.u16(joined, 0) == 53 && Packets.u16(joined, 2) == 40000 && Packets.u16(joined, 6) == refUdp6(SV6, CL6, joined.copyOf().also { it[6] = 0; it[7] = 0 }) &&
        (0 until 3000).all { joined[8 + it] == (it * 7 + 3).toByte() })
}

private fun fakeServer(id: String, a: String, b: String?, a6: String?, b6: String?, dot: String? = "dns.example", doh: String? = "https://dns.example/dns-query") =
    DnsServer(id, "T", null, a, b, emptySet(), dot, null, doh, true, "T", false, a6, b6)

private fun testTargets() {
    T.group("Hedef sırası: IPv4 ve IPv6 birlikte")
    val cf = Catalog.byId("cloudflare")!!
    val dual = NetFamilies(true, true)
    val v4only = NetFamilies(true, false)
    val v6only = NetFamilies(false, true)
    T.check("uç noktalar: birincil ve ikincil, IPv4 + IPv6 karşılıkları", Targets.endpoints(cf).map { it.v4 to it.v6 } ==
        listOf("1.1.1.1" to "2606:4700:4700::1111", "1.0.0.1" to "2606:4700:4700::1001"))
    T.check("çift yığın: önce IPv4, sonra IPv6", Targets.order(Targets.endpoints(cf)[0], IpMode.BOTH, dual) == listOf("1.1.1.1", "2606:4700:4700::1111"))
    T.check("yalnızca IPv6 ağ: önce IPv6", Targets.order(Targets.endpoints(cf)[0], IpMode.BOTH, v6only) == listOf("2606:4700:4700::1111", "1.1.1.1"))
    T.check("yalnızca IPv4 ağ ve bilinmeyen ağ: önce IPv4 (IPv6 yedek)", Targets.order(Targets.endpoints(cf)[0], IpMode.BOTH, v4only) == listOf("1.1.1.1", "2606:4700:4700::1111") &&
        Targets.order(Targets.endpoints(cf)[0], IpMode.BOTH, NetFamilies.UNKNOWN) == listOf("1.1.1.1", "2606:4700:4700::1111"))
    T.check("'Yalnız IPv4' kipi: yalnızca IPv4", Targets.order(Targets.endpoints(cf)[0], IpMode.V4, dual) == listOf("1.1.1.1") && Targets.order(Targets.endpoints(cf)[0], IpMode.V4, v6only) == listOf("1.1.1.1"))
    T.check("düz DNS listesi: önce her adresin ilk tercihi, sonra yedek aile", Targets.plain(cf, IpMode.BOTH, dual) ==
        listOf("1.1.1.1", "1.0.0.1", "2606:4700:4700::1111", "2606:4700:4700::1001"))
    T.check("düz DNS listesi: yalnızca IPv6 ağda IPv6 önde", Targets.plain(cf, IpMode.BOTH, v6only) ==
        listOf("2606:4700:4700::1111", "2606:4700:4700::1001", "1.1.1.1", "1.0.0.1"))
    T.check("düz DNS listesi: 'Yalnız IPv4'", Targets.plain(cf, IpMode.V4, dual) == listOf("1.1.1.1", "1.0.0.1"))
    val one = fakeServer("o", "9.9.9.9", null, "2620:fe::fe", null)
    T.check("tek adresli sunucu", Targets.plain(one, IpMode.BOTH, dual) == listOf("9.9.9.9", "2620:fe::fe") && Targets.plain(one, IpMode.V4, dual) == listOf("9.9.9.9"))
    val noV6 = fakeServer("n", "9.9.9.9", "9.9.9.10", null, null)
    T.check("IPv6 karşılığı olmayan sunucu: yalnızca IPv4, hata yok", Targets.plain(noV6, IpMode.BOTH, v6only) == listOf("9.9.9.9", "9.9.9.10"))
    val custom6 = DnsServer("u1", "Ev", null, "2606:4700:4700::1111", "192.168.1.1", emptySet(), custom = true)
    T.check("özel sunucu: IPv6 birincil + IPv4 ikincil", Targets.endpoints(custom6).map { it.v4 to it.v6 } == listOf(null to "2606:4700:4700::1111", "192.168.1.1" to null))
    T.check("özel IPv6 sunucu 'Yalnız IPv4' kipinde de kullanılır (kullanıcı kendisi yazdı)", Targets.plain(custom6, IpMode.V4, dual) == listOf("2606:4700:4700::1111", "192.168.1.1"))
    T.check("yinelenen adres yok", Targets.plain(cf, IpMode.BOTH, dual).toSet().size == 4 && Targets.plain(one, IpMode.BOTH, dual).toSet().size == 2)

    val dot = Targets.secure(cf, Proto.DOT, IpMode.BOTH, dual)
    T.check("DoT hedefleri: sertifika adı, 1. aile IPv4, yedek IPv6", dot.size == 2 && dot[0].ip == "1.1.1.1" && dot[0].alt == "2606:4700:4700::1111" &&
        dot[0].host == "one.one.one.one" && dot[1].ip == "1.0.0.1" && dot[1].alt == "2606:4700:4700::1001")
    val dotV6 = Targets.secure(cf, Proto.DOT, IpMode.BOTH, v6only)
    T.check("DoT: yalnızca IPv6 ağda IPv6 önce", dotV6[0].ip == "2606:4700:4700::1111" && dotV6[0].alt == "1.1.1.1")
    T.check("DoT: 'Yalnız IPv4' kipinde yedek aile yok", Targets.secure(cf, Proto.DOT, IpMode.V4, dual).all { it.alt == null })
    val doh = Targets.secure(cf, Proto.DOH, IpMode.BOTH, dual, listOf("104.16.249.249", "1.1.1.1", "10.0.0.1", "2606:4700::6810:f8f9"))
    T.check("DoH: çözülen ek IPv4 önce; bilinen, özel ve IPv6 olanlar elenir", doh.size == 3 && doh[0].ip == "104.16.249.249" && doh[0].alt == null && doh[1].ip == "1.1.1.1" &&
        doh.all { it.host == "cloudflare-dns.com" && it.path == "/dns-query" }, doh.map { it.ip }.toString())
    T.check("DoT'ta ek adres sonda", Targets.secure(cf, Proto.DOT, IpMode.BOTH, dual, listOf("104.16.249.249")).map { it.ip } == listOf("1.1.1.1", "1.0.0.1", "104.16.249.249"))
    T.check("PLAIN için şifreli hedef istenemez", runCatching { Targets.secure(cf, Proto.PLAIN, IpMode.BOTH, dual) }.isFailure)
    val noEnc = fakeServer("x", "9.9.9.9", null, null, null, dot = null, doh = null)
    T.check("şifreli adresi olmayan sunucu: hedef yok (hata)", runCatching { Targets.secure(noEnc, Proto.DOT, IpMode.BOTH, dual) }.isFailure)
    T.check("NetFamilies: eşitlik ve v6Only", NetFamilies(true, false) == v4only && v6only.v6Only && !dual.v6Only && !v4only.v6Only && NetFamilies.UNKNOWN == dual)
}

private fun testCatalogV6() {
    T.group("Katalog: IPv6 adresleri")
    val all = Catalog.builtin
    val withV6 = all.filter { it.primary6 != null }
    T.check("her sunucunun IPv6 adresleri geçerli ve herkese açık", all.all { s ->
        listOfNotNull(s.primary6, s.secondary6).all { Ip.parse6(it)?.let { b -> Ip.isGlobalV6(b) } == true } }, all.filter { s -> listOfNotNull(s.primary6, s.secondary6).any { Ip.parse6(it) == null } }.joinToString { it.id })
    T.check("ikincil IPv6 yalnızca birincil varsa var; birincil ikincilden farklı", all.all { (it.secondary6 == null || (it.primary6 != null && it.secondary6 != it.primary6)) })
    T.check("ikincil IPv4 yoksa ikincil IPv6 da yok", all.all { it.secondary != null || it.secondary6 == null })
    T.check("her hazır sunucunun IPv6 adresi var", withV6.size == all.size, "${withV6.size}/${all.size}")
    T.check("addresses4/addresses6 ayrımı", Catalog.byId("google")!!.addresses4 == listOf("8.8.8.8", "8.8.4.4") && Catalog.byId("google")!!.addresses6 == listOf("2001:4860:4860::8888", "2001:4860:4860::8844"))
    T.check("IPv6 adresleri başka sunucuyla çakışmaz", withV6.flatMap { listOfNotNull(it.primary6, it.secondary6) }.let { it.size == it.toSet().size })
    T.check("hiçbir adres tünelin kendi adresleriyle çakışmaz", all.none { s -> (s.addresses + listOfNotNull(s.primary6, s.secondary6)).any { it == SelfTest.FAKE_DNS || it == SelfTest.FAKE_DNS6 || it == SelfTest.CLIENT_ADDR6 } })
}

private fun testCustomV6() {
    T.group("Özel DNS: IPv6 adresleri")
    fun d(a: String, b: String = "") = CustomDns.Draft("Evim", a, b, "", "")
    T.check("global IPv6 ve ULA kabul", CustomDns.validate(d("2606:4700:4700::1111")) == null && CustomDns.validate(d("fd12:3456::1")) == null && CustomDns.validate(d("192.168.1.2", "2001:4860:4860::8888")) == null)
    T.check("geri döngü, bağlantı-yerel, çok noktaya yayın, belirsiz, eşlenmiş IPv4 reddedilir",
        listOf("::1", "fe80::1", "ff02::1", "::", "::ffff:1.2.3.4", "[2606:4700::1]", "2606:4700::1%eth0").all { CustomDns.validate(d(it)) == CustomDns.Error.IP })
    T.check("uygulamanın tünel adresleri reddedilir", CustomDns.validate(d(SelfTest.FAKE_DNS6)) == CustomDns.Error.IP && CustomDns.validate(d("fd6e:7368:a1c2:0:1::5")) == CustomDns.Error.IP)
    T.check("aynı IPv6'nın farklı yazımı ikincil olarak kopya sayılır", CustomDns.validate(d("2606:4700:4700::1111", "2606:4700:4700:0:0:0:0:1111")) == CustomDns.Error.IP2)
    T.check("DoT ve DoH adı olarak IPv6 yazılamaz", CustomDns.validate(CustomDns.Draft("E", "1.2.3.4", "", "2606:4700::1", "")) == CustomDns.Error.DOT &&
        CustomDns.validate(CustomDns.Draft("E", "1.2.3.4", "", "", "https://2606:4700::1/dns-query")) == CustomDns.Error.DOH)
    val s = CustomDns.build("u9", d("2606:4700:4700::1111", "192.168.1.1"))
    T.check("build: IPv6 birincil korunur, addresses6 bunu verir", s.primary == "2606:4700:4700::1111" && s.addresses6 == listOf("2606:4700:4700::1111") && s.addresses4 == listOf("192.168.1.1"))
}

private fun testSanitize() {
    T.group("Gizlilik: sorgu temizliği (ECS, çerez, cihaz kimliği, dolgu)")
    val q = optQuery(0x1234)
    val s = Dns.sanitizeQuery(q, 0, q.size, pad = false, absentPayload = 512)!!
    val m = Msg(s.query)
    T.check("istemcinin tüm EDNS seçenekleri atılır; yalnızca 'alt ağı iletme' (ECS /0) kalır", m.edns != null && m.optCount == 1 &&
        m.edns!!.options.size == 1 && m.edns!!.options[0].first == 8 && m.edns!!.options[0].second.contentEquals(byteArrayOf(0, 1, 0, 0)))
    T.check("alt ağ adresi, çerez ve cihaz kimliği giden sorguda yok", !contains(s.query, byteArrayOf(192.toByte(), 0, 2)) && !contains(s.query, COOKIE) && !contains(s.query, DEVICE_ID))
    T.check("istemcinin UDP yük boyutu ve DO bitı korunur", m.edns!!.payload == 4096 && (m.edns!!.ttl and 0xFFFF) == 0x8000)
    T.check("kimlik, bayraklar ve soru aynen korunur", Packets.u16(s.query, 0) == 0x1234 && Packets.u16(s.query, 2) == 0x0100 && Msg(q).qEnd == m.qEnd &&
        (12 until m.qEnd).all { s.query[it] == q[it] })
    T.check("OPT zaten vardı: addedOpt false", !s.addedOpt)
    val n = Dns.buildQuery(7, "plain.example.org")
    val s2 = Dns.sanitizeQuery(n, 0, n.size, pad = false, absentPayload = 1232)!!
    val m2 = Msg(s2.query)
    T.check("OPT yoksa eklenir (addedOpt), UDP yükü verilen değer, yalnızca ECS /0", s2.addedOpt && m2.optCount == 1 && m2.edns!!.payload == 1232 && m2.edns!!.options.size == 1 && m2.ar == 1)
    val tiny = optQuery(8, payload = 100)
    T.check("istemci 512'den küçük yük bildirirse 512'ye yükseltilir", Msg(Dns.sanitizeQuery(tiny, 0, tiny.size, false, 512)!!.query).edns!!.payload == 512)

    var allPadded = true
    var padsZero = true
    var hasPad = true
    for (len in 1..60) {
        val name = "a".repeat(len.coerceAtMost(60)) + ".example.com"
        for (src in listOf(Dns.buildQuery(1, name), optQuery(2, name))) {
            val r = Dns.sanitizeQuery(src, 0, src.size, pad = true, absentPayload = 1232)!!.query
            if (r.size % Dns.PAD_BLOCK != 0) allPadded = false
            val e = Msg(r).edns!!
            val pad = e.options.firstOrNull { it.first == 12 }
            if (pad == null) hasPad = false else if (pad.second.any { it != 0.toByte() }) padsZero = false
            if (e.options.map { it.first } != listOf(8, 12)) hasPad = false
        }
    }
    T.check("dolgu: her sorgu 128 baytın tam katı (RFC 8467), 120 farklı uzunlukta", allPadded)
    T.check("dolgu seçeneği (kod 12) var, baytları sıfır, ECS'den sonra", hasPad && padsZero)
    val x = optQuery(3, extraRr = true)
    val r3 = Dns.sanitizeQuery(x, 0, x.size, pad = false, absentPayload = 512)!!.query
    val m3 = Msg(r3)
    T.check("OPT dışı ek kayıtlar korunur (sayı doğru, tek OPT)", m3.ar == 2 && m3.otherAdditional == 1 && m3.optCount == 1 && contains(r3, byteArrayOf(7, 8, 9)))
    T.check("temizlik idempotent: ikinci geçiş aynı baytları üretir", Dns.sanitizeQuery(r3, 0, r3.size, false, 512)!!.query.contentEquals(r3))
    val twoOpt = optQuery(4).let { it + it.copyOfRange(it.size - 11 - 4 - 4 - 4 - 7 - 16, it.size) }
    val dupOpt = optQuery(5, opts = emptyList()).let { b -> val o = b.copyOfRange(b.size - 11, b.size); (b + o).also { Packets.put16(it, 10, 2) } }
    T.check("iki OPT içeren sorgu reddedilir (null)", Dns.sanitizeQuery(dupOpt, 0, dupOpt.size, false, 512) == null)
    T.check("kesik, bozuk ve çok kısa sorgular reddedilir", Dns.sanitizeQuery(q, 0, q.size - 3, false, 512) == null && Dns.sanitizeQuery(q, 0, 5, false, 512) == null &&
        Dns.sanitizeQuery(q, 0, q.size + 10, false, 512) == null && twoOpt.isNotEmpty())
    val off = ByteArray(10) + q
    T.check("konum kaydırması: tamponun ortasındaki sorgu da temizlenir", Dns.sanitizeQuery(off, 10, q.size, false, 512)!!.query.contentEquals(s.query))

    // Cevaptan OPT'yi çıkarma
    val withOpt = buildAnswer(s2.query, s2.query.size, aRecord(byteArrayOf(1, 2, 3, 4)), 1)
    val cut = Dns.stripOpt(withOpt, 0, withOpt.size)
    val mc = Msg(withOpt, 0, cut)
    T.check("cevaptaki OPT çıkarılır: ek kayıt sayısı 0, A kaydı korunur, uzunluk kısalır", cut < withOpt.size && Packets.u16(withOpt, 10) == 0 && mc.answerIps == listOf("1.2.3.4") && cut == withOpt.size - 19)
    val noOpt = buildAnswer(n, n.size, aRecord(byteArrayOf(1, 2, 3, 4)), 1)
    T.check("OPT yoksa cevaba dokunulmaz", Dns.stripOpt(noOpt, 0, noOpt.size) == noOpt.size)
    val notLast = withOpt + byteArrayOf(0, 0, 99, 0, 1, 0, 0, 0, 0, 0, 0)
    Packets.put16(notLast, 10, 2)
    T.check("OPT son kayıt değilse dokunulmaz", Dns.stripOpt(notLast, 0, notLast.size) == notLast.size)
    T.check("bozuk cevapta dokunulmaz", Dns.stripOpt(withOpt, 0, withOpt.size - 5) == withOpt.size - 5 && Dns.stripOpt(ByteArray(5), 0, 5) == 5)
}

private fun testPlainForwarder() {
    T.group("Gizlilik: düz DNS yönlendirici (IPv4 ve IPv6 istemciler)")
    CaptureDns().use { dns ->
        PlainHarness(listOf(dns.addr)).use { h ->
            // 1) EDNS'li IPv4 istemci
            h.send(v4Packet(optQuery(0x0101, "one.example.com"), 40001))
            val r1 = h.reply()
            T.check("EDNS'li istemci: cevap geldi", r1 != null && checkV4Reply(r1, 40001, 0x0101) == null, r1?.let { checkV4Reply(it, 40001, 0x0101) } ?: "cevap yok")
            val up1 = dns.received.getOrNull(0)
            val mu1 = up1?.let { Msg(it) }
            T.check("sunucuya giden sorguda ECS adresi, çerez ve cihaz kimliği yok; yalnızca ECS /0",
                up1 != null && !contains(up1, byteArrayOf(192.toByte(), 0, 2)) && !contains(up1, COOKIE) && !contains(up1, DEVICE_ID) &&
                    mu1!!.edns!!.options.size == 1 && mu1.edns!!.options[0].second.contentEquals(byteArrayOf(0, 1, 0, 0)))
            T.check("istemcinin kendi OPT'si olduğu için cevapta OPT kalır", r1 != null && Msg(r1, Packets.HDR, r1.size - Packets.HDR).optCount == 1 && Msg(r1, Packets.HDR, r1.size - Packets.HDR).answerIps == listOf("1.2.3.4"))

            // 2) EDNS'siz IPv4 istemci: OPT eklenir, cevaptan çıkarılır
            h.send(v4Packet(Dns.buildQuery(0x0202, "two.example.com"), 40002))
            val r2 = h.reply()
            val up2 = dns.received.getOrNull(1)?.let { Msg(it) }
            T.check("EDNS'siz istemci: sunucuya OPT eklenir (ECS /0)", up2 != null && up2.optCount == 1 && up2.edns!!.options.size == 1)
            val m2 = r2?.let { Msg(it, Packets.HDR, it.size - Packets.HDR) }
            T.check("cevapta OPT yok (istemci istemedi), A kaydı sağlam, paket geçerli", r2 != null && checkV4Reply(r2, 40002, 0x0202) == null && m2!!.ar == 0 && m2.answerIps == listOf("1.2.3.4") &&
                Packets.u16(r2, 24) == r2.size - 20 && Packets.checksum(r2, 0, 20) == 0)
            // 3) Önbellek: aynı soru yine OPT'siz dönmeli
            h.send(v4Packet(Dns.buildQuery(0x0303, "two.example.com"), 40003))
            val r3 = h.reply()
            val m3 = r3?.let { Msg(it, Packets.HDR, it.size - Packets.HDR) }
            T.check("önbellekten gelen cevap da OPT'siz ve doğru; sunucuya ikinci sorgu gitmedi", r3 != null && checkV4Reply(r3, 40003, 0x0303) == null && m3!!.ar == 0 && h.fw.stats().cacheHits == 1L && dns.received.size == 2)

            // 4) IPv6 istemci
            h.send(v6Packet(Dns.buildQuery(0x0404, "six.example.com"), 40004))
            val r4 = h.reply()
            T.check("IPv6 istemci: cevap IPv6 olarak, doğru adres, port ve UDP sağlama toplamıyla gelir", r4 != null && checkV6Reply(r4, 40004, 0x0404) == null, r4?.let { checkV6Reply(it, 40004, 0x0404) } ?: "cevap yok")
            val m4 = r4?.let { Msg(it, Packets.HDR6, it.size - Packets.HDR6) }
            T.check("IPv6 cevap: OPT yok, A kaydı doğru", m4 != null && m4.ar == 0 && m4.answerIps == listOf("1.2.3.4"))
            h.send(v6Packet(optQuery(0x0505, "six.example.net"), 40005))
            val r5 = h.reply()
            val up5 = dns.received.lastOrNull()
            T.check("IPv6 istemci + EDNS: temizlenir ve cevap doğru", r5 != null && checkV6Reply(r5, 40005, 0x0505) == null && up5 != null && !contains(up5, COOKIE) && !contains(up5, DEVICE_ID))

            // 5) Aynı anda IPv4 ve IPv6 istemciler karışmaz
            h.send(v4Packet(Dns.buildQuery(0x0601, "mix1.example.com"), 41001))
            h.send(v6Packet(Dns.buildQuery(0x0602, "mix2.example.com"), 41002))
            h.send(v4Packet(Dns.buildQuery(0x0603, "mix3.example.com"), 41003))
            val got = (0 until 3).mapNotNull { h.reply() }
            val ok = got.size == 3 && got.count { (it[0].toInt() and 0xF0) == 0x60 } == 1 &&
                got.all { r -> if ((r[0].toInt() and 0xF0) == 0x60) checkV6Reply(r, 41002, 0x0602) == null else checkV4Reply(r, Packets.u16(r, 22), Packets.u16(r, 28)) == null }
            T.check("eş zamanlı IPv4 ve IPv6 sorgular doğru aileyle cevaplanır", ok, got.map { (it[0].toInt() and 0xF0) shr 4 }.toString())
            // 6) Kısa / bozuk IPv6 paketleri sessizce atılır
            h.send(v6Packet(Dns.buildQuery(0x0708, "bad2.example.com"), 42001).copyOf(30))
            h.send(v6Packet(Dns.buildQuery(0x0707, "bad.example.com"), 42000).also { it[6] = 6 })           // TCP
            T.check("kısa ve UDP olmayan IPv6 paketleri atılır (cevap yok), çökme yok", h.reply(400) == null)
            h.send(v4Packet(Dns.buildQuery(0x0709, "after.example.com"), 42002))
            val ra = h.reply()
            T.check("bozuk paketlerden sonra yönlendirici çalışmayı sürdürür", ra != null && checkV4Reply(ra, 42002, 0x0709) == null)
        }
    }
}

private fun testSecurePrivacy() {
    T.group("Gizlilik: şifreli yol (DoT ve DoH)")
    FakeTlsDns(doh = false).use { srv ->
        SecHarness(Proto.DOT, listOf(srv.target)).use { h ->
            val p = v4Packet(optQuery(0x1111, "dot.example.com"), 40000)
            h.fw.onPacket(p, p.size)
            val r = h.reply()
            T.check("DoT: cevap geldi", r != null && checkV4Reply(r, 40000, 0x1111) == null)
            val up = srv.received.firstOrNull()
            val mu = up?.let { Msg(it) }
            T.check("DoT: sunucu ECS adresi, çerez ve cihaz kimliği görmedi", up != null && !contains(up, byteArrayOf(192.toByte(), 0, 2)) && !contains(up, COOKIE) && !contains(up, DEVICE_ID))
            T.check("DoT: seçenekler yalnızca ECS /0 + dolgu", mu != null && mu.edns!!.options.map { it.first } == listOf(8, 12) && mu.edns!!.options[0].second.contentEquals(byteArrayOf(0, 1, 0, 0)))
            T.check("DoT: sorgu 128 baytın katı (uzunluktan ad tahmini zorlaşır)", up != null && up.size % 128 == 0, "uzunluk=${up?.size}")
            val p2 = v4Packet(Dns.buildQuery(0x2222, "x.example.com"), 40001)
            h.fw.onPacket(p2, p2.size)
            val r2 = h.reply()
            val m2 = r2?.let { Msg(it, Packets.HDR, it.size - Packets.HDR) }
            T.check("DoT: EDNS istemeyen istemciye OPT'siz cevap döner (dolgu da dışarı sızmaz)", r2 != null && checkV4Reply(r2, 40001, 0x2222) == null && m2!!.ar == 0 && m2.answerIps == listOf("1.2.3.4"))
            val sizes = srv.received.map { it.size }.toSet()
            T.check("DoT: farklı uzunlukta adlar aynı bloğa dolar", sizes.all { it % 128 == 0 })
            val p3 = v6Packet(Dns.buildQuery(0x3333, "v6client.example.com"), 40003)
            h.fw.onPacket(p3, p3.size)
            val r3 = h.reply()
            T.check("DoT: IPv6 istemci de cevaplanır (IPv6 paket, doğru sağlama toplamı)", r3 != null && checkV6Reply(r3, 40003, 0x3333) == null, r3?.let { checkV6Reply(it, 40003, 0x3333) } ?: "cevap yok")
            T.check("DoT: TLS 1.2 ya da 1.3 pazarlık edildi", srv.tlsVersions.isNotEmpty() && srv.tlsVersions.all { it == "TLSv1.3" || it == "TLSv1.2" }, srv.tlsVersions.toString())
        }
    }
    FakeTlsDns(doh = true).use { srv ->
        SecHarness(Proto.DOH, listOf(srv.target)).use { h ->
            val p = v4Packet(optQuery(0x4444, "doh.example.com"), 40010)
            h.fw.onPacket(p, p.size)
            val r = h.reply()
            T.check("DoH: cevap geldi", r != null && checkV4Reply(r, 40010, 0x4444) == null)
            val up = srv.received.firstOrNull()
            val mu = up?.let { Msg(it) }
            T.check("DoH: ECS /0 + dolgu, sızıntı yok, 128'in katı", up != null && !contains(up, COOKIE) && !contains(up, DEVICE_ID) && !contains(up, byteArrayOf(192.toByte(), 0, 2)) &&
                mu!!.edns!!.options.map { it.first } == listOf(8, 12) && up.size % 128 == 0)
            T.check("DoH: sorgu kimliği 0 (RFC 8484; önbellek ve izlenebilirlik için)", srv.zeroIds.get() == 1)
            val names = srv.headers.map { it.substringBefore(':') }.toSet()
            T.check("DoH: tanıtıcı üstbilgi yok; yalnızca host, user-agent, accept, content-type, content-length", names.all { it in setOf("host", "user-agent", "accept", "content-type", "content-length") }, names.toString())
            T.check("DoH: User-Agent genel ('Mozilla/5.0'); uygulama adı/sürümü yok", srv.headers.filter { it.startsWith("user-agent") }.all { it == "user-agent: Mozilla/5.0" })
            T.check("DoH: çerez ve yetki üstbilgisi gönderilmez", srv.headers.none { it.startsWith("cookie") || it.startsWith("authorization") || it.startsWith("x-") })
            T.check("DoH: TLS 1.2 ya da 1.3", srv.tlsVersions.isNotEmpty() && srv.tlsVersions.all { it == "TLSv1.3" || it == "TLSv1.2" })
        }
    }
    // Ağ değişince TLS oturum önbelleği atılır
    FakeTlsDns(doh = false).use { srv ->
        val made = AtomicInteger()
        SecHarness(Proto.DOT, listOf(srv.target), freshTls = { made.incrementAndGet(); TestTls.client }).use { h ->
            h.send(1, "a.example.com", 40020)
            val r = h.reply()
            T.check("taze TLS: ilk bağlantı çalışır, fabrika henüz yenilenmedi", r != null && made.get() == 0)
            h.fw.resetNetwork("test")
            h.send(2, "b.example.com", 40021)
            val r2 = h.reply()
            T.check("ağ değişince yeni TLS fabrikası kurulur (eski oturum biletleri atılır) ve bağlantı yenilenir", r2 != null && made.get() == 1 && srv.accepted.get() >= 2, "fabrika=${made.get()} bağlantı=${srv.accepted.get()}")
            h.fw.resetNetwork("test2")
            T.check("her ağ değişiminde bir fabrika", made.get() == 2)
        }
    }
}

private fun testDualFamily() {
    T.group("Çift aile (IPv4 / IPv6) şifreli bağlantı")
    // İlk aile ölü bir adres, yedek aile çalışan sunucu: [alt] ile geçiş (aynı mantık IPv4 ↔ IPv6 için de geçerlidir).
    FakeTlsDns(doh = false).use { srv ->
        val deadPort = java.net.ServerSocket(0, 1, loop).let { val p = it.localPort; it.close(); p }
        val live = srv.server.localPort
        val target = SecureTarget(InetSocketAddress(loop, deadPort), "dns.test", "/dns-query", alt = InetSocketAddress(loop, live))
        SecHarness(Proto.DOT, listOf(target)).use { h ->
            val t0 = System.nanoTime()
            h.send(1, "fam1.example.com", 40030)
            val r = h.reply(5000)
            val ms1 = (System.nanoTime() - t0) / 1_000_000
            T.check("ilk aile erişilemezse öbür aileye geçilir ve sorgu cevaplanır", r != null && checkReply(r, 1, port = 40030) == null, "ms=$ms1")
            T.check("öbür aileye geçiş ilk aile bütçesinden (1,5 sn) uzun sürmedi", ms1 < 3000, "ms=$ms1")
            val accepted = srv.accepted.get()
            h.send(2, "fam2.example.com", 40031)
            val r2 = h.reply(3000)
            T.check("çalışan aile hatırlanır: sonraki sorgu doğrudan oradan gider (ek gecikme yok)", r2 != null && checkReply(r2, 2, port = 40031) == null && srv.accepted.get() - accepted <= 1)
            h.fw.resetNetwork("test")
            h.send(3, "fam3.example.com", 40032)
            val r3 = h.reply(5000)
            T.check("ağ değişince tercih sıfırlanır ve yine çalışır", r3 != null && checkReply(r3, 3, port = 40032) == null)
        }
    }
    // Çalışan hedef önde: yedek aile hiç denenmez
    FakeTlsDns(doh = false).use { srv ->
        val deadPort = java.net.ServerSocket(0, 1, loop).let { val p = it.localPort; it.close(); p }
        val target = SecureTarget(InetSocketAddress(loop, srv.server.localPort), "dns.test", "/dns-query", alt = InetSocketAddress(loop, deadPort))
        SecHarness(Proto.DOT, listOf(target)).use { h ->
            h.send(1, "ok.example.com", 40040)
            val r = h.reply(3000)
            T.check("ilk aile çalışıyorsa yedek aile kullanılmaz ve bağlantı hatası günlüğe düşmez", r != null && checkReply(r, 1, port = 40040) == null && h.logs.none { it.contains("hata") })
        }
    }
    // İki aile de ölü: kısa sürede pes edilir
    run {
        val d1 = java.net.ServerSocket(0, 1, loop).let { val p = it.localPort; it.close(); p }
        val d2 = java.net.ServerSocket(0, 1, loop).let { val p = it.localPort; it.close(); p }
        val target = SecureTarget(InetSocketAddress(loop, d1), "dns.test", "/dns-query", alt = InetSocketAddress(loop, d2))
        SecHarness(Proto.DOT, listOf(target)).use { h ->
            val t0 = System.nanoTime()
            h.send(1, "dead.example.com", 40050)
            val r = h.reply(1500)
            T.check("iki aile de ölüyse cevap yok (sahte cevap üretilmez)", r == null)
            T.check("bağlantı hataları günlüğe düştü, istatistiklerde zaman aşımı sayıldı", waitUntil(7000) { h.fw.stats().timeouts >= 1 } && (System.nanoTime() - t0) / 1_000_000 < 7500)
        }
    }
}

private fun testFastFailure() {
    T.group("Hızlı hata tespiti (bağlantı testi)")
    // Sertifika adı uymayan sunucu: beklemeden Untrusted
    FakeTlsDns(doh = false, ks = TestTls.wrong).use { srv ->
        SecHarness(Proto.DOT, listOf(srv.target)).use { h ->
            val t0 = System.nanoTime()
            val res = ConnectionCheck.run(h.fw, resolve = { h.send(1, "mitm.example.com", 40060) }, timeoutMs = 6000)
            val ms = (System.nanoTime() - t0) / 1_000_000
            T.check("yanlış sertifika: Untrusted döner", res is CheckResult.Untrusted, res.toString())
            T.check("ve zaman aşımını beklemeden (en çok 2,5 sn)", ms < 2500, "ms=$ms")
            T.check("istatistik: tlsFailures sayıldı, hiç cevap iletilmedi", h.fw.stats().tlsFailures >= 1 && h.fw.stats().answered == 0L && h.reply(100) == null)
        }
    }
    // Hiç dinlemeyen sunucu: forwarder pes edince NoAnswer (zaman aşımının dolmasını beklemez)
    run {
        val dead = java.net.ServerSocket(0, 1, loop).let { val p = it.localPort; it.close(); SecureTarget(InetSocketAddress(loop, p), "dns.test") }
        SecHarness(Proto.DOT, listOf(dead)).use { h ->
            val t0 = System.nanoTime()
            val res = ConnectionCheck.run(h.fw, resolve = { h.send(1, "dead.example.com", 40061) }, timeoutMs = 12000)
            val ms = (System.nanoTime() - t0) / 1_000_000
            T.check("ölü sunucu: NoAnswer, 12 sn'lik süreyi beklemeden", res is CheckResult.NoAnswer && ms < 8000, "ms=$ms $res")
        }
    }
    // Sağlıklı sunucu: Ok
    FakeTlsDns(doh = true).use { srv ->
        SecHarness(Proto.DOH, listOf(srv.target)).use { h ->
            val res = ConnectionCheck.run(h.fw, resolve = { h.send(1, "fine.example.com", 40062) }, timeoutMs = 4000)
            T.check("sağlıklı DoH: Ok", res is CheckResult.Ok, res.toString())
        }
    }
    T.check("CheckResult.Untrusted ayrı bir sonuç", (CheckResult.Untrusted as CheckResult) != CheckResult.NoAnswer)
}

private fun testSelfTestV6() {
    T.group("Bağlantı testi: IPv6 yolu")
    CaptureDns().use { dns ->
        val tap = SelfTest.Tap()
        val fw = DnsForwarder(upstreams = listOf(dns.addr), writeToTun = { b, off, len -> tap.offer(b, off, len) }, sweepMs = 50, cacheEntries = 64).also { it.start() }
        try {
            val r = SelfTest.run(inject = { p -> fw.onPacket(p, p.size) }, tap = tap, proto = Proto.PLAIN, serverId = "x", timeoutMs = 3000, tunnelV6 = true)
            T.check("tünelde IPv6 varsa dördüncü soru IPv6 yoluyla sorulur ve cevaplanır", r.ok && r.v6 == true, r.toString())
            val r2 = SelfTest.run(inject = { p -> fw.onPacket(p, p.size) }, tap = tap, proto = Proto.PLAIN, serverId = "x", timeoutMs = 3000, tunnelV6 = false)
            T.check("tünelde IPv6 yoksa sonuç null (sınanmadı)", r2.ok && r2.v6 == null)
            T.check("IPv6 sınama paketi geçerli", SelfTest.packet6(5, "t.example.com").let { Packets.queryHeaderLen6(it, it.size) == 40 && Packets.udpChecksum6Ok(it, it.size) && SelfTest.dnsOffset(it) == Packets.HDR6 } &&
                SelfTest.dnsOffset(SelfTest.packet(5, "t.example.com")) == Packets.HDR)
        } finally { fw.close() }
    }
    val dead = SelfTest.Tap()
    val none = SelfTest.run(inject = { }, tap = dead, proto = Proto.DOT, serverId = "y", timeoutMs = 300, tunnelV6 = true)
    T.check("cevap gelmezse IPv6 yolu da 'yok' (false)", !none.ok && none.v6 == false)
}

private fun testIpModeSetting() {
    T.group("Ayar: IP sürümü")
    T.check("varsayılan: IPv4 + IPv6", AppSettings().ipMode == IpMode.BOTH)
    val s = AppSettings(ipMode = IpMode.V4)
    T.check("ayar kaydedilip okunur", SettingsCodec.decode(SettingsCodec.encode(s)).ipMode == IpMode.V4 && SettingsCodec.decode(SettingsCodec.encode(AppSettings())).ipMode == IpMode.BOTH)
    T.check("bozuk değer varsayılana düşer", SettingsCodec.decode(mapOf("ipMode" to "v9")).ipMode == IpMode.BOTH && SettingsCodec.decode(emptyMap()).ipMode == IpMode.BOTH)
    val imported = SettingsCodec.import(SettingsCodec.export(s), AppSettings())
    T.check("ayar koduyla dışa/içe aktarılır", imported != null && imported.ipMode == IpMode.V4)
    T.check("IpMode kimlikleri benzersiz", IpMode.values().map { it.id }.toSet().size == IpMode.values().size && IpMode.values().size == 2)
    T.check("tüm dillerde IP sürümü metinleri dolu", Lang.values().map { L.of(it) }.all { t -> t.IP_MODE.isNotBlank() && t.IP_MODE_NOTE.isNotBlank() && t.OPT_IP_MODE.size == 2 && t.OPT_IP_MODE.all { it.contains("IPv4") } &&
        t.TEST_IPV6.contains("IPv6") && t.errUntrusted("X").contains("X") })
}
