package app.dnshizli.selftest

import app.dnshizli.core.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Güvenlik incelemesi (pentest) bulgularının düz DNS tarafındaki karşılıkları ve paket/önbellek sağlamlığı:
 * soru bölümü denetimi, kaynak portu değişimi, özdeş soruların birleşmesi, önbellek bayt sınırı ve TTL eskitme,
 * UDP sağlama toplamı, büyük cevapların kesilmesi, ilk çözümleme doğrulaması ve rastgele girdi taraması.
 */

private val lo: InetAddress = InetAddress.getLoopbackAddress()
private val CIP = Packets.ip(10, 111, 222, 1)
private val FIP = Packets.ip(10, 111, 222, 2)

/** DNS cevabı: sorgunun kendisi + bir A kaydı. [question] verilirse soru bölümü o sorgudan alınır (sahte cevap). */
private fun aAnswer(q: ByteArray, len: Int, ip: ByteArray, ttl: Int = 60): ByteArray = buildAnswer(q, len, aRecord(ip, ttl), 1)

/** Kaynak portlarını kaydeden, isteğe göre geciken ya da önce sahte cevap gönderen UDP DNS sunucusu. */
private class PortDns(
    val delayMs: Long = 0,
    /** Doluysa her soruya önce soru bölümü başka bir ada ait (aynı kimlikli) sahte cevap gönderilir. */
    val forgeFirst: Boolean = false,
    /** Doluysa bu kadar baytlık (sığmayan) bir cevap gönderilir. */
    val hugeReply: Int = 0,
    /** Gerçek cevapta soru adının harfleri karıştırılır (0x20 benzeri). */
    val mixCase: Boolean = false,
) : AutoCloseable {
    val socket = DatagramSocket(0, lo)
    val ports: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    val received = AtomicInteger()
    val addr: InetSocketAddress get() = InetSocketAddress(lo, socket.localPort)

    init {
        Thread {
            val buf = ByteArray(4096)
            val p = DatagramPacket(buf, buf.size)
            while (!socket.isClosed) {
                try { p.length = buf.size; socket.receive(p) } catch (_: Exception) { return@Thread }
                received.incrementAndGet()
                ports.add(p.port)
                val q = buf.copyOf(p.length)
                val to = p.socketAddress
                Thread {
                    try {
                        if (delayMs > 0) Thread.sleep(delayMs)
                        if (forgeFirst) {
                            val evil = Dns.buildQuery(Packets.u16(q, 0), "evil.test")
                            val forged = aAnswer(evil, evil.size, byteArrayOf(6, 6, 6, 6))
                            socket.send(DatagramPacket(forged, forged.size, to))
                            Thread.sleep(40)
                        }
                        val r = if (hugeReply > 0) huge(q, hugeReply) else aAnswer(q, q.size, byteArrayOf(1, 2, 3, 4))
                        if (mixCase) {
                            var i = 12
                            while (i < q.size && r[i].toInt() != 0) {
                                val l = r[i].toInt() and 0xFF
                                for (k in 1..l) if (k % 2 == 1 && r[i + k] in 'a'.code.toByte()..'z'.code.toByte()) r[i + k] = (r[i + k] - 32).toByte()
                                i += 1 + l
                            }
                        }
                        socket.send(DatagramPacket(r, r.size, to))
                    } catch (_: Exception) {}
                }.apply { isDaemon = true; start() }
            }
        }.apply { isDaemon = true; start() }
    }

    /** Tek TXT kaydı içeren, [size] bayta yakın büyüklükte cevap. */
    private fun huge(q: ByteArray, size: Int): ByteArray {
        val rec = java.io.ByteArrayOutputStream()
        val rdLen = size - q.size - 12
        rec.write(byteArrayOf(0xC0.toByte(), 0x0C, 0, 16, 0, 1, 0, 0, 0, 60, (rdLen ushr 8).toByte(), rdLen.toByte()))
        var left = rdLen
        while (left > 0) {
            val n = minOf(255, left - 1)
            rec.write(n)
            repeat(n) { rec.write('x'.code) }
            left -= n + 1
        }
        return buildAnswer(q, q.size, rec.toByteArray(), 1)
    }

    override fun close() = socket.close()
}

private fun query(id: Int, name: String = "example.com", srcPort: Int = 40000): ByteArray {
    val dns = Dns.buildQuery(id, name)
    val b = ByteArray(Packets.HDR + dns.size)
    b[0] = 0x45
    Packets.put16(b, 2, b.size)
    Packets.put16(b, 6, 0x4000)
    b[8] = 64
    b[9] = 17
    Packets.put32(b, 12, CIP)
    Packets.put32(b, 16, FIP)
    Packets.put16(b, 10, Packets.checksum(b, 0, 20))
    Packets.put16(b, 20, srcPort)
    Packets.put16(b, 22, 53)
    Packets.put16(b, 24, 8 + dns.size)
    System.arraycopy(dns, 0, b, 28, dns.size)
    return b
}

private class Fw(ups: List<InetSocketAddress>, rotateAfter: Int = DnsForwarder.ROTATE_AFTER, giveUp: Long = 4000, cache: Int = 256) : AutoCloseable {
    val tun = LinkedBlockingQueue<ByteArray>()
    val fw = DnsForwarder(
        upstreams = ups, writeToTun = { b, o, l -> tun.add(b.copyOfRange(o, o + l)) },
        retryAfterMs = 1200, giveUpAfterMs = giveUp, sweepMs = 50, cacheEntries = cache, rotateAfter = rotateAfter,
    ).also { it.start() }

    fun send(id: Int, name: String = "example.com", port: Int = 40000) { val p = query(id, name, port); fw.onPacket(p, p.size) }
    fun reply(ms: Long = 2000): ByteArray? = tun.poll(ms, TimeUnit.MILLISECONDS)
    override fun close() = fw.close()
}

private fun lastIp(r: ByteArray): String = (r.size - 4 until r.size).joinToString(".") { (r[it].toInt() and 0xFF).toString() }

fun runHardeningTests() {
    println("\nGüvenlik ve sağlamlık (pentest bulguları)\n")
    testQuestionCheck()
    testPortRotation()
    testMerge()
    testCacheLimits()
    testChecksumAndIdent()
    testPartialStart()
    testTruncation()
    testBootstrapValidation()
    testParserFuzz()
    testImportPrivacy()
}

private fun testQuestionCheck() {
    T.group("Güvenlik: cevabın soru bölümü denetlenir (RFC 5452)")
    PortDns(forgeFirst = true).use { srv ->
        Fw(listOf(srv.addr)).use { h ->
            h.send(0x5151, port = 44100)
            val r = h.reply()
            T.check("aynı kimlikli ama başka ada ait sahte cevap iletilmez, gerçeği iletilir", r != null && lastIp(r) == "1.2.3.4", r?.let { lastIp(it) } ?: "cevap yok")
            T.check("ikinci bir cevap yazılmaz", h.reply(300) == null)
            T.check("reddedilen sahte cevap sayılır", h.fw.stats().rejected == 1L, h.fw.stats().toString())
            h.send(0x5152, port = 44101)
            T.check("sahte cevap önbelleğe de girmez (sonraki soru da gerçek)", h.reply()?.let { lastIp(it) } == "1.2.3.4")
        }
    }
    PortDns(mixCase = true).use { srv ->
        Fw(listOf(srv.addr)).use { h ->
            h.send(0x6161, "mixed.example.com", 44200)
            T.check("adın büyük/küçük harf farkı kabul edilir", h.reply() != null && h.fw.stats().rejected == 0L)
        }
    }
    val q = Dns.buildQuery(7, "a.example.com")
    val qEnd = Dns.questionEnd(q, 0, q.size)
    val good = aAnswer(q, q.size, byteArrayOf(1, 1, 1, 1))
    T.check("soru sonu doğru hesaplanır", qEnd == q.size)
    T.check("doğru cevap kabul", Dns.sameQuestion(q, 0, qEnd, good, 0, good.size))
    T.check("QR=0 (sorgu) reddedilir", !Dns.sameQuestion(q, 0, qEnd, q, 0, q.size))
    val op = good.copyOf().also { Packets.put16(it, 2, 0x8180 or (2 shl 11)) }
    T.check("farklı OPCODE reddedilir", !Dns.sameQuestion(q, 0, qEnd, op, 0, op.size))
    val type = good.copyOf().also { Packets.put16(it, qEnd - 4, 28) }
    T.check("farklı soru türü (AAAA) reddedilir", !Dns.sameQuestion(q, 0, qEnd, type, 0, type.size))
    val two = good.copyOf().also { Packets.put16(it, 4, 2) }
    T.check("iki sorulu cevap reddedilir", !Dns.sameQuestion(q, 0, qEnd, two, 0, two.size))
    val formerr = ByteArray(12).also { Packets.put16(it, 0, 7); Packets.put16(it, 2, 0x8181) }
    T.check("soru bölümü boş FORMERR cevabı kabul (önbelleğe girmez)", Dns.sameQuestion(q, 0, qEnd, formerr, 0, 12) && Dns.cacheTtl(formerr, 12) == 0)
    val emptyOk = ByteArray(12).also { Packets.put16(it, 0, 7); Packets.put16(it, 2, 0x8180) }
    T.check("soru bölümü boş başarılı cevap reddedilir", !Dns.sameQuestion(q, 0, qEnd, emptyOk, 0, 12))
    T.check("kesik cevap reddedilir", !Dns.sameQuestion(q, 0, qEnd, good, 0, 20))
}

private fun testPortRotation() {
    T.group("Güvenlik: kaynak portu düzenli değişir")
    PortDns().use { srv ->
        Fw(listOf(srv.addr), rotateAfter = 3).use { h ->
            var ok = 0
            for (i in 0 until 16) { h.send(100 + i, "r$i.example.com", 45000 + i); if (h.reply() != null) ok++ }
            T.check("tüm sorular cevaplandı", ok == 16, "ok=$ok")
            T.check("16 soruda en az 4 farklı kaynak portu kullanıldı", srv.ports.size >= 4, "port=${srv.ports.size}")
            T.check("yuvalar hâlâ açık ve çalışıyor", h.fw.localPorts().all { it > 0 })
        }
    }
    PortDns(delayMs = 30).use { srv ->
        Fw(listOf(srv.addr), rotateAfter = 8).use { h ->
            // Sürekli trafikte (hep bekleyen soru varken) de port değişebilmeli: 5 ms arayla 100 soru, sunucu 30 ms gecikir.
            for (i in 0 until 100) { h.send(200 + i, "b$i.example.com", 46000 + i); Thread.sleep(5) }
            var ok = 0
            repeat(100) { if (h.reply(3000) != null) ok++ }
            T.check("sürekli trafikte 100 sorunun 100'ü cevaplandı (port değişirken cevap kaybolmaz)", ok == 100, "ok=$ok")
            T.check("sürekli trafikte de port değişti", srv.ports.size >= 5, "port=${srv.ports.size}")
        }
    }
}

private fun testMerge() {
    T.group("Özdeş soruların birleşmesi")
    PortDns(delayMs = 200).use { srv ->
        Fw(listOf(srv.addr)).use { h ->
            for (i in 0 until 5) h.send(0x700 + i, "same.example.com", 47000 + i)
            val got = HashMap<Int, Int>()
            repeat(5) { val r = h.reply() ?: return@repeat; got[Packets.u16(r, 28)] = Packets.u16(r, 22) }
            T.check("5 özdeş soru sunucuya tek kez gitti", srv.received.get() == 1, "sunucu=${srv.received.get()}")
            T.check("5 istemcinin hepsi kendi kimliği ve portuyla cevap aldı", (0 until 5).all { got[0x700 + it] == 47000 + it }, got.toString())
            T.check("birleştirme sayacı 4", h.fw.stats().merged == 4L, h.fw.stats().toString())
            T.check("bekleyen soru kalmadı", h.fw.pendingCount() == 0)
            h.send(0x710, "same.example.com", 47010)
            T.check("sonraki aynı soru önbellekten", h.reply(500) != null && srv.received.get() == 1)
        }
    }
}

private fun testCacheLimits() {
    T.group("Önbellek: bayt sınırı ve TTL eskitme")
    var now = 0L
    val c = DnsCache(maxEntries = 100, nowMs = { now }, maxBytes = 1000)
    val big = ByteArray(400).also { Packets.put16(it, 2, 0x8180) }
    for (k in listOf("a", "b", "c")) c.put(k, big, big.size, 60)
    T.check("bayt sınırı aşılmaz (3×400 > 1000)", c.byteSize() <= 1000 && c.size() == 2, "bayt=${c.byteSize()} kayıt=${c.size()}")
    T.check("en eski kayıt atıldı", c.get("a", 1, ByteArray(500), 0) == -1 && c.get("c", 1, ByteArray(500), 0) == 400)
    c.put("huge", ByteArray(DnsCache.MAX_ENTRY_BYTES + 1), DnsCache.MAX_ENTRY_BYTES + 1, 60)
    T.check("tek başına çok büyük cevap saklanmaz", c.get("huge", 1, ByteArray(20000), 0) == -1)
    T.check("hedef tampona sığmayan kayıt -1 döner (taşma yok)", c.get("c", 1, ByteArray(100), 0) == -1)
    c.put("c", big, 100, 60)
    T.check("aynı anahtarın yeniden yazılması bayt sayısını şişirmez", c.byteSize() == 400 + 100, "bayt=${c.byteSize()}")

    now = 0
    val q = Dns.buildQuery(9, "ttl.example.com")
    val ans = aAnswer(q, q.size, byteArrayOf(4, 4, 4, 4), ttl = 60)
    val cc = DnsCache(maxEntries = 10, nowMs = { now })
    cc.put("t", ans, ans.size, 60)
    now = 20_500
    val out = ByteArray(200)
    val n = cc.get("t", 0x1234, out, 0)
    val ttlAfter = Packets.i32(out, n - 10)
    T.check("önbellekten verilen cevapta TTL 20 sn azalır (60 -> 40)", n == ans.size && ttlAfter == 40, "ttl=$ttlAfter")
    T.check("orijinal kayıt değişmez (bir sonraki okumada yine doğru)", run { now = 30_000; cc.get("t", 1, out, 0); Packets.i32(out, n - 10) == 30 })
    val opt = q.copyOf(q.size + 11).also {
        Packets.put16(it, 2, 0x8180); Packets.put16(it, 10, 1)
        val p = q.size
        it[p] = 0; Packets.put16(it, p + 1, 41); Packets.put16(it, p + 3, 1232); Packets.put32(it, p + 5, 0x00008000)
    }
    Dns.ageTtls(opt, 0, opt.size, 100)
    T.check("OPT kaydının bayrak alanı (TTL yeri) değiştirilmez", Packets.i32(opt, q.size + 5) == 0x00008000)
}

private fun testChecksumAndIdent() {
    T.group("Tünel paketleri: UDP sağlama toplamı ve IP kimliği")
    val out = ByteArray(Packets.HDR + 33)
    for (i in 0 until 33) out[Packets.HDR + i] = (i * 13 + 1).toByte()
    Packets.writeHeaders(out, FIP, CIP, 53, 40000, 33, 77)
    T.check("UDP sağlaması geçerli (tek sayıda bayt dahil)", Packets.udpChecksumOk(out, 20, 8 + 33, FIP, CIP) && Packets.u16(out, 26) != 0)
    T.check("IP kimliği başlığa yazılır", Packets.u16(out, 4) == 77)
    out[Packets.HDR + 5] = (out[Packets.HDR + 5] + 1).toByte()
    T.check("tek bayt bozulunca sağlama tutmaz", !Packets.udpChecksumOk(out, 20, 8 + 33, FIP, CIP))
    // Bilinen örnek: tümü sıfır veri, sözde başlık elle hesaplanmış toplamla karşılaştırılır.
    val z = ByteArray(Packets.HDR + 4)
    Packets.writeHeaders(z, Packets.ip(1, 2, 3, 4), Packets.ip(5, 6, 7, 8), 53, 53, 4)
    var sum = 0x0102 + 0x0304 + 0x0506 + 0x0708 + 17 + 12 + 53 + 53 + 12
    while (sum ushr 16 != 0) sum = (sum and 0xFFFF) + (sum ushr 16)
    T.check("sözde başlıklı toplam elle hesaplananla aynı", Packets.u16(z, 26) == (sum.inv() and 0xFFFF))
    val seen = HashSet<Int>()
    var zero = false
    repeat(5000) { val v = Packets.nextIdent(); if (v == 0) zero = true; seen.add(v) }
    T.check("IP kimliği 5000 çağrıda tekrar etmez ve 0 olmaz", seen.size == 5000 && !zero)
}

private fun testTruncation() {
    T.group("Sığmayan büyük cevap: kesildi (TC) işareti")
    PortDns(hugeReply = 20_000).use { srv ->
        Fw(listOf(srv.addr)).use { h ->
            h.send(0x2020, "huge.example.com", 48000)
            val parts = ArrayList<ByteArray>()
            while (true) { val r = h.reply(if (parts.isEmpty()) 2000 else 300) ?: break; parts.add(r) }
            val first = parts.firstOrNull()
            T.check("cevap parçalar halinde iletildi", parts.size >= 2, "parça=${parts.size}")
            T.check("TC bayrağı açık", first != null && (first[28 + 2].toInt() and 0x02) != 0)
            h.send(0x2021, "huge.example.com", 48001)
            while (h.reply(500) != null) {}
            T.check("kesik cevap önbelleğe alınmadı (ikinci soru yine sunucuya gitti)", srv.received.get() == 2, "sunucu=${srv.received.get()}")
        }
    }
}

private fun testBootstrapValidation() {
    T.group("İlk çözümleme (bootstrap) doğrulaması")
    fun server(handler: (ByteArray, Int) -> ByteArray?): DatagramSocket {
        val s = DatagramSocket(0, lo)
        Thread {
            val buf = ByteArray(1500)
            val p = DatagramPacket(buf, buf.size)
            while (!s.isClosed) {
                try { p.length = buf.size; s.receive(p) } catch (_: Exception) { return@Thread }
                val r = handler(buf, p.length) ?: continue
                try { s.send(DatagramPacket(r, r.size, p.socketAddress)) } catch (_: Exception) {}
            }
        }.apply { isDaemon = true; start() }
        return s
    }
    val wrongName = server { b, n ->
        val other = Dns.buildQuery(Packets.u16(b, 0), "evil.test")
        aAnswer(other, other.size, byteArrayOf(5, 6, 7, 8))
    }
    T.check("başka bir adın cevabı kabul edilmez", Bootstrap.resolveA("dns.test", lo.hostAddress, wrongName.localPort, timeoutMs = 300).isEmpty())
    wrongName.close()
    val mixed = server { b, n ->
        val q = b.copyOf(n)
        val r1 = aAnswer(q, q.size, byteArrayOf(10, 0, 0, 1))
        // ikinci A kaydı ekle: 127.0.0.1, sonra herkese açık 9.9.9.9
        val extra = byteArrayOf(0xC0.toByte(), 0x0C, 0, 1, 0, 1, 0, 0, 0, 60, 0, 4)
        val r = r1 + extra + byteArrayOf(127, 0, 0, 1) + extra + byteArrayOf(9, 9, 9, 9)
        Packets.put16(r, 6, 3)
        r
    }
    T.check("yalnızca herkese açık adresler kabul edilir", Bootstrap.resolveA("dns.test", lo.hostAddress, mixed.localPort) == listOf("9.9.9.9"))
    mixed.close()
    T.check("özel/döngü/çoklu yayın adresleri global değil",
        !Dns.isGlobalIpv4(10, 1, 2, 3) && !Dns.isGlobalIpv4(127, 0, 0, 1) && !Dns.isGlobalIpv4(192, 168, 1, 1) &&
            !Dns.isGlobalIpv4(172, 20, 0, 1) && !Dns.isGlobalIpv4(169, 254, 1, 1) && !Dns.isGlobalIpv4(100, 100, 1, 1) &&
            !Dns.isGlobalIpv4(224, 0, 0, 1) && !Dns.isGlobalIpv4(0, 0, 0, 0) && !Dns.isGlobalIpv4(255, 255, 255, 255))
    T.check("herkese açık adresler global",
        Dns.isGlobalIpv4(1, 1, 1, 1) && Dns.isGlobalIpv4(9, 9, 9, 9) && Dns.isGlobalIpv4(172, 15, 0, 1) && Dns.isGlobalIpv4(100, 63, 0, 1) &&
            Dns.isGlobalIpv4(194, 242, 2, 2))
}

private fun testParserFuzz() {
    T.group("Dayanıklılık: ayrıştırıcılarda rastgele girdi")
    val rnd = Random(2026)
    var crash: Throwable? = null
    val base = aAnswer(Dns.buildQuery(1, "fuzz.example.com"), 34, byteArrayOf(1, 2, 3, 4))
    repeat(60_000) {
        val b = if (rnd.nextBoolean()) ByteArray(rnd.nextInt(90)).also { rnd.nextBytes(it) }
        else base.copyOf().also { x -> repeat(1 + rnd.nextInt(5)) { x[rnd.nextInt(x.size)] = rnd.nextInt().toByte() } }
        val n = if (b.isEmpty()) 0 else rnd.nextInt(b.size + 1)
        try {
            val qe = Dns.questionEnd(b, 0, n)
            Dns.sameQuestion(b, 0, qe, b, 0, n)
            Dns.sameQuestion(base, 0, Dns.questionEnd(base, 0, 34), b, 0, n)
            Dns.ageTtls(b, 0, n, rnd.nextInt(400))
            Dns.cacheTtl(b, 0, n)
            Dns.isBlocked(b, 0, n)
            Dns.aRecords(b, n)
            if (n >= 28) Packets.udpChecksumOk(b, 20, n - 20, 1, 2)
        } catch (e: Throwable) { crash = e }
    }
    T.check("60 bin rastgele/bozuk mesaj hiçbir ayrıştırıcıyı çökertmez", crash == null, crash?.toString() ?: "")
    PortDns().use { srv ->
        Fw(listOf(srv.addr)).use { h ->
            var thrown = 0
            val good = query(1)
            repeat(30_000) {
                val m = good.copyOf().also { x -> repeat(1 + rnd.nextInt(6)) { x[rnd.nextInt(x.size)] = rnd.nextInt().toByte() } }
                try { h.fw.onPacket(m, rnd.nextInt(m.size + 1)) } catch (_: Throwable) { thrown++ }
            }
            T.check("30 bin bozuk tünel paketi yönlendiriciyi çökertmez", thrown == 0, "hata=$thrown")
            h.tun.clear()
            Thread.sleep(300)
            h.tun.clear()
            h.send(0x4242, "after-fuzz.example.com", 49000)
            T.check("tarama sonrası yönlendirici çalışmaya devam ediyor", h.reply() != null)
        }
    }
}

private fun testImportPrivacy() {
    T.group("İçe aktarma: gizlilik gevşemesi işaretlenir, seçim içe aktarılmaz")
    val base = AppSettings(notifyDrop = true, hideOnLockscreen = true, lastServer = "cloudflare", recent = listOf("cloudflare"))
    T.check("uyarıları kapatmak işaretlenir", SensitiveChange.PRIVACY in ImportReview.changes(base, base.copy(notifyDrop = false)))
    T.check("kilit ekranında göstermek işaretlenir", SensitiveChange.PRIVACY in ImportReview.changes(base, base.copy(hideOnLockscreen = false)))
    T.check("sıkılaştırmak işaretlenmez", ImportReview.changes(base.copy(notifyDrop = false), base).none { it == SensitiveChange.PRIVACY })
    val hostile = base.copy(lastServer = "quad9", recent = listOf("quad9", "google"), notifyDrop = false)
    val code = SettingsCodec.export(hostile)
    val back = SettingsCodec.import(code, base)
    T.check("içe aktarma geçerli", back != null)
    T.check("son sunucu ve geçmiş içe aktarılmaz", back != null && back.lastServer == "cloudflare" && back.recent == listOf("cloudflare"))
    T.check("diğer ayarlar uygulanır", back != null && !back.notifyDrop)
}

private fun testPartialStart() {
    T.group("Sağlamlık: kısmi başlatmada geri alma")
    val socks = ArrayList<java.net.DatagramSocket>()
    var made = 0
    val fw = DnsForwarder(
        listOf(java.net.InetSocketAddress("127.0.0.1", 9)), { _, _, _ -> },
        protect = { s -> socks.add(s); true },
        threadFactory = { r, n -> if (++made == 2) throw IllegalStateException("iş parçacığı açılamadı") else Thread(r, n).apply { isDaemon = true } },
    )
    val threw = try { fw.start(); false } catch (_: IllegalStateException) { true }
    T.check("ikinci yuvada hata olursa start() hatayı iletir", threw)
    T.check("daha önce açılan soketler kapatılır (sızıntı yok)", socks.isNotEmpty() && socks.all { it.isClosed }, socks.map { it.isClosed }.toString())
}
