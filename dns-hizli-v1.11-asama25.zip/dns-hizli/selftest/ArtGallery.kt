package app.dnshizli.selftest

import app.dnshizli.core.AeroArt
import app.dnshizli.core.AeroTheme
import app.dnshizli.core.BubbleField
import app.dnshizli.core.Gfx
import app.dnshizli.core.Icon
import app.dnshizli.core.Icons
import app.dnshizli.core.Rgb
import app.dnshizli.core.Themes

/** Bileşen galerisi: tüm cam parçaları tek sayfada, tema başına. Görsel tasarımı gözle değerlendirmek içindir. */
object ArtGallery {
    const val W = 360
    const val H = 1130

    fun draw(g: Gfx, th: AeroTheme, glass: Float = 0.55f) {
        val art = AeroArt(th, glass)
        art.sky(g, W.toFloat(), H.toFloat())
        val bf = BubbleField(5L)
        bf.setCount(14)
        for (b in bf.items) art.bubble(g, b.x * W, b.y * H, b.r, b.alpha)

        g.paint(th.text)
        g.text("Bileşen galerisi · ${th.name}", 20f, 34f, 15f, true, 0)

        // ana küre
        art.orb(g, 180f, 150f, 92f, 0.66f, 1.1f, 0.85f, 0f, 0f)

        // küçük küreler: kapalı, bağlanıyor, hata
        art.orb(g, 70f, 330f, 44f, 0.0f, 0f, 0f, 0f, 0f)
        art.orb(g, 180f, 330f, 44f, 0.40f, 2.0f, 0.5f, 0f, 0f)
        art.orb(g, 290f, 330f, 44f, 0.10f, 0.5f, 0f, 1f, 0f)

        // kartlar
        fun row(y: Float, title: String, sel: Float, press: Float) {
            art.card(g, 20f, y, 340f, y + 66f, 20f, selected = sel, press = press)
            g.paint(th.text); g.text(title, 76f, y + 29f, 16f, true, 0)
            g.paint(th.textSoft); g.text("Hızlı, gizlilik odaklı", 76f, y + 49f, 13f, false, 0)
            g.paint(Rgb.alpha(th.accent, 0.35f)); g.circle(46f, y + 33f, 20f)
            Icons.draw(g, Icon.BOLT, 46f, y + 33f, 22f, th.control, 2f)
            art.bars(g, 290f, y + 38f, 3, sel > 0f)
            Icons.draw(g, Icon.STAR, 330f, y + 18f, 18f, th.textSoft, 1.8f)
        }
        row(410f, "Cloudflare", 0f, 0f)
        row(486f, "Google (seçili)", 1f, 0f)
        row(562f, "Quad9 (basılı)", 0f, 1f)

        // çipler
        art.card(g, 20f, 650f, 92f, 684f, 17f, shadow = 0.6f)
        g.paint(th.text); g.text("Tümü", 56f, 672f, 14f, false, 1)
        art.card(g, 100f, 650f, 190f, 684f, 17f, shadow = 0.6f)
        g.paint(th.text); g.text("Gizlilik", 145f, 672f, 14f, false, 1)
        art.pill(g, 198f, 650f, 280f, 684f)
        g.paint(th.onControl); g.text("Reklam", 239f, 672f, 14f, true, 1)

        // anahtarlar ve kaydırıcı
        art.switch(g, 20f, 704f, 52f, 30f, 0f, 0f)
        art.switch(g, 84f, 704f, 52f, 30f, 1f, 0f)
        art.slider(g, 160f, 719f, 180f, 0.6f, 0f)

        // segment
        art.card(g, 20f, 750f, 340f, 750f + 1f, 1f, shadow = 0f)
        art.segmented(g, 20f, 750f, 260f, 790f, 3, 1f)
        g.paint(th.textSoft); g.text("Kapalı", 20f + 40f, 775f, 13f, false, 1)
        g.paint(th.onControl); g.text("Az", 20f + 120f, 775f, 13f, true, 1)
        g.paint(th.textSoft); g.text("Çok", 20f + 200f, 775f, 13f, false, 1)

        // tema örnekleri
        var x = 38f
        art.swatch(g, x, 836f, 17f, null, 0f); x += 46f
        for ((i, t) in Themes.all.withIndex()) {
            art.swatch(g, x, 836f, 17f, t, if (t.id == th.id) 1f else 0f)
            x += 46f
        }

        // simgeler
        art.card(g, 20f, 872f, 340f, 1010f, 20f)
        for ((i, ic) in Icon.values().withIndex()) {
            val col = i % 7
            val rw = i / 7
            Icons.draw(g, ic, 52f + col * 42f, 906f + rw * 44f, 26f, if (ic == Icon.POWER) th.control else th.text, 2f)
        }

        // çubuklar
        for (lv in 0..4) {
            art.bars(g, 30f + lv * 56f, 1060f, lv, true)
            g.paint(th.textSoft); g.text("$lv", 38f + lv * 56f, 1082f, 12f, false, 1)
        }

        // alt sayfa örneği
        art.card(g, 20f, 1092f, 340f, 1170f, 24f, strong = 1f)
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val outDir = args.getOrNull(0) ?: "."
        val only = args.getOrNull(1)
        println("Yazı tipi: " + AwtGfx.fontName())
        for (th in Themes.all) {
            if (only != null && th.id != only) continue
            val cv = AwtCanvas(W, H, 2f)
            draw(cv.gfx, th)
            cv.savePng("$outDir/galeri-${th.id}.png")
            cv.dispose()
            println("yazıldı: $outDir/galeri-${th.id}.png")
        }
    }
}
