package app.dnshizli.selftest

import app.dnshizli.core.*

/** Dar genişlikte ve boş metinde sarmanın çökmediğini denetler (ana ekran çökmesinin regresyon testi). */
fun runWrapGuardTests() {
    T.group("Metin sarma: dar genişlik ve boş metin çökmez")
    run {
        var ok = true
        for (w in listOf(-10f, 0f, 0.5f, 3f, 12f, 40f)) for (t in listOf("", " ", "Reklam+", "DPI atlatma, Engelli siteleri açar", "ÇokUzunBirKelimeYaniSigmayan")) {
            try { TextFit.wrap(FixedMetrics, t, w, 14f, true) } catch (e: Exception) { ok = false }
        }
        T.check("TextFit.wrap: negatif, sıfır ve çok dar genişliklerde çökmez", ok)
    }
}
