package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*
import java.lang.management.ManagementFactory

private val shapeMx = ManagementFactory.getThreadMXBean() as com.sun.management.ThreadMXBean

/** Küre şekilleri (küre, üçgen, kare, altıgen, yıldız), tema başına seçim ve sıvının hız tonu. */
fun runOrbShapeTests() {
    val r = 60f

    T.group("Küre şekilleri: geometri")
    T.check("otuz yedi şekil var (12 + 25 kalkan), kimlikler benzersiz, ilki küre (varsayılan)",
        OrbShape.values().size == 37 && OrbShape.values().map { it.id }.toSet().size == 37 && OrbShape.DEFAULT == OrbShape.CIRCLE &&
            OrbShape.values().map { it.id } == listOf("circle", "triangle", "square", "hexagon", "star", "octagon", "pentagon", "rectangle", "inv_triangle", "diamond", "flower", "star6") + (1..25).map { "shield_$it" })
    T.check("ters üçgen üçgenin tersi: simge zıt yöne kayar", OrbShape.INV_TRIANGLE.iconDy < 0f && OrbShape.TRIANGLE.iconDy > 0f)
    T.check("byId gidiş-dönüş, bilinmeyen null", OrbShape.values().all { OrbShape.byId(it.id) == it } && OrbShape.byId("zzz") == null && OrbShape.byId(null) == null)
    for (s in OrbShape.values()) {
        val p = s.outline(GPath(), r)
        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        var closes = 0
        var finite = true
        var lx = 0f; var ly = 0f
        fun see(x: Float, y: Float) {
            if (!x.isFinite() || !y.isFinite()) finite = false
            minX = minOf(minX, x); maxX = maxOf(maxX, x); minY = minOf(minY, y); maxY = maxOf(maxY, y)
            lx = x; ly = y
        }
        p.visit(object : PathSink {
            override fun move(x: Float, y: Float) = see(x, y)
            override fun line(x: Float, y: Float) = see(x, y)
            // Eğrinin gerçek ucu için eğri üzerinde 20 nokta örneklenir (kontrol noktası değil).
            override fun quad(cx: Float, cy: Float, x: Float, y: Float) {
                val x0 = lx; val y0 = ly
                for (k in 1..20) { val u = k / 20f; val v = 1f - u
                    see(v * v * x0 + 2f * v * u * cx + u * u * x, v * v * y0 + 2f * v * u * cy + u * u * y) }
            }
            override fun cubic(c1x: Float, c1y: Float, c2x: Float, c2y: Float, x: Float, y: Float) {
                val x0 = lx; val y0 = ly
                for (k in 1..20) { val u = k / 20f; val v = 1f - u
                    see(v * v * v * x0 + 3f * v * v * u * c1x + 3f * v * u * u * c2x + u * u * u * x,
                        v * v * v * y0 + 3f * v * v * u * c1y + 3f * v * u * u * c2y + u * u * u * y) }
            }
            override fun close() { closes++ }
        })
        T.check("${s.id}: yol dolu, kapalı ve sonlu", !p.isEmpty && closes >= 1 && finite)
        T.check("${s.id}: dikeyde bildirilen üst/alt uçlar içinde (yerleşim değişmez)",
            kotlin.math.abs(minY - s.topF * r) <= 1.5f && kotlin.math.abs(maxY - s.bottomF * r) <= 1.5f, "$minY..$maxY beklenen ${s.topF * r}..${s.bottomF * r}")
        T.check("${s.id}: yatayda küre genişliğini aşmaz", minX >= -r - 0.5f && maxX <= r + 0.5f && (s == OrbShape.CIRCLE || (minX >= -r * 0.99f && maxX <= r * 0.99f)), "$minX..$maxX")
        T.check("${s.id}: merkeze yakın ortalanmış (dikey taşma dengeli)", kotlin.math.abs((minY + maxY) / 2f - (s.topF + s.bottomF) / 2f * r) < 0.05f * r)
        T.check("${s.id}: yeniden kurmak aynı yolu üretir", s.outline(p, r).size == s.outline(GPath(), r).size)
    }

    T.group("Küre şekilleri: tema başına ayar")
    run {
        T.check("boş ayar: her tema küre", OrbShapes.get("", "aqua") == OrbShape.CIRCLE && OrbShapes.get(null, "ocean") == OrbShape.CIRCLE)
        var s = ""
        s = OrbShapes.with(s, "aqua", OrbShape.HEXAGON)
        s = OrbShapes.with(s, "ocean", OrbShape.STAR)
        T.check("iki tema ayrı şekil tutar", OrbShapes.get(s, "aqua") == OrbShape.HEXAGON && OrbShapes.get(s, "ocean") == OrbShape.STAR && OrbShapes.get(s, "mint") == OrbShape.CIRCLE, s)
        T.check("kodlama gidiş-dönüş ve sıralı", OrbShapes.encode(OrbShapes.decode(s)) == s && s == "aqua=hexagon;ocean=star")
        s = OrbShapes.with(s, "aqua", OrbShape.CIRCLE)
        T.check("küreye dönmek kaydı siler", s == "ocean=star", s)
        val junk = "aqua=zzz;=star;a b=star;mint=triangle;=;;x=y=z;ocean"
        T.check("bozuk girdiler atılır, geçerli kalır", OrbShapes.decode(junk) == mapOf("mint" to OrbShape.TRIANGLE), OrbShapes.decode(junk).toString())
        val many = (1..60).joinToString(";") { "t$it=star" }
        T.check("kayıt sayısı sınırlı", OrbShapes.decode(many).size <= OrbShapes.MAX)
        T.check("çok uzun tema kimliği reddedilir", OrbShapes.decode("${"a".repeat(40)}=star").isEmpty())
    }
    run {
        val st = AppSettings(orbShapes = "aqua=hexagon;ocean=star")
        T.check("ayar kodlayıcı gidiş-dönüş", SettingsCodec.decode(SettingsCodec.encode(st)).orbShapes == "aqua=hexagon;ocean=star")
        T.check("varsayılan ayarda boş", AppSettings().orbShapes == "" && SettingsCodec.decode(emptyMap()).orbShapes == "")
        T.check("bozuk değer temizlenir", SettingsCodec.decode(mapOf("orbShapes" to "aqua=zzz;;;")).orbShapes == "")
        T.check("dışa/içe aktarılır (yerel durum değil)", SettingsCodec.import(SettingsCodec.export(st), AppSettings())?.orbShapes == "aqua=hexagon;ocean=star")
    }

    T.group("Küre şekilleri: sıvı hız tonu")
    run {
        T.check("dalga hızı sınırlı (0,55..1,45) ve gecikme arttıkça yavaşlar",
            (1..400 step 5).all { OrbMath.waveSpeed(it) in 0.55f..1.45f } && (1..399 step 3).all { OrbMath.waveSpeed(it + 1) <= OrbMath.waveSpeed(it) + 1e-6f })
        T.check("gecikme bilinmiyorsa dalga hızı ve ton nötr", OrbMath.waveSpeed(0) == 1f && OrbMath.tintAmount(0) == 0f && OrbMath.tintAmount(-5) == 0f)
        T.check("hızlıda canlı, yavaşta ağır dalga", OrbMath.waveSpeed(15) > 1.2f && OrbMath.waveSpeed(300) < 0.6f)
        T.check("ton oranı 0..0,45 aralığında", (0..600).all { OrbMath.tintAmount(it) in 0f..0.45f })
        T.check("ton süreklidir (komşu gecikmeler arasında sıçrama yok)", (2..600).all { kotlin.math.abs(OrbMath.tintAmount(it) - OrbMath.tintAmount(it - 1)) < 0.02f })
        T.check("orta gecikmede (60–80 ms) ton yok, temanın kendi rengi", (60..80).all { OrbMath.tintAmount(it) == 0f })
        T.check("hızlıda yeşil, yavaşta turuncu", OrbMath.tintColor(20) == 0xFF3DDC84.toInt() && OrbMath.tintColor(150) == 0xFFFF9800.toInt())
        T.check("yavaşlayınca ton güçlenir", OrbMath.tintAmount(200) > OrbMath.tintAmount(120) && OrbMath.tintAmount(120) > 0f)
    }

    T.group("Küre şekilleri: çizim")
    // 200x200 tuvalde merkez (100,100); sıvı seviyesi 0,66: şeklin alt kısmı dolu.
    fun render(style: UiStyle, shape: OrbShape, level: Float = 0.66f, error: Float = 0f, tint: Float = 0f): java.awt.image.BufferedImage {
        val c = AwtCanvas(200, 200, 1f)
        val art = ArtFactory.create(style, Themes.aqua, 0.55f)
        art.orbShape = shape
        art.liquidTint = 0xFFFF9800.toInt(); art.liquidTintAmt = tint
        art.orb(c.gfx, 100f, 100f, r, level, 0.7f, 0f, error, 0f)
        c.dispose()
        return c.image
    }
    fun alpha(im: java.awt.image.BufferedImage, dx: Float, dy: Float): Int = (im.getRGB((100 + dx * r).toInt(), (100 + dy * r).toInt()) ushr 24) and 0xFF
    // (şekil, içeride olması gerekenler, dışarıda olması gerekenler) noktaları: merkeze göre yarıçap katı
    val probes = mapOf(
        OrbShape.CIRCLE to Pair(listOf(0f to 0.3f, 0f to -0.5f, -0.6f to 0.1f), listOf(-0.85f to -0.85f, 0.85f to 0.85f, 0.9f to -0.9f)),
        OrbShape.TRIANGLE to Pair(listOf(0f to 0.5f, 0f to 0.1f, -0.4f to 0.55f), listOf(-0.8f to -0.5f, 0.8f to -0.5f, 0f to -1.0f)),
        OrbShape.SQUARE to Pair(listOf(0f to 0.3f, -0.7f to 0.2f, 0.6f to -0.6f), listOf(-0.97f to 0f, 0f to -0.97f, 0.97f to 0f)),
        OrbShape.HEXAGON to Pair(listOf(0f to 0.3f, -0.7f to 0f, 0.5f to 0.6f), listOf(-0.93f to -0.5f, 0.93f to 0.5f, -0.9f to 0.6f)),
        OrbShape.STAR to Pair(listOf(0f to 0.3f, -0.3f to 0.0f, 0.2f to -0.4f), listOf(-0.6f to -0.6f, 0.6f to -0.6f, 0.75f to 0.55f)),
        OrbShape.OCTAGON to Pair(listOf(0f to 0.3f, -0.7f to 0.2f, 0.6f to -0.6f), listOf(0.9f to -0.9f, -0.9f to -0.9f, -1.02f to 0f)),
        OrbShape.PENTAGON to Pair(listOf(0f to 0.3f, -0.5f to 0.5f, 0.2f to -0.4f), listOf(-0.8f to -0.7f, 0.8f to -0.7f, 0f to -1.0f)),
        OrbShape.RECTANGLE to Pair(listOf(0f to 0f, -0.8f to 0.3f, 0.8f to -0.4f), listOf(-0.6f to -0.85f, 0.6f to -0.85f, -1.02f to 0f)),
        OrbShape.DIAMOND to Pair(listOf(0f to 0.3f, 0f to -0.5f, -0.5f to 0f), listOf(-0.8f to -0.8f, 0.8f to 0.8f, 0.85f to -0.5f)),
        OrbShape.FLOWER to Pair(listOf(0f to 0.3f, 0f to -0.6f, -0.5f to 0.1f), listOf(-0.95f to -0.95f, 0.95f to -0.95f, -0.97f to 0.3f)),
        OrbShape.STAR6 to Pair(listOf(0f to 0.3f, 0f to -0.6f, -0.5f to 0.2f), listOf(-0.9f to -0.8f, 0.9f to -0.8f, -0.95f to 0.0f)),
        OrbShape.INV_TRIANGLE to Pair(listOf(0f to -0.3f, 0.4f to -0.5f, 0f to 0.2f), listOf(-0.9f to -0.3f, 0.9f to -0.3f, 0f to -1.0f)),
    )
    // Kalkanlar: gövdenin ortası dolu; kutunun yanları ve alt köşeleri (her kalkanda) boş.
    val shieldProbe = Pair(listOf(0f to 0.25f, 0.3f to 0.1f, 0f to -0.2f), listOf(-1.06f to 0f, 1.06f to 0f, -0.99f to 0.97f, 0.99f to 0.97f))
    for (st in UiStyle.values()) {
        for (sh in OrbShape.values()) {
            val im = render(st, sh)
            val (inside, outside) = probes[sh] ?: shieldProbe
            T.check("${st.label}/${sh.id}: içi dolu", inside.all { (x, y) -> alpha(im, x, y) > 30 }, inside.map { (x, y) -> alpha(im, x, y) }.toString())
            // Eco'nun filizi şeklin üstünden dışarı uzanır (süs); Y2K'nın krom halkası çizginin hemen dışındadır.
            val outs = if (st == UiStyle.ECO) outside.filter { (_, y) -> y > -0.6f } else outside
            T.check("${st.label}/${sh.id}: dışı boş", outs.all { (x, y) -> alpha(im, x, y) <= 2 }, outs.map { (x, y) -> alpha(im, x, y) }.toString())
        }
    }

    // Süsler her şekilde çizilir: stilin çizimi, süssüz taban çizimden (AeroArt) farklı olmalı ve süs şeklin üstünde kalmalı.
    fun renderArt(art: AeroArt, shape: OrbShape): java.awt.image.BufferedImage {
        val c = AwtCanvas(200, 200, 1f)
        art.orbShape = shape
        art.orb(c.gfx, 100f, 100f, r, 0.66f, 0.7f, 0f, 0f, 0f)
        c.dispose()
        return c.image
    }
    fun diff(a: java.awt.image.BufferedImage, b: java.awt.image.BufferedImage, y0: Int = 0, y1: Int = 200): Int {
        var n = 0
        for (y in y0 until y1) for (x in 0 until 200) if (a.getRGB(x, y) != b.getRGB(x, y)) n++
        return n
    }
    for (sh in OrbShape.values()) {
        val base = renderArt(AeroArt(Themes.aqua, 0.55f), sh)
        for (st in listOf(UiStyle.AERO, UiStyle.ECO, UiStyle.Y2K)) {
            val im = renderArt(ArtFactory.create(st, Themes.aqua, 0.55f), sh)
            T.check("${st.label}/${sh.id}: süsler çizilir", diff(im, base) > 60, diff(im, base).toString())
        }
        // Aero: çim yansıması şeklin alt yarısında, Eco/Y2K'dan bağımsız
        val aero = renderArt(ArtFactory.create(UiStyle.AERO, Themes.aqua, 0.55f), sh)
        val aeroBase = renderArt(AeroArt(Themes.aqua, 0.55f), sh)
        val lowerOnly = diff(aero, aeroBase, 0, 100 - (r * 0.1f).toInt())
        T.check("Aero/${sh.id}: çim yansıması yalnız altta (üst yarıda fark ${lowerOnly})", lowerOnly < diff(aero, aeroBase, 100, 200) / 4)
        // Y2K: krom halka şeklin üst ucunun hemen dışında opak
        val y2k = renderArt(ArtFactory.create(UiStyle.Y2K, Themes.aqua, 0.55f), sh)
        // Kalkanların üstü ortada çukur/tepe olabilir; halka kalkanlarda yalnız "çizilir" testiyle sınanır.
        if (!sh.isShield) {
            T.check("Y2K/${sh.id}: krom halka çizgiyi sarar", alpha(y2k, 0f, sh.topF - 1.5f / r) > 30, alpha(y2k, 0f, sh.topF - 1.5f / r).toString())
            T.check("Aqua/${sh.id}: halka yok", alpha(base, 0f, sh.topF - 1.5f / r) <= 2)
        }
        // Eco: filiz şeklin dışına çıkar (yaprak şeklin üst ucunun üstünde)
        val eco = renderArt(ArtFactory.create(UiStyle.ECO, Themes.aqua, 0.55f), sh)
        val ecoBase = renderArt(AeroArt(Themes.aqua, 0.55f), sh)
        val top = (100 + sh.topF * r).toInt() - 2
        T.check("Eco/${sh.id}: filiz şeklin üstüne çıkar", diff(eco, ecoBase, 0, top) > 20, diff(eco, ecoBase, 0, top).toString())
    }
    run {
        val im = render(UiStyle.AQUA, OrbShape.STAR)
        val pngDir = java.io.File(System.getProperty("java.io.tmpdir"), "dnshizli-shapes").also { it.mkdirs() }
        // Önizleme: tüm şekiller yan yana (elle bakmak için; testin geçmesi buna bağlı değildir)
        val shapesAll = OrbShape.values()
        fun sheetOf(items: List<Pair<UiStyle, OrbShape>>, name: String) {
            val rows = (items.size + 4) / 5
            val sheet = java.awt.image.BufferedImage(1000, 200 * rows, java.awt.image.BufferedImage.TYPE_INT_ARGB)
            val g2 = sheet.createGraphics()
            g2.color = java.awt.Color(0xC9E6F5); g2.fillRect(0, 0, sheet.width, sheet.height)
            items.forEachIndexed { i, (st, sh) -> g2.drawImage(render(st, sh), (i % 5) * 200, (i / 5) * 200, null) }
            g2.dispose()
            javax.imageio.ImageIO.write(sheet, "png", java.io.File(pngDir, name))
        }
        sheetOf(shapesAll.map { UiStyle.AQUA to it }, "sekiller.png")
        // Süslü stiller: bir kısım şekil Eco, bir kısmı Y2K ile
        sheetOf(shapesAll.filter { !it.isShield }.map { UiStyle.ECO to it } + shapesAll.filter { it.isShield }.take(10).map { UiStyle.ECO to it } +
            shapesAll.filter { it.isShield }.drop(10).take(10).map { UiStyle.Y2K to it }, "sekiller-stil.png")
        T.check("önizleme görseli üretildi", im.width == 200 && java.io.File(pngDir, "sekiller.png").length() > 1000)
    }
    run {
        // Hız tonu sıvının rengini değiştirir; sıvı olmayan yerler değişmez.
        val plain = render(UiStyle.AQUA, OrbShape.CIRCLE, tint = 0f)
        val tinted = render(UiStyle.AQUA, OrbShape.CIRCLE, tint = 0.45f)
        val x = (100 + 0.1f * r).toInt(); val y = (100 + 0.5f * r).toInt()
        val a = plain.getRGB(x, y); val b = tinted.getRGB(x, y)
        fun red(c: Int) = (c shr 16) and 0xFF
        fun blue(c: Int) = c and 0xFF
        T.check("küre: turuncu ton sıvıyı kırmızıya/sarıya çeker", red(b) > red(a) + 10 && blue(b) < blue(a), "R ${red(a)}→${red(b)}  B ${blue(a)}→${blue(b)}")
        val air1 = plain.getRGB((100 + 0.1f * r).toInt(), (100 - 0.7f * r).toInt())
        val air2 = tinted.getRGB((100 + 0.1f * r).toInt(), (100 - 0.7f * r).toInt())
        T.check("sıvı olmayan üst kısım ton almaz", air1 == air2)
        val ts = render(UiStyle.AQUA, OrbShape.HEXAGON, tint = 0.45f).getRGB(x, y)
        val ps = render(UiStyle.AQUA, OrbShape.HEXAGON, tint = 0f).getRGB(x, y)
        T.check("altıgen: ton burada da sıvıya işler", red(ts) > red(ps) + 10)
        val err = render(UiStyle.AQUA, OrbShape.TRIANGLE, error = 1f, tint = 0.45f).getRGB(x, y)
        val err0 = render(UiStyle.AQUA, OrbShape.TRIANGLE, error = 1f, tint = 0f).getRGB(x, y)
        T.check("hata durumunda ton karışmaz (hata rengi korunur)", err == err0)
    }
    run {
        // Seviye uçları: boş, çok az, tam dolu; her şekil ve stil için çizim geçerli ve dengeli kalır.
        var ok = true
        var detail = ""
        for (st in UiStyle.values()) for (sh in OrbShape.values()) for (lv in listOf(0f, 0.01f, 0.1f, 0.4f, 0.66f, 1f)) for (er in listOf(0f, 1f)) {
            val g = CountingGfx()
            val art = ArtFactory.create(st, Themes.aqua, 0.55f)
            art.orbShape = sh
            art.orb(g, 100f, 100f, r, lv, 1.3f, 0.6f, er, 0.5f)
            art.orb(g, 20f, 20f, 17f, lv, 1.3f, 0f, er, 0f)       // mini düğme boyu
            if (g.bad != 0 || g.depth != 0 || g.underflow) { ok = false; detail = "${st.label}/${sh.id}/lv=$lv/er=$er bad=${g.bad} depth=${g.depth}" }
        }
        T.check("her stil x şekil x seviye x hata: sonlu koordinat, save/restore dengeli", ok, detail)
    }
    run {
        // Kare başına bellek: şekil yolları ilk çizimde kurulur, sonra çizim bellek ayırmaz.
        var worst = 0L
        for (sh in OrbShape.values()) {
            val art = ArtFactory.create(UiStyle.AQUA, Themes.aqua, 0.55f)
            art.orbShape = sh
            art.liquidTint = 0xFFFF9800.toInt(); art.liquidTintAmt = 0.3f
            val g = CountingGfx()
            repeat(40) { art.orb(g, 100f, 100f, r, 0.66f, it * 0.1f, 0.6f, 0f, 0f) }       // ısınma
            val id = Thread.currentThread().id
            val b0 = shapeMx.getThreadAllocatedBytes(id)
            repeat(200) { art.orb(g, 100f, 100f, r, 0.66f, it * 0.1f, 0.6f, 0f, 0f) }
            val used = shapeMx.getThreadAllocatedBytes(id) - b0
            if (used > worst) worst = used
        }
        T.check("200 karede bellek ayırma ihmal edilir (≤ 8 KB)", worst <= 8192, "$worst bayt")
    }

    T.group("Küre şekilleri: ana ekran ve kişiselleştirme")
    run {
        val rig = Rig()
        T.check("ilk durumda küre", rig.model.orbShapeFor("aqua") == OrbShape.CIRCLE && rig.scene.env.art.orbShape == OrbShape.CIRCLE)
        T.check("gösterilen tema kimliği sahneden gelir", rig.model.shownThemeId == "aqua", rig.model.shownThemeId)
        rig.scene.openPersonalize(); rig.settle(900)
        T.check("kişiselleştirmede 'Küre şekli' ve 'Temaya göre şekil' satırları var", rig.find(Strings.ORB_SHAPE, exact = true) != null && rig.find(Strings.ORB_SHAPE_EACH, exact = true) != null)
        rig.tapText(Strings.ORB_SHAPE, exact = true, settleMs = 800)
        T.check("seçici 37 şekli listeler (uzun liste kaydırılarak)", OrbShape.values().all { runCatching { rig.need(Strings.orbShapeName(it), exact = true) }.isSuccess })
        rig.tapText(Strings.orbShapeName(OrbShape.HEXAGON), exact = true, settleMs = 1200)
        T.check("altıgen seçilince yalnız bu tema için kaydedilir", rig.model.settings.orbShapes == "aqua=hexagon", rig.model.settings.orbShapes)
        T.check("seçici kapandı", !rig.scene.hasSheet)
        val g = CountingGfx(); rig.scene.draw(g)
        T.check("sahne altıgeni kullanır ve çizim geçerli", rig.scene.env.art.orbShape == OrbShape.HEXAGON && g.bad == 0 && g.depth == 0)

        rig.tapText(Strings.ORB_SHAPE_EACH, exact = true, settleMs = 800)
        // Seçenek etiketi "Tema adı, şekil adı" olarak okunur; liste uzun olduğundan görünmeyenler kaydırılarak bulunur.
        fun themeLabel(id: String) = Strings.themeName(id) + ", " + Strings.orbShapeName(rig.model.orbShapeFor(id))
        T.check("şu anki temanın satırı altıgeni söyler", rig.find(themeLabel("aqua"), exact = true)?.info?.label == Strings.themeName("aqua") + ", " + Strings.orbShapeName(OrbShape.HEXAGON))
        val missing = Themes.all.filter { t -> runCatching { rig.need(themeLabel(t.id), exact = true) }.isFailure }.map { it.id }
        T.check("tema listesi 12 temanın hepsini ve şekillerini gösterir", Themes.all.size == 12 && missing.isEmpty(), missing.toString())
        rig.tapText(themeLabel("ocean"), exact = true, settleMs = 1200)
        T.check("tema seçilince o temanın şekil penceresi açılır", rig.scene.hasSheet && OrbShape.values().all { runCatching { rig.need(Strings.orbShapeName(it), exact = true) }.isSuccess })
        rig.tapText(Strings.orbShapeName(OrbShape.STAR), exact = true, settleMs = 1200)
        T.check("okyanus yıldız, aqua altıgen kalır", rig.model.settings.orbShapes == "aqua=hexagon;ocean=star", rig.model.settings.orbShapes)
        T.check("sahne hâlâ aqua altıgenini gösterir", rig.scene.env.art.orbShape == OrbShape.HEXAGON)

        rig.model.update { it.copy(theme = "ocean") }
        rig.settle(1500)
        T.check("tema değişince o temanın şekli gelir (yıldız)", rig.model.shownThemeId == "ocean" && rig.scene.env.art.orbShape == OrbShape.STAR, "${rig.model.shownThemeId} ${rig.scene.env.art.orbShape}")
        rig.model.update { it.copy(theme = "mint") }
        rig.settle(1500)
        T.check("kaydı olmayan tema küre kalır", rig.scene.env.art.orbShape == OrbShape.CIRCLE)
        rig.model.update { it.copy(theme = "aqua") }
        rig.settle(1500)
        T.check("aqua'ya dönünce altıgen geri gelir", rig.scene.env.art.orbShape == OrbShape.HEXAGON)
        rig.model.setOrbShape("aqua", OrbShape.CIRCLE)
        T.check("küreye dönmek kaydı siler", rig.model.settings.orbShapes == "ocean=star", rig.model.settings.orbShapes)
    }
    run {
        // Her şekil bağlıyken ve bağlantı kesikken ana ekranda doğru çizilir; küreye dokunma çalışır.
        for (sh in OrbShape.values()) {
            val rig = Rig(Rig.base().copy(orbShapes = if (sh == OrbShape.CIRCLE) "" else "aqua=${sh.id}"))
            val off = CountingGfx().also { rig.scene.draw(it) }
            rig.connectOk()
            val on = CountingGfx().also { rig.scene.draw(it) }
            T.check("${sh.id}: kapalı ve bağlı çizim geçerli", off.bad == 0 && off.depth == 0 && on.bad == 0 && on.depth == 0 && rig.scene.env.art.orbShape == sh)
        }
    }

    T.group("Küre şekilleri: her dilde metinler")
    val saved = L.lang
    try {
        for (lang in Lang.values()) {
            L.set(lang)
            val n = Strings.ORB_SHAPE_NAMES
            T.check("${lang.native}: başlıklar ve 12 şekil adı adı dolu, benzersiz",
                Strings.ORB_SHAPE.isNotBlank() && Strings.ORB_SHAPE_EACH.isNotBlank() && Strings.ORB_SHAPE != Strings.ORB_SHAPE_EACH &&
                    n.size == 12 && n.all { it.isNotBlank() && it.length <= 26 } && n.toSet().size == 12, n.toString())
            T.check("${lang.native}: her şeklin adı okunur (kalkanlar numaralı)", OrbShape.values().all { Strings.orbShapeName(it) == (if (it.isShield) Strings.SHIELD_WORD + " " + it.shieldNumber else n[it.ordinal]) })
            val all = OrbShape.values().map { Strings.orbShapeName(it) }
            T.check("${lang.native}: 37 şekil adı benzersiz ve kısa", all.toSet().size == 37 && all.all { it.length <= 26 && it.isNotBlank() } && Strings.SHIELD_WORD.isNotBlank())
        }
        L.set(Lang.values().first { it.name == "TR" })
        T.check("Türkçe adlar", Strings.ORB_SHAPE_NAMES == listOf("Küre", "Üçgen", "Kare", "Altıgen", "Yıldız", "Sekizgen", "Beşgen", "Dikdörtgen", "Ters üçgen", "Elmas", "Çiçek", "Altı köşeli yıldız"))
    } finally { L.set(saved) }
}
