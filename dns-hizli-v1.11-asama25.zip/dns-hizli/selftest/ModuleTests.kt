package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

private fun newModel(s: AppSettings = Rig.base()): Pair<AppModel, FakeHost> { val h = FakeHost(); return AppModel(h, s) to h }
private fun record(rig: Rig): TextRecorder = TextRecorder().also { rig.scene.draw(it) }

/** Aşama 23: ağ geçidi modülleri (DPI atlatma, Reklam+) — ayarlar, model, ana ekran kartları, 12 dil. */
fun runModuleTests() {
    T.group("Modüller: ayarlar")
    run {
        val d = AppSettings()
        T.check("varsayılanlar: DNS açık, modüller kapalı, QUIC engelli", d.dnsOn && !d.dpiOn && !d.adsPlus && d.blockQuic)
        val s = d.copy(dnsOn = false, dpiOn = true, adsPlus = true, blockQuic = false)
        val back = SettingsCodec.decode(SettingsCodec.encode(s))
        T.check("kodlama gidiş-dönüş", !back.dnsOn && back.dpiOn && back.adsPlus && !back.blockQuic)
        T.check("servis alanları kullanıcı kaydında değişmez", listOf("dnsOn", "dpiOn", "adsPlus").all { it in SettingsCodec.SERVICE_KEYS })
        val code = SettingsCodec.export(s)
        val imp = SettingsCodec.import(code, AppSettings())!!
        T.check("dışa aktarım modül durumunu taşımaz (cihaza özgü), QUIC ayarını taşır", !imp.dpiOn && !imp.adsPlus && imp.dnsOn && !imp.blockQuic)
    }

    T.group("Modüller: model")
    run {
        val (m, h) = newModel()
        T.check("başlangıçta ikisi de kapalı", !m.dpiOn && !m.adsPlusOn && m.modulesLine() == null)
        m.toggleDpi()
        T.check("DPI düğmesi servise 'DPI açık, Reklam+ kapalı' iletir", h.lastModules == (true to false) && m.dpiOn && !m.adsPlusOn)
        T.check("açma mesajı", m.toast?.text == Strings.modOn(Strings.MOD_DPI))
        m.toggleAdsPlus()
        T.check("Reklam+ düğmesi DPI'ı korur", h.lastModules == (true to true) && m.adsPlusOn && m.dpiOn)
        m.onVpn(VpnUi(OrbState.OFF, null, 0, gwOnly = true, gwActive = true, gwDpi = true, gwAds = true))
        T.check("servis cevabı gelince istek temizlenir, durum servisten okunur", m.dpiOn && m.adsPlusOn && m.modulesLine() == "${Strings.MOD_DPI} + ${Strings.MOD_ADS}")
        T.check("yalnızca modül açıkken küre kapalı, alt yazı modülleri söyler", m.vpn.state == OrbState.OFF && m.statusSub() == Strings.gwOn(m.modulesLine()!!))
        m.toggleDpi()
        T.check("kapatma isteği", h.lastModules == (false to true) && !m.dpiOn)
        m.onVpn(VpnUi(OrbState.OFF, null, 0, gwOnly = true, gwActive = true, gwDpi = false, gwAds = true))
        T.check("kapanış servisten onaylanınca", !m.dpiOn && m.adsPlusOn)
    }
    run {
        val (m, h) = newModel()
        h.moduleFail = true
        m.toggleDpi()
        T.check("izin verilmezse istek geri alınır", !m.dpiOn)
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.OFF, null, 0, gwOnly = true, gwActive = true, gwDpi = true))
        m.tapOrb()
        T.check("modül açıkken küreye dokunmak DNS'i bağlar", h.calls.any { it.startsWith("connect:") })
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 1, 0, 20, gwActive = true, gwDpi = true))
        h.calls.clear()
        m.tapOrb()
        T.check("DNS+modül açıkken küre yalnızca DNS'i keser", h.calls == listOf("disconnectDns"), h.calls.toString())
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 1, 0, 20))
        h.calls.clear()
        m.tapOrb()
        T.check("modül yokken küre eskisi gibi her şeyi keser", h.calls == listOf("disconnect"), h.calls.toString())
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.OFF, null, 0))
        m.update { it.copy(onboarded = false) }
        m.toggleAdsPlus()
        T.check("ilk açılış onayı bitmeden modül başlamaz, onay istenir", m.consentOpen && h.lastModules == null)
        m.acceptConsent()
        T.check("onaydan sonra istek servise gider", h.lastModules == (false to true))
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.OFF, null, 0, gwOnly = true, gwActive = true, gwDpi = true))
        m.update { it.copy(blockQuic = false) }
        T.check("QUIC ayarı çalışan ağ geçidine canlı iletilir", h.lastModules == (true to false))
        val (m2, h2) = newModel()
        m2.update { it.copy(blockQuic = false) }
        T.check("ağ geçidi yokken servise bir şey gönderilmez", h2.lastModules == null)
    }
    run {
        val (m, _) = newModel()
        m.onVpn(VpnUi(OrbState.OFF, null, 0, info = Strings.GW_TRIPPED, gwTripped = true))
        T.check("güvenlik vanası mesajı gösterilir", m.toast?.text == Strings.GW_TRIPPED)
    }

    T.group("Modüller: ana ekran kartları")
    run {
        val rig = Rig()
        val dpi = rig.need(Strings.MOD_DPI + ",")
        val ads = rig.need(Strings.MOD_ADS + ",")
        T.check("iki kart yan yana, aynı yükseklikte", dpi.t == ads.t && dpi.b == ads.b && dpi.r <= ads.l + 1f)
        T.check("kartlar büyük dokunma hedefi", dpi.r - dpi.l >= 120f && dpi.b - dpi.t >= 90f)
        T.check("anahtar rolü ve kapalı durum", dpi.info.role == Role.SWITCH && dpi.info.checked == false && ads.info.checked == false)
        rig.tapItem(dpi, 400)
        T.check("DPI kartına dokunmak modülü ister", rig.host.lastModules == (true to false))
        rig.tapItem(rig.need(Strings.MOD_ADS + ","), 400)
        T.check("Reklam+ kartı DPI'yı korur", rig.host.lastModules == (true to true))
        T.check("kartlar açıkken işaretli", rig.need(Strings.MOD_DPI + ",").info.checked == true && rig.need(Strings.MOD_ADS + ",").info.checked == true)
    }
    run {
        val rig = Rig(); rig.connectOk()
        T.check("DNS bağlıyken de iki kart görünür", rig.find(Strings.MOD_DPI + ",") != null && rig.find(Strings.MOD_ADS + ",") != null)
    }
    run {
        val saved = L.lang
        try {
            for (lang in Lang.values()) {
                L.set(lang)
                val rig = Rig(Rig.base(), 360, 780)
                val rec = record(rig)
                val bad = rec.runs.filter { it.s.endsWith("…") && it.t < 560f }
                T.check("${lang.native}: kartlarda kısaltılmış yazı yok (360 dp)", bad.isEmpty(), bad.joinToString { it.s })
                T.check("${lang.native}: kartlar dolu", rig.items().count { it.info.role == Role.SWITCH } >= 2 && Strings.MOD_DPI.isNotBlank() && Strings.MOD_ADS.isNotBlank())
                val big = Rig(Rig.base(), 360, 780, fontScale = 1.3f)
                val rec2 = record(big)
                val bad2 = rec2.runs.filter { it.s.endsWith("…") && it.t < 560f && !Strings.HINT_OFF.startsWith(it.s.dropLast(1)) }
                T.check("${lang.native}: 1.3x yazıda da kısaltma yok", bad2.isEmpty(), bad2.joinToString { it.s })
            }
        } finally { L.set(saved) }
    }
}
