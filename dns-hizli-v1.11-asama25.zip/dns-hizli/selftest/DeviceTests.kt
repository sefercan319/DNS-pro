package app.dnshizli.selftest

import app.dnshizli.core.Themes
import app.dnshizli.ui.Scene
import app.dnshizli.ui.Strings

/**
 * Gerçek cihaz davranışı benzetimi: Android'de sahne yalnızca bir kare istendiğinde ([requestFrame]) ya da önceki karenin
 * önerdiği gecikme >= 0 ise çizilir; durağan ekranda kare YOKTUR. Bu yüzden her dokunuştan sonra yalnızca bu kurala göre
 * kare ilerletilir. (Diğer testler her zaman kare ilerlettiği için "kare istenmedi, ekran değişmedi" hatalarını yakalayamaz.)
 */
private class DeviceDriver(val rig: Rig) {
    private var seen = rig.host.frames
    private var delay = 16L

    /** İstek ya da önerilen gecikme sürdükçe kare ilerlet; ekran durağan olunca bırak. */
    fun pump(maxMs: Long = 3000) {
        var spent = 0L
        var guard = 0
        while (guard++ < 2000 && spent < maxMs) {
            val requested = rig.host.frames != seen
            if (!requested && delay < 0) break
            seen = rig.host.frames
            val step = if (delay > 16) delay else 16L
            rig.host.now += step
            spent += step
            delay = rig.scene.tick(rig.host.now)
        }
    }

    /** Parmak titremesiyle ([jitter] dp) dokunuş. */
    fun tap(x: Float, y: Float, holdMs: Long = 90, jitter: Float = 2f) {
        rig.scene.touch(Scene.DOWN, x, y, rig.host.now)
        pump(holdMs)
        rig.host.now += 16
        rig.scene.touch(Scene.MOVE, x + jitter, y - jitter, rig.host.now)
        pump(holdMs)
        rig.scene.touch(Scene.UP, x + jitter, y - jitter, rig.host.now)
        pump()
    }

    fun tapItem(label: String, exact: Boolean = true, jitter: Float = 2f) {
        val it = rig.need(label, exact)
        val b = it
        tap((b.l + b.r) / 2f, (b.t + b.b) / 2f, jitter = jitter)
    }
}

fun runDeviceTests() {
    T.group("Cihaz benzetimi: kare yalnızca istenince çizilir")
    for (jitter in listOf(0f, 3f, 6f)) {
        val rig = Rig()
        val d = DeviceDriver(rig)
        d.pump()
        d.tapItem(Strings.MENU, jitter = jitter)
        d.tapItem(Strings.PERSONALIZE, jitter = jitter)
        T.check("menüden kişiselleştirme açılır (titreme $jitter)", rig.scene.pageCount == 3)
        for (t in Themes.all) {
            val sw = rig.reveal("Tema: ${t.name}", exact = true)
            if (sw == null) { T.check("tema düğmesi bulunur: ${t.id}", false); continue }
            d.tapItem("Tema: ${t.name}", jitter = jitter)
            T.check("tema '${t.id}' cihaz benzetiminde ekrana yansır (titreme $jitter)",
                rig.model.settings.theme == t.id && rig.scene.env.theme.id == t.id,
                "ayar=${rig.model.settings.theme} ekran=${rig.scene.env.theme.id}")
        }
    }
}

/** Kişiselleştirme, ayar pencereleri ve Hakkında sayfalarındaki HER anahtar ve düğmeyi cihaz benzetimiyle sırayla dener; etkisiz olanları listeler. */
fun runControlAudit() {
    auditPage("kişiselleştirmedeki", Strings.PERSONALIZE)
    auditPage("DNS ayarlarındaki", Strings.DNS_SETTINGS)
    auditPage("bağlantı ve uygulamalardaki", Strings.CONN_APPS)
    auditPage("bildirimlerdeki", Strings.SEC_NOTIF)
    auditPage("sunucu listesindeki", Strings.SEC_LIST)
    auditPage("istatistikler ve geçmişteki", Strings.STATS_HISTORY)
    auditPage("verilerdeki", Strings.SEC_DATA)
    auditPage("Hakkında penceresindeki", Strings.ABOUT)
}

private fun auditPage(group: String, entry: String) {
    T.group("Denetim: $group her düğme ve anahtar işe yarar")
    val rig = Rig()
    val d = DeviceDriver(rig)
    d.pump()
    d.tapItem(Strings.MENU)
    d.tapItem(entry)
    // Sayfadaki tüm öğelerin etiketlerini kaydırarak topla.
    val labels = LinkedHashMap<String, app.dnshizli.ui.Role>()
    fun collect() { for (i in rig.items()) if (i.info.role == app.dnshizli.ui.Role.SWITCH || i.info.role == app.dnshizli.ui.Role.BUTTON) labels.putIfAbsent(i.info.label, i.info.role) }
    collect()
    for (n in 0 until 60) { val y0 = rig.h * 0.7f; rig.drag(rig.w / 2f, y0, y0 - rig.h * 0.3f, 8); collect() }
    println("  bilgi: $group ${labels.size} etkileşimli öğe bulundu")
    val skip = setOf(Strings.BACK)
    for ((label, role) in labels) {
        if (label in skip) continue
        val r = Rig()                      // her öğe temiz bir durumda denenir (öncekinin etkisi karışmasın)
        val dd = DeviceDriver(r)
        dd.pump()
        dd.tapItem(Strings.MENU)
        dd.tapItem(entry)
        val before = r.model.settings
        val pagesBefore = r.scene.pageCount
        val toastBefore = r.model.toastSeq
        val callsBefore = r.host.calls.size
        val item = r.reveal(label, exact = true)
        if (item == null) { println("  bilgi: bulunamadı: $label"); continue }
        dd.tap((item.l + item.r) / 2f, (item.t + item.b) / 2f)
        val changed = r.model.settings != before || r.scene.pageCount != pagesBefore || r.scene.hasSheet ||
            r.host.calls.size != callsBefore || r.model.toastSeq != toastBefore || r.model.testing
        val alreadySelected = item.info.role == app.dnshizli.ui.Role.BUTTON && item.info.checked == true     // zaten seçili seçeneğe dokunmak değişiklik yapmaz
        if (!changed && !alreadySelected) println("  ETKİSİZ? [$role] $label")
        T.check("öğe tepki verir: $label", changed || alreadySelected)
    }
}
