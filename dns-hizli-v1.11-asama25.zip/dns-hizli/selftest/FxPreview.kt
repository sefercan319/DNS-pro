package app.dnshizli.selftest

import app.dnshizli.core.*
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO

/** Stile özgü dokunma ve kutlama efektlerini kare kare tek PNG'de gösterir (gözle değerlendirmek için). */
object FxPreview {
    @JvmStatic
    fun main(args: Array<String>) {
        val out = File(args.getOrElse(0) { "fx.png" })
        val cols = listOf(0.15f, 0.35f, 0.55f, 0.8f)
        val cele = listOf(0.15f, 0.4f, 0.7f)
        val cw = 120; val rh = 150
        val w = cw * (cols.size + cele.size * 2); val h = rh * 6
        val img = BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB)
        val gr = img.createGraphics()
        val g = AwtGfx(gr)
        for ((row, st) in UiStyle.values().withIndex()) {
            val art = ArtFactory.create(st, Themes.aqua, 0.55f)
            g.save(); g.translate(0f, row * rh.toFloat())
            g.clipRect(0f, 0f, w.toFloat(), rh.toFloat())
            art.sky(g, w.toFloat(), rh.toFloat())
            g.paint(Themes.aqua.text); g.text(st.label, 4f, 14f, 12f, true, 0)
            for ((i, t) in cols.withIndex()) {
                art.card(g, i * cw + 30f, 55f, i * cw + 90f, 95f, 14f)
                g.save(); StyleFx.tap(art.motion.fx, g, Themes.aqua, i * cw + 60f, 75f, t); g.restore()
            }
            for ((i, t) in cele.withIndex()) {
                val cx = (cols.size * cw + i * 2 * cw + cw).toFloat()
                art.orb(g, cx, 75f, 30f, 0.7f, 1f, 1f, 0f, 0f)
                g.save(); StyleFx.celebrate(art.motion.fx, g, Themes.aqua, cx, 75f, 30f, t); g.restore()
            }
            g.restore()
        }
        ImageIO.write(img, "png", out)
        println("yazıldı: $out")
    }
}
