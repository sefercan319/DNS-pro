package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

private fun newModel(s: AppSettings = Rig.base(), lat: Map<String, Latency> = emptyMap()): Pair<AppModel, FakeHost> {
    val h = FakeHost()
    return AppModel(h, s, lat) to h
}

fun testModelConnect() {
    T.group("Model: bağlan / kes")
    run {
        val (m, h) = newModel()
        m.tapOrb()
        T.check("küre: seçili sunucuya bağlanır", h.calls == listOf("connect:cloudflare"))
        T.check("hemen 'bağlanıyor' durumuna geçer", m.vpn.state == OrbState.CONNECTING && m.vpn.serverId == "cloudflare")
        T.check("seçim kaydedilir", h.saved?.lastServer == "cloudflare")
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 0, 0, 20))
        T.check("bağlıyken connectedId", m.connectedId() == "cloudflare")
        m.tapOrb()
        T.check("küre: bağlıyken keser", h.calls.last() == "disconnect")
        T.check("kesince bildirim", m.toast?.text == Strings.DISCONNECTED)
        m.onVpn(VpnUi(OrbState.OFF))
        T.check("kapalıyken connectedId boş", m.connectedId() == null)
    }
    run {
        val (m, h) = newModel(Rig.base().copy(lastServer = "quad9"))
        m.tapOrb()
        T.check("son seçilen sunucuya bağlanır", h.calls == listOf("connect:quad9"))
    }
    run {
        val (m, h) = newModel(Rig.base().copy(lastServer = null))
        m.tapOrb()
        T.check("seçim yoksa varsayılan (Cloudflare)", h.calls == listOf("connect:${Catalog.DEFAULT_ID}"))
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 0, 0, 20))
        m.tapServer("quad9")
        T.check("bağlıyken başka sunucu: kesintisiz geçiş çağrısı", h.calls == listOf("connect:quad9"))
        T.check("geçiş bildirimi", m.toast?.text == Strings.switched("Quad9"))
        T.check("durum bağlı kalır", m.vpn.state == OrbState.ON)
        T.check("seçim kaydedildi", m.settings.lastServer == "quad9")
        m.tapServer("quad9")
        T.check("zaten bağlı olana dokunmak bir şey yapmaz", h.calls.size == 1)
        m.onVpn(VpnUi(OrbState.ON, "quad9", h.now, 0, 0, 20))
        m.tapServer("quad9")
        T.check("sunucu değişince de aynısı", h.calls.size == 1)
    }
    run {
        val (m, h) = newModel()
        m.tapServer("yok-boyle-bir-sunucu")
        T.check("bilinmeyen sunucu yok sayılır", h.calls.isEmpty() && m.vpn.state == OrbState.OFF)
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.CONNECTING, "cloudflare", h.now))
        T.check("bağlanıyorken küre keser", run { m.tapOrb(); h.calls.last() == "disconnect" })
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.ERROR, null, 0, 0, 0, 0, "Neden"))
        m.tapOrb()
        T.check("hata durumunda küre yeniden dener", h.calls == listOf("connect:cloudflare"))
    }
}

fun testModelConsent() {
    T.group("Model: ilk açılış bilgilendirmesi")
    run {
        val (m, h) = newModel(Rig.base().copy(onboarded = false))
        m.tapOrb()
        T.check("kabul edilmeden bağlanmaz", h.calls.isEmpty() && m.consentOpen)
        T.check("durum kapalı kalır", m.vpn.state == OrbState.OFF)
        m.acceptConsent()
        T.check("kabulden sonra bağlanır", h.calls == listOf("connect:cloudflare") && !m.consentOpen)
        T.check("kabul kalıcı kaydedilir", h.saved?.onboarded == true && m.settings.onboarded)
    }
    run {
        val (m, h) = newModel(Rig.base().copy(onboarded = false))
        m.tapServer("quad9")
        m.acceptConsent()
        T.check("beklemedeki sunucu korunur", h.calls == listOf("connect:quad9"))
    }
    run {
        val (m, h) = newModel(Rig.base().copy(onboarded = false))
        m.tapOrb()
        m.dismissConsent()
        T.check("vazgeçilirse bağlanmaz", h.calls.isEmpty() && !m.consentOpen && !m.settings.onboarded)
        m.acceptConsent()
        T.check("beklemesiz kabul bağlanmaz ama kaydeder", h.calls.isEmpty() && m.settings.onboarded)
    }
    run {
        val (m, h) = newModel()
        m.tapOrb()
        T.check("kabul edilmişse bilgilendirme açılmaz", !m.consentOpen)
    }
}

fun testModelList() {
    T.group("Model: liste, favori, sıralama")
    run {
        val (m, h) = newModel(Rig.base().copy(favorites = setOf("quad9", "google")))
        val v0 = m.version
        m.setFilter(Filter.ALL)
        T.check("aynı süzgeç sürümü artırmaz", m.version == v0)
        m.setFilter(Filter.FAVORITES)
        T.check("favoriler süzgeci yalnızca favorileri gösterir", m.visibleServers().map { it.id }.toSet() == setOf("quad9", "google"))
        m.setFilter(Filter.ADS)
        T.check("etiket süzgeci", m.visibleServers().isNotEmpty() && m.visibleServers().all { Tag.ADS in it.tags })
        T.check("süzgeçte favoriler üstte", run { m.setFilter(Filter.ALL); m.visibleServers().take(2).map { it.id }.toSet() == setOf("quad9", "google") })
        for (f in Filter.values()) {
            m.setFilter(f)
            T.check("süzgeç ${f.name} boş değil ya da favori/son kullanılan", m.visibleServers().isNotEmpty() || f == Filter.FAVORITES || f == Filter.RECENT)
        }
        m.setFilter(Filter.ALL)
        m.toggleFavorite("cloudflare")
        T.check("favori eklenir ve kaydedilir", "cloudflare" in m.settings.favorites && h.saved?.favorites?.contains("cloudflare") == true)
        m.toggleFavorite("cloudflare")
        T.check("favori kaldırılır", "cloudflare" !in m.settings.favorites)
        val n = h.savedCount
        m.toggleFavorite("yok")
        T.check("bilinmeyen favori yok sayılır", h.savedCount == n)
        m.setFilter(Filter.FAVORITES)
        for (id in listOf("quad9", "google")) m.toggleFavorite(id)
        T.check("favori yokken liste boş", m.visibleServers().isEmpty())
    }
    run {
        val lat = mapOf(
            "cloudflare" to Latency(18, 0), "quad9" to Latency(41, 0), "google" to Latency(24, 0),
            "controld" to Latency(29, 0), "adguard" to Latency(33, 0), "uncensored" to Latency(null, 0),
        )
        val (m, h) = newModel(Rig.base().copy(favorites = setOf("quad9", "cloudflare")), lat)
        m.toggleSort()
        val ids = m.visibleServers().map { it.id }
        T.check("hıza göre sıralama: favoriler önce, hızlıdan yavaşa", ids.take(2) == listOf("cloudflare", "quad9"))
        T.check("ardından ölçülmüşler hız sırasıyla", ids.subList(2, 5) == listOf("google", "controld", "adguard"))
        T.check("cevapsız sunucu en sonda", ids.last() == "uncensored")
        T.check("tüm sunucular listede", ids.size == Catalog.all.size && ids.toSet().size == ids.size)
        T.check("sıralama kaydedilir", h.saved?.sortMode == SortMode.SPEED)
        m.toggleSort()
        val names = m.visibleServers().drop(2).map { it.name }
        T.check("ikinci dokunuş: ada göre (favoriler yine önce)", m.settings.sortMode == SortMode.NAME &&
            names == names.sortedWith(String.CASE_INSENSITIVE_ORDER), names.take(4).toString())
        m.toggleSort()
        T.check("üçüncü dokunuş: katalog sırası", m.settings.sortMode == SortMode.DEFAULT &&
            m.visibleServers().map { it.id }.drop(2).take(3) == Catalog.all.map { it.id }.filter { it != "quad9" && it != "cloudflare" }.take(3))
    }
    run {
        val (m, h) = newModel()
        val n = h.savedCount
        m.update { it }
        T.check("değişmeyen ayar kaydedilmez", h.savedCount == n)
        val v = m.version
        m.update { it.copy(glass = 0.9f) }
        T.check("değişen ayar kaydedilir ve sürüm artar", h.savedCount == n + 1 && m.version > v && m.settings.glass == 0.9f)
    }
}

fun testModelMeasure() {
    T.group("Model: hız ölçümü")
    run {
        val (m, h) = newModel()
        m.measureAll()
        T.check("tüm sunucular ölçülür", h.calls == listOf("measure:${Catalog.all.size}") && m.measuring)
        m.measureAll()
        T.check("ölçüm sürerken yenisi başlamaz", h.calls.size == 1)
        m.onLatency("cloudflare", 18)
        m.onLatency("google", 24)
        m.onLatency("quad9", null)
        m.onLatency("yok", 5)
        T.check("gecikmeler kaydedilir", m.latencies["cloudflare"]?.ms == 18 && m.latencies["quad9"]?.ms == null && m.latencies.containsKey("quad9") && !m.latencies.containsKey("yok"))
        T.check("gecikme metni", m.latencyText("cloudflare") == "18 ms" && m.latencyText("quad9") == "—" && m.latencyText("dnssb") == null)
        m.onMeasureDone()
        T.check("ölçüm bitince durum kapanır ve kaydedilir", !m.measuring && h.savedLatencies?.size == 3)
        T.check("en hızlı için eylemli bildirim", m.toast?.text == Strings.fastest("Cloudflare", 18) && m.toast?.action == Strings.CONNECT)
        m.toast?.onAction?.invoke()
        T.check("bildirim eylemi en hızlıya bağlanır", h.calls.last() == "connect:cloudflare")
        val c = h.calls.size
        m.onMeasureDone()
        T.check("ölçüm yokken bitiş çağrısı etkisiz", h.calls.size == c)
    }
    run {
        val (m, h) = newModel()
        m.measure(listOf("google"))
        m.onLatency("google", null)
        m.onMeasureDone()
        T.check("hiç yanıt yoksa bildirim", m.toast?.text == Strings.NO_REPLY && m.toast?.action == null)
        m.measure(emptyList())
        T.check("boş liste ölçülmez", !m.measuring)
    }
    run {
        val (m, h) = newModel()
        m.connectFastest()
        T.check("ölçüm yokken uyarı", m.toast?.text == Strings.MEASURE_FIRST && h.calls.isEmpty())
        m.onLatency("opendns", 70); m.onLatency("google", 20)
        m.connectFastest()
        T.check("en hızlıya bağlanır", h.calls == listOf("connect:google"))
    }
}

fun testModelStatus() {
    T.group("Model: durum metinleri ve geri bildirim")
    run {
        val (m, h) = newModel()
        T.check("kapalı: başlık/alt/ipucu", m.statusTitle() == "Bağlı değil" && m.statusSub() == "Cloudflare seçili" && m.statusHint() == "Bağlanmak için küreye dokun")
        m.onVpn(VpnUi(OrbState.CONNECTING, "quad9", h.now))
        T.check("bağlanıyor", m.statusTitle() == "Bağlanıyor…" && m.statusSub() == "Quad9")
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now - 754_000, 1342, 511, 23))
        T.check("bağlı: ad ve gecikme", m.statusTitle() == "Bağlı" && m.statusSub() == "Cloudflare · 23 ms")
        T.check("bağlı: süre, sorgu, önbellek", m.statusHint() == "12:34 · 1,3 bin sorgu · %38 önbellek", m.statusHint())
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 0, 0, 0))
        T.check("sorgu yokken yüzde 0 ve gecikme gizli", m.statusSub() == "Cloudflare" && m.statusHint().endsWith("%0 önbellek"))
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now + 5_000_000, 10, 99, 0))
        T.check("saat geriye giderse süre negatif olmaz", m.statusHint().startsWith("00:00"), m.statusHint())
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 10, 99, 0))
        T.check("önbellek yüzdesi 100'ü aşmaz", m.statusHint().contains("%100"), m.statusHint())
        m.onVpn(VpnUi(OrbState.ERROR, null, 0, 0, 0, 0, "Başka bir VPN açık"))
        T.check("hata: neden gösterilir", m.statusTitle() == "Bağlanamadı" && m.statusSub() == "Başka bir VPN açık" && m.statusHint() == Strings.HINT_ERROR)
        m.onVpn(VpnUi(OrbState.ERROR))
        T.check("hata: varsayılan neden", m.statusSub() == Strings.ERR_DEFAULT)
        m.onVpn(VpnUi(OrbState.ON, "bilinmeyen", h.now, 0, 0, 0))
        T.check("bilinmeyen sunucu kimliği çökertmez", m.statusSub() == "Cloudflare")
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.CONNECTING, "cloudflare", h.now))
        T.check("bağlanırken titreşim yok", h.haptics == 0)
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now))
        T.check("bağlanınca güçlü titreşim deseni (2 vuruş)", h.patterns.size == 1 && h.patterns[0].first == 2 && h.patterns[0].third)
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 5))
        T.check("aynı durum tekrar titretmez", h.patterns.size == 1)
        m.onVpn(VpnUi(OrbState.ERROR))
        T.check("hatada titreşim (3 vuruş)", h.patterns.size == 2 && h.patterns[1].first == 3)
        m.onVpn(VpnUi(OrbState.OFF))
        T.check("hatadan kapanınca titreşim yok", h.patterns.size == 2)
    }
    run {
        val (m, h) = newModel(Rig.base().copy(haptics = false))
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now))
        T.check("titreşim kapalıysa titretmez", h.haptics == 0)
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now))
        val seq = m.toastSeq
        m.onVpn(VpnUi(OrbState.ON, "quad9", h.now, onBackup = true))
        T.check("yedek sunucuya geçince bildirim", m.toast?.text == Strings.BACKUP && m.toastSeq == seq + 1)
        m.onVpn(VpnUi(OrbState.ON, "quad9", h.now, onBackup = true))
        T.check("bildirim yalnızca geçişte", m.toastSeq == seq + 1)
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now))
        val seq = m.toastSeq
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, error = "Quad9 yanıt vermedi"))
        T.check("bağlıyken gelen hata bir kez bildirilir", m.toast?.text == "Quad9 yanıt vermedi" && m.toastSeq == seq + 1)
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, error = "Quad9 yanıt vermedi"))
        T.check("aynı hata tekrar bildirilmez", m.toastSeq == seq + 1)
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now))
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, error = "Quad9 yanıt vermedi"))
        T.check("hata temizlenip yine gelirse yeniden bildirilir", m.toastSeq == seq + 2)
        T.check("bağlı durum bozulmadı", m.vpn.state == OrbState.ON && m.statusTitle() == Strings.ON)
        m.onVpn(VpnUi(OrbState.ERROR, null, 0, 0, 0, 0, "Başka bir VPN açık"))
        T.check("hata durumunda ayrıca bildirim açılmaz (neden küre altında yazar)", m.toastSeq == seq + 2)
    }
    run {
        val (m, h) = newModel()
        val v = m.version
        m.replaceSettings(m.settings)
        T.check("aynı ayarlar sürümü artırmaz", m.version == v)
        val n = h.savedCount
        m.replaceSettings(m.settings.copy(totalQueries = 9))
        T.check("depodan gelen ayar kaydedilmez ama görünür", m.version > v && h.savedCount == n && m.settings.totalQueries == 9L)
        T.check("önbellek yüzdesi: sorgu yokken 0", newModel(Rig.base().copy(totalQueries = 0, totalHits = 5)).first.hitPercentTotal() == 0)
        T.check("önbellek yüzdesi", newModel(Rig.base()).first.hitPercentTotal() == 35)
        T.check("önbellek yüzdesi 100'ü aşmaz", newModel(Rig.base().copy(totalQueries = 5, totalHits = 50)).first.hitPercentTotal() == 100)
    }
    run {
        val (m, h) = newModel()
        m.copy("1.1.1.1")
        T.check("kopyalama panoya yazar ve bildirir", h.clipboard == "1.1.1.1" && m.toast?.text == Strings.COPIED)
    }
}

fun runModelTests() {
    testModelConnect()
    testModelCustom()
    testModelApps()
    testModelConsent()
    testModelList()
    testModelMeasure()
    testModelStatus()
    testModelFeatures()
}

// =================================================================================== yeni özellikler (model)

fun testModelFeatures() {
    T.group("Model: gizleme, son kullanılanlar, en hızlı")
    run {
        val (m, h) = newModel()
        m.hide("google")
        T.check("gizlenen sunucu listeden çıkar", m.visibleServers().none { it.id == "google" } && "google" in h.saved!!.hidden)
        T.check("gizlenenler listesi", m.hiddenServers().map { it.id } == listOf("google"))
        T.check("geri al eylemli mesaj", m.toast?.action == Strings.UNDO && m.toast?.text == Strings.hiddenToast("Google"))
        m.toast?.onAction?.invoke()
        T.check("geri al gizlemeyi kaldırır", m.visibleServers().any { it.id == "google" } && m.hiddenServers().isEmpty())
        m.hide("google"); m.measureAll()
        T.check("gizlenenler ölçülmez", h.lastMeasureIds.size == Catalog.all.size - 1 && "google" !in h.lastMeasureIds)
    }
    run {
        val (m, h) = newModel()
        m.tapServer("quad9"); m.onVpn(VpnUi(OrbState.ON, "quad9", 0)); m.tapServer("google")
        T.check("bağlanılan sunucular son kullanılanlara eklenir (yeni başta)", m.settings.recent == listOf("google", "quad9"), m.settings.recent.toString())
        m.setFilter(Filter.RECENT)
        T.check("'son kullanılan' süzgeci kullanım sırasını korur", m.visibleServers().map { it.id }.take(2) == listOf("google", "quad9"))
        T.check("son kullanılanlar kaydedilir", h.saved?.recent?.first() == "google")
    }
    run {
        val lat = mapOf("google" to Latency(9, 0), "quad9" to Latency(15, 0), "dnssb" to Latency(5, 0))
        val (m, h) = newModel(Rig.base().copy(autoFastest = true, hidden = setOf("dnssb")), lat)
        m.tapOrb()
        T.check("'en hızlıya bağlan': gizlenmemiş en hızlı (Google)", h.calls.last() == "connect:google", h.calls.toString())
        val (m2, h2) = newModel(Rig.base().copy(autoFastest = true))
        m2.tapOrb()
        T.check("ölçüm yoksa seçili sunucu", h2.calls.last() == "connect:cloudflare")
    }

    T.group("Model: şifreleme tercihi")
    run {
        val (m, h) = newModel(Rig.base().copy(encryption = Encryption.DOH))
        m.tapServer("uncensored")
        T.check("DoH zorunluyken DoH'suz sunucuya bağlanılmaz, nedeni söylenir", h.count("connect:") == 0 && m.toast?.text == Strings.errNoProto("UncensoredDNS", "DoH"))
        T.check("canUse", !m.canUse(Catalog.byId("uncensored")!!) && m.canUse(Catalog.byId("cloudflare")!!))
        m.tapServer("cloudflare")
        T.check("destekleyen sunucuya bağlanılır", h.calls.last() == "connect:cloudflare")
    }
    run {
        val lat = mapOf("uncensored" to Latency(3, 0), "google" to Latency(9, 0))
        val (m, h) = newModel(Rig.base().copy(encryption = Encryption.DOH), lat)
        m.connectFastest()
        T.check("en hızlı seçimi kullanılamayan sunucuyu atlar", h.calls.last() == "connect:google")
    }

    T.group("Model: duraklatma, önbellek, dil")
    run {
        val (m, h) = newModel()
        m.pause(15)
        T.check("bağlı değilken duraklatma yok sayılır", h.count("pause") == 0)
        m.tapOrb(); m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now))
        m.pause(15)
        T.check("bağlıyken duraklatılır", h.calls.last() == "pause:15" && m.paused && m.statusTitle() == Strings.PAUSED)
        T.check("bitiş saati alt satırda", m.statusSub() == Strings.pausedUntil(Format.hm(h.now + 15 * 60_000L)) && m.statusHint() == Strings.HINT_PAUSED)
        m.tapOrb()
        T.check("duraklatılmışken küre: devam et", h.calls.last() == "resume" && m.vpn.state == OrbState.CONNECTING && !m.paused)
    }
    run {
        val (m, h) = newModel()
        m.tapOrb(); m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now)); m.pause(5)
        h.now += 5 * 60_000L + AppModel.PAUSE_GRACE_MS + 1000; m.watchdog()
        T.check("süre dolup servis haber vermezse 'duraklatıldı'da takılmaz", !m.paused && m.statusTitle() == Strings.OFF)
    }
    run {
        val (m, h) = newModel()
        m.clearCache()
        T.check("bağlı değilken önbellek temizleme: uyarı", h.count("clearCache") == 0 && m.toast?.text == Strings.ONLY_CONNECTED)
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now)); m.clearCache()
        T.check("bağlıyken temizlenir", h.count("clearCache") == 1 && m.toast?.text == Strings.CACHE_CLEARED)
    }
    run {
        val (m, h) = newModel()
        val seq = m.langSeq
        m.setLanguage("en")
        T.check("dil değişince platforma bildirilir ve sayfalar yenilenir", h.calls.contains("lang:en") && m.langSeq == seq + 1 && L.lang == Lang.EN)
        T.check("metinler yeni dilde", Strings.SETTINGS == "Settings" && m.statusTitle() == "Not connected")
        m.setLanguage("auto")
        T.check("otomatik dile dönülür", L.lang == Lang.TR && h.saved?.lang == "auto")
    }

    T.group("Model: dışa/içe aktarma, sıfırlama, sade görünüm")
    run {
        val (m, h) = newModel(Rig.base().copy(theme = "mint", compact = true, hidden = setOf("opendns")))
        m.exportSettings()
        T.check("ayar kodu panoya", h.clipboard?.startsWith("DNSH1:") == true && m.toast?.text == Strings.EXPORTED)
        val (m2, h2) = newModel()
        h2.clipboard = h.clipboard
        m2.importSettings()
        T.check("başka cihazda içe aktarılır", m2.settings.theme == "mint" && m2.settings.compact && m2.settings.hidden == setOf("opendns") && m2.toast?.text == Strings.IMPORTED)
        T.check("içe aktarma onayı ve istatistikleri değiştirmez", m2.settings.onboarded && m2.settings.totalQueries == Rig.base().totalQueries)
        h2.clipboard = "rastgele metin"
        m2.importSettings()
        T.check("geçersiz kod: uyarı, ayar değişmez", m2.toast?.text == Strings.IMPORT_BAD && m2.settings.theme == "mint")
    }
    run {
        val (m, h) = newModel(Rig.base().copy(theme = "night", glass = 0.9f, compact = true))
        m.askResetSettings()
        T.check("sıfırlama önce onay ister", m.toast?.text == Strings.CONFIRM && m.toast?.action == Strings.RESET && m.settings.theme == "night")
        m.toast?.onAction?.invoke()
        T.check("ayarlar varsayılana döner", m.settings.theme == Themes.AUTO_ID && !m.settings.compact && m.settings.glass == AppSettings().glass)
        T.check("favoriler, onay ve istatistik korunur", m.settings.favorites == Rig.base().favorites && m.settings.onboarded && m.settings.totalQueries == Rig.base().totalQueries)
        m.askResetStats(); m.toast?.onAction?.invoke()
        T.check("istatistikler sıfırlanır", h.count("resetTotals") == 1 && m.settings.totalQueries == 0L && m.settings.daily == "")
    }
    run {
        val (m, h) = newModel(Rig.base().copy(minimal = true))
        m.setFilter(Filter.ADS)
        T.check("sade görünümde süzgeç uygulanmaz", m.effectiveFilter == Filter.ALL && m.visibleServers().size == Catalog.all.size)
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now - 61_000, 100, 10, 20, blocked = 7))
        T.check("sade görünümde yalnızca süre", m.statusHint() == "01:01")
        m.update { it.copy(minimal = false) }
        T.check("normal görünümde engellenen sayısı da yazar", m.statusHint().endsWith(Strings.blockedShort("7")))
        T.check("bağlıyken protokol görünür", m.statusSub() == "Cloudflare · 20 ms" && run {
            m.onVpn(m.vpn.copy(proto = Proto.DOT)); m.statusSub() == "Cloudflare · DoT · 20 ms" })
    }
    run {
        val (m, h) = newModel()
        m.measure(listOf("google"))
        m.onLatency("google", 14, 33); m.onMeasureDone()
        T.check("ölçüm kaybı ve geçmişi tutulur", m.latencies["google"]?.loss == 33 && m.history["google"] == listOf(14) && h.savedHistory?.get("google") == listOf(14))
    }
}


fun testModelCustom() {
    T.group("Model: özel DNS ekle / sil")
    try {
        val (m, h) = newModel()
        h.customDraft = CustomDns.Draft("Evim", "192.168.1.2", "", "dns.example.com", "")
        m.promptCustom()
        val s = Catalog.custom.firstOrNull()
        T.check("pencere açıldı ve sunucu eklendi", h.calls.contains("promptCustom") && s != null && s.name == "Evim" && Catalog.byId(s.id) === s)
        T.check("ayara yazıldı ve kaydedildi", s != null && m.settings.custom.contains("Evim") && h.saved?.custom == m.settings.custom)
        T.check("listede görünür, bildirim", s != null && m.visibleServers().any { it.id == s.id } && m.toast?.text == Strings.customAdded("Evim"))
        h.customDraft = CustomDns.Draft("x", "bozuk", "", "", "")
        m.promptCustom()
        T.check("geçersiz girdi hata metni verir, eklenmez", h.customError == Strings.CUSTOM_ERR_IP && Catalog.custom.size == 1)
        m.commitCustom(CustomDns.Draft("x", "bozuk", "", "", ""))
        T.check("geçersiz girdi doğrudan da eklenmez", Catalog.custom.size == 1)
        val id = s!!.id
        m.toggleFavorite(id)
        m.update { it.copy(lastServer = id, wifiServer = id, backupServer = id) }
        m.onVpn(VpnUi(OrbState.ON, id, h.now, 0, 0, 20))
        T.check("bağlıyken silinemez", !m.removeCustom(id) && Catalog.byId(id) != null && m.toast?.text == Strings.CUSTOM_IN_USE)
        m.onVpn(VpnUi(OrbState.OFF))
        T.check("bağlı değilken silinir", m.removeCustom(id) && Catalog.byId(id) == null && Catalog.custom.isEmpty())
        T.check("bağlı seçimler temizlenir", id !in m.settings.favorites && m.settings.lastServer == null && m.settings.wifiServer == null && m.settings.backupServer == null && m.settings.custom == "")
        T.check("hazır sunucu silinemez", !m.removeCustom("cloudflare") && Catalog.byId("cloudflare") != null)
        for (i in 1..CustomDns.MAX) m.commitCustom(CustomDns.Draft("S$i", "192.168.1.$i", "", "", ""))
        m.commitCustom(CustomDns.Draft("fazla", "192.168.2.2", "", "", ""))
        T.check("en fazla ${CustomDns.MAX} özel sunucu", Catalog.custom.size == CustomDns.MAX)
        h.customDraft = CustomDns.Draft("fazla", "192.168.2.2", "", "", "")
        m.promptCustom()
        T.check("sınırda hata metni", h.customError == Strings.CUSTOM_ERR_LIMIT)
    } finally { Catalog.setCustom(emptyList()) }
}


fun testModelApps() {
    T.group("Model: uygulama seçimi")
    run {
        val (m, h) = newModel()
        m.loadApps()
        T.check("uygulamalar yüklenir", h.calls.contains("loadApps") && m.apps?.size == 3)
        m.setAppScope(AppScope.ONLY); m.toggleApp("com.example.mail", true)
        T.check("kapalıyken değişiklik beklemede sayılmaz", !m.appsPending && m.settings.apps == setOf("com.example.mail") && h.saved?.appScope == AppScope.ONLY && !h.calls.contains("reapply"))
        m.toggleApp("com.example.mail", false)
        T.check("seçim kaldırılır", m.settings.apps.isEmpty())
    }
    run {
        val (m, h) = newModel()
        m.onVpn(VpnUi(OrbState.ON, "cloudflare", h.now, 0, 0, 20))
        m.setAppScope(AppScope.EXCEPT)
        T.check("bağlıyken değişiklik beklemede", m.appsPending && !h.calls.contains("applyApps"))
        m.applyAppsNow()
        T.check("şimdi uygula: tünel yenilenir", !m.appsPending && h.calls.contains("applyApps") && m.toast?.text == Strings.APPLYING)
        m.toggleApp("org.example.browser", true)
        T.check("yeni değişiklik yine beklemede", m.appsPending)
        m.onVpn(VpnUi(OrbState.OFF))
        T.check("bağlantı kapanınca bekleme düşer (yeni bağlantı güncel seçimi kullanır)", !m.appsPending)
        m.applyAppsNow()
        T.check("bekleme yokken uygula bir şey yapmaz", h.calls.count { it == "applyApps" } == 1)
    }
}
