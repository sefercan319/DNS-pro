package app.dnshizli.selftest

import app.dnshizli.core.AppSettings
import app.dnshizli.core.BubbleLevel
import app.dnshizli.core.CacheLevel
import app.dnshizli.core.Catalog
import app.dnshizli.core.Latency
import app.dnshizli.core.Motion
import app.dnshizli.core.NightHours
import app.dnshizli.core.SortMode
import app.dnshizli.core.OrbState
import app.dnshizli.core.SettingsCodec
import app.dnshizli.core.Themes
import app.dnshizli.core.UiStyle
import app.dnshizli.ui.Filter
import app.dnshizli.ui.Scene
import app.dnshizli.ui.VpnUi
import java.util.Random

/**
 * Rastgele kullanım ("maymun") testi: sabit tohumlarla binlerce rastgele olay üretir. Denetlenenler:
 * istisna yok, çizim save/restore dengeli ve koordinatlar sonlu, sayfa yığını sınırlı, ayarlar geçerli aralıkta,
 * erişilebilirlik kutuları sağlam, dokunulmayınca sahne 16 ms kare istemeyi bırakıyor, aynı tohum aynı sonucu veriyor.
 */
private class Monkey(private val seed: Long, private val steps: Int) {
    private val rnd = Random(seed)
    private val ids = Catalog.all.map { it.id }
    private val themeIds = Themes.all.map { it.id } + Themes.AUTO_ID
    private val g = CountingGfx()
    private val recent = ArrayDeque<String>()
    private val errors = listOf("İzin verilmedi", "Başka bir VPN etkin", "Ağ yok", "x".repeat(300), "")
    private val texts = listOf("Kısa", "Biraz daha uzun bir bildirim metni", "Çok uzun bir bildirim ".repeat(12), "")

    private var sizeW = 360f
    private var sizeH = 780f
    // Rastgele dokunuşlar dil seçicisine de basabilir; her koşu aynı dilden başlamalı ki aynı tohum aynı sonucu versin.
    private val langReset = app.dnshizli.core.L.set(app.dnshizli.core.Lang.TR)
    private var rig = Rig(Rig.base().copy(onboarded = rnd.nextInt(4) != 0, style = UiStyle.values()[rnd.nextInt(UiStyle.values().size)]), 360, 780)

    var failure: String? = null
        private set
    var maxPages = 1
        private set
    var draws = 0
        private set
    var quietChecks = 0
        private set

    private fun <X> pick(a: List<X>): X = a[rnd.nextInt(a.size)]
    private fun <X> pick(a: Array<X>): X = a[rnd.nextInt(a.size)]
    private fun op(s: String) { if (recent.size >= 14) recent.removeFirst(); recent.addLast(s) }
    private fun fail(what: String) { if (failure == null) failure = "$what  | son işlemler: " + recent.joinToString(" ; ") }

    private fun rx() = rnd.nextFloat() * (sizeW + 40f) - 20f
    private fun ry() = rnd.nextFloat() * (sizeH + 40f) - 20f

    private fun randomSettings(s: AppSettings): AppSettings = when (rnd.nextInt(15)) {
        0 -> s.copy(theme = pick(themeIds))
        1 -> s.copy(glass = rnd.nextFloat())
        2 -> s.copy(bubbles = pick(BubbleLevel.values()))
        3 -> s.copy(motion = pick(Motion.values()))
        4 -> s.copy(haptics = !s.haptics)
        5 -> s.copy(lowPower = !s.lowPower)
        6 -> s.copy(autoConnect = !s.autoConnect)
        7 -> s.copy(cache = pick(CacheLevel.values()))
        8 -> s.copy(wifiServer = if (rnd.nextBoolean()) null else pick(ids))
        9 -> s.copy(mobileServer = if (rnd.nextBoolean()) null else pick(ids))
        10 -> s.copy(favorites = ids.filter { rnd.nextInt(3) == 0 }.toSet())
        11 -> s.copy(sortMode = pick(SortMode.values()), strictEncryption = rnd.nextBoolean(), nightHours = pick(NightHours.values()),
            backupServer = if (rnd.nextBoolean()) null else if (rnd.nextBoolean()) AppSettings.BACKUP_AUTO else pick(ids),
            autoLight = pick(Themes.all.filter { !it.dark }.map { it.id }), autoDark = pick(Themes.all.filter { it.dark }.map { it.id }),
            confirmDisconnect = rnd.nextBoolean(), autoMeasure = rnd.nextBoolean(), rememberFilter = rnd.nextBoolean())
        12 -> s.copy(lastServer = pick(ids))
        13 -> s.copy(totalQueries = if (rnd.nextInt(8) == 0) 4_000_000_000_000L else rnd.nextInt(2_000_000).toLong(),
            totalHits = rnd.nextInt(2_000_000).toLong(), totalSeconds = rnd.nextInt(90_000_000).toLong())
        else -> s.copy(refreshOnNetwork = !s.refreshOnNetwork, connectOnBoot = !s.connectOnBoot)
    }

    private fun randomVpn(): VpnUi {
        val st = pick(OrbState.values())
        val id = if (rnd.nextInt(5) == 0) null else pick(ids)
        val big = rnd.nextInt(10) == 0
        return VpnUi(
            st, id, rig.host.now - rnd.nextInt(4_000_000) + (if (rnd.nextInt(20) == 0) 90_000 else 0),
            if (big) 9_000_000_000_000L else rnd.nextInt(100_000).toLong(),
            if (big) 8_000_000_000_000L else rnd.nextInt(60_000).toLong(),
            rnd.nextInt(500), if (st == OrbState.ERROR) pick(errors) else null, rnd.nextBoolean(),
        )
    }

    private fun randomResize() {
        val ws = floatArrayOf(320f, 360f, 392f, 411f, 600f, 800f, 780f)
        val hs = floatArrayOf(568f, 640f, 780f, 915f, 1100f, 360f, 400f)
        sizeW = ws[rnd.nextInt(ws.size)]; sizeH = hs[rnd.nextInt(hs.size)]
        val top = floatArrayOf(0f, 24f, 48f)[rnd.nextInt(3)]
        val bot = floatArrayOf(0f, 16f, 34f)[rnd.nextInt(3)]
        op("resize ${sizeW.toInt()}x${sizeH.toInt()}")
        rig.scene.resize(sizeW, sizeH, top, bot)
    }

    private fun randomItem() = rig.items().let { if (it.isEmpty()) null else it[rnd.nextInt(it.size)] }

    private fun oneStep() {
        val sc = rig.scene
        val m = rig.model
        when (rnd.nextInt(100)) {
            in 0..11 -> { val x = rx(); val y = ry(); op("tap %.0f,%.0f".format(x, y)); rig.tap(x, y, rnd.nextInt(300).toLong()) }
            in 12..27 -> randomItem()?.let { op("tapItem ${it.info.label.take(18)}"); rig.tapItem(it, rnd.nextInt(300).toLong()) }
            in 28..33 -> { val x = rx(); val y0 = ry(); val y1 = ry(); op("drag y"); rig.drag(x, y0, y1, 3 + rnd.nextInt(12)) }
            in 34..36 -> { val y = ry(); val x0 = rx(); val x1 = rx(); op("drag x"); rig.dragX(y, x0, x1, 3 + rnd.nextInt(10)) }
            in 37..42 -> { val x = rx(); val y0 = ry(); val y1 = ry(); op("fling"); rig.fling(x, y0, y1, 2 + rnd.nextInt(6)); rig.advance(rnd.nextInt(800).toLong()) }
            in 43..45 -> randomItem()?.let { op("longPress ${it.info.label.take(18)}"); rig.longPress(rig.cx(it), rig.cy(it), 300L + rnd.nextInt(600)) }
            in 46..50 -> { op("back"); val had = sc.hasSheet || sc.pageCount > 1 || sc.transitioning(); if (had != sc.canGoBack) fail("canGoBack kuralı goBack ile uyuşmuyor"); val r = sc.goBack(); if (had != r) fail("geri: tüketim beklenenle uyuşmuyor ($had/$r)"); rig.advance(rnd.nextInt(400).toLong()) }
            in 51..52 -> randomResize()
            in 53..54 -> { val f = floatArrayOf(1f, 1.15f, 1.3f, 2f, 0.5f)[rnd.nextInt(5)]; op("fontScale $f"); sc.setFontScale(f) }
            in 55..56 -> { op("dark"); sc.setSystemDark(rnd.nextBoolean()) }
            57 -> { op("systemMotion"); sc.setSystemMotion(rnd.nextBoolean()) }
            in 58..63 -> { op("onVpn"); m.onVpn(randomVpn()) }
            in 64..67 -> { val id = pick(ids); val ms = if (rnd.nextInt(4) == 0) null else rnd.nextInt(2500); op("onLatency $id $ms"); m.onLatency(id, ms) }
            68 -> { op("onMeasureDone"); m.onMeasureDone() }
            in 69..70 -> { op("toast"); m.toast(pick(texts), if (rnd.nextBoolean()) "Geri al" else null) { } }
            in 71..76 -> { op("update"); m.update { randomSettings(it) } }
            77 -> { op("replaceSettings"); m.replaceSettings(randomSettings(m.settings)) }
            in 78..83 -> randomItem()?.let {
                when (rnd.nextInt(4)) {
                    0, 1 -> { op("a11yClick ${it.info.label.take(18)}"); sc.a11yClick(it) }
                    2 -> { op("a11yLong ${it.info.label.take(18)}"); sc.a11yLongClick(it) }
                    else -> { op("a11yAdjust ${it.info.label.take(18)}"); sc.a11yAdjust(it, if (rnd.nextBoolean()) 1 else -1) }
                }
            }
            in 84..91 -> { val ms = rnd.nextInt(500).toLong(); op("advance $ms"); rig.advance(ms, 8L + rnd.nextInt(40)) }
            in 92..94 -> { val a = rnd.nextInt(4); op("raw touch $a"); sc.touch(a, rx(), ry(), rig.host.now) }
            in 95..96 -> { op("burst"); rig.down(rx(), ry()); repeat(20) { sc.touch(Scene.MOVE, rx(), ry(), rig.host.now) }; rig.up(rx(), ry()); rig.advance(100) }
            97 -> { op("tapOrb"); m.tapOrb() }
            98 -> { if (rnd.nextBoolean()) { op("measureAll"); m.measureAll() } else { op("connectFastest"); m.connectFastest() } }
            else -> when (rnd.nextInt(3)) {
                0 -> { op("filter"); m.setFilter(pick(Filter.values())) }
                1 -> { op("tapServer"); m.tapServer(pick(ids)) }
                else -> { op("fav"); m.toggleFavorite(pick(ids)) }
            }
        }
        if (rnd.nextInt(6) == 0) rig.host.diag = if (rnd.nextBoolean()) "" else (1..rnd.nextInt(400)).joinToString("\n") { "12:00:%02d olay $it ${"y".repeat(rnd.nextInt(120))}".format(it % 60) }
    }

    private fun invariants() {
        val sc = rig.scene
        val m = rig.model
        if (sc.pageCount !in 1..4) fail("sayfa sayısı ${sc.pageCount}")
        if (sc.pageCount > maxPages) maxPages = sc.pageCount
        g.reset(); sc.draw(g); draws++
        if (g.depth != 0 || g.underflow) fail("save/restore dengesiz (derinlik=${g.depth}, alt taşma=${g.underflow})")
        if (g.bad != 0) fail("çizimde sonlu olmayan sayı: ${g.bad}")
        if (g.calls == 0) fail("boş kare")
        val s = m.settings
        if (s.glass !in 0f..1f || !Themes.isValidId(s.theme) || s.favorites.any { Catalog.byId(it) == null }) fail("geçersiz ayar: $s")
        for (it in sc.a11yItems()) {
            if (!(it.l.isFinite() && it.t.isFinite() && it.r.isFinite() && it.b.isFinite()) || it.r < it.l || it.b < it.t) fail("a11y kutusu bozuk: ${it.info.label} ${it.l},${it.t},${it.r},${it.b}")
            if (it.info.label.isBlank()) fail("a11y etiketi boş: ${it.node.javaClass.simpleName} ${it.l},${it.t},${it.r},${it.b} rol=${it.info.role}")
        }
    }

    /** Parmaklar kalktıktan ve zaman geçtikten sonra sahne dinlenmeye geçmeli. */
    private fun quiet() {
        val sc = rig.scene
        sc.touch(Scene.CANCEL, 0f, 0f, rig.host.now)
        rig.advance(9000, 33)
        if (rig.lastDelay == 16L) rig.advance(2000, 33)   // ölçüm zaman aşımı gibi geç tetiklenen kısa bir animasyon olabilir
        quietChecks++
        val d = rig.lastDelay
        if (d != 33L && d != -1L) fail("9 sn sonra sahne hâlâ $d ms kare istiyor; etkin düğümler: ${activeNodes()}")
        if (!sc.env.ambient && !sc.toastActive && d != -1L) fail("süs animasyonu kapalı ama sahne kare istiyor ($d)")
    }

    /** Hata ayıklama: tick() değeri true dönen yaprak düğümler (derinlik:sınıf). */
    private fun activeNodes(): String {
        val out = ArrayList<String>()
        fun walk(n: app.dnshizli.ui.Node, depth: Int) {
            if (n.children.isEmpty()) { if (n.tick(0.016f, rig.scene.env)) out.add("$depth:${n.javaClass.simpleName}@${n.absY().toInt()}") }
            for (k in n.children) walk(k, depth + 1)
        }
        walk(rig.scene.currentPage, 0)
        return out.joinToString(",")
    }

    fun run(): Monkey {
        try {
            val first = rnd.nextInt(4)
            if (first > 0) rig.model.update { randomSettings(it) }
            for (i in 1..steps) {
                oneStep()
                invariants()
                if (failure != null) return this
                if (i % 250 == 0) { quiet(); if (failure != null) return this }
            }
            // sonuç denetimleri
            val calls = rig.host.calls
            for (c in calls) if (c.startsWith("connect:") && Catalog.byId(c.substring(8)) == null) fail("geçersiz sunucu kimliğiyle bağlanıldı: $c")
            if (rig.host.lastMeasureIds.any { Catalog.byId(it) == null }) fail("ölçüm geçersiz kimlik içeriyor")
            rig.host.saved?.let { if (SettingsCodec.decode(SettingsCodec.encode(it)) != it) fail("kaydedilen ayar kodlama gidiş-dönüşünde değişiyor: $it") }
            if (rig.model.latencies.size > Catalog.all.size) fail("gecikme tablosu büyüdü: ${rig.model.latencies.size}")
        } catch (e: Throwable) {
            val where = e.stackTrace.take(6).joinToString(" < ") { "${it.fileName}:${it.lineNumber}" }
            fail("istisna: $e @ $where")
        }
        return this
    }

    /** Tekrarlanabilirlik özeti: aynı tohum, aynı sonuç. */
    fun fingerprint(): String =
        "${rig.model.version}/${rig.host.calls.size}/${rig.host.savedCount}/${rig.scene.pageCount}/${rig.model.settings.hashCode()}/${rig.model.vpn.state}/${draws}"
}

fun runMonkeyTests() {
    T.group("maymun: rastgele kullanım")
    // Varsayılan: 5 sabit tohum. Uzun tarama için: MONKEY_SEEDS=200 MONKEY_STEPS=4000 (tohumlar 1..N)
    val extra = System.getenv("MONKEY_SEEDS")?.toIntOrNull()
    val seeds = if (extra != null) LongArray(extra) { it + 1L } else longArrayOf(1, 2, 3, 7, 42)
    val steps = (System.getenv("MONKEY_STEPS")?.toIntOrNull() ?: 2500)
    var pages = 1
    var draws = 0
    for (s in seeds) {
        val r = Monkey(s, steps).run()
        T.check("tohum $s: $steps rastgele olay, değişmezler korunuyor", r.failure == null, r.failure ?: "")
        if (r.maxPages > pages) pages = r.maxPages
        draws += r.draws
    }
    T.check("rastgele kullanımda sayfa yığını en çok 4 kat ($pages)", pages in 1..4)
    T.check("rastgele kullanımda çok sayıda kare çizildi ($draws)", draws >= seeds.size * steps)

    T.group("maymun: tekrarlanabilirlik")
    val a = Monkey(5, 600).run()
    val b = Monkey(5, 600).run()
    T.check("aynı tohum aynı sonucu veriyor", a.failure == null && b.failure == null && a.fingerprint() == b.fingerprint(), "${a.fingerprint()} <> ${b.fingerprint()} ${a.failure ?: b.failure ?: ""}")
}
