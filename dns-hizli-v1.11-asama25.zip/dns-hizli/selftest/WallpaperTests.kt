package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*
import java.lang.management.ManagementFactory

private val mx2 = ManagementFactory.getThreadMXBean() as com.sun.management.ThreadMXBean

/** Rig + sahnede fotoğraf. */
private fun wrig(s: AppSettings = Rig.base(), lo: Float = 0.4f, hi: Float = 0.6f): Rig {
    val r = Rig(s)
    r.host.wpLuma = lo to hi
    r.host.wpStored = true
    r.model.update { it.copy(wallpaper = true, wpRev = it.wpRev + 1) }
    r.settle(900)
    return r
}

/** Aşama 6: kullanıcının arka plan fotoğrafı. */
fun testWallpaper() {
    T.group("Arka plan: saf hesaplar")
    run {
        val c = WallpaperMath.cover(1000, 1000, 360f, 780f)
        T.check("kaplama: kare foto dikey ekrana yanlardan kırpılır, oran korunur",
            c[1] == 0f && c[3] == 1000f && Math.abs((c[2] - c[0]) / (c[3] - c[1]) - 360f / 780f) < 1e-3f && Math.abs(c[0] - (1000 - (c[2] - c[0])) / 2f) < 1e-2f)
        val d = WallpaperMath.cover(500, 2000, 360f, 780f)
        T.check("kaplama: çok uzun foto üstten/alttan kırpılır", d[0] == 0f && d[2] == 500f && Math.abs((d[2] - d[0]) / (d[3] - d[1]) - 360f / 780f) < 1e-3f)
        val e = WallpaperMath.cover(0, 0, 0f, 0f)
        T.check("kaplama: sıfır boyutlar çökmez", e.size == 4 && e.all { !it.isNaN() })
    }
    T.check("açık tema: açık fotoğraf perdesiz, koyu fotoğraf perde ister",
        WallpaperMath.minVeil(false, 0.8f, 0.95f) == 0f && WallpaperMath.minVeil(false, 0.05f, 0.5f) > 0.5f)
    T.check("koyu tema: koyu fotoğraf perdesiz, parlak fotoğraf perde ister",
        WallpaperMath.minVeil(true, 0.0f, 0.2f) == 0f && WallpaperMath.minVeil(true, 0.5f, 0.98f) > 0.5f)
    run {
        var ok = true
        for (dark in listOf(false, true)) for (lo in 0..10) for (hi in lo..10) for (u in 0..8) for (hc in listOf(false, true)) {
            val v = WallpaperMath.veil(dark, lo / 10f, hi / 10f, u / 10f, hc)
            if (v.isNaN() || v < 0f || v > 0.85f || v < minOf(u / 10f, 0.85f) - 1e-4f || v < WallpaperMath.minVeil(dark, lo / 10f, hi / 10f) - 1e-4f) ok = false
            if (hc && v < 0.75f - 1e-4f) ok = false
        }
        T.check("perde: her girdide 0..0,85, kullanıcı seçiminden ve okunabilirlik alt sınırından küçük değil, yüksek kontrastta ≥0,75", ok)
    }
    T.check("perde rengi: açık temada açık, koyu temada koyu",
        WallpaperMath.luma(WallpaperMath.veilColor(Themes.aqua)) > 0.7f && WallpaperMath.luma(WallpaperMath.veilColor(Themes.night)) < 0.2f)
    run {
        val p = WallpaperMath.prepare(4000, 3000, 360f / 780f)
        val cw = p[2] - p[0]; val ch = p[3] - p[1]
        T.check("hazırlık: ekran oranına kırpılır, ortalanır, sınırlara küçültülür",
            Math.abs(cw.toFloat() / ch - 360f / 780f) < 0.01f && p[0] == (4000 - cw) / 2 && p[4] <= WallpaperMath.MAX_WIDTH && p[5] <= WallpaperMath.MAX_HEIGHT && p[3] <= 3000)
        val small = WallpaperMath.prepare(300, 600, 0.5f)
        T.check("hazırlık: küçük görüntü büyütülmez", small[4] == 300 && small[5] == 600, small.toList().toString())
        val weird = WallpaperMath.prepare(1, 1, 0f)
        T.check("hazırlık: 1x1 ve saçma oran çökmez", weird.all { it >= 0 } && weird[4] >= 1 && weird[5] >= 1)
    }
    T.check("yüzdelik dilim", WallpaperMath.percentile(floatArrayOf(0.9f, 0.1f, 0.5f), 0f) == 0.1f && WallpaperMath.percentile(floatArrayOf(0.9f, 0.1f, 0.5f), 1f) == 0.9f && WallpaperMath.percentile(floatArrayOf(), 0.5f) == 0.5f)
    T.check("bulanıklık: kimlikler, bölenler, byId", WpBlur.values().map { it.divisor } == listOf(1, 6, 16) && WpBlur.values().all { WpBlur.byId(it.id) == it } && WpBlur.byId("x") == null)
    run {
        var n = 0
        val p = Pic(10, 10, Any(), 0f, 1f) { n++ }
        p.release(); p.release()
        T.check("Pic: bellek bir kez geri verilir", n == 1 && p.isReleased)
    }

    T.group("Arka plan: ayarlar")
    run {
        val s = AppSettings(wallpaper = true, wpRev = 5, wpDim = 0.5f, wpBlur = WpBlur.STRONG)
        val d = SettingsCodec.decode(SettingsCodec.encode(s))
        T.check("kodlayıcı gidiş-dönüş", d.wallpaper && d.wpRev == 5 && Math.abs(d.wpDim - 0.5f) < 1e-4f && d.wpBlur == WpBlur.STRONG)
        T.check("varsayılan: fotoğraf yok, perde 0,35, bulanıklık yok", AppSettings().let { !it.wallpaper && it.wpRev == 0 && it.wpDim == WallpaperMath.DIM_DEFAULT && it.wpBlur == WpBlur.OFF })
        val bad = SettingsCodec.decode(mapOf("wpDim" to "9", "wpBlur" to "zzz", "wpRev" to "abc", "wallpaper" to "x"))
        T.check("bozuk değerler güvenli varsayılana/sınıra düşer", bad.wpDim <= WallpaperMath.DIM_MAX && bad.wpDim >= 0f && bad.wpBlur == WpBlur.OFF && bad.wpRev == 0 && !bad.wallpaper)
        val exp = SettingsCodec.export(s)
        val body = String(Base64Mini.decode(exp.removePrefix("DNSH1:"))!!, Charsets.UTF_8)
        val keys = body.lines().map { it.substringBefore('=') }
        T.check("dışa aktarım: fotoğraf var/sürüm cihaza özel (yok), perde ve bulanıklık var", "wallpaper" !in keys && "wpRev" !in keys && "wpDim" in keys && "wpBlur" in keys, keys.toString())
        val imp = SettingsCodec.import(exp, AppSettings(wallpaper = true, wpRev = 3))
        T.check("içe aktarım: bu telefondaki fotoğrafı silmez, perde/bulanıklığı alır", imp != null && imp.wallpaper && imp.wpRev == 3 && imp.wpBlur == WpBlur.STRONG)
    }

    T.group("Arka plan: sahne")
    run {
        val g = CountingGfx()
        val none = Rig(); g.reset(); none.scene.draw(g)
        T.check("fotoğraf yokken görüntü çizilmez, yükleme istenmez", g.images == 0 && !none.scene.wallpaperShown && none.host.calls.none { it.startsWith("loadWallpaper") })

        val r = wrig()
        g.reset(); r.scene.draw(g)
        val li = g.lastImage
        T.check("fotoğraf varken yüklenir ve çizilir", r.scene.wallpaperShown && g.images == 1 && li != null && r.host.calls.contains("loadWallpaper:off") && g.bad == 0 && g.depth == 0, "images=${g.images}")
        T.check("kaynak dikdörtgen resmin içinde, hedef ekranı kaplar", li != null && li[0] >= 0f && li[1] >= 0f && li[2] <= 360f + 0.01f && li[3] <= 780f + 0.01f && li[4] <= 0f && li[5] <= 0f && li[6] >= 360f && li[7] >= 780f, li?.toList().toString())
        val loaded = r.host.wpLoaded
        r.model.update { it.copy(wpDim = 0.6f) }; r.settle(300)
        T.check("perde değişince yeniden yüklenmez", r.host.wpLoaded == loaded)
        r.model.update { it.copy(wpBlur = WpBlur.SOFT) }; r.settle(900)
        T.check("bulanıklık değişince yeniden yüklenir, eski görüntü geri verilir", r.host.wpLoaded == loaded + 1 && r.host.calls.contains("loadWallpaper:soft") && r.host.wpReleased == 1 && r.scene.wallpaperShown)
        r.model.update { it.copy(wpRev = it.wpRev + 1) }; r.settle(900)
        T.check("yeni dosya (sürüm) yeniden yükler", r.host.wpLoaded == loaded + 2 && r.host.wpReleased == 2)
        r.host.wpStored = false
        r.model.update { it.copy(wallpaper = false) }; r.settle(300)
        g.reset(); r.scene.draw(g)
        T.check("kapatınca görüntü çizilmez ve bellek geri verilir", !r.scene.wallpaperShown && g.images == 0 && r.host.wpReleased == 3)
    }
    run {
        val r = Rig()
        r.model.update { it.copy(wallpaper = true, wpRev = 1) }; r.settle(600)
        T.check("dosya yoksa/bozuksa ayar sessizce kapanır (kendini onarır)", !r.model.settings.wallpaper && !r.scene.wallpaperShown && !r.scene.toastActive)
    }
    run {
        // geç gelen eski yükleme yeni durumu bozmaz
        val r = Rig()
        val pending = ArrayList<(Pic?) -> Unit>()
        var released = 0
        val saveLoader = r.host
        r.host.wpStored = true
        r.host.deferLoad = { cb -> pending.add(cb) }
        r.model.update { it.copy(wallpaper = true, wpRev = 1) }; r.settle(100)
        r.model.update { it.copy(wpBlur = WpBlur.SOFT) }; r.settle(100)
        T.check("iki yükleme beklemede", pending.size == 2)
        pending[1](Pic(10, 10, Any(), 0.4f, 0.6f) { released += 10 })
        pending[0](Pic(10, 10, Any(), 0.4f, 0.6f) { released += 1 })
        r.settle(600)
        T.check("eski yükleme gelirse atılır ve bırakılır, yeni olan kalır", released == 1 && r.scene.wallpaperShown, "released=$released")
        saveLoader.deferLoad = null
    }
    run {
        val g = CountingGfx()
        val r = wrig(Rig.base().copy(motion = Motion.OFF))
        g.reset(); r.scene.draw(g)
        T.check("hareket kapalı: fotoğraf hemen tam görünür çizilir", g.images == 1 && g.bad == 0)
        r.settle(300)
        T.check("hareket kapalı: kare gerekmez", r.lastDelay == -1L, "${r.lastDelay}")
        val w = wrig()
        w.settle(1500)
        T.check("fotoğraf varken durağan ekranda süs kareleri gerekmez (gökyüzü canlı değil)", w.lastDelay == -1L || w.lastDelay == 33L, "${w.lastDelay}")
    }

    T.group("Arka plan: her stil ve tema")
    run {
        val g = CountingGfx()
        for (st in UiStyle.values()) for (th in listOf("aqua", "night", "sakura", "meadow", "amoled")) for (b in listOf(0.2f to 0.5f, 0.0f to 1.0f)) {
            val r = wrig(Rig.base(th).copy(style = st), b.first, b.second)
            r.connectOk()
            val where = "${st.label}/$th/${b.first}-${b.second}"
            g.reset(); r.scene.draw(g)
            T.check("$where ana ekran: fotoğraf çizilir, çizim geçerli, bütçe içinde", g.images == 1 && g.bad == 0 && !g.underflow && g.depth == 0 && g.calls < 4200, "img=${g.images} bad=${g.bad} calls=${g.calls}")
            r.scene.openSection(Section.DNS); r.settle(900)
            g.reset(); r.scene.draw(g)
            T.check("$where dns ayarları: geçerli", g.images == 1 && g.bad == 0 && !g.underflow && g.depth == 0 && g.calls < 4200)
            r.scene.back(); r.settle(900)
            r.scene.openPersonalize(); r.settle(900)
            g.reset(); r.scene.draw(g)
            T.check("$where kişiselleştirme: geçerli", g.images == 1 && g.bad == 0 && !g.underflow && g.depth == 0 && g.calls < 4200)
            r.scene.back(); r.settle(900)
            r.scene.openDetails(Catalog.byId("quad9")!!); r.settle(700)
            g.reset(); r.scene.draw(g)
            T.check("$where ayrıntı paneli: geçerli", g.bad == 0 && !g.underflow && g.depth == 0)
        }
    }
    run {
        // arayüz bozulmaz: yazılar ve dokunulabilir öğeler fotoğraf olmadan olanla aynı
        val base = Rig(); base.connectOk(); base.settle(1200)
        val ref = base.items().map { it.info.label }
        val r = wrig(); r.connectOk(); r.settle(1200)
        T.check("erişilebilirlik etiketleri fotoğrafsız ekranla aynı", r.items().map { it.info.label } == ref)
        val a = TextRecorder().also { base.scene.draw(it) }.runs.map { it.s to Math.round(it.l) to Math.round(it.t) }
        val b = TextRecorder().also { r.scene.draw(it) }.runs.map { it.s to Math.round(it.l) to Math.round(it.t) }
        T.check("yazı yerleşimi fotoğrafsız ekranla aynı", a == b, "${a.size} <> ${b.size}")
    }

    T.group("Arka plan: ayarlardan akış")
    run {
        val r = Rig()
        r.scene.openPersonalize(); r.settle(900)
        T.check("kişiselleştirmede Arka plan fotoğrafı, perde ve bulanıklık satırları var", r.reveal(Strings.WALLPAPER) != null && r.reveal(Strings.WP_DIM) != null && r.reveal(Strings.WP_BLUR) != null)
        r.tapText(Strings.WALLPAPER, settleMs = 800)
        T.check("seçici: yalnızca 'seç' var, 'kaldır' yok (fotoğraf yok)", r.find(Strings.WP_PICK) != null && r.find(Strings.WP_REMOVE) == null)
        T.check("seçicide 'Hazır görseller' var", r.find(Strings.WP_PRESETS) != null)
        r.tapText(Strings.WP_PICK, settleMs = 600)
        T.check("seç → sistem seçicisi istenir", r.host.calls.contains("pickWallpaper") && !r.scene.hasSheet)
        r.host.wpStored = true
        r.model.onWallpaperPicked(true); r.settle(900)
        T.check("seçim başarılı: ayar açılır, fotoğraf sahnede, bildirim çıkar", r.model.settings.wallpaper && r.scene.wallpaperShown && r.scene.toastActive)
        T.check("bildirim metni", TextRecorder().also { r.scene.draw(it) }.runs.any { it.s == Strings.WP_SAVED })
        r.settle(4500)
        r.tapText(Strings.WALLPAPER, settleMs = 800)
        r.tapText(Strings.WP_PRESETS, settleMs = 700)
        T.check("hazır görseller: 8 ad listelenir", WallpaperPresets.NAMES.size == 8 && WallpaperPresets.NAMES.all { r.find(it) != null })
        r.tapText("Rain Alley", settleMs = 600)
        T.check("hazır görsel seçilince ilgili sıra istenir, pencere kapanır", r.host.calls.contains("preset:3") && !r.scene.hasSheet)
        r.model.onWallpaperPicked(true); r.settle(900)
        r.settle(4500)
        r.tapText(Strings.WALLPAPER, settleMs = 800)
        T.check("seçici: fotoğraf varken 'kaldır' da var", r.find(Strings.WP_REMOVE) != null)
        r.tapText(Strings.WP_REMOVE, settleMs = 900)
        T.check("kaldır: dosya silinir, ayar kapanır, fotoğraf gider", r.host.calls.contains("removeWallpaper") && !r.model.settings.wallpaper && !r.scene.wallpaperShown)
        r.model.onWallpaperPicked(false); r.advance(200)
        T.check("seçim başarısız: ayar değişmez, hata bildirimi", !r.model.settings.wallpaper && TextRecorder().also { r.scene.draw(it) }.runs.any { it.s == Strings.WP_FAILED })
    }

    T.group("Arka plan: her dilde metinler")
    val saved = L.lang
    try {
        for (lang in Lang.values()) {
            L.set(lang)
            val o = Strings.OPT_WP_BLUR
            val all = listOf(Strings.WALLPAPER, Strings.WP_OFF, Strings.WP_ON, Strings.WP_PICK, Strings.WP_PICK_NOTE, Strings.WP_REMOVE, Strings.WP_DIM, Strings.WP_BLUR, Strings.WP_SAVED, Strings.WP_FAILED, Strings.WP_REMOVED, Strings.WP_PRESETS, Strings.WP_PRESETS_NOTE)
            T.check("${lang.native}: 13 metin dolu, bulanıklık 3 seçenek", all.all { it.isNotBlank() && it.length <= 150 } && o.size == 3 && o.toSet().size == 3 && o.all { it.length in 1..14 }, all.toString())
            T.check("${lang.native}: yeniliklerde arka plan maddesi", Strings.WHATS_NEW_ITEMS.size >= 2 && Strings.WHATS_NEW_ITEMS.first().length in 15..160)
        }
    } finally { L.set(saved) }

    T.group("Arka plan: kare başına bellek")
    run {
        val g = CountingGfx()
        for (st in listOf(UiStyle.AQUA, UiStyle.METRO, UiStyle.Y2K)) {
            val r = wrig(Rig.base().copy(style = st)); r.connectOk()
            repeat(150) { r.host.now += 16; r.scene.tick(r.host.now); g.reset(); r.scene.draw(g) }
            val before = mx2.getThreadAllocatedBytes(Thread.currentThread().id)
            for (i in 0 until 300) { r.host.now += 16; r.scene.tick(r.host.now); g.reset(); r.scene.draw(g) }
            val per = (mx2.getThreadAllocatedBytes(Thread.currentThread().id) - before) / 300.0
            T.check("${st.label}: fotoğrafla kare başına ≤96 bayt", per <= 96.0, "%.1f".format(per))
        }
    }
}

/** Gömülü hazır görseller: dosyalar var, çözülebilir, makul boyutta; toplam boyut sınırlı. */
fun testWallpaperPresets() {
    T.group("Hazır görseller: dosyalar")
    var total = 0L
    val root = java.io.File("app/src/main/assets")
    for (i in WallpaperPresets.NAMES.indices) {
        val f = java.io.File(root, WallpaperPresets.asset(i))
        val img = try { javax.imageio.ImageIO.read(f) } catch (_: Exception) { null }
        T.check("${WallpaperPresets.NAMES[i]}: dosya var ve çözülür", f.isFile && img != null)
        if (img != null) T.check("${WallpaperPresets.NAMES[i]}: boyut makul (600–1300 px, <260 KB)", img.width in 600..1300 && img.height in 600..1300 && f.length() < 260_000, "${img.width}x${img.height} ${f.length()}")
        total += f.length()
    }
    T.check("toplam 2 MB altında", total < 2_000_000, total.toString())
    T.check("adlar benzersiz ve boş değil", WallpaperPresets.NAMES.toSet().size == 8 && WallpaperPresets.NAMES.all { it.isNotBlank() })
}
