package app.dnshizli.selftest

import app.dnshizli.core.*
import app.dnshizli.ui.*

/** Modül kartlarının "son 10 dk" sayacı ve ana ekran özet satırı. */
fun runRecentTests() {
    T.group("Son 10 dk sayacı")
    val min = 60_000L
    run {
        val c = RollingCounter()
        T.check("veri yokken 0", c.recent() == 0L)
        c.record(0, 100)
        T.check("tek örnekle 0 (fark yok)", c.recent() == 0L)
        c.record(2 * min, 130)
        T.check("2 dk sonra artış 30", c.recent() == 30L)
        c.record(5 * min, 150)
        T.check("5 dk sonra artış 50", c.recent() == 50L)
    }
    run {
        val c = RollingCounter()
        for (m in 0..30) c.record(m * min, m * 10L)       // dakikada 10 artış
        T.check("pencere kayar: 30. dkda son 10 dk = 100", c.recent() == 100L)
        c.record(60 * min, 310)                             // 30 dk sessizlik, sonra 10 artış
        T.check("uzun sessizlikten sonra eski artışlar sayılmaz (taban en yakın eski örnek)", c.recent() == 10L)
    }
    run {
        val c = RollingCounter()
        c.record(0, 500)
        c.record(min, 520)
        c.record(2 * min, 5)      // yeni oturum: toplam düştü
        T.check("toplam düşünce geçmiş atılır", c.recent() == 0L)
        c.record(3 * min, 25)
        T.check("sıfırlamadan sonra yeniden artış sayılır", c.recent() == 20L)
    }
    run {
        val c = RollingCounter()
        c.record(0, 10)
        c.record(1_000, 14)       // 5 sn'den sık: son örnek güncellenir, yeni örnek açılmaz
        c.record(2_000, 19)
        T.check("sık çağrıda ilk örnek korunur, son değer güncellenir", c.recent() == 9L)
    }
    run {
        val c = RollingCounter()
        var t = 0L
        for (i in 0 until 5000) { t += 5_000; c.record(t, i.toLong()) }
        T.check("çok uzun çalışmada bellek sabit, artış ~10 dk (≤ 125 adım)", c.recent() in 100L..125L)
        c.clear()
        T.check("clear sıfırlar", c.recent() == 0L)
    }

    T.group("Ana ekran: hızlı profil çipleri")
    run {
        val rig = Rig(Rig.base(), 360, 1100)
        val names = Strings.PROFILE_NAMES.map { Strings.PROFILES + ": " + it }
        T.check("dört profil çipi var, erişilebilirlik etiketi 'Profiller: ad'", names.all { rig.find(it, exact = true) != null })
        rig.tapText(names[1], exact = true)          // Gizlilik
        rig.settle(600)
        val p = Profiles.byId("privacy")!!
        T.check("Gizlilik çipi profili uygular (sıkı şifreleme, süzgeç, sunucu)",
            rig.model.settings.strictEncryption == p.encryptionStrict && rig.model.settings.filterLevel == p.filter && rig.model.settings.lastServer == p.serverId)
        T.check("uygulanan profilin çipi seçili okunur", rig.find(names[1], exact = true)?.info?.checked == true && rig.find(names[0], exact = true)?.info?.checked == false)
        T.check("'Aile' süzgeç çipi ile profil çipi karışmaz", rig.find("Aile", exact = true) != null && rig.find("Aile", exact = true)?.info?.label != names[2])
    }

    T.group("Ana ekran özet satırı")
    val saved = L.lang
    try {
        for (lang in Lang.values()) {
            L.set(lang)
            val line = Strings.todayLine(1240)
            T.check("${lang.name}: bugün satırı sözcük ve sayı içerir", line.startsWith(Strings.TODAY) && line.contains("·") && line.length > Strings.TODAY.length + 3)
            val w = Strings.modWindow(Strings.modAdsCount("42"))
            T.check("${lang.name}: son 10 dk satırı sayı ve açıklama içerir", w.contains("42") && w.contains("10"))
        }
    } finally { L.set(saved) }
}
