package app.dnshizli.selftest

import app.dnshizli.core.Fill
import app.dnshizli.core.GPath
import app.dnshizli.core.Gfx
import app.dnshizli.core.PathSink
import java.awt.AlphaComposite
import java.awt.BasicStroke
import java.awt.Color
import java.awt.Font
import java.awt.Graphics2D
import java.awt.LinearGradientPaint
import java.awt.Paint
import java.awt.RadialGradientPaint
import java.awt.RenderingHints
import java.awt.Shape
import java.awt.font.FontRenderContext
import java.awt.geom.AffineTransform
import java.awt.geom.Ellipse2D
import java.awt.geom.Line2D
import java.awt.geom.Path2D
import java.awt.geom.Point2D
import java.awt.geom.Rectangle2D
import java.awt.geom.RoundRectangle2D
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO

/**
 * [Gfx]'in JVM (Java2D) uygulaması. Yalnızca test ve önizleme görseli üretmek içindir; uygulamanın parçası değildir.
 * Android'deki Canvas bağdaştırıcısıyla aynı sözleşmeyi izler.
 */
class AwtGfx(private val g2: Graphics2D) : Gfx {
    private class State(val tr: AffineTransform, val clip: Shape?, val alpha: Float)

    private val stack = ArrayList<State>()
    private var alphaMul = 1f
    private var color = 0
    private var fill: Fill? = null
    private var sw = 1f

    init {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON)
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE)
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON)
        g2.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON)
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY)
    }

    override fun save() { stack.add(State(g2.transform, g2.clip, alphaMul)) }

    override fun restore() {
        val s = stack.removeAt(stack.size - 1)
        g2.transform = s.tr
        g2.clip = s.clip
        alphaMul = s.alpha
    }

    override fun translate(dx: Float, dy: Float) = g2.translate(dx.toDouble(), dy.toDouble())
    override fun scale(sx: Float, sy: Float) = g2.scale(sx.toDouble(), sy.toDouble())
    override fun rotate(deg: Float) = g2.rotate(Math.toRadians(deg.toDouble()))
    override fun alpha(a: Float) { alphaMul *= a.coerceIn(0f, 1f) }

    override fun image(p: app.dnshizli.core.Pic, sl: Float, st: Float, sr: Float, sb: Float, dl: Float, dt: Float, dr: Float, db: Float) {
        val img = p.handle as? java.awt.image.BufferedImage ?: return
        val old = g2.composite
        g2.composite = AlphaComposite.SrcOver.derive(alphaMul.coerceIn(0f, 1f))
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC)
        g2.drawImage(img, Math.round(dl), Math.round(dt), Math.round(dr), Math.round(db),
            Math.round(sl), Math.round(st), Math.round(sr), Math.round(sb), null)
        g2.composite = old
    }

    override fun clipRect(l: Float, t: Float, r: Float, b: Float) {
        g2.clip(Rectangle2D.Float(l, t, r - l, b - t))
    }

    override fun clipRoundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) {
        g2.clip(RoundRectangle2D.Float(l, t, r - l, b - t, rad * 2, rad * 2))
    }

    override fun clipCircle(cx: Float, cy: Float, r: Float) {
        g2.clip(Ellipse2D.Float(cx - r, cy - r, r * 2, r * 2))
    }

    override fun clipPath(p: GPath) { if (!p.isEmpty) g2.clip(toPath(p)) }

    override fun paint(color: Int) { this.color = color; this.fill = null }
    override fun paint(fill: Fill) { this.fill = fill }
    override fun strokeWidth(w: Float) { sw = w }

    private fun awtPaint(f: Fill): Paint {
        (f.native as? Paint)?.let { return it }
        fun cols(c: IntArray) = Array(c.size) { Color(c[it], true) }
        fun stops(s: FloatArray): FloatArray {
            val o = s.copyOf()
            for (i in 1 until o.size) if (o[i] <= o[i - 1]) o[i] = o[i - 1] + 1e-4f
            return o
        }
        val p: Paint = when (f) {
            is Fill.Linear ->
                if (f.x0 == f.x1 && f.y0 == f.y1) Color(f.colors[0], true)
                else LinearGradientPaint(Point2D.Float(f.x0, f.y0), Point2D.Float(f.x1, f.y1), stops(f.stops), cols(f.colors))
            is Fill.Radial ->
                if (f.r <= 0f) Color(f.colors[0], true)
                else RadialGradientPaint(Point2D.Float(f.cx, f.cy), f.r, stops(f.stops), cols(f.colors))
        }
        f.native = p
        return p
    }

    private fun prepare(stroke: Boolean) {
        val f = fill
        g2.paint = if (f != null) awtPaint(f) else Color(color, true)
        g2.composite = AlphaComposite.SrcOver.derive(alphaMul.coerceIn(0f, 1f))
        if (stroke) g2.stroke = BasicStroke(maxOf(sw, 0.001f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND)
    }

    private fun fillShape(s: Shape) { prepare(false); g2.fill(s) }
    private fun strokeShape(s: Shape) { prepare(true); g2.draw(s) }

    override fun rect(l: Float, t: Float, r: Float, b: Float) = fillShape(Rectangle2D.Float(l, t, r - l, b - t))
    override fun roundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) =
        fillShape(RoundRectangle2D.Float(l, t, r - l, b - t, rad * 2, rad * 2))
    override fun circle(cx: Float, cy: Float, r: Float) = fillShape(Ellipse2D.Float(cx - r, cy - r, r * 2, r * 2))
    override fun oval(l: Float, t: Float, r: Float, b: Float) = fillShape(Ellipse2D.Float(l, t, r - l, b - t))
    override fun path(p: GPath) = fillShape(toPath(p))

    override fun strokeRoundRect(l: Float, t: Float, r: Float, b: Float, rad: Float) =
        strokeShape(RoundRectangle2D.Float(l, t, r - l, b - t, rad * 2, rad * 2))
    override fun strokeCircle(cx: Float, cy: Float, r: Float) = strokeShape(Ellipse2D.Float(cx - r, cy - r, r * 2, r * 2))
    override fun strokePath(p: GPath) = strokeShape(toPath(p))
    override fun line(x0: Float, y0: Float, x1: Float, y1: Float) = strokeShape(Line2D.Float(x0, y0, x1, y1))

    private fun toPath(p: GPath): Path2D.Float {
        val cached = p.native as? Path2D.Float
        if (cached != null && p.nativeVersion == p.version) return cached
        val out = cached ?: Path2D.Float(Path2D.WIND_NON_ZERO)
        out.reset()
        p.visit(object : PathSink {
            override fun move(x: Float, y: Float) = out.moveTo(x.toDouble(), y.toDouble())
            override fun line(x: Float, y: Float) = out.lineTo(x.toDouble(), y.toDouble())
            override fun quad(cx: Float, cy: Float, x: Float, y: Float) =
                out.quadTo(cx.toDouble(), cy.toDouble(), x.toDouble(), y.toDouble())
            override fun cubic(c1x: Float, c1y: Float, c2x: Float, c2y: Float, x: Float, y: Float) =
                out.curveTo(c1x.toDouble(), c1y.toDouble(), c2x.toDouble(), c2y.toDouble(), x.toDouble(), y.toDouble())
            override fun close() = out.closePath()
        })
        p.native = out
        p.nativeVersion = p.version
        return out
    }

    override fun text(s: String, x: Float, baseline: Float, size: Float, bold: Boolean, align: Int) {
        if (s.isEmpty()) return
        val f = font(size, bold)
        val w = f.getStringBounds(s, FRC).width.toFloat()
        val px = when (align) { 1 -> x - w / 2f; 2 -> x - w; else -> x }
        prepare(false)
        g2.font = f
        g2.drawString(s, px, baseline)
    }

    override fun textWidth(s: String, size: Float, bold: Boolean): Float =
        font(size, bold).getStringBounds(s, FRC).width.toFloat()

    companion object {
        private val FRC = FontRenderContext(null, true, true)
        private val regular = Font("Inter", Font.PLAIN, 1)
        private val bolder = Font("Inter", Font.BOLD, 1)
        private val cache = HashMap<Long, Font>()

        private fun font(size: Float, bold: Boolean): Font {
            val k = (size * 10).toLong() * 2 + (if (bold) 1 else 0)
            return cache.getOrPut(k) { (if (bold) bolder else regular).deriveFont(size) }
        }

        /** Hangi yazı tipinin gerçekten kullanıldığını bildirir (önizlemenin dürüst olması için). */
        fun fontName(): String = regular.deriveFont(12f).fontName
    }
}

/** Önizleme tuvali: [w] x [h] dp, [scale] kat büyütülmüş piksel görüntü. */
class AwtCanvas(val w: Int, val h: Int, val scale: Float = 2f) {
    val image = BufferedImage((w * scale).toInt(), (h * scale).toInt(), BufferedImage.TYPE_INT_ARGB)
    val g2: Graphics2D = image.createGraphics().also { it.scale(scale.toDouble(), scale.toDouble()) }
    val gfx = AwtGfx(g2)

    fun savePng(path: String) {
        File(path).parentFile?.mkdirs()
        ImageIO.write(image, "png", File(path))
    }

    fun dispose() = g2.dispose()
}
