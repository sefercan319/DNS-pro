# DNS Hızlı — Gizlilik Politikası

> **Bu bir şablondur.** Köşeli parantezli yerleri kendi bilgilerinle doldur, herkese açık bir adrese koy (GitHub Pages, kendi siten…)
> ve bu adresi Play Console'daki "Gizlilik politikası" alanına gir. Hukuki tavsiye değildir; gerekirse bir uzmana danış.
> Uygulama bir şeyi değiştirirse (ör. analitik eklenirse) bu metni de güncelle.

**Son güncelleme:** [GG.AA.YYYY]
**Geliştirici:** [Adın ya da şirket adın] · **İletişim:** [e-posta adresin]

## Kısaca

- Hesap açmazsın, kişisel bilgi vermezsin.
- Uygulama kişisel veri **toplamaz, saklamaz, satmaz, paylaşmaz**. Reklam ve analitik içermez.
- Girdiğin sitelerin adlarını (DNS sorgularını) **kaydetmez**. Bu sorgular, **senin seçtiğin DNS sağlayıcısına** gönderilir (aşağıya bak).

## Uygulama ne yapar?

DNS Hızlı, telefonundaki DNS sorgularını (bir site adının numarasını sormayı) sen seçtiğin herkese açık bir DNS sunucusuna
(ör. Cloudflare, Google, Quad9, AdGuard) yönlendirir. Bunu yapmak için Android'in VPN arayüzünü (`VpnService`) **yerel olarak** kullanır.
Bu bir VPN hizmeti değildir: trafiğin bir VPN sunucusuna gönderilmez; yalnızca DNS sorguları seçtiğin sunucuya iletilir, diğer tüm
trafik normal yolundan devam eder.

**İstisna: iki isteğe bağlı modül ("DPI atlatma" ve "Reklam+", varsayılan kapalı).** Bunlardan birini açarsan telefonun tüm internet
trafiği, yine yalnızca **cihazın içinde** çalışan bir aktarıcıdan (uygulamanın kendi kodu) geçer ve oradan, hiçbir aracıya uğramadan,
gideceği yere ulaştırılır. Trafik bize, bir VPN sunucusuna ya da herhangi bir üçüncü tarafa gönderilmez. Aktarıcı içerik okumaz: yalnızca
bağlantının ilk paketindeki site adını (TLS "SNI" ya da HTTP "Host" satırı) **bellekte** bakıp engelleme listesiyle karşılaştırır (Reklam+)
ya da ilk paketi parçalara bölerek gönderir (DPI atlatma); bu adlar kaydedilmez, saklanmaz, sayılmaz. Şifreli (HTTPS) içeriği çözmez,
sertifika değiştirmez. Modüller açıkken QUIC (UDP/443) varsayılan olarak engellenir (ayardan kapatılır): uygulamalar TCP'ye döner. "Reklam+" ve DNS birlikte açıksa DNS'i atlatan şifreli DNS (bağlantı noktası 853 ve bilinen DoH sağlayıcı adları) da kapatılır.

## Hangi veriye erişir, ne yapar?

| Veri | Ne olur |
|------|---------|
| DNS sorguları (girdiğin sitelerin adları) | VPN arayüzü üzerinden alınır ve seçtiğin DNS sağlayıcısına iletilir. Varsayılan olarak **şifreli** gider (DNS-over-TLS ya da DNS-over-HTTPS); ayarlardan şifrelemeyi kapatırsan ya da şifreli bağlantı kurulamazsa **şifresiz (düz DNS, UDP/53)** gider ve uygulama bunu gösterir. Uygulama sorguları **kaydetmez**, kendi sunucusuna **göndermez**, kimseyle paylaşmaz. |
| Sağlayıcının sunucu adı | Şifreli bağlantı kurmak için sağlayıcının kendi sunucu adı (ör. `dns.quad9.net`) bir kez o sağlayıcının düz DNS'ine sorulur. Bu sorgu senin gezdiğin siteler hakkında bilgi içermez. |
| Ölçüm geçmişi, günlük sorgu sayıları (son 7 gün), son kullanılan ve gizlenen sunucular | Yalnızca cihazında saklanır. Site adı içermez. |
| Eklediğin özel DNS sunucuları | Yalnızca cihazında, uygulamanın kendi ayar deposunda tutulur; dışa aktarılan koda girmez, hiçbir yere gönderilmez. |
| Uygulama listesi ("Hangi uygulamalar") | Yalnızca sen o sayfayı açınca, telefondaki başlatıcıda görünen uygulamaların adı ve paket adı **cihazda** okunur (Android'in `queries` bildirimi; geniş paket izni yok). Seçtiğin paket adları cihazda kalır, dışa aktarılmaz, hiçbir yere gönderilmez. |
| Arka plan fotoğrafı | Yalnızca sen "Arka plan fotoğrafı"nı seçersen, seçtiğin tek fotoğraf Android'in sistem seçicisiyle (depolama izni istenmez) alınır, küçültülüp uygulamanın özel alanına kaydedilir. Cihazdan çıkmaz, dışa aktarılmaz, yedeğe girmez; Ayarlar'dan kaldırınca silinir. |
| Geçmişi tut ayarı | Varsayılan olarak açıktır. Kapatırsan son kullanılanlar, bağlantı geçmişi, ölçüm grafiği ve sunucu kullanım süreleri yazılmaz; var olanlar silinmez ("Geçmişi sil" ile silersin). "Son engellenenler" listesi de tutulmaz; yalnızca engellenen sorgu sayısı artar. |
| Kendi engelleme listem | Yalnızca sen içe aktarırsan: yapıştırdığın ya da seçtiğin dosyadaki alan adları uygulamanın özel klasöründe (`my-blocklist.txt`) cihazda saklanır. Dışa aktarılan ayar koduna ve yedeğe girmez, hiçbir yere gönderilmez; "Listeyi temizle" ile silinir. Panoya dışa aktarırsan Android pano geçmişi bu metni görebilir. Dosya seçici depolama izni istemez. |
| Gecikme grafiği | Son cevap sürelerinin (milisaniye) kısa listesi yalnızca bellekte tutulur; site adı içermez, diske yazılmaz, uygulama kapanınca silinir. |
| Kapalı kalırsa dur | Açarsan bağlantı koptuğunda tünel açık kalır ve DNS soruları hata ile cevaplanır (soru hiçbir yere iletilmez). Ek veri toplanmaz. |
| Kendini onarma | Bağlıyken uygulama dakikada bir yalnızca kendi sayaçlarına (kaç sorgu cevaplandı, kaçı zaman aşımına uğradı) bakar; ağa ek sorgu göndermez, site adı okumaz ya da saklamaz. Cevap gelmiyorsa bağlantıyı kendisi yeniler, yedek sunucuya geçer ya da tüneli yeniden kurar; bunlar cihazda olur ve hiçbir yere bildirilmez. |
| Sorun giderici | "Sorun gider" dendiğinde yalnızca telefondaki bağlantı durumu (internet var mı, başka VPN var mı, Özel DNS ayarı, VPN izni) cihazda okunur ve ekranda gösterilir; hiçbir yere gönderilmez. |
| Ölçüm sonuçlarını paylaş | Yalnızca sen "paylaş" dersen hazır sunucuların ölçüm süreleri metin olarak paylaşım penceresine verilir; kendi eklediğin sunucular dahil edilmez. |
| Ayarları dışa aktarma | Yalnızca **sen** "Dışa aktar" dersen ayarların kısa bir metin olarak panoya kopyalanır; nereye yapıştıracağın senin kararındır. Site adı içermez. |
| Ana ekran widget'ı | Yalnızca bağlantı durumu, sunucu adı ve protokolü gösterir. |
| Ayarların (tema, favoriler, son sunucu, anahtarlar) | Yalnızca cihazında, uygulamanın özel alanında saklanır. Cihazdan çıkmaz. |
| Toplam sayaçlar (sorgu sayısı, önbellek isabeti, bağlı kalma süresi) | Yalnızca cihazında, sayı olarak saklanır; hangi siteye ait olduğu tutulmaz. |
| Bağlantı geçmişi, sunucu kullanım süreleri, veri trafiği | Son 30 bağlantı oturumunun sunucusu, yöntemi, süresi, sorgu sayısı ve bitiş nedeni; sunucu başına süre; gönderilen/alınan toplam bayt. Yalnızca cihazında saklanır; site adı içermez; Ayarlar'dan silinebilir. |
| Reklam/izleyici engelleme | Engelleme listeleri uygulamayla gelir ve tamamen cihazda çalışır; hiçbir şey indirilmez ya da gönderilmez. Seçtiğin seviye, izin listen ve kendi engel listen yalnızca cihazında saklanır. "Son engellenenler" yalnızca bellekte, bu oturum için tutulur; diske yazılmaz, günlüğe ve dışa aktarmaya girmez, bağlantı kesilince silinir. Sayaç yalnızca bir sayıdır. |
| DPI atlatma ve Reklam+ (isteğe bağlı) | Açıkken tüm trafik cihaz içindeki aktarıcıdan geçer (yukarıya bak). Hedef adresler ve site adları yalnızca o bağlantı sürerken bellekte durur; diske yazılmaz, günlüğe girmez, hiçbir yere gönderilmez. Saklanan tek şey, son kullanılan bölme yönteminin hedef başına kısa belleğidir ve yalnızca bellekte, uygulama kapanınca silinir. İki modülün açık/kapalı durumu cihazda, ayar deposunda tutulur; dışa aktarılan koda girmez. Sayaçlar ("kaç bağlantı engellendi") yalnızca sayıdır. |
| Bağlantı testi | "Bağlantıyı test et" dendiğinde rastgele bir ad, bilerek DNSSEC'i bozuk bir test adı ve bilinen bir reklam adı seçtiğin DNS sağlayıcısına sorulur (kişisel veri içermez). Sonuç yalnızca ekranda gösterilir. |
| Son çökme notu | Uygulama beklenmedik biçimde kapanırsa hata türünün kısa özeti cihazında tutulur ve yalnızca sen "tanılama raporunu paylaş" dersen rapora girer. |
| Yedekleme | Android yedeklemesi ve cihazdan cihaza aktarım **kapalıdır**: ayarların bulut yedeğine girmez. |
| Tanılama günlüğü | Yalnızca bağlantı olayları ("bağlandı", "yedek sunucuya geçildi"…) ve yalnızca bellekte tutulur; uygulama kapanınca silinir. Site adı ve kişisel veri içermez. Onu **sen** paylaşmayı seçmedikçe hiçbir yere gitmez. |

## Üçüncü taraflar: DNS sağlayıcıları

Seçtiğin DNS sağlayıcısı (Cloudflare, Google, Quad9, AdGuard, Control D, OpenDNS, DNS.SB, DNS4EU, UncensoredDNS,
CleanBrowsing, NextDNS ve listedeki diğerleri) sorgularını görür ve **kendi gizlilik politikasına** göre işler. Bu politikalar bizim denetimimizde değildir;
tercih etmeden önce ilgili sağlayıcının internet sitesindeki politikayı okumanı öneririz. Şifreleme açıkken ağdaki üçüncü kişiler
(ör. Wi-Fi sahibi, internet operatörü) sorguların içeriğini göremez, ancak hangi DNS sağlayıcısına bağlandığını görebilir.
Şifreleme kapalıyken bu kişiler sorguları da görebilir.

### Sorguların gizliliği için alınan önlemler ve dürüst sınırlar

Alınan önlemler (şifreli DNS, yani DoT/DoH açıkken; çoğu düz DNS'te de geçerlidir):

- **Ağdakiler okuyamaz, değiştiremez:** sorgular TLS 1.2/1.3 ile şifrelenir; sunucu sertifikası adıyla doğrulanır. Sertifika reddedilirse
  bu, aradaki birinin (ağ, güvenlik yazılımı) bağlantıya karıştığının belirtisi olabilir; uygulama bunu söyler ve bu bağlantıya güvenmez.
- **Cihazını ele verebilecek ek veriler atılır:** sunucuya gitmeden önce sorgudaki tüm EDNS seçenekleri (istemci alt ağı / ECS, çerez,
  sağlayıcıya özgü cihaz ya da hesap kimlikleri) silinir ve "alt ağımı iletme" işareti konur; sunucu adresini yetkili sunuculara aktarmaz.
- **Uzunluktan alan adı tahmini zorlaştırılır:** şifreli sorgular 128 baytın katına doldurulur (RFC 8467).
- **Bağlantılar arasında izlenmezsin:** TLS oturum biletleri Wi-Fi ↔ mobil geçişinde atılır; DoH isteğinde uygulamayı belli eden başlık
  yoktur (genel bir User-Agent kullanılır); DNS sorguları rastgele kaynak portlarından gider.
- **Gizli şifresiz sorgu yok:** "Sıkı şifreleme" açıkken ve şifreli-yalnızca kiplerde şifresiz hiçbir sorgu (ilk çözümleme dahil) gönderilmez.
  "Otomatik" kipte şifreli bağlantı kurulamazsa (ör. ağ 853/443 portlarını engelliyorsa) şifresiz DNS'e düşülür ve bu sana bildirilir; bunu
  istemiyorsan "Sıkı şifreleme"yi aç.

Yapılamayanlar (dürüst olalım):

- **DNS sağlayıcısı herkese açık IP adresini görür.** Sana cevap verebilmesi için gerekir; araya bir röle (ODoH, Tor, başka bir VPN) koymadığımız
  için bunu gizleyemeyiz. IP adresinden yaklaşık konum ve internet operatörün anlaşılabilir. Sağlayıcıyı seçerken kendi politikasına bak.
- **Operatör, bağlandığın sunucunun IP adresini görür** (şifreli de olsa): hangi DNS sağlayıcısını kullandığın saklanamaz; sorguların içeriği saklanır.
- Uygulama yalnızca DNS'i yönlendirir; diğer trafiğin (siteler, uygulamalar) şifrelenmesi ya da IP'nin gizlenmesi için ayrıca bir VPN gerekir.
- IPv4 ve IPv6 birlikte kullanılır; IPv6'da cihazının geçici adresi sunucuya görünür (Android adresi düzenli değiştirir).

## İzinler ve nedenleri

- **VPN (Android'in VPN izni / `BIND_VPN_SERVICE`)**: DNS sorgularını yönlendirmek için yerel arayüzü kurar; "DPI atlatma" ya da "Reklam+" açıksa aynı yerel arayüz tüm trafiği cihaz içindeki aktarıcıya alır. Sen onay vermeden açılmaz. Yeni bir izin gerekmez.
- **İnternet, ağ durumu**: DNS sunucularına ulaşmak, hız ölçmek ve Wi-Fi ↔ mobil veri geçişini fark etmek için.
- **Önplan hizmeti**: bağlantı açıkken Android'in zorunlu tuttuğu bildirimi göstermek için.
- **Açılışta başlatma (`RECEIVE_BOOT_COMPLETED`)**: yalnızca "Telefon açılınca bağlan" ayarını açarsan kullanılır.
- **Bildirimler (Android 13+)**: bağlantı bildirimi ile "bağlandı", "bağlantı koptu", "zaman aşımı" ve (açarsan) "durduruldu" uyarıları için; uygulama ilk açılışta bir kez sorar. Vermezsen uygulama yine çalışır.

Uygulama konum, kişi, mikrofon, kamera, depolama gibi hiçbir kişisel veri iznine ihtiyaç duymaz.

## Çocuklar

Uygulama çocuklara yönelik değildir ve bilerek hiçbir kişiden veri toplamaz.

## Verilerini silmek

Uygulamanın cihazındaki tüm verisi (ayarlar, sayaçlar) uygulamayı kaldırdığında silinir. Geliştirici tarafında saklanan bir verin yoktur.

## Değişiklikler

Bu politika değişirse bu sayfada yeni tarihle yayınlanır.

## İletişim

Sorular için: [e-posta adresin]

**Ses efektleri (v1.11.0):** sesler telefonda kodla üretilir; mikrofon, kayıt, ek izin ya da ağ erişimi gerekmez. Titreşim de sistemin kendi dokunsal geri bildirimidir (VIBRATE izni yok).
