package app.dnshizli.core

import java.io.IOException

/**
 * HTTP/1.1 cevap çerçevelemesinin sıkı kuralları (RFC 9112). DoH/ODoH şeritleri ([SecureForwarder]) ve yapılandırma alımı
 * ([MiniHttps]) aynı kuralları kullanır: iki ayrıştırıcı birbirinden farklı yorumlamasın.
 *
 * Neden sıkı: aynı bağlantı üzerinde ardışık cevaplar okunur (keep-alive). Gevşek bir ayrıştırıcı ile sunucu (ya da araya giren
 * bozuk bir ara katman) çerçevenin nerede bittiği konusunda anlaşamazsa bir cevabın artığı sonraki sorunun cevabı sanılabilir
 * ("cevap kaydırma", HTTP smuggling'in istemci tarafı). Soru denetimi bunu yakalardı; burada daha baştan reddedilir.
 *
 * Kurallar:
 *  - Durum satırı: `HTTP/1.x SP 3RAKAM [SP sebep]`.
 *  - Başlık adı yalnızca "token" karakterlerinden oluşur; ad ile ":" arasında boşluk yasak (RFC 9112 §5.1).
 *  - Satır başında boşlukla devam eden eski katlanmış başlık (obs-fold) reddedilir (RFC 9112 §5.2).
 *  - Transfer-Encoding yalnızca tam olarak "chunked" olabilir; başka bir kodlama (gzip vb.) çözülemeyeceği için hata.
 *  - Parça verisinden sonra boş satır (CRLF) gelmelidir.
 *  - 100/102/103 ara cevapları atlanır (en çok [MAX_INTERIM]); 101 (protokol değişimi) hatadır.
 */
object HttpRules {
    /** Bir istekte atlanabilecek en fazla ara (1xx) cevap. */
    const val MAX_INTERIM = 4

    /** Durum satırından kod; biçim bozuksa [IOException]. */
    fun statusCode(line: String): Int {
        // "HTTP/1.1 200" en kısa geçerli biçimdir (sebep metni isteğe bağlı).
        if (line.length < 12 || !line.startsWith("HTTP/1.") || line[8] != ' ') throw IOException("bozuk durum satırı")
        if (line[7] != '0' && line[7] != '1') throw IOException("bozuk durum satırı")
        val c0 = line[9]; val c1 = line[10]; val c2 = line[11]
        if (c0 !in '1'..'5' || c1 !in '0'..'9' || c2 !in '0'..'9') throw IOException("bozuk durum kodu")
        if (line.length > 12 && line[12] != ' ') throw IOException("bozuk durum satırı")
        return (c0 - '0') * 100 + (c1 - '0') * 10 + (c2 - '0')
    }

    /** Sunucu "meşgul / hız sınırı" diyor mu (429 Too Many Requests, 503 Service Unavailable)? */
    fun isBusy(code: Int): Boolean = code == 429 || code == 503

    /**
     * Retry-After değeri (RFC 9110 §10.2.3): saniye ise o değer, [0, [MAX_RETRY_AFTER_S]] aralığına kırpılır. Tarih biçimi ya da bozuk
     * değer: null (çağıran varsayılanı kullanır). Kötü niyetli sunucu "1 yıl bekle" diyerek sunucuyu kalıcı devre dışı bıraktıramaz.
     */
    fun retryAfter(value: String?): Int? {
        val v = value?.trim() ?: return null
        if (v.isEmpty() || v.length > 9 || !v.all { it in '0'..'9' }) return null
        return v.toInt().coerceAtMost(MAX_RETRY_AFTER_S)
    }
    const val MAX_RETRY_AFTER_S = 300

    /**
     * Cache-Control'den taze kalma süresi (saniye): "max-age=N". "no-store"/"no-cache" → 0. Yoksa ya da bozuksa null. s-maxage
     * (paylaşılan önbellekler için) dikkate alınmaz.
     */
    fun maxAge(value: String?): Int? {
        val v = value?.lowercase() ?: return null
        var out: Int? = null
        for (raw in v.split(',')) {
            val d = raw.trim()
            if (d == "no-store" || d == "no-cache") return 0
            if (d.startsWith("max-age=")) {
                val n = d.removePrefix("max-age=").trim().trim('"')
                if (n.isNotEmpty() && n.length <= 9 && n.all { it in '0'..'9' }) out = n.toInt()
            }
        }
        return out
    }

    /** Atlanacak ara cevap mı? (101 değildir: protokol değişimi beklenmez, hata sayılır.) */
    fun isInterim(code: Int): Boolean = code == 100 || code == 102 || code == 103

    /** Başlık satırını (CRLF hariç) ad/değer olarak döner; ad küçük harfe çevrilir. Kurala aykırıysa [IOException]. */
    fun header(line: String): Pair<String, String> {
        if (line.isEmpty()) throw IOException("boş başlık")
        if (line[0] == ' ' || line[0] == '\t') throw IOException("katlanmış başlık (obs-fold)")
        val colon = line.indexOf(':')
        if (colon <= 0) throw IOException("bozuk başlık")
        for (i in 0 until colon) if (!isToken(line[i])) throw IOException("bozuk başlık adı")
        val value = line.substring(colon + 1).trim(' ', '\t')
        for (ch in value) if ((ch.code < 0x20 && ch != '\t') || ch.code == 0x7F) throw IOException("başlık değerinde denetim karakteri")
        return line.substring(0, colon).lowercase() to value
    }

    /**
     * Transfer-Encoding değeri: tam olarak "chunked" ise true. "identity" eski bir eşanlamlıdır, false (uzunluk belirler).
     * Başka her şey (gzip, "gzip, chunked", boş) çözülemez: [IOException].
     */
    fun chunked(value: String): Boolean {
        val v = value.trim().lowercase()
        if (v == "chunked") return true
        if (v == "identity") return false
        throw IOException("desteklenmeyen aktarım kodlaması")
    }

    /** İçerik uzunluğu: yalnızca rakamlar, en çok 9 basamak. Aynı değerin virgülle tekrarı ("12, 12") bile reddedilir. */
    fun contentLength(value: String): Int {
        if (value.isEmpty() || value.length > 9 || !value.all { it in '0'..'9' }) throw IOException("bozuk içerik uzunluğu")
        return value.toInt()
    }

    /** Parça boyu satırı: onaltılık, en çok 6 basamak; uzantılar (";…") yok sayılır. */
    fun chunkSize(line: String): Int {
        val hex = line.substringBefore(';').trim(' ', '\t')
        if (hex.isEmpty() || hex.length > 6 || !hex.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) throw IOException("bozuk parça")
        return hex.toInt(16)
    }

    /** Parça verisinin ardından gelen satır boş olmalıdır. */
    fun chunkEnd(line: String?) {
        if (line == null) throw IOException("parça sonu kesildi")
        if (line.isNotEmpty()) throw IOException("parça sonu bozuk")
    }

    private fun isToken(c: Char): Boolean =
        c in 'a'..'z' || c in 'A'..'Z' || c in '0'..'9' || c in "!#$%&'*+-.^_`|~"
}
