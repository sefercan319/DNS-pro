package app.dnshizli.core

import java.io.IOException
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Tünel dışında tutulan (VpnService.protect) soketler. Servisten çıkarıldı: koruma işlevleri dışarıdan verilir, böylece JVM'de
 * "koruma başarısız" durumu test edilebilir. Korunamayan soket HİÇBİR zaman bağlanmaz/kullanılmaz (tünele girer: öz-döngü, sızıntı).
 */
class ProtectedSockets(
    private val protectTcp: (Socket) -> Boolean,
    private val protectUdp: (DatagramSocket) -> Boolean,
    private val log: (String) -> Unit = {},
) {
    /** Hedefe bağlanmış, tünel dışı UDP yuvası (QUIC). Korunamazsa [IOException]. */
    fun udp(addr: InetSocketAddress): DatagramSocket {
        val s = DatagramSocket()
        try {
            if (!guard { protectUdp(s) }) throw IOException("UDP soketi korunamadı")
            s.connect(addr)
            return s
        } catch (e: IOException) {
            try { s.close() } catch (_: Exception) {}
            throw e
        } catch (e: RuntimeException) {
            try { s.close() } catch (_: Exception) {}
            throw IOException(e)
        }
    }

    /**
     * Tünel dışı TCP soketi. Bağlanmamış bir Socket'in dosya tanıtıcısı yoktur: önce yerel adrese bağlanır (bind), sonra korunur, sonra hedefe
     * bağlanır. Koruma başarısızsa bağlanılmaz ([IOException]); yönlendirici sonraki yöntemi dener.
     */
    fun tcp(addr: InetSocketAddress, timeout: Int): Socket {
        val s = Socket()
        try {
            try { s.bind(null) } catch (_: IOException) {}
            if (!guard { protectTcp(s) }) { log("TLS soketi korunamadı: bağlanılmadı"); throw IOException("TLS soketi korunamadı") }
            s.connect(addr, timeout)
            return s
        } catch (e: IOException) {
            try { s.close() } catch (_: Exception) {}
            throw e
        } catch (e: RuntimeException) {
            try { s.close() } catch (_: Exception) {}
            throw IOException(e)
        }
    }

    /** Bootstrap A sorusu için korunmuş, bağlanmamış UDP yuvası; korunamazsa kapatılıp [IOException]. */
    fun bootstrapUdp(): DatagramSocket {
        val s = DatagramSocket()
        if (!guard { protectUdp(s) }) { s.close(); throw IOException("bootstrap soketi korunamadı") }
        return s
    }

    private inline fun guard(f: () -> Boolean): Boolean = try { f() } catch (_: Exception) { false }

    companion object {
        /** Yazılı IP adresinden [InetAddress]; ad çözümlemesi yapmaz. */
        fun addr(ip: String): InetAddress = InetAddress.getByAddress(Ip.parse(ip) ?: throw IllegalArgumentException("geçersiz adres"))
    }
}
