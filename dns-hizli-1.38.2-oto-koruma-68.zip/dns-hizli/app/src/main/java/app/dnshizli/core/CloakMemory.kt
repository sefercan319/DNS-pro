package app.dnshizli.core

/**
 * Gizli izleyici belleği: CNAME zinciri engelli bir ada çıktığı için engellenen sitenin kendi alt adı ("metrik.site.com") burada
 * hatırlanır ([TTL_MS] boyunca, en çok [CAP] ad). Sonraki sorgular üst sunucuya gitmeden yerelde engellenir ve, daha önemlisi, AĞ
 * GEÇİDİ bu adı SNI/Host'ta da tanır: uygulama kendi şifreli DNS'iyle ya da önbellekteki adresle bağlansa bile gizli izleyici geçmez
 * (SNI'de yalnızca birinci taraf ad görünür, CNAME hedefi görünmez). Kullanıcı izin listesi her zaman önce gelir.
 *
 * Okuma yolu ayırma yapmaz ve kilitsizdir: sıralı özet dizisinin değişmez bir kopyası üzerinde ikili arama. Yazma seyrektir.
 */
object CloakMemory {
    const val CAP = 2048
    const val TTL_MS = 6 * 3600_000L

    private class Snap(val keys: LongArray, val until: LongArray)
    @Volatile private var snap = Snap(LongArray(0), LongArray(0))
    @Volatile var now: () -> Long = { System.currentTimeMillis() }
    private val map = LinkedHashMap<Long, Long>()

    val size: Int get() = snap.keys.size

    /** Adın özeti (FilterHash, küçük harf, noktalı ad) gizli izleyici olarak hatırlanır. */
    @Synchronized fun remember(hash: Long) {
        val t = now()
        map.remove(hash)
        map[hash] = t + TTL_MS
        val it = map.entries.iterator()
        while (it.hasNext()) { val e = it.next(); if (e.value <= t) it.remove() }
        while (map.size > CAP) { val f = map.keys.first(); map.remove(f) }
        val keys = map.keys.toLongArray()
        val idx = keys.indices.sortedBy { keys[it] }
        snap = Snap(LongArray(idx.size) { keys[idx[it]] }, LongArray(idx.size) { map.getValue(keys[idx[it]]) })
    }

    fun remember(name: String) {
        val n = FilterNames.lenient(name) ?: return
        remember(FilterHash.hash(n))
    }

    /** Ayırmasız: özet bellekte ve süresi dolmamış mı? */
    fun contains(hash: Long): Boolean {
        val s = snap
        if (s.keys.isEmpty()) return false
        val i = java.util.Arrays.binarySearch(s.keys, hash)
        return i >= 0 && s.until[i] > now()
    }

    @Synchronized fun clear() { map.clear(); snap = Snap(LongArray(0), LongArray(0)) }
}
