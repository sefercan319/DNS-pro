package app.dnshizli.core

/**
 * Kullanıcının joker kuralları: "ads*.ornek.com", "*-reklam-*.cdn.ornek.net", "izleme.*.ornek.com". Düz adlarla aynı anlam: kural ve
 * eşleştiği adın tüm alt alan adları ("x.ads7.ornek.com") yakalanır. '*' tek bir etiket İÇİNDE herhangi bir dizi karakteri karşılar,
 * noktayı aşmaz. Aşırı geniş kurallar kabul edilmez: son iki etiket jokersiz olmalı ve ortak son ek ("co.uk", "com.tr") olmamalı
 * ("ads*.com", "*.co.uk", "reklam.*" reddedilir). Eşleştirme ayırma yapmaz ve doğrusal zamanlıdır (düzenli ifade yok, ReDoS yok).
 */
class NamePatterns private constructor(private val pats: Array<Array<ByteArray>>) {
    val size: Int get() = pats.size

    /**
     * [name] tamponundaki ad (küçük harf, noktalı; [starts] etiket başları, [cnt] etiket sayısı) bir kurala ya da kuralın alt alanına
     * uyuyor mu?
     */
    fun matches(name: ByteArray, nameLen: Int, starts: IntArray, cnt: Int): Boolean {
        for (p in pats) {
            val l = p.size
            if (cnt < l) continue
            var ok = true
            for (j in 0 until l) {
                val k = cnt - l + j
                val st = starts[k]
                val en = if (k + 1 < cnt) starts[k + 1] - 1 else nameLen
                if (!glob(p[j], name, st, en)) { ok = false; break }
            }
            if (ok) return true
        }
        return false
    }

    /** Ad metni için (testler, arayüz). */
    fun matches(domain: String): Boolean {
        val b = domain.lowercase(java.util.Locale.ROOT).trimEnd('.').toByteArray(Charsets.ISO_8859_1)
        val st = IntArray(MAX_LABELS); var c = 0
        st[c++] = 0
        for (i in b.indices) if (b[i] == DOT && c < st.size) st[c++] = i + 1
        return matches(b, b.size, st, c)
    }

    companion object {
        /** En çok bu kadar joker kural (her sorguda hepsi denenir). */
        const val MAX = 64
        private const val MAX_LABELS = 128
        private const val STAR = '*'.code.toByte()
        private const val DOT = '.'.code.toByte()
        private val LABEL = Regex("^[a-z0-9_*-]{1,63}$")

        val EMPTY = NamePatterns(emptyArray())

        /**
         * Girdi geçerli bir joker kural mı? Geçerliyse temiz biçimi ("ads*.ornek.com"), değilse null. Jokersiz girdi için de null
         * (düz adlar [FilterNames.normalize] ile işlenir). Baştaki "*." alt alan anlamındadır ve atılır; ardından joker kalmalıdır.
         */
        fun normalize(input: String): String? {
            var s = input.trim().lowercase(java.util.Locale.ROOT)
            val scheme = s.indexOf("://")
            if (scheme in 1..10) s = s.substring(scheme + 3)
            s = s.substringBefore('/').substringBefore('?').substringBefore('#').substringBefore(':').trimEnd('.')
            while (s.startsWith("*.")) s = s.substring(2)
            while (s.contains("**")) s = s.replace("**", "*")
            if (s.isEmpty() || s.length > 253 || !s.contains('*')) return null
            val parts = s.split('.')
            if (parts.size < 3 || parts.any { !LABEL.matches(it) }) return null
            val tail = parts.takeLast(2)
            if (tail.any { it.contains('*') }) return null                 // "ads*.com", "reklam.*": bütün bir uzantıyı kapsar
            val reg = tail.joinToString(".")
            if (FilterNames.isPublicSuffix(reg)) return null                // "x*.co.uk": bütün bir ülke uzantısı
            if (parts.dropLast(2).all { it == "*" }) return null           // "*.*.ornek.com" düz kurala eşdeğer ama yanıltıcı: düz ad yazılmalı
            return s
        }

        /** Listeden joker kuralları derler (geçersizler ve jokersizler atlanır, en çok [MAX]). */
        fun of(list: Collection<String>): NamePatterns {
            val ps = list.mapNotNull { normalize(it) }.distinct().take(MAX)
            if (ps.isEmpty()) return EMPTY
            return NamePatterns(ps.map { p -> p.split('.').map { it.toByteArray(Charsets.ISO_8859_1) }.toTypedArray() }.toTypedArray())
        }

        /** [pat] (joker içerebilir) [b][from, to) etiketine tam uyar mı? Yıldız geri dönüşlü klasik eşleme: O(n·m) en kötü, ayırmasız. */
        internal fun glob(pat: ByteArray, b: ByteArray, from: Int, to: Int): Boolean {
            var p = 0; var i = from
            var starP = -1; var starI = 0
            while (i < to) {
                if (p < pat.size && pat[p] != STAR && pat[p] == b[i]) { p++; i++ }
                else if (p < pat.size && pat[p] == STAR) { starP = p++; starI = i }
                else if (starP >= 0) { p = starP + 1; i = ++starI }
                else return false
            }
            while (p < pat.size && pat[p] == STAR) p++
            return p == pat.size
        }
    }
}
