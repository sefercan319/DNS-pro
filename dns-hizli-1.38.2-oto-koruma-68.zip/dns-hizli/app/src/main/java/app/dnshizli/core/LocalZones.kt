package app.dnshizli.core

/**
 * İnternete hiç sorulmaması gereken adlar: cevabı yerelde "yok" (NXDOMAIN) olarak verilir.
 *  - Özel adres aralıklarının ters (PTR) bölgeleri (RFC 6303, 7793): "1.1.168.192.in-addr.arpa" gibi sorular genel çözümleyiciye giderse
 *    ev ağının adres planı dışarı sızar; cevap zaten her zaman "yok"tur. Yerelde anında verilir (gecikme ve sızıntı yok).
 *  - ".onion" (RFC 7686): Tor adı DNS'e gitmemeli (ziyaret edilen gizli servis sızar).
 *  - ".local" (RFC 6762): mDNS adı; tek noktaya (unicast) DNS'e gitmez, gitse de genel çözümleyici bilmez.
 *  - ".invalid" (RFC 6761): tanım gereği yok.
 * Üst sunucu yerel ağdaysa (ör. Pi-hole, modem) ters bölgeler ve .local o sunucuda anlamlı olabilir: [FilterRuntime.localZones] kapatılır.
 * Ayırma yapmaz: son etiket "arpa/local/onion/invalid" değilse hemen false döner (sorguların neredeyse tamamı).
 */
object LocalZones {
    private val V4 = listOf("10", "127", "0", "254.169", "168.192", "255.255.255.255") +
        (16..31).map { "$it.172" } + (64..127).map { "$it.100" }
    private val V4_ZONES: Set<String> = V4.map { "$it.in-addr.arpa" }.toSet()
    private val V6_ZONES: Set<String> = setOf(
        "1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa",   // ::1
        "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa",   // ::
        "d.f.ip6.arpa", "c.f.ip6.arpa",                                            // fc00::/7 (ULA)
        "8.e.f.ip6.arpa", "9.e.f.ip6.arpa", "a.e.f.ip6.arpa", "b.e.f.ip6.arpa",    // fe80::/10 (bağlantı-yerel)
        "8.b.d.0.1.0.0.2.ip6.arpa",                                                 // 2001:db8::/32 (belgeleme)
    )
    private val TLD = setOf("local", "onion", "invalid")

    /** [name] (küçük harf, sondaki nokta yok) yerelde "yok" denecek bir ad mı? */
    fun matches(name: String): Boolean {
        val n = name.lowercase(java.util.Locale.ROOT).trimEnd('.')
        val last = n.substringAfterLast('.')
        if (last in TLD) return true
        if (last != "arpa") return false
        if (n.endsWith(".in-addr.arpa")) return V4_ZONES.any { n == it || n.endsWith(".$it") }
        if (n.endsWith(".ip6.arpa")) return V6_ZONES.any { n == it || n.endsWith(".$it") }
        return false
    }

    /**
     * DNS sorgusunun ([b] içinde [off]'tan, [len] bayt; başlık dahil) tek sorusu yerel bir ad mı? Biçim bozuksa false (süzgeç ayrıca bakar).
     * Hızlı yol: son etiket önce bayt düzeyinde denetlenir; yalnızca adayda dizgi kurulur.
     */
    fun matchesQuery(b: ByteArray, off: Int, len: Int): Boolean {
        if (len < Packets.DNS_HDR + 5 || Packets.u16(b, off + 4) != 1) return false
        var i = off + Packets.DNS_HDR
        val end = off + len
        var lastStart = -1; var lastLen = 0; var total = 0
        while (true) {
            if (i >= end) return false
            val l = b[i].toInt() and 0xFF
            if (l == 0) break
            if (l > 63 || i + 1 + l > end) return false
            lastStart = i + 1; lastLen = l
            total += l + 1
            if (total > 255) return false
            i += 1 + l
        }
        if (lastStart < 0) return false
        if (!isCandidate(b, lastStart, lastLen)) return false
        val sb = StringBuilder(total)
        var j = off + Packets.DNS_HDR
        while (true) {
            val l = b[j].toInt() and 0xFF
            if (l == 0) break
            if (sb.isNotEmpty()) sb.append('.')
            for (k in 1..l) sb.append((b[j + k].toInt() and 0xFF).toChar())
            j += 1 + l
        }
        return matches(sb.toString())
    }

    private fun isCandidate(b: ByteArray, s: Int, l: Int): Boolean {
        fun eq(w: String): Boolean {
            if (w.length != l) return false
            for (k in 0 until l) { var c = b[s + k].toInt() and 0xFF; if (c in 'A'.code..'Z'.code) c += 32; if (c != w[k].code) return false }
            return true
        }
        return eq("arpa") || eq("local") || eq("onion") || eq("invalid")
    }

    /** Üst sunucu yerel ağda mı (ters bölgeler ve .local orada çözülebilir)? Adreslerden biri yerelse true. */
    fun lanUpstream(addresses: Collection<String>): Boolean = addresses.any { a -> Ip.parse(a)?.let { Dpi.isLocalAddress(it) } == true }
}
