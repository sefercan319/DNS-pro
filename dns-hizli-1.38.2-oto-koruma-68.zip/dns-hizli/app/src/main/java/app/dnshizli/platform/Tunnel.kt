package app.dnshizli.platform

import android.os.ParcelFileDescriptor
import android.system.ErrnoException
import android.system.Os
import android.system.OsConstants
import android.system.StructPollfd
import app.dnshizli.core.Forwarder
import app.dnshizli.core.Gateway
import app.dnshizli.core.Gw
import app.dnshizli.core.Journal
import app.dnshizli.core.LeakAudit
import app.dnshizli.core.SelfTest
import app.dnshizli.core.TcpDns
import java.io.FileDescriptor
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean


/**
 * Tünel arayüzünü okuyan tek iş parçacığı. `poll()` tünel ile bir uyandırma borusunu birlikte bekler: paket
 * yokken hiç uyanmaz; kapatılırken ya da bağlantı testi bir soru eklediğinde boruya yazılarak anında uyandırılır.
 * Eklenen sorular da bu iş parçacığında yönlendiriciye verilir ([Forwarder.onPacket] tek iş parçacıklıdır).
 */
internal class Tunnel(
    private val pfd: ParcelFileDescriptor,
    private val onEnded: (Tunnel, String) -> Unit,
    private val onActivity: () -> Unit,
) {
    @Volatile var forwarder: Forwarder? = null

    /** Varsa DNS dışındaki tüm paketler buraya gider (DNS adresine gidenler eskisi gibi yönlendiriciye). */
    @Volatile var gateway: Gateway? = null
    @Volatile private var stopping = false

    private val fd: FileDescriptor = pfd.fileDescriptor
    private val pipe: Array<FileDescriptor> = Os.pipe()
    private val thread = Thread({ loop() }, "dns-tun").also { it.isDaemon = true }
    private class Injected(val p: ByteArray, val target: Forwarder?)
    private val injected = ConcurrentLinkedQueue<Injected>()

    // Yazma ve kapatma birbirini dışlar: kapanan bir dosya tanıtıcısının numarası başka bir dosyaya verilmişken
    // gecikmiş bir cevabın oraya yazılması (klasik fd yeniden kullanım hatası) böylece imkânsız olur.
    private val writeLock = Any()
    private var closed = false
    private val closing = AtomicBoolean(false)

    fun start() = thread.start()

    /**
     * Kendi TCP katmanımız (DNS-over-TCP): tünelden gelen TCP/53 bağlantılarını karşılar. Soruları yönlendiriciye sanal
     * UDP istemcisi olarak verir ([feed]; tünel okuyucu iş parçacığında), cevapları [write] yakalayıp TCP olarak yazar.
     */
    private val tcp = TcpDns({ b, o, l -> rawWrite(b, o, l) }, { p, n -> forwarder?.onPacket(p, n) }, autoTimer = true)

    /** Cevabı tünele yazar. Sanal TCP istemcisine gidiyorsa TCP katmanı alır. Kuyruk doluysa paket sessizce atılır; istemci yeniden dener. */
    fun write(b: ByteArray, off: Int, len: Int) {
        if (tcp.offer(b, off, len)) return
        rawWrite(b, off, len)
    }

    /** Ağ geçidinin cevapları (kendi iş parçacığından). */
    fun writeRaw(b: ByteArray, off: Int, len: Int) = rawWrite(b, off, len)

    private fun rawWrite(b: ByteArray, off: Int, len: Int) {
        synchronized(writeLock) {
            if (closed) return
            try { Os.write(fd, b, off, len) } catch (_: Exception) {}
        }
    }

    /** Tünelden gelmiş gibi bir paket ekler (bağlantı testi). Okuyucu iş parçacığı uyandırılır. */
    fun inject(p: ByteArray, target: Forwarder? = null) {
        if (stopping) return
        injected.add(Injected(p, target))
        synchronized(writeLock) {
            if (closed) return
            try { Os.write(pipe[1], byteArrayOf(2), 0, 1) } catch (_: Exception) {}
        }
    }

    fun close() {
        if (!closing.compareAndSet(false, true)) return     // ikinci çağrı: borular zaten kapalı olabilir
        stopping = true
        try { Os.write(pipe[1], byteArrayOf(1), 0, 1) } catch (_: Exception) {}
        if (Thread.currentThread() !== thread && thread.isAlive) {
            try { thread.join(1000) } catch (_: InterruptedException) {}
        }
        synchronized(writeLock) {
            if (closed) return
            closed = true
            try { pfd.close() } catch (_: Exception) {}
            try { Os.close(pipe[0]) } catch (_: Exception) {}
            try { Os.close(pipe[1]) } catch (_: Exception) {}
        }
    }

    private fun loop() {
        var why = "okuma bitti"
        try {
            val tunPoll = StructPollfd()
            tunPoll.fd = fd
            tunPoll.events = OsConstants.POLLIN.toShort()
            val wakePoll = StructPollfd()
            wakePoll.fd = pipe[0]
            wakePoll.events = OsConstants.POLLIN.toShort()
            val fds = arrayOf(tunPoll, wakePoll)
            val buf = ByteArray(BUF)
            val wake = ByteArray(64)
            val bad = OsConstants.POLLERR or OsConstants.POLLHUP or OsConstants.POLLNVAL
            while (!stopping) {
                tunPoll.revents = 0
                wakePoll.revents = 0
                try {
                    Os.poll(fds, -1)
                } catch (e: ErrnoException) {
                    if (e.errno == OsConstants.EINTR) continue
                    throw e
                }
                if (stopping) break
                if (wakePoll.revents.toInt() != 0) {
                    // Uyandırma: borudaki baytları boşalt (poll hazır dediği için okuma bloklamaz), eklenenleri işle.
                    try { Os.read(pipe[0], wake, 0, wake.size) } catch (_: ErrnoException) {}
                    if (stopping) break
                    while (true) {
                        val inj = injected.poll() ?: break
                        // [target] verilmişse paket yalnızca o (henüz takılmamış) yönlendiriciye gider: gerçek sorgular etkilenmez.
                        try { (inj.target ?: forwarder)?.onPacket(inj.p, inj.p.size) } catch (_: Throwable) {}
                    }
                }
                val r = tunPoll.revents.toInt()
                if (r and OsConstants.POLLIN != 0) drain(buf)
                else if (r and bad != 0) { why = "tünel arayüzü kapandı"; break }
                onActivity()
            }
        } catch (e: Exception) {
            why = "hata: ${Journal.where(e)}"
        }
        if (!stopping) onEnded(this, why)
    }

    /** Hazır paketleri (en çok [MAX_BURST]) okuyup yönlendiriciye verir. Okunacak kalmayınca döner. */
    private fun drain(buf: ByteArray) {
        var n = 0
        while (n++ < MAX_BURST && !stopping) {
            val len = try {
                Os.read(fd, buf, 0, buf.size)
            } catch (e: ErrnoException) {
                if (e.errno == OsConstants.EAGAIN) return
                if (e.errno == OsConstants.EINTR) continue
                throw e
            }
            if (len <= 0) throw IllegalStateException("tünel okuması 0 bayt döndü")
            // Tek bir bozuk paket tüneli düşürmesin.
            try {
                val g = gateway
                if (forwarder != null && !toDns(buf, len) && Gw.isPublicTcpDns(buf, len)) {
                    // Genel IP'lere giden TCP/53 de şifreli DNS yoluna girer: düz metin TCP/53 ağ geçidinden çıkmaz.
                    LeakAudit.plainTcp.incrementAndGet()
                    tcp.onPacket(buf, len)
                } else if (g != null && !toDns(buf, len)) {
                    // DNS açıkken sabit bir sunucuya (ör. 8.8.8.8:53) giden düz DNS de seçilen DNS'e ve süzgece yönlenir.
                    val f = forwarder
                    if (f != null && Gw.isPublicPlainDns(buf, len)) { LeakAudit.plainUdp.incrementAndGet(); f.onPacket(buf, len) } else g.onPacket(buf, len)
                } else if (isTcp(buf, len)) tcp.onPacket(buf, len) else forwarder?.onPacket(buf, len)
            } catch (_: Throwable) {}              // StackOverflowError/OutOfMemoryError dahil: okuyucu iş parçacığı ölürse tünel sessizce donardı
        }
    }

    /** Paketin hedefi sahte DNS adresi mi? (Yalnızca ağ geçidi açıkken sorulur.) */
    private fun toDns(b: ByteArray, len: Int): Boolean {
        if (len < 20) return false
        return when ((b[0].toInt() ushr 4) and 0xF) {
            4 -> b[16] == FAKE4[0] && b[17] == FAKE4[1] && b[18] == FAKE4[2] && b[19] == FAKE4[3]
            6 -> len >= 40 && (0 until 16).all { b[24 + it] == SelfTest.FAKE6[it] }
            else -> false
        }
    }

    /** IPv4/IPv6 üzerinde doğrudan TCP mi? (DNS yolu UDP'dir; TCP yalnızca "kesildi" sonrası yeniden denemelerde gelir.) */
    private fun isTcp(b: ByteArray, len: Int): Boolean {
        if (len < 40) return false
        return when ((b[0].toInt() ushr 4) and 0xF) {
            4 -> (b[9].toInt() and 0xFF) == 6
            6 -> (b[6].toInt() and 0xFF) == 6
            else -> false
        }
    }

    private companion object {
        val FAKE4: ByteArray = byteArrayOf(10, 111.toByte(), 222.toByte(), 2)
        const val BUF = 4096
        const val MAX_BURST = 32
    }
}
