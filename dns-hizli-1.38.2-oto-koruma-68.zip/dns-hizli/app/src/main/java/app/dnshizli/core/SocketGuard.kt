package app.dnshizli.core

import java.io.IOException
import java.net.DatagramSocket
import java.net.Socket

/**
 * Uygulamanın kendi ağ işlerinin (hız ölçümü gibi) VPN tünelinin dışında kalmasını sağlayan köprü.
 *
 * Neden: uygulamanın kendi trafiği her zaman tünelin kapsamındadır. Yalnızca-DNS kipinde tünele sadece sahte DNS adresi
 * yönlendirilir, ölçüm soketleri doğrudan ağdan çıkar. Ağ geçidi (DPI atlatma, Reklam+) açıkken ise yol 0.0.0.0/0 olur:
 * korumasız bir ölçüm soketi tünele girer, düz DNS sorguları geçit tarafından yakalanıp seçili sunucuya (ve önbelleğine)
 * yönlendirilir, 853. port bağlantıları ise engellenir. Sonuç: sahte 0-1 ms süreler ya da "yanıt yok".
 *
 * Servis çalışırken [protectTcp]/[protectUdp] `VpnService.protect` çağrısına bağlanır; servis yokken boştur ve soketler
 * olduğu gibi kullanılır (JVM testleri dahil).
 */
object SocketGuard {
    @Volatile var protectTcp: ((Socket) -> Boolean)? = null
    @Volatile var protectUdp: ((DatagramSocket) -> Boolean)? = null

    /**
     * UDP soketini tünel dışında tutar. true: korundu ya da korunacak bir tünel yok (servis çalışmıyor). false: koruma BAŞARISIZ; çağıran
     * bu soketi kullanmamalı (tünele girer, önbellekten sahte hızlı cevap alır ya da döngüye düşer).
     */
    fun udp(s: DatagramSocket): Boolean {
        val p = protectUdp ?: return true
        return try { p(s) } catch (_: Exception) { false }
    }

    /**
     * Henüz bağlanmamış TCP soketini tünel dışında tutmaya çalışır. Bağlanmamış bir Socket'in dosya tanıtıcısı yoktur;
     * bu yüzden önce yerel bir adrese bağlanır (bind), sonra korunur. Hedefe bağlanmak çağıranın işidir.
     */
    fun tcp(s: Socket): Boolean {
        val p = protectTcp ?: return true
        try { s.bind(null) } catch (_: IOException) {}
        return try { p(s) } catch (_: Exception) { false }
    }
}
