package app.dnshizli.core

import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PublicKey
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

/**
 * Filtre listesi güncellemesinin saf (ağ ve Android'siz) çekirdeği.
 *
 * Yayın tarafı [MANIFEST] ile birlikte her listenin SHA-256 özetini ve boyunu yayımlar; manifest ECDSA P-256 ile imzalanır.
 * İstemci şunları yapar: imzayı gömülü açık anahtarla doğrular, her dosyanın özetini ve boyunu manifestle karşılaştırır,
 * sürüm numarasının artmasını ister (eski bir imzalı sürüme geri dönüş = rollback reddedilir).
 *
 * Gömülü açık anahtar boşsa güncelleme KAPALIDIR (güvenli varsayılan): imzasız hiçbir liste kabul edilmez.
 */
object ListUpdate {
    /** Manifestin ilk satırı: biçim sürümü. */
    const val FORMAT = "DNSHIZLI-LISTE 1"

    /** Tek bir liste dosyası için en büyük boyut (strict.bin ~2.3 MB; pay bırakılmış). */
    const val MAX_FILE = 8L * 1024 * 1024

    /**
     * Bir liste dosyası için en küçük boyut. Boş ya da kırpılmış bir liste imzalı olsa bile tüm kullanıcılarda engellemeyi
     * kapatırdı; bu sınır böyle bir yayını baştan reddeder. (basic.bin ~1.6 MB, medium.bin ~0.6 MB.)
     */
    const val MIN_FILE = 100_000L

    /** Manifest için en büyük boyut. */
    const val MAX_MANIFEST = 16 * 1024

    /** Güncellenebilen liste dosyaları. psl.txt ve protected.txt bilerek YOKTUR: korunan adlar yalnızca paketten gelir. */
    val UPDATABLE: List<String> = listOf("basic.bin", "medium.bin", "strict.bin")

    class Entry(val name: String, val sha256: String, val bytes: Long)

    class Manifest(val version: Long, val entries: List<Entry>) {
        fun entry(name: String): Entry? = entries.firstOrNull { it.name == name }
    }

    /** Manifesti okur. Biçim bozuk, eksik ya da sınır dışıysa null. */
    fun parse(bytes: ByteArray): Manifest? {
        if (bytes.isEmpty() || bytes.size > MAX_MANIFEST) return null
        val lines = String(bytes, Charsets.UTF_8).split('\n')
        if (lines.firstOrNull()?.trimEnd('\r') != FORMAT) return null
        var version = -1L
        val entries = ArrayList<Entry>()
        for (raw in lines.drop(1)) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("tarih=")) continue
            if (line.startsWith("surum=")) {
                if (version != -1L) return null                  // iki sürüm satırı: hangisinin geçerli olduğu belirsiz
                val v = line.removePrefix("surum=")
                if (v.isEmpty() || v.length > 18 || !v.all { it in '0'..'9' }) return null
                version = v.toLong()
                continue
            }
            val p = line.split(' ')
            if (p.size != 3) return null
            val size = p[2].toLongOrNull() ?: return null
            if (p[1].length != 64 || !p[1].all { it in '0'..'9' || it in 'a'..'f' }) return null
            if (p[0] !in UPDATABLE || size < MIN_FILE || size > MAX_FILE) return null
            if (entries.any { it.name == p[0] }) return null
            entries.add(Entry(p[0], p[1], size))
        }
        if (version <= 0) return null
        if (entries.map { it.name }.toSet() != UPDATABLE.toSet()) return null
        return Manifest(version, entries)
    }

    /** Manifestin imzası (DER biçimli ECDSA) gömülü anahtarla geçerli mi? */
    fun verifySignature(manifest: ByteArray, signature: ByteArray, key: PublicKey): Boolean = try {
        Signature.getInstance("SHA256withECDSA").run {
            initVerify(key)
            update(manifest)
            verify(signature)
        }
    } catch (_: Exception) {
        false
    }

    /** DER (X.509 SubjectPublicKeyInfo) biçimli açık anahtarı çözer. Bozuksa null. */
    fun publicKey(der: ByteArray): PublicKey? = try {
        val k = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(der))
        // Yalnızca P-256 (secp256r1): yanlışlıkla daha zayıf ya da beklenmeyen bir eğri gömülürse güncelleme kapalı kalır.
        val ec = k as? java.security.interfaces.ECPublicKey
        val field = ec?.params?.curve?.field as? java.security.spec.ECFieldFp
        if (ec == null || field == null || field.p != P256_P || ec.params.order != P256_N) null
        else if (ec.params.cofactor != 1 || ec.w == java.security.spec.ECPoint.POINT_INFINITY) null
        else if (!onCurve(ec)) null else k
    } catch (_: Exception) {
        null
    }

    /** Açık anahtar noktası eğri denklemini (y² = x³ + ax + b mod p) sağlıyor mu? */
    private fun onCurve(ec: java.security.interfaces.ECPublicKey): Boolean {
        val p = P256_P
        val c = ec.params.curve
        val x = ec.w.affineX
        val y = ec.w.affineY
        if (x.signum() < 0 || y.signum() < 0 || x >= p || y >= p) return false
        val lhs = y.multiply(y).mod(p)
        val rhs = x.multiply(x).multiply(x).add(c.a.multiply(x)).add(c.b).mod(p)
        return lhs == rhs
    }

    /** P-256 (secp256r1) asal alanı ve grup mertebesi (FIPS 186-4 D.1.2.3). */
    private val P256_P = java.math.BigInteger("ffffffff00000001000000000000000000000000ffffffffffffffffffffffff", 16)
    private val P256_N = java.math.BigInteger("ffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551", 16)

    fun sha256Hex(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    /** İndirilen dosya manifestteki boy ve özetle birebir uyuyor mu? */
    fun matches(file: ByteArray, e: Entry): Boolean = file.size.toLong() == e.bytes && sha256Hex(file) == e.sha256

    /**
     * Yeni manifest, kurulu sürümden yeniyse kabul edilir (eşit ya da eski = geri dönüş saldırısı). Sürüm, imzalama anının Unix
     * saniyesidir: saatten [FUTURE_SKEW_S] fazla İLERİDE bir sürüm reddedilir. Aksi halde yanlış saatle ya da bir kez ele geçirilen
     * anahtarla imzalanmış "2099" sürümü kurulur ve sonraki bütün meşru güncellemeleri kalıcı olarak kilitlerdi ("gelecekten donma").
     * Kurulu sürüm zaten böyle zehirliyse (saatten çok ileride) pencere içindeki imzalı bir sürüm kabul edilir: kilit kendiliğinden açılır.
     * Pay geniştir (30 gün): saati geri kalmış telefonlar meşru güncellemeleri kaçırmaz.
     */
    fun isNewer(installed: Long, incoming: Manifest, nowSec: Long = System.currentTimeMillis() / 1000): Boolean {
        val limit = nowSec + FUTURE_SKEW_S
        if (incoming.version > limit) return false
        if (installed > limit) return true
        return incoming.version > installed
    }

    /** Manifest sürümünün saate göre en çok ne kadar ileride olabileceği (saniye). */
    const val FUTURE_SKEW_S = 30L * 24 * 3600
}

/**
 * İndirilmiş (imzası ve özeti doğru) listelerin YERİNE KONMADAN önceki sağlık denetimi. İmza listenin içeriğinin iyi olduğunu değil,
 * yayıncıdan geldiğini kanıtlar; hatalı üretilmiş bir yayın (ör. bir kaynağın bozulup popüler siteleri içermesi) tüm kullanıcıların
 * siteleri açamamasına yol açardı. Burada liste en sıkı seviyede bir motora kurulur ve şunlara bakılır:
 *  - her dosya çözülebiliyor mu,
 *  - çok bilinen, hiçbir zaman engellenmemesi gereken siteler ([MUST_PASS]) geçiyor mu,
 *  - bilinen reklam ağları ([MUST_BLOCK]) hâlâ büyük oranda engelleniyor mu (boş/anlamsız liste),
 *  - boyut, paketteki sürüme göre makul mü (yarıdan az: kırpılmış; 4 katından çok: şişmiş).
 * Başarısızlıkta neden metni döner ve güncelleme atlanır (eski liste kalır).
 */
object ListCanary {
    val MUST_PASS: List<String> = listOf(
        "google.com", "www.google.com", "youtube.com", "m.youtube.com", "gmail.com", "wikipedia.org", "en.wikipedia.org",
        "github.com", "githubusercontent.com", "microsoft.com", "live.com", "office.com", "apple.com", "icloud.com",
        "amazon.com", "whatsapp.com", "web.whatsapp.com", "telegram.org", "t.me", "instagram.com", "facebook.com",
        "twitter.com", "x.com", "reddit.com", "netflix.com", "spotify.com", "cloudflare.com", "mozilla.org", "paypal.com",
        "stackoverflow.com", "linkedin.com", "twitch.tv", "discord.com", "zoom.us", "dropbox.com", "yahoo.com",
        "bing.com", "duckduckgo.com", "trendyol.com", "hepsiburada.com", "sahibinden.com", "turkiye.gov.tr", "ziraatbank.com.tr",
        "garantibbva.com.tr", "isbank.com.tr", "akbank.com", "yapikredi.com.tr",
    )

    val MUST_BLOCK: List<String> = listOf(
        "doubleclick.net", "googlesyndication.com", "adservice.google.com", "pagead2.googlesyndication.com",
        "ads.yahoo.com", "adnxs.com", "criteo.com", "outbrain.com", "taboola.com", "scorecardresearch.com",
    )

    /** MUST_BLOCK içinde en az bu kadarı engellenmeli. */
    const val MIN_BLOCKED = 7

    /** protected.txt içeriğinden korunan küme (liste motorundaki ile aynı kural). */
    fun protectedOf(text: String): FilterTier {
        val hs = text.lineSequence().map { it.substringBefore('#').trim() }
            .filter { it.isNotEmpty() }.mapNotNull { FilterNames.normalize(it) }.map { FilterHash.hash(it) }.distinct().toList().toLongArray()
        hs.sort()
        return FilterTier(hs)
    }

    /**
     * [data]: dosya adı → bayt (basic/medium/strict). [prot]: paketteki korunan küme. [reference]: paketteki listelerin ad sayıları
     * (null ise boyut denetimi yapılmaz). Sorun yoksa null, varsa kısa neden.
     */
    fun check(data: Map<String, ByteArray>, prot: FilterTier = FilterTier.EMPTY, reference: Map<String, Int>? = null): String? {
        val tiers = ArrayList<FilterTier>(3)
        for (n in ListUpdate.UPDATABLE) {
            val b = data[n] ?: return "eksik:$n"
            val t = try { FilterTier.read(java.io.ByteArrayInputStream(b)) } catch (_: Exception) { return "bozuk:$n" } catch (_: OutOfMemoryError) { return null }
            val ref = reference?.get(n)
            if (ref != null && ref > 0) {
                if (t.size * 2L < ref) return "kirpilmis:$n"
                if (t.size.toLong() > ref * 4L) return "sismis:$n"
            }
            tiers.add(t)
        }
        val e = FilterEngine(tiers, prot, emptyList(), emptyList(), blockDoh = false, riskyTlds = true)
        for (n in MUST_PASS) if (e.verdictOf(n) != FilterVerdict.PASS) return "engelli:$n"
        val blocked = MUST_BLOCK.count { e.verdictOf(it) != FilterVerdict.PASS }
        if (blocked < MIN_BLOCKED) return "zayif:$blocked/${MUST_BLOCK.size}"
        return null
    }
}
