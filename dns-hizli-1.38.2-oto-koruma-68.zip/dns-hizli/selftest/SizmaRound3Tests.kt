package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.io.File

/** sizma27: güvenlik turu 3 — yayın öncesi sunucu kanaryası (tools/yayin/kanarya.py) uygulamadaki ListCanary ile aynı kararı verir. */
internal fun runRound3Tests() {
    runCiPinningTests()
    runReleaseCanaryTests()
    runIsolationTests()
    runDohCoverageTests()
}

/**
 * Tarayıcı içi şifreli DNS kapsamı: Chrome'un "Güvenli DNS" sağlayıcı listesindeki (net/dns/public/doh_provider_entry.cc, Ekim 2026) ve
 * Firefox TRR ortaklarındaki her ad engellenir; aynı alan adındaki asıl siteler (spectrum.com, nic.cz...) ENGELLENMEZ.
 */
private fun runDohCoverageTests() {
    T.group("sizma27: tarayıcı içi şifreli DNS (Chrome/Firefox sağlayıcı listesi) süzgeci atlatamaz")
    val chrome = listOf("doh.cleanbrowsing.org", "chrome.cloudflare-dns.com", "family.cloudflare-dns.com", "security.cloudflare-dns.com",
        "doh.xfinity.com", "doh.cox.net", "odvr.nic.cz", "protective.joindns4.eu", "doh.dns.sb", "dns.google", "dns64.dns.google",
        "public.dns.iij.jp", "dns.levonet.sk", "chromium.dns.nextdns.io", "doh.opendns.com", "doh.familyshield.opendns.com",
        "dns11.quad9.net", "dns10.quad9.net", "dns.quad9.net", "doh.quickline.ch", "doh-01.spectrum.com", "doh-02.spectrum.com")
    val firefox = listOf("mozilla.cloudflare-dns.com", "firefox.dns.nextdns.io", "private.canadianshield.cira.ca", "doh.xfinity.com", "wikimedia-dns.org")
    val dns4eu = listOf("noads.joindns4.eu", "child.joindns4.eu", "child-noads.joindns4.eu", "unfiltered.joindns4.eu")
    val all = chrome + firefox + dns4eu
    val missing = all.filterNot { Dpi.isDohHost(it) }
    T.check("Chrome + Firefox + DNS4EU sağlayıcı adlarının hepsi DoH sayılır (ağ geçidi SNI/QUIC yolu)", missing.isEmpty(), missing.joinToString())
    val e = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), emptyList(), blockDoh = true)
    val pass = all.filter { e.verdictOf(it) == FilterVerdict.PASS }
    T.check("DNS süzgecinde (DoH koruması açık) hepsi engellenir — tarayıcı sistem DNS'ine döner", pass.isEmpty(), pass.joinToString())
    val sites = listOf("spectrum.com", "www.spectrum.com", "cox.net", "www.cox.net", "nic.cz", "www.nic.cz", "joindns4.eu", "www.joindns4.eu",
        "cira.ca", "www.cira.ca", "iij.jp", "levonet.sk", "quickline.ch", "google.com", "quad9.net", "www.quad9.net", "cloudflare.com")
    val over = sites.filter { Dpi.isDohHost(it) || e.verdictOf(it) != FilterVerdict.PASS }
    T.check("aynı alan adındaki asıl siteler engellenmez (aşırı engel yok)", over.isEmpty(), over.joinToString())
    T.check("kanarya MUST_PASS sitelerinden hiçbiri DoH sayılmaz", ListCanary.MUST_PASS.none { Dpi.isDohHost(it) })
    val off = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), emptyList(), blockDoh = false)
    T.check("DoH koruması kapalıyken bu adlar engellenmez (ayar saygısı)", all.all { off.verdictOf(it) == FilterVerdict.PASS })
}

/** FilterRuntime.reset tam mı: her ayar bayrağı ve son istek varsayılana döner, kaynaklar korunur; test koşucusu sızıntıyı görür. */
private fun runIsolationTests() {
    T.group("sizma27: tekil yalıtımı — FilterRuntime.reset tam, kaynak korunur")
    try {
        val fake = FilterSource { throw java.io.IOException("yok") }
        FilterRuntime.source = fake
        FilterRuntime.setDohGuard(false); FilterRuntime.setLight(true); FilterRuntime.setGateway(FilterLevel.STRICT); FilterRuntime.setStrictApps(true)
        FilterRuntime.echAllow = true; FilterRuntime.rebind = false
        FilterRuntime.updateNow(FilterLevel.BASIC, listOf("izin.example"), listOf("engel.example"))
        val dirty = FilterRuntime.stateKey()
        T.check("kirli durum görülür (dohGuard, light, gw, strict, ech, rebind, son istek)",
            listOf("dohGuard=false", "light", "gwLevel=STRICT", "wantStrict", "ech", "rebind=false", "last=BASIC").all { it in dirty }, dirty)
        FilterRuntime.reset()
        T.check("reset sonrası durum varsayılan (boş özet)", FilterRuntime.stateKey().isEmpty(), FilterRuntime.stateKey())
        T.check("reset: dohGuard yeniden açık (sonraki kurulum DoH adlarını engeller)", run {
            FilterRuntime.updateNow(FilterLevel.BASIC, emptyList(), emptyList())
            FilterRuntime.engine?.verdictOf("dns.google") != FilterVerdict.PASS
        })
        FilterRuntime.reset()
        T.check("reset kaynağa dokunmaz (App yapılandırması)", FilterRuntime.source === fake)
        T.check("reset: rebind ve echAllow varsayılan", FilterRuntime.rebind && !FilterRuntime.echAllow && !FilterRuntime.dropHttpsRr)
        // Sızıntı dedektörü: birim kirli bırakırsa kaydedilir, sonraki birimden önce sıfırlanır.
        Isolation.reset()                                   // bu birimin kendi sahte kaynağı sızıntı sayılmasın
        Isolation.enter("deneme-birimi")
        FilterRuntime.setLight(true); FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), emptyList())
        Isolation.enter("sonraki")
        val leaked = Isolation.leaks.remove("deneme-birimi")
        T.check("koşucu kirli bırakılan birimi yakalar ve sıfırlar", leaked != null && "light" in leaked && FilterRuntime.stateKey().isEmpty(), leaked ?: "-")
    } finally { Isolation.reset() }
}

/** CI tedarik zinciri: her eylem ve imaj değişmez bir özete sabit; "latest" ya da yalnızca etiket yok. */
private fun runCiPinningTests() {
    T.group("sizma27: CI tedarik zinciri — eylemler ve imajlar özete sabit")
    val wf = File(".github/workflows").listFiles { f -> f.extension == "yml" || f.extension == "yaml" }.orEmpty().sortedBy { it.name }
    T.check("iş akışları bulundu", wf.isNotEmpty())
    val bad = ArrayList<String>()
    for (f in wf) for ((i, raw) in f.readLines().withIndex()) {
        val l = raw.substringBefore(" #").trim()
        if (l.startsWith("#")) continue
        Regex("""uses:\s*([^\s]+)""").find(l)?.let { m -> val u = m.groupValues[1]; if (!u.startsWith("./") && !Regex("""@[0-9a-f]{40}$""").containsMatchIn(u)) bad += "${f.name}:${i + 1} $u" }
        if (Regex(""":latest\b""").containsMatchIn(l)) bad += "${f.name}:${i + 1} latest"
        Regex("""(?:image|MOBSF_IMAGE|container):\s*([^\s"]+)""").find(l)?.let { m -> if (!m.groupValues[1].contains("@sha256:")) bad += "${f.name}:${i + 1} ${m.groupValues[1]}" }
        if (l.contains("docker run") && !l.contains("\$MOBSF_IMAGE") && !l.contains("@sha256:")) bad += "${f.name}:${i + 1} docker run"
    }
    T.check("tüm `uses:` 40 haneli SHA, imajlar @sha256 özetli, `:latest` yok", bad.isEmpty(), bad.joinToString("; ").take(300))
    val sec = File(".github/workflows/security.yml").readText()
    T.check("MobSF imajı özetle sabit (sha256, 64 hane)", Regex("""MOBSF_IMAGE: opensecurity/mobile-security-framework-mobsf:v[\d.]+@sha256:[0-9a-f]{64}""").containsMatchIn(sec))
}

private fun dnf(hashes: Collection<Long>): ByteArray {
    val hs = hashes.distinct().sorted()
    val o = ByteArrayOutputStream()
    o.write("DNF1".toByteArray())
    val n = hs.size
    o.write(n ushr 24); o.write(n ushr 16); o.write(n ushr 8); o.write(n)
    var prev = 0L
    for (h in hs) {
        var d = h - prev; prev = h
        while (true) { val b = (d and 0x7F).toInt(); d = d ushr 7; if (d == 0L) { o.write(b); break } else o.write(b or 0x80) }
    }
    return o.toByteArray()
}

private fun undnf(b: ByteArray): List<Long> {
    val n = ((b[4].toInt() and 0xFF) shl 24) or ((b[5].toInt() and 0xFF) shl 16) or ((b[6].toInt() and 0xFF) shl 8) or (b[7].toInt() and 0xFF)
    val out = ArrayList<Long>(n)
    var i = 8; var prev = 0L
    repeat(n) {
        var v = 0L; var sh = 0
        while (true) { val c = b[i++].toInt() and 0xFF; v = v or ((c and 0x7F).toLong() shl sh); sh += 7; if (c and 0x80 == 0) break }
        prev += v; out.add(prev)
    }
    return out
}

private fun python(): Boolean = try {
    ProcessBuilder("python3", "--version").redirectErrorStream(true).start().let { it.inputStream.readBytes(); it.waitFor() == 0 }
} catch (_: Exception) { false }

/** kanarya.py'yi çalıştırır: null = geçti, yoksa "::error::Kanarya: <neden> —" içindeki neden. */
private fun pyCanary(dir: File, prev: File?): String? {
    val cmd = arrayListOf("python3", "-I", "tools/yayin/kanarya.py", dir.path)
    if (prev != null) { cmd.add("--prev"); cmd.add(prev.path) }
    val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
    val out = p.inputStream.readBytes().toString(Charsets.UTF_8)
    val rc = p.waitFor()
    if (rc == 0) return null
    return Regex("Kanarya: (\\S+)").find(out)?.groupValues?.get(1) ?: "rc=$rc $out"
}

private fun runReleaseCanaryTests() {
    T.group("sizma27: yayın öncesi kanarya (sunucu) ↔ ListCanary (uygulama) aynı kararı verir")
    val assets = File("app/src/main/assets/filter")
    val base = ListUpdate.UPDATABLE.associateWith { File(assets, it).readBytes() }
    T.check("kanarya betiği ve iş akışı adımı var", File("tools/yayin/kanarya.py").exists() &&
        File(".github/workflows/listeleri-yayinla.yml").readText().let { w -> w.contains("tools/yayin/kanarya.py dist --prev") && w.indexOf("kanarya.py") < w.indexOf("gh release upload") })
    if (!python()) { T.check("python3 yok: çapraz denetim atlandı (CI'da çalışır)", true); return }

    val tmp = kotlin.io.path.createTempDirectory("kanarya").toFile()
    try {
        var case = 0
        fun run(label: String, data: Map<String, ByteArray?>, prevCounts: Map<String, Int>? = null) {
            val d = File(tmp, "c${case++}").also { it.mkdirs() }
            for ((n, b) in data) if (b != null) File(d, n).writeBytes(b)
            var prev: File? = null
            if (prevCounts != null) {
                prev = File(tmp, "p$case").also { it.mkdirs() }
                for ((n, c) in prevCounts) File(prev, n).writeBytes(dnf((1..c).map { it.toLong() * 7919 }))
            }
            @Suppress("UNCHECKED_CAST")
            val kt = ListCanary.check(data.filterValues { it != null } as Map<String, ByteArray>, FilterTier.EMPTY, prevCounts)
            val py = pyCanary(d, prev)
            // Sunucu en az uygulama kadar sıkı: uygulama reddediyorsa sunucu da aynı TÜR nedenle reddeder. Sunucu yalnızca listelere bakar;
            // uygulamanın ad sezgileri ("ads.", "pagead" etiketleri) sayılmaz, bu yüzden "zayıf" sayısı sunucuda daha düşük çıkabilir.
            val same = kt == py || (kt != null && py != null && kt.substringBefore(':') == py.substringBefore(':') && kt.startsWith("zayif"))
            T.check("$label: Kotlin='${kt ?: "geçti"}' Python='${py ?: "geçti"}'", same)
        }
        run("paketteki listeler", base)
        val basic = undnf(base.getValue("basic.bin"))
        for (site in listOf("google.com", "turkiye.gov.tr", "web.whatsapp.com")) {
            run("$site basic'e sızmış", base + ("basic.bin" to dnf(basic + FilterHash.hash(site))))
        }
        run("üst alan (whatsapp.com) engelliyse alt ad (web.whatsapp.com) da yakalanır", base + ("medium.bin" to dnf(undnf(base.getValue("medium.bin")) + FilterHash.hash("whatsapp.com"))))
        val adH = ListCanary.MUST_BLOCK.map { FilterHash.hash(it) }.toSet()
        run("reklam ağları çıkarılmış (zayıf liste)", ListUpdate.UPDATABLE.associateWith { n -> dnf(undnf(base.getValue(n)).filter { it !in adH }) })
        run("bozuk dosya", base + ("strict.bin" to "DNF1\u0000\u0000\u0000\u0009abc".toByteArray()))
        run("eksik dosya", base + ("medium.bin" to null))
        val counts = ListUpdate.UPDATABLE.associateWith { undnf(base.getValue(it)).size }
        run("önceki yayına göre normal", base, counts)
        run("önceki yayından 2 kattan fazla küçük (kırpılmış)", base, counts + ("basic.bin" to counts.getValue("basic.bin") * 3))
        run("önceki yayından 4 kattan fazla büyük (şişmiş)", base, counts + ("strict.bin" to counts.getValue("strict.bin") / 5))
        // Sunucu daha sıkı: korunan ad (protected.txt) listeye girmişse uygulama korumayla geçirir, sunucu yine reddeder.
        val withProt = base + ("basic.bin" to dnf(basic + FilterHash.hash("google.com")))
        val prot = ListCanary.protectedOf("google.com\n")
        T.check("korunan ad listeye sızmışsa: uygulama korumayla geçer, sunucu reddeder (daha sıkı)",
            ListCanary.check(withProt, prot, null) == null && pyCanary(File(tmp, "c1"), null) == "engelli:google.com")
    } finally { tmp.deleteRecursively() }
}
