package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** sizma30: DoH "meşgul" sunucu (429/503 + Retry-After) ve ODoH anahtar önbelleğinde sunucunun max-age'i. */
internal fun runRound6Tests() {
    runHttpRuleTests()
    runBusyFailoverTests()
    runOdohMaxAgeTests()
}

private fun runHttpRuleTests() {
    T.group("sizma30: HTTP kuralları — meşgul, Retry-After, max-age")
    T.check("429 ve 503 meşgul; 500/404/200 değil", HttpRules.isBusy(429) && HttpRules.isBusy(503) && !HttpRules.isBusy(500) && !HttpRules.isBusy(404) && !HttpRules.isBusy(200))
    T.check("Retry-After saniye okunur, 300 sn ile kırpılır",
        HttpRules.retryAfter("60") == 60 && HttpRules.retryAfter(" 5 ") == 5 && HttpRules.retryAfter("999999") == HttpRules.MAX_RETRY_AFTER_S && HttpRules.retryAfter("0") == 0)
    T.check("Retry-After tarih/bozuk/eksi/aşırı uzun: null (varsayılan kullanılır)",
        listOf("Wed, 21 Oct 2015 07:28:00 GMT", "-5", "1e3", "", "12345678901", null).all { HttpRules.retryAfter(it) == null })
    T.check("max-age okunur; no-store/no-cache 0; yoksa null",
        HttpRules.maxAge("public, max-age=3600") == 3600 && HttpRules.maxAge("max-age=\"120\"") == 120 && HttpRules.maxAge("no-store") == 0 &&
            HttpRules.maxAge("max-age=60, no-cache") == 0 && HttpRules.maxAge("s-maxage=99") == null && HttpRules.maxAge(null) == null && HttpRules.maxAge("max-age=abc") == null)
}

private fun runBusyFailoverTests() {
    T.group("sizma30: DoH sunucusu 'meşgul' (429) derse beklemeden yedeğe geçilir")
    FakeTlsDns(doh = true).use { busy ->
        FakeTlsDns(doh = true).use { good ->
            busy.rawHttp = "HTTP/1.1 429 Too Many Requests\r\nRetry-After: 60\r\nContent-Length: 0\r\n\r\n".toByteArray()
            SecHarness(Proto.DOH, listOf(busy.target, good.target), maxLanes = 1).use { h ->
                h.send(1, "m1.example.com")
                val r = h.reply()
                T.check("ilk sorgu yedekten cevaplandı", r != null && checkReply(r, 1) == null)
                val st = h.fw.stats()
                T.check("TEK 'meşgul' cevabıyla yedeğe geçildi (normalde 2 hata gerekir)", st.backup && st.failovers == 1L && h.fw.busyMarks.get() == 1L, st.toString())
                T.check("meşgul sunucu Retry-After süresince atlanır", h.fw.busy(0) && !h.fw.busy(1))
                val before = busy.requests.size
                var ok = 0
                for (i in 2..5) { h.send(i, "m$i.example.com"); if (h.reply()?.let { checkReply(it, i) } == null) ok++ }
                T.check("sonraki sorgular yedekten, meşgul sunucuya istek gitmez", ok == 4 && busy.requests.size == before, "ok=$ok istek=${busy.requests.size - before}")
                T.check("günlükte nedeni yazar", h.logs.any { it.contains("meşgul") && it.contains("60") })
                h.fw.resetNetwork("test")
                T.check("ağ değişince meşgul işareti silinir", !h.fw.busy(0))
            }
        }
    }
    // Kontrol: sıradan sunucu hatası (500) tek başına geçiş yaptırmaz (eski davranış korunur).
    FakeTlsDns(doh = true).use { bad ->
        FakeTlsDns(doh = true).use { good ->
            bad.rawHttp = "HTTP/1.1 500 Oops\r\nContent-Length: 0\r\n\r\n".toByteArray()
            SecHarness(Proto.DOH, listOf(bad.target, good.target), maxLanes = 1).use { h ->
                h.send(7, "k.example.com")
                T.check("500: sorgu yine cevaplandı", h.reply()?.let { checkReply(it, 7) } == null)
                T.check("500: tek hatada kalıcı geçiş yok, meşgul işareti yok", h.fw.stats().failovers == 0L && h.fw.busyMarks.get() == 0L && !h.fw.busy(0))
            }
        }
    }
    // Retry-After yoksa varsayılan süre; Retry-After "1 yıl" ise 300 sn ile sınırlı.
    FakeTlsDns(doh = true).use { busy ->
        FakeTlsDns(doh = true).use { good ->
            busy.rawHttp = "HTTP/1.1 503 Busy\r\nRetry-After: 31536000\r\nContent-Length: 0\r\n\r\n".toByteArray()
            val clock = AtomicLong(1_000_000L)
            SecHarness(Proto.DOH, listOf(busy.target, good.target), maxLanes = 1, nowMs = { clock.get() }).use { h ->
                h.send(9, "y.example.com"); h.reply()
                T.check("503 + 'bir yıl': işaretlendi", h.fw.busy(0))
                clock.addAndGet(299_000)
                T.check("299 sn sonra hâlâ meşgul", h.fw.busy(0))
                clock.addAndGet(2_000)
                T.check("300 sn sınırı: sonra yeniden denenebilir (kötü niyetli sunucu kalıcı devre dışı bıraktıramaz)", !h.fw.busy(0))
            }
        }
    }
}

private fun runOdohMaxAgeTests() {
    T.group("sizma30: ODoH anahtar önbelleği sunucunun max-age'ine uyar (yalnızca kısaltır)")
    val cfg = odohConfigBytes(X25519.publicKey(ByteArray(32) { 3 }))
    val clock = AtomicLong(0)
    val fetches = AtomicInteger()
    var maxAge: Int? = 3600
    val kr = OdohKeyring({ _ -> fetches.incrementAndGet(); cfg }, { clock.get() }, ttlMs = 6 * 3600_000L, maxAgeOf = { maxAge })
    kr.current("h"); val f0 = fetches.get()
    clock.addAndGet(59 * 60_000L); kr.current("h")
    T.check("max-age=3600: 59. dakikada yeniden alınmaz", fetches.get() == f0)
    clock.addAndGet(2 * 60_000L); kr.current("h")
    T.check("61. dakikada yenilenir (6 saat beklenmez; 401 almadan önce)", fetches.get() == f0 + 1)
    maxAge = 0
    clock.addAndGet(3600_000L); kr.current("h"); val f1 = fetches.get()
    clock.addAndGet(60_000L); kr.current("h")
    T.check("max-age=0: her sorguda alım yapılmaz (en az 5 dk taze)", fetches.get() == f1)
    clock.addAndGet(5 * 60_000L); kr.current("h")
    T.check("max-age=0: 5 dk sonra yenilenir", fetches.get() == f1 + 1)
    maxAge = 7 * 24 * 3600
    clock.addAndGet(10 * 60_000L); kr.current("h"); val f2 = fetches.get()
    clock.addAndGet(6 * 3600_000L + 1000); kr.current("h")
    T.check("max-age=1 hafta: tazelik 6 saati aşmaz (anahtar döndürme önerisi)", fetches.get() == f2 + 1)
    maxAge = null
    val kr2 = OdohKeyring({ _ -> fetches.incrementAndGet(); cfg }, { clock.get() }, ttlMs = 1000)
    kr2.current("q"); val f3 = fetches.get(); clock.addAndGet(500); kr2.current("q")
    T.check("max-age yoksa ve tazelik 5 dk'dan kısa ayarlıysa eski davranış (çökme yok)", fetches.get() == f3)
    T.check("MiniHttps: cevap başlık vermezse önceki max-age silinir", run { MiniHttps.noteMaxAge("x.test", 30); MiniHttps.noteMaxAge("x.test", null); MiniHttps.maxAge("x.test") == null })
}
