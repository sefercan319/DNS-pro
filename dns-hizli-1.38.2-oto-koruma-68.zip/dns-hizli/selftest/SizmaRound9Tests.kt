package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File

/** sizma33: içe aktarma incelemesi kapsamı (her ayar sınıflı, uygulama muafiyeti uyarılır) ve test altyapısı sağlamlığı. */
internal fun runRound9Tests() {
    T.group("sizma33: içe aktarma — her ayar anahtarı sınıflandırılmış")
    val keys = SettingsCodec.encode(AppSettings()).keys
    val classified = ImportReview.REVIEWED + ImportReview.HARMLESS + SettingsCodec.SERVICE_KEYS + SettingsCodec.LOCAL_KEYS
    val missing = keys.filter { it !in classified }
    T.check("yeni bir ayar incelemeye ya da 'zararsız' listesine bilinçli olarak eklenmeli", missing.isEmpty(), missing.joinToString())
    T.check("bir anahtar hem incelenen hem zararsız olamaz", (ImportReview.REVIEWED intersect ImportReview.HARMLESS).isEmpty())
    val stale = (ImportReview.REVIEWED + ImportReview.HARMLESS).filter { it !in keys }
    T.check("listelerde artık var olmayan anahtar kalmadı", stale.isEmpty(), stale.joinToString())

    T.group("sizma33: içe aktarma — paylaşılan kod bir uygulamayı süzgeçten muaf yaparsa uyarılır")
    val base = AppSettings(appAds = AppAds.encode(mapOf("com.ornek.oyun" to AppMode.STRICT)))
    val exempt = base.copy(appAds = AppAds.encode(mapOf("com.ornek.oyun" to AppMode.STRICT, "com.reklamci.app" to AppMode.EXEMPT)))
    T.check("yeni muaf uygulama: kurallar uyarısı", SensitiveChange.RULES in ImportReview.changes(base, exempt))
    val strictOnly = base.copy(appAds = AppAds.encode(mapOf("com.ornek.oyun" to AppMode.STRICT, "com.baska" to AppMode.STRICT)))
    T.check("sıkılaştırma (yeni sıkı uygulama) uyarı vermez", ImportReview.changes(base, strictOnly).isEmpty())
    val already = AppSettings(appAds = AppAds.encode(mapOf("com.x" to AppMode.EXEMPT)))
    T.check("zaten muaf olan uygulama yeniden uyarı vermez", ImportReview.changes(already, already).isEmpty())
    val code = SettingsCodec.export(exempt)
    val imported = SettingsCodec.import(code, base)
    T.check("kod üzerinden gerçek içe aktarma da yakalanır", imported != null && SensitiveChange.RULES in ImportReview.changes(base, imported))

    T.group("sizma33: test altyapısı — eşzamanlı koşu kilidi")
    val rt = File("run-tests.sh").readText()
    T.check("run-tests.sh ortak jar için kilit alır (iki koşu birbirinin derlemesini silmez)", rt.contains("flock 9") && rt.indexOf("flock 9") < rt.indexOf("rm -f \"\$OUT\""))
}
