package app.dnshizli.selftest

import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.SocketGuard

/**
 * Test birimleri arası yalıtım: süreç geneli tekiller ([FilterRuntime], [SocketGuard]) her birimden önce varsayılana döner. Böylece bir
 * testin bıraktığı süzgeç seviyesi / bayrak / koruma işlevi sonraki testin sonucunu değiştirmez ve testler sırası değişse de aynı sonucu verir.
 * Varsayılana dönmeden bırakılan durum "sızıntı" olarak kaydedilir ve sonda raporlanır (hata sayılmaz: yalıtım zaten sağlanır).
 */
internal object Isolation {
    private var current: String? = null
    // Kaynaklar süreç yapılandırmasıdır: [FilterRuntime.reset] onlara dokunmaz; testler sahte kaynak bırakırsa ilk değere dönülür.
    private val source0 = FilterRuntime.source
    private val fallback0 = FilterRuntime.fallbackSource
    val leaks = LinkedHashMap<String, String>()

    fun enter(unit: String) {
        settle()
        current = unit
    }

    /** Önceki birimin bıraktığı durumu kaydeder ve her şeyi varsayılana döndürür. */
    fun settle() {
        val prev = current
        val key = FilterRuntime.stateKey() + (if (FilterRuntime.source !== source0 || FilterRuntime.fallbackSource !== fallback0) " source" else "") + (if (SocketGuard.protectTcp != null || SocketGuard.protectUdp != null) " socketGuard" else "")
        if (prev != null && key.isNotBlank()) leaks[prev] = key.trim()
        reset()
        current = null
    }

    fun reset() {
        FilterRuntime.reset()
        FilterRuntime.source = source0
        FilterRuntime.fallbackSource = fallback0
        SocketGuard.protectTcp = null
        SocketGuard.protectUdp = null
    }

    fun report() {
        settle()
        if (leaks.isNotEmpty()) println("\nYalıtım: ${leaks.size} birim tekil durumu varsayılana döndürmeden bıraktı (sonraki birimden önce sıfırlandı): " +
            leaks.entries.joinToString("; ") { "${it.key} → ${it.value}" })
    }
}
