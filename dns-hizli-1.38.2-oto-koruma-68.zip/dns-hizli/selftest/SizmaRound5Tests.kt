package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File

/** sizma29: mevcut yöntemlerin iyileştirmeleri — DPI site ailesi belleği, rastgele sahte ad, tireli reklam sözcükleri, liste sürümü saati. */
internal fun runRound5Tests() {
    runFamilyTests()
    runDecoyTests()
    runAdTokenTests()
    runManifestClockTests()
}

private fun runFamilyTests() {
    T.group("sizma29: DPI site ailesi — kardeş alt adlar öğrenilen yöntemle başlar")
    val was = PublicSuffix.ready
    try { familyBody() } finally { PublicSuffix.clear(); if (was) File("app/src/main/assets/filter/psl.txt").takeIf { it.exists() }?.inputStream()?.use { PublicSuffix.install(it) } }
}

private fun familyBody() {
    val psl = File("app/src/main/assets/filter/psl.txt")
    for (mode in listOf("liste yok (kaba kural)", "ortak sonek listesi")) {
        PublicSuffix.clear()
        if (mode != "liste yok (kaba kural)") { if (!psl.exists()) continue; psl.inputStream().use { PublicSuffix.install(it) } }
        val fam = mapOf("img.cdn.ornek.com" to "ornek.com", "www.ornek.com.tr" to "ornek.com.tr", "a.b.ornek.co.uk" to "ornek.co.uk",
            "ornek.com" to "ornek.com", "x.ornek.gov.tr" to "ornek.gov.tr")
        val bad = fam.filter { (k, v) -> Dpi.family(k) != v }
        T.check("[$mode] kayıtlı ad doğru: ${fam.keys.joinToString()}", bad.isEmpty(), bad.keys.joinToString { "$it→${Dpi.family(it)}" })
        T.check("[$mode] IP, IP:port, IPv6, tek etiket ailesizdir", listOf("1.2.3.4:443", "1.2.3.4", "[::1]:443", "2001:db8::1", "localhost", "").all { Dpi.family(it) == null })
    }
    PublicSuffix.clear()
    psl.takeIf { it.exists() }?.inputStream()?.use { PublicSuffix.install(it) }
    T.check("ortak sonek tek başına aile değildir (com.tr)", Dpi.family("com.tr") == null || Dpi.family("com.tr") == "com.tr")

    val p = Dpi.Planner()
    val prior = p.first("hic-gorulmedi.example", Dpi.TLS)
    p.worked("www.ornek.com", Dpi.TLS, 6)
    T.check("kardeş ad (img.ornek.com) ağ önceliği yerine ailenin yöntemiyle (6) başlar", p.first("img.ornek.com", Dpi.TLS) == 6)
    // ağ oyu (prior) her başarıda değişir; aynı oyu alan ama ailesi olmayan (IP anahtarlı) ikiz planlayıcıyla karşılaştırılır
    val twin = Dpi.Planner(); twin.worked("9.9.9.9:443", Dpi.TLS, 6)
    T.check("ilgisiz ad yalnızca ağ oyundan etkilenir, aileden değil", p.first("baska-site.com", Dpi.TLS) == twin.first("baska-site.com", Dpi.TLS) && prior >= 0)
    p.worked("img.ornek.com", Dpi.TLS, 8)
    T.check("adın kendi yöntemi aileden önce gelir (www=6, img=8)", p.first("www.ornek.com", Dpi.TLS) == 6 && p.first("img.ornek.com", Dpi.TLS) == 8)
    T.check("aile en son çalışan yöntemi taşır (yeni kardeş 8 ile başlar)", p.first("cdn.ornek.com", Dpi.TLS) == 8)
    T.check("TLS ailesi HTTP'ye geçmez", p.first("cdn.ornek.com", Dpi.HTTP) == p.first("hic.gorulmedi.example", Dpi.HTTP))
    T.check("denenemeyen uçuş (firstSafe) yalnızca adın kendi kanıtına bakar", p.firstSafe("yeni.ornek.com", Dpi.TLS) == Dpi.TLS_ORDER[0])
    p.worked("1.2.3.4:443", Dpi.TLS, 9)
    T.check("IP anahtarında aile yok: başka IP etkilenmez", p.first("1.2.3.5:443", Dpi.TLS) == p.first("hic-gorulmedi2.example", Dpi.TLS))
    p.failed("img.ornek.com", Dpi.TLS)
    T.check("bir kardeşte tükenme yalnızca o adı siler", p.first("img.ornek.com", Dpi.TLS) == 8 && p.first("www.ornek.com", Dpi.TLS) == 6)
    val exp = p.siteExport()
    val q = Dpi.Planner(); q.siteImport(exp)
    T.check("aile bilgisi kalıcı belleğe (site özeti) yazılır ve geri gelir; ad açık yazılmaz",
        q.first("yepyeni.ornek.com", Dpi.TLS) == 8 && exp.keys.none { it.contains("ornek") })
}

private fun runDecoyTests() {
    T.group("sizma29: sahte ClientHello — her bağlantıda farklı, parmak izi bırakmayan ad")
    val h = testHello("engelli-site.ornek.com")
    val hi = Dpi.Hello().also { Dpi.parseHello(h, h.size, it) }
    val names = (1..50).map { Dpi.fakeHello(h, hi.sniOff, hi.sniLen) }.map { String(it, hi.sniOff, hi.sniLen, Charsets.ISO_8859_1) }
    T.check("50 sahte addan en az 48'i farklı", names.toSet().size >= 48, "${names.toSet().size}")
    T.check("hepsi aynı uzunlukta ve .iana.org alt alanı", names.all { it.length == hi.sniLen && it.endsWith(".iana.org") })
    T.check("sabit 'wwww' kalıbı yok", names.none { it.startsWith("wwww") })
    val a = Dpi.fakeHello(h, hi.sniOff, hi.sniLen, java.util.Random(1)); val b = Dpi.fakeHello(h, hi.sniOff, hi.sniLen, java.util.Random(1))
    T.check("tohumlu üreteçle tekrarlanabilir (testler için)", a.contentEquals(b))
    var outside = 0
    for (i in h.indices) if ((i < hi.sniOff || i >= hi.sniOff + hi.sniLen) && a[i] != h[i]) outside++
    T.check("yalnızca SNI baytları değişir", outside == 0)
    val parts = Dpi.split(Dpi.TLS, 12, h, h.size)
    T.check("yöntem 12 sahte kopyası da rastgele adlı", parts[0].fake?.let { String(it, hi.sniOff, hi.sniLen, Charsets.ISO_8859_1) }?.let { it.endsWith(".iana.org") && !it.startsWith("wwww") } == true)
}

private fun runAdTokenTests() {
    T.group("sizma29: Sıkı seviye sezgisi — tireli ve yeni reklam/izleme sözcükleri")
    val strict = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), emptyList(), riskyTlds = true)
    val normal = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), emptyList(), riskyTlds = false)
    val hit = listOf("ads-cdn.site.com", "cdn-ads.site.com", "tracking-api.app.com", "eu-telemetry.app.net", "ads2-img.site.com",
        "adsense.site.com", "impressions.site.com", "tracker.site.com", "x.adnetwork.site.com", "cdn-tracker3.site.com")
    val miss = hit.filter { strict.verdictOf(it) == FilterVerdict.PASS }
    T.check("yakalanır: ${hit.size} ad", miss.isEmpty(), miss.joinToString())
    val pass = listOf("ad-sso.sirket.com", "pixel-art.site.com", "lads-x.site.com", "uploads-cdn.site.com", "roads-api.site.com", "ads-cdn.com",
        "my-ads.com", "banner-yonetim.site.com", "adsense-yardim.ornek.com", "trackingnumber.kargo.com", "shipment-track.kargo.com", "www.site.com", "api.site.com")
    val over = pass.filter { strict.verdictOf(it) != FilterVerdict.PASS }
    T.check("geçer (aşırı engel yok): ${pass.size} ad", over.isEmpty(), over.joinToString())
    T.check("sezgi yalnız Sıkı seviyede: Basit/Orta'da hepsi geçer", hit.all { normal.verdictOf(it) == FilterVerdict.PASS })
    T.check("kanarya MUST_PASS siteleri Sıkı sezgide de geçer", ListCanary.MUST_PASS.all { strict.verdictOf(it) == FilterVerdict.PASS && strict.verdictOf("www.$it") == FilterVerdict.PASS })
}

private fun runManifestClockTests() {
    T.group("sizma29: liste güncellemesi — gelecekten donma (freeze) koruması")
    val now = 1_800_000_000L
    fun m(v: Long) = ListUpdate.Manifest(v, emptyList())
    val day = 24 * 3600L
    T.check("normal: yeni sürüm kabul, eşit/eski ret (geri dönüş)",
        ListUpdate.isNewer(now - day, m(now), now) && !ListUpdate.isNewer(now, m(now), now) && !ListUpdate.isNewer(now, m(now - 1), now))
    T.check("saatten 29 gün ileri: kabul (geri kalmış saat payı)", ListUpdate.isNewer(now, m(now + 29 * day), now))
    T.check("saatten 31 gün ileri ('2099' sürümü): ret — sonraki güncellemeleri kilitleyemez", !ListUpdate.isNewer(now, m(now + 31 * day), now) && !ListUpdate.isNewer(0, m(4_102_444_800L), now))
    T.check("zaten zehirli kurulu sürüm (5 yıl ileride): pencere içi imzalı sürüm kilidi açar", ListUpdate.isNewer(now + 5 * 365 * day, m(now), now))
    T.check("zehirli durumda da pencere dışı sürüm reddedilir", !ListUpdate.isNewer(now + 5 * 365 * day, m(now + 6 * 365 * day), now))
    T.check("eski çağrı biçimi (saat verilmeden) çalışır", ListUpdate.isNewer(100, m(200)) && !ListUpdate.isNewer(200, m(100)))
}
