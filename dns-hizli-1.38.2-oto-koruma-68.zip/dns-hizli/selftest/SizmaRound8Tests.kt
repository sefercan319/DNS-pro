package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.File

/** sizma32: HTTP/QUIC bölme noktası kayıtlı adın ortasında; gizli izleyici (CNAME) belleği ağ geçidinde de engeller. */
internal fun runRound8Tests() {
    runHttpCutTests()
    runCloakTests()
}

private fun parts2s(p: List<Dpi.Part>) = p.map { String(it.data, Charsets.ISO_8859_1) }

private fun runHttpCutTests() {
    T.group("sizma32: DPI — HTTP Host ve QUIC SNI de kayıtlı adın ortasından bölünür")
    for ((host, word) in listOf("rr5---sn-u0g3uxax3-xncl.googlevideo.com" to "googlevideo", "cdn.uzun-alt-alan.ornek-site.com:8080" to "ornek-site")) {
        val req = "GET /v?id=1 HTTP/1.1\r\nHost: $host\r\nUser-Agent: x\r\n\r\n".toByteArray()
        for (plan in intArrayOf(6, 7, 8)) {
            val p = parts2s(Dpi.split(Dpi.HTTP, plan, req, req.size))
            val hi = Dpi.HttpInfo(); val j = p.joinToString("").toByteArray(Charsets.ISO_8859_1)
            T.check("$host HTTP $plan: hiçbir parça '$word' taşımaz, Host korunur",
                p.none { it.contains(word) } && Dpi.parseHttp(j, j.size, hi) && String(j, hi.valOff, hi.valLen, Charsets.ISO_8859_1).trim() == host, p.joinToString(" | ").take(160))
        }
    }
    val b = "x:443.ornek.com".toByteArray()
    T.check("nameCut: port ve bozuk girdi çökertmez, aralık içinde kalır", listOf("a", "a.b", "[::1]:443", "1.2.3.4:80", "x:443.ornek.com", "").all { s ->
        val bb = s.toByteArray(); val c = Dpi.nameCut(bb, 0, bb.size); bb.isEmpty() || c in 0..bb.size } && Dpi.nameCut(b, 0, b.size) in 0..b.size)
    val q = File("app/src/main/java/app/dnshizli/core/QuicInitial.kt").readText()
    T.check("QUIC CRYPTO yeniden sıralama da aynı kuralı kullanır (Dpi.nameCut)", q.contains("Dpi.nameCut(c.hello, c.sni[0], c.sni[1])"))
}

private fun encName(n: String): ByteArray { val o = java.io.ByteArrayOutputStream(); for (l in n.split('.')) { o.write(l.length); o.write(l.toByteArray()) }; o.write(0); return o.toByteArray() }

private fun cnameAns(q: String, target: String, ip: ByteArray = byteArrayOf(1, 2, 3, 4)): ByteArray {
    val o = java.io.ByteArrayOutputStream()
    val hd = ByteArray(12); Packets.put16(hd, 0, 0x77); Packets.put16(hd, 2, 0x8180); Packets.put16(hd, 4, 1); Packets.put16(hd, 6, 2)
    o.write(hd); o.write(encName(q)); o.write(byteArrayOf(0, 1, 0, 1))
    val t = encName(target)
    o.write(byteArrayOf(0xC0.toByte(), 12, 0, 5, 0, 1, 0, 0, 0, 60, 0, t.size.toByte())); o.write(t)
    o.write(t); o.write(byteArrayOf(0, 1, 0, 1, 0, 0, 0, 60, 0, 4)); o.write(ip)
    return o.toByteArray() + ByteArray(64)
}

private fun runCloakTests() {
    T.group("sizma32: gizli izleyici belleği — CNAME ile yakalanan birinci taraf ad SNI'de de engellenir")
    val clock = longArrayOf(1_000_000L)
    try {
        CloakMemory.clear(); CloakMemory.now = { clock[0] }
        FilterRuntime.source = null
        FilterRuntime.updateNow(FilterLevel.OFF, emptyList(), listOf("izleyici.test"))
        val eng0 = FilterRuntime.engine!!
        T.check("başta birinci taraf ad geçer (listede değil)", eng0.verdictOf("metrik.site.example") == FilterVerdict.PASS)
        val a = cnameAns("metrik.site.example", "t.izleyici.test")
        val n = CnameGuard.guard(a, 0, a.size - 64)
        T.check("DNS cevabı CNAME zinciri yüzünden engellendi", n != a.size - 64 || (Packets.u16(a, 2) and 0xF) != 0 || Packets.u16(a, 6) <= 2)
        val eng = FilterRuntime.engine!!.fork()
        T.check("artık ad doğrudan (SNI/Host, sorgu) engellenir — DNS atlatılsa da", eng.verdictOf("metrik.site.example") == FilterVerdict.LIST && CloakMemory.size == 1)
        T.check("yalnızca tam ad: kardeş/alt adlar etkilenmez", eng.verdictOf("www.site.example") == FilterVerdict.PASS && eng.verdictOf("a.metrik.site.example") == FilterVerdict.PASS)
        val allow = FilterEngine(emptyList(), FilterTier.EMPTY, listOf("metrik.site.example"), listOf("izleyici.test"))
        T.check("kullanıcı izin listesi bellekten önce gelir", allow.verdictOf("metrik.site.example") == FilterVerdict.PASS)
        val clean = cnameAns("cdn.site.example", "edge.cdnsaglayici.example")
        CnameGuard.guard(clean, 0, clean.size - 64)
        T.check("temiz CNAME hatırlanmaz", CloakMemory.size == 1 && eng.verdictOf("cdn.site.example") == FilterVerdict.PASS)
        val reb = cnameAns("nas.site.example", "x.site-cdn.example", byteArrayOf(192.toByte(), 168.toByte(), 1, 5))
        CnameGuard.guard(reb, 0, reb.size - 64)
        T.check("yeniden bağlama (yerel adres) yüzünden engellenen ad gizli izleyici sayılmaz", CloakMemory.size == 1)
        clock[0] += CloakMemory.TTL_MS + 1
        T.check("süre dolunca unutulur (6 sa)", eng.verdictOf("metrik.site.example") == FilterVerdict.PASS)
        clock[0] += 1
        repeat(CloakMemory.CAP + 500) { CloakMemory.remember("t$it.site${it % 7}.example") }
        T.check("bellek sınırlı (${CloakMemory.CAP}), en eskiler atılır", CloakMemory.size == CloakMemory.CAP && eng.verdictOf("t${CloakMemory.CAP + 499}.site${(CloakMemory.CAP + 499) % 7}.example") == FilterVerdict.LIST &&
            eng.verdictOf("t0.site0.example") == FilterVerdict.PASS)
        val t0 = System.nanoTime(); var hits = 0
        repeat(200_000) { if (eng.verdictOf("yok$it.baska.example") != FilterVerdict.PASS) hits++ }
        T.check("dolu bellekle sorgu yolu hızlı (200 bin < 3 sn)", hits == 0 && (System.nanoTime() - t0) / 1_000_000 < 3000)
        FilterRuntime.reset()
        T.check("süzgeç sıfırlanınca bellek temizlenir", CloakMemory.size == 0)
    } finally { CloakMemory.now = { System.currentTimeMillis() }; Isolation.reset() }
}
