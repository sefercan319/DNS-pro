package app.dnshizli.selftest

import kotlin.system.exitProcess

/**
 * Tüm JVM testlerinin giriş noktası (Android gerekmez).
 *   hepsi:            java -cp ... app.dnshizli.selftest.AllTests
 *   seçilenler:       ... AllTests core secure privacy filter harden gfx model ui monkey
 *   bellek raporu:    ... AllTests alloc
 */
object AllTests {
    @JvmStatic
    fun main(args: Array<String>) {
        val which = args.toSet()
        // Her seçilen birimden önce süreç geneli tekiller sıfırlanır (bkz. Isolation): sonuç test sırasına bağlı olmaz.
        fun want(n: String): Boolean { val w = which.isEmpty() || n in which; if (w) Isolation.enter(n); return w }
        if ("bench" in which) {                                       // ölçüm: testlerle karışmaz, tek başına çalışır
            runFilterBench(); runOdohBench()
            exitProcess(0)
        }

        val t0 = System.nanoTime()
        if (want("core")) runCoreTests()
        if (want("secure")) { runSecureTests(); runSniFallbackTests() }
        if (want("odoh")) { println("\nODoH testleri\n"); runOdohTests(); runOdohSimTests() }
        if (want("tcp")) { println("\nTCP katmanı testleri\n"); runTcpTests(); runTcpRtoTests() }
        if (want("privacy")) runPrivacyTests()
        if (want("filter")) runFilterTests()
        if (want("filter")) { runIdnNormalizeTests(); runAdCoverageTests() }
        if (want("harden")) { runHardeningTests(); runFuzzTests(); runNewFuzzTests(); runHealthTests(); runManifestTests() }
        if (want("stage22")) runStage22Tests()
        if (want("gateway")) { println("\nAğ geçidi testleri\n"); runGatewayTests(); runGatewayHardeningTests(); runGatewayDpiHardeningTests(); runGatewayFlowBudgetTests(); runAppAdsGatewayTests(); runDpiMemoryGatewayTests(); runPenGatewayTests(); runBlockRedirectGatewayTests(); runSelectiveQuicTests(); runListedQuicTests(); runMultiSegmentHelloTests(); runDpiExtrasTests(); runDpiListedOnlyTests(); runMitmGatewayTests() }
        if (want("mitm")) { runMitmNameConstraintTests(); runRedTeamMitmTests() }
        if (want("derin")) { runDeepGatewayTests() }
        if (want("sizma")) runGatewayChaosTests()
        if (want("sizma2")) runGatewayAbuseTests()
        if (want("sizma3")) runDpiPropertyTests()
        if (want("sizma4")) runSizmaDnsTests()
        if (want("sizma5")) runSizmaMitmTests()
        if (want("sizma6")) runFeatureFixTests()
        if (want("sizma7")) runQuicEvasionTests()
        if (want("sizma8")) { runHostileH2Tests(); runLaneStormTests() }
        if (want("sizma9")) runSchedulerTests()
        if (want("sizma10")) runGatewayFaultTests()
        if (want("sizma11")) runUdpResilienceTests()
        if (want("sizma12")) runDifferentialTests()
        if (want("sizma13")) runIpv6StatefulTests()
        if (want("sizma14")) runTcpDnsHostileTests()
        if (want("sizma15")) runComplexityAttackTests()
        if (want("sizma16")) runFloodTests()
        if (want("sizma17")) runHeavyLoadTests()
        if (want("sizma18")) runGapTests()
        if (want("sizma20")) runReferenceTests()
        if (want("sizma21")) runPlatformLogicTests()
        if (want("sizma22")) runHuntTests()
        if (want("sizma23")) runFaultTests()
        if (want("sizma24")) runServicePolicyTests()
        if (want("sizma25")) runStaticPlatformChecks()
        if (want("sizma26")) runAuditRound2Tests()
        if (want("sizma27")) runRound3Tests()
        if (want("sizma28")) runRound4Tests()
        if (want("sizma29")) runRound5Tests()
        if (want("sizma30")) runRound6Tests()
        if (want("sizma31")) runRound7Tests()
        if (want("sizma32")) runRound8Tests()
        if (want("sizma33")) runRound9Tests()
        if (want("mitm")) { println("\nTarayıcı kipi (MITM) testleri\n"); runMitmTests() }
        if (want("derin")) { println("\nDerin katman testleri (3x zor)\n"); runDeepDnsTests(); runDeepImmuneTests(); runDeepImmuneExperimentalTests(); runDeepAuditTests(); runDeepExperimentalAuditTests(); runDeepMitmTests(); runDeepSettingsTests() }
        if (want("plan")) { println("\nAğa göre DPI belleği testleri\n"); runPlanTests(); runSiteCheckTests(); runYouTubeAdsTests() }
        if (want("hpke")) { println("\nHPKE çapraz doğrulama testleri\n"); runHpkeInteropTests(); runHpkeConcurrencyTests() }
        if (want("filter")) { runFilterProbeTests() }
        if (want("girdi")) { println("\nDış girdi dayanıklılık testleri\n"); runInputHardeningTests(); runOdohBindingTests(); runHttpFramingTests(); runListUpdateTests(); runListStoreTests(); runSecurityPassTests() }
        if (want("diag")) { println("\nTanılama raporu testleri\n"); runDiagReportTests() }
        if (want("supply")) { println("\nYayın ve depo güvenliği testleri\n"); runSupplyChainTests() }
        if (want("wrap")) runWrapGuardTests()
        if (want("stage24")) { println("\nAşama 24 testleri\n"); runStage24Tests() }
        if (want("stage26")) { println("\nAşama 26 testleri\n"); runStage26Tests() }
        if (want("immune")) { println("\nOtomatik koruma testleri\n"); runImmuneTests() }
        if (want("modules")) { println("\nModül testleri\n"); runModuleTests(); runRecentTests(); runOrbShapeTests(); runLiquidColorTests(); runPackTests(); runMaintenanceTests(); runAdBoostTests(); runGemini2Tests(); runLogLeakTests(); runAuditTests(); runAuditI18nTests(); runAppAdsTests(); runDpiQualityTests(); runTruthfulnessTests(); runBlockRedirectTests(); runBlockedSitesTests(); runPenTests(); runDpiSimTests(); runMobileTests(); runSoundCompatTests(); runCompatTests(); runRegressionTests(); runDeviceProfileTests() }
        if (want("iyilestirme")) { println("\nİyileştirme testleri (1.31)\n"); runImproveTests() }
        if (want("yeni")) { println("\nYeni animasyon ve ses testleri\n"); runNewVisualTests() }
        if (want("gfx")) { println("\nÇizim ve geometri testleri\n"); runGfxTests() }
        if (want("model")) { println("\nModel testleri\n"); runModelTests() }
        if (want("ui")) { println("\nArayüz testleri\n"); runUiTests(); runListTests(); runAdvancedUiTests() }
        if (want("yeni69")) { println("\n1.33 iyileştirme testleri\n"); runImprove69Tests() }
        if (want("yeni134")) { println("\n1.34 kesinti ve engel sayfası testleri\n"); runCut134Tests() }
        if (want("quic")) { println("\nQUIC / DoQ / DoH3 testleri\n"); runQuicTests() }
        if (want("device")) { println("\nCihaz benzetimi testleri\n"); runDeviceTests(); runControlAudit() }
        if (want("fuzz2")) runCodecFuzz()
        if (want("tarama")) { println("\nTarama testleri\n"); runSweepTests(); runBinarySweepTests() }
        if (want("sizma")) { println("\nSızma girişimi testleri\n"); runRedTeamTests() }
        if (want("audit")) { println("\nYerleşim denetimi\n"); runLayoutAudit() }
        if (want("monkey")) { println("\nRastgele kullanım (maymun) testleri\n"); runMonkeyTests() }
        if ("alloc" in which) { println("\nKare başına bellek ayırma\n"); allocReport() }
        Isolation.report()
        T.flush()
        val sec = (System.nanoTime() - t0) / 1_000_000_000.0
        println("\n${T.total} kontrol, ${T.failures} başarısız  (%.1f sn)".format(sec))
        exitProcess(if (T.failures > 0) 1 else 0)
    }
}
