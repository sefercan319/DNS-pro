package app.dnshizli.selftest

import java.io.File

/**
 * Sızma 25 — `platform` paketindeki Android kodu için derleyicisiz statik denetim. Android SDK olmadan derlenemeyen dosyalarda en sık görülen
 * düzenleme hataları yakalanır: eksik import, var olmayan çekirdek sembolü, dengesiz parantez/küme, çift tanım.
 * Derlemenin yerine geçmez; GitHub Actions derlemesinden önce ucuz bir ön eleme.
 */
internal fun runStaticPlatformChecks() {
    val root = File("app/src/main/java/app/dnshizli")
    val core = File(root, "core").walkTopDown().filter { it.isFile && it.extension == "kt" }.toList()
    val plat = File(root, "platform").walkTopDown().filter { it.isFile && it.extension == "kt" }.toList()

    fun strip(src: String): String {          // yorum ve dizgileri boşlukla değiştir (satır sayısı korunur)
        val o = StringBuilder(src.length); var i = 0; val n = src.length
        while (i < n) {
            val c = src[i]
            when {
                src.startsWith("//", i) -> { while (i < n && src[i] != '\n') { o.append(' '); i++ } }
                src.startsWith("/*", i) -> { var d = 0
                    while (i < n) {
                        if (src.startsWith("/*", i)) { d++; o.append("  "); i += 2 }
                        else if (src.startsWith("*/", i)) { d--; o.append("  "); i += 2; if (d == 0) break }
                        else { o.append(if (src[i] == '\n') '\n' else ' '); i++ }
                    } }
                src.startsWith("\"\"\"", i) -> { o.append("   "); i += 3
                    while (i < n && !src.startsWith("\"\"\"", i)) { o.append(if (src[i] == '\n') '\n' else ' '); i++ }
                    if (i < n) { o.append("   "); i += 3 } }
                c == '"' -> { o.append(' '); i++
                    while (i < n && src[i] != '"' && src[i] != '\n') { if (src[i] == '\\' && i + 1 < n) { o.append("  "); i += 2 } else { o.append(' '); i++ } }
                    if (i < n && src[i] == '"') { o.append(' '); i++ } }
                c == '\'' && i + 2 < n && (src[i + 2] == '\'' || (src[i + 1] == '\\' && src.indexOf('\'', i + 2) in (i + 3)..(i + 8))) -> {
                    val e = if (src[i + 1] == '\\') src.indexOf('\'', i + 2) else i + 2
                    repeat(e - i + 1) { o.append(' ') }; i = e + 1 }
                else -> { o.append(c); i++ }
            }
        }
        return o.toString()
    }

    // ---- çekirdekte bildirilen üst düzey adlar ve nesne üyeleri
    val decl = Regex("""^\s*(?:@\w+(?:\([^)]*\))?\s+)*(?:public |internal |private |data |sealed |enum |abstract |open |fun |value |annotation |const |inline )*(?:class|object|interface|typealias)\s+(\w+)""", RegexOption.MULTILINE)
    val topFun = Regex("""^(?:public |internal |inline |private )*fun\s+(?:<[^>]+>\s*)?(?:[\w.<>?, ]+\.)?(\w+)\s*\(""", RegexOption.MULTILINE)
    val topVal = Regex("""^(?:public |internal |private |const )*(?:val|var)\s+(?:[\w.<>?, ]+\.)?(\w+)""", RegexOption.MULTILINE)
    val coreNames = HashSet<String>(); val coreSrc = HashMap<String, String>()
    for (f in core) {
        val t = strip(f.readText()); coreSrc[f.name] = t
        decl.findAll(t).forEach { coreNames.add(it.groupValues[1]) }
        topFun.findAll(t).forEach { coreNames.add(it.groupValues[1]) }
        topVal.findAll(t).forEach { coreNames.add(it.groupValues[1]) }
    }
    // Gövde içi (iç içe) sınıf/nesne adlarını da ekle (import app.dnshizli.core.Outer.Inner için)
    val allCoreText = coreSrc.values.joinToString("\n")

    T.group("Sızma 25 / platform statik denetim: ${plat.size} dosyada dengesiz parantez/küme yok")
    run {
        var bad = ""
        for (f in plat) {
            val t = strip(f.readText())
            val st = ArrayList<Pair<Char, Int>>(); var line = 1
            for (c in t) {
                when (c) {
                    '\n' -> line++
                    '(', '[', '{' -> st.add(c to line)
                    ')', ']', '}' -> {
                        val want = when (c) { ')' -> '('; ']' -> '['; else -> '{' }
                        if (st.isEmpty() || st.last().first != want) { bad += " ${f.name}:$line '$c'"; st.clear(); break }
                        st.removeAt(st.size - 1)
                    }
                }
            }
            if (st.isNotEmpty()) bad += " ${f.name}: açık ${st.last().first} satır ${st.last().second}"
        }
        T.check("tüm platform dosyalarında ( ) [ ] { } dengeli", bad.isEmpty(), bad.take(300))
    }

    T.group("Sızma 25 / platform statik denetim: her `import app.dnshizli.core.X` çekirdekte var")
    run {
        var bad = ""; var count = 0
        for (f in plat) for (m in Regex("""^import app\.dnshizli\.core\.([\w.]+)""", RegexOption.MULTILINE).findAll(f.readText())) {
            count++
            val first = m.groupValues[1].split('.').first()
            if (first != "*" && first !in coreNames) bad += " ${f.name}→$first"
        }
        T.check("$count çekirdek import'u çözülür", bad.isEmpty(), bad.take(300))
    }

    T.group("Sızma 25 / platform statik denetim: kullanılan çekirdek türleri import edilmiş (eksik import yok)")
    run {
        // Yalnızca çekirdekte BÜYÜK harfle başlayan üst düzey sınıf/nesne adları ve platform'da başka yerde tanımlı olmayanlar
        val classNames = HashSet<String>()
        for (t in coreSrc.values) decl.findAll(t).forEach { if (it.groupValues[1][0].isUpperCase()) classNames.add(it.groupValues[1]) }
        val platDecl = HashSet<String>()
        for (f in plat) decl.findAll(strip(f.readText())).forEach { platDecl.add(it.groupValues[1]) }
        // iç içe tanımlar (ör. Tunnel) ve aynı adlı Android/Java sınıfları çakışmasın diye çekirdek adı platformda da tanımlıysa atla
        val ambiguous = setOf("Log", "Context", "Intent", "State", "Result", "Builder", "Check", "Mode", "Kind", "Type", "Event", "Entry", "Plan", "Act", "Change", "Do")
        var bad = ""; var checked = 0
        for (f in plat) {
            val raw = f.readText(); val t = strip(raw)
            val imports = Regex("""^import ([\w.]+)""", RegexOption.MULTILINE).findAll(raw).map { it.groupValues[1] }.toList()
            val wildcard = imports.any { it == "app.dnshizli.core.*" }
            if (wildcard) continue
            val importedSimple = imports.map { it.substringAfterLast('.') }.toSet()
            val pkgCore = raw.contains(Regex("""^package app\.dnshizli\.core""", RegexOption.MULTILINE))
            if (pkgCore) continue
            val used = HashSet<String>()
            for (m in Regex("""(?<![\w.])([A-Z]\w{2,})\b""").findAll(t)) used.add(m.groupValues[1])
            for (u in used) {
                if (u !in classNames || u in platDecl || u in importedSimple || u in ambiguous) continue
                // başka platform dosyasında/paket düzeyinde aynı pakette (app.dnshizli.platform) tanımlı mı? platDecl bunu kapsar.
                checked++
                bad += " ${f.name}:$u"
            }
        }
        T.check("kullanılıp import edilmeyen çekirdek türü yok", bad.isEmpty(), bad.take(500))
    }

    T.group("Sızma 25 / platform statik denetim: platform'un çağırdığı çekirdek nesne üyeleri var (ServicePolicy, BootPolicy, IntentPolicy, KeyVault ve diğerleri)")
    run {
        val objs = listOf("ServicePolicy", "BootPolicy", "IntentPolicy", "KeyVault", "ListStore", "FilterRuntime", "Journal")
        var bad = ""; var n = 0
        for (o in objs) {
            val body = coreSrc.values.firstOrNull { Regex("""\bobject\s+$o\b""").containsMatchIn(it) } ?: continue
            for (f in plat) {
                val t = strip(f.readText())
                for (m in Regex("""\b$o\.(\w+)""").findAll(t)) {
                    n++
                    val member = m.groupValues[1]
                    if (!Regex("""\b(?:fun|val|var|const val|class|object|interface|enum class)\s+(?:<[^>]+>\s*)?(?:[\w.<>?, ]+\.)?$member\b""").containsMatchIn(body) &&
                        !Regex("""\b$member\s*[,;)]""").containsMatchIn(body) && !Regex("""^\s*$member\b""", RegexOption.MULTILINE).containsMatchIn(body)) {
                        bad += " ${f.name}:$o.$member"
                    }
                }
            }
        }
        T.check("$n çağrı/erişim çözülür", bad.isEmpty(), bad.take(400))
    }

    T.group("Sızma 25 / platform statik denetim: bir dosyada aynı özel işlev imzası iki kez tanımlı değil; servis hâlâ ServicePolicy'ye devrediyor")
    run {
        var bad = ""
        for (f in plat) {
            val t = strip(f.readText())
            val seen = HashMap<String, Int>()
            for (m in Regex("""^\s*(?:private |internal |override |protected |public )*fun\s+(\w+)\s*\(([^)]*)\)""", RegexOption.MULTILINE).findAll(t)) {
                val sig = m.groupValues[1] + "(" + m.groupValues[2].split(',').joinToString(",") { it.substringAfter(':').trim().substringBefore('=').trim() } + ")"
                seen[sig] = (seen[sig] ?: 0) + 1
            }
            // iç içe sınıflarda aynı imza meşru olabilir; yalnızca DnsVpnService (tek büyük sınıf) için sıkı denetim
            if (f.name == "DnsVpnService.kt") for ((k, v) in seen) if (v > 1 && !k.startsWith("onReceive") && !k.startsWith("close") && !k.startsWith("run(")) bad += " $k×$v"
        }
        T.check("DnsVpnService.kt'de çift işlev tanımı yok", bad.isEmpty(), bad.take(300))
        val svc = strip(File(root, "platform/DnsVpnService.kt").readText())
        for (name in listOf("triesFor", "msFor", "isDowngrade", "backupFor", "nextRing", "gwWanted", "gwLevelFor", "pauseUntil", "pauseRemainingMs"))
            T.check("servis $name kararını ServicePolicy'ye bırakır", svc.contains("ServicePolicy.$name"))
        T.check("ağ geçidi vanası ve yeniden deneme çizelgesi çekirdekte: servis GwValve/RetrySchedule'a devreder, eski sayaçlar kalmadı",
            svc.contains("gwValve.observe") && svc.contains("gwValve.onTrip") && svc.contains("RetrySchedule.delayFor") &&
            !svc.contains("gwBadTicks") && !svc.contains("gwDpiBadTicks") && !svc.contains("gwTripCount") && !svc.contains("RETRY_DELAYS"))
        val tun = File(root, "platform/Tunnel.kt")
        T.check("tünel okuyucu ayrı dosyada (Tunnel.kt); servis içinde sınıf tanımı kalmadı", tun.exists() && strip(tun.readText()).contains("internal class Tunnel(") && !Regex("""class\s+Tunnel\s*\(""").containsMatchIn(svc))
        T.check("soket koruma çekirdekte (ProtectedSockets): servis TLS/UDP/bootstrap soketlerini kendisi korumaz (korumasız soketle bağlanamaz)",
            svc.contains("ProtectedSockets(") && svc.contains("socks.bootstrapUdp()") && !svc.contains("TLS soketi korunamadı"))
    }
}
