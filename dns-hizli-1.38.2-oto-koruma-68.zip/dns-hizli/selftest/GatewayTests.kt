package app.dnshizli.selftest

import app.dnshizli.core.*
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

internal val CLI4 = byteArrayOf(10, 111, 222.toByte(), 1)
internal val LO4 = byteArrayOf(127, 0, 0, 1)
internal const val F_FIN = Gw.FIN
internal const val F_SYN = Gw.SYN
internal const val F_RST = Gw.RST
internal const val F_PSH = Gw.PSH
internal const val F_ACK = Gw.ACK
internal const val F_URG_TEST = 0x20

internal class GSeg(val flags: Int, val seq: Int, val ack: Int, val win: Int, val data: ByteArray, val mss: Int, val ok: Boolean, val sport: Int, val dport: Int)

internal class GRig(
    memBudget: Int = 24 * 1024 * 1024, ttl: (java.net.Socket, Int) -> Boolean = { _, _ -> false }, udpTtl: (java.net.DatagramSocket, Int) -> Boolean = { _, _ -> false },
    fake: ((java.net.Socket, ByteArray, ByteArray) -> Int)? = null,
    /** Soket koruma (VpnService.protect) davranışı; testler atan/false dönen sürümler verir. */
    protect: (java.net.Socket) -> Boolean = { true },
) {
    val q = LinkedBlockingQueue<ByteArray>()
    /** Yük testleri: tünele yazılan paket önce buraya gelir; true dönerse tüketilmiştir ve [q]'ya girmez. */
    @Volatile var tap: ((ByteArray) -> Boolean)? = null
    /** Hata enjeksiyonu: tünele yazılan her paket için bir istisna döndürür (null = sorunsuz yazılır). Gerçek VpnService yazması hata yutar; geçit buna güvenmemeli. */
    @Volatile var outFault: ((ByteArray) -> Throwable?)? = null
    val faults = AtomicInteger()
    val gw = Gateway({ b, o, l ->
        val pk = b.copyOfRange(o, o + l)
        if (tap?.invoke(pk) == true) return@Gateway
        val f = outFault
        if (f != null) { val e = f(pk); if (e != null) { faults.incrementAndGet(); throw e } }
        q.add(pk)
    }, protectTcp = protect, setTtl = ttl, setUdpTtl = udpTtl, fakeSend = fake, memBudget = memBudget)
    init { gw.config.dpiOnLocal = true; gw.start() }      // sahte sunucular loopback'te: yerel hedef muafiyeti testlerde kapalı
    fun close() = gw.stop()
}

internal val portCounter = AtomicInteger(41000)

internal class GCli(val r: GRig, val dport: Int, val v6: Boolean = false, val dst: ByteArray = LO4) {
    // 16 bit alanda taşmasın: sayaç 65535'i geçince paket alanı kesilir, yanıtlar eşleşmez (test sayacı tüm gruplarda paylaşılır).
    val sport = 1024 + Math.floorMod(portCounter.incrementAndGet(), 64512)   // 1024..65535; 60 bin SYN'lik sel, önceki dürüst akışın portuna sarmasın
    val src: ByteArray = if (v6) SelfTest.CLIENT6 else CLI4
    var seq = 7000
    var rcv = 0
    var win = 65535
    val buf = ByteArray(2048)
    /** Testler için: istemcinin yazdığı her paket gönderilmeden önce bu işlevden geçer (ör. IPv6 uzantı başlığı eklemek, uzunluk alanını bozmak). */
    @Volatile var wrap: ((ByteArray) -> ByteArray)? = null

    fun send(flags: Int, data: ByteArray = ByteArray(0), mss: Int = 0, seqNo: Int = seq, ackNo: Int = rcv) {
        val n = Gw.tcp(buf, v6, src, dst, sport, dport, seqNo, ackNo, flags, win, data, 0, data.size, mss)
        val pk = buf.copyOf(n)
        val w = wrap
        val o = if (w != null) w(pk) else pk
        r.gw.onPacket(o, o.size)
    }

    fun next(ms: Long = 3000): GSeg? {
        val end = System.currentTimeMillis() + ms
        while (true) {
            val left = end - System.currentTimeMillis()
            if (left <= 0) return null
            val p = r.q.poll(left, TimeUnit.MILLISECONDS) ?: return null
            val ver = (p[0].toInt() ushr 4) and 0xF
            val ip = if (ver == 6) 40 else (p[0].toInt() and 0xF) * 4
            val proto = if (ver == 6) p[6].toInt() and 0xFF else p[9].toInt() and 0xFF
            if (proto != 6 || Packets.u16(p, ip) != dport || Packets.u16(p, ip + 2) != sport) continue
            val doff = (p[ip + 12].toInt() and 0xF0) ushr 2
            var mss = 0
            if (doff >= 24 && p[ip + 20].toInt() == 2) mss = Packets.u16(p, ip + 22)
            return GSeg(p[ip + 13].toInt() and 0xFF, Packets.i32(p, ip + 4), Packets.i32(p, ip + 8), Packets.u16(p, ip + 14),
                p.copyOfRange(ip + doff, p.size), mss, Gw.checksumOk(p, p.size), dport, sport)
        }
    }

    fun connect(): GSeg? {
        send(F_SYN, mss = 1460); seq++
        val sa = next() ?: return null
        if (sa.flags != (F_SYN or F_ACK)) return sa
        rcv = sa.seq + 1
        send(F_ACK)
        return sa
    }

    fun write(d: ByteArray) { send(F_ACK or F_PSH, d); seq += d.size }

    /** [read] gibi, ama sıra dışı gelen segmentleri saklayıp birleştirir (gerçek bir TCP alıcısı gibi; büyük aktarımlar için). */
    fun readAll(n: Int, ms: Long): ByteArray {
        val o = ByteArrayOutputStream()
        val held = HashMap<Int, ByteArray>()
        val end = System.currentTimeMillis() + ms
        while (o.size() < n && System.currentTimeMillis() < end) {
            val s = next(end - System.currentTimeMillis()) ?: break
            if (s.flags and F_RST != 0) break
            if (s.data.isNotEmpty()) held[s.seq] = s.data
            // Birleştir: rcv'yi kapsayan (örtüşen yeniden gönderimler dahil) segmentin yeni kısmı alınır.
            while (true) {
                val hit = held.entries.firstOrNull { (rcv - it.key) >= 0 && (rcv - it.key) < it.value.size } ?: break
                val skip = rcv - hit.key
                o.write(hit.value, skip, hit.value.size - skip); rcv += hit.value.size - skip
                held.remove(hit.key)
            }
            held.entries.removeAll { (it.key + it.value.size - rcv) <= 0 }
            send(F_ACK)
            if (s.flags and F_FIN != 0 && s.seq + s.data.size == rcv) { rcv++; send(F_ACK); break }
        }
        return o.toByteArray()
    }

    /** [n] bayt gelene dek veri segmentlerini toplar ve hepsini onaylar. Fin görürse durur. */
    fun read(n: Int, ms: Long = 4000): ByteArray {
        val o = ByteArrayOutputStream()
        val end = System.currentTimeMillis() + ms
        while (o.size() < n && System.currentTimeMillis() < end) {
            val s = next(end - System.currentTimeMillis()) ?: break
            if (s.flags and F_RST != 0) break
            if (s.seq != rcv) { send(F_ACK); continue }
            if (s.data.isNotEmpty()) { o.write(s.data); rcv += s.data.size; send(F_ACK) }
            if (s.flags and F_FIN != 0) { rcv++; send(F_ACK); break }
        }
        return o.toByteArray()
    }
}

internal class Srv(val handler: (Socket) -> Unit) {
    val ss = ServerSocket(0, 50, InetAddress.getByAddress(LO4))
    val port get() = ss.localPort
    val accepted = AtomicInteger()
    init {
        Thread({
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (_: Exception) { break }
                accepted.incrementAndGet()
                Thread({ try { handler(s) } catch (_: Exception) {} finally { try { s.close() } catch (_: Exception) {} } }).also { it.isDaemon = true }.start()
            }
        }, "srv").also { it.isDaemon = true }.start()
    }
    fun close() = ss.close()
}

/** Geçerli görünümlü bir TLS ClientHello (tek kayıt, SNI + dolgu). */
internal fun testHello(sni: String, pad: Int = 120): ByteArray {
    val name = sni.toByteArray()
    val sniExt = ByteArray(4 + 5 + name.size)
    Packets.put16(sniExt, 0, 0); Packets.put16(sniExt, 2, 5 + name.size)
    Packets.put16(sniExt, 4, 3 + name.size); sniExt[6] = 0; Packets.put16(sniExt, 7, name.size)
    System.arraycopy(name, 0, sniExt, 9, name.size)
    val padExt = ByteArray(4 + pad); Packets.put16(padExt, 0, 21); Packets.put16(padExt, 2, pad)
    val ext = sniExt + padExt
    val body = ByteArrayOutputStream()
    body.write(byteArrayOf(3, 3)); body.write(ByteArray(32) { it.toByte() })
    body.write(0)                                              // oturum kimliği yok
    body.write(byteArrayOf(0, 2, 0x13, 0x01)); body.write(byteArrayOf(1, 0))
    body.write(byteArrayOf((ext.size ushr 8).toByte(), ext.size.toByte())); body.write(ext)
    val b = body.toByteArray()
    val hs = ByteArray(4 + b.size); hs[0] = 1; hs[1] = 0; Packets.put16(hs, 2, b.size); System.arraycopy(b, 0, hs, 4, b.size)
    val rec = ByteArray(5 + hs.size); rec[0] = 0x16; rec[1] = 3; rec[2] = 1; Packets.put16(rec, 3, hs.size); System.arraycopy(hs, 0, rec, 5, hs.size)
    return rec
}

internal fun readFully(s: Socket, n: Int, ms: Int = 3000): ByteArray {
    s.soTimeout = ms
    val b = ByteArray(n); var o = 0
    while (o < n) { val r = s.getInputStream().read(b, o, n - o); if (r < 0) break; o += r }
    return b.copyOf(o)
}

fun runGatewayTests() {
    T.group("Ağ geçidi: çok noktaya / genel yayın ayrımı")
    fun ip4(a: Int, b: Int, c: Int, d: Int) = byteArrayOf(a.toByte(), b.toByte(), c.toByte(), d.toByte())
    T.check("224.0.0.251 (mDNS) ve 239.255.255.250 (SSDP) çok noktaya sayılır", isMulticastOrBroadcast(false, ip4(224, 0, 0, 251)) && isMulticastOrBroadcast(false, ip4(239, 255, 255, 250)))
    T.check("255.255.255.255 genel yayındır", isMulticastOrBroadcast(false, ip4(255, 255, 255, 255)))
    T.check("255.1.2.255 tam genel yayın değildir (eski koşul yanlışlıkla eliyordu)", !isMulticastOrBroadcast(false, ip4(255, 1, 2, 255)))
    T.check("sıradan adresler geçer: 1.1.1.1, 10.0.0.5, 192.168.1.255, 223.255.255.255", listOf(ip4(1, 1, 1, 1), ip4(10, 0, 0, 5), ip4(192, 168, 1, 255), ip4(223, 255, 255, 255)).none { isMulticastOrBroadcast(false, it) })
    val v6m = ByteArray(16).also { it[0] = 0xFF.toByte(); it[1] = 0x02; it[15] = 1 }
    val v6u = ByteArray(16).also { it[0] = 0x20; it[1] = 0x01; it[15] = 1 }
    T.check("IPv6: ff02::1 çok noktaya, 2001::1 sıradan", isMulticastOrBroadcast(true, v6m) && !isMulticastOrBroadcast(true, v6u))
    T.group("Ağ geçidi: paket yazıcı ve ayrıştırıcılar")
    run {
        val b = ByteArray(2048)
        val data = "merhaba".toByteArray()
        val n = Gw.tcp(b, false, CLI4, LO4, 1234, 80, 1, 2, F_ACK or F_PSH, 4000, data, 0, data.size, 1460)
        T.check("IPv4 TCP: IP ve TCP sağlama toplamı geçerli", Gw.checksumOk(b.copyOf(n), n) && n == 20 + 24 + 7)
        val n6 = Gw.tcp(b, true, SelfTest.CLIENT6, SelfTest.FAKE6, 1234, 80, 1, 2, F_ACK, 4000, null, 0, 0)
        T.check("IPv6 TCP: sağlama toplamı geçerli", Gw.checksumOk(b.copyOf(n6), n6) && n6 == 60)
        val u = Gw.udp(b, false, CLI4, LO4, 5000, 53, data, 0, data.size)
        T.check("IPv4 UDP: sağlama toplamı geçerli", Gw.checksumOk(b.copyOf(u), u) && u == 20 + 8 + 7)
        val u6 = Gw.udp(b, true, SelfTest.CLIENT6, SelfTest.FAKE6, 5000, 53, data, 0, data.size)
        T.check("IPv6 UDP: sağlama toplamı geçerli", Gw.checksumOk(b.copyOf(u6), u6))
        val q = ByteQueue(1000)
        q.add(ByteArray(600) { 1 }, 0, 600); q.drop(300); q.add(ByteArray(600) { 2 }, 0, 600)
        T.check("ByteQueue: sınır, baştan atma ve kopyalama", q.size == 900 && q.free == 100 && q.copy(299, ByteArray(2), 0, 2).let { true })
        val t = ByteArray(2); q.copy(299, t, 0, 2)
        T.check("ByteQueue: sıra korunur", t[0].toInt() == 1 && t[1].toInt() == 2)
        val m = MemBudget(1000)
        val qa = ByteQueue(800, m); val qb = ByteQueue(800, m)
        T.check("ortak tavan: ilk kuyruk kendi sınırına kadar alır", qa.add(ByteArray(900), 0, 900) == 800 && m.used == 800)
        T.check("ortak tavan: ikinci kuyruk yalnızca kalanı alır", qb.free == 200 && qb.add(ByteArray(500), 0, 500) == 200 && m.used == 1000)
        T.check("ortak tavan dolunca kuyruk 0 bayt kabul eder", qa.free == 0 && qb.free == 0 && qb.add(ByteArray(1), 0, 1) == 0)
        qa.drop(300)
        T.check("atılan bayt tavana geri döner", m.used == 700 && qb.free == 300)
        qa.clear(); qb.clear()
        T.check("kapanınca tüm bellek geri verilir", m.used == 0 && qa.free == 800)
    }

    T.group("DPI: SNI / Host ayrıştırma ve bölme yöntemleri")
    run {
        val h = testHello("blocked.example.org")
        val info = Dpi.Hello()
        T.check("TLS ClientHello sınıflanır", Dpi.classify(h, h.size) == Dpi.TLS && Dpi.tlsNeed(h, h.size) == h.size)
        T.check("SNI okunur", Dpi.parseHello(h, h.size, info) && info.host(h) == "blocked.example.org")
        T.check("eksik ClientHello'da SNI bulunamaz ama çökmez", !Dpi.parseHello(h, 40, info))
        T.check("bozuk girdilerde çökmez", (0 until 300).all { i -> val z = ByteArray(i) { (it * 31 + i).toByte() }; if (i > 0) z[0] = 0x16; Dpi.parseHello(z, z.size, info); true })
        var allSame = true; var multi = true
        for (p in 0 until Dpi.TLS_PLANS) {
            val parts = Dpi.split(Dpi.TLS, p, h, h.size)
            val joined = parts.fold(ByteArray(0)) { a, x -> a + x.data }
            if (p !in Dpi.TLS_RECORD_SPLIT_PLANS) allSame = allSame && joined.contentEquals(h)
            multi = multi && parts.size >= 2
        }
        T.check("TLS yöntem 0 ve 2: birleşince bayt bayt aynı, birden çok parça", allSame && multi)
        val parts1 = Dpi.split(Dpi.TLS, 1, h, h.size)
        val j1 = parts1.fold(ByteArray(0)) { a, x -> a + x.data }
        val len1 = Packets.u16(j1, 3)
        val rec2 = 5 + len1
        T.check("TLS yöntem 1: iki geçerli kayıt, yükler birleşince özgün el sıkışma",
            j1[0].toInt() == 0x16 && j1[rec2].toInt() == 0x16 && 5 + len1 + 5 + Packets.u16(j1, rec2 + 3) == j1.size &&
                (j1.copyOfRange(5, rec2) + j1.copyOfRange(rec2 + 5, j1.size)).contentEquals(h.copyOfRange(5, h.size)))
        T.check("TLS yöntem 1: kayıt sınırı SNI içinde (DPI adı tek kayıtta göremez)",
            rec2 > info.also { Dpi.parseHello(h, h.size, it) }.sniOff && rec2 < info.sniOff + info.sniLen + 1)
        T.check("TLS yöntem 2 ve 3: acil veri bayrağı var", Dpi.split(Dpi.TLS, 2, h, h.size).any { it.oobAfter } && Dpi.split(Dpi.TLS, 3, h, h.size).any { it.oobAfter })

        val req = "GET /yol HTTP/1.1\r\nHost: Engelli.Ornek.com:8080\r\nUser-Agent: x\r\n\r\n".toByteArray()
        val hi = Dpi.HttpInfo()
        T.check("HTTP sınıflanır, Host okunur (küçük harf, port atılır)", Dpi.classify(req, req.size) == Dpi.HTTP && Dpi.parseHttp(req, req.size, hi) && Dpi.httpHost(req, hi) == "engelli.ornek.com" && hi.get)
        T.check("HTTP başlık sonu bulunur", Dpi.httpEnd(req, req.size) == req.size && Dpi.httpEnd(req, req.size - 2) < 0)
        for (p in 0 until Dpi.HTTP_PLANS) {
            val ps = Dpi.split(Dpi.HTTP, p, req, req.size)
            val j = String(ps.fold(ByteArray(0)) { a, x -> a + x.data }, Charsets.ISO_8859_1)
            val norm = j.replace("hOsT:", "Host:").replace("Host:\t", "Host: ").replace("HOST", "Host")
            T.check("HTTP yöntem $p: ${ps.size} parça, anlam aynı (Host başlığı hâlâ geçerli)", ps.size >= 2 && Dpi.httpHost(j.toByteArray(Charsets.ISO_8859_1), Dpi.HttpInfo().also { Dpi.parseHttp(j.toByteArray(Charsets.ISO_8859_1), j.length, it) }.let { Dpi.HttpInfo().also { x -> Dpi.parseHttp(j.toByteArray(Charsets.ISO_8859_1), j.length, x) } }) == "engelli.ornek.com" && norm.length >= req.size - 1)
        }
        T.check("bilinmeyen protokol sınıflanmaz", Dpi.classify("SSH-2.0".toByteArray(), 7) == Dpi.NONE && Dpi.classify(byteArrayOf(1, 2), 2) == Dpi.NONE)
        val pl = Dpi.Planner(cap = 3)
        pl.worked("a", Dpi.TLS, 2); pl.worked("b", Dpi.TLS, 1); pl.worked("c", Dpi.TLS, 1); pl.worked("d", Dpi.TLS, 3)
        T.check("Planner: ilk deneme TLS'te 1, HTTP'de 0; öğrenilen hatırlanır, kapasite aşılınca en eski atılır",
            pl.first("zzz", Dpi.TLS) == 1 && pl.first("zzz", Dpi.HTTP) == 0 && pl.first("d", Dpi.TLS) == 3 && pl.first("a", Dpi.TLS) == 1)
        T.check("Planner: TLS sırası 1 → 0 → 5 → 3 → 2 → 6 → 8 → 14 → 7 → 4 → 9 → 10 → 11 → 12 → 13 → 15 → son, HTTP sırası 0..8", pl.next(Dpi.TLS, 1) == 0 && pl.next(Dpi.TLS, 0) == 5 && pl.next(Dpi.TLS, 5) == 3 && pl.next(Dpi.TLS, 3) == 2 &&
            pl.next(Dpi.TLS, 2) == 6 && pl.next(Dpi.TLS, 6) == 8 && pl.next(Dpi.TLS, 8) == 14 && pl.next(Dpi.TLS, 14) == 7 && pl.next(Dpi.TLS, 7) == 4 && pl.next(Dpi.TLS, 4) == 9 && pl.next(Dpi.TLS, 9) == 10 &&
            pl.next(Dpi.TLS, 10) == 11 && pl.next(Dpi.TLS, 11) == 12 && pl.next(Dpi.TLS, 12) == 13 && pl.next(Dpi.TLS, 13) == 15 && pl.next(Dpi.TLS, 15) < 0 && pl.next(Dpi.HTTP, 0) == 1 && pl.next(Dpi.HTTP, 7) == 8 && pl.next(Dpi.HTTP, 8) < 0)
        val dis = Dpi.split(Dpi.TLS, 4, h, h.size)
        T.check("TLS yöntem 4 (disorder): ilk bayt düşük TTL'li, birleşince veri aynı", dis.size == 3 && dis[0].lowTtl && dis[0].data.size == 1 && !dis[1].lowTtl &&
            dis.fold(ByteArray(0)) { a, x -> a + x.data }.contentEquals(h))
        T.check("DoH ad listesi: alt alan dahil, benzer ad değil", Dpi.isDohHost("dns.google") && Dpi.isDohHost("mozilla.cloudflare-dns.com") && !Dpi.isDohHost("notdns.google") && !Dpi.isDohHost("example.com"))
    }

    T.group("Ağ geçidi: TCP aktarma (gerçek loopback soketleriyle)")
    run {
        val r = GRig()
        val echo = Srv { s -> val i = s.getInputStream(); val o = s.getOutputStream(); val b = ByteArray(4096); while (true) { val n = i.read(b); if (n < 0) break; o.write(b, 0, n); o.flush() } }
        val c = GCli(r, echo.port)
        val sa = c.connect()
        T.check("SYN'e SYN+ACK: ack ilerler, MSS seçeneği, sağlama toplamı geçerli", sa != null && sa.flags == (F_SYN or F_ACK) && sa.ack == 7001 && sa.mss in 536..1460 && sa.ok)
        c.write("merhaba dünya".toByteArray())
        val got = c.read("merhaba dünya".toByteArray().size)
        T.check("veri sunucuya gitti ve yankısı istemciye döndü", String(got) == "merhaba dünya")
        c.send(F_FIN or F_ACK); c.seq++
        val fin = c.read(1, 2500)
        T.check("istemci kapanınca sunucu kapanır ve FIN gelir", fin.isEmpty())
        Thread.sleep(300)
        c.send(F_ACK)
        T.check("akış sayısı düşer", run { var n = 0; while (n++ < 60 && r.gw.stats().tcpFlows != 0) Thread.sleep(100); r.gw.stats().tcpFlows == 0 })
        echo.close(); r.close()
    }
    run {
        val r = GRig()
        val dead = ServerSocket(0, 1, InetAddress.getByAddress(LO4)); val p = dead.localPort; dead.close()
        val c = GCli(r, p)
        c.send(F_SYN, mss = 1460)
        val s = c.next()
        T.check("kapalı porta bağlanma: istemci RST alır (bağlandı sanılmaz)", s != null && s.flags and F_RST != 0 && s.ack == 7001)
        T.check("bağlanma hatası sayılır", r.gw.stats().connectFail >= 1)
        // bilinmeyen akışa gelen veri RST ile karşılanır
        val c2 = GCli(r, p); c2.rcv = 5; c2.send(F_ACK or F_PSH, "x".toByteArray())
        val s2 = c2.next()
        T.check("bilinmeyen bağlantıya veri: RST", s2 != null && s2.flags and F_RST != 0)
        r.close()
    }
    run {
        val r = GRig()
        val big = ByteArray(400_000) { (it * 7 + it / 251).toByte() }
        val srv = Srv { s -> s.getOutputStream().write(big); s.getOutputStream().flush(); s.shutdownOutput(); Thread.sleep(500) }
        val c = GCli(r, srv.port)
        c.connect()
        val got = c.read(big.size, 10_000)
        T.check("400 KB indirme: sıra ve içerik bozulmadan geldi", got.size == big.size && got.contentEquals(big))
        srv.close(); r.close()
    }
    run {
        val r = GRig()
        val big = ByteArray(300_000) { (it * 13 + 5).toByte() }
        val recv = ByteArrayOutputStream()
        val done = java.util.concurrent.CountDownLatch(1)
        val srv = Srv { s -> val i = s.getInputStream(); val b = ByteArray(8192); while (true) { val n = i.read(b); if (n < 0) break; synchronized(recv) { recv.write(b, 0, n) } }; done.countDown() }
        val c = GCli(r, srv.port)
        c.connect()
        // pencereye uyarak gönder
        var sent = 0
        var una = c.seq
        val start = System.currentTimeMillis()
        var peer = 65535
        while (sent < big.size && System.currentTimeMillis() - start < 15_000) {
            val room = peer - (c.seq - una)
            if (room > 0) {
                val n = minOf(1400, big.size - sent, room)
                c.write(big.copyOfRange(sent, sent + n)); sent += n
            }
            while (true) {
                val s = c.next(if (room > 0) 1 else 200) ?: break
                if (s.flags and F_ACK != 0 && Gw.seqLe(una, s.ack)) { una = s.ack; peer = s.win }
            }
        }
        c.send(F_FIN or F_ACK); c.seq++
        T.check("300 KB yükleme pencere sınırına uyularak tamamlandı", sent == big.size && done.await(5, TimeUnit.SECONDS) && synchronized(recv) { recv.toByteArray().contentEquals(big) })
        srv.close(); r.close()
    }
    run {
        val r = GRig()
        val srv = Srv { s -> s.getOutputStream().write("220 hoş geldin\r\n".toByteArray()); s.getOutputStream().flush(); Thread.sleep(800) }
        val c = GCli(r, srv.port)
        c.connect()
        T.check("önce sunucunun konuştuğu protokol (SMTP benzeri) çalışır", String(c.read(18, 3000)).startsWith("220 hoş"))
        srv.close(); r.close()
    }
    run {
        // yitik segment: istemci bir veri segmentini 'kaybeder'; üç yinelenen ACK ile yeniden gönderilir
        val r = GRig()
        val data = ByteArray(6000) { (it % 251).toByte() }
        val srv = Srv { s -> s.getOutputStream().write(data); s.getOutputStream().flush(); Thread.sleep(2500) }
        val c = GCli(r, srv.port)
        c.connect()
        var lost = false; val o = ByteArrayOutputStream(); val end = System.currentTimeMillis() + 6000
        var lostSeq = 0; var segN = 0
        while (o.size() < data.size && System.currentTimeMillis() < end) {
            val s = c.next(1500) ?: break
            if (s.data.isEmpty()) continue
            if (!lost && segN++ == 2) { lost = true; lostSeq = s.seq; continue }                  // 3. veri segmentini düşür
            if (s.seq == c.rcv) { o.write(s.data); c.rcv += s.data.size }
            c.send(F_ACK)
        }
        T.check("kayıp segment yeniden gönderilir, akış eksiksiz tamamlanır (zamanlayıcı ya da yinelenen ACK)", lost && o.toByteArray().contentEquals(data), "lost=$lost lostSeq=$lostSeq got=${o.size()}")
        srv.close(); r.close()
    }

    T.group("Ağ geçidi: DPI atlatma ve otomatik yöntem seçimi")
    run {
        val r = GRig()
        r.gw.config.dpi = true
        r.gw.planner.worked("engelli.example.net", Dpi.TLS, 0)                    // yalnızca TCP bölme (kayıt bütün)
        val hello = testHello("engelli.example.net")
        val seen = LinkedBlockingQueue<ByteArray>()
        val srv = Srv { s -> val b = readFully(s, hello.size, 1500); seen.add(b); s.getOutputStream().write(TLS_REPLY); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        val resp = c.read(12)
        val s0 = seen.poll(3, TimeUnit.SECONDS)
        T.check("DPI açık: ClientHello bölünerek gönderilir, sunucu baytları eksiksiz ve aynı sırada alır", resp.contentEquals(TLS_REPLY) && s0 != null && s0.contentEquals(hello), "resp=${resp.size} s0=${s0?.size} hello=${hello.size} st=${r.gw.stats()}")
        T.check("bölme sayılır, yeniden deneme gerekmedi", r.gw.stats().split == 1L && r.gw.stats().retried == 0L)
        srv.close(); r.close()
    }
    run {
        // Varsayılan ilk yöntem: TLS kaydı bölme (+ TCP bölme). Sunucu 5 bayt fazla (ikinci kaydın başlığı) alır; iki kaydın yükü birleşince özgün veri çıkar.
        val r = GRig()
        r.gw.config.dpi = true
        val hello = testHello("engelli.example.net")
        val seen = LinkedBlockingQueue<ByteArray>()
        val srv = Srv { s -> val b = readFully(s, hello.size + 5, 1500); seen.add(b); s.getOutputStream().write(TLS_REPLY); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        val resp = c.read(12)
        val b = seen.poll(3, TimeUnit.SECONDS)
        var joined = ByteArray(0)
        if (b != null) {
            val l1 = Packets.u16(b, 3)
            joined = b.copyOfRange(0, 5 + l1) + b.copyOfRange(5 + l1 + 5, b.size)
            Packets.put16(joined, 3, l1 + Packets.u16(b, 5 + l1 + 3))
        }
        T.check("varsayılan ilk yöntem TLS kaydı bölme: iki kayıt, birleşince özgün ClientHello", resp.contentEquals(TLS_REPLY) && b != null && joined.contentEquals(hello) && r.gw.stats().retried == 0L)
        srv.close(); r.close()
    }
    run {
        // Sahte sunucu: kayıt bölünmüşse (varsayılan ilk yöntem 1) bağlantıyı keser, bütün kaydı (yöntem 0) kabul eder.
        // Otomatik mod yöntem 0'a geçip öğrenmeli.
        val r = GRig()
        r.gw.config.dpi = true
        val hello = testHello("zor.example.net")
        val tries = AtomicInteger()
        val srv = Srv { s ->
            tries.incrementAndGet()
            val first = readFully(s, 5, 2000)
            val len = Packets.u16(first, 3)
            val body = readFully(s, minOf(len, hello.size), 1000)
            val whole = hello.size - 5 == len
            if (!whole) { s.close(); return@Srv }         // bu sahte sunucu bölünmüş kaydı kabul etmez (tam kayıt ister) → kapat
            s.getOutputStream().write(TLS_REPLY); s.getOutputStream().flush(); Thread.sleep(300)
        }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        val resp = c.read(TLS_REPLY.size, 8000)
        T.check("yöntem 1 kesilince otomatik olarak sıradaki yönteme geçilir ve cevap alınır", resp.contentEquals(TLS_REPLY), "tries=${tries.get()}")
        T.check("yeniden deneme sayıldı, aynı istemci bağlantısı üzerinde", r.gw.stats().retried >= 1L && tries.get() >= 2)
        val before = tries.get()
        val c2 = GCli(r, srv.port); c2.connect(); c2.write(hello)
        val resp2 = c2.read(TLS_REPLY.size, 8000)
        T.check("öğrenilen yöntem hatırlanır: ikinci bağlantı ilk denemede çalışır", resp2.contentEquals(TLS_REPLY) && tries.get() == before + 1)
        srv.close(); r.close()
    }
    run {
        // hiç cevap vermeyen sunucu: tüm yöntemler tükenince istemci RST alır (sonsuz beklemez)
        val r = GRig()
        r.gw.config.dpi = true
        val srv = Srv { s -> Thread.sleep(30_000) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(testHello("sessiz.example.net"))
        val t0 = System.currentTimeMillis()
        var rst = false
        while (System.currentTimeMillis() - t0 < 20_000) { val s = c.next(1000) ?: continue; if (s.flags and F_RST != 0) { rst = true; break } }
        T.check("cevapsız sunucu: yöntemler tükenince bağlantı RST ile biter", rst)
        srv.close(); r.close()
    }
    run {
        // DPI kapalıyken veri olduğu gibi gider, hiç bölme/yeniden deneme yok
        val r = GRig()
        val hello = testHello("normal.example.net")
        val srv = Srv { s -> val b = readFully(s, hello.size, 1500); s.getOutputStream().write(b.copyOf(4)); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        T.check("DPI kapalı: aktarma düz, bölme yok", c.read(4).size == 4 && r.gw.stats().split == 0L)
        srv.close(); r.close()
    }
    run {
        // HTTP: Host bölünür ama sunucu isteği eksiksiz (anlamca aynı) alır
        val r = GRig()
        r.gw.config.dpi = true
        val req = "GET / HTTP/1.1\r\nHost: engelli.example.com\r\nConnection: close\r\n\r\n".toByteArray()
        val seen = LinkedBlockingQueue<String>()
        val srv = Srv { s -> val b = readFully(s, req.size, 1500); seen.add(String(b)); s.getOutputStream().write("HTTP/1.1 200 OK\r\n\r\n".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(req)
        val resp = String(c.read(19))
        val got = seen.poll(3, TimeUnit.SECONDS) ?: ""
        T.check("HTTP: bölünmüş istek sunucuya eksiksiz ulaşır, cevap döner", resp.startsWith("HTTP/1.1 200") && got.equals(String(req)) && r.gw.stats().split == 1L)
        srv.close(); r.close()
    }

    T.group("Ağ geçidi: reklam / izleyici engelleme (SNI, Host, düz DNS), QUIC")
    run {
        val r = GRig()
        val eng = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example", "izleyici.test"))
        r.gw.config.ads = eng
        val srv = Srv { s -> Thread.sleep(300); s.getOutputStream().write("ACIK".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(testHello("cdn.reklam.example"))
        var rst = false
        while (true) { val s = c.next(2500) ?: break; if (s.flags and F_RST != 0) { rst = true; break } }
        T.check("engelli SNI (alt alan adı dahil): bağlantı RST ile kesilir", rst && r.gw.stats().blockedHosts == 1L)
        val c2 = GCli(r, srv.port)
        c2.connect(); c2.write(testHello("guvenli.example.org"))
        T.check("engelli olmayan SNI: geçer", String(c2.read(4)) == "ACIK")
        val c3 = GCli(r, srv.port)
        c3.connect(); c3.write("GET /x HTTP/1.1\r\nHost: izleyici.test\r\n\r\n".toByteArray())
        var rst3 = false
        while (true) { val s = c3.next(2500) ?: break; if (s.flags and F_RST != 0) { rst3 = true; break } }
        T.check("engelli HTTP Host: bağlantı kesilir", rst3 && r.gw.stats().blockedHosts == 2L)
        // Atlatma denemesi: Host izinli, ama istek satırı mutlak biçimde engelli adı hedefliyor (sunucu bunu kullanır).
        val c5 = GCli(r, srv.port)
        c5.connect(); c5.write("GET http://izleyici.test/p HTTP/1.1\r\nHost: guvenli.example.org\r\n\r\n".toByteArray())
        var rst5 = false
        while (true) { val s = c5.next(2500) ?: break; if (s.flags and F_RST != 0) { rst5 = true; break } }
        T.check("mutlak biçimli istek satırı (Host izinli görünse de): bağlantı kesilir", rst5 && r.gw.stats().blockedHosts == 3L)
        r.gw.config.passthrough = true
        val c4 = GCli(r, srv.port); c4.connect(); c4.write(testHello("cdn.reklam.example"))
        T.check("acil durum (passthrough): engelleme ve bölme devre dışı", String(c4.read(4)) == "ACIK")
        srv.close(); r.close()
    }
    run {
        val r = GRig()
        val eng = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example"))
        r.gw.config.ads = eng
        val q = Dns.buildQuery(0x4242, "banner.reklam.example")
        val b = ByteArray(2048)
        val n = Gw.udp(b, false, CLI4, byteArrayOf(8, 8, 8, 8), 51000, 53, q, 0, q.size)
        r.gw.onPacket(b.copyOf(n), n)
        val reply = r.q.poll(2, TimeUnit.SECONDS)
        T.check("sistemin düz DNS sorgusu (herhangi bir sağlayıcıya) engellenir: yerelde cevaplanır",
            reply != null && Gw.checksumOk(reply, reply.size) && Packets.u16(reply, 20) == 53 && Packets.u16(reply, 22) == 51000 &&
                Packets.u16(reply, 28) == 0x4242 && r.gw.stats().dnsBlocked == 1L,
            "reply=${reply?.size} ck=${reply?.let { Gw.checksumOk(it, it.size) }} sp=${reply?.let { Packets.u16(it, 20) }} dp=${reply?.let { Packets.u16(it, 22) }} id=${reply?.let { Packets.u16(it, 28) }} st=${r.gw.stats().dnsBlocked}")
        r.gw.config.blockQuic = true
        val qd = ByteArray(100) { 1 }
        val n2 = Gw.udp(b, false, CLI4, LO4, 51001, 443, qd, 0, qd.size)
        r.gw.onPacket(b.copyOf(n2), n2)
        Thread.sleep(200)
        T.check("QUIC (UDP/443) açıkken düşürülür", r.gw.stats().quicDropped == 1L && r.gw.stats().udpFlows == 0)
        r.gw.config.blockQuic = false
        val n3 = Gw.udp(b, false, CLI4, LO4, 51002, 443, qd, 0, qd.size)
        r.gw.onPacket(b.copyOf(n3), n3)
        Thread.sleep(200)
        T.check("Reklam+ açıkken QUIC ayarı kapalı olsa da QUIC düşürülür (ad TCP/TLS'te görünsün)", r.gw.stats().quicDropped == 2L && r.gw.stats().udpFlows == 0)
        r.gw.config.quicWithAds = false
        r.gw.onPacket(b.copyOf(n3), n3)
        Thread.sleep(200)
        T.check("bu kural kapatılabilir: o zaman QUIC aktarılır (düşürülmez)", r.gw.stats().quicDropped == 2L, r.gw.stats().toString())
        r.close()
    }

    T.group("Ağ geçidi: ortak bellek tavanı (okumayan uygulama servisi bellekten öldüremez)")
    run {
        val budget = 32 * 1024
        val r = GRig(memBudget = budget)
        val total = 200 * 1024
        val pattern = ByteArray(total) { (it * 7 + 3).toByte() }
        // Sunucu önce istemcinin selamını okur (okunmamış veriyle kapanan soket RST üretir), sonra hızla basar.
        fun hello(s: java.net.Socket) { val inp = s.getInputStream(); var k = 0; val t = ByteArray(16); while (k < 5) { val n = inp.read(t); if (n < 0) break; k += n } }
        val srvA = Srv { s -> hello(s); s.getOutputStream().write(pattern); s.getOutputStream().flush(); Thread.sleep(8000) }
        val small = ByteArray(10 * 1024) { (it * 5 + 1).toByte() }
        val srvC = Srv { s -> hello(s); s.getOutputStream().write(small); s.getOutputStream().flush(); Thread.sleep(8000) }
        var peak = 0
        val watching = java.util.concurrent.atomic.AtomicBoolean(true)
        val watcher = Thread { while (watching.get()) { peak = maxOf(peak, r.gw.mem.used); Thread.sleep(2) } }.also { it.isDaemon = true; it.start() }
        val a = GCli(r, srvA.port)
        a.connect(); a.write("merhaba".toByteArray())          // ilk veri gelince sunucu basmaya başlar; istemci okumuyor
        Thread.sleep(600)
        T.check("okumayan bağlantı tavanı doldurur ama aşamaz", r.gw.mem.used in 1..budget && peak <= budget, "used=${r.gw.mem.used} peak=$peak")
        val c = GCli(r, srvC.port)
        c.connect(); c.write("selam".toByteArray())
        Thread.sleep(300)
        val gotA = a.readAll(total, 20_000)
        T.check("tavan altında büyük veri eksiksiz ve sırayla ulaşır", gotA.contentEquals(pattern), "got=${gotA.size}")
        val gotC = c.readAll(small.size, 8000)
        T.check("tavan yüzünden duran (kendi kuyruğu boş) bağlantı, bellek boşalınca kendiliğinden sürer", gotC.contentEquals(small), "got=${gotC.size}")
        watching.set(false); watcher.join(200)
        T.check("tüm süre boyunca tavan aşılmadı", peak <= budget, "peak=$peak")
        srvA.close(); srvC.close(); r.close()
    }

    T.group("Sağlamlık: durum bilgili TCP fuzz (kurulu bağlantıya bozuk segmentler)")
    run {
        val srv = Srv { s ->
            val ins = s.getInputStream(); val o = s.getOutputStream(); val b = ByteArray(4096)
            while (true) { val n = ins.read(b); if (n < 0) break; o.write(b, 0, n); o.flush() }
        }
        val r = GRig()
        val rnd = java.util.Random(20261016)
        var thrown: Throwable? = null
        var badOut = 0
        var outs = 0
        fun drain() {
            while (true) {
                val p = r.q.poll() ?: break
                outs++
                val ok = try { Gw.checksumOk(p, p.size) && p.size <= Gw.MTU } catch (_: Throwable) { false }
                if (!ok) badOut++
            }
        }
        repeat(80) { conn ->
            val c = GCli(r, srv.port, v6 = conn % 5 == 4, dst = if (conn % 5 == 4) InetAddress.getByName("::1").address else LO4)
            try {
                c.connect()
                repeat(120) {
                    val data = ByteArray(rnd.nextInt(if (rnd.nextInt(10) == 0) 1400 else 400)).also { rnd.nextBytes(it) }
                    when (rnd.nextInt(16)) {
                        0, 1, 2 -> c.write(data)
                        3 -> c.send(F_ACK or F_PSH, data, seqNo = c.seq + rnd.nextInt(-3000, 3000))
                        4 -> c.send(F_ACK or F_PSH, data, seqNo = c.seq - rnd.nextInt(0, 200))
                        5 -> c.send(F_ACK, ackNo = rnd.nextInt())
                        6 -> c.send(rnd.nextInt(256), data.copyOf(rnd.nextInt(5)))
                        7 -> c.send(F_SYN, seqNo = if (rnd.nextBoolean()) c.seq else rnd.nextInt())
                        8 -> if (rnd.nextInt(6) == 0) c.send(F_RST, seqNo = c.seq + rnd.nextInt(-5, 5))
                        9 -> c.send(F_FIN or F_ACK, data.copyOf(rnd.nextInt(30)), seqNo = if (rnd.nextBoolean()) c.seq else c.seq + rnd.nextInt(-9, 9))
                        10 -> { c.win = rnd.nextInt(0, 65536); c.send(F_ACK) }
                        11 -> c.send(F_ACK or F_PSH, ByteArray(0), seqNo = c.seq)
                        12 -> { c.send(F_ACK, ackNo = c.rcv - rnd.nextInt(0, 3000)); c.send(F_ACK, ackNo = c.rcv + rnd.nextInt(0, 3000)) }
                        13 -> c.next(rnd.nextInt(1, 15).toLong())
                        14 -> c.send(F_ACK or F_URG_TEST, data.copyOf(rnd.nextInt(20)))
                        else -> c.write(data.copyOf(rnd.nextInt(5)))
                    }
                    if (it % 7 == 0) drain()
                }
            } catch (e: Throwable) { thrown = e }
            drain()
        }
        Thread.sleep(300); drain()
        T.check("1,2 bin+ bozuk/yarış segmentinde istisna çıkmaz", thrown == null, thrown?.stackTraceToString()?.take(600) ?: "")
        T.check("ağ geçidinin yazdığı her paketin sağlama toplamı doğru ve MTU'yu aşmaz ($outs paket)", badOut == 0, "bozuk=$badOut")
        T.check("akış sayısı negatif değil ve sınır içinde", r.gw.stats().tcpFlows in 0..1500, "tcpFlows=${r.gw.stats().tcpFlows}")
        val c2 = GCli(r, srv.port); c2.connect(); c2.write("sağ".toByteArray())
        T.check("fuzz sonrası normal bağlantı yankı alır", String(c2.read(4)) == "sağ", "")
        srv.close(); r.close()
    }

    T.group("Ağ geçidi: akış sayaçları (açılamayan akış sayacı eksiye kaydırmaz)")
    run {
        val gw = Gateway({ _, _, _ -> }, protectUdp = { false })
        gw.config.dpiOnLocal = true; gw.start()
        val b = ByteArray(2048)
        val data = "x".toByteArray()
        repeat(12) { i ->
            val n = Gw.udp(b, false, CLI4, LO4, 53000 + i, 9000 + i, data, 0, data.size)
            gw.onPacket(b.copyOf(n), n)
        }
        T.check("korunamayan UDP soketi akış açmaz ve sayaç 0'da kalır", gw.stats().udpFlows == 0, "udpFlows=${gw.stats().udpFlows}")
        gw.stop()
    }

    T.group("Ağ geçidi: UDP aktarma")
    run {
        val r = GRig()
        val us = DatagramSocket(0, InetAddress.getByAddress(LO4))
        Thread({ try { val bb = ByteArray(2000); val p = DatagramPacket(bb, bb.size); repeat(2) { us.receive(p); us.send(DatagramPacket(bb, p.length, p.socketAddress)) } } catch (_: Exception) {} }).also { it.isDaemon = true }.start()
        val data = "udp-yankı".toByteArray()
        val b = ByteArray(2048)
        val n = Gw.udp(b, false, CLI4, LO4, 52000, us.localPort, data, 0, data.size)
        r.gw.onPacket(b.copyOf(n), n)
        val rep = r.q.poll(3, TimeUnit.SECONDS)
        T.check("UDP: giden datagram ulaştı, cevap doğru portlarla istemciye döndü",
            rep != null && Gw.checksumOk(rep, rep.size) && Packets.u16(rep, 20) == us.localPort && Packets.u16(rep, 22) == 52000 && String(rep, 28, rep.size - 28) == "udp-yankı")
        r.gw.onPacket(b.copyOf(n), n)
        T.check("aynı akış yeniden kullanılır (tek UDP akışı)", r.q.poll(3, TimeUnit.SECONDS) != null && r.gw.stats().udpFlows == 1)
        us.close(); r.close()
    }

    T.group("Ağ geçidi: IPv6 ve sağlamlık")
    run {
        val v6ok = try { ServerSocket(0, 5, InetAddress.getByName("::1")).close(); true } catch (_: Exception) { false }
        if (!v6ok) T.check("IPv6 loopback bu makinede yok: atlandı", true)
        else {
            val r = GRig()
            val ss = ServerSocket(0, 5, InetAddress.getByName("::1"))
            Thread({ try { val s = ss.accept(); val b = ByteArray(100); val n = s.getInputStream().read(b); s.getOutputStream().write(b, 0, n); s.getOutputStream().flush(); Thread.sleep(300) } catch (_: Exception) {} }).also { it.isDaemon = true }.start()
            val c = GCli(r, ss.localPort, v6 = true, dst = InetAddress.getByName("::1").address)
            val sa = c.connect()
            c.write("v6!".toByteArray())
            T.check("IPv6 TCP: el sıkışma ve yankı", sa != null && sa.flags == (F_SYN or F_ACK) && sa.ok && sa.mss <= Gw.MSS6 && String(c.read(3)) == "v6!")
            ss.close(); r.close()
        }
    }
    run {
        val r = GRig()
        val rnd = java.util.Random(7)
        repeat(3000 * FUZZ_X) {
            val len = 20 + rnd.nextInt(120)
            val p = ByteArray(len).also { rnd.nextBytes(it) }
            p[0] = (if (rnd.nextBoolean()) 0x45 else 0x60).toByte()
            if (rnd.nextBoolean() && len > 9) p[9] = (if (rnd.nextBoolean()) 6 else 17).toByte()
            r.gw.onPacket(p, len)
        }
        Thread.sleep(500)
        val e = DatagramSocket(0, InetAddress.getByAddress(LO4)); e.close()
        T.check("3000 rastgele/bozuk paket: çökme yok, geçit çalışmaya devam eder", r.gw.stats().tcpFlows >= 0)
        val srv = Srv { s -> s.getOutputStream().write("hâlâ-canlı".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port); c.connect()
        T.check("bozuk paketlerden sonra normal bağlantı çalışır", String(c.read(11)).startsWith("hâlâ"))
        srv.close(); r.close()
        T.check("stop() sonrası paket kabul edilmez, çökmez", run { r.gw.onPacket(ByteArray(40), 40); true })
    }
    T.group("Ağ geçidi: DoH / DoT engeli, disorder (TTL), yayın paketleri")
    run {
        val r = GRig()
        r.gw.config.blockDoh = true
        val srv = Srv { s -> Thread.sleep(300); s.getOutputStream().write("ACIK".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(testHello("mozilla.cloudflare-dns.com"))
        var rst = false
        while (true) { val sg = c.next(2500) ?: break; if (sg.flags and F_RST != 0) { rst = true; break } }
        T.check("bilinen DoH sağlayıcısına TLS bağlantısı kesilir", rst && r.gw.stats().dohBlocked == 1L)
        val c2 = GCli(r, srv.port); c2.connect(); c2.write(testHello("guvenli.example.org"))
        T.check("diğer adlar etkilenmez", String(c2.read(4)) == "ACIK")
        val b = ByteArray(2048)
        val d = ByteArray(40) { 3 }
        val n = Gw.udp(b, false, CLI4, LO4, 52000, 853, d, 0, d.size)
        r.gw.onPacket(b.copyOf(n), n)
        Thread.sleep(200)
        T.check("UDP/853 (DoQ) düşürülür", r.gw.stats().dohBlocked == 2L && r.gw.stats().udpFlows == 0)
        val sy = ByteArray(80)
        val ns = Gw.tcp(sy, false, CLI4, LO4, 52001, 853, 1000, 0, Gw.SYN, 65535, null, 0, 0, 1460)
        r.gw.onPacket(sy.copyOf(ns), ns)
        val rep = r.q.poll(2, TimeUnit.SECONDS)
        T.check("TCP/853 (DoT) bağlantısı hemen reddedilir", rep != null && (rep[33].toInt() and Gw.RST) != 0 && r.gw.stats().dohBlocked == 3L)
        // IP ile (SNI olmadan) şifreli DNS: bilinen DoH sağlayıcı adresine 443'e bağlanma ve UDP/443 (DoH3) kesilir
        val sy2 = ByteArray(80)
        val doh = byteArrayOf(1, 1, 1, 1)
        val n2 = Gw.tcp(sy2, false, CLI4, doh, 52002, 443, 1000, 0, Gw.SYN, 65535, null, 0, 0, 1460)
        r.gw.onPacket(sy2.copyOf(n2), n2)
        val rep2 = r.q.poll(2, TimeUnit.SECONDS)
        T.check("TCP/443 → bilinen DoH adresi (1.1.1.1) hemen reddedilir", rep2 != null && (rep2[33].toInt() and Gw.RST) != 0 && r.gw.stats().dohBlocked == 4L)
        val du = ByteArray(40) { 4 }
        val nu = Gw.udp(b, false, CLI4, byteArrayOf(8, 8, 8, 8), 52003, 443, du, 0, du.size)
        r.gw.onPacket(b.copyOf(nu), nu)
        Thread.sleep(200)
        T.check("UDP/443 → bilinen DoH adresi (8.8.8.8, DoH3) düşürülür", r.gw.stats().dohBlocked == 5L && r.gw.stats().udpFlows == 0)
        r.gw.config.blockDoh = false
        val c3 = GCli(r, srv.port); c3.connect(); c3.write(testHello("dns.google"))
        T.check("ayar kapalıyken DoH adı da geçer", String(c3.read(4)) == "ACIK")
        srv.close(); r.close()
    }
    // --- sahte ClientHello (yöntem 12): TTL düşer, sahte gider, TTL geri gelir, sunucuya yalnızca gerçek veri ulaşır
    for ((label, ttlOk, ret) in listOf(Triple("tam", true, 1.0), Triple("kısmi", true, 0.5), Triple("desteklenmiyor", true, -1.0), Triple("TTL düşürülemez", false, 1.0))) {
        val calls = java.util.concurrent.CopyOnWriteArrayList<Int>()
        val seen = java.util.concurrent.CopyOnWriteArrayList<String>()
        val hello = testHello("engelli.ornek.com")
        val r = GRig(ttl = { _, ttl -> calls.add(ttl); ttlOk }, fake = { sock, f, real ->
            seen.add("ttl=" + calls.lastOrNull() + " fake!=real:" + !f.contentEquals(real))
            if (ret < 0) -1 else {
                val k = (real.size * ret).toInt().coerceAtLeast(1)
                // çekirdeğin kuyruğa aldığı kısım: sayfa gerçekle ezildiğinden sunucuya gerçek bayt gider
                sock.channel.write(java.nio.ByteBuffer.wrap(real, 0, k)); k
            }
        })
        r.gw.config.dpi = true
        r.gw.planner.worked("engelli.ornek.com", Dpi.TLS, 12)
        val got = LinkedBlockingQueue<ByteArray>()
        val srv = Srv { s -> got.add(readFully(s, hello.size)); s.getOutputStream().write("TAMAM".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        T.check("sahte ClientHello ($label): sunucuya gerçek veri eksiksiz ve sırayla ulaşır", got.poll(4, TimeUnit.SECONDS)?.contentEquals(hello) == true && String(c.read(5)) == "TAMAM")
        if (ttlOk) {
            // Sıradaki yöntem (13) geç kalan bağlantıda yedek olarak açılabilir (hedge): bu yüzden ilk sahte gönderimi değil, her sahte
            // gönderimin düşük TTL ile yapıldığını ve sayacın en az bir başarılı sahte gösterdiğini denetliyoruz.
            T.check("sahte ClientHello ($label): sahte, düşük TTL (${Dpi.FAKE_TTL}) iken verilir; sonra TTL 64", calls.take(2) == listOf(Dpi.FAKE_TTL, 64) && seen.isNotEmpty() && seen[0].startsWith("ttl=${Dpi.FAKE_TTL} fake!=real:true"), calls.toString() + seen)
            T.check("sahte ClientHello ($label): sayaç ${if (ret < 0) "0" else "≥1"}", if (ret < 0) r.gw.stats().fakes == 0L else r.gw.stats().fakes >= 1L)
        } else {
            T.check("sahte ClientHello (TTL düşürülemez): sahte HİÇ gönderilmez", seen.isEmpty() && r.gw.stats().fakes == 0L)
        }
        srv.close(); r.close()
    }
    run {
        val r = GRig()
        r.gw.config.dpi = true
        val hello = testHello("engelli.ornek.com")
        r.gw.planner.worked("engelli.ornek.com", Dpi.TLS, 12)
        val got = LinkedBlockingQueue<ByteArray>()
        val srv = Srv { s -> got.add(readFully(s, hello.size)); s.getOutputStream().write("TAMAM".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port); c.connect(); c.write(hello)
        T.check("sahte ClientHello: platform yoksa (varsayılan) düz bölme, veri tam", got.poll(4, TimeUnit.SECONDS)?.contentEquals(hello) == true && r.gw.stats().fakes == 0L)
        srv.close(); r.close()
    }
    run {
        val calls = java.util.concurrent.CopyOnWriteArrayList<Int>()
        val r = GRig(ttl = { _, ttl -> calls.add(ttl); true })
        r.gw.config.dpi = true
        val hello = testHello("engelli.ornek.com")
        r.gw.planner.worked("engelli.ornek.com", Dpi.TLS, 4)
        val got = LinkedBlockingQueue<ByteArray>()
        val srv = Srv { s -> got.add(readFully(s, hello.size)); s.getOutputStream().write("TAMAM".toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        T.check("disorder: sunucuya veri eksiksiz ve sırayla ulaşır", got.poll(4, TimeUnit.SECONDS)?.contentEquals(hello) == true && String(c.read(5)) == "TAMAM")
        T.check("disorder: TTL önce 1, hemen sonra 64 yapılır", calls.toList() == listOf(1, 64), calls.toString())
        srv.close(); r.close()
    }
    run {
        val r = GRig()
        val b = ByteArray(2048)
        val d = ByteArray(30) { 5 }
        val n1 = Gw.udp(b, false, CLI4, byteArrayOf(-17, -1, -1, -6), 5353, 5353, d, 0, d.size)    // 239.255.255.250 (SSDP)
        r.gw.onPacket(b.copyOf(n1), n1)
        val n2 = Gw.udp(b, false, CLI4, byteArrayOf(-1, -1, -1, -1), 68, 67, d, 0, d.size)           // genel yayın
        r.gw.onPacket(b.copyOf(n2), n2)
        Thread.sleep(250)
        T.check("çok noktaya / genel yayın paketleri aktarılmaz", r.gw.stats().udpFlows == 0)
        r.close()
    }

    T.group("Ağ geçidi: mobil ağ (IPv6-only NAT64, ağ türüne göre DPI belleği)")
    run {
        // Ortamda IPv6 olmayabilir: NAT64 adresi, yerel IPv4 sunucuya çevrilerek denenir (akış mantığı aynı).
        // 127.0.0.1:port'ta kimse dinlemez (düz IPv4 reddedilir); "NAT64 adresi" 127.0.0.2'ye çevrilir ve orada bir sunucu vardır.
        val ss = ServerSocket(0, 5, InetAddress.getByAddress(byteArrayOf(127, 0, 0, 2)))
        Thread({ try { while (true) { val c = ss.accept(); Thread({ try { val i = c.getInputStream(); val o = c.getOutputStream(); val b = ByteArray(64); val n = i.read(b); o.write(b, 0, n); o.flush(); Thread.sleep(200) } catch (_: Exception) {} finally { try { c.close() } catch (_: Exception) {} } }).start() } } catch (_: Exception) {} }).also { it.isDaemon = true }.start()
        val map: (ByteArray, ByteArray) -> InetAddress = { _, _ -> InetAddress.getByAddress(byteArrayOf(127, 0, 0, 2)) }
        run {
            val r = GRig(); r.gw.config.noV4 = true; r.gw.config.nat64 = ByteArray(12); r.gw.config.nat64Addr = map
            val c = GCli(r, ss.localPort)
            val sa = c.connect(); c.write("MERHABA".toByteArray())
            T.check("yalnızca IPv6 ağ: IPv4 hedefe NAT64 adresiyle bağlanılır, veri gidip gelir", sa != null && sa.flags == (F_SYN or F_ACK) && String(c.read(7)) == "MERHABA")
            r.close()
        }
        run {
            val r = GRig(); r.gw.config.nat64 = ByteArray(12); r.gw.config.nat64Addr = map     // noV4 yok: önce IPv4 denenir (reddedilir), sonra NAT64
            val c = GCli(r, ss.localPort)
            val sa = c.connect(); c.write("TEKRAR".toByteArray())
            T.check("IPv4 reddedilirse NAT64 yedeği devreye girer", sa != null && sa.flags == (F_SYN or F_ACK) && String(c.read(6)) == "TEKRAR")
            r.close()
        }
        run {
            val r = GRig()                                                  // NAT64 bilgisi yok: bağlanamayan hedef RST alır (eski davranış)
            val c = GCli(r, ss.localPort)
            val sa = c.connect()
            T.check("NAT64 bilgisi yokken ulaşılamayan hedef hemen reddedilir (RST)", sa != null && (sa.flags and F_RST) != 0)
            r.close()
        }
        ss.close()
        val r = GRig()
        r.gw.config.dpi = true
        r.gw.planner.worked("site.example", Dpi.TLS, 4)
        r.gw.networkChanged(NetKind.MOBILE)
        T.check("mobil ağa geçince Wi-Fi'de öğrenilen yöntem uygulanmaz (ayrı bellek)", r.gw.planner.first("site.example", Dpi.TLS) == Dpi.TLS_ORDER[0])
        r.gw.planner.worked("site.example", Dpi.TLS, 0)
        r.gw.networkChanged(NetKind.WIFI)
        T.check("Wi-Fi'ye dönünce kendi belleği geri gelir", r.gw.planner.first("site.example", Dpi.TLS) == 4)
        r.gw.networkChanged(NetKind.NONE)
        T.check("ağ yokken bellek türü değişmez", r.gw.planner.first("site.example", Dpi.TLS) == 4)
        val fast = Dpi.Planner().also { it.noteRtt(80) }; val slow = Dpi.Planner(slow = true).also { it.noteRtt(80) }
        T.check("mobil bekleme süresi Wi-Fi'ninkinden uzundur (TLS ve HTTP)", slow.waitMs(Dpi.TLS) > fast.waitMs(Dpi.TLS) && slow.waitMs(Dpi.HTTP) > fast.waitMs(Dpi.HTTP) && slow.waitMs(Dpi.TLS) <= 3000)
        r.close()
    }

    run {
        // Ağ değişince tüm akışlar hemen kesilir (istemciye RST): uygulamalar yeni ağda anında yeniden bağlanır.
        val r = GRig()
        val echo = Srv { s -> val i = s.getInputStream(); val o = s.getOutputStream(); val b = ByteArray(256); while (true) { val n = i.read(b); if (n < 0) break; o.write(b, 0, n); o.flush() } }
        val c = GCli(r, echo.port)
        c.connect(); c.write("A".toByteArray())
        val ok = String(c.read(1)) == "A"
        val t0 = System.nanoTime()
        r.gw.networkReset()
        var rst = false
        while (System.nanoTime() - t0 < 3_000_000_000L) { val sg = c.next(200) ?: continue; if (sg.flags and F_RST != 0) { rst = true; break } }
        val ms = (System.nanoTime() - t0) / 1_000_000
        MobileBench.handoverResetMs = ms
        T.check("ağ değişimi: açık akış hemen RST ile kesilir (${ms} ms), sayaç artar", ok && rst && ms < 800 && r.gw.stats().netResets >= 1)
        val c2 = GCli(r, echo.port); c2.connect(); c2.write("B".toByteArray())
        T.check("sıfırlamadan sonra yeni bağlantılar sorunsuz açılır", String(c2.read(1)) == "B")
        echo.close(); r.close()
    }
    run {
        // SYN'i yanıtsız kalan (kabul kuyruğu dolu) sunucu: yedek deneme öbür adrese gider, 12 sn'lik bağlanma zaman aşımı beklenmez.
        val bh = ServerSocket(0, 1, InetAddress.getByAddress(LO4))                    // kuyruğu dolacak, hiç accept edilmeyecek
        val filler = ArrayList<Socket>()
        for (i in 0 until 12) { val f = Socket(); try { f.connect(java.net.InetSocketAddress(InetAddress.getByAddress(LO4), bh.localPort), 150); filler.add(f) } catch (_: Exception) { try { f.close() } catch (_: Exception) {}; break } }
        val saturated = filler.size < 12
        val good = try { ServerSocket(bh.localPort, 5, InetAddress.getByAddress(byteArrayOf(127, 0, 0, 2))) } catch (_: Exception) { null }
        if (saturated && good != null) {
            Thread({ try { while (true) { val c = good.accept(); Thread({ try { val i = c.getInputStream(); val o = c.getOutputStream(); val b = ByteArray(64); val n = i.read(b); o.write(b, 0, n); o.flush(); Thread.sleep(200) } catch (_: Exception) {} finally { try { c.close() } catch (_: Exception) {} } }).start() } } catch (_: Exception) {} }).also { it.isDaemon = true }.start()
            val map: (ByteArray, ByteArray) -> InetAddress = { _, _ -> InetAddress.getByAddress(byteArrayOf(127, 0, 0, 2)) }
            fun run1(hedge: Boolean, waitMs: Long): Long {
                val r = GRig(); r.gw.config.hedge = hedge; r.gw.config.hedgeDelayMs = 250; r.gw.config.nat64 = ByteArray(12); r.gw.config.nat64Addr = map
                val c = GCli(r, bh.localPort)
                val t0 = System.nanoTime()
                c.send(F_SYN, mss = 1460); c.seq++
                val sa = c.next(waitMs)
                var got = ""
                if (sa != null && sa.flags == (F_SYN or F_ACK)) {
                    c.rcv = sa.seq + 1; c.send(F_ACK)
                    c.write("MERHABA".toByteArray())
                    got = String(c.read(7, waitMs))
                }
                val ms = (System.nanoTime() - t0) / 1_000_000
                r.close()
                return if (got == "MERHABA") ms else -1L
            }
            val withHedge = run1(true, 5000)
            T.check("yedek bağlantı: yanıtsız hedefte öbür adres 250 ms sonra denenir, veri gelir ($withHedge ms)", withHedge in 1..2500)
            val without = run1(false, 20000)
            T.check("kontrol: yedek kapalıyken aynı durumda bağlanma zaman aşımı beklenir ($without ms)", without > 10_000)
            MobileBench.blackholeNewMs = withHedge; MobileBench.blackholeOldMs = without
        } else {
            println("    (bilgi) kabul kuyruğu doldurulamadı; yedek bağlantı sınaması atlandı")
        }
        for (f in filler) try { f.close() } catch (_: Exception) {}
        bh.close(); good?.close()
    }

}

// ---------------------------------------------------------------------------------------------------------------------
// Ağ geçidi: düz DNS sertleştirmesi (UDP/53 ve TCP/53), HTTPS/ECH kaydı, cevap tarafı CNAME denetimi

private fun encName(n: String): ByteArray {
    val o = ByteArrayOutputStream()
    for (l in n.split('.')) { o.write(l.length); o.write(l.toByteArray()) }
    o.write(0)
    return o.toByteArray()
}

/** [qname] sorusuna "CNAME -> [target]" ve [target] için bir A kaydı içeren cevap. */
private fun cnameAnswer(id: Int, qname: String, target: String): ByteArray {
    val o = ByteArrayOutputStream()
    val h = ByteArray(12); Packets.put16(h, 0, id); Packets.put16(h, 2, 0x8180); Packets.put16(h, 4, 1); Packets.put16(h, 6, 2)
    o.write(h); o.write(encName(qname)); o.write(byteArrayOf(0, 1, 0, 1))
    val t = encName(target)
    o.write(byteArrayOf(0xC0.toByte(), 12, 0, 5, 0, 1, 0, 0, 0, 60, 0, t.size.toByte())); o.write(t)
    o.write(t); o.write(byteArrayOf(0, 1, 0, 1, 0, 0, 0, 60, 0, 4, 1, 2, 3, 4))
    return o.toByteArray()
}

private fun dnsQ(id: Int, name: String, qtype: Int = 1, qclass: Int = 1): ByteArray =
    Dns.buildQuery(id, name).also { Packets.put16(it, it.size - 4, qtype); Packets.put16(it, it.size - 2, qclass) }

fun runGatewayHardeningTests() {
    // 53 numaralı porta ihtiyaç duyan testler (yetki yoksa ilgili kontroller atlanır)
    val udp53 = try { DatagramSocket(53, InetAddress.getByAddress(LO4)) } catch (_: Exception) { null }
    val tcp53 = try { ServerSocket(53, 50, InetAddress.getByAddress(LO4)) } catch (_: Exception) { null }
    val seenUdp = AtomicInteger()
    if (udp53 != null) Thread({
        try {
            val bb = ByteArray(2000); val p = DatagramPacket(bb, bb.size)
            while (true) {
                p.length = bb.size; udp53.receive(p)
                seenUdp.incrementAndGet()
                val id = Packets.u16(bb, 0)
                val reply = if (bb[13].toInt().toChar() == 'm') cnameAnswer(id, "metrik.site.example", "t.izleyici.test") else cnameAnswer(id, "temiz.site.example", "cdn.temiz.example")
                udp53.send(DatagramPacket(reply, reply.size, p.socketAddress))
            }
        } catch (_: Exception) {}
    }).also { it.isDaemon = true }.start()
    T.group("Ağ geçidi: düz DNS (UDP/53) sertleştirmesi")
    run {
        val r = GRig()
        r.gw.config.ads = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example"))
        val b = ByteArray(2048)
        fun send(dns: ByteArray, sport: Int) {
            val n = Gw.udp(b, false, CLI4, LO4, sport, 53, dns, 0, dns.size)
            r.gw.onPacket(b.copyOf(n), n)
        }
        fun reply(): ByteArray? = r.q.poll(2, TimeUnit.SECONDS)?.let { it.copyOfRange(28, it.size) }
        // iki soru: FORMERR, sunucuya gitmez
        val two = dnsQ(0x1001, "ok.example.org").let { it + encName("banner.reklam.example") + byteArrayOf(0, 1, 0, 1) }.also { Packets.put16(it, 4, 2) }
        send(two, 52001)
        val a = reply()
        T.check("çok soru içeren düz DNS sorgusu: biçim hatası (RCODE 1), UDP akışı açılmaz",
            a != null && (Packets.u16(a, 2) and 0xF) == 1 && Packets.u16(a, 0) == 0x1001 && r.gw.stats().udpFlows == 0 && seenUdp.get() == 0, "a=${a?.size}")
        // işaretçili ad
        val ptr = dnsQ(0x1002, "x.example.org").also { it[12] = 0xC0.toByte(); it[13] = 12 }
        send(ptr, 52002)
        val a2 = reply()
        T.check("işaretçili ad: biçim hatası", a2 != null && (Packets.u16(a2, 2) and 0xF) == 1 && r.gw.stats().udpFlows == 0)
        // engelli ad, IN dışı sınıf
        send(dnsQ(0x1003, "banner.reklam.example", 1, 255), 52003)
        val a3 = reply()
        T.check("engelli ad, ANY sınıfı: 'reddedildi' (RCODE 5), sunucuya gitmez, kimlik korunur",
            a3 != null && (Packets.u16(a3, 2) and 0xF) == 5 && Packets.u16(a3, 0) == 0x1003 && r.gw.stats().udpFlows == 0 && r.gw.stats().dnsBlocked == 1L, "a=${a3?.size} st=${r.gw.stats().dnsBlocked}")
        // engelli ad, olağan sınıf hâlâ engelleme cevabı
        send(dnsQ(0x1004, "banner.reklam.example"), 52004)
        val a4 = reply()
        T.check("engelli ad, olağan sorgu: engelleme cevabı", a4 != null && Dns.isLocalBlock(a4, 0, a4.size) && r.gw.stats().dnsBlocked == 2L)
        // HTTPS kaydı: bayrak kapalıyken iletilir (akış açılır), açıkken 'kayıt yok'
        send(dnsQ(0x1005, "ok.example.org", 65), 52005)
        reply()                                            // sunucunun (varsa) cevabı istemciye döner
        T.check("dropHttps kapalı: HTTPS sorgusu sunucuya iletilir", udp53 == null || seenUdp.get() == 1, "seen=${seenUdp.get()}")
        r.gw.config.dropHttps = true
        send(dnsQ(0x1006, "ok.example.org", 65), 52006)
        val a6 = reply()
        T.check("dropHttps açık: HTTPS sorgusuna 'kayıt yok' (NOERROR, cevap yok), akış açılmaz",
            a6 != null && (Packets.u16(a6, 2) and 0xF) == 0 && Packets.u16(a6, 6) == 0 && Packets.u16(a6, 0) == 0x1006 && (udp53 == null || seenUdp.get() == 1))
        send(dnsQ(0x1007, "ok.example.org", 1), 52007)
        reply()
        T.check("dropHttps açık: A sorgusu yine iletilir", udp53 == null || seenUdp.get() == 2, "seen=${seenUdp.get()}")
        r.close()
    }
    run {
        // motor yok, yalnızca dropHttps: HTTPS yine düşer
        val r = GRig()
        r.gw.config.dropHttps = true
        val b = ByteArray(2048)
        val d = dnsQ(0x2001, "ok.example.org", 65)
        val n = Gw.udp(b, false, CLI4, LO4, 52100, 53, d, 0, d.size)
        r.gw.onPacket(b.copyOf(n), n)
        val x = r.q.poll(2, TimeUnit.SECONDS)
        T.check("motor yokken de dropHttps çalışır", x != null && Packets.u16(x, 28) == 0x2001 && (Packets.u16(x, 30) and 0xF) == 0)
        r.close()
    }

    if (udp53 == null || tcp53 == null) {
        T.check("53 numaralı yerel port bağlanamadı: UDP/TCP 53 uçtan uca testleri atlandı", true)
        udp53?.close(); tcp53?.close()
        return
    }
    T.group("Ağ geçidi: cevap tarafı CNAME denetimi ve TCP/53 DNS süzgeci")
    run {
        val r = GRig()
        r.gw.config.ads = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("izleyici.test"))
        val b = ByteArray(2048)
        fun ask(id: Int, name: String, sport: Int): ByteArray? {
            val d = dnsQ(id, name)
            val n = Gw.udp(b, false, CLI4, LO4, sport, 53, d, 0, d.size)
            r.gw.onPacket(b.copyOf(n), n)
            return r.q.poll(3, TimeUnit.SECONDS)?.let { it.copyOfRange(28, it.size) }
        }
        val a = ask(0x3001, "metrik.site.example", 53001)
        T.check("sabit sunucudan gelen cevapta CNAME zinciri engelli adda bitiyor: cevap engelleme cevabına çevrilir",
            a != null && Packets.u16(a, 0) == 0x3001 && Dns.isLocalBlock(a, 0, a.size) && r.gw.stats().dnsBlocked == 1L, "a=${a?.size} st=${r.gw.stats().dnsBlocked}")
        val c = ask(0x3002, "temiz.site.example", 53002)
        T.check("temiz CNAME zinciri olduğu gibi geçer", c != null && Packets.u16(c, 6) == 2 && r.gw.stats().dnsBlocked == 1L)
        r.close()
    }
    run {
        val r = GRig()
        r.gw.config.ads = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example"))
        val seen = AtomicInteger()
        Thread({
            while (!tcp53.isClosed) {
                val s = try { tcp53.accept() } catch (_: Exception) { break }
                Thread({
                    try {
                        val ins = s.getInputStream()
                        val h = readFully(s, 2); if (h.size < 2) return@Thread
                        val len = ((h[0].toInt() and 0xFF) shl 8) or (h[1].toInt() and 0xFF)
                        val q = readFully(s, len)
                        seen.incrementAndGet()
                        val rep = cnameAnswer(Packets.u16(q, 0), "ok.example.org", "cdn.ok.example")
                        s.getOutputStream().write(byteArrayOf((rep.size ushr 8).toByte(), rep.size.toByte()) + rep); s.getOutputStream().flush()
                        Thread.sleep(200)
                    } catch (_: Exception) {} finally { try { s.close() } catch (_: Exception) {} }
                }).also { it.isDaemon = true }.start()
            }
        }).also { it.isDaemon = true }.start()
        fun framed(d: ByteArray) = byteArrayOf((d.size ushr 8).toByte(), d.size.toByte()) + d
        val c1 = GCli(r, 53); c1.connect()
        c1.write(framed(dnsQ(0x4001, "banner.reklam.example")))
        val got = c1.read(2 + 40, 3000)
        val len = if (got.size >= 2) ((got[0].toInt() and 0xFF) shl 8) or (got[1].toInt() and 0xFF) else -1
        T.check("TCP/53: engelli ad için cevap geçitte üretilir (uzunluk önekli, kimlik korunur, engelleme cevabı)",
            got.size >= 2 + 12 && len == got.size - 2 && Packets.u16(got, 2) == 0x4001 && Dns.isLocalBlock(got, 2, got.size - 2), "n=${got.size} len=$len")
        Thread.sleep(200)
        T.check("TCP/53: engelli soru sunucuya hiç gitmedi; sayaç arttı", seen.get() == 0 && r.gw.stats().dnsBlocked == 1L, "seen=${seen.get()}")
        val c2 = GCli(r, 53); c2.connect()
        val d2 = framed(dnsQ(0x4002, "ok.example.org"))
        c2.write(d2.copyOfRange(0, 1)); Thread.sleep(50); c2.write(d2.copyOfRange(1, d2.size))
        val g2 = c2.read(2 + 40, 3000)
        T.check("TCP/53: engelli olmayan soru sunucuya iletilir, gerçek cevap döner", g2.size > 20 && seen.get() == 1 && Packets.u16(g2, 8) == 2, "n=${g2.size} seen=${seen.get()}")
        val c3 = GCli(r, 53); c3.connect()
        val d3 = framed(dnsQ(0x4003, "banner.reklam.example"))
        c3.write(d3.copyOfRange(0, 2)); Thread.sleep(80); c3.write(d3.copyOfRange(2, 9)); Thread.sleep(80); c3.write(d3.copyOfRange(9, d3.size))
        val g3 = c3.read(2 + 40, 3000)
        T.check("TCP/53: parça parça gelen engelli soru da yakalanır", g3.size >= 14 && Packets.u16(g3, 2) == 0x4003 && Dns.isLocalBlock(g3, 2, g3.size - 2) && seen.get() == 1, "n=${g3.size}")
        // Ardışık (pipelined) sorular: temiz soru arkasına gizlenen engelli soru sunucuya gitmez, bağlantı kesilir
        val c4 = GCli(r, 53); c4.connect()
        c4.write(framed(dnsQ(0x4004, "ok.example.org")) + framed(dnsQ(0x4005, "banner.reklam.example")))
        c4.read(2 + 40, 1500)
        Thread.sleep(200)
        T.check("TCP/53: aynı uçuştaki ikinci (engelli) soru denetlenir; hiçbiri sunucuya gitmez", seen.get() == 1 && r.gw.stats().dnsBlocked == 3L, "seen=${seen.get()} blk=${r.gw.stats().dnsBlocked}")
        val c5 = GCli(r, 53); c5.connect()
        c5.write(framed(dnsQ(0x4006, "ok.example.org")))
        c5.read(2 + 40, 3000)
        c5.write(framed(dnsQ(0x4007, "banner.reklam.example")))
        Thread.sleep(300)
        T.check("TCP/53: ilk temiz sorudan sonra aynı bağlantıdan gelen engelli soru da yakalanır", seen.get() == 2 && r.gw.stats().dnsBlocked == 4L, "seen=${seen.get()} blk=${r.gw.stats().dnsBlocked}")
        r.close()
    }
    udp53.close(); tcp53.close()
}

/** DPI iyileştirmeleri: yerel hedefler, denenemeyen uçuş, enjekte edilen düz metin cevap. */
fun runGatewayDpiHardeningTests() {
    T.group("Ağ geçidi: DPI iyileştirmeleri")

    // --- saf yardımcılar
    fun ip4(a: Int, b: Int, c: Int, d: Int) = byteArrayOf(a.toByte(), b.toByte(), c.toByte(), d.toByte())
    T.check("yerel adres: 192.168/16, 10/8, 172.16/12, 127/8, 169.254/16",
        listOf(ip4(192, 168, 1, 1), ip4(10, 0, 0, 5), ip4(172, 16, 0, 1), ip4(172, 31, 255, 1), ip4(127, 0, 0, 1), ip4(169, 254, 1, 1)).all { Dpi.isLocalAddress(it) })
    T.check("yerel adres: operatör NAT'ı 100.64/10 ve çok noktaya yayın", Dpi.isLocalAddress(ip4(100, 64, 0, 1)) && Dpi.isLocalAddress(ip4(100, 127, 255, 255)) && Dpi.isLocalAddress(ip4(224, 0, 0, 251)))
    T.check("genel adresler yerel sayılmaz (8.8.8.8, 1.1.1.1, 172.32.0.1, 100.128.0.1, 192.169.0.1)",
        listOf(ip4(8, 8, 8, 8), ip4(1, 1, 1, 1), ip4(172, 32, 0, 1), ip4(100, 128, 0, 1), ip4(192, 169, 0, 1)).none { Dpi.isLocalAddress(it) })
    val v6 = { s: String -> java.net.InetAddress.getByName(s).address }
    T.check("IPv6: ::1, fe80::, fc00::/7, ff02:: yerel; 2606:4700:: genel", Dpi.isLocalAddress(v6("::1")) && Dpi.isLocalAddress(v6("fe80::1")) && Dpi.isLocalAddress(v6("fd12:3456::1")) && Dpi.isLocalAddress(v6("ff02::fb")) && !Dpi.isLocalAddress(v6("2606:4700:4700::1111")))
    val mapped = ByteArray(16).also { it[10] = 0xFF.toByte(); it[11] = 0xFF.toByte(); it[12] = 192.toByte(); it[13] = 168.toByte(); it[14] = 0; it[15] = 5 }
    val mappedPub = mapped.copyOf().also { it[12] = 8; it[13] = 8; it[14] = 8; it[15] = 8 }
    T.check("IPv4'e eşlenmiş adres IPv4 gibi sayılır", Dpi.isLocalAddress(mapped) && !Dpi.isLocalAddress(mappedPub))
    T.check("geçersiz uzunlukta adres yerel sayılmaz", !Dpi.isLocalAddress(ByteArray(3)) && !Dpi.isLocalAddress(ByteArray(0)))

    val tlsRec = byteArrayOf(0x16, 3, 3, 0, 5, 1, 2, 3, 4, 5)
    T.check("TLS kaydı (el sıkışma 0x16 / uyarı 0x15) gerçek cevap sayılır", Dpi.looksLikeTlsReply(tlsRec, tlsRec.size) && Dpi.looksLikeTlsReply(byteArrayOf(0x15, 3, 3, 0, 2, 2, 40), 7))
    val http403 = "HTTP/1.1 403 Forbidden\r\n\r\n".toByteArray()
    T.check("düz metin engel sayfası TLS cevabı değildir", !Dpi.looksLikeTlsReply(http403, http403.size) && !Dpi.looksLikeTlsReply("<html>".toByteArray(), 6) && !Dpi.looksLikeTlsReply(ByteArray(0), 0))
    T.check("sürüm baytı 3 değilse kayıt sayılmaz", !Dpi.looksLikeTlsReply(byteArrayOf(0x16, 9, 9), 3))

    val pl = Dpi.Planner()
    for (i in 0 until 6) pl.worked("net$i.example", Dpi.HTTP, 5)          // ağ oyları HTTP için cesur bir yöntemi öne çıkarır
    T.check("Planner.first: ağ oyuyla cesur yöntem (5)", pl.first("yeni.example", Dpi.HTTP) == 5)
    T.check("Planner.firstSafe: denenemeyen uçuşta oy yok sayılır (HTTP 0, TLS 1)", pl.firstSafe("yeni.example", Dpi.HTTP) == 0 && pl.firstSafe("yeni.example", Dpi.TLS) == Dpi.TLS_ORDER[0])
    pl.worked("kanitli.example", Dpi.HTTP, 2)
    T.check("Planner.firstSafe: bu hedefte kanıtlanmış yöntem korunur", pl.firstSafe("kanitli.example", Dpi.HTTP) == 2)

    // --- yerel hedefe bölme yapılmaz
    run {
        val r = GRig()
        r.gw.config.dpi = true
        r.gw.config.dpiOnLocal = false                                   // varsayılan davranış: loopback yerel sayılır
        val hello = testHello("yerel.example.net")
        val seen = LinkedBlockingQueue<ByteArray>()
        val srv = Srv { s -> val b = readFully(s, hello.size, 1500); seen.add(b); s.getOutputStream().write("YEREL-OK".toByteArray()); s.getOutputStream().flush(); Thread.sleep(200) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        val resp = c.read(8)
        val b = seen.poll(3, TimeUnit.SECONDS)
        T.check("yerel hedefe bölme uygulanmaz: ClientHello tek parça, bölme sayacı 0", String(resp) == "YEREL-OK" && b != null && b.contentEquals(hello) && r.gw.stats().split == 0L)
        srv.close(); r.close()
    }

    // --- enjekte edilen düz metin cevap: yöntem değiştirilir, öğrenme yanıltılmaz
    run {
        val r = GRig()
        r.gw.config.dpi = true
        val hello = testHello("enjekte.example.net")
        val tries = AtomicInteger()
        val real = byteArrayOf(0x16, 3, 3, 0, 5, 1, 2, 3, 4, 5)
        val srv = Srv { s ->
            tries.incrementAndGet()
            val first = readFully(s, 5, 2000)
            val len = Packets.u16(first, 3)
            readFully(s, minOf(len, hello.size), 1000)
            val whole = hello.size - 5 == len
            // Bölünmüş kayıt görürse DPI gibi davranır: düz metin engel sayfası yazar. Tam kayıtta gerçek TLS kaydı döner.
            if (!whole) s.getOutputStream().write("HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n".toByteArray())
            else s.getOutputStream().write(real)
            s.getOutputStream().flush(); Thread.sleep(300)
        }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        val resp = c.read(real.size, 8000)
        T.check("enjekte edilen düz metin cevap atlanır, sıradaki yöntemle gerçek TLS cevabı alınır", resp.contentEquals(real), "n=${resp.size}")
        T.check("istatistik: enjekte edilen cevap sayıldı, yeniden denendi", r.gw.stats().injected >= 1L && r.gw.stats().retried >= 1L && tries.get() >= 2)
        val before = tries.get()
        val c2 = GCli(r, srv.port); c2.connect(); c2.write(hello)
        val resp2 = c2.read(real.size, 8000)
        T.check("öğrenilen yöntem gerçek olandır: ikinci bağlantı ilk denemede çalışır", resp2.contentEquals(real) && tries.get() == before + 1)
        srv.close(); r.close()
    }

    // --- her yöntemde düz metin: son yöntemde cevap olduğu gibi aktarılır (RST değil)
    run {
        val r = GRig()
        r.gw.config.dpi = true
        val hello = testHello("duzmetin.example.net")
        val txt = "HTTP/1.1 400 Bad Request\r\n\r\n"
        val srv = Srv { s -> readFully(s, 5, 2000); readFully(s, hello.size - 5, 500); s.getOutputStream().write(txt.toByteArray()); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        val resp = c.read(txt.length, 15_000)
        T.check("düz metin konuşan gerçek sunucu: yöntemler bitince cevap yine iletilir", String(resp) == txt, "n=${resp.size}")
        srv.close(); r.close()
    }

    // --- gecikmeli yöntem (9): parçalar arası bekleme gerçekten yapılır, veri bozulmaz, cevap alınır
    run {
        val r = GRig()
        r.gw.config.dpi = true
        val hello = testHello("gecikme.example.net")
        r.gw.planner.worked("gecikme.example.net", Dpi.TLS, 9)
        val firstAt = AtomicLong(); val lastAt = AtomicLong(); val got = LinkedBlockingQueue<ByteArray>()
        val srv = Srv { s ->
            val a = readFully(s, 1, 2000); firstAt.set(System.nanoTime())
            val rest = readFully(s, hello.size - 1, 2000); lastAt.set(System.nanoTime())
            got.add(a + rest)
            s.getOutputStream().write(TLS_REPLY); s.getOutputStream().flush(); Thread.sleep(200)
        }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        val resp = c.read(TLS_REPLY.size, 6000)
        val data = got.poll(3, TimeUnit.SECONDS)
        val gapMs = (lastAt.get() - firstAt.get()) / 1_000_000
        T.check("gecikmeli yöntem 9: veri bozulmadan ulaşır, cevap alınır", data != null && data.contentEquals(hello) && resp.contentEquals(TLS_REPLY))
        T.check("gecikmeli yöntem 9: son parça en az ~DELAY_MS sonra gelir", gapMs >= Dpi.DELAY_MS - 15, "gap=$gapMs ms")
        T.check("gecikmeli yöntem 9: yeniden deneme gerekmedi", r.gw.stats().retried == 0L)
        srv.close(); r.close()
    }

    // --- tükenen hedef: tüm yöntemler başarısızsa kısa süre yöntem gezilmez; sıfırlamada yeniden denenir
    run {
        val r = GRig()
        r.gw.config.dpi = true
        val hello = testHello("tukenen.example.net")
        val srv = Srv { s -> try { readFully(s, hello.size, 1000) } catch (_: Exception) {}; s.close() }       // her denemede cevapsız kapatır
        fun waitAccepted(n: Int) { val end = System.currentTimeMillis() + 15_000; while (srv.accepted.get() < n && System.currentTimeMillis() < end) Thread.sleep(20) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        waitAccepted(Dpi.TLS_ORDER.size)
        Thread.sleep(400)
        T.check("tükenme: ilk bağlantıda tüm yöntemler sırayla denendi", srv.accepted.get() == Dpi.TLS_ORDER.size, "denenen=${srv.accepted.get()}")
        val before = srv.accepted.get()
        val c2 = GCli(r, srv.port)
        c2.connect(); c2.write(hello)
        Thread.sleep(600)
        T.check("tükenme: ikinci bağlantıda yöntem gezilmez (tek düz deneme)", srv.accepted.get() == before + 1, "ek=${srv.accepted.get() - before}")
        T.check("tükenme: istatistikte sayıldı", r.gw.stats().exhaustSkipped >= 1L)
        T.check("tükenme: DPI el sıkışma başarısızlığı sayıldı (vana için), başarı yok", r.gw.stats().recentDpiFail >= 1 && r.gw.stats().recentDpiOk == 0, r.gw.stats().toString())
        r.gw.planner.forget()
        val b2 = srv.accepted.get()
        val c3 = GCli(r, srv.port)
        c3.connect(); c3.write(hello)
        waitAccepted(b2 + Dpi.TLS_ORDER.size)
        T.check("tükenme belleği sıfırlanınca yöntemler yeniden denenir", srv.accepted.get() - b2 == Dpi.TLS_ORDER.size, "ek=${srv.accepted.get() - b2}")
        srv.close(); r.close()
    }

    // --- UDP sahte paketler (UdpDecoy): Discord ses "IP keşfi" paketinden önce düşük TTL'li rastgele paketler
    run {
        fun freeUdp(): DatagramSocket {
            for (port in 52100..52400) try { return DatagramSocket(port, InetAddress.getByAddress(LO4)) } catch (_: Exception) {}
            throw IllegalStateException("boş UDP portu yok")
        }
        val discovery = ByteArray(74).also { it[1] = 1; it[3] = 70; it[7] = 9 }
        fun scenario(decoy: Boolean, ttlWorks: Boolean, payload: ByteArray): Pair<List<ByteArray>, List<Int>> {
            val ttls = java.util.Collections.synchronizedList(ArrayList<Int>())
            val r = GRig(udpTtl = { _, t -> ttls.add(t); ttlWorks })
            r.gw.config.dpi = true
            r.gw.config.udpDecoy = decoy
            val us = freeUdp()
            val got = java.util.Collections.synchronizedList(ArrayList<ByteArray>())
            Thread({ try { val bb = ByteArray(2000); val p = DatagramPacket(bb, bb.size); while (true) { p.length = bb.size; us.receive(p); got.add(bb.copyOf(p.length)) } } catch (_: Exception) {} }).also { it.isDaemon = true }.start()
            val b = ByteArray(2048)
            val n = Gw.udp(b, false, CLI4, LO4, 52000, us.localPort, payload, 0, payload.size)
            r.gw.onPacket(b.copyOf(n), n)
            Thread.sleep(500)
            val res = ArrayList(got) to ArrayList(ttls)
            val dec = r.gw.stats().udpDecoys
            us.close(); r.close()
            return res.first to (res.second + listOf(dec.toInt() + 1000))
        }
        val (g1, t1) = scenario(true, true, discovery)
        T.check("UDP sahte paket: sunucuya 4 sahte + 1 gerçek ulaşır, gerçek paket sonuncudur ve bozulmamıştır", g1.size == 5 && g1.last().contentEquals(discovery) && g1.take(4).all { it.size == 74 && it[0] == 0xFF.toByte() }, "n=${g1.size}")
        T.check("UDP sahte paket: TTL önce 4, sonra 64'e döner", t1.take(2) == listOf(UdpDecoy.TTL, 64), "ttl=$t1")
        T.check("UDP sahte paket: sayaç 4", t1.last() == 1004, "ttl=$t1")
        val (g2, _) = scenario(false, true, discovery)
        T.check("ayar kapalıyken sahte paket yok (yalnızca gerçek paket)", g2.size == 1 && g2[0].contentEquals(discovery))
        val (g3, _) = scenario(true, false, discovery)
        T.check("TTL ayarlanamıyorsa sahte paket gönderilmez (sunucuya ulaşmasın)", g3.size == 1 && g3[0].contentEquals(discovery))
        val other = ByteArray(74).also { it[1] = 2; it[3] = 70 }
        val (g4, _) = scenario(true, true, other)
        T.check("parmak izine uymayan UDP paketine dokunulmaz", g4.size == 1 && g4[0].contentEquals(other))
    }
    T.check("UdpDecoy: Discord IP keşfi yalnızca 50000-65535 portlarında ve 74 baytta", UdpDecoy.applies(50000, ByteArray(74).also { it[1] = 1; it[3] = 70 }, 0, 74) && !UdpDecoy.applies(49999, ByteArray(74).also { it[1] = 1; it[3] = 70 }, 0, 74) && !UdpDecoy.applies(50000, ByteArray(75).also { it[1] = 1; it[3] = 70 }, 0, 75))
    run {
        fun stun(len: Int = 20, type: Int = 1, cookie: Int = 0x2112A442): ByteArray {
            val b = ByteArray(len)
            b[0] = (type ushr 8).toByte(); b[1] = type.toByte()
            val l = len - 20; b[2] = (l ushr 8).toByte(); b[3] = l.toByte()
            b[4] = (cookie ushr 24).toByte(); b[5] = (cookie ushr 16).toByte(); b[6] = (cookie ushr 8).toByte(); b[7] = cookie.toByte()
            return b
        }
        T.check("UdpDecoy: STUN bağlama isteği 3478 ve 19302-19309'da tanınır", UdpDecoy.applies(3478, stun(), 0, 20) && UdpDecoy.applies(19302, stun(32), 0, 32) && UdpDecoy.applies(19309, stun(), 0, 20))
        T.check("UdpDecoy: STUN dışı (tür, çerez, uzunluk, port) reddedilir", !UdpDecoy.applies(3478, stun(type = 0x0101), 0, 20) && !UdpDecoy.applies(3478, stun(cookie = 1), 0, 20) && !UdpDecoy.applies(3478, stun(22), 0, 22) && !UdpDecoy.applies(3479, stun(), 0, 20) && !UdpDecoy.applies(19310, stun(), 0, 20))
        T.check("UdpDecoy: kısa ya da sınır dışı girdide çökmez", !UdpDecoy.applies(3478, ByteArray(10), 0, 10) && !UdpDecoy.applies(3478, stun(), 5, 20) && !UdpDecoy.applies(3478, stun(), -1, 20))
    }

    // --- QUIC Initial (QuicInitial): UDP/443'ün ilk paketi yeniden kurulur, önce düşük TTL'li sahte gider
    run {
        val init = QuicVectors.bytes(QuicVectors.INITIAL)
        fun freeUdp2(): DatagramSocket {
            for (port in 52500..52800) try { return DatagramSocket(port, InetAddress.getByAddress(LO4)) } catch (_: Exception) {}
            throw IllegalStateException("boş UDP portu yok")
        }
        fun scenario(on: Boolean, ttlWorks: Boolean, payload: ByteArray): Triple<List<ByteArray>, List<Int>, Long> {
            val ttls = java.util.Collections.synchronizedList(ArrayList<Int>())
            val r = GRig(udpTtl = { _, t -> ttls.add(t); ttlWorks })
            r.gw.config.dpi = true
            r.gw.config.quicSplit = on
            val us = freeUdp2()
            r.gw.config.quicPort = us.localPort
            val got = java.util.Collections.synchronizedList(ArrayList<ByteArray>())
            Thread({ try { val bb = ByteArray(2000); val p = DatagramPacket(bb, bb.size); while (true) { p.length = bb.size; us.receive(p); got.add(bb.copyOf(p.length)) } } catch (_: Exception) {} }).also { it.isDaemon = true }.start()
            val b = ByteArray(2048)
            val n = Gw.udp(b, false, CLI4, LO4, 52001, us.localPort, payload, 0, payload.size)
            r.gw.onPacket(b.copyOf(n), n)
            // Sabit 500 ms yerine: ilk paket gelene dek (en çok 3 sn) ve sonra 300 ms yeni paket gelmeyene dek beklenir (yük altında dalgalanmasın).
            run {
                val end = System.nanoTime() + 3_000_000_000L
                while (got.isEmpty() && System.nanoTime() < end) Thread.sleep(10)
                var last = -1
                while (got.size != last && System.nanoTime() < end) { last = got.size; Thread.sleep(300) }
            }
            val res = Triple(ArrayList(got) as List<ByteArray>, ArrayList(ttls) as List<Int>, r.gw.stats().quicFakes * 10 + r.gw.stats().quicSplits)
            us.close(); r.close()
            return res
        }
        val (g1, t1, c1) = scenario(true, true, init)
        T.check("QUIC Initial: sunucuya önce sahte, sonra yeniden kurulmuş gerçek paket ulaşır", g1.size == 2 && g1.all { it.size == init.size } && !g1[0].contentEquals(init) && !g1[1].contentEquals(init) && !g1[0].contentEquals(g1[1]))
        T.check("QUIC Initial: ikinci paket ters sıralı CRYPTO çerçeveleri, birleşince özgün ClientHello", run {
            val f = g1.getOrNull(1)?.let { x -> QuicInitial.parse(x, 0, x.size) }?.let { QuicInitial.frames(it.plain) }
            f != null && f.size == 2 && QuicInitial.assemble(f)!!.contentEquals(QuicVectors.bytes(QuicVectors.HELLO))
        })
        T.check("QUIC Initial: birinci paketin SNI'sı sahte (iana.org)", run {
            val h = g1.getOrNull(0)?.let { x -> QuicInitial.parse(x, 0, x.size) }?.let { QuicInitial.frames(it.plain) }?.let { QuicInitial.assemble(it) }
            h != null && QuicInitial.sni(h)!!.let { String(h, it[0], it[1]) }.endsWith("iana.org")
        })
        T.check("QUIC Initial: TTL önce ${Dpi.FAKE_TTL}, sonra 64; sayaçlar 1 sahte + 1 bölme", t1.take(2) == listOf(Dpi.FAKE_TTL, 64) && c1 == 11L, "ttl=$t1 c=$c1")
        val (g2, _, c2) = scenario(false, true, init)
        T.check("QUIC Initial: ayar kapalıyken paket olduğu gibi gider", g2.size == 1 && g2[0].contentEquals(init) && c2 == 0L)
        val (g3, _, c3) = scenario(true, false, init)
        T.check("QUIC Initial: TTL ayarlanamıyorsa sahte yok, yalnızca yeniden kurulmuş paket", g3.size == 1 && !g3[0].contentEquals(init) && c3 == 1L)
        val junk = ByteArray(1250) { 5 }
        val (g4, _, c4) = scenario(true, true, junk)
        T.check("QUIC olmayan UDP/443 paketine dokunulmaz", g4.size == 1 && g4[0].contentEquals(junk) && c4 == 0L)
    }

    // --- bağlantı kurulduktan sonraki kesinti (CutWatch): kayıt ortasında susma, sıfırlama, cevapsız istek
    fun partialRecord(extra: Int) = byteArrayOf(0x16, 3, 3, 0, 100) + ByteArray(extra) { 1 }       // 100 baytlık kaydın yalnızca başı
    run {
        val r = GRig()
        r.gw.config.dpi = true
        r.gw.config.cutStallMs = 400
        val host = "kesinti.example.net"
        val hello = testHello(host)
        val srv = Srv { s -> readFully(s, hello.size, 1500); s.getOutputStream().write(TLS_REPLY + partialRecord(10)); s.getOutputStream().flush(); Thread.sleep(2500) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        val got = c.read(TLS_REPLY.size + 15, 4000)
        T.check("kesinti: cevap ve yarım kayıt istemciye aktarılır", got.size == TLS_REPLY.size + 15, "n=${got.size}")
        Thread.sleep(1300)
        T.check("kesinti: kayıt ortasında susma bir kez sayılır", r.gw.stats().cuts == 1L, "cuts=${r.gw.stats().cuts}")
        T.check("kesinti: tek belirti yöntemi değiştirmez (puan 2 < 3)", r.gw.stats().cutSwitched == 0L && r.gw.planner.first(host, Dpi.TLS) == Dpi.TLS_ORDER[0])
        val c2 = GCli(r, srv.port)
        c2.connect(); c2.write(hello)
        c2.read(TLS_REPLY.size + 15, 4000)
        Thread.sleep(1300)
        T.check("kesinti: ikinci belirti toplamı eşiğe getirir, yöntem SIRADAKİNE geçer", r.gw.stats().cuts == 2L && r.gw.stats().cutSwitched == 1L && r.gw.planner.first(host, Dpi.TLS) == Dpi.TLS_ORDER[1],
            "cuts=${r.gw.stats().cuts} sw=${r.gw.stats().cutSwitched} first=${r.gw.planner.first(host, Dpi.TLS)}")
        val b = srv.accepted.get()
        val c3 = GCli(r, srv.port)
        c3.connect(); c3.write(hello)
        c3.read(TLS_REPLY.size + 15, 4000)
        T.check("kesinti: yeni bağlantı artık yeni yöntemle başlar ve tekrar sayılmaz", srv.accepted.get() == b + 1)
        srv.close(); r.close()
    }
    run {
        // sağlıklı: tam kayıt, sonra boşta; istemcinin el sıkışma bitişi (~80 bayt) cevap beklemez
        val r = GRig()
        r.gw.config.dpi = true
        r.gw.config.cutStallMs = 300; r.gw.config.cutNoreplyMs = 300
        val hello = testHello("saglikli.example.net")
        val srv = Srv { s -> readFully(s, hello.size, 1500); s.getOutputStream().write(TLS_REPLY); s.getOutputStream().flush(); Thread.sleep(2500) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        c.read(TLS_REPLY.size, 4000)
        c.write(ByteArray(80) { 7 })
        Thread.sleep(1200)
        T.check("kesinti: tam kayıt + boşta bağlantı + küçük istemci yazması kesinti sayılmaz", r.gw.stats().cuts == 0L, "cuts=${r.gw.stats().cuts}")
        srv.close(); r.close()
    }
    run {
        // gerçek istek (>= 300 bayt) cevapsız kalırsa "cevapsız" sayılır (zayıf belirti: tek başına yöntem değiştirmez)
        val r = GRig()
        r.gw.config.dpi = true
        r.gw.config.cutNoreplyMs = 300
        val hello = testHello("cevapsiz.example.net")
        val srv = Srv { s -> readFully(s, hello.size, 1500); s.getOutputStream().write(TLS_REPLY); s.getOutputStream().flush(); Thread.sleep(2500) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        c.read(TLS_REPLY.size, 4000)
        c.write(ByteArray(400) { 9 })
        Thread.sleep(1200)
        T.check("kesinti: cevapsız gerçek istek bir kez sayılır, yöntem değişmez", r.gw.stats().cuts == 1L && r.gw.stats().cutSwitched == 0L, "cuts=${r.gw.stats().cuts}")
        srv.close(); r.close()
    }
    run {
        // kayıt ortasında sıfırlama kesintidir; iş bittikten sonraki sıfırlama değildir
        val r = GRig()
        r.gw.config.dpi = true
        val hello = testHello("sifirla.example.net")
        val srv = Srv { s ->
            readFully(s, hello.size, 1500)
            s.getOutputStream().write(TLS_REPLY + partialRecord(10)); s.getOutputStream().flush()
            Thread.sleep(300); s.setSoLinger(true, 0); s.close()
        }
        val c = GCli(r, srv.port)
        c.connect(); c.write(hello)
        c.read(TLS_REPLY.size + 15, 4000)
        Thread.sleep(800)
        T.check("kesinti: kayıt ortasında sıfırlama kesinti sayılır", r.gw.stats().cuts == 1L, "cuts=${r.gw.stats().cuts}")
        srv.close(); r.close()
        val r2 = GRig()
        r2.gw.config.dpi = true
        val hello2 = testHello("sifirla2.example.net")
        val srv2 = Srv { s ->
            readFully(s, hello2.size, 1500)
            s.getOutputStream().write(TLS_REPLY); s.getOutputStream().flush()
            Thread.sleep(300); s.setSoLinger(true, 0); s.close()
        }
        val c2 = GCli(r2, srv2.port)
        c2.connect(); c2.write(hello2)
        c2.read(TLS_REPLY.size, 4000)
        Thread.sleep(800)
        T.check("kesinti: iş bittikten sonraki sıfırlama (canlı tutma kapanışı) sayılmaz", r2.gw.stats().cuts == 0L, "cuts=${r2.gw.stats().cuts}")
        srv2.close(); r2.close()
    }
}

/** Gerçek bir sunucu TLS kaydıyla (ServerHello) cevap verir; DPI, TLS olmayan ilk cevabı sahte enjeksiyon sayıp yöntem değiştirir. */
private val TLS_REPLY = byteArrayOf(0x16, 3, 3, 0, 7) + "SERVER-".toByteArray()

/** Yeni akış hız sınırlayıcısı (otomatik korumanın FLOOD önlemi). */
fun runGatewayFlowBudgetTests() {
    gatewayCombinedTests()
    T.group("Ağ geçidi: yeni akış hız sınırı (jeton kovası)")
    run {
        val r = GRig()
        try {
            repeat(30) { GCli(r, 9).send(F_SYN, mss = 1460) }
            Thread.sleep(500)
            T.check("sınır kapalıyken (0) hiçbir akış reddedilmez", r.gw.shedFlows() == 0L)
            r.gw.config.flowBudget = 5
            repeat(40) { GCli(r, 9).send(F_SYN, mss = 1460) }
            val until = System.currentTimeMillis() + 4000
            while (System.currentTimeMillis() < until && r.gw.shedFlows() < 20) Thread.sleep(25)      // paketler ağ geçidi iş parçacığında işlenir
            Thread.sleep(150)
            val shed = r.gw.shedFlows()
            T.check("saniyede 5 sınırında kısa patlamada (2×) kalan akışlar reddedilir", shed in 20..32, "reddedilen=$shed")
            r.gw.config.flowBudget = 0
            Thread.sleep(150)
            val before = r.gw.shedFlows()
            repeat(10) { GCli(r, 9).send(F_SYN, mss = 1460) }
            Thread.sleep(500)
            T.check("sınır kaldırılınca yeni akışlar yeniden kabul edilir", r.gw.shedFlows() == before)
        } finally { r.close() }
    }
}

/** DPI atlatma + reklam engelleme + DoH engeli + QUIC + parmak izi AYNI ANDA açıkken her biri kendi işini yapar, birbirini bozmaz. */
private fun gatewayCombinedTests() {
    T.group("Ağ geçidi: tüm modüller birlikte (DPI + reklam + DoH/QUIC engeli)")
    val r = GRig()
    val c0 = r.gw.config
    c0.dpi = true; c0.blockDoh = true; c0.quicWithAds = true; c0.ja3 = true; c0.ipNames = true; c0.adsDns = true
    c0.ads = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example", "izleyici.test"))
    val got = java.util.concurrent.ConcurrentHashMap<Int, Int>()
    val srv = Srv { s ->
        val b = ByteArray(4096); val n = s.getInputStream().read(b)
        if (n > 0) got.merge(s.localPort, n) { x, y -> x + y }
        s.getOutputStream().write(TLS_REPLY); s.getOutputStream().flush(); Thread.sleep(250)
    }
    fun rstSeen(c: GCli): Boolean { while (true) { val sg = c.next(2500) ?: return false; if (sg.flags and F_RST != 0) return true } }

    // 1) izinli site: DPI bölmesi uygulanır, cevap eksiksiz döner
    val hello = testHello("guvenli.example.org")
    val a = GCli(r, srv.port); a.connect(); a.write(hello)
    T.check("birlikte: izinli site DPI bölmesiyle açılır, cevap gelir", a.read(12).contentEquals(TLS_REPLY), "st=${r.gw.stats()}")
    T.check("birlikte: DPI el sıkışma başarısı sayıldı, başarısızlık yok", r.gw.stats().recentDpiOk >= 1 && r.gw.stats().recentDpiFail == 0, "st=${r.gw.stats()}")
    // 2) reklam adı: DPI açık olsa da kesilir ve sunucu ClientHello baytlarını hiç görmez
    val before = got.values.sum()
    val b = GCli(r, srv.port); b.connect(); b.write(testHello("cdn.reklam.example"))
    T.check("birlikte: reklam adı DPI açıkken de kesilir", rstSeen(b) && r.gw.stats().blockedHosts >= 1L)
    Thread.sleep(200)
    T.check("birlikte: engellenen akışın ClientHello'su sunucuya sızmaz", got.values.sum() == before, "before=$before after=${got.values.sum()}")
    // 3) DoH sağlayıcı adı (SNI): kesilir
    val d = GCli(r, srv.port); d.connect(); d.write(testHello("dns.google"))
    T.check("birlikte: DoH sağlayıcı adı (SNI) kesilir", rstSeen(d) && r.gw.stats().dohBlocked >= 1L, "st=${r.gw.stats()}")
    // 4) düz DNS ile reklam adı: yerelde cevaplanır
    val q = Dns.buildQuery(0x5151, "banner.reklam.example")
    val buf = ByteArray(2048)
    val n = Gw.udp(buf, false, CLI4, byteArrayOf(9, 9, 9, 9), 51555, 53, q, 0, q.size)
    r.gw.onPacket(buf.copyOf(n), n)
    val rep = r.q.poll(2, TimeUnit.SECONDS)
    T.check("birlikte: düz DNS'teki reklam adı yerelde engellenir", rep != null && Packets.u16(rep, 28) == 0x5151 && r.gw.stats().dnsBlocked >= 1L)
    // 5) karışık akışlar art arda (test altyapısının tek paket kuyruğu eşzamanlı okumaya elverişli değildir): her biri kendi sonucunu alır
    var okCount = 0; var blkCount = 0
    for (i in 0 until 8) {
        val blocked = i % 2 == 1
        val c = GCli(r, srv.port); c.connect()
        c.write(testHello(if (blocked) "x$i.izleyici.test" else "site$i.example.org"))
        if (blocked) { if (rstSeen(c)) blkCount++ } else if (c.read(12).contentEquals(TLS_REPLY)) okCount++
    }
    T.check("birlikte: karışık akışlar (4 izinli açılır, 4 reklam kesilir)", okCount == 4 && blkCount == 4, "ok=$okCount blk=$blkCount")
    // 6) acil durum anahtarı hepsini devre dışı bırakır
    c0.passthrough = true
    val e = GCli(r, srv.port); e.connect(); e.write(testHello("cdn.reklam.example"))
    T.check("birlikte: passthrough hepsini kapatır", e.read(12).contentEquals(TLS_REPLY))
    srv.close(); r.close()
}

/** Uygulama bazlı reklam kipleri: muaf uygulama engellenmez, sıkı uygulama en sıkı listeyle süzülür, istatistik sahibine yazılır. */
fun runAppAdsGatewayTests() {
    T.group("Ağ geçidi: uygulama bazlı reklam kipleri (muaf / sıkı) ve istatistik")
    val srvOk = "ACIK".toByteArray()
    val r = GRig()
    try {
        AppAds.reset()
        val owners = java.util.concurrent.ConcurrentHashMap<Int, String>()
        AppAds.owner = { _, _, sport, _, _ -> owners[sport] }
        AppAds.setRules(mapOf("banka.app" to AppMode.EXEMPT, "oyun.app" to AppMode.STRICT))
        val base = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example"))
        val strict = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("reklam.example", "ekstra.example"))
        r.gw.config.ads = base
        r.gw.config.strictSource = { strict }
        val srv = Srv { s -> Thread.sleep(300); s.getOutputStream().write(srvOk); s.getOutputStream().flush(); Thread.sleep(300) }

        fun tryHello(pkg: String, sni: String): Boolean {            // true = geçti
            val c = GCli(r, srv.port)
            owners[c.sport] = pkg
            c.connect(); c.write(testHello(sni))
            while (true) { val s = c.next(2500) ?: return false; if (s.flags and F_RST != 0) return false; if (s.data.isNotEmpty()) return String(s.data) == "ACIK" }
        }
        T.check("genel uygulama: engelli ad kesilir", !tryHello("diger.app", "cdn.reklam.example"))
        T.check("muaf uygulama: aynı ad geçer (bankacılık bozulmaz)", tryHello("banka.app", "cdn.reklam.example"))
        T.check("genel uygulama: yalnızca sıkı listedeki ad geçer", tryHello("diger.app", "x.ekstra.example"))
        T.check("sıkı uygulama: sıkı listedeki ad da kesilir", !tryHello("oyun.app", "x.ekstra.example"))
        T.check("sahibi bilinmeyen bağlantı: genel ayar", !tryHello("", "cdn.reklam.example"))
        val rows = AppAds.top(10).associate { it.pkg to it.blocked }
        T.check("istatistik sahibine yazılır (diger.app 1, oyun.app 1, muaf uygulama 0)", rows["diger.app"] == 1 && rows["oyun.app"] == 1 && rows["banka.app"] == null, "rows=$rows")

        // Düz DNS (UDP/53): muaf uygulamanın sorgusu yerelde engellenmez, genel uygulamanınki engellenir.
        val b = ByteArray(2048)
        fun ask(pkg: String, sport: Int, name: String): ByteArray? {
            owners[sport] = pkg
            val d = Dns.buildQuery(0x5500 + sport % 200, name)
            val n = Gw.udp(b, false, CLI4, byteArrayOf(8, 8, 8, 8), sport, 53, d, 0, d.size)
            r.gw.onPacket(b.copyOf(n), n)
            return r.q.poll(700, TimeUnit.MILLISECONDS)
        }
        val before = r.gw.stats().dnsBlocked
        val exemptReply = ask("banka.app", 54001, "banner.reklam.example")
        T.check("muaf uygulamanın DNS sorgusu yerelde engellenmez", (exemptReply == null || !Dns.isLocalBlock(exemptReply, 28, exemptReply.size - 28)) && r.gw.stats().dnsBlocked == before)
        val normalReply = ask("diger.app", 54002, "banner.reklam.example")
        T.check("genel uygulamanın DNS sorgusu yerelde engellenir", normalReply != null && r.gw.stats().dnsBlocked == before + 1)
        val strictReply = ask("oyun.app", 54003, "x.ekstra.example")
        T.check("sıkı uygulamanın DNS sorgusu sıkı listeyle engellenir", strictReply != null && r.gw.stats().dnsBlocked == before + 2)
        val rows2 = AppAds.top(10).associate { it.pkg to it.blocked }
        T.check("DNS engelleri de sahibine yazılır", rows2["diger.app"] == 2 && rows2["oyun.app"] == 2, "rows=$rows2")
        srv.close()
    } finally {
        AppAds.reset()
        r.close()
    }
}

/** DPI: başarılı bağlantı yöntem tablosuna, site belleğine (özet anahtarlı) ve günlüğe yansır. */
fun runDpiMemoryGatewayTests() {
    T.group("Ağ geçidi: DPI yöntem tablosu, site belleği ve günlük")
    val r = GRig()
    try {
        val mem = PlanMemory()
        r.gw.config.planMemory = mem
        r.gw.config.dpi = true
        r.gw.config.dpiOnLocal = true
        r.gw.networkChanged(NetKind.WIFI)
        val reply = byteArrayOf(0x16, 3, 3, 0, 4, 2, 0, 0, 0)
        val srv = Srv { s -> Thread.sleep(150); s.getOutputStream().write(reply); s.getOutputStream().flush(); Thread.sleep(300) }
        val c = GCli(r, srv.port)
        c.connect(); c.write(testHello("site.example.org"))
        val got = c.read(reply.size)
        T.check("DPI açıkken TLS cevabı gelir", got.size == reply.size)
        Thread.sleep(100)
        val table = r.gw.dpiTable()
        T.check("yöntem tablosu: kazanılan yöntem görünür", table.isNotEmpty() && table.first().startsWith("TLS ") && table.first().contains("1 kazanç"), table.toString())
        val key = PlanMemory.key(NetKind.WIFI, "")
        val sites = mem.sites(key)
        val sk = Dpi.siteKey("127.0.0.1:${srv.port}")
        T.check("site belleğine özet anahtarıyla yazılır (ad açık yok)", sites.isNotEmpty() && sites.keys.all { it.matches(Regex("[0-9a-f]{1,12}")) } && !mem.encode().contains("site.example") && !mem.encode().contains("127.0.0.1"), "sites=$sites enc=${mem.encode()} sk=$sk")
        val journal = Journal.log.dump()
        T.check("ağ değişimi [DPI] günlüğe yazılır", journal.contains("[DPI] ağ değişti"))
        srv.close()
    } finally { r.close() }
}

/** Sızma testi: DPI açık ağ geçidinde bozulmuş ClientHello'lar ve kötü niyetli sunucu cevapları (4x). */
fun runPenGatewayTests() {
    T.group("Sızma testi: ağ geçidi akışları (bozuk ClientHello, kötü sunucu cevabı)")
    val rnd = java.util.Random(1020)
    val uncaught = java.util.concurrent.CopyOnWriteArrayList<Throwable>()
    val oldH = Thread.getDefaultUncaughtExceptionHandler()
    Thread.setDefaultUncaughtExceptionHandler { _, e -> uncaught.add(e) }
    val r = GRig()
    try {
        r.gw.config.dpi = true; r.gw.config.dpiOnLocal = true
        r.gw.networkChanged(NetKind.WIFI)
        val bad = listOf(
            ByteArray(0), byteArrayOf(0x16, 3, 1, 0xFF.toByte(), 0xFF.toByte()), ByteArray(70_000) { 0x16 },
            byteArrayOf(0x16, 3, 3, 0, 4, 2, 0, 0, 0) + ByteArray(5000) { 0x41 }, "garbage\r\n\r\n".toByteArray())
        val srv = Srv { s ->
            val o = s.getOutputStream()
            when (rnd.nextInt(4)) {
                0 -> { o.write(ByteArray(rnd.nextInt(3000)).also { rnd.nextBytes(it) }); o.flush() }
                1 -> { /* hiç cevap verme */ Thread.sleep(200) }
                2 -> { s.setSoLinger(true, 0); s.close() }                              // RST
                else -> { o.write(bad[rnd.nextInt(bad.size)]); o.flush() }
            }
        }
        var ok = 0
        repeat(16 * FUZZ_X) {
            val c = GCli(r, srv.port)
            try {
                if (c.connect() != null) {
                    val hello = testHello("pen${it}.example.org")
                    val m = hello.copyOf()
                    repeat(1 + rnd.nextInt(5)) { k -> m[rnd.nextInt(m.size)] = rnd.nextInt().toByte() }
                    c.write(if (rnd.nextInt(3) == 0) bad[rnd.nextInt(bad.size)].copyOf(minOf(1400, bad[0].size + 1400)) else m)
                    c.read(1, 300)
                    ok++
                }
            } catch (_: Throwable) {}
        }
        Thread.sleep(500)
        T.check("bozuk istemci/sunucu akışlarında ağ geçidi çalışmayı sürdürür ($ok akış)", ok > 0 && uncaught.isEmpty(), uncaught.firstOrNull().toString())
        // sonrasında sağlıklı bir akış hâlâ geçer
        val good = byteArrayOf(0x16, 3, 3, 0, 4, 2, 0, 0, 0)
        val srv2 = Srv { s -> Thread.sleep(100); s.getOutputStream().write(good); s.getOutputStream().flush(); Thread.sleep(200) }
        val c2 = GCli(r, srv2.port)
        c2.connect(); c2.write(testHello("after.example.org"))
        T.check("saldırı sonrası normal akış yine çalışır", c2.read(good.size).size == good.size)
        srv.close(); srv2.close()
    } finally { r.close(); Thread.setDefaultUncaughtExceptionHandler(oldH) }
}

/** Enjekte edilmiş HTTP engel yönlendirmesi başarı sayılmaz: sıradaki yöntemle yeniden denenir. */
fun runBlockRedirectGatewayTests() {
    T.group("Ağ geçidi: HTTP'de enjekte edilmiş engel yönlendirmesi yeniden denenir")
    val r = GRig()
    try {
        r.gw.config.dpi = true; r.gw.config.dpiOnLocal = true
        val conns = AtomicInteger()
        val srv = Srv { s ->
            val n = conns.incrementAndGet()
            val buf = ByteArray(2048); s.getInputStream().read(buf)
            val o = s.getOutputStream()
            if (n == 1) o.write("HTTP/1.1 302 Found\r\nLocation: http://195.175.254.2/\r\nContent-Length: 0\r\n\r\n".toByteArray())
            else o.write("HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok".toByteArray())
            o.flush(); Thread.sleep(300)
        }
        val c = GCli(r, srv.port)
        c.connect(); c.write("GET / HTTP/1.1\r\nHost: blocked.example\r\n\r\n".toByteArray())
        val got = String(c.read(40, 6000))
        T.check("istemci gerçek cevabı alır (enjekte yönlendirme değil)", got.startsWith("HTTP/1.1 200"), got.take(60))
        T.check("enjekte sayacı artar, ikinci bağlantı açılır", r.gw.stats().injected >= 1 && conns.get() >= 2, "injected=${r.gw.stats().injected} conns=${conns.get()}")
        srv.close()
    } finally { r.close() }
}

/** Seçici QUIC düşürme: yalnızca TCP'de engel yöntemi gerektiren sunucu adresine giden UDP/443 düşürülür. */
fun runSelectiveQuicTests() {
    T.group("Ağ geçidi: seçici QUIC düşürme")
    val r = GRig()
    try {
        r.gw.config.dpi = true
        val blocked = byteArrayOf(93.toByte(), 184.toByte(), 216.toByte(), 34)
        val other = byteArrayOf(93.toByte(), 184.toByte(), 216.toByte(), 35)
        val buf = ByteArray(1500)
        fun quic(dst: ByteArray, sport: Int) {
            val data = ByteArray(1200) { 0x41 }
            val n = Gw.udp(buf, false, CLI4, dst, sport, 443, data, 0, data.size)
            r.gw.onPacket(buf.copyOf(n), n)
            Thread.sleep(250)                                   // paketler ağ geçidi iş parçacığında işlenir
        }
        quic(blocked, 50001)
        T.check("adres işaretli değilken QUIC düşürülmez", r.gw.stats().quicDropped == 0L)
        r.gw.noteBypass(blocked)
        quic(blocked, 50002)
        T.check("işaretli adrese QUIC düşürülür", r.gw.stats().quicDropped == 1L, r.gw.stats().quicDropped.toString())
        quic(other, 50003)
        T.check("başka adrese QUIC düşürülmez (hız korunur)", r.gw.stats().quicDropped == 1L)
        r.gw.config.quicSelective = false
        quic(blocked, 50004)
        T.check("ayar kapalıyken düşürülmez", r.gw.stats().quicDropped == 1L)
        r.gw.config.quicSelective = true; r.gw.config.dpi = false
        quic(blocked, 50005)
        T.check("DPI kapalıyken düşürülmez", r.gw.stats().quicDropped == 1L)
    } finally { r.close() }
}

/** Engelli site listesindeki bir adın QUIC'i (SNI) DPI açıkken düşürülür; listede olmayan düşmez. */
fun runListedQuicTests() {
    T.group("Ağ geçidi: engelli listedeki ad için QUIC düşürme")
    val r = GRig()
    try {
        r.gw.config.dpi = true
        val dst = byteArrayOf(93.toByte(), 184.toByte(), 216.toByte(), 40)
        val buf = ByteArray(1500)
        val pkt = QuicVectors.bytes(QuicVectors.INITIAL)                 // SNI = discord.com
        fun initial(sport: Int) {
            val n = Gw.udp(buf, false, CLI4, dst, sport, 443, pkt, 0, pkt.size)
            r.gw.onPacket(buf.copyOf(n), n)
            Thread.sleep(250)
        }
        BlockedSites.set(setOf("baska.example"))
        initial(50101)
        T.check("listede olmayan adın QUIC'i düşürülmez", r.gw.stats().quicDropped == 0L)
        BlockedSites.set(setOf("discord.com"))
        initial(50102)
        T.check("listedeki adın QUIC Initial'ı düşürülür", r.gw.stats().quicDropped == 1L, r.gw.stats().quicDropped.toString())
        r.gw.config.quicSelective = false
        initial(50103)
        T.check("seçici QUIC kapalıyken düşürülmez", r.gw.stats().quicDropped == 1L)
        r.gw.config.quicSelective = true
        BlockedSites.reset()
        initial(50104)
        T.check("liste boşalınca düşürme durur", r.gw.stats().quicDropped == 1L)
    } finally { BlockedSites.reset(); r.close() }
}

/** Birden çok TCP segmentine yayılan büyük ClientHello (post-quantum tarayıcılar): akış eksiksiz iletilir, bölme uygulanır. */
fun runMultiSegmentHelloTests() {
    T.group("Ağ geçidi: çok segmentli büyük ClientHello")
    val r = GRig()
    try {
        r.gw.config.dpi = true; r.gw.config.dpiOnLocal = true
        val hello = testHello("pq.example.org", pad = 2600)
        val got = java.io.ByteArrayOutputStream()
        val reply = byteArrayOf(0x16, 3, 3, 0, 4, 2, 0, 0, 0)
        val srv = Srv { s ->
            val ins = s.getInputStream(); val b = ByteArray(4096)
            s.soTimeout = 3000
            try { while (got.size() < hello.size) { val n = ins.read(b); if (n < 0) break; got.write(b, 0, n) } } catch (_: Exception) {}
            s.getOutputStream().write(reply); s.getOutputStream().flush(); Thread.sleep(300)
        }
        val c = GCli(r, srv.port)
        c.connect()
        var off = 0
        while (off < hello.size) { val n = minOf(1200, hello.size - off); c.write(hello.copyOfRange(off, off + n)); off += n }
        val back = c.read(reply.size, 6000)
        T.check("sunucu eksiksiz ClientHello alır (${hello.size} bayt, ${got.size()} geldi)", got.size() >= hello.size, "geldi=${got.size()}")
        val h = Dpi.Hello()
        val received = got.toByteArray()
        T.check("alınan akışta SNI hâlâ okunur ya da kayıtlar bölünmüştür", Dpi.parseHello(received, received.size, h) || received.size > hello.size)
        T.check("cevap istemciye ulaşır", back.size == reply.size)
        srv.close()
    } finally { r.close() }
}

fun runDpiExtrasTests() {
    T.group("Ağ geçidi: tanılama DPI yan sayaçları")
    val r = GRig()
    try {
        BlockedSites.set(setOf("a.example", "b.example"))
        val x = r.gw.dpiExtras()
        T.check("yan sayaç satırı sayıları içerir ve 160 karakteri aşmaz", x.size == 1 && x[0].contains("engelli liste: 2 ad") && x[0].contains("QUIC düşürülen: 0") && x[0].length <= 160, x.toString())
        T.check("DPI tablosu boşken boş kalır (yan sayaç eklenmez)", r.gw.dpiTable().isEmpty())
    } finally { BlockedSites.reset(); r.close() }
}

fun runDpiListedOnlyTests() {
    T.group("Ağ geçidi: DPI yalnızca listedeki sitelere")
    fun hit(listed: Set<String>, name: String, only: Boolean): Pair<Long, Long> {
        val r = GRig()
        try {
            r.gw.config.dpi = true; r.gw.config.dpiOnLocal = true; r.gw.config.dpiListedOnly = only
            BlockedSites.set(listed)
            val reply = byteArrayOf(0x16, 3, 3, 0, 4, 2, 0, 0, 0)
            val srv = Srv { s -> val b = ByteArray(4096); s.soTimeout = 3000; try { s.getInputStream().read(b) } catch (_: Exception) {}; s.getOutputStream().write(reply); s.getOutputStream().flush(); Thread.sleep(200) }
            val c = GCli(r, srv.port)
            c.connect()
            c.write(testHello(name))
            c.read(reply.size, 4000)
            Thread.sleep(150)
            srv.close()
            return r.gw.stats().split to r.gw.listedSkipped()
        } finally { BlockedSites.reset(); r.close() }
    }
    val a = hit(setOf("blocked.example"), "blocked.example", true)
    T.check("listedeki site bölünür, muaf sayılmaz", a.first > 0 && a.second == 0L, a.toString())
    val b = hit(setOf("blocked.example"), "other.example", true)
    T.check("listede olmayan site düz geçer ve muaf sayılır", b.first == 0L && b.second == 1L, b.toString())
    val c = hit(emptySet(), "other.example", true)
    T.check("liste boşsa DPI her siteye uygulanır (kapalı kalmaz)", c.first > 0 && c.second == 0L, c.toString())
    val d = hit(setOf("blocked.example"), "other.example", false)
    T.check("ayar kapalıyken eskisi gibi tüm sitelere", d.first > 0 && d.second == 0L, d.toString())
}

fun runMitmGatewayTests() {
    T.group("Ağ geçidi: tarayıcı kipi yönlendirmesi")
    class Hook(val want: Set<String>) : MitmHook {
        val expects = java.util.concurrent.CopyOnWriteArrayList<String>()
        val asked = java.util.concurrent.CopyOnWriteArrayList<String>()
        lateinit var proxy: Srv
        override fun wants(host: String, client: ByteArray, cport: Int, server: ByteArray, sport: Int): Boolean { asked.add("$host:$sport"); return host in want }
        override fun port() = proxy.port
        override fun expect(localPort: Int, host: String, addr: java.net.InetAddress, port: Int) { expects.add("$localPort|$host|${addr.hostAddress}|$port") }
    }
    fun run(host: String, want: Set<String>, mitmOn: Boolean): Triple<Hook, ByteArray, Pair<Int, Int>> {
        val r = GRig()
        try {
            val hello = testHello(host)
            val reply = byteArrayOf(0x16, 3, 3, 0, 4, 2, 0, 0, 0)
            val gotProxy = java.io.ByteArrayOutputStream(); val remote = java.util.concurrent.atomic.AtomicInteger(-1)
            val proxy = Srv { s -> remote.set(s.port); val b = ByteArray(4096); s.soTimeout = 3000; val n = try { s.getInputStream().read(b) } catch (_: Exception) { -1 }; if (n > 0) gotProxy.write(b, 0, n); s.getOutputStream().write(reply); s.getOutputStream().flush(); Thread.sleep(200) }
            val origin = Srv { s -> val b = ByteArray(4096); s.soTimeout = 3000; try { s.getInputStream().read(b) } catch (_: Exception) {}; s.getOutputStream().write(byteArrayOf(0x16, 3, 3, 0, 4, 2, 9, 9, 9)); s.getOutputStream().flush(); Thread.sleep(200) }
            val hook = Hook(want); hook.proxy = proxy
            if (mitmOn) r.gw.config.mitm = hook
            val c = GCli(r, origin.port)
            c.connect()
            c.write(hello)
            val back = c.read(reply.size, 4000)
            Thread.sleep(150)
            val res = Triple(hook, back, origin.accepted.get() to proxy.accepted.get())
            check(gotProxy.size() == 0 || gotProxy.toByteArray().contentEquals(hello)) { "proxy gördüğü bayt eşleşmedi" }
            proxy.close(); origin.close()
            return res
        } finally { r.close() }
    }
    val (h1, b1, acc1) = run("site.example.com", setOf("site.example.com"), true)
    T.check("listedeki ad: hook soruldu ve gerçek hedef bildirildi", h1.asked.contains("site.example.com:${acc1.let { h1.expects.firstOrNull()?.split('|')?.get(3) }}") && h1.expects.size == 1 && h1.expects[0].split('|').let { it[1] == "site.example.com" && it[2] == "127.0.0.1" }, "${h1.asked} ${h1.expects}")
    T.check("ClientHello yerel vekile gitti (cevap vekilden: 0 numaralı baytlar)", b1.size == 9 && b1[6].toInt() == 0, b1.toList().toString())
    T.check("vekile bağlanan yerel port önceden bildirilen porttur", h1.expects.size == 1 && h1.expects[0].split('|')[0].toInt() > 0)
    val (h2, b2, _) = run("other.example.com", setOf("site.example.com"), true)
    T.check("listede olmayan ad gerçek sunucuya gider (cevap kaynaktan: 9 numaralı baytlar)", b2.size == 9 && b2[6].toInt() == 9 && h2.expects.isEmpty(), "${b2.toList()} ${h2.expects}")
    val (h3, b3, _) = run("site.example.com", setOf("site.example.com"), false)
    T.check("kip kapalıyken (hook yok) hiçbir şey yönlendirilmez", b3.size == 9 && b3[6].toInt() == 9 && h3.asked.isEmpty() && h3.expects.isEmpty())
}

fun runDeepGatewayTests() {
    T.group("Derin ağ geçidi: DPI × listeyle sınırlama × tarayıcı kipi tam kombinasyon (oracle denetimli)")
    class Hook : MitmHook {
        lateinit var proxy: Srv
        val expects = java.util.concurrent.atomic.AtomicInteger()
        override fun wants(host: String, client: ByteArray, cport: Int, server: ByteArray, sport: Int) = host == "m.example.com"
        override fun port() = proxy.port
        override fun expect(localPort: Int, host: String, addr: java.net.InetAddress, port: Int) { expects.incrementAndGet() }
    }
    var cases = 0; val wrong = ArrayList<String>()
    for (dpi in listOf(false, true)) for (only in listOf(false, true)) for (list in 0..2) for (mitm in 0..2) for (host in listOf("m.example.com", "x.example.com")) {
        val r = GRig()
        try {
            r.gw.config.dpi = dpi; r.gw.config.dpiOnLocal = true; r.gw.config.dpiListedOnly = only
            BlockedSites.set(when (list) { 0 -> emptySet(); 1 -> setOf(host); else -> setOf("baska.example.net") })
            val reply = byteArrayOf(0x16, 3, 3, 0, 4, 2, 0, 0, 0)
            val proxy = Srv { s -> val b = ByteArray(4096); s.soTimeout = 2500; try { s.getInputStream().read(b) } catch (_: Exception) {}; s.getOutputStream().write(reply); s.getOutputStream().flush(); Thread.sleep(150) }
            val origin = Srv { s -> val b = ByteArray(4096); s.soTimeout = 2500; try { s.getInputStream().read(b) } catch (_: Exception) {}; s.getOutputStream().write(byteArrayOf(0x16, 3, 3, 0, 4, 2, 9, 9, 9)); s.getOutputStream().flush(); Thread.sleep(150) }
            val hook = Hook(); hook.proxy = proxy
            if (mitm > 0) r.gw.config.mitm = hook
            val c = GCli(r, origin.port)
            c.connect(); c.write(testHello(host))
            val back = c.read(9, 4000)
            Thread.sleep(100)
            val st = r.gw.stats()
            val viaProxy = back.size == 9 && back[6].toInt() == 0
            val wantProxy = mitm > 0 && host == "m.example.com"
            val wantSplit = !wantProxy && dpi && (!only || list == 0 || list == 1)
            cases++
            if (viaProxy != wantProxy) wrong += "dpi=$dpi only=$only list=$list mitm=$mitm host=$host: vekil=$viaProxy beklenen=$wantProxy"
            if ((st.split > 0) != wantSplit) wrong += "dpi=$dpi only=$only list=$list mitm=$mitm host=$host: bölme=${st.split} beklenen=$wantSplit"
            if (back.size != 9) wrong += "dpi=$dpi only=$only list=$list mitm=$mitm host=$host: cevap ${back.size} bayt"
            if (wantProxy && hook.expects.get() != 1) wrong += "expect sayısı ${hook.expects.get()}"
            proxy.close(); origin.close()
        } finally { BlockedSites.reset(); r.close() }
    }
    T.check("$cases kombinasyonda yönlendirme ve bölme kararı oracle ile birebir", wrong.isEmpty(), wrong.take(4).toString())

    T.group("Derin ağ geçidi: hook istisnası ve vekil yokken akış çökmez")
    run {
        val r = GRig()
        try {
            r.gw.config.mitm = object : MitmHook {
                override fun wants(host: String, client: ByteArray, cport: Int, server: ByteArray, sport: Int): Boolean = throw IllegalStateException("hook patladı")
                override fun port() = 1
                override fun expect(localPort: Int, host: String, addr: java.net.InetAddress, port: Int) {}
            }
            val origin = Srv { s -> val b = ByteArray(4096); s.soTimeout = 2500; try { s.getInputStream().read(b) } catch (_: Exception) {}; s.getOutputStream().write(byteArrayOf(0x16, 3, 3, 0, 4, 2, 9, 9, 9)); s.getOutputStream().flush(); Thread.sleep(150) }
            val c = GCli(r, origin.port); c.connect(); c.write(testHello("m.example.com"))
            val back = c.read(9, 3000)
            T.check("wants() istisna atsa bile ağ geçidi çökmez; sonraki akış hâlâ çalışır", true)
            val c2 = GCli(r, origin.port); c2.connect(); c2.write(testHello("m.example.com"))
            T.check("sonraki akışlar da cevaplanır (geçidin iş parçacığı ölmedi) ya da güvenle kapatılır", c2.read(9, 3000).size in 0..9 && back.size in 0..9)
            origin.close()
        } finally { r.close() }
    }
    run {
        val r = GRig()
        try {
            val dead = java.net.ServerSocket(0, 1, java.net.InetAddress.getByAddress(LO4)); val deadPort = dead.localPort; dead.close()
            val h = object : MitmHook {
                override fun wants(host: String, client: ByteArray, cport: Int, server: ByteArray, sport: Int) = true
                override fun port() = deadPort
                override fun expect(localPort: Int, host: String, addr: java.net.InetAddress, port: Int) {}
            }
            r.gw.config.mitm = h
            val origin = Srv { s -> val b = ByteArray(4096); try { s.getInputStream().read(b) } catch (_: Exception) {}; s.getOutputStream().write(byteArrayOf(0x16, 3, 3, 0, 4, 2, 9, 9, 9)) }
            val c = GCli(r, origin.port); c.connect(); c.write(testHello("m.example.com"))
            val back = c.read(9, 3000)
            T.check("vekil kapalıyken (bağlantı reddi) akış temiz kapanır; geçit çökmez", back.size in 0..9)
            val c2 = GCli(r, origin.port); r.gw.config.mitm = null; c2.connect(); c2.write(testHello("m.example.com"))
            T.check("kip kapatılınca yeni akış doğrudan sunucuya gider", c2.read(9, 3000).let { it.size == 9 && it[6].toInt() == 9 || it.size == 9 })
            origin.close()
        } finally { r.close() }
    }
}

/**
 * Sızma girişimi: kötü niyetli yerel uygulama tünele yüz binlerce bozuk/mutasyonlu paket yazar (rastgele ham baytlar, IP seçenekleri, parçalar,
 * IPv6 uzantı başlığı zincirleri ve döngüleri, SYN seli, sahte ClientHello). Beklenen: istisna sızmaz, akış/bellek sınırlı kalır, sonrasında sağlıklı akış çalışır.
 */
fun runGatewayChaosTests() {
    T.group("Sızma girişimi: ağ geçidine ${DEEP_X * 60_000} bozuk paket (rastgele, mutasyon, parça, uzantı zinciri, SYN seli)")
    val uncaught = java.util.concurrent.CopyOnWriteArrayList<Throwable>()
    val oldH = Thread.getDefaultUncaughtExceptionHandler()
    Thread.setDefaultUncaughtExceptionHandler { _, e -> uncaught.add(e) }
    val r = GRig()
    val rt = Runtime.getRuntime()
    try {
        r.gw.config.dpi = true; r.gw.config.dpiOnLocal = true
        r.gw.networkChanged(NetKind.WIFI)
        val rnd = java.util.Random(31337)
        val srv = Srv { s -> try { val b = ByteArray(4096); while (s.getInputStream().read(b) >= 0) { s.getOutputStream().write(b, 0, 16); s.getOutputStream().flush() } } catch (_: Exception) {} }
        val stop = java.util.concurrent.atomic.AtomicBoolean(false)
        val drained = AtomicInteger()
        val drainer = Thread({ while (!stop.get()) { if (r.q.poll(20, TimeUnit.MILLISECONDS) != null) drained.incrementAndGet() } }, "drain").also { it.isDaemon = true; it.start() }
        System.gc(); val mem0 = rt.totalMemory() - rt.freeMemory()
        val buf = ByteArray(2048)
        val hello = testHello("chaos.example.org")
        fun tcp(flags: Int, data: ByteArray, sport: Int, dport: Int, seq: Int, ack: Int, v6: Boolean = false, mss: Int = 0): ByteArray {
            val n = Gw.tcp(buf, v6, if (v6) SelfTest.CLIENT6 else CLI4, if (v6) ByteArray(16).also { it[15] = 1 } else LO4, sport, dport, seq, ack, flags, 65535, data, 0, data.size, mss)
            return buf.copyOf(n)
        }
        fun udp(dport: Int, data: ByteArray, sport: Int, dst: ByteArray = LO4): ByteArray { val n = Gw.udp(buf, false, CLI4, dst, sport, dport, data, 0, data.size); return buf.copyOf(n) }
        fun mutate(p: ByteArray): ByteArray {
            val m = p.copyOf()
            when (rnd.nextInt(6)) {
                0 -> repeat(1 + rnd.nextInt(6)) { m[rnd.nextInt(m.size)] = rnd.nextInt().toByte() }
                1 -> return m.copyOf(rnd.nextInt(m.size + 1))                                    // kesik
                2 -> { m[0] = ((m[0].toInt() and 0xF0) or (rnd.nextInt(16))).toByte() }          // IHL (seçenekler/kısa başlık)
                3 -> { if (m.size > 8) { m[6] = rnd.nextInt().toByte(); m[7] = rnd.nextInt().toByte() } }       // parça bayrakları/kayması
                4 -> { if (m.size > 3) { Packets.put16(m, 2, rnd.nextInt(65536)) } }             // toplam uzunluk yalanı
                else -> { if (m.size > 9) m[9] = rnd.nextInt().toByte() }                        // protokol
            }
            return m
        }
        val total = DEEP_X * 60_000
        var sent = 0
        var maxFlows = 0
        var i = 0
        while (i < total) {
            val sport = 1_100 + rnd.nextInt(38_000)                    // GCli kaynak portlarından (41000+) ayrı aralık
            val dport = if (rnd.nextInt(4) == 0) srv.port else listOf(80, 443, 53, 853, 5228, 1 + rnd.nextInt(65534))[rnd.nextInt(5)]
            val pkt: ByteArray = when (rnd.nextInt(12)) {
                0, 1 -> tcp(F_SYN, ByteArray(0), sport, dport, rnd.nextInt(), 0, mss = 1460)
                2 -> tcp(F_ACK or F_PSH, hello, sport, dport, rnd.nextInt(), rnd.nextInt())
                3 -> tcp(rnd.nextInt(64), ByteArray(rnd.nextInt(1200)).also { rnd.nextBytes(it) }, sport, dport, rnd.nextInt(), rnd.nextInt())
                4 -> udp(listOf(53, 443, 123, 5353, 1 + rnd.nextInt(65534))[rnd.nextInt(5)], ByteArray(rnd.nextInt(1300)).also { rnd.nextBytes(it) }, sport)
                5 -> tcp(F_SYN, ByteArray(0), sport, dport, rnd.nextInt(), 0, v6 = true)
                6 -> ByteArray(20 + rnd.nextInt(1400)).also { rnd.nextBytes(it); it[0] = (0x40 or rnd.nextInt(16)).toByte() }          // ham IPv4
                7 -> ByteArray(40 + rnd.nextInt(1400)).also { rnd.nextBytes(it); it[0] = 0x60.toByte() }                              // ham IPv6
                8 -> ByteArray(60 + rnd.nextInt(200)).also { b ->                                                                    // IPv6 uzantı zinciri/döngüsü
                    b[0] = 0x60.toByte(); b[6] = listOf(0, 43, 44, 60, 51, 135)[rnd.nextInt(6)].toByte()
                    for (k in 40 until b.size - 2 step 8) { b[k] = listOf(0, 43, 44, 60, 6, 17)[rnd.nextInt(6)].toByte(); b[k + 1] = rnd.nextInt(4).toByte() } }
                9 -> mutate(tcp(F_ACK or F_PSH, hello, sport, srv.port, rnd.nextInt(), rnd.nextInt()))
                10 -> mutate(udp(443, ByteArray(1200) { 0x41 }, sport))
                else -> mutate(tcp(F_SYN, ByteArray(0), sport, dport, rnd.nextInt(), 0, mss = 1460))
            }
            try { r.gw.onPacket(pkt, pkt.size) } catch (e: Throwable) { uncaught.add(e) }
            sent++; i++
            if (i % 5000 == 0) { maxFlows = maxOf(maxFlows, r.gw.stats().let { it.tcpFlows + it.udpFlows }); Thread.sleep(5) }
        }
        Thread.sleep(1500)
        maxFlows = maxOf(maxFlows, r.gw.stats().let { it.tcpFlows + it.udpFlows })
        System.gc(); val grew = (rt.totalMemory() - rt.freeMemory() - mem0) / (1024 * 1024)
        T.check("$sent paket işlendi, hiçbir iş parçacığında yakalanmamış istisna yok", uncaught.isEmpty(), uncaught.take(2).joinToString { "${it.javaClass.simpleName}: ${it.message} @ ${it.stackTrace.firstOrNull()}" })
        T.check("eşzamanlı akış sayısı sınırlı kaldı (≤ 5000, en çok $maxFlows)", maxFlows <= 5000, maxFlows.toString())
        T.check("bellek büyümesi makul (< 200 MB, $grew MB)", grew < 200, "$grew MB")
        val st = r.gw.stats()
        T.check("sayaçlar eksiye düşmez", st.tcpFlows >= 0 && st.udpFlows >= 0 && st.opened >= 0)
        T.check("saldırı etkisiz kalmadı: yüzlerce akış açıldı, yanıt paketleri üretildi (açılan ${st.opened}, yanıt ${drained.get()})", st.opened > 100 && drained.get() > 100, "opened=${st.opened} drained=${drained.get()}")
        // Saldırı sonrası: sağlıklı akış (boşaltıcı iş parçacığı durdurulur; yoksa GCli'nin okuyacağı paketleri çalar)
        stop.set(true); drainer.join(1000); r.q.clear()
        val good = byteArrayOf(0x16, 3, 3, 0, 4, 2, 0, 0, 0)
        val srv2 = Srv { s -> Thread.sleep(100); s.getOutputStream().write(good); s.getOutputStream().flush(); Thread.sleep(200) }
        val c = GCli(r, srv2.port)
        val sa = c.connect()
        c.write(testHello("after-chaos.example.org"))
        T.check("saldırıdan sonra sağlıklı TCP akışı çalışır", sa != null && c.read(good.size, 6000).size == good.size)
        srv.close(); srv2.close()
        val t0 = System.nanoTime(); r.close()
        T.check("durdurma hızlı (< 5 sn) ve temiz", (System.nanoTime() - t0) / 1_000_000_000 < 5)
    } finally { Thread.setDefaultUncaughtExceptionHandler(oldH); try { r.close() } catch (_: Exception) {} }
}
