package app.dnshizli.selftest

import app.dnshizli.core.*

/** Dış denetim turu 2 (sizma26): NAT64/eşlenmiş adres tutarlılığı, soket koruma hatası. */
internal fun runAuditRound2Tests() {
    T.group("sizma26: adres yardımcıları (NAT64 / eşlenmiş) tutarlılığı")
    val rnd = java.util.Random(26)
    fun mapped(v4: ByteArray) = ByteArray(16).also { it[10] = 0xFF.toByte(); it[11] = 0xFF.toByte(); System.arraycopy(v4, 0, it, 12, 4) }
    fun nat64(v4: ByteArray) = ByteArray(16).also { it[1] = 0x64; it[2] = 0xFF.toByte(); it[3] = 0x9B.toByte(); System.arraycopy(v4, 0, it, 12, 4) }
    var bad = 0; var badPriv = 0
    repeat(4000) {
        val v4 = ByteArray(4).also { b -> rnd.nextBytes(b) }
        if (it % 3 == 0) { v4[0] = byteArrayOf(10, 127, 192.toByte(), 172.toByte(), 169.toByte(), 100)[rnd.nextInt(6)]; v4[1] = byteArrayOf(0, 168.toByte(), 254.toByte(), 16, 64, 100)[rnd.nextInt(6)] }
        for (v6 in listOf(mapped(v4), nat64(v4))) {
            if (Dpi.isLocalAddress(v6) != Dpi.isLocalAddress(v4)) bad++
            if (Gw.isLocalDestination(true, v6) != Gw.isLocalDestination(false, v4)) bad++
            if (FilterEngine.privateV6(v6, 0) != FilterEngine.privateV4(v4, 0)) badPriv++
        }
    }
    T.check("Dpi.isLocalAddress / Gw.isLocalDestination: eşlenmiş ve NAT64 adres, gömülü IPv4 ile aynı karar", bad == 0)
    T.check("FilterEngine.privateV6: eşlenmiş ve NAT64, privateV4 ile aynı karar (yeniden bağlama kaçağı yok)", badPriv == 0)
    val lan = byteArrayOf(192.toByte(), 168.toByte(), 1, 1)
    T.check("64:ff9b::192.168.1.1 yerel", FilterEngine.privateV6(nat64(lan), 0) && Dpi.isLocalAddress(nat64(lan)) && Gw.isLocalDestination(true, nat64(lan)))
    val pub = byteArrayOf(93, 184.toByte(), 216.toByte(), 34)
    T.check("64:ff9b::93.184.216.34 genel", !FilterEngine.privateV6(nat64(pub), 0) && !Dpi.isLocalAddress(nat64(pub)))
    val notNat = nat64(lan).also { it[5] = 1 }
    T.check("64:ff9b:0:0:0100::… (/96 dışı) gömülü sayılmaz", Dpi.embeddedV4(notNat) == null)

    T.group("sizma26: soket koruma başarısızlığı devam ettirilmez")
    val oldU = SocketGuard.protectUdp; val oldT = SocketGuard.protectTcp
    try {
        SocketGuard.protectUdp = null; SocketGuard.protectTcp = null
        java.net.DatagramSocket().use { s -> T.check("koruma yokken (JVM/servis yok) true", SocketGuard.udp(s)) }
        SocketGuard.protectUdp = { false }
        java.net.DatagramSocket().use { s -> T.check("protect false → udp() false", !SocketGuard.udp(s)) }
        SocketGuard.protectUdp = { throw IllegalStateException("x") }
        java.net.DatagramSocket().use { s -> T.check("protect istisna → udp() false", !SocketGuard.udp(s)) }
        SocketGuard.protectTcp = { false }
        java.net.Socket().use { s -> T.check("protect false → tcp() false", !SocketGuard.tcp(s)) }
    } finally { SocketGuard.protectUdp = oldU; SocketGuard.protectTcp = oldT }

    T.group("sizma26: ProtectedSockets (servisten çıkarıldı) — koruma başarısızsa bağlanılmaz")
    val srv = java.net.ServerSocket(0)
    val udpSrv = java.net.DatagramSocket(0)
    try {
        val tcpTarget = java.net.InetSocketAddress(java.net.InetAddress.getLoopbackAddress(), srv.localPort)
        val udpTarget = java.net.InetSocketAddress(java.net.InetAddress.getLoopbackAddress(), udpSrv.localPort)
        val logs = ArrayList<String>()
        val bad = ProtectedSockets({ false }, { false }) { logs.add(it) }
        fun fails(f: () -> Unit) = try { f(); false } catch (_: java.io.IOException) { true }
        T.check("tcp(): protect false → IOException, sunucuya bağlantı gelmez", fails { bad.tcp(tcpTarget, 500) } && logs.size == 1)
        srv.soTimeout = 150
        T.check("  korunamayan TCP soket hedefe hiç bağlanmadı", try { srv.accept(); false } catch (_: java.net.SocketTimeoutException) { true })
        T.check("udp(): protect false → IOException", fails { bad.udp(udpTarget) })
        T.check("bootstrapUdp(): protect false → IOException", fails { bad.bootstrapUdp() })
        val boom = ProtectedSockets({ throw IllegalStateException("x") }, { throw IllegalStateException("x") })
        T.check("protect istisna fırlatırsa da reddedilir (tcp/udp/bootstrap)", fails { boom.tcp(tcpTarget, 500) } && fails { boom.udp(udpTarget) } && fails { boom.bootstrapUdp() })
        val good = ProtectedSockets({ true }, { true })
        good.tcp(tcpTarget, 1000).use { c -> T.check("protect true → bağlanır", c.isConnected) }
        good.udp(udpTarget).use { u -> T.check("udp protect true → hedefe bağlı", u.isConnected) }
        good.bootstrapUdp().use { b -> T.check("bootstrapUdp protect true → soket döner", !b.isClosed) }
        T.check("addr(): yazılı IP, ad çözümlemesiz", ProtectedSockets.addr("1.2.3.4").address.contentEquals(byteArrayOf(1, 2, 3, 4)) &&
            try { ProtectedSockets.addr("not-an-ip"); false } catch (_: IllegalArgumentException) { true })
    } finally { srv.close(); udpSrv.close() }
}
