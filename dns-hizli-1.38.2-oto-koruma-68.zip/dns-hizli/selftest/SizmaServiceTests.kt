package app.dnshizli.selftest

import app.dnshizli.core.*
import java.util.Random

/** Sızma 24 — DnsVpnService'ten çıkarılan saf karar mantığı ([ServicePolicy]): eski satır içi kodun birebir kopyası (kâhin) ve değişmezler. */
internal fun runServicePolicyTests() {
    // ---- kâhinler: servisteki eski gövdelerin kelimesi kelimesine kopyası
    fun oldTries(proto: Proto, last: Boolean): Int =
        if (QuicBackoff.isQuic(proto) && !last) 1 else if (proto == Proto.ODOH) 3 else if (last) 4 else if (proto == Proto.PLAIN) 2 else 3
    fun oldMs(proto: Proto): Long = when (proto) {
        Proto.PLAIN -> 2000L
        Proto.DOQ, Proto.DOH3 -> 2500L
        Proto.ODOH -> 6000L
        else -> 3500L
    }
    fun oldDowngrade(first: Proto?, chosen: Proto): Boolean =
        (chosen == Proto.PLAIN && first != Proto.PLAIN) || (first == Proto.ODOH && chosen != Proto.ODOH)
    fun oldBackup(failed: DnsServer, s: AppSettings, lat: Map<String, Latency>): DnsServer? {
        val b = s.backupServer ?: return null
        val usable: (DnsServer) -> Boolean = { it.id != failed.id && it.id !in s.hidden && s.plan(it).isNotEmpty() }
        if (b == AppSettings.BACKUP_AUTO) return ServerList.fastest(Catalog.all, lat, usable)?.first ?: Catalog.all.firstOrNull(usable)
        return Catalog.byId(b)?.takeIf(usable)
    }
    fun oldRing(s: AppSettings): List<String> {
        val usable: (DnsServer) -> Boolean = { s.plan(it).isNotEmpty() && it.id !in s.hidden }
        val fav = Catalog.all.filter { it.id in s.favorites && usable(it) }.map { it.id }
        if (fav.size >= 2) return fav
        return Catalog.all.filter { it.id in s.recent && usable(it) }.map { it.id }
    }

    T.group("Sızma 24 / ServicePolicy: deneme sayısı, süre ve gizlilik düşüşü eski satır içi koda birebir eşit (tüm yöntemler)")
    run {
        var bad = ""
        for (p in Proto.values()) for (last in listOf(false, true)) {
            if (ServicePolicy.triesFor(p, last) != oldTries(p, last)) bad += " tries($p,$last)"
        }
        for (p in Proto.values()) if (ServicePolicy.msFor(p) != oldMs(p)) bad += " ms($p)"
        val protos = Proto.values().toList<Proto?>() + null
        for (a in protos) for (b in Proto.values()) if (ServicePolicy.isDowngrade(a, b) != oldDowngrade(a, b)) bad += " down($a,$b)"
        T.check("${Proto.values().size} yöntem × 2 × tüm çiftler eşit", bad.isEmpty(), bad)
        T.check("QUIC son değilken tek deneme; son yöntem 4 deneme (ODoH hariç 3)",
            ServicePolicy.triesFor(Proto.DOQ, false) == 1 && ServicePolicy.triesFor(Proto.DOH, true) == 4 && ServicePolicy.triesFor(Proto.ODOH, true) == 3)
        T.check("düz DNS'e iniş düşüş sayılır, düzden düze sayılmaz; ODoH'tan başka yönteme düşüş sayılır",
            ServicePolicy.isDowngrade(Proto.DOH, Proto.PLAIN) && !ServicePolicy.isDowngrade(Proto.PLAIN, Proto.PLAIN) && ServicePolicy.isDowngrade(Proto.ODOH, Proto.DOH) && !ServicePolicy.isDowngrade(null, Proto.DOH))
        T.check("süreler pozitif; QUIC düzden uzun, ODoH en uzun", Proto.values().all { ServicePolicy.msFor(it) > 0 } && ServicePolicy.msFor(Proto.ODOH) == Proto.values().maxOf { ServicePolicy.msFor(it) })
    }

    T.group("Sızma 24 / ServicePolicy: yedek sunucu ve sunucu halkası — 3000 rastgele ayar, eski koda birebir eşit")
    run {
        val rnd = Random(2501)
        val ids = Catalog.all.map { it.id }
        fun subset(p: Double) = ids.filter { rnd.nextDouble() < p }
        val encs = Encryption.values()
        var bad = ""; var nonNullBackup = 0; var ringBig = 0
        repeat(3000) { i ->
            val lat = HashMap<String, Latency>()
            for (id in ids) if (rnd.nextInt(3) != 0) lat[id] = Latency(if (rnd.nextInt(5) == 0) null else rnd.nextInt(5, 900), 0L)
            val s = AppSettings(
                encryption = encs[rnd.nextInt(encs.size)], strictEncryption = rnd.nextInt(4) == 0, quicDns = rnd.nextBoolean(),
                backupServer = when (rnd.nextInt(4)) { 0 -> null; 1 -> AppSettings.BACKUP_AUTO; 2 -> ids[rnd.nextInt(ids.size)]; else -> "yok-boyle-bir-sunucu" },
                favorites = subset(if (rnd.nextBoolean()) 0.05 else 0.3).toSet(),
                recent = subset(0.3).shuffled(rnd),
                hidden = subset(0.15).toSet(),
            )
            val failed = Catalog.all[rnd.nextInt(Catalog.all.size)]
            val a = ServicePolicy.backupFor(failed, s) { lat }
            val b = oldBackup(failed, s, lat)
            if (a?.id != b?.id) bad += " [backup#$i ${a?.id}/${b?.id}]"
            if (a != null) { nonNullBackup++; if (a.id == failed.id || a.id in s.hidden) bad += " [yedek geçersiz#$i]" }
            val ra = ServicePolicy.nextRing(s); val rb = oldRing(s)
            if (ra != rb) bad += " [ring#$i]"
            if (ra.size >= 2) ringBig++
        }
        T.check("yedek sunucu ve halka eşit; yedek asla başarısız/gizli sunucu değil", bad.isEmpty(), bad.take(300))
        T.check("deney dengeli: yedek bulunan ve halka ≥2 olan durumlar var", nonNullBackup > 300 && ringBig > 300, "yedek=$nonNullBackup halka=$ringBig")
    }

    T.group("Sızma 24 / ServicePolicy.nextInRing: döngüsel, kendine dönmez, |halka| adımda hepsini gezer")
    run {
        val rnd = Random(2502)
        var bad = ""
        repeat(2000) {
            val n = rnd.nextInt(0, 9)
            val ring = (0 until n).map { "s$it" }
            val cur = if (n > 0 && rnd.nextInt(5) != 0) ring[rnd.nextInt(n)] else if (rnd.nextBoolean()) null else "yok"
            val nx = ServicePolicy.nextInRing(ring, cur)
            if (n < 2) { if (nx != null) bad += " [küçük halka $n]"; return@repeat }
            if (nx == null || nx !in ring) { bad += " [dışarı $nx]"; return@repeat }
            if (cur in ring && nx == cur) bad += " [kendine döndü]"
            if (cur !in ring && nx != ring[0]) bad += " [bilinmeyen kimlik → ilk eleman olmalı]"
            if (cur in ring) {
                val seen = HashSet<String>(); var c = cur
                repeat(n) { c = ServicePolicy.nextInRing(ring, c)!!; seen.add(c!!) }
                if (seen.size != n || c != cur) bad += " [tur tamamlanmadı]"
            }
        }
        T.check("2000 rastgele halka/konum", bad.isEmpty(), bad.take(300))
    }

    T.group("Sızma 24 / ServicePolicy: ağ geçidi modülleri ve duraklatma süresi")
    run {
        var bad = ""
        for (dpi in listOf(false, true)) for (ads in listOf(false, true)) for (lv in FilterLevel.values()) {
            val s = AppSettings(dpiOn = dpi, adsPlus = ads, filterLevel = lv)
            if (ServicePolicy.gwWanted(s) != (dpi || ads)) bad += " want($dpi,$ads)"
            val exp = if (!ads) FilterLevel.OFF else if (lv == FilterLevel.STRICT) FilterLevel.STRICT else FilterLevel.MEDIUM
            if (ServicePolicy.gwLevelFor(s) != exp) bad += " lvl($ads,$lv)"
        }
        T.check("gwWanted / gwLevelFor tüm birleşimlerde tablo gibi", bad.isEmpty(), bad)
        T.check("Reklam+ en az ORTA, hiçbir zaman BASIC/OFF değil (açıkken)",
            FilterLevel.values().all { ServicePolicy.gwLevelFor(AppSettings(adsPlus = true, filterLevel = it)).let { l -> l == FilterLevel.MEDIUM || l == FilterLevel.STRICT } })

        val now = 1_700_000_000_000L
        T.check("1 dk → +60 sn; 0, negatif ve devasa dakika sınırlara sıkışır",
            ServicePolicy.pauseUntil(now, 1) == now + 60_000 && ServicePolicy.pauseUntil(now, 0) == now + 60_000 &&
            ServicePolicy.pauseUntil(now, -50) == now + 60_000 && ServicePolicy.pauseUntil(now, Int.MAX_VALUE) == now + 24 * 3_600_000L &&
            ServicePolicy.pauseUntil(now, Int.MIN_VALUE) == now + 60_000)
        val rnd = Random(2503)
        var rb = ""
        repeat(20_000) {
            val until = now + rnd.nextLong() % (10L * 24 * 3_600_000)
            val t = now + rnd.nextLong() % (10L * 24 * 3_600_000)
            val r = ServicePolicy.pauseRemainingMs(until, t)
            if (r < 0 || r > 24 * 3_600_000L) rb += " [r=$r]"
            if (until <= t && r != 0L) rb += " [geçmiş r=$r]"
        }
        T.check("kalan süre hep 0..24 sa (saat geri gitse/atlasa da alarm uçmaz)", rb.isEmpty(), rb.take(200))
        T.check("duraklatma → kalan süre uyumlu", ServicePolicy.pauseRemainingMs(ServicePolicy.pauseUntil(now, 15), now + 5 * 60_000) == 10 * 60_000L)
    }

    T.group("Sızma 24 / RetrySchedule: eski çizelgeyle birebir; bekleme azalmaz, kapalı kipte ≤120 sn ve vazgeçmez")
    run {
        val old = longArrayOf(5_000L, 30_000L, 120_000L, 5 * 60_000L, 10 * 60_000L, 15 * 60_000L, 30 * 60_000L)
        fun oldDelay(step: Int, sealed: Boolean): Long? {
            if (!sealed && step >= old.size) return null
            val base = old[minOf(step, old.size - 1)]
            return if (sealed) minOf(base, 120_000L) else base
        }
        var bad = ""
        for (step in 0..40) for (sealed in listOf(false, true)) if (RetrySchedule.delayFor(step, sealed) != oldDelay(step, sealed)) bad += " [$step,$sealed]"
        T.check("0..40 adım × kapalı/açık eşit", bad.isEmpty(), bad)
        var prev = 0L; var mono = true
        for (step in 0 until old.size) { val d = RetrySchedule.delayFor(step, false)!!; if (d < prev) mono = false; prev = d }
        T.check("bekleme azalmaz; 7. denemeden sonra vazgeçilir", mono && RetrySchedule.delayFor(old.size, false) == null && RetrySchedule.delayFor(old.size - 1, false) != null)
        T.check("kapalı kipte hiç vazgeçilmez ve ≤ 120 sn", (0..1000).all { RetrySchedule.delayFor(it, true).let { d -> d != null && d <= 120_000L && d > 0 } })
        T.check("negatif adım 0 gibi", RetrySchedule.delayFor(-5, false) == 5_000L && RetrySchedule.delayFor(Int.MIN_VALUE, true) == 5_000L)
    }

    T.group("Sızma 24 / GwValve: ağ geçidi vanası eski sayaç koduyla birebir (20 000 rastgele dizi) ve tek tek senaryolar")
    run {
        // Eski gwTick sayaç mantığının kelimesi kelimesine kopyası
        class Old(val failMin: Int, val dpiMin: Int) {
            var bad = 0; var ok = 0; var dpiBad = 0; var trips = 0
            fun tick(o: GwValve.Obs): GwValve.Verdict {
                if (o.online && o.dnsOk && o.recentOk == 0 && o.recentFail >= failMin) bad++ else bad = 0
                if (o.recentOk > 0) { if (++ok >= 20) { ok = 0; trips = 0 } } else ok = 0
                if (o.gwDpi && o.online && o.dnsOk && o.recentOk > 0 && o.recentDpiOk == 0 && o.recentDpiFail >= dpiMin) dpiBad++ else dpiBad = 0
                if (dpiBad >= 2) { dpiBad = 0; if (o.settingsDpiOn) return GwValve.Verdict.TRIP_DPI }
                if (bad < 2) return GwValve.Verdict.NONE
                bad = 0
                return GwValve.Verdict.TRIP_ALL
            }
        }
        val rnd = Random(2601)
        var mism = ""; var dpiTrips = 0; var allTrips = 0; var forgiven = 0
        repeat(20_000) { seq ->
            val v = GwValve(15, 8); val o = Old(15, 8)
            val phase = rnd.nextInt(4)
            repeat(30) { step ->
                val healthy = rnd.nextInt(6) == 0
                val ob = GwValve.Obs(
                    online = rnd.nextInt(10) != 0, dnsOk = rnd.nextInt(8) != 0, gwDpi = rnd.nextInt(3) != 0, settingsDpiOn = rnd.nextInt(5) != 0,
                    recentOk = if (healthy || phase == 0) rnd.nextInt(1, 40) else if (rnd.nextBoolean()) 0 else rnd.nextInt(0, 3),
                    recentFail = rnd.nextInt(0, 40), recentDpiOk = if (rnd.nextInt(3) == 0) rnd.nextInt(1, 5) else 0, recentDpiFail = rnd.nextInt(0, 30))
                val a = v.observe(ob); val b = o.tick(ob)
                if (a != b) mism += " [seq$seq/$step $a≠$b]"
                if (a == GwValve.Verdict.TRIP_DPI) { dpiTrips++; val w = v.onTrip(); o.trips++; if (w != GwRecovery.waitMs(o.trips)) mism += " [bekleme seq$seq]" }
                if (a == GwValve.Verdict.TRIP_ALL) { allTrips++; if (rnd.nextBoolean()) { val w = v.onTrip(); o.trips++; if (w != GwRecovery.waitMs(o.trips)) mism += " [bekleme2 seq$seq]" } }
                if (v.tripCount != o.trips) mism += " [sayaç seq$seq/$step ${v.tripCount}≠${o.trips}]"
                if (o.trips == 0 && v.tripCount == 0) forgiven++
            }
        }
        T.check("20 000 dizi × 30 ölçüm: karar ve kesinti sayacı eşit", mism.isEmpty(), mism.take(300))
        T.check("deney dengeli: DPI vanası ve genel vana çok kez tetiklendi", dpiTrips > 500 && allTrips > 500, "dpi=$dpiTrips hepsi=$allTrips")

        fun obs(ok: Int = 0, fail: Int = 20, dpiOk: Int = 0, dpiFail: Int = 0, online: Boolean = true, dnsOk: Boolean = true, gwDpi: Boolean = true, setDpi: Boolean = true) =
            GwValve.Obs(online, dnsOk, gwDpi, setDpi, ok, fail, dpiOk, dpiFail)
        run {
            val v = GwValve()
            T.check("tek kötü ölçüm vana açmaz, ikinci açar", v.observe(obs()) == GwValve.Verdict.NONE && v.observe(obs()) == GwValve.Verdict.TRIP_ALL)
            T.check("vanadan sonra sayaç sıfırlanır (üçüncü ölçüm yeniden saymaya başlar)", v.observe(obs()) == GwValve.Verdict.NONE)
        }
        run {
            val v = GwValve()
            T.check("arada sağlıklı ölçüm sayacı sıfırlar", v.observe(obs()) == GwValve.Verdict.NONE && v.observe(obs(ok = 5, fail = 0)) == GwValve.Verdict.NONE && v.observe(obs()) == GwValve.Verdict.NONE)
        }
        run {
            val v = GwValve()
            val r = (0 until 5).map { v.observe(obs(online = false)) } + (0 until 5).map { v.observe(obs(dnsOk = false)) }
            T.check("çevrimdışı ya da DNS cevapsızken (suç ağda) hiç vana açılmaz", r.all { it == GwValve.Verdict.NONE })
        }
        run {
            val v = GwValve()
            val a = v.observe(obs(ok = 5, fail = 0, dpiFail = 8)); val b = v.observe(obs(ok = 5, fail = 0, dpiFail = 8))
            T.check("DPI el sıkışmaları bozuk: ikinci ölçümde yalnızca DPI vanası", a == GwValve.Verdict.NONE && b == GwValve.Verdict.TRIP_DPI)
            val w = GwValve()
            w.observe(obs(ok = 5, fail = 0, dpiFail = 8)); val c = w.observe(obs(ok = 5, fail = 0, dpiFail = 8, setDpi = false))
            T.check("ayarlarda DPI kapalıysa (kullanıcı kapattı) DPI vanası açılmaz", c == GwValve.Verdict.NONE)
            val x = GwValve()
            x.observe(obs(ok = 5, fail = 0, dpiFail = 7)); val d = x.observe(obs(ok = 5, fail = 0, dpiFail = 7))
            T.check("DPI eşiğin altında (7 < 8) vana açılmaz", d == GwValve.Verdict.NONE)
        }
        run {
            val v = GwValve()
            repeat(3) { v.onTrip() }
            T.check("kesinti sayacı 5→15→45 dk bekleme verir", v.tripCount == 3 && GwRecovery.waitMs(v.tripCount) == 45 * 60_000L)
            repeat(19) { v.observe(obs(ok = 5, fail = 0)) }
            T.check("19 sağlıklı ölçüm affetmez", v.tripCount == 3)
            v.observe(obs(ok = 5, fail = 0))
            T.check("20. sağlıklı ölçümde kesinti sayacı sıfırlanır", v.tripCount == 0)
            val w = GwValve(); w.onTrip(); repeat(19) { w.observe(obs(ok = 5, fail = 0)) }; w.observe(obs(ok = 0, fail = 0)); repeat(19) { w.observe(obs(ok = 5, fail = 0)) }
            T.check("sağlıklı seri kesilirse affetme baştan başlar", w.tripCount == 1)
        }
    }
}
