package app.dnshizli.selftest

import app.dnshizli.core.*

/** sizma28: birleşik DPI yöntemleri (TLS 14/15, HTTP 8) ve kullanıcının joker kuralları. */
internal fun runRound4Tests() {
    runComboDpiTests()
    runPatternTests()
}

/** Kayıt akışını çözer: (kayıt yükleri birleşik, kayıt sayısı, her kaydın yükü); geçersizse null. */
private fun recs(j: ByteArray): Triple<ByteArray, Int, List<ByteArray>>? {
    var i = 0
    val all = java.io.ByteArrayOutputStream()
    val list = ArrayList<ByteArray>()
    while (i < j.size) {
        if (i + 5 > j.size || j[i].toInt() != 0x16) return null
        val l = Packets.u16(j, i + 3)
        if (i + 5 + l > j.size) return null
        list.add(j.copyOfRange(i + 5, i + 5 + l)); all.write(j, i + 5, l)
        i += 5 + l
    }
    return Triple(all.toByteArray(), list.size, list)
}

private fun joinParts(p: List<Dpi.Part>): ByteArray { val o = java.io.ByteArrayOutputStream(); for (x in p) o.write(x.data); return o.toByteArray() }

private fun runComboDpiTests() {
    T.group("sizma28: birleşik DPI — yöntem tabloları ve sıralama")
    T.check("yöntem sayıları planlayıcı tablolarına sığar (≤ ${Dpi.MAX_PLANS})", Dpi.TLS_PLANS <= Dpi.MAX_PLANS && Dpi.HTTP_PLANS <= Dpi.MAX_PLANS)
    T.check("yeni TLS yöntemleri (14 çoklu kayıt, 15 zincir) sırada ve kayıt bölen sayılır",
        14 in Dpi.TLS_ORDER && 15 in Dpi.TLS_ORDER && 14 in Dpi.TLS_RECORD_SPLIT_PLANS && 15 in Dpi.TLS_RECORD_SPLIT_PLANS)
    T.check("zincir (15) sahte gönderim içerdiğinden en sonda denenir", Dpi.TLS_ORDER.last() == 15)

    T.group("sizma28: TLS 14 — çoklu kayıt: SNI'nın her etiketi ayrı kayıtta")
    val host = "cdn.video.ornek-site.com"
    val hello = testHello(host)
    val h = Dpi.Hello(); Dpi.parseHello(hello, hello.size, h)
    val p14 = Dpi.split(Dpi.TLS, 14, hello, hello.size)
    val r14 = recs(joinParts(p14))
    T.check("akış geçerli TLS kayıtları, el sıkışma yükü birebir aynı", r14 != null && r14.first.contentEquals(hello.copyOfRange(5, hello.size)))
    val dots = host.count { it == '.' }
    T.check("kayıt sayısı = başlık + SNI öncesi + her etiket + SNI sonrası (${dots + 4})", r14?.second == dots + 4, "kayıt=${r14?.second}")
    T.check("hiçbir kayıt adın tamamını ya da kayıtlı adı ('ornek-site.com') bütün taşımaz",
        r14 != null && r14.third.none { rec -> String(rec, Charsets.ISO_8859_1).let { it.contains(host) || it.contains("ornek-site.com") } })
    T.check("her kayıt ayrı TCP parçası (+ ilk bayt ayrı)", p14.size == (r14?.second ?: 0) + 1, "parça=${p14.size}")
    val merged = Dpi.mergedHello(joinParts(p14), joinParts(p14).size)
    T.check("birleştiren cihaz/sunucu aynı SNI'yı görür", merged != null && Dpi.Hello().let { hh -> Dpi.parseHello(merged, merged.size, hh) && hh.host(merged) == host })
    val many = testHello((1..30).joinToString(".") { "e$it" } + ".com")
    val rm = recs(joinParts(Dpi.split(Dpi.TLS, 14, many, many.size)))
    T.check("çok etiketli adda kayıt sayısı sınırlı (≤ ${Dpi.MULTI_REC_MAX})", rm != null && rm.second <= Dpi.MULTI_REC_MAX, "kayıt=${rm?.second}")

    T.group("sizma28: TLS 15 — zincir: sahte + kayıt bölme + OOB aynı bağlantıda")
    val p15 = Dpi.split(Dpi.TLS, 15, hello, hello.size)
    val j15 = joinParts(p15)
    val r15 = recs(j15)
    T.check("akış geçerli, yük birebir aynı, 3 kayıt", r15 != null && r15.first.contentEquals(hello.copyOfRange(5, hello.size)) && r15.second == 3, "kayıt=${r15?.second}")
    val fk = p15.firstOrNull()?.fake
    T.check("ilk parçanın sahte kopyası var, aynı uzunlukta", fk != null && fk.size == p15[0].data.size)
    val fs = fk?.let { String(it, Charsets.ISO_8859_1) } ?: ""
    T.check("sahte kopyada gerçek ad yok (DPI 'izinli' bir ad görür)", fk != null && !fs.contains("ornek-site") && !fs.contains("video"))
    var diff = 0; if (fk != null) for (k in fk.indices) if (fk[k] != p15[0].data[k]) diff++
    T.check("sahte kopya yalnızca SNI baytlarında farklı", fk != null && diff in 1..host.length, "fark=$diff")
    T.check("ikinci sınırda 1 baytlık parça + acil (OOB) bayt", p15.size == 3 && p15[1].data.size == 1 && p15[1].oobAfter)
    T.check("son etiket ('.com') ayrı kayıtta: ad sonu kuralları ilk kayıtta eşleşmez", r15 != null && String(r15.third[2], Charsets.ISO_8859_1).startsWith(".com"))
    val noSni = testHello("x").let { it }               // tek etiket: zincir yine geçerli bir akış üretir
    val rn = recs(joinParts(Dpi.split(Dpi.TLS, 15, noSni, noSni.size)))
    T.check("tek etiketli/kısa adda da akış geçerli (düşüş yolu)", rn != null && rn.first.contentEquals(noSni.copyOfRange(5, noSni.size)))

    T.group("sizma28: HTTP 8 — zincir: boş satır + harf karışımı + sekme + üç bölme")
    val req = "GET /yol?a=1 HTTP/1.1\r\nUser-Agent: x\r\nHost: engelli.ornek.com\r\nAccept: */*\r\n\r\n".toByteArray()
    val p8 = Dpi.split(Dpi.HTTP, 8, req, req.size)
    val j8 = String(joinParts(p8), Charsets.ISO_8859_1)
    T.check("istek CRLF ile başlar, 'hOsT:' + sekme içerir", j8.startsWith("\r\nGET ") && j8.contains("hOsT:\t engelli.ornek.com\r\n"), j8.take(80))
    T.check("en az 4 parça; hiçbir parça Host değerini bütün taşımaz", p8.size >= 4 && p8.none { String(it.data, Charsets.ISO_8859_1).contains("engelli.ornek.com") })
    val hi = Dpi.HttpInfo(); val jb = joinParts(p8)
    T.check("birleşik istek ayrışır, Host aynı (anlam korunur)", Dpi.parseHttp(jb, jb.size, hi) && String(jb, hi.valOff, hi.valLen, Charsets.ISO_8859_1).trim() == "engelli.ornek.com")
    T.check("geri kalan baytlar özgünle aynı (yalnız CRLF, harf karışımı ve sekme eklendi)",
        j8.removePrefix("\r\n").replace("hOsT:\t ", "Host: ") == String(req, Charsets.ISO_8859_1))
}

private fun runPatternTests() {
    T.group("sizma28: joker kurallar — biçim ve aşırı genişlik denetimi")
    val good = mapOf("ads*.ornek.com" to "ads*.ornek.com", "*.ads*.ornek.com" to "ads*.ornek.com", "https://Track*-*.Cdn.Ornek.NET/x" to "track*-*.cdn.ornek.net",
        "izleme.*.ornek.com" to "izleme.*.ornek.com", "a**b.ornek.com" to "a*b.ornek.com")
    val gBad = good.filter { (i, o) -> NamePatterns.normalize(i) != o }
    T.check("geçerli joker kurallar temizlenir", gBad.isEmpty(), gBad.keys.joinToString())
    val bad = listOf("ads*.com", "reklam.*", "*.com", "x*.co.uk", "x*.com.tr", "*.*.ornek.com", "ornek.com", "*.ornek.com", "a b*.ornek.com", "a*.ornék.com", "", "*", "a*.b")
    val bBad = bad.filter { NamePatterns.normalize(it) != null }
    T.check("aşırı geniş / jokersiz / geçersiz girdiler reddedilir", bBad.isEmpty(), bBad.joinToString())
    T.check("FilterNames.entry: düz ad düz kalır, joker kural kabul edilir, geniş joker reddedilir",
        FilterNames.entry("Ornek.com") == "ornek.com" && FilterNames.entry("ads*.ornek.com") == "ads*.ornek.com" && FilterNames.entry("ads*.com") == null)
    T.check("ayar kaydı joker kuralı korur (encode/decode)", FilterNames.decode(FilterNames.encode(listOf("ornek.com", "ads*.ornek.com", "ads*.com"))) == listOf("ornek.com", "ads*.ornek.com"))

    T.group("sizma28: joker kurallar — DNS/ağ geçidi süzgecinde eşleşme")
    val e = FilterEngine(emptyList(), FilterTier.EMPTY, listOf("ads9.ornek.com"), listOf("ads*.ornek.com", "*-izle-*.cdn.site.net", "pixel.*.takip.org"))
    fun v(n: String) = e.verdictOf(n)
    T.check("'ads*' etiketi: ads, ads1, adserver yakalanır", listOf("ads.ornek.com", "ads1.ornek.com", "adserver.ornek.com").all { v(it) == FilterVerdict.USER })
    T.check("kuralın alt alanları da yakalanır", v("x.y.ads7.ornek.com") == FilterVerdict.USER)
    T.check("benzer ama uymayan adlar geçer", listOf("ornek.com", "www.ornek.com", "bads.ornek.com", "ads.ornek.com.tr", "ads.baska.com").all { v(it) == FilterVerdict.PASS })
    T.check("ortada joker: '*-izle-*' ve 'pixel.*.takip.org'", v("a-izle-b.cdn.site.net") == FilterVerdict.USER && v("pixel.eu.takip.org") == FilterVerdict.USER && v("pixel.takip.org") == FilterVerdict.PASS)
    T.check("joker noktayı aşmaz ('pixel.*' iki etiketi yutmaz)", v("pixel.a.b.takip.org") == FilterVerdict.PASS)
    T.check("izin listesi joker kuraldan önce gelir (ads9 izinli)", v("ads9.ornek.com") == FilterVerdict.PASS && v("cdn.ads9.ornek.com") == FilterVerdict.PASS)
    val ae = FilterEngine(emptyList(), FilterTier.EMPTY, listOf("*.izin*.ornek.com"), listOf("ornek.com"))
    T.check("joker izin kuralı düz engeli deler", ae.verdictOf("izinli.ornek.com") == FilterVerdict.PASS && ae.verdictOf("baska.ornek.com") == FilterVerdict.USER)
    val q = Dns.buildQuery(0x1111, "ADS3.Ornek.Com")
    T.check("DNS sorgusunda (büyük/küçük harf karışık) yakalanır", e.fork().verdict(q, 0, q.size) == FilterVerdict.USER)
    T.check("yalnız joker kural varken motor etkin sayılır", FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("ads*.ornek.com")).active)

    fun enc(n: String): ByteArray { val o = java.io.ByteArrayOutputStream(); for (l in n.split('.')) { o.write(l.length); o.write(l.toByteArray()) }; o.write(0); return o.toByteArray() }
    fun cname(q: String, target: String): ByteArray {
        val o = java.io.ByteArrayOutputStream()
        val hd = ByteArray(12); Packets.put16(hd, 0, 7); Packets.put16(hd, 2, 0x8180); Packets.put16(hd, 4, 1); Packets.put16(hd, 6, 2)
        o.write(hd); o.write(enc(q)); o.write(byteArrayOf(0, 1, 0, 1))
        val t = enc(target)
        o.write(byteArrayOf(0xC0.toByte(), 12, 0, 5, 0, 1, 0, 0, 0, 60, 0, t.size.toByte())); o.write(t)
        o.write(t); o.write(byteArrayOf(0, 1, 0, 1, 0, 0, 0, 60, 0, 4, 1, 2, 3, 4))
        return o.toByteArray()
    }
    val c1 = cname("magaza.site.example", "ads42.ornek.com")
    val c2 = cname("magaza.site.example", "cdn.ornek.com")
    T.check("CNAME gizlemesi: temiz ad joker kurala uyan hedefe yönlenirse engellenir", e.fork().cnameVerdict(c1, 0, c1.size) != FilterVerdict.PASS &&
        e.fork().cnameVerdict(c2, 0, c2.size) == FilterVerdict.PASS)

    T.group("sizma28: joker kurallar — kötücül girdi (uzunluk, karmaşıklık)")
    val evil = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), listOf("a*a*a*a*a*a*a*a*b.ornek.com"))
    val longLabel = "a".repeat(63) + ".ornek.com"
    val t0 = System.nanoTime()
    var hit = 0
    repeat(20_000) { if (evil.verdictOf(longLabel) != FilterVerdict.PASS) hit++ }
    val ms = (System.nanoTime() - t0) / 1_000_000
    T.check("geri dönüşlü kötücül kural: eşleşmez ve hızlı (20 000 sorgu < 2 sn)", hit == 0 && ms < 2000, "$ms ms")
    val many = (1..200).map { "r$it*.ornek$it.com" }
    T.check("en çok ${NamePatterns.MAX} kural derlenir", NamePatterns.of(many).size == NamePatterns.MAX)
    val rnd = java.util.Random(28)
    var mismatch = 0
    repeat(3000) {
        val lab = (1..rnd.nextInt(8) + 1).map { "ab*-".random(kotlin.random.Random(rnd.nextLong())) }.joinToString("")
        val txt = (1..rnd.nextInt(10)).map { "ab-".random(kotlin.random.Random(rnd.nextLong())) }.joinToString("")
        if (txt.isEmpty()) return@repeat
        val re = Regex("^" + lab.split('*').joinToString("[a-z0-9_-]*") { Regex.escape(it) } + "$")
        val pb = lab.toByteArray(); val tb = txt.toByteArray()
        if (NamePatterns.glob(pb, tb, 0, tb.size) != re.matches(txt)) mismatch++
    }
    T.check("glob eşleyici 3000 rastgele durumda düzenli ifade kâhiniyle aynı", mismatch == 0, "fark=$mismatch")
}
