package app.dnshizli.selftest

import app.dnshizli.core.*

/** sizma31: DPI kayıtlı ad ortasından bölme, tireli etiketin her parçası, yerel bölgeler (RFC 6303/6761/6762/7686). */
internal fun runRound7Tests() {
    runSniCutTests()
    runHyphenTokenTests()
    runLocalZoneTests()
}

private fun joinedParts(p: List<Dpi.Part>): ByteArray { val o = java.io.ByteArrayOutputStream(); for (x in p) o.write(x.data); return o.toByteArray() }

private fun runSniCutTests() {
    T.group("sizma31: DPI — bölme noktası kayıtlı adın ortasında (uzun alt alanlarda ayırt edici kısım bütün kalmaz)")
    val cases = mapOf(
        "rr5---sn-u0g3uxax3-xncl.googlevideo.com" to "googlevideo",
        "www.youtube.com" to "youtube",
        "media.discordapp.net" to "discordapp",
        "static-cdn.edge.uzun-bir-alt-alan.ornek-site.com.tr" to "ornek-site",
        "x.co" to null,
    )
    for ((host, word) in cases) {
        val h = testHello(host)
        val hi = Dpi.Hello().also { Dpi.parseHello(h, h.size, it) }
        val cut = Dpi.sniCut(h, hi)
        T.check("$host: bölme noktası SNI içinde", cut in hi.sniOff + 1 until hi.sniOff + hi.sniLen)
        if (word != null) {
            val left = String(h, hi.sniOff, cut - hi.sniOff, Charsets.ISO_8859_1)
            val right = String(h, cut, hi.sniOff + hi.sniLen - cut, Charsets.ISO_8859_1)
            T.check("$host: '$word' iki parçada da bütün değil ('$left' | '$right')", !left.contains(word) && !right.contains(word))
            for (plan in intArrayOf(0, 2, 4, 9)) {
                val parts = Dpi.split(Dpi.TLS, plan, h, h.size)
                val bad = parts.any { String(it.data, Charsets.ISO_8859_1).contains(word) }
                T.check("$host yöntem $plan: hiçbir TCP parçası '$word' taşımaz, birleşince aynı", !bad && joinedParts(parts).contentEquals(h))
            }
        }
    }
    val long = testHello("rr5---sn-u0g3uxax3-xncl.googlevideo.com")
    val hl = Dpi.Hello().also { Dpi.parseHello(long, long.size, it) }
    T.check("eski davranış (adın tam ortası) bu adda 'googlevideo.com'u ikinci parçada bütün bırakıyordu (iyileştirmenin gerekçesi)",
        String(long, hl.sniOff + hl.sniLen / 2, hl.sniLen - hl.sniLen / 2, Charsets.ISO_8859_1).contains("googlevideo.com"))
}

private fun runHyphenTokenTests() {
    T.group("sizma31: Sıkı sezgi — tireli etiketin ORTA parçaları da")
    val strict = FilterEngine(emptyList(), FilterTier.EMPTY, emptyList(), emptyList(), riskyTlds = true)
    val hit = listOf("eu-ads-img.site.com", "cdn-tracking-v2.app.com", "x-telemetry-y.app.net", "a-b-adserver-c.site.org")
    val miss = hit.filter { strict.verdictOf(it) == FilterVerdict.PASS }
    T.check("orta parça yakalanır", miss.isEmpty(), miss.joinToString())
    val pass = listOf("my-uploads-x.site.com", "x-ad-y.site.com", "a-pixel-b.site.com", "road-s.site.com", "re-adsense-yardim.site.com", "a--b.site.com", "-.site.com")
    val over = pass.filter { strict.verdictOf(it) != FilterVerdict.PASS }
    T.check("benzer/zayıf parçalar geçer", over.isEmpty(), over.joinToString())
}

private fun runLocalZoneTests() {
    T.group("sizma31: yerel bölgeler — internete sorulmayan adlar")
    val yes = listOf("4.3.168.192.in-addr.arpa", "5.0.0.10.in-addr.arpa", "1.2.20.172.in-addr.arpa", "1.0.0.127.in-addr.arpa", "9.9.254.169.in-addr.arpa",
        "1.0.64.100.in-addr.arpa", "168.192.in-addr.arpa", "1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa",
        "a.b.c.d.f.ip6.arpa", "1.2.3.8.e.f.ip6.arpa", "gizli.onion", "abcdef.ONION", "yazici.local", "x.invalid", "invalid", "Printer.Local.")
    val no = listOf("8.8.8.8.in-addr.arpa", "1.0.32.172.in-addr.arpa", "1.0.15.172.in-addr.arpa", "1.0.128.100.in-addr.arpa", "1.1.1.1.in-addr.arpa",
        "arpa", "in-addr.arpa", "8.4.0.6.8.b.d.0.1.0.0.2.ip6.arpa".replace("8.b.d.0.1.0.0.2", "0.0.0.0.8.6.2.2"), "local.com", "onion.ornek.com", "ornek.com", "home.arpa", "router.lan")
    T.check("yerel sayılır: ${yes.size} ad", yes.all { LocalZones.matches(it) }, yes.filterNot { LocalZones.matches(it) }.joinToString())
    T.check("yerel sayılmaz: ${no.size} ad (genel adresler, 172.32, 100.128, home.arpa, .lan)", no.none { LocalZones.matches(it) }, no.filter { LocalZones.matches(it) }.joinToString())
    T.check("üst sunucu yerel ağdaysa (Pi-hole/modem) kapanır", LocalZones.lanUpstream(listOf("192.168.1.2")) && LocalZones.lanUpstream(listOf("fd00::53")) && !LocalZones.lanUpstream(listOf("1.1.1.1", "2606:4700::1111")))

    // Sarmalayıcıdan geçiş: yerel ad "yok" cevabı alır, üst sunucuya gitmez; genel ters ad gider; kapalıyken gider.
    val inner = object : Forwarder {
        var got = 0
        override val proto: Proto get() = Proto.PLAIN
        override fun start() {}
        override fun onPacket(p: ByteArray, len: Int) { got++ }
        override fun stats() = Stats(queries = got.toLong(), forwarded = got.toLong())
        override fun resetNetwork(reason: String) {}
        override fun clearCache() {}
        override fun close() {}
    }
    val wrote = ArrayList<ByteArray>()
    val fw = FilteringForwarder(inner) { b, off, len -> wrote.add(b.copyOfRange(off, off + len)) }
    fun pkt(name: String, id: Int): ByteArray {
        val dns = Dns.buildQuery(id, name)
        Packets.put16(dns, dns.size - 4, 12)                                   // PTR
        val pk = ByteArray(Packets.HDR + dns.size)
        System.arraycopy(dns, 0, pk, Packets.HDR, dns.size)
        pk[0] = 0x45; Packets.put16(pk, 2, pk.size); Packets.put16(pk, 6, 0x4000); pk[8] = 64; pk[9] = 17
        Packets.put32(pk, 12, Packets.ip(10, 111, 222, 1)); Packets.put32(pk, 16, Packets.ip(10, 111, 222, 2))
        Packets.put16(pk, 10, Packets.checksum(pk, 0, 20)); Packets.put16(pk, 20, 40001); Packets.put16(pk, 22, 53); Packets.put16(pk, 24, 8 + dns.size)
        return pk
    }
    try {
        FilterRuntime.localZones = true
        val p1 = pkt("7.1.168.192.in-addr.arpa", 0x5151)
        fw.onPacket(p1, p1.size)
        T.check("filtre kapalıyken bile: LAN ters sorgusu yerelde NXDOMAIN, üst sunucuya gitmez",
            inner.got == 0 && wrote.size == 1 && (Packets.u16(wrote[0], Packets.HDR + 2) and 0xF) == 3 && Packets.u16(wrote[0], Packets.HDR) == 0x5151 && fw.localAnswered == 1L)
        val p2 = pkt("8.8.8.8.in-addr.arpa", 0x5152); fw.onPacket(p2, p2.size)
        T.check("genel ters sorgu üst sunucuya gider", inner.got == 1 && wrote.size == 1)
        val p3 = pkt("gizli.onion", 0x5153); fw.onPacket(p3, p3.size)
        T.check(".onion adı DNS'e sızmaz", inner.got == 1 && wrote.size == 2)
        FilterRuntime.localZones = false
        val p4 = pkt("7.1.168.192.in-addr.arpa", 0x5154); fw.onPacket(p4, p4.size)
        T.check("yerel ağ üst sunucusunda (kapalı) ters sorgu sunucuya gider", inner.got == 2 && wrote.size == 2)
        T.check("yerel cevaplar 'engellenen' sayılmaz", fw.stats().blocked == 0L)
    } finally { FilterRuntime.localZones = true }
    var t0 = System.nanoTime(); var hits = 0
    val q = Dns.buildQuery(1, "www.ornek-site.com")
    repeat(200_000) { if (LocalZones.matchesQuery(q, 0, q.size)) hits++ }
    val ms = (System.nanoTime() - t0) / 1_000_000
    T.check("sıradan adlar için hızlı yol (200 bin sorgu < 1 sn, eşleşme yok)", hits == 0 && ms < 1000, "$ms ms")
}
