#!/usr/bin/env python3
"""Yayın öncesi kanarya: üretilen filtre listeleri yayınlanmadan ÖNCE sunucu tarafında denetlenir.

Uygulama (core/ListUpdate.kt, ListCanary) indirdiği listeyi zaten denetler; ama orada yakalanan bozuk bir yayın her telefonda
ayrı ayrı reddedilir ve günlerce eski listede kalınır. Burada yakalanırsa hiç yayınlanmaz.

Kurallar tek kaynaktan okunur: MUST_PASS / MUST_BLOCK / MIN_BLOCKED doğrudan ListUpdate.kt'den ayrıştırılır (iki liste ayrışmasın).
Sunucu denetimi uygulamadakinden SIKIDIR: korunan adlar (protected.txt) hesaba katılmaz; çünkü eski APK'larda korunan küme farklı
olabilir ve popüler bir site yalnızca korumaya güvenerek açık kalmamalı.

Kullanım: kanarya.py LISTE_KLASORU [--prev ONCEKI_KLASOR] [--kt ListUpdate.kt]
Çıkış kodu 0: sorun yok. 1: yayın iptal (neden stderr'de).
"""
import os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
LISTS = ("basic.bin", "medium.bin", "strict.bin")
M = (1 << 64) - 1


def h64(name):
    """Filter.kt FilterHash.hash ve build_filter.py h64 ile birebir aynı (48 bit)."""
    x = 0xcbf29ce484222325
    for b in name.encode("ascii"):
        x ^= b
        x = (x * 0x100000001b3) & M
    x = ((x ^ (x >> 30)) * 0xbf58476d1ce4e5b9) & M
    x = ((x ^ (x >> 27)) * 0x94d049bb133111eb) & M
    x ^= x >> 31
    return x & 0xFFFFFFFFFFFF


def read_bin(path):
    """DNF1 dosyası → özet kümesi. Bozuksa ValueError."""
    data = open(path, "rb").read()
    if len(data) < 8 or data[:4] != b"DNF1":
        raise ValueError("başlık")
    n = struct.unpack(">I", data[4:8])[0]
    out, prev, i = set(), 0, 8
    for _ in range(n):
        v, shift = 0, 0
        while True:
            if i >= len(data) or shift > 63:
                raise ValueError("kısa")
            c = data[i]; i += 1
            v |= (c & 0x7F) << shift; shift += 7
            if not c & 0x80:
                break
        prev += v
        if prev > 0xFFFFFFFFFFFF:
            raise ValueError("taşma")
        out.add(prev)
    if i != len(data) or len(out) != n:
        raise ValueError("fazla/tekrar")
    return out


def rules(kt_path):
    """ListUpdate.kt içindeki ListCanary listelerini ayrıştırır."""
    src = open(kt_path, encoding="utf-8").read()
    def lst(name):
        m = re.search(r"val %s: List<String> = listOf\((.*?)\)" % name, src, re.S)
        if not m:
            raise SystemExit("ListUpdate.kt içinde %s bulunamadı" % name)
        return re.findall(r'"([^"]+)"', m.group(1))
    m = re.search(r"const val MIN_BLOCKED = (\d+)", src)
    if not m:
        raise SystemExit("ListUpdate.kt içinde MIN_BLOCKED bulunamadı")
    return lst("MUST_PASS"), lst("MUST_BLOCK"), int(m.group(1))


def suffixes(d):
    p = d.split(".")
    return [".".join(p[i:]) for i in range(len(p) - 1)]       # kendisi dahil, en az iki etiket (Filter.kt ile aynı)


def check(folder, prev=None, kt=None):
    """Sorun yoksa None, varsa ListCanary.check ile aynı biçimde kısa neden."""
    must_pass, must_block, min_blocked = rules(kt or os.path.join(ROOT, "app/src/main/java/app/dnshizli/core/ListUpdate.kt"))
    tiers = {}
    for n in LISTS:
        p = os.path.join(folder, n)
        if not os.path.exists(p):
            return "eksik:" + n
        try:
            tiers[n] = read_bin(p)
        except (ValueError, struct.error):
            return "bozuk:" + n
        if prev:
            pp = os.path.join(prev, n)
            if os.path.exists(pp):
                try:
                    ref = len(read_bin(pp))
                except (ValueError, struct.error):
                    ref = 0
                if ref > 0:
                    if len(tiers[n]) * 2 < ref: return "kirpilmis:" + n
                    if len(tiers[n]) > ref * 4: return "sismis:" + n
    allh = set().union(*tiers.values())
    def blocked(d): return any(h64(s) in allh for s in suffixes(d.lower()))
    for d in must_pass:
        if blocked(d): return "engelli:" + d
    nb = sum(1 for d in must_block if blocked(d))
    if nb < min_blocked: return "zayif:%d/%d" % (nb, len(must_block))
    return None


def main(argv):
    if not argv or argv[0].startswith("-"):
        print(__doc__, file=sys.stderr); return 2
    folder, prev, kt = argv[0], None, None
    i = 1
    while i < len(argv):
        if argv[i] == "--prev" and i + 1 < len(argv): prev = argv[i + 1]; i += 2
        elif argv[i] == "--kt" and i + 1 < len(argv): kt = argv[i + 1]; i += 2
        else: print("bilinmeyen argüman: " + argv[i], file=sys.stderr); return 2
    why = check(folder, prev, kt)
    if why:
        print("::error::Kanarya: %s — yayın iptal" % why, file=sys.stderr); return 1
    print("Kanarya: geçti")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
