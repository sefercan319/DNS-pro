import java.util.Properties

// Kotlin, AGP 9'a yerleşiktir; ayrı bir Kotlin eklentisi yoktur.
plugins {
    id("com.android.application")
}

// Kodun Java hedefi (tek yerde). Derleme bozulursa (ör. "class file version" hatası) yalnızca bu satırı 21 ya da 17 yap.
val JAVA_HEDEF = JavaVersion.VERSION_25

// Yayın imzası: proje köküne keystore.properties koyarsan (bkz. OKUBENI.md) yayın derlemesi imzalanır.
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

// Play Store'a yüklemeden önce kendi benzersiz kimliğinle değiştir (ör. com.seninadin.dnshizli).
// Yalnızca BU satır değişir: kod paketi (namespace) "app.dnshizli" kalır, kısayollar kimliği buradan alır.
val appId = "app.dnshizli"

// Kişisel sürüm: gradle -Ppersonal=true ile derlenir (ör. ./gradlew assembleRelease -Ppersonal=true). Varsayılan Play sürümüdür.
val personalBuild = (findProperty("personal") as String?) == "true"

// Liste güncellemesi (tools/yayin/README.md): açık anahtar ve yayın adresi kodda değil, derleme ortamından gelir.
// GitHub Actions'ta LIST_PUBLIC_KEY gizli değeri tanımlıysa güncelleme açılır; adres deponun "listeler" yayınıdır.
// Değerler yalnızca güvenli karakterlerden oluşmalı (Java kaynağına yazılır): değilse boş sayılır, güncelleme kapalı kalır.
val listPublicKey = (System.getenv("LIST_PUBLIC_KEY") ?: (findProperty("listPublicKey") as String?) ?: "").trim()
    .takeIf { it.matches(Regex("^[A-Za-z0-9+/=]{0,400}$")) } ?: ""
val listBaseUrl = (System.getenv("LIST_BASE_URL")
    ?: System.getenv("GITHUB_REPOSITORY")?.let { "https://github.com/$it/releases/download/listeler/" } ?: "").trim()
    .takeIf { it.matches(Regex("^https://[A-Za-z0-9._~/-]{1,200}/$")) } ?: ""

android {
    namespace = "app.dnshizli"
    // Google Play, yeni uygulama ve güncellemelerde (31 Ağustos 2026'dan beri) hedef API 36 ister; her yıl bir üst sürüme çıkar.
    compileSdk = 36

    defaultConfig {
        applicationId = appId
        // shortcuts.xml içindeki targetPackage bu değeri kullanır (@string/app_package).
        resValue("string", "app_package", appId)
        buildConfigField("boolean", "PERSONAL", personalBuild.toString())
        buildConfigField("String", "LIST_PUBLIC_KEY", "\"$listPublicKey\"")
        buildConfigField("String", "LIST_BASE_URL", "\"$listBaseUrl\"")
        minSdk = 34
        targetSdk = 36
        versionCode = 48
        versionName = "1.30.0"
    }

    signingConfigs {
        // Sabit, herkese açık "debug" anahtarı (gizli değildir): GitHub'da her derleme aynı anahtarla imzalanır, böylece yeni APK
        // eskisinin ÜZERİNE kurulur (her çalıştırmada rastgele yeni anahtar üretilseydi "paket çakışıyor" hatası alınırdı).
        // Play Store'a yüklenecek yayın için bu anahtar KULLANILMAZ; aşağıdaki "release" anahtarı kullanılır.
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        create("release") {
            if (keystoreProps.isNotEmpty()) {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (keystoreProps.isNotEmpty()) signingConfig = signingConfigs.getByName("release")
        }
    }

    buildFeatures {
        resValues = true   // AGP 8 ve 9'da varsayılan kapalı; app_package metin kaynağı için gerekli
        buildConfig = true // BuildConfig.PERSONAL (kişisel/Play ayrımı)
    }

    compileOptions {
        sourceCompatibility = JAVA_HEDEF
        targetCompatibility = JAVA_HEDEF
    }

    lint {
        // Yayın derlemesi, uyarılar yüzünden durmasın; ./gradlew lint ile raporu ayrıca incele.
        abortOnError = false
    }
}

// Yayın paketi imzasız üretilmesin: anahtar bilgisi yoksa yayın derlemesi açık bir hatayla durur (debug etkilenmez).
gradle.taskGraph.whenReady {
    val wantsRelease = allTasks.any { it.project == project && (it.name == "assembleRelease" || it.name == "bundleRelease") }
    if (wantsRelease && keystoreProps.isEmpty()) {
        throw GradleException("Yayın derlemesi için keystore.properties gerekli (bkz. keystore.properties.example ve OKUBENI.md).")
    }
}

// Kotlin'in jvmTarget değeri, AGP 9'da compileOptions.targetCompatibility'den otomatik alınır (ayrı ayar gerekmez).

// Bağımlılık yok: yalnızca Android çatısı ve Kotlin standart kütüphanesi. Bu, uygulamanın küçük
// ve hızlı açılan kalmasının nedenlerinden biridir.
