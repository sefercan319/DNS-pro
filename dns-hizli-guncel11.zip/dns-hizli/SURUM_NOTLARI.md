# Sürüm notları

Ayrıntılı geliştirme tarihçesi ve kararlar: [DNS_HIZLI_TARIHCE.txt](DNS_HIZLI_TARIHCE.txt). En yeni sürüm en üstte.

## 1.30.0 (versionCode 48)

**Geniş güvenlik geçişi: şifreli DNS, ODoH, kriptografi, ağ geçidi (ayrıntı: GUVENLIK_INCELEMESI.md, "Ek inceleme 1.30.0")**
- **HTTP çerçeveleme (DoH, ODoH, yapılandırma alımı):** tek ortak kural kümesi (`HttpRules`). Katlanmış başlık, boşluklu başlık adı, "gzip, chunked" gibi çözülemeyen aktarım kodlamaları, ikinci Transfer-Encoding ve parça sonunda CRLF olmayan cevaplar reddedilir; 100/103 ara cevapları atlanır (en çok 4); durum satırı tam 3 basamak olmalı.
- **ODoH:** her sorgu tek kullanımlık (aynı cevap ikinci kez açılamaz); cevap anahtarı, nonce, ara anahtar, dışa aktarılan sır ve sorgunun düz metni başarıda da hatada da bellekten silinir.
- **HPKE/HKDF:** ara sırlar (paylaşılan sır, anahtar çizelgesi sırrı, KEM ara anahtarı, HKDF blokları) kullanıldıktan hemen sonra silinir. RFC vektörleri ve çapraz doğrulama aynen geçiyor.
- **Düz DNS:** cevap, sorunun gönderildiği soketten (aynı kaynak portundan) gelmek zorunda; sahte cevap gönderen biri artık iki porttan herhangi birini tutturmakla yetinemez.
- **Reklam+:** mutlak biçimli HTTP isteği (`GET http://reklam.example/ …` + izinli görünen Host) ve CONNECT hedefi de denetlenir; "Host: izinli.com" yazarak engel atlatılamaz.
- **Ağ geçidi belleği:** tüm TCP akışlarının kuyruklarına ortak 24 MB tavan. Önceden 1500 bağlantı × 224 KB ≈ 330 MB'a kadar büyüyebiliyordu; okumayan bir uygulama servisi bellek yetersizliğinden öldürebilirdi. Tavan dolunca TCP geri basıncı devreye girer, boşalınca duran akışlar kendiliğinden sürer.
- **Kilitlenme düzeltmesi:** istemci penceresi dolduğunda sunucudan gelen veri istemciye gönderilmeden bekleyebiliyordu (iki yön birbirini bekliyordu). Artık her durumda akıtılır; zamanlayıcı da bekleyen veriyi yoklar.
- **Liste güncelleme:** manifestte ikinci sürüm satırı ve rakam dışı sürüm reddedilir; gömülü anahtar yalnızca P-256 olabilir.

- Testler: 7594 kontrol, 0 başarısız (yeni: HTTP kuralları, ODoH tek kullanım/silme, yanlış soketten cevap, mutlak biçim atlatması uçtan uca, ortak bellek tavanı uçtan uca). Android tarafı bu sürümde değişmedi.

**Reklam engelleme güçlendirmesi**
- **Yeni listeler (Basit):** GoodbyeAds (mobil uygulama reklamları, MIT) ve turk-adlist (Türkçe haber/alışveriş sitelerinin reklam sunucuları, CC BY-SA 3.0). Türkçe sitelerin reklam sunucularında kapsam %81'den %98'e çıktı; Basit katman 360 binden 506 bin ada çıktı. Tüm listeler bugünkü sürümleriyle yeniden derlendi.
- **Yeni liste (Orta):** AdGuard CNAME gizli izleyicileri (MIT): birinci taraf gibi görünen izleyici alt alan adları.
- **Bozulma koruması:** liste derlenirken siteleri/uygulamaları bozan girdiler (AliExpress görselleri, JW Player videoları, TRT oynatıcısının bölge denetimi, giriş servisleri, kısa bağlantılar...) çıkarılır; popüler alan adları ayrıca bağımsız bir listede yoksa yalnızca Sıkı'ya girer.
- **Bildirim düzeltmesi:** eski Basit liste `fcm.googleapis.com` adını engelliyordu (anlık bildirim altyapısı); bazı uygulamaların bildirimleri gecikebilir ya da gelmeyebilirdi. FCM, Firebase kurulum kimliği ve OneSignal artık hiçbir seviyede engellenmez.
- **Son izin verilenler:** Engelleme sayfasında yeni liste. Reklam hâlâ görünüyorsa süzgeçten geçen son 60 adı görüp kaçan reklam sunucusunu tek dokunuşla engelleyebilirsin. Yalnızca bellekte tutulur ("Geçmişi tut" kapalıyken hiç tutulmaz). 12 dilde.
- **Reklam+ ve QUIC:** Reklam+ açıkken QUIC (UDP/443) da düşürülür. QUIC'te site adı şifreli olduğundan QUIC kullanan reklam sunucuları ve uygulamalar Reklam+'ı atlıyordu; artık TCP/TLS'e dönüp adları görünür oluyor.
- **Yabancı siteler, açılır pencere ve yönlendirmeler:** EasyList reklam sunucuları ve EasyList açılır pencere/yönlendirme sunucuları (yalnızca bütün alan adını engelleyen kurallar; CC BY-SA 3.0) Basit'e, EasyPrivacy izleyici sunucuları Orta'ya eklendi. Genel karşılaştırma listesinde (HaGeZi Multi Normal, yalnızca ölçüt, pakete girmez) Basit kapsamı %54'ten %64'e çıktı; bilinen açılır pencere ağlarında %96.
- **Tarayıcının DNS atlatmasını engelle (yeni ayar, varsayılan açık):** tarayıcı ya da uygulama kendi şifreli DNS'ini (Chrome "Güvenli DNS", uygulama içi DoH) kullanırsa sorgular süzgece hiç gelmez, reklamlar ve açılır pencereler geçerdi. Engelleme açıkken bilinen şifreli DNS sağlayıcılarının adları engellenir; tarayıcı sistem DNS'ine döner. Chrome'da "Güvenli DNS" belirli bir sağlayıcıya ayarlıysa sayfa açılmayabilir: o ayar kapatılmalı ya da bu ayar kapatılmalı (notta yazıyor). 12 dilde.
- **Her gün değişen reklam adları:**
  - *Günlük liste güncellemesi:* GitHub her gün listeleri yeniden üretip imzalar; uygulama Wi-Fi'de 12 saatte bir, mobil veride 3 günde bir denetler. Açık anahtar ve yayın adresi artık koddan değil derleme ortamından (GitHub gizli değeri `LIST_PUBLIC_KEY`) gelir; kurulum 2 gizli değer + 1 tıklama (tools/yayin/README.md). Proje zip olarak yüklenmiş depoda da çalışır.
  - *Şüpheli ad işaretleme:* "Son izin verilenler" listesinde reklam/yönlendirme sunucusuna benzeyen adlar (reklam sözcükleri, rastgele onaltılık ya da harf-rakam dizileri, riskli uzantılar) başa alınır ve "Reklama benziyor" diye işaretlenir; "Şüphelilerin hepsini engelle" tek dokunuşla hepsini kendi engel listesine ekler. Yalnızca öne çıkarır, kendiliğinden engellemez (en popüler 10 bin sitenin ~%0,5'i işaretlenir; çoğu zaten reklam/bahis adı).
  - *Sıkı seviyede riskli uzantılar:* yaygın sitelerde neredeyse hiç görülmeyen, dönen reklam adlarında sık kullanılan uzantılar (.cfd, .cyou, .icu, .sbs, .rest, .quest, .buzz…) bütünüyle engellenir. EasyList reklam sunucularının ~%11'i bu uzantılarda. İzin listesi önce gelir. Seviye notu 12 dilde güncellendi.
  - *Kendi adresinden reklam veren siteler:* reklam ayrı bir alt alan adındaysa (ads.site.com) yukarıdaki listeden engellenebilir; sayfa ile aynı adresten geliyorsa DNS ile ayırt edilemez (HTTPS içeriğini açmak gerekir, bu uygulama bunu bilerek yapmaz).
- Testler: 7754 kontrol, 0 başarısız (yeni: Türkçe, mobil ve açılır pencere reklam sunucuları, bozulmaması gereken 33 ad, lisans bildirimleri, son izin verilenler, DNS atlatma koruması, şüpheli ad işaretleme ve toplu engelleme, riskli uzantılar).


## 1.29.1 (versionCode 47)

**Reklam+, DPI ve DNS düzeltmeleri**
- **Sabit DNS sunucusuna soran uygulamalar:** ağ geçidi açıkken, DNS de açıksa, bir uygulama kendi DNS sunucusuna (ör. 8.8.8.8:53) düz DNS ile sorsa bile sorgu artık seçtiğin sunucuya ve süzgece yönlenir (önceden şifresiz olarak doğrudan çıkıyordu). Yerel/özel hedefler (yönlendirici, şirket DNS'i) yönlendirilmez.
- **TCP/53 DNS:** sabit sunucuya TCP ile giden DNS soruları da süzülür (önceden yalnızca UDP süzülüyordu).
- **Gizli izleyici (CNAME):** sabit sunucudan UDP/53 ile gelen cevaplarda da CNAME zinciri denetlenir.
- **ECH:** Reklam+ açıkken HTTPS/SVCB (tür 65/64) sorgularına "kayıt yok" denir. Bu kayıtlar şifreli ClientHello (ECH) anahtarı taşır; tarayıcı ECH kullanınca gerçek site adı ağ geçidinden görünmez, reklam engeli atlanırdı. Kayıt yoksa tarayıcı düz TLS'e döner. Reklam+ kapalıyken davranış değişmedi.
- **Engelli ad asla sızmaz:** sınıfı IN olmayan (CHAOS, ANY...) bir soruyla engelli ad üst sunucuya gidebiliyordu; artık "reddedildi" (RCODE 5) cevabı verilir. Aynı sağlamlaştırma gizli izleyici cevabında da var.
- **Kök ad sorgusu** (".") biçim hatası sayılıyordu; artık normal iletilir.
- **HTTP Host okuma:** gövdedeki "Host:" satırı Host başlığı sayılmaz (yalnızca başlık bölümü okunur).
- Testler: yeni kontroller eklendi (UDP/TCP 53 uçtan uca dahil).

## 1.29.0 (versionCode 46)

**Güvenlik sertleştirmesi (ayrıntı: GUVENLIK_INCELEMESI.md, "Ek inceleme 1.29.0")**
- **Filtre atlatmaları kapatıldı:** 0x80 ve üstü baytlı etiketlerle (ör. `x.doubleclick.net` önüne eklenen sahte bayt) engel atlanabiliyordu; artık ad bayt bayt doğru okunur. Birden çok soru içeren, sıkıştırma işaretçili, ayrılmış etiket türlü ya da kesik sorgular filtre açıkken yönlendirilmez; istemciye hata (FORMERR) döner.
- **Reklam+ / DPI:** ağdan gelen SNI ve Host adları, kullanıcı girişi gibi katı değil, gevşek biçimde temizlenir; alışılmadık yazımlar engel listesini artık aşamaz.
- **Kayıt sızıntısı:** günlüğe yazılan adlardaki denetim ve garip karakterler "?" ile değiştirilir.
- **Liste güncelleme:** liste kümesi tek dizin değişimiyle yerine konur (yarım kalan güncelleme eski ve yeni dosyaları karıştırmaz); uygulama güncellenince eski önbellek yok sayılır; dosya başına 90 sn toplam süre sınırı; aynı anda tek güncelleme.
- Testler: 7457 kontrol, 0 başarısız. Android tarafı (ListUpdater) bu ortamda derlenmedi; GitHub derlemesinde doğrulanır.

**Metinler:** Yenilikler ilk maddesi ve mağaza/gizlilik metinleri Google Play koşullarına göre güncellendi (VPN açıklaması, isteğe bağlı DPI/Reklam+ kipleri, liste güncelleme beyanı).

## 1.28.0 (versionCode 45)

**Engelleme motoru ve liste güncellemesi**
- **Otomatik liste güncellemesi:** engelleme listeleri (basic/medium/strict) uygulamanın içinde değil, imzalı bir yayın adresinde tutulur. Uygulama en çok günde bir kontrol eder, indirir, doğrular ve yerine koyar. Varsayılan açık; gizlilik metninde ayrıntı var.
- **İmza zorunluluğu:** manifest ECDSA P-256 ile imzalanır; imza gömülü açık anahtarla doğrulanmadan hiçbir liste kabul edilmez. Açık anahtar tanımlı değilse güncelleme kapalıdır (güvenli varsayılan).
- **Geri dönüş (rollback) engeli:** sürüm numarası kurulu sürümden büyük olmalı; eski imzalı bir sürüme dönülemez.
- **Boyut ve özet kontrolü:** her dosyanın boyu ve SHA-256 özeti manifestle eşleşmeli; 100 KB altındaki (boş/kırpılmış) listeler reddedilir, böylece bir yayın hatası tüm kullanıcılarda engellemeyi kapatamaz.
- **Katman bazında yedek:** önbellekteki bir liste bozuksa yalnızca o katman paketteki sürümden okunur; eskiden tek bozuk dosya tüm engellemeyi kapatıyordu.
- **Yeniden yükleme:** liste değişince motor, ayarları korunarak senkron ya da arka planda yeniden kurulabilir.
- **Yayın iş akışı:** `.github/workflows/listeleri-yayinla.yml` haftada bir listeleri üretir, imzalar ve "listeler" yayınına koyar. Kurulum adımları: `tools/yayin/README.md`.

**Hazır arka planlar**
- Uygulamayla gelen 8 görsel yerine 28 görsel. Filigranlı iki görsel (onedio ve pngtree damgalı) listeye alınmadı. Hazır görseller ekran oranına kırpılır; küçük çözünürlüklü görseller (genişlik 240–500 px) telefonda yumuşak görünebilir.

**Kendi stilim**
- Kişiselleştirmede "Kendi stilim" sayfası beş bölümden oluşur: Görünüm (gökyüzü, vurgu, sıvı hareketi, dalga yüksekliği kaydırıcısı), Hareket (animasyon türü, biçimi ve büyüklük kaydırıcısı), Ses (tını, dizi ve perde), Kayıtlı stillerim (altı yuva) ve Araçlar (karıştır, sesi dinle, sıfırla).
- Kayıtlı stillerim: Bir yuvaya dokunup mevcut ayarları kaydedebilirsin. Dolu bir yuvada uygula ya da sil seçilir. Kayıtlar telefona özgüdür.
- 24 yeni tema (12 açık, 12 koyu): toplam 48 tema. Her tema WCAG kontrolünden geçer.
- Güvenlik: ağ geçidi açıkken IPv4 tünelinde IPv6 trafiğinin reklam, DoH ve DPI denetimini atladığı sızıntı kapatıldı.
- IPv6 uzantı başlıkları (hop-by-hop, yönlendirme, hedef seçenekleri) artık geçiyor; önceden bu paketler düşüyordu.
- HTTP Host başlığında IPv6 değişmezi doğru okunuyor.
- Yeni dillerde (Almanca, İspanyolca, Fransızca, Endonezyaca, İtalyanca, Lehçe, Portekizce, Rusça, Ukraynaca, Vietnamca) yeni özel stil ve tema adları çevrildi.
- Uzun seçim listelerinde (dil, tema, parça vb.) açılışta seçili seçenek görünür; artık en alttaki seçenekten sonra listenin başına dönülmez.
- 162 animasyon parçası: 18 efekt türü × 9 biçim. Türler birbirinden farklı çizilir: yörünge, taç yaprağı, kabarcık, şimşek, kristal, ateşböceği, sarmal, ışın, kırılma ve piksel türleri eklendi. "Stilin kendi animasyonu" varsayılandır.
- 384 ses parçası: 16 tını × 12 nota dizisi × 2 perde (normal ve yüksek). Dizilere titreşim ve akor eklendi. "Otomatik (paket)" varsayılandır.

**Efekt biçimleri ve ses parçaları**
- Dokunma efekti biçimi 5'ten 9'a çıktı: Eğik, Ayna, Büyüyen, Hızlı (her stil için ayrı seçilir).
- 384 ses parçası (16 tını × 12 nota dizisi × 2 perde): Ayarlar › Ses › "Ses parçası" ile seçilir, tını, dizi ve perde sırayla sorulur; "Otomatik (paket)" varsayılandır ve eski davranış aynıdır. Parça seçiliyken arayüz sesleri parçayla çalar.

**Özel tema**
- Kişiselleştirmede "Gökyüzü" (8 seçenek: 4 açık, 4 koyu) ve "Vurgu" (6 seçenek) ile kendi temanı kur. Metin ve yüzey renkleri seçime göre türetilir; 48 kombinasyonun hepsi WCAG 4,5:1 okunabilirlik testinden geçer.
- Tema seçicide "Özel" örneği, seçilen kombinasyonu gösterir.
- Sıvı rengi önizlemesi artık süs animasyonu olarak 33 ms kare hızında çalışır (eskiden 16 ms istiyordu).

**Yeni temalar**
- 12 yeni tema eklendi (toplam 24): açık olarak Şeftali, Turunç, Gül, Buzul, Kum, Lagün, Kakao, Şeker; koyu olarak Orman, Kor, Erik, Arduvaz. Her biri 12 dilde adlandırıldı; okunabilirlik testleri (WCAG 4,5:1) geçiyor.
- Tema seçicideki örnek önbelleği 24 temaya göre büyütüldü; eskiden her karede yeniden ayrım yapıyordu.

**Küre animasyonları ve sesler**
- **10 sıvı hareketi:** Ayarlar › Görünüm › Küre › "Sıvı hareketi" (tüm stillerde): Sakin (özgün), Gelgit, Halka, Kabarma, İkiz, Üçgen, Yumuşak kare, Kaynama, Sarmal, Durgun. Varsayılan Sakin; görünüm değişmez.
- **Her stil için 4 yeni dokunma/kutlama efekti:** "Dokunma efekti biçimi" seçeneği, aktif stil için ayrı saklanır. Seçenekler: özgün, yoğun, dönen, çift nabız, toplanan. Özgün varsayılandır.
- **3 yeni ses:** kaydırma (sayfa geçişi), uzun basış, uyarı (bağlı değilken duraklatma isteğinde). Ses paketi tınısıyla çalar.
- Sıvı hareketleri yeniden ayarlandı: her hareketin kendi hızı ve genlik çarpanı var; "Durgun" eskiden neredeyse hiç hareket etmiyordu. Sakin (varsayılan) değişmedi. Sıvı yalnızca bağlanırken/bağlıyken görünür; kapalıyken küre boştur.
- Sıvı hareketi tüm tasarım stillerinde çalışır (Duru'nun düz daire küresi dahil). Türkçe dışındaki dillerde yeni etiketler İngilizce gösterilir.

**Arayüz düzeltmeleri**
- "Kabarcıklar" ayrı ayar satırı kaldırıldı. Kabarcık miktarı artık animasyon seviyesinden gelir: Tam → çok, Az → az, Yok → kapalı. Varsayılan (Tam) görünümde kabarcık sayısı önceki "az"dan "çok"a çıktı; geri almak istersen söyle.
- Animasyon seçenekleri Yok · Az · Tam sırasıyla gösterilir (her dilde). Türkçe "Kapalı" etiketi "Yok" oldu. Kayıtlı ayarlar bozulmaz (enum sırası aynı).

**Önceki sürümden düzeltmeler (1.27.x içinde)**
- DNS cevap doğrulama açığı (soru çözülemeyen sorgularda kimlik tutan her cevap kabul ediliyordu) kapatıldı.
- HTTP çerçeveleme sertleştirildi (bozuk ya da çelişen uzunluk ve chunked+Content-Length reddedilir).

**Testler:** liste imzası, manifest biçimi, özet/boy, rollback, minimum boyut ve bozuk önbellekte yedek (57 kontrol, "girdi" grubu).

**Henüz yapılmadı (bilerek):**
- Gerçek yayın adresi ve açık anahtar: `ListUpdater.BASE_URL` ve `PUBLIC_KEY_B64` yayın kurulumunda doldurulmalı; boşken güncelleme kapalıdır.
- Ayarlarda "Listeleri otomatik güncelle" anahtarı: şimdilik yalnızca varsayılan açıktır, arayüz anahtarı sonraki adımda eklenmeli.
- Üç dosyanın yerine taşınması sırasında çökme olursa karışık sürüm kalabilir (her dosya ayrı ayrı doğrulanmış olur).

## 1.27.0 (versionCode 44)

**Güvenlik ve sağlamlık**
- **HPKE çapraz doğrulama:** ODoH'un şifreleme katmanı bağımsız bir referans uygulamayla (pyhpke, RFC 9180) iki yönde doğrulandı. Kodda değişiklik yok; test ve vektörler eklendi.
- **Nonce ve anahtar kuralları:** her kurulumda yeni efemer anahtar, nonce tekrarı olmadığı ve sıra dışı mesajların reddedildiği testlerle korunuyor.
- **Bozuk girdi fuzzing:** şifreli metne 4000 bozuk girdi; istisna ya da kabul yok, alıcı durumu korunuyor.
- **Yayın imzalama koruması:** yayın derlemesinin debug anahtarına düşmediğini ve gizli anahtar dosyalarının depo dışında kaldığını doğrulayan testler.
- **Dependabot:** Gradle bağımlılıkları ve GitHub Actions sürümleri haftalık izleniyor.
- **Ad etiketi dizisi taşması:** filtre, 128'den fazla etiketli adlarda sağdaki sonekleri sessizce atıyordu. Dizi, 255 baytlık DNS adının en çok etiket sayısına (128) göre boyutlandırıldı. Gerçek ağ sorgularında bu durum zaten oluşamıyordu; yine de düzeltildi.
- **HTTP çerçeveleme sertliği:** ODoH ve DoH cevaplarında bozuk içerik uzunluğu, birbirini tutmayan iki içerik uzunluğu ve hem chunked hem içerik uzunluğu birlikte gelen cevaplar artık reddediliyor (önceden sessizce kabul ya da 'kapanana kadar oku' moduna düşüyordu). Testler: 'HTTP çerçeveleme' grubu.
- **DNS cevabı doğrulama açığı (kritik, düzeltildi):** sorgunun sorusu çözülemediğinde (soru yok ya da sıkıştırılmış ad) soru denetimi atlanıyordu; kimlik tutan her cevap önbelleğe giriyordu. Artık yalnızca soru bölümü ve cevabı boş hata cevabı kabul ediliyor. Düz DNS ve şifreli DNS yolları aynı fonksiyonu kullandığı için ikisi de kapandı. Testler: 'Güvenlik' grubu (2 yeni kontrol).
- **Eşleştirme sınır testleri:** DNS sınırında (≤253 bayt) çok etiketli adlarda engel yakalanıyor; 253 bayttan uzun adlar geçersiz sayılıp güvenle reddediliyor.
- **Güvenlik taraması iş akışı:** Lint, mobsfscan, gitleaks ve MobSF (APK) taraması.
- **Eşzamanlılık hatası düzeltildi (kripto):** Aynı şifreleme bağlamı birden çok iş parçacığından kullanılınca nonce çakışabiliyordu (test 4000 şifrelemede 128 çakışma buldu). Artık sayaç ve şifreleme tek kilit altında; sayaç tükenirse bağlam kullanılmaz.
- **Türkçe alan adları:** `örnek.com` gibi IDN adlar artık kabul edilir ve punycode'a çevrilir (`xn--rnek-4qa.com`). Büyük harf eşlemesi (İ/ı) doğru çalışır.
- **Gizlilik politikası:** Tanılama raporunun içeriği, çökme özeti ve bildirim/açılış izinleri politikaya işlendi.
- **Tanılama raporu** (☰ > Sorun giderici > Tanılama raporu): sürüm, Android sürümü, cihaz modeli, ağ türü, ayar kodları ve sorun sayısını gösterir. Önce önizlenir, paylaşımı sen onaylarsın; alan adı, IP ya da kişisel veri içermez.

## 1.26.0 (versionCode 43)

**Yeni**
- **Duru stili** (☰ > Kişiselleştir > Stil): sakin ve sade; nane tonlu zemin, altta saydam su bandı, ince kenarlı düz yüzeyler, az hareket (solarak büyüyen sayfa geçişi, yumuşak yaylar, halka efekti).
- **Duru uygulama simgesi:** suya süzülen iki yaprak, saydam su ve cam rozette "DNS" (uyarlanabilir + tek renkli simge dahil).
- **Duru ses paketi:** yumuşak, kısa, sıcak tınılı 11 olay sesi; Otomatik pakette Duru stiliyle eşleşir, ayrıca kendi paketi olarak seçilebilir.
- **Duru animasyonları:** 10 olay için yaprak süzülmesi ve su halkaları (dokunma, anahtar, bağlanma, kesilme, hata, tamamlanma, panel, geri, seçim, yenileme).
- 12 dilde stil ve simge açıklamaları.

**Bağlantı (aynı sürüm):**
- **Uyanık kalma kilidi:** Tünel açıkken (bağlanıyor, bağlı, yeniden denerken) CPU uyanık tutulur; ekran kapalıyken bağlantı donup sessizce düşmesin diye. Kullanıcı kestiğinde, duraklattığında ya da hata verince bırakılır. Pil tüketimi bu kilidin bedelidir; pil ayarları sayfasındaki muafiyet durumu hâlâ geçerli.
- **Ağ dönünce yeniden bağlanma:** Yeniden denemeler tükendikten sonra bile, kullanıcı bağlantıyı kesmediyse ağ geri geldiğinde bağlantı yeniden kurulur. Kullanıcı kestiyse hiçbir şey kendiliğinden açılmaz.
- **DNS sızıntı kontrolü:** Sorun gidericide, tünel açıkken sistemin DNS sunucusu bizim sanal adresimiz değilse uyarı verir. Uygulamalar kendi DNS'lerini (ör. tarayıcının DoH ayarı) kullanıyorsa bu kontrol görmez; bunu da not olarak belirtiyorum.

- **Ağa göre DPI öğrenmesi (kalıcı):** Hangi DPI yönteminin hangi ağda çalıştığı artık uygulama kapansa da hatırlanır. Anahtar: ağ türü ve mobilde operatör kodu (MCC+MNC); Wi-Fi'de SSID kullanılmaz (konum izni gerekir), yalnızca "Wi-Fi" olarak tutulur. Kayıt yalnızca telefonda durur. Bir yöntem artık çalışmazsa sıradakine geçilir ve yeni çalışan kayda yazılır.

- **"Site neden açılmıyor?" (☰ > Sorun giderici alanında ayrı satır):** Bir alan adı yazılır; uygulama sırayla bakar: bağlantı açık mı, kullanıcı engel listesinde mi, reklam/izleme listesinde mi, şifreli DNS sağlayıcısı mı, izin verilmiş mi. Engelliyorsa "İzin ver" düğmesi çıkar. Engellemiyorsa sorunun büyük olasılıkla sitede ya da tarayıcıda olduğunu söyler.

- **YouTube reklam sunucuları (yalnızca kişisel sürüm, kısmi):** Ayarlarda isteğe bağlı anahtar. Bilinen reklam ve reklam ölçüm alan adlarını DNS'te engeller. İçerik sunucuları (googlevideo.com, youtubei, youtube.com) asla engellenmez; oynatıcı içi reklamları kaldırmaz, bu yüzden kısmidir. Play sürümünde anahtar görünmez ve etkin olmaz. Kişisel APK: `./gradlew assembleRelease -Ppersonal=true`.

**Düzeltme (aynı sürüm):** Duru Aqua çakması gibi duruyordu; bileşenler baştan düz çizildi (cam küre yerine düz daire + sakin su düzeyi, hap yerine yumuşak köşeli düğmeler, gölgesiz kartlar, düz simge kareleri, düz üst çubuk), yeni "süzülme" sayfa geçişi ve ince halka + yaprak efekti eklendi.

**Test:** tüm JVM testleri, 0 hata (stil/paket/tını sayıları 8/14/16'ya güncellendi).

## 1.25.0 (versionCode 42)

**Değişti**
- **Ses varsayılanı (Otomatik):** dokunma ve bağlanma sesleri artık telefon **titreşim** modundayken de çalar (oyun ve klavye sesleri gibi, medya kanalından). Yalnızca **tam sessiz** modda susar. Önceden Otomatik modda telefon titreşimdeyken de susuyordu; "bazı telefonlarda ses gelmiyor" geri bildiriminin başlıca nedeni buydu (çok kullanıcı telefonu sürekli titreşimde tutuyor). Sistem/medya ses seviyesine ve "sessiz başarı" / yedek yol mantığına dokunulmadı. İsteyen eski davranışa Ses çıkışı: Sistem ile dönebilir, tam sessizde de duymak isteyen Medya seçebilir.

**İnceleme**
- Şifreli bağlantı çekirdeği (`SecureForwarder`: DoT / DoH / ODoH) kaynak kodundan yeniden gözden geçirildi: HTTP ayrıştırma (chunked + content-length çakışmasında chunked önceliği), sınır denetimleri, şerit eşzamanlılığı ve TLS 1.2/1.3 sabitlemesi. Yeni bir açık ya da hata bulunmadı; değişiklik yapılmadı.

**Test:** tüm JVM testleri, 0 hata (ses kanalı seçimine titreşim + medya durumları eklendi).

## 1.23.0 (versionCode 40)

**Yeni**
- **Oblivious DoH (ODoH, RFC 9230)**, isteğe bağlı, varsayılan **kapalı** (☰ > DNS ayarları > Oblivious DoH: Kapalı / Yedekli / Sıkı). Sorgu hedef sunucunun anahtarıyla şifrelenip bir **röle** üzerinden gider: röle IP'nizi görür ama soruyu göremez, DNS sunucusu soruyu görür ama sizi göremez.
  - *Yedekli:* önce ODoH; kurulamazsa normal şifreli yöntemler (gizlilik düştü uyarısıyla) ve ODoH'a dönmek için arka planda yeniden deneme. *Sıkı:* yalnızca ODoH; kurulamazsa bağlanmaz, hiçbir yönteme düşmez.
  - ODoH seçili DNS sunucusundan bağımsızdır; uygulamanın kendi röle + hedef çiftlerini kullanır (2 röle × 3 hedef, her çiftte iki ayrı işletmeci; aynı işletmeci ya da alan adı eşleşmez, kurucu bunu reddeder).
- **Kendini onaran, çok katmanlı motor:** (1) yol seçimi: gecikme + hata puanı, devre kesici, üstel geri çekilme (2 sn → 2 dk, ±%20 sapma), yarı açık tek deneme, bayat yolların yoklanması; (2) anahtar yönetimi: tek uçuşlu alım, 6 saat taze, alınamazsa 7 güne kadar bayat anahtarla devam, 401'de hız sınırlı yenileme (anahtar dönmesi arıza sayılmaz); (3) adresler: son çalışan → ipucu → şifreli (DoT) ad çözümü, düz DNS hiç kullanılmaz; (4) bağlantı: aynı sorguda ölü röleden sonra başka röleye geçiş, sahte/bozuk cevap yolu uzun süre keser; (5) ağ değişince yol bilgisi sıfırlanır.
- Gizlilik ayrıntıları: her sorgu için taze HPKE anahtarı, DNS kimliği 0, düz metin 128 baytın katına doldurulur, cevaplar kimlik doğrulamalı; hedefin yapılandırması doğrudan (röleden değil) alınır, bu sırada hedef IP'nizi görür ama soru görmez.
- Kendi X25519 + HPKE (RFC 9180) gerçeklemesi (dış kütüphane yok); RFC 7748 / RFC 9180 vektörleriyle ve JDK ile 300 rastgele çapraz sınamayla doğrulandı.
- Araç: `tools/odoh_check.py` canlı röle/hedef denetimi.

**Dürüst sınırlar**
- ODoH yalnızca **DNS sağlayıcısından IP'nizi** saklar. Operatörünüz, Wi-Fi sahibi ve bağlandığınız siteler IP'nizi yine görür; röle trafik zamanını ve hacmini görür. Gizlilik, rölenin ve hedefin **anlaşmamasına** dayanır.
- Gerçek röle/hedeflerle **canlı uyumluluk bu ortamda denenemedi** (ağ yok); şifreleme RFC vektörleriyle ve bağımsız bir sunucu benzetimiyle sınandı. Röle/hedef IP ipuçları Ekim 2026 tarihlidir. Cihazda denenmedi: VPN servisi entegrasyonu, bildirimler, ağ değişimi.

**Test:** 6153 kontrol, 0 hata (212 yeni: şifreleme, yapılandırma, ileti biçimi, yol tahtası, anahtar önbelleği, katalog, adres defteri, ayarlar, uçtan uca benzetim).

## 1.22.0 (versionCode 39)

**Yeni**
- **Liquid Glass stili:** yarı saydam mavi-indigo cam, parlak beyaz kenar ışığı, cam anahtar damlası. Kendi dokunma efekti, ses paketi (parlak, dalgalanan cam tınısı) ve uygulama simgesi (cam küre içinde kalkan ve güç simgesi).
- **Her stile 4 yeni animasyon:** panel açılması, geri, seçim, yenileme. Sekiz mevcut paket için ayrı çizimler; Liquid Glass'ın 10 animasyonunun hepsi kendine özel. Toplam 10 paket × 10 animasyon.
- **Her ses paketine 2 yeni ses:** seçim ve yenileme. Seçenek, sunucu veya tema seçince seçim sesi; ölçüm ve bağlantı testi başlayınca yenileme sesi çalar.

**Değişti**
- Uygulama **güvenlik / ağ aracı** olarak konumlandırıldı: mağaza metni ve kısa açıklamalar (12 dil) "zararlı, kimlik avı ve izleyici alan adlarına karşı koruma" diline çevrildi.
- Stil, simge ve ses paketi açıklamaları 12 dilde güncellendi.

**Test:** 5941 kontrol, 0 hata. Cihazda doğrulanmadı: görünüm, ses beğenisi, yeni simgenin başlatıcıdaki görünümü.

## 1.21.9
- Gömülü **Public Suffix List**: "aynı site" kararı gerçek eTLD+1'e bakar (co.uk, com.tr, github.io…); sıcak yolda bellek ayırmaz.
- **Filtre belleği** ayarı: Otomatik / Hafif / Tam. Az belleği olan telefonda en büyük liste atlanır, bellek yetmezse çökmeden devam edilir.
- "Yalnızca seçilenler"de seçili uygulama yoksa koruma **başlamaz** (Android boş listeyi "hepsi" sayar); hata gösterilir.
- Play beyan taslağına kontrol listesi eklendi.

## 1.21.8
- Filtre listeleri akışla okunur (tam dosya ayrıca belleğe alınmaz), bellek yetmezse yedek yol.
- Özel son ek listesi, SecureForwarder yarışı, TcpDns port sarması düzeltmeleri, ayar önbelleği.

## 1.21.5 – 1.21.7
- Dış incelemelerden doğrulanan düzeltmeler: içe aktarılan listenin korunan adları geçemesi, tema örnek küresi önbelleği, CNAME sayacının atomik olması, ağ geçidi adres elemesi, regresyon testleri.

## 1.10 – 1.21
- Kendi kullanıcı alanı TCP/UDP aktarıcısı (ağ geçidi), DPI atlatma ve Reklam+ düğmeleri, mobil ağ politikası, ses uyumluluğu (Rahatsız Etmeyin), yeni hareket motoru, ses efektleri, stile özgü efektler, profiller, sessiz saatler.

## 1.9.x
- Dört seviyeli koruma/engelleme, izin ve engel listesi, kendini onarma, kendi TCP katmanımız, bildirim sistemi, gecikme grafiği, kendi liste içe/dışa aktarma, Aurora stili, IPv4 + IPv6.

## 1.1 – 1.8
- Özel DNS sunucuları ve 32'lik katalog, uygulama başına kapsam, stiller ve sayfa geçişleri, arka plan fotoğrafı, uygulama simgeleri, sorun giderici, sunucu arama, ☰ menü ve Hakkında, kişiselleştirme penceresi.
