package app.dnshizli.platform

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import app.dnshizli.core.FilterRuntime
import app.dnshizli.core.FilteringForwarder
import app.dnshizli.core.Forwarder
import app.dnshizli.core.HopPlan
import app.dnshizli.core.Ip
import app.dnshizli.core.Journal
import app.dnshizli.core.LocalZones
import app.dnshizli.core.PqPsk
import app.dnshizli.core.JitterSender
import app.dnshizli.core.SelfTest
import app.dnshizli.core.Shaper
import app.dnshizli.core.StealthClient
import app.dnshizli.core.StealthSession
import app.dnshizli.core.WgChain
import app.dnshizli.core.WgConfig
import app.dnshizli.core.WgDnsForwarder
import app.dnshizli.core.WgPath
import app.dnshizli.core.WgTunnel
import app.dnshizli.core.YouTubeAds
import app.dnshizli.core.lightEffective
import app.dnshizli.ui.Strings
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Bize özel WireGuard istemcisi (saf Kotlin çekirdek: [WgTunnel]). Tüm (ya da AllowedIPs kadar) trafik kendi sunucuna şifreli gider;
 * sistemin DNS'i sahte yerel adrestir: sorgu önce reklam/izleyici süzgecinden geçer ([FilteringForwarder]), kalan sorgu TÜNELİN İÇİNDEN
 * yapılandırmadaki DNS'e gider ([WgDnsForwarder]). Uç nokta soketi korunur (tünele geri girmez). DNS kipi servisiyle aynı anda çalışmaz.
 *
 * Çoklu atlama ([WgChain]): ana yapılandırma ÇIKIŞ sunucusudur; giriş sunucusu yapılandırması varsa ve kip açıksa iç tünel (çıkış)
 * dış tünelin (giriş) içinden gider. "Gerektiğinde" kipinde ([HopPlan]) önce doğrudan bağlanılır, olmazsa zincire geçilir.
 * Ağ yolu ([tunnel], UDP/Stealth, [WgPath]) her zaman ağa paket gönderen tüneldir: zincirde giriş, doğrudan bağlantıda çıkış.
 * Yol yeniden kurulurken ([setupPath]) tün açık kalır; eski okuyucular nesil ([gen]) değişince çıkar.
 */
class WgVpnService : VpnService() {
    @Volatile private var stopping = false
    @Volatile private var tun: ParcelFileDescriptor? = null
    @Volatile private var socket: DatagramSocket? = null
    /** Ağa paket gönderen tünel (zincirde giriş, doğrudan bağlantıda çıkış). */
    @Volatile private var tunnel: WgTunnel? = null
    /** Zincirde iç (çıkış) tüneli; doğrudan bağlantıda null. Tün'den gelen trafik [entry] tüneline girer. */
    @Volatile private var inner: WgTunnel? = null
    @Volatile private var chain: WgChain? = null
    private val entry: WgTunnel? get() = inner ?: tunnel
    @Volatile private var dns: Forwarder? = null
    @Volatile private var endpoint: InetSocketAddress? = null          // ağ tünelinin doğrudan UDP uç noktası
    @Volatile private var stealthEndpoint: InetSocketAddress? = null
    /** Yol seçici (Smart kip); [stealthMode] o anki yoldur. */
    @Volatile private var picker: WgPath? = null
    @Volatile private var hop: HopPlan? = null
    @Volatile private var gen = 0
    private var tunReader: Thread? = null
    private var ticker: Thread? = null
    /** Stealth kipi: kurulu TLS/WebSocket oturumu ve gönderim kuyruğu (tünel kilidi ağ yazımında beklemesin). */
    @Volatile private var stealthSession: StealthSession? = null
    private val stealthOut = ArrayBlockingQueue<ByteArray>(256)
    @Volatile private var stealthMode = false
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private val tunOutLock = Any()
    private var tunOut: FileOutputStream? = null
    private var sinceMs = 0L
    @Volatile private var shownConnected: Boolean? = null
    /** Trafik gizleme: yüksek seviyede UDP gönderimlerine sırayı koruyan rastgele gecikme. */
    @Volatile private var jitter: JitterSender? = null

    // başlangıçta çözülen yapılandırmalar ve uç noktaları (yol değişiminde ad çözümü tünele takılmasın diye önceden)
    private var exitCfg: WgConfig? = null
    private var entryCfg: WgConfig? = null
    private val resolved = HashMap<String, InetSocketAddress?>()
    private var writeTunFn: ((ByteArray, Int, Int) -> Unit)? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { foreground(notification(false)); shutdown("kullanıcı kesti"); return START_NOT_STICKY }
        if (intent?.action == ACTION_MODE) {
            if (!running) { stopSelfSafe(); return START_NOT_STICKY }
            foreground(notification(tunnel?.connected == true))
            // onStartCommand ana iş parçacığında çalışır: soket yazımı (el sıkışma, SHP1 isteği) orada NetworkOnMainThreadException verir
            Thread({
                picker?.setMode(WgStore.mode(this), System.currentTimeMillis())?.let { usePath(it, "kip değişti") }
                applyShaping()
            }, "wg-mode").start()
            return START_NOT_STICKY
        }
        foreground(notification(false))
        if (running) return START_NOT_STICKY
        running = true; stopping = false
        Thread({ start() }, "wg-start").start()
        return START_NOT_STICKY
    }

    override fun onRevoke() { shutdown("izin geri alındı") }
    override fun onDestroy() { shutdown("servis kapandı"); super.onDestroy() }

    private fun parse(text: String?): WgConfig? = text?.let { (WgConfig.parse(it) as? WgConfig.Companion.Result.Ok)?.cfg }

    private fun key(host: String, port: Int) = "$host|$port"

    /** Bir yapılandırmanın iki yolunun adları tün kurulmadan çözülür. */
    private fun resolveAll(c: WgConfig) {
        if (c.hasUdpEndpoint) resolved[key(c.peer.endpointHost, c.peer.endpointPort)] = resolve(c.peer.endpointHost, c.peer.endpointPort)
        c.stealth?.let { st -> resolved[key(st.host, st.port)] = resolve(st.host, st.port) }
    }

    private fun start() {
        val cfg = parse(WgStore.load(this))
        if (cfg == null) { Journal.add("WireGuard: ${Strings.WG_NO_CONFIG}"); fail(Strings.WG_NO_CONFIG); return }
        if (prepare(this) != null) { fail(Strings.ERR_PERMISSION); return }
        val ent = parse(WgStore.loadEntry(this))
        val hopMode = if (ent != null) WgStore.hopMode(this) else HopPlan.Mode.OFF
        exitCfg = cfg; entryCfg = ent
        hop = HopPlan(hopMode, System.currentTimeMillis())
        // Uç nokta adları tünel kurulmadan çözülür (tam tünelde ad çözümü yoksa tünelin kendisine takılırdı).
        resolveAll(cfg)
        if (ent != null && hopMode != HopPlan.Mode.OFF) resolveAll(ent)
        if (stopping) return
        val settings = PrefsStore(this).loadSettings()
        FilterRuntime.setLight(settings.lightEffective())
        FilterRuntime.rebind = settings.rebindGuard
        FilterRuntime.setDohGuard(settings.dohGuard)
        FilterRuntime.update(settings.filterLevel, settings.filterAllow, YouTubeAds.blockFor(settings, BuildFlags.PERSONAL))
        // Sunucunun DNS'i özel ağdaysa (ör. 10.2.0.1) ters bölgeler orada anlamlı olabilir: yerel cevap kapatılır.
        FilterRuntime.localZones = !LocalZones.lanUpstream(cfg.dns.map { Ip.format(it) })
        // Zincir olasıysa tün MTU'su iki katman başlığa yer bırakır (sonradan zincire geçişte büyük paket parçalanmasın).
        // IPv6 1280'in altında çalışmaz: giriş MTU'su iki katman başlığına yetmiyorsa zincir kurulmaz (taşan paket parçalanırdı).
        val chainMtu = if (ent != null) WgChain.innerMtu(ent.mtu, true) else 0
        if (ent != null && hopMode != HopPlan.Mode.OFF && chainMtu < 1280) {
            Journal.add("Çoklu atlama kapatıldı: giriş sunucusu MTU'su (${ent.mtu}) iç tünele yetmiyor (en az ${1280 + 80})")
            entryCfg = null; hop = HopPlan(HopPlan.Mode.OFF, System.currentTimeMillis())
        }
        val mtu = if (entryCfg != null && hopMode != HopPlan.Mode.OFF) minOf(cfg.mtu, chainMtu) else cfg.mtu
        val fd = try { establish(cfg, mtu) } catch (e: Exception) { Journal.add("WireGuard tün kurulamadı: ${Journal.where(e)}"); null }
        if (fd == null) { fail(Strings.ERR_UNKNOWN); return }
        tun = fd
        val out = FileOutputStream(fd.fileDescriptor)
        tunOut = out
        writeTunFn = { b, off, len -> synchronized(tunOutLock) { try { out.write(b, off, len) } catch (_: Exception) {} } }
        sinceMs = System.currentTimeMillis()
        if (!setupPath(hop!!.chained)) { fail(Strings.WG_ENDPOINT_FAIL); return }
        watchNetwork()
        tunReader = Thread({ readTun(fd) }, "wg-tun").also { it.start() }
        ticker = Thread({ tickLoop() }, "wg-tick").also { it.start() }
    }

    /**
     * Yolu kurar: [chained] ise ağ tüneli giriş, iç tünel çıkış; değilse ağ tüneli çıkış. Önceki yolun soketleri, oturumu ve tünelleri
     * kapatılır (anahtarlar silinir), okuyucuları yeni nesil görünce çıkar. Ağ tünelinin uç noktası yoksa false.
     */
    @Synchronized private fun setupPath(chained: Boolean): Boolean {
        val my = ++gen
        val writeTun = writeTunFn ?: return false
        closePath()
        val exit = exitCfg ?: return false
        val ent = entryCfg
        val cfg = if (chained && ent != null) ent else exit             // ağ tüneli
        val st = cfg.stealth
        val pk = WgPath(WgStore.mode(this), cfg.hasUdpEndpoint, st != null, System.currentTimeMillis())
        endpoint = if (cfg.hasUdpEndpoint) resolved[key(cfg.peer.endpointHost, cfg.peer.endpointPort)] else null
        stealthEndpoint = st?.let { resolved[key(it.host, it.port)] }
        if (pk.path == WgPath.Path.UDP && endpoint == null && stealthEndpoint != null) pk.setMode(WgPath.Mode.STEALTH, System.currentTimeMillis())
        if (pk.path == WgPath.Path.STEALTH && stealthEndpoint == null && endpoint != null) pk.setMode(WgPath.Mode.UDP, System.currentTimeMillis())
        if ((if (pk.path == WgPath.Path.UDP) endpoint else stealthEndpoint) == null) return false
        picker = pk
        stealthMode = pk.path == WgPath.Path.STEALTH
        // Zincir: iç tünelin paketleri sarılıp ağ tüneline verilir; ağ tünelinden çözülen paket iç tünele gider
        val ch: WgChain? = if (chained && ent != null) {
            val ep = (if (exit.hasUdpEndpoint) resolved[key(exit.peer.endpointHost, exit.peer.endpointPort)] else null)
                ?: run { Journal.add("Çoklu atlama: çıkış sunucusunun UDP uç noktası yok/çözülemedi"); return false }
            val src = WgChain.outerSource(ent, ep.address.address) ?: run { Journal.add("Çoklu atlama: giriş yapılandırmasında uygun adres ailesi yok"); return false }
            WgChain(src, ep.address.address, ep.port)
        } else null
        val outerWrite: (ByteArray, Int, Int) -> Unit = if (ch != null) { b, o, l ->
            val p = if (o == 0) b else b.copyOfRange(o, o + l)
            ch.unwrap(p, l)?.let { w -> inner?.fromNet(w, 0, w.size) }
        } else writeTun
        // Stealth: kuyruk doluysa paket düşer (UDP gibi; WireGuard telafi eder)
        val t = WgTunnel(cfg, sendUdp = { if (stealthMode) stealthOut.offer(it) else sendJittered(it) }, writeTun = outerWrite, log = { Journal.add(it) })
        val inn: WgTunnel? = if (ch != null) WgTunnel(exit, sendUdp = { m -> val w = ch.wrap(m); tunnel?.fromTun(w, w.size) }, writeTun = writeTun, log = { Journal.add("çıkış: $it") }) else null
        tunnel = t; inner = inn; chain = ch
        applyShaping()
        // Kuantum sonrası PSK: son başarılı değişimin değeri (sunucu da onu kullanıyor) ile başlanır; UDP yolundaysak hemen yenisi alınır.
        if (st?.pq == true) {
            val saved = WgStore.loadPq(this, cfg.publicKey)
            saved?.let { t.setPsk(it, fromPq = true, handshakeNow = false) }
            // Katı kip (PqPin): doğrulanmış PQ PSK'si yokken klasik PSK ile el sıkışılmaz; Stealth yolunda değişim zaten önce yapılır.
            if (st.pqPin != null && saved == null) t.hold = true
            // UDP yolunda yeni PSK ayrı iş parçacığında alınır: yol kilidi ağda (en çok ~15 sn) beklemesin
            if (!stealthMode) Thread({ if (my == gen && !stopping) pqOverSeparateConnection(cfg) }, "wg-pq").start()
        }
        if (inn != null && exit.stealth?.pq == true) {
            // Çoklu atlamada çıkış aktarıcısıyla doğrudan değişim yapılamaz (çıkış gerçek IP'yi görürdü): son doğrulanmış PSK kullanılır;
            // katı kipte hiç yoksa iç tünel bekletilir ve bildirimde söylenir (bir kez doğrudan bağlanınca alınır).
            val saved = WgStore.loadPq(this, exit.publicKey)
            if (saved != null) inn.setPsk(saved, fromPq = true, handshakeNow = false)
            else if (exit.stealth?.pqPin != null) { inn.hold = true; Journal.add("Çoklu atlama: çıkış sunucusu için doğrulanmış kuantum sonrası PSK yok; bir kez doğrudan bağlan") }
        }
        val e = inn ?: t
        dns = FilteringForwarder(WgDnsForwarder(e, writeTun, SelfTest.FAKE4, SelfTest.FAKE6), writeTun).also { it.start() }
        if (endpoint != null && !openSocket() && !stealthMode) return false
        if (endpoint != null) Thread({ readNet(my) }, "wg-net").start()           // UDP yolu hazır kalır (Smart geçişi)
        if (st != null) {
            Thread({ readStealth(my) }, "wg-stealth").start()
            Thread({ writeStealth(my) }, "wg-stealth-w").start()
        }
        Thread({ coverLoop(my) }, "wg-cover").start()
        Journal.add("WireGuard yolu: " + pathText(cfg) + " (kip: ${pk.mode.id})" + if (ch != null) " · çoklu atlama → ${exit.peer.endpointHost}" else "")
        shownConnected = null
        t.tick(); inn?.reconnected()
        return true
    }

    /** Trafik gizleme seviyesini ağ tüneline (ve Stealth'te aktarıcıya) uygular; kip değişince de çağrılır. */
    private fun applyShaping() {
        val lvl = WgStore.shapeLevel(this)
        val t = tunnel ?: return
        t.shaper = if (lvl == Shaper.Level.OFF) null else Shaper(lvl)
        jitter?.close()
        jitter = if (lvl == Shaper.Level.HIGH) JitterSender({ send(it) }, { t.shaper?.jitterMs() ?: 0 }) else null
        stealthSession?.let { s -> try { s.requestShaping(lvl.code) } catch (_: Exception) {} }
        shownConnected = null
    }

    private fun sendJittered(b: ByteArray) { val j = jitter; if (j != null) j.offer(b) else send(b) }

    /** Örtü paketleri: seviyenin hızında, gerçek trafik yokken (yüksekte sabit taban akış). */
    private fun coverLoop(my: Int) {
        while (!stopping && my == gen) {
            val sh = tunnel?.shaper
            val d = sh?.nextCoverDelayMs() ?: 1000L
            try { Thread.sleep(if (d > 0) d else 1000L) } catch (_: InterruptedException) { break }
            val t = tunnel ?: continue
            val s = t.shaper ?: continue
            if (my == gen && t.connected && s.coverWanted(System.currentTimeMillis(), t.lastRealSentMs)) t.sendCover()
        }
    }

    /** Yolun ağ kaynaklarını ve tünellerini kapatır (tün açık kalır). */
    private fun closePath() {
        jitter?.close(); jitter = null
        try { dns?.close() } catch (_: Exception) {}
        dns = null
        inner?.close(); inner = null; chain = null
        tunnel?.close(); tunnel = null                        // oturum anahtarları silinir
        stealthSession?.close(); stealthSession = null; stealthOut.clear()
        try { socket?.close() } catch (_: Exception) {}
        socket = null
    }

    private fun establish(cfg: WgConfig, mtu: Int): ParcelFileDescriptor? {
        val configure = PendingIntent.getActivity(this, 0, Notifier.appIntent(this), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = Builder().setSession(Strings.WG_TITLE).setMtu(mtu).setBlocking(true).setConfigureIntent(configure)
        var v6 = false
        for (a in cfg.addresses) { b.addAddress(InetAddress.getByAddress(a.ip), a.prefix); if (a.ip.size == 16) v6 = true }
        for (r in cfg.peer.allowedIps) b.addRoute(InetAddress.getByAddress(r.ip), r.prefix)
        b.addDnsServer(SelfTest.FAKE_DNS).addRoute(SelfTest.FAKE_DNS, 32)
        if (v6) b.addDnsServer(SelfTest.FAKE_DNS6).addRoute(SelfTest.FAKE_DNS6, 128)
        // Yapılandırmada bir aile yoksa Android o ailenin trafiğini engeller (allowFamily çağrılmaz): IPv6 sızıntısı olmaz.
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)
        applyScope(b)
        return b.establish()
    }

    /** Uygulama kapsamı (dışlanan / yalnız seçilen uygulamalar) DNS kipindeki gibi WireGuard'da da uygulanır. */
    private fun applyScope(b: Builder) {
        val settings = PrefsStore(this).loadSettings()
        val pm = packageManager
        val plan = app.dnshizli.core.AppScopes.plan(settings, packageName) { p -> try { pm.getApplicationInfo(p, 0); true } catch (_: Exception) { false } }
        if (plan.kind != app.dnshizli.core.ScopePlan.Kind.ALLOW && plan.kind != app.dnshizli.core.ScopePlan.Kind.DENY) return
        var added = 0
        for (p in plan.packages) try {
            if (plan.kind == app.dnshizli.core.ScopePlan.Kind.ALLOW) b.addAllowedApplication(p) else b.addDisallowedApplication(p)
            added++
        } catch (_: Exception) {}
        Journal.add(if (plan.kind == app.dnshizli.core.ScopePlan.Kind.ALLOW) "WireGuard: yalnızca $added uygulama tünelde" else "WireGuard: $added uygulama tünel dışında")
    }

    private fun resolve(host: String, port: Int): InetSocketAddress? {
        Ip.parse(host)?.let { return InetSocketAddress(InetAddress.getByAddress(it), port) }
        repeat(3) { n ->
            try {
                val all = InetAddress.getAllByName(host)
                val pick = all.firstOrNull { it.address.size == 4 } ?: all.firstOrNull()
                if (pick != null) return InetSocketAddress(pick, port)
            } catch (_: Exception) {}
            if (n < 2) try { Thread.sleep(1000) } catch (_: InterruptedException) { return null }
        }
        return null
    }

    /** Adı alttaki (VPN olmayan) ağın çözümleyicisiyle çözer; tün kurulduktan sonra sistem çözümleyicisi tünelden geçerdi. */
    private fun resolveOutside(host: String, port: Int): InetSocketAddress? {
        Ip.parse(host)?.let { return InetSocketAddress(InetAddress.getByAddress(it), port) }
        val cm = getSystemService(ConnectivityManager::class.java) ?: return null
        @Suppress("DEPRECATION")
        for (n in cm.allNetworks) {
            val c = cm.getNetworkCapabilities(n) ?: continue
            if (!c.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_VPN) || !c.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
            try {
                val all = n.getAllByName(host)
                val pick = all.firstOrNull { it.address.size == 4 } ?: all.firstOrNull() ?: continue
                return InetSocketAddress(pick, port)
            } catch (_: Exception) {}
        }
        return null
    }

    /** Korunan, uç noktaya bağlı UDP soketi; ağ değişince yenisi açılır (eski soket eski ağa bağlı kalırdı). */
    @Synchronized private fun openSocket(): Boolean {
        val ep = endpoint ?: return false
        val old = socket
        return try {
            val s = DatagramSocket()
            if (!protect(s)) { s.close(); Journal.add("WireGuard: soket korunamadı"); return false }
            s.soTimeout = 1000
            s.connect(ep)
            socket = s
            old?.close()
            true
        } catch (e: Exception) { Journal.add("WireGuard soketi açılamadı: ${Journal.where(e)}"); false }
    }

    private fun send(b: ByteArray) {
        val s = socket ?: return
        try { s.send(DatagramPacket(b, b.size)) } catch (_: Exception) { /* ağ yok: el sıkışma zamanlayıcısı yeniden dener */ }
    }

    private fun readTun(fd: ParcelFileDescriptor) {
        val inp = FileInputStream(fd.fileDescriptor)
        val buf = ByteArray(65535)
        while (!stopping) {
            val n = try { inp.read(buf) } catch (_: Exception) { if (stopping) break else -1 }
            if (n < 0) break
            if (n == 0) continue
            val t = entry ?: continue                                        // yol yeniden kuruluyor: paket düşer
            if (isFakeDns(buf, n)) dns?.onPacket(buf, n) else t.fromTun(buf, n)
        }
    }

    private fun tickLoop() {
        while (!stopping) {
            try { Thread.sleep(1000) } catch (_: InterruptedException) { break }
            val t = tunnel ?: continue
            t.tick()
            inner?.tick()
            // katı kip: UDP yolunda bekleyen tünel için PQ değişimi 30 sn'de bir yeniden denenir
            if (t.hold && !stealthMode && System.currentTimeMillis() - lastPqTry > 30_000L) {
                lastPqTry = System.currentTimeMillis(); val c = t.cfg; val g = gen
                Thread({ if (g == gen && !stopping) pqOverSeparateConnection(c) }, "wg-pq").start()
            }
            picker?.onTick(System.currentTimeMillis(), t.handshakePendingMs())?.let { usePath(it, "el sıkışma cevapsız") }
            // "Gerektiğinde" çoklu atlama: doğrudan bağlantı kurulamıyorsa giriş sunucusu üzerinden zincire geç
            if (inner == null && hop?.onTick(System.currentTimeMillis(), t.handshakePendingMs()) == true) {
                Journal.add("Çoklu atlama: doğrudan bağlantı kurulamadı, giriş sunucusu üzerinden")
                if (!setupPath(true)) setupPath(false)
            }
            refreshNotification()
        }
    }

    /** Yolu değiştirir: gönderim yeni yola yönelir, eski Stealth oturumu kapanır, tünel hemen yeniden el sıkışır/canlı tutar. */
    @Synchronized private fun usePath(p: WgPath.Path, why: String) {
        val toStealth = p == WgPath.Path.STEALTH
        if (toStealth == stealthMode) return
        Journal.add("WireGuard yolu: ${if (toStealth) "Stealth" else "UDP"} ($why)")
        stealthMode = toStealth
        stealthOut.clear()
        if (!toStealth) stealthSession?.close()
        if (!toStealth || stealthSession != null) tunnel?.reconnected()      // Stealth'te oturum kurulunca okuyucu çağırır
        shownConnected = null
    }

    private fun pathText(cfg: WgConfig): String =
        if (stealthMode) "${cfg.stealth} (Stealth)" else "${cfg.peer.endpointHost}:${cfg.peer.endpointPort} (UDP)"

    /**
     * Stealth okuyucu: bağlan (korunan TCP → sabitlenmiş TLS → WebSocket), çerçeveleri tünele ver; kopunca artan beklemeyle yeniden bağlan.
     * Ağ değişince mevcut oturum kapatılır; döngü yenisini kurar. Yol yeniden kurulunca ([gen] değişir) çıkar.
     */
    private fun readStealth(my: Int) {
        val st = tunnel?.cfg?.stealth ?: return
        val buf = ByteArray(65535)
        var backoff = 1000L
        var failures = 0
        while (!stopping && my == gen) {
            if (!stealthMode) { try { Thread.sleep(250) } catch (_: InterruptedException) { break }; continue }   // UDP yolundayken bekler
            val ep = stealthEndpoint ?: break
            val sess = try {
                StealthClient.open(st, ep, connect = { a -> protectedTcp(a) })
            } catch (e: Exception) {
                Journal.add("Stealth bağlanamadı: ${Journal.where(e)}")
                try { Thread.sleep(backoff) } catch (_: InterruptedException) { break }
                backoff = minOf(backoff * 2, 30_000L)
                // Ad başka adrese taşınmış olabilir: ama tün kurulduktan sonra sistem çözümleyicisi tünelden (kopuk) gider; yalnız alttaki
                // (VPN olmayan) ağdan ve her 4 başarısızlıkta bir çözülür, olmazsa eski adres kalır.
                if (++failures % 4 == 0) resolveOutside(st.host, st.port)?.let { stealthEndpoint = it }
                continue
            }
            if (my != gen) { sess.close(); break }
            backoff = 1000L
            // Katı kip (PqPin): kimliği doğrulanmış değişim olmadan bu aktarıcı üzerinden HİÇBİR WireGuard paketi gitmez; hata çerçeveleri
            // kimlik doğrulamasızdır (sahte aktarıcı üretebilir), bu yüzden hiçbir hata kodu "devam" sayılmaz ve PQ'suza düşülmez.
            val strict = st.pqPin != null
            if (st.pq && (strict || !skipPqOnce)) {
                val ok = pqExchange(sess, tunnel?.cfg ?: break)
                if (!ok && strict) {
                    sess.close(); try { Thread.sleep(backoff) } catch (_: InterruptedException) { break }
                    backoff = minOf(backoff * 2, 30_000L); continue
                }
                if (!ok) { sess.close(); skipPqOnce = true; continue }            // yalnız PQ1 (kimliksiz): akış belirsiz, bir kez PQ'suz
            }
            skipPqOnce = false
            stealthOut.clear()                                                      // eski oturumun bayat paketleri gitmesin
            WgStore.shapeLevel(this).let { l -> if (l != Shaper.Level.OFF) try { sess.requestShaping(l.code) } catch (_: Exception) {} }
            stealthSession = sess
            Journal.add("Stealth bağlandı: $st")
            tunnel?.reconnected()
            try {
                while (!stopping && stealthMode && my == gen) {
                    val n = sess.receive(buf)
                    if (n < 0) break
                    tunnel?.fromNet(buf, 0, n)
                }
            } catch (_: Exception) {}
            if (stealthSession === sess) stealthSession = null
            sess.close()
            if (!stopping && stealthMode && my == gen) Journal.add("Stealth bağlantısı koptu, yeniden kuruluyor")
        }
    }

    @Volatile private var skipPqOnce = false
    @Volatile private var identityWarned = false
    @Volatile private var lastPqTry = 0L
    /** Son değişimin hata kodu (-1 başarı). Kimlik hatasında oturum hiç kullanılmaz ve PQ'suz da denenmez. */
    @Volatile private var lastPqCode = -1

    /**
     * Açık Stealth oturumunda ML-KEM değişimi. Başarılıysa tünelin PSK'si yenilenir ve saklanır. Aktarıcı hata koduyla reddettiyse
     * (eski sürüm değil, ör. saat farkı) oturum kullanılabilir kalır: true. Cevap yoksa/bozuksa false (oturum kapatılmalı).
     */
    private fun pqExchange(sess: StealthSession, cfg: WgConfig): Boolean {
        val pin = cfg.stealth?.pqPin
        val r = if (pin != null) PqPsk.exchange2(sess, cfg.peer.presharedKey, cfg.publicKey, pin, System.currentTimeMillis() / 1000)
            else PqPsk.exchange(sess, cfg.peer.presharedKey, cfg.publicKey, System.currentTimeMillis() / 1000)
        lastPqCode = (r as? PqPsk.Result.Fail)?.code ?: -1
        return when (r) {
            is PqPsk.Result.Ok -> {
                tunnel?.takeIf { it.cfg === cfg }?.let { t ->
                    t.setPsk(r.psk, fromPq = true, handshakeNow = false)   // yol bu arada değiştiyse başka tünele uygulanmaz
                    if (t.hold) { t.hold = false; t.reconnected() }       // katı kipte bekleyen tünel artık el sıkışabilir
                }
                WgStore.savePq(this, cfg.publicKey, r.psk)
                Journal.add("Kuantum sonrası PSK yenilendi (ML-KEM-768)")
                shownConnected = null
                true
            }
            is PqPsk.Result.Fail -> {
                if (r.code == PqPsk.FAIL_IDENTITY) {
                    Journal.add("UYARI: aktarıcının kuantum sonrası kimliği doğrulanamadı (PqPin uyuşmuyor) — bu bağlantı kullanılmadı")
                    if (!identityWarned) { identityWarned = true; Notifier.securityAlert(this, Strings.WG_PQ_IDENTITY_FAIL) }
                    return false
                }
                Journal.add("Kuantum sonrası PSK alınamadı (kod ${r.code}); önceki PSK ile devam")
                if (cfg.stealth?.pqPin != null) return false              // katı kip: kimliksiz hata çerçevesi "devam" sayılmaz
                r.code != 0
            }
        }
    }

    /** UDP yolundayken PSK değişimi için kısa ömürlü Stealth bağlantısı (aktarıcıya ulaşılamazsa saklı PSK ile devam). */
    private fun pqOverSeparateConnection(cfg: WgConfig) {
        val st = cfg.stealth ?: return
        val ep = stealthEndpoint ?: return
        try {
            StealthClient.open(st, ep, connect = { a -> protectedTcp(a) }).use { pqExchange(it, cfg) }
        } catch (e: Exception) { Journal.add("Kuantum sonrası PSK için aktarıcıya ulaşılamadı: ${Journal.where(e)}") }
    }

    private fun writeStealth(my: Int) {
        while (!stopping && my == gen) {
            val p = try { stealthOut.poll(1, TimeUnit.SECONDS) } catch (_: InterruptedException) { break } ?: continue
            val s = stealthSession ?: continue                                      // bağlantı yok: WireGuard zamanlayıcısı yeniden dener
            val j = tunnel?.shaper?.jitterMs() ?: 0
            if (j > 0) try { Thread.sleep(j.toLong()) } catch (_: InterruptedException) { break }       // sıra korunur
            try { s.send(p) } catch (_: Exception) { s.close() }                    // okuyucu kopmayı görür ve yeniden bağlanır
        }
    }

    private fun protectedTcp(a: InetSocketAddress): Socket {
        val s = Socket()
        if (!protect(s)) { s.close(); throw java.io.IOException("soket korunamadı") }
        s.connect(a, 10_000)
        return s
    }

    private fun readNet(my: Int) {
        val buf = ByteArray(65535)
        while (!stopping && my == gen) {
            val s = socket ?: run { try { Thread.sleep(1000) } catch (_: InterruptedException) { return }; if (!stopping && my == gen) openSocket(); null } ?: continue
            try {
                val p = DatagramPacket(buf, buf.size)
                s.receive(p)
                if (my == gen) tunnel?.fromNet(buf, 0, p.length)
            } catch (_: SocketTimeoutException) {
            } catch (_: Exception) {
                if (stopping || my != gen) break
                if (s === socket) { try { Thread.sleep(1000) } catch (_: InterruptedException) { break }; openSocket() }
            }
        }
    }

    private fun isFakeDns(p: ByteArray, n: Int): Boolean = when ((p[0].toInt() ushr 4) and 0xF) {
        4 -> n >= 20 && app.dnshizli.core.Wg.eq(p, 16, SelfTest.FAKE4, 0, 4)
        6 -> n >= 40 && app.dnshizli.core.Wg.eq(p, 24, SelfTest.FAKE6, 0, 16)
        else -> false
    }

    private fun watchNetwork() {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        val cb = object : ConnectivityManager.NetworkCallback() {
            private var first = true
            override fun onAvailable(network: Network) {
                if (first) { first = false; return }               // kayıt anında gelen ilk bildirim mevcut ağdır
                if (stopping) return
                Journal.add("WireGuard: ağ değişti, bağlantı yenileniyor")
                // "Gerektiğinde" çoklu atlama: yeni ağda doğrudan bağlantı yeniden denenir
                if (hop?.onNetworkChanged(System.currentTimeMillis()) == true) { setupPath(false); return }
                if (endpoint != null) openSocket()
                stealthSession?.close()
                val np = picker?.onNetworkChanged(System.currentTimeMillis())
                if (np != null) usePath(np, "ağ değişti") else if (!stealthMode) tunnel?.reconnected()
                dns?.resetNetwork()
            }
        }
        try { cm.registerDefaultNetworkCallback(cb); netCallback = cb } catch (_: Exception) {}
    }

    private fun refreshNotification() {
        val c = entry?.connected == true
        if (shownConnected == c) return
        shownConnected = c
        foreground(notification(c))
    }

    private fun notification(connected: Boolean): Notification {
        val stop = PendingIntent.getService(this, 41, stopIntent(this), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val s = PrefsStore(this).loadSettings()
        val text = (if (connected) Strings.WG_CONNECTED else Strings.WG_CONNECTING) + (if (stealthMode) " · Stealth" else "") +
            (if (connected && tunnel?.pskFromPq == true && (inner?.pskFromPq ?: true)) " · PQ" else "") +
            (if (tunnel?.hold == true || inner?.hold == true) " · " + Strings.WG_PQ_WAIT else "") + (if (inner != null) " · " + Strings.WG_HOP_SHORT else "") + (if (tunnel?.shaper != null) " · " + Strings.WG_SHAPE_SHORT else "")
        return Notifier.wireGuard(this, s, text, connected, sinceMs, stop)
    }

    private fun foreground(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(Notifier.NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
            else startForeground(Notifier.NOTIF_ID, n)
        } catch (e: Exception) { Journal.add("WireGuard önplan bildirimi açılamadı: ${Journal.where(e)}") }
    }

    private fun fail(why: String) {
        Journal.add("WireGuard başlatılamadı: $why")
        shutdown(why)
    }

    @Synchronized private fun shutdown(why: String) {
        if (stopping && tun == null && socket == null) { running = false; stopSelfSafe(); return }
        stopping = true
        gen++
        netCallback?.let { cb -> try { getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(cb) } catch (_: Exception) {} }
        netCallback = null
        closePath()
        ticker?.interrupt()
        try { tun?.close() } catch (_: Exception) {}
        tun = null; tunOut = null
        running = false
        Journal.add("WireGuard durdu: $why")
        stopSelfSafe()
    }

    private fun stopSelfSafe() {
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    companion object {
        const val ACTION_START = "app.dnshizli.WG_START"
        const val ACTION_STOP = "app.dnshizli.WG_STOP"
        const val ACTION_MODE = "app.dnshizli.WG_MODE"
        @Volatile var running = false; private set

        fun startIntent(ctx: Context): Intent = Intent(ctx, WgVpnService::class.java).setAction(ACTION_START)
        fun stopIntent(ctx: Context): Intent = Intent(ctx, WgVpnService::class.java).setAction(ACTION_STOP)
        fun modeIntent(ctx: Context): Intent = Intent(ctx, WgVpnService::class.java).setAction(ACTION_MODE)
    }
}
