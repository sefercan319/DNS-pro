package app.dnshizli.core

import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Sunucu küresinin vektör haritası: Natural Earth 1:10m ülke çokgenleri ([GlobeVec], tools/kure/kara.py; kamu malı).
 *  - Yaylar: ülkelerin paylaştığı kenarlar; köşeler dünya birim vektörü (x = cosφ·cosλ, y = cosφ·sinλ, z = sinφ) ve önem düzeyi
 *    (0..7, [GlobeVec.LEVELS]): çizerken ekranın gerektirdiğinden ince ayrıntı atlanır, yakınlaştıkça tüm ayrıntı gelir.
 *  - Yay türü: [BORDER] iki ülkenin ortak sınırı, [COAST] kıyı, [SEAM] 180. boylam / kutup kesimi (çizilmez).
 *  - Ülkeler: boyama grubu (komşular farklı ton, 0..3) ve halkalar (yay dizisi; eksi = ~yay, ters yön).
 *  - Kaba kara maskesi (0,25°): yarım ton noktalarının açık denizde olanları erken elenir.
 * Veri ilk kullanımda açılır; [warm] arka planda hazırlar.
 */
object GlobeLand {
    const val COAST = 0
    const val BORDER = 1
    const val SEAM = 2

    class VecMap(
        /** Köşelerin dünya vektörleri (x, y, z ardışık) ve önem düzeyleri. */
        val xyz: FloatArray, val level: ByteArray,
        /** Yay k: köşeler [arcStart][k] .. [arcStart][k+1]-1; türü [kind][k]; kapsayan başlık: merkez ([capX], [capY], [capZ]) ve yarıçap sinüsü/kosinüsü. */
        val arcStart: IntArray, val kind: ByteArray,
        val capX: FloatArray, val capY: FloatArray, val capZ: FloatArray, val capCos: FloatArray, val capSin: FloatArray,
        /** Ülke c: grup [group][c], halkalar [ringStart][c] .. [ringStart][c+1]-1; halka q: yay referansları [refStart][q] .. [refStart][q+1]-1. */
        val group: IntArray, val ringStart: IntArray, val refStart: IntArray, val refs: IntArray,
        val names: Array<String>,
        private val mask: ByteArray,
    ) {
        val arcCount get() = arcStart.size - 1
        val countryCount get() = group.size
        val vertexCount get() = level.size

        /** (enlem, boylam; radyan) kaba maskede kara (ya da kıyıya bir hücre yakın) mı? */
        fun maybeLand(lat: Double, lon: Double): Boolean {
            val row = ((Math.PI / 2 - lat) / Math.PI * GlobeVec.MASK_H).toInt().coerceIn(0, GlobeVec.MASK_H - 1)
            val col = ((lon + Math.PI) / (2 * Math.PI) * GlobeVec.MASK_W).toInt().coerceIn(0, GlobeVec.MASK_W - 1)
            val bit = row * GlobeVec.MASK_W + col
            return (mask[bit ushr 3].toInt() ushr (bit and 7)) and 1 == 1
        }

        /** Maske satırı [row] ve boylam [lon] (radyan, sarmalanır) için hızlı sorgu (yarım ton). */
        fun maybeLandRC(row: Int, lon: Double): Boolean {
            var l = lon % (2 * Math.PI); if (l < -Math.PI) l += 2 * Math.PI; if (l >= Math.PI) l -= 2 * Math.PI
            val col = ((l + Math.PI) / (2 * Math.PI) * GlobeVec.MASK_W).toInt().coerceIn(0, GlobeVec.MASK_W - 1)
            val bit = row * GlobeVec.MASK_W + col
            return (mask[bit ushr 3].toInt() ushr (bit and 7)) and 1 == 1
        }

        /** (enlem, boylam; derece) hangi ülkede; yoksa -1. Halkalar üzerinde ışın atma (boylam/enlem düzleminde). */
        fun countryAt(latDeg: Double, lonDeg: Double): Int {
            for (c in 0 until countryCount) {
                var inside = false
                for (q in ringStart[c] until ringStart[c + 1]) {
                    var px = Double.NaN; var py = 0.0
                    forRing(q) { x, y, z ->
                        val la = Math.toDegrees(asin(z.toDouble().coerceIn(-1.0, 1.0))); val lo = Math.toDegrees(atan2(y.toDouble(), x.toDouble()))
                        if (!px.isNaN() && abs(lo - px) < 180 && ((py > latDeg) != (la > latDeg)) && lonDeg < (lo - px) * (latDeg - py) / (la - py) + px) inside = !inside
                        px = lo; py = la
                    }
                }
                if (inside) return c
            }
            return -1
        }

        /** Halka [q]'nun köşelerini sırayla (yay yönüne göre) verir (tüm ayrıntı). */
        inline fun forRing(q: Int, f: (Float, Float, Float) -> Unit) {
            for (r in refStart[q] until refStart[q + 1]) {
                val ref = refs[r]; val a = if (ref >= 0) ref else ref.inv()
                val s = arcStart[a]; val e = arcStart[a + 1]
                if (ref >= 0) for (v in s until e) f(xyz[3 * v], xyz[3 * v + 1], xyz[3 * v + 2])
                else for (v in e - 1 downTo s) f(xyz[3 * v], xyz[3 * v + 1], xyz[3 * v + 2])
            }
        }
    }

    val map: VecMap by lazy { load().also { ready = true } }
    @Volatile var ready = false; private set

    /** Veriyi arka planda hazırlar (ilk çizimde takılma olmasın). */
    fun warm() { if (!ready) Thread({ map }, "kure-veri").apply { isDaemon = true; priority = Thread.MIN_PRIORITY }.start() }

    private fun inflate(b64: String): ByteArray {
        val src = java.util.Base64.getDecoder().decode(b64)
        val inf = java.util.zip.Inflater()
        try {
            inf.setInput(src)
            val out = java.io.ByteArrayOutputStream(src.size * 3)
            val buf = ByteArray(64 * 1024)
            while (!inf.finished()) {
                val n = inf.inflate(buf)
                if (n == 0 && (inf.needsInput() || inf.needsDictionary())) throw IllegalStateException("küre verisi bozuk")
                out.write(buf, 0, n)
            }
            return out.toByteArray()
        } finally { inf.end() }
    }

    private class Reader(val d: ByteArray) {
        var pos = 0
        val more get() = pos < d.size
        fun varint(): Int { var r = 0L; var s = 0; while (true) { val c = d[pos++].toInt() and 0xFF; r = r or ((c and 0x7F).toLong() shl s); if (c < 0x80) return r.toInt(); s += 7 } }
        fun zz(): Int { val v = varint(); return (v ushr 1) xor -(v and 1) }
    }

    private fun load(): VecMap {
        val nArcs = GlobeVec.ARC_COUNT; val nV = GlobeVec.VERTEX_COUNT
        val xyz = FloatArray(3 * nV); val arcStart = IntArray(nArcs + 1)
        val capX = FloatArray(nArcs); val capY = FloatArray(nArcs); val capZ = FloatArray(nArcs); val capCos = FloatArray(nArcs); val capSin = FloatArray(nArcs)
        val ar = Reader(inflate(GlobeVec.ARCS))
        var v = 0
        for (a in 0 until nArcs) {
            arcStart[a] = v
            val n = ar.varint(); var x = 0; var y = 0
            var sx = 0.0; var sy = 0.0; var sz = 0.0
            repeat(n) {
                x += ar.zz(); y += ar.zz()
                val lo = Math.toRadians(x * GlobeVec.Q - 180); val la = Math.toRadians(y * GlobeVec.Q - 90)
                val cx = cos(la) * cos(lo); val cy = cos(la) * sin(lo); val cz = sin(la)
                xyz[3 * v] = cx.toFloat(); xyz[3 * v + 1] = cy.toFloat(); xyz[3 * v + 2] = cz.toFloat()
                sx += cx; sy += cy; sz += cz; v++
            }
            val l = sqrt(sx * sx + sy * sy + sz * sz).coerceAtLeast(1e-9)
            capX[a] = (sx / l).toFloat(); capY[a] = (sy / l).toFloat(); capZ[a] = (sz / l).toFloat()
            var mn = 1f
            for (k in arcStart[a] until v) mn = minOf(mn, capX[a] * xyz[3 * k] + capY[a] * xyz[3 * k + 1] + capZ[a] * xyz[3 * k + 2])
            capCos[a] = mn.coerceIn(-1f, 1f); capSin[a] = sqrt(1f - capCos[a] * capCos[a])
        }
        arcStart[nArcs] = v
        check(v == nV && !ar.more) { "küre verisi bozuk" }
        val level = inflate(GlobeVec.ARC_LEVELS); check(level.size == nV) { "küre verisi bozuk" }
        val kind = inflate(GlobeVec.ARC_KINDS); check(kind.size == nArcs) { "küre verisi bozuk" }
        val cr = Reader(inflate(GlobeVec.COUNTRIES))
        val nc = cr.varint()
        val group = IntArray(nc); val ringStart = IntArray(nc + 1)
        val refStartL = ArrayList<Int>(); val refsL = ArrayList<Int>()
        var rings = 0
        for (c in 0 until nc) {
            group[c] = cr.varint(); ringStart[c] = rings
            val nr = cr.varint()
            repeat(nr) { refStartL.add(refsL.size); val na = cr.varint(); repeat(na) { refsL.add(cr.zz()) }; rings++ }
        }
        ringStart[nc] = rings; refStartL.add(refsL.size)
        return VecMap(xyz, level, arcStart, kind, capX, capY, capZ, capCos, capSin, group, ringStart, refStartL.toIntArray(), refsL.toIntArray(),
            GlobeVec.NAMES, inflate(GlobeVec.MASK))
    }

    /**
     * Çoklu çizgiler (ızgara): tüm noktaların dünya birim vektörleri [xyz] (x, y, z ardışık) ve her çizginin başlangıç
     * noktası [start] (son eleman toplam nokta sayısı). Çizgi k: [start][k] .. [start][k+1]-1.
     */
    class Lines(val xyz: FloatArray, val start: IntArray) { val count get() = start.size - 1 }

    /**
     * Köşe yapay kesimde mi: tam 180. boylam (Natural Earth ülkeleri orada böler: Rusya, Fiji) ya da Güney Kutbu (Antarktika).
     * İki ucu da kesimde olan parça kıyı/sınır olarak çizilmez.
     */
    fun isSeam(x: Float, y: Float, z: Float): Boolean = (abs(y) < 1e-6f && x < 0f) || z < -0.99999f

    /** Gösterilecek ayrıntı düzeyi: köşe sapması bu eşiğin altındaysa atlanır. [radiusDp]: kürenin ekran yarıçapı. */
    fun minLevel(radiusDp: Float, tolDp: Float = 0.6f): Int {
        val req = tolDp / radiusDp
        var k = 0
        for (i in GlobeVec.LEVELS.indices) if (GlobeVec.LEVELS[i] <= req) k = i
        return k
    }
}
