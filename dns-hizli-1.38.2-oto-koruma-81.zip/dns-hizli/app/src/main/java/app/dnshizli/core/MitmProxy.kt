package app.dnshizli.core

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/** Ağ geçidinin TLS akışını yerel vekile yönlendirmek için kullandığı kanca (yalnızca tarayıcı kipinde ayarlanır). */
interface MitmHook {
    /** Bu akışın TLS'i vekile verilsin mi? Ad kural listesinde değilse, vekil bu adda hata yaptıysa ya da istemci tarayıcı değilse false. */
    fun wants(host: String, client: ByteArray, cport: Int, server: ByteArray, sport: Int): Boolean
    /** Vekilin yerel dinleme portu. */
    fun port(): Int
    /** Ağ geçidinin vekile açacağı bağlantının yerel portu ([localPort]) için gerçek hedefi bildirir; bağlanmadan ÖNCE çağrılır. */
    fun expect(localPort: Int, host: String, addr: InetAddress, port: Int)
    /** [expect] ile bildirilen bağlantı vekile hiç ulaşmadan düştü: kayıt hemen silinir (30 sn boyunca başka bir bağlantı o portla eşleşmesin). */
    fun unexpect(localPort: Int) {}
}

/**
 * Yerel TLS vekili (deneysel tarayıcı kipi). İstemci tarafında [MitmCa]'nın ürettiği yaprak sertifikayla TLS sonlandırır, sunucuya
 * ise ayrı, tam doğrulamalı (zincir + ad) bir TLS bağlantısı açar; yalnızca HTML cevaplarına [Cosmetic] CSS'i enjekte eder.
 * İstemci HTTP/1.1'e indirilir (ALPN yok), her bağlantıda tek istek/cevap işlenir ("Connection: close"); ters/yükseltme (WebSocket,
 * chunked istek gövdesi) isteklerinde sade tünel olur. İstemci CA'ya güvenmiyorsa (TLS el sıkışma hatası) ad 10 dk vekilden muaf tutulur.
 */
class MitmProxy(
    private val ca: MitmCa,
    private val rules: Cosmetic,
    /** Gerçek sunucuya bağlı (korumalı) ham soket. */
    private val connectOrigin: (InetAddress, Int) -> Socket,
    private val originTls: () -> SSLSocketFactory = { SSLSocketFactory.getDefault() as SSLSocketFactory },
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000 },
    private val log: (String) -> Unit = {},
    /** HTML gövdesinin toplanması için toplam süre (ms); yalnızca testler değiştirir. */
    private val bodyDeadlineMs: Long = BODY_DEADLINE_MS,
) : AutoCloseable {
    private class Expect(val host: String, val addr: InetAddress, val port: Int, val at: Long)

    private val server = ServerSocket(0, 64, InetAddress.getLoopbackAddress())
    private val expects = ConcurrentHashMap<Int, Expect>()
    private val muted = ConcurrentHashMap<String, Long>()
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "mitm").apply { isDaemon = true } }
    private val slots = Semaphore(MAX_CONN)
    @Volatile private var closed = false

    /** Kural alanı (ör. "youtube.com") başına açık bağlantı sayısı: bir sitenin yavaş/askıdaki bağlantılarla bütün yuvaları tutup öteki siteleri engellemesine karşı. */
    private val perDomain = ConcurrentHashMap<String, AtomicInteger>()
    private val capped = AtomicLong()
    private val certRejects = AtomicLong()
    private val handled = AtomicLong(); private val injected = AtomicLong(); private val failed = AtomicLong(); private val tunneled = AtomicLong()

    val port: Int get() = server.localPort
    fun certRejects() = certRejects.get()
    fun handled() = handled.get(); fun injected() = injected.get(); fun failed() = failed.get(); fun tunneled() = tunneled.get()
    /** Alan başına bağlantı sınırı yüzünden reddedilen bağlantı sayısı. */
    fun capped() = capped.get()
    /** Sertifikayı reddeden istemci sayısı ile işlenen bağlantı sayısı (denetim için). */
    fun summary(): String = "tarayıcı kipi: işlenen ${handled.get()}, enjekte ${injected.get()}, tünel ${tunneled.get()}, hata ${failed.get()}, muaf ad ${muted.size}"

    fun start() {
        Thread({ acceptLoop() }, "mitm-accept").apply { isDaemon = true; start() }
    }

    fun expect(localPort: Int, host: String, addr: InetAddress, port: Int) {
        if (expects.size > 512) expects.entries.removeIf { nowMs() - it.value.at > 30_000 }
        if (expects.size >= 1024) expects.entries.minByOrNull { it.value.at }?.let { expects.remove(it.key) }     // üst sınır: en eskisi düşer (yeni, meşru akış reddedilmez)
        expects[localPort] = Expect(host, addr, port, nowMs())
    }

    fun unexpect(localPort: Int) { expects.remove(localPort) }

    /** Ad kural listesinde ve vekilden muaf değilse true. */
    fun wantsHost(host: String): Boolean {
        if (closed || !rules.has(host)) return false
        val until = muted[host.lowercase()] ?: return true
        if (nowMs() < until) return false
        muted.remove(host.lowercase()); return true
    }

    private val strikes = ConcurrentHashMap<String, Long>()
    /** "Broken pipe" için ikinci vuruş mu (60 sn içinde)? */
    private fun strike(host: String): Boolean {
        val h = host.lowercase(); val now = nowMs()
        val prev = strikes.put(h, now)
        if (strikes.size > 256) strikes.entries.removeIf { now - it.value > 60_000L }
        return prev != null && now - prev <= 60_000L
    }

    private fun mute(host: String) { muted[host.lowercase()] = nowMs() + MUTE_MS; if (muted.size > 256) muted.entries.removeIf { nowMs() >= it.value } }

    private fun acceptLoop() {
        while (!closed) {
            val s = try { server.accept() } catch (_: IOException) { return }
            if (!slots.tryAcquire()) { try { s.close() } catch (_: Exception) {}; continue }
            try { pool.execute { try { serve(s) } finally { slots.release() } } } catch (_: Exception) { slots.release(); try { s.close() } catch (_: Exception) {} }
        }
    }

    private fun serve(raw: Socket) {
        var client: SSLSocket? = null
        var origin: SSLSocket? = null
        var held: AtomicInteger? = null
        try {
            val ex = expects.remove(raw.port) ?: run { return }
            if (nowMs() - ex.at > 30_000) return
            val dom = rules.ruleDomain(ex.host) ?: ex.host.lowercase()
            if (perDomain.size > 1024) perDomain.entries.removeIf { it.value.get() == 0 }
            val cnt = perDomain.computeIfAbsent(dom) { AtomicInteger() }
            if (cnt.incrementAndGet() > MAX_PER_DOMAIN) { cnt.decrementAndGet(); capped.incrementAndGet(); return }
            held = cnt
            handled.incrementAndGet()
            raw.tcpNoDelay = true
            val ctx = ca.serverContext(ex.host) ?: return
            client = ctx.socketFactory.createSocket(raw, ex.host, raw.port, true) as SSLSocket
            client.useClientMode = false
            client.soTimeout = HANDSHAKE_MS
            try { client.startHandshake() } catch (e: IOException) {
                failed.incrementAndGet()
                log("tarayıcı kipi: istemci el sıkışması hatası: ${e.javaClass.simpleName}: ${e.message?.take(120)}")
                // Yalnızca istemci sertifikayı REDDEDERSE (TLS uyarısı: bilinmeyen CA / sertifika hatası) ad bir süre vekilsiz kalır: tarayıcı değil ya da CA
                // kurulu değil, bağlantı kendini yeniler. Sessizce kapanan bağlantı (tarayıcının boşa açtığı ön bağlantı, iptal) bunu tetiklemez.
                // Açık TLS uyarısı (bilinmeyen CA vb.) hemen; yalnız "broken pipe" ise (tarayıcının iptal ettiği ön bağlantı da olabilir)
                // 60 sn içinde ikinci kez görülünce muaf tutulur — tek bir iptal kozmetik süzgeci 10 dk susturmasın.
                when (rejectKind(e)) {
                    2 -> { certRejects.incrementAndGet(); mute(ex.host); log("tarayıcı kipi: ${ex.host} istemci sertifikayı reddetti; 10 dk muaf") }
                    1 -> if (strike(ex.host)) { certRejects.incrementAndGet(); mute(ex.host); log("tarayıcı kipi: ${ex.host} tekrarlanan kopma; 10 dk muaf") }
                }
                return
            }
            client.soTimeout = IO_MS
            val o = connectOrigin(ex.addr, ex.port)
            val sf = originTls()
            val os = sf.createSocket(o, ex.host, ex.port, true) as SSLSocket
            origin = os
            val p = os.sslParameters
            p.serverNames = listOf(SNIHostName(ex.host))
            p.endpointIdentificationAlgorithm = "HTTPS"           // sunucu sertifikasının adı doğrulanır; yoksa vekil kendisi bir saldırı yüzeyi olurdu
            os.sslParameters = p
            os.soTimeout = HANDSHAKE_MS
            os.startHandshake()
            os.soTimeout = IO_MS
            exchange(ex.host, client.inputStream, client.outputStream, os.inputStream, os.outputStream, client, os)
        } catch (e: Exception) {
            failed.incrementAndGet()
            if (e !is SocketTimeoutException) log("tarayıcı kipi: ${e.javaClass.simpleName}")
        } finally {
            held?.decrementAndGet()
            try { client?.close() } catch (_: Exception) {}
            try { origin?.close() } catch (_: Exception) {}
            try { raw.close() } catch (_: Exception) {}
        }
    }

    // ---- HTTP/1.1: tek istek, tek cevap

    private class Head(val first: String, val lines: List<String>, val consumed: Int, val rest: ByteArray) {
        /**
         * Başlık satırı biçimi bozuk mu: katlanmış satır (SP/HT ile başlayan, RFC 9112 §5.2), iki nokta yok, ya da ad ile ':' arasında boşluk /
         * kontrol karakteri (§5.1: "Transfer-Encoding : chunked"). Biz bu satırı başlık saymadığımız için çerçeveleme (uzunluk / chunked)
         * kararımız karşı tarafınkinden ayrışabilir (HTTP kaçakçılığı); bu yüzden böyle bir mesaj hiç iletilmez.
         */
        val malformed: Boolean by lazy(LazyThreadSafetyMode.NONE) {
            lines.any { l ->
                val c = l.indexOf(':')
                c <= 0 || l[0] == ' ' || l[0] == '\t' || (0 until c).any { l[it] == ' ' || l[it] == '\t' || l[it] < ' ' }
            }
        }
        fun header(name: String): String? {
            val p = name.lowercase() + ":"
            for (l in lines) if (l.length > p.length && l.regionMatches(0, p, 0, p.length, ignoreCase = true)) return l.substring(p.length).trim()
            return null
        }
        fun all(name: String): List<String> {
            val p = name.lowercase() + ":"
            return lines.filter { l -> l.length > p.length && l.regionMatches(0, p, 0, p.length, ignoreCase = true) }.map { it.substring(p.length).trim() }
        }
        /** Content-Length: tek, geçerli ve ≥ 0 ise değer; yoksa null; çift/çelişkili/bozuksa [BAD_LEN]. (İstek sızdırma ve yanlış çerçeveleme savunması.) */
        fun length(): Long? {
            val v = all("content-length")
            if (v.isEmpty()) return null
            if (v.toSet().size > 1) return BAD_LEN
            val n = v[0].toLongOrNull() ?: return BAD_LEN
            return if (n < 0) BAD_LEN else n
        }
        fun without(vararg names: String): List<String> {
            val ps = names.map { it.lowercase() + ":" }
            return lines.filter { l -> ps.none { l.regionMatches(0, it, 0, it.length, ignoreCase = true) } }
        }
    }

    private fun readHead(ins: InputStream): Head? {
        val buf = ByteArrayOutputStream()
        val b = ByteArray(4096)
        var end = -1
        while (end < 0) {
            val n = ins.read(b)
            if (n < 0) return null
            buf.write(b, 0, n)
            if (buf.size() > MAX_HEAD) return null
            end = indexOf(buf.toByteArray(), CRLF2)
        }
        val all = buf.toByteArray()
        val text = String(all, 0, end, Charsets.ISO_8859_1)
        val ls = text.split("\r\n")
        return Head(ls[0], ls.drop(1).filter { it.isNotEmpty() }, end + 4, all.copyOfRange(end + 4, all.size))
    }

    private fun exchange(host: String, cin: InputStream, cout: OutputStream, oin: InputStream, oout: OutputStream, client: Socket, origin: Socket) {
        val req = readHead(cin) ?: return
        if (req.malformed) { failed.incrementAndGet(); log("tarayıcı kipi: biçimi bozuk istek başlığı (boşluklu ad / katlanmış satır) düşürüldü"); return }
        val method = req.first.substringBefore(' ').uppercase()
        val te = req.header("transfer-encoding")?.lowercase() ?: ""
        val upgrade = req.header("upgrade") != null || method == "CONNECT"
        val clen0 = req.length()
        if (clen0 == BAD_LEN) { failed.incrementAndGet(); log("tarayıcı kipi: çelişkili/bozuk Content-Length isteği düşürüldü"); return }
        val clen = clen0 ?: 0L
        if (upgrade || te.contains("chunked") || clen > MAX_REQ_BODY || clen < 0 || req.header("expect") != null) {
            tunneled.incrementAndGet()
            oout.write((req.first + "\r\n" + req.lines.joinToString("") { it + "\r\n" } + "\r\n").toByteArray(Charsets.ISO_8859_1))
            oout.write(req.rest); oout.flush()
            pump(cin, oout, oin, cout, client, origin)
            return
        }
        val newLines = req.without("accept-encoding", "connection", "proxy-connection", "keep-alive") + listOf("Accept-Encoding: identity", "Connection: close")
        oout.write((req.first + "\r\n" + newLines.joinToString("") { it + "\r\n" } + "\r\n").toByteArray(Charsets.ISO_8859_1))
        // istek gövdesi: Content-Length kadar, önceden okunan kısım dahil
        var left = clen
        if (left > 0) {
            val pre = minOf(left, req.rest.size.toLong()).toInt()
            oout.write(req.rest, 0, pre); left -= pre
            val b = ByteArray(8192)
            while (left > 0) { val n = cin.read(b, 0, minOf(b.size.toLong(), left).toInt()); if (n < 0) return; oout.write(b, 0, n); left -= n }
        }
        oout.flush()

        val res = readHead(oin) ?: return
        if (res.malformed) { failed.incrementAndGet(); log("tarayıcı kipi: biçimi bozuk cevap başlığı (boşluklu ad / katlanmış satır) düşürüldü"); return }
        val status = res.first.split(' ').getOrNull(1)?.toIntOrNull() ?: 0
        val ctype = res.header("content-type")?.lowercase() ?: ""
        val enc = res.header("content-encoding")?.lowercase()
        val rte = res.header("transfer-encoding")?.lowercase() ?: ""
        val rlen0 = res.length()
        val rlen = if (rlen0 == BAD_LEN) null else rlen0           // bozuk uzunluk: çerçeve bilinmiyor, bağlantı kapanana dek aktar (enjekte yok)
        val chunked = rte.contains("chunked")
        val css = rules.css(host)
        val canInject = method == "GET" && status == 200 && css.isNotEmpty() && ctype.startsWith("text/html") && (enc == null || enc == "identity") &&
            (chunked || (rlen != null && rlen in 0..MAX_BODY)) && charsetOk(ctype) && res.header("content-range") == null
        if (!canInject) {
            val hl = res.without("connection", "keep-alive") + "Connection: close"
            cout.write((res.first + "\r\n" + hl.joinToString("") { it + "\r\n" } + "\r\n").toByteArray(Charsets.ISO_8859_1))
            cout.write(res.rest); cout.flush()
            var sent = res.rest.size.toLong()
            val b = ByteArray(16384)
            val noBody = method == "HEAD" || status in 100..199 || status == 204 || status == 304
            // Transfer-Encoding: chunked varsa Content-Length yok sayılır (RFC 9112 §6.3); ikisi birlikte gelirse akış uzunlukla erken kesilmesin.
            val framed = if (chunked) null else rlen
            val ce = if (chunked) ChunkEnd().also { it.feed(res.rest, 0, res.rest.size) } else null
            if (!noBody && !(framed != null && sent >= framed) && ce?.done != true) {
                try {
                    while (true) {
                        val n = oin.read(b); if (n < 0) break
                        cout.write(b, 0, n); sent += n
                        if (framed != null && sent >= framed) break
                        if (ce != null && ce.feed(b, 0, n)) break           // son parça gerçekten görüldü (veri içinde "0\r\n\r\n" gibi baytlar yanıltmaz)
                    }
                } catch (_: SocketTimeoutException) { /* sunucu bağlantıyı kapatmadı: tamam say */ }
            }
            cout.flush()
            return
        }
        // HTML: gövde tamamen okunur, CSS eklenir, Content-Length yeniden yazılır.
        val body = ByteArrayOutputStream()
        val deadline = System.nanoTime() / 1_000_000 + bodyDeadlineMs          // damla damla gelen gövdeyle yuva tutmaya karşı toplam süre sınırı
        if (chunked) readChunked(res.rest, oin, body, deadline) else readFixed(res.rest, oin, body, rlen!!, deadline)
        val html = body.toByteArray()
        val nonce = styleNonce(res.all("content-security-policy"))
        val outBody = inject(html, css, nonce)
        if (outBody !== html) injected.incrementAndGet()
        val hl = res.without("content-length", "transfer-encoding", "connection", "keep-alive") + listOf("Content-Length: ${outBody.size}", "Connection: close")
        cout.write((res.first + "\r\n" + hl.joinToString("") { it + "\r\n" } + "\r\n").toByteArray(Charsets.ISO_8859_1))
        cout.write(outBody); cout.flush()
    }

    private fun pump(cin: InputStream, oout: OutputStream, oin: InputStream, cout: OutputStream, client: Socket, origin: Socket) {
        val t = Thread({
            val b = ByteArray(16384)
            try { while (true) { val n = cin.read(b); if (n < 0) break; oout.write(b, 0, n); oout.flush() } } catch (_: Exception) {}
            try { origin.close() } catch (_: Exception) {}
        }, "mitm-up").apply { isDaemon = true; start() }
        val b = ByteArray(16384)
        try { while (true) { val n = oin.read(b); if (n < 0) break; cout.write(b, 0, n); cout.flush() } } catch (_: Exception) {}
        try { client.close() } catch (_: Exception) {}
        t.join(1000)
    }

    override fun close() {
        closed = true
        try { server.close() } catch (_: Exception) {}
        pool.shutdownNow()
    }

    companion object {
        const val MAX_CONN = 128
        /** Bir kural alanının (youtube.com…) aynı anda açık tutabileceği en çok vekil bağlantısı; tarayıcı alan başına en çok ~6 bağlantı açar. */
        const val MAX_PER_DOMAIN = 72
        /** HTML gövdesinin bellekte toplanması için toplam süre (ms); tek okuma zaman aşımından bağımsız. */
        const val BODY_DEADLINE_MS = 60_000L
        private const val BAD_LEN = -1L
        const val MAX_HEAD = 32 * 1024
        const val MAX_BODY = 4L * 1024 * 1024
        const val MAX_REQ_BODY = 1L * 1024 * 1024
        const val HANDSHAKE_MS = 10_000
        const val IO_MS = 20_000
        const val MUTE_MS = 10 * 60_000L
        private val CRLF2 = byteArrayOf(13, 10, 13, 10)

        /**
         * El sıkışma hatası istemcinin sertifikayı reddetmesinden mi geldi? TLS uyarısı ya da "Broken pipe" (yazma ancak ClientHello okunduktan sonra olur;
         * istemci uyarıyı gönderip hemen kapatınca uyarı kaybolabilir). EOF, okuma sıfırlaması ve zaman aşımı değil: o bağlantı hiç el sıkışmamıştır.
         */
        /** 2: açık sertifika reddi (TLS uyarısı), 1: yalnız "broken pipe" (uyarı kaybolmuş ya da bağlantı iptal), 0: değil. */
        internal fun rejectKind(e: Throwable): Int {
            var x: Throwable? = e; var pipe = false
            while (x != null) {
                if (x !is SocketTimeoutException) {
                    val m = (x.message ?: "").lowercase()
                    if ("unknown_ca" in m || "unknown ca" in m || "bad_certificate" in m || "certificate_unknown" in m || "certificate unknown" in m ||
                        "bad certificate" in m || "certificate_expired" in m || "unsupported_certificate" in m || "alert" in m && "certificate" in m) return 2
                    if ("broken pipe" in m) pipe = true
                }
                x = x.cause
            }
            return if (pipe) 1 else 0
        }

        internal fun rejectedCert(e: Throwable): Boolean {
            var x: Throwable? = e
            while (x != null) {
                val m = (x.message ?: "").lowercase()
                if (x !is SocketTimeoutException && ("unknown_ca" in m || "unknown ca" in m || "bad_certificate" in m || "certificate_unknown" in m || "certificate unknown" in m ||
                        "bad certificate" in m || "broken pipe" in m || "certificate_expired" in m || "unsupported_certificate" in m || "alert" in m && "certificate" in m)) return true
                x = x.cause
            }
            return false
        }

        internal fun indexOf(h: ByteArray, n: ByteArray, from: Int = 0): Int {
            outer@ for (i in from..h.size - n.size) { for (j in n.indices) if (h[i + j] != n[j]) continue@outer; return i }
            return -1
        }

        private fun charsetOk(ctype: String): Boolean {
            val i = ctype.indexOf("charset=")
            if (i < 0) return true
            val cs = ctype.substring(i + 8).trim().trim('"', '\'').substringBefore(';').trim()
            return cs == "utf-8" || cs == "utf8" || cs == "us-ascii" || cs == "iso-8859-1" || cs == "iso-8859-9" || cs.startsWith("windows-125")
        }

        /**
         * İçeriğe CSS enjekte edilecek konum için `<style>` ekler: `</head>` öncesine (yoksa `<body ...>` sonrasına). Yorum, `<script>`, `<style>`,
         * `<textarea>`, `<title>`, `<noscript>` ve `<xmp>` içindeki "</head>" metinleri atlanır (betikteki bir dizgeye enjekte etmek sayfayı bozardı).
         * Yer bulunamazsa girdiyi AYNI nesne olarak döndürür.
         */
        fun inject(html: ByteArray, css: String, nonce: String?): ByteArray {
            if (css.isEmpty()) return html
            val s = String(html, Charsets.ISO_8859_1)          // bayt/karakter 1:1; UTF-8 baytları bozulmadan geri yazılır
            val low = s.lowercase()
            val tag = "<style" + (if (nonce != null) " nonce=\"$nonce\"" else "") + ">" + css + "</style>"
            var at = findTag(low, "</head", closing = true)
            if (at < 0) {
                val b = findTag(low, "<body", closing = false)
                if (b < 0) return html
                val e = tagEnd(low, b + 5)
                if (e < 0) return html
                at = e + 1
            }
            return (s.substring(0, at) + tag + s.substring(at)).toByteArray(Charsets.ISO_8859_1)
        }

        /** Etiketin kapanış '>' konumu; tırnaklı öznitelik değerleri içindeki '>' ("<body data-x=\"a>b\">") atlanır. Yoksa -1. */
        internal fun tagEnd(low: String, from: Int): Int {
            var q = '\u0000'
            var i = from
            while (i < low.length) {
                val c = low[i]
                if (q != '\u0000') { if (c == q) q = '\u0000' }
                else if (c == '"' || c == '\'') q = c
                else if (c == '>') return i
                i++
            }
            return -1
        }

        private val RAW_TEXT = arrayOf("<script", "<style", "<textarea", "<title", "<noscript", "<xmp")

        private fun nameEnds(low: String, at: Int): Boolean = at >= low.length || low[at] == '>' || low[at] == '/' || low[at].isWhitespace()

        /** [name] ("</head" ya da "<body") etiketinin başlangıcı; yorum ve ham metin bölgeleri atlanır. Yoksa -1. */
        internal fun findTag(low: String, name: String, closing: Boolean): Int {
            var i = 0
            val n = low.length
            while (i < n) {
                val lt = low.indexOf('<', i)
                if (lt < 0) return -1
                if (low.startsWith("<!--", lt)) { val e = low.indexOf("-->", lt + 4); if (e < 0) return -1; i = e + 3; continue }
                if (low.startsWith(name, lt) && nameEnds(low, lt + name.length)) {
                    if (!closing) return lt
                    var k = lt + name.length
                    while (k < n && low[k].isWhitespace()) k++
                    if (k < n && low[k] == '>') return lt
                }
                var skipped = false
                for (raw in RAW_TEXT) {
                    if (low.startsWith(raw, lt) && nameEnds(low, lt + raw.length)) {
                        val e = low.indexOf("</" + raw.substring(1), lt + raw.length)
                        if (e < 0) return -1
                        i = e + 1; skipped = true; break
                    }
                }
                if (!skipped) i = lt + 1
            }
            return -1
        }

        /**
         * Enjekte edilen `<style>` için nonce: CSP'nin `style-src`/`style-src-elem` yönergesindeki, yoksa `default-src`'deki, o da yoksa herhangi bir
         * `'nonce-…'` değeri (yalnızca `script-src` nonce'u olan sayfa satır içi stile zaten izin verir; fazladan nonce özniteliği zararsızdır).
         */
        internal fun styleNonce(policies: List<String>): String? {
            val re = Regex("'nonce-([A-Za-z0-9+/=_\\-]+)'")
            fun pick(dirs: List<String>): String? {
                for (p in policies) for (d in p.split(';')) {
                    val t = d.trim()
                    val name = t.substringBefore(' ').lowercase()
                    if (name in dirs) re.find(t)?.let { return it.groupValues[1] }
                }
                return null
            }
            return pick(listOf("style-src-elem")) ?: pick(listOf("style-src")) ?: pick(listOf("default-src")) ?: policies.firstNotNullOfOrNull { re.find(it)?.groupValues?.get(1) }
        }

        private fun overdue(deadlineMs: Long) { if (System.nanoTime() / 1_000_000 > deadlineMs) throw IOException("gövde süresi aşıldı") }

        /** Tam [len] bayt okunur ([pre]: başlıkla birlikte gelen kısım). Akış erken biterse IOException: kesik sayfa "tam" gibi gösterilmez. */
        internal fun readFixed(pre: ByteArray, ins: InputStream, out: ByteArrayOutputStream, len: Long, deadlineMs: Long = Long.MAX_VALUE) {
            out.write(pre, 0, minOf(pre.size.toLong(), len).toInt())
            val b = ByteArray(16384)
            while (out.size() < len) {
                overdue(deadlineMs)
                val n = ins.read(b, 0, minOf(b.size.toLong(), len - out.size()).toInt())
                if (n < 0) throw IOException("gövde kesik")
                out.write(b, 0, n)
            }
        }

        /** Boyut satırı en çok bu kadar bayt (uzantılar dahil). */
        private const val MAX_CHUNK_LINE = 256

        /**
         * chunked gövdeyi doğrusal sürede çözer ([pre]: başlıkla birlikte okunmuş kısım). Aşırı büyük, bozuk ya da erken biten akışta IOException.
         * (Önceki sürüm her parçada biriken baytı baştan kopyalıyordu: 1 baytlık parçalarla 4 MB, dakikalarca işlemci yakardı.)
         */
        internal fun readChunked(pre: ByteArray, ins: InputStream, out: ByteArrayOutputStream, deadlineMs: Long = Long.MAX_VALUE) {
            val src = java.io.BufferedInputStream(java.io.SequenceInputStream(java.io.ByteArrayInputStream(pre), ins), 16384)
            fun line(): String {
                val sb = StringBuilder()
                while (true) {
                    val c = src.read()
                    if (c < 0) throw IOException("chunked eksik")
                    if (c == '\n'.code) return sb.toString().trimEnd('\r')
                    if (sb.length >= MAX_CHUNK_LINE) throw IOException("chunk satırı çok uzun")
                    sb.append(c.toChar())
                }
            }
            val tmp = ByteArray(16384)
            while (true) {
                overdue(deadlineMs)
                val size = line().substringBefore(';').trim().let { if (it.isEmpty() || it.length > 8) null else it.toIntOrNull(16) } ?: throw IOException("chunk boyutu")
                if (size < 0 || out.size().toLong() + size > MAX_BODY) throw IOException("büyük gövde")
                if (size == 0) return
                var left = size
                while (left > 0) {
                    val n = src.read(tmp, 0, minOf(tmp.size, left))
                    if (n < 0) throw IOException("chunked eksik")
                    out.write(tmp, 0, n); left -= n
                    overdue(deadlineMs)
                }
                val c1 = src.read()
                if (c1 == '\r'.code) { if (src.read() != '\n'.code) throw IOException("chunk sonu") } else if (c1 != '\n'.code) throw IOException("chunk sonu")
            }
        }
    }
}

/**
 * chunked gövdenin BİTTİĞİ yeri akıştan bulur (okuma sınırlarından bağımsız): boyut satırı → veri → CRLF → ... → 0 boyutlu parça + iz satırları + boş satır.
 * Yalnızca okunan arabelleğin sonuna bakmak, veri içindeki "0\r\n\r\n" baytlarında akışı erken keser ve bölünmüş son parçayı hiç görmezdi.
 * Çerçeve bozuksa [bad] olur ve çağıran bağlantı kapanana dek aktarmaya devam eder.
 */
internal class ChunkEnd {
    private var st = 0                 // 0 boyut satırı, 1 veri, 2 veri sonu CRLF, 3 iz satırı başı, 4 iz satırı, 6 son LF
    private var size = 0L
    private var digits = 0
    private var ext = false
    private var line = 0
    private var left = 0L
    var done = false; private set
    var bad = false; private set

    /** [n] baytı işler; gövde tamamlandıysa true. */
    fun feed(b: ByteArray, off: Int, n: Int): Boolean {
        var i = off
        val end = minOf(off + n, b.size)
        while (i < end && !done && !bad) {
            val c = b[i].toInt() and 0xFF
            when (st) {
                0 -> {
                    if (++line > 1024) bad = true
                    else if (c == '\n'.code) {
                        if (digits == 0) bad = true else { left = size; st = if (size == 0L) 3 else 1 }
                        size = 0; digits = 0; ext = false; line = 0
                    } else if (c == '\r'.code || c == ' '.code || c == '\t'.code) { /* boşluk */ }
                    else if (ext) { /* uzantı */ }
                    else if (c == ';'.code) ext = true
                    else {
                        val d = Character.digit(c, 16)
                        if (d < 0 || ++digits > 8) bad = true else size = size * 16 + d
                    }
                }
                1 -> {
                    val take = minOf(left, (end - i).toLong()).toInt()
                    left -= take; i += take
                    if (left == 0L) st = 2
                    continue
                }
                2 -> if (c == '\n'.code) st = 0 else if (c != '\r'.code) bad = true
                3 -> if (c == '\n'.code) done = true else if (c == '\r'.code) st = 6 else { st = 4; line = 1 }
                6 -> if (c == '\n'.code) done = true else bad = true
                else -> { if (c == '\n'.code) { st = 3; line = 0 } else if (++line > 8192) bad = true }
            }
            i++
        }
        return done
    }
}
