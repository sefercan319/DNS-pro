package app.dnshizli.core

import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Kürenin piksel başına ışık katmanları: her piksel için görüş ışını küreyle kesiştirilir (ışın izleme), yüzey normali ve ışık
 * yönünden fiziksel tabanlı terimler hesaplanır. Işık görünüm uzayında sabit olduğu için (sol üst önden) katmanlar dönüşten
 * bağımsızdır: bir kez hesaplanır, her karede ölçeklenip çizilir (kare maliyeti üç görüntü çizimi).
 *  - [shade]: siyah, saydamlık = 1 − aydınlık (çarpma): sarmalı Lambert (yumuşak gündüz/gece sınırı), gök ortam ışığı, kenar kararması.
 *  - [spec]: okyanus parlaması (GGX mikro yüzey dağılımı, Schlick Fresnel, Smith gölgeleme; su F0 = 0,02) ve kenarda göğün
 *    Fresnel yansıması. Karadan önce çizilir (kara mattır).
 *  - [atmo]: atmosfer kabuğu boyunca optik derinlik (Rayleigh benzeri saçılma): diskin içinde kenara doğru artan mavi pus,
 *    dışında hale; gündüz/gece sınırında gün batımı kızıllığı. En son çizilir.
 * Görüntüler [size]×[size], merkez ortada; birim küre yarıçapı [radiusPx] = size / 2 / (1 + [H]).
 */
class GlobeShading(val size: Int, look: GlobeLook) {
    val radiusPx = size / 2f / (1f + H)
    val shade = IntArray(size * size)
    val spec = IntArray(size * size)
    val atmo = IntArray(size * size)

    init {
        val lx = LX; val ly = LY; val lz = LZ
        val hv = norm(lx, ly, lz + 1f)
        val shadeK = (look.shade * 1.9f).coerceIn(0f, 0.9f)
        val specK = look.specular
        val atmA = Rgb.a(look.atmosphere) / 255f
        val atmCol = look.atmosphere or (0xFF shl 24)
        val sky = Rgb.lerp(atmCol, Rgb.WHITE, 0.35f)
        val sun = 0xFFFFF6E8.toInt()
        val dusk = 0xFFFF8A4C.toInt()
        val outer = (1f + H) * (1f + H)
        for (py in 0 until size) for (px in 0 until size) {
            val u = (px + 0.5f - size / 2f) / radiusPx
            val v = -(py + 0.5f - size / 2f) / radiusPx
            val rho2 = u * u + v * v
            val o = py * size + px
            if (rho2 < 1f) {
                val nz = sqrt(1f - rho2)
                val ndl = u * lx + v * ly + nz * lz
                // sarmalı Lambert + yumuşak geçiş: gündüz/gece sınırı keskin değil, atmosfer ışığı biraz geceye taşar
                val wrap = ((ndl + 0.18f) / 1.18f).coerceIn(0f, 1f)
                val diff = wrap * wrap * (3f - 2f * wrap)
                val ambient = 0.22f + 0.08f * nz
                val limb = 0.80f + 0.20f * sqrt(nz)
                val light = (ambient + (1f - ambient) * diff) * limb
                shade[o] = argbA(0xFF000814.toInt(), ((1f - light) * shadeK).coerceIn(0f, 0.92f))
                // okyanus parlaması: GGX
                if (specK > 0f) {
                    val ndh = (u * hv[0] + v * hv[1] + nz * hv[2]).coerceAtLeast(0f)
                    val vdh = hv[2].coerceAtLeast(0f)
                    val a = 0.11f; val a2 = a * a
                    val dd = ndh * ndh * (a2 - 1f) + 1f
                    val d = a2 / (Math.PI.toFloat() * dd * dd)
                    val f = 0.02f + 0.98f * (1f - vdh).pow(5)
                    val k = (a + 1f) * (a + 1f) / 8f
                    val nl = ndl.coerceAtLeast(0f); val nv = nz
                    val g = nv / (nv * (1f - k) + k) * nl / (nl * (1f - k) + k)
                    val glint = d * f * g / (4f * nv * nl + 1e-3f) * nl * 3.2f
                    val fres = 0.02f + 0.98f * (1f - nv).pow(5)
                    val skyR = fres * 0.55f * (0.25f + 0.75f * diff)
                    val tot = glint + skyR
                    val al = (1f - exp(-tot)) * specK
                    val c = if (tot > 0f) Rgb.lerp(sky, sun, (glint / tot).coerceIn(0f, 1f)) else sky
                    spec[o] = argbA(c, al.coerceIn(0f, 0.95f))
                }
            }
            // atmosfer: kabuktaki yol uzunluğu → optik derinlik
            if (atmA > 0f && rho2 < outer) {
                val shell = sqrt(outer - rho2)
                val path = if (rho2 < 1f) shell - sqrt(1f - rho2) else 2f * shell
                val rho = sqrt(rho2)
                val tau = 0.55f * path / H * (if (rho2 < 1f) 1f else exp(-(rho - 1f) / H * 2.2f))
                // kabuk noktasının normali (yaklaşık): ışığa bakan kenar parlak, gece kenarı sönük
                val an = 1f / maxOf(rho, 1e-3f)
                val nx = u * an * minOf(rho, 1f); val ny = v * an * minOf(rho, 1f); val nzz = sqrt((1f - minOf(rho2, 1f)).coerceAtLeast(0f))
                val al = nx * lx + ny * ly + nzz * lz
                val lit = ((al + 0.35f) / 0.75f).coerceIn(0f, 1f)
                val glow = (1f - exp(-tau)) * (0.12f + 0.88f * lit * lit) * atmA * 1.6f
                val sunset = exp(-((al - 0.05f) / 0.14f).let { it * it }) * 0.75f
                val c = Rgb.lerp(atmCol, dusk, sunset)
                atmo[o] = argbA(c, glow.coerceIn(0f, 0.9f))
            }
        }
    }

    companion object {
        /** Atmosfer kalınlığı (küre yarıçapına oranla). */
        const val H = 0.08f
        // Işık yönü (görünüm uzayı, sol üst önden); GlobeNode ile aynı
        private val L = norm(-0.45f, 0.55f, 0.70f)
        val LX = L[0]; val LY = L[1]; val LZ = L[2]
        fun norm(x: Float, y: Float, z: Float): FloatArray { val l = sqrt(x * x + y * y + z * z); return floatArrayOf(x / l, y / l, z / l) }
        private fun argbA(c: Int, a: Float): Int = ((a * 255f + 0.5f).toInt().coerceIn(0, 255) shl 24) or (c and 0xFFFFFF)
    }
}
