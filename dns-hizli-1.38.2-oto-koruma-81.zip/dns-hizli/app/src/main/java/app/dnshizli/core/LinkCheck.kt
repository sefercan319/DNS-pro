package app.dnshizli.core

import java.net.IDN
import java.util.Locale

/**
 * Dolandırıcılık mesajı koruması: SMS / mesaj metnindeki bağlantıları tıklamadan önce denetler. Tamamen cihazda çalışır, ağa çıkmaz,
 * metin saklanmaz. Kanıtlar:
 *  - engel listeleri (seçili seviye + kullanıcı listesi; zararlı / kimlik avı adları),
 *  - marka adının resmî olmayan alanda kullanılması ("ziraat-bonus.com", "ptt-kargo-teslim.xyz"),
 *  - resmî alana benzeyen ad (tek harf farkı, 0/o 1/l rn/m vv/w, Türkçe harf taklidi "zıraatbank"),
 *  - punycode (xn--) ve karışık alfabe (Kiril + Latin), adres yerine çıplak IP, "kullanıcı@" hilesi, kısaltılmış bağlantı (hedef görünmez),
 *    kötüye kullanımı yüksek uzantı, şifresiz http, .apk indirme, alışılmadık port, çok katlı alt alan, "giriş/doğrula/ödeme/iade/ceza" sözcükleri.
 * Sonuç ([Level]) en kötü kanıta göredir; bulunamaması "güvenli" demek değildir (yeni açılmış kimlik avı sitesi listede olmayabilir).
 */
object LinkCheck {
    enum class Level { OK, CAUTION, DANGER }

    enum class Reason(val level: Level) {
        BLOCKLIST(Level.DANGER), BRAND_ELSEWHERE(Level.DANGER), LOOKALIKE(Level.DANGER), MIXED_SCRIPT(Level.DANGER),
        IP_HOST(Level.DANGER), USERINFO(Level.DANGER), APK(Level.DANGER),
        BRAND_HINT(Level.CAUTION), PUNYCODE(Level.CAUTION), SHORTENER(Level.CAUTION), RISKY_TLD(Level.CAUTION), NO_TLS(Level.CAUTION),
        ODD_PORT(Level.CAUTION), DEEP_SUBDOMAIN(Level.CAUTION), BAIT_WORDS(Level.CAUTION),
    }

    class Finding(val reason: Reason, val detail: String = "")
    class Result(val url: String, val host: String?, val registrable: String?, val level: Level, val findings: List<Finding>)

    /** Marka → resmî kayıtlı alan adları. Kısa (≤ 4 harf) markalar yalnız tire ile ayrılmış parça olarak aranır (yanlış alarm azalır). */
    internal val BRANDS: Map<String, Set<String>> = mapOf(
        "ziraat" to setOf("ziraatbank.com.tr", "ziraatkatilim.com.tr", "ziraatyatirim.com.tr"),
        "isbank" to setOf("isbank.com.tr"),
        "garanti" to setOf("garantibbva.com.tr", "garanti.com.tr", "garantibbvaemeklilik.com.tr"),
        "akbank" to setOf("akbank.com"),
        "yapikredi" to setOf("yapikredi.com.tr"),
        "halkbank" to setOf("halkbank.com.tr"),
        "vakifbank" to setOf("vakifbank.com.tr"),
        "denizbank" to setOf("denizbank.com"),
        "enpara" to setOf("enpara.com"),
        "papara" to setOf("papara.com"),
        "qnb" to setOf("qnb.com.tr", "qnbfinansbank.com", "finansbank.com.tr"),
        "ptt" to setOf("ptt.gov.tr", "pttavm.com"),
        "edevlet" to setOf("turkiye.gov.tr"),
        "turkiye-gov" to setOf("turkiye.gov.tr"),
        "sgk" to setOf("sgk.gov.tr"),
        "gib" to setOf("gib.gov.tr"),
        "hgs" to setOf("ptt.gov.tr", "kgm.gov.tr"),
        "yurticikargo" to setOf("yurticikargo.com"),
        "araskargo" to setOf("araskargo.com.tr"),
        "mngkargo" to setOf("mngkargo.com.tr"),
        "trendyol" to setOf("trendyol.com"),
        "hepsiburada" to setOf("hepsiburada.com"),
        "sahibinden" to setOf("sahibinden.com"),
        "turkcell" to setOf("turkcell.com.tr"),
        "vodafone" to setOf("vodafone.com.tr", "vodafone.com"),
        "turktelekom" to setOf("turktelekom.com.tr"),
        "paypal" to setOf("paypal.com"),
        "netflix" to setOf("netflix.com"),
        "instagram" to setOf("instagram.com"),
        "whatsapp" to setOf("whatsapp.com", "whatsapp.net"),
        "icloud" to setOf("icloud.com", "apple.com"),
        "amazon" to setOf("amazon.com.tr", "amazon.com"),
    )
    /** Küresel markalar: ülke uzantılı resmî alanları ve CDN adları çok; başka alanda geçmeleri yalnız dikkat işaretidir. */
    private val GLOBAL = setOf("paypal", "netflix", "instagram", "whatsapp", "icloud", "amazon", "vodafone")
    /** Markaların bilinen yardımcı/CDN alanları (marka adı geçer ama resmîdir). */
    private val KNOWN_AUX = setOf(
        "amazonaws.com", "amazontrust.com", "media-amazon.com", "cdninstagram.com", "paypalobjects.com", "paypal.me", "icloud-content.com",
        "nflxvideo.net", "nflximg.net", "netflix.net", "whatsapp.net", "nflxext.com",
    )
    private val OFFICIAL: Set<String> = BRANDS.values.flatten().toSet() + KNOWN_AUX

    private val SHORTENERS = setOf(
        "bit.ly", "tinyurl.com", "t.co", "cutt.ly", "rb.gy", "is.gd", "shorturl.at", "t.ly", "ow.ly", "buff.ly", "s.id", "tiny.cc",
        "rebrand.ly", "bl.ink", "short.io", "goo.su", "clck.ru", "v.gd", "qrco.de", "urlz.fr", "lnkd.in", "shorturl.gg",
    )
    private val BAIT = listOf(
        "giris", "login", "signin", "dogrula", "verify", "guncelle", "update", "odeme", "payment", "iade", "refund", "ceza", "borc",
        "aidat", "teslimat", "kargo", "hesap", "sifre", "password", "kampanya", "hediye", "odul", "bonus", "puan", "secure", "onay",
    )
    private val TR_SECOND = setOf("com", "net", "org", "gov", "edu", "gen", "web", "biz", "info", "av", "bel", "k12", "pol", "tsk", "bbs", "name", "tel", "dr", "kep")

    private val URL_RE = Regex("""(?i)(?<![\p{L}\p{N}_.\-])(?:https?://[^\s<>"'()]+|(?:[a-z0-9¡-￿](?:[a-z0-9¡-￿-]{0,61}[a-z0-9¡-￿])?\.)+(?:[a-z]{2,24}|xn--[a-z0-9-]{2,20})(?:[:/][^\s<>"'()]*)?)""")

    /** Metindeki bağlantılar (en çok [max]); sondaki noktalama atılır. E-posta adresleri bağlantı sayılmaz. */
    /** Denetlenen en uzun metin: düzenli ifade, saldırganın yazdığı dev mesajda zaman harcamasın (bildirim dinleyicisi de kullanır). */
    const val MAX_TEXT = 4096

    fun extract(text0: String, max: Int = 10): List<String> {
        val text = if (text0.length > MAX_TEXT) text0.substring(0, MAX_TEXT) else text0
        val out = ArrayList<String>()
        for (m in URL_RE.findAll(text)) {
            if (m.range.first > 0 && text[m.range.first - 1] == '@') continue
            val u = m.value.trimEnd('.', ',', ';', ':', '!', '?', ')', ']', '}', '"', '\'', '»')
            if (!u.contains('.')) continue
            out.add(u)
            if (out.size >= max) break
        }
        return out
    }

    /** [verdict]: ad için süzgeç kararı ([FilterVerdict]); yoksa -1. */
    fun check(raw: String, verdict: (String) -> Int = { -1 }): Result {
        val f = ArrayList<Finding>()
        val url = if (raw.contains("://")) raw else "http://$raw"
        val scheme = url.substringBefore("://").lowercase(Locale.ROOT)
        val rest = url.substringAfter("://")
        val authority = rest.substringBefore('/').substringBefore('\\').substringBefore('?').substringBefore('#')
        val path = rest.substring(authority.length).lowercase(Locale.ROOT)
        if (authority.contains('@')) f.add(Finding(Reason.USERINFO, authority.substringBefore('@')))
        // Tarayıcılar ana makine adındaki %xx kodlamasını açar ve ters bölüyü bölü sayar: denetim de aynı adı görmeli
        val hostPort = pctDecode(authority.substringAfterLast('@'))
        val host0 = if (hostPort.startsWith("[")) hostPort.substringBefore(']') + "]" else hostPort.substringBefore(':')
        val port = if (hostPort.startsWith("[")) hostPort.substringAfter("]", "").removePrefix(":") else hostPort.substringAfter(':', "")
        if (scheme == "http" && raw.contains("://")) f.add(Finding(Reason.NO_TLS))
        if (port.isNotEmpty() && port != "443" && port != "80") f.add(Finding(Reason.ODD_PORT, port))
        if (path.substringBefore('?').endsWith(".apk")) f.add(Finding(Reason.APK))
        val bare = host0.trim('[', ']')
        if (Ip.parse(bare) != null) { f.add(Finding(Reason.IP_HOST, bare)); return result(raw, bare, null, f) }
        val unicode = try { IDN.toUnicode(host0, IDN.ALLOW_UNASSIGNED) } catch (_: Exception) { host0 }
        val ascii = try { IDN.toASCII(unicode, IDN.ALLOW_UNASSIGNED) } catch (_: Exception) { null }
        val host = (ascii ?: host0).lowercase(Locale.ROOT).trimEnd('.')
        if (host.isEmpty() || !host.contains('.')) return result(raw, null, null, f)
        val uni = unicode.lowercase(Locale.ROOT).trimEnd('.')
        if (host.split('.').any { it.startsWith("xn--") }) {
            if (mixedScript(uni)) f.add(Finding(Reason.MIXED_SCRIPT, uni)) else f.add(Finding(Reason.PUNYCODE, uni))
        }
        val reg = registrable(host)
        when (verdict(host)) { FilterVerdict.LIST, FilterVerdict.USER -> f.add(Finding(Reason.BLOCKLIST, host)) }
        if (host in SHORTENERS || reg in SHORTENERS) f.add(Finding(Reason.SHORTENER, reg))
        val tld = host.substringAfterLast('.')
        if (tld in AdSuspect.RISKY_TLDS || tld in COMMON_ABUSED) f.add(Finding(Reason.RISKY_TLD, ".$tld"))
        val labels = host.split('.')
        if (labels.size >= 5) f.add(Finding(Reason.DEEP_SUBDOMAIN, host))
        val official = reg in OFFICIAL || OFFICIAL.any { host.endsWith(".$it") }
        if (!official) {
            brandChecks(host, uni, reg, f)
            // tuzak sözcükler resmî adreste olağandır ("giris", "login"); yalnız resmî olmayan alanda işarettir
            val words = BAIT.filter { path.contains(it) || labels.dropLast(1).any { l -> l.contains(it) } }
            if (words.isNotEmpty()) f.add(Finding(Reason.BAIT_WORDS, words.take(3).joinToString(", ")))
        }
        return result(raw, host, reg, f)
    }

    private fun pctDecode(s: String): String {
        if (!s.contains('%')) return s
        val out = java.io.ByteArrayOutputStream()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '%' && i + 2 < s.length && s.substring(i + 1, i + 3).all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) {
                out.write(s.substring(i + 1, i + 3).toInt(16)); i += 3
            } else { out.write(c.toString().toByteArray(Charsets.UTF_8)); i++ }
        }
        return String(out.toByteArray(), Charsets.UTF_8)
    }

    private val COMMON_ABUSED = setOf("top", "xyz", "online", "site", "space", "click", "website", "pw", "bid", "win", "loan", "work", "live", "shop", "info", "vip", "lol")

    private fun result(raw: String, host: String?, reg: String?, f: List<Finding>): Result {
        var lv = f.maxOfOrNull { it.reason.level } ?: Level.OK
        // Birleşen işaretler: kısa marka adı başka işaretle birlikteyse ya da üç ayrı uyarı varsa tehlike
        val cautions = f.count { it.reason.level == Level.CAUTION && it.reason != Reason.NO_TLS }
        if (lv == Level.CAUTION && (f.any { it.reason == Reason.BRAND_HINT } && cautions >= 2 || cautions >= 3)) lv = Level.DANGER
        return Result(raw, host, reg, lv, f.sortedByDescending { it.reason.level })
    }

    /** Kayıt edilebilir alan (eTLD+1): genel sonek listesi yüklüyse ondan, değilse .tr ikinci düzeyleri bilinerek. */
    fun registrable(host: String): String {
        val b = host.toByteArray(Charsets.ISO_8859_1)
        val s = PublicSuffix.registrableStart(b, b.size)
        if (s >= 0) return host.substring(s)
        val l = host.split('.')
        if (l.size >= 3 && l.last() == "tr" && l[l.size - 2] in TR_SECOND) return l.takeLast(3).joinToString(".")
        return l.takeLast(2).joinToString(".")
    }

    /** Türkçe harfler ve sık taklit edilen karakterler sadeleştirilir (ı→i, 0→o, rn→m, vv→w…). */
    internal fun skeleton(s: String): String {
        val t = StringBuilder()
        for (c in s) t.append(when (c) { 'ı', 'í', 'ì', 'î', 'ï', '1', 'l', '|' -> 'i'; 'ç' -> 'c'; 'ğ' -> 'g'; 'ö', 'ó', 'ò', 'ô', '0' -> 'o'; 'ş' -> 's'; 'ü', 'ú', 'ù', 'û' -> 'u'
            'а' -> 'a'; 'е' -> 'e'; 'о' -> 'o'; 'р' -> 'p'; 'с' -> 'c'; 'х' -> 'x'; 'у' -> 'y'; 'і' -> 'i'; 'к' -> 'k'; 'м' -> 'm'; 'н' -> 'h'; 'т' -> 't'; 'в' -> 'b'
            '-', '_' -> ' '; else -> c })
        return t.toString().replace("rn", "m").replace("vv", "w").replace(" ", "")
    }

    private fun mixedScript(s: String): Boolean {
        var latin = false; var other = false
        for (c in s) {
            if (!c.isLetter()) continue
            val sc = Character.UnicodeScript.of(c.code)
            if (sc == Character.UnicodeScript.LATIN) latin = true else other = true
        }
        return latin && other
    }

    private fun sld(reg: String): String = reg.substringBefore('.')

    private fun brandChecks(host: String, uni: String, reg: String, f: MutableList<Finding>) {
        val parts = host.removeSuffix(reg.substringAfter('.')).split('.', '-').filter { it.isNotEmpty() }
        val regLabel = sld(reg)
        val skel = skeleton(sld(registrableUnicode(uni, reg)))
        // önce taklit (resmî adın kendisine benzeyen ad), sonra marka adının başka alanda geçmesi
        for ((_, officials) in BRANDS) {
            for (o in officials) {
                val os = sld(o)
                if (os.length < 5) continue
                if (skel == skeleton(os) && regLabel != os) { f.add(Finding(Reason.LOOKALIKE, o)); return }
                val d = distance(regLabel, os)
                if (regLabel != os && ((os.length >= 6 && d == 1) || (os.length >= 10 && d == 2))) { f.add(Finding(Reason.LOOKALIKE, o)); return }
            }
        }
        for ((brand, officials) in BRANDS) {
            val b = brand.replace("-", "")
            if (brand in GLOBAL && regLabel == b) continue                // amazon.de, vodafone.de, netflix.ca: ülke alanı
            val strong = b.length >= 5 && brand !in GLOBAL
            val inHost = if (strong) skeleton(host).contains(skeleton(b)) || host.replace("-", "").contains(b)
                else if (brand in GLOBAL) host.replace("-", "").contains(b)
                else parts.any { it == b } || compound(host, reg, b)
            // kısa marka tuzak sözcükle birleşik ("pttkargo", "sgkborc", "qnbmobil", "gibodeme"): taklit kadar güçlü işaret
            if (!strong && brand !in GLOBAL && compound(host, reg, b)) { f.add(Finding(Reason.BRAND_ELSEWHERE, brand + " ≠ " + officials.first())); return }
            if (inHost) { f.add(Finding(if (strong) Reason.BRAND_ELSEWHERE else Reason.BRAND_HINT, brand + " ≠ " + officials.first())); return }
        }
    }

    /** Kısa markanın tuzak sözcükle tek etikette birleşmesi (önce ya da sonra; tire yok sayılır). */
    private val COMPOUND = listOf("kargo", "odeme", "borc", "iade", "giris", "mobil", "destek", "bonus", "hediye", "ceza", "sorgu", "teslim",
        "online", "guvenlik", "onay", "dogrula", "hesap", "sube", "bilgi", "basvuru", "tahsilat", "fatura")
    private fun compound(host: String, reg: String, b: String): Boolean {
        val labels = host.removeSuffix(reg.substringAfter('.')).trimEnd('.').split('.').map { it.replace("-", "") }
        return labels.any { l -> l.length > b.length && (l.startsWith(b) && COMPOUND.any { w -> l.substring(b.length).startsWith(w) } ||
            l.endsWith(b) && COMPOUND.any { w -> l.substring(0, l.length - b.length).endsWith(w) }) }
    }

    private fun registrableUnicode(uni: String, reg: String): String {
        val n = reg.count { it == '.' } + 1
        return uni.split('.').takeLast(n).joinToString(".")
    }

    /** Damerau-Levenshtein (komşu yer değiştirme dahil). */
    internal fun distance(a: String, b: String): Int {
        if (kotlin.math.abs(a.length - b.length) > 2) return 3
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length) {
            val c = if (a[i - 1] == b[j - 1]) 0 else 1
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c)
            if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) d[i][j] = minOf(d[i][j], d[i - 2][j - 2] + 1)
        }
        return d[a.length][b.length]
    }
}
