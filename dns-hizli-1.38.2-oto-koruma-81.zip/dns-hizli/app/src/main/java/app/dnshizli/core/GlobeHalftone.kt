package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.round
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Kara üzerindeki yarım ton noktaları: küreye sabitlenmiş enlem halkası ızgarası (halka aralığı Δ, halkada ~2π·cosφ/Δ nokta,
 * tek halkalar yarım adım kaydırılmış: altıgen düzen). Düzey k'de Δ = π / (64·2^k): yakınlaştıkça ızgara iki kat sıklaşır,
 * iki düzey saydamlıkla karışır, noktalar kaymaz. Yalnız ekranda görünebilecek enlem ve boylam aralığı üretilir; kaba kara
 * maskesinde deniz olan noktalar atlanır (kesin şekli kara yolu kırpar).
 */
object GlobeHalftone {
    const val BASE_RINGS = 64
    /** Ekranda en sık nokta aralığı (dp); düzeyler bunun 1..2 katı arasında. */
    const val MIN_SPACING = 1.25f

    /** Yarıçap [r] (dp) için kaba düzey ve ince düzeyin karışım payı (0..1). */
    fun levelFor(r: Float): Pair<Int, Float> {
        val k = floor(ln(PI * r / (BASE_RINGS * MIN_SPACING)) / ln(2.0)).toInt().coerceAtLeast(0)
        val s = (PI / (BASE_RINGS shl k) * r).toFloat()
        return k to ((s / MIN_SPACING - 1f).coerceIn(0f, 1f))
    }

    /** Düzey [k] ızgarasının küre üzerindeki toplam nokta sayısı. */
    fun totalPoints(k: Int): Long {
        val m = BASE_RINGS shl k; val d = PI / m; var n = 0L
        for (j in 0 until m) n += max(1, round(2 * PI * cos(-PI / 2 + (j + 0.5) * d) / d).toInt())
        return n
    }

    /**
     * Düzey [k] noktalarını ekran koordinatı olarak [out]'a yazar (x, y ardışık); sayıyı döner. [m]: kamera matrisi,
     * merkez ([cx], [cy]), yarıçap [r], görünüm [w]×[h]; [lat0]/[lon0]: ekran merkezindeki nokta; [map] null değilse kaba maskeyle eler.
     */
    fun generate(k: Int, m: FloatArray, lat0: Double, lon0: Double, cx: Float, cy: Float, r: Float, w: Float, h: Float,
                 map: GlobeLand.VecMap?, out: Buf, limit: Int = 600_000): Int {
        val rings = BASE_RINGS shl k
        val d = PI / rings
        val hd = sqrt(w * w + h * h) / 2f / r
        val alpha = if (hd >= 0.999f) PI / 2 else asin(hd.toDouble()) + d
        val sinC = sin(lat0); val cosC = cos(lat0)
        val jLo = max(0, floor((lat0 - alpha + PI / 2) / d - 0.5).toInt())
        val jHi = minOf(rings - 1, floor((lat0 + alpha + PI / 2) / d + 0.5).toInt())
        val cosA = cos(alpha)
        var n = 0
        val pad = 3f
        for (j in jLo..jHi) {
            val phi = -PI / 2 + (j + 0.5) * d
            val sp = sin(phi); val cp = cos(phi)
            val cnt = max(1, round(2 * PI * cp / d).toInt())
            val dl = 2 * PI / cnt
            val off = if (j and 1 == 1) 0.5 else 0.0
            val iFrom: Int; val iTo: Int
            if (alpha >= PI / 2 - 1e-9 || cp < 1e-9 || cosC < 1e-9) { iFrom = 0; iTo = cnt - 1 }
            else {
                val c = (cosA - sp * sinC) / (cp * cosC)
                if (c >= 1.0) continue
                if (c <= -1.0) { iFrom = 0; iTo = cnt - 1 }
                else {
                    val half = acos(c) + dl
                    iFrom = floor((lon0 - half + PI) / dl - off).toInt(); iTo = floor((lon0 + half + PI) / dl - off).toInt() + 1
                    if (iTo - iFrom >= cnt) { /* tüm halka */ }
                }
            }
            val span = minOf(iTo - iFrom, cnt - 1)
            val row = ((PI / 2 - phi) / PI * GlobeVec.MASK_H).toInt().coerceIn(0, GlobeVec.MASK_H - 1)
            val spf = sp.toFloat(); val cpf = cp.toFloat()
            // boylamı artımlı döndür (nokta başına trigonometri yok)
            val lam0 = -PI + (iFrom + off) * dl
            var cl = cos(lam0); var sl = sin(lam0)
            val cd = cos(dl); val sd = sin(dl)
            var lam = lam0
            for (q in 0..span) {
                if (map == null || map.maybeLandRC(row, lam)) {
                    val wx = cpf * cl.toFloat(); val wy = cpf * sl.toFloat()
                    val z = m[6] * wx + m[7] * wy + m[8] * spf
                    if (z > 0.01f) {
                        val sx = cx + r * (m[0] * wx + m[1] * wy + m[2] * spf)
                        val sy = cy - r * (m[3] * wx + m[4] * wy + m[5] * spf)
                        if (sx > -pad && sx < w + pad && sy > -pad && sy < h + pad) {
                            out.add(sx, sy); n++
                            if (n >= limit) return n
                        }
                    }
                }
                val ncl = cl * cd - sl * sd; sl = sl * cd + cl * sd; cl = ncl
                lam += dl
            }
        }
        return n
    }

    /** Büyüyen kayan nokta tamponu (x, y çiftleri). */
    class Buf { var a = FloatArray(8192); var n = 0
        fun clear() { n = 0 }
        fun add(x: Float, y: Float) { if (2 * n + 2 > a.size) a = a.copyOf(a.size * 2); a[2 * n] = x; a[2 * n + 1] = y; n++ } }
}
