package app.dnshizli.ui

import app.dnshizli.core.ALIGN_CENTER
import app.dnshizli.core.Catalog
import app.dnshizli.core.DnsServer
import app.dnshizli.core.Gfx
import app.dnshizli.core.GlobeCamera
import app.dnshizli.core.Fill
import app.dnshizli.core.GlobeLand
import app.dnshizli.core.Pic
import app.dnshizli.core.GPath
import app.dnshizli.core.GlobeShading
import app.dnshizli.core.GlobeHalftone
import app.dnshizli.core.GlobeLook
import app.dnshizli.core.GlobeSites
import app.dnshizli.core.Rgb
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Sunucu küresi: sürükleyerek döndür, iki parmakla (ya da çift dokunarak) yakınlaştır, noktaya dokununca o sağlayıcının
 * sunucuları altta listelenir; listeden dokununca bağlanır. Anycast sağlayıcılar merkezlerinde halka ile, tek konumlular dolu nokta ile.
 */
class GlobePage(private val model: AppModel, nav: Nav) : ScrollPage(Strings.GLOBE, true, nav) {
    private val globe = GlobeNode(model) { onPick(it) }
    private val hint = Label(Strings.GLOBE_HINT, 13f, ink = Ink.SOFT, align = ALIGN_CENTER, maxLines = 2)
    private val title = Label("", 18f, bold = true, maxLines = 1, shrink = true)
    private val place = Label("", 13f, ink = Ink.SOFT, maxLines = 2)
    private val rows = Column(gap = M.ROW_GAP)
    private val unknownHead = Label(Strings.GLOBE_UNKNOWN, 15f, bold = true)
    private val unknown = Column(gap = M.ROW_GAP)
    private val rowCache = HashMap<String, ServerRow>()
    private var seen = -1
    private var picked: String? = null

    init {
        col.add(globe)
        col.add(hint)
        col.add(title)
        col.add(place)
        col.add(rows)
        col.add(unknownHead)
        col.add(unknown)
        finish()
        GlobeLand.warm()
        // Başlangıçta bağlı/seçili sunucunun markası seçili gelir.
        Catalog.byId(model.selectedId())?.let { s -> if (GlobeSites.of(s) != null) picked = s.brand }
        picked?.let { b -> GlobeSites.siteOfBrand(b)?.let { globe.camera.focus(Math.toRadians(it.lat), Math.toRadians(it.lon)) } }
    }

    private fun row(s: DnsServer) = rowCache.getOrPut(s.id) { ServerRow(s) { nav.openDetails(it) } }

    private fun onPick(brand: String?) {
        picked = brand; seen = -1
        brand?.let { GlobeSites.siteOfBrand(it) }?.let { globe.camera.flyTo(Math.toRadians(it.lat), Math.toRadians(it.lon)) }
    }

    val selectedBrand: String? get() = picked

    override fun tick(dt: Float, env: Env): Boolean {
        if (seen != model.version || globe.selected != picked) {
            seen = model.version
            globe.selected = picked
            val visible = model.visibleServers()
            rows.removeAll()
            val b = picked
            if (b != null) {
                val site = GlobeSites.siteOfBrand(b)
                title.text = b
                place.text = site?.let { Strings.globePlace(it.place) + " · " + (if (it.anycast) Strings.GLOBE_ANYCAST else Strings.GLOBE_UNICAST) } ?: ""
                for (s in visible) if (s.brand == b && GlobeSites.of(s) != null) rows.add(row(s))
            } else { title.text = Strings.GLOBE_PICK; place.text = "" }
            unknown.removeAll()
            for (s in visible) if (GlobeSites.of(s) == null) unknown.add(row(s))
            unknownHead.visible = unknown.children.isNotEmpty()
            relayoutContent(env)
        }
        return super.tick(dt, env)
    }
}

class GlobeNode(private val model: AppModel, private val onPick: (String?) -> Unit) : Node(), Pinchable {
    val camera = GlobeCamera()
    var selected: String? = null
    private val p = GlobeCamera.P()
    private var lastX = 0f; private var lastY = 0f; private var lastT = 0f
    private var downX = 0f; private var downY = 0f
    private var active = false
    private var lastTapAt = -10f
    private var clock = 0f
    private var lastPinchT = -10f
    private var brands: List<String> = emptyList()
    private var lats = DoubleArray(0); private var lons = DoubleArray(0)
    private var brandsVersion = -1
    private val m = FloatArray(9)
    private val ll = DoubleArray(2)
    private class Label3(val text: String, val x: Float, val top: Float, val prio: Int)
    private val labelReq = ArrayList<Label3>()
    private val placed = ArrayList<FloatArray>()

    // Kare başına yeniden kullanılan tamponlar (bellek ayırma yok)
    private val groupPath = Array(4) { GPath() }
    private val landPath = GPath()
    private var ring = FloatArray(4096)
    private var seg = FloatArray(4096)
    private var segN = 0
    private val dots = GlobeHalftone.Buf()
    private val dots2 = GlobeHalftone.Buf()
    private var arcThr = IntArray(0)
    private var dotLevel = -1; private var prevLevel = -1; private var dotFade = 1f
    private fun spacingOf(k: Int, r: Float): Float = (Math.PI / (GlobeHalftone.BASE_RINGS shl k) * r).toFloat()

    // Işık katmanları (dönüşten bağımsız; görünüm/stil değişince yeniden)
    private var shading: GlobeShading? = null
    private var shadingLook: GlobeLook? = null
    private var picShade: Pic? = null; private var picSpec: Pic? = null; private var picAtmo: Pic? = null

    /** Son çizimin istatistikleri (test ve ayar için). */
    var lastDots = 0; private set
    var lastVertices = 0; private set
    var lastBorderSegs = 0; private set

    override val dragCapture: Boolean get() = true
    override val dragActive: Boolean get() = active
    override val dragAll: Boolean get() = true
    override val tappable: Boolean get() = true

    private val cx get() = w / 2f
    private val cy get() = h / 2f
    /** Yakınlaştırma 1'deki yarıçap (atmosfer halesi sığsın diye kenardan pay). */
    private val baseRadius: Float get() = minOf(w, h) / 2f / (1f + GlobeShading.H) - 6f
    /** Kürenin ekrandaki yarıçapı (yakınlaştırmayla büyür; görünüm dışına taşan kısım kırpılır). */
    val radius: Float get() = baseRadius * camera.zoom.toFloat()

    override fun layout(env: Env, maxW: Float) { w = maxW; h = minOf(maxW, 440f) }

    private fun syncBrands() {
        if (brandsVersion == model.version) return
        brandsVersion = model.version
        brands = GlobeSites.brands(model.visibleServers())
        lats = DoubleArray(brands.size) { GlobeSites.siteOfBrand(brands[it])!!.lat }
        lons = DoubleArray(brands.size) { GlobeSites.siteOfBrand(brands[it])!!.lon }
    }

    /** Noktanın ekran konumu (yerel dp); arka yüzdeyse null. Test ve dokunma için. */
    fun screenOf(brand: String): Pair<Float, Float>? {
        val s = GlobeSites.siteOfBrand(brand) ?: return null
        camera.project(Math.toRadians(s.lat), Math.toRadians(s.lon), p)
        if (p.z <= 0.05) return null
        return (cx + radius * p.x.toFloat()) to (cy - radius * p.y.toFloat())
    }

    override fun tick(dt: Float, env: Env): Boolean {
        clock += dt
        val moving = camera.tick(dt.toDouble(), env.ambient && env.motion > 0f)
        val fading = dotFade < 1f
        if (fading) dotFade = if (env.motion <= 0f) 1f else minOf(1f, dotFade + dt / 0.28f)
        return moving || active || fading || !GlobeLand.ready
    }

    override fun ambient(env: Env): Boolean = env.ambient && env.motion > 0f

    override fun onDown(lx: Float, ly: Float, env: Env) {
        active = true
        downX = lx; downY = ly; lastX = lx; lastY = ly; lastT = clock
        camera.beginDrag()
    }

    override fun onDrag(lx: Float, ly: Float, env: Env) {
        val dt = (clock - lastT).toDouble()
        if (lx == lastX && ly == lastY) return
        camera.dragBy((lx - lastX).toDouble(), (ly - lastY).toDouble(), radius.toDouble(), if (dt > 0) dt else 1.0 / 60)
        lastX = lx; lastY = ly; lastT = clock
    }

    override fun onUp(lx: Float, ly: Float, tap: Boolean, env: Env) {
        active = false
        camera.endDrag((clock - lastT).toDouble())
        val moved = (lx - downX) * (lx - downX) + (ly - downY) * (ly - downY) > 100f
        if (!tap || moved) return
        // Çift dokunma: dokunulan noktaya uçarak bir kademe yakınlaş
        if (clock - lastTapAt < 0.3f) {
            val r = radius.toDouble()
            if (camera.unproject((lx - cx) / r, (cy - ly) / r, ll)) camera.zoomStepAt(ll[0], ll[1]) else camera.zoomStep()
            lastTapAt = -10f; return
        }
        lastTapAt = clock
        syncBrands()
        val i = camera.pick(lx.toDouble(), ly.toDouble(), cx.toDouble(), cy.toDouble(), radius.toDouble(), lats, lons, 28.0)
        if (i >= 0) { env.tap(); onPick(brands[i]) }
    }

    override fun onCancel(env: Env) { active = false; camera.endDrag(1.0) }

    override fun onPinch(f: Float, cx: Float, cy: Float, env: Env) {
        val dt = (clock - lastPinchT).toDouble(); lastPinchT = clock
        camera.zoomAt(f.toDouble(), (cx - this.cx).toDouble(), (cy - this.cy).toDouble(), baseRadius.toDouble(), if (dt in 0.001..0.2) dt else 0.0)
    }

    private fun addSeg(x0: Float, y0: Float, x1: Float, y1: Float) {
        if (4 * segN + 4 > seg.size) seg = seg.copyOf(seg.size * 2)
        seg[4 * segN] = x0; seg[4 * segN + 1] = y0; seg[4 * segN + 2] = x1; seg[4 * segN + 3] = y1; segN++
    }

    /** Dünya vektörleri [xyz] üzerindeki çoklu çizgilerin ön yüzdeki parçaları (ızgara). */
    private fun polyline(xyz: FloatArray, start: Int, end: Int, r: Float) {
        var px = 0f; var py = 0f; var pv = false
        for (k in start until end) {
            val wx = xyz[3 * k]; val wy = xyz[3 * k + 1]; val wz = xyz[3 * k + 2]
            val z = m[6] * wx + m[7] * wy + m[8] * wz
            val x = cx + r * (m[0] * wx + m[1] * wy + m[2] * wz)
            val y = cy - r * (m[3] * wx + m[4] * wy + m[5] * wz)
            val v = z > 0.01f
            if (v && pv) addSeg(px, py, x, y)
            px = x; py = y; pv = v
        }
    }

    /**
     * Yayların bu karede kullanılacağı ayrıntı eşiği: ekranda görünebilen yaylar tam ([kmin]), arka yüzdeki ya da ekran dışındaki
     * yaylar kaba (halkalar kapanabilsin diye yine de gerekir). -1: hiç çizilmez (bu yay için dolgu bile gerekmez — kullanılmıyor).
     */
    private fun classify(map: GlobeLand.VecMap, r: Float, kmin: Int) {
        val n = map.arcCount
        if (arcThr.size < n) arcThr = IntArray(n)
        val vx = m[6]; val vy = m[7]; val vz = m[8]
        val hd = sqrt(w * w + h * h) / 2f / r
        val alpha = if (hd >= 1f) (Math.PI / 2).toFloat() else asin(hd)
        val ca = cos(alpha); val sa = sin(alpha)
        for (a in 0 until n) {
            val d = map.capX[a] * vx + map.capY[a] * vy + map.capZ[a] * vz          // cos(merkez–bakış açısı)
            val cr = map.capCos[a]; val sr = map.capSin[a]
            // açı(merkez, bakış) < α + yarıçap  ⇔  d > cos(α + yarıçap)
            val visible = d > ca * cr - sa * sr
            arcThr[a] = if (visible) kmin else COARSE
        }
    }

    /** Ülke halkalarını izdüşür (arka yüzdeki köşeler ufuk çemberine bastırılır) ve grup yollarına ekler. */
    private fun buildFills(map: GlobeLand.VecMap, r: Float) {
        for (gp in groupPath) gp.reset()
        landPath.reset()
        val xyz = map.xyz; val lev = map.level
        val m0 = m[0]; val m1 = m[1]; val m2 = m[2]; val m3 = m[3]; val m4 = m[4]; val m5 = m[5]; val m6 = m[6]; val m7 = m[7]; val m8 = m[8]
        var verts = 0
        for (c in 0 until map.countryCount) {
            val gp = groupPath[map.group[c] and 3]
            for (q in map.ringStart[c] until map.ringStart[c + 1]) {
                var n = 0; var front = false
                for (rr in map.refStart[q] until map.refStart[q + 1]) {
                    val ref = map.refs[rr]; val a = if (ref >= 0) ref else ref.inv()
                    val thr = arcThr[a]
                    val s = map.arcStart[a]; val e = map.arcStart[a + 1]
                    var k = if (ref >= 0) s else e - 1
                    val stepK = if (ref >= 0) 1 else -1
                    val count = e - s
                    for (t in 0 until count) {
                        val v = k; k += stepK
                        val lvl = lev[v].toInt()
                        if (lvl < thr && t != 0 && t != count - 1) continue
                        val wx = xyz[3 * v]; val wy = xyz[3 * v + 1]; val wz = xyz[3 * v + 2]
                        var x = m0 * wx + m1 * wy + m2 * wz
                        var y = m3 * wx + m4 * wy + m5 * wz
                        val z = m6 * wx + m7 * wy + m8 * wz
                        if (z < 0f) { val l = sqrt(x * x + y * y).coerceAtLeast(1e-6f); x /= l; y /= l } else front = true
                        if (2 * n + 2 > ring.size) ring = ring.copyOf(ring.size * 2)
                        ring[2 * n] = cx + r * x; ring[2 * n + 1] = cy - r * y; n++
                    }
                }
                if (!front || n < 3) continue
                verts += n
                gp.moveTo(ring[0], ring[1]); landPath.moveTo(ring[0], ring[1])
                for (i in 1 until n) { gp.lineTo(ring[2 * i], ring[2 * i + 1]); landPath.lineTo(ring[2 * i], ring[2 * i + 1]) }
                gp.close(); landPath.close()
            }
        }
        lastVertices = verts
    }

    /** Kıyı ya da sınır yaylarının ön yüzdeki parçaları. */
    private fun buildStrokes(map: GlobeLand.VecMap, r: Float, kind: Int) {
        segN = 0
        val xyz = map.xyz; val lev = map.level
        for (a in 0 until map.arcCount) {
            if (map.kind[a].toInt() != kind || arcThr[a] == COARSE) continue
            val thr = arcThr[a]
            val s = map.arcStart[a]; val e = map.arcStart[a + 1]
            var px = 0f; var py = 0f; var pv = false; var pSeam = false
            for (v in s until e) {
                if (lev[v] < thr && v != s && v != e - 1) continue
                // 180. boylam / Güney Kutbu kesimi boyunca uzanan parça gerçek kıyı değil: çizilmez
                val seam = GlobeLand.isSeam(xyz[3 * v], xyz[3 * v + 1], xyz[3 * v + 2])
                val wx = xyz[3 * v]; val wy = xyz[3 * v + 1]; val wz = xyz[3 * v + 2]
                val z = m[6] * wx + m[7] * wy + m[8] * wz
                val x = cx + r * (m[0] * wx + m[1] * wy + m[2] * wz)
                val y = cy - r * (m[3] * wx + m[4] * wy + m[5] * wz)
                val vis = z > 0f
                if (vis && pv && !(seam && pSeam)) addSeg(px, py, x, y)
                px = x; py = y; pv = vis; pSeam = seam
            }
        }
    }

    private fun ensureShading(g: Gfx, look: GlobeLook) {
        if (look.flat) return
        if (shadingLook === look && picShade != null) return
        val sh = GlobeShading(SHADE_PX, look)
        picShade?.release(); picSpec?.release(); picAtmo?.release()
        picShade = g.makePic(sh.shade, SHADE_PX, SHADE_PX)
        picSpec = if (look.specular > 0f) g.makePic(sh.spec, SHADE_PX, SHADE_PX) else null
        picAtmo = if (Rgb.a(look.atmosphere) > 0) g.makePic(sh.atmo, SHADE_PX, SHADE_PX) else null
        shading = sh; shadingLook = look
    }

    private fun layer(g: Gfx, pic: Pic?, r: Float) {
        val p = pic ?: return
        val R = r * (1f + GlobeShading.H)
        g.image(p, 0f, 0f, p.w.toFloat(), p.h.toFloat(), cx - R, cy - R, cx + R, cy + R)
    }

    override fun draw(g: Gfx, env: Env) {
        syncBrands()
        val r = radius
        val look = GlobeLook.of(env.theme, env.art.style)
        ensureShading(g, look)
        g.save()
        g.clipRect(0f, 0f, w, h)
        camera.matrix(m)
        // okyanus
        g.paint(if (look.flat) Rgb.lerp(look.oceanLit, look.oceanDeep, 0.55f) else Rgb.lerp(look.oceanLit, look.oceanDeep, 0.3f))
        g.circle(cx, cy, r)
        // enlem/boylam ızgarası
        if (Rgb.a(look.grid) > 0) {
            segN = 0
            val gl = GRID
            for (k in 0 until gl.count) polyline(gl.xyz, gl.start[k], gl.start[k + 1], r)
            g.paint(look.grid); g.strokeWidth(0.8f); g.lines(seg, segN)
        }
        // okyanus parlaması (kara mat: karadan önce)
        layer(g, picSpec, r)
        val map = if (GlobeLand.ready) GlobeLand.map else null
        if (map != null) {
            val kmin = GlobeLand.minLevel(r)
            classify(map, r, kmin)
            buildFills(map, r)
            // ülke dolguları (komşular farklı ton)
            for (k in 0 until 4) { if (groupPath[k].isEmpty) continue; g.paint(look.fill[k]); g.path(groupPath[k]) }
            // yarım ton noktaları: kara yoluyla kırpılmış, iki düzey karışımı
            // Izgara düzeyi: ekranda aralık 1–2,2 katı dışına çıkınca bir sonrakine geçilir, iki düzey kısa sürede (zamanla) karışır.
            val want = GlobeHalftone.levelFor(r).first
            if (dotLevel < 0) dotLevel = want
            else if (want != dotLevel) {
                val sp = spacingOf(dotLevel, r)
                if (sp < GlobeHalftone.MIN_SPACING * 0.88f || sp > GlobeHalftone.MIN_SPACING * 2.3f) { prevLevel = dotLevel; dotLevel = want; dotFade = 0f }
            }
            dots.clear(); dots2.clear()
            GlobeHalftone.generate(dotLevel, m, camera.lat0, camera.lon0, cx, cy, r, w, h, map, dots)
            val blend = dotFade < 1f && prevLevel >= 0
            if (blend) GlobeHalftone.generate(prevLevel, m, camera.lat0, camera.lon0, cx, cy, r, w, h, map, dots2)
            lastDots = dots.n + dots2.n
            if (!landPath.isEmpty) {
                g.save(); g.clipPath(landPath)
                g.paint(look.halftone)
                g.save(); g.alpha(if (blend) dotFade else 1f); g.dots(dots.a, dots.n, spacingOf(dotLevel, r) * HALFTONE_R, look.square); g.restore()
                if (blend) { g.save(); g.alpha(1f - dotFade); g.dots(dots2.a, dots2.n, spacingOf(prevLevel, r) * HALFTONE_R, look.square); g.restore() }
                g.restore()
            }
            // kıyılar
            buildStrokes(map, r, GlobeLand.COAST)
            g.paint(look.coast); g.strokeWidth((0.7f + 0.08f * camera.zoom.toFloat()).coerceAtMost(1.5f)); g.lines(seg, segN)
            // ülke sınırları: geniş ışıma + ince çekirdek
            buildStrokes(map, r, GlobeLand.BORDER)
            lastBorderSegs = segN
            val bw = (1.1f + 0.12f * camera.zoom.toFloat()).coerceAtMost(2.2f)
            if (!look.flat) { g.paint(Rgb.alpha(look.border, 0.2f)); g.strokeWidth(bw * 2.4f); g.lines(seg, segN) }
            g.paint(Rgb.alpha(look.border, 0.95f)); g.strokeWidth(bw); g.lines(seg, segN)
        }
        // ışık: gölge (çarpma) ve atmosfer saçılması; hazır değilse yumuşak gradyan
        if (!look.flat) {
            if (picShade != null) { layer(g, picShade, r); layer(g, picAtmo, r) }
            else fallbackLight(g, look, r)
        } else { g.strokeWidth(2f); g.paint(env.theme.accent); g.strokeCircle(cx, cy, r) }
        drawMarkers(g, env, r)
        g.restore()
    }

    /** Görüntü desteklemeyen çizicilerde (ve katmanlar hazır olmadan) gradyanla yaklaşık ışık. */
    private fun fallbackLight(g: Gfx, look: GlobeLook, r: Float) {
        val hx = cx + LX * r * 0.62f; val hy = cy - LY * r * 0.62f
        val night = 0xFF000814.toInt()
        g.save(); g.clipCircle(cx, cy, r)
        g.paint(Fill.Radial(hx, hy, r * 1.8f, intArrayOf(Rgb.alpha(night, 0f), Rgb.alpha(night, 0f), Rgb.alpha(night, look.shade * 0.9f)), floatArrayOf(0f, 0.45f, 1f)))
        g.circle(cx, cy, r)
        g.restore()
        g.strokeWidth(1f); g.paint(Rgb.alpha(Rgb.WHITE, 0.28f)); g.strokeCircle(cx, cy, r)
    }

    private fun drawMarkers(g: Gfx, env: Env, r: Float) {
        val connected = Catalog.byId(model.selectedId())?.brand
        val on = model.vpn.active
        for (k in brands.indices) {
            camera.project(Math.toRadians(lats[k]), Math.toRadians(lons[k]), p)
            if (p.z <= 0.05) continue
            val x = cx + r * p.x.toFloat(); val y = cy - r * p.y.toFloat()
            val b = brands[k]
            val anycast = GlobeSites.siteOfBrand(b)!!.anycast
            val sel = b == selected
            val live = on && b == connected
            val col = if (live) 0xFF3DDC84.toInt() else if (sel) env.theme.link else 0xFFFFD166.toInt()
            val rr = if (sel) 8f else 5.5f
            val edge = (0.4f + 0.6f * p.z.toFloat()).coerceIn(0f, 1f)
            g.save(); g.alpha(edge)
            if (live) { val pulse = (clock % 1.6f) / 1.6f; g.paint(Rgb.alpha(col, 0.5f * (1 - pulse))); g.circle(x, y, rr + 14f * pulse) }
            g.paint(Fill.radial(x, y, rr * 2.6f, Rgb.alpha(col, 0.45f), Rgb.alpha(col, 0f))); g.circle(x, y, rr * 2.6f)
            g.paint(Rgb.alpha(0xFF000000.toInt(), 0.4f)); g.circle(x, y + 1f, rr + 1.5f)
            if (anycast) { g.strokeWidth(2.4f); g.paint(col); g.strokeCircle(x, y, rr); g.circle(x, y, rr * 0.38f) }
            else { g.paint(col); g.circle(x, y, rr) }
            g.restore()
            // yakın planda tüm görünen sağlayıcıların adı (seçili/bağlı önce; çakışan etiket atlanır)
            if (sel || live || camera.zoom >= LABEL_ZOOM) labelReq.add(Label3(b, x, y - rr, if (sel || live) 0 else 1))
        }
        labelReq.sortBy { it.prio }
        placed.clear()
        val fs = env.sz(12f)
        for (lb in labelReq) {
            val tw = env.metrics.textWidth(lb.text, fs, true)
            val l = lb.x - tw / 2 - 6f; val t = lb.top - fs - 10f; val rr2 = lb.x + tw / 2 + 6f; val bt = lb.top - 3f
            if (placed.any { it[0] < rr2 && l < it[2] && it[1] < bt && t < it[3] }) continue
            placed.add(floatArrayOf(l, t, rr2, bt))
            g.paint(Rgb.alpha(0xFF000000.toInt(), 0.6f)); g.roundRect(l, t, rr2, bt, 6f)
            g.paint(Rgb.WHITE); g.text(lb.text, lb.x, lb.top - 7f, fs, true, ALIGN_CENTER)
        }
        labelReq.clear()
    }

    override fun a11y(): A11y = A11y(Strings.GLOBE + ": " + (selected ?: Strings.GLOBE_PICK), Role.TEXT)

    companion object {
        /** Arka yüzdeki/ekran dışındaki yaylarda kullanılan kaba düzey (halkalar kapansın diye). */
        const val COARSE = 5
        /** Işık katmanlarının çözünürlüğü (piksel). */
        const val SHADE_PX = 512
        const val LABEL_ZOOM = 3.0
        /** Yarım ton noktasının yarıçapı / ızgara aralığı. */
        const val HALFTONE_R = 0.3f
        val LX = GlobeShading.LX; val LY = GlobeShading.LY

        /** Enlem/boylam ızgarası (30°), 4°'lik adımlarla dünya vektörleri. */
        val GRID: GlobeLand.Lines by lazy {
            val xyz = ArrayList<Float>(); val st = ArrayList<Int>()
            fun pt(la: Double, lo: Double) { val a = Math.toRadians(la); val o = Math.toRadians(lo); xyz.add((cos(a) * cos(o)).toFloat()); xyz.add((cos(a) * sin(o)).toFloat()); xyz.add(sin(a).toFloat()) }
            for (la in -60..60 step 30) { st.add(xyz.size / 3); for (lo in -180..180 step 4) pt(la.toDouble(), lo.toDouble()) }
            for (lo in -180 until 180 step 30) { st.add(xyz.size / 3); for (la in -80..80 step 4) pt(la.toDouble(), lo.toDouble()) }
            st.add(xyz.size / 3)
            GlobeLand.Lines(xyz.toFloatArray(), st.toIntArray())
        }
    }
}
