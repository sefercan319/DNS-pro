package app.dnshizli.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Küre kamerası ve dik izdüşüm (orthographic). Saf matematik: arayüzden bağımsız sınanır.
 *  - [lon0]/[lat0]: ekran merkezindeki nokta (radyan); [zoom] 1..[MAX_ZOOM].
 *  - Sürükleme küreyi parmakla birlikte döndürür; bırakınca atalet sürer (parmak durup kalkarsa savrulmaz).
 *  - Yakınlaştırma parmakların altındaki noktayı yerinde tutar; çift dokunma ve seçim yumuşak uçuşla ([flyTo]) gelir.
 *  - Boşta yavaşça kendiliğinden döner (hareket açıksa).
 */
class GlobeCamera(var lon0: Double = Math.toRadians(30.0), var lat0: Double = Math.toRadians(30.0), var zoom: Double = 1.0) {
    private var vLon = 0.0
    private var vLat = 0.0
    private var idle = 0.0
    /** Yumuşak yakınlaştırmanın hedefi (çift dokunma, uçuş); iki parmak doğrudan [zoom]'u değiştirir. */
    var zoomTarget = zoom; private set
    private var flyLat = Double.NaN
    private var flyLon = Double.NaN
    private var flyVLon = 0.0
    private var flyVLat = 0.0
    /** İki parmak sürüyor mu; yakınlaştırma hızı (ln zoom / sn) bırakınca süzülme için. */
    var pinching = false; private set
    private var vZoom = 0.0
    var dragging = false; private set

    /** İzdüşüm sonucu: ekran x, y (merkezli, yarıçap 1) ve derinlik z (> 0 görünür yüz). */
    class P { var x = 0.0; var y = 0.0; var z = 0.0 }

    fun project(lat: Double, lon: Double, out: P): P {
        val sl = sin(lat); val cl = cos(lat)
        return projectSc(sl, cl, lon, out)
    }

    fun projectSc(sinLat: Double, cosLat: Double, lon: Double, out: P): P {
        val d = lon - lon0
        val cd = cos(d)
        val s0 = sin(lat0); val c0 = cos(lat0)
        out.x = cosLat * sin(d)
        out.y = c0 * sinLat - s0 * cosLat * cd
        out.z = s0 * sinLat + c0 * cosLat * cd
        return out
    }

    /**
     * Dünya birim vektörünü (x = cosφ·cosλ, y = cosφ·sinλ, z = sinφ) görünüme çeviren 3×3 matris (satır düzeninde) [m]'ye yazılır.
     * Binlerce noktayı karede trigonometri olmadan çevirmek için: görünüm = m · dünya. [project] ile aynı sonucu verir.
     */
    fun matrix(m: FloatArray) {
        val sl = sin(lon0); val cl = cos(lon0); val s0 = sin(lat0); val c0 = cos(lat0)
        m[0] = (-sl).toFloat(); m[1] = cl.toFloat(); m[2] = 0f
        m[3] = (-s0 * cl).toFloat(); m[4] = (-s0 * sl).toFloat(); m[5] = c0.toFloat()
        m[6] = (c0 * cl).toFloat(); m[7] = (c0 * sl).toFloat(); m[8] = s0.toFloat()
    }

    /** Ekran noktası (merkezli, yarıçap 1; y yukarı) kürenin ön yüzündeyse enlem/boylamı (radyan) [out]'a yazar; değilse false. */
    fun unproject(x: Double, y: Double, out: DoubleArray): Boolean {
        val q = x * x + y * y
        if (q >= 1.0) return false
        val z = sqrt(1 - q)
        val sl = sin(lon0); val cl = cos(lon0); val s0 = sin(lat0); val c0 = cos(lat0)
        // dünya = mᵀ · görünüm
        val wx = -sl * x - s0 * cl * y + c0 * cl * z
        val wy = cl * x - s0 * sl * y + c0 * sl * z
        val wz = c0 * y + s0 * z
        out[0] = asin(wz.coerceIn(-1.0, 1.0)); out[1] = atan2(wy, wx)
        return true
    }

    fun beginDrag() { dragging = true; vLon = 0.0; vLat = 0.0; idle = 0.0; cancelFly() }

    /** Ekran pikseli (dp) cinsinden sürükleme; [r] kürenin ekrandaki yarıçapı. [dtSec] hız tahmini için. */
    fun dragBy(dx: Double, dy: Double, r: Double, dtSec: Double) {
        val dl = -dx / r; var dp = dy / r
        lon0 = wrap(lon0 + dl)
        // Kutup sınırında lastik: sınırı aşan eğim dirençle sürer, bırakınca yay gibi geri gelir.
        val over = abs(lat0) - MAX_TILT
        if (over > 0 && dp * lat0 > 0) dp *= 0.35 * (1 - over / OVER_TILT).coerceIn(0.0, 1.0)
        lat0 = (lat0 + dp).coerceIn(-MAX_TILT - OVER_TILT, MAX_TILT + OVER_TILT)
        if (dtSec > 0.0) {
            // Kısa aralıklar hızı abartmasın: ağırlık aralıkla orantılı (60 Hz'de ~0.35)
            val k = (dtSec / 0.045).coerceIn(0.15, 0.8)
            vLon = (1 - k) * vLon + k * (dl / dtSec); vLat = (1 - k) * vLat + k * (dp / dtSec)
        }
    }

    /** [heldSec]: son hareketten bırakmaya kadar geçen süre; parmak durup kalktıysa atalet yok. */
    fun endDrag(heldSec: Double = 0.0) {
        dragging = false; idle = 0.0
        if (pinching) {
            pinching = false
            // Bırakınca kısa süzülme (parmaklar durmadıysa), sonra sınırların içine yay gibi döner.
            val glide = if (heldSec <= STILL_SEC) vZoom.coerceIn(-6.0, 6.0) * 0.12 else 0.0
            zoomTarget = (zoom * exp(glide)).coerceIn(1.0, MAX_ZOOM); vZoom = 0.0
        }
        if (heldSec > STILL_SEC) { vLon = 0.0; vLat = 0.0 }
        val sp = sqrt(vLon * vLon + vLat * vLat)
        if (sp > MAX_SPEED) { vLon *= MAX_SPEED / sp; vLat *= MAX_SPEED / sp }
    }

    fun zoomBy(f: Double) { zoom = (zoom * f).coerceIn(1.0, MAX_ZOOM); zoomTarget = zoom; idle = 0.0 }

    /**
     * İki parmak: [f] kat yakınlaştırır, parmakların ortası ([ux], [uy]: merkezden dp, y aşağı) altındaki nokta yerinde kalır.
     * [r1]: zoom = 1 iken kürenin yarıçapı (dp).
     */
    fun zoomAt(f: Double, ux: Double, uy: Double, r1: Double, dtSec: Double = 0.0) {
        val rOld = r1 * zoom
        val ll = DoubleArray(2)
        val hit = unproject(ux / rOld, -uy / rOld, ll)
        pinching = true; idle = 0.0
        // Sınır dışında lastik: aşan kısım dirençle büyür (bırakınca geri döner).
        val lo = 0.0; val hi = kotlin.math.ln(MAX_ZOOM)
        var lz = kotlin.math.ln(zoom); val step = kotlin.math.ln(f)
        val outside = (lz >= hi && step > 0) || (lz <= lo && step < 0)
        lz += if (outside) step * 0.3 else step
        zoom = exp(lz.coerceIn(lo - OVER_ZOOM, hi + OVER_ZOOM)); zoomTarget = zoom
        if (dtSec > 0) vZoom = 0.6 * vZoom + 0.4 * (step / dtSec)
        cancelFly()
        if (hit) keepUnder(ll[0], ll[1], ux, uy, r1 * zoom)
    }

    /** [lat]/[lon]'u ekranda merkezden ([ux], [uy]) uzağa (yarıçap [r]) getirecek şekilde kamerayı çevirir (birkaç yakınsama adımı). */
    private fun keepUnder(lat: Double, lon: Double, ux: Double, uy: Double, r: Double) {
        val p = P()
        repeat(6) {
            project(lat, lon, p)
            val ex = ux / r - p.x; val ey = -uy / r - p.y
            if (abs(ex) < 1e-5 && abs(ey) < 1e-5) return
            val c = cos(lat).coerceAtLeast(0.3)
            lon0 = wrap(lon0 - ex / c)
            lat0 = (lat0 - ey).coerceIn(-MAX_TILT, MAX_TILT)
        }
    }

    /** Çift dokunma: 1 → 2 → 4 → 1 (yumuşak geçiş; hedef [zoomTarget]). */
    fun zoomStep() { zoomTarget = when { zoomTarget < 1.9 -> 2.0; zoomTarget < 3.9 -> 4.0; else -> 1.0 }; idle = 0.0 }

    /** Çift dokunma bir noktaya: o noktaya uçar ve bir kademe yakınlaşır. */
    fun zoomStepAt(lat: Double, lon: Double) { zoomStep(); if (zoomTarget > 1.0) flyTo(lat, lon) }

    /** [lat]/[lon]'u merkeze getirir (anında). */
    fun focus(lat: Double, lon: Double) { lon0 = wrap(lon); lat0 = lat.coerceIn(-MAX_TILT, MAX_TILT); vLon = 0.0; vLat = 0.0; idle = 0.0; cancelFly() }

    /** [lat]/[lon]'u merkeze yumuşakça getirir (kısa yoldan). */
    fun flyTo(lat: Double, lon: Double) {
        // atalet uçuşa hız olarak devredilir: savrulan küre hedefe doğru kıvrılır, sıçramaz
        if (!flying) { flyVLon = vLon; flyVLat = vLat }
        flyLat = lat.coerceIn(-MAX_TILT, MAX_TILT); flyLon = wrap(lon); vLon = 0.0; vLat = 0.0; idle = 0.0
    }

    val flying: Boolean get() = !flyLat.isNaN()

    private fun cancelFly() { flyLat = Double.NaN; flyLon = Double.NaN; flyVLon = 0.0; flyVLat = 0.0 }

    /** Atalet, uçuş, yumuşak yakınlaştırma ve boşta dönme. Hareket sürüyorsa true. */
    fun tick(dt: Double, autoSpin: Boolean): Boolean {
        if (dragging) return true
        var moving = false
        if (abs(zoom - zoomTarget) > 1e-3) {
            zoom = zoomTarget + (zoom - zoomTarget) * exp(-dt * ZOOM_RATE)
            moving = true; idle = 0.0
        } else zoom = zoomTarget
        // kutup lastiği geri yaylanır
        val over = abs(lat0) - MAX_TILT
        if (over > 0) {
            lat0 = kotlin.math.sign(lat0) * (MAX_TILT + over * exp(-dt * 12.0)); if (over < 1e-4) lat0 = kotlin.math.sign(lat0) * MAX_TILT
            vLat = 0.0; moving = true
        }
        if (flying) {
            // kritik sönümlü yay (yumuşak kalkış ve iniş, aşma yok); büyük adımlar alt adımlara bölünür
            var left = dt
            while (left > 0 && flying) {
                val h = minOf(left, 1.0 / 120); left -= h
                val dl = wrap(flyLon - lon0); val dp = flyLat - lat0
                flyVLon += (FLY_W * FLY_W * dl - 2 * FLY_W * flyVLon) * h
                flyVLat += (FLY_W * FLY_W * dp - 2 * FLY_W * flyVLat) * h
                lon0 = wrap(lon0 + flyVLon * h); lat0 += flyVLat * h
                if (abs(dl) < 1e-5 && abs(dp) < 1e-5 && abs(flyVLon) < 1e-3 && abs(flyVLat) < 1e-3) { lon0 = flyLon; lat0 = flyLat; cancelFly() }
            }
            moving = true; idle = 0.0
        } else if (abs(vLon) > 1e-3 || abs(vLat) > 1e-3) {
            lon0 = wrap(lon0 + vLon * dt); lat0 = (lat0 + vLat * dt).coerceIn(-MAX_TILT, MAX_TILT)
            if (abs(lat0) >= MAX_TILT) vLat = 0.0                      // kutupta eğim hızı söner, sekmez
            val k = exp(-dt * FRICTION); vLon *= k; vLat *= k
            moving = true; idle = 0.0
        } else { vLon = 0.0; vLat = 0.0; idle += dt }
        if (autoSpin && idle > IDLE_SPIN_AFTER && zoom < 1.5) {
            // dönmeye yumuşak başla (ani sıçrama yok)
            val ramp = ((idle - IDLE_SPIN_AFTER) / 1.5).coerceIn(0.0, 1.0)
            lon0 = wrap(lon0 - SPIN * ramp * dt); moving = true
        }
        return moving
    }

    /** Görünür noktalardan ekran konumu (merkez cx, cy; yarıçap r) [x],[y]'ye en yakın olanın sırası; [maxDist] içinde yoksa -1. */
    fun pick(x: Double, y: Double, cx: Double, cy: Double, r: Double, lats: DoubleArray, lons: DoubleArray, maxDist: Double): Int {
        val p = P(); var best = -1; var bd = maxDist * maxDist
        for (i in lats.indices) {
            project(Math.toRadians(lats[i]), Math.toRadians(lons[i]), p)
            if (p.z <= 0.05) continue
            val dx = cx + r * p.x - x; val dy = cy - r * p.y - y
            val d = dx * dx + dy * dy
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    companion object {
        const val MAX_ZOOM = 12.0
        /** Kutup ve yakınlaştırma lastiğinin en çok aşımı (radyan; ln zoom). */
        const val OVER_TILT = 0.25
        const val OVER_ZOOM = 0.3
        const val FLY_W = 7.0
        val MAX_TILT = Math.toRadians(75.0)
        const val SPIN = 0.06                // rad/sn
        const val IDLE_SPIN_AFTER = 4.0      // sn
        const val FRICTION = 2.6             // atalet sönümü (1/sn)
        const val MAX_SPEED = 9.0            // rad/sn: sert savurmada küre fırıl fırıl dönmesin
        const val STILL_SEC = 0.08           // bu kadar durup kaldırılan parmak savurmaz
        const val ZOOM_RATE = 9.0
        fun wrap(a: Double): Double { var v = a % (2 * PI); if (v > PI) v -= 2 * PI; if (v < -PI) v += 2 * PI; return v }
    }
}
